<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-07 04:00:30 --> Config Class Initialized
INFO - 2023-01-07 04:00:30 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:00:30 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:00:30 --> Utf8 Class Initialized
INFO - 2023-01-07 04:00:30 --> URI Class Initialized
INFO - 2023-01-07 04:00:30 --> Router Class Initialized
INFO - 2023-01-07 04:00:30 --> Output Class Initialized
INFO - 2023-01-07 04:00:30 --> Security Class Initialized
DEBUG - 2023-01-07 04:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:00:30 --> Input Class Initialized
INFO - 2023-01-07 04:00:30 --> Language Class Initialized
INFO - 2023-01-07 04:00:30 --> Language Class Initialized
INFO - 2023-01-07 04:00:30 --> Config Class Initialized
INFO - 2023-01-07 04:00:30 --> Loader Class Initialized
INFO - 2023-01-07 04:00:30 --> Helper loaded: url_helper
INFO - 2023-01-07 04:00:30 --> Helper loaded: file_helper
INFO - 2023-01-07 04:00:30 --> Helper loaded: form_helper
INFO - 2023-01-07 04:00:30 --> Helper loaded: my_helper
INFO - 2023-01-07 04:00:30 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:00:30 --> Controller Class Initialized
DEBUG - 2023-01-07 04:00:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:00:30 --> Final output sent to browser
DEBUG - 2023-01-07 04:00:30 --> Total execution time: 0.1974
INFO - 2023-01-07 04:00:50 --> Config Class Initialized
INFO - 2023-01-07 04:00:50 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:00:50 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:00:50 --> Utf8 Class Initialized
INFO - 2023-01-07 04:00:50 --> URI Class Initialized
INFO - 2023-01-07 04:00:50 --> Router Class Initialized
INFO - 2023-01-07 04:00:50 --> Output Class Initialized
INFO - 2023-01-07 04:00:50 --> Security Class Initialized
DEBUG - 2023-01-07 04:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:00:50 --> Input Class Initialized
INFO - 2023-01-07 04:00:50 --> Language Class Initialized
INFO - 2023-01-07 04:00:50 --> Language Class Initialized
INFO - 2023-01-07 04:00:50 --> Config Class Initialized
INFO - 2023-01-07 04:00:50 --> Loader Class Initialized
INFO - 2023-01-07 04:00:50 --> Helper loaded: url_helper
INFO - 2023-01-07 04:00:50 --> Helper loaded: file_helper
INFO - 2023-01-07 04:00:50 --> Helper loaded: form_helper
INFO - 2023-01-07 04:00:50 --> Helper loaded: my_helper
INFO - 2023-01-07 04:00:50 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:00:50 --> Controller Class Initialized
DEBUG - 2023-01-07 04:00:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:00:51 --> Final output sent to browser
DEBUG - 2023-01-07 04:00:51 --> Total execution time: 0.1657
INFO - 2023-01-07 04:01:15 --> Config Class Initialized
INFO - 2023-01-07 04:01:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:01:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:01:15 --> Utf8 Class Initialized
INFO - 2023-01-07 04:01:15 --> URI Class Initialized
INFO - 2023-01-07 04:01:15 --> Router Class Initialized
INFO - 2023-01-07 04:01:15 --> Output Class Initialized
INFO - 2023-01-07 04:01:15 --> Security Class Initialized
DEBUG - 2023-01-07 04:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:01:15 --> Input Class Initialized
INFO - 2023-01-07 04:01:15 --> Language Class Initialized
INFO - 2023-01-07 04:01:15 --> Language Class Initialized
INFO - 2023-01-07 04:01:15 --> Config Class Initialized
INFO - 2023-01-07 04:01:15 --> Loader Class Initialized
INFO - 2023-01-07 04:01:15 --> Helper loaded: url_helper
INFO - 2023-01-07 04:01:15 --> Helper loaded: file_helper
INFO - 2023-01-07 04:01:15 --> Helper loaded: form_helper
INFO - 2023-01-07 04:01:15 --> Helper loaded: my_helper
INFO - 2023-01-07 04:01:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:01:15 --> Controller Class Initialized
ERROR - 2023-01-07 04:01:15 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:01:15 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:01:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:01:15 --> Final output sent to browser
DEBUG - 2023-01-07 04:01:15 --> Total execution time: 0.0389
INFO - 2023-01-07 04:01:18 --> Config Class Initialized
INFO - 2023-01-07 04:01:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:01:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:01:18 --> Utf8 Class Initialized
INFO - 2023-01-07 04:01:18 --> URI Class Initialized
INFO - 2023-01-07 04:01:18 --> Router Class Initialized
INFO - 2023-01-07 04:01:18 --> Output Class Initialized
INFO - 2023-01-07 04:01:18 --> Security Class Initialized
DEBUG - 2023-01-07 04:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:01:18 --> Input Class Initialized
INFO - 2023-01-07 04:01:18 --> Language Class Initialized
INFO - 2023-01-07 04:01:18 --> Language Class Initialized
INFO - 2023-01-07 04:01:18 --> Config Class Initialized
INFO - 2023-01-07 04:01:18 --> Loader Class Initialized
INFO - 2023-01-07 04:01:18 --> Helper loaded: url_helper
INFO - 2023-01-07 04:01:18 --> Helper loaded: file_helper
INFO - 2023-01-07 04:01:18 --> Helper loaded: form_helper
INFO - 2023-01-07 04:01:18 --> Helper loaded: my_helper
INFO - 2023-01-07 04:01:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:01:18 --> Controller Class Initialized
ERROR - 2023-01-07 04:01:18 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:01:18 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:01:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:01:18 --> Final output sent to browser
DEBUG - 2023-01-07 04:01:18 --> Total execution time: 0.0339
INFO - 2023-01-07 04:01:19 --> Config Class Initialized
INFO - 2023-01-07 04:01:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:01:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:01:19 --> Utf8 Class Initialized
INFO - 2023-01-07 04:01:19 --> URI Class Initialized
INFO - 2023-01-07 04:01:19 --> Router Class Initialized
INFO - 2023-01-07 04:01:19 --> Output Class Initialized
INFO - 2023-01-07 04:01:19 --> Security Class Initialized
DEBUG - 2023-01-07 04:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:01:19 --> Input Class Initialized
INFO - 2023-01-07 04:01:19 --> Language Class Initialized
INFO - 2023-01-07 04:01:19 --> Language Class Initialized
INFO - 2023-01-07 04:01:19 --> Config Class Initialized
INFO - 2023-01-07 04:01:19 --> Loader Class Initialized
INFO - 2023-01-07 04:01:19 --> Helper loaded: url_helper
INFO - 2023-01-07 04:01:19 --> Helper loaded: file_helper
INFO - 2023-01-07 04:01:19 --> Helper loaded: form_helper
INFO - 2023-01-07 04:01:19 --> Helper loaded: my_helper
INFO - 2023-01-07 04:01:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:01:19 --> Controller Class Initialized
ERROR - 2023-01-07 04:01:19 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:01:19 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:01:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:01:19 --> Final output sent to browser
DEBUG - 2023-01-07 04:01:19 --> Total execution time: 0.0600
INFO - 2023-01-07 04:01:59 --> Config Class Initialized
INFO - 2023-01-07 04:01:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:01:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:01:59 --> Utf8 Class Initialized
INFO - 2023-01-07 04:01:59 --> URI Class Initialized
INFO - 2023-01-07 04:01:59 --> Router Class Initialized
INFO - 2023-01-07 04:01:59 --> Output Class Initialized
INFO - 2023-01-07 04:01:59 --> Security Class Initialized
DEBUG - 2023-01-07 04:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:01:59 --> Input Class Initialized
INFO - 2023-01-07 04:01:59 --> Language Class Initialized
INFO - 2023-01-07 04:01:59 --> Language Class Initialized
INFO - 2023-01-07 04:01:59 --> Config Class Initialized
INFO - 2023-01-07 04:01:59 --> Loader Class Initialized
INFO - 2023-01-07 04:01:59 --> Helper loaded: url_helper
INFO - 2023-01-07 04:01:59 --> Helper loaded: file_helper
INFO - 2023-01-07 04:01:59 --> Helper loaded: form_helper
INFO - 2023-01-07 04:01:59 --> Helper loaded: my_helper
INFO - 2023-01-07 04:01:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:01:59 --> Controller Class Initialized
ERROR - 2023-01-07 04:01:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:01:59 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:01:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:01:59 --> Final output sent to browser
DEBUG - 2023-01-07 04:01:59 --> Total execution time: 0.0590
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:01 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:01 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:01 --> URI Class Initialized
INFO - 2023-01-07 04:02:01 --> Router Class Initialized
INFO - 2023-01-07 04:02:01 --> Output Class Initialized
INFO - 2023-01-07 04:02:01 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:01 --> Input Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Loader Class Initialized
INFO - 2023-01-07 04:02:01 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:01 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:01 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:01 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:01 --> Total execution time: 0.0357
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:01 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:01 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:01 --> URI Class Initialized
INFO - 2023-01-07 04:02:01 --> Router Class Initialized
INFO - 2023-01-07 04:02:01 --> Output Class Initialized
INFO - 2023-01-07 04:02:01 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:01 --> Input Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Loader Class Initialized
INFO - 2023-01-07 04:02:01 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:01 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:01 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:01 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:01 --> Total execution time: 0.0481
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:01 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:01 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:01 --> URI Class Initialized
INFO - 2023-01-07 04:02:01 --> Router Class Initialized
INFO - 2023-01-07 04:02:01 --> Output Class Initialized
INFO - 2023-01-07 04:02:01 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:01 --> Input Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Language Class Initialized
INFO - 2023-01-07 04:02:01 --> Config Class Initialized
INFO - 2023-01-07 04:02:01 --> Loader Class Initialized
INFO - 2023-01-07 04:02:01 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:01 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:01 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:01 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:01 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:01 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:01 --> Total execution time: 0.0566
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:02 --> URI Class Initialized
INFO - 2023-01-07 04:02:02 --> Router Class Initialized
INFO - 2023-01-07 04:02:02 --> Output Class Initialized
INFO - 2023-01-07 04:02:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:02 --> Input Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Loader Class Initialized
INFO - 2023-01-07 04:02:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:02 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:02 --> Total execution time: 0.0338
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:02 --> URI Class Initialized
INFO - 2023-01-07 04:02:02 --> Router Class Initialized
INFO - 2023-01-07 04:02:02 --> Output Class Initialized
INFO - 2023-01-07 04:02:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:02 --> Input Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Loader Class Initialized
INFO - 2023-01-07 04:02:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:02 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:02 --> Total execution time: 0.0312
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:02 --> URI Class Initialized
INFO - 2023-01-07 04:02:02 --> Router Class Initialized
INFO - 2023-01-07 04:02:02 --> Output Class Initialized
INFO - 2023-01-07 04:02:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:02 --> Input Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Language Class Initialized
INFO - 2023-01-07 04:02:02 --> Config Class Initialized
INFO - 2023-01-07 04:02:02 --> Loader Class Initialized
INFO - 2023-01-07 04:02:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:02 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:02 --> Total execution time: 0.0551
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:03 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:03 --> URI Class Initialized
INFO - 2023-01-07 04:02:03 --> Router Class Initialized
INFO - 2023-01-07 04:02:03 --> Output Class Initialized
INFO - 2023-01-07 04:02:03 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:03 --> Input Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Loader Class Initialized
INFO - 2023-01-07 04:02:03 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:03 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:03 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:03 --> Total execution time: 0.0502
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:03 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:03 --> URI Class Initialized
INFO - 2023-01-07 04:02:03 --> Router Class Initialized
INFO - 2023-01-07 04:02:03 --> Output Class Initialized
INFO - 2023-01-07 04:02:03 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:03 --> Input Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Loader Class Initialized
INFO - 2023-01-07 04:02:03 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:03 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:03 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:03 --> Total execution time: 0.0347
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:03 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:03 --> URI Class Initialized
INFO - 2023-01-07 04:02:03 --> Router Class Initialized
INFO - 2023-01-07 04:02:03 --> Output Class Initialized
INFO - 2023-01-07 04:02:03 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:03 --> Input Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Language Class Initialized
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Loader Class Initialized
INFO - 2023-01-07 04:02:03 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:03 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:03 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:03 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:03 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:03 --> Total execution time: 0.0488
INFO - 2023-01-07 04:02:03 --> Config Class Initialized
INFO - 2023-01-07 04:02:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:03 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:03 --> URI Class Initialized
INFO - 2023-01-07 04:02:04 --> Router Class Initialized
INFO - 2023-01-07 04:02:04 --> Output Class Initialized
INFO - 2023-01-07 04:02:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:04 --> Input Class Initialized
INFO - 2023-01-07 04:02:04 --> Language Class Initialized
INFO - 2023-01-07 04:02:04 --> Language Class Initialized
INFO - 2023-01-07 04:02:04 --> Config Class Initialized
INFO - 2023-01-07 04:02:04 --> Loader Class Initialized
INFO - 2023-01-07 04:02:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:04 --> Total execution time: 0.0330
INFO - 2023-01-07 04:02:04 --> Config Class Initialized
INFO - 2023-01-07 04:02:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:04 --> URI Class Initialized
INFO - 2023-01-07 04:02:04 --> Router Class Initialized
INFO - 2023-01-07 04:02:04 --> Output Class Initialized
INFO - 2023-01-07 04:02:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:04 --> Input Class Initialized
INFO - 2023-01-07 04:02:04 --> Language Class Initialized
INFO - 2023-01-07 04:02:04 --> Language Class Initialized
INFO - 2023-01-07 04:02:04 --> Config Class Initialized
INFO - 2023-01-07 04:02:04 --> Loader Class Initialized
INFO - 2023-01-07 04:02:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:04 --> Total execution time: 0.0500
INFO - 2023-01-07 04:02:31 --> Config Class Initialized
INFO - 2023-01-07 04:02:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:31 --> URI Class Initialized
INFO - 2023-01-07 04:02:31 --> Router Class Initialized
INFO - 2023-01-07 04:02:31 --> Output Class Initialized
INFO - 2023-01-07 04:02:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:31 --> Input Class Initialized
INFO - 2023-01-07 04:02:31 --> Language Class Initialized
INFO - 2023-01-07 04:02:31 --> Language Class Initialized
INFO - 2023-01-07 04:02:31 --> Config Class Initialized
INFO - 2023-01-07 04:02:31 --> Loader Class Initialized
INFO - 2023-01-07 04:02:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:31 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:31 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:31 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:31 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:31 --> Total execution time: 0.0338
INFO - 2023-01-07 04:02:33 --> Config Class Initialized
INFO - 2023-01-07 04:02:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:33 --> URI Class Initialized
INFO - 2023-01-07 04:02:33 --> Router Class Initialized
INFO - 2023-01-07 04:02:33 --> Output Class Initialized
INFO - 2023-01-07 04:02:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:33 --> Input Class Initialized
INFO - 2023-01-07 04:02:33 --> Language Class Initialized
INFO - 2023-01-07 04:02:33 --> Language Class Initialized
INFO - 2023-01-07 04:02:33 --> Config Class Initialized
INFO - 2023-01-07 04:02:33 --> Loader Class Initialized
INFO - 2023-01-07 04:02:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:33 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:33 --> Total execution time: 0.0305
INFO - 2023-01-07 04:02:42 --> Config Class Initialized
INFO - 2023-01-07 04:02:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:42 --> URI Class Initialized
INFO - 2023-01-07 04:02:42 --> Router Class Initialized
INFO - 2023-01-07 04:02:42 --> Output Class Initialized
INFO - 2023-01-07 04:02:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:42 --> Input Class Initialized
INFO - 2023-01-07 04:02:42 --> Language Class Initialized
INFO - 2023-01-07 04:02:42 --> Language Class Initialized
INFO - 2023-01-07 04:02:42 --> Config Class Initialized
INFO - 2023-01-07 04:02:42 --> Loader Class Initialized
INFO - 2023-01-07 04:02:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:42 --> Controller Class Initialized
DEBUG - 2023-01-07 04:02:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:02:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:42 --> Total execution time: 0.1388
INFO - 2023-01-07 04:02:57 --> Config Class Initialized
INFO - 2023-01-07 04:02:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:02:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:02:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:02:57 --> URI Class Initialized
INFO - 2023-01-07 04:02:57 --> Router Class Initialized
INFO - 2023-01-07 04:02:57 --> Output Class Initialized
INFO - 2023-01-07 04:02:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:02:57 --> Input Class Initialized
INFO - 2023-01-07 04:02:57 --> Language Class Initialized
INFO - 2023-01-07 04:02:57 --> Language Class Initialized
INFO - 2023-01-07 04:02:57 --> Config Class Initialized
INFO - 2023-01-07 04:02:57 --> Loader Class Initialized
INFO - 2023-01-07 04:02:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:02:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:02:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:02:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:02:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:02:57 --> Controller Class Initialized
ERROR - 2023-01-07 04:02:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:02:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:02:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:02:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:02:57 --> Total execution time: 0.0351
INFO - 2023-01-07 04:03:55 --> Config Class Initialized
INFO - 2023-01-07 04:03:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:03:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:03:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:03:55 --> URI Class Initialized
INFO - 2023-01-07 04:03:55 --> Router Class Initialized
INFO - 2023-01-07 04:03:55 --> Output Class Initialized
INFO - 2023-01-07 04:03:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:03:55 --> Input Class Initialized
INFO - 2023-01-07 04:03:55 --> Language Class Initialized
INFO - 2023-01-07 04:03:55 --> Language Class Initialized
INFO - 2023-01-07 04:03:55 --> Config Class Initialized
INFO - 2023-01-07 04:03:55 --> Loader Class Initialized
INFO - 2023-01-07 04:03:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:03:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:03:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:03:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:03:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:03:55 --> Controller Class Initialized
INFO - 2023-01-07 04:03:55 --> Final output sent to browser
DEBUG - 2023-01-07 04:03:55 --> Total execution time: 0.0297
INFO - 2023-01-07 04:03:58 --> Config Class Initialized
INFO - 2023-01-07 04:03:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:03:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:03:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:03:58 --> URI Class Initialized
INFO - 2023-01-07 04:03:58 --> Router Class Initialized
INFO - 2023-01-07 04:03:58 --> Output Class Initialized
INFO - 2023-01-07 04:03:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:03:58 --> Input Class Initialized
INFO - 2023-01-07 04:03:58 --> Language Class Initialized
INFO - 2023-01-07 04:03:58 --> Language Class Initialized
INFO - 2023-01-07 04:03:58 --> Config Class Initialized
INFO - 2023-01-07 04:03:58 --> Loader Class Initialized
INFO - 2023-01-07 04:03:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:03:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:03:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:03:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:03:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:03:58 --> Controller Class Initialized
INFO - 2023-01-07 04:03:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:03:58 --> Total execution time: 0.0272
INFO - 2023-01-07 04:04:00 --> Config Class Initialized
INFO - 2023-01-07 04:04:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:00 --> URI Class Initialized
INFO - 2023-01-07 04:04:00 --> Router Class Initialized
INFO - 2023-01-07 04:04:00 --> Output Class Initialized
INFO - 2023-01-07 04:04:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:00 --> Input Class Initialized
INFO - 2023-01-07 04:04:00 --> Language Class Initialized
INFO - 2023-01-07 04:04:00 --> Language Class Initialized
INFO - 2023-01-07 04:04:00 --> Config Class Initialized
INFO - 2023-01-07 04:04:00 --> Loader Class Initialized
INFO - 2023-01-07 04:04:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:00 --> Controller Class Initialized
INFO - 2023-01-07 04:04:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:00 --> Total execution time: 0.0441
INFO - 2023-01-07 04:04:02 --> Config Class Initialized
INFO - 2023-01-07 04:04:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:02 --> URI Class Initialized
INFO - 2023-01-07 04:04:02 --> Router Class Initialized
INFO - 2023-01-07 04:04:02 --> Output Class Initialized
INFO - 2023-01-07 04:04:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:02 --> Input Class Initialized
INFO - 2023-01-07 04:04:02 --> Language Class Initialized
INFO - 2023-01-07 04:04:02 --> Language Class Initialized
INFO - 2023-01-07 04:04:02 --> Config Class Initialized
INFO - 2023-01-07 04:04:02 --> Loader Class Initialized
INFO - 2023-01-07 04:04:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:02 --> Controller Class Initialized
DEBUG - 2023-01-07 04:04:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:04:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:04:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:02 --> Total execution time: 0.0334
INFO - 2023-01-07 04:04:02 --> Config Class Initialized
INFO - 2023-01-07 04:04:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:02 --> URI Class Initialized
INFO - 2023-01-07 04:04:02 --> Router Class Initialized
INFO - 2023-01-07 04:04:02 --> Output Class Initialized
INFO - 2023-01-07 04:04:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:02 --> Input Class Initialized
INFO - 2023-01-07 04:04:02 --> Language Class Initialized
INFO - 2023-01-07 04:04:02 --> Language Class Initialized
INFO - 2023-01-07 04:04:02 --> Config Class Initialized
INFO - 2023-01-07 04:04:02 --> Loader Class Initialized
INFO - 2023-01-07 04:04:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:02 --> Controller Class Initialized
INFO - 2023-01-07 04:04:04 --> Config Class Initialized
INFO - 2023-01-07 04:04:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:04 --> URI Class Initialized
INFO - 2023-01-07 04:04:04 --> Router Class Initialized
INFO - 2023-01-07 04:04:04 --> Output Class Initialized
INFO - 2023-01-07 04:04:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:04 --> Input Class Initialized
INFO - 2023-01-07 04:04:04 --> Language Class Initialized
INFO - 2023-01-07 04:04:04 --> Language Class Initialized
INFO - 2023-01-07 04:04:04 --> Config Class Initialized
INFO - 2023-01-07 04:04:04 --> Loader Class Initialized
INFO - 2023-01-07 04:04:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:04 --> Controller Class Initialized
INFO - 2023-01-07 04:04:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:04 --> Total execution time: 0.0314
INFO - 2023-01-07 04:04:06 --> Config Class Initialized
INFO - 2023-01-07 04:04:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:06 --> URI Class Initialized
INFO - 2023-01-07 04:04:06 --> Router Class Initialized
INFO - 2023-01-07 04:04:06 --> Output Class Initialized
INFO - 2023-01-07 04:04:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:06 --> Input Class Initialized
INFO - 2023-01-07 04:04:06 --> Language Class Initialized
INFO - 2023-01-07 04:04:06 --> Language Class Initialized
INFO - 2023-01-07 04:04:06 --> Config Class Initialized
INFO - 2023-01-07 04:04:06 --> Loader Class Initialized
INFO - 2023-01-07 04:04:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:06 --> Controller Class Initialized
INFO - 2023-01-07 04:04:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:06 --> Total execution time: 0.0273
INFO - 2023-01-07 04:04:07 --> Config Class Initialized
INFO - 2023-01-07 04:04:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:07 --> URI Class Initialized
INFO - 2023-01-07 04:04:07 --> Router Class Initialized
INFO - 2023-01-07 04:04:07 --> Output Class Initialized
INFO - 2023-01-07 04:04:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:07 --> Input Class Initialized
INFO - 2023-01-07 04:04:07 --> Language Class Initialized
INFO - 2023-01-07 04:04:07 --> Language Class Initialized
INFO - 2023-01-07 04:04:07 --> Config Class Initialized
INFO - 2023-01-07 04:04:07 --> Loader Class Initialized
INFO - 2023-01-07 04:04:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:07 --> Controller Class Initialized
ERROR - 2023-01-07 04:04:07 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:04:07 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:04:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:04:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:07 --> Total execution time: 0.0394
INFO - 2023-01-07 04:04:11 --> Config Class Initialized
INFO - 2023-01-07 04:04:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:11 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:11 --> URI Class Initialized
INFO - 2023-01-07 04:04:11 --> Router Class Initialized
INFO - 2023-01-07 04:04:11 --> Output Class Initialized
INFO - 2023-01-07 04:04:11 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:11 --> Input Class Initialized
INFO - 2023-01-07 04:04:11 --> Language Class Initialized
INFO - 2023-01-07 04:04:11 --> Language Class Initialized
INFO - 2023-01-07 04:04:11 --> Config Class Initialized
INFO - 2023-01-07 04:04:11 --> Loader Class Initialized
INFO - 2023-01-07 04:04:11 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:11 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:11 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:11 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:11 --> Controller Class Initialized
INFO - 2023-01-07 04:04:11 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:11 --> Total execution time: 0.0456
INFO - 2023-01-07 04:04:13 --> Config Class Initialized
INFO - 2023-01-07 04:04:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:13 --> URI Class Initialized
INFO - 2023-01-07 04:04:13 --> Router Class Initialized
INFO - 2023-01-07 04:04:13 --> Output Class Initialized
INFO - 2023-01-07 04:04:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:13 --> Input Class Initialized
INFO - 2023-01-07 04:04:13 --> Language Class Initialized
INFO - 2023-01-07 04:04:13 --> Language Class Initialized
INFO - 2023-01-07 04:04:13 --> Config Class Initialized
INFO - 2023-01-07 04:04:13 --> Loader Class Initialized
INFO - 2023-01-07 04:04:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:13 --> Controller Class Initialized
INFO - 2023-01-07 04:04:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:13 --> Total execution time: 0.0268
INFO - 2023-01-07 04:04:17 --> Config Class Initialized
INFO - 2023-01-07 04:04:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:17 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:17 --> URI Class Initialized
INFO - 2023-01-07 04:04:17 --> Router Class Initialized
INFO - 2023-01-07 04:04:17 --> Output Class Initialized
INFO - 2023-01-07 04:04:17 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:17 --> Input Class Initialized
INFO - 2023-01-07 04:04:17 --> Language Class Initialized
INFO - 2023-01-07 04:04:17 --> Language Class Initialized
INFO - 2023-01-07 04:04:17 --> Config Class Initialized
INFO - 2023-01-07 04:04:17 --> Loader Class Initialized
INFO - 2023-01-07 04:04:17 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:17 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:17 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:17 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:17 --> Controller Class Initialized
DEBUG - 2023-01-07 04:04:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-07 04:04:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:04:17 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:17 --> Total execution time: 0.0353
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:22 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:22 --> URI Class Initialized
INFO - 2023-01-07 04:04:22 --> Router Class Initialized
INFO - 2023-01-07 04:04:22 --> Output Class Initialized
INFO - 2023-01-07 04:04:22 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:22 --> Input Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Loader Class Initialized
INFO - 2023-01-07 04:04:22 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:22 --> Controller Class Initialized
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:22 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:22 --> URI Class Initialized
INFO - 2023-01-07 04:04:22 --> Router Class Initialized
INFO - 2023-01-07 04:04:22 --> Output Class Initialized
INFO - 2023-01-07 04:04:22 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:22 --> Input Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Loader Class Initialized
INFO - 2023-01-07 04:04:22 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:22 --> Controller Class Initialized
DEBUG - 2023-01-07 04:04:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:04:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:04:22 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:22 --> Total execution time: 0.0292
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:22 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:22 --> URI Class Initialized
INFO - 2023-01-07 04:04:22 --> Router Class Initialized
INFO - 2023-01-07 04:04:22 --> Output Class Initialized
INFO - 2023-01-07 04:04:22 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:22 --> Input Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Language Class Initialized
INFO - 2023-01-07 04:04:22 --> Config Class Initialized
INFO - 2023-01-07 04:04:22 --> Loader Class Initialized
INFO - 2023-01-07 04:04:22 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:22 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:22 --> Controller Class Initialized
INFO - 2023-01-07 04:04:24 --> Config Class Initialized
INFO - 2023-01-07 04:04:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:04:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:04:24 --> Utf8 Class Initialized
INFO - 2023-01-07 04:04:24 --> URI Class Initialized
INFO - 2023-01-07 04:04:24 --> Router Class Initialized
INFO - 2023-01-07 04:04:24 --> Output Class Initialized
INFO - 2023-01-07 04:04:24 --> Security Class Initialized
DEBUG - 2023-01-07 04:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:04:24 --> Input Class Initialized
INFO - 2023-01-07 04:04:24 --> Language Class Initialized
INFO - 2023-01-07 04:04:24 --> Language Class Initialized
INFO - 2023-01-07 04:04:24 --> Config Class Initialized
INFO - 2023-01-07 04:04:24 --> Loader Class Initialized
INFO - 2023-01-07 04:04:24 --> Helper loaded: url_helper
INFO - 2023-01-07 04:04:24 --> Helper loaded: file_helper
INFO - 2023-01-07 04:04:24 --> Helper loaded: form_helper
INFO - 2023-01-07 04:04:24 --> Helper loaded: my_helper
INFO - 2023-01-07 04:04:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:04:24 --> Controller Class Initialized
ERROR - 2023-01-07 04:04:24 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:04:24 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:04:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:04:24 --> Final output sent to browser
DEBUG - 2023-01-07 04:04:24 --> Total execution time: 0.0371
INFO - 2023-01-07 04:05:10 --> Config Class Initialized
INFO - 2023-01-07 04:05:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:10 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:10 --> URI Class Initialized
INFO - 2023-01-07 04:05:10 --> Router Class Initialized
INFO - 2023-01-07 04:05:10 --> Output Class Initialized
INFO - 2023-01-07 04:05:10 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:10 --> Input Class Initialized
INFO - 2023-01-07 04:05:10 --> Language Class Initialized
INFO - 2023-01-07 04:05:10 --> Language Class Initialized
INFO - 2023-01-07 04:05:10 --> Config Class Initialized
INFO - 2023-01-07 04:05:10 --> Loader Class Initialized
INFO - 2023-01-07 04:05:10 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:10 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:10 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:10 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:10 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:10 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:10 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:10 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:10 --> Total execution time: 0.0313
INFO - 2023-01-07 04:05:11 --> Config Class Initialized
INFO - 2023-01-07 04:05:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:11 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:11 --> URI Class Initialized
INFO - 2023-01-07 04:05:11 --> Router Class Initialized
INFO - 2023-01-07 04:05:11 --> Output Class Initialized
INFO - 2023-01-07 04:05:11 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:11 --> Input Class Initialized
INFO - 2023-01-07 04:05:11 --> Language Class Initialized
INFO - 2023-01-07 04:05:11 --> Language Class Initialized
INFO - 2023-01-07 04:05:11 --> Config Class Initialized
INFO - 2023-01-07 04:05:11 --> Loader Class Initialized
INFO - 2023-01-07 04:05:11 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:11 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:11 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:11 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:11 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:11 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:11 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:11 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:11 --> Total execution time: 0.0448
INFO - 2023-01-07 04:05:40 --> Config Class Initialized
INFO - 2023-01-07 04:05:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:40 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:40 --> URI Class Initialized
INFO - 2023-01-07 04:05:40 --> Router Class Initialized
INFO - 2023-01-07 04:05:40 --> Output Class Initialized
INFO - 2023-01-07 04:05:40 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:40 --> Input Class Initialized
INFO - 2023-01-07 04:05:40 --> Language Class Initialized
INFO - 2023-01-07 04:05:40 --> Language Class Initialized
INFO - 2023-01-07 04:05:40 --> Config Class Initialized
INFO - 2023-01-07 04:05:40 --> Loader Class Initialized
INFO - 2023-01-07 04:05:40 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:40 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:40 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:40 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:40 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:40 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:40 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:40 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:40 --> Total execution time: 0.0329
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:42 --> URI Class Initialized
INFO - 2023-01-07 04:05:42 --> Router Class Initialized
INFO - 2023-01-07 04:05:42 --> Output Class Initialized
INFO - 2023-01-07 04:05:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:42 --> Input Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Loader Class Initialized
INFO - 2023-01-07 04:05:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:42 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:42 --> Total execution time: 0.0455
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:42 --> URI Class Initialized
INFO - 2023-01-07 04:05:42 --> Router Class Initialized
INFO - 2023-01-07 04:05:42 --> Output Class Initialized
INFO - 2023-01-07 04:05:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:42 --> Input Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Loader Class Initialized
INFO - 2023-01-07 04:05:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:42 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:42 --> Total execution time: 0.0546
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:42 --> URI Class Initialized
INFO - 2023-01-07 04:05:42 --> Router Class Initialized
INFO - 2023-01-07 04:05:42 --> Output Class Initialized
INFO - 2023-01-07 04:05:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:42 --> Input Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Loader Class Initialized
INFO - 2023-01-07 04:05:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:42 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:42 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:42 --> Total execution time: 0.0311
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:05:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:05:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:05:42 --> URI Class Initialized
INFO - 2023-01-07 04:05:42 --> Router Class Initialized
INFO - 2023-01-07 04:05:42 --> Output Class Initialized
INFO - 2023-01-07 04:05:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:05:42 --> Input Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Language Class Initialized
INFO - 2023-01-07 04:05:42 --> Config Class Initialized
INFO - 2023-01-07 04:05:42 --> Loader Class Initialized
INFO - 2023-01-07 04:05:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:05:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:05:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:05:43 --> Controller Class Initialized
ERROR - 2023-01-07 04:05:43 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:05:43 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:05:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:05:43 --> Final output sent to browser
DEBUG - 2023-01-07 04:05:43 --> Total execution time: 0.0491
INFO - 2023-01-07 04:06:02 --> Config Class Initialized
INFO - 2023-01-07 04:06:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:02 --> URI Class Initialized
INFO - 2023-01-07 04:06:02 --> Router Class Initialized
INFO - 2023-01-07 04:06:02 --> Output Class Initialized
INFO - 2023-01-07 04:06:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:02 --> Input Class Initialized
INFO - 2023-01-07 04:06:02 --> Language Class Initialized
INFO - 2023-01-07 04:06:02 --> Language Class Initialized
INFO - 2023-01-07 04:06:02 --> Config Class Initialized
INFO - 2023-01-07 04:06:02 --> Loader Class Initialized
INFO - 2023-01-07 04:06:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:02 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:02 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:02 --> Total execution time: 0.0363
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:04 --> URI Class Initialized
INFO - 2023-01-07 04:06:04 --> Router Class Initialized
INFO - 2023-01-07 04:06:04 --> Output Class Initialized
INFO - 2023-01-07 04:06:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:04 --> Input Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Loader Class Initialized
INFO - 2023-01-07 04:06:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:04 --> Total execution time: 0.0336
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:04 --> URI Class Initialized
INFO - 2023-01-07 04:06:04 --> Router Class Initialized
INFO - 2023-01-07 04:06:04 --> Output Class Initialized
INFO - 2023-01-07 04:06:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:04 --> Input Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Loader Class Initialized
INFO - 2023-01-07 04:06:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:04 --> Total execution time: 0.0315
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:04 --> URI Class Initialized
INFO - 2023-01-07 04:06:04 --> Router Class Initialized
INFO - 2023-01-07 04:06:04 --> Output Class Initialized
INFO - 2023-01-07 04:06:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:04 --> Input Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Loader Class Initialized
INFO - 2023-01-07 04:06:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:04 --> Total execution time: 0.0442
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:04 --> URI Class Initialized
INFO - 2023-01-07 04:06:04 --> Router Class Initialized
INFO - 2023-01-07 04:06:04 --> Output Class Initialized
INFO - 2023-01-07 04:06:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:04 --> Input Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Loader Class Initialized
INFO - 2023-01-07 04:06:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:04 --> Total execution time: 0.0335
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:04 --> URI Class Initialized
INFO - 2023-01-07 04:06:04 --> Router Class Initialized
INFO - 2023-01-07 04:06:04 --> Output Class Initialized
INFO - 2023-01-07 04:06:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:04 --> Input Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Language Class Initialized
INFO - 2023-01-07 04:06:04 --> Config Class Initialized
INFO - 2023-01-07 04:06:04 --> Loader Class Initialized
INFO - 2023-01-07 04:06:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:04 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:04 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:04 --> Total execution time: 0.0482
INFO - 2023-01-07 04:06:05 --> Config Class Initialized
INFO - 2023-01-07 04:06:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:05 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:05 --> URI Class Initialized
INFO - 2023-01-07 04:06:05 --> Router Class Initialized
INFO - 2023-01-07 04:06:05 --> Output Class Initialized
INFO - 2023-01-07 04:06:05 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:05 --> Input Class Initialized
INFO - 2023-01-07 04:06:05 --> Language Class Initialized
INFO - 2023-01-07 04:06:05 --> Language Class Initialized
INFO - 2023-01-07 04:06:05 --> Config Class Initialized
INFO - 2023-01-07 04:06:05 --> Loader Class Initialized
INFO - 2023-01-07 04:06:05 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:05 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:05 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:05 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:05 --> Total execution time: 0.0327
INFO - 2023-01-07 04:06:05 --> Config Class Initialized
INFO - 2023-01-07 04:06:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:05 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:05 --> URI Class Initialized
INFO - 2023-01-07 04:06:05 --> Router Class Initialized
INFO - 2023-01-07 04:06:05 --> Output Class Initialized
INFO - 2023-01-07 04:06:05 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:05 --> Input Class Initialized
INFO - 2023-01-07 04:06:05 --> Language Class Initialized
INFO - 2023-01-07 04:06:05 --> Language Class Initialized
INFO - 2023-01-07 04:06:05 --> Config Class Initialized
INFO - 2023-01-07 04:06:05 --> Loader Class Initialized
INFO - 2023-01-07 04:06:05 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:05 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:05 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:05 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:05 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:05 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:05 --> Total execution time: 0.0330
INFO - 2023-01-07 04:06:30 --> Config Class Initialized
INFO - 2023-01-07 04:06:30 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:30 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:30 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:30 --> URI Class Initialized
INFO - 2023-01-07 04:06:30 --> Router Class Initialized
INFO - 2023-01-07 04:06:30 --> Output Class Initialized
INFO - 2023-01-07 04:06:30 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:30 --> Input Class Initialized
INFO - 2023-01-07 04:06:30 --> Language Class Initialized
INFO - 2023-01-07 04:06:30 --> Language Class Initialized
INFO - 2023-01-07 04:06:30 --> Config Class Initialized
INFO - 2023-01-07 04:06:30 --> Loader Class Initialized
INFO - 2023-01-07 04:06:30 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:30 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:30 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:30 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:30 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:30 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:30 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:30 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:30 --> Total execution time: 0.0317
INFO - 2023-01-07 04:06:32 --> Config Class Initialized
INFO - 2023-01-07 04:06:32 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:32 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:32 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:32 --> URI Class Initialized
INFO - 2023-01-07 04:06:32 --> Router Class Initialized
INFO - 2023-01-07 04:06:32 --> Output Class Initialized
INFO - 2023-01-07 04:06:32 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:32 --> Input Class Initialized
INFO - 2023-01-07 04:06:32 --> Language Class Initialized
INFO - 2023-01-07 04:06:32 --> Language Class Initialized
INFO - 2023-01-07 04:06:32 --> Config Class Initialized
INFO - 2023-01-07 04:06:32 --> Loader Class Initialized
INFO - 2023-01-07 04:06:32 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:32 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:32 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:32 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:32 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:32 --> Total execution time: 0.0611
INFO - 2023-01-07 04:06:32 --> Config Class Initialized
INFO - 2023-01-07 04:06:32 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:32 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:32 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:32 --> URI Class Initialized
INFO - 2023-01-07 04:06:32 --> Router Class Initialized
INFO - 2023-01-07 04:06:32 --> Output Class Initialized
INFO - 2023-01-07 04:06:32 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:32 --> Input Class Initialized
INFO - 2023-01-07 04:06:32 --> Language Class Initialized
INFO - 2023-01-07 04:06:32 --> Language Class Initialized
INFO - 2023-01-07 04:06:32 --> Config Class Initialized
INFO - 2023-01-07 04:06:32 --> Loader Class Initialized
INFO - 2023-01-07 04:06:32 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:32 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:32 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:32 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:32 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:32 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:32 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:32 --> Total execution time: 0.0310
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:33 --> URI Class Initialized
INFO - 2023-01-07 04:06:33 --> Router Class Initialized
INFO - 2023-01-07 04:06:33 --> Output Class Initialized
INFO - 2023-01-07 04:06:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:33 --> Input Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Loader Class Initialized
INFO - 2023-01-07 04:06:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:33 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:33 --> Total execution time: 0.0452
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:33 --> URI Class Initialized
INFO - 2023-01-07 04:06:33 --> Router Class Initialized
INFO - 2023-01-07 04:06:33 --> Output Class Initialized
INFO - 2023-01-07 04:06:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:33 --> Input Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Loader Class Initialized
INFO - 2023-01-07 04:06:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:33 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:33 --> Total execution time: 0.0572
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:06:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:06:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:06:33 --> URI Class Initialized
INFO - 2023-01-07 04:06:33 --> Router Class Initialized
INFO - 2023-01-07 04:06:33 --> Output Class Initialized
INFO - 2023-01-07 04:06:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:06:33 --> Input Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Language Class Initialized
INFO - 2023-01-07 04:06:33 --> Config Class Initialized
INFO - 2023-01-07 04:06:33 --> Loader Class Initialized
INFO - 2023-01-07 04:06:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:06:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:06:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:06:33 --> Controller Class Initialized
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:06:33 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:06:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:06:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:06:33 --> Total execution time: 0.0295
INFO - 2023-01-07 04:08:54 --> Config Class Initialized
INFO - 2023-01-07 04:08:54 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:54 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:54 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:54 --> URI Class Initialized
INFO - 2023-01-07 04:08:54 --> Router Class Initialized
INFO - 2023-01-07 04:08:54 --> Output Class Initialized
INFO - 2023-01-07 04:08:54 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:54 --> Input Class Initialized
INFO - 2023-01-07 04:08:54 --> Language Class Initialized
INFO - 2023-01-07 04:08:54 --> Language Class Initialized
INFO - 2023-01-07 04:08:54 --> Config Class Initialized
INFO - 2023-01-07 04:08:54 --> Loader Class Initialized
INFO - 2023-01-07 04:08:54 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:54 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:54 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:54 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:54 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:54 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:54 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:54 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:54 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:54 --> Total execution time: 0.0605
INFO - 2023-01-07 04:08:55 --> Config Class Initialized
INFO - 2023-01-07 04:08:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:55 --> URI Class Initialized
INFO - 2023-01-07 04:08:55 --> Router Class Initialized
INFO - 2023-01-07 04:08:55 --> Output Class Initialized
INFO - 2023-01-07 04:08:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:55 --> Input Class Initialized
INFO - 2023-01-07 04:08:55 --> Language Class Initialized
INFO - 2023-01-07 04:08:55 --> Language Class Initialized
INFO - 2023-01-07 04:08:55 --> Config Class Initialized
INFO - 2023-01-07 04:08:55 --> Loader Class Initialized
INFO - 2023-01-07 04:08:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:55 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:55 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:55 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:55 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:55 --> Total execution time: 0.0524
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:56 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:56 --> URI Class Initialized
INFO - 2023-01-07 04:08:56 --> Router Class Initialized
INFO - 2023-01-07 04:08:56 --> Output Class Initialized
INFO - 2023-01-07 04:08:56 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:56 --> Input Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Loader Class Initialized
INFO - 2023-01-07 04:08:56 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:56 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:56 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:56 --> Total execution time: 0.0559
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:56 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:56 --> URI Class Initialized
INFO - 2023-01-07 04:08:56 --> Router Class Initialized
INFO - 2023-01-07 04:08:56 --> Output Class Initialized
INFO - 2023-01-07 04:08:56 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:56 --> Input Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Loader Class Initialized
INFO - 2023-01-07 04:08:56 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:56 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:56 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:56 --> Total execution time: 0.0372
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:56 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:56 --> URI Class Initialized
INFO - 2023-01-07 04:08:56 --> Router Class Initialized
INFO - 2023-01-07 04:08:56 --> Output Class Initialized
INFO - 2023-01-07 04:08:56 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:56 --> Input Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Loader Class Initialized
INFO - 2023-01-07 04:08:56 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:56 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:56 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:56 --> Total execution time: 0.0331
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:56 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:56 --> URI Class Initialized
INFO - 2023-01-07 04:08:56 --> Router Class Initialized
INFO - 2023-01-07 04:08:56 --> Output Class Initialized
INFO - 2023-01-07 04:08:56 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:56 --> Input Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Language Class Initialized
INFO - 2023-01-07 04:08:56 --> Config Class Initialized
INFO - 2023-01-07 04:08:56 --> Loader Class Initialized
INFO - 2023-01-07 04:08:56 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:56 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:56 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:56 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:56 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:56 --> Total execution time: 0.0331
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:57 --> URI Class Initialized
INFO - 2023-01-07 04:08:57 --> Router Class Initialized
INFO - 2023-01-07 04:08:57 --> Output Class Initialized
INFO - 2023-01-07 04:08:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:57 --> Input Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Loader Class Initialized
INFO - 2023-01-07 04:08:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:57 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:57 --> Total execution time: 0.0525
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:57 --> URI Class Initialized
INFO - 2023-01-07 04:08:57 --> Router Class Initialized
INFO - 2023-01-07 04:08:57 --> Output Class Initialized
INFO - 2023-01-07 04:08:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:57 --> Input Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Loader Class Initialized
INFO - 2023-01-07 04:08:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:57 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:57 --> Total execution time: 0.0318
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:57 --> URI Class Initialized
INFO - 2023-01-07 04:08:57 --> Router Class Initialized
INFO - 2023-01-07 04:08:57 --> Output Class Initialized
INFO - 2023-01-07 04:08:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:57 --> Input Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Loader Class Initialized
INFO - 2023-01-07 04:08:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:57 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:57 --> Total execution time: 0.0503
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:57 --> URI Class Initialized
INFO - 2023-01-07 04:08:57 --> Router Class Initialized
INFO - 2023-01-07 04:08:57 --> Output Class Initialized
INFO - 2023-01-07 04:08:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:57 --> Input Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Language Class Initialized
INFO - 2023-01-07 04:08:57 --> Config Class Initialized
INFO - 2023-01-07 04:08:57 --> Loader Class Initialized
INFO - 2023-01-07 04:08:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:57 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:57 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:57 --> Total execution time: 0.0514
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:58 --> URI Class Initialized
INFO - 2023-01-07 04:08:58 --> Router Class Initialized
INFO - 2023-01-07 04:08:58 --> Output Class Initialized
INFO - 2023-01-07 04:08:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:58 --> Input Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Loader Class Initialized
INFO - 2023-01-07 04:08:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:58 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:58 --> Total execution time: 0.0325
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:58 --> URI Class Initialized
INFO - 2023-01-07 04:08:58 --> Router Class Initialized
INFO - 2023-01-07 04:08:58 --> Output Class Initialized
INFO - 2023-01-07 04:08:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:58 --> Input Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Loader Class Initialized
INFO - 2023-01-07 04:08:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:58 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:58 --> Total execution time: 0.0542
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:58 --> URI Class Initialized
INFO - 2023-01-07 04:08:58 --> Router Class Initialized
INFO - 2023-01-07 04:08:58 --> Output Class Initialized
INFO - 2023-01-07 04:08:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:58 --> Input Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Loader Class Initialized
INFO - 2023-01-07 04:08:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:58 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:58 --> Total execution time: 0.0569
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:58 --> URI Class Initialized
INFO - 2023-01-07 04:08:58 --> Router Class Initialized
INFO - 2023-01-07 04:08:58 --> Output Class Initialized
INFO - 2023-01-07 04:08:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:58 --> Input Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Loader Class Initialized
INFO - 2023-01-07 04:08:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:58 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:58 --> Total execution time: 0.0322
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:58 --> URI Class Initialized
INFO - 2023-01-07 04:08:58 --> Router Class Initialized
INFO - 2023-01-07 04:08:58 --> Output Class Initialized
INFO - 2023-01-07 04:08:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:58 --> Input Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Language Class Initialized
INFO - 2023-01-07 04:08:58 --> Config Class Initialized
INFO - 2023-01-07 04:08:58 --> Loader Class Initialized
INFO - 2023-01-07 04:08:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:58 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:58 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:58 --> Total execution time: 0.0323
INFO - 2023-01-07 04:08:59 --> Config Class Initialized
INFO - 2023-01-07 04:08:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:08:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:08:59 --> Utf8 Class Initialized
INFO - 2023-01-07 04:08:59 --> URI Class Initialized
INFO - 2023-01-07 04:08:59 --> Router Class Initialized
INFO - 2023-01-07 04:08:59 --> Output Class Initialized
INFO - 2023-01-07 04:08:59 --> Security Class Initialized
DEBUG - 2023-01-07 04:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:08:59 --> Input Class Initialized
INFO - 2023-01-07 04:08:59 --> Language Class Initialized
INFO - 2023-01-07 04:08:59 --> Language Class Initialized
INFO - 2023-01-07 04:08:59 --> Config Class Initialized
INFO - 2023-01-07 04:08:59 --> Loader Class Initialized
INFO - 2023-01-07 04:08:59 --> Helper loaded: url_helper
INFO - 2023-01-07 04:08:59 --> Helper loaded: file_helper
INFO - 2023-01-07 04:08:59 --> Helper loaded: form_helper
INFO - 2023-01-07 04:08:59 --> Helper loaded: my_helper
INFO - 2023-01-07 04:08:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:08:59 --> Controller Class Initialized
ERROR - 2023-01-07 04:08:59 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:08:59 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:08:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:08:59 --> Final output sent to browser
DEBUG - 2023-01-07 04:08:59 --> Total execution time: 0.0556
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:00 --> URI Class Initialized
INFO - 2023-01-07 04:09:00 --> Router Class Initialized
INFO - 2023-01-07 04:09:00 --> Output Class Initialized
INFO - 2023-01-07 04:09:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:00 --> Input Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Loader Class Initialized
INFO - 2023-01-07 04:09:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:00 --> Controller Class Initialized
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:09:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:09:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:00 --> Total execution time: 0.0440
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:00 --> URI Class Initialized
INFO - 2023-01-07 04:09:00 --> Router Class Initialized
INFO - 2023-01-07 04:09:00 --> Output Class Initialized
INFO - 2023-01-07 04:09:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:00 --> Input Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Loader Class Initialized
INFO - 2023-01-07 04:09:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:00 --> Controller Class Initialized
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:09:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:09:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:00 --> Total execution time: 0.0302
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:00 --> URI Class Initialized
INFO - 2023-01-07 04:09:00 --> Router Class Initialized
INFO - 2023-01-07 04:09:00 --> Output Class Initialized
INFO - 2023-01-07 04:09:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:00 --> Input Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Loader Class Initialized
INFO - 2023-01-07 04:09:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:00 --> Controller Class Initialized
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:09:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:09:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:00 --> Total execution time: 0.0357
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:00 --> URI Class Initialized
INFO - 2023-01-07 04:09:00 --> Router Class Initialized
INFO - 2023-01-07 04:09:00 --> Output Class Initialized
INFO - 2023-01-07 04:09:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:00 --> Input Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Language Class Initialized
INFO - 2023-01-07 04:09:00 --> Config Class Initialized
INFO - 2023-01-07 04:09:00 --> Loader Class Initialized
INFO - 2023-01-07 04:09:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:00 --> Controller Class Initialized
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> Division by zero C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 201
ERROR - 2023-01-07 04:09:00 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 202
DEBUG - 2023-01-07 04:09:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:09:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:00 --> Total execution time: 0.0327
INFO - 2023-01-07 04:09:06 --> Config Class Initialized
INFO - 2023-01-07 04:09:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:06 --> URI Class Initialized
INFO - 2023-01-07 04:09:06 --> Router Class Initialized
INFO - 2023-01-07 04:09:06 --> Output Class Initialized
INFO - 2023-01-07 04:09:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:06 --> Input Class Initialized
INFO - 2023-01-07 04:09:06 --> Language Class Initialized
INFO - 2023-01-07 04:09:06 --> Language Class Initialized
INFO - 2023-01-07 04:09:06 --> Config Class Initialized
INFO - 2023-01-07 04:09:06 --> Loader Class Initialized
INFO - 2023-01-07 04:09:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:06 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:09:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:06 --> Total execution time: 0.0335
INFO - 2023-01-07 04:09:07 --> Config Class Initialized
INFO - 2023-01-07 04:09:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:07 --> URI Class Initialized
INFO - 2023-01-07 04:09:07 --> Router Class Initialized
INFO - 2023-01-07 04:09:07 --> Output Class Initialized
INFO - 2023-01-07 04:09:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:07 --> Input Class Initialized
INFO - 2023-01-07 04:09:07 --> Language Class Initialized
INFO - 2023-01-07 04:09:07 --> Language Class Initialized
INFO - 2023-01-07 04:09:07 --> Config Class Initialized
INFO - 2023-01-07 04:09:07 --> Loader Class Initialized
INFO - 2023-01-07 04:09:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:07 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:09:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:07 --> Total execution time: 0.0448
INFO - 2023-01-07 04:09:08 --> Config Class Initialized
INFO - 2023-01-07 04:09:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:08 --> URI Class Initialized
INFO - 2023-01-07 04:09:08 --> Router Class Initialized
INFO - 2023-01-07 04:09:08 --> Output Class Initialized
INFO - 2023-01-07 04:09:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:08 --> Input Class Initialized
INFO - 2023-01-07 04:09:08 --> Language Class Initialized
INFO - 2023-01-07 04:09:08 --> Language Class Initialized
INFO - 2023-01-07 04:09:08 --> Config Class Initialized
INFO - 2023-01-07 04:09:08 --> Loader Class Initialized
INFO - 2023-01-07 04:09:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:09:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:08 --> Total execution time: 0.0543
INFO - 2023-01-07 04:09:08 --> Config Class Initialized
INFO - 2023-01-07 04:09:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:08 --> URI Class Initialized
INFO - 2023-01-07 04:09:08 --> Router Class Initialized
INFO - 2023-01-07 04:09:08 --> Output Class Initialized
INFO - 2023-01-07 04:09:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:08 --> Input Class Initialized
INFO - 2023-01-07 04:09:08 --> Language Class Initialized
INFO - 2023-01-07 04:09:08 --> Language Class Initialized
INFO - 2023-01-07 04:09:08 --> Config Class Initialized
INFO - 2023-01-07 04:09:08 --> Loader Class Initialized
INFO - 2023-01-07 04:09:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:09:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:08 --> Total execution time: 0.0315
INFO - 2023-01-07 04:09:31 --> Config Class Initialized
INFO - 2023-01-07 04:09:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:31 --> URI Class Initialized
DEBUG - 2023-01-07 04:09:31 --> No URI present. Default controller set.
INFO - 2023-01-07 04:09:31 --> Router Class Initialized
INFO - 2023-01-07 04:09:31 --> Output Class Initialized
INFO - 2023-01-07 04:09:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:31 --> Input Class Initialized
INFO - 2023-01-07 04:09:31 --> Language Class Initialized
INFO - 2023-01-07 04:09:31 --> Language Class Initialized
INFO - 2023-01-07 04:09:31 --> Config Class Initialized
INFO - 2023-01-07 04:09:31 --> Loader Class Initialized
INFO - 2023-01-07 04:09:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:31 --> Controller Class Initialized
INFO - 2023-01-07 04:09:31 --> Config Class Initialized
INFO - 2023-01-07 04:09:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:31 --> URI Class Initialized
INFO - 2023-01-07 04:09:31 --> Router Class Initialized
INFO - 2023-01-07 04:09:31 --> Output Class Initialized
INFO - 2023-01-07 04:09:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:31 --> Input Class Initialized
INFO - 2023-01-07 04:09:31 --> Language Class Initialized
INFO - 2023-01-07 04:09:31 --> Language Class Initialized
INFO - 2023-01-07 04:09:31 --> Config Class Initialized
INFO - 2023-01-07 04:09:31 --> Loader Class Initialized
INFO - 2023-01-07 04:09:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:31 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:09:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:09:31 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:31 --> Total execution time: 0.0577
INFO - 2023-01-07 04:09:38 --> Config Class Initialized
INFO - 2023-01-07 04:09:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:38 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:38 --> URI Class Initialized
INFO - 2023-01-07 04:09:38 --> Router Class Initialized
INFO - 2023-01-07 04:09:38 --> Output Class Initialized
INFO - 2023-01-07 04:09:38 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:38 --> Input Class Initialized
INFO - 2023-01-07 04:09:38 --> Language Class Initialized
INFO - 2023-01-07 04:09:38 --> Language Class Initialized
INFO - 2023-01-07 04:09:38 --> Config Class Initialized
INFO - 2023-01-07 04:09:38 --> Loader Class Initialized
INFO - 2023-01-07 04:09:38 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:38 --> Controller Class Initialized
INFO - 2023-01-07 04:09:38 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:09:38 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:38 --> Total execution time: 0.0330
INFO - 2023-01-07 04:09:38 --> Config Class Initialized
INFO - 2023-01-07 04:09:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:38 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:38 --> URI Class Initialized
INFO - 2023-01-07 04:09:38 --> Router Class Initialized
INFO - 2023-01-07 04:09:38 --> Output Class Initialized
INFO - 2023-01-07 04:09:38 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:38 --> Input Class Initialized
INFO - 2023-01-07 04:09:38 --> Language Class Initialized
INFO - 2023-01-07 04:09:38 --> Language Class Initialized
INFO - 2023-01-07 04:09:38 --> Config Class Initialized
INFO - 2023-01-07 04:09:38 --> Loader Class Initialized
INFO - 2023-01-07 04:09:38 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:38 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:38 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:09:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:09:38 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:38 --> Total execution time: 0.0514
INFO - 2023-01-07 04:09:43 --> Config Class Initialized
INFO - 2023-01-07 04:09:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:43 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:43 --> URI Class Initialized
INFO - 2023-01-07 04:09:43 --> Router Class Initialized
INFO - 2023-01-07 04:09:43 --> Output Class Initialized
INFO - 2023-01-07 04:09:43 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:43 --> Input Class Initialized
INFO - 2023-01-07 04:09:43 --> Language Class Initialized
INFO - 2023-01-07 04:09:43 --> Language Class Initialized
INFO - 2023-01-07 04:09:43 --> Config Class Initialized
INFO - 2023-01-07 04:09:43 --> Loader Class Initialized
INFO - 2023-01-07 04:09:43 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:43 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:43 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:43 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:43 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 04:09:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:09:43 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:43 --> Total execution time: 0.0300
INFO - 2023-01-07 04:09:45 --> Config Class Initialized
INFO - 2023-01-07 04:09:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:45 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:45 --> URI Class Initialized
INFO - 2023-01-07 04:09:45 --> Router Class Initialized
INFO - 2023-01-07 04:09:45 --> Output Class Initialized
INFO - 2023-01-07 04:09:45 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:45 --> Input Class Initialized
INFO - 2023-01-07 04:09:45 --> Language Class Initialized
INFO - 2023-01-07 04:09:45 --> Language Class Initialized
INFO - 2023-01-07 04:09:45 --> Config Class Initialized
INFO - 2023-01-07 04:09:45 --> Loader Class Initialized
INFO - 2023-01-07 04:09:45 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:45 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:45 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:45 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:45 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:09:45 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:45 --> Total execution time: 0.0382
INFO - 2023-01-07 04:09:57 --> Config Class Initialized
INFO - 2023-01-07 04:09:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:57 --> URI Class Initialized
INFO - 2023-01-07 04:09:57 --> Router Class Initialized
INFO - 2023-01-07 04:09:57 --> Output Class Initialized
INFO - 2023-01-07 04:09:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:57 --> Input Class Initialized
INFO - 2023-01-07 04:09:57 --> Language Class Initialized
INFO - 2023-01-07 04:09:57 --> Language Class Initialized
INFO - 2023-01-07 04:09:57 --> Config Class Initialized
INFO - 2023-01-07 04:09:57 --> Loader Class Initialized
INFO - 2023-01-07 04:09:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:57 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-01-07 04:09:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:09:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:57 --> Total execution time: 0.0433
INFO - 2023-01-07 04:09:58 --> Config Class Initialized
INFO - 2023-01-07 04:09:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:09:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:09:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:09:58 --> URI Class Initialized
INFO - 2023-01-07 04:09:58 --> Router Class Initialized
INFO - 2023-01-07 04:09:58 --> Output Class Initialized
INFO - 2023-01-07 04:09:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:09:58 --> Input Class Initialized
INFO - 2023-01-07 04:09:58 --> Language Class Initialized
INFO - 2023-01-07 04:09:58 --> Language Class Initialized
INFO - 2023-01-07 04:09:58 --> Config Class Initialized
INFO - 2023-01-07 04:09:58 --> Loader Class Initialized
INFO - 2023-01-07 04:09:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:09:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:09:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:09:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:09:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:09:58 --> Controller Class Initialized
DEBUG - 2023-01-07 04:09:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-01-07 04:09:58 --> Final output sent to browser
DEBUG - 2023-01-07 04:09:58 --> Total execution time: 0.0332
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:14 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:14 --> URI Class Initialized
INFO - 2023-01-07 04:10:14 --> Router Class Initialized
INFO - 2023-01-07 04:10:14 --> Output Class Initialized
INFO - 2023-01-07 04:10:14 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:14 --> Input Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Loader Class Initialized
INFO - 2023-01-07 04:10:14 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:14 --> Controller Class Initialized
INFO - 2023-01-07 04:10:14 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:14 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:14 --> URI Class Initialized
INFO - 2023-01-07 04:10:14 --> Router Class Initialized
INFO - 2023-01-07 04:10:14 --> Output Class Initialized
INFO - 2023-01-07 04:10:14 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:14 --> Input Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Loader Class Initialized
INFO - 2023-01-07 04:10:14 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:14 --> Controller Class Initialized
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:14 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:14 --> URI Class Initialized
INFO - 2023-01-07 04:10:14 --> Router Class Initialized
INFO - 2023-01-07 04:10:14 --> Output Class Initialized
INFO - 2023-01-07 04:10:14 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:14 --> Input Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Language Class Initialized
INFO - 2023-01-07 04:10:14 --> Config Class Initialized
INFO - 2023-01-07 04:10:14 --> Loader Class Initialized
INFO - 2023-01-07 04:10:14 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:14 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:14 --> Controller Class Initialized
DEBUG - 2023-01-07 04:10:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:10:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:10:14 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:14 --> Total execution time: 0.0443
INFO - 2023-01-07 04:10:20 --> Config Class Initialized
INFO - 2023-01-07 04:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:20 --> URI Class Initialized
INFO - 2023-01-07 04:10:20 --> Router Class Initialized
INFO - 2023-01-07 04:10:20 --> Output Class Initialized
INFO - 2023-01-07 04:10:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:20 --> Input Class Initialized
INFO - 2023-01-07 04:10:20 --> Language Class Initialized
INFO - 2023-01-07 04:10:20 --> Language Class Initialized
INFO - 2023-01-07 04:10:20 --> Config Class Initialized
INFO - 2023-01-07 04:10:20 --> Loader Class Initialized
INFO - 2023-01-07 04:10:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:20 --> Controller Class Initialized
INFO - 2023-01-07 04:10:20 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:10:20 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:20 --> Total execution time: 0.0483
INFO - 2023-01-07 04:10:20 --> Config Class Initialized
INFO - 2023-01-07 04:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:20 --> URI Class Initialized
INFO - 2023-01-07 04:10:20 --> Router Class Initialized
INFO - 2023-01-07 04:10:20 --> Output Class Initialized
INFO - 2023-01-07 04:10:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:20 --> Input Class Initialized
INFO - 2023-01-07 04:10:20 --> Language Class Initialized
INFO - 2023-01-07 04:10:20 --> Language Class Initialized
INFO - 2023-01-07 04:10:20 --> Config Class Initialized
INFO - 2023-01-07 04:10:20 --> Loader Class Initialized
INFO - 2023-01-07 04:10:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:20 --> Controller Class Initialized
DEBUG - 2023-01-07 04:10:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:10:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:10:20 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:20 --> Total execution time: 0.0336
INFO - 2023-01-07 04:10:23 --> Config Class Initialized
INFO - 2023-01-07 04:10:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:23 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:23 --> URI Class Initialized
INFO - 2023-01-07 04:10:23 --> Router Class Initialized
INFO - 2023-01-07 04:10:23 --> Output Class Initialized
INFO - 2023-01-07 04:10:23 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:23 --> Input Class Initialized
INFO - 2023-01-07 04:10:23 --> Language Class Initialized
INFO - 2023-01-07 04:10:23 --> Language Class Initialized
INFO - 2023-01-07 04:10:23 --> Config Class Initialized
INFO - 2023-01-07 04:10:23 --> Loader Class Initialized
INFO - 2023-01-07 04:10:23 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:23 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:23 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:23 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:23 --> Controller Class Initialized
DEBUG - 2023-01-07 04:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 04:10:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:10:23 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:23 --> Total execution time: 0.0279
INFO - 2023-01-07 04:10:25 --> Config Class Initialized
INFO - 2023-01-07 04:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:25 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:25 --> URI Class Initialized
INFO - 2023-01-07 04:10:25 --> Router Class Initialized
INFO - 2023-01-07 04:10:25 --> Output Class Initialized
INFO - 2023-01-07 04:10:25 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:25 --> Input Class Initialized
INFO - 2023-01-07 04:10:25 --> Language Class Initialized
INFO - 2023-01-07 04:10:25 --> Language Class Initialized
INFO - 2023-01-07 04:10:25 --> Config Class Initialized
INFO - 2023-01-07 04:10:25 --> Loader Class Initialized
INFO - 2023-01-07 04:10:25 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:25 --> Controller Class Initialized
DEBUG - 2023-01-07 04:10:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:10:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:10:25 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:25 --> Total execution time: 0.0297
INFO - 2023-01-07 04:10:25 --> Config Class Initialized
INFO - 2023-01-07 04:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:25 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:25 --> URI Class Initialized
INFO - 2023-01-07 04:10:25 --> Router Class Initialized
INFO - 2023-01-07 04:10:25 --> Output Class Initialized
INFO - 2023-01-07 04:10:25 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:25 --> Input Class Initialized
INFO - 2023-01-07 04:10:25 --> Language Class Initialized
INFO - 2023-01-07 04:10:25 --> Language Class Initialized
INFO - 2023-01-07 04:10:25 --> Config Class Initialized
INFO - 2023-01-07 04:10:25 --> Loader Class Initialized
INFO - 2023-01-07 04:10:25 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:25 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:25 --> Controller Class Initialized
INFO - 2023-01-07 04:10:27 --> Config Class Initialized
INFO - 2023-01-07 04:10:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:10:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:10:27 --> Utf8 Class Initialized
INFO - 2023-01-07 04:10:27 --> URI Class Initialized
INFO - 2023-01-07 04:10:27 --> Router Class Initialized
INFO - 2023-01-07 04:10:27 --> Output Class Initialized
INFO - 2023-01-07 04:10:27 --> Security Class Initialized
DEBUG - 2023-01-07 04:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:10:27 --> Input Class Initialized
INFO - 2023-01-07 04:10:27 --> Language Class Initialized
INFO - 2023-01-07 04:10:27 --> Language Class Initialized
INFO - 2023-01-07 04:10:27 --> Config Class Initialized
INFO - 2023-01-07 04:10:27 --> Loader Class Initialized
INFO - 2023-01-07 04:10:27 --> Helper loaded: url_helper
INFO - 2023-01-07 04:10:27 --> Helper loaded: file_helper
INFO - 2023-01-07 04:10:27 --> Helper loaded: form_helper
INFO - 2023-01-07 04:10:27 --> Helper loaded: my_helper
INFO - 2023-01-07 04:10:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:10:27 --> Controller Class Initialized
DEBUG - 2023-01-07 04:10:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:10:27 --> Final output sent to browser
DEBUG - 2023-01-07 04:10:27 --> Total execution time: 0.0354
INFO - 2023-01-07 04:11:05 --> Config Class Initialized
INFO - 2023-01-07 04:11:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:05 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:05 --> URI Class Initialized
INFO - 2023-01-07 04:11:05 --> Router Class Initialized
INFO - 2023-01-07 04:11:05 --> Output Class Initialized
INFO - 2023-01-07 04:11:05 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:05 --> Input Class Initialized
INFO - 2023-01-07 04:11:05 --> Language Class Initialized
INFO - 2023-01-07 04:11:05 --> Language Class Initialized
INFO - 2023-01-07 04:11:05 --> Config Class Initialized
INFO - 2023-01-07 04:11:05 --> Loader Class Initialized
INFO - 2023-01-07 04:11:05 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:05 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:05 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:05 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:05 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:05 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:05 --> Total execution time: 0.0324
INFO - 2023-01-07 04:11:06 --> Config Class Initialized
INFO - 2023-01-07 04:11:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:06 --> URI Class Initialized
INFO - 2023-01-07 04:11:06 --> Router Class Initialized
INFO - 2023-01-07 04:11:06 --> Output Class Initialized
INFO - 2023-01-07 04:11:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:06 --> Input Class Initialized
INFO - 2023-01-07 04:11:06 --> Language Class Initialized
INFO - 2023-01-07 04:11:06 --> Language Class Initialized
INFO - 2023-01-07 04:11:06 --> Config Class Initialized
INFO - 2023-01-07 04:11:06 --> Loader Class Initialized
INFO - 2023-01-07 04:11:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:06 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:06 --> Total execution time: 0.0459
INFO - 2023-01-07 04:11:06 --> Config Class Initialized
INFO - 2023-01-07 04:11:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:06 --> URI Class Initialized
INFO - 2023-01-07 04:11:06 --> Router Class Initialized
INFO - 2023-01-07 04:11:06 --> Output Class Initialized
INFO - 2023-01-07 04:11:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:06 --> Input Class Initialized
INFO - 2023-01-07 04:11:06 --> Language Class Initialized
INFO - 2023-01-07 04:11:06 --> Language Class Initialized
INFO - 2023-01-07 04:11:06 --> Config Class Initialized
INFO - 2023-01-07 04:11:06 --> Loader Class Initialized
INFO - 2023-01-07 04:11:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:06 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:06 --> Total execution time: 0.0444
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:07 --> URI Class Initialized
INFO - 2023-01-07 04:11:07 --> Router Class Initialized
INFO - 2023-01-07 04:11:07 --> Output Class Initialized
INFO - 2023-01-07 04:11:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:07 --> Input Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Loader Class Initialized
INFO - 2023-01-07 04:11:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:07 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:07 --> Total execution time: 0.0422
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:07 --> URI Class Initialized
INFO - 2023-01-07 04:11:07 --> Router Class Initialized
INFO - 2023-01-07 04:11:07 --> Output Class Initialized
INFO - 2023-01-07 04:11:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:07 --> Input Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Loader Class Initialized
INFO - 2023-01-07 04:11:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:07 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:07 --> Total execution time: 0.0332
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:07 --> URI Class Initialized
INFO - 2023-01-07 04:11:07 --> Router Class Initialized
INFO - 2023-01-07 04:11:07 --> Output Class Initialized
INFO - 2023-01-07 04:11:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:07 --> Input Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Language Class Initialized
INFO - 2023-01-07 04:11:07 --> Config Class Initialized
INFO - 2023-01-07 04:11:07 --> Loader Class Initialized
INFO - 2023-01-07 04:11:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:07 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:07 --> Total execution time: 0.0431
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:08 --> URI Class Initialized
INFO - 2023-01-07 04:11:08 --> Router Class Initialized
INFO - 2023-01-07 04:11:08 --> Output Class Initialized
INFO - 2023-01-07 04:11:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:08 --> Input Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Loader Class Initialized
INFO - 2023-01-07 04:11:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:08 --> Total execution time: 0.0447
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:08 --> URI Class Initialized
INFO - 2023-01-07 04:11:08 --> Router Class Initialized
INFO - 2023-01-07 04:11:08 --> Output Class Initialized
INFO - 2023-01-07 04:11:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:08 --> Input Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Loader Class Initialized
INFO - 2023-01-07 04:11:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:08 --> Total execution time: 0.0597
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:08 --> URI Class Initialized
INFO - 2023-01-07 04:11:08 --> Router Class Initialized
INFO - 2023-01-07 04:11:08 --> Output Class Initialized
INFO - 2023-01-07 04:11:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:08 --> Input Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Language Class Initialized
INFO - 2023-01-07 04:11:08 --> Config Class Initialized
INFO - 2023-01-07 04:11:08 --> Loader Class Initialized
INFO - 2023-01-07 04:11:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:09 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:09 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:09 --> Total execution time: 0.0546
INFO - 2023-01-07 04:11:09 --> Config Class Initialized
INFO - 2023-01-07 04:11:09 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:09 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:09 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:09 --> URI Class Initialized
INFO - 2023-01-07 04:11:09 --> Router Class Initialized
INFO - 2023-01-07 04:11:09 --> Output Class Initialized
INFO - 2023-01-07 04:11:09 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:09 --> Input Class Initialized
INFO - 2023-01-07 04:11:09 --> Language Class Initialized
INFO - 2023-01-07 04:11:09 --> Language Class Initialized
INFO - 2023-01-07 04:11:09 --> Config Class Initialized
INFO - 2023-01-07 04:11:09 --> Loader Class Initialized
INFO - 2023-01-07 04:11:09 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:09 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:09 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:09 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:09 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:09 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:09 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:09 --> Total execution time: 0.0314
INFO - 2023-01-07 04:11:13 --> Config Class Initialized
INFO - 2023-01-07 04:11:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:13 --> URI Class Initialized
INFO - 2023-01-07 04:11:13 --> Router Class Initialized
INFO - 2023-01-07 04:11:13 --> Output Class Initialized
INFO - 2023-01-07 04:11:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:13 --> Input Class Initialized
INFO - 2023-01-07 04:11:13 --> Language Class Initialized
INFO - 2023-01-07 04:11:13 --> Language Class Initialized
INFO - 2023-01-07 04:11:13 --> Config Class Initialized
INFO - 2023-01-07 04:11:13 --> Loader Class Initialized
INFO - 2023-01-07 04:11:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:13 --> Controller Class Initialized
INFO - 2023-01-07 04:11:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:13 --> Total execution time: 0.0448
INFO - 2023-01-07 04:11:16 --> Config Class Initialized
INFO - 2023-01-07 04:11:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:11:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:11:16 --> Utf8 Class Initialized
INFO - 2023-01-07 04:11:16 --> URI Class Initialized
INFO - 2023-01-07 04:11:16 --> Router Class Initialized
INFO - 2023-01-07 04:11:16 --> Output Class Initialized
INFO - 2023-01-07 04:11:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:11:16 --> Input Class Initialized
INFO - 2023-01-07 04:11:16 --> Language Class Initialized
INFO - 2023-01-07 04:11:16 --> Language Class Initialized
INFO - 2023-01-07 04:11:16 --> Config Class Initialized
INFO - 2023-01-07 04:11:16 --> Loader Class Initialized
INFO - 2023-01-07 04:11:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:11:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:11:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:11:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:11:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:11:16 --> Controller Class Initialized
DEBUG - 2023-01-07 04:11:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:11:16 --> Final output sent to browser
DEBUG - 2023-01-07 04:11:16 --> Total execution time: 0.0556
INFO - 2023-01-07 04:27:35 --> Config Class Initialized
INFO - 2023-01-07 04:27:35 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:27:35 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:27:35 --> Utf8 Class Initialized
INFO - 2023-01-07 04:27:35 --> URI Class Initialized
INFO - 2023-01-07 04:27:35 --> Router Class Initialized
INFO - 2023-01-07 04:27:35 --> Output Class Initialized
INFO - 2023-01-07 04:27:35 --> Security Class Initialized
DEBUG - 2023-01-07 04:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:27:35 --> Input Class Initialized
INFO - 2023-01-07 04:27:35 --> Language Class Initialized
INFO - 2023-01-07 04:27:35 --> Language Class Initialized
INFO - 2023-01-07 04:27:35 --> Config Class Initialized
INFO - 2023-01-07 04:27:35 --> Loader Class Initialized
INFO - 2023-01-07 04:27:35 --> Helper loaded: url_helper
INFO - 2023-01-07 04:27:35 --> Helper loaded: file_helper
INFO - 2023-01-07 04:27:35 --> Helper loaded: form_helper
INFO - 2023-01-07 04:27:35 --> Helper loaded: my_helper
INFO - 2023-01-07 04:27:35 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:27:35 --> Controller Class Initialized
DEBUG - 2023-01-07 04:27:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:27:35 --> Final output sent to browser
DEBUG - 2023-01-07 04:27:35 --> Total execution time: 0.0447
INFO - 2023-01-07 04:27:36 --> Config Class Initialized
INFO - 2023-01-07 04:27:36 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:27:36 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:27:36 --> Utf8 Class Initialized
INFO - 2023-01-07 04:27:36 --> URI Class Initialized
INFO - 2023-01-07 04:27:36 --> Router Class Initialized
INFO - 2023-01-07 04:27:36 --> Output Class Initialized
INFO - 2023-01-07 04:27:36 --> Security Class Initialized
DEBUG - 2023-01-07 04:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:27:36 --> Input Class Initialized
INFO - 2023-01-07 04:27:36 --> Language Class Initialized
INFO - 2023-01-07 04:27:36 --> Language Class Initialized
INFO - 2023-01-07 04:27:36 --> Config Class Initialized
INFO - 2023-01-07 04:27:36 --> Loader Class Initialized
INFO - 2023-01-07 04:27:36 --> Helper loaded: url_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: file_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: form_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: my_helper
INFO - 2023-01-07 04:27:36 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:27:36 --> Controller Class Initialized
DEBUG - 2023-01-07 04:27:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:27:36 --> Final output sent to browser
DEBUG - 2023-01-07 04:27:36 --> Total execution time: 0.0496
INFO - 2023-01-07 04:27:36 --> Config Class Initialized
INFO - 2023-01-07 04:27:36 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:27:36 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:27:36 --> Utf8 Class Initialized
INFO - 2023-01-07 04:27:36 --> URI Class Initialized
INFO - 2023-01-07 04:27:36 --> Router Class Initialized
INFO - 2023-01-07 04:27:36 --> Output Class Initialized
INFO - 2023-01-07 04:27:36 --> Security Class Initialized
DEBUG - 2023-01-07 04:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:27:36 --> Input Class Initialized
INFO - 2023-01-07 04:27:36 --> Language Class Initialized
INFO - 2023-01-07 04:27:36 --> Language Class Initialized
INFO - 2023-01-07 04:27:36 --> Config Class Initialized
INFO - 2023-01-07 04:27:36 --> Loader Class Initialized
INFO - 2023-01-07 04:27:36 --> Helper loaded: url_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: file_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: form_helper
INFO - 2023-01-07 04:27:36 --> Helper loaded: my_helper
INFO - 2023-01-07 04:27:36 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:27:36 --> Controller Class Initialized
DEBUG - 2023-01-07 04:27:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:27:36 --> Final output sent to browser
DEBUG - 2023-01-07 04:27:36 --> Total execution time: 0.0449
INFO - 2023-01-07 04:27:44 --> Config Class Initialized
INFO - 2023-01-07 04:27:44 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:27:44 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:27:44 --> Utf8 Class Initialized
INFO - 2023-01-07 04:27:44 --> URI Class Initialized
INFO - 2023-01-07 04:27:44 --> Router Class Initialized
INFO - 2023-01-07 04:27:44 --> Output Class Initialized
INFO - 2023-01-07 04:27:44 --> Security Class Initialized
DEBUG - 2023-01-07 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:27:44 --> Input Class Initialized
INFO - 2023-01-07 04:27:44 --> Language Class Initialized
INFO - 2023-01-07 04:27:44 --> Language Class Initialized
INFO - 2023-01-07 04:27:44 --> Config Class Initialized
INFO - 2023-01-07 04:27:44 --> Loader Class Initialized
INFO - 2023-01-07 04:27:44 --> Helper loaded: url_helper
INFO - 2023-01-07 04:27:44 --> Helper loaded: file_helper
INFO - 2023-01-07 04:27:44 --> Helper loaded: form_helper
INFO - 2023-01-07 04:27:44 --> Helper loaded: my_helper
INFO - 2023-01-07 04:27:44 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:27:44 --> Controller Class Initialized
DEBUG - 2023-01-07 04:27:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:27:44 --> Final output sent to browser
DEBUG - 2023-01-07 04:27:44 --> Total execution time: 0.0310
INFO - 2023-01-07 04:33:07 --> Config Class Initialized
INFO - 2023-01-07 04:33:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:07 --> URI Class Initialized
INFO - 2023-01-07 04:33:07 --> Router Class Initialized
INFO - 2023-01-07 04:33:07 --> Output Class Initialized
INFO - 2023-01-07 04:33:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:07 --> Input Class Initialized
INFO - 2023-01-07 04:33:07 --> Language Class Initialized
INFO - 2023-01-07 04:33:08 --> Language Class Initialized
INFO - 2023-01-07 04:33:08 --> Config Class Initialized
INFO - 2023-01-07 04:33:08 --> Loader Class Initialized
INFO - 2023-01-07 04:33:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:33:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:33:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:33:08 --> Total execution time: 0.4600
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:12 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:12 --> URI Class Initialized
INFO - 2023-01-07 04:33:12 --> Router Class Initialized
INFO - 2023-01-07 04:33:12 --> Output Class Initialized
INFO - 2023-01-07 04:33:12 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:12 --> Input Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Loader Class Initialized
INFO - 2023-01-07 04:33:12 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:12 --> Controller Class Initialized
INFO - 2023-01-07 04:33:12 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:12 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:12 --> URI Class Initialized
INFO - 2023-01-07 04:33:12 --> Router Class Initialized
INFO - 2023-01-07 04:33:12 --> Output Class Initialized
INFO - 2023-01-07 04:33:12 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:12 --> Input Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Loader Class Initialized
INFO - 2023-01-07 04:33:12 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:12 --> Controller Class Initialized
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:12 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:12 --> URI Class Initialized
INFO - 2023-01-07 04:33:12 --> Router Class Initialized
INFO - 2023-01-07 04:33:12 --> Output Class Initialized
INFO - 2023-01-07 04:33:12 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:12 --> Input Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Language Class Initialized
INFO - 2023-01-07 04:33:12 --> Config Class Initialized
INFO - 2023-01-07 04:33:12 --> Loader Class Initialized
INFO - 2023-01-07 04:33:12 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:12 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:12 --> Controller Class Initialized
DEBUG - 2023-01-07 04:33:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:33:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:33:12 --> Final output sent to browser
DEBUG - 2023-01-07 04:33:12 --> Total execution time: 0.0627
INFO - 2023-01-07 04:33:18 --> Config Class Initialized
INFO - 2023-01-07 04:33:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:18 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:18 --> URI Class Initialized
INFO - 2023-01-07 04:33:18 --> Router Class Initialized
INFO - 2023-01-07 04:33:18 --> Output Class Initialized
INFO - 2023-01-07 04:33:18 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:18 --> Input Class Initialized
INFO - 2023-01-07 04:33:18 --> Language Class Initialized
INFO - 2023-01-07 04:33:18 --> Language Class Initialized
INFO - 2023-01-07 04:33:18 --> Config Class Initialized
INFO - 2023-01-07 04:33:18 --> Loader Class Initialized
INFO - 2023-01-07 04:33:18 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:18 --> Controller Class Initialized
INFO - 2023-01-07 04:33:18 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:33:18 --> Final output sent to browser
DEBUG - 2023-01-07 04:33:18 --> Total execution time: 0.0282
INFO - 2023-01-07 04:33:18 --> Config Class Initialized
INFO - 2023-01-07 04:33:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:18 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:18 --> URI Class Initialized
INFO - 2023-01-07 04:33:18 --> Router Class Initialized
INFO - 2023-01-07 04:33:18 --> Output Class Initialized
INFO - 2023-01-07 04:33:18 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:18 --> Input Class Initialized
INFO - 2023-01-07 04:33:18 --> Language Class Initialized
INFO - 2023-01-07 04:33:18 --> Language Class Initialized
INFO - 2023-01-07 04:33:18 --> Config Class Initialized
INFO - 2023-01-07 04:33:18 --> Loader Class Initialized
INFO - 2023-01-07 04:33:18 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:18 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:18 --> Controller Class Initialized
DEBUG - 2023-01-07 04:33:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:33:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:33:18 --> Final output sent to browser
DEBUG - 2023-01-07 04:33:18 --> Total execution time: 0.0757
INFO - 2023-01-07 04:33:22 --> Config Class Initialized
INFO - 2023-01-07 04:33:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:22 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:22 --> URI Class Initialized
INFO - 2023-01-07 04:33:22 --> Router Class Initialized
INFO - 2023-01-07 04:33:22 --> Output Class Initialized
INFO - 2023-01-07 04:33:22 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:22 --> Input Class Initialized
INFO - 2023-01-07 04:33:22 --> Language Class Initialized
INFO - 2023-01-07 04:33:22 --> Language Class Initialized
INFO - 2023-01-07 04:33:22 --> Config Class Initialized
INFO - 2023-01-07 04:33:22 --> Loader Class Initialized
INFO - 2023-01-07 04:33:22 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:22 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:22 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:22 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:22 --> Controller Class Initialized
DEBUG - 2023-01-07 04:33:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 04:33:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:33:22 --> Final output sent to browser
DEBUG - 2023-01-07 04:33:22 --> Total execution time: 0.0726
INFO - 2023-01-07 04:33:24 --> Config Class Initialized
INFO - 2023-01-07 04:33:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:33:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:33:24 --> Utf8 Class Initialized
INFO - 2023-01-07 04:33:24 --> URI Class Initialized
INFO - 2023-01-07 04:33:24 --> Router Class Initialized
INFO - 2023-01-07 04:33:24 --> Output Class Initialized
INFO - 2023-01-07 04:33:24 --> Security Class Initialized
DEBUG - 2023-01-07 04:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:33:24 --> Input Class Initialized
INFO - 2023-01-07 04:33:24 --> Language Class Initialized
INFO - 2023-01-07 04:33:24 --> Language Class Initialized
INFO - 2023-01-07 04:33:24 --> Config Class Initialized
INFO - 2023-01-07 04:33:24 --> Loader Class Initialized
INFO - 2023-01-07 04:33:24 --> Helper loaded: url_helper
INFO - 2023-01-07 04:33:24 --> Helper loaded: file_helper
INFO - 2023-01-07 04:33:24 --> Helper loaded: form_helper
INFO - 2023-01-07 04:33:24 --> Helper loaded: my_helper
INFO - 2023-01-07 04:33:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:33:24 --> Controller Class Initialized
DEBUG - 2023-01-07 04:33:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
ERROR - 2023-01-07 04:33:24 --> Severity: error --> Exception: The tag [thead] must contain at least one tag [tr] C:\xampp\htdocs\myraportk13\aset\html2pdf\spipu\html2pdf\src\Parsing\Html.php 212
INFO - 2023-01-07 04:35:39 --> Config Class Initialized
INFO - 2023-01-07 04:35:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:35:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:35:39 --> Utf8 Class Initialized
INFO - 2023-01-07 04:35:39 --> URI Class Initialized
INFO - 2023-01-07 04:35:39 --> Router Class Initialized
INFO - 2023-01-07 04:35:39 --> Output Class Initialized
INFO - 2023-01-07 04:35:39 --> Security Class Initialized
DEBUG - 2023-01-07 04:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:35:39 --> Input Class Initialized
INFO - 2023-01-07 04:35:39 --> Language Class Initialized
INFO - 2023-01-07 04:35:39 --> Language Class Initialized
INFO - 2023-01-07 04:35:39 --> Config Class Initialized
INFO - 2023-01-07 04:35:39 --> Loader Class Initialized
INFO - 2023-01-07 04:35:39 --> Helper loaded: url_helper
INFO - 2023-01-07 04:35:39 --> Helper loaded: file_helper
INFO - 2023-01-07 04:35:39 --> Helper loaded: form_helper
INFO - 2023-01-07 04:35:39 --> Helper loaded: my_helper
INFO - 2023-01-07 04:35:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:35:39 --> Controller Class Initialized
DEBUG - 2023-01-07 04:35:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:35:39 --> Final output sent to browser
DEBUG - 2023-01-07 04:35:39 --> Total execution time: 0.3435
INFO - 2023-01-07 04:36:17 --> Config Class Initialized
INFO - 2023-01-07 04:36:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:17 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:17 --> URI Class Initialized
DEBUG - 2023-01-07 04:36:17 --> No URI present. Default controller set.
INFO - 2023-01-07 04:36:17 --> Router Class Initialized
INFO - 2023-01-07 04:36:17 --> Output Class Initialized
INFO - 2023-01-07 04:36:17 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:17 --> Input Class Initialized
INFO - 2023-01-07 04:36:17 --> Language Class Initialized
INFO - 2023-01-07 04:36:17 --> Language Class Initialized
INFO - 2023-01-07 04:36:17 --> Config Class Initialized
INFO - 2023-01-07 04:36:17 --> Loader Class Initialized
INFO - 2023-01-07 04:36:17 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:17 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:17 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:17 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:17 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:36:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:17 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:17 --> Total execution time: 0.0469
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:20 --> URI Class Initialized
INFO - 2023-01-07 04:36:20 --> Router Class Initialized
INFO - 2023-01-07 04:36:20 --> Output Class Initialized
INFO - 2023-01-07 04:36:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:20 --> Input Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Loader Class Initialized
INFO - 2023-01-07 04:36:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:20 --> Controller Class Initialized
INFO - 2023-01-07 04:36:20 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:20 --> URI Class Initialized
INFO - 2023-01-07 04:36:20 --> Router Class Initialized
INFO - 2023-01-07 04:36:20 --> Output Class Initialized
INFO - 2023-01-07 04:36:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:20 --> Input Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Loader Class Initialized
INFO - 2023-01-07 04:36:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:20 --> Controller Class Initialized
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:20 --> URI Class Initialized
INFO - 2023-01-07 04:36:20 --> Router Class Initialized
INFO - 2023-01-07 04:36:20 --> Output Class Initialized
INFO - 2023-01-07 04:36:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:20 --> Input Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Language Class Initialized
INFO - 2023-01-07 04:36:20 --> Config Class Initialized
INFO - 2023-01-07 04:36:20 --> Loader Class Initialized
INFO - 2023-01-07 04:36:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:20 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:36:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:20 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:20 --> Total execution time: 0.0231
INFO - 2023-01-07 04:36:31 --> Config Class Initialized
INFO - 2023-01-07 04:36:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:31 --> URI Class Initialized
DEBUG - 2023-01-07 04:36:31 --> No URI present. Default controller set.
INFO - 2023-01-07 04:36:31 --> Router Class Initialized
INFO - 2023-01-07 04:36:31 --> Output Class Initialized
INFO - 2023-01-07 04:36:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:31 --> Input Class Initialized
INFO - 2023-01-07 04:36:31 --> Language Class Initialized
INFO - 2023-01-07 04:36:31 --> Language Class Initialized
INFO - 2023-01-07 04:36:31 --> Config Class Initialized
INFO - 2023-01-07 04:36:31 --> Loader Class Initialized
INFO - 2023-01-07 04:36:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:31 --> Controller Class Initialized
INFO - 2023-01-07 04:36:31 --> Config Class Initialized
INFO - 2023-01-07 04:36:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:31 --> URI Class Initialized
INFO - 2023-01-07 04:36:31 --> Router Class Initialized
INFO - 2023-01-07 04:36:31 --> Output Class Initialized
INFO - 2023-01-07 04:36:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:31 --> Input Class Initialized
INFO - 2023-01-07 04:36:31 --> Language Class Initialized
INFO - 2023-01-07 04:36:31 --> Language Class Initialized
INFO - 2023-01-07 04:36:31 --> Config Class Initialized
INFO - 2023-01-07 04:36:31 --> Loader Class Initialized
INFO - 2023-01-07 04:36:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:31 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:36:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:31 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:31 --> Total execution time: 0.0314
INFO - 2023-01-07 04:36:38 --> Config Class Initialized
INFO - 2023-01-07 04:36:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:38 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:38 --> URI Class Initialized
INFO - 2023-01-07 04:36:38 --> Router Class Initialized
INFO - 2023-01-07 04:36:38 --> Output Class Initialized
INFO - 2023-01-07 04:36:38 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:38 --> Input Class Initialized
INFO - 2023-01-07 04:36:38 --> Language Class Initialized
INFO - 2023-01-07 04:36:38 --> Language Class Initialized
INFO - 2023-01-07 04:36:38 --> Config Class Initialized
INFO - 2023-01-07 04:36:38 --> Loader Class Initialized
INFO - 2023-01-07 04:36:38 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:38 --> Controller Class Initialized
INFO - 2023-01-07 04:36:38 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:36:38 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:38 --> Total execution time: 0.0262
INFO - 2023-01-07 04:36:38 --> Config Class Initialized
INFO - 2023-01-07 04:36:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:38 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:38 --> URI Class Initialized
INFO - 2023-01-07 04:36:38 --> Router Class Initialized
INFO - 2023-01-07 04:36:38 --> Output Class Initialized
INFO - 2023-01-07 04:36:38 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:38 --> Input Class Initialized
INFO - 2023-01-07 04:36:38 --> Language Class Initialized
INFO - 2023-01-07 04:36:38 --> Language Class Initialized
INFO - 2023-01-07 04:36:38 --> Config Class Initialized
INFO - 2023-01-07 04:36:38 --> Loader Class Initialized
INFO - 2023-01-07 04:36:38 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:38 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:38 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:36:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:38 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:38 --> Total execution time: 0.0433
INFO - 2023-01-07 04:36:41 --> Config Class Initialized
INFO - 2023-01-07 04:36:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:41 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:41 --> URI Class Initialized
INFO - 2023-01-07 04:36:41 --> Router Class Initialized
INFO - 2023-01-07 04:36:41 --> Output Class Initialized
INFO - 2023-01-07 04:36:41 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:41 --> Input Class Initialized
INFO - 2023-01-07 04:36:41 --> Language Class Initialized
INFO - 2023-01-07 04:36:41 --> Language Class Initialized
INFO - 2023-01-07 04:36:41 --> Config Class Initialized
INFO - 2023-01-07 04:36:41 --> Loader Class Initialized
INFO - 2023-01-07 04:36:41 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:41 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:41 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:41 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:41 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 04:36:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:41 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:41 --> Total execution time: 0.0573
INFO - 2023-01-07 04:36:42 --> Config Class Initialized
INFO - 2023-01-07 04:36:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:42 --> URI Class Initialized
INFO - 2023-01-07 04:36:42 --> Router Class Initialized
INFO - 2023-01-07 04:36:42 --> Output Class Initialized
INFO - 2023-01-07 04:36:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:42 --> Input Class Initialized
INFO - 2023-01-07 04:36:42 --> Language Class Initialized
INFO - 2023-01-07 04:36:42 --> Language Class Initialized
INFO - 2023-01-07 04:36:42 --> Config Class Initialized
INFO - 2023-01-07 04:36:42 --> Loader Class Initialized
INFO - 2023-01-07 04:36:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:42 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:36:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:36:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:42 --> Total execution time: 0.0546
INFO - 2023-01-07 04:36:42 --> Config Class Initialized
INFO - 2023-01-07 04:36:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:42 --> URI Class Initialized
INFO - 2023-01-07 04:36:42 --> Router Class Initialized
INFO - 2023-01-07 04:36:42 --> Output Class Initialized
INFO - 2023-01-07 04:36:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:42 --> Input Class Initialized
INFO - 2023-01-07 04:36:42 --> Language Class Initialized
INFO - 2023-01-07 04:36:42 --> Language Class Initialized
INFO - 2023-01-07 04:36:42 --> Config Class Initialized
INFO - 2023-01-07 04:36:42 --> Loader Class Initialized
INFO - 2023-01-07 04:36:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:42 --> Controller Class Initialized
INFO - 2023-01-07 04:36:43 --> Config Class Initialized
INFO - 2023-01-07 04:36:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:43 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:43 --> URI Class Initialized
INFO - 2023-01-07 04:36:43 --> Router Class Initialized
INFO - 2023-01-07 04:36:43 --> Output Class Initialized
INFO - 2023-01-07 04:36:43 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:43 --> Input Class Initialized
INFO - 2023-01-07 04:36:43 --> Language Class Initialized
INFO - 2023-01-07 04:36:43 --> Language Class Initialized
INFO - 2023-01-07 04:36:43 --> Config Class Initialized
INFO - 2023-01-07 04:36:43 --> Loader Class Initialized
INFO - 2023-01-07 04:36:43 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:43 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:43 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:43 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:43 --> Controller Class Initialized
DEBUG - 2023-01-07 04:36:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:36:43 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:43 --> Total execution time: 0.0364
INFO - 2023-01-07 04:36:51 --> Config Class Initialized
INFO - 2023-01-07 04:36:51 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:36:51 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:36:51 --> Utf8 Class Initialized
INFO - 2023-01-07 04:36:51 --> URI Class Initialized
INFO - 2023-01-07 04:36:51 --> Router Class Initialized
INFO - 2023-01-07 04:36:51 --> Output Class Initialized
INFO - 2023-01-07 04:36:51 --> Security Class Initialized
DEBUG - 2023-01-07 04:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:36:51 --> Input Class Initialized
INFO - 2023-01-07 04:36:51 --> Language Class Initialized
INFO - 2023-01-07 04:36:51 --> Language Class Initialized
INFO - 2023-01-07 04:36:51 --> Config Class Initialized
INFO - 2023-01-07 04:36:51 --> Loader Class Initialized
INFO - 2023-01-07 04:36:51 --> Helper loaded: url_helper
INFO - 2023-01-07 04:36:51 --> Helper loaded: file_helper
INFO - 2023-01-07 04:36:51 --> Helper loaded: form_helper
INFO - 2023-01-07 04:36:51 --> Helper loaded: my_helper
INFO - 2023-01-07 04:36:51 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:36:51 --> Controller Class Initialized
INFO - 2023-01-07 04:36:51 --> Final output sent to browser
DEBUG - 2023-01-07 04:36:51 --> Total execution time: 0.0440
INFO - 2023-01-07 04:37:00 --> Config Class Initialized
INFO - 2023-01-07 04:37:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:37:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:37:00 --> Utf8 Class Initialized
INFO - 2023-01-07 04:37:00 --> URI Class Initialized
INFO - 2023-01-07 04:37:00 --> Router Class Initialized
INFO - 2023-01-07 04:37:00 --> Output Class Initialized
INFO - 2023-01-07 04:37:00 --> Security Class Initialized
DEBUG - 2023-01-07 04:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:37:00 --> Input Class Initialized
INFO - 2023-01-07 04:37:00 --> Language Class Initialized
INFO - 2023-01-07 04:37:00 --> Language Class Initialized
INFO - 2023-01-07 04:37:00 --> Config Class Initialized
INFO - 2023-01-07 04:37:00 --> Loader Class Initialized
INFO - 2023-01-07 04:37:00 --> Helper loaded: url_helper
INFO - 2023-01-07 04:37:00 --> Helper loaded: file_helper
INFO - 2023-01-07 04:37:00 --> Helper loaded: form_helper
INFO - 2023-01-07 04:37:00 --> Helper loaded: my_helper
INFO - 2023-01-07 04:37:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:37:00 --> Controller Class Initialized
DEBUG - 2023-01-07 04:37:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:37:00 --> Final output sent to browser
DEBUG - 2023-01-07 04:37:00 --> Total execution time: 0.0325
INFO - 2023-01-07 04:39:55 --> Config Class Initialized
INFO - 2023-01-07 04:39:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:39:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:39:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:39:55 --> URI Class Initialized
INFO - 2023-01-07 04:39:55 --> Router Class Initialized
INFO - 2023-01-07 04:39:55 --> Output Class Initialized
INFO - 2023-01-07 04:39:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:39:55 --> Input Class Initialized
INFO - 2023-01-07 04:39:55 --> Language Class Initialized
INFO - 2023-01-07 04:39:55 --> Language Class Initialized
INFO - 2023-01-07 04:39:55 --> Config Class Initialized
INFO - 2023-01-07 04:39:55 --> Loader Class Initialized
INFO - 2023-01-07 04:39:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:39:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:39:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:39:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:39:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:39:55 --> Controller Class Initialized
DEBUG - 2023-01-07 04:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-07 04:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:39:55 --> Final output sent to browser
DEBUG - 2023-01-07 04:39:55 --> Total execution time: 0.0406
INFO - 2023-01-07 04:40:57 --> Config Class Initialized
INFO - 2023-01-07 04:40:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:40:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:40:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:40:57 --> URI Class Initialized
INFO - 2023-01-07 04:40:57 --> Router Class Initialized
INFO - 2023-01-07 04:40:57 --> Output Class Initialized
INFO - 2023-01-07 04:40:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:40:57 --> Input Class Initialized
INFO - 2023-01-07 04:40:57 --> Language Class Initialized
ERROR - 2023-01-07 04:40:57 --> 404 Page Not Found: /index
INFO - 2023-01-07 04:43:58 --> Config Class Initialized
INFO - 2023-01-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:43:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:43:58 --> URI Class Initialized
INFO - 2023-01-07 04:43:58 --> Router Class Initialized
INFO - 2023-01-07 04:43:58 --> Output Class Initialized
INFO - 2023-01-07 04:43:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:43:58 --> Input Class Initialized
INFO - 2023-01-07 04:43:58 --> Language Class Initialized
INFO - 2023-01-07 04:43:58 --> Language Class Initialized
INFO - 2023-01-07 04:43:58 --> Config Class Initialized
INFO - 2023-01-07 04:43:58 --> Loader Class Initialized
INFO - 2023-01-07 04:43:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:43:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:43:58 --> Controller Class Initialized
INFO - 2023-01-07 04:43:58 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:43:58 --> Config Class Initialized
INFO - 2023-01-07 04:43:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:43:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:43:58 --> Utf8 Class Initialized
INFO - 2023-01-07 04:43:58 --> URI Class Initialized
INFO - 2023-01-07 04:43:58 --> Router Class Initialized
INFO - 2023-01-07 04:43:58 --> Output Class Initialized
INFO - 2023-01-07 04:43:58 --> Security Class Initialized
DEBUG - 2023-01-07 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:43:58 --> Input Class Initialized
INFO - 2023-01-07 04:43:58 --> Language Class Initialized
INFO - 2023-01-07 04:43:58 --> Language Class Initialized
INFO - 2023-01-07 04:43:58 --> Config Class Initialized
INFO - 2023-01-07 04:43:58 --> Loader Class Initialized
INFO - 2023-01-07 04:43:58 --> Helper loaded: url_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: file_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: form_helper
INFO - 2023-01-07 04:43:58 --> Helper loaded: my_helper
INFO - 2023-01-07 04:43:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:43:58 --> Controller Class Initialized
INFO - 2023-01-07 04:43:59 --> Config Class Initialized
INFO - 2023-01-07 04:43:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:43:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:43:59 --> Utf8 Class Initialized
INFO - 2023-01-07 04:43:59 --> URI Class Initialized
INFO - 2023-01-07 04:43:59 --> Router Class Initialized
INFO - 2023-01-07 04:43:59 --> Output Class Initialized
INFO - 2023-01-07 04:43:59 --> Security Class Initialized
DEBUG - 2023-01-07 04:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:43:59 --> Input Class Initialized
INFO - 2023-01-07 04:43:59 --> Language Class Initialized
INFO - 2023-01-07 04:43:59 --> Language Class Initialized
INFO - 2023-01-07 04:43:59 --> Config Class Initialized
INFO - 2023-01-07 04:43:59 --> Loader Class Initialized
INFO - 2023-01-07 04:43:59 --> Helper loaded: url_helper
INFO - 2023-01-07 04:43:59 --> Helper loaded: file_helper
INFO - 2023-01-07 04:43:59 --> Helper loaded: form_helper
INFO - 2023-01-07 04:43:59 --> Helper loaded: my_helper
INFO - 2023-01-07 04:43:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:43:59 --> Controller Class Initialized
DEBUG - 2023-01-07 04:43:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:43:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:43:59 --> Final output sent to browser
DEBUG - 2023-01-07 04:43:59 --> Total execution time: 0.0226
INFO - 2023-01-07 04:44:06 --> Config Class Initialized
INFO - 2023-01-07 04:44:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:06 --> URI Class Initialized
INFO - 2023-01-07 04:44:06 --> Router Class Initialized
INFO - 2023-01-07 04:44:06 --> Output Class Initialized
INFO - 2023-01-07 04:44:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:06 --> Input Class Initialized
INFO - 2023-01-07 04:44:06 --> Language Class Initialized
INFO - 2023-01-07 04:44:06 --> Language Class Initialized
INFO - 2023-01-07 04:44:06 --> Config Class Initialized
INFO - 2023-01-07 04:44:06 --> Loader Class Initialized
INFO - 2023-01-07 04:44:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:06 --> Controller Class Initialized
INFO - 2023-01-07 04:44:06 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:44:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:06 --> Total execution time: 0.0422
INFO - 2023-01-07 04:44:06 --> Config Class Initialized
INFO - 2023-01-07 04:44:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:06 --> URI Class Initialized
INFO - 2023-01-07 04:44:06 --> Router Class Initialized
INFO - 2023-01-07 04:44:06 --> Output Class Initialized
INFO - 2023-01-07 04:44:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:06 --> Input Class Initialized
INFO - 2023-01-07 04:44:06 --> Language Class Initialized
INFO - 2023-01-07 04:44:06 --> Language Class Initialized
INFO - 2023-01-07 04:44:06 --> Config Class Initialized
INFO - 2023-01-07 04:44:06 --> Loader Class Initialized
INFO - 2023-01-07 04:44:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:06 --> Controller Class Initialized
DEBUG - 2023-01-07 04:44:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 04:44:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:06 --> Total execution time: 0.0705
INFO - 2023-01-07 04:44:08 --> Config Class Initialized
INFO - 2023-01-07 04:44:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:08 --> URI Class Initialized
INFO - 2023-01-07 04:44:08 --> Router Class Initialized
INFO - 2023-01-07 04:44:08 --> Output Class Initialized
INFO - 2023-01-07 04:44:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:08 --> Input Class Initialized
INFO - 2023-01-07 04:44:08 --> Language Class Initialized
INFO - 2023-01-07 04:44:08 --> Language Class Initialized
INFO - 2023-01-07 04:44:08 --> Config Class Initialized
INFO - 2023-01-07 04:44:08 --> Loader Class Initialized
INFO - 2023-01-07 04:44:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:44:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:44:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:08 --> Total execution time: 0.0463
INFO - 2023-01-07 04:44:08 --> Config Class Initialized
INFO - 2023-01-07 04:44:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:08 --> URI Class Initialized
INFO - 2023-01-07 04:44:08 --> Router Class Initialized
INFO - 2023-01-07 04:44:08 --> Output Class Initialized
INFO - 2023-01-07 04:44:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:08 --> Input Class Initialized
INFO - 2023-01-07 04:44:08 --> Language Class Initialized
INFO - 2023-01-07 04:44:08 --> Language Class Initialized
INFO - 2023-01-07 04:44:08 --> Config Class Initialized
INFO - 2023-01-07 04:44:08 --> Loader Class Initialized
INFO - 2023-01-07 04:44:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:08 --> Controller Class Initialized
INFO - 2023-01-07 04:44:10 --> Config Class Initialized
INFO - 2023-01-07 04:44:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:10 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:10 --> URI Class Initialized
INFO - 2023-01-07 04:44:10 --> Router Class Initialized
INFO - 2023-01-07 04:44:10 --> Output Class Initialized
INFO - 2023-01-07 04:44:10 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:10 --> Input Class Initialized
INFO - 2023-01-07 04:44:10 --> Language Class Initialized
INFO - 2023-01-07 04:44:10 --> Language Class Initialized
INFO - 2023-01-07 04:44:10 --> Config Class Initialized
INFO - 2023-01-07 04:44:10 --> Loader Class Initialized
INFO - 2023-01-07 04:44:10 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:10 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:10 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:10 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:10 --> Controller Class Initialized
ERROR - 2023-01-07 04:44:10 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-01-07 04:44:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-01-07 04:44:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:10 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:10 --> Total execution time: 0.0741
INFO - 2023-01-07 04:44:13 --> Config Class Initialized
INFO - 2023-01-07 04:44:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:13 --> URI Class Initialized
INFO - 2023-01-07 04:44:13 --> Router Class Initialized
INFO - 2023-01-07 04:44:13 --> Output Class Initialized
INFO - 2023-01-07 04:44:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:13 --> Input Class Initialized
INFO - 2023-01-07 04:44:13 --> Language Class Initialized
INFO - 2023-01-07 04:44:13 --> Language Class Initialized
INFO - 2023-01-07 04:44:13 --> Config Class Initialized
INFO - 2023-01-07 04:44:13 --> Loader Class Initialized
INFO - 2023-01-07 04:44:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:13 --> Controller Class Initialized
DEBUG - 2023-01-07 04:44:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:44:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:13 --> Total execution time: 0.0254
INFO - 2023-01-07 04:44:13 --> Config Class Initialized
INFO - 2023-01-07 04:44:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:13 --> URI Class Initialized
INFO - 2023-01-07 04:44:13 --> Router Class Initialized
INFO - 2023-01-07 04:44:13 --> Output Class Initialized
INFO - 2023-01-07 04:44:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:13 --> Input Class Initialized
INFO - 2023-01-07 04:44:13 --> Language Class Initialized
INFO - 2023-01-07 04:44:13 --> Language Class Initialized
INFO - 2023-01-07 04:44:13 --> Config Class Initialized
INFO - 2023-01-07 04:44:13 --> Loader Class Initialized
INFO - 2023-01-07 04:44:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:13 --> Controller Class Initialized
INFO - 2023-01-07 04:44:15 --> Config Class Initialized
INFO - 2023-01-07 04:44:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:15 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:15 --> URI Class Initialized
INFO - 2023-01-07 04:44:15 --> Router Class Initialized
INFO - 2023-01-07 04:44:16 --> Output Class Initialized
INFO - 2023-01-07 04:44:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:16 --> Input Class Initialized
INFO - 2023-01-07 04:44:16 --> Language Class Initialized
INFO - 2023-01-07 04:44:16 --> Language Class Initialized
INFO - 2023-01-07 04:44:16 --> Config Class Initialized
INFO - 2023-01-07 04:44:16 --> Loader Class Initialized
INFO - 2023-01-07 04:44:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:16 --> Controller Class Initialized
ERROR - 2023-01-07 04:44:16 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-01-07 04:44:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-01-07 04:44:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:16 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:16 --> Total execution time: 0.0302
INFO - 2023-01-07 04:44:20 --> Config Class Initialized
INFO - 2023-01-07 04:44:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:20 --> URI Class Initialized
INFO - 2023-01-07 04:44:20 --> Router Class Initialized
INFO - 2023-01-07 04:44:20 --> Output Class Initialized
INFO - 2023-01-07 04:44:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:20 --> Input Class Initialized
INFO - 2023-01-07 04:44:20 --> Language Class Initialized
INFO - 2023-01-07 04:44:20 --> Language Class Initialized
INFO - 2023-01-07 04:44:20 --> Config Class Initialized
INFO - 2023-01-07 04:44:20 --> Loader Class Initialized
INFO - 2023-01-07 04:44:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:20 --> Controller Class Initialized
DEBUG - 2023-01-07 04:44:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:44:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:20 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:20 --> Total execution time: 0.0273
INFO - 2023-01-07 04:44:20 --> Config Class Initialized
INFO - 2023-01-07 04:44:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:20 --> URI Class Initialized
INFO - 2023-01-07 04:44:20 --> Router Class Initialized
INFO - 2023-01-07 04:44:20 --> Output Class Initialized
INFO - 2023-01-07 04:44:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:20 --> Input Class Initialized
INFO - 2023-01-07 04:44:20 --> Language Class Initialized
INFO - 2023-01-07 04:44:20 --> Language Class Initialized
INFO - 2023-01-07 04:44:20 --> Config Class Initialized
INFO - 2023-01-07 04:44:20 --> Loader Class Initialized
INFO - 2023-01-07 04:44:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:20 --> Controller Class Initialized
INFO - 2023-01-07 04:44:21 --> Config Class Initialized
INFO - 2023-01-07 04:44:21 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:21 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:21 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:21 --> URI Class Initialized
INFO - 2023-01-07 04:44:21 --> Router Class Initialized
INFO - 2023-01-07 04:44:21 --> Output Class Initialized
INFO - 2023-01-07 04:44:21 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:21 --> Input Class Initialized
INFO - 2023-01-07 04:44:21 --> Language Class Initialized
INFO - 2023-01-07 04:44:21 --> Language Class Initialized
INFO - 2023-01-07 04:44:21 --> Config Class Initialized
INFO - 2023-01-07 04:44:21 --> Loader Class Initialized
INFO - 2023-01-07 04:44:21 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:21 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:21 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:21 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:21 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:21 --> Controller Class Initialized
ERROR - 2023-01-07 04:44:21 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-01-07 04:44:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-01-07 04:44:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:21 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:21 --> Total execution time: 0.0292
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:55 --> URI Class Initialized
INFO - 2023-01-07 04:44:55 --> Router Class Initialized
INFO - 2023-01-07 04:44:55 --> Output Class Initialized
INFO - 2023-01-07 04:44:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:55 --> Input Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Loader Class Initialized
INFO - 2023-01-07 04:44:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:55 --> Controller Class Initialized
INFO - 2023-01-07 04:44:55 --> Upload Class Initialized
INFO - 2023-01-07 04:44:55 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-01-07 04:44:55 --> The upload path does not appear to be valid.
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:55 --> URI Class Initialized
INFO - 2023-01-07 04:44:55 --> Router Class Initialized
INFO - 2023-01-07 04:44:55 --> Output Class Initialized
INFO - 2023-01-07 04:44:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:55 --> Input Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Loader Class Initialized
INFO - 2023-01-07 04:44:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:55 --> Controller Class Initialized
DEBUG - 2023-01-07 04:44:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:44:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:44:55 --> Final output sent to browser
DEBUG - 2023-01-07 04:44:55 --> Total execution time: 0.0386
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:44:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:44:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:44:55 --> URI Class Initialized
INFO - 2023-01-07 04:44:55 --> Router Class Initialized
INFO - 2023-01-07 04:44:55 --> Output Class Initialized
INFO - 2023-01-07 04:44:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:44:55 --> Input Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Language Class Initialized
INFO - 2023-01-07 04:44:55 --> Config Class Initialized
INFO - 2023-01-07 04:44:55 --> Loader Class Initialized
INFO - 2023-01-07 04:44:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:44:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:44:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:44:55 --> Controller Class Initialized
INFO - 2023-01-07 04:45:01 --> Config Class Initialized
INFO - 2023-01-07 04:45:01 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:01 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:01 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:01 --> URI Class Initialized
INFO - 2023-01-07 04:45:01 --> Router Class Initialized
INFO - 2023-01-07 04:45:01 --> Output Class Initialized
INFO - 2023-01-07 04:45:01 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:01 --> Input Class Initialized
INFO - 2023-01-07 04:45:01 --> Language Class Initialized
INFO - 2023-01-07 04:45:01 --> Language Class Initialized
INFO - 2023-01-07 04:45:01 --> Config Class Initialized
INFO - 2023-01-07 04:45:01 --> Loader Class Initialized
INFO - 2023-01-07 04:45:01 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:01 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:01 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:01 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:01 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:01 --> Controller Class Initialized
ERROR - 2023-01-07 04:45:01 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-01-07 04:45:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-01-07 04:45:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:01 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:01 --> Total execution time: 0.0311
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:06 --> URI Class Initialized
INFO - 2023-01-07 04:45:06 --> Router Class Initialized
INFO - 2023-01-07 04:45:06 --> Output Class Initialized
INFO - 2023-01-07 04:45:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:06 --> Input Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Loader Class Initialized
INFO - 2023-01-07 04:45:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:06 --> Controller Class Initialized
INFO - 2023-01-07 04:45:06 --> Upload Class Initialized
INFO - 2023-01-07 04:45:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-01-07 04:45:06 --> The upload path does not appear to be valid.
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:06 --> URI Class Initialized
INFO - 2023-01-07 04:45:06 --> Router Class Initialized
INFO - 2023-01-07 04:45:06 --> Output Class Initialized
INFO - 2023-01-07 04:45:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:06 --> Input Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Loader Class Initialized
INFO - 2023-01-07 04:45:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:06 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:45:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:06 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:06 --> Total execution time: 0.0244
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:06 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:06 --> URI Class Initialized
INFO - 2023-01-07 04:45:06 --> Router Class Initialized
INFO - 2023-01-07 04:45:06 --> Output Class Initialized
INFO - 2023-01-07 04:45:06 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:06 --> Input Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Language Class Initialized
INFO - 2023-01-07 04:45:06 --> Config Class Initialized
INFO - 2023-01-07 04:45:06 --> Loader Class Initialized
INFO - 2023-01-07 04:45:06 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:06 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:07 --> Controller Class Initialized
INFO - 2023-01-07 04:45:13 --> Config Class Initialized
INFO - 2023-01-07 04:45:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:13 --> URI Class Initialized
INFO - 2023-01-07 04:45:13 --> Router Class Initialized
INFO - 2023-01-07 04:45:13 --> Output Class Initialized
INFO - 2023-01-07 04:45:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:13 --> Input Class Initialized
INFO - 2023-01-07 04:45:13 --> Language Class Initialized
INFO - 2023-01-07 04:45:13 --> Language Class Initialized
INFO - 2023-01-07 04:45:13 --> Config Class Initialized
INFO - 2023-01-07 04:45:13 --> Loader Class Initialized
INFO - 2023-01-07 04:45:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:13 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 04:45:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:13 --> Total execution time: 0.0525
INFO - 2023-01-07 04:45:16 --> Config Class Initialized
INFO - 2023-01-07 04:45:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:16 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:16 --> URI Class Initialized
INFO - 2023-01-07 04:45:16 --> Router Class Initialized
INFO - 2023-01-07 04:45:16 --> Output Class Initialized
INFO - 2023-01-07 04:45:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:16 --> Input Class Initialized
INFO - 2023-01-07 04:45:16 --> Language Class Initialized
INFO - 2023-01-07 04:45:16 --> Language Class Initialized
INFO - 2023-01-07 04:45:16 --> Config Class Initialized
INFO - 2023-01-07 04:45:16 --> Loader Class Initialized
INFO - 2023-01-07 04:45:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:16 --> Controller Class Initialized
ERROR - 2023-01-07 04:45:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 04:45:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 04:45:16 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 04:45:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 04:45:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:16 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:16 --> Total execution time: 0.0465
INFO - 2023-01-07 04:45:25 --> Config Class Initialized
INFO - 2023-01-07 04:45:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:25 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:25 --> URI Class Initialized
INFO - 2023-01-07 04:45:25 --> Router Class Initialized
INFO - 2023-01-07 04:45:25 --> Output Class Initialized
INFO - 2023-01-07 04:45:25 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:25 --> Input Class Initialized
INFO - 2023-01-07 04:45:25 --> Language Class Initialized
INFO - 2023-01-07 04:45:25 --> Language Class Initialized
INFO - 2023-01-07 04:45:25 --> Config Class Initialized
INFO - 2023-01-07 04:45:25 --> Loader Class Initialized
INFO - 2023-01-07 04:45:25 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:25 --> Controller Class Initialized
INFO - 2023-01-07 04:45:25 --> Config Class Initialized
INFO - 2023-01-07 04:45:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:25 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:25 --> URI Class Initialized
INFO - 2023-01-07 04:45:25 --> Router Class Initialized
INFO - 2023-01-07 04:45:25 --> Output Class Initialized
INFO - 2023-01-07 04:45:25 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:25 --> Input Class Initialized
INFO - 2023-01-07 04:45:25 --> Language Class Initialized
INFO - 2023-01-07 04:45:25 --> Language Class Initialized
INFO - 2023-01-07 04:45:25 --> Config Class Initialized
INFO - 2023-01-07 04:45:25 --> Loader Class Initialized
INFO - 2023-01-07 04:45:25 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:25 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:25 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 04:45:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:25 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:25 --> Total execution time: 0.0375
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:29 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:29 --> URI Class Initialized
INFO - 2023-01-07 04:45:29 --> Router Class Initialized
INFO - 2023-01-07 04:45:29 --> Output Class Initialized
INFO - 2023-01-07 04:45:29 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:29 --> Input Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Loader Class Initialized
INFO - 2023-01-07 04:45:29 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:29 --> Controller Class Initialized
INFO - 2023-01-07 04:45:29 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:29 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:29 --> URI Class Initialized
INFO - 2023-01-07 04:45:29 --> Router Class Initialized
INFO - 2023-01-07 04:45:29 --> Output Class Initialized
INFO - 2023-01-07 04:45:29 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:29 --> Input Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Loader Class Initialized
INFO - 2023-01-07 04:45:29 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:29 --> Controller Class Initialized
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:29 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:29 --> URI Class Initialized
INFO - 2023-01-07 04:45:29 --> Router Class Initialized
INFO - 2023-01-07 04:45:29 --> Output Class Initialized
INFO - 2023-01-07 04:45:29 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:29 --> Input Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Language Class Initialized
INFO - 2023-01-07 04:45:29 --> Config Class Initialized
INFO - 2023-01-07 04:45:29 --> Loader Class Initialized
INFO - 2023-01-07 04:45:29 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:29 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:29 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:45:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:29 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:29 --> Total execution time: 0.0231
INFO - 2023-01-07 04:45:37 --> Config Class Initialized
INFO - 2023-01-07 04:45:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:37 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:37 --> URI Class Initialized
INFO - 2023-01-07 04:45:37 --> Router Class Initialized
INFO - 2023-01-07 04:45:37 --> Output Class Initialized
INFO - 2023-01-07 04:45:37 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:37 --> Input Class Initialized
INFO - 2023-01-07 04:45:37 --> Language Class Initialized
INFO - 2023-01-07 04:45:37 --> Language Class Initialized
INFO - 2023-01-07 04:45:37 --> Config Class Initialized
INFO - 2023-01-07 04:45:37 --> Loader Class Initialized
INFO - 2023-01-07 04:45:37 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:37 --> Controller Class Initialized
INFO - 2023-01-07 04:45:37 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:45:37 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:37 --> Total execution time: 0.0451
INFO - 2023-01-07 04:45:37 --> Config Class Initialized
INFO - 2023-01-07 04:45:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:37 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:37 --> URI Class Initialized
INFO - 2023-01-07 04:45:37 --> Router Class Initialized
INFO - 2023-01-07 04:45:37 --> Output Class Initialized
INFO - 2023-01-07 04:45:37 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:37 --> Input Class Initialized
INFO - 2023-01-07 04:45:37 --> Language Class Initialized
INFO - 2023-01-07 04:45:37 --> Language Class Initialized
INFO - 2023-01-07 04:45:37 --> Config Class Initialized
INFO - 2023-01-07 04:45:37 --> Loader Class Initialized
INFO - 2023-01-07 04:45:37 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:37 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:37 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:45:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:37 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:37 --> Total execution time: 0.0299
INFO - 2023-01-07 04:45:41 --> Config Class Initialized
INFO - 2023-01-07 04:45:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:41 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:41 --> URI Class Initialized
DEBUG - 2023-01-07 04:45:41 --> No URI present. Default controller set.
INFO - 2023-01-07 04:45:41 --> Router Class Initialized
INFO - 2023-01-07 04:45:41 --> Output Class Initialized
INFO - 2023-01-07 04:45:41 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:41 --> Input Class Initialized
INFO - 2023-01-07 04:45:41 --> Language Class Initialized
INFO - 2023-01-07 04:45:41 --> Language Class Initialized
INFO - 2023-01-07 04:45:41 --> Config Class Initialized
INFO - 2023-01-07 04:45:41 --> Loader Class Initialized
INFO - 2023-01-07 04:45:41 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:41 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:41 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:41 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:41 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:45:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:41 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:41 --> Total execution time: 0.0432
INFO - 2023-01-07 04:45:42 --> Config Class Initialized
INFO - 2023-01-07 04:45:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:42 --> URI Class Initialized
INFO - 2023-01-07 04:45:42 --> Router Class Initialized
INFO - 2023-01-07 04:45:42 --> Output Class Initialized
INFO - 2023-01-07 04:45:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:42 --> Input Class Initialized
INFO - 2023-01-07 04:45:42 --> Language Class Initialized
INFO - 2023-01-07 04:45:42 --> Language Class Initialized
INFO - 2023-01-07 04:45:42 --> Config Class Initialized
INFO - 2023-01-07 04:45:42 --> Loader Class Initialized
INFO - 2023-01-07 04:45:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:42 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 04:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:42 --> Total execution time: 0.0416
INFO - 2023-01-07 04:45:44 --> Config Class Initialized
INFO - 2023-01-07 04:45:44 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:44 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:44 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:44 --> URI Class Initialized
INFO - 2023-01-07 04:45:44 --> Router Class Initialized
INFO - 2023-01-07 04:45:44 --> Output Class Initialized
INFO - 2023-01-07 04:45:44 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:44 --> Input Class Initialized
INFO - 2023-01-07 04:45:44 --> Language Class Initialized
INFO - 2023-01-07 04:45:44 --> Language Class Initialized
INFO - 2023-01-07 04:45:44 --> Config Class Initialized
INFO - 2023-01-07 04:45:44 --> Loader Class Initialized
INFO - 2023-01-07 04:45:44 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:44 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:44 --> Controller Class Initialized
DEBUG - 2023-01-07 04:45:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:45:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:45:44 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:44 --> Total execution time: 0.0430
INFO - 2023-01-07 04:45:44 --> Config Class Initialized
INFO - 2023-01-07 04:45:44 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:44 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:44 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:44 --> URI Class Initialized
INFO - 2023-01-07 04:45:44 --> Router Class Initialized
INFO - 2023-01-07 04:45:44 --> Output Class Initialized
INFO - 2023-01-07 04:45:44 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:44 --> Input Class Initialized
INFO - 2023-01-07 04:45:44 --> Language Class Initialized
INFO - 2023-01-07 04:45:44 --> Language Class Initialized
INFO - 2023-01-07 04:45:44 --> Config Class Initialized
INFO - 2023-01-07 04:45:44 --> Loader Class Initialized
INFO - 2023-01-07 04:45:44 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:44 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:44 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:44 --> Controller Class Initialized
INFO - 2023-01-07 04:45:47 --> Config Class Initialized
INFO - 2023-01-07 04:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:47 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:47 --> URI Class Initialized
INFO - 2023-01-07 04:45:47 --> Router Class Initialized
INFO - 2023-01-07 04:45:47 --> Output Class Initialized
INFO - 2023-01-07 04:45:47 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:47 --> Input Class Initialized
INFO - 2023-01-07 04:45:47 --> Language Class Initialized
INFO - 2023-01-07 04:45:47 --> Language Class Initialized
INFO - 2023-01-07 04:45:47 --> Config Class Initialized
INFO - 2023-01-07 04:45:47 --> Loader Class Initialized
INFO - 2023-01-07 04:45:47 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:47 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:47 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:47 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:47 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:47 --> Controller Class Initialized
INFO - 2023-01-07 04:45:56 --> Config Class Initialized
INFO - 2023-01-07 04:45:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:45:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:45:56 --> Utf8 Class Initialized
INFO - 2023-01-07 04:45:56 --> URI Class Initialized
INFO - 2023-01-07 04:45:56 --> Router Class Initialized
INFO - 2023-01-07 04:45:56 --> Output Class Initialized
INFO - 2023-01-07 04:45:56 --> Security Class Initialized
DEBUG - 2023-01-07 04:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:45:56 --> Input Class Initialized
INFO - 2023-01-07 04:45:56 --> Language Class Initialized
INFO - 2023-01-07 04:45:56 --> Language Class Initialized
INFO - 2023-01-07 04:45:56 --> Config Class Initialized
INFO - 2023-01-07 04:45:56 --> Loader Class Initialized
INFO - 2023-01-07 04:45:56 --> Helper loaded: url_helper
INFO - 2023-01-07 04:45:56 --> Helper loaded: file_helper
INFO - 2023-01-07 04:45:56 --> Helper loaded: form_helper
INFO - 2023-01-07 04:45:56 --> Helper loaded: my_helper
INFO - 2023-01-07 04:45:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:45:56 --> Controller Class Initialized
INFO - 2023-01-07 04:45:56 --> Final output sent to browser
DEBUG - 2023-01-07 04:45:56 --> Total execution time: 0.0442
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:07 --> URI Class Initialized
INFO - 2023-01-07 04:46:07 --> Router Class Initialized
INFO - 2023-01-07 04:46:07 --> Output Class Initialized
INFO - 2023-01-07 04:46:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:07 --> Input Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Loader Class Initialized
INFO - 2023-01-07 04:46:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:07 --> Controller Class Initialized
INFO - 2023-01-07 04:46:07 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:07 --> URI Class Initialized
INFO - 2023-01-07 04:46:07 --> Router Class Initialized
INFO - 2023-01-07 04:46:07 --> Output Class Initialized
INFO - 2023-01-07 04:46:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:07 --> Input Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Loader Class Initialized
INFO - 2023-01-07 04:46:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:07 --> Controller Class Initialized
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:07 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:07 --> URI Class Initialized
INFO - 2023-01-07 04:46:07 --> Router Class Initialized
INFO - 2023-01-07 04:46:07 --> Output Class Initialized
INFO - 2023-01-07 04:46:07 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:07 --> Input Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Language Class Initialized
INFO - 2023-01-07 04:46:07 --> Config Class Initialized
INFO - 2023-01-07 04:46:07 --> Loader Class Initialized
INFO - 2023-01-07 04:46:07 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:07 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:07 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:46:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:07 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:07 --> Total execution time: 0.0456
INFO - 2023-01-07 04:46:13 --> Config Class Initialized
INFO - 2023-01-07 04:46:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:13 --> URI Class Initialized
INFO - 2023-01-07 04:46:13 --> Router Class Initialized
INFO - 2023-01-07 04:46:13 --> Output Class Initialized
INFO - 2023-01-07 04:46:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:13 --> Input Class Initialized
INFO - 2023-01-07 04:46:13 --> Language Class Initialized
INFO - 2023-01-07 04:46:13 --> Language Class Initialized
INFO - 2023-01-07 04:46:13 --> Config Class Initialized
INFO - 2023-01-07 04:46:13 --> Loader Class Initialized
INFO - 2023-01-07 04:46:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:13 --> Controller Class Initialized
INFO - 2023-01-07 04:46:13 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:46:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:13 --> Total execution time: 0.0259
INFO - 2023-01-07 04:46:13 --> Config Class Initialized
INFO - 2023-01-07 04:46:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:13 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:13 --> URI Class Initialized
INFO - 2023-01-07 04:46:13 --> Router Class Initialized
INFO - 2023-01-07 04:46:13 --> Output Class Initialized
INFO - 2023-01-07 04:46:13 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:13 --> Input Class Initialized
INFO - 2023-01-07 04:46:13 --> Language Class Initialized
INFO - 2023-01-07 04:46:13 --> Language Class Initialized
INFO - 2023-01-07 04:46:13 --> Config Class Initialized
INFO - 2023-01-07 04:46:13 --> Loader Class Initialized
INFO - 2023-01-07 04:46:13 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:13 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:13 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:46:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:13 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:13 --> Total execution time: 0.0315
INFO - 2023-01-07 04:46:19 --> Config Class Initialized
INFO - 2023-01-07 04:46:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:19 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:19 --> URI Class Initialized
INFO - 2023-01-07 04:46:19 --> Router Class Initialized
INFO - 2023-01-07 04:46:19 --> Output Class Initialized
INFO - 2023-01-07 04:46:19 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:19 --> Input Class Initialized
INFO - 2023-01-07 04:46:19 --> Language Class Initialized
INFO - 2023-01-07 04:46:19 --> Language Class Initialized
INFO - 2023-01-07 04:46:19 --> Config Class Initialized
INFO - 2023-01-07 04:46:19 --> Loader Class Initialized
INFO - 2023-01-07 04:46:19 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:19 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:19 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:19 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:19 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 04:46:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:19 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:19 --> Total execution time: 0.0423
INFO - 2023-01-07 04:46:21 --> Config Class Initialized
INFO - 2023-01-07 04:46:21 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:21 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:21 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:21 --> URI Class Initialized
INFO - 2023-01-07 04:46:21 --> Router Class Initialized
INFO - 2023-01-07 04:46:21 --> Output Class Initialized
INFO - 2023-01-07 04:46:21 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:21 --> Input Class Initialized
INFO - 2023-01-07 04:46:21 --> Language Class Initialized
INFO - 2023-01-07 04:46:21 --> Language Class Initialized
INFO - 2023-01-07 04:46:21 --> Config Class Initialized
INFO - 2023-01-07 04:46:21 --> Loader Class Initialized
INFO - 2023-01-07 04:46:21 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:21 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:21 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:21 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:21 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:21 --> Controller Class Initialized
ERROR - 2023-01-07 04:46:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 327
ERROR - 2023-01-07 04:46:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2023-01-07 04:46:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 04:46:21 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:21 --> Total execution time: 0.1761
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:33 --> URI Class Initialized
INFO - 2023-01-07 04:46:33 --> Router Class Initialized
INFO - 2023-01-07 04:46:33 --> Output Class Initialized
INFO - 2023-01-07 04:46:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:33 --> Input Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Loader Class Initialized
INFO - 2023-01-07 04:46:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:33 --> Controller Class Initialized
INFO - 2023-01-07 04:46:33 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:33 --> URI Class Initialized
INFO - 2023-01-07 04:46:33 --> Router Class Initialized
INFO - 2023-01-07 04:46:33 --> Output Class Initialized
INFO - 2023-01-07 04:46:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:33 --> Input Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Loader Class Initialized
INFO - 2023-01-07 04:46:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:33 --> Controller Class Initialized
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:33 --> URI Class Initialized
INFO - 2023-01-07 04:46:33 --> Router Class Initialized
INFO - 2023-01-07 04:46:33 --> Output Class Initialized
INFO - 2023-01-07 04:46:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:33 --> Input Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Language Class Initialized
INFO - 2023-01-07 04:46:33 --> Config Class Initialized
INFO - 2023-01-07 04:46:33 --> Loader Class Initialized
INFO - 2023-01-07 04:46:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:33 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:46:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:33 --> Total execution time: 0.0436
INFO - 2023-01-07 04:46:37 --> Config Class Initialized
INFO - 2023-01-07 04:46:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:37 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:37 --> URI Class Initialized
INFO - 2023-01-07 04:46:37 --> Router Class Initialized
INFO - 2023-01-07 04:46:37 --> Output Class Initialized
INFO - 2023-01-07 04:46:37 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:37 --> Input Class Initialized
INFO - 2023-01-07 04:46:37 --> Language Class Initialized
INFO - 2023-01-07 04:46:37 --> Language Class Initialized
INFO - 2023-01-07 04:46:37 --> Config Class Initialized
INFO - 2023-01-07 04:46:37 --> Loader Class Initialized
INFO - 2023-01-07 04:46:37 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:37 --> Controller Class Initialized
INFO - 2023-01-07 04:46:37 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:46:37 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:37 --> Total execution time: 0.0309
INFO - 2023-01-07 04:46:37 --> Config Class Initialized
INFO - 2023-01-07 04:46:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:37 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:37 --> URI Class Initialized
INFO - 2023-01-07 04:46:37 --> Router Class Initialized
INFO - 2023-01-07 04:46:37 --> Output Class Initialized
INFO - 2023-01-07 04:46:37 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:37 --> Input Class Initialized
INFO - 2023-01-07 04:46:37 --> Language Class Initialized
INFO - 2023-01-07 04:46:37 --> Language Class Initialized
INFO - 2023-01-07 04:46:37 --> Config Class Initialized
INFO - 2023-01-07 04:46:37 --> Loader Class Initialized
INFO - 2023-01-07 04:46:37 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:37 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:37 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 04:46:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:37 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:37 --> Total execution time: 0.0437
INFO - 2023-01-07 04:46:40 --> Config Class Initialized
INFO - 2023-01-07 04:46:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:40 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:40 --> URI Class Initialized
INFO - 2023-01-07 04:46:40 --> Router Class Initialized
INFO - 2023-01-07 04:46:40 --> Output Class Initialized
INFO - 2023-01-07 04:46:40 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:40 --> Input Class Initialized
INFO - 2023-01-07 04:46:40 --> Language Class Initialized
INFO - 2023-01-07 04:46:40 --> Language Class Initialized
INFO - 2023-01-07 04:46:40 --> Config Class Initialized
INFO - 2023-01-07 04:46:40 --> Loader Class Initialized
INFO - 2023-01-07 04:46:40 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:40 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-01-07 04:46:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:40 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:40 --> Total execution time: 0.0408
INFO - 2023-01-07 04:46:40 --> Config Class Initialized
INFO - 2023-01-07 04:46:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:40 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:40 --> URI Class Initialized
INFO - 2023-01-07 04:46:40 --> Router Class Initialized
INFO - 2023-01-07 04:46:40 --> Output Class Initialized
INFO - 2023-01-07 04:46:40 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:40 --> Input Class Initialized
INFO - 2023-01-07 04:46:40 --> Language Class Initialized
INFO - 2023-01-07 04:46:40 --> Language Class Initialized
INFO - 2023-01-07 04:46:40 --> Config Class Initialized
INFO - 2023-01-07 04:46:40 --> Loader Class Initialized
INFO - 2023-01-07 04:46:40 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:40 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:40 --> Controller Class Initialized
INFO - 2023-01-07 04:46:45 --> Config Class Initialized
INFO - 2023-01-07 04:46:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:45 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:45 --> URI Class Initialized
INFO - 2023-01-07 04:46:45 --> Router Class Initialized
INFO - 2023-01-07 04:46:45 --> Output Class Initialized
INFO - 2023-01-07 04:46:45 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:45 --> Input Class Initialized
INFO - 2023-01-07 04:46:45 --> Language Class Initialized
INFO - 2023-01-07 04:46:45 --> Language Class Initialized
INFO - 2023-01-07 04:46:45 --> Config Class Initialized
INFO - 2023-01-07 04:46:45 --> Loader Class Initialized
INFO - 2023-01-07 04:46:45 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:45 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-07 04:46:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:45 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:45 --> Total execution time: 0.0359
INFO - 2023-01-07 04:46:45 --> Config Class Initialized
INFO - 2023-01-07 04:46:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:45 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:45 --> URI Class Initialized
INFO - 2023-01-07 04:46:45 --> Router Class Initialized
INFO - 2023-01-07 04:46:45 --> Output Class Initialized
INFO - 2023-01-07 04:46:45 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:45 --> Input Class Initialized
INFO - 2023-01-07 04:46:45 --> Language Class Initialized
INFO - 2023-01-07 04:46:45 --> Language Class Initialized
INFO - 2023-01-07 04:46:45 --> Config Class Initialized
INFO - 2023-01-07 04:46:45 --> Loader Class Initialized
INFO - 2023-01-07 04:46:45 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:45 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:45 --> Controller Class Initialized
INFO - 2023-01-07 04:46:48 --> Config Class Initialized
INFO - 2023-01-07 04:46:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:48 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:48 --> URI Class Initialized
INFO - 2023-01-07 04:46:48 --> Router Class Initialized
INFO - 2023-01-07 04:46:48 --> Output Class Initialized
INFO - 2023-01-07 04:46:48 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:48 --> Input Class Initialized
INFO - 2023-01-07 04:46:48 --> Language Class Initialized
INFO - 2023-01-07 04:46:48 --> Language Class Initialized
INFO - 2023-01-07 04:46:48 --> Config Class Initialized
INFO - 2023-01-07 04:46:48 --> Loader Class Initialized
INFO - 2023-01-07 04:46:48 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:48 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:48 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:48 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:48 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 04:46:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:48 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:48 --> Total execution time: 0.0257
INFO - 2023-01-07 04:46:57 --> Config Class Initialized
INFO - 2023-01-07 04:46:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:57 --> URI Class Initialized
INFO - 2023-01-07 04:46:57 --> Router Class Initialized
INFO - 2023-01-07 04:46:57 --> Output Class Initialized
INFO - 2023-01-07 04:46:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:57 --> Input Class Initialized
INFO - 2023-01-07 04:46:57 --> Language Class Initialized
INFO - 2023-01-07 04:46:57 --> Language Class Initialized
INFO - 2023-01-07 04:46:57 --> Config Class Initialized
INFO - 2023-01-07 04:46:57 --> Loader Class Initialized
INFO - 2023-01-07 04:46:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:57 --> Controller Class Initialized
DEBUG - 2023-01-07 04:46:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_walikelas/views/list.php
DEBUG - 2023-01-07 04:46:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:46:57 --> Final output sent to browser
DEBUG - 2023-01-07 04:46:57 --> Total execution time: 0.0723
INFO - 2023-01-07 04:46:57 --> Config Class Initialized
INFO - 2023-01-07 04:46:57 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:46:57 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:46:57 --> Utf8 Class Initialized
INFO - 2023-01-07 04:46:57 --> URI Class Initialized
INFO - 2023-01-07 04:46:57 --> Router Class Initialized
INFO - 2023-01-07 04:46:57 --> Output Class Initialized
INFO - 2023-01-07 04:46:57 --> Security Class Initialized
DEBUG - 2023-01-07 04:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:46:57 --> Input Class Initialized
INFO - 2023-01-07 04:46:57 --> Language Class Initialized
INFO - 2023-01-07 04:46:57 --> Language Class Initialized
INFO - 2023-01-07 04:46:57 --> Config Class Initialized
INFO - 2023-01-07 04:46:57 --> Loader Class Initialized
INFO - 2023-01-07 04:46:57 --> Helper loaded: url_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: file_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: form_helper
INFO - 2023-01-07 04:46:57 --> Helper loaded: my_helper
INFO - 2023-01-07 04:46:57 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:46:57 --> Controller Class Initialized
INFO - 2023-01-07 04:47:02 --> Config Class Initialized
INFO - 2023-01-07 04:47:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:02 --> URI Class Initialized
INFO - 2023-01-07 04:47:02 --> Router Class Initialized
INFO - 2023-01-07 04:47:02 --> Output Class Initialized
INFO - 2023-01-07 04:47:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:02 --> Input Class Initialized
INFO - 2023-01-07 04:47:02 --> Language Class Initialized
INFO - 2023-01-07 04:47:02 --> Language Class Initialized
INFO - 2023-01-07 04:47:02 --> Config Class Initialized
INFO - 2023-01-07 04:47:02 --> Loader Class Initialized
INFO - 2023-01-07 04:47:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:02 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-07 04:47:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:47:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:02 --> Total execution time: 0.0420
INFO - 2023-01-07 04:47:02 --> Config Class Initialized
INFO - 2023-01-07 04:47:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:02 --> URI Class Initialized
INFO - 2023-01-07 04:47:02 --> Router Class Initialized
INFO - 2023-01-07 04:47:02 --> Output Class Initialized
INFO - 2023-01-07 04:47:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:02 --> Input Class Initialized
INFO - 2023-01-07 04:47:02 --> Language Class Initialized
INFO - 2023-01-07 04:47:02 --> Language Class Initialized
INFO - 2023-01-07 04:47:02 --> Config Class Initialized
INFO - 2023-01-07 04:47:02 --> Loader Class Initialized
INFO - 2023-01-07 04:47:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:02 --> Controller Class Initialized
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:04 --> URI Class Initialized
INFO - 2023-01-07 04:47:04 --> Router Class Initialized
INFO - 2023-01-07 04:47:04 --> Output Class Initialized
INFO - 2023-01-07 04:47:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:04 --> Input Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Loader Class Initialized
INFO - 2023-01-07 04:47:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:04 --> Controller Class Initialized
INFO - 2023-01-07 04:47:04 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:04 --> URI Class Initialized
INFO - 2023-01-07 04:47:04 --> Router Class Initialized
INFO - 2023-01-07 04:47:04 --> Output Class Initialized
INFO - 2023-01-07 04:47:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:04 --> Input Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Loader Class Initialized
INFO - 2023-01-07 04:47:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:04 --> Controller Class Initialized
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:04 --> URI Class Initialized
INFO - 2023-01-07 04:47:04 --> Router Class Initialized
INFO - 2023-01-07 04:47:04 --> Output Class Initialized
INFO - 2023-01-07 04:47:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:04 --> Input Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Language Class Initialized
INFO - 2023-01-07 04:47:04 --> Config Class Initialized
INFO - 2023-01-07 04:47:04 --> Loader Class Initialized
INFO - 2023-01-07 04:47:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:04 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:47:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:47:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:04 --> Total execution time: 0.0444
INFO - 2023-01-07 04:47:08 --> Config Class Initialized
INFO - 2023-01-07 04:47:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:08 --> URI Class Initialized
INFO - 2023-01-07 04:47:08 --> Router Class Initialized
INFO - 2023-01-07 04:47:08 --> Output Class Initialized
INFO - 2023-01-07 04:47:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:08 --> Input Class Initialized
INFO - 2023-01-07 04:47:08 --> Language Class Initialized
INFO - 2023-01-07 04:47:08 --> Language Class Initialized
INFO - 2023-01-07 04:47:08 --> Config Class Initialized
INFO - 2023-01-07 04:47:08 --> Loader Class Initialized
INFO - 2023-01-07 04:47:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:08 --> Controller Class Initialized
INFO - 2023-01-07 04:47:08 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:47:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:08 --> Total execution time: 0.0395
INFO - 2023-01-07 04:47:08 --> Config Class Initialized
INFO - 2023-01-07 04:47:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:08 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:08 --> URI Class Initialized
INFO - 2023-01-07 04:47:08 --> Router Class Initialized
INFO - 2023-01-07 04:47:08 --> Output Class Initialized
INFO - 2023-01-07 04:47:08 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:08 --> Input Class Initialized
INFO - 2023-01-07 04:47:08 --> Language Class Initialized
INFO - 2023-01-07 04:47:08 --> Language Class Initialized
INFO - 2023-01-07 04:47:08 --> Config Class Initialized
INFO - 2023-01-07 04:47:08 --> Loader Class Initialized
INFO - 2023-01-07 04:47:08 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:08 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:08 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:47:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:47:08 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:08 --> Total execution time: 0.0531
INFO - 2023-01-07 04:47:12 --> Config Class Initialized
INFO - 2023-01-07 04:47:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:12 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:12 --> URI Class Initialized
INFO - 2023-01-07 04:47:12 --> Router Class Initialized
INFO - 2023-01-07 04:47:12 --> Output Class Initialized
INFO - 2023-01-07 04:47:12 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:12 --> Input Class Initialized
INFO - 2023-01-07 04:47:12 --> Language Class Initialized
INFO - 2023-01-07 04:47:12 --> Language Class Initialized
INFO - 2023-01-07 04:47:12 --> Config Class Initialized
INFO - 2023-01-07 04:47:12 --> Loader Class Initialized
INFO - 2023-01-07 04:47:12 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:12 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:12 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:12 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:12 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 04:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:47:12 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:12 --> Total execution time: 0.0403
INFO - 2023-01-07 04:47:14 --> Config Class Initialized
INFO - 2023-01-07 04:47:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:14 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:14 --> URI Class Initialized
INFO - 2023-01-07 04:47:14 --> Router Class Initialized
INFO - 2023-01-07 04:47:14 --> Output Class Initialized
INFO - 2023-01-07 04:47:14 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:14 --> Input Class Initialized
INFO - 2023-01-07 04:47:14 --> Language Class Initialized
INFO - 2023-01-07 04:47:14 --> Language Class Initialized
INFO - 2023-01-07 04:47:14 --> Config Class Initialized
INFO - 2023-01-07 04:47:14 --> Loader Class Initialized
INFO - 2023-01-07 04:47:14 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:14 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:47:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:47:14 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:14 --> Total execution time: 0.0434
INFO - 2023-01-07 04:47:14 --> Config Class Initialized
INFO - 2023-01-07 04:47:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:14 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:14 --> URI Class Initialized
INFO - 2023-01-07 04:47:14 --> Router Class Initialized
INFO - 2023-01-07 04:47:14 --> Output Class Initialized
INFO - 2023-01-07 04:47:14 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:14 --> Input Class Initialized
INFO - 2023-01-07 04:47:14 --> Language Class Initialized
INFO - 2023-01-07 04:47:14 --> Language Class Initialized
INFO - 2023-01-07 04:47:14 --> Config Class Initialized
INFO - 2023-01-07 04:47:14 --> Loader Class Initialized
INFO - 2023-01-07 04:47:14 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:14 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:14 --> Controller Class Initialized
INFO - 2023-01-07 04:47:16 --> Config Class Initialized
INFO - 2023-01-07 04:47:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:16 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:16 --> URI Class Initialized
INFO - 2023-01-07 04:47:16 --> Router Class Initialized
INFO - 2023-01-07 04:47:16 --> Output Class Initialized
INFO - 2023-01-07 04:47:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:16 --> Input Class Initialized
INFO - 2023-01-07 04:47:16 --> Language Class Initialized
INFO - 2023-01-07 04:47:16 --> Language Class Initialized
INFO - 2023-01-07 04:47:16 --> Config Class Initialized
INFO - 2023-01-07 04:47:16 --> Loader Class Initialized
INFO - 2023-01-07 04:47:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:16 --> Controller Class Initialized
INFO - 2023-01-07 04:47:16 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:16 --> Total execution time: 0.0439
INFO - 2023-01-07 04:47:19 --> Config Class Initialized
INFO - 2023-01-07 04:47:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:19 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:19 --> URI Class Initialized
INFO - 2023-01-07 04:47:19 --> Router Class Initialized
INFO - 2023-01-07 04:47:19 --> Output Class Initialized
INFO - 2023-01-07 04:47:19 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:19 --> Input Class Initialized
INFO - 2023-01-07 04:47:19 --> Language Class Initialized
INFO - 2023-01-07 04:47:19 --> Language Class Initialized
INFO - 2023-01-07 04:47:19 --> Config Class Initialized
INFO - 2023-01-07 04:47:19 --> Loader Class Initialized
INFO - 2023-01-07 04:47:19 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:19 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:19 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:19 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:19 --> Controller Class Initialized
INFO - 2023-01-07 04:47:19 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:19 --> Total execution time: 0.0433
INFO - 2023-01-07 04:47:21 --> Config Class Initialized
INFO - 2023-01-07 04:47:21 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:21 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:21 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:21 --> URI Class Initialized
INFO - 2023-01-07 04:47:21 --> Router Class Initialized
INFO - 2023-01-07 04:47:21 --> Output Class Initialized
INFO - 2023-01-07 04:47:21 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:21 --> Input Class Initialized
INFO - 2023-01-07 04:47:21 --> Language Class Initialized
INFO - 2023-01-07 04:47:21 --> Language Class Initialized
INFO - 2023-01-07 04:47:21 --> Config Class Initialized
INFO - 2023-01-07 04:47:21 --> Loader Class Initialized
INFO - 2023-01-07 04:47:21 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:21 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:21 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:21 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:21 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:21 --> Controller Class Initialized
INFO - 2023-01-07 04:47:21 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:21 --> Total execution time: 0.0440
INFO - 2023-01-07 04:47:24 --> Config Class Initialized
INFO - 2023-01-07 04:47:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:24 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:24 --> URI Class Initialized
INFO - 2023-01-07 04:47:24 --> Router Class Initialized
INFO - 2023-01-07 04:47:24 --> Output Class Initialized
INFO - 2023-01-07 04:47:24 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:24 --> Input Class Initialized
INFO - 2023-01-07 04:47:24 --> Language Class Initialized
INFO - 2023-01-07 04:47:24 --> Language Class Initialized
INFO - 2023-01-07 04:47:24 --> Config Class Initialized
INFO - 2023-01-07 04:47:24 --> Loader Class Initialized
INFO - 2023-01-07 04:47:24 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:24 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:24 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:24 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:24 --> Controller Class Initialized
INFO - 2023-01-07 04:47:24 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:24 --> Total execution time: 0.0242
INFO - 2023-01-07 04:47:29 --> Config Class Initialized
INFO - 2023-01-07 04:47:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:47:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:47:29 --> Utf8 Class Initialized
INFO - 2023-01-07 04:47:29 --> URI Class Initialized
INFO - 2023-01-07 04:47:29 --> Router Class Initialized
INFO - 2023-01-07 04:47:29 --> Output Class Initialized
INFO - 2023-01-07 04:47:29 --> Security Class Initialized
DEBUG - 2023-01-07 04:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:47:29 --> Input Class Initialized
INFO - 2023-01-07 04:47:29 --> Language Class Initialized
INFO - 2023-01-07 04:47:29 --> Language Class Initialized
INFO - 2023-01-07 04:47:29 --> Config Class Initialized
INFO - 2023-01-07 04:47:29 --> Loader Class Initialized
INFO - 2023-01-07 04:47:29 --> Helper loaded: url_helper
INFO - 2023-01-07 04:47:29 --> Helper loaded: file_helper
INFO - 2023-01-07 04:47:29 --> Helper loaded: form_helper
INFO - 2023-01-07 04:47:29 --> Helper loaded: my_helper
INFO - 2023-01-07 04:47:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:47:29 --> Controller Class Initialized
DEBUG - 2023-01-07 04:47:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:47:29 --> Final output sent to browser
DEBUG - 2023-01-07 04:47:29 --> Total execution time: 0.0399
INFO - 2023-01-07 04:48:11 --> Config Class Initialized
INFO - 2023-01-07 04:48:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:11 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:11 --> URI Class Initialized
DEBUG - 2023-01-07 04:48:11 --> No URI present. Default controller set.
INFO - 2023-01-07 04:48:11 --> Router Class Initialized
INFO - 2023-01-07 04:48:11 --> Output Class Initialized
INFO - 2023-01-07 04:48:11 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:11 --> Input Class Initialized
INFO - 2023-01-07 04:48:11 --> Language Class Initialized
INFO - 2023-01-07 04:48:11 --> Language Class Initialized
INFO - 2023-01-07 04:48:11 --> Config Class Initialized
INFO - 2023-01-07 04:48:11 --> Loader Class Initialized
INFO - 2023-01-07 04:48:11 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:11 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:11 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:11 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:11 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:48:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:48:11 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:11 --> Total execution time: 0.0267
INFO - 2023-01-07 04:48:16 --> Config Class Initialized
INFO - 2023-01-07 04:48:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:16 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:16 --> URI Class Initialized
INFO - 2023-01-07 04:48:16 --> Router Class Initialized
INFO - 2023-01-07 04:48:16 --> Output Class Initialized
INFO - 2023-01-07 04:48:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:16 --> Input Class Initialized
INFO - 2023-01-07 04:48:16 --> Language Class Initialized
INFO - 2023-01-07 04:48:16 --> Language Class Initialized
INFO - 2023-01-07 04:48:16 --> Config Class Initialized
INFO - 2023-01-07 04:48:16 --> Loader Class Initialized
INFO - 2023-01-07 04:48:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:16 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:48:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:48:16 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:16 --> Total execution time: 0.0460
INFO - 2023-01-07 04:48:16 --> Config Class Initialized
INFO - 2023-01-07 04:48:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:16 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:16 --> URI Class Initialized
INFO - 2023-01-07 04:48:16 --> Router Class Initialized
INFO - 2023-01-07 04:48:16 --> Output Class Initialized
INFO - 2023-01-07 04:48:16 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:16 --> Input Class Initialized
INFO - 2023-01-07 04:48:16 --> Language Class Initialized
INFO - 2023-01-07 04:48:16 --> Language Class Initialized
INFO - 2023-01-07 04:48:16 --> Config Class Initialized
INFO - 2023-01-07 04:48:16 --> Loader Class Initialized
INFO - 2023-01-07 04:48:16 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:16 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:16 --> Controller Class Initialized
INFO - 2023-01-07 04:48:17 --> Config Class Initialized
INFO - 2023-01-07 04:48:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:17 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:17 --> URI Class Initialized
INFO - 2023-01-07 04:48:17 --> Router Class Initialized
INFO - 2023-01-07 04:48:17 --> Output Class Initialized
INFO - 2023-01-07 04:48:17 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:17 --> Input Class Initialized
INFO - 2023-01-07 04:48:17 --> Language Class Initialized
INFO - 2023-01-07 04:48:17 --> Language Class Initialized
INFO - 2023-01-07 04:48:17 --> Config Class Initialized
INFO - 2023-01-07 04:48:17 --> Loader Class Initialized
INFO - 2023-01-07 04:48:17 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:17 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:17 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:17 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:17 --> Controller Class Initialized
INFO - 2023-01-07 04:48:17 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:17 --> Total execution time: 0.0436
INFO - 2023-01-07 04:48:31 --> Config Class Initialized
INFO - 2023-01-07 04:48:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:31 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:31 --> URI Class Initialized
INFO - 2023-01-07 04:48:31 --> Router Class Initialized
INFO - 2023-01-07 04:48:31 --> Output Class Initialized
INFO - 2023-01-07 04:48:31 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:31 --> Input Class Initialized
INFO - 2023-01-07 04:48:31 --> Language Class Initialized
INFO - 2023-01-07 04:48:31 --> Language Class Initialized
INFO - 2023-01-07 04:48:31 --> Config Class Initialized
INFO - 2023-01-07 04:48:31 --> Loader Class Initialized
INFO - 2023-01-07 04:48:31 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:31 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:31 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:31 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:31 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 04:48:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:48:31 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:31 --> Total execution time: 0.0699
INFO - 2023-01-07 04:48:33 --> Config Class Initialized
INFO - 2023-01-07 04:48:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:33 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:33 --> URI Class Initialized
INFO - 2023-01-07 04:48:33 --> Router Class Initialized
INFO - 2023-01-07 04:48:33 --> Output Class Initialized
INFO - 2023-01-07 04:48:33 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:33 --> Input Class Initialized
INFO - 2023-01-07 04:48:33 --> Language Class Initialized
INFO - 2023-01-07 04:48:33 --> Language Class Initialized
INFO - 2023-01-07 04:48:33 --> Config Class Initialized
INFO - 2023-01-07 04:48:33 --> Loader Class Initialized
INFO - 2023-01-07 04:48:33 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:33 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:33 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:33 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:33 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/cetak.php
INFO - 2023-01-07 04:48:33 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:33 --> Total execution time: 0.1355
INFO - 2023-01-07 04:48:37 --> Config Class Initialized
INFO - 2023-01-07 04:48:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:37 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:37 --> URI Class Initialized
INFO - 2023-01-07 04:48:37 --> Router Class Initialized
INFO - 2023-01-07 04:48:37 --> Output Class Initialized
INFO - 2023-01-07 04:48:37 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:37 --> Input Class Initialized
INFO - 2023-01-07 04:48:37 --> Language Class Initialized
INFO - 2023-01-07 04:48:37 --> Language Class Initialized
INFO - 2023-01-07 04:48:37 --> Config Class Initialized
INFO - 2023-01-07 04:48:37 --> Loader Class Initialized
INFO - 2023-01-07 04:48:37 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:37 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:37 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:37 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:37 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 04:48:37 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:37 --> Total execution time: 0.0299
INFO - 2023-01-07 04:48:42 --> Config Class Initialized
INFO - 2023-01-07 04:48:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:42 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:42 --> URI Class Initialized
INFO - 2023-01-07 04:48:42 --> Router Class Initialized
INFO - 2023-01-07 04:48:42 --> Output Class Initialized
INFO - 2023-01-07 04:48:42 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:42 --> Input Class Initialized
INFO - 2023-01-07 04:48:42 --> Language Class Initialized
INFO - 2023-01-07 04:48:42 --> Language Class Initialized
INFO - 2023-01-07 04:48:42 --> Config Class Initialized
INFO - 2023-01-07 04:48:42 --> Loader Class Initialized
INFO - 2023-01-07 04:48:42 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:42 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:42 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:42 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:42 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 04:48:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:48:42 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:42 --> Total execution time: 0.0441
INFO - 2023-01-07 04:48:45 --> Config Class Initialized
INFO - 2023-01-07 04:48:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:45 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:45 --> URI Class Initialized
INFO - 2023-01-07 04:48:45 --> Router Class Initialized
INFO - 2023-01-07 04:48:45 --> Output Class Initialized
INFO - 2023-01-07 04:48:45 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:45 --> Input Class Initialized
INFO - 2023-01-07 04:48:45 --> Language Class Initialized
INFO - 2023-01-07 04:48:45 --> Language Class Initialized
INFO - 2023-01-07 04:48:45 --> Config Class Initialized
INFO - 2023-01-07 04:48:45 --> Loader Class Initialized
INFO - 2023-01-07 04:48:45 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:45 --> Controller Class Initialized
DEBUG - 2023-01-07 04:48:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:48:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:48:45 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:45 --> Total execution time: 0.0271
INFO - 2023-01-07 04:48:45 --> Config Class Initialized
INFO - 2023-01-07 04:48:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:45 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:45 --> URI Class Initialized
INFO - 2023-01-07 04:48:45 --> Router Class Initialized
INFO - 2023-01-07 04:48:45 --> Output Class Initialized
INFO - 2023-01-07 04:48:45 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:45 --> Input Class Initialized
INFO - 2023-01-07 04:48:45 --> Language Class Initialized
INFO - 2023-01-07 04:48:45 --> Language Class Initialized
INFO - 2023-01-07 04:48:45 --> Config Class Initialized
INFO - 2023-01-07 04:48:45 --> Loader Class Initialized
INFO - 2023-01-07 04:48:45 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:45 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:45 --> Controller Class Initialized
INFO - 2023-01-07 04:48:51 --> Config Class Initialized
INFO - 2023-01-07 04:48:51 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:48:51 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:48:51 --> Utf8 Class Initialized
INFO - 2023-01-07 04:48:51 --> URI Class Initialized
INFO - 2023-01-07 04:48:51 --> Router Class Initialized
INFO - 2023-01-07 04:48:51 --> Output Class Initialized
INFO - 2023-01-07 04:48:51 --> Security Class Initialized
DEBUG - 2023-01-07 04:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:48:51 --> Input Class Initialized
INFO - 2023-01-07 04:48:51 --> Language Class Initialized
INFO - 2023-01-07 04:48:51 --> Language Class Initialized
INFO - 2023-01-07 04:48:51 --> Config Class Initialized
INFO - 2023-01-07 04:48:51 --> Loader Class Initialized
INFO - 2023-01-07 04:48:51 --> Helper loaded: url_helper
INFO - 2023-01-07 04:48:51 --> Helper loaded: file_helper
INFO - 2023-01-07 04:48:51 --> Helper loaded: form_helper
INFO - 2023-01-07 04:48:51 --> Helper loaded: my_helper
INFO - 2023-01-07 04:48:51 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:48:51 --> Controller Class Initialized
INFO - 2023-01-07 04:48:51 --> Final output sent to browser
DEBUG - 2023-01-07 04:48:51 --> Total execution time: 0.0436
INFO - 2023-01-07 04:53:54 --> Config Class Initialized
INFO - 2023-01-07 04:53:54 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:53:54 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:53:54 --> Utf8 Class Initialized
INFO - 2023-01-07 04:53:54 --> URI Class Initialized
DEBUG - 2023-01-07 04:53:54 --> No URI present. Default controller set.
INFO - 2023-01-07 04:53:54 --> Router Class Initialized
INFO - 2023-01-07 04:53:54 --> Output Class Initialized
INFO - 2023-01-07 04:53:54 --> Security Class Initialized
DEBUG - 2023-01-07 04:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:53:54 --> Input Class Initialized
INFO - 2023-01-07 04:53:54 --> Language Class Initialized
INFO - 2023-01-07 04:53:54 --> Language Class Initialized
INFO - 2023-01-07 04:53:54 --> Config Class Initialized
INFO - 2023-01-07 04:53:54 --> Loader Class Initialized
INFO - 2023-01-07 04:53:54 --> Helper loaded: url_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: file_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: form_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: my_helper
INFO - 2023-01-07 04:53:54 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:53:54 --> Controller Class Initialized
INFO - 2023-01-07 04:53:54 --> Config Class Initialized
INFO - 2023-01-07 04:53:54 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:53:54 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:53:54 --> Utf8 Class Initialized
INFO - 2023-01-07 04:53:54 --> URI Class Initialized
INFO - 2023-01-07 04:53:54 --> Router Class Initialized
INFO - 2023-01-07 04:53:54 --> Output Class Initialized
INFO - 2023-01-07 04:53:54 --> Security Class Initialized
DEBUG - 2023-01-07 04:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:53:54 --> Input Class Initialized
INFO - 2023-01-07 04:53:54 --> Language Class Initialized
INFO - 2023-01-07 04:53:54 --> Language Class Initialized
INFO - 2023-01-07 04:53:54 --> Config Class Initialized
INFO - 2023-01-07 04:53:54 --> Loader Class Initialized
INFO - 2023-01-07 04:53:54 --> Helper loaded: url_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: file_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: form_helper
INFO - 2023-01-07 04:53:54 --> Helper loaded: my_helper
INFO - 2023-01-07 04:53:54 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:53:54 --> Controller Class Initialized
DEBUG - 2023-01-07 04:53:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 04:53:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:53:54 --> Final output sent to browser
DEBUG - 2023-01-07 04:53:54 --> Total execution time: 0.0267
INFO - 2023-01-07 04:53:59 --> Config Class Initialized
INFO - 2023-01-07 04:53:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:53:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:53:59 --> Utf8 Class Initialized
INFO - 2023-01-07 04:53:59 --> URI Class Initialized
INFO - 2023-01-07 04:53:59 --> Router Class Initialized
INFO - 2023-01-07 04:53:59 --> Output Class Initialized
INFO - 2023-01-07 04:53:59 --> Security Class Initialized
DEBUG - 2023-01-07 04:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:53:59 --> Input Class Initialized
INFO - 2023-01-07 04:53:59 --> Language Class Initialized
INFO - 2023-01-07 04:53:59 --> Language Class Initialized
INFO - 2023-01-07 04:53:59 --> Config Class Initialized
INFO - 2023-01-07 04:53:59 --> Loader Class Initialized
INFO - 2023-01-07 04:53:59 --> Helper loaded: url_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: file_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: form_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: my_helper
INFO - 2023-01-07 04:53:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:53:59 --> Controller Class Initialized
INFO - 2023-01-07 04:53:59 --> Helper loaded: cookie_helper
INFO - 2023-01-07 04:53:59 --> Final output sent to browser
DEBUG - 2023-01-07 04:53:59 --> Total execution time: 0.0645
INFO - 2023-01-07 04:53:59 --> Config Class Initialized
INFO - 2023-01-07 04:53:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:53:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:53:59 --> Utf8 Class Initialized
INFO - 2023-01-07 04:53:59 --> URI Class Initialized
INFO - 2023-01-07 04:53:59 --> Router Class Initialized
INFO - 2023-01-07 04:53:59 --> Output Class Initialized
INFO - 2023-01-07 04:53:59 --> Security Class Initialized
DEBUG - 2023-01-07 04:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:53:59 --> Input Class Initialized
INFO - 2023-01-07 04:53:59 --> Language Class Initialized
INFO - 2023-01-07 04:53:59 --> Language Class Initialized
INFO - 2023-01-07 04:53:59 --> Config Class Initialized
INFO - 2023-01-07 04:53:59 --> Loader Class Initialized
INFO - 2023-01-07 04:53:59 --> Helper loaded: url_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: file_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: form_helper
INFO - 2023-01-07 04:53:59 --> Helper loaded: my_helper
INFO - 2023-01-07 04:53:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:53:59 --> Controller Class Initialized
DEBUG - 2023-01-07 04:53:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 04:53:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:53:59 --> Final output sent to browser
DEBUG - 2023-01-07 04:53:59 --> Total execution time: 0.0444
INFO - 2023-01-07 04:54:02 --> Config Class Initialized
INFO - 2023-01-07 04:54:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:02 --> URI Class Initialized
INFO - 2023-01-07 04:54:02 --> Router Class Initialized
INFO - 2023-01-07 04:54:02 --> Output Class Initialized
INFO - 2023-01-07 04:54:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:02 --> Input Class Initialized
INFO - 2023-01-07 04:54:02 --> Language Class Initialized
INFO - 2023-01-07 04:54:02 --> Language Class Initialized
INFO - 2023-01-07 04:54:02 --> Config Class Initialized
INFO - 2023-01-07 04:54:02 --> Loader Class Initialized
INFO - 2023-01-07 04:54:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:02 --> Controller Class Initialized
DEBUG - 2023-01-07 04:54:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 04:54:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 04:54:02 --> Final output sent to browser
DEBUG - 2023-01-07 04:54:02 --> Total execution time: 0.0386
INFO - 2023-01-07 04:54:02 --> Config Class Initialized
INFO - 2023-01-07 04:54:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:02 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:02 --> URI Class Initialized
INFO - 2023-01-07 04:54:02 --> Router Class Initialized
INFO - 2023-01-07 04:54:02 --> Output Class Initialized
INFO - 2023-01-07 04:54:02 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:02 --> Input Class Initialized
INFO - 2023-01-07 04:54:02 --> Language Class Initialized
INFO - 2023-01-07 04:54:02 --> Language Class Initialized
INFO - 2023-01-07 04:54:02 --> Config Class Initialized
INFO - 2023-01-07 04:54:02 --> Loader Class Initialized
INFO - 2023-01-07 04:54:02 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:02 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:02 --> Controller Class Initialized
INFO - 2023-01-07 04:54:04 --> Config Class Initialized
INFO - 2023-01-07 04:54:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:04 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:04 --> URI Class Initialized
INFO - 2023-01-07 04:54:04 --> Router Class Initialized
INFO - 2023-01-07 04:54:04 --> Output Class Initialized
INFO - 2023-01-07 04:54:04 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:04 --> Input Class Initialized
INFO - 2023-01-07 04:54:04 --> Language Class Initialized
INFO - 2023-01-07 04:54:04 --> Language Class Initialized
INFO - 2023-01-07 04:54:04 --> Config Class Initialized
INFO - 2023-01-07 04:54:04 --> Loader Class Initialized
INFO - 2023-01-07 04:54:04 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:04 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:04 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:04 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:04 --> Controller Class Initialized
INFO - 2023-01-07 04:54:04 --> Final output sent to browser
DEBUG - 2023-01-07 04:54:04 --> Total execution time: 0.0437
INFO - 2023-01-07 04:54:17 --> Config Class Initialized
INFO - 2023-01-07 04:54:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:17 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:17 --> URI Class Initialized
INFO - 2023-01-07 04:54:17 --> Router Class Initialized
INFO - 2023-01-07 04:54:17 --> Output Class Initialized
INFO - 2023-01-07 04:54:17 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:17 --> Input Class Initialized
INFO - 2023-01-07 04:54:17 --> Language Class Initialized
INFO - 2023-01-07 04:54:17 --> Language Class Initialized
INFO - 2023-01-07 04:54:17 --> Config Class Initialized
INFO - 2023-01-07 04:54:17 --> Loader Class Initialized
INFO - 2023-01-07 04:54:17 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:17 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:17 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:17 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:17 --> Controller Class Initialized
INFO - 2023-01-07 04:54:17 --> Final output sent to browser
DEBUG - 2023-01-07 04:54:17 --> Total execution time: 0.0245
INFO - 2023-01-07 04:54:18 --> Config Class Initialized
INFO - 2023-01-07 04:54:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:18 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:18 --> URI Class Initialized
INFO - 2023-01-07 04:54:18 --> Router Class Initialized
INFO - 2023-01-07 04:54:18 --> Output Class Initialized
INFO - 2023-01-07 04:54:18 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:18 --> Input Class Initialized
INFO - 2023-01-07 04:54:18 --> Language Class Initialized
INFO - 2023-01-07 04:54:18 --> Language Class Initialized
INFO - 2023-01-07 04:54:18 --> Config Class Initialized
INFO - 2023-01-07 04:54:18 --> Loader Class Initialized
INFO - 2023-01-07 04:54:18 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:18 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:18 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:18 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:18 --> Controller Class Initialized
INFO - 2023-01-07 04:54:18 --> Final output sent to browser
DEBUG - 2023-01-07 04:54:18 --> Total execution time: 0.0235
INFO - 2023-01-07 04:54:20 --> Config Class Initialized
INFO - 2023-01-07 04:54:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:54:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:54:20 --> Utf8 Class Initialized
INFO - 2023-01-07 04:54:20 --> URI Class Initialized
INFO - 2023-01-07 04:54:20 --> Router Class Initialized
INFO - 2023-01-07 04:54:20 --> Output Class Initialized
INFO - 2023-01-07 04:54:20 --> Security Class Initialized
DEBUG - 2023-01-07 04:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:54:20 --> Input Class Initialized
INFO - 2023-01-07 04:54:20 --> Language Class Initialized
INFO - 2023-01-07 04:54:20 --> Language Class Initialized
INFO - 2023-01-07 04:54:20 --> Config Class Initialized
INFO - 2023-01-07 04:54:20 --> Loader Class Initialized
INFO - 2023-01-07 04:54:20 --> Helper loaded: url_helper
INFO - 2023-01-07 04:54:20 --> Helper loaded: file_helper
INFO - 2023-01-07 04:54:20 --> Helper loaded: form_helper
INFO - 2023-01-07 04:54:20 --> Helper loaded: my_helper
INFO - 2023-01-07 04:54:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:54:20 --> Controller Class Initialized
INFO - 2023-01-07 04:54:20 --> Final output sent to browser
DEBUG - 2023-01-07 04:54:20 --> Total execution time: 0.0430
INFO - 2023-01-07 04:57:55 --> Config Class Initialized
INFO - 2023-01-07 04:57:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 04:57:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 04:57:55 --> Utf8 Class Initialized
INFO - 2023-01-07 04:57:55 --> URI Class Initialized
INFO - 2023-01-07 04:57:55 --> Router Class Initialized
INFO - 2023-01-07 04:57:55 --> Output Class Initialized
INFO - 2023-01-07 04:57:55 --> Security Class Initialized
DEBUG - 2023-01-07 04:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 04:57:55 --> Input Class Initialized
INFO - 2023-01-07 04:57:55 --> Language Class Initialized
INFO - 2023-01-07 04:57:55 --> Language Class Initialized
INFO - 2023-01-07 04:57:55 --> Config Class Initialized
INFO - 2023-01-07 04:57:55 --> Loader Class Initialized
INFO - 2023-01-07 04:57:55 --> Helper loaded: url_helper
INFO - 2023-01-07 04:57:55 --> Helper loaded: file_helper
INFO - 2023-01-07 04:57:55 --> Helper loaded: form_helper
INFO - 2023-01-07 04:57:55 --> Helper loaded: my_helper
INFO - 2023-01-07 04:57:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 04:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 04:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 04:57:55 --> Controller Class Initialized
INFO - 2023-01-07 04:57:55 --> Final output sent to browser
DEBUG - 2023-01-07 04:57:55 --> Total execution time: 0.0412
INFO - 2023-01-07 05:00:24 --> Config Class Initialized
INFO - 2023-01-07 05:00:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:00:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:00:24 --> Utf8 Class Initialized
INFO - 2023-01-07 05:00:24 --> URI Class Initialized
INFO - 2023-01-07 05:00:24 --> Router Class Initialized
INFO - 2023-01-07 05:00:24 --> Output Class Initialized
INFO - 2023-01-07 05:00:24 --> Security Class Initialized
DEBUG - 2023-01-07 05:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:00:24 --> Input Class Initialized
INFO - 2023-01-07 05:00:24 --> Language Class Initialized
INFO - 2023-01-07 05:00:24 --> Language Class Initialized
INFO - 2023-01-07 05:00:24 --> Config Class Initialized
INFO - 2023-01-07 05:00:24 --> Loader Class Initialized
INFO - 2023-01-07 05:00:24 --> Helper loaded: url_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: file_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: form_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: my_helper
INFO - 2023-01-07 05:00:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:00:24 --> Controller Class Initialized
DEBUG - 2023-01-07 05:00:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 05:00:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:00:24 --> Final output sent to browser
DEBUG - 2023-01-07 05:00:24 --> Total execution time: 0.0286
INFO - 2023-01-07 05:00:24 --> Config Class Initialized
INFO - 2023-01-07 05:00:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:00:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:00:24 --> Utf8 Class Initialized
INFO - 2023-01-07 05:00:24 --> URI Class Initialized
INFO - 2023-01-07 05:00:24 --> Router Class Initialized
INFO - 2023-01-07 05:00:24 --> Output Class Initialized
INFO - 2023-01-07 05:00:24 --> Security Class Initialized
DEBUG - 2023-01-07 05:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:00:24 --> Input Class Initialized
INFO - 2023-01-07 05:00:24 --> Language Class Initialized
INFO - 2023-01-07 05:00:24 --> Language Class Initialized
INFO - 2023-01-07 05:00:24 --> Config Class Initialized
INFO - 2023-01-07 05:00:24 --> Loader Class Initialized
INFO - 2023-01-07 05:00:24 --> Helper loaded: url_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: file_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: form_helper
INFO - 2023-01-07 05:00:24 --> Helper loaded: my_helper
INFO - 2023-01-07 05:00:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:00:24 --> Controller Class Initialized
INFO - 2023-01-07 05:00:26 --> Config Class Initialized
INFO - 2023-01-07 05:00:26 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:00:26 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:00:26 --> Utf8 Class Initialized
INFO - 2023-01-07 05:00:26 --> URI Class Initialized
INFO - 2023-01-07 05:00:26 --> Router Class Initialized
INFO - 2023-01-07 05:00:26 --> Output Class Initialized
INFO - 2023-01-07 05:00:26 --> Security Class Initialized
DEBUG - 2023-01-07 05:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:00:26 --> Input Class Initialized
INFO - 2023-01-07 05:00:26 --> Language Class Initialized
INFO - 2023-01-07 05:00:26 --> Language Class Initialized
INFO - 2023-01-07 05:00:26 --> Config Class Initialized
INFO - 2023-01-07 05:00:26 --> Loader Class Initialized
INFO - 2023-01-07 05:00:26 --> Helper loaded: url_helper
INFO - 2023-01-07 05:00:26 --> Helper loaded: file_helper
INFO - 2023-01-07 05:00:26 --> Helper loaded: form_helper
INFO - 2023-01-07 05:00:26 --> Helper loaded: my_helper
INFO - 2023-01-07 05:00:26 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:00:26 --> Controller Class Initialized
INFO - 2023-01-07 05:00:26 --> Final output sent to browser
DEBUG - 2023-01-07 05:00:26 --> Total execution time: 0.0248
INFO - 2023-01-07 05:00:39 --> Config Class Initialized
INFO - 2023-01-07 05:00:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:00:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:00:39 --> Utf8 Class Initialized
INFO - 2023-01-07 05:00:39 --> URI Class Initialized
INFO - 2023-01-07 05:00:39 --> Router Class Initialized
INFO - 2023-01-07 05:00:39 --> Output Class Initialized
INFO - 2023-01-07 05:00:39 --> Security Class Initialized
DEBUG - 2023-01-07 05:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:00:39 --> Input Class Initialized
INFO - 2023-01-07 05:00:39 --> Language Class Initialized
INFO - 2023-01-07 05:00:39 --> Language Class Initialized
INFO - 2023-01-07 05:00:39 --> Config Class Initialized
INFO - 2023-01-07 05:00:39 --> Loader Class Initialized
INFO - 2023-01-07 05:00:39 --> Helper loaded: url_helper
INFO - 2023-01-07 05:00:39 --> Helper loaded: file_helper
INFO - 2023-01-07 05:00:39 --> Helper loaded: form_helper
INFO - 2023-01-07 05:00:39 --> Helper loaded: my_helper
INFO - 2023-01-07 05:00:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:00:39 --> Controller Class Initialized
INFO - 2023-01-07 05:00:39 --> Final output sent to browser
DEBUG - 2023-01-07 05:00:39 --> Total execution time: 0.0257
INFO - 2023-01-07 05:00:41 --> Config Class Initialized
INFO - 2023-01-07 05:00:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:00:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:00:41 --> Utf8 Class Initialized
INFO - 2023-01-07 05:00:41 --> URI Class Initialized
INFO - 2023-01-07 05:00:41 --> Router Class Initialized
INFO - 2023-01-07 05:00:41 --> Output Class Initialized
INFO - 2023-01-07 05:00:41 --> Security Class Initialized
DEBUG - 2023-01-07 05:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:00:41 --> Input Class Initialized
INFO - 2023-01-07 05:00:41 --> Language Class Initialized
INFO - 2023-01-07 05:00:41 --> Language Class Initialized
INFO - 2023-01-07 05:00:41 --> Config Class Initialized
INFO - 2023-01-07 05:00:41 --> Loader Class Initialized
INFO - 2023-01-07 05:00:41 --> Helper loaded: url_helper
INFO - 2023-01-07 05:00:41 --> Helper loaded: file_helper
INFO - 2023-01-07 05:00:41 --> Helper loaded: form_helper
INFO - 2023-01-07 05:00:41 --> Helper loaded: my_helper
INFO - 2023-01-07 05:00:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:00:41 --> Controller Class Initialized
INFO - 2023-01-07 05:03:10 --> Config Class Initialized
INFO - 2023-01-07 05:03:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:10 --> URI Class Initialized
INFO - 2023-01-07 05:03:10 --> Router Class Initialized
INFO - 2023-01-07 05:03:10 --> Output Class Initialized
INFO - 2023-01-07 05:03:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:10 --> Input Class Initialized
INFO - 2023-01-07 05:03:10 --> Language Class Initialized
INFO - 2023-01-07 05:03:10 --> Language Class Initialized
INFO - 2023-01-07 05:03:10 --> Config Class Initialized
INFO - 2023-01-07 05:03:10 --> Loader Class Initialized
INFO - 2023-01-07 05:03:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:10 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 05:03:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:10 --> Total execution time: 0.0397
INFO - 2023-01-07 05:03:10 --> Config Class Initialized
INFO - 2023-01-07 05:03:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:10 --> URI Class Initialized
INFO - 2023-01-07 05:03:10 --> Router Class Initialized
INFO - 2023-01-07 05:03:10 --> Output Class Initialized
INFO - 2023-01-07 05:03:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:10 --> Input Class Initialized
INFO - 2023-01-07 05:03:10 --> Language Class Initialized
INFO - 2023-01-07 05:03:10 --> Language Class Initialized
INFO - 2023-01-07 05:03:10 --> Config Class Initialized
INFO - 2023-01-07 05:03:10 --> Loader Class Initialized
INFO - 2023-01-07 05:03:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:10 --> Controller Class Initialized
INFO - 2023-01-07 05:03:11 --> Config Class Initialized
INFO - 2023-01-07 05:03:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:11 --> URI Class Initialized
INFO - 2023-01-07 05:03:11 --> Router Class Initialized
INFO - 2023-01-07 05:03:11 --> Output Class Initialized
INFO - 2023-01-07 05:03:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:11 --> Input Class Initialized
INFO - 2023-01-07 05:03:11 --> Language Class Initialized
INFO - 2023-01-07 05:03:11 --> Language Class Initialized
INFO - 2023-01-07 05:03:11 --> Config Class Initialized
INFO - 2023-01-07 05:03:11 --> Loader Class Initialized
INFO - 2023-01-07 05:03:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:11 --> Controller Class Initialized
INFO - 2023-01-07 05:03:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:11 --> Total execution time: 0.0256
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:14 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:14 --> URI Class Initialized
INFO - 2023-01-07 05:03:14 --> Router Class Initialized
INFO - 2023-01-07 05:03:14 --> Output Class Initialized
INFO - 2023-01-07 05:03:14 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:14 --> Input Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Loader Class Initialized
INFO - 2023-01-07 05:03:14 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:14 --> Controller Class Initialized
INFO - 2023-01-07 05:03:14 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:14 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:14 --> URI Class Initialized
INFO - 2023-01-07 05:03:14 --> Router Class Initialized
INFO - 2023-01-07 05:03:14 --> Output Class Initialized
INFO - 2023-01-07 05:03:14 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:14 --> Input Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Loader Class Initialized
INFO - 2023-01-07 05:03:14 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:14 --> Controller Class Initialized
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:14 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:14 --> URI Class Initialized
INFO - 2023-01-07 05:03:14 --> Router Class Initialized
INFO - 2023-01-07 05:03:14 --> Output Class Initialized
INFO - 2023-01-07 05:03:14 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:14 --> Input Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Language Class Initialized
INFO - 2023-01-07 05:03:14 --> Config Class Initialized
INFO - 2023-01-07 05:03:14 --> Loader Class Initialized
INFO - 2023-01-07 05:03:14 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:14 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:14 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:03:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:14 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:14 --> Total execution time: 0.0441
INFO - 2023-01-07 05:03:26 --> Config Class Initialized
INFO - 2023-01-07 05:03:26 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:26 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:26 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:26 --> URI Class Initialized
INFO - 2023-01-07 05:03:26 --> Router Class Initialized
INFO - 2023-01-07 05:03:26 --> Output Class Initialized
INFO - 2023-01-07 05:03:26 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:26 --> Input Class Initialized
INFO - 2023-01-07 05:03:26 --> Language Class Initialized
INFO - 2023-01-07 05:03:26 --> Language Class Initialized
INFO - 2023-01-07 05:03:26 --> Config Class Initialized
INFO - 2023-01-07 05:03:26 --> Loader Class Initialized
INFO - 2023-01-07 05:03:26 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:26 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:26 --> Controller Class Initialized
INFO - 2023-01-07 05:03:26 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:03:26 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:26 --> Total execution time: 0.0355
INFO - 2023-01-07 05:03:26 --> Config Class Initialized
INFO - 2023-01-07 05:03:26 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:26 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:26 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:26 --> URI Class Initialized
INFO - 2023-01-07 05:03:26 --> Router Class Initialized
INFO - 2023-01-07 05:03:26 --> Output Class Initialized
INFO - 2023-01-07 05:03:26 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:26 --> Input Class Initialized
INFO - 2023-01-07 05:03:26 --> Language Class Initialized
INFO - 2023-01-07 05:03:26 --> Language Class Initialized
INFO - 2023-01-07 05:03:26 --> Config Class Initialized
INFO - 2023-01-07 05:03:26 --> Loader Class Initialized
INFO - 2023-01-07 05:03:26 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:26 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:26 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:26 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 05:03:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:26 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:26 --> Total execution time: 0.0413
INFO - 2023-01-07 05:03:31 --> Config Class Initialized
INFO - 2023-01-07 05:03:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:31 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:31 --> URI Class Initialized
INFO - 2023-01-07 05:03:31 --> Router Class Initialized
INFO - 2023-01-07 05:03:31 --> Output Class Initialized
INFO - 2023-01-07 05:03:31 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:31 --> Input Class Initialized
INFO - 2023-01-07 05:03:31 --> Language Class Initialized
INFO - 2023-01-07 05:03:31 --> Language Class Initialized
INFO - 2023-01-07 05:03:31 --> Config Class Initialized
INFO - 2023-01-07 05:03:31 --> Loader Class Initialized
INFO - 2023-01-07 05:03:31 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:31 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:31 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:31 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:31 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:03:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:31 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:31 --> Total execution time: 0.0270
INFO - 2023-01-07 05:03:35 --> Config Class Initialized
INFO - 2023-01-07 05:03:35 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:35 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:35 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:35 --> URI Class Initialized
INFO - 2023-01-07 05:03:35 --> Router Class Initialized
INFO - 2023-01-07 05:03:35 --> Output Class Initialized
INFO - 2023-01-07 05:03:35 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:35 --> Input Class Initialized
INFO - 2023-01-07 05:03:35 --> Language Class Initialized
INFO - 2023-01-07 05:03:35 --> Language Class Initialized
INFO - 2023-01-07 05:03:35 --> Config Class Initialized
INFO - 2023-01-07 05:03:35 --> Loader Class Initialized
INFO - 2023-01-07 05:03:35 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:35 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:35 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:35 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:35 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:35 --> Controller Class Initialized
INFO - 2023-01-07 05:03:35 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:35 --> Total execution time: 0.0319
INFO - 2023-01-07 05:03:39 --> Config Class Initialized
INFO - 2023-01-07 05:03:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:39 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:39 --> URI Class Initialized
INFO - 2023-01-07 05:03:39 --> Router Class Initialized
INFO - 2023-01-07 05:03:39 --> Output Class Initialized
INFO - 2023-01-07 05:03:39 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:39 --> Input Class Initialized
INFO - 2023-01-07 05:03:39 --> Language Class Initialized
INFO - 2023-01-07 05:03:39 --> Language Class Initialized
INFO - 2023-01-07 05:03:39 --> Config Class Initialized
INFO - 2023-01-07 05:03:39 --> Loader Class Initialized
INFO - 2023-01-07 05:03:39 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:39 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:39 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:39 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:39 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:39 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:39 --> Total execution time: 0.0287
INFO - 2023-01-07 05:03:41 --> Config Class Initialized
INFO - 2023-01-07 05:03:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:41 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:41 --> URI Class Initialized
INFO - 2023-01-07 05:03:41 --> Router Class Initialized
INFO - 2023-01-07 05:03:41 --> Output Class Initialized
INFO - 2023-01-07 05:03:41 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:41 --> Input Class Initialized
INFO - 2023-01-07 05:03:41 --> Language Class Initialized
INFO - 2023-01-07 05:03:41 --> Language Class Initialized
INFO - 2023-01-07 05:03:41 --> Config Class Initialized
INFO - 2023-01-07 05:03:41 --> Loader Class Initialized
INFO - 2023-01-07 05:03:41 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:41 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:41 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:41 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:41 --> Controller Class Initialized
ERROR - 2023-01-07 05:03:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 05:03:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 05:03:41 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 05:03:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:03:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:41 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:41 --> Total execution time: 0.0576
INFO - 2023-01-07 05:03:52 --> Config Class Initialized
INFO - 2023-01-07 05:03:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:52 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:52 --> URI Class Initialized
INFO - 2023-01-07 05:03:52 --> Router Class Initialized
INFO - 2023-01-07 05:03:52 --> Output Class Initialized
INFO - 2023-01-07 05:03:52 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:52 --> Input Class Initialized
INFO - 2023-01-07 05:03:52 --> Language Class Initialized
INFO - 2023-01-07 05:03:52 --> Language Class Initialized
INFO - 2023-01-07 05:03:52 --> Config Class Initialized
INFO - 2023-01-07 05:03:52 --> Loader Class Initialized
INFO - 2023-01-07 05:03:52 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:52 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:52 --> Controller Class Initialized
INFO - 2023-01-07 05:03:52 --> Config Class Initialized
INFO - 2023-01-07 05:03:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:03:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:03:52 --> Utf8 Class Initialized
INFO - 2023-01-07 05:03:52 --> URI Class Initialized
INFO - 2023-01-07 05:03:52 --> Router Class Initialized
INFO - 2023-01-07 05:03:52 --> Output Class Initialized
INFO - 2023-01-07 05:03:52 --> Security Class Initialized
DEBUG - 2023-01-07 05:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:03:52 --> Input Class Initialized
INFO - 2023-01-07 05:03:52 --> Language Class Initialized
INFO - 2023-01-07 05:03:52 --> Language Class Initialized
INFO - 2023-01-07 05:03:52 --> Config Class Initialized
INFO - 2023-01-07 05:03:52 --> Loader Class Initialized
INFO - 2023-01-07 05:03:52 --> Helper loaded: url_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: file_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: form_helper
INFO - 2023-01-07 05:03:52 --> Helper loaded: my_helper
INFO - 2023-01-07 05:03:52 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:03:52 --> Controller Class Initialized
DEBUG - 2023-01-07 05:03:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:03:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:03:52 --> Final output sent to browser
DEBUG - 2023-01-07 05:03:52 --> Total execution time: 0.0558
INFO - 2023-01-07 05:05:29 --> Config Class Initialized
INFO - 2023-01-07 05:05:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:05:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:05:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:05:29 --> URI Class Initialized
INFO - 2023-01-07 05:05:29 --> Router Class Initialized
INFO - 2023-01-07 05:05:29 --> Output Class Initialized
INFO - 2023-01-07 05:05:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:05:29 --> Input Class Initialized
INFO - 2023-01-07 05:05:29 --> Language Class Initialized
INFO - 2023-01-07 05:05:29 --> Language Class Initialized
INFO - 2023-01-07 05:05:29 --> Config Class Initialized
INFO - 2023-01-07 05:05:29 --> Loader Class Initialized
INFO - 2023-01-07 05:05:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:05:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:05:29 --> Controller Class Initialized
DEBUG - 2023-01-07 05:05:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/tahun/views/list.php
DEBUG - 2023-01-07 05:05:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:05:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:05:29 --> Total execution time: 0.0460
INFO - 2023-01-07 05:05:29 --> Config Class Initialized
INFO - 2023-01-07 05:05:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:05:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:05:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:05:29 --> URI Class Initialized
INFO - 2023-01-07 05:05:29 --> Router Class Initialized
INFO - 2023-01-07 05:05:29 --> Output Class Initialized
INFO - 2023-01-07 05:05:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:05:29 --> Input Class Initialized
INFO - 2023-01-07 05:05:29 --> Language Class Initialized
INFO - 2023-01-07 05:05:29 --> Language Class Initialized
INFO - 2023-01-07 05:05:29 --> Config Class Initialized
INFO - 2023-01-07 05:05:29 --> Loader Class Initialized
INFO - 2023-01-07 05:05:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:05:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:05:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:05:29 --> Controller Class Initialized
INFO - 2023-01-07 05:05:33 --> Config Class Initialized
INFO - 2023-01-07 05:05:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:05:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:05:33 --> Utf8 Class Initialized
INFO - 2023-01-07 05:05:33 --> URI Class Initialized
INFO - 2023-01-07 05:05:33 --> Router Class Initialized
INFO - 2023-01-07 05:05:33 --> Output Class Initialized
INFO - 2023-01-07 05:05:33 --> Security Class Initialized
DEBUG - 2023-01-07 05:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:05:33 --> Input Class Initialized
INFO - 2023-01-07 05:05:33 --> Language Class Initialized
INFO - 2023-01-07 05:05:33 --> Language Class Initialized
INFO - 2023-01-07 05:05:33 --> Config Class Initialized
INFO - 2023-01-07 05:05:33 --> Loader Class Initialized
INFO - 2023-01-07 05:05:33 --> Helper loaded: url_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: file_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: form_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: my_helper
INFO - 2023-01-07 05:05:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:05:33 --> Controller Class Initialized
INFO - 2023-01-07 05:05:33 --> Final output sent to browser
DEBUG - 2023-01-07 05:05:33 --> Total execution time: 0.0262
INFO - 2023-01-07 05:05:33 --> Config Class Initialized
INFO - 2023-01-07 05:05:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:05:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:05:33 --> Utf8 Class Initialized
INFO - 2023-01-07 05:05:33 --> URI Class Initialized
INFO - 2023-01-07 05:05:33 --> Router Class Initialized
INFO - 2023-01-07 05:05:33 --> Output Class Initialized
INFO - 2023-01-07 05:05:33 --> Security Class Initialized
DEBUG - 2023-01-07 05:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:05:33 --> Input Class Initialized
INFO - 2023-01-07 05:05:33 --> Language Class Initialized
INFO - 2023-01-07 05:05:33 --> Language Class Initialized
INFO - 2023-01-07 05:05:33 --> Config Class Initialized
INFO - 2023-01-07 05:05:33 --> Loader Class Initialized
INFO - 2023-01-07 05:05:33 --> Helper loaded: url_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: file_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: form_helper
INFO - 2023-01-07 05:05:33 --> Helper loaded: my_helper
INFO - 2023-01-07 05:05:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:05:33 --> Controller Class Initialized
INFO - 2023-01-07 05:05:42 --> Config Class Initialized
INFO - 2023-01-07 05:05:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:05:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:05:42 --> Utf8 Class Initialized
INFO - 2023-01-07 05:05:42 --> URI Class Initialized
INFO - 2023-01-07 05:05:42 --> Router Class Initialized
INFO - 2023-01-07 05:05:42 --> Output Class Initialized
INFO - 2023-01-07 05:05:42 --> Security Class Initialized
DEBUG - 2023-01-07 05:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:05:42 --> Input Class Initialized
INFO - 2023-01-07 05:05:42 --> Language Class Initialized
INFO - 2023-01-07 05:05:42 --> Language Class Initialized
INFO - 2023-01-07 05:05:42 --> Config Class Initialized
INFO - 2023-01-07 05:05:42 --> Loader Class Initialized
INFO - 2023-01-07 05:05:42 --> Helper loaded: url_helper
INFO - 2023-01-07 05:05:42 --> Helper loaded: file_helper
INFO - 2023-01-07 05:05:42 --> Helper loaded: form_helper
INFO - 2023-01-07 05:05:42 --> Helper loaded: my_helper
INFO - 2023-01-07 05:05:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:05:42 --> Controller Class Initialized
DEBUG - 2023-01-07 05:05:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:05:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:05:42 --> Final output sent to browser
DEBUG - 2023-01-07 05:05:42 --> Total execution time: 0.0281
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:00 --> URI Class Initialized
INFO - 2023-01-07 05:07:00 --> Router Class Initialized
INFO - 2023-01-07 05:07:00 --> Output Class Initialized
INFO - 2023-01-07 05:07:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:00 --> Input Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Loader Class Initialized
INFO - 2023-01-07 05:07:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:00 --> Controller Class Initialized
INFO - 2023-01-07 05:07:00 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:00 --> URI Class Initialized
INFO - 2023-01-07 05:07:00 --> Router Class Initialized
INFO - 2023-01-07 05:07:00 --> Output Class Initialized
INFO - 2023-01-07 05:07:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:00 --> Input Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Loader Class Initialized
INFO - 2023-01-07 05:07:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:00 --> Controller Class Initialized
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:00 --> URI Class Initialized
INFO - 2023-01-07 05:07:00 --> Router Class Initialized
INFO - 2023-01-07 05:07:00 --> Output Class Initialized
INFO - 2023-01-07 05:07:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:00 --> Input Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Language Class Initialized
INFO - 2023-01-07 05:07:00 --> Config Class Initialized
INFO - 2023-01-07 05:07:00 --> Loader Class Initialized
INFO - 2023-01-07 05:07:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:00 --> Controller Class Initialized
DEBUG - 2023-01-07 05:07:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:07:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:07:00 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:00 --> Total execution time: 0.0414
INFO - 2023-01-07 05:07:08 --> Config Class Initialized
INFO - 2023-01-07 05:07:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:08 --> URI Class Initialized
INFO - 2023-01-07 05:07:08 --> Router Class Initialized
INFO - 2023-01-07 05:07:08 --> Output Class Initialized
INFO - 2023-01-07 05:07:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:08 --> Input Class Initialized
INFO - 2023-01-07 05:07:08 --> Language Class Initialized
INFO - 2023-01-07 05:07:08 --> Language Class Initialized
INFO - 2023-01-07 05:07:08 --> Config Class Initialized
INFO - 2023-01-07 05:07:08 --> Loader Class Initialized
INFO - 2023-01-07 05:07:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:08 --> Controller Class Initialized
INFO - 2023-01-07 05:07:08 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:07:08 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:08 --> Total execution time: 0.0387
INFO - 2023-01-07 05:07:08 --> Config Class Initialized
INFO - 2023-01-07 05:07:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:08 --> URI Class Initialized
INFO - 2023-01-07 05:07:08 --> Router Class Initialized
INFO - 2023-01-07 05:07:08 --> Output Class Initialized
INFO - 2023-01-07 05:07:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:08 --> Input Class Initialized
INFO - 2023-01-07 05:07:08 --> Language Class Initialized
INFO - 2023-01-07 05:07:08 --> Language Class Initialized
INFO - 2023-01-07 05:07:08 --> Config Class Initialized
INFO - 2023-01-07 05:07:08 --> Loader Class Initialized
INFO - 2023-01-07 05:07:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:08 --> Controller Class Initialized
DEBUG - 2023-01-07 05:07:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 05:07:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:07:08 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:08 --> Total execution time: 0.0387
INFO - 2023-01-07 05:07:11 --> Config Class Initialized
INFO - 2023-01-07 05:07:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:11 --> URI Class Initialized
INFO - 2023-01-07 05:07:11 --> Router Class Initialized
INFO - 2023-01-07 05:07:11 --> Output Class Initialized
INFO - 2023-01-07 05:07:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:11 --> Input Class Initialized
INFO - 2023-01-07 05:07:11 --> Language Class Initialized
INFO - 2023-01-07 05:07:11 --> Language Class Initialized
INFO - 2023-01-07 05:07:11 --> Config Class Initialized
INFO - 2023-01-07 05:07:11 --> Loader Class Initialized
INFO - 2023-01-07 05:07:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:07:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 05:07:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:07:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:11 --> Total execution time: 0.0257
INFO - 2023-01-07 05:07:11 --> Config Class Initialized
INFO - 2023-01-07 05:07:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:11 --> URI Class Initialized
INFO - 2023-01-07 05:07:11 --> Router Class Initialized
INFO - 2023-01-07 05:07:11 --> Output Class Initialized
INFO - 2023-01-07 05:07:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:11 --> Input Class Initialized
INFO - 2023-01-07 05:07:11 --> Language Class Initialized
INFO - 2023-01-07 05:07:11 --> Language Class Initialized
INFO - 2023-01-07 05:07:11 --> Config Class Initialized
INFO - 2023-01-07 05:07:11 --> Loader Class Initialized
INFO - 2023-01-07 05:07:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:11 --> Controller Class Initialized
INFO - 2023-01-07 05:07:13 --> Config Class Initialized
INFO - 2023-01-07 05:07:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:13 --> URI Class Initialized
INFO - 2023-01-07 05:07:13 --> Router Class Initialized
INFO - 2023-01-07 05:07:13 --> Output Class Initialized
INFO - 2023-01-07 05:07:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:13 --> Input Class Initialized
INFO - 2023-01-07 05:07:13 --> Language Class Initialized
INFO - 2023-01-07 05:07:13 --> Language Class Initialized
INFO - 2023-01-07 05:07:13 --> Config Class Initialized
INFO - 2023-01-07 05:07:13 --> Loader Class Initialized
INFO - 2023-01-07 05:07:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:13 --> Controller Class Initialized
INFO - 2023-01-07 05:07:13 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:13 --> Total execution time: 0.0429
INFO - 2023-01-07 05:07:16 --> Config Class Initialized
INFO - 2023-01-07 05:07:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:16 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:16 --> URI Class Initialized
INFO - 2023-01-07 05:07:16 --> Router Class Initialized
INFO - 2023-01-07 05:07:16 --> Output Class Initialized
INFO - 2023-01-07 05:07:16 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:16 --> Input Class Initialized
INFO - 2023-01-07 05:07:16 --> Language Class Initialized
INFO - 2023-01-07 05:07:16 --> Language Class Initialized
INFO - 2023-01-07 05:07:16 --> Config Class Initialized
INFO - 2023-01-07 05:07:16 --> Loader Class Initialized
INFO - 2023-01-07 05:07:16 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:16 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:16 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:16 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:16 --> Controller Class Initialized
INFO - 2023-01-07 05:07:16 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:16 --> Total execution time: 0.0404
INFO - 2023-01-07 05:07:19 --> Config Class Initialized
INFO - 2023-01-07 05:07:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:19 --> URI Class Initialized
INFO - 2023-01-07 05:07:19 --> Router Class Initialized
INFO - 2023-01-07 05:07:19 --> Output Class Initialized
INFO - 2023-01-07 05:07:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:19 --> Input Class Initialized
INFO - 2023-01-07 05:07:19 --> Language Class Initialized
INFO - 2023-01-07 05:07:19 --> Language Class Initialized
INFO - 2023-01-07 05:07:19 --> Config Class Initialized
INFO - 2023-01-07 05:07:19 --> Loader Class Initialized
INFO - 2023-01-07 05:07:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:19 --> Controller Class Initialized
DEBUG - 2023-01-07 05:07:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 05:07:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:07:19 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:19 --> Total execution time: 0.0403
INFO - 2023-01-07 05:07:19 --> Config Class Initialized
INFO - 2023-01-07 05:07:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:19 --> URI Class Initialized
INFO - 2023-01-07 05:07:19 --> Router Class Initialized
INFO - 2023-01-07 05:07:19 --> Output Class Initialized
INFO - 2023-01-07 05:07:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:19 --> Input Class Initialized
INFO - 2023-01-07 05:07:19 --> Language Class Initialized
INFO - 2023-01-07 05:07:19 --> Language Class Initialized
INFO - 2023-01-07 05:07:19 --> Config Class Initialized
INFO - 2023-01-07 05:07:19 --> Loader Class Initialized
INFO - 2023-01-07 05:07:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:19 --> Controller Class Initialized
INFO - 2023-01-07 05:07:22 --> Config Class Initialized
INFO - 2023-01-07 05:07:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:22 --> URI Class Initialized
INFO - 2023-01-07 05:07:22 --> Router Class Initialized
INFO - 2023-01-07 05:07:22 --> Output Class Initialized
INFO - 2023-01-07 05:07:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:22 --> Input Class Initialized
INFO - 2023-01-07 05:07:22 --> Language Class Initialized
INFO - 2023-01-07 05:07:22 --> Language Class Initialized
INFO - 2023-01-07 05:07:22 --> Config Class Initialized
INFO - 2023-01-07 05:07:22 --> Loader Class Initialized
INFO - 2023-01-07 05:07:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:22 --> Controller Class Initialized
INFO - 2023-01-07 05:07:22 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:22 --> Total execution time: 0.0429
INFO - 2023-01-07 05:07:35 --> Config Class Initialized
INFO - 2023-01-07 05:07:35 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:35 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:35 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:35 --> URI Class Initialized
INFO - 2023-01-07 05:07:35 --> Router Class Initialized
INFO - 2023-01-07 05:07:35 --> Output Class Initialized
INFO - 2023-01-07 05:07:35 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:35 --> Input Class Initialized
INFO - 2023-01-07 05:07:35 --> Language Class Initialized
INFO - 2023-01-07 05:07:35 --> Language Class Initialized
INFO - 2023-01-07 05:07:35 --> Config Class Initialized
INFO - 2023-01-07 05:07:35 --> Loader Class Initialized
INFO - 2023-01-07 05:07:35 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:35 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:35 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:35 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:35 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:35 --> Controller Class Initialized
INFO - 2023-01-07 05:07:35 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:35 --> Total execution time: 0.0535
INFO - 2023-01-07 05:07:40 --> Config Class Initialized
INFO - 2023-01-07 05:07:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:40 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:40 --> URI Class Initialized
INFO - 2023-01-07 05:07:40 --> Router Class Initialized
INFO - 2023-01-07 05:07:40 --> Output Class Initialized
INFO - 2023-01-07 05:07:40 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:40 --> Input Class Initialized
INFO - 2023-01-07 05:07:40 --> Language Class Initialized
INFO - 2023-01-07 05:07:40 --> Language Class Initialized
INFO - 2023-01-07 05:07:40 --> Config Class Initialized
INFO - 2023-01-07 05:07:40 --> Loader Class Initialized
INFO - 2023-01-07 05:07:40 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:40 --> Controller Class Initialized
INFO - 2023-01-07 05:07:40 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:40 --> Total execution time: 0.0272
INFO - 2023-01-07 05:07:40 --> Config Class Initialized
INFO - 2023-01-07 05:07:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:40 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:40 --> URI Class Initialized
INFO - 2023-01-07 05:07:40 --> Router Class Initialized
INFO - 2023-01-07 05:07:40 --> Output Class Initialized
INFO - 2023-01-07 05:07:40 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:40 --> Input Class Initialized
INFO - 2023-01-07 05:07:40 --> Language Class Initialized
INFO - 2023-01-07 05:07:40 --> Language Class Initialized
INFO - 2023-01-07 05:07:40 --> Config Class Initialized
INFO - 2023-01-07 05:07:40 --> Loader Class Initialized
INFO - 2023-01-07 05:07:40 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:40 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:40 --> Controller Class Initialized
INFO - 2023-01-07 05:07:43 --> Config Class Initialized
INFO - 2023-01-07 05:07:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:07:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:07:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:07:43 --> URI Class Initialized
INFO - 2023-01-07 05:07:43 --> Router Class Initialized
INFO - 2023-01-07 05:07:43 --> Output Class Initialized
INFO - 2023-01-07 05:07:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:07:43 --> Input Class Initialized
INFO - 2023-01-07 05:07:43 --> Language Class Initialized
INFO - 2023-01-07 05:07:43 --> Language Class Initialized
INFO - 2023-01-07 05:07:43 --> Config Class Initialized
INFO - 2023-01-07 05:07:43 --> Loader Class Initialized
INFO - 2023-01-07 05:07:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:07:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:07:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:07:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:07:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:07:43 --> Controller Class Initialized
INFO - 2023-01-07 05:07:43 --> Final output sent to browser
DEBUG - 2023-01-07 05:07:43 --> Total execution time: 0.0442
INFO - 2023-01-07 05:08:00 --> Config Class Initialized
INFO - 2023-01-07 05:08:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:00 --> URI Class Initialized
INFO - 2023-01-07 05:08:00 --> Router Class Initialized
INFO - 2023-01-07 05:08:00 --> Output Class Initialized
INFO - 2023-01-07 05:08:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:00 --> Input Class Initialized
INFO - 2023-01-07 05:08:00 --> Language Class Initialized
INFO - 2023-01-07 05:08:00 --> Language Class Initialized
INFO - 2023-01-07 05:08:00 --> Config Class Initialized
INFO - 2023-01-07 05:08:00 --> Loader Class Initialized
INFO - 2023-01-07 05:08:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:00 --> Controller Class Initialized
INFO - 2023-01-07 05:08:00 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:00 --> Total execution time: 0.0439
INFO - 2023-01-07 05:08:03 --> Config Class Initialized
INFO - 2023-01-07 05:08:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:03 --> URI Class Initialized
INFO - 2023-01-07 05:08:03 --> Router Class Initialized
INFO - 2023-01-07 05:08:03 --> Output Class Initialized
INFO - 2023-01-07 05:08:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:03 --> Input Class Initialized
INFO - 2023-01-07 05:08:03 --> Language Class Initialized
INFO - 2023-01-07 05:08:03 --> Language Class Initialized
INFO - 2023-01-07 05:08:03 --> Config Class Initialized
INFO - 2023-01-07 05:08:03 --> Loader Class Initialized
INFO - 2023-01-07 05:08:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:03 --> Controller Class Initialized
INFO - 2023-01-07 05:08:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:03 --> Total execution time: 0.0425
INFO - 2023-01-07 05:08:06 --> Config Class Initialized
INFO - 2023-01-07 05:08:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:06 --> URI Class Initialized
INFO - 2023-01-07 05:08:06 --> Router Class Initialized
INFO - 2023-01-07 05:08:06 --> Output Class Initialized
INFO - 2023-01-07 05:08:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:06 --> Input Class Initialized
INFO - 2023-01-07 05:08:06 --> Language Class Initialized
INFO - 2023-01-07 05:08:06 --> Language Class Initialized
INFO - 2023-01-07 05:08:06 --> Config Class Initialized
INFO - 2023-01-07 05:08:06 --> Loader Class Initialized
INFO - 2023-01-07 05:08:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:06 --> Controller Class Initialized
INFO - 2023-01-07 05:08:06 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:06 --> Total execution time: 0.0287
INFO - 2023-01-07 05:08:06 --> Config Class Initialized
INFO - 2023-01-07 05:08:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:06 --> URI Class Initialized
INFO - 2023-01-07 05:08:06 --> Router Class Initialized
INFO - 2023-01-07 05:08:06 --> Output Class Initialized
INFO - 2023-01-07 05:08:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:06 --> Input Class Initialized
INFO - 2023-01-07 05:08:06 --> Language Class Initialized
INFO - 2023-01-07 05:08:06 --> Language Class Initialized
INFO - 2023-01-07 05:08:06 --> Config Class Initialized
INFO - 2023-01-07 05:08:06 --> Loader Class Initialized
INFO - 2023-01-07 05:08:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:06 --> Controller Class Initialized
INFO - 2023-01-07 05:08:08 --> Config Class Initialized
INFO - 2023-01-07 05:08:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:08 --> URI Class Initialized
INFO - 2023-01-07 05:08:08 --> Router Class Initialized
INFO - 2023-01-07 05:08:08 --> Output Class Initialized
INFO - 2023-01-07 05:08:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:08 --> Input Class Initialized
INFO - 2023-01-07 05:08:08 --> Language Class Initialized
INFO - 2023-01-07 05:08:08 --> Language Class Initialized
INFO - 2023-01-07 05:08:08 --> Config Class Initialized
INFO - 2023-01-07 05:08:08 --> Loader Class Initialized
INFO - 2023-01-07 05:08:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:08 --> Controller Class Initialized
INFO - 2023-01-07 05:08:08 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:08 --> Total execution time: 0.0412
INFO - 2023-01-07 05:08:10 --> Config Class Initialized
INFO - 2023-01-07 05:08:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:10 --> URI Class Initialized
INFO - 2023-01-07 05:08:10 --> Router Class Initialized
INFO - 2023-01-07 05:08:10 --> Output Class Initialized
INFO - 2023-01-07 05:08:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:10 --> Input Class Initialized
INFO - 2023-01-07 05:08:10 --> Language Class Initialized
INFO - 2023-01-07 05:08:10 --> Language Class Initialized
INFO - 2023-01-07 05:08:10 --> Config Class Initialized
INFO - 2023-01-07 05:08:10 --> Loader Class Initialized
INFO - 2023-01-07 05:08:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:10 --> Controller Class Initialized
INFO - 2023-01-07 05:08:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:10 --> Total execution time: 0.0287
INFO - 2023-01-07 05:08:11 --> Config Class Initialized
INFO - 2023-01-07 05:08:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:11 --> URI Class Initialized
INFO - 2023-01-07 05:08:11 --> Router Class Initialized
INFO - 2023-01-07 05:08:11 --> Output Class Initialized
INFO - 2023-01-07 05:08:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:11 --> Input Class Initialized
INFO - 2023-01-07 05:08:11 --> Language Class Initialized
INFO - 2023-01-07 05:08:11 --> Language Class Initialized
INFO - 2023-01-07 05:08:11 --> Config Class Initialized
INFO - 2023-01-07 05:08:11 --> Loader Class Initialized
INFO - 2023-01-07 05:08:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:11 --> Controller Class Initialized
INFO - 2023-01-07 05:08:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:11 --> Total execution time: 0.0408
INFO - 2023-01-07 05:08:11 --> Config Class Initialized
INFO - 2023-01-07 05:08:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:11 --> URI Class Initialized
INFO - 2023-01-07 05:08:11 --> Router Class Initialized
INFO - 2023-01-07 05:08:11 --> Output Class Initialized
INFO - 2023-01-07 05:08:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:11 --> Input Class Initialized
INFO - 2023-01-07 05:08:11 --> Language Class Initialized
INFO - 2023-01-07 05:08:11 --> Language Class Initialized
INFO - 2023-01-07 05:08:11 --> Config Class Initialized
INFO - 2023-01-07 05:08:11 --> Loader Class Initialized
INFO - 2023-01-07 05:08:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:11 --> Controller Class Initialized
INFO - 2023-01-07 05:08:13 --> Config Class Initialized
INFO - 2023-01-07 05:08:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:13 --> URI Class Initialized
INFO - 2023-01-07 05:08:13 --> Router Class Initialized
INFO - 2023-01-07 05:08:13 --> Output Class Initialized
INFO - 2023-01-07 05:08:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:13 --> Input Class Initialized
INFO - 2023-01-07 05:08:13 --> Language Class Initialized
INFO - 2023-01-07 05:08:13 --> Language Class Initialized
INFO - 2023-01-07 05:08:13 --> Config Class Initialized
INFO - 2023-01-07 05:08:13 --> Loader Class Initialized
INFO - 2023-01-07 05:08:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:13 --> Controller Class Initialized
INFO - 2023-01-07 05:08:13 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:13 --> Total execution time: 0.0268
INFO - 2023-01-07 05:08:15 --> Config Class Initialized
INFO - 2023-01-07 05:08:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:15 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:15 --> URI Class Initialized
INFO - 2023-01-07 05:08:15 --> Router Class Initialized
INFO - 2023-01-07 05:08:15 --> Output Class Initialized
INFO - 2023-01-07 05:08:15 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:15 --> Input Class Initialized
INFO - 2023-01-07 05:08:15 --> Language Class Initialized
INFO - 2023-01-07 05:08:15 --> Language Class Initialized
INFO - 2023-01-07 05:08:15 --> Config Class Initialized
INFO - 2023-01-07 05:08:15 --> Loader Class Initialized
INFO - 2023-01-07 05:08:15 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:15 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:15 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:15 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:15 --> Controller Class Initialized
INFO - 2023-01-07 05:08:15 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:15 --> Total execution time: 0.0242
INFO - 2023-01-07 05:08:16 --> Config Class Initialized
INFO - 2023-01-07 05:08:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:16 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:16 --> URI Class Initialized
INFO - 2023-01-07 05:08:16 --> Router Class Initialized
INFO - 2023-01-07 05:08:16 --> Output Class Initialized
INFO - 2023-01-07 05:08:16 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:16 --> Input Class Initialized
INFO - 2023-01-07 05:08:16 --> Language Class Initialized
INFO - 2023-01-07 05:08:16 --> Language Class Initialized
INFO - 2023-01-07 05:08:16 --> Config Class Initialized
INFO - 2023-01-07 05:08:16 --> Loader Class Initialized
INFO - 2023-01-07 05:08:16 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:16 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:16 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:16 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:16 --> Controller Class Initialized
INFO - 2023-01-07 05:08:16 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:16 --> Total execution time: 0.0421
INFO - 2023-01-07 05:08:29 --> Config Class Initialized
INFO - 2023-01-07 05:08:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:29 --> URI Class Initialized
INFO - 2023-01-07 05:08:29 --> Router Class Initialized
INFO - 2023-01-07 05:08:29 --> Output Class Initialized
INFO - 2023-01-07 05:08:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:29 --> Input Class Initialized
INFO - 2023-01-07 05:08:29 --> Language Class Initialized
INFO - 2023-01-07 05:08:29 --> Language Class Initialized
INFO - 2023-01-07 05:08:29 --> Config Class Initialized
INFO - 2023-01-07 05:08:29 --> Loader Class Initialized
INFO - 2023-01-07 05:08:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:29 --> Controller Class Initialized
INFO - 2023-01-07 05:08:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:29 --> Total execution time: 0.0278
INFO - 2023-01-07 05:08:42 --> Config Class Initialized
INFO - 2023-01-07 05:08:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:42 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:42 --> URI Class Initialized
INFO - 2023-01-07 05:08:42 --> Router Class Initialized
INFO - 2023-01-07 05:08:42 --> Output Class Initialized
INFO - 2023-01-07 05:08:42 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:42 --> Input Class Initialized
INFO - 2023-01-07 05:08:42 --> Language Class Initialized
INFO - 2023-01-07 05:08:42 --> Language Class Initialized
INFO - 2023-01-07 05:08:42 --> Config Class Initialized
INFO - 2023-01-07 05:08:42 --> Loader Class Initialized
INFO - 2023-01-07 05:08:42 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:42 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:42 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:42 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:42 --> Controller Class Initialized
INFO - 2023-01-07 05:08:42 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:42 --> Total execution time: 0.0243
INFO - 2023-01-07 05:08:47 --> Config Class Initialized
INFO - 2023-01-07 05:08:47 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:47 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:47 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:47 --> URI Class Initialized
INFO - 2023-01-07 05:08:47 --> Router Class Initialized
INFO - 2023-01-07 05:08:47 --> Output Class Initialized
INFO - 2023-01-07 05:08:47 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:47 --> Input Class Initialized
INFO - 2023-01-07 05:08:47 --> Language Class Initialized
INFO - 2023-01-07 05:08:47 --> Language Class Initialized
INFO - 2023-01-07 05:08:47 --> Config Class Initialized
INFO - 2023-01-07 05:08:47 --> Loader Class Initialized
INFO - 2023-01-07 05:08:47 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:47 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:47 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:47 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:47 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:47 --> Controller Class Initialized
INFO - 2023-01-07 05:08:47 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:47 --> Total execution time: 0.0263
INFO - 2023-01-07 05:08:56 --> Config Class Initialized
INFO - 2023-01-07 05:08:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:56 --> URI Class Initialized
INFO - 2023-01-07 05:08:56 --> Router Class Initialized
INFO - 2023-01-07 05:08:56 --> Output Class Initialized
INFO - 2023-01-07 05:08:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:56 --> Input Class Initialized
INFO - 2023-01-07 05:08:56 --> Language Class Initialized
INFO - 2023-01-07 05:08:56 --> Language Class Initialized
INFO - 2023-01-07 05:08:56 --> Config Class Initialized
INFO - 2023-01-07 05:08:56 --> Loader Class Initialized
INFO - 2023-01-07 05:08:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:56 --> Controller Class Initialized
INFO - 2023-01-07 05:08:56 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:56 --> Total execution time: 0.0284
INFO - 2023-01-07 05:08:59 --> Config Class Initialized
INFO - 2023-01-07 05:08:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:59 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:59 --> URI Class Initialized
INFO - 2023-01-07 05:08:59 --> Router Class Initialized
INFO - 2023-01-07 05:08:59 --> Output Class Initialized
INFO - 2023-01-07 05:08:59 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:59 --> Input Class Initialized
INFO - 2023-01-07 05:08:59 --> Language Class Initialized
INFO - 2023-01-07 05:08:59 --> Language Class Initialized
INFO - 2023-01-07 05:08:59 --> Config Class Initialized
INFO - 2023-01-07 05:08:59 --> Loader Class Initialized
INFO - 2023-01-07 05:08:59 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:59 --> Controller Class Initialized
INFO - 2023-01-07 05:08:59 --> Final output sent to browser
DEBUG - 2023-01-07 05:08:59 --> Total execution time: 0.0457
INFO - 2023-01-07 05:08:59 --> Config Class Initialized
INFO - 2023-01-07 05:08:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:08:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:08:59 --> Utf8 Class Initialized
INFO - 2023-01-07 05:08:59 --> URI Class Initialized
INFO - 2023-01-07 05:08:59 --> Router Class Initialized
INFO - 2023-01-07 05:08:59 --> Output Class Initialized
INFO - 2023-01-07 05:08:59 --> Security Class Initialized
DEBUG - 2023-01-07 05:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:08:59 --> Input Class Initialized
INFO - 2023-01-07 05:08:59 --> Language Class Initialized
INFO - 2023-01-07 05:08:59 --> Language Class Initialized
INFO - 2023-01-07 05:08:59 --> Config Class Initialized
INFO - 2023-01-07 05:08:59 --> Loader Class Initialized
INFO - 2023-01-07 05:08:59 --> Helper loaded: url_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: file_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: form_helper
INFO - 2023-01-07 05:08:59 --> Helper loaded: my_helper
INFO - 2023-01-07 05:08:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:08:59 --> Controller Class Initialized
INFO - 2023-01-07 05:09:03 --> Config Class Initialized
INFO - 2023-01-07 05:09:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:03 --> URI Class Initialized
INFO - 2023-01-07 05:09:03 --> Router Class Initialized
INFO - 2023-01-07 05:09:03 --> Output Class Initialized
INFO - 2023-01-07 05:09:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:03 --> Input Class Initialized
INFO - 2023-01-07 05:09:03 --> Language Class Initialized
INFO - 2023-01-07 05:09:03 --> Language Class Initialized
INFO - 2023-01-07 05:09:03 --> Config Class Initialized
INFO - 2023-01-07 05:09:03 --> Loader Class Initialized
INFO - 2023-01-07 05:09:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:03 --> Controller Class Initialized
INFO - 2023-01-07 05:09:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:03 --> Total execution time: 0.0434
INFO - 2023-01-07 05:09:05 --> Config Class Initialized
INFO - 2023-01-07 05:09:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:05 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:05 --> URI Class Initialized
INFO - 2023-01-07 05:09:05 --> Router Class Initialized
INFO - 2023-01-07 05:09:05 --> Output Class Initialized
INFO - 2023-01-07 05:09:05 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:05 --> Input Class Initialized
INFO - 2023-01-07 05:09:05 --> Language Class Initialized
INFO - 2023-01-07 05:09:05 --> Language Class Initialized
INFO - 2023-01-07 05:09:05 --> Config Class Initialized
INFO - 2023-01-07 05:09:05 --> Loader Class Initialized
INFO - 2023-01-07 05:09:05 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:05 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:05 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:05 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:05 --> Controller Class Initialized
INFO - 2023-01-07 05:09:05 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:05 --> Total execution time: 0.0279
INFO - 2023-01-07 05:09:11 --> Config Class Initialized
INFO - 2023-01-07 05:09:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:11 --> URI Class Initialized
INFO - 2023-01-07 05:09:11 --> Router Class Initialized
INFO - 2023-01-07 05:09:11 --> Output Class Initialized
INFO - 2023-01-07 05:09:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:11 --> Input Class Initialized
INFO - 2023-01-07 05:09:11 --> Language Class Initialized
INFO - 2023-01-07 05:09:11 --> Language Class Initialized
INFO - 2023-01-07 05:09:11 --> Config Class Initialized
INFO - 2023-01-07 05:09:11 --> Loader Class Initialized
INFO - 2023-01-07 05:09:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:11 --> Controller Class Initialized
INFO - 2023-01-07 05:09:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:11 --> Total execution time: 0.0308
INFO - 2023-01-07 05:09:14 --> Config Class Initialized
INFO - 2023-01-07 05:09:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:14 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:14 --> URI Class Initialized
INFO - 2023-01-07 05:09:14 --> Router Class Initialized
INFO - 2023-01-07 05:09:14 --> Output Class Initialized
INFO - 2023-01-07 05:09:14 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:14 --> Input Class Initialized
INFO - 2023-01-07 05:09:14 --> Language Class Initialized
INFO - 2023-01-07 05:09:14 --> Language Class Initialized
INFO - 2023-01-07 05:09:14 --> Config Class Initialized
INFO - 2023-01-07 05:09:14 --> Loader Class Initialized
INFO - 2023-01-07 05:09:14 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:14 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:14 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:14 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:15 --> Controller Class Initialized
INFO - 2023-01-07 05:09:15 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:15 --> Total execution time: 0.0395
INFO - 2023-01-07 05:09:15 --> Config Class Initialized
INFO - 2023-01-07 05:09:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:15 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:15 --> URI Class Initialized
INFO - 2023-01-07 05:09:15 --> Router Class Initialized
INFO - 2023-01-07 05:09:15 --> Output Class Initialized
INFO - 2023-01-07 05:09:15 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:15 --> Input Class Initialized
INFO - 2023-01-07 05:09:15 --> Language Class Initialized
INFO - 2023-01-07 05:09:15 --> Language Class Initialized
INFO - 2023-01-07 05:09:15 --> Config Class Initialized
INFO - 2023-01-07 05:09:15 --> Loader Class Initialized
INFO - 2023-01-07 05:09:15 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:15 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:15 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:15 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:15 --> Controller Class Initialized
INFO - 2023-01-07 05:09:18 --> Config Class Initialized
INFO - 2023-01-07 05:09:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:18 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:18 --> URI Class Initialized
INFO - 2023-01-07 05:09:18 --> Router Class Initialized
INFO - 2023-01-07 05:09:18 --> Output Class Initialized
INFO - 2023-01-07 05:09:18 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:18 --> Input Class Initialized
INFO - 2023-01-07 05:09:18 --> Language Class Initialized
INFO - 2023-01-07 05:09:18 --> Language Class Initialized
INFO - 2023-01-07 05:09:18 --> Config Class Initialized
INFO - 2023-01-07 05:09:18 --> Loader Class Initialized
INFO - 2023-01-07 05:09:18 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:18 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:18 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:18 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:18 --> Controller Class Initialized
INFO - 2023-01-07 05:09:18 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:18 --> Total execution time: 0.0273
INFO - 2023-01-07 05:09:22 --> Config Class Initialized
INFO - 2023-01-07 05:09:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:22 --> URI Class Initialized
INFO - 2023-01-07 05:09:22 --> Router Class Initialized
INFO - 2023-01-07 05:09:22 --> Output Class Initialized
INFO - 2023-01-07 05:09:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:22 --> Input Class Initialized
INFO - 2023-01-07 05:09:22 --> Language Class Initialized
INFO - 2023-01-07 05:09:22 --> Language Class Initialized
INFO - 2023-01-07 05:09:22 --> Config Class Initialized
INFO - 2023-01-07 05:09:22 --> Loader Class Initialized
INFO - 2023-01-07 05:09:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:22 --> Controller Class Initialized
INFO - 2023-01-07 05:09:22 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:22 --> Total execution time: 0.0278
INFO - 2023-01-07 05:09:27 --> Config Class Initialized
INFO - 2023-01-07 05:09:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:27 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:27 --> URI Class Initialized
INFO - 2023-01-07 05:09:27 --> Router Class Initialized
INFO - 2023-01-07 05:09:27 --> Output Class Initialized
INFO - 2023-01-07 05:09:27 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:27 --> Input Class Initialized
INFO - 2023-01-07 05:09:27 --> Language Class Initialized
INFO - 2023-01-07 05:09:27 --> Language Class Initialized
INFO - 2023-01-07 05:09:27 --> Config Class Initialized
INFO - 2023-01-07 05:09:27 --> Loader Class Initialized
INFO - 2023-01-07 05:09:27 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:27 --> Controller Class Initialized
INFO - 2023-01-07 05:09:27 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:27 --> Total execution time: 0.0236
INFO - 2023-01-07 05:09:27 --> Config Class Initialized
INFO - 2023-01-07 05:09:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:27 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:27 --> URI Class Initialized
INFO - 2023-01-07 05:09:27 --> Router Class Initialized
INFO - 2023-01-07 05:09:27 --> Output Class Initialized
INFO - 2023-01-07 05:09:27 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:27 --> Input Class Initialized
INFO - 2023-01-07 05:09:27 --> Language Class Initialized
INFO - 2023-01-07 05:09:27 --> Language Class Initialized
INFO - 2023-01-07 05:09:27 --> Config Class Initialized
INFO - 2023-01-07 05:09:27 --> Loader Class Initialized
INFO - 2023-01-07 05:09:27 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:27 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:27 --> Controller Class Initialized
INFO - 2023-01-07 05:09:41 --> Config Class Initialized
INFO - 2023-01-07 05:09:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:41 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:41 --> URI Class Initialized
INFO - 2023-01-07 05:09:41 --> Router Class Initialized
INFO - 2023-01-07 05:09:41 --> Output Class Initialized
INFO - 2023-01-07 05:09:41 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:41 --> Input Class Initialized
INFO - 2023-01-07 05:09:41 --> Language Class Initialized
INFO - 2023-01-07 05:09:41 --> Language Class Initialized
INFO - 2023-01-07 05:09:41 --> Config Class Initialized
INFO - 2023-01-07 05:09:41 --> Loader Class Initialized
INFO - 2023-01-07 05:09:41 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:41 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:41 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:41 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:41 --> Controller Class Initialized
INFO - 2023-01-07 05:09:41 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:41 --> Total execution time: 0.0295
INFO - 2023-01-07 05:09:54 --> Config Class Initialized
INFO - 2023-01-07 05:09:54 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:54 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:54 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:54 --> URI Class Initialized
INFO - 2023-01-07 05:09:54 --> Router Class Initialized
INFO - 2023-01-07 05:09:54 --> Output Class Initialized
INFO - 2023-01-07 05:09:54 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:54 --> Input Class Initialized
INFO - 2023-01-07 05:09:54 --> Language Class Initialized
INFO - 2023-01-07 05:09:54 --> Language Class Initialized
INFO - 2023-01-07 05:09:54 --> Config Class Initialized
INFO - 2023-01-07 05:09:54 --> Loader Class Initialized
INFO - 2023-01-07 05:09:54 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:54 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:54 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:54 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:54 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:54 --> Controller Class Initialized
INFO - 2023-01-07 05:09:54 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:54 --> Total execution time: 0.0272
INFO - 2023-01-07 05:09:59 --> Config Class Initialized
INFO - 2023-01-07 05:09:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:09:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:09:59 --> Utf8 Class Initialized
INFO - 2023-01-07 05:09:59 --> URI Class Initialized
INFO - 2023-01-07 05:09:59 --> Router Class Initialized
INFO - 2023-01-07 05:09:59 --> Output Class Initialized
INFO - 2023-01-07 05:09:59 --> Security Class Initialized
DEBUG - 2023-01-07 05:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:09:59 --> Input Class Initialized
INFO - 2023-01-07 05:09:59 --> Language Class Initialized
INFO - 2023-01-07 05:09:59 --> Language Class Initialized
INFO - 2023-01-07 05:09:59 --> Config Class Initialized
INFO - 2023-01-07 05:09:59 --> Loader Class Initialized
INFO - 2023-01-07 05:09:59 --> Helper loaded: url_helper
INFO - 2023-01-07 05:09:59 --> Helper loaded: file_helper
INFO - 2023-01-07 05:09:59 --> Helper loaded: form_helper
INFO - 2023-01-07 05:09:59 --> Helper loaded: my_helper
INFO - 2023-01-07 05:09:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:09:59 --> Controller Class Initialized
INFO - 2023-01-07 05:09:59 --> Final output sent to browser
DEBUG - 2023-01-07 05:09:59 --> Total execution time: 0.0280
INFO - 2023-01-07 05:10:03 --> Config Class Initialized
INFO - 2023-01-07 05:10:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:03 --> URI Class Initialized
INFO - 2023-01-07 05:10:03 --> Router Class Initialized
INFO - 2023-01-07 05:10:03 --> Output Class Initialized
INFO - 2023-01-07 05:10:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:03 --> Input Class Initialized
INFO - 2023-01-07 05:10:03 --> Language Class Initialized
INFO - 2023-01-07 05:10:03 --> Language Class Initialized
INFO - 2023-01-07 05:10:03 --> Config Class Initialized
INFO - 2023-01-07 05:10:03 --> Loader Class Initialized
INFO - 2023-01-07 05:10:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:03 --> Controller Class Initialized
INFO - 2023-01-07 05:10:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:03 --> Total execution time: 0.0239
INFO - 2023-01-07 05:10:03 --> Config Class Initialized
INFO - 2023-01-07 05:10:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:03 --> URI Class Initialized
INFO - 2023-01-07 05:10:03 --> Router Class Initialized
INFO - 2023-01-07 05:10:03 --> Output Class Initialized
INFO - 2023-01-07 05:10:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:03 --> Input Class Initialized
INFO - 2023-01-07 05:10:03 --> Language Class Initialized
INFO - 2023-01-07 05:10:03 --> Language Class Initialized
INFO - 2023-01-07 05:10:03 --> Config Class Initialized
INFO - 2023-01-07 05:10:03 --> Loader Class Initialized
INFO - 2023-01-07 05:10:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:03 --> Controller Class Initialized
INFO - 2023-01-07 05:10:06 --> Config Class Initialized
INFO - 2023-01-07 05:10:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:06 --> URI Class Initialized
INFO - 2023-01-07 05:10:06 --> Router Class Initialized
INFO - 2023-01-07 05:10:06 --> Output Class Initialized
INFO - 2023-01-07 05:10:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:06 --> Input Class Initialized
INFO - 2023-01-07 05:10:06 --> Language Class Initialized
INFO - 2023-01-07 05:10:06 --> Language Class Initialized
INFO - 2023-01-07 05:10:06 --> Config Class Initialized
INFO - 2023-01-07 05:10:06 --> Loader Class Initialized
INFO - 2023-01-07 05:10:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:06 --> Controller Class Initialized
INFO - 2023-01-07 05:10:06 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:06 --> Total execution time: 0.0280
INFO - 2023-01-07 05:10:12 --> Config Class Initialized
INFO - 2023-01-07 05:10:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:12 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:12 --> URI Class Initialized
INFO - 2023-01-07 05:10:12 --> Router Class Initialized
INFO - 2023-01-07 05:10:12 --> Output Class Initialized
INFO - 2023-01-07 05:10:12 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:12 --> Input Class Initialized
INFO - 2023-01-07 05:10:12 --> Language Class Initialized
INFO - 2023-01-07 05:10:12 --> Language Class Initialized
INFO - 2023-01-07 05:10:12 --> Config Class Initialized
INFO - 2023-01-07 05:10:12 --> Loader Class Initialized
INFO - 2023-01-07 05:10:12 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:12 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:12 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:12 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:12 --> Controller Class Initialized
INFO - 2023-01-07 05:10:12 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:12 --> Total execution time: 0.0278
INFO - 2023-01-07 05:10:17 --> Config Class Initialized
INFO - 2023-01-07 05:10:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:17 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:17 --> URI Class Initialized
INFO - 2023-01-07 05:10:17 --> Router Class Initialized
INFO - 2023-01-07 05:10:17 --> Output Class Initialized
INFO - 2023-01-07 05:10:17 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:17 --> Input Class Initialized
INFO - 2023-01-07 05:10:17 --> Language Class Initialized
INFO - 2023-01-07 05:10:17 --> Language Class Initialized
INFO - 2023-01-07 05:10:17 --> Config Class Initialized
INFO - 2023-01-07 05:10:17 --> Loader Class Initialized
INFO - 2023-01-07 05:10:17 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:17 --> Controller Class Initialized
INFO - 2023-01-07 05:10:17 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:17 --> Total execution time: 0.0268
INFO - 2023-01-07 05:10:17 --> Config Class Initialized
INFO - 2023-01-07 05:10:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:17 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:17 --> URI Class Initialized
INFO - 2023-01-07 05:10:17 --> Router Class Initialized
INFO - 2023-01-07 05:10:17 --> Output Class Initialized
INFO - 2023-01-07 05:10:17 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:17 --> Input Class Initialized
INFO - 2023-01-07 05:10:17 --> Language Class Initialized
INFO - 2023-01-07 05:10:17 --> Language Class Initialized
INFO - 2023-01-07 05:10:17 --> Config Class Initialized
INFO - 2023-01-07 05:10:17 --> Loader Class Initialized
INFO - 2023-01-07 05:10:17 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:17 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:17 --> Controller Class Initialized
INFO - 2023-01-07 05:10:20 --> Config Class Initialized
INFO - 2023-01-07 05:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:20 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:20 --> URI Class Initialized
INFO - 2023-01-07 05:10:20 --> Router Class Initialized
INFO - 2023-01-07 05:10:20 --> Output Class Initialized
INFO - 2023-01-07 05:10:20 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:20 --> Input Class Initialized
INFO - 2023-01-07 05:10:20 --> Language Class Initialized
INFO - 2023-01-07 05:10:20 --> Language Class Initialized
INFO - 2023-01-07 05:10:20 --> Config Class Initialized
INFO - 2023-01-07 05:10:20 --> Loader Class Initialized
INFO - 2023-01-07 05:10:20 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:20 --> Controller Class Initialized
INFO - 2023-01-07 05:10:20 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:20 --> Total execution time: 0.0302
INFO - 2023-01-07 05:10:20 --> Config Class Initialized
INFO - 2023-01-07 05:10:20 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:20 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:20 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:20 --> URI Class Initialized
INFO - 2023-01-07 05:10:20 --> Router Class Initialized
INFO - 2023-01-07 05:10:20 --> Output Class Initialized
INFO - 2023-01-07 05:10:20 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:20 --> Input Class Initialized
INFO - 2023-01-07 05:10:20 --> Language Class Initialized
INFO - 2023-01-07 05:10:20 --> Language Class Initialized
INFO - 2023-01-07 05:10:20 --> Config Class Initialized
INFO - 2023-01-07 05:10:20 --> Loader Class Initialized
INFO - 2023-01-07 05:10:20 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:20 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:20 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:20 --> Controller Class Initialized
INFO - 2023-01-07 05:10:23 --> Config Class Initialized
INFO - 2023-01-07 05:10:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:23 --> URI Class Initialized
INFO - 2023-01-07 05:10:23 --> Router Class Initialized
INFO - 2023-01-07 05:10:23 --> Output Class Initialized
INFO - 2023-01-07 05:10:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:23 --> Input Class Initialized
INFO - 2023-01-07 05:10:23 --> Language Class Initialized
INFO - 2023-01-07 05:10:23 --> Language Class Initialized
INFO - 2023-01-07 05:10:23 --> Config Class Initialized
INFO - 2023-01-07 05:10:23 --> Loader Class Initialized
INFO - 2023-01-07 05:10:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:23 --> Controller Class Initialized
INFO - 2023-01-07 05:10:23 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:23 --> Total execution time: 0.0315
INFO - 2023-01-07 05:10:23 --> Config Class Initialized
INFO - 2023-01-07 05:10:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:23 --> URI Class Initialized
INFO - 2023-01-07 05:10:23 --> Router Class Initialized
INFO - 2023-01-07 05:10:23 --> Output Class Initialized
INFO - 2023-01-07 05:10:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:23 --> Input Class Initialized
INFO - 2023-01-07 05:10:23 --> Language Class Initialized
INFO - 2023-01-07 05:10:23 --> Language Class Initialized
INFO - 2023-01-07 05:10:23 --> Config Class Initialized
INFO - 2023-01-07 05:10:23 --> Loader Class Initialized
INFO - 2023-01-07 05:10:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:23 --> Controller Class Initialized
INFO - 2023-01-07 05:10:25 --> Config Class Initialized
INFO - 2023-01-07 05:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:25 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:25 --> URI Class Initialized
INFO - 2023-01-07 05:10:25 --> Router Class Initialized
INFO - 2023-01-07 05:10:25 --> Output Class Initialized
INFO - 2023-01-07 05:10:25 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:25 --> Input Class Initialized
INFO - 2023-01-07 05:10:25 --> Language Class Initialized
INFO - 2023-01-07 05:10:25 --> Language Class Initialized
INFO - 2023-01-07 05:10:25 --> Config Class Initialized
INFO - 2023-01-07 05:10:25 --> Loader Class Initialized
INFO - 2023-01-07 05:10:25 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:25 --> Controller Class Initialized
INFO - 2023-01-07 05:10:25 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:25 --> Total execution time: 0.0310
INFO - 2023-01-07 05:10:25 --> Config Class Initialized
INFO - 2023-01-07 05:10:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:25 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:25 --> URI Class Initialized
INFO - 2023-01-07 05:10:25 --> Router Class Initialized
INFO - 2023-01-07 05:10:25 --> Output Class Initialized
INFO - 2023-01-07 05:10:25 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:25 --> Input Class Initialized
INFO - 2023-01-07 05:10:25 --> Language Class Initialized
INFO - 2023-01-07 05:10:25 --> Language Class Initialized
INFO - 2023-01-07 05:10:25 --> Config Class Initialized
INFO - 2023-01-07 05:10:25 --> Loader Class Initialized
INFO - 2023-01-07 05:10:25 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:25 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:25 --> Controller Class Initialized
INFO - 2023-01-07 05:10:29 --> Config Class Initialized
INFO - 2023-01-07 05:10:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:29 --> URI Class Initialized
INFO - 2023-01-07 05:10:29 --> Router Class Initialized
INFO - 2023-01-07 05:10:29 --> Output Class Initialized
INFO - 2023-01-07 05:10:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:29 --> Input Class Initialized
INFO - 2023-01-07 05:10:29 --> Language Class Initialized
INFO - 2023-01-07 05:10:29 --> Language Class Initialized
INFO - 2023-01-07 05:10:29 --> Config Class Initialized
INFO - 2023-01-07 05:10:29 --> Loader Class Initialized
INFO - 2023-01-07 05:10:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:29 --> Controller Class Initialized
INFO - 2023-01-07 05:10:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:29 --> Total execution time: 0.0408
INFO - 2023-01-07 05:10:29 --> Config Class Initialized
INFO - 2023-01-07 05:10:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:29 --> URI Class Initialized
INFO - 2023-01-07 05:10:29 --> Router Class Initialized
INFO - 2023-01-07 05:10:29 --> Output Class Initialized
INFO - 2023-01-07 05:10:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:29 --> Input Class Initialized
INFO - 2023-01-07 05:10:29 --> Language Class Initialized
INFO - 2023-01-07 05:10:29 --> Language Class Initialized
INFO - 2023-01-07 05:10:29 --> Config Class Initialized
INFO - 2023-01-07 05:10:29 --> Loader Class Initialized
INFO - 2023-01-07 05:10:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:29 --> Controller Class Initialized
INFO - 2023-01-07 05:10:31 --> Config Class Initialized
INFO - 2023-01-07 05:10:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:31 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:31 --> URI Class Initialized
INFO - 2023-01-07 05:10:31 --> Router Class Initialized
INFO - 2023-01-07 05:10:31 --> Output Class Initialized
INFO - 2023-01-07 05:10:31 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:31 --> Input Class Initialized
INFO - 2023-01-07 05:10:31 --> Language Class Initialized
INFO - 2023-01-07 05:10:31 --> Language Class Initialized
INFO - 2023-01-07 05:10:31 --> Config Class Initialized
INFO - 2023-01-07 05:10:31 --> Loader Class Initialized
INFO - 2023-01-07 05:10:31 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:31 --> Controller Class Initialized
INFO - 2023-01-07 05:10:31 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:31 --> Total execution time: 0.0282
INFO - 2023-01-07 05:10:31 --> Config Class Initialized
INFO - 2023-01-07 05:10:31 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:31 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:31 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:31 --> URI Class Initialized
INFO - 2023-01-07 05:10:31 --> Router Class Initialized
INFO - 2023-01-07 05:10:31 --> Output Class Initialized
INFO - 2023-01-07 05:10:31 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:31 --> Input Class Initialized
INFO - 2023-01-07 05:10:31 --> Language Class Initialized
INFO - 2023-01-07 05:10:31 --> Language Class Initialized
INFO - 2023-01-07 05:10:31 --> Config Class Initialized
INFO - 2023-01-07 05:10:31 --> Loader Class Initialized
INFO - 2023-01-07 05:10:31 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:31 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:31 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:31 --> Controller Class Initialized
INFO - 2023-01-07 05:10:33 --> Config Class Initialized
INFO - 2023-01-07 05:10:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:33 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:33 --> URI Class Initialized
INFO - 2023-01-07 05:10:33 --> Router Class Initialized
INFO - 2023-01-07 05:10:33 --> Output Class Initialized
INFO - 2023-01-07 05:10:33 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:33 --> Input Class Initialized
INFO - 2023-01-07 05:10:33 --> Language Class Initialized
INFO - 2023-01-07 05:10:33 --> Language Class Initialized
INFO - 2023-01-07 05:10:33 --> Config Class Initialized
INFO - 2023-01-07 05:10:33 --> Loader Class Initialized
INFO - 2023-01-07 05:10:33 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:33 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:33 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:33 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:33 --> Controller Class Initialized
INFO - 2023-01-07 05:10:33 --> Final output sent to browser
DEBUG - 2023-01-07 05:10:33 --> Total execution time: 0.0437
INFO - 2023-01-07 05:10:36 --> Config Class Initialized
INFO - 2023-01-07 05:10:36 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:10:36 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:10:36 --> Utf8 Class Initialized
INFO - 2023-01-07 05:10:36 --> URI Class Initialized
INFO - 2023-01-07 05:10:36 --> Router Class Initialized
INFO - 2023-01-07 05:10:36 --> Output Class Initialized
INFO - 2023-01-07 05:10:36 --> Security Class Initialized
DEBUG - 2023-01-07 05:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:10:36 --> Input Class Initialized
INFO - 2023-01-07 05:10:36 --> Language Class Initialized
INFO - 2023-01-07 05:10:36 --> Language Class Initialized
INFO - 2023-01-07 05:10:36 --> Config Class Initialized
INFO - 2023-01-07 05:10:36 --> Loader Class Initialized
INFO - 2023-01-07 05:10:36 --> Helper loaded: url_helper
INFO - 2023-01-07 05:10:36 --> Helper loaded: file_helper
INFO - 2023-01-07 05:10:36 --> Helper loaded: form_helper
INFO - 2023-01-07 05:10:36 --> Helper loaded: my_helper
INFO - 2023-01-07 05:10:36 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:10:36 --> Controller Class Initialized
INFO - 2023-01-07 05:11:34 --> Config Class Initialized
INFO - 2023-01-07 05:11:34 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:34 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:34 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:34 --> URI Class Initialized
INFO - 2023-01-07 05:11:34 --> Router Class Initialized
INFO - 2023-01-07 05:11:34 --> Output Class Initialized
INFO - 2023-01-07 05:11:34 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:34 --> Input Class Initialized
INFO - 2023-01-07 05:11:34 --> Language Class Initialized
INFO - 2023-01-07 05:11:34 --> Language Class Initialized
INFO - 2023-01-07 05:11:34 --> Config Class Initialized
INFO - 2023-01-07 05:11:34 --> Loader Class Initialized
INFO - 2023-01-07 05:11:34 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:34 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:34 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:34 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:34 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:34 --> Controller Class Initialized
DEBUG - 2023-01-07 05:11:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-07 05:11:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:11:34 --> Final output sent to browser
DEBUG - 2023-01-07 05:11:34 --> Total execution time: 0.0543
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:42 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:42 --> URI Class Initialized
INFO - 2023-01-07 05:11:42 --> Router Class Initialized
INFO - 2023-01-07 05:11:42 --> Output Class Initialized
INFO - 2023-01-07 05:11:42 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:42 --> Input Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Loader Class Initialized
INFO - 2023-01-07 05:11:42 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:42 --> Controller Class Initialized
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:42 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:42 --> URI Class Initialized
INFO - 2023-01-07 05:11:42 --> Router Class Initialized
INFO - 2023-01-07 05:11:42 --> Output Class Initialized
INFO - 2023-01-07 05:11:42 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:42 --> Input Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Loader Class Initialized
INFO - 2023-01-07 05:11:42 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:42 --> Controller Class Initialized
DEBUG - 2023-01-07 05:11:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-07 05:11:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:11:42 --> Final output sent to browser
DEBUG - 2023-01-07 05:11:42 --> Total execution time: 0.0441
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:42 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:42 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:42 --> URI Class Initialized
INFO - 2023-01-07 05:11:42 --> Router Class Initialized
INFO - 2023-01-07 05:11:42 --> Output Class Initialized
INFO - 2023-01-07 05:11:42 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:42 --> Input Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Language Class Initialized
INFO - 2023-01-07 05:11:42 --> Config Class Initialized
INFO - 2023-01-07 05:11:42 --> Loader Class Initialized
INFO - 2023-01-07 05:11:42 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:42 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:42 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:42 --> Controller Class Initialized
INFO - 2023-01-07 05:11:43 --> Config Class Initialized
INFO - 2023-01-07 05:11:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:43 --> URI Class Initialized
INFO - 2023-01-07 05:11:43 --> Router Class Initialized
INFO - 2023-01-07 05:11:43 --> Output Class Initialized
INFO - 2023-01-07 05:11:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:43 --> Input Class Initialized
INFO - 2023-01-07 05:11:43 --> Language Class Initialized
INFO - 2023-01-07 05:11:43 --> Language Class Initialized
INFO - 2023-01-07 05:11:43 --> Config Class Initialized
INFO - 2023-01-07 05:11:43 --> Loader Class Initialized
INFO - 2023-01-07 05:11:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:43 --> Controller Class Initialized
INFO - 2023-01-07 05:11:43 --> Final output sent to browser
DEBUG - 2023-01-07 05:11:43 --> Total execution time: 0.0435
INFO - 2023-01-07 05:11:47 --> Config Class Initialized
INFO - 2023-01-07 05:11:47 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:47 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:47 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:47 --> URI Class Initialized
INFO - 2023-01-07 05:11:47 --> Router Class Initialized
INFO - 2023-01-07 05:11:47 --> Output Class Initialized
INFO - 2023-01-07 05:11:47 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:47 --> Input Class Initialized
INFO - 2023-01-07 05:11:47 --> Language Class Initialized
INFO - 2023-01-07 05:11:47 --> Language Class Initialized
INFO - 2023-01-07 05:11:47 --> Config Class Initialized
INFO - 2023-01-07 05:11:47 --> Loader Class Initialized
INFO - 2023-01-07 05:11:47 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:47 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:47 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:47 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:47 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:47 --> Controller Class Initialized
DEBUG - 2023-01-07 05:11:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/cetak.php
INFO - 2023-01-07 05:11:47 --> Final output sent to browser
DEBUG - 2023-01-07 05:11:47 --> Total execution time: 0.0578
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:56 --> URI Class Initialized
INFO - 2023-01-07 05:11:56 --> Router Class Initialized
INFO - 2023-01-07 05:11:56 --> Output Class Initialized
INFO - 2023-01-07 05:11:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:56 --> Input Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Loader Class Initialized
INFO - 2023-01-07 05:11:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:56 --> Controller Class Initialized
INFO - 2023-01-07 05:11:56 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:56 --> URI Class Initialized
INFO - 2023-01-07 05:11:56 --> Router Class Initialized
INFO - 2023-01-07 05:11:56 --> Output Class Initialized
INFO - 2023-01-07 05:11:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:56 --> Input Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Loader Class Initialized
INFO - 2023-01-07 05:11:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:56 --> Controller Class Initialized
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:11:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:11:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:11:56 --> URI Class Initialized
INFO - 2023-01-07 05:11:56 --> Router Class Initialized
INFO - 2023-01-07 05:11:56 --> Output Class Initialized
INFO - 2023-01-07 05:11:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:11:56 --> Input Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Language Class Initialized
INFO - 2023-01-07 05:11:56 --> Config Class Initialized
INFO - 2023-01-07 05:11:56 --> Loader Class Initialized
INFO - 2023-01-07 05:11:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:11:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:11:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:11:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:11:56 --> Controller Class Initialized
DEBUG - 2023-01-07 05:11:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:11:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:11:56 --> Final output sent to browser
DEBUG - 2023-01-07 05:11:56 --> Total execution time: 0.0438
INFO - 2023-01-07 05:12:05 --> Config Class Initialized
INFO - 2023-01-07 05:12:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:05 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:05 --> URI Class Initialized
INFO - 2023-01-07 05:12:05 --> Router Class Initialized
INFO - 2023-01-07 05:12:05 --> Output Class Initialized
INFO - 2023-01-07 05:12:05 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:05 --> Input Class Initialized
INFO - 2023-01-07 05:12:05 --> Language Class Initialized
INFO - 2023-01-07 05:12:05 --> Language Class Initialized
INFO - 2023-01-07 05:12:05 --> Config Class Initialized
INFO - 2023-01-07 05:12:05 --> Loader Class Initialized
INFO - 2023-01-07 05:12:05 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:05 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:05 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:05 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:05 --> Controller Class Initialized
INFO - 2023-01-07 05:12:05 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:12:05 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:05 --> Total execution time: 0.0337
INFO - 2023-01-07 05:12:06 --> Config Class Initialized
INFO - 2023-01-07 05:12:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:06 --> URI Class Initialized
INFO - 2023-01-07 05:12:06 --> Router Class Initialized
INFO - 2023-01-07 05:12:06 --> Output Class Initialized
INFO - 2023-01-07 05:12:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:06 --> Input Class Initialized
INFO - 2023-01-07 05:12:06 --> Language Class Initialized
INFO - 2023-01-07 05:12:06 --> Language Class Initialized
INFO - 2023-01-07 05:12:06 --> Config Class Initialized
INFO - 2023-01-07 05:12:06 --> Loader Class Initialized
INFO - 2023-01-07 05:12:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:06 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 05:12:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:12:06 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:06 --> Total execution time: 0.0382
INFO - 2023-01-07 05:12:09 --> Config Class Initialized
INFO - 2023-01-07 05:12:09 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:09 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:09 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:09 --> URI Class Initialized
INFO - 2023-01-07 05:12:09 --> Router Class Initialized
INFO - 2023-01-07 05:12:09 --> Output Class Initialized
INFO - 2023-01-07 05:12:09 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:09 --> Input Class Initialized
INFO - 2023-01-07 05:12:09 --> Language Class Initialized
INFO - 2023-01-07 05:12:09 --> Language Class Initialized
INFO - 2023-01-07 05:12:09 --> Config Class Initialized
INFO - 2023-01-07 05:12:09 --> Loader Class Initialized
INFO - 2023-01-07 05:12:09 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:09 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:09 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:09 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:09 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:09 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 05:12:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:12:09 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:09 --> Total execution time: 0.0378
INFO - 2023-01-07 05:12:11 --> Config Class Initialized
INFO - 2023-01-07 05:12:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:11 --> URI Class Initialized
INFO - 2023-01-07 05:12:11 --> Router Class Initialized
INFO - 2023-01-07 05:12:11 --> Output Class Initialized
INFO - 2023-01-07 05:12:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:11 --> Input Class Initialized
INFO - 2023-01-07 05:12:11 --> Language Class Initialized
INFO - 2023-01-07 05:12:11 --> Language Class Initialized
INFO - 2023-01-07 05:12:11 --> Config Class Initialized
INFO - 2023-01-07 05:12:11 --> Loader Class Initialized
INFO - 2023-01-07 05:12:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 05:12:12 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:12 --> Total execution time: 0.1549
INFO - 2023-01-07 05:12:21 --> Config Class Initialized
INFO - 2023-01-07 05:12:21 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:21 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:21 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:21 --> URI Class Initialized
INFO - 2023-01-07 05:12:21 --> Router Class Initialized
INFO - 2023-01-07 05:12:21 --> Output Class Initialized
INFO - 2023-01-07 05:12:21 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:21 --> Input Class Initialized
INFO - 2023-01-07 05:12:21 --> Language Class Initialized
INFO - 2023-01-07 05:12:21 --> Language Class Initialized
INFO - 2023-01-07 05:12:21 --> Config Class Initialized
INFO - 2023-01-07 05:12:21 --> Loader Class Initialized
INFO - 2023-01-07 05:12:21 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:21 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:21 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:21 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:21 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:21 --> Controller Class Initialized
ERROR - 2023-01-07 05:12:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 327
ERROR - 2023-01-07 05:12:21 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2023-01-07 05:12:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 05:12:21 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:21 --> Total execution time: 0.1605
INFO - 2023-01-07 05:12:33 --> Config Class Initialized
INFO - 2023-01-07 05:12:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:33 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:33 --> URI Class Initialized
INFO - 2023-01-07 05:12:33 --> Router Class Initialized
INFO - 2023-01-07 05:12:33 --> Output Class Initialized
INFO - 2023-01-07 05:12:33 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:33 --> Input Class Initialized
INFO - 2023-01-07 05:12:33 --> Language Class Initialized
INFO - 2023-01-07 05:12:33 --> Language Class Initialized
INFO - 2023-01-07 05:12:33 --> Config Class Initialized
INFO - 2023-01-07 05:12:33 --> Loader Class Initialized
INFO - 2023-01-07 05:12:33 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:33 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:33 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:33 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:33 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-01-07 05:12:33 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:33 --> Total execution time: 0.0346
INFO - 2023-01-07 05:12:37 --> Config Class Initialized
INFO - 2023-01-07 05:12:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:37 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:37 --> URI Class Initialized
INFO - 2023-01-07 05:12:37 --> Router Class Initialized
INFO - 2023-01-07 05:12:37 --> Output Class Initialized
INFO - 2023-01-07 05:12:37 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:37 --> Input Class Initialized
INFO - 2023-01-07 05:12:37 --> Language Class Initialized
INFO - 2023-01-07 05:12:37 --> Language Class Initialized
INFO - 2023-01-07 05:12:37 --> Config Class Initialized
INFO - 2023-01-07 05:12:37 --> Loader Class Initialized
INFO - 2023-01-07 05:12:37 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:37 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:37 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:37 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:37 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-01-07 05:12:37 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:37 --> Total execution time: 0.0324
INFO - 2023-01-07 05:12:41 --> Config Class Initialized
INFO - 2023-01-07 05:12:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:41 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:41 --> URI Class Initialized
INFO - 2023-01-07 05:12:41 --> Router Class Initialized
INFO - 2023-01-07 05:12:41 --> Output Class Initialized
INFO - 2023-01-07 05:12:41 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:41 --> Input Class Initialized
INFO - 2023-01-07 05:12:41 --> Language Class Initialized
INFO - 2023-01-07 05:12:41 --> Language Class Initialized
INFO - 2023-01-07 05:12:41 --> Config Class Initialized
INFO - 2023-01-07 05:12:41 --> Loader Class Initialized
INFO - 2023-01-07 05:12:41 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:41 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:41 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:41 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:41 --> Controller Class Initialized
DEBUG - 2023-01-07 05:12:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-01-07 05:12:41 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:41 --> Total execution time: 0.0361
INFO - 2023-01-07 05:12:48 --> Config Class Initialized
INFO - 2023-01-07 05:12:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:12:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:12:48 --> Utf8 Class Initialized
INFO - 2023-01-07 05:12:48 --> URI Class Initialized
INFO - 2023-01-07 05:12:48 --> Router Class Initialized
INFO - 2023-01-07 05:12:48 --> Output Class Initialized
INFO - 2023-01-07 05:12:48 --> Security Class Initialized
DEBUG - 2023-01-07 05:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:12:48 --> Input Class Initialized
INFO - 2023-01-07 05:12:48 --> Language Class Initialized
INFO - 2023-01-07 05:12:48 --> Language Class Initialized
INFO - 2023-01-07 05:12:48 --> Config Class Initialized
INFO - 2023-01-07 05:12:48 --> Loader Class Initialized
INFO - 2023-01-07 05:12:48 --> Helper loaded: url_helper
INFO - 2023-01-07 05:12:48 --> Helper loaded: file_helper
INFO - 2023-01-07 05:12:48 --> Helper loaded: form_helper
INFO - 2023-01-07 05:12:48 --> Helper loaded: my_helper
INFO - 2023-01-07 05:12:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:12:48 --> Controller Class Initialized
ERROR - 2023-01-07 05:12:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 327
ERROR - 2023-01-07 05:12:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2023-01-07 05:12:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 05:12:48 --> Final output sent to browser
DEBUG - 2023-01-07 05:12:48 --> Total execution time: 0.1627
INFO - 2023-01-07 05:13:06 --> Config Class Initialized
INFO - 2023-01-07 05:13:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:06 --> URI Class Initialized
INFO - 2023-01-07 05:13:06 --> Router Class Initialized
INFO - 2023-01-07 05:13:06 --> Output Class Initialized
INFO - 2023-01-07 05:13:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:06 --> Input Class Initialized
INFO - 2023-01-07 05:13:06 --> Language Class Initialized
INFO - 2023-01-07 05:13:06 --> Language Class Initialized
INFO - 2023-01-07 05:13:06 --> Config Class Initialized
INFO - 2023-01-07 05:13:06 --> Loader Class Initialized
INFO - 2023-01-07 05:13:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:06 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:13:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:06 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:06 --> Total execution time: 0.0256
INFO - 2023-01-07 05:13:11 --> Config Class Initialized
INFO - 2023-01-07 05:13:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:11 --> URI Class Initialized
INFO - 2023-01-07 05:13:11 --> Router Class Initialized
INFO - 2023-01-07 05:13:11 --> Output Class Initialized
INFO - 2023-01-07 05:13:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:11 --> Input Class Initialized
INFO - 2023-01-07 05:13:11 --> Language Class Initialized
INFO - 2023-01-07 05:13:11 --> Language Class Initialized
INFO - 2023-01-07 05:13:11 --> Config Class Initialized
INFO - 2023-01-07 05:13:11 --> Loader Class Initialized
INFO - 2023-01-07 05:13:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:13:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:11 --> Total execution time: 0.0395
INFO - 2023-01-07 05:13:17 --> Config Class Initialized
INFO - 2023-01-07 05:13:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:17 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:17 --> URI Class Initialized
INFO - 2023-01-07 05:13:17 --> Router Class Initialized
INFO - 2023-01-07 05:13:17 --> Output Class Initialized
INFO - 2023-01-07 05:13:17 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:17 --> Input Class Initialized
INFO - 2023-01-07 05:13:17 --> Language Class Initialized
INFO - 2023-01-07 05:13:17 --> Language Class Initialized
INFO - 2023-01-07 05:13:17 --> Config Class Initialized
INFO - 2023-01-07 05:13:17 --> Loader Class Initialized
INFO - 2023-01-07 05:13:17 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:17 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:17 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:17 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:17 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:13:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:17 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:17 --> Total execution time: 0.0377
INFO - 2023-01-07 05:13:19 --> Config Class Initialized
INFO - 2023-01-07 05:13:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:19 --> URI Class Initialized
INFO - 2023-01-07 05:13:19 --> Router Class Initialized
INFO - 2023-01-07 05:13:19 --> Output Class Initialized
INFO - 2023-01-07 05:13:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:19 --> Input Class Initialized
INFO - 2023-01-07 05:13:19 --> Language Class Initialized
INFO - 2023-01-07 05:13:19 --> Language Class Initialized
INFO - 2023-01-07 05:13:19 --> Config Class Initialized
INFO - 2023-01-07 05:13:19 --> Loader Class Initialized
INFO - 2023-01-07 05:13:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:19 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 05:13:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:19 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:19 --> Total execution time: 0.0385
INFO - 2023-01-07 05:13:21 --> Config Class Initialized
INFO - 2023-01-07 05:13:21 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:21 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:21 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:21 --> URI Class Initialized
INFO - 2023-01-07 05:13:21 --> Router Class Initialized
INFO - 2023-01-07 05:13:21 --> Output Class Initialized
INFO - 2023-01-07 05:13:21 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:21 --> Input Class Initialized
INFO - 2023-01-07 05:13:21 --> Language Class Initialized
INFO - 2023-01-07 05:13:21 --> Language Class Initialized
INFO - 2023-01-07 05:13:21 --> Config Class Initialized
INFO - 2023-01-07 05:13:21 --> Loader Class Initialized
INFO - 2023-01-07 05:13:21 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:21 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:21 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:21 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:21 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:21 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:13:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:21 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:21 --> Total execution time: 0.0377
INFO - 2023-01-07 05:13:22 --> Config Class Initialized
INFO - 2023-01-07 05:13:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:13:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:13:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:13:22 --> URI Class Initialized
INFO - 2023-01-07 05:13:22 --> Router Class Initialized
INFO - 2023-01-07 05:13:22 --> Output Class Initialized
INFO - 2023-01-07 05:13:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:13:22 --> Input Class Initialized
INFO - 2023-01-07 05:13:22 --> Language Class Initialized
INFO - 2023-01-07 05:13:22 --> Language Class Initialized
INFO - 2023-01-07 05:13:22 --> Config Class Initialized
INFO - 2023-01-07 05:13:22 --> Loader Class Initialized
INFO - 2023-01-07 05:13:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:13:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:13:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:13:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:13:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:13:22 --> Controller Class Initialized
DEBUG - 2023-01-07 05:13:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:13:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:13:22 --> Final output sent to browser
DEBUG - 2023-01-07 05:13:22 --> Total execution time: 0.0246
INFO - 2023-01-07 05:15:19 --> Config Class Initialized
INFO - 2023-01-07 05:15:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:15:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:15:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:15:19 --> URI Class Initialized
INFO - 2023-01-07 05:15:19 --> Router Class Initialized
INFO - 2023-01-07 05:15:19 --> Output Class Initialized
INFO - 2023-01-07 05:15:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:15:19 --> Input Class Initialized
INFO - 2023-01-07 05:15:19 --> Language Class Initialized
INFO - 2023-01-07 05:15:19 --> Language Class Initialized
INFO - 2023-01-07 05:15:19 --> Config Class Initialized
INFO - 2023-01-07 05:15:19 --> Loader Class Initialized
INFO - 2023-01-07 05:15:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:15:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:15:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:15:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:15:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:15:19 --> Controller Class Initialized
INFO - 2023-01-07 05:15:19 --> Final output sent to browser
DEBUG - 2023-01-07 05:15:19 --> Total execution time: 0.0257
INFO - 2023-01-07 05:15:22 --> Config Class Initialized
INFO - 2023-01-07 05:15:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:15:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:15:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:15:22 --> URI Class Initialized
INFO - 2023-01-07 05:15:22 --> Router Class Initialized
INFO - 2023-01-07 05:15:22 --> Output Class Initialized
INFO - 2023-01-07 05:15:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:15:22 --> Input Class Initialized
INFO - 2023-01-07 05:15:22 --> Language Class Initialized
INFO - 2023-01-07 05:15:22 --> Language Class Initialized
INFO - 2023-01-07 05:15:22 --> Config Class Initialized
INFO - 2023-01-07 05:15:22 --> Loader Class Initialized
INFO - 2023-01-07 05:15:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:15:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:15:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:15:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:15:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:15:22 --> Controller Class Initialized
DEBUG - 2023-01-07 05:15:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:15:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:15:22 --> Final output sent to browser
DEBUG - 2023-01-07 05:15:22 --> Total execution time: 0.0263
INFO - 2023-01-07 05:15:24 --> Config Class Initialized
INFO - 2023-01-07 05:15:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:15:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:15:24 --> Utf8 Class Initialized
INFO - 2023-01-07 05:15:24 --> URI Class Initialized
INFO - 2023-01-07 05:15:24 --> Router Class Initialized
INFO - 2023-01-07 05:15:24 --> Output Class Initialized
INFO - 2023-01-07 05:15:24 --> Security Class Initialized
DEBUG - 2023-01-07 05:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:15:24 --> Input Class Initialized
INFO - 2023-01-07 05:15:24 --> Language Class Initialized
INFO - 2023-01-07 05:15:24 --> Language Class Initialized
INFO - 2023-01-07 05:15:24 --> Config Class Initialized
INFO - 2023-01-07 05:15:24 --> Loader Class Initialized
INFO - 2023-01-07 05:15:24 --> Helper loaded: url_helper
INFO - 2023-01-07 05:15:24 --> Helper loaded: file_helper
INFO - 2023-01-07 05:15:24 --> Helper loaded: form_helper
INFO - 2023-01-07 05:15:24 --> Helper loaded: my_helper
INFO - 2023-01-07 05:15:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:15:24 --> Controller Class Initialized
DEBUG - 2023-01-07 05:15:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:15:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:15:24 --> Final output sent to browser
DEBUG - 2023-01-07 05:15:24 --> Total execution time: 0.0253
INFO - 2023-01-07 05:15:55 --> Config Class Initialized
INFO - 2023-01-07 05:15:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:15:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:15:55 --> Utf8 Class Initialized
INFO - 2023-01-07 05:15:55 --> URI Class Initialized
INFO - 2023-01-07 05:15:55 --> Router Class Initialized
INFO - 2023-01-07 05:15:55 --> Output Class Initialized
INFO - 2023-01-07 05:15:55 --> Security Class Initialized
DEBUG - 2023-01-07 05:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:15:55 --> Input Class Initialized
INFO - 2023-01-07 05:15:55 --> Language Class Initialized
INFO - 2023-01-07 05:15:55 --> Language Class Initialized
INFO - 2023-01-07 05:15:55 --> Config Class Initialized
INFO - 2023-01-07 05:15:55 --> Loader Class Initialized
INFO - 2023-01-07 05:15:55 --> Helper loaded: url_helper
INFO - 2023-01-07 05:15:55 --> Helper loaded: file_helper
INFO - 2023-01-07 05:15:55 --> Helper loaded: form_helper
INFO - 2023-01-07 05:15:55 --> Helper loaded: my_helper
INFO - 2023-01-07 05:15:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:15:55 --> Controller Class Initialized
DEBUG - 2023-01-07 05:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 05:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:15:55 --> Final output sent to browser
DEBUG - 2023-01-07 05:15:55 --> Total execution time: 0.0528
INFO - 2023-01-07 05:15:58 --> Config Class Initialized
INFO - 2023-01-07 05:15:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:15:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:15:58 --> Utf8 Class Initialized
INFO - 2023-01-07 05:15:58 --> URI Class Initialized
INFO - 2023-01-07 05:15:58 --> Router Class Initialized
INFO - 2023-01-07 05:15:58 --> Output Class Initialized
INFO - 2023-01-07 05:15:58 --> Security Class Initialized
DEBUG - 2023-01-07 05:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:15:58 --> Input Class Initialized
INFO - 2023-01-07 05:15:58 --> Language Class Initialized
INFO - 2023-01-07 05:15:58 --> Language Class Initialized
INFO - 2023-01-07 05:15:58 --> Config Class Initialized
INFO - 2023-01-07 05:15:58 --> Loader Class Initialized
INFO - 2023-01-07 05:15:58 --> Helper loaded: url_helper
INFO - 2023-01-07 05:15:58 --> Helper loaded: file_helper
INFO - 2023-01-07 05:15:58 --> Helper loaded: form_helper
INFO - 2023-01-07 05:15:58 --> Helper loaded: my_helper
INFO - 2023-01-07 05:15:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:15:58 --> Controller Class Initialized
DEBUG - 2023-01-07 05:15:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:15:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:15:58 --> Final output sent to browser
DEBUG - 2023-01-07 05:15:58 --> Total execution time: 0.0392
INFO - 2023-01-07 05:16:03 --> Config Class Initialized
INFO - 2023-01-07 05:16:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:03 --> URI Class Initialized
INFO - 2023-01-07 05:16:03 --> Router Class Initialized
INFO - 2023-01-07 05:16:03 --> Output Class Initialized
INFO - 2023-01-07 05:16:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:03 --> Input Class Initialized
INFO - 2023-01-07 05:16:03 --> Language Class Initialized
INFO - 2023-01-07 05:16:03 --> Language Class Initialized
INFO - 2023-01-07 05:16:03 --> Config Class Initialized
INFO - 2023-01-07 05:16:03 --> Loader Class Initialized
INFO - 2023-01-07 05:16:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:03 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_prestasi/views/list.php
DEBUG - 2023-01-07 05:16:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:03 --> Total execution time: 0.0255
INFO - 2023-01-07 05:16:03 --> Config Class Initialized
INFO - 2023-01-07 05:16:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:03 --> URI Class Initialized
INFO - 2023-01-07 05:16:03 --> Router Class Initialized
INFO - 2023-01-07 05:16:03 --> Output Class Initialized
INFO - 2023-01-07 05:16:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:03 --> Input Class Initialized
INFO - 2023-01-07 05:16:03 --> Language Class Initialized
INFO - 2023-01-07 05:16:03 --> Language Class Initialized
INFO - 2023-01-07 05:16:03 --> Config Class Initialized
INFO - 2023-01-07 05:16:03 --> Loader Class Initialized
INFO - 2023-01-07 05:16:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:04 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:04 --> Controller Class Initialized
INFO - 2023-01-07 05:16:05 --> Config Class Initialized
INFO - 2023-01-07 05:16:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:05 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:05 --> URI Class Initialized
INFO - 2023-01-07 05:16:05 --> Router Class Initialized
INFO - 2023-01-07 05:16:05 --> Output Class Initialized
INFO - 2023-01-07 05:16:05 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:05 --> Input Class Initialized
INFO - 2023-01-07 05:16:05 --> Language Class Initialized
INFO - 2023-01-07 05:16:05 --> Language Class Initialized
INFO - 2023-01-07 05:16:05 --> Config Class Initialized
INFO - 2023-01-07 05:16:05 --> Loader Class Initialized
INFO - 2023-01-07 05:16:05 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:05 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:05 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:05 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:05 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-07 05:16:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:05 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:05 --> Total execution time: 0.0388
INFO - 2023-01-07 05:16:08 --> Config Class Initialized
INFO - 2023-01-07 05:16:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:08 --> URI Class Initialized
INFO - 2023-01-07 05:16:08 --> Router Class Initialized
INFO - 2023-01-07 05:16:08 --> Output Class Initialized
INFO - 2023-01-07 05:16:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:08 --> Input Class Initialized
INFO - 2023-01-07 05:16:08 --> Language Class Initialized
INFO - 2023-01-07 05:16:08 --> Language Class Initialized
INFO - 2023-01-07 05:16:08 --> Config Class Initialized
INFO - 2023-01-07 05:16:08 --> Loader Class Initialized
INFO - 2023-01-07 05:16:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:08 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 05:16:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:08 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:08 --> Total execution time: 0.0277
INFO - 2023-01-07 05:16:09 --> Config Class Initialized
INFO - 2023-01-07 05:16:09 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:09 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:09 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:09 --> URI Class Initialized
INFO - 2023-01-07 05:16:09 --> Router Class Initialized
INFO - 2023-01-07 05:16:09 --> Output Class Initialized
INFO - 2023-01-07 05:16:09 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:09 --> Input Class Initialized
INFO - 2023-01-07 05:16:09 --> Language Class Initialized
INFO - 2023-01-07 05:16:09 --> Language Class Initialized
INFO - 2023-01-07 05:16:09 --> Config Class Initialized
INFO - 2023-01-07 05:16:09 --> Loader Class Initialized
INFO - 2023-01-07 05:16:09 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:09 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:09 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:09 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:09 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:09 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:16:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:09 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:09 --> Total execution time: 0.0240
INFO - 2023-01-07 05:16:10 --> Config Class Initialized
INFO - 2023-01-07 05:16:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:10 --> URI Class Initialized
INFO - 2023-01-07 05:16:10 --> Router Class Initialized
INFO - 2023-01-07 05:16:10 --> Output Class Initialized
INFO - 2023-01-07 05:16:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:10 --> Input Class Initialized
INFO - 2023-01-07 05:16:10 --> Language Class Initialized
INFO - 2023-01-07 05:16:10 --> Language Class Initialized
INFO - 2023-01-07 05:16:10 --> Config Class Initialized
INFO - 2023-01-07 05:16:10 --> Loader Class Initialized
INFO - 2023-01-07 05:16:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:10 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:16:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:10 --> Total execution time: 0.0248
INFO - 2023-01-07 05:16:11 --> Config Class Initialized
INFO - 2023-01-07 05:16:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:11 --> URI Class Initialized
INFO - 2023-01-07 05:16:11 --> Router Class Initialized
INFO - 2023-01-07 05:16:11 --> Output Class Initialized
INFO - 2023-01-07 05:16:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:11 --> Input Class Initialized
INFO - 2023-01-07 05:16:11 --> Language Class Initialized
INFO - 2023-01-07 05:16:11 --> Language Class Initialized
INFO - 2023-01-07 05:16:11 --> Config Class Initialized
INFO - 2023-01-07 05:16:11 --> Loader Class Initialized
INFO - 2023-01-07 05:16:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:16:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:11 --> Total execution time: 0.0238
INFO - 2023-01-07 05:16:12 --> Config Class Initialized
INFO - 2023-01-07 05:16:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:12 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:12 --> URI Class Initialized
INFO - 2023-01-07 05:16:12 --> Router Class Initialized
INFO - 2023-01-07 05:16:12 --> Output Class Initialized
INFO - 2023-01-07 05:16:12 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:12 --> Input Class Initialized
INFO - 2023-01-07 05:16:12 --> Language Class Initialized
INFO - 2023-01-07 05:16:12 --> Language Class Initialized
INFO - 2023-01-07 05:16:12 --> Config Class Initialized
INFO - 2023-01-07 05:16:12 --> Loader Class Initialized
INFO - 2023-01-07 05:16:12 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:12 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:12 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:12 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:12 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 05:16:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:12 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:12 --> Total execution time: 0.0376
INFO - 2023-01-07 05:16:13 --> Config Class Initialized
INFO - 2023-01-07 05:16:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:13 --> URI Class Initialized
DEBUG - 2023-01-07 05:16:13 --> No URI present. Default controller set.
INFO - 2023-01-07 05:16:13 --> Router Class Initialized
INFO - 2023-01-07 05:16:13 --> Output Class Initialized
INFO - 2023-01-07 05:16:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:13 --> Input Class Initialized
INFO - 2023-01-07 05:16:13 --> Language Class Initialized
INFO - 2023-01-07 05:16:13 --> Language Class Initialized
INFO - 2023-01-07 05:16:13 --> Config Class Initialized
INFO - 2023-01-07 05:16:13 --> Loader Class Initialized
INFO - 2023-01-07 05:16:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:14 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 05:16:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:14 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:14 --> Total execution time: 0.0395
INFO - 2023-01-07 05:16:53 --> Config Class Initialized
INFO - 2023-01-07 05:16:53 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:53 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:53 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:53 --> URI Class Initialized
INFO - 2023-01-07 05:16:53 --> Router Class Initialized
INFO - 2023-01-07 05:16:53 --> Output Class Initialized
INFO - 2023-01-07 05:16:53 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:53 --> Input Class Initialized
INFO - 2023-01-07 05:16:53 --> Language Class Initialized
INFO - 2023-01-07 05:16:53 --> Language Class Initialized
INFO - 2023-01-07 05:16:53 --> Config Class Initialized
INFO - 2023-01-07 05:16:53 --> Loader Class Initialized
INFO - 2023-01-07 05:16:53 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:53 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:53 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:53 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:53 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-07 05:16:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:53 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:53 --> Total execution time: 0.0380
INFO - 2023-01-07 05:16:55 --> Config Class Initialized
INFO - 2023-01-07 05:16:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:55 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:55 --> URI Class Initialized
INFO - 2023-01-07 05:16:55 --> Router Class Initialized
INFO - 2023-01-07 05:16:55 --> Output Class Initialized
INFO - 2023-01-07 05:16:55 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:55 --> Input Class Initialized
INFO - 2023-01-07 05:16:55 --> Language Class Initialized
INFO - 2023-01-07 05:16:55 --> Language Class Initialized
INFO - 2023-01-07 05:16:55 --> Config Class Initialized
INFO - 2023-01-07 05:16:55 --> Loader Class Initialized
INFO - 2023-01-07 05:16:55 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:55 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:55 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:55 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:55 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:16:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:55 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:55 --> Total execution time: 0.0399
INFO - 2023-01-07 05:16:56 --> Config Class Initialized
INFO - 2023-01-07 05:16:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:16:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:16:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:16:56 --> URI Class Initialized
INFO - 2023-01-07 05:16:56 --> Router Class Initialized
INFO - 2023-01-07 05:16:56 --> Output Class Initialized
INFO - 2023-01-07 05:16:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:16:56 --> Input Class Initialized
INFO - 2023-01-07 05:16:56 --> Language Class Initialized
INFO - 2023-01-07 05:16:56 --> Language Class Initialized
INFO - 2023-01-07 05:16:56 --> Config Class Initialized
INFO - 2023-01-07 05:16:56 --> Loader Class Initialized
INFO - 2023-01-07 05:16:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:16:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:16:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:16:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:16:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:16:56 --> Controller Class Initialized
DEBUG - 2023-01-07 05:16:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:16:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:16:56 --> Final output sent to browser
DEBUG - 2023-01-07 05:16:56 --> Total execution time: 0.0255
INFO - 2023-01-07 05:17:03 --> Config Class Initialized
INFO - 2023-01-07 05:17:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:03 --> URI Class Initialized
INFO - 2023-01-07 05:17:03 --> Router Class Initialized
INFO - 2023-01-07 05:17:03 --> Output Class Initialized
INFO - 2023-01-07 05:17:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:03 --> Input Class Initialized
INFO - 2023-01-07 05:17:03 --> Language Class Initialized
INFO - 2023-01-07 05:17:03 --> Language Class Initialized
INFO - 2023-01-07 05:17:03 --> Config Class Initialized
INFO - 2023-01-07 05:17:03 --> Loader Class Initialized
INFO - 2023-01-07 05:17:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:04 --> Controller Class Initialized
DEBUG - 2023-01-07 05:17:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 05:17:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:17:04 --> Final output sent to browser
DEBUG - 2023-01-07 05:17:04 --> Total execution time: 0.0395
INFO - 2023-01-07 05:17:10 --> Config Class Initialized
INFO - 2023-01-07 05:17:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:10 --> URI Class Initialized
INFO - 2023-01-07 05:17:10 --> Router Class Initialized
INFO - 2023-01-07 05:17:10 --> Output Class Initialized
INFO - 2023-01-07 05:17:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:10 --> Input Class Initialized
INFO - 2023-01-07 05:17:10 --> Language Class Initialized
INFO - 2023-01-07 05:17:10 --> Language Class Initialized
INFO - 2023-01-07 05:17:10 --> Config Class Initialized
INFO - 2023-01-07 05:17:10 --> Loader Class Initialized
INFO - 2023-01-07 05:17:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:10 --> Controller Class Initialized
DEBUG - 2023-01-07 05:17:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_leger/views/landing.php
DEBUG - 2023-01-07 05:17:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:17:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:17:10 --> Total execution time: 0.0386
INFO - 2023-01-07 05:17:12 --> Config Class Initialized
INFO - 2023-01-07 05:17:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:12 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:12 --> URI Class Initialized
INFO - 2023-01-07 05:17:12 --> Router Class Initialized
INFO - 2023-01-07 05:17:12 --> Output Class Initialized
INFO - 2023-01-07 05:17:12 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:12 --> Input Class Initialized
INFO - 2023-01-07 05:17:12 --> Language Class Initialized
INFO - 2023-01-07 05:17:12 --> Language Class Initialized
INFO - 2023-01-07 05:17:12 --> Config Class Initialized
INFO - 2023-01-07 05:17:12 --> Loader Class Initialized
INFO - 2023-01-07 05:17:12 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:12 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:12 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:12 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:12 --> Controller Class Initialized
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 136
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 136
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 136
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 136
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 137
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
ERROR - 2023-01-07 05:17:12 --> Severity: Warning --> A non-numeric value encountered C:\xampp\htdocs\myraportk13\application\modules\cetak_leger\controllers\Cetak_leger.php 138
DEBUG - 2023-01-07 05:17:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_leger/views/cetak.php
INFO - 2023-01-07 05:17:12 --> Final output sent to browser
DEBUG - 2023-01-07 05:17:12 --> Total execution time: 0.0566
INFO - 2023-01-07 05:17:28 --> Config Class Initialized
INFO - 2023-01-07 05:17:28 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:28 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:28 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:28 --> URI Class Initialized
INFO - 2023-01-07 05:17:28 --> Router Class Initialized
INFO - 2023-01-07 05:17:28 --> Output Class Initialized
INFO - 2023-01-07 05:17:28 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:28 --> Input Class Initialized
INFO - 2023-01-07 05:17:28 --> Language Class Initialized
INFO - 2023-01-07 05:17:28 --> Language Class Initialized
INFO - 2023-01-07 05:17:28 --> Config Class Initialized
INFO - 2023-01-07 05:17:28 --> Loader Class Initialized
INFO - 2023-01-07 05:17:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:29 --> Controller Class Initialized
DEBUG - 2023-01-07 05:17:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2023-01-07 05:17:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:17:29 --> Total execution time: 0.0332
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:52 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:52 --> URI Class Initialized
INFO - 2023-01-07 05:17:52 --> Router Class Initialized
INFO - 2023-01-07 05:17:52 --> Output Class Initialized
INFO - 2023-01-07 05:17:52 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:52 --> Input Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Loader Class Initialized
INFO - 2023-01-07 05:17:52 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:52 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:52 --> Controller Class Initialized
INFO - 2023-01-07 05:17:52 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:52 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:52 --> URI Class Initialized
INFO - 2023-01-07 05:17:52 --> Router Class Initialized
INFO - 2023-01-07 05:17:52 --> Output Class Initialized
INFO - 2023-01-07 05:17:52 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:52 --> Input Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Loader Class Initialized
INFO - 2023-01-07 05:17:52 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:52 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:52 --> Controller Class Initialized
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:17:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:17:52 --> Utf8 Class Initialized
INFO - 2023-01-07 05:17:52 --> URI Class Initialized
INFO - 2023-01-07 05:17:52 --> Router Class Initialized
INFO - 2023-01-07 05:17:52 --> Output Class Initialized
INFO - 2023-01-07 05:17:52 --> Security Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:17:52 --> Input Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Language Class Initialized
INFO - 2023-01-07 05:17:52 --> Config Class Initialized
INFO - 2023-01-07 05:17:52 --> Loader Class Initialized
INFO - 2023-01-07 05:17:52 --> Helper loaded: url_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: file_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: form_helper
INFO - 2023-01-07 05:17:52 --> Helper loaded: my_helper
INFO - 2023-01-07 05:17:52 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:17:52 --> Controller Class Initialized
DEBUG - 2023-01-07 05:17:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:17:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:17:52 --> Final output sent to browser
DEBUG - 2023-01-07 05:17:52 --> Total execution time: 0.0412
INFO - 2023-01-07 05:18:03 --> Config Class Initialized
INFO - 2023-01-07 05:18:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:03 --> URI Class Initialized
INFO - 2023-01-07 05:18:03 --> Router Class Initialized
INFO - 2023-01-07 05:18:03 --> Output Class Initialized
INFO - 2023-01-07 05:18:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:03 --> Input Class Initialized
INFO - 2023-01-07 05:18:03 --> Language Class Initialized
INFO - 2023-01-07 05:18:03 --> Language Class Initialized
INFO - 2023-01-07 05:18:03 --> Config Class Initialized
INFO - 2023-01-07 05:18:03 --> Loader Class Initialized
INFO - 2023-01-07 05:18:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:03 --> Controller Class Initialized
INFO - 2023-01-07 05:18:03 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:18:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:03 --> Total execution time: 0.0344
INFO - 2023-01-07 05:18:03 --> Config Class Initialized
INFO - 2023-01-07 05:18:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:03 --> URI Class Initialized
INFO - 2023-01-07 05:18:03 --> Router Class Initialized
INFO - 2023-01-07 05:18:03 --> Output Class Initialized
INFO - 2023-01-07 05:18:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:03 --> Input Class Initialized
INFO - 2023-01-07 05:18:03 --> Language Class Initialized
INFO - 2023-01-07 05:18:03 --> Language Class Initialized
INFO - 2023-01-07 05:18:03 --> Config Class Initialized
INFO - 2023-01-07 05:18:03 --> Loader Class Initialized
INFO - 2023-01-07 05:18:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:03 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 05:18:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:03 --> Total execution time: 0.0392
INFO - 2023-01-07 05:18:11 --> Config Class Initialized
INFO - 2023-01-07 05:18:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:11 --> URI Class Initialized
INFO - 2023-01-07 05:18:11 --> Router Class Initialized
INFO - 2023-01-07 05:18:11 --> Output Class Initialized
INFO - 2023-01-07 05:18:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:11 --> Input Class Initialized
INFO - 2023-01-07 05:18:11 --> Language Class Initialized
INFO - 2023-01-07 05:18:11 --> Language Class Initialized
INFO - 2023-01-07 05:18:11 --> Config Class Initialized
INFO - 2023-01-07 05:18:11 --> Loader Class Initialized
INFO - 2023-01-07 05:18:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-01-07 05:18:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:11 --> Total execution time: 0.0259
INFO - 2023-01-07 05:18:11 --> Config Class Initialized
INFO - 2023-01-07 05:18:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:11 --> URI Class Initialized
INFO - 2023-01-07 05:18:11 --> Router Class Initialized
INFO - 2023-01-07 05:18:11 --> Output Class Initialized
INFO - 2023-01-07 05:18:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:11 --> Input Class Initialized
INFO - 2023-01-07 05:18:11 --> Language Class Initialized
INFO - 2023-01-07 05:18:11 --> Language Class Initialized
INFO - 2023-01-07 05:18:11 --> Config Class Initialized
INFO - 2023-01-07 05:18:11 --> Loader Class Initialized
INFO - 2023-01-07 05:18:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:11 --> Controller Class Initialized
INFO - 2023-01-07 05:18:13 --> Config Class Initialized
INFO - 2023-01-07 05:18:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:13 --> URI Class Initialized
INFO - 2023-01-07 05:18:13 --> Router Class Initialized
INFO - 2023-01-07 05:18:13 --> Output Class Initialized
INFO - 2023-01-07 05:18:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:13 --> Input Class Initialized
INFO - 2023-01-07 05:18:13 --> Language Class Initialized
INFO - 2023-01-07 05:18:13 --> Language Class Initialized
INFO - 2023-01-07 05:18:13 --> Config Class Initialized
INFO - 2023-01-07 05:18:13 --> Loader Class Initialized
INFO - 2023-01-07 05:18:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:13 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:18:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:13 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:13 --> Total execution time: 0.0262
INFO - 2023-01-07 05:18:16 --> Config Class Initialized
INFO - 2023-01-07 05:18:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:16 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:16 --> URI Class Initialized
INFO - 2023-01-07 05:18:16 --> Router Class Initialized
INFO - 2023-01-07 05:18:16 --> Output Class Initialized
INFO - 2023-01-07 05:18:16 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:16 --> Input Class Initialized
INFO - 2023-01-07 05:18:16 --> Language Class Initialized
INFO - 2023-01-07 05:18:16 --> Language Class Initialized
INFO - 2023-01-07 05:18:16 --> Config Class Initialized
INFO - 2023-01-07 05:18:16 --> Loader Class Initialized
INFO - 2023-01-07 05:18:16 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:16 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:16 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:16 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:16 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:18:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:16 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:16 --> Total execution time: 0.0549
INFO - 2023-01-07 05:18:47 --> Config Class Initialized
INFO - 2023-01-07 05:18:47 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:47 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:47 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:47 --> URI Class Initialized
INFO - 2023-01-07 05:18:47 --> Router Class Initialized
INFO - 2023-01-07 05:18:47 --> Output Class Initialized
INFO - 2023-01-07 05:18:47 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:47 --> Input Class Initialized
INFO - 2023-01-07 05:18:47 --> Language Class Initialized
INFO - 2023-01-07 05:18:47 --> Language Class Initialized
INFO - 2023-01-07 05:18:47 --> Config Class Initialized
INFO - 2023-01-07 05:18:47 --> Loader Class Initialized
INFO - 2023-01-07 05:18:47 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:47 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:47 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:47 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:47 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:47 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:18:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:47 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:47 --> Total execution time: 0.0589
INFO - 2023-01-07 05:18:59 --> Config Class Initialized
INFO - 2023-01-07 05:18:59 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:18:59 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:18:59 --> Utf8 Class Initialized
INFO - 2023-01-07 05:18:59 --> URI Class Initialized
INFO - 2023-01-07 05:18:59 --> Router Class Initialized
INFO - 2023-01-07 05:18:59 --> Output Class Initialized
INFO - 2023-01-07 05:18:59 --> Security Class Initialized
DEBUG - 2023-01-07 05:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:18:59 --> Input Class Initialized
INFO - 2023-01-07 05:18:59 --> Language Class Initialized
INFO - 2023-01-07 05:18:59 --> Language Class Initialized
INFO - 2023-01-07 05:18:59 --> Config Class Initialized
INFO - 2023-01-07 05:18:59 --> Loader Class Initialized
INFO - 2023-01-07 05:18:59 --> Helper loaded: url_helper
INFO - 2023-01-07 05:18:59 --> Helper loaded: file_helper
INFO - 2023-01-07 05:18:59 --> Helper loaded: form_helper
INFO - 2023-01-07 05:18:59 --> Helper loaded: my_helper
INFO - 2023-01-07 05:18:59 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:18:59 --> Controller Class Initialized
DEBUG - 2023-01-07 05:18:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:18:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:18:59 --> Final output sent to browser
DEBUG - 2023-01-07 05:18:59 --> Total execution time: 0.0432
INFO - 2023-01-07 05:19:43 --> Config Class Initialized
INFO - 2023-01-07 05:19:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:19:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:19:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:19:43 --> URI Class Initialized
INFO - 2023-01-07 05:19:43 --> Router Class Initialized
INFO - 2023-01-07 05:19:43 --> Output Class Initialized
INFO - 2023-01-07 05:19:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:19:43 --> Input Class Initialized
INFO - 2023-01-07 05:19:43 --> Language Class Initialized
INFO - 2023-01-07 05:19:43 --> Language Class Initialized
INFO - 2023-01-07 05:19:43 --> Config Class Initialized
INFO - 2023-01-07 05:19:43 --> Loader Class Initialized
INFO - 2023-01-07 05:19:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:19:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:19:43 --> Controller Class Initialized
DEBUG - 2023-01-07 05:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/tahun/views/list.php
DEBUG - 2023-01-07 05:19:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:19:43 --> Final output sent to browser
DEBUG - 2023-01-07 05:19:43 --> Total execution time: 0.0368
INFO - 2023-01-07 05:19:43 --> Config Class Initialized
INFO - 2023-01-07 05:19:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:19:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:19:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:19:43 --> URI Class Initialized
INFO - 2023-01-07 05:19:43 --> Router Class Initialized
INFO - 2023-01-07 05:19:43 --> Output Class Initialized
INFO - 2023-01-07 05:19:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:19:43 --> Input Class Initialized
INFO - 2023-01-07 05:19:43 --> Language Class Initialized
INFO - 2023-01-07 05:19:43 --> Language Class Initialized
INFO - 2023-01-07 05:19:43 --> Config Class Initialized
INFO - 2023-01-07 05:19:43 --> Loader Class Initialized
INFO - 2023-01-07 05:19:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:19:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:19:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:19:43 --> Controller Class Initialized
INFO - 2023-01-07 05:19:48 --> Config Class Initialized
INFO - 2023-01-07 05:19:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:19:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:19:48 --> Utf8 Class Initialized
INFO - 2023-01-07 05:19:48 --> URI Class Initialized
INFO - 2023-01-07 05:19:48 --> Router Class Initialized
INFO - 2023-01-07 05:19:48 --> Output Class Initialized
INFO - 2023-01-07 05:19:48 --> Security Class Initialized
DEBUG - 2023-01-07 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:19:48 --> Input Class Initialized
INFO - 2023-01-07 05:19:48 --> Language Class Initialized
INFO - 2023-01-07 05:19:48 --> Language Class Initialized
INFO - 2023-01-07 05:19:48 --> Config Class Initialized
INFO - 2023-01-07 05:19:48 --> Loader Class Initialized
INFO - 2023-01-07 05:19:48 --> Helper loaded: url_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: file_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: form_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: my_helper
INFO - 2023-01-07 05:19:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:19:48 --> Controller Class Initialized
INFO - 2023-01-07 05:19:48 --> Final output sent to browser
DEBUG - 2023-01-07 05:19:48 --> Total execution time: 0.0256
INFO - 2023-01-07 05:19:48 --> Config Class Initialized
INFO - 2023-01-07 05:19:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:19:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:19:48 --> Utf8 Class Initialized
INFO - 2023-01-07 05:19:48 --> URI Class Initialized
INFO - 2023-01-07 05:19:48 --> Router Class Initialized
INFO - 2023-01-07 05:19:48 --> Output Class Initialized
INFO - 2023-01-07 05:19:48 --> Security Class Initialized
DEBUG - 2023-01-07 05:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:19:48 --> Input Class Initialized
INFO - 2023-01-07 05:19:48 --> Language Class Initialized
INFO - 2023-01-07 05:19:48 --> Language Class Initialized
INFO - 2023-01-07 05:19:48 --> Config Class Initialized
INFO - 2023-01-07 05:19:48 --> Loader Class Initialized
INFO - 2023-01-07 05:19:48 --> Helper loaded: url_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: file_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: form_helper
INFO - 2023-01-07 05:19:48 --> Helper loaded: my_helper
INFO - 2023-01-07 05:19:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:19:48 --> Controller Class Initialized
INFO - 2023-01-07 05:19:50 --> Config Class Initialized
INFO - 2023-01-07 05:19:50 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:19:50 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:19:50 --> Utf8 Class Initialized
INFO - 2023-01-07 05:19:50 --> URI Class Initialized
INFO - 2023-01-07 05:19:50 --> Router Class Initialized
INFO - 2023-01-07 05:19:50 --> Output Class Initialized
INFO - 2023-01-07 05:19:50 --> Security Class Initialized
DEBUG - 2023-01-07 05:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:19:50 --> Input Class Initialized
INFO - 2023-01-07 05:19:50 --> Language Class Initialized
INFO - 2023-01-07 05:19:50 --> Language Class Initialized
INFO - 2023-01-07 05:19:50 --> Config Class Initialized
INFO - 2023-01-07 05:19:50 --> Loader Class Initialized
INFO - 2023-01-07 05:19:50 --> Helper loaded: url_helper
INFO - 2023-01-07 05:19:50 --> Helper loaded: file_helper
INFO - 2023-01-07 05:19:50 --> Helper loaded: form_helper
INFO - 2023-01-07 05:19:50 --> Helper loaded: my_helper
INFO - 2023-01-07 05:19:50 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:19:50 --> Controller Class Initialized
INFO - 2023-01-07 05:19:50 --> Final output sent to browser
DEBUG - 2023-01-07 05:19:50 --> Total execution time: 0.0294
INFO - 2023-01-07 05:20:00 --> Config Class Initialized
INFO - 2023-01-07 05:20:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:00 --> URI Class Initialized
INFO - 2023-01-07 05:20:00 --> Router Class Initialized
INFO - 2023-01-07 05:20:00 --> Output Class Initialized
INFO - 2023-01-07 05:20:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:00 --> Input Class Initialized
INFO - 2023-01-07 05:20:00 --> Language Class Initialized
INFO - 2023-01-07 05:20:00 --> Language Class Initialized
INFO - 2023-01-07 05:20:00 --> Config Class Initialized
INFO - 2023-01-07 05:20:00 --> Loader Class Initialized
INFO - 2023-01-07 05:20:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:00 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_ekstra/views/list.php
DEBUG - 2023-01-07 05:20:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:00 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:00 --> Total execution time: 0.0381
INFO - 2023-01-07 05:20:00 --> Config Class Initialized
INFO - 2023-01-07 05:20:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:00 --> URI Class Initialized
INFO - 2023-01-07 05:20:00 --> Router Class Initialized
INFO - 2023-01-07 05:20:00 --> Output Class Initialized
INFO - 2023-01-07 05:20:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:00 --> Input Class Initialized
INFO - 2023-01-07 05:20:00 --> Language Class Initialized
INFO - 2023-01-07 05:20:00 --> Language Class Initialized
INFO - 2023-01-07 05:20:00 --> Config Class Initialized
INFO - 2023-01-07 05:20:00 --> Loader Class Initialized
INFO - 2023-01-07 05:20:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:00 --> Controller Class Initialized
INFO - 2023-01-07 05:20:03 --> Config Class Initialized
INFO - 2023-01-07 05:20:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:03 --> URI Class Initialized
INFO - 2023-01-07 05:20:03 --> Router Class Initialized
INFO - 2023-01-07 05:20:03 --> Output Class Initialized
INFO - 2023-01-07 05:20:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:03 --> Input Class Initialized
INFO - 2023-01-07 05:20:03 --> Language Class Initialized
INFO - 2023-01-07 05:20:03 --> Language Class Initialized
INFO - 2023-01-07 05:20:03 --> Config Class Initialized
INFO - 2023-01-07 05:20:03 --> Loader Class Initialized
INFO - 2023-01-07 05:20:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:03 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-01-07 05:20:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:03 --> Total execution time: 0.0397
INFO - 2023-01-07 05:20:03 --> Config Class Initialized
INFO - 2023-01-07 05:20:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:03 --> URI Class Initialized
INFO - 2023-01-07 05:20:03 --> Router Class Initialized
INFO - 2023-01-07 05:20:03 --> Output Class Initialized
INFO - 2023-01-07 05:20:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:03 --> Input Class Initialized
INFO - 2023-01-07 05:20:03 --> Language Class Initialized
INFO - 2023-01-07 05:20:03 --> Language Class Initialized
INFO - 2023-01-07 05:20:03 --> Config Class Initialized
INFO - 2023-01-07 05:20:03 --> Loader Class Initialized
INFO - 2023-01-07 05:20:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:03 --> Controller Class Initialized
INFO - 2023-01-07 05:20:08 --> Config Class Initialized
INFO - 2023-01-07 05:20:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:08 --> URI Class Initialized
INFO - 2023-01-07 05:20:08 --> Router Class Initialized
INFO - 2023-01-07 05:20:08 --> Output Class Initialized
INFO - 2023-01-07 05:20:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:08 --> Input Class Initialized
INFO - 2023-01-07 05:20:08 --> Language Class Initialized
INFO - 2023-01-07 05:20:08 --> Language Class Initialized
INFO - 2023-01-07 05:20:08 --> Config Class Initialized
INFO - 2023-01-07 05:20:08 --> Loader Class Initialized
INFO - 2023-01-07 05:20:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:08 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_ekstra/views/list.php
DEBUG - 2023-01-07 05:20:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:08 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:08 --> Total execution time: 0.0374
INFO - 2023-01-07 05:20:08 --> Config Class Initialized
INFO - 2023-01-07 05:20:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:08 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:08 --> URI Class Initialized
INFO - 2023-01-07 05:20:08 --> Router Class Initialized
INFO - 2023-01-07 05:20:08 --> Output Class Initialized
INFO - 2023-01-07 05:20:08 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:08 --> Input Class Initialized
INFO - 2023-01-07 05:20:08 --> Language Class Initialized
INFO - 2023-01-07 05:20:08 --> Language Class Initialized
INFO - 2023-01-07 05:20:08 --> Config Class Initialized
INFO - 2023-01-07 05:20:08 --> Loader Class Initialized
INFO - 2023-01-07 05:20:08 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:08 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:08 --> Controller Class Initialized
INFO - 2023-01-07 05:20:10 --> Config Class Initialized
INFO - 2023-01-07 05:20:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:10 --> URI Class Initialized
INFO - 2023-01-07 05:20:10 --> Router Class Initialized
INFO - 2023-01-07 05:20:10 --> Output Class Initialized
INFO - 2023-01-07 05:20:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:10 --> Input Class Initialized
INFO - 2023-01-07 05:20:10 --> Language Class Initialized
INFO - 2023-01-07 05:20:10 --> Language Class Initialized
INFO - 2023-01-07 05:20:10 --> Config Class Initialized
INFO - 2023-01-07 05:20:10 --> Loader Class Initialized
INFO - 2023-01-07 05:20:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:10 --> Controller Class Initialized
INFO - 2023-01-07 05:20:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:10 --> Total execution time: 0.0332
INFO - 2023-01-07 05:20:12 --> Config Class Initialized
INFO - 2023-01-07 05:20:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:12 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:12 --> URI Class Initialized
INFO - 2023-01-07 05:20:12 --> Router Class Initialized
INFO - 2023-01-07 05:20:12 --> Output Class Initialized
INFO - 2023-01-07 05:20:12 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:12 --> Input Class Initialized
INFO - 2023-01-07 05:20:12 --> Language Class Initialized
INFO - 2023-01-07 05:20:12 --> Language Class Initialized
INFO - 2023-01-07 05:20:12 --> Config Class Initialized
INFO - 2023-01-07 05:20:12 --> Loader Class Initialized
INFO - 2023-01-07 05:20:12 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:12 --> Controller Class Initialized
INFO - 2023-01-07 05:20:12 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:12 --> Total execution time: 0.0386
INFO - 2023-01-07 05:20:12 --> Config Class Initialized
INFO - 2023-01-07 05:20:12 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:12 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:12 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:12 --> URI Class Initialized
INFO - 2023-01-07 05:20:12 --> Router Class Initialized
INFO - 2023-01-07 05:20:12 --> Output Class Initialized
INFO - 2023-01-07 05:20:12 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:12 --> Input Class Initialized
INFO - 2023-01-07 05:20:12 --> Language Class Initialized
INFO - 2023-01-07 05:20:12 --> Language Class Initialized
INFO - 2023-01-07 05:20:12 --> Config Class Initialized
INFO - 2023-01-07 05:20:12 --> Loader Class Initialized
INFO - 2023-01-07 05:20:12 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:12 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:12 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:12 --> Controller Class Initialized
INFO - 2023-01-07 05:20:14 --> Config Class Initialized
INFO - 2023-01-07 05:20:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:14 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:14 --> URI Class Initialized
INFO - 2023-01-07 05:20:14 --> Router Class Initialized
INFO - 2023-01-07 05:20:14 --> Output Class Initialized
INFO - 2023-01-07 05:20:14 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:14 --> Input Class Initialized
INFO - 2023-01-07 05:20:14 --> Language Class Initialized
INFO - 2023-01-07 05:20:14 --> Language Class Initialized
INFO - 2023-01-07 05:20:14 --> Config Class Initialized
INFO - 2023-01-07 05:20:14 --> Loader Class Initialized
INFO - 2023-01-07 05:20:14 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:14 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:14 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:14 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:14 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:14 --> Controller Class Initialized
INFO - 2023-01-07 05:20:14 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:14 --> Total execution time: 0.0255
INFO - 2023-01-07 05:20:15 --> Config Class Initialized
INFO - 2023-01-07 05:20:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:15 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:15 --> URI Class Initialized
INFO - 2023-01-07 05:20:15 --> Router Class Initialized
INFO - 2023-01-07 05:20:15 --> Output Class Initialized
INFO - 2023-01-07 05:20:15 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:15 --> Input Class Initialized
INFO - 2023-01-07 05:20:15 --> Language Class Initialized
INFO - 2023-01-07 05:20:15 --> Language Class Initialized
INFO - 2023-01-07 05:20:15 --> Config Class Initialized
INFO - 2023-01-07 05:20:15 --> Loader Class Initialized
INFO - 2023-01-07 05:20:15 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:15 --> Controller Class Initialized
INFO - 2023-01-07 05:20:15 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:15 --> Total execution time: 0.0406
INFO - 2023-01-07 05:20:15 --> Config Class Initialized
INFO - 2023-01-07 05:20:15 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:15 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:15 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:15 --> URI Class Initialized
INFO - 2023-01-07 05:20:15 --> Router Class Initialized
INFO - 2023-01-07 05:20:15 --> Output Class Initialized
INFO - 2023-01-07 05:20:15 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:15 --> Input Class Initialized
INFO - 2023-01-07 05:20:15 --> Language Class Initialized
INFO - 2023-01-07 05:20:15 --> Language Class Initialized
INFO - 2023-01-07 05:20:15 --> Config Class Initialized
INFO - 2023-01-07 05:20:15 --> Loader Class Initialized
INFO - 2023-01-07 05:20:15 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:15 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:15 --> Controller Class Initialized
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:19 --> URI Class Initialized
INFO - 2023-01-07 05:20:19 --> Router Class Initialized
INFO - 2023-01-07 05:20:19 --> Output Class Initialized
INFO - 2023-01-07 05:20:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:19 --> Input Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Loader Class Initialized
INFO - 2023-01-07 05:20:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:19 --> Controller Class Initialized
INFO - 2023-01-07 05:20:19 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:19 --> URI Class Initialized
INFO - 2023-01-07 05:20:19 --> Router Class Initialized
INFO - 2023-01-07 05:20:19 --> Output Class Initialized
INFO - 2023-01-07 05:20:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:19 --> Input Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Loader Class Initialized
INFO - 2023-01-07 05:20:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:19 --> Controller Class Initialized
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:19 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:19 --> URI Class Initialized
INFO - 2023-01-07 05:20:19 --> Router Class Initialized
INFO - 2023-01-07 05:20:19 --> Output Class Initialized
INFO - 2023-01-07 05:20:19 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:19 --> Input Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Language Class Initialized
INFO - 2023-01-07 05:20:19 --> Config Class Initialized
INFO - 2023-01-07 05:20:19 --> Loader Class Initialized
INFO - 2023-01-07 05:20:19 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:19 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:19 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:20:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:19 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:19 --> Total execution time: 0.0466
INFO - 2023-01-07 05:20:24 --> Config Class Initialized
INFO - 2023-01-07 05:20:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:24 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:24 --> URI Class Initialized
INFO - 2023-01-07 05:20:24 --> Router Class Initialized
INFO - 2023-01-07 05:20:24 --> Output Class Initialized
INFO - 2023-01-07 05:20:24 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:24 --> Input Class Initialized
INFO - 2023-01-07 05:20:24 --> Language Class Initialized
INFO - 2023-01-07 05:20:24 --> Language Class Initialized
INFO - 2023-01-07 05:20:24 --> Config Class Initialized
INFO - 2023-01-07 05:20:24 --> Loader Class Initialized
INFO - 2023-01-07 05:20:24 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:24 --> Controller Class Initialized
INFO - 2023-01-07 05:20:24 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:20:24 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:24 --> Total execution time: 0.0350
INFO - 2023-01-07 05:20:24 --> Config Class Initialized
INFO - 2023-01-07 05:20:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:24 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:24 --> URI Class Initialized
INFO - 2023-01-07 05:20:24 --> Router Class Initialized
INFO - 2023-01-07 05:20:24 --> Output Class Initialized
INFO - 2023-01-07 05:20:24 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:24 --> Input Class Initialized
INFO - 2023-01-07 05:20:24 --> Language Class Initialized
INFO - 2023-01-07 05:20:24 --> Language Class Initialized
INFO - 2023-01-07 05:20:24 --> Config Class Initialized
INFO - 2023-01-07 05:20:24 --> Loader Class Initialized
INFO - 2023-01-07 05:20:24 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:24 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:24 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 05:20:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:24 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:24 --> Total execution time: 0.0385
INFO - 2023-01-07 05:20:28 --> Config Class Initialized
INFO - 2023-01-07 05:20:28 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:28 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:28 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:28 --> URI Class Initialized
INFO - 2023-01-07 05:20:28 --> Router Class Initialized
INFO - 2023-01-07 05:20:28 --> Output Class Initialized
INFO - 2023-01-07 05:20:28 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:28 --> Input Class Initialized
INFO - 2023-01-07 05:20:28 --> Language Class Initialized
INFO - 2023-01-07 05:20:28 --> Language Class Initialized
INFO - 2023-01-07 05:20:28 --> Config Class Initialized
INFO - 2023-01-07 05:20:28 --> Loader Class Initialized
INFO - 2023-01-07 05:20:28 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:28 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:28 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:28 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:28 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:28 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:20:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:28 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:28 --> Total execution time: 0.0259
INFO - 2023-01-07 05:20:30 --> Config Class Initialized
INFO - 2023-01-07 05:20:30 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:30 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:30 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:30 --> URI Class Initialized
INFO - 2023-01-07 05:20:30 --> Router Class Initialized
INFO - 2023-01-07 05:20:30 --> Output Class Initialized
INFO - 2023-01-07 05:20:30 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:30 --> Input Class Initialized
INFO - 2023-01-07 05:20:30 --> Language Class Initialized
INFO - 2023-01-07 05:20:30 --> Language Class Initialized
INFO - 2023-01-07 05:20:30 --> Config Class Initialized
INFO - 2023-01-07 05:20:30 --> Loader Class Initialized
INFO - 2023-01-07 05:20:30 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:30 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:30 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:30 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:30 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:30 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:20:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:30 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:30 --> Total execution time: 0.0385
INFO - 2023-01-07 05:20:33 --> Config Class Initialized
INFO - 2023-01-07 05:20:33 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:33 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:33 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:33 --> URI Class Initialized
INFO - 2023-01-07 05:20:33 --> Router Class Initialized
INFO - 2023-01-07 05:20:33 --> Output Class Initialized
INFO - 2023-01-07 05:20:33 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:33 --> Input Class Initialized
INFO - 2023-01-07 05:20:33 --> Language Class Initialized
INFO - 2023-01-07 05:20:33 --> Language Class Initialized
INFO - 2023-01-07 05:20:33 --> Config Class Initialized
INFO - 2023-01-07 05:20:33 --> Loader Class Initialized
INFO - 2023-01-07 05:20:33 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:33 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:33 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:33 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:33 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:33 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:20:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:33 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:33 --> Total execution time: 0.0253
INFO - 2023-01-07 05:20:34 --> Config Class Initialized
INFO - 2023-01-07 05:20:34 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:34 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:34 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:34 --> URI Class Initialized
INFO - 2023-01-07 05:20:34 --> Router Class Initialized
INFO - 2023-01-07 05:20:34 --> Output Class Initialized
INFO - 2023-01-07 05:20:34 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:34 --> Input Class Initialized
INFO - 2023-01-07 05:20:34 --> Language Class Initialized
INFO - 2023-01-07 05:20:34 --> Language Class Initialized
INFO - 2023-01-07 05:20:34 --> Config Class Initialized
INFO - 2023-01-07 05:20:34 --> Loader Class Initialized
INFO - 2023-01-07 05:20:34 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:34 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:34 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:34 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:34 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:34 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-07 05:20:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:34 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:34 --> Total execution time: 0.0242
INFO - 2023-01-07 05:20:36 --> Config Class Initialized
INFO - 2023-01-07 05:20:36 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:36 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:36 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:36 --> URI Class Initialized
INFO - 2023-01-07 05:20:36 --> Router Class Initialized
INFO - 2023-01-07 05:20:36 --> Output Class Initialized
INFO - 2023-01-07 05:20:36 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:36 --> Input Class Initialized
INFO - 2023-01-07 05:20:36 --> Language Class Initialized
INFO - 2023-01-07 05:20:36 --> Language Class Initialized
INFO - 2023-01-07 05:20:36 --> Config Class Initialized
INFO - 2023-01-07 05:20:36 --> Loader Class Initialized
INFO - 2023-01-07 05:20:36 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:36 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:36 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:36 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:36 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:36 --> Controller Class Initialized
INFO - 2023-01-07 05:20:36 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:36 --> Total execution time: 0.0242
INFO - 2023-01-07 05:20:37 --> Config Class Initialized
INFO - 2023-01-07 05:20:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:37 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:37 --> URI Class Initialized
INFO - 2023-01-07 05:20:37 --> Router Class Initialized
INFO - 2023-01-07 05:20:37 --> Output Class Initialized
INFO - 2023-01-07 05:20:37 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:37 --> Input Class Initialized
INFO - 2023-01-07 05:20:37 --> Language Class Initialized
INFO - 2023-01-07 05:20:37 --> Language Class Initialized
INFO - 2023-01-07 05:20:37 --> Config Class Initialized
INFO - 2023-01-07 05:20:37 --> Loader Class Initialized
INFO - 2023-01-07 05:20:37 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:37 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:37 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:37 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:37 --> Controller Class Initialized
INFO - 2023-01-07 05:20:37 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:37 --> Total execution time: 0.0436
INFO - 2023-01-07 05:20:39 --> Config Class Initialized
INFO - 2023-01-07 05:20:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:39 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:39 --> URI Class Initialized
INFO - 2023-01-07 05:20:39 --> Router Class Initialized
INFO - 2023-01-07 05:20:39 --> Output Class Initialized
INFO - 2023-01-07 05:20:39 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:39 --> Input Class Initialized
INFO - 2023-01-07 05:20:39 --> Language Class Initialized
INFO - 2023-01-07 05:20:39 --> Language Class Initialized
INFO - 2023-01-07 05:20:39 --> Config Class Initialized
INFO - 2023-01-07 05:20:39 --> Loader Class Initialized
INFO - 2023-01-07 05:20:39 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:39 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:39 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:39 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:39 --> Controller Class Initialized
INFO - 2023-01-07 05:20:39 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:39 --> Total execution time: 0.0440
INFO - 2023-01-07 05:20:44 --> Config Class Initialized
INFO - 2023-01-07 05:20:44 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:44 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:44 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:44 --> URI Class Initialized
INFO - 2023-01-07 05:20:44 --> Router Class Initialized
INFO - 2023-01-07 05:20:44 --> Output Class Initialized
INFO - 2023-01-07 05:20:44 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:44 --> Input Class Initialized
INFO - 2023-01-07 05:20:44 --> Language Class Initialized
INFO - 2023-01-07 05:20:44 --> Language Class Initialized
INFO - 2023-01-07 05:20:44 --> Config Class Initialized
INFO - 2023-01-07 05:20:44 --> Loader Class Initialized
INFO - 2023-01-07 05:20:44 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:44 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:44 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:44 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:44 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:44 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:20:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:44 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:44 --> Total execution time: 0.0408
INFO - 2023-01-07 05:20:53 --> Config Class Initialized
INFO - 2023-01-07 05:20:53 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:53 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:53 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:53 --> URI Class Initialized
INFO - 2023-01-07 05:20:53 --> Router Class Initialized
INFO - 2023-01-07 05:20:53 --> Output Class Initialized
INFO - 2023-01-07 05:20:53 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:53 --> Input Class Initialized
INFO - 2023-01-07 05:20:53 --> Language Class Initialized
INFO - 2023-01-07 05:20:53 --> Language Class Initialized
INFO - 2023-01-07 05:20:53 --> Config Class Initialized
INFO - 2023-01-07 05:20:53 --> Loader Class Initialized
INFO - 2023-01-07 05:20:53 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:53 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:53 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:53 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:53 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:20:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:53 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:53 --> Total execution time: 0.0264
INFO - 2023-01-07 05:20:56 --> Config Class Initialized
INFO - 2023-01-07 05:20:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:56 --> URI Class Initialized
INFO - 2023-01-07 05:20:56 --> Router Class Initialized
INFO - 2023-01-07 05:20:56 --> Output Class Initialized
INFO - 2023-01-07 05:20:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:56 --> Input Class Initialized
INFO - 2023-01-07 05:20:56 --> Language Class Initialized
INFO - 2023-01-07 05:20:56 --> Language Class Initialized
INFO - 2023-01-07 05:20:56 --> Config Class Initialized
INFO - 2023-01-07 05:20:56 --> Loader Class Initialized
INFO - 2023-01-07 05:20:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:56 --> Controller Class Initialized
INFO - 2023-01-07 05:20:56 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:56 --> Total execution time: 0.0253
INFO - 2023-01-07 05:20:58 --> Config Class Initialized
INFO - 2023-01-07 05:20:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:20:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:20:58 --> Utf8 Class Initialized
INFO - 2023-01-07 05:20:58 --> URI Class Initialized
INFO - 2023-01-07 05:20:58 --> Router Class Initialized
INFO - 2023-01-07 05:20:58 --> Output Class Initialized
INFO - 2023-01-07 05:20:58 --> Security Class Initialized
DEBUG - 2023-01-07 05:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:20:58 --> Input Class Initialized
INFO - 2023-01-07 05:20:58 --> Language Class Initialized
INFO - 2023-01-07 05:20:58 --> Language Class Initialized
INFO - 2023-01-07 05:20:58 --> Config Class Initialized
INFO - 2023-01-07 05:20:58 --> Loader Class Initialized
INFO - 2023-01-07 05:20:58 --> Helper loaded: url_helper
INFO - 2023-01-07 05:20:58 --> Helper loaded: file_helper
INFO - 2023-01-07 05:20:58 --> Helper loaded: form_helper
INFO - 2023-01-07 05:20:58 --> Helper loaded: my_helper
INFO - 2023-01-07 05:20:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:20:58 --> Controller Class Initialized
DEBUG - 2023-01-07 05:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:20:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:20:58 --> Final output sent to browser
DEBUG - 2023-01-07 05:20:58 --> Total execution time: 0.0280
INFO - 2023-01-07 05:21:03 --> Config Class Initialized
INFO - 2023-01-07 05:21:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:21:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:21:03 --> Utf8 Class Initialized
INFO - 2023-01-07 05:21:03 --> URI Class Initialized
INFO - 2023-01-07 05:21:03 --> Router Class Initialized
INFO - 2023-01-07 05:21:03 --> Output Class Initialized
INFO - 2023-01-07 05:21:03 --> Security Class Initialized
DEBUG - 2023-01-07 05:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:21:03 --> Input Class Initialized
INFO - 2023-01-07 05:21:03 --> Language Class Initialized
INFO - 2023-01-07 05:21:03 --> Language Class Initialized
INFO - 2023-01-07 05:21:03 --> Config Class Initialized
INFO - 2023-01-07 05:21:03 --> Loader Class Initialized
INFO - 2023-01-07 05:21:03 --> Helper loaded: url_helper
INFO - 2023-01-07 05:21:03 --> Helper loaded: file_helper
INFO - 2023-01-07 05:21:03 --> Helper loaded: form_helper
INFO - 2023-01-07 05:21:03 --> Helper loaded: my_helper
INFO - 2023-01-07 05:21:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:21:03 --> Controller Class Initialized
DEBUG - 2023-01-07 05:21:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:21:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:21:03 --> Final output sent to browser
DEBUG - 2023-01-07 05:21:03 --> Total execution time: 0.0253
INFO - 2023-01-07 05:21:23 --> Config Class Initialized
INFO - 2023-01-07 05:21:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:21:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:21:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:21:23 --> URI Class Initialized
INFO - 2023-01-07 05:21:23 --> Router Class Initialized
INFO - 2023-01-07 05:21:23 --> Output Class Initialized
INFO - 2023-01-07 05:21:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:21:23 --> Input Class Initialized
INFO - 2023-01-07 05:21:23 --> Language Class Initialized
INFO - 2023-01-07 05:21:23 --> Language Class Initialized
INFO - 2023-01-07 05:21:23 --> Config Class Initialized
INFO - 2023-01-07 05:21:23 --> Loader Class Initialized
INFO - 2023-01-07 05:21:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:21:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:21:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:21:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:21:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:21:23 --> Controller Class Initialized
DEBUG - 2023-01-07 05:21:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_ekstra/views/list.php
DEBUG - 2023-01-07 05:21:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:21:23 --> Final output sent to browser
DEBUG - 2023-01-07 05:21:23 --> Total execution time: 0.0335
INFO - 2023-01-07 05:21:26 --> Config Class Initialized
INFO - 2023-01-07 05:21:26 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:21:26 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:21:26 --> Utf8 Class Initialized
INFO - 2023-01-07 05:21:26 --> URI Class Initialized
INFO - 2023-01-07 05:21:26 --> Router Class Initialized
INFO - 2023-01-07 05:21:26 --> Output Class Initialized
INFO - 2023-01-07 05:21:26 --> Security Class Initialized
DEBUG - 2023-01-07 05:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:21:26 --> Input Class Initialized
INFO - 2023-01-07 05:21:26 --> Language Class Initialized
INFO - 2023-01-07 05:21:26 --> Language Class Initialized
INFO - 2023-01-07 05:21:26 --> Config Class Initialized
INFO - 2023-01-07 05:21:26 --> Loader Class Initialized
INFO - 2023-01-07 05:21:26 --> Helper loaded: url_helper
INFO - 2023-01-07 05:21:26 --> Helper loaded: file_helper
INFO - 2023-01-07 05:21:26 --> Helper loaded: form_helper
INFO - 2023-01-07 05:21:26 --> Helper loaded: my_helper
INFO - 2023-01-07 05:21:26 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:21:26 --> Controller Class Initialized
DEBUG - 2023-01-07 05:21:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_leger/views/landing.php
DEBUG - 2023-01-07 05:21:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:21:26 --> Final output sent to browser
DEBUG - 2023-01-07 05:21:26 --> Total execution time: 0.0257
INFO - 2023-01-07 05:21:27 --> Config Class Initialized
INFO - 2023-01-07 05:21:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:21:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:21:27 --> Utf8 Class Initialized
INFO - 2023-01-07 05:21:27 --> URI Class Initialized
INFO - 2023-01-07 05:21:27 --> Router Class Initialized
INFO - 2023-01-07 05:21:27 --> Output Class Initialized
INFO - 2023-01-07 05:21:27 --> Security Class Initialized
DEBUG - 2023-01-07 05:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:21:27 --> Input Class Initialized
INFO - 2023-01-07 05:21:27 --> Language Class Initialized
INFO - 2023-01-07 05:21:27 --> Language Class Initialized
INFO - 2023-01-07 05:21:27 --> Config Class Initialized
INFO - 2023-01-07 05:21:27 --> Loader Class Initialized
INFO - 2023-01-07 05:21:27 --> Helper loaded: url_helper
INFO - 2023-01-07 05:21:27 --> Helper loaded: file_helper
INFO - 2023-01-07 05:21:27 --> Helper loaded: form_helper
INFO - 2023-01-07 05:21:27 --> Helper loaded: my_helper
INFO - 2023-01-07 05:21:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:21:27 --> Controller Class Initialized
DEBUG - 2023-01-07 05:21:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2023-01-07 05:21:27 --> Final output sent to browser
DEBUG - 2023-01-07 05:21:27 --> Total execution time: 0.0383
INFO - 2023-01-07 05:21:37 --> Config Class Initialized
INFO - 2023-01-07 05:21:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:21:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:21:37 --> Utf8 Class Initialized
INFO - 2023-01-07 05:21:37 --> URI Class Initialized
INFO - 2023-01-07 05:21:37 --> Router Class Initialized
INFO - 2023-01-07 05:21:37 --> Output Class Initialized
INFO - 2023-01-07 05:21:37 --> Security Class Initialized
DEBUG - 2023-01-07 05:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:21:37 --> Input Class Initialized
INFO - 2023-01-07 05:21:37 --> Language Class Initialized
INFO - 2023-01-07 05:21:37 --> Language Class Initialized
INFO - 2023-01-07 05:21:37 --> Config Class Initialized
INFO - 2023-01-07 05:21:37 --> Loader Class Initialized
INFO - 2023-01-07 05:21:37 --> Helper loaded: url_helper
INFO - 2023-01-07 05:21:37 --> Helper loaded: file_helper
INFO - 2023-01-07 05:21:37 --> Helper loaded: form_helper
INFO - 2023-01-07 05:21:37 --> Helper loaded: my_helper
INFO - 2023-01-07 05:21:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:21:37 --> Controller Class Initialized
DEBUG - 2023-01-07 05:21:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 05:21:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:21:37 --> Final output sent to browser
DEBUG - 2023-01-07 05:21:37 --> Total execution time: 0.0253
INFO - 2023-01-07 05:23:56 --> Config Class Initialized
INFO - 2023-01-07 05:23:56 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:23:56 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:23:56 --> Utf8 Class Initialized
INFO - 2023-01-07 05:23:56 --> URI Class Initialized
INFO - 2023-01-07 05:23:56 --> Router Class Initialized
INFO - 2023-01-07 05:23:56 --> Output Class Initialized
INFO - 2023-01-07 05:23:56 --> Security Class Initialized
DEBUG - 2023-01-07 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:23:56 --> Input Class Initialized
INFO - 2023-01-07 05:23:56 --> Language Class Initialized
INFO - 2023-01-07 05:23:56 --> Language Class Initialized
INFO - 2023-01-07 05:23:56 --> Config Class Initialized
INFO - 2023-01-07 05:23:56 --> Loader Class Initialized
INFO - 2023-01-07 05:23:56 --> Helper loaded: url_helper
INFO - 2023-01-07 05:23:56 --> Helper loaded: file_helper
INFO - 2023-01-07 05:23:56 --> Helper loaded: form_helper
INFO - 2023-01-07 05:23:56 --> Helper loaded: my_helper
INFO - 2023-01-07 05:23:56 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:23:56 --> Controller Class Initialized
DEBUG - 2023-01-07 05:23:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 05:23:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:23:56 --> Final output sent to browser
DEBUG - 2023-01-07 05:23:56 --> Total execution time: 0.0342
INFO - 2023-01-07 05:36:07 --> Config Class Initialized
INFO - 2023-01-07 05:36:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:36:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:36:07 --> Utf8 Class Initialized
INFO - 2023-01-07 05:36:07 --> URI Class Initialized
INFO - 2023-01-07 05:36:07 --> Router Class Initialized
INFO - 2023-01-07 05:36:07 --> Output Class Initialized
INFO - 2023-01-07 05:36:07 --> Security Class Initialized
DEBUG - 2023-01-07 05:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:36:07 --> Input Class Initialized
INFO - 2023-01-07 05:36:07 --> Language Class Initialized
INFO - 2023-01-07 05:36:07 --> Language Class Initialized
INFO - 2023-01-07 05:36:07 --> Config Class Initialized
INFO - 2023-01-07 05:36:07 --> Loader Class Initialized
INFO - 2023-01-07 05:36:07 --> Helper loaded: url_helper
INFO - 2023-01-07 05:36:07 --> Helper loaded: file_helper
INFO - 2023-01-07 05:36:07 --> Helper loaded: form_helper
INFO - 2023-01-07 05:36:07 --> Helper loaded: my_helper
INFO - 2023-01-07 05:36:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:36:07 --> Controller Class Initialized
DEBUG - 2023-01-07 05:36:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:36:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:36:07 --> Final output sent to browser
DEBUG - 2023-01-07 05:36:07 --> Total execution time: 0.4986
INFO - 2023-01-07 05:36:09 --> Config Class Initialized
INFO - 2023-01-07 05:36:09 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:36:09 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:36:09 --> Utf8 Class Initialized
INFO - 2023-01-07 05:36:09 --> URI Class Initialized
INFO - 2023-01-07 05:36:09 --> Router Class Initialized
INFO - 2023-01-07 05:36:09 --> Output Class Initialized
INFO - 2023-01-07 05:36:09 --> Security Class Initialized
DEBUG - 2023-01-07 05:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:36:09 --> Input Class Initialized
INFO - 2023-01-07 05:36:09 --> Language Class Initialized
INFO - 2023-01-07 05:36:09 --> Language Class Initialized
INFO - 2023-01-07 05:36:09 --> Config Class Initialized
INFO - 2023-01-07 05:36:09 --> Loader Class Initialized
INFO - 2023-01-07 05:36:09 --> Helper loaded: url_helper
INFO - 2023-01-07 05:36:09 --> Helper loaded: file_helper
INFO - 2023-01-07 05:36:09 --> Helper loaded: form_helper
INFO - 2023-01-07 05:36:09 --> Helper loaded: my_helper
INFO - 2023-01-07 05:36:09 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:36:09 --> Controller Class Initialized
DEBUG - 2023-01-07 05:36:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:36:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:36:09 --> Final output sent to browser
DEBUG - 2023-01-07 05:36:09 --> Total execution time: 0.0595
INFO - 2023-01-07 05:38:38 --> Config Class Initialized
INFO - 2023-01-07 05:38:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:38:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:38:38 --> Utf8 Class Initialized
INFO - 2023-01-07 05:38:38 --> URI Class Initialized
INFO - 2023-01-07 05:38:38 --> Router Class Initialized
INFO - 2023-01-07 05:38:38 --> Output Class Initialized
INFO - 2023-01-07 05:38:38 --> Security Class Initialized
DEBUG - 2023-01-07 05:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:38:38 --> Input Class Initialized
INFO - 2023-01-07 05:38:38 --> Language Class Initialized
INFO - 2023-01-07 05:38:38 --> Language Class Initialized
INFO - 2023-01-07 05:38:38 --> Config Class Initialized
INFO - 2023-01-07 05:38:38 --> Loader Class Initialized
INFO - 2023-01-07 05:38:38 --> Helper loaded: url_helper
INFO - 2023-01-07 05:38:38 --> Helper loaded: file_helper
INFO - 2023-01-07 05:38:38 --> Helper loaded: form_helper
INFO - 2023-01-07 05:38:38 --> Helper loaded: my_helper
INFO - 2023-01-07 05:38:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:38:38 --> Controller Class Initialized
DEBUG - 2023-01-07 05:38:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:38:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:38:38 --> Final output sent to browser
DEBUG - 2023-01-07 05:38:38 --> Total execution time: 0.0331
INFO - 2023-01-07 05:38:39 --> Config Class Initialized
INFO - 2023-01-07 05:38:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:38:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:38:39 --> Utf8 Class Initialized
INFO - 2023-01-07 05:38:39 --> URI Class Initialized
INFO - 2023-01-07 05:38:39 --> Router Class Initialized
INFO - 2023-01-07 05:38:39 --> Output Class Initialized
INFO - 2023-01-07 05:38:39 --> Security Class Initialized
DEBUG - 2023-01-07 05:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:38:39 --> Input Class Initialized
INFO - 2023-01-07 05:38:39 --> Language Class Initialized
INFO - 2023-01-07 05:38:39 --> Language Class Initialized
INFO - 2023-01-07 05:38:39 --> Config Class Initialized
INFO - 2023-01-07 05:38:39 --> Loader Class Initialized
INFO - 2023-01-07 05:38:39 --> Helper loaded: url_helper
INFO - 2023-01-07 05:38:39 --> Helper loaded: file_helper
INFO - 2023-01-07 05:38:39 --> Helper loaded: form_helper
INFO - 2023-01-07 05:38:39 --> Helper loaded: my_helper
INFO - 2023-01-07 05:38:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:38:39 --> Controller Class Initialized
DEBUG - 2023-01-07 05:38:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:38:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:38:39 --> Final output sent to browser
DEBUG - 2023-01-07 05:38:39 --> Total execution time: 0.0473
INFO - 2023-01-07 05:39:27 --> Config Class Initialized
INFO - 2023-01-07 05:39:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:39:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:39:27 --> Utf8 Class Initialized
INFO - 2023-01-07 05:39:27 --> URI Class Initialized
INFO - 2023-01-07 05:39:27 --> Router Class Initialized
INFO - 2023-01-07 05:39:27 --> Output Class Initialized
INFO - 2023-01-07 05:39:27 --> Security Class Initialized
DEBUG - 2023-01-07 05:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:39:27 --> Input Class Initialized
INFO - 2023-01-07 05:39:27 --> Language Class Initialized
INFO - 2023-01-07 05:39:27 --> Language Class Initialized
INFO - 2023-01-07 05:39:27 --> Config Class Initialized
INFO - 2023-01-07 05:39:27 --> Loader Class Initialized
INFO - 2023-01-07 05:39:27 --> Helper loaded: url_helper
INFO - 2023-01-07 05:39:27 --> Helper loaded: file_helper
INFO - 2023-01-07 05:39:27 --> Helper loaded: form_helper
INFO - 2023-01-07 05:39:27 --> Helper loaded: my_helper
INFO - 2023-01-07 05:39:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:39:27 --> Controller Class Initialized
DEBUG - 2023-01-07 05:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:39:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:39:27 --> Final output sent to browser
DEBUG - 2023-01-07 05:39:27 --> Total execution time: 0.0336
INFO - 2023-01-07 05:39:38 --> Config Class Initialized
INFO - 2023-01-07 05:39:38 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:39:38 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:39:38 --> Utf8 Class Initialized
INFO - 2023-01-07 05:39:38 --> URI Class Initialized
INFO - 2023-01-07 05:39:38 --> Router Class Initialized
INFO - 2023-01-07 05:39:38 --> Output Class Initialized
INFO - 2023-01-07 05:39:38 --> Security Class Initialized
DEBUG - 2023-01-07 05:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:39:38 --> Input Class Initialized
INFO - 2023-01-07 05:39:38 --> Language Class Initialized
INFO - 2023-01-07 05:39:38 --> Language Class Initialized
INFO - 2023-01-07 05:39:38 --> Config Class Initialized
INFO - 2023-01-07 05:39:38 --> Loader Class Initialized
INFO - 2023-01-07 05:39:38 --> Helper loaded: url_helper
INFO - 2023-01-07 05:39:38 --> Helper loaded: file_helper
INFO - 2023-01-07 05:39:38 --> Helper loaded: form_helper
INFO - 2023-01-07 05:39:38 --> Helper loaded: my_helper
INFO - 2023-01-07 05:39:38 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:39:38 --> Controller Class Initialized
DEBUG - 2023-01-07 05:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:39:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:39:38 --> Final output sent to browser
DEBUG - 2023-01-07 05:39:38 --> Total execution time: 0.0250
INFO - 2023-01-07 05:39:39 --> Config Class Initialized
INFO - 2023-01-07 05:39:39 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:39:39 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:39:39 --> Utf8 Class Initialized
INFO - 2023-01-07 05:39:39 --> URI Class Initialized
INFO - 2023-01-07 05:39:39 --> Router Class Initialized
INFO - 2023-01-07 05:39:39 --> Output Class Initialized
INFO - 2023-01-07 05:39:39 --> Security Class Initialized
DEBUG - 2023-01-07 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:39:39 --> Input Class Initialized
INFO - 2023-01-07 05:39:39 --> Language Class Initialized
INFO - 2023-01-07 05:39:39 --> Language Class Initialized
INFO - 2023-01-07 05:39:39 --> Config Class Initialized
INFO - 2023-01-07 05:39:39 --> Loader Class Initialized
INFO - 2023-01-07 05:39:39 --> Helper loaded: url_helper
INFO - 2023-01-07 05:39:39 --> Helper loaded: file_helper
INFO - 2023-01-07 05:39:39 --> Helper loaded: form_helper
INFO - 2023-01-07 05:39:39 --> Helper loaded: my_helper
INFO - 2023-01-07 05:39:39 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:39:39 --> Controller Class Initialized
DEBUG - 2023-01-07 05:39:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:39:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:39:39 --> Final output sent to browser
DEBUG - 2023-01-07 05:39:39 --> Total execution time: 0.0253
INFO - 2023-01-07 05:39:41 --> Config Class Initialized
INFO - 2023-01-07 05:39:41 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:39:41 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:39:41 --> Utf8 Class Initialized
INFO - 2023-01-07 05:39:41 --> URI Class Initialized
INFO - 2023-01-07 05:39:41 --> Router Class Initialized
INFO - 2023-01-07 05:39:41 --> Output Class Initialized
INFO - 2023-01-07 05:39:41 --> Security Class Initialized
DEBUG - 2023-01-07 05:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:39:41 --> Input Class Initialized
INFO - 2023-01-07 05:39:41 --> Language Class Initialized
INFO - 2023-01-07 05:39:41 --> Language Class Initialized
INFO - 2023-01-07 05:39:41 --> Config Class Initialized
INFO - 2023-01-07 05:39:41 --> Loader Class Initialized
INFO - 2023-01-07 05:39:41 --> Helper loaded: url_helper
INFO - 2023-01-07 05:39:41 --> Helper loaded: file_helper
INFO - 2023-01-07 05:39:41 --> Helper loaded: form_helper
INFO - 2023-01-07 05:39:41 --> Helper loaded: my_helper
INFO - 2023-01-07 05:39:41 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:39:41 --> Controller Class Initialized
DEBUG - 2023-01-07 05:39:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:39:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:39:41 --> Final output sent to browser
DEBUG - 2023-01-07 05:39:41 --> Total execution time: 0.0537
INFO - 2023-01-07 05:39:58 --> Config Class Initialized
INFO - 2023-01-07 05:39:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:39:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:39:58 --> Utf8 Class Initialized
INFO - 2023-01-07 05:39:58 --> URI Class Initialized
INFO - 2023-01-07 05:39:58 --> Router Class Initialized
INFO - 2023-01-07 05:39:58 --> Output Class Initialized
INFO - 2023-01-07 05:39:58 --> Security Class Initialized
DEBUG - 2023-01-07 05:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:39:58 --> Input Class Initialized
INFO - 2023-01-07 05:39:58 --> Language Class Initialized
INFO - 2023-01-07 05:39:58 --> Language Class Initialized
INFO - 2023-01-07 05:39:58 --> Config Class Initialized
INFO - 2023-01-07 05:39:58 --> Loader Class Initialized
INFO - 2023-01-07 05:39:58 --> Helper loaded: url_helper
INFO - 2023-01-07 05:39:58 --> Helper loaded: file_helper
INFO - 2023-01-07 05:39:58 --> Helper loaded: form_helper
INFO - 2023-01-07 05:39:58 --> Helper loaded: my_helper
INFO - 2023-01-07 05:39:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:39:58 --> Controller Class Initialized
DEBUG - 2023-01-07 05:39:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:39:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:39:58 --> Final output sent to browser
DEBUG - 2023-01-07 05:39:58 --> Total execution time: 0.0389
INFO - 2023-01-07 05:40:00 --> Config Class Initialized
INFO - 2023-01-07 05:40:00 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:40:00 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:40:00 --> Utf8 Class Initialized
INFO - 2023-01-07 05:40:00 --> URI Class Initialized
INFO - 2023-01-07 05:40:00 --> Router Class Initialized
INFO - 2023-01-07 05:40:00 --> Output Class Initialized
INFO - 2023-01-07 05:40:00 --> Security Class Initialized
DEBUG - 2023-01-07 05:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:40:00 --> Input Class Initialized
INFO - 2023-01-07 05:40:00 --> Language Class Initialized
INFO - 2023-01-07 05:40:00 --> Language Class Initialized
INFO - 2023-01-07 05:40:00 --> Config Class Initialized
INFO - 2023-01-07 05:40:00 --> Loader Class Initialized
INFO - 2023-01-07 05:40:00 --> Helper loaded: url_helper
INFO - 2023-01-07 05:40:00 --> Helper loaded: file_helper
INFO - 2023-01-07 05:40:00 --> Helper loaded: form_helper
INFO - 2023-01-07 05:40:00 --> Helper loaded: my_helper
INFO - 2023-01-07 05:40:00 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:40:00 --> Controller Class Initialized
INFO - 2023-01-07 05:40:00 --> Final output sent to browser
DEBUG - 2023-01-07 05:40:00 --> Total execution time: 0.0255
INFO - 2023-01-07 05:43:09 --> Config Class Initialized
INFO - 2023-01-07 05:43:09 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:43:09 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:43:09 --> Utf8 Class Initialized
INFO - 2023-01-07 05:43:09 --> URI Class Initialized
INFO - 2023-01-07 05:43:09 --> Router Class Initialized
INFO - 2023-01-07 05:43:09 --> Output Class Initialized
INFO - 2023-01-07 05:43:09 --> Security Class Initialized
DEBUG - 2023-01-07 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:43:09 --> Input Class Initialized
INFO - 2023-01-07 05:43:09 --> Language Class Initialized
INFO - 2023-01-07 05:43:09 --> Language Class Initialized
INFO - 2023-01-07 05:43:09 --> Config Class Initialized
INFO - 2023-01-07 05:43:09 --> Loader Class Initialized
INFO - 2023-01-07 05:43:09 --> Helper loaded: url_helper
INFO - 2023-01-07 05:43:09 --> Helper loaded: file_helper
INFO - 2023-01-07 05:43:09 --> Helper loaded: form_helper
INFO - 2023-01-07 05:43:09 --> Helper loaded: my_helper
INFO - 2023-01-07 05:43:09 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:43:09 --> Controller Class Initialized
DEBUG - 2023-01-07 05:43:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-01-07 05:43:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:43:09 --> Final output sent to browser
DEBUG - 2023-01-07 05:43:09 --> Total execution time: 0.0650
INFO - 2023-01-07 05:43:11 --> Config Class Initialized
INFO - 2023-01-07 05:43:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:43:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:43:11 --> Utf8 Class Initialized
INFO - 2023-01-07 05:43:11 --> URI Class Initialized
INFO - 2023-01-07 05:43:11 --> Router Class Initialized
INFO - 2023-01-07 05:43:11 --> Output Class Initialized
INFO - 2023-01-07 05:43:11 --> Security Class Initialized
DEBUG - 2023-01-07 05:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:43:11 --> Input Class Initialized
INFO - 2023-01-07 05:43:11 --> Language Class Initialized
INFO - 2023-01-07 05:43:11 --> Language Class Initialized
INFO - 2023-01-07 05:43:11 --> Config Class Initialized
INFO - 2023-01-07 05:43:11 --> Loader Class Initialized
INFO - 2023-01-07 05:43:11 --> Helper loaded: url_helper
INFO - 2023-01-07 05:43:11 --> Helper loaded: file_helper
INFO - 2023-01-07 05:43:11 --> Helper loaded: form_helper
INFO - 2023-01-07 05:43:11 --> Helper loaded: my_helper
INFO - 2023-01-07 05:43:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:43:11 --> Controller Class Initialized
DEBUG - 2023-01-07 05:43:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-01-07 05:43:11 --> Final output sent to browser
DEBUG - 2023-01-07 05:43:11 --> Total execution time: 0.0769
INFO - 2023-01-07 05:43:17 --> Config Class Initialized
INFO - 2023-01-07 05:43:17 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:43:17 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:43:17 --> Utf8 Class Initialized
INFO - 2023-01-07 05:43:17 --> URI Class Initialized
INFO - 2023-01-07 05:43:17 --> Router Class Initialized
INFO - 2023-01-07 05:43:17 --> Output Class Initialized
INFO - 2023-01-07 05:43:17 --> Security Class Initialized
DEBUG - 2023-01-07 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:43:17 --> Input Class Initialized
INFO - 2023-01-07 05:43:17 --> Language Class Initialized
INFO - 2023-01-07 05:43:17 --> Language Class Initialized
INFO - 2023-01-07 05:43:17 --> Config Class Initialized
INFO - 2023-01-07 05:43:17 --> Loader Class Initialized
INFO - 2023-01-07 05:43:17 --> Helper loaded: url_helper
INFO - 2023-01-07 05:43:17 --> Helper loaded: file_helper
INFO - 2023-01-07 05:43:17 --> Helper loaded: form_helper
INFO - 2023-01-07 05:43:17 --> Helper loaded: my_helper
INFO - 2023-01-07 05:43:17 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:43:17 --> Controller Class Initialized
DEBUG - 2023-01-07 05:43:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 05:43:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:43:17 --> Final output sent to browser
DEBUG - 2023-01-07 05:43:17 --> Total execution time: 0.0724
INFO - 2023-01-07 05:43:18 --> Config Class Initialized
INFO - 2023-01-07 05:43:18 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:43:18 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:43:18 --> Utf8 Class Initialized
INFO - 2023-01-07 05:43:18 --> URI Class Initialized
INFO - 2023-01-07 05:43:18 --> Router Class Initialized
INFO - 2023-01-07 05:43:18 --> Output Class Initialized
INFO - 2023-01-07 05:43:18 --> Security Class Initialized
DEBUG - 2023-01-07 05:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:43:18 --> Input Class Initialized
INFO - 2023-01-07 05:43:18 --> Language Class Initialized
INFO - 2023-01-07 05:43:18 --> Language Class Initialized
INFO - 2023-01-07 05:43:18 --> Config Class Initialized
INFO - 2023-01-07 05:43:18 --> Loader Class Initialized
INFO - 2023-01-07 05:43:18 --> Helper loaded: url_helper
INFO - 2023-01-07 05:43:18 --> Helper loaded: file_helper
INFO - 2023-01-07 05:43:18 --> Helper loaded: form_helper
INFO - 2023-01-07 05:43:18 --> Helper loaded: my_helper
INFO - 2023-01-07 05:43:18 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:43:18 --> Controller Class Initialized
ERROR - 2023-01-07 05:43:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 327
ERROR - 2023-01-07 05:43:18 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2023-01-07 05:43:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 05:43:19 --> Final output sent to browser
DEBUG - 2023-01-07 05:43:19 --> Total execution time: 0.8828
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:23 --> URI Class Initialized
INFO - 2023-01-07 05:52:23 --> Router Class Initialized
INFO - 2023-01-07 05:52:23 --> Output Class Initialized
INFO - 2023-01-07 05:52:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:23 --> Input Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Loader Class Initialized
INFO - 2023-01-07 05:52:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:23 --> Controller Class Initialized
INFO - 2023-01-07 05:52:23 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:23 --> URI Class Initialized
INFO - 2023-01-07 05:52:23 --> Router Class Initialized
INFO - 2023-01-07 05:52:23 --> Output Class Initialized
INFO - 2023-01-07 05:52:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:23 --> Input Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Loader Class Initialized
INFO - 2023-01-07 05:52:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:23 --> Controller Class Initialized
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:23 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:23 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:23 --> URI Class Initialized
INFO - 2023-01-07 05:52:23 --> Router Class Initialized
INFO - 2023-01-07 05:52:23 --> Output Class Initialized
INFO - 2023-01-07 05:52:23 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:23 --> Input Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Language Class Initialized
INFO - 2023-01-07 05:52:23 --> Config Class Initialized
INFO - 2023-01-07 05:52:23 --> Loader Class Initialized
INFO - 2023-01-07 05:52:23 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:23 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:23 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:23 --> Controller Class Initialized
DEBUG - 2023-01-07 05:52:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:52:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:23 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:23 --> Total execution time: 0.0367
INFO - 2023-01-07 05:52:29 --> Config Class Initialized
INFO - 2023-01-07 05:52:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:29 --> URI Class Initialized
INFO - 2023-01-07 05:52:29 --> Router Class Initialized
INFO - 2023-01-07 05:52:29 --> Output Class Initialized
INFO - 2023-01-07 05:52:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:29 --> Input Class Initialized
INFO - 2023-01-07 05:52:29 --> Language Class Initialized
INFO - 2023-01-07 05:52:29 --> Language Class Initialized
INFO - 2023-01-07 05:52:29 --> Config Class Initialized
INFO - 2023-01-07 05:52:29 --> Loader Class Initialized
INFO - 2023-01-07 05:52:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:29 --> Controller Class Initialized
INFO - 2023-01-07 05:52:29 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:52:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:29 --> Total execution time: 0.0484
INFO - 2023-01-07 05:52:29 --> Config Class Initialized
INFO - 2023-01-07 05:52:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:29 --> URI Class Initialized
INFO - 2023-01-07 05:52:29 --> Router Class Initialized
INFO - 2023-01-07 05:52:29 --> Output Class Initialized
INFO - 2023-01-07 05:52:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:29 --> Input Class Initialized
INFO - 2023-01-07 05:52:29 --> Language Class Initialized
INFO - 2023-01-07 05:52:29 --> Language Class Initialized
INFO - 2023-01-07 05:52:29 --> Config Class Initialized
INFO - 2023-01-07 05:52:29 --> Loader Class Initialized
INFO - 2023-01-07 05:52:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:29 --> Controller Class Initialized
DEBUG - 2023-01-07 05:52:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 05:52:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:29 --> Total execution time: 0.0608
INFO - 2023-01-07 05:52:35 --> Config Class Initialized
INFO - 2023-01-07 05:52:35 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:35 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:35 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:35 --> URI Class Initialized
INFO - 2023-01-07 05:52:35 --> Router Class Initialized
INFO - 2023-01-07 05:52:35 --> Output Class Initialized
INFO - 2023-01-07 05:52:35 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:35 --> Input Class Initialized
INFO - 2023-01-07 05:52:35 --> Language Class Initialized
INFO - 2023-01-07 05:52:35 --> Language Class Initialized
INFO - 2023-01-07 05:52:35 --> Config Class Initialized
INFO - 2023-01-07 05:52:35 --> Loader Class Initialized
INFO - 2023-01-07 05:52:35 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:35 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:35 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:35 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:35 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:35 --> Controller Class Initialized
DEBUG - 2023-01-07 05:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:52:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:35 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:35 --> Total execution time: 0.0505
INFO - 2023-01-07 05:52:40 --> Config Class Initialized
INFO - 2023-01-07 05:52:40 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:40 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:40 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:40 --> URI Class Initialized
INFO - 2023-01-07 05:52:40 --> Router Class Initialized
INFO - 2023-01-07 05:52:40 --> Output Class Initialized
INFO - 2023-01-07 05:52:40 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:40 --> Input Class Initialized
INFO - 2023-01-07 05:52:40 --> Language Class Initialized
INFO - 2023-01-07 05:52:40 --> Language Class Initialized
INFO - 2023-01-07 05:52:40 --> Config Class Initialized
INFO - 2023-01-07 05:52:40 --> Loader Class Initialized
INFO - 2023-01-07 05:52:40 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:40 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:40 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:40 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:40 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:40 --> Controller Class Initialized
INFO - 2023-01-07 05:52:40 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:40 --> Total execution time: 0.0298
INFO - 2023-01-07 05:52:43 --> Config Class Initialized
INFO - 2023-01-07 05:52:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:43 --> URI Class Initialized
INFO - 2023-01-07 05:52:43 --> Router Class Initialized
INFO - 2023-01-07 05:52:43 --> Output Class Initialized
INFO - 2023-01-07 05:52:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:43 --> Input Class Initialized
INFO - 2023-01-07 05:52:43 --> Language Class Initialized
INFO - 2023-01-07 05:52:43 --> Language Class Initialized
INFO - 2023-01-07 05:52:43 --> Config Class Initialized
INFO - 2023-01-07 05:52:43 --> Loader Class Initialized
INFO - 2023-01-07 05:52:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:43 --> Controller Class Initialized
DEBUG - 2023-01-07 05:52:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:52:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:43 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:43 --> Total execution time: 0.0277
INFO - 2023-01-07 05:52:45 --> Config Class Initialized
INFO - 2023-01-07 05:52:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:45 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:45 --> URI Class Initialized
INFO - 2023-01-07 05:52:45 --> Router Class Initialized
INFO - 2023-01-07 05:52:45 --> Output Class Initialized
INFO - 2023-01-07 05:52:45 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:45 --> Input Class Initialized
INFO - 2023-01-07 05:52:45 --> Language Class Initialized
INFO - 2023-01-07 05:52:45 --> Language Class Initialized
INFO - 2023-01-07 05:52:45 --> Config Class Initialized
INFO - 2023-01-07 05:52:45 --> Loader Class Initialized
INFO - 2023-01-07 05:52:45 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:45 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:45 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:45 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:45 --> Controller Class Initialized
ERROR - 2023-01-07 05:52:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 05:52:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 05:52:45 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 05:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:52:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:45 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:45 --> Total execution time: 0.0453
INFO - 2023-01-07 05:52:53 --> Config Class Initialized
INFO - 2023-01-07 05:52:53 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:53 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:53 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:53 --> URI Class Initialized
INFO - 2023-01-07 05:52:53 --> Router Class Initialized
INFO - 2023-01-07 05:52:53 --> Output Class Initialized
INFO - 2023-01-07 05:52:53 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:53 --> Input Class Initialized
INFO - 2023-01-07 05:52:53 --> Language Class Initialized
INFO - 2023-01-07 05:52:53 --> Language Class Initialized
INFO - 2023-01-07 05:52:53 --> Config Class Initialized
INFO - 2023-01-07 05:52:53 --> Loader Class Initialized
INFO - 2023-01-07 05:52:53 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:53 --> Controller Class Initialized
INFO - 2023-01-07 05:52:53 --> Config Class Initialized
INFO - 2023-01-07 05:52:53 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:52:53 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:52:53 --> Utf8 Class Initialized
INFO - 2023-01-07 05:52:53 --> URI Class Initialized
INFO - 2023-01-07 05:52:53 --> Router Class Initialized
INFO - 2023-01-07 05:52:53 --> Output Class Initialized
INFO - 2023-01-07 05:52:53 --> Security Class Initialized
DEBUG - 2023-01-07 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:52:53 --> Input Class Initialized
INFO - 2023-01-07 05:52:53 --> Language Class Initialized
INFO - 2023-01-07 05:52:53 --> Language Class Initialized
INFO - 2023-01-07 05:52:53 --> Config Class Initialized
INFO - 2023-01-07 05:52:53 --> Loader Class Initialized
INFO - 2023-01-07 05:52:53 --> Helper loaded: url_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: file_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: form_helper
INFO - 2023-01-07 05:52:53 --> Helper loaded: my_helper
INFO - 2023-01-07 05:52:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:52:53 --> Controller Class Initialized
DEBUG - 2023-01-07 05:52:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:52:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:52:53 --> Final output sent to browser
DEBUG - 2023-01-07 05:52:53 --> Total execution time: 0.0415
INFO - 2023-01-07 05:58:02 --> Config Class Initialized
INFO - 2023-01-07 05:58:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:02 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:02 --> URI Class Initialized
INFO - 2023-01-07 05:58:02 --> Router Class Initialized
INFO - 2023-01-07 05:58:02 --> Output Class Initialized
INFO - 2023-01-07 05:58:02 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:02 --> Input Class Initialized
INFO - 2023-01-07 05:58:02 --> Language Class Initialized
INFO - 2023-01-07 05:58:02 --> Language Class Initialized
INFO - 2023-01-07 05:58:02 --> Config Class Initialized
INFO - 2023-01-07 05:58:02 --> Loader Class Initialized
INFO - 2023-01-07 05:58:02 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:02 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:02 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:02 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:02 --> Controller Class Initialized
INFO - 2023-01-07 05:58:02 --> Final output sent to browser
DEBUG - 2023-01-07 05:58:02 --> Total execution time: 0.0405
INFO - 2023-01-07 05:58:04 --> Config Class Initialized
INFO - 2023-01-07 05:58:04 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:04 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:04 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:04 --> URI Class Initialized
INFO - 2023-01-07 05:58:04 --> Router Class Initialized
INFO - 2023-01-07 05:58:04 --> Output Class Initialized
INFO - 2023-01-07 05:58:04 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:04 --> Input Class Initialized
INFO - 2023-01-07 05:58:04 --> Language Class Initialized
INFO - 2023-01-07 05:58:04 --> Language Class Initialized
INFO - 2023-01-07 05:58:04 --> Config Class Initialized
INFO - 2023-01-07 05:58:04 --> Loader Class Initialized
INFO - 2023-01-07 05:58:04 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:04 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:04 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:04 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:04 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:04 --> Controller Class Initialized
DEBUG - 2023-01-07 05:58:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:58:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:58:04 --> Final output sent to browser
DEBUG - 2023-01-07 05:58:04 --> Total execution time: 0.0427
INFO - 2023-01-07 05:58:06 --> Config Class Initialized
INFO - 2023-01-07 05:58:06 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:06 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:06 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:06 --> URI Class Initialized
INFO - 2023-01-07 05:58:06 --> Router Class Initialized
INFO - 2023-01-07 05:58:06 --> Output Class Initialized
INFO - 2023-01-07 05:58:06 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:06 --> Input Class Initialized
INFO - 2023-01-07 05:58:06 --> Language Class Initialized
INFO - 2023-01-07 05:58:06 --> Language Class Initialized
INFO - 2023-01-07 05:58:06 --> Config Class Initialized
INFO - 2023-01-07 05:58:06 --> Loader Class Initialized
INFO - 2023-01-07 05:58:06 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:06 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:06 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:06 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:06 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:06 --> Controller Class Initialized
ERROR - 2023-01-07 05:58:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 05:58:06 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 05:58:06 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 05:58:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:58:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:58:06 --> Final output sent to browser
DEBUG - 2023-01-07 05:58:06 --> Total execution time: 0.0401
INFO - 2023-01-07 05:58:13 --> Config Class Initialized
INFO - 2023-01-07 05:58:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:13 --> URI Class Initialized
INFO - 2023-01-07 05:58:13 --> Router Class Initialized
INFO - 2023-01-07 05:58:13 --> Output Class Initialized
INFO - 2023-01-07 05:58:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:13 --> Input Class Initialized
INFO - 2023-01-07 05:58:13 --> Language Class Initialized
INFO - 2023-01-07 05:58:13 --> Language Class Initialized
INFO - 2023-01-07 05:58:13 --> Config Class Initialized
INFO - 2023-01-07 05:58:13 --> Loader Class Initialized
INFO - 2023-01-07 05:58:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:13 --> Controller Class Initialized
INFO - 2023-01-07 05:58:13 --> Config Class Initialized
INFO - 2023-01-07 05:58:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:13 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:13 --> URI Class Initialized
INFO - 2023-01-07 05:58:13 --> Router Class Initialized
INFO - 2023-01-07 05:58:13 --> Output Class Initialized
INFO - 2023-01-07 05:58:13 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:13 --> Input Class Initialized
INFO - 2023-01-07 05:58:13 --> Language Class Initialized
INFO - 2023-01-07 05:58:13 --> Language Class Initialized
INFO - 2023-01-07 05:58:13 --> Config Class Initialized
INFO - 2023-01-07 05:58:13 --> Loader Class Initialized
INFO - 2023-01-07 05:58:13 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:13 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:13 --> Controller Class Initialized
DEBUG - 2023-01-07 05:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:58:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:58:13 --> Final output sent to browser
DEBUG - 2023-01-07 05:58:13 --> Total execution time: 0.0487
INFO - 2023-01-07 05:58:58 --> Config Class Initialized
INFO - 2023-01-07 05:58:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:58:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:58:58 --> Utf8 Class Initialized
INFO - 2023-01-07 05:58:58 --> URI Class Initialized
INFO - 2023-01-07 05:58:58 --> Router Class Initialized
INFO - 2023-01-07 05:58:58 --> Output Class Initialized
INFO - 2023-01-07 05:58:58 --> Security Class Initialized
DEBUG - 2023-01-07 05:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:58:58 --> Input Class Initialized
INFO - 2023-01-07 05:58:58 --> Language Class Initialized
INFO - 2023-01-07 05:58:58 --> Language Class Initialized
INFO - 2023-01-07 05:58:58 --> Config Class Initialized
INFO - 2023-01-07 05:58:58 --> Loader Class Initialized
INFO - 2023-01-07 05:58:58 --> Helper loaded: url_helper
INFO - 2023-01-07 05:58:58 --> Helper loaded: file_helper
INFO - 2023-01-07 05:58:58 --> Helper loaded: form_helper
INFO - 2023-01-07 05:58:58 --> Helper loaded: my_helper
INFO - 2023-01-07 05:58:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:58:58 --> Controller Class Initialized
INFO - 2023-01-07 05:58:58 --> Final output sent to browser
DEBUG - 2023-01-07 05:58:58 --> Total execution time: 0.0276
INFO - 2023-01-07 05:59:02 --> Config Class Initialized
INFO - 2023-01-07 05:59:02 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:02 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:02 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:02 --> URI Class Initialized
INFO - 2023-01-07 05:59:02 --> Router Class Initialized
INFO - 2023-01-07 05:59:02 --> Output Class Initialized
INFO - 2023-01-07 05:59:02 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:02 --> Input Class Initialized
INFO - 2023-01-07 05:59:02 --> Language Class Initialized
INFO - 2023-01-07 05:59:02 --> Language Class Initialized
INFO - 2023-01-07 05:59:02 --> Config Class Initialized
INFO - 2023-01-07 05:59:02 --> Loader Class Initialized
INFO - 2023-01-07 05:59:02 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:02 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:02 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:02 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:02 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:02 --> Controller Class Initialized
ERROR - 2023-01-07 05:59:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 05:59:02 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 05:59:02 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 05:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 05:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:02 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:02 --> Total execution time: 0.0318
INFO - 2023-01-07 05:59:10 --> Config Class Initialized
INFO - 2023-01-07 05:59:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:10 --> URI Class Initialized
INFO - 2023-01-07 05:59:10 --> Router Class Initialized
INFO - 2023-01-07 05:59:10 --> Output Class Initialized
INFO - 2023-01-07 05:59:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:10 --> Input Class Initialized
INFO - 2023-01-07 05:59:10 --> Language Class Initialized
INFO - 2023-01-07 05:59:10 --> Language Class Initialized
INFO - 2023-01-07 05:59:10 --> Config Class Initialized
INFO - 2023-01-07 05:59:10 --> Loader Class Initialized
INFO - 2023-01-07 05:59:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:10 --> Controller Class Initialized
INFO - 2023-01-07 05:59:10 --> Config Class Initialized
INFO - 2023-01-07 05:59:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:10 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:10 --> URI Class Initialized
INFO - 2023-01-07 05:59:10 --> Router Class Initialized
INFO - 2023-01-07 05:59:10 --> Output Class Initialized
INFO - 2023-01-07 05:59:10 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:10 --> Input Class Initialized
INFO - 2023-01-07 05:59:10 --> Language Class Initialized
INFO - 2023-01-07 05:59:10 --> Language Class Initialized
INFO - 2023-01-07 05:59:10 --> Config Class Initialized
INFO - 2023-01-07 05:59:10 --> Loader Class Initialized
INFO - 2023-01-07 05:59:10 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:10 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:10 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 05:59:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:10 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:10 --> Total execution time: 0.0493
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:22 --> URI Class Initialized
INFO - 2023-01-07 05:59:22 --> Router Class Initialized
INFO - 2023-01-07 05:59:22 --> Output Class Initialized
INFO - 2023-01-07 05:59:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:22 --> Input Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Loader Class Initialized
INFO - 2023-01-07 05:59:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:22 --> Controller Class Initialized
INFO - 2023-01-07 05:59:22 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:22 --> URI Class Initialized
INFO - 2023-01-07 05:59:22 --> Router Class Initialized
INFO - 2023-01-07 05:59:22 --> Output Class Initialized
INFO - 2023-01-07 05:59:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:22 --> Input Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Loader Class Initialized
INFO - 2023-01-07 05:59:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:22 --> Controller Class Initialized
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:22 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:22 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:22 --> URI Class Initialized
INFO - 2023-01-07 05:59:22 --> Router Class Initialized
INFO - 2023-01-07 05:59:22 --> Output Class Initialized
INFO - 2023-01-07 05:59:22 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:22 --> Input Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Language Class Initialized
INFO - 2023-01-07 05:59:22 --> Config Class Initialized
INFO - 2023-01-07 05:59:22 --> Loader Class Initialized
INFO - 2023-01-07 05:59:22 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:22 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:22 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:22 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 05:59:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:22 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:22 --> Total execution time: 0.0410
INFO - 2023-01-07 05:59:29 --> Config Class Initialized
INFO - 2023-01-07 05:59:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:29 --> URI Class Initialized
INFO - 2023-01-07 05:59:29 --> Router Class Initialized
INFO - 2023-01-07 05:59:29 --> Output Class Initialized
INFO - 2023-01-07 05:59:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:29 --> Input Class Initialized
INFO - 2023-01-07 05:59:29 --> Language Class Initialized
INFO - 2023-01-07 05:59:29 --> Language Class Initialized
INFO - 2023-01-07 05:59:29 --> Config Class Initialized
INFO - 2023-01-07 05:59:29 --> Loader Class Initialized
INFO - 2023-01-07 05:59:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:29 --> Controller Class Initialized
INFO - 2023-01-07 05:59:29 --> Helper loaded: cookie_helper
INFO - 2023-01-07 05:59:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:29 --> Total execution time: 0.0371
INFO - 2023-01-07 05:59:29 --> Config Class Initialized
INFO - 2023-01-07 05:59:29 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:29 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:29 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:29 --> URI Class Initialized
INFO - 2023-01-07 05:59:29 --> Router Class Initialized
INFO - 2023-01-07 05:59:29 --> Output Class Initialized
INFO - 2023-01-07 05:59:29 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:29 --> Input Class Initialized
INFO - 2023-01-07 05:59:29 --> Language Class Initialized
INFO - 2023-01-07 05:59:29 --> Language Class Initialized
INFO - 2023-01-07 05:59:29 --> Config Class Initialized
INFO - 2023-01-07 05:59:29 --> Loader Class Initialized
INFO - 2023-01-07 05:59:29 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:29 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:29 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:29 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 05:59:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:29 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:29 --> Total execution time: 0.0816
INFO - 2023-01-07 05:59:32 --> Config Class Initialized
INFO - 2023-01-07 05:59:32 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:32 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:32 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:32 --> URI Class Initialized
INFO - 2023-01-07 05:59:32 --> Router Class Initialized
INFO - 2023-01-07 05:59:32 --> Output Class Initialized
INFO - 2023-01-07 05:59:32 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:32 --> Input Class Initialized
INFO - 2023-01-07 05:59:32 --> Language Class Initialized
INFO - 2023-01-07 05:59:32 --> Language Class Initialized
INFO - 2023-01-07 05:59:32 --> Config Class Initialized
INFO - 2023-01-07 05:59:32 --> Loader Class Initialized
INFO - 2023-01-07 05:59:32 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:32 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:32 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:32 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:32 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:32 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 05:59:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:32 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:32 --> Total execution time: 0.0259
INFO - 2023-01-07 05:59:34 --> Config Class Initialized
INFO - 2023-01-07 05:59:34 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:34 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:34 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:34 --> URI Class Initialized
INFO - 2023-01-07 05:59:34 --> Router Class Initialized
INFO - 2023-01-07 05:59:34 --> Output Class Initialized
INFO - 2023-01-07 05:59:34 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:34 --> Input Class Initialized
INFO - 2023-01-07 05:59:34 --> Language Class Initialized
INFO - 2023-01-07 05:59:34 --> Language Class Initialized
INFO - 2023-01-07 05:59:34 --> Config Class Initialized
INFO - 2023-01-07 05:59:34 --> Loader Class Initialized
INFO - 2023-01-07 05:59:34 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:34 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:34 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:34 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:34 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:34 --> Controller Class Initialized
ERROR - 2023-01-07 05:59:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 327
ERROR - 2023-01-07 05:59:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2023-01-07 05:59:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 05:59:34 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:34 --> Total execution time: 0.1900
INFO - 2023-01-07 05:59:43 --> Config Class Initialized
INFO - 2023-01-07 05:59:43 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:43 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:43 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:43 --> URI Class Initialized
INFO - 2023-01-07 05:59:43 --> Router Class Initialized
INFO - 2023-01-07 05:59:43 --> Output Class Initialized
INFO - 2023-01-07 05:59:43 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:43 --> Input Class Initialized
INFO - 2023-01-07 05:59:43 --> Language Class Initialized
INFO - 2023-01-07 05:59:43 --> Language Class Initialized
INFO - 2023-01-07 05:59:43 --> Config Class Initialized
INFO - 2023-01-07 05:59:43 --> Loader Class Initialized
INFO - 2023-01-07 05:59:43 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:43 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:43 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:43 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:43 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:43 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-07 05:59:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:43 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:43 --> Total execution time: 0.0665
INFO - 2023-01-07 05:59:45 --> Config Class Initialized
INFO - 2023-01-07 05:59:45 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:45 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:45 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:45 --> URI Class Initialized
INFO - 2023-01-07 05:59:45 --> Router Class Initialized
INFO - 2023-01-07 05:59:45 --> Output Class Initialized
INFO - 2023-01-07 05:59:45 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:45 --> Input Class Initialized
INFO - 2023-01-07 05:59:45 --> Language Class Initialized
INFO - 2023-01-07 05:59:45 --> Language Class Initialized
INFO - 2023-01-07 05:59:45 --> Config Class Initialized
INFO - 2023-01-07 05:59:45 --> Loader Class Initialized
INFO - 2023-01-07 05:59:45 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:45 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:45 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:45 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:45 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:45 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 05:59:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:45 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:45 --> Total execution time: 0.0398
INFO - 2023-01-07 05:59:48 --> Config Class Initialized
INFO - 2023-01-07 05:59:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:48 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:48 --> URI Class Initialized
INFO - 2023-01-07 05:59:48 --> Router Class Initialized
INFO - 2023-01-07 05:59:48 --> Output Class Initialized
INFO - 2023-01-07 05:59:48 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:48 --> Input Class Initialized
INFO - 2023-01-07 05:59:48 --> Language Class Initialized
INFO - 2023-01-07 05:59:48 --> Language Class Initialized
INFO - 2023-01-07 05:59:48 --> Config Class Initialized
INFO - 2023-01-07 05:59:48 --> Loader Class Initialized
INFO - 2023-01-07 05:59:48 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:48 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:48 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:48 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:48 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 05:59:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:48 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:48 --> Total execution time: 0.0243
INFO - 2023-01-07 05:59:55 --> Config Class Initialized
INFO - 2023-01-07 05:59:55 --> Hooks Class Initialized
DEBUG - 2023-01-07 05:59:55 --> UTF-8 Support Enabled
INFO - 2023-01-07 05:59:55 --> Utf8 Class Initialized
INFO - 2023-01-07 05:59:55 --> URI Class Initialized
INFO - 2023-01-07 05:59:55 --> Router Class Initialized
INFO - 2023-01-07 05:59:55 --> Output Class Initialized
INFO - 2023-01-07 05:59:55 --> Security Class Initialized
DEBUG - 2023-01-07 05:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 05:59:55 --> Input Class Initialized
INFO - 2023-01-07 05:59:55 --> Language Class Initialized
INFO - 2023-01-07 05:59:55 --> Language Class Initialized
INFO - 2023-01-07 05:59:55 --> Config Class Initialized
INFO - 2023-01-07 05:59:55 --> Loader Class Initialized
INFO - 2023-01-07 05:59:55 --> Helper loaded: url_helper
INFO - 2023-01-07 05:59:55 --> Helper loaded: file_helper
INFO - 2023-01-07 05:59:55 --> Helper loaded: form_helper
INFO - 2023-01-07 05:59:55 --> Helper loaded: my_helper
INFO - 2023-01-07 05:59:55 --> Database Driver Class Initialized
DEBUG - 2023-01-07 05:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 05:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 05:59:55 --> Controller Class Initialized
DEBUG - 2023-01-07 05:59:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 05:59:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 05:59:55 --> Final output sent to browser
DEBUG - 2023-01-07 05:59:55 --> Total execution time: 0.0405
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:13 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:13 --> URI Class Initialized
INFO - 2023-01-07 06:03:13 --> Router Class Initialized
INFO - 2023-01-07 06:03:13 --> Output Class Initialized
INFO - 2023-01-07 06:03:13 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:13 --> Input Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Loader Class Initialized
INFO - 2023-01-07 06:03:13 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:13 --> Controller Class Initialized
INFO - 2023-01-07 06:03:13 --> Helper loaded: cookie_helper
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:13 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:13 --> URI Class Initialized
INFO - 2023-01-07 06:03:13 --> Router Class Initialized
INFO - 2023-01-07 06:03:13 --> Output Class Initialized
INFO - 2023-01-07 06:03:13 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:13 --> Input Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Loader Class Initialized
INFO - 2023-01-07 06:03:13 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:13 --> Controller Class Initialized
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:13 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:13 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:13 --> URI Class Initialized
INFO - 2023-01-07 06:03:13 --> Router Class Initialized
INFO - 2023-01-07 06:03:13 --> Output Class Initialized
INFO - 2023-01-07 06:03:13 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:13 --> Input Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Language Class Initialized
INFO - 2023-01-07 06:03:13 --> Config Class Initialized
INFO - 2023-01-07 06:03:13 --> Loader Class Initialized
INFO - 2023-01-07 06:03:13 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:13 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:13 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:13 --> Controller Class Initialized
DEBUG - 2023-01-07 06:03:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 06:03:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:03:13 --> Final output sent to browser
DEBUG - 2023-01-07 06:03:13 --> Total execution time: 0.0224
INFO - 2023-01-07 06:03:19 --> Config Class Initialized
INFO - 2023-01-07 06:03:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:19 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:19 --> URI Class Initialized
INFO - 2023-01-07 06:03:19 --> Router Class Initialized
INFO - 2023-01-07 06:03:19 --> Output Class Initialized
INFO - 2023-01-07 06:03:19 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:19 --> Input Class Initialized
INFO - 2023-01-07 06:03:19 --> Language Class Initialized
INFO - 2023-01-07 06:03:19 --> Language Class Initialized
INFO - 2023-01-07 06:03:19 --> Config Class Initialized
INFO - 2023-01-07 06:03:19 --> Loader Class Initialized
INFO - 2023-01-07 06:03:19 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:19 --> Controller Class Initialized
INFO - 2023-01-07 06:03:19 --> Helper loaded: cookie_helper
INFO - 2023-01-07 06:03:19 --> Final output sent to browser
DEBUG - 2023-01-07 06:03:19 --> Total execution time: 0.0325
INFO - 2023-01-07 06:03:19 --> Config Class Initialized
INFO - 2023-01-07 06:03:19 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:19 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:19 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:19 --> URI Class Initialized
INFO - 2023-01-07 06:03:19 --> Router Class Initialized
INFO - 2023-01-07 06:03:19 --> Output Class Initialized
INFO - 2023-01-07 06:03:19 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:19 --> Input Class Initialized
INFO - 2023-01-07 06:03:19 --> Language Class Initialized
INFO - 2023-01-07 06:03:19 --> Language Class Initialized
INFO - 2023-01-07 06:03:19 --> Config Class Initialized
INFO - 2023-01-07 06:03:19 --> Loader Class Initialized
INFO - 2023-01-07 06:03:19 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:19 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:19 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:19 --> Controller Class Initialized
DEBUG - 2023-01-07 06:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-07 06:03:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:03:19 --> Final output sent to browser
DEBUG - 2023-01-07 06:03:19 --> Total execution time: 0.0394
INFO - 2023-01-07 06:03:25 --> Config Class Initialized
INFO - 2023-01-07 06:03:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:25 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:25 --> URI Class Initialized
INFO - 2023-01-07 06:03:25 --> Router Class Initialized
INFO - 2023-01-07 06:03:25 --> Output Class Initialized
INFO - 2023-01-07 06:03:25 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:25 --> Input Class Initialized
INFO - 2023-01-07 06:03:25 --> Language Class Initialized
INFO - 2023-01-07 06:03:25 --> Language Class Initialized
INFO - 2023-01-07 06:03:25 --> Config Class Initialized
INFO - 2023-01-07 06:03:25 --> Loader Class Initialized
INFO - 2023-01-07 06:03:25 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:25 --> Controller Class Initialized
DEBUG - 2023-01-07 06:03:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/tahun/views/list.php
DEBUG - 2023-01-07 06:03:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:03:25 --> Final output sent to browser
DEBUG - 2023-01-07 06:03:25 --> Total execution time: 0.0437
INFO - 2023-01-07 06:03:25 --> Config Class Initialized
INFO - 2023-01-07 06:03:25 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:25 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:25 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:25 --> URI Class Initialized
INFO - 2023-01-07 06:03:25 --> Router Class Initialized
INFO - 2023-01-07 06:03:25 --> Output Class Initialized
INFO - 2023-01-07 06:03:25 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:25 --> Input Class Initialized
INFO - 2023-01-07 06:03:25 --> Language Class Initialized
INFO - 2023-01-07 06:03:25 --> Language Class Initialized
INFO - 2023-01-07 06:03:25 --> Config Class Initialized
INFO - 2023-01-07 06:03:25 --> Loader Class Initialized
INFO - 2023-01-07 06:03:25 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:25 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:25 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:25 --> Controller Class Initialized
INFO - 2023-01-07 06:03:27 --> Config Class Initialized
INFO - 2023-01-07 06:03:27 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:03:27 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:03:27 --> Utf8 Class Initialized
INFO - 2023-01-07 06:03:27 --> URI Class Initialized
INFO - 2023-01-07 06:03:27 --> Router Class Initialized
INFO - 2023-01-07 06:03:27 --> Output Class Initialized
INFO - 2023-01-07 06:03:27 --> Security Class Initialized
DEBUG - 2023-01-07 06:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:03:27 --> Input Class Initialized
INFO - 2023-01-07 06:03:27 --> Language Class Initialized
INFO - 2023-01-07 06:03:27 --> Language Class Initialized
INFO - 2023-01-07 06:03:27 --> Config Class Initialized
INFO - 2023-01-07 06:03:27 --> Loader Class Initialized
INFO - 2023-01-07 06:03:27 --> Helper loaded: url_helper
INFO - 2023-01-07 06:03:27 --> Helper loaded: file_helper
INFO - 2023-01-07 06:03:27 --> Helper loaded: form_helper
INFO - 2023-01-07 06:03:27 --> Helper loaded: my_helper
INFO - 2023-01-07 06:03:27 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:03:27 --> Controller Class Initialized
INFO - 2023-01-07 06:03:27 --> Final output sent to browser
DEBUG - 2023-01-07 06:03:27 --> Total execution time: 0.0265
INFO - 2023-01-07 06:06:24 --> Config Class Initialized
INFO - 2023-01-07 06:06:24 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:24 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:24 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:24 --> URI Class Initialized
INFO - 2023-01-07 06:06:24 --> Router Class Initialized
INFO - 2023-01-07 06:06:24 --> Output Class Initialized
INFO - 2023-01-07 06:06:24 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:24 --> Input Class Initialized
INFO - 2023-01-07 06:06:24 --> Language Class Initialized
INFO - 2023-01-07 06:06:24 --> Language Class Initialized
INFO - 2023-01-07 06:06:24 --> Config Class Initialized
INFO - 2023-01-07 06:06:24 --> Loader Class Initialized
INFO - 2023-01-07 06:06:24 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:24 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:24 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:24 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:24 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:24 --> Controller Class Initialized
DEBUG - 2023-01-07 06:06:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 06:06:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:24 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:24 --> Total execution time: 0.0389
INFO - 2023-01-07 06:06:28 --> Config Class Initialized
INFO - 2023-01-07 06:06:28 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:28 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:28 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:28 --> URI Class Initialized
INFO - 2023-01-07 06:06:28 --> Router Class Initialized
INFO - 2023-01-07 06:06:28 --> Output Class Initialized
INFO - 2023-01-07 06:06:28 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:28 --> Input Class Initialized
INFO - 2023-01-07 06:06:28 --> Language Class Initialized
INFO - 2023-01-07 06:06:28 --> Language Class Initialized
INFO - 2023-01-07 06:06:28 --> Config Class Initialized
INFO - 2023-01-07 06:06:28 --> Loader Class Initialized
INFO - 2023-01-07 06:06:28 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:28 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:28 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:28 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:28 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:28 --> Controller Class Initialized
INFO - 2023-01-07 06:06:28 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:28 --> Total execution time: 0.0303
INFO - 2023-01-07 06:06:30 --> Config Class Initialized
INFO - 2023-01-07 06:06:30 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:30 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:30 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:30 --> URI Class Initialized
INFO - 2023-01-07 06:06:30 --> Router Class Initialized
INFO - 2023-01-07 06:06:30 --> Output Class Initialized
INFO - 2023-01-07 06:06:30 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:30 --> Input Class Initialized
INFO - 2023-01-07 06:06:30 --> Language Class Initialized
INFO - 2023-01-07 06:06:30 --> Language Class Initialized
INFO - 2023-01-07 06:06:30 --> Config Class Initialized
INFO - 2023-01-07 06:06:30 --> Loader Class Initialized
INFO - 2023-01-07 06:06:30 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:30 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:30 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:30 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:30 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:30 --> Controller Class Initialized
ERROR - 2023-01-07 06:06:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-07 06:06:30 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-07 06:06:30 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-07 06:06:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-07 06:06:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:30 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:30 --> Total execution time: 0.0415
INFO - 2023-01-07 06:06:37 --> Config Class Initialized
INFO - 2023-01-07 06:06:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:37 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:37 --> URI Class Initialized
INFO - 2023-01-07 06:06:37 --> Router Class Initialized
INFO - 2023-01-07 06:06:37 --> Output Class Initialized
INFO - 2023-01-07 06:06:37 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:37 --> Input Class Initialized
INFO - 2023-01-07 06:06:37 --> Language Class Initialized
INFO - 2023-01-07 06:06:37 --> Language Class Initialized
INFO - 2023-01-07 06:06:37 --> Config Class Initialized
INFO - 2023-01-07 06:06:37 --> Loader Class Initialized
INFO - 2023-01-07 06:06:37 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:37 --> Controller Class Initialized
INFO - 2023-01-07 06:06:37 --> Config Class Initialized
INFO - 2023-01-07 06:06:37 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:37 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:37 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:37 --> URI Class Initialized
INFO - 2023-01-07 06:06:37 --> Router Class Initialized
INFO - 2023-01-07 06:06:37 --> Output Class Initialized
INFO - 2023-01-07 06:06:37 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:37 --> Input Class Initialized
INFO - 2023-01-07 06:06:37 --> Language Class Initialized
INFO - 2023-01-07 06:06:37 --> Language Class Initialized
INFO - 2023-01-07 06:06:37 --> Config Class Initialized
INFO - 2023-01-07 06:06:37 --> Loader Class Initialized
INFO - 2023-01-07 06:06:37 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:37 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:37 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:37 --> Controller Class Initialized
DEBUG - 2023-01-07 06:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-07 06:06:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:37 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:37 --> Total execution time: 0.0264
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:48 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:48 --> URI Class Initialized
INFO - 2023-01-07 06:06:48 --> Router Class Initialized
INFO - 2023-01-07 06:06:48 --> Output Class Initialized
INFO - 2023-01-07 06:06:48 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:48 --> Input Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Loader Class Initialized
INFO - 2023-01-07 06:06:48 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:48 --> Controller Class Initialized
INFO - 2023-01-07 06:06:48 --> Helper loaded: cookie_helper
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:48 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:48 --> URI Class Initialized
INFO - 2023-01-07 06:06:48 --> Router Class Initialized
INFO - 2023-01-07 06:06:48 --> Output Class Initialized
INFO - 2023-01-07 06:06:48 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:48 --> Input Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Loader Class Initialized
INFO - 2023-01-07 06:06:48 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:48 --> Controller Class Initialized
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:48 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:48 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:48 --> URI Class Initialized
INFO - 2023-01-07 06:06:48 --> Router Class Initialized
INFO - 2023-01-07 06:06:48 --> Output Class Initialized
INFO - 2023-01-07 06:06:48 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:48 --> Input Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Language Class Initialized
INFO - 2023-01-07 06:06:48 --> Config Class Initialized
INFO - 2023-01-07 06:06:48 --> Loader Class Initialized
INFO - 2023-01-07 06:06:48 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:48 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:48 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:48 --> Controller Class Initialized
DEBUG - 2023-01-07 06:06:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-07 06:06:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:48 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:48 --> Total execution time: 0.0417
INFO - 2023-01-07 06:06:52 --> Config Class Initialized
INFO - 2023-01-07 06:06:52 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:52 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:52 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:52 --> URI Class Initialized
INFO - 2023-01-07 06:06:53 --> Router Class Initialized
INFO - 2023-01-07 06:06:53 --> Output Class Initialized
INFO - 2023-01-07 06:06:53 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:53 --> Input Class Initialized
INFO - 2023-01-07 06:06:53 --> Language Class Initialized
INFO - 2023-01-07 06:06:53 --> Language Class Initialized
INFO - 2023-01-07 06:06:53 --> Config Class Initialized
INFO - 2023-01-07 06:06:53 --> Loader Class Initialized
INFO - 2023-01-07 06:06:53 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:53 --> Controller Class Initialized
INFO - 2023-01-07 06:06:53 --> Helper loaded: cookie_helper
INFO - 2023-01-07 06:06:53 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:53 --> Total execution time: 0.0331
INFO - 2023-01-07 06:06:53 --> Config Class Initialized
INFO - 2023-01-07 06:06:53 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:53 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:53 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:53 --> URI Class Initialized
INFO - 2023-01-07 06:06:53 --> Router Class Initialized
INFO - 2023-01-07 06:06:53 --> Output Class Initialized
INFO - 2023-01-07 06:06:53 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:53 --> Input Class Initialized
INFO - 2023-01-07 06:06:53 --> Language Class Initialized
INFO - 2023-01-07 06:06:53 --> Language Class Initialized
INFO - 2023-01-07 06:06:53 --> Config Class Initialized
INFO - 2023-01-07 06:06:53 --> Loader Class Initialized
INFO - 2023-01-07 06:06:53 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:53 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:53 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:53 --> Controller Class Initialized
DEBUG - 2023-01-07 06:06:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-07 06:06:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:53 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:53 --> Total execution time: 0.0454
INFO - 2023-01-07 06:06:58 --> Config Class Initialized
INFO - 2023-01-07 06:06:58 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:06:58 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:06:58 --> Utf8 Class Initialized
INFO - 2023-01-07 06:06:58 --> URI Class Initialized
INFO - 2023-01-07 06:06:58 --> Router Class Initialized
INFO - 2023-01-07 06:06:58 --> Output Class Initialized
INFO - 2023-01-07 06:06:58 --> Security Class Initialized
DEBUG - 2023-01-07 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:06:58 --> Input Class Initialized
INFO - 2023-01-07 06:06:58 --> Language Class Initialized
INFO - 2023-01-07 06:06:58 --> Language Class Initialized
INFO - 2023-01-07 06:06:58 --> Config Class Initialized
INFO - 2023-01-07 06:06:58 --> Loader Class Initialized
INFO - 2023-01-07 06:06:58 --> Helper loaded: url_helper
INFO - 2023-01-07 06:06:58 --> Helper loaded: file_helper
INFO - 2023-01-07 06:06:58 --> Helper loaded: form_helper
INFO - 2023-01-07 06:06:58 --> Helper loaded: my_helper
INFO - 2023-01-07 06:06:58 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:06:58 --> Controller Class Initialized
DEBUG - 2023-01-07 06:06:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 06:06:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:06:58 --> Final output sent to browser
DEBUG - 2023-01-07 06:06:58 --> Total execution time: 0.0256
INFO - 2023-01-07 06:07:01 --> Config Class Initialized
INFO - 2023-01-07 06:07:01 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:01 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:01 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:01 --> URI Class Initialized
INFO - 2023-01-07 06:07:01 --> Router Class Initialized
INFO - 2023-01-07 06:07:01 --> Output Class Initialized
INFO - 2023-01-07 06:07:01 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:01 --> Input Class Initialized
INFO - 2023-01-07 06:07:01 --> Language Class Initialized
INFO - 2023-01-07 06:07:01 --> Language Class Initialized
INFO - 2023-01-07 06:07:01 --> Config Class Initialized
INFO - 2023-01-07 06:07:01 --> Loader Class Initialized
INFO - 2023-01-07 06:07:01 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:01 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:01 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:01 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:01 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:01 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 06:07:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:07:01 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:01 --> Total execution time: 0.0375
INFO - 2023-01-07 06:07:03 --> Config Class Initialized
INFO - 2023-01-07 06:07:03 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:03 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:03 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:03 --> URI Class Initialized
INFO - 2023-01-07 06:07:03 --> Router Class Initialized
INFO - 2023-01-07 06:07:03 --> Output Class Initialized
INFO - 2023-01-07 06:07:03 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:03 --> Input Class Initialized
INFO - 2023-01-07 06:07:03 --> Language Class Initialized
INFO - 2023-01-07 06:07:03 --> Language Class Initialized
INFO - 2023-01-07 06:07:03 --> Config Class Initialized
INFO - 2023-01-07 06:07:03 --> Loader Class Initialized
INFO - 2023-01-07 06:07:03 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:03 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:03 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:03 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:03 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:03 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-07 06:07:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:07:03 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:03 --> Total execution time: 0.0246
INFO - 2023-01-07 06:07:05 --> Config Class Initialized
INFO - 2023-01-07 06:07:05 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:05 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:05 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:05 --> URI Class Initialized
INFO - 2023-01-07 06:07:05 --> Router Class Initialized
INFO - 2023-01-07 06:07:05 --> Output Class Initialized
INFO - 2023-01-07 06:07:05 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:05 --> Input Class Initialized
INFO - 2023-01-07 06:07:05 --> Language Class Initialized
INFO - 2023-01-07 06:07:05 --> Language Class Initialized
INFO - 2023-01-07 06:07:05 --> Config Class Initialized
INFO - 2023-01-07 06:07:05 --> Loader Class Initialized
INFO - 2023-01-07 06:07:05 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:05 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:05 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:05 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:05 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:05 --> Controller Class Initialized
INFO - 2023-01-07 06:07:05 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:05 --> Total execution time: 0.0255
INFO - 2023-01-07 06:07:07 --> Config Class Initialized
INFO - 2023-01-07 06:07:07 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:07 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:07 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:07 --> URI Class Initialized
INFO - 2023-01-07 06:07:07 --> Router Class Initialized
INFO - 2023-01-07 06:07:07 --> Output Class Initialized
INFO - 2023-01-07 06:07:07 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:07 --> Input Class Initialized
INFO - 2023-01-07 06:07:07 --> Language Class Initialized
INFO - 2023-01-07 06:07:07 --> Language Class Initialized
INFO - 2023-01-07 06:07:07 --> Config Class Initialized
INFO - 2023-01-07 06:07:07 --> Loader Class Initialized
INFO - 2023-01-07 06:07:07 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:07 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:07 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:07 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:07 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:07 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-07 06:07:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:07:07 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:07 --> Total execution time: 0.0246
INFO - 2023-01-07 06:07:08 --> Config Class Initialized
INFO - 2023-01-07 06:07:08 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:08 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:08 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:08 --> URI Class Initialized
INFO - 2023-01-07 06:07:08 --> Router Class Initialized
INFO - 2023-01-07 06:07:08 --> Output Class Initialized
INFO - 2023-01-07 06:07:08 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:08 --> Input Class Initialized
INFO - 2023-01-07 06:07:08 --> Language Class Initialized
INFO - 2023-01-07 06:07:08 --> Language Class Initialized
INFO - 2023-01-07 06:07:08 --> Config Class Initialized
INFO - 2023-01-07 06:07:08 --> Loader Class Initialized
INFO - 2023-01-07 06:07:08 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:08 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:08 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:08 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:08 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:08 --> Controller Class Initialized
INFO - 2023-01-07 06:07:08 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:08 --> Total execution time: 0.0260
INFO - 2023-01-07 06:07:10 --> Config Class Initialized
INFO - 2023-01-07 06:07:10 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:10 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:10 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:10 --> URI Class Initialized
INFO - 2023-01-07 06:07:10 --> Router Class Initialized
INFO - 2023-01-07 06:07:10 --> Output Class Initialized
INFO - 2023-01-07 06:07:10 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:10 --> Input Class Initialized
INFO - 2023-01-07 06:07:10 --> Language Class Initialized
INFO - 2023-01-07 06:07:10 --> Language Class Initialized
INFO - 2023-01-07 06:07:10 --> Config Class Initialized
INFO - 2023-01-07 06:07:10 --> Loader Class Initialized
INFO - 2023-01-07 06:07:10 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:10 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:10 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:10 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:10 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:10 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-07 06:07:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:07:10 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:10 --> Total execution time: 0.0239
INFO - 2023-01-07 06:07:11 --> Config Class Initialized
INFO - 2023-01-07 06:07:11 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:11 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:11 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:11 --> URI Class Initialized
INFO - 2023-01-07 06:07:11 --> Router Class Initialized
INFO - 2023-01-07 06:07:11 --> Output Class Initialized
INFO - 2023-01-07 06:07:11 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:11 --> Input Class Initialized
INFO - 2023-01-07 06:07:11 --> Language Class Initialized
INFO - 2023-01-07 06:07:11 --> Language Class Initialized
INFO - 2023-01-07 06:07:11 --> Config Class Initialized
INFO - 2023-01-07 06:07:11 --> Loader Class Initialized
INFO - 2023-01-07 06:07:11 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:11 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:11 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:11 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:11 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:11 --> Controller Class Initialized
INFO - 2023-01-07 06:07:11 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:11 --> Total execution time: 0.0238
INFO - 2023-01-07 06:07:14 --> Config Class Initialized
INFO - 2023-01-07 06:07:14 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:14 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:14 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:14 --> URI Class Initialized
INFO - 2023-01-07 06:07:14 --> Router Class Initialized
INFO - 2023-01-07 06:07:14 --> Output Class Initialized
INFO - 2023-01-07 06:07:15 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:15 --> Input Class Initialized
INFO - 2023-01-07 06:07:15 --> Language Class Initialized
INFO - 2023-01-07 06:07:15 --> Language Class Initialized
INFO - 2023-01-07 06:07:15 --> Config Class Initialized
INFO - 2023-01-07 06:07:15 --> Loader Class Initialized
INFO - 2023-01-07 06:07:15 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:15 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:15 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:15 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:15 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:15 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-07 06:07:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-07 06:07:15 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:15 --> Total execution time: 0.0380
INFO - 2023-01-07 06:07:16 --> Config Class Initialized
INFO - 2023-01-07 06:07:16 --> Hooks Class Initialized
DEBUG - 2023-01-07 06:07:16 --> UTF-8 Support Enabled
INFO - 2023-01-07 06:07:16 --> Utf8 Class Initialized
INFO - 2023-01-07 06:07:16 --> URI Class Initialized
INFO - 2023-01-07 06:07:16 --> Router Class Initialized
INFO - 2023-01-07 06:07:16 --> Output Class Initialized
INFO - 2023-01-07 06:07:16 --> Security Class Initialized
DEBUG - 2023-01-07 06:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-07 06:07:16 --> Input Class Initialized
INFO - 2023-01-07 06:07:16 --> Language Class Initialized
INFO - 2023-01-07 06:07:16 --> Language Class Initialized
INFO - 2023-01-07 06:07:16 --> Config Class Initialized
INFO - 2023-01-07 06:07:16 --> Loader Class Initialized
INFO - 2023-01-07 06:07:16 --> Helper loaded: url_helper
INFO - 2023-01-07 06:07:16 --> Helper loaded: file_helper
INFO - 2023-01-07 06:07:16 --> Helper loaded: form_helper
INFO - 2023-01-07 06:07:16 --> Helper loaded: my_helper
INFO - 2023-01-07 06:07:16 --> Database Driver Class Initialized
DEBUG - 2023-01-07 06:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-07 06:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-07 06:07:16 --> Controller Class Initialized
DEBUG - 2023-01-07 06:07:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-07 06:07:16 --> Final output sent to browser
DEBUG - 2023-01-07 06:07:16 --> Total execution time: 0.1531
