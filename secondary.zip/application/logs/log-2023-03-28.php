<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-28 05:36:46 --> Config Class Initialized
INFO - 2023-03-28 05:36:46 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:36:46 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:36:46 --> Utf8 Class Initialized
INFO - 2023-03-28 05:36:46 --> URI Class Initialized
DEBUG - 2023-03-28 05:36:46 --> No URI present. Default controller set.
INFO - 2023-03-28 05:36:46 --> Router Class Initialized
INFO - 2023-03-28 05:36:46 --> Output Class Initialized
INFO - 2023-03-28 05:36:46 --> Security Class Initialized
DEBUG - 2023-03-28 05:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:36:46 --> Input Class Initialized
INFO - 2023-03-28 05:36:46 --> Language Class Initialized
INFO - 2023-03-28 05:36:46 --> Language Class Initialized
INFO - 2023-03-28 05:36:46 --> Config Class Initialized
INFO - 2023-03-28 05:36:46 --> Loader Class Initialized
INFO - 2023-03-28 05:36:46 --> Helper loaded: url_helper
INFO - 2023-03-28 05:36:46 --> Helper loaded: file_helper
INFO - 2023-03-28 05:36:46 --> Helper loaded: form_helper
INFO - 2023-03-28 05:36:46 --> Helper loaded: my_helper
INFO - 2023-03-28 05:36:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:36:46 --> Controller Class Initialized
INFO - 2023-03-28 05:36:47 --> Config Class Initialized
INFO - 2023-03-28 05:36:47 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:36:47 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:36:47 --> Utf8 Class Initialized
INFO - 2023-03-28 05:36:47 --> URI Class Initialized
INFO - 2023-03-28 05:36:47 --> Router Class Initialized
INFO - 2023-03-28 05:36:47 --> Output Class Initialized
INFO - 2023-03-28 05:36:47 --> Security Class Initialized
DEBUG - 2023-03-28 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:36:47 --> Input Class Initialized
INFO - 2023-03-28 05:36:47 --> Language Class Initialized
INFO - 2023-03-28 05:36:47 --> Language Class Initialized
INFO - 2023-03-28 05:36:47 --> Config Class Initialized
INFO - 2023-03-28 05:36:47 --> Loader Class Initialized
INFO - 2023-03-28 05:36:47 --> Helper loaded: url_helper
INFO - 2023-03-28 05:36:47 --> Helper loaded: file_helper
INFO - 2023-03-28 05:36:47 --> Helper loaded: form_helper
INFO - 2023-03-28 05:36:47 --> Helper loaded: my_helper
INFO - 2023-03-28 05:36:47 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:36:47 --> Controller Class Initialized
DEBUG - 2023-03-28 05:36:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 05:36:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:36:47 --> Final output sent to browser
DEBUG - 2023-03-28 05:36:47 --> Total execution time: 0.1039
INFO - 2023-03-28 05:36:52 --> Config Class Initialized
INFO - 2023-03-28 05:36:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:36:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:36:52 --> Utf8 Class Initialized
INFO - 2023-03-28 05:36:52 --> URI Class Initialized
INFO - 2023-03-28 05:36:52 --> Router Class Initialized
INFO - 2023-03-28 05:36:52 --> Output Class Initialized
INFO - 2023-03-28 05:36:52 --> Security Class Initialized
DEBUG - 2023-03-28 05:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:36:52 --> Input Class Initialized
INFO - 2023-03-28 05:36:52 --> Language Class Initialized
INFO - 2023-03-28 05:36:52 --> Language Class Initialized
INFO - 2023-03-28 05:36:52 --> Config Class Initialized
INFO - 2023-03-28 05:36:52 --> Loader Class Initialized
INFO - 2023-03-28 05:36:52 --> Helper loaded: url_helper
INFO - 2023-03-28 05:36:52 --> Helper loaded: file_helper
INFO - 2023-03-28 05:36:52 --> Helper loaded: form_helper
INFO - 2023-03-28 05:36:52 --> Helper loaded: my_helper
INFO - 2023-03-28 05:36:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:36:52 --> Controller Class Initialized
INFO - 2023-03-28 05:36:52 --> Final output sent to browser
DEBUG - 2023-03-28 05:36:52 --> Total execution time: 0.0566
INFO - 2023-03-28 05:36:58 --> Config Class Initialized
INFO - 2023-03-28 05:36:58 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:36:58 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:36:58 --> Utf8 Class Initialized
INFO - 2023-03-28 05:36:58 --> URI Class Initialized
INFO - 2023-03-28 05:36:58 --> Router Class Initialized
INFO - 2023-03-28 05:36:58 --> Output Class Initialized
INFO - 2023-03-28 05:36:58 --> Security Class Initialized
DEBUG - 2023-03-28 05:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:36:58 --> Input Class Initialized
INFO - 2023-03-28 05:36:58 --> Language Class Initialized
INFO - 2023-03-28 05:36:58 --> Language Class Initialized
INFO - 2023-03-28 05:36:58 --> Config Class Initialized
INFO - 2023-03-28 05:36:58 --> Loader Class Initialized
INFO - 2023-03-28 05:36:58 --> Helper loaded: url_helper
INFO - 2023-03-28 05:36:58 --> Helper loaded: file_helper
INFO - 2023-03-28 05:36:58 --> Helper loaded: form_helper
INFO - 2023-03-28 05:36:58 --> Helper loaded: my_helper
INFO - 2023-03-28 05:36:58 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:36:58 --> Controller Class Initialized
INFO - 2023-03-28 05:36:58 --> Final output sent to browser
DEBUG - 2023-03-28 05:36:58 --> Total execution time: 0.0254
INFO - 2023-03-28 05:37:32 --> Config Class Initialized
INFO - 2023-03-28 05:37:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:32 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:32 --> URI Class Initialized
INFO - 2023-03-28 05:37:32 --> Router Class Initialized
INFO - 2023-03-28 05:37:32 --> Output Class Initialized
INFO - 2023-03-28 05:37:32 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:32 --> Input Class Initialized
INFO - 2023-03-28 05:37:32 --> Language Class Initialized
INFO - 2023-03-28 05:37:32 --> Language Class Initialized
INFO - 2023-03-28 05:37:32 --> Config Class Initialized
INFO - 2023-03-28 05:37:32 --> Loader Class Initialized
INFO - 2023-03-28 05:37:32 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:32 --> Controller Class Initialized
INFO - 2023-03-28 05:37:32 --> Helper loaded: cookie_helper
INFO - 2023-03-28 05:37:32 --> Final output sent to browser
DEBUG - 2023-03-28 05:37:32 --> Total execution time: 0.0641
INFO - 2023-03-28 05:37:32 --> Config Class Initialized
INFO - 2023-03-28 05:37:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:32 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:32 --> URI Class Initialized
INFO - 2023-03-28 05:37:32 --> Router Class Initialized
INFO - 2023-03-28 05:37:32 --> Output Class Initialized
INFO - 2023-03-28 05:37:32 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:32 --> Input Class Initialized
INFO - 2023-03-28 05:37:32 --> Language Class Initialized
INFO - 2023-03-28 05:37:32 --> Language Class Initialized
INFO - 2023-03-28 05:37:32 --> Config Class Initialized
INFO - 2023-03-28 05:37:32 --> Loader Class Initialized
INFO - 2023-03-28 05:37:32 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:32 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:32 --> Controller Class Initialized
DEBUG - 2023-03-28 05:37:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-03-28 05:37:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:37:32 --> Final output sent to browser
DEBUG - 2023-03-28 05:37:32 --> Total execution time: 0.0489
INFO - 2023-03-28 05:37:54 --> Config Class Initialized
INFO - 2023-03-28 05:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:54 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:54 --> URI Class Initialized
INFO - 2023-03-28 05:37:54 --> Router Class Initialized
INFO - 2023-03-28 05:37:54 --> Output Class Initialized
INFO - 2023-03-28 05:37:54 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:54 --> Input Class Initialized
INFO - 2023-03-28 05:37:54 --> Language Class Initialized
INFO - 2023-03-28 05:37:54 --> Language Class Initialized
INFO - 2023-03-28 05:37:54 --> Config Class Initialized
INFO - 2023-03-28 05:37:54 --> Loader Class Initialized
INFO - 2023-03-28 05:37:54 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:54 --> Controller Class Initialized
DEBUG - 2023-03-28 05:37:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-03-28 05:37:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:37:54 --> Final output sent to browser
DEBUG - 2023-03-28 05:37:54 --> Total execution time: 0.0750
INFO - 2023-03-28 05:37:54 --> Config Class Initialized
INFO - 2023-03-28 05:37:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:54 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:54 --> URI Class Initialized
INFO - 2023-03-28 05:37:54 --> Router Class Initialized
INFO - 2023-03-28 05:37:54 --> Output Class Initialized
INFO - 2023-03-28 05:37:54 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:54 --> Input Class Initialized
INFO - 2023-03-28 05:37:54 --> Language Class Initialized
INFO - 2023-03-28 05:37:54 --> Language Class Initialized
INFO - 2023-03-28 05:37:54 --> Config Class Initialized
INFO - 2023-03-28 05:37:54 --> Loader Class Initialized
INFO - 2023-03-28 05:37:54 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:54 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:54 --> Controller Class Initialized
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:57 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:57 --> URI Class Initialized
INFO - 2023-03-28 05:37:57 --> Router Class Initialized
INFO - 2023-03-28 05:37:57 --> Output Class Initialized
INFO - 2023-03-28 05:37:57 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:57 --> Input Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Loader Class Initialized
INFO - 2023-03-28 05:37:57 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:57 --> Controller Class Initialized
INFO - 2023-03-28 05:37:57 --> Helper loaded: cookie_helper
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:57 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:57 --> URI Class Initialized
INFO - 2023-03-28 05:37:57 --> Router Class Initialized
INFO - 2023-03-28 05:37:57 --> Output Class Initialized
INFO - 2023-03-28 05:37:57 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:57 --> Input Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Loader Class Initialized
INFO - 2023-03-28 05:37:57 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:57 --> Controller Class Initialized
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:37:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:37:57 --> Utf8 Class Initialized
INFO - 2023-03-28 05:37:57 --> URI Class Initialized
INFO - 2023-03-28 05:37:57 --> Router Class Initialized
INFO - 2023-03-28 05:37:57 --> Output Class Initialized
INFO - 2023-03-28 05:37:57 --> Security Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:37:57 --> Input Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Language Class Initialized
INFO - 2023-03-28 05:37:57 --> Config Class Initialized
INFO - 2023-03-28 05:37:57 --> Loader Class Initialized
INFO - 2023-03-28 05:37:57 --> Helper loaded: url_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: file_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: form_helper
INFO - 2023-03-28 05:37:57 --> Helper loaded: my_helper
INFO - 2023-03-28 05:37:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:37:57 --> Controller Class Initialized
DEBUG - 2023-03-28 05:37:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 05:37:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:37:57 --> Final output sent to browser
DEBUG - 2023-03-28 05:37:57 --> Total execution time: 0.0241
INFO - 2023-03-28 05:38:02 --> Config Class Initialized
INFO - 2023-03-28 05:38:02 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:38:02 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:38:02 --> Utf8 Class Initialized
INFO - 2023-03-28 05:38:02 --> URI Class Initialized
INFO - 2023-03-28 05:38:02 --> Router Class Initialized
INFO - 2023-03-28 05:38:02 --> Output Class Initialized
INFO - 2023-03-28 05:38:02 --> Security Class Initialized
DEBUG - 2023-03-28 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:38:02 --> Input Class Initialized
INFO - 2023-03-28 05:38:02 --> Language Class Initialized
INFO - 2023-03-28 05:38:02 --> Language Class Initialized
INFO - 2023-03-28 05:38:02 --> Config Class Initialized
INFO - 2023-03-28 05:38:02 --> Loader Class Initialized
INFO - 2023-03-28 05:38:02 --> Helper loaded: url_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: file_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: form_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: my_helper
INFO - 2023-03-28 05:38:02 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:38:02 --> Controller Class Initialized
INFO - 2023-03-28 05:38:02 --> Helper loaded: cookie_helper
INFO - 2023-03-28 05:38:02 --> Final output sent to browser
DEBUG - 2023-03-28 05:38:02 --> Total execution time: 0.0296
INFO - 2023-03-28 05:38:02 --> Config Class Initialized
INFO - 2023-03-28 05:38:02 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:38:02 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:38:02 --> Utf8 Class Initialized
INFO - 2023-03-28 05:38:02 --> URI Class Initialized
INFO - 2023-03-28 05:38:02 --> Router Class Initialized
INFO - 2023-03-28 05:38:02 --> Output Class Initialized
INFO - 2023-03-28 05:38:02 --> Security Class Initialized
DEBUG - 2023-03-28 05:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:38:02 --> Input Class Initialized
INFO - 2023-03-28 05:38:02 --> Language Class Initialized
INFO - 2023-03-28 05:38:02 --> Language Class Initialized
INFO - 2023-03-28 05:38:02 --> Config Class Initialized
INFO - 2023-03-28 05:38:02 --> Loader Class Initialized
INFO - 2023-03-28 05:38:02 --> Helper loaded: url_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: file_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: form_helper
INFO - 2023-03-28 05:38:02 --> Helper loaded: my_helper
INFO - 2023-03-28 05:38:02 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:38:02 --> Controller Class Initialized
DEBUG - 2023-03-28 05:38:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 05:38:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:38:02 --> Final output sent to browser
DEBUG - 2023-03-28 05:38:02 --> Total execution time: 0.0442
INFO - 2023-03-28 05:38:11 --> Config Class Initialized
INFO - 2023-03-28 05:38:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:38:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:38:11 --> Utf8 Class Initialized
INFO - 2023-03-28 05:38:11 --> URI Class Initialized
INFO - 2023-03-28 05:38:11 --> Router Class Initialized
INFO - 2023-03-28 05:38:11 --> Output Class Initialized
INFO - 2023-03-28 05:38:11 --> Security Class Initialized
DEBUG - 2023-03-28 05:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:38:11 --> Input Class Initialized
INFO - 2023-03-28 05:38:11 --> Language Class Initialized
INFO - 2023-03-28 05:38:11 --> Language Class Initialized
INFO - 2023-03-28 05:38:11 --> Config Class Initialized
INFO - 2023-03-28 05:38:11 --> Loader Class Initialized
INFO - 2023-03-28 05:38:11 --> Helper loaded: url_helper
INFO - 2023-03-28 05:38:11 --> Helper loaded: file_helper
INFO - 2023-03-28 05:38:11 --> Helper loaded: form_helper
INFO - 2023-03-28 05:38:11 --> Helper loaded: my_helper
INFO - 2023-03-28 05:38:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:38:11 --> Controller Class Initialized
DEBUG - 2023-03-28 05:38:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 05:38:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 05:38:11 --> Final output sent to browser
DEBUG - 2023-03-28 05:38:11 --> Total execution time: 0.0665
INFO - 2023-03-28 05:38:13 --> Config Class Initialized
INFO - 2023-03-28 05:38:13 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:38:14 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:38:14 --> Utf8 Class Initialized
INFO - 2023-03-28 05:38:14 --> URI Class Initialized
INFO - 2023-03-28 05:38:14 --> Router Class Initialized
INFO - 2023-03-28 05:38:14 --> Output Class Initialized
INFO - 2023-03-28 05:38:14 --> Security Class Initialized
DEBUG - 2023-03-28 05:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:38:14 --> Input Class Initialized
INFO - 2023-03-28 05:38:14 --> Language Class Initialized
INFO - 2023-03-28 05:38:14 --> Language Class Initialized
INFO - 2023-03-28 05:38:14 --> Config Class Initialized
INFO - 2023-03-28 05:38:14 --> Loader Class Initialized
INFO - 2023-03-28 05:38:14 --> Helper loaded: url_helper
INFO - 2023-03-28 05:38:14 --> Helper loaded: file_helper
INFO - 2023-03-28 05:38:14 --> Helper loaded: form_helper
INFO - 2023-03-28 05:38:14 --> Helper loaded: my_helper
INFO - 2023-03-28 05:38:14 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:38:14 --> Controller Class Initialized
DEBUG - 2023-03-28 05:38:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:38:16 --> Final output sent to browser
DEBUG - 2023-03-28 05:38:16 --> Total execution time: 2.0443
INFO - 2023-03-28 05:42:08 --> Config Class Initialized
INFO - 2023-03-28 05:42:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:42:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:42:08 --> Utf8 Class Initialized
INFO - 2023-03-28 05:42:08 --> URI Class Initialized
INFO - 2023-03-28 05:42:08 --> Router Class Initialized
INFO - 2023-03-28 05:42:08 --> Output Class Initialized
INFO - 2023-03-28 05:42:08 --> Security Class Initialized
DEBUG - 2023-03-28 05:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:42:08 --> Input Class Initialized
INFO - 2023-03-28 05:42:08 --> Language Class Initialized
INFO - 2023-03-28 05:42:08 --> Language Class Initialized
INFO - 2023-03-28 05:42:08 --> Config Class Initialized
INFO - 2023-03-28 05:42:08 --> Loader Class Initialized
INFO - 2023-03-28 05:42:08 --> Helper loaded: url_helper
INFO - 2023-03-28 05:42:08 --> Helper loaded: file_helper
INFO - 2023-03-28 05:42:08 --> Helper loaded: form_helper
INFO - 2023-03-28 05:42:08 --> Helper loaded: my_helper
INFO - 2023-03-28 05:42:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:42:08 --> Controller Class Initialized
DEBUG - 2023-03-28 05:42:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:42:09 --> Final output sent to browser
DEBUG - 2023-03-28 05:42:09 --> Total execution time: 1.2333
INFO - 2023-03-28 05:42:56 --> Config Class Initialized
INFO - 2023-03-28 05:42:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:42:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:42:56 --> Utf8 Class Initialized
INFO - 2023-03-28 05:42:56 --> URI Class Initialized
INFO - 2023-03-28 05:42:56 --> Router Class Initialized
INFO - 2023-03-28 05:42:56 --> Output Class Initialized
INFO - 2023-03-28 05:42:56 --> Security Class Initialized
DEBUG - 2023-03-28 05:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:42:56 --> Input Class Initialized
INFO - 2023-03-28 05:42:56 --> Language Class Initialized
INFO - 2023-03-28 05:42:56 --> Language Class Initialized
INFO - 2023-03-28 05:42:56 --> Config Class Initialized
INFO - 2023-03-28 05:42:56 --> Loader Class Initialized
INFO - 2023-03-28 05:42:56 --> Helper loaded: url_helper
INFO - 2023-03-28 05:42:56 --> Helper loaded: file_helper
INFO - 2023-03-28 05:42:56 --> Helper loaded: form_helper
INFO - 2023-03-28 05:42:56 --> Helper loaded: my_helper
INFO - 2023-03-28 05:42:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:42:56 --> Controller Class Initialized
DEBUG - 2023-03-28 05:42:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:42:57 --> Final output sent to browser
DEBUG - 2023-03-28 05:42:57 --> Total execution time: 1.1134
INFO - 2023-03-28 05:43:09 --> Config Class Initialized
INFO - 2023-03-28 05:43:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:43:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:43:09 --> Utf8 Class Initialized
INFO - 2023-03-28 05:43:09 --> URI Class Initialized
INFO - 2023-03-28 05:43:09 --> Router Class Initialized
INFO - 2023-03-28 05:43:09 --> Output Class Initialized
INFO - 2023-03-28 05:43:09 --> Security Class Initialized
DEBUG - 2023-03-28 05:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:43:09 --> Input Class Initialized
INFO - 2023-03-28 05:43:09 --> Language Class Initialized
INFO - 2023-03-28 05:43:09 --> Language Class Initialized
INFO - 2023-03-28 05:43:09 --> Config Class Initialized
INFO - 2023-03-28 05:43:09 --> Loader Class Initialized
INFO - 2023-03-28 05:43:09 --> Helper loaded: url_helper
INFO - 2023-03-28 05:43:09 --> Helper loaded: file_helper
INFO - 2023-03-28 05:43:09 --> Helper loaded: form_helper
INFO - 2023-03-28 05:43:09 --> Helper loaded: my_helper
INFO - 2023-03-28 05:43:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:43:09 --> Controller Class Initialized
DEBUG - 2023-03-28 05:43:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:43:10 --> Final output sent to browser
DEBUG - 2023-03-28 05:43:10 --> Total execution time: 1.1254
INFO - 2023-03-28 05:44:41 --> Config Class Initialized
INFO - 2023-03-28 05:44:41 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:44:41 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:44:41 --> Utf8 Class Initialized
INFO - 2023-03-28 05:44:41 --> URI Class Initialized
INFO - 2023-03-28 05:44:41 --> Router Class Initialized
INFO - 2023-03-28 05:44:41 --> Output Class Initialized
INFO - 2023-03-28 05:44:41 --> Security Class Initialized
DEBUG - 2023-03-28 05:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:44:41 --> Input Class Initialized
INFO - 2023-03-28 05:44:41 --> Language Class Initialized
INFO - 2023-03-28 05:44:41 --> Language Class Initialized
INFO - 2023-03-28 05:44:41 --> Config Class Initialized
INFO - 2023-03-28 05:44:41 --> Loader Class Initialized
INFO - 2023-03-28 05:44:41 --> Helper loaded: url_helper
INFO - 2023-03-28 05:44:41 --> Helper loaded: file_helper
INFO - 2023-03-28 05:44:41 --> Helper loaded: form_helper
INFO - 2023-03-28 05:44:41 --> Helper loaded: my_helper
INFO - 2023-03-28 05:44:41 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:44:42 --> Controller Class Initialized
DEBUG - 2023-03-28 05:44:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:44:43 --> Final output sent to browser
DEBUG - 2023-03-28 05:44:43 --> Total execution time: 1.1538
INFO - 2023-03-28 05:45:17 --> Config Class Initialized
INFO - 2023-03-28 05:45:17 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:45:17 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:45:17 --> Utf8 Class Initialized
INFO - 2023-03-28 05:45:17 --> URI Class Initialized
INFO - 2023-03-28 05:45:17 --> Router Class Initialized
INFO - 2023-03-28 05:45:17 --> Output Class Initialized
INFO - 2023-03-28 05:45:17 --> Security Class Initialized
DEBUG - 2023-03-28 05:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:45:17 --> Input Class Initialized
INFO - 2023-03-28 05:45:17 --> Language Class Initialized
INFO - 2023-03-28 05:45:17 --> Language Class Initialized
INFO - 2023-03-28 05:45:17 --> Config Class Initialized
INFO - 2023-03-28 05:45:17 --> Loader Class Initialized
INFO - 2023-03-28 05:45:17 --> Helper loaded: url_helper
INFO - 2023-03-28 05:45:17 --> Helper loaded: file_helper
INFO - 2023-03-28 05:45:17 --> Helper loaded: form_helper
INFO - 2023-03-28 05:45:17 --> Helper loaded: my_helper
INFO - 2023-03-28 05:45:17 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:45:17 --> Controller Class Initialized
DEBUG - 2023-03-28 05:45:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:45:18 --> Final output sent to browser
DEBUG - 2023-03-28 05:45:18 --> Total execution time: 1.2001
INFO - 2023-03-28 05:45:27 --> Config Class Initialized
INFO - 2023-03-28 05:45:27 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:45:27 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:45:27 --> Utf8 Class Initialized
INFO - 2023-03-28 05:45:27 --> URI Class Initialized
INFO - 2023-03-28 05:45:27 --> Router Class Initialized
INFO - 2023-03-28 05:45:27 --> Output Class Initialized
INFO - 2023-03-28 05:45:27 --> Security Class Initialized
DEBUG - 2023-03-28 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:45:27 --> Input Class Initialized
INFO - 2023-03-28 05:45:27 --> Language Class Initialized
INFO - 2023-03-28 05:45:27 --> Language Class Initialized
INFO - 2023-03-28 05:45:27 --> Config Class Initialized
INFO - 2023-03-28 05:45:27 --> Loader Class Initialized
INFO - 2023-03-28 05:45:27 --> Helper loaded: url_helper
INFO - 2023-03-28 05:45:27 --> Helper loaded: file_helper
INFO - 2023-03-28 05:45:27 --> Helper loaded: form_helper
INFO - 2023-03-28 05:45:27 --> Helper loaded: my_helper
INFO - 2023-03-28 05:45:27 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:45:27 --> Controller Class Initialized
DEBUG - 2023-03-28 05:45:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:45:28 --> Final output sent to browser
DEBUG - 2023-03-28 05:45:28 --> Total execution time: 1.1580
INFO - 2023-03-28 05:45:41 --> Config Class Initialized
INFO - 2023-03-28 05:45:41 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:45:41 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:45:41 --> Utf8 Class Initialized
INFO - 2023-03-28 05:45:41 --> URI Class Initialized
INFO - 2023-03-28 05:45:41 --> Router Class Initialized
INFO - 2023-03-28 05:45:41 --> Output Class Initialized
INFO - 2023-03-28 05:45:41 --> Security Class Initialized
DEBUG - 2023-03-28 05:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:45:41 --> Input Class Initialized
INFO - 2023-03-28 05:45:41 --> Language Class Initialized
INFO - 2023-03-28 05:45:41 --> Language Class Initialized
INFO - 2023-03-28 05:45:41 --> Config Class Initialized
INFO - 2023-03-28 05:45:41 --> Loader Class Initialized
INFO - 2023-03-28 05:45:41 --> Helper loaded: url_helper
INFO - 2023-03-28 05:45:41 --> Helper loaded: file_helper
INFO - 2023-03-28 05:45:41 --> Helper loaded: form_helper
INFO - 2023-03-28 05:45:41 --> Helper loaded: my_helper
INFO - 2023-03-28 05:45:41 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:45:41 --> Controller Class Initialized
DEBUG - 2023-03-28 05:45:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:45:42 --> Final output sent to browser
DEBUG - 2023-03-28 05:45:42 --> Total execution time: 1.1295
INFO - 2023-03-28 05:46:05 --> Config Class Initialized
INFO - 2023-03-28 05:46:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:46:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:46:05 --> Utf8 Class Initialized
INFO - 2023-03-28 05:46:05 --> URI Class Initialized
INFO - 2023-03-28 05:46:05 --> Router Class Initialized
INFO - 2023-03-28 05:46:05 --> Output Class Initialized
INFO - 2023-03-28 05:46:05 --> Security Class Initialized
DEBUG - 2023-03-28 05:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:46:05 --> Input Class Initialized
INFO - 2023-03-28 05:46:05 --> Language Class Initialized
INFO - 2023-03-28 05:46:05 --> Language Class Initialized
INFO - 2023-03-28 05:46:05 --> Config Class Initialized
INFO - 2023-03-28 05:46:05 --> Loader Class Initialized
INFO - 2023-03-28 05:46:05 --> Helper loaded: url_helper
INFO - 2023-03-28 05:46:05 --> Helper loaded: file_helper
INFO - 2023-03-28 05:46:05 --> Helper loaded: form_helper
INFO - 2023-03-28 05:46:05 --> Helper loaded: my_helper
INFO - 2023-03-28 05:46:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:46:05 --> Controller Class Initialized
DEBUG - 2023-03-28 05:46:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:46:06 --> Final output sent to browser
DEBUG - 2023-03-28 05:46:06 --> Total execution time: 1.2053
INFO - 2023-03-28 05:46:13 --> Config Class Initialized
INFO - 2023-03-28 05:46:13 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:46:13 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:46:13 --> Utf8 Class Initialized
INFO - 2023-03-28 05:46:13 --> URI Class Initialized
INFO - 2023-03-28 05:46:13 --> Router Class Initialized
INFO - 2023-03-28 05:46:13 --> Output Class Initialized
INFO - 2023-03-28 05:46:13 --> Security Class Initialized
DEBUG - 2023-03-28 05:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:46:13 --> Input Class Initialized
INFO - 2023-03-28 05:46:13 --> Language Class Initialized
INFO - 2023-03-28 05:46:13 --> Language Class Initialized
INFO - 2023-03-28 05:46:13 --> Config Class Initialized
INFO - 2023-03-28 05:46:13 --> Loader Class Initialized
INFO - 2023-03-28 05:46:13 --> Helper loaded: url_helper
INFO - 2023-03-28 05:46:13 --> Helper loaded: file_helper
INFO - 2023-03-28 05:46:13 --> Helper loaded: form_helper
INFO - 2023-03-28 05:46:13 --> Helper loaded: my_helper
INFO - 2023-03-28 05:46:13 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:46:13 --> Controller Class Initialized
DEBUG - 2023-03-28 05:46:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:46:14 --> Final output sent to browser
DEBUG - 2023-03-28 05:46:14 --> Total execution time: 1.1358
INFO - 2023-03-28 05:46:23 --> Config Class Initialized
INFO - 2023-03-28 05:46:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:46:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:46:23 --> Utf8 Class Initialized
INFO - 2023-03-28 05:46:23 --> URI Class Initialized
INFO - 2023-03-28 05:46:23 --> Router Class Initialized
INFO - 2023-03-28 05:46:23 --> Output Class Initialized
INFO - 2023-03-28 05:46:23 --> Security Class Initialized
DEBUG - 2023-03-28 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:46:23 --> Input Class Initialized
INFO - 2023-03-28 05:46:23 --> Language Class Initialized
INFO - 2023-03-28 05:46:23 --> Language Class Initialized
INFO - 2023-03-28 05:46:23 --> Config Class Initialized
INFO - 2023-03-28 05:46:23 --> Loader Class Initialized
INFO - 2023-03-28 05:46:23 --> Helper loaded: url_helper
INFO - 2023-03-28 05:46:23 --> Helper loaded: file_helper
INFO - 2023-03-28 05:46:23 --> Helper loaded: form_helper
INFO - 2023-03-28 05:46:23 --> Helper loaded: my_helper
INFO - 2023-03-28 05:46:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:46:23 --> Controller Class Initialized
DEBUG - 2023-03-28 05:46:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:46:24 --> Final output sent to browser
DEBUG - 2023-03-28 05:46:24 --> Total execution time: 1.1181
INFO - 2023-03-28 05:47:56 --> Config Class Initialized
INFO - 2023-03-28 05:47:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:47:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:47:56 --> Utf8 Class Initialized
INFO - 2023-03-28 05:47:56 --> URI Class Initialized
INFO - 2023-03-28 05:47:56 --> Router Class Initialized
INFO - 2023-03-28 05:47:56 --> Output Class Initialized
INFO - 2023-03-28 05:47:56 --> Security Class Initialized
DEBUG - 2023-03-28 05:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:47:56 --> Input Class Initialized
INFO - 2023-03-28 05:47:56 --> Language Class Initialized
INFO - 2023-03-28 05:47:56 --> Language Class Initialized
INFO - 2023-03-28 05:47:56 --> Config Class Initialized
INFO - 2023-03-28 05:47:56 --> Loader Class Initialized
INFO - 2023-03-28 05:47:56 --> Helper loaded: url_helper
INFO - 2023-03-28 05:47:56 --> Helper loaded: file_helper
INFO - 2023-03-28 05:47:56 --> Helper loaded: form_helper
INFO - 2023-03-28 05:47:56 --> Helper loaded: my_helper
INFO - 2023-03-28 05:47:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:47:56 --> Controller Class Initialized
DEBUG - 2023-03-28 05:47:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:47:57 --> Final output sent to browser
DEBUG - 2023-03-28 05:47:57 --> Total execution time: 1.1729
INFO - 2023-03-28 05:48:23 --> Config Class Initialized
INFO - 2023-03-28 05:48:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:48:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:48:23 --> Utf8 Class Initialized
INFO - 2023-03-28 05:48:23 --> URI Class Initialized
INFO - 2023-03-28 05:48:23 --> Router Class Initialized
INFO - 2023-03-28 05:48:23 --> Output Class Initialized
INFO - 2023-03-28 05:48:23 --> Security Class Initialized
DEBUG - 2023-03-28 05:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:48:23 --> Input Class Initialized
INFO - 2023-03-28 05:48:23 --> Language Class Initialized
INFO - 2023-03-28 05:48:23 --> Language Class Initialized
INFO - 2023-03-28 05:48:23 --> Config Class Initialized
INFO - 2023-03-28 05:48:23 --> Loader Class Initialized
INFO - 2023-03-28 05:48:23 --> Helper loaded: url_helper
INFO - 2023-03-28 05:48:23 --> Helper loaded: file_helper
INFO - 2023-03-28 05:48:23 --> Helper loaded: form_helper
INFO - 2023-03-28 05:48:23 --> Helper loaded: my_helper
INFO - 2023-03-28 05:48:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:48:23 --> Controller Class Initialized
DEBUG - 2023-03-28 05:48:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:48:24 --> Final output sent to browser
DEBUG - 2023-03-28 05:48:24 --> Total execution time: 1.1391
INFO - 2023-03-28 05:49:05 --> Config Class Initialized
INFO - 2023-03-28 05:49:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:49:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:49:05 --> Utf8 Class Initialized
INFO - 2023-03-28 05:49:05 --> URI Class Initialized
INFO - 2023-03-28 05:49:05 --> Router Class Initialized
INFO - 2023-03-28 05:49:05 --> Output Class Initialized
INFO - 2023-03-28 05:49:05 --> Security Class Initialized
DEBUG - 2023-03-28 05:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:49:05 --> Input Class Initialized
INFO - 2023-03-28 05:49:05 --> Language Class Initialized
INFO - 2023-03-28 05:49:05 --> Language Class Initialized
INFO - 2023-03-28 05:49:05 --> Config Class Initialized
INFO - 2023-03-28 05:49:05 --> Loader Class Initialized
INFO - 2023-03-28 05:49:05 --> Helper loaded: url_helper
INFO - 2023-03-28 05:49:05 --> Helper loaded: file_helper
INFO - 2023-03-28 05:49:05 --> Helper loaded: form_helper
INFO - 2023-03-28 05:49:05 --> Helper loaded: my_helper
INFO - 2023-03-28 05:49:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:49:05 --> Controller Class Initialized
DEBUG - 2023-03-28 05:49:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:49:07 --> Final output sent to browser
DEBUG - 2023-03-28 05:49:07 --> Total execution time: 1.1020
INFO - 2023-03-28 05:49:48 --> Config Class Initialized
INFO - 2023-03-28 05:49:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:49:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:49:48 --> Utf8 Class Initialized
INFO - 2023-03-28 05:49:48 --> URI Class Initialized
INFO - 2023-03-28 05:49:48 --> Router Class Initialized
INFO - 2023-03-28 05:49:48 --> Output Class Initialized
INFO - 2023-03-28 05:49:48 --> Security Class Initialized
DEBUG - 2023-03-28 05:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:49:48 --> Input Class Initialized
INFO - 2023-03-28 05:49:48 --> Language Class Initialized
INFO - 2023-03-28 05:49:48 --> Language Class Initialized
INFO - 2023-03-28 05:49:48 --> Config Class Initialized
INFO - 2023-03-28 05:49:48 --> Loader Class Initialized
INFO - 2023-03-28 05:49:48 --> Helper loaded: url_helper
INFO - 2023-03-28 05:49:48 --> Helper loaded: file_helper
INFO - 2023-03-28 05:49:48 --> Helper loaded: form_helper
INFO - 2023-03-28 05:49:48 --> Helper loaded: my_helper
INFO - 2023-03-28 05:49:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:49:48 --> Controller Class Initialized
DEBUG - 2023-03-28 05:49:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:49:49 --> Final output sent to browser
DEBUG - 2023-03-28 05:49:49 --> Total execution time: 1.2060
INFO - 2023-03-28 05:50:04 --> Config Class Initialized
INFO - 2023-03-28 05:50:04 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:50:04 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:50:04 --> Utf8 Class Initialized
INFO - 2023-03-28 05:50:04 --> URI Class Initialized
INFO - 2023-03-28 05:50:04 --> Router Class Initialized
INFO - 2023-03-28 05:50:04 --> Output Class Initialized
INFO - 2023-03-28 05:50:04 --> Security Class Initialized
DEBUG - 2023-03-28 05:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:50:04 --> Input Class Initialized
INFO - 2023-03-28 05:50:04 --> Language Class Initialized
INFO - 2023-03-28 05:50:04 --> Language Class Initialized
INFO - 2023-03-28 05:50:04 --> Config Class Initialized
INFO - 2023-03-28 05:50:04 --> Loader Class Initialized
INFO - 2023-03-28 05:50:04 --> Helper loaded: url_helper
INFO - 2023-03-28 05:50:04 --> Helper loaded: file_helper
INFO - 2023-03-28 05:50:04 --> Helper loaded: form_helper
INFO - 2023-03-28 05:50:04 --> Helper loaded: my_helper
INFO - 2023-03-28 05:50:04 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:50:04 --> Controller Class Initialized
DEBUG - 2023-03-28 05:50:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:50:06 --> Final output sent to browser
DEBUG - 2023-03-28 05:50:06 --> Total execution time: 1.1900
INFO - 2023-03-28 05:50:52 --> Config Class Initialized
INFO - 2023-03-28 05:50:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:50:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:50:52 --> Utf8 Class Initialized
INFO - 2023-03-28 05:50:52 --> URI Class Initialized
INFO - 2023-03-28 05:50:52 --> Router Class Initialized
INFO - 2023-03-28 05:50:52 --> Output Class Initialized
INFO - 2023-03-28 05:50:52 --> Security Class Initialized
DEBUG - 2023-03-28 05:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:50:52 --> Input Class Initialized
INFO - 2023-03-28 05:50:52 --> Language Class Initialized
INFO - 2023-03-28 05:50:52 --> Language Class Initialized
INFO - 2023-03-28 05:50:52 --> Config Class Initialized
INFO - 2023-03-28 05:50:52 --> Loader Class Initialized
INFO - 2023-03-28 05:50:52 --> Helper loaded: url_helper
INFO - 2023-03-28 05:50:52 --> Helper loaded: file_helper
INFO - 2023-03-28 05:50:52 --> Helper loaded: form_helper
INFO - 2023-03-28 05:50:52 --> Helper loaded: my_helper
INFO - 2023-03-28 05:50:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:50:52 --> Controller Class Initialized
DEBUG - 2023-03-28 05:50:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:50:53 --> Final output sent to browser
DEBUG - 2023-03-28 05:50:53 --> Total execution time: 1.1627
INFO - 2023-03-28 05:51:05 --> Config Class Initialized
INFO - 2023-03-28 05:51:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:51:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:51:05 --> Utf8 Class Initialized
INFO - 2023-03-28 05:51:05 --> URI Class Initialized
INFO - 2023-03-28 05:51:05 --> Router Class Initialized
INFO - 2023-03-28 05:51:05 --> Output Class Initialized
INFO - 2023-03-28 05:51:05 --> Security Class Initialized
DEBUG - 2023-03-28 05:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:51:05 --> Input Class Initialized
INFO - 2023-03-28 05:51:05 --> Language Class Initialized
INFO - 2023-03-28 05:51:05 --> Language Class Initialized
INFO - 2023-03-28 05:51:05 --> Config Class Initialized
INFO - 2023-03-28 05:51:05 --> Loader Class Initialized
INFO - 2023-03-28 05:51:05 --> Helper loaded: url_helper
INFO - 2023-03-28 05:51:05 --> Helper loaded: file_helper
INFO - 2023-03-28 05:51:05 --> Helper loaded: form_helper
INFO - 2023-03-28 05:51:05 --> Helper loaded: my_helper
INFO - 2023-03-28 05:51:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:51:05 --> Controller Class Initialized
DEBUG - 2023-03-28 05:51:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:51:06 --> Final output sent to browser
DEBUG - 2023-03-28 05:51:06 --> Total execution time: 1.1897
INFO - 2023-03-28 05:51:20 --> Config Class Initialized
INFO - 2023-03-28 05:51:20 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:51:20 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:51:20 --> Utf8 Class Initialized
INFO - 2023-03-28 05:51:20 --> URI Class Initialized
INFO - 2023-03-28 05:51:20 --> Router Class Initialized
INFO - 2023-03-28 05:51:20 --> Output Class Initialized
INFO - 2023-03-28 05:51:20 --> Security Class Initialized
DEBUG - 2023-03-28 05:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:51:20 --> Input Class Initialized
INFO - 2023-03-28 05:51:20 --> Language Class Initialized
INFO - 2023-03-28 05:51:20 --> Language Class Initialized
INFO - 2023-03-28 05:51:20 --> Config Class Initialized
INFO - 2023-03-28 05:51:20 --> Loader Class Initialized
INFO - 2023-03-28 05:51:20 --> Helper loaded: url_helper
INFO - 2023-03-28 05:51:20 --> Helper loaded: file_helper
INFO - 2023-03-28 05:51:20 --> Helper loaded: form_helper
INFO - 2023-03-28 05:51:20 --> Helper loaded: my_helper
INFO - 2023-03-28 05:51:20 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:51:20 --> Controller Class Initialized
DEBUG - 2023-03-28 05:51:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:51:22 --> Final output sent to browser
DEBUG - 2023-03-28 05:51:22 --> Total execution time: 1.1703
INFO - 2023-03-28 05:51:54 --> Config Class Initialized
INFO - 2023-03-28 05:51:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:51:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:51:54 --> Utf8 Class Initialized
INFO - 2023-03-28 05:51:54 --> URI Class Initialized
INFO - 2023-03-28 05:51:54 --> Router Class Initialized
INFO - 2023-03-28 05:51:54 --> Output Class Initialized
INFO - 2023-03-28 05:51:54 --> Security Class Initialized
DEBUG - 2023-03-28 05:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:51:54 --> Input Class Initialized
INFO - 2023-03-28 05:51:54 --> Language Class Initialized
INFO - 2023-03-28 05:51:54 --> Language Class Initialized
INFO - 2023-03-28 05:51:54 --> Config Class Initialized
INFO - 2023-03-28 05:51:54 --> Loader Class Initialized
INFO - 2023-03-28 05:51:54 --> Helper loaded: url_helper
INFO - 2023-03-28 05:51:54 --> Helper loaded: file_helper
INFO - 2023-03-28 05:51:54 --> Helper loaded: form_helper
INFO - 2023-03-28 05:51:54 --> Helper loaded: my_helper
INFO - 2023-03-28 05:51:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:51:54 --> Controller Class Initialized
DEBUG - 2023-03-28 05:51:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-28 05:51:55 --> Final output sent to browser
DEBUG - 2023-03-28 05:51:55 --> Total execution time: 1.1652
INFO - 2023-03-28 05:52:37 --> Config Class Initialized
INFO - 2023-03-28 05:52:37 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:52:37 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:52:37 --> Utf8 Class Initialized
INFO - 2023-03-28 05:52:37 --> URI Class Initialized
INFO - 2023-03-28 05:52:37 --> Router Class Initialized
INFO - 2023-03-28 05:52:37 --> Output Class Initialized
INFO - 2023-03-28 05:52:37 --> Security Class Initialized
DEBUG - 2023-03-28 05:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:52:37 --> Input Class Initialized
INFO - 2023-03-28 05:52:37 --> Language Class Initialized
INFO - 2023-03-28 05:52:37 --> Language Class Initialized
INFO - 2023-03-28 05:52:37 --> Config Class Initialized
INFO - 2023-03-28 05:52:37 --> Loader Class Initialized
INFO - 2023-03-28 05:52:37 --> Helper loaded: url_helper
INFO - 2023-03-28 05:52:37 --> Helper loaded: file_helper
INFO - 2023-03-28 05:52:37 --> Helper loaded: form_helper
INFO - 2023-03-28 05:52:37 --> Helper loaded: my_helper
INFO - 2023-03-28 05:52:37 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:52:37 --> Controller Class Initialized
DEBUG - 2023-03-28 05:52:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:52:38 --> Final output sent to browser
DEBUG - 2023-03-28 05:52:38 --> Total execution time: 1.1780
INFO - 2023-03-28 05:53:30 --> Config Class Initialized
INFO - 2023-03-28 05:53:30 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:53:30 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:53:30 --> Utf8 Class Initialized
INFO - 2023-03-28 05:53:30 --> URI Class Initialized
INFO - 2023-03-28 05:53:30 --> Router Class Initialized
INFO - 2023-03-28 05:53:30 --> Output Class Initialized
INFO - 2023-03-28 05:53:30 --> Security Class Initialized
DEBUG - 2023-03-28 05:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:53:30 --> Input Class Initialized
INFO - 2023-03-28 05:53:30 --> Language Class Initialized
INFO - 2023-03-28 05:53:30 --> Language Class Initialized
INFO - 2023-03-28 05:53:30 --> Config Class Initialized
INFO - 2023-03-28 05:53:30 --> Loader Class Initialized
INFO - 2023-03-28 05:53:30 --> Helper loaded: url_helper
INFO - 2023-03-28 05:53:30 --> Helper loaded: file_helper
INFO - 2023-03-28 05:53:30 --> Helper loaded: form_helper
INFO - 2023-03-28 05:53:30 --> Helper loaded: my_helper
INFO - 2023-03-28 05:53:30 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:53:30 --> Controller Class Initialized
DEBUG - 2023-03-28 05:53:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:53:31 --> Final output sent to browser
DEBUG - 2023-03-28 05:53:31 --> Total execution time: 1.1386
INFO - 2023-03-28 05:54:19 --> Config Class Initialized
INFO - 2023-03-28 05:54:19 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:54:19 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:54:19 --> Utf8 Class Initialized
INFO - 2023-03-28 05:54:19 --> URI Class Initialized
INFO - 2023-03-28 05:54:19 --> Router Class Initialized
INFO - 2023-03-28 05:54:19 --> Output Class Initialized
INFO - 2023-03-28 05:54:19 --> Security Class Initialized
DEBUG - 2023-03-28 05:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:54:19 --> Input Class Initialized
INFO - 2023-03-28 05:54:19 --> Language Class Initialized
INFO - 2023-03-28 05:54:19 --> Language Class Initialized
INFO - 2023-03-28 05:54:19 --> Config Class Initialized
INFO - 2023-03-28 05:54:19 --> Loader Class Initialized
INFO - 2023-03-28 05:54:19 --> Helper loaded: url_helper
INFO - 2023-03-28 05:54:19 --> Helper loaded: file_helper
INFO - 2023-03-28 05:54:19 --> Helper loaded: form_helper
INFO - 2023-03-28 05:54:19 --> Helper loaded: my_helper
INFO - 2023-03-28 05:54:19 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:54:19 --> Controller Class Initialized
DEBUG - 2023-03-28 05:54:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:54:20 --> Final output sent to browser
DEBUG - 2023-03-28 05:54:20 --> Total execution time: 1.1813
INFO - 2023-03-28 05:54:30 --> Config Class Initialized
INFO - 2023-03-28 05:54:30 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:54:30 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:54:30 --> Utf8 Class Initialized
INFO - 2023-03-28 05:54:30 --> URI Class Initialized
INFO - 2023-03-28 05:54:30 --> Router Class Initialized
INFO - 2023-03-28 05:54:30 --> Output Class Initialized
INFO - 2023-03-28 05:54:30 --> Security Class Initialized
DEBUG - 2023-03-28 05:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:54:30 --> Input Class Initialized
INFO - 2023-03-28 05:54:30 --> Language Class Initialized
INFO - 2023-03-28 05:54:30 --> Language Class Initialized
INFO - 2023-03-28 05:54:30 --> Config Class Initialized
INFO - 2023-03-28 05:54:30 --> Loader Class Initialized
INFO - 2023-03-28 05:54:30 --> Helper loaded: url_helper
INFO - 2023-03-28 05:54:30 --> Helper loaded: file_helper
INFO - 2023-03-28 05:54:30 --> Helper loaded: form_helper
INFO - 2023-03-28 05:54:30 --> Helper loaded: my_helper
INFO - 2023-03-28 05:54:30 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:54:30 --> Controller Class Initialized
DEBUG - 2023-03-28 05:54:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:54:31 --> Final output sent to browser
DEBUG - 2023-03-28 05:54:31 --> Total execution time: 1.1347
INFO - 2023-03-28 05:54:56 --> Config Class Initialized
INFO - 2023-03-28 05:54:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 05:54:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 05:54:56 --> Utf8 Class Initialized
INFO - 2023-03-28 05:54:56 --> URI Class Initialized
INFO - 2023-03-28 05:54:56 --> Router Class Initialized
INFO - 2023-03-28 05:54:56 --> Output Class Initialized
INFO - 2023-03-28 05:54:56 --> Security Class Initialized
DEBUG - 2023-03-28 05:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 05:54:56 --> Input Class Initialized
INFO - 2023-03-28 05:54:56 --> Language Class Initialized
INFO - 2023-03-28 05:54:56 --> Language Class Initialized
INFO - 2023-03-28 05:54:56 --> Config Class Initialized
INFO - 2023-03-28 05:54:56 --> Loader Class Initialized
INFO - 2023-03-28 05:54:56 --> Helper loaded: url_helper
INFO - 2023-03-28 05:54:56 --> Helper loaded: file_helper
INFO - 2023-03-28 05:54:56 --> Helper loaded: form_helper
INFO - 2023-03-28 05:54:56 --> Helper loaded: my_helper
INFO - 2023-03-28 05:54:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 05:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 05:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 05:54:56 --> Controller Class Initialized
DEBUG - 2023-03-28 05:54:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 05:54:57 --> Final output sent to browser
DEBUG - 2023-03-28 05:54:57 --> Total execution time: 1.1402
INFO - 2023-03-28 06:00:57 --> Config Class Initialized
INFO - 2023-03-28 06:00:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:00:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:00:57 --> Utf8 Class Initialized
INFO - 2023-03-28 06:00:57 --> URI Class Initialized
INFO - 2023-03-28 06:00:57 --> Router Class Initialized
INFO - 2023-03-28 06:00:57 --> Output Class Initialized
INFO - 2023-03-28 06:00:57 --> Security Class Initialized
DEBUG - 2023-03-28 06:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:00:57 --> Input Class Initialized
INFO - 2023-03-28 06:00:57 --> Language Class Initialized
INFO - 2023-03-28 06:00:57 --> Language Class Initialized
INFO - 2023-03-28 06:00:57 --> Config Class Initialized
INFO - 2023-03-28 06:00:57 --> Loader Class Initialized
INFO - 2023-03-28 06:00:57 --> Helper loaded: url_helper
INFO - 2023-03-28 06:00:57 --> Helper loaded: file_helper
INFO - 2023-03-28 06:00:57 --> Helper loaded: form_helper
INFO - 2023-03-28 06:00:57 --> Helper loaded: my_helper
INFO - 2023-03-28 06:00:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:00:57 --> Controller Class Initialized
DEBUG - 2023-03-28 06:00:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:00:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:00:57 --> Final output sent to browser
DEBUG - 2023-03-28 06:00:57 --> Total execution time: 0.0982
INFO - 2023-03-28 06:01:06 --> Config Class Initialized
INFO - 2023-03-28 06:01:06 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:01:06 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:01:06 --> Utf8 Class Initialized
INFO - 2023-03-28 06:01:06 --> URI Class Initialized
INFO - 2023-03-28 06:01:06 --> Router Class Initialized
INFO - 2023-03-28 06:01:06 --> Output Class Initialized
INFO - 2023-03-28 06:01:06 --> Security Class Initialized
DEBUG - 2023-03-28 06:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:01:06 --> Input Class Initialized
INFO - 2023-03-28 06:01:06 --> Language Class Initialized
INFO - 2023-03-28 06:01:06 --> Language Class Initialized
INFO - 2023-03-28 06:01:06 --> Config Class Initialized
INFO - 2023-03-28 06:01:06 --> Loader Class Initialized
INFO - 2023-03-28 06:01:06 --> Helper loaded: url_helper
INFO - 2023-03-28 06:01:06 --> Helper loaded: file_helper
INFO - 2023-03-28 06:01:06 --> Helper loaded: form_helper
INFO - 2023-03-28 06:01:06 --> Helper loaded: my_helper
INFO - 2023-03-28 06:01:06 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:01:06 --> Controller Class Initialized
DEBUG - 2023-03-28 06:01:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:01:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:01:06 --> Final output sent to browser
DEBUG - 2023-03-28 06:01:06 --> Total execution time: 0.0483
INFO - 2023-03-28 06:01:08 --> Config Class Initialized
INFO - 2023-03-28 06:01:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:01:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:01:08 --> Utf8 Class Initialized
INFO - 2023-03-28 06:01:08 --> URI Class Initialized
INFO - 2023-03-28 06:01:08 --> Router Class Initialized
INFO - 2023-03-28 06:01:08 --> Output Class Initialized
INFO - 2023-03-28 06:01:08 --> Security Class Initialized
DEBUG - 2023-03-28 06:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:01:08 --> Input Class Initialized
INFO - 2023-03-28 06:01:08 --> Language Class Initialized
INFO - 2023-03-28 06:01:08 --> Language Class Initialized
INFO - 2023-03-28 06:01:08 --> Config Class Initialized
INFO - 2023-03-28 06:01:08 --> Loader Class Initialized
INFO - 2023-03-28 06:01:08 --> Helper loaded: url_helper
INFO - 2023-03-28 06:01:08 --> Helper loaded: file_helper
INFO - 2023-03-28 06:01:08 --> Helper loaded: form_helper
INFO - 2023-03-28 06:01:08 --> Helper loaded: my_helper
INFO - 2023-03-28 06:01:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:01:08 --> Controller Class Initialized
DEBUG - 2023-03-28 06:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:01:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:01:08 --> Final output sent to browser
DEBUG - 2023-03-28 06:01:08 --> Total execution time: 0.0472
INFO - 2023-03-28 06:24:54 --> Config Class Initialized
INFO - 2023-03-28 06:24:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:24:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:24:54 --> Utf8 Class Initialized
INFO - 2023-03-28 06:24:54 --> URI Class Initialized
INFO - 2023-03-28 06:24:54 --> Router Class Initialized
INFO - 2023-03-28 06:24:54 --> Output Class Initialized
INFO - 2023-03-28 06:24:54 --> Security Class Initialized
DEBUG - 2023-03-28 06:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:24:54 --> Input Class Initialized
INFO - 2023-03-28 06:24:54 --> Language Class Initialized
INFO - 2023-03-28 06:24:54 --> Language Class Initialized
INFO - 2023-03-28 06:24:54 --> Config Class Initialized
INFO - 2023-03-28 06:24:54 --> Loader Class Initialized
INFO - 2023-03-28 06:24:54 --> Helper loaded: url_helper
INFO - 2023-03-28 06:24:54 --> Helper loaded: file_helper
INFO - 2023-03-28 06:24:54 --> Helper loaded: form_helper
INFO - 2023-03-28 06:24:54 --> Helper loaded: my_helper
INFO - 2023-03-28 06:24:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:24:54 --> Controller Class Initialized
DEBUG - 2023-03-28 06:24:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:24:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:24:54 --> Final output sent to browser
DEBUG - 2023-03-28 06:24:54 --> Total execution time: 0.1000
INFO - 2023-03-28 06:24:55 --> Config Class Initialized
INFO - 2023-03-28 06:24:55 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:24:55 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:24:55 --> Utf8 Class Initialized
INFO - 2023-03-28 06:24:55 --> URI Class Initialized
INFO - 2023-03-28 06:24:55 --> Router Class Initialized
INFO - 2023-03-28 06:24:55 --> Output Class Initialized
INFO - 2023-03-28 06:24:55 --> Security Class Initialized
DEBUG - 2023-03-28 06:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:24:55 --> Input Class Initialized
INFO - 2023-03-28 06:24:55 --> Language Class Initialized
INFO - 2023-03-28 06:24:55 --> Language Class Initialized
INFO - 2023-03-28 06:24:55 --> Config Class Initialized
INFO - 2023-03-28 06:24:55 --> Loader Class Initialized
INFO - 2023-03-28 06:24:55 --> Helper loaded: url_helper
INFO - 2023-03-28 06:24:55 --> Helper loaded: file_helper
INFO - 2023-03-28 06:24:55 --> Helper loaded: form_helper
INFO - 2023-03-28 06:24:55 --> Helper loaded: my_helper
INFO - 2023-03-28 06:24:55 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:24:55 --> Controller Class Initialized
DEBUG - 2023-03-28 06:24:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:24:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:24:55 --> Final output sent to browser
DEBUG - 2023-03-28 06:24:55 --> Total execution time: 0.0283
INFO - 2023-03-28 06:27:43 --> Config Class Initialized
INFO - 2023-03-28 06:27:43 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:27:43 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:27:43 --> Utf8 Class Initialized
INFO - 2023-03-28 06:27:43 --> URI Class Initialized
INFO - 2023-03-28 06:27:43 --> Router Class Initialized
INFO - 2023-03-28 06:27:43 --> Output Class Initialized
INFO - 2023-03-28 06:27:43 --> Security Class Initialized
DEBUG - 2023-03-28 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:27:43 --> Input Class Initialized
INFO - 2023-03-28 06:27:43 --> Language Class Initialized
INFO - 2023-03-28 06:27:43 --> Language Class Initialized
INFO - 2023-03-28 06:27:43 --> Config Class Initialized
INFO - 2023-03-28 06:27:43 --> Loader Class Initialized
INFO - 2023-03-28 06:27:43 --> Helper loaded: url_helper
INFO - 2023-03-28 06:27:43 --> Helper loaded: file_helper
INFO - 2023-03-28 06:27:43 --> Helper loaded: form_helper
INFO - 2023-03-28 06:27:43 --> Helper loaded: my_helper
INFO - 2023-03-28 06:27:43 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:27:43 --> Controller Class Initialized
DEBUG - 2023-03-28 06:27:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:27:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:27:43 --> Final output sent to browser
DEBUG - 2023-03-28 06:27:43 --> Total execution time: 0.0263
INFO - 2023-03-28 06:28:33 --> Config Class Initialized
INFO - 2023-03-28 06:28:33 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:28:33 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:28:33 --> Utf8 Class Initialized
INFO - 2023-03-28 06:28:33 --> URI Class Initialized
INFO - 2023-03-28 06:28:33 --> Router Class Initialized
INFO - 2023-03-28 06:28:33 --> Output Class Initialized
INFO - 2023-03-28 06:28:33 --> Security Class Initialized
DEBUG - 2023-03-28 06:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:28:33 --> Input Class Initialized
INFO - 2023-03-28 06:28:33 --> Language Class Initialized
INFO - 2023-03-28 06:28:33 --> Language Class Initialized
INFO - 2023-03-28 06:28:33 --> Config Class Initialized
INFO - 2023-03-28 06:28:33 --> Loader Class Initialized
INFO - 2023-03-28 06:28:33 --> Helper loaded: url_helper
INFO - 2023-03-28 06:28:33 --> Helper loaded: file_helper
INFO - 2023-03-28 06:28:33 --> Helper loaded: form_helper
INFO - 2023-03-28 06:28:33 --> Helper loaded: my_helper
INFO - 2023-03-28 06:28:33 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:28:33 --> Controller Class Initialized
DEBUG - 2023-03-28 06:28:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:28:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:28:33 --> Final output sent to browser
DEBUG - 2023-03-28 06:28:33 --> Total execution time: 0.0501
INFO - 2023-03-28 06:30:58 --> Config Class Initialized
INFO - 2023-03-28 06:30:58 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:30:58 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:30:58 --> Utf8 Class Initialized
INFO - 2023-03-28 06:30:58 --> URI Class Initialized
INFO - 2023-03-28 06:30:58 --> Router Class Initialized
INFO - 2023-03-28 06:30:58 --> Output Class Initialized
INFO - 2023-03-28 06:30:58 --> Security Class Initialized
DEBUG - 2023-03-28 06:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:30:58 --> Input Class Initialized
INFO - 2023-03-28 06:30:58 --> Language Class Initialized
INFO - 2023-03-28 06:30:58 --> Language Class Initialized
INFO - 2023-03-28 06:30:58 --> Config Class Initialized
INFO - 2023-03-28 06:30:58 --> Loader Class Initialized
INFO - 2023-03-28 06:30:58 --> Helper loaded: url_helper
INFO - 2023-03-28 06:30:58 --> Helper loaded: file_helper
INFO - 2023-03-28 06:30:58 --> Helper loaded: form_helper
INFO - 2023-03-28 06:30:58 --> Helper loaded: my_helper
INFO - 2023-03-28 06:30:58 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:30:58 --> Controller Class Initialized
DEBUG - 2023-03-28 06:30:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:30:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:30:58 --> Final output sent to browser
DEBUG - 2023-03-28 06:30:58 --> Total execution time: 0.0523
INFO - 2023-03-28 06:32:30 --> Config Class Initialized
INFO - 2023-03-28 06:32:30 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:32:30 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:32:30 --> Utf8 Class Initialized
INFO - 2023-03-28 06:32:30 --> URI Class Initialized
INFO - 2023-03-28 06:32:30 --> Router Class Initialized
INFO - 2023-03-28 06:32:30 --> Output Class Initialized
INFO - 2023-03-28 06:32:30 --> Security Class Initialized
DEBUG - 2023-03-28 06:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:32:30 --> Input Class Initialized
INFO - 2023-03-28 06:32:30 --> Language Class Initialized
INFO - 2023-03-28 06:32:30 --> Language Class Initialized
INFO - 2023-03-28 06:32:30 --> Config Class Initialized
INFO - 2023-03-28 06:32:30 --> Loader Class Initialized
INFO - 2023-03-28 06:32:30 --> Helper loaded: url_helper
INFO - 2023-03-28 06:32:30 --> Helper loaded: file_helper
INFO - 2023-03-28 06:32:30 --> Helper loaded: form_helper
INFO - 2023-03-28 06:32:30 --> Helper loaded: my_helper
INFO - 2023-03-28 06:32:30 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:32:30 --> Controller Class Initialized
DEBUG - 2023-03-28 06:32:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:32:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:32:30 --> Final output sent to browser
DEBUG - 2023-03-28 06:32:30 --> Total execution time: 0.0403
INFO - 2023-03-28 06:32:48 --> Config Class Initialized
INFO - 2023-03-28 06:32:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:32:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:32:48 --> Utf8 Class Initialized
INFO - 2023-03-28 06:32:48 --> URI Class Initialized
INFO - 2023-03-28 06:32:48 --> Router Class Initialized
INFO - 2023-03-28 06:32:48 --> Output Class Initialized
INFO - 2023-03-28 06:32:48 --> Security Class Initialized
DEBUG - 2023-03-28 06:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:32:48 --> Input Class Initialized
INFO - 2023-03-28 06:32:48 --> Language Class Initialized
INFO - 2023-03-28 06:32:48 --> Language Class Initialized
INFO - 2023-03-28 06:32:48 --> Config Class Initialized
INFO - 2023-03-28 06:32:48 --> Loader Class Initialized
INFO - 2023-03-28 06:32:48 --> Helper loaded: url_helper
INFO - 2023-03-28 06:32:48 --> Helper loaded: file_helper
INFO - 2023-03-28 06:32:48 --> Helper loaded: form_helper
INFO - 2023-03-28 06:32:48 --> Helper loaded: my_helper
INFO - 2023-03-28 06:32:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:32:48 --> Controller Class Initialized
DEBUG - 2023-03-28 06:32:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:32:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:32:48 --> Final output sent to browser
DEBUG - 2023-03-28 06:32:48 --> Total execution time: 0.0273
INFO - 2023-03-28 06:38:49 --> Config Class Initialized
INFO - 2023-03-28 06:38:49 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:49 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:49 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:49 --> URI Class Initialized
INFO - 2023-03-28 06:38:49 --> Router Class Initialized
INFO - 2023-03-28 06:38:49 --> Output Class Initialized
INFO - 2023-03-28 06:38:49 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:49 --> Input Class Initialized
INFO - 2023-03-28 06:38:49 --> Language Class Initialized
INFO - 2023-03-28 06:38:49 --> Language Class Initialized
INFO - 2023-03-28 06:38:49 --> Config Class Initialized
INFO - 2023-03-28 06:38:49 --> Loader Class Initialized
INFO - 2023-03-28 06:38:49 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:49 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:49 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:49 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:49 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:49 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:49 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:49 --> Total execution time: 0.0304
INFO - 2023-03-28 06:38:52 --> Config Class Initialized
INFO - 2023-03-28 06:38:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:52 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:52 --> URI Class Initialized
INFO - 2023-03-28 06:38:52 --> Router Class Initialized
INFO - 2023-03-28 06:38:52 --> Output Class Initialized
INFO - 2023-03-28 06:38:52 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:52 --> Input Class Initialized
INFO - 2023-03-28 06:38:52 --> Language Class Initialized
INFO - 2023-03-28 06:38:52 --> Language Class Initialized
INFO - 2023-03-28 06:38:52 --> Config Class Initialized
INFO - 2023-03-28 06:38:52 --> Loader Class Initialized
INFO - 2023-03-28 06:38:52 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:52 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:52 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:52 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:52 --> Controller Class Initialized
INFO - 2023-03-28 06:38:52 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:52 --> Total execution time: 0.0253
INFO - 2023-03-28 06:38:55 --> Config Class Initialized
INFO - 2023-03-28 06:38:55 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:55 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:55 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:55 --> URI Class Initialized
INFO - 2023-03-28 06:38:55 --> Router Class Initialized
INFO - 2023-03-28 06:38:55 --> Output Class Initialized
INFO - 2023-03-28 06:38:55 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:55 --> Input Class Initialized
INFO - 2023-03-28 06:38:55 --> Language Class Initialized
INFO - 2023-03-28 06:38:55 --> Language Class Initialized
INFO - 2023-03-28 06:38:55 --> Config Class Initialized
INFO - 2023-03-28 06:38:55 --> Loader Class Initialized
INFO - 2023-03-28 06:38:55 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:55 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:55 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:55 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:55 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:55 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:55 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:55 --> Total execution time: 0.0256
INFO - 2023-03-28 06:38:57 --> Config Class Initialized
INFO - 2023-03-28 06:38:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:57 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:57 --> URI Class Initialized
INFO - 2023-03-28 06:38:57 --> Router Class Initialized
INFO - 2023-03-28 06:38:57 --> Output Class Initialized
INFO - 2023-03-28 06:38:57 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:57 --> Input Class Initialized
INFO - 2023-03-28 06:38:57 --> Language Class Initialized
INFO - 2023-03-28 06:38:57 --> Language Class Initialized
INFO - 2023-03-28 06:38:57 --> Config Class Initialized
INFO - 2023-03-28 06:38:57 --> Loader Class Initialized
INFO - 2023-03-28 06:38:57 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:57 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:57 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:57 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:57 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:57 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:57 --> Total execution time: 0.0263
INFO - 2023-03-28 06:38:58 --> Config Class Initialized
INFO - 2023-03-28 06:38:58 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:58 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:58 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:58 --> URI Class Initialized
INFO - 2023-03-28 06:38:58 --> Router Class Initialized
INFO - 2023-03-28 06:38:58 --> Output Class Initialized
INFO - 2023-03-28 06:38:58 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:58 --> Input Class Initialized
INFO - 2023-03-28 06:38:58 --> Language Class Initialized
INFO - 2023-03-28 06:38:58 --> Language Class Initialized
INFO - 2023-03-28 06:38:58 --> Config Class Initialized
INFO - 2023-03-28 06:38:58 --> Loader Class Initialized
INFO - 2023-03-28 06:38:58 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:58 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:58 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:58 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:58 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:58 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:58 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:58 --> Total execution time: 0.0298
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:59 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:59 --> URI Class Initialized
INFO - 2023-03-28 06:38:59 --> Router Class Initialized
INFO - 2023-03-28 06:38:59 --> Output Class Initialized
INFO - 2023-03-28 06:38:59 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:59 --> Input Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Loader Class Initialized
INFO - 2023-03-28 06:38:59 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:59 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:59 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:59 --> Total execution time: 0.0259
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:59 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:59 --> URI Class Initialized
INFO - 2023-03-28 06:38:59 --> Router Class Initialized
INFO - 2023-03-28 06:38:59 --> Output Class Initialized
INFO - 2023-03-28 06:38:59 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:59 --> Input Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Loader Class Initialized
INFO - 2023-03-28 06:38:59 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:59 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:59 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:59 --> Total execution time: 0.0242
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:59 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:59 --> URI Class Initialized
INFO - 2023-03-28 06:38:59 --> Router Class Initialized
INFO - 2023-03-28 06:38:59 --> Output Class Initialized
INFO - 2023-03-28 06:38:59 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:59 --> Input Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Loader Class Initialized
INFO - 2023-03-28 06:38:59 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:59 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:59 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:59 --> Total execution time: 0.0507
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:38:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:38:59 --> Utf8 Class Initialized
INFO - 2023-03-28 06:38:59 --> URI Class Initialized
INFO - 2023-03-28 06:38:59 --> Router Class Initialized
INFO - 2023-03-28 06:38:59 --> Output Class Initialized
INFO - 2023-03-28 06:38:59 --> Security Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:38:59 --> Input Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Language Class Initialized
INFO - 2023-03-28 06:38:59 --> Config Class Initialized
INFO - 2023-03-28 06:38:59 --> Loader Class Initialized
INFO - 2023-03-28 06:38:59 --> Helper loaded: url_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: file_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: form_helper
INFO - 2023-03-28 06:38:59 --> Helper loaded: my_helper
INFO - 2023-03-28 06:38:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:38:59 --> Controller Class Initialized
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:38:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:38:59 --> Final output sent to browser
DEBUG - 2023-03-28 06:38:59 --> Total execution time: 0.0271
INFO - 2023-03-28 06:39:03 --> Config Class Initialized
INFO - 2023-03-28 06:39:03 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:03 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:03 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:03 --> URI Class Initialized
INFO - 2023-03-28 06:39:03 --> Router Class Initialized
INFO - 2023-03-28 06:39:03 --> Output Class Initialized
INFO - 2023-03-28 06:39:03 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:03 --> Input Class Initialized
INFO - 2023-03-28 06:39:03 --> Language Class Initialized
INFO - 2023-03-28 06:39:03 --> Language Class Initialized
INFO - 2023-03-28 06:39:03 --> Config Class Initialized
INFO - 2023-03-28 06:39:03 --> Loader Class Initialized
INFO - 2023-03-28 06:39:03 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:03 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:03 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:03 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:03 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:03 --> Controller Class Initialized
INFO - 2023-03-28 06:39:03 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:03 --> Total execution time: 0.0256
INFO - 2023-03-28 06:39:05 --> Config Class Initialized
INFO - 2023-03-28 06:39:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:05 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:05 --> URI Class Initialized
INFO - 2023-03-28 06:39:05 --> Router Class Initialized
INFO - 2023-03-28 06:39:05 --> Output Class Initialized
INFO - 2023-03-28 06:39:05 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:05 --> Input Class Initialized
INFO - 2023-03-28 06:39:05 --> Language Class Initialized
INFO - 2023-03-28 06:39:05 --> Language Class Initialized
INFO - 2023-03-28 06:39:05 --> Config Class Initialized
INFO - 2023-03-28 06:39:05 --> Loader Class Initialized
INFO - 2023-03-28 06:39:05 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:05 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:05 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:05 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:05 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:05 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:05 --> Total execution time: 0.0265
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:06 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:06 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:06 --> URI Class Initialized
INFO - 2023-03-28 06:39:06 --> Router Class Initialized
INFO - 2023-03-28 06:39:06 --> Output Class Initialized
INFO - 2023-03-28 06:39:06 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:06 --> Input Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Loader Class Initialized
INFO - 2023-03-28 06:39:06 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:06 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:06 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:06 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:06 --> Total execution time: 0.0404
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:06 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:06 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:06 --> URI Class Initialized
INFO - 2023-03-28 06:39:06 --> Router Class Initialized
INFO - 2023-03-28 06:39:06 --> Output Class Initialized
INFO - 2023-03-28 06:39:06 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:06 --> Input Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Loader Class Initialized
INFO - 2023-03-28 06:39:06 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:06 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:06 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:06 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:06 --> Total execution time: 0.0251
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:06 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:06 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:06 --> URI Class Initialized
INFO - 2023-03-28 06:39:06 --> Router Class Initialized
INFO - 2023-03-28 06:39:06 --> Output Class Initialized
INFO - 2023-03-28 06:39:06 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:06 --> Input Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Language Class Initialized
INFO - 2023-03-28 06:39:06 --> Config Class Initialized
INFO - 2023-03-28 06:39:06 --> Loader Class Initialized
INFO - 2023-03-28 06:39:06 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:06 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:06 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:07 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:07 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:07 --> Total execution time: 0.0497
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:07 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:07 --> URI Class Initialized
INFO - 2023-03-28 06:39:07 --> Router Class Initialized
INFO - 2023-03-28 06:39:07 --> Output Class Initialized
INFO - 2023-03-28 06:39:07 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:07 --> Input Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Loader Class Initialized
INFO - 2023-03-28 06:39:07 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:07 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:07 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:07 --> Total execution time: 0.0375
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:07 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:07 --> URI Class Initialized
INFO - 2023-03-28 06:39:07 --> Router Class Initialized
INFO - 2023-03-28 06:39:07 --> Output Class Initialized
INFO - 2023-03-28 06:39:07 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:07 --> Input Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Loader Class Initialized
INFO - 2023-03-28 06:39:07 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:07 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:07 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:07 --> Total execution time: 0.0455
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:07 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:07 --> URI Class Initialized
INFO - 2023-03-28 06:39:07 --> Router Class Initialized
INFO - 2023-03-28 06:39:07 --> Output Class Initialized
INFO - 2023-03-28 06:39:07 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:07 --> Input Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Language Class Initialized
INFO - 2023-03-28 06:39:07 --> Config Class Initialized
INFO - 2023-03-28 06:39:07 --> Loader Class Initialized
INFO - 2023-03-28 06:39:07 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:07 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:07 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:07 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:07 --> Total execution time: 0.0346
INFO - 2023-03-28 06:39:12 --> Config Class Initialized
INFO - 2023-03-28 06:39:12 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:12 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:12 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:12 --> URI Class Initialized
INFO - 2023-03-28 06:39:12 --> Router Class Initialized
INFO - 2023-03-28 06:39:12 --> Output Class Initialized
INFO - 2023-03-28 06:39:12 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:12 --> Input Class Initialized
INFO - 2023-03-28 06:39:12 --> Language Class Initialized
INFO - 2023-03-28 06:39:12 --> Language Class Initialized
INFO - 2023-03-28 06:39:12 --> Config Class Initialized
INFO - 2023-03-28 06:39:12 --> Loader Class Initialized
INFO - 2023-03-28 06:39:12 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:12 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:12 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:12 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:12 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:12 --> Controller Class Initialized
INFO - 2023-03-28 06:39:12 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:12 --> Total execution time: 0.0251
INFO - 2023-03-28 06:39:13 --> Config Class Initialized
INFO - 2023-03-28 06:39:13 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:13 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:13 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:13 --> URI Class Initialized
INFO - 2023-03-28 06:39:13 --> Router Class Initialized
INFO - 2023-03-28 06:39:13 --> Output Class Initialized
INFO - 2023-03-28 06:39:13 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:13 --> Input Class Initialized
INFO - 2023-03-28 06:39:13 --> Language Class Initialized
INFO - 2023-03-28 06:39:13 --> Language Class Initialized
INFO - 2023-03-28 06:39:13 --> Config Class Initialized
INFO - 2023-03-28 06:39:13 --> Loader Class Initialized
INFO - 2023-03-28 06:39:13 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:13 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:13 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:13 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:13 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:13 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:13 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:13 --> Total execution time: 0.0256
INFO - 2023-03-28 06:39:19 --> Config Class Initialized
INFO - 2023-03-28 06:39:19 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:19 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:19 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:19 --> URI Class Initialized
INFO - 2023-03-28 06:39:19 --> Router Class Initialized
INFO - 2023-03-28 06:39:19 --> Output Class Initialized
INFO - 2023-03-28 06:39:19 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:19 --> Input Class Initialized
INFO - 2023-03-28 06:39:19 --> Language Class Initialized
INFO - 2023-03-28 06:39:19 --> Language Class Initialized
INFO - 2023-03-28 06:39:19 --> Config Class Initialized
INFO - 2023-03-28 06:39:19 --> Loader Class Initialized
INFO - 2023-03-28 06:39:19 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:19 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:19 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:19 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:19 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:19 --> Controller Class Initialized
INFO - 2023-03-28 06:39:19 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:19 --> Total execution time: 0.0245
INFO - 2023-03-28 06:39:21 --> Config Class Initialized
INFO - 2023-03-28 06:39:21 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:39:21 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:39:21 --> Utf8 Class Initialized
INFO - 2023-03-28 06:39:21 --> URI Class Initialized
INFO - 2023-03-28 06:39:21 --> Router Class Initialized
INFO - 2023-03-28 06:39:21 --> Output Class Initialized
INFO - 2023-03-28 06:39:21 --> Security Class Initialized
DEBUG - 2023-03-28 06:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:39:21 --> Input Class Initialized
INFO - 2023-03-28 06:39:21 --> Language Class Initialized
INFO - 2023-03-28 06:39:21 --> Language Class Initialized
INFO - 2023-03-28 06:39:21 --> Config Class Initialized
INFO - 2023-03-28 06:39:21 --> Loader Class Initialized
INFO - 2023-03-28 06:39:21 --> Helper loaded: url_helper
INFO - 2023-03-28 06:39:21 --> Helper loaded: file_helper
INFO - 2023-03-28 06:39:21 --> Helper loaded: form_helper
INFO - 2023-03-28 06:39:21 --> Helper loaded: my_helper
INFO - 2023-03-28 06:39:21 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:39:21 --> Controller Class Initialized
DEBUG - 2023-03-28 06:39:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 06:39:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:39:21 --> Final output sent to browser
DEBUG - 2023-03-28 06:39:21 --> Total execution time: 0.0257
INFO - 2023-03-28 06:47:40 --> Config Class Initialized
INFO - 2023-03-28 06:47:40 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:47:40 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:47:40 --> Utf8 Class Initialized
INFO - 2023-03-28 06:47:40 --> URI Class Initialized
INFO - 2023-03-28 06:47:40 --> Router Class Initialized
INFO - 2023-03-28 06:47:40 --> Output Class Initialized
INFO - 2023-03-28 06:47:40 --> Security Class Initialized
DEBUG - 2023-03-28 06:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:47:40 --> Input Class Initialized
INFO - 2023-03-28 06:47:40 --> Language Class Initialized
INFO - 2023-03-28 06:47:40 --> Language Class Initialized
INFO - 2023-03-28 06:47:40 --> Config Class Initialized
INFO - 2023-03-28 06:47:40 --> Loader Class Initialized
INFO - 2023-03-28 06:47:40 --> Helper loaded: url_helper
INFO - 2023-03-28 06:47:40 --> Helper loaded: file_helper
INFO - 2023-03-28 06:47:40 --> Helper loaded: form_helper
INFO - 2023-03-28 06:47:40 --> Helper loaded: my_helper
INFO - 2023-03-28 06:47:40 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:47:40 --> Controller Class Initialized
DEBUG - 2023-03-28 06:47:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 06:47:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:47:40 --> Final output sent to browser
DEBUG - 2023-03-28 06:47:40 --> Total execution time: 0.0309
INFO - 2023-03-28 06:47:45 --> Config Class Initialized
INFO - 2023-03-28 06:47:45 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:47:45 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:47:45 --> Utf8 Class Initialized
INFO - 2023-03-28 06:47:45 --> URI Class Initialized
INFO - 2023-03-28 06:47:45 --> Router Class Initialized
INFO - 2023-03-28 06:47:45 --> Output Class Initialized
INFO - 2023-03-28 06:47:45 --> Security Class Initialized
DEBUG - 2023-03-28 06:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:47:45 --> Input Class Initialized
INFO - 2023-03-28 06:47:45 --> Language Class Initialized
INFO - 2023-03-28 06:47:45 --> Language Class Initialized
INFO - 2023-03-28 06:47:45 --> Config Class Initialized
INFO - 2023-03-28 06:47:45 --> Loader Class Initialized
INFO - 2023-03-28 06:47:45 --> Helper loaded: url_helper
INFO - 2023-03-28 06:47:45 --> Helper loaded: file_helper
INFO - 2023-03-28 06:47:45 --> Helper loaded: form_helper
INFO - 2023-03-28 06:47:45 --> Helper loaded: my_helper
INFO - 2023-03-28 06:47:45 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:47:45 --> Controller Class Initialized
DEBUG - 2023-03-28 06:47:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 06:47:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:47:45 --> Final output sent to browser
DEBUG - 2023-03-28 06:47:45 --> Total execution time: 0.0679
INFO - 2023-03-28 06:47:47 --> Config Class Initialized
INFO - 2023-03-28 06:47:47 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:47:47 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:47:47 --> Utf8 Class Initialized
INFO - 2023-03-28 06:47:47 --> URI Class Initialized
INFO - 2023-03-28 06:47:47 --> Router Class Initialized
INFO - 2023-03-28 06:47:47 --> Output Class Initialized
INFO - 2023-03-28 06:47:47 --> Security Class Initialized
DEBUG - 2023-03-28 06:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:47:47 --> Input Class Initialized
INFO - 2023-03-28 06:47:47 --> Language Class Initialized
INFO - 2023-03-28 06:47:47 --> Language Class Initialized
INFO - 2023-03-28 06:47:47 --> Config Class Initialized
INFO - 2023-03-28 06:47:47 --> Loader Class Initialized
INFO - 2023-03-28 06:47:47 --> Helper loaded: url_helper
INFO - 2023-03-28 06:47:47 --> Helper loaded: file_helper
INFO - 2023-03-28 06:47:47 --> Helper loaded: form_helper
INFO - 2023-03-28 06:47:47 --> Helper loaded: my_helper
INFO - 2023-03-28 06:47:47 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:47:47 --> Controller Class Initialized
DEBUG - 2023-03-28 06:47:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-03-28 06:47:47 --> Final output sent to browser
DEBUG - 2023-03-28 06:47:47 --> Total execution time: 0.0717
INFO - 2023-03-28 06:48:45 --> Config Class Initialized
INFO - 2023-03-28 06:48:45 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:48:45 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:48:45 --> Utf8 Class Initialized
INFO - 2023-03-28 06:48:45 --> URI Class Initialized
INFO - 2023-03-28 06:48:45 --> Router Class Initialized
INFO - 2023-03-28 06:48:45 --> Output Class Initialized
INFO - 2023-03-28 06:48:45 --> Security Class Initialized
DEBUG - 2023-03-28 06:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:48:45 --> Input Class Initialized
INFO - 2023-03-28 06:48:45 --> Language Class Initialized
INFO - 2023-03-28 06:48:45 --> Language Class Initialized
INFO - 2023-03-28 06:48:45 --> Config Class Initialized
INFO - 2023-03-28 06:48:46 --> Loader Class Initialized
INFO - 2023-03-28 06:48:46 --> Helper loaded: url_helper
INFO - 2023-03-28 06:48:46 --> Helper loaded: file_helper
INFO - 2023-03-28 06:48:46 --> Helper loaded: form_helper
INFO - 2023-03-28 06:48:46 --> Helper loaded: my_helper
INFO - 2023-03-28 06:48:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:48:46 --> Controller Class Initialized
DEBUG - 2023-03-28 06:48:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-03-28 06:48:46 --> Final output sent to browser
DEBUG - 2023-03-28 06:48:46 --> Total execution time: 0.0433
INFO - 2023-03-28 06:48:51 --> Config Class Initialized
INFO - 2023-03-28 06:48:51 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:48:51 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:48:51 --> Utf8 Class Initialized
INFO - 2023-03-28 06:48:51 --> URI Class Initialized
INFO - 2023-03-28 06:48:51 --> Router Class Initialized
INFO - 2023-03-28 06:48:51 --> Output Class Initialized
INFO - 2023-03-28 06:48:51 --> Security Class Initialized
DEBUG - 2023-03-28 06:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:48:51 --> Input Class Initialized
INFO - 2023-03-28 06:48:51 --> Language Class Initialized
INFO - 2023-03-28 06:48:51 --> Language Class Initialized
INFO - 2023-03-28 06:48:51 --> Config Class Initialized
INFO - 2023-03-28 06:48:51 --> Loader Class Initialized
INFO - 2023-03-28 06:48:51 --> Helper loaded: url_helper
INFO - 2023-03-28 06:48:51 --> Helper loaded: file_helper
INFO - 2023-03-28 06:48:51 --> Helper loaded: form_helper
INFO - 2023-03-28 06:48:51 --> Helper loaded: my_helper
INFO - 2023-03-28 06:48:51 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:48:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:48:51 --> Controller Class Initialized
DEBUG - 2023-03-28 06:48:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 06:48:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:48:51 --> Final output sent to browser
DEBUG - 2023-03-28 06:48:51 --> Total execution time: 0.0521
INFO - 2023-03-28 06:48:57 --> Config Class Initialized
INFO - 2023-03-28 06:48:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:48:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:48:57 --> Utf8 Class Initialized
INFO - 2023-03-28 06:48:57 --> URI Class Initialized
INFO - 2023-03-28 06:48:57 --> Router Class Initialized
INFO - 2023-03-28 06:48:57 --> Output Class Initialized
INFO - 2023-03-28 06:48:57 --> Security Class Initialized
DEBUG - 2023-03-28 06:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:48:57 --> Input Class Initialized
INFO - 2023-03-28 06:48:57 --> Language Class Initialized
INFO - 2023-03-28 06:48:57 --> Language Class Initialized
INFO - 2023-03-28 06:48:57 --> Config Class Initialized
INFO - 2023-03-28 06:48:57 --> Loader Class Initialized
INFO - 2023-03-28 06:48:57 --> Helper loaded: url_helper
INFO - 2023-03-28 06:48:57 --> Helper loaded: file_helper
INFO - 2023-03-28 06:48:57 --> Helper loaded: form_helper
INFO - 2023-03-28 06:48:57 --> Helper loaded: my_helper
INFO - 2023-03-28 06:48:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:48:57 --> Controller Class Initialized
DEBUG - 2023-03-28 06:48:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2023-03-28 06:48:57 --> Final output sent to browser
DEBUG - 2023-03-28 06:48:57 --> Total execution time: 0.0524
INFO - 2023-03-28 06:49:02 --> Config Class Initialized
INFO - 2023-03-28 06:49:02 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:49:02 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:49:02 --> Utf8 Class Initialized
INFO - 2023-03-28 06:49:02 --> URI Class Initialized
INFO - 2023-03-28 06:49:02 --> Router Class Initialized
INFO - 2023-03-28 06:49:02 --> Output Class Initialized
INFO - 2023-03-28 06:49:02 --> Security Class Initialized
DEBUG - 2023-03-28 06:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:49:02 --> Input Class Initialized
INFO - 2023-03-28 06:49:02 --> Language Class Initialized
INFO - 2023-03-28 06:49:02 --> Language Class Initialized
INFO - 2023-03-28 06:49:02 --> Config Class Initialized
INFO - 2023-03-28 06:49:02 --> Loader Class Initialized
INFO - 2023-03-28 06:49:02 --> Helper loaded: url_helper
INFO - 2023-03-28 06:49:02 --> Helper loaded: file_helper
INFO - 2023-03-28 06:49:02 --> Helper loaded: form_helper
INFO - 2023-03-28 06:49:02 --> Helper loaded: my_helper
INFO - 2023-03-28 06:49:02 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:49:02 --> Controller Class Initialized
DEBUG - 2023-03-28 06:49:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2023-03-28 06:49:02 --> Final output sent to browser
DEBUG - 2023-03-28 06:49:02 --> Total execution time: 0.0515
INFO - 2023-03-28 06:49:07 --> Config Class Initialized
INFO - 2023-03-28 06:49:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:49:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:49:07 --> Utf8 Class Initialized
INFO - 2023-03-28 06:49:07 --> URI Class Initialized
INFO - 2023-03-28 06:49:07 --> Router Class Initialized
INFO - 2023-03-28 06:49:07 --> Output Class Initialized
INFO - 2023-03-28 06:49:07 --> Security Class Initialized
DEBUG - 2023-03-28 06:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:49:07 --> Input Class Initialized
INFO - 2023-03-28 06:49:07 --> Language Class Initialized
INFO - 2023-03-28 06:49:07 --> Language Class Initialized
INFO - 2023-03-28 06:49:07 --> Config Class Initialized
INFO - 2023-03-28 06:49:07 --> Loader Class Initialized
INFO - 2023-03-28 06:49:07 --> Helper loaded: url_helper
INFO - 2023-03-28 06:49:07 --> Helper loaded: file_helper
INFO - 2023-03-28 06:49:07 --> Helper loaded: form_helper
INFO - 2023-03-28 06:49:07 --> Helper loaded: my_helper
INFO - 2023-03-28 06:49:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:49:07 --> Controller Class Initialized
DEBUG - 2023-03-28 06:49:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2023-03-28 06:49:07 --> Final output sent to browser
DEBUG - 2023-03-28 06:49:07 --> Total execution time: 0.0588
INFO - 2023-03-28 06:49:13 --> Config Class Initialized
INFO - 2023-03-28 06:49:13 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:49:13 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:49:13 --> Utf8 Class Initialized
INFO - 2023-03-28 06:49:13 --> URI Class Initialized
INFO - 2023-03-28 06:49:13 --> Router Class Initialized
INFO - 2023-03-28 06:49:13 --> Output Class Initialized
INFO - 2023-03-28 06:49:13 --> Security Class Initialized
DEBUG - 2023-03-28 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:49:13 --> Input Class Initialized
INFO - 2023-03-28 06:49:13 --> Language Class Initialized
INFO - 2023-03-28 06:49:13 --> Language Class Initialized
INFO - 2023-03-28 06:49:13 --> Config Class Initialized
INFO - 2023-03-28 06:49:13 --> Loader Class Initialized
INFO - 2023-03-28 06:49:13 --> Helper loaded: url_helper
INFO - 2023-03-28 06:49:13 --> Helper loaded: file_helper
INFO - 2023-03-28 06:49:13 --> Helper loaded: form_helper
INFO - 2023-03-28 06:49:13 --> Helper loaded: my_helper
INFO - 2023-03-28 06:49:13 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:49:13 --> Controller Class Initialized
DEBUG - 2023-03-28 06:49:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-28 06:49:14 --> Final output sent to browser
DEBUG - 2023-03-28 06:49:14 --> Total execution time: 1.0578
INFO - 2023-03-28 06:49:34 --> Config Class Initialized
INFO - 2023-03-28 06:49:34 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:49:34 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:49:34 --> Utf8 Class Initialized
INFO - 2023-03-28 06:49:34 --> URI Class Initialized
INFO - 2023-03-28 06:49:34 --> Router Class Initialized
INFO - 2023-03-28 06:49:34 --> Output Class Initialized
INFO - 2023-03-28 06:49:34 --> Security Class Initialized
DEBUG - 2023-03-28 06:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:49:34 --> Input Class Initialized
INFO - 2023-03-28 06:49:34 --> Language Class Initialized
INFO - 2023-03-28 06:49:34 --> Language Class Initialized
INFO - 2023-03-28 06:49:34 --> Config Class Initialized
INFO - 2023-03-28 06:49:34 --> Loader Class Initialized
INFO - 2023-03-28 06:49:34 --> Helper loaded: url_helper
INFO - 2023-03-28 06:49:34 --> Helper loaded: file_helper
INFO - 2023-03-28 06:49:34 --> Helper loaded: form_helper
INFO - 2023-03-28 06:49:34 --> Helper loaded: my_helper
INFO - 2023-03-28 06:49:34 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:49:34 --> Controller Class Initialized
DEBUG - 2023-03-28 06:49:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 06:49:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:49:34 --> Final output sent to browser
DEBUG - 2023-03-28 06:49:34 --> Total execution time: 0.0274
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:34 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:34 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:34 --> URI Class Initialized
INFO - 2023-03-28 06:50:34 --> Router Class Initialized
INFO - 2023-03-28 06:50:34 --> Output Class Initialized
INFO - 2023-03-28 06:50:34 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:34 --> Input Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Loader Class Initialized
INFO - 2023-03-28 06:50:34 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:34 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:34 --> Controller Class Initialized
INFO - 2023-03-28 06:50:34 --> Helper loaded: cookie_helper
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:34 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:34 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:34 --> URI Class Initialized
INFO - 2023-03-28 06:50:34 --> Router Class Initialized
INFO - 2023-03-28 06:50:34 --> Output Class Initialized
INFO - 2023-03-28 06:50:34 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:34 --> Input Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Loader Class Initialized
INFO - 2023-03-28 06:50:34 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:34 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:34 --> Controller Class Initialized
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:34 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:34 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:34 --> URI Class Initialized
INFO - 2023-03-28 06:50:34 --> Router Class Initialized
INFO - 2023-03-28 06:50:34 --> Output Class Initialized
INFO - 2023-03-28 06:50:34 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:34 --> Input Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Language Class Initialized
INFO - 2023-03-28 06:50:34 --> Config Class Initialized
INFO - 2023-03-28 06:50:34 --> Loader Class Initialized
INFO - 2023-03-28 06:50:34 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:34 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:34 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:34 --> Controller Class Initialized
DEBUG - 2023-03-28 06:50:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 06:50:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:50:34 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:34 --> Total execution time: 0.0427
INFO - 2023-03-28 06:50:38 --> Config Class Initialized
INFO - 2023-03-28 06:50:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:38 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:38 --> URI Class Initialized
INFO - 2023-03-28 06:50:38 --> Router Class Initialized
INFO - 2023-03-28 06:50:38 --> Output Class Initialized
INFO - 2023-03-28 06:50:38 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:38 --> Input Class Initialized
INFO - 2023-03-28 06:50:38 --> Language Class Initialized
INFO - 2023-03-28 06:50:38 --> Language Class Initialized
INFO - 2023-03-28 06:50:38 --> Config Class Initialized
INFO - 2023-03-28 06:50:38 --> Loader Class Initialized
INFO - 2023-03-28 06:50:38 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:38 --> Controller Class Initialized
INFO - 2023-03-28 06:50:38 --> Helper loaded: cookie_helper
INFO - 2023-03-28 06:50:38 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:38 --> Total execution time: 0.0252
INFO - 2023-03-28 06:50:38 --> Config Class Initialized
INFO - 2023-03-28 06:50:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:38 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:38 --> URI Class Initialized
INFO - 2023-03-28 06:50:38 --> Router Class Initialized
INFO - 2023-03-28 06:50:38 --> Output Class Initialized
INFO - 2023-03-28 06:50:38 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:38 --> Input Class Initialized
INFO - 2023-03-28 06:50:38 --> Language Class Initialized
INFO - 2023-03-28 06:50:38 --> Language Class Initialized
INFO - 2023-03-28 06:50:38 --> Config Class Initialized
INFO - 2023-03-28 06:50:38 --> Loader Class Initialized
INFO - 2023-03-28 06:50:38 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:38 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:38 --> Controller Class Initialized
DEBUG - 2023-03-28 06:50:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 06:50:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:50:38 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:38 --> Total execution time: 0.0417
INFO - 2023-03-28 06:50:40 --> Config Class Initialized
INFO - 2023-03-28 06:50:40 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:40 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:40 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:40 --> URI Class Initialized
INFO - 2023-03-28 06:50:40 --> Router Class Initialized
INFO - 2023-03-28 06:50:40 --> Output Class Initialized
INFO - 2023-03-28 06:50:40 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:40 --> Input Class Initialized
INFO - 2023-03-28 06:50:40 --> Language Class Initialized
INFO - 2023-03-28 06:50:40 --> Language Class Initialized
INFO - 2023-03-28 06:50:40 --> Config Class Initialized
INFO - 2023-03-28 06:50:40 --> Loader Class Initialized
INFO - 2023-03-28 06:50:40 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:40 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:40 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:40 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:40 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:40 --> Controller Class Initialized
DEBUG - 2023-03-28 06:50:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 06:50:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:50:40 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:40 --> Total execution time: 0.0745
INFO - 2023-03-28 06:50:46 --> Config Class Initialized
INFO - 2023-03-28 06:50:46 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:46 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:46 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:46 --> URI Class Initialized
INFO - 2023-03-28 06:50:46 --> Router Class Initialized
INFO - 2023-03-28 06:50:46 --> Output Class Initialized
INFO - 2023-03-28 06:50:46 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:46 --> Input Class Initialized
INFO - 2023-03-28 06:50:46 --> Language Class Initialized
INFO - 2023-03-28 06:50:46 --> Language Class Initialized
INFO - 2023-03-28 06:50:46 --> Config Class Initialized
INFO - 2023-03-28 06:50:46 --> Loader Class Initialized
INFO - 2023-03-28 06:50:46 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:46 --> Controller Class Initialized
DEBUG - 2023-03-28 06:50:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-03-28 06:50:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:50:46 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:46 --> Total execution time: 0.0800
INFO - 2023-03-28 06:50:46 --> Config Class Initialized
INFO - 2023-03-28 06:50:46 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:46 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:46 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:46 --> URI Class Initialized
INFO - 2023-03-28 06:50:46 --> Router Class Initialized
INFO - 2023-03-28 06:50:46 --> Output Class Initialized
INFO - 2023-03-28 06:50:46 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:46 --> Input Class Initialized
INFO - 2023-03-28 06:50:46 --> Language Class Initialized
INFO - 2023-03-28 06:50:46 --> Language Class Initialized
INFO - 2023-03-28 06:50:46 --> Config Class Initialized
INFO - 2023-03-28 06:50:46 --> Loader Class Initialized
INFO - 2023-03-28 06:50:46 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:46 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:46 --> Controller Class Initialized
INFO - 2023-03-28 06:50:54 --> Config Class Initialized
INFO - 2023-03-28 06:50:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:54 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:54 --> URI Class Initialized
INFO - 2023-03-28 06:50:54 --> Router Class Initialized
INFO - 2023-03-28 06:50:54 --> Output Class Initialized
INFO - 2023-03-28 06:50:54 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:54 --> Input Class Initialized
INFO - 2023-03-28 06:50:54 --> Language Class Initialized
INFO - 2023-03-28 06:50:54 --> Language Class Initialized
INFO - 2023-03-28 06:50:54 --> Config Class Initialized
INFO - 2023-03-28 06:50:54 --> Loader Class Initialized
INFO - 2023-03-28 06:50:54 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:54 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:54 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:54 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:54 --> Controller Class Initialized
INFO - 2023-03-28 06:50:54 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:54 --> Total execution time: 0.0264
INFO - 2023-03-28 06:50:57 --> Config Class Initialized
INFO - 2023-03-28 06:50:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:57 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:57 --> URI Class Initialized
INFO - 2023-03-28 06:50:57 --> Router Class Initialized
INFO - 2023-03-28 06:50:57 --> Output Class Initialized
INFO - 2023-03-28 06:50:57 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:57 --> Input Class Initialized
INFO - 2023-03-28 06:50:57 --> Language Class Initialized
INFO - 2023-03-28 06:50:57 --> Language Class Initialized
INFO - 2023-03-28 06:50:57 --> Config Class Initialized
INFO - 2023-03-28 06:50:57 --> Loader Class Initialized
INFO - 2023-03-28 06:50:57 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:57 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:57 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:57 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:57 --> Controller Class Initialized
INFO - 2023-03-28 06:50:57 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:57 --> Total execution time: 0.0240
INFO - 2023-03-28 06:50:58 --> Config Class Initialized
INFO - 2023-03-28 06:50:58 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:50:58 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:50:58 --> Utf8 Class Initialized
INFO - 2023-03-28 06:50:58 --> URI Class Initialized
INFO - 2023-03-28 06:50:58 --> Router Class Initialized
INFO - 2023-03-28 06:50:58 --> Output Class Initialized
INFO - 2023-03-28 06:50:58 --> Security Class Initialized
DEBUG - 2023-03-28 06:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:50:58 --> Input Class Initialized
INFO - 2023-03-28 06:50:58 --> Language Class Initialized
INFO - 2023-03-28 06:50:58 --> Language Class Initialized
INFO - 2023-03-28 06:50:58 --> Config Class Initialized
INFO - 2023-03-28 06:50:58 --> Loader Class Initialized
INFO - 2023-03-28 06:50:58 --> Helper loaded: url_helper
INFO - 2023-03-28 06:50:58 --> Helper loaded: file_helper
INFO - 2023-03-28 06:50:58 --> Helper loaded: form_helper
INFO - 2023-03-28 06:50:58 --> Helper loaded: my_helper
INFO - 2023-03-28 06:50:58 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:50:58 --> Controller Class Initialized
INFO - 2023-03-28 06:50:58 --> Final output sent to browser
DEBUG - 2023-03-28 06:50:58 --> Total execution time: 0.0242
INFO - 2023-03-28 06:51:29 --> Config Class Initialized
INFO - 2023-03-28 06:51:29 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:29 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:29 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:29 --> URI Class Initialized
INFO - 2023-03-28 06:51:29 --> Router Class Initialized
INFO - 2023-03-28 06:51:29 --> Output Class Initialized
INFO - 2023-03-28 06:51:29 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:29 --> Input Class Initialized
INFO - 2023-03-28 06:51:29 --> Language Class Initialized
INFO - 2023-03-28 06:51:29 --> Language Class Initialized
INFO - 2023-03-28 06:51:29 --> Config Class Initialized
INFO - 2023-03-28 06:51:29 --> Loader Class Initialized
INFO - 2023-03-28 06:51:29 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:29 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:29 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:29 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:29 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:29 --> Controller Class Initialized
INFO - 2023-03-28 06:51:29 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:29 --> Total execution time: 0.0265
INFO - 2023-03-28 06:51:32 --> Config Class Initialized
INFO - 2023-03-28 06:51:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:32 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:32 --> URI Class Initialized
INFO - 2023-03-28 06:51:32 --> Router Class Initialized
INFO - 2023-03-28 06:51:32 --> Output Class Initialized
INFO - 2023-03-28 06:51:32 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:32 --> Input Class Initialized
INFO - 2023-03-28 06:51:32 --> Language Class Initialized
INFO - 2023-03-28 06:51:32 --> Language Class Initialized
INFO - 2023-03-28 06:51:32 --> Config Class Initialized
INFO - 2023-03-28 06:51:32 --> Loader Class Initialized
INFO - 2023-03-28 06:51:32 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:32 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:32 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:32 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:32 --> Controller Class Initialized
INFO - 2023-03-28 06:51:32 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:32 --> Total execution time: 0.0410
INFO - 2023-03-28 06:51:33 --> Config Class Initialized
INFO - 2023-03-28 06:51:33 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:33 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:33 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:33 --> URI Class Initialized
INFO - 2023-03-28 06:51:33 --> Router Class Initialized
INFO - 2023-03-28 06:51:33 --> Output Class Initialized
INFO - 2023-03-28 06:51:33 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:33 --> Input Class Initialized
INFO - 2023-03-28 06:51:33 --> Language Class Initialized
INFO - 2023-03-28 06:51:33 --> Language Class Initialized
INFO - 2023-03-28 06:51:33 --> Config Class Initialized
INFO - 2023-03-28 06:51:33 --> Loader Class Initialized
INFO - 2023-03-28 06:51:33 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:33 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:33 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:33 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:33 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:33 --> Controller Class Initialized
INFO - 2023-03-28 06:51:33 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:33 --> Total execution time: 0.0266
INFO - 2023-03-28 06:51:35 --> Config Class Initialized
INFO - 2023-03-28 06:51:35 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:35 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:35 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:35 --> URI Class Initialized
INFO - 2023-03-28 06:51:35 --> Router Class Initialized
INFO - 2023-03-28 06:51:35 --> Output Class Initialized
INFO - 2023-03-28 06:51:35 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:35 --> Input Class Initialized
INFO - 2023-03-28 06:51:35 --> Language Class Initialized
INFO - 2023-03-28 06:51:35 --> Language Class Initialized
INFO - 2023-03-28 06:51:35 --> Config Class Initialized
INFO - 2023-03-28 06:51:35 --> Loader Class Initialized
INFO - 2023-03-28 06:51:35 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:35 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:35 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:35 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:35 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:35 --> Controller Class Initialized
INFO - 2023-03-28 06:51:35 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:35 --> Total execution time: 0.0323
INFO - 2023-03-28 06:51:36 --> Config Class Initialized
INFO - 2023-03-28 06:51:36 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:36 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:36 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:36 --> URI Class Initialized
INFO - 2023-03-28 06:51:36 --> Router Class Initialized
INFO - 2023-03-28 06:51:36 --> Output Class Initialized
INFO - 2023-03-28 06:51:36 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:36 --> Input Class Initialized
INFO - 2023-03-28 06:51:36 --> Language Class Initialized
INFO - 2023-03-28 06:51:36 --> Language Class Initialized
INFO - 2023-03-28 06:51:36 --> Config Class Initialized
INFO - 2023-03-28 06:51:36 --> Loader Class Initialized
INFO - 2023-03-28 06:51:36 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:36 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:36 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:36 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:36 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:36 --> Controller Class Initialized
INFO - 2023-03-28 06:51:36 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:36 --> Total execution time: 0.0245
INFO - 2023-03-28 06:51:37 --> Config Class Initialized
INFO - 2023-03-28 06:51:37 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:37 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:37 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:37 --> URI Class Initialized
INFO - 2023-03-28 06:51:37 --> Router Class Initialized
INFO - 2023-03-28 06:51:37 --> Output Class Initialized
INFO - 2023-03-28 06:51:37 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:37 --> Input Class Initialized
INFO - 2023-03-28 06:51:37 --> Language Class Initialized
INFO - 2023-03-28 06:51:37 --> Language Class Initialized
INFO - 2023-03-28 06:51:37 --> Config Class Initialized
INFO - 2023-03-28 06:51:37 --> Loader Class Initialized
INFO - 2023-03-28 06:51:37 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:37 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:37 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:37 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:37 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:37 --> Controller Class Initialized
INFO - 2023-03-28 06:51:37 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:37 --> Total execution time: 0.0451
INFO - 2023-03-28 06:51:38 --> Config Class Initialized
INFO - 2023-03-28 06:51:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:38 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:38 --> URI Class Initialized
INFO - 2023-03-28 06:51:38 --> Router Class Initialized
INFO - 2023-03-28 06:51:38 --> Output Class Initialized
INFO - 2023-03-28 06:51:38 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:38 --> Input Class Initialized
INFO - 2023-03-28 06:51:38 --> Language Class Initialized
INFO - 2023-03-28 06:51:38 --> Language Class Initialized
INFO - 2023-03-28 06:51:38 --> Config Class Initialized
INFO - 2023-03-28 06:51:38 --> Loader Class Initialized
INFO - 2023-03-28 06:51:38 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:38 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:38 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:38 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:38 --> Controller Class Initialized
INFO - 2023-03-28 06:51:38 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:38 --> Total execution time: 0.0433
INFO - 2023-03-28 06:51:39 --> Config Class Initialized
INFO - 2023-03-28 06:51:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:51:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:51:39 --> Utf8 Class Initialized
INFO - 2023-03-28 06:51:39 --> URI Class Initialized
INFO - 2023-03-28 06:51:39 --> Router Class Initialized
INFO - 2023-03-28 06:51:39 --> Output Class Initialized
INFO - 2023-03-28 06:51:39 --> Security Class Initialized
DEBUG - 2023-03-28 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:51:39 --> Input Class Initialized
INFO - 2023-03-28 06:51:39 --> Language Class Initialized
INFO - 2023-03-28 06:51:39 --> Language Class Initialized
INFO - 2023-03-28 06:51:39 --> Config Class Initialized
INFO - 2023-03-28 06:51:39 --> Loader Class Initialized
INFO - 2023-03-28 06:51:39 --> Helper loaded: url_helper
INFO - 2023-03-28 06:51:39 --> Helper loaded: file_helper
INFO - 2023-03-28 06:51:39 --> Helper loaded: form_helper
INFO - 2023-03-28 06:51:39 --> Helper loaded: my_helper
INFO - 2023-03-28 06:51:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:51:39 --> Controller Class Initialized
INFO - 2023-03-28 06:51:39 --> Final output sent to browser
DEBUG - 2023-03-28 06:51:39 --> Total execution time: 0.0459
INFO - 2023-03-28 06:56:09 --> Config Class Initialized
INFO - 2023-03-28 06:56:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:56:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:56:09 --> Utf8 Class Initialized
INFO - 2023-03-28 06:56:09 --> URI Class Initialized
INFO - 2023-03-28 06:56:09 --> Router Class Initialized
INFO - 2023-03-28 06:56:09 --> Output Class Initialized
INFO - 2023-03-28 06:56:09 --> Security Class Initialized
DEBUG - 2023-03-28 06:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:56:09 --> Input Class Initialized
INFO - 2023-03-28 06:56:09 --> Language Class Initialized
INFO - 2023-03-28 06:56:09 --> Language Class Initialized
INFO - 2023-03-28 06:56:09 --> Config Class Initialized
INFO - 2023-03-28 06:56:09 --> Loader Class Initialized
INFO - 2023-03-28 06:56:09 --> Helper loaded: url_helper
INFO - 2023-03-28 06:56:09 --> Helper loaded: file_helper
INFO - 2023-03-28 06:56:09 --> Helper loaded: form_helper
INFO - 2023-03-28 06:56:09 --> Helper loaded: my_helper
INFO - 2023-03-28 06:56:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:56:09 --> Controller Class Initialized
DEBUG - 2023-03-28 06:56:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 06:56:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:56:09 --> Final output sent to browser
DEBUG - 2023-03-28 06:56:09 --> Total execution time: 0.0274
INFO - 2023-03-28 06:56:10 --> Config Class Initialized
INFO - 2023-03-28 06:56:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:56:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:56:10 --> Utf8 Class Initialized
INFO - 2023-03-28 06:56:10 --> URI Class Initialized
INFO - 2023-03-28 06:56:10 --> Router Class Initialized
INFO - 2023-03-28 06:56:10 --> Output Class Initialized
INFO - 2023-03-28 06:56:10 --> Security Class Initialized
DEBUG - 2023-03-28 06:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:56:10 --> Input Class Initialized
INFO - 2023-03-28 06:56:10 --> Language Class Initialized
INFO - 2023-03-28 06:56:10 --> Language Class Initialized
INFO - 2023-03-28 06:56:10 --> Config Class Initialized
INFO - 2023-03-28 06:56:10 --> Loader Class Initialized
INFO - 2023-03-28 06:56:10 --> Helper loaded: url_helper
INFO - 2023-03-28 06:56:10 --> Helper loaded: file_helper
INFO - 2023-03-28 06:56:10 --> Helper loaded: form_helper
INFO - 2023-03-28 06:56:10 --> Helper loaded: my_helper
INFO - 2023-03-28 06:56:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:56:10 --> Controller Class Initialized
DEBUG - 2023-03-28 06:56:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-03-28 06:56:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:56:10 --> Final output sent to browser
DEBUG - 2023-03-28 06:56:10 --> Total execution time: 0.0602
INFO - 2023-03-28 06:56:20 --> Config Class Initialized
INFO - 2023-03-28 06:56:20 --> Hooks Class Initialized
DEBUG - 2023-03-28 06:56:20 --> UTF-8 Support Enabled
INFO - 2023-03-28 06:56:20 --> Utf8 Class Initialized
INFO - 2023-03-28 06:56:20 --> URI Class Initialized
INFO - 2023-03-28 06:56:20 --> Router Class Initialized
INFO - 2023-03-28 06:56:20 --> Output Class Initialized
INFO - 2023-03-28 06:56:20 --> Security Class Initialized
DEBUG - 2023-03-28 06:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 06:56:20 --> Input Class Initialized
INFO - 2023-03-28 06:56:20 --> Language Class Initialized
INFO - 2023-03-28 06:56:20 --> Language Class Initialized
INFO - 2023-03-28 06:56:20 --> Config Class Initialized
INFO - 2023-03-28 06:56:20 --> Loader Class Initialized
INFO - 2023-03-28 06:56:20 --> Helper loaded: url_helper
INFO - 2023-03-28 06:56:20 --> Helper loaded: file_helper
INFO - 2023-03-28 06:56:20 --> Helper loaded: form_helper
INFO - 2023-03-28 06:56:20 --> Helper loaded: my_helper
INFO - 2023-03-28 06:56:20 --> Database Driver Class Initialized
DEBUG - 2023-03-28 06:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 06:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 06:56:20 --> Controller Class Initialized
DEBUG - 2023-03-28 06:56:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 06:56:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 06:56:20 --> Final output sent to browser
DEBUG - 2023-03-28 06:56:20 --> Total execution time: 0.0277
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:01 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:01 --> URI Class Initialized
INFO - 2023-03-28 07:02:01 --> Router Class Initialized
INFO - 2023-03-28 07:02:01 --> Output Class Initialized
INFO - 2023-03-28 07:02:01 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:01 --> Input Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Loader Class Initialized
INFO - 2023-03-28 07:02:01 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:01 --> Controller Class Initialized
INFO - 2023-03-28 07:02:01 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:01 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:01 --> URI Class Initialized
INFO - 2023-03-28 07:02:01 --> Router Class Initialized
INFO - 2023-03-28 07:02:01 --> Output Class Initialized
INFO - 2023-03-28 07:02:01 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:01 --> Input Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Loader Class Initialized
INFO - 2023-03-28 07:02:01 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:01 --> Controller Class Initialized
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:01 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:01 --> URI Class Initialized
INFO - 2023-03-28 07:02:01 --> Router Class Initialized
INFO - 2023-03-28 07:02:01 --> Output Class Initialized
INFO - 2023-03-28 07:02:01 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:01 --> Input Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Language Class Initialized
INFO - 2023-03-28 07:02:01 --> Config Class Initialized
INFO - 2023-03-28 07:02:01 --> Loader Class Initialized
INFO - 2023-03-28 07:02:01 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:01 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:01 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:02:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:02:01 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:01 --> Total execution time: 0.0224
INFO - 2023-03-28 07:02:08 --> Config Class Initialized
INFO - 2023-03-28 07:02:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:08 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:08 --> URI Class Initialized
INFO - 2023-03-28 07:02:08 --> Router Class Initialized
INFO - 2023-03-28 07:02:08 --> Output Class Initialized
INFO - 2023-03-28 07:02:08 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:08 --> Input Class Initialized
INFO - 2023-03-28 07:02:08 --> Language Class Initialized
INFO - 2023-03-28 07:02:08 --> Language Class Initialized
INFO - 2023-03-28 07:02:08 --> Config Class Initialized
INFO - 2023-03-28 07:02:08 --> Loader Class Initialized
INFO - 2023-03-28 07:02:08 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:08 --> Controller Class Initialized
INFO - 2023-03-28 07:02:08 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:02:08 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:08 --> Total execution time: 0.0343
INFO - 2023-03-28 07:02:08 --> Config Class Initialized
INFO - 2023-03-28 07:02:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:08 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:08 --> URI Class Initialized
INFO - 2023-03-28 07:02:08 --> Router Class Initialized
INFO - 2023-03-28 07:02:08 --> Output Class Initialized
INFO - 2023-03-28 07:02:08 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:08 --> Input Class Initialized
INFO - 2023-03-28 07:02:08 --> Language Class Initialized
INFO - 2023-03-28 07:02:08 --> Language Class Initialized
INFO - 2023-03-28 07:02:08 --> Config Class Initialized
INFO - 2023-03-28 07:02:08 --> Loader Class Initialized
INFO - 2023-03-28 07:02:08 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:08 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:08 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:02:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:02:08 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:08 --> Total execution time: 0.0300
INFO - 2023-03-28 07:02:15 --> Config Class Initialized
INFO - 2023-03-28 07:02:15 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:15 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:15 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:15 --> URI Class Initialized
INFO - 2023-03-28 07:02:15 --> Router Class Initialized
INFO - 2023-03-28 07:02:15 --> Output Class Initialized
INFO - 2023-03-28 07:02:15 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:15 --> Input Class Initialized
INFO - 2023-03-28 07:02:15 --> Language Class Initialized
INFO - 2023-03-28 07:02:15 --> Language Class Initialized
INFO - 2023-03-28 07:02:15 --> Config Class Initialized
INFO - 2023-03-28 07:02:15 --> Loader Class Initialized
INFO - 2023-03-28 07:02:15 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:15 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:15 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:15 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:15 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:15 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 07:02:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:02:15 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:15 --> Total execution time: 0.0291
INFO - 2023-03-28 07:02:17 --> Config Class Initialized
INFO - 2023-03-28 07:02:17 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:17 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:17 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:17 --> URI Class Initialized
INFO - 2023-03-28 07:02:17 --> Router Class Initialized
INFO - 2023-03-28 07:02:17 --> Output Class Initialized
INFO - 2023-03-28 07:02:17 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:17 --> Input Class Initialized
INFO - 2023-03-28 07:02:17 --> Language Class Initialized
INFO - 2023-03-28 07:02:17 --> Language Class Initialized
INFO - 2023-03-28 07:02:17 --> Config Class Initialized
INFO - 2023-03-28 07:02:17 --> Loader Class Initialized
INFO - 2023-03-28 07:02:17 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:17 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:17 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:17 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:17 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:17 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:02:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:02:17 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:17 --> Total execution time: 0.0276
INFO - 2023-03-28 07:02:18 --> Config Class Initialized
INFO - 2023-03-28 07:02:18 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:18 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:18 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:18 --> URI Class Initialized
INFO - 2023-03-28 07:02:18 --> Router Class Initialized
INFO - 2023-03-28 07:02:18 --> Output Class Initialized
INFO - 2023-03-28 07:02:18 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:18 --> Input Class Initialized
INFO - 2023-03-28 07:02:18 --> Language Class Initialized
INFO - 2023-03-28 07:02:18 --> Language Class Initialized
INFO - 2023-03-28 07:02:18 --> Config Class Initialized
INFO - 2023-03-28 07:02:18 --> Loader Class Initialized
INFO - 2023-03-28 07:02:18 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:18 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:18 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:18 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:18 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:18 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-03-28 07:02:18 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:18 --> Total execution time: 0.0361
INFO - 2023-03-28 07:02:23 --> Config Class Initialized
INFO - 2023-03-28 07:02:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:23 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:23 --> URI Class Initialized
INFO - 2023-03-28 07:02:23 --> Router Class Initialized
INFO - 2023-03-28 07:02:23 --> Output Class Initialized
INFO - 2023-03-28 07:02:23 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:23 --> Input Class Initialized
INFO - 2023-03-28 07:02:23 --> Language Class Initialized
INFO - 2023-03-28 07:02:23 --> Language Class Initialized
INFO - 2023-03-28 07:02:23 --> Config Class Initialized
INFO - 2023-03-28 07:02:23 --> Loader Class Initialized
INFO - 2023-03-28 07:02:23 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:23 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:23 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:23 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:23 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:02:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:02:23 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:23 --> Total execution time: 0.0281
INFO - 2023-03-28 07:02:25 --> Config Class Initialized
INFO - 2023-03-28 07:02:25 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:02:25 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:02:25 --> Utf8 Class Initialized
INFO - 2023-03-28 07:02:25 --> URI Class Initialized
INFO - 2023-03-28 07:02:25 --> Router Class Initialized
INFO - 2023-03-28 07:02:25 --> Output Class Initialized
INFO - 2023-03-28 07:02:25 --> Security Class Initialized
DEBUG - 2023-03-28 07:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:02:25 --> Input Class Initialized
INFO - 2023-03-28 07:02:25 --> Language Class Initialized
INFO - 2023-03-28 07:02:25 --> Language Class Initialized
INFO - 2023-03-28 07:02:25 --> Config Class Initialized
INFO - 2023-03-28 07:02:25 --> Loader Class Initialized
INFO - 2023-03-28 07:02:25 --> Helper loaded: url_helper
INFO - 2023-03-28 07:02:25 --> Helper loaded: file_helper
INFO - 2023-03-28 07:02:25 --> Helper loaded: form_helper
INFO - 2023-03-28 07:02:25 --> Helper loaded: my_helper
INFO - 2023-03-28 07:02:25 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:02:25 --> Controller Class Initialized
DEBUG - 2023-03-28 07:02:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 07:02:26 --> Final output sent to browser
DEBUG - 2023-03-28 07:02:26 --> Total execution time: 1.2044
INFO - 2023-03-28 07:03:16 --> Config Class Initialized
INFO - 2023-03-28 07:03:16 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:16 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:16 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:16 --> URI Class Initialized
DEBUG - 2023-03-28 07:03:16 --> No URI present. Default controller set.
INFO - 2023-03-28 07:03:16 --> Router Class Initialized
INFO - 2023-03-28 07:03:16 --> Output Class Initialized
INFO - 2023-03-28 07:03:16 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:16 --> Input Class Initialized
INFO - 2023-03-28 07:03:16 --> Language Class Initialized
INFO - 2023-03-28 07:03:16 --> Language Class Initialized
INFO - 2023-03-28 07:03:16 --> Config Class Initialized
INFO - 2023-03-28 07:03:16 --> Loader Class Initialized
INFO - 2023-03-28 07:03:16 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:16 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:16 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:16 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:16 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:16 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:03:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:16 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:16 --> Total execution time: 0.0414
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:24 --> URI Class Initialized
INFO - 2023-03-28 07:03:24 --> Router Class Initialized
INFO - 2023-03-28 07:03:24 --> Output Class Initialized
INFO - 2023-03-28 07:03:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:24 --> Input Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Loader Class Initialized
INFO - 2023-03-28 07:03:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:24 --> Controller Class Initialized
INFO - 2023-03-28 07:03:24 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:24 --> URI Class Initialized
INFO - 2023-03-28 07:03:24 --> Router Class Initialized
INFO - 2023-03-28 07:03:24 --> Output Class Initialized
INFO - 2023-03-28 07:03:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:24 --> Input Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Loader Class Initialized
INFO - 2023-03-28 07:03:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:24 --> Controller Class Initialized
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:24 --> URI Class Initialized
INFO - 2023-03-28 07:03:24 --> Router Class Initialized
INFO - 2023-03-28 07:03:24 --> Output Class Initialized
INFO - 2023-03-28 07:03:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:24 --> Input Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Language Class Initialized
INFO - 2023-03-28 07:03:24 --> Config Class Initialized
INFO - 2023-03-28 07:03:24 --> Loader Class Initialized
INFO - 2023-03-28 07:03:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:24 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:03:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:24 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:24 --> Total execution time: 0.0393
INFO - 2023-03-28 07:03:29 --> Config Class Initialized
INFO - 2023-03-28 07:03:29 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:29 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:29 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:29 --> URI Class Initialized
INFO - 2023-03-28 07:03:29 --> Router Class Initialized
INFO - 2023-03-28 07:03:29 --> Output Class Initialized
INFO - 2023-03-28 07:03:29 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:29 --> Input Class Initialized
INFO - 2023-03-28 07:03:29 --> Language Class Initialized
INFO - 2023-03-28 07:03:29 --> Language Class Initialized
INFO - 2023-03-28 07:03:29 --> Config Class Initialized
INFO - 2023-03-28 07:03:29 --> Loader Class Initialized
INFO - 2023-03-28 07:03:29 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:29 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:29 --> Controller Class Initialized
INFO - 2023-03-28 07:03:29 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:03:29 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:29 --> Total execution time: 0.0265
INFO - 2023-03-28 07:03:29 --> Config Class Initialized
INFO - 2023-03-28 07:03:29 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:29 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:29 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:29 --> URI Class Initialized
INFO - 2023-03-28 07:03:29 --> Router Class Initialized
INFO - 2023-03-28 07:03:29 --> Output Class Initialized
INFO - 2023-03-28 07:03:29 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:29 --> Input Class Initialized
INFO - 2023-03-28 07:03:29 --> Language Class Initialized
INFO - 2023-03-28 07:03:29 --> Language Class Initialized
INFO - 2023-03-28 07:03:29 --> Config Class Initialized
INFO - 2023-03-28 07:03:29 --> Loader Class Initialized
INFO - 2023-03-28 07:03:29 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:29 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:29 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:29 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:03:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:29 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:29 --> Total execution time: 0.0273
INFO - 2023-03-28 07:03:31 --> Config Class Initialized
INFO - 2023-03-28 07:03:31 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:31 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:31 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:31 --> URI Class Initialized
INFO - 2023-03-28 07:03:31 --> Router Class Initialized
INFO - 2023-03-28 07:03:31 --> Output Class Initialized
INFO - 2023-03-28 07:03:31 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:31 --> Input Class Initialized
INFO - 2023-03-28 07:03:31 --> Language Class Initialized
INFO - 2023-03-28 07:03:31 --> Language Class Initialized
INFO - 2023-03-28 07:03:31 --> Config Class Initialized
INFO - 2023-03-28 07:03:31 --> Loader Class Initialized
INFO - 2023-03-28 07:03:31 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:31 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:31 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:31 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:31 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:31 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:03:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:31 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:31 --> Total execution time: 0.0465
INFO - 2023-03-28 07:03:35 --> Config Class Initialized
INFO - 2023-03-28 07:03:35 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:35 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:35 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:35 --> URI Class Initialized
INFO - 2023-03-28 07:03:35 --> Router Class Initialized
INFO - 2023-03-28 07:03:35 --> Output Class Initialized
INFO - 2023-03-28 07:03:35 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:35 --> Input Class Initialized
INFO - 2023-03-28 07:03:35 --> Language Class Initialized
INFO - 2023-03-28 07:03:35 --> Language Class Initialized
INFO - 2023-03-28 07:03:35 --> Config Class Initialized
INFO - 2023-03-28 07:03:35 --> Loader Class Initialized
INFO - 2023-03-28 07:03:35 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:35 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:35 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:35 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:35 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:35 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-03-28 07:03:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:35 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:35 --> Total execution time: 0.0679
INFO - 2023-03-28 07:03:36 --> Config Class Initialized
INFO - 2023-03-28 07:03:36 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:36 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:36 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:36 --> URI Class Initialized
INFO - 2023-03-28 07:03:36 --> Router Class Initialized
INFO - 2023-03-28 07:03:36 --> Output Class Initialized
INFO - 2023-03-28 07:03:36 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:36 --> Input Class Initialized
INFO - 2023-03-28 07:03:36 --> Language Class Initialized
INFO - 2023-03-28 07:03:36 --> Language Class Initialized
INFO - 2023-03-28 07:03:36 --> Config Class Initialized
INFO - 2023-03-28 07:03:36 --> Loader Class Initialized
INFO - 2023-03-28 07:03:36 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:36 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:36 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:36 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:36 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:36 --> Controller Class Initialized
INFO - 2023-03-28 07:03:36 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:36 --> Total execution time: 0.0476
INFO - 2023-03-28 07:03:38 --> Config Class Initialized
INFO - 2023-03-28 07:03:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:38 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:38 --> URI Class Initialized
INFO - 2023-03-28 07:03:38 --> Router Class Initialized
INFO - 2023-03-28 07:03:38 --> Output Class Initialized
INFO - 2023-03-28 07:03:38 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:38 --> Input Class Initialized
INFO - 2023-03-28 07:03:38 --> Language Class Initialized
INFO - 2023-03-28 07:03:38 --> Language Class Initialized
INFO - 2023-03-28 07:03:38 --> Config Class Initialized
INFO - 2023-03-28 07:03:38 --> Loader Class Initialized
INFO - 2023-03-28 07:03:38 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:38 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:38 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:38 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:38 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:03:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:38 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:38 --> Total execution time: 0.0277
INFO - 2023-03-28 07:03:39 --> Config Class Initialized
INFO - 2023-03-28 07:03:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:39 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:39 --> URI Class Initialized
INFO - 2023-03-28 07:03:39 --> Router Class Initialized
INFO - 2023-03-28 07:03:39 --> Output Class Initialized
INFO - 2023-03-28 07:03:39 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:39 --> Input Class Initialized
INFO - 2023-03-28 07:03:39 --> Language Class Initialized
INFO - 2023-03-28 07:03:39 --> Language Class Initialized
INFO - 2023-03-28 07:03:39 --> Config Class Initialized
INFO - 2023-03-28 07:03:39 --> Loader Class Initialized
INFO - 2023-03-28 07:03:39 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:39 --> Controller Class Initialized
DEBUG - 2023-03-28 07:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-03-28 07:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:03:39 --> Final output sent to browser
DEBUG - 2023-03-28 07:03:39 --> Total execution time: 0.0268
INFO - 2023-03-28 07:03:39 --> Config Class Initialized
INFO - 2023-03-28 07:03:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:03:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:03:39 --> Utf8 Class Initialized
INFO - 2023-03-28 07:03:39 --> URI Class Initialized
INFO - 2023-03-28 07:03:39 --> Router Class Initialized
INFO - 2023-03-28 07:03:39 --> Output Class Initialized
INFO - 2023-03-28 07:03:39 --> Security Class Initialized
DEBUG - 2023-03-28 07:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:03:39 --> Input Class Initialized
INFO - 2023-03-28 07:03:39 --> Language Class Initialized
INFO - 2023-03-28 07:03:39 --> Language Class Initialized
INFO - 2023-03-28 07:03:39 --> Config Class Initialized
INFO - 2023-03-28 07:03:39 --> Loader Class Initialized
INFO - 2023-03-28 07:03:39 --> Helper loaded: url_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: file_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: form_helper
INFO - 2023-03-28 07:03:39 --> Helper loaded: my_helper
INFO - 2023-03-28 07:03:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:03:39 --> Controller Class Initialized
INFO - 2023-03-28 07:04:16 --> Config Class Initialized
INFO - 2023-03-28 07:04:16 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:16 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:16 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:16 --> URI Class Initialized
INFO - 2023-03-28 07:04:16 --> Router Class Initialized
INFO - 2023-03-28 07:04:16 --> Output Class Initialized
INFO - 2023-03-28 07:04:16 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:16 --> Input Class Initialized
INFO - 2023-03-28 07:04:16 --> Language Class Initialized
INFO - 2023-03-28 07:04:16 --> Language Class Initialized
INFO - 2023-03-28 07:04:16 --> Config Class Initialized
INFO - 2023-03-28 07:04:16 --> Loader Class Initialized
INFO - 2023-03-28 07:04:16 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:16 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:16 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:16 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:16 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:16 --> Controller Class Initialized
DEBUG - 2023-03-28 07:04:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:04:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:04:16 --> Final output sent to browser
DEBUG - 2023-03-28 07:04:16 --> Total execution time: 0.0286
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:18 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:18 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:18 --> URI Class Initialized
INFO - 2023-03-28 07:04:18 --> Router Class Initialized
INFO - 2023-03-28 07:04:18 --> Output Class Initialized
INFO - 2023-03-28 07:04:18 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:18 --> Input Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Loader Class Initialized
INFO - 2023-03-28 07:04:18 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:18 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:18 --> Controller Class Initialized
INFO - 2023-03-28 07:04:18 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:18 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:18 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:18 --> URI Class Initialized
INFO - 2023-03-28 07:04:18 --> Router Class Initialized
INFO - 2023-03-28 07:04:18 --> Output Class Initialized
INFO - 2023-03-28 07:04:18 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:18 --> Input Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Loader Class Initialized
INFO - 2023-03-28 07:04:18 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:18 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:18 --> Controller Class Initialized
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:18 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:18 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:18 --> URI Class Initialized
INFO - 2023-03-28 07:04:18 --> Router Class Initialized
INFO - 2023-03-28 07:04:18 --> Output Class Initialized
INFO - 2023-03-28 07:04:18 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:18 --> Input Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Language Class Initialized
INFO - 2023-03-28 07:04:18 --> Config Class Initialized
INFO - 2023-03-28 07:04:18 --> Loader Class Initialized
INFO - 2023-03-28 07:04:18 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:18 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:18 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:18 --> Controller Class Initialized
DEBUG - 2023-03-28 07:04:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:04:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:04:18 --> Final output sent to browser
DEBUG - 2023-03-28 07:04:18 --> Total execution time: 0.0222
INFO - 2023-03-28 07:04:23 --> Config Class Initialized
INFO - 2023-03-28 07:04:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:23 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:23 --> URI Class Initialized
INFO - 2023-03-28 07:04:23 --> Router Class Initialized
INFO - 2023-03-28 07:04:23 --> Output Class Initialized
INFO - 2023-03-28 07:04:23 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:23 --> Input Class Initialized
INFO - 2023-03-28 07:04:23 --> Language Class Initialized
INFO - 2023-03-28 07:04:23 --> Language Class Initialized
INFO - 2023-03-28 07:04:23 --> Config Class Initialized
INFO - 2023-03-28 07:04:23 --> Loader Class Initialized
INFO - 2023-03-28 07:04:23 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:23 --> Controller Class Initialized
INFO - 2023-03-28 07:04:23 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:04:23 --> Final output sent to browser
DEBUG - 2023-03-28 07:04:23 --> Total execution time: 0.0430
INFO - 2023-03-28 07:04:23 --> Config Class Initialized
INFO - 2023-03-28 07:04:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:23 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:23 --> URI Class Initialized
INFO - 2023-03-28 07:04:23 --> Router Class Initialized
INFO - 2023-03-28 07:04:23 --> Output Class Initialized
INFO - 2023-03-28 07:04:23 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:23 --> Input Class Initialized
INFO - 2023-03-28 07:04:23 --> Language Class Initialized
INFO - 2023-03-28 07:04:23 --> Language Class Initialized
INFO - 2023-03-28 07:04:23 --> Config Class Initialized
INFO - 2023-03-28 07:04:23 --> Loader Class Initialized
INFO - 2023-03-28 07:04:23 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:23 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:23 --> Controller Class Initialized
DEBUG - 2023-03-28 07:04:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:04:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:04:23 --> Final output sent to browser
DEBUG - 2023-03-28 07:04:23 --> Total execution time: 0.0489
INFO - 2023-03-28 07:04:25 --> Config Class Initialized
INFO - 2023-03-28 07:04:25 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:04:25 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:04:25 --> Utf8 Class Initialized
INFO - 2023-03-28 07:04:25 --> URI Class Initialized
INFO - 2023-03-28 07:04:25 --> Router Class Initialized
INFO - 2023-03-28 07:04:25 --> Output Class Initialized
INFO - 2023-03-28 07:04:25 --> Security Class Initialized
DEBUG - 2023-03-28 07:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:04:25 --> Input Class Initialized
INFO - 2023-03-28 07:04:25 --> Language Class Initialized
INFO - 2023-03-28 07:04:25 --> Language Class Initialized
INFO - 2023-03-28 07:04:25 --> Config Class Initialized
INFO - 2023-03-28 07:04:25 --> Loader Class Initialized
INFO - 2023-03-28 07:04:25 --> Helper loaded: url_helper
INFO - 2023-03-28 07:04:25 --> Helper loaded: file_helper
INFO - 2023-03-28 07:04:25 --> Helper loaded: form_helper
INFO - 2023-03-28 07:04:25 --> Helper loaded: my_helper
INFO - 2023-03-28 07:04:25 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:04:25 --> Controller Class Initialized
DEBUG - 2023-03-28 07:04:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:04:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:04:25 --> Final output sent to browser
DEBUG - 2023-03-28 07:04:25 --> Total execution time: 0.0373
INFO - 2023-03-28 07:26:29 --> Config Class Initialized
INFO - 2023-03-28 07:26:29 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:29 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:29 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:29 --> URI Class Initialized
INFO - 2023-03-28 07:26:29 --> Router Class Initialized
INFO - 2023-03-28 07:26:29 --> Output Class Initialized
INFO - 2023-03-28 07:26:29 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:29 --> Input Class Initialized
INFO - 2023-03-28 07:26:29 --> Language Class Initialized
INFO - 2023-03-28 07:26:29 --> Language Class Initialized
INFO - 2023-03-28 07:26:29 --> Config Class Initialized
INFO - 2023-03-28 07:26:29 --> Loader Class Initialized
INFO - 2023-03-28 07:26:29 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:29 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:29 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:29 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:29 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:30 --> Controller Class Initialized
INFO - 2023-03-28 07:26:30 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:26:30 --> Config Class Initialized
INFO - 2023-03-28 07:26:30 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:30 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:30 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:30 --> URI Class Initialized
INFO - 2023-03-28 07:26:30 --> Router Class Initialized
INFO - 2023-03-28 07:26:30 --> Output Class Initialized
INFO - 2023-03-28 07:26:30 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:30 --> Input Class Initialized
INFO - 2023-03-28 07:26:30 --> Language Class Initialized
INFO - 2023-03-28 07:26:30 --> Language Class Initialized
INFO - 2023-03-28 07:26:30 --> Config Class Initialized
INFO - 2023-03-28 07:26:30 --> Loader Class Initialized
INFO - 2023-03-28 07:26:30 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:30 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:30 --> Controller Class Initialized
INFO - 2023-03-28 07:26:30 --> Config Class Initialized
INFO - 2023-03-28 07:26:30 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:30 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:30 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:30 --> URI Class Initialized
INFO - 2023-03-28 07:26:30 --> Router Class Initialized
INFO - 2023-03-28 07:26:30 --> Output Class Initialized
INFO - 2023-03-28 07:26:30 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:30 --> Input Class Initialized
INFO - 2023-03-28 07:26:30 --> Language Class Initialized
INFO - 2023-03-28 07:26:30 --> Language Class Initialized
INFO - 2023-03-28 07:26:30 --> Config Class Initialized
INFO - 2023-03-28 07:26:30 --> Loader Class Initialized
INFO - 2023-03-28 07:26:30 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:30 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:30 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:30 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:26:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:30 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:30 --> Total execution time: 0.0853
INFO - 2023-03-28 07:26:35 --> Config Class Initialized
INFO - 2023-03-28 07:26:35 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:35 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:35 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:35 --> URI Class Initialized
INFO - 2023-03-28 07:26:35 --> Router Class Initialized
INFO - 2023-03-28 07:26:35 --> Output Class Initialized
INFO - 2023-03-28 07:26:35 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:35 --> Input Class Initialized
INFO - 2023-03-28 07:26:35 --> Language Class Initialized
INFO - 2023-03-28 07:26:35 --> Language Class Initialized
INFO - 2023-03-28 07:26:35 --> Config Class Initialized
INFO - 2023-03-28 07:26:35 --> Loader Class Initialized
INFO - 2023-03-28 07:26:35 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:35 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:35 --> Controller Class Initialized
INFO - 2023-03-28 07:26:35 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:26:35 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:35 --> Total execution time: 0.0298
INFO - 2023-03-28 07:26:35 --> Config Class Initialized
INFO - 2023-03-28 07:26:35 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:35 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:35 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:35 --> URI Class Initialized
INFO - 2023-03-28 07:26:35 --> Router Class Initialized
INFO - 2023-03-28 07:26:35 --> Output Class Initialized
INFO - 2023-03-28 07:26:35 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:35 --> Input Class Initialized
INFO - 2023-03-28 07:26:35 --> Language Class Initialized
INFO - 2023-03-28 07:26:35 --> Language Class Initialized
INFO - 2023-03-28 07:26:35 --> Config Class Initialized
INFO - 2023-03-28 07:26:35 --> Loader Class Initialized
INFO - 2023-03-28 07:26:35 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:35 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:35 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:35 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:26:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:35 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:35 --> Total execution time: 0.0673
INFO - 2023-03-28 07:26:38 --> Config Class Initialized
INFO - 2023-03-28 07:26:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:38 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:38 --> URI Class Initialized
INFO - 2023-03-28 07:26:38 --> Router Class Initialized
INFO - 2023-03-28 07:26:38 --> Output Class Initialized
INFO - 2023-03-28 07:26:38 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:38 --> Input Class Initialized
INFO - 2023-03-28 07:26:38 --> Language Class Initialized
INFO - 2023-03-28 07:26:38 --> Language Class Initialized
INFO - 2023-03-28 07:26:38 --> Config Class Initialized
INFO - 2023-03-28 07:26:38 --> Loader Class Initialized
INFO - 2023-03-28 07:26:38 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:38 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:38 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:38 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:38 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:26:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:38 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:38 --> Total execution time: 0.0722
INFO - 2023-03-28 07:26:43 --> Config Class Initialized
INFO - 2023-03-28 07:26:43 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:43 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:43 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:43 --> URI Class Initialized
INFO - 2023-03-28 07:26:43 --> Router Class Initialized
INFO - 2023-03-28 07:26:43 --> Output Class Initialized
INFO - 2023-03-28 07:26:43 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:43 --> Input Class Initialized
INFO - 2023-03-28 07:26:43 --> Language Class Initialized
INFO - 2023-03-28 07:26:43 --> Language Class Initialized
INFO - 2023-03-28 07:26:43 --> Config Class Initialized
INFO - 2023-03-28 07:26:43 --> Loader Class Initialized
INFO - 2023-03-28 07:26:43 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:43 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:43 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:43 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:43 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:43 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:26:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:43 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:43 --> Total execution time: 0.0710
INFO - 2023-03-28 07:26:44 --> Config Class Initialized
INFO - 2023-03-28 07:26:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:44 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:44 --> URI Class Initialized
INFO - 2023-03-28 07:26:44 --> Router Class Initialized
INFO - 2023-03-28 07:26:44 --> Output Class Initialized
INFO - 2023-03-28 07:26:44 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:44 --> Input Class Initialized
INFO - 2023-03-28 07:26:44 --> Language Class Initialized
INFO - 2023-03-28 07:26:44 --> Language Class Initialized
INFO - 2023-03-28 07:26:44 --> Config Class Initialized
INFO - 2023-03-28 07:26:44 --> Loader Class Initialized
INFO - 2023-03-28 07:26:44 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:44 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:44 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:44 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:44 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-03-28 07:26:44 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:44 --> Total execution time: 0.0459
INFO - 2023-03-28 07:26:47 --> Config Class Initialized
INFO - 2023-03-28 07:26:47 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:47 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:47 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:47 --> URI Class Initialized
INFO - 2023-03-28 07:26:47 --> Router Class Initialized
INFO - 2023-03-28 07:26:47 --> Output Class Initialized
INFO - 2023-03-28 07:26:47 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:47 --> Input Class Initialized
INFO - 2023-03-28 07:26:47 --> Language Class Initialized
INFO - 2023-03-28 07:26:47 --> Language Class Initialized
INFO - 2023-03-28 07:26:47 --> Config Class Initialized
INFO - 2023-03-28 07:26:47 --> Loader Class Initialized
INFO - 2023-03-28 07:26:47 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:47 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:47 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:47 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:47 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:47 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:47 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:47 --> Total execution time: 0.0362
INFO - 2023-03-28 07:26:52 --> Config Class Initialized
INFO - 2023-03-28 07:26:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:26:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:26:52 --> Utf8 Class Initialized
INFO - 2023-03-28 07:26:52 --> URI Class Initialized
INFO - 2023-03-28 07:26:52 --> Router Class Initialized
INFO - 2023-03-28 07:26:52 --> Output Class Initialized
INFO - 2023-03-28 07:26:52 --> Security Class Initialized
DEBUG - 2023-03-28 07:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:26:52 --> Input Class Initialized
INFO - 2023-03-28 07:26:52 --> Language Class Initialized
INFO - 2023-03-28 07:26:52 --> Language Class Initialized
INFO - 2023-03-28 07:26:52 --> Config Class Initialized
INFO - 2023-03-28 07:26:52 --> Loader Class Initialized
INFO - 2023-03-28 07:26:52 --> Helper loaded: url_helper
INFO - 2023-03-28 07:26:52 --> Helper loaded: file_helper
INFO - 2023-03-28 07:26:52 --> Helper loaded: form_helper
INFO - 2023-03-28 07:26:52 --> Helper loaded: my_helper
INFO - 2023-03-28 07:26:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:26:52 --> Controller Class Initialized
DEBUG - 2023-03-28 07:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:26:52 --> Final output sent to browser
DEBUG - 2023-03-28 07:26:52 --> Total execution time: 0.0270
INFO - 2023-03-28 07:27:42 --> Config Class Initialized
INFO - 2023-03-28 07:27:42 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:27:42 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:27:42 --> Utf8 Class Initialized
INFO - 2023-03-28 07:27:42 --> URI Class Initialized
INFO - 2023-03-28 07:27:42 --> Router Class Initialized
INFO - 2023-03-28 07:27:42 --> Output Class Initialized
INFO - 2023-03-28 07:27:42 --> Security Class Initialized
DEBUG - 2023-03-28 07:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:27:42 --> Input Class Initialized
INFO - 2023-03-28 07:27:42 --> Language Class Initialized
INFO - 2023-03-28 07:27:42 --> Language Class Initialized
INFO - 2023-03-28 07:27:42 --> Config Class Initialized
INFO - 2023-03-28 07:27:42 --> Loader Class Initialized
INFO - 2023-03-28 07:27:42 --> Helper loaded: url_helper
INFO - 2023-03-28 07:27:42 --> Helper loaded: file_helper
INFO - 2023-03-28 07:27:42 --> Helper loaded: form_helper
INFO - 2023-03-28 07:27:42 --> Helper loaded: my_helper
INFO - 2023-03-28 07:27:42 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:27:42 --> Controller Class Initialized
DEBUG - 2023-03-28 07:27:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:27:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:27:42 --> Final output sent to browser
DEBUG - 2023-03-28 07:27:42 --> Total execution time: 0.0307
INFO - 2023-03-28 07:27:47 --> Config Class Initialized
INFO - 2023-03-28 07:27:47 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:27:47 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:27:47 --> Utf8 Class Initialized
INFO - 2023-03-28 07:27:47 --> URI Class Initialized
INFO - 2023-03-28 07:27:47 --> Router Class Initialized
INFO - 2023-03-28 07:27:47 --> Output Class Initialized
INFO - 2023-03-28 07:27:47 --> Security Class Initialized
DEBUG - 2023-03-28 07:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:27:47 --> Input Class Initialized
INFO - 2023-03-28 07:27:47 --> Language Class Initialized
INFO - 2023-03-28 07:27:47 --> Language Class Initialized
INFO - 2023-03-28 07:27:47 --> Config Class Initialized
INFO - 2023-03-28 07:27:47 --> Loader Class Initialized
INFO - 2023-03-28 07:27:47 --> Helper loaded: url_helper
INFO - 2023-03-28 07:27:47 --> Helper loaded: file_helper
INFO - 2023-03-28 07:27:47 --> Helper loaded: form_helper
INFO - 2023-03-28 07:27:47 --> Helper loaded: my_helper
INFO - 2023-03-28 07:27:47 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:27:47 --> Controller Class Initialized
DEBUG - 2023-03-28 07:27:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:27:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:27:47 --> Final output sent to browser
DEBUG - 2023-03-28 07:27:47 --> Total execution time: 0.0500
INFO - 2023-03-28 07:28:05 --> Config Class Initialized
INFO - 2023-03-28 07:28:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:28:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:28:05 --> Utf8 Class Initialized
INFO - 2023-03-28 07:28:05 --> URI Class Initialized
INFO - 2023-03-28 07:28:05 --> Router Class Initialized
INFO - 2023-03-28 07:28:05 --> Output Class Initialized
INFO - 2023-03-28 07:28:05 --> Security Class Initialized
DEBUG - 2023-03-28 07:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:28:05 --> Input Class Initialized
INFO - 2023-03-28 07:28:05 --> Language Class Initialized
INFO - 2023-03-28 07:28:05 --> Language Class Initialized
INFO - 2023-03-28 07:28:05 --> Config Class Initialized
INFO - 2023-03-28 07:28:05 --> Loader Class Initialized
INFO - 2023-03-28 07:28:05 --> Helper loaded: url_helper
INFO - 2023-03-28 07:28:05 --> Helper loaded: file_helper
INFO - 2023-03-28 07:28:05 --> Helper loaded: form_helper
INFO - 2023-03-28 07:28:05 --> Helper loaded: my_helper
INFO - 2023-03-28 07:28:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:28:05 --> Controller Class Initialized
DEBUG - 2023-03-28 07:28:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:28:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:28:05 --> Final output sent to browser
DEBUG - 2023-03-28 07:28:05 --> Total execution time: 0.0294
INFO - 2023-03-28 07:28:07 --> Config Class Initialized
INFO - 2023-03-28 07:28:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:28:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:28:07 --> Utf8 Class Initialized
INFO - 2023-03-28 07:28:07 --> URI Class Initialized
INFO - 2023-03-28 07:28:07 --> Router Class Initialized
INFO - 2023-03-28 07:28:07 --> Output Class Initialized
INFO - 2023-03-28 07:28:07 --> Security Class Initialized
DEBUG - 2023-03-28 07:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:28:07 --> Input Class Initialized
INFO - 2023-03-28 07:28:07 --> Language Class Initialized
INFO - 2023-03-28 07:28:07 --> Language Class Initialized
INFO - 2023-03-28 07:28:07 --> Config Class Initialized
INFO - 2023-03-28 07:28:07 --> Loader Class Initialized
INFO - 2023-03-28 07:28:07 --> Helper loaded: url_helper
INFO - 2023-03-28 07:28:07 --> Helper loaded: file_helper
INFO - 2023-03-28 07:28:07 --> Helper loaded: form_helper
INFO - 2023-03-28 07:28:07 --> Helper loaded: my_helper
INFO - 2023-03-28 07:28:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:28:07 --> Controller Class Initialized
DEBUG - 2023-03-28 07:28:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:28:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:28:07 --> Final output sent to browser
DEBUG - 2023-03-28 07:28:07 --> Total execution time: 0.0272
INFO - 2023-03-28 07:29:10 --> Config Class Initialized
INFO - 2023-03-28 07:29:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:29:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:29:10 --> Utf8 Class Initialized
INFO - 2023-03-28 07:29:10 --> URI Class Initialized
INFO - 2023-03-28 07:29:10 --> Router Class Initialized
INFO - 2023-03-28 07:29:10 --> Output Class Initialized
INFO - 2023-03-28 07:29:10 --> Security Class Initialized
DEBUG - 2023-03-28 07:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:29:10 --> Input Class Initialized
INFO - 2023-03-28 07:29:10 --> Language Class Initialized
INFO - 2023-03-28 07:29:10 --> Language Class Initialized
INFO - 2023-03-28 07:29:10 --> Config Class Initialized
INFO - 2023-03-28 07:29:10 --> Loader Class Initialized
INFO - 2023-03-28 07:29:10 --> Helper loaded: url_helper
INFO - 2023-03-28 07:29:10 --> Helper loaded: file_helper
INFO - 2023-03-28 07:29:10 --> Helper loaded: form_helper
INFO - 2023-03-28 07:29:10 --> Helper loaded: my_helper
INFO - 2023-03-28 07:29:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:29:10 --> Controller Class Initialized
DEBUG - 2023-03-28 07:29:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:29:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:29:10 --> Final output sent to browser
DEBUG - 2023-03-28 07:29:10 --> Total execution time: 0.0459
INFO - 2023-03-28 07:30:37 --> Config Class Initialized
INFO - 2023-03-28 07:30:37 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:30:37 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:30:37 --> Utf8 Class Initialized
INFO - 2023-03-28 07:30:37 --> URI Class Initialized
INFO - 2023-03-28 07:30:37 --> Router Class Initialized
INFO - 2023-03-28 07:30:37 --> Output Class Initialized
INFO - 2023-03-28 07:30:37 --> Security Class Initialized
DEBUG - 2023-03-28 07:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:30:37 --> Input Class Initialized
INFO - 2023-03-28 07:30:37 --> Language Class Initialized
INFO - 2023-03-28 07:30:37 --> Language Class Initialized
INFO - 2023-03-28 07:30:37 --> Config Class Initialized
INFO - 2023-03-28 07:30:37 --> Loader Class Initialized
INFO - 2023-03-28 07:30:37 --> Helper loaded: url_helper
INFO - 2023-03-28 07:30:37 --> Helper loaded: file_helper
INFO - 2023-03-28 07:30:37 --> Helper loaded: form_helper
INFO - 2023-03-28 07:30:37 --> Helper loaded: my_helper
INFO - 2023-03-28 07:30:37 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:30:37 --> Controller Class Initialized
DEBUG - 2023-03-28 07:30:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:30:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:30:37 --> Final output sent to browser
DEBUG - 2023-03-28 07:30:37 --> Total execution time: 0.0479
INFO - 2023-03-28 07:35:26 --> Config Class Initialized
INFO - 2023-03-28 07:35:26 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:35:26 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:35:26 --> Utf8 Class Initialized
INFO - 2023-03-28 07:35:26 --> URI Class Initialized
INFO - 2023-03-28 07:35:26 --> Router Class Initialized
INFO - 2023-03-28 07:35:26 --> Output Class Initialized
INFO - 2023-03-28 07:35:26 --> Security Class Initialized
DEBUG - 2023-03-28 07:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:35:26 --> Input Class Initialized
INFO - 2023-03-28 07:35:26 --> Language Class Initialized
INFO - 2023-03-28 07:35:26 --> Language Class Initialized
INFO - 2023-03-28 07:35:26 --> Config Class Initialized
INFO - 2023-03-28 07:35:26 --> Loader Class Initialized
INFO - 2023-03-28 07:35:26 --> Helper loaded: url_helper
INFO - 2023-03-28 07:35:26 --> Helper loaded: file_helper
INFO - 2023-03-28 07:35:26 --> Helper loaded: form_helper
INFO - 2023-03-28 07:35:26 --> Helper loaded: my_helper
INFO - 2023-03-28 07:35:26 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:35:26 --> Controller Class Initialized
DEBUG - 2023-03-28 07:35:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:35:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:35:26 --> Final output sent to browser
DEBUG - 2023-03-28 07:35:26 --> Total execution time: 0.0517
INFO - 2023-03-28 07:35:32 --> Config Class Initialized
INFO - 2023-03-28 07:35:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:35:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:35:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:35:32 --> URI Class Initialized
INFO - 2023-03-28 07:35:32 --> Router Class Initialized
INFO - 2023-03-28 07:35:32 --> Output Class Initialized
INFO - 2023-03-28 07:35:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:35:32 --> Input Class Initialized
INFO - 2023-03-28 07:35:32 --> Language Class Initialized
INFO - 2023-03-28 07:35:32 --> Language Class Initialized
INFO - 2023-03-28 07:35:32 --> Config Class Initialized
INFO - 2023-03-28 07:35:32 --> Loader Class Initialized
INFO - 2023-03-28 07:35:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:35:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:35:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:35:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:35:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:35:32 --> Controller Class Initialized
DEBUG - 2023-03-28 07:35:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:35:34 --> Final output sent to browser
DEBUG - 2023-03-28 07:35:34 --> Total execution time: 1.9932
INFO - 2023-03-28 07:36:07 --> Config Class Initialized
INFO - 2023-03-28 07:36:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:07 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:07 --> URI Class Initialized
INFO - 2023-03-28 07:36:07 --> Router Class Initialized
INFO - 2023-03-28 07:36:07 --> Output Class Initialized
INFO - 2023-03-28 07:36:07 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:07 --> Input Class Initialized
INFO - 2023-03-28 07:36:07 --> Language Class Initialized
INFO - 2023-03-28 07:36:07 --> Language Class Initialized
INFO - 2023-03-28 07:36:07 --> Config Class Initialized
INFO - 2023-03-28 07:36:07 --> Loader Class Initialized
INFO - 2023-03-28 07:36:07 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:07 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:07 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:07 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:07 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:36:08 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:08 --> Total execution time: 1.1583
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:32 --> URI Class Initialized
INFO - 2023-03-28 07:36:32 --> Router Class Initialized
INFO - 2023-03-28 07:36:32 --> Output Class Initialized
INFO - 2023-03-28 07:36:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:32 --> Input Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Loader Class Initialized
INFO - 2023-03-28 07:36:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:32 --> Controller Class Initialized
INFO - 2023-03-28 07:36:32 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:32 --> URI Class Initialized
INFO - 2023-03-28 07:36:32 --> Router Class Initialized
INFO - 2023-03-28 07:36:32 --> Output Class Initialized
INFO - 2023-03-28 07:36:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:32 --> Input Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Loader Class Initialized
INFO - 2023-03-28 07:36:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:32 --> Controller Class Initialized
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:32 --> URI Class Initialized
INFO - 2023-03-28 07:36:32 --> Router Class Initialized
INFO - 2023-03-28 07:36:32 --> Output Class Initialized
INFO - 2023-03-28 07:36:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:32 --> Input Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Language Class Initialized
INFO - 2023-03-28 07:36:32 --> Config Class Initialized
INFO - 2023-03-28 07:36:32 --> Loader Class Initialized
INFO - 2023-03-28 07:36:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:32 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:36:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:32 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:32 --> Total execution time: 0.0242
INFO - 2023-03-28 07:36:39 --> Config Class Initialized
INFO - 2023-03-28 07:36:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:39 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:39 --> URI Class Initialized
INFO - 2023-03-28 07:36:39 --> Router Class Initialized
INFO - 2023-03-28 07:36:39 --> Output Class Initialized
INFO - 2023-03-28 07:36:39 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:39 --> Input Class Initialized
INFO - 2023-03-28 07:36:39 --> Language Class Initialized
INFO - 2023-03-28 07:36:39 --> Language Class Initialized
INFO - 2023-03-28 07:36:39 --> Config Class Initialized
INFO - 2023-03-28 07:36:39 --> Loader Class Initialized
INFO - 2023-03-28 07:36:39 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:39 --> Controller Class Initialized
INFO - 2023-03-28 07:36:39 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:36:39 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:39 --> Total execution time: 0.0445
INFO - 2023-03-28 07:36:39 --> Config Class Initialized
INFO - 2023-03-28 07:36:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:39 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:39 --> URI Class Initialized
INFO - 2023-03-28 07:36:39 --> Router Class Initialized
INFO - 2023-03-28 07:36:39 --> Output Class Initialized
INFO - 2023-03-28 07:36:39 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:39 --> Input Class Initialized
INFO - 2023-03-28 07:36:39 --> Language Class Initialized
INFO - 2023-03-28 07:36:39 --> Language Class Initialized
INFO - 2023-03-28 07:36:39 --> Config Class Initialized
INFO - 2023-03-28 07:36:39 --> Loader Class Initialized
INFO - 2023-03-28 07:36:39 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:39 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:39 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:36:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:39 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:39 --> Total execution time: 0.0489
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:48 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:48 --> URI Class Initialized
INFO - 2023-03-28 07:36:48 --> Router Class Initialized
INFO - 2023-03-28 07:36:48 --> Output Class Initialized
INFO - 2023-03-28 07:36:48 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:48 --> Input Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Loader Class Initialized
INFO - 2023-03-28 07:36:48 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:48 --> Controller Class Initialized
INFO - 2023-03-28 07:36:48 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:48 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:48 --> URI Class Initialized
INFO - 2023-03-28 07:36:48 --> Router Class Initialized
INFO - 2023-03-28 07:36:48 --> Output Class Initialized
INFO - 2023-03-28 07:36:48 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:48 --> Input Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Loader Class Initialized
INFO - 2023-03-28 07:36:48 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:48 --> Controller Class Initialized
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:48 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:48 --> URI Class Initialized
INFO - 2023-03-28 07:36:48 --> Router Class Initialized
INFO - 2023-03-28 07:36:48 --> Output Class Initialized
INFO - 2023-03-28 07:36:48 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:48 --> Input Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Language Class Initialized
INFO - 2023-03-28 07:36:48 --> Config Class Initialized
INFO - 2023-03-28 07:36:48 --> Loader Class Initialized
INFO - 2023-03-28 07:36:48 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:48 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:48 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:36:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:48 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:48 --> Total execution time: 0.0234
INFO - 2023-03-28 07:36:52 --> Config Class Initialized
INFO - 2023-03-28 07:36:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:52 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:52 --> URI Class Initialized
INFO - 2023-03-28 07:36:52 --> Router Class Initialized
INFO - 2023-03-28 07:36:52 --> Output Class Initialized
INFO - 2023-03-28 07:36:52 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:52 --> Input Class Initialized
INFO - 2023-03-28 07:36:52 --> Language Class Initialized
INFO - 2023-03-28 07:36:52 --> Language Class Initialized
INFO - 2023-03-28 07:36:52 --> Config Class Initialized
INFO - 2023-03-28 07:36:52 --> Loader Class Initialized
INFO - 2023-03-28 07:36:52 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:52 --> Controller Class Initialized
INFO - 2023-03-28 07:36:52 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:36:52 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:52 --> Total execution time: 0.0274
INFO - 2023-03-28 07:36:52 --> Config Class Initialized
INFO - 2023-03-28 07:36:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:52 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:52 --> URI Class Initialized
INFO - 2023-03-28 07:36:52 --> Router Class Initialized
INFO - 2023-03-28 07:36:52 --> Output Class Initialized
INFO - 2023-03-28 07:36:52 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:52 --> Input Class Initialized
INFO - 2023-03-28 07:36:52 --> Language Class Initialized
INFO - 2023-03-28 07:36:52 --> Language Class Initialized
INFO - 2023-03-28 07:36:52 --> Config Class Initialized
INFO - 2023-03-28 07:36:52 --> Loader Class Initialized
INFO - 2023-03-28 07:36:52 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:52 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:52 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:36:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:52 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:52 --> Total execution time: 0.0299
INFO - 2023-03-28 07:36:54 --> Config Class Initialized
INFO - 2023-03-28 07:36:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:54 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:54 --> URI Class Initialized
DEBUG - 2023-03-28 07:36:54 --> No URI present. Default controller set.
INFO - 2023-03-28 07:36:54 --> Router Class Initialized
INFO - 2023-03-28 07:36:54 --> Output Class Initialized
INFO - 2023-03-28 07:36:54 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:54 --> Input Class Initialized
INFO - 2023-03-28 07:36:54 --> Language Class Initialized
INFO - 2023-03-28 07:36:54 --> Language Class Initialized
INFO - 2023-03-28 07:36:54 --> Config Class Initialized
INFO - 2023-03-28 07:36:54 --> Loader Class Initialized
INFO - 2023-03-28 07:36:54 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:54 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:54 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:54 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:54 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:36:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:54 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:54 --> Total execution time: 0.0438
INFO - 2023-03-28 07:36:55 --> Config Class Initialized
INFO - 2023-03-28 07:36:55 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:55 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:55 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:55 --> URI Class Initialized
INFO - 2023-03-28 07:36:55 --> Router Class Initialized
INFO - 2023-03-28 07:36:55 --> Output Class Initialized
INFO - 2023-03-28 07:36:55 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:55 --> Input Class Initialized
INFO - 2023-03-28 07:36:55 --> Language Class Initialized
INFO - 2023-03-28 07:36:55 --> Language Class Initialized
INFO - 2023-03-28 07:36:55 --> Config Class Initialized
INFO - 2023-03-28 07:36:55 --> Loader Class Initialized
INFO - 2023-03-28 07:36:55 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:55 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:55 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:55 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:55 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:55 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:36:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:55 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:55 --> Total execution time: 0.0905
INFO - 2023-03-28 07:36:57 --> Config Class Initialized
INFO - 2023-03-28 07:36:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:57 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:57 --> URI Class Initialized
INFO - 2023-03-28 07:36:57 --> Router Class Initialized
INFO - 2023-03-28 07:36:57 --> Output Class Initialized
INFO - 2023-03-28 07:36:57 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:57 --> Input Class Initialized
INFO - 2023-03-28 07:36:57 --> Language Class Initialized
INFO - 2023-03-28 07:36:57 --> Language Class Initialized
INFO - 2023-03-28 07:36:57 --> Config Class Initialized
INFO - 2023-03-28 07:36:57 --> Loader Class Initialized
INFO - 2023-03-28 07:36:57 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:57 --> Controller Class Initialized
DEBUG - 2023-03-28 07:36:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-03-28 07:36:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:36:57 --> Final output sent to browser
DEBUG - 2023-03-28 07:36:57 --> Total execution time: 0.0857
INFO - 2023-03-28 07:36:57 --> Config Class Initialized
INFO - 2023-03-28 07:36:57 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:36:57 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:36:57 --> Utf8 Class Initialized
INFO - 2023-03-28 07:36:57 --> URI Class Initialized
INFO - 2023-03-28 07:36:57 --> Router Class Initialized
INFO - 2023-03-28 07:36:57 --> Output Class Initialized
INFO - 2023-03-28 07:36:57 --> Security Class Initialized
DEBUG - 2023-03-28 07:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:36:57 --> Input Class Initialized
INFO - 2023-03-28 07:36:57 --> Language Class Initialized
INFO - 2023-03-28 07:36:57 --> Language Class Initialized
INFO - 2023-03-28 07:36:57 --> Config Class Initialized
INFO - 2023-03-28 07:36:57 --> Loader Class Initialized
INFO - 2023-03-28 07:36:57 --> Helper loaded: url_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: file_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: form_helper
INFO - 2023-03-28 07:36:57 --> Helper loaded: my_helper
INFO - 2023-03-28 07:36:57 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:36:57 --> Controller Class Initialized
INFO - 2023-03-28 07:37:08 --> Config Class Initialized
INFO - 2023-03-28 07:37:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:37:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:37:08 --> Utf8 Class Initialized
INFO - 2023-03-28 07:37:08 --> URI Class Initialized
INFO - 2023-03-28 07:37:08 --> Router Class Initialized
INFO - 2023-03-28 07:37:08 --> Output Class Initialized
INFO - 2023-03-28 07:37:08 --> Security Class Initialized
DEBUG - 2023-03-28 07:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:37:08 --> Input Class Initialized
INFO - 2023-03-28 07:37:08 --> Language Class Initialized
INFO - 2023-03-28 07:37:08 --> Language Class Initialized
INFO - 2023-03-28 07:37:08 --> Config Class Initialized
INFO - 2023-03-28 07:37:08 --> Loader Class Initialized
INFO - 2023-03-28 07:37:08 --> Helper loaded: url_helper
INFO - 2023-03-28 07:37:08 --> Helper loaded: file_helper
INFO - 2023-03-28 07:37:08 --> Helper loaded: form_helper
INFO - 2023-03-28 07:37:08 --> Helper loaded: my_helper
INFO - 2023-03-28 07:37:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:37:08 --> Controller Class Initialized
INFO - 2023-03-28 07:37:08 --> Final output sent to browser
DEBUG - 2023-03-28 07:37:08 --> Total execution time: 0.0438
INFO - 2023-03-28 07:37:12 --> Config Class Initialized
INFO - 2023-03-28 07:37:12 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:37:12 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:37:12 --> Utf8 Class Initialized
INFO - 2023-03-28 07:37:12 --> URI Class Initialized
INFO - 2023-03-28 07:37:12 --> Router Class Initialized
INFO - 2023-03-28 07:37:12 --> Output Class Initialized
INFO - 2023-03-28 07:37:12 --> Security Class Initialized
DEBUG - 2023-03-28 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:37:12 --> Input Class Initialized
INFO - 2023-03-28 07:37:12 --> Language Class Initialized
INFO - 2023-03-28 07:37:12 --> Language Class Initialized
INFO - 2023-03-28 07:37:12 --> Config Class Initialized
INFO - 2023-03-28 07:37:12 --> Loader Class Initialized
INFO - 2023-03-28 07:37:12 --> Helper loaded: url_helper
INFO - 2023-03-28 07:37:12 --> Helper loaded: file_helper
INFO - 2023-03-28 07:37:12 --> Helper loaded: form_helper
INFO - 2023-03-28 07:37:12 --> Helper loaded: my_helper
INFO - 2023-03-28 07:37:12 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:37:12 --> Controller Class Initialized
INFO - 2023-03-28 07:37:12 --> Final output sent to browser
DEBUG - 2023-03-28 07:37:12 --> Total execution time: 0.0493
INFO - 2023-03-28 07:37:23 --> Config Class Initialized
INFO - 2023-03-28 07:37:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:37:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:37:23 --> Utf8 Class Initialized
INFO - 2023-03-28 07:37:23 --> URI Class Initialized
INFO - 2023-03-28 07:37:23 --> Router Class Initialized
INFO - 2023-03-28 07:37:23 --> Output Class Initialized
INFO - 2023-03-28 07:37:23 --> Security Class Initialized
DEBUG - 2023-03-28 07:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:37:23 --> Input Class Initialized
INFO - 2023-03-28 07:37:23 --> Language Class Initialized
INFO - 2023-03-28 07:37:23 --> Language Class Initialized
INFO - 2023-03-28 07:37:23 --> Config Class Initialized
INFO - 2023-03-28 07:37:23 --> Loader Class Initialized
INFO - 2023-03-28 07:37:23 --> Helper loaded: url_helper
INFO - 2023-03-28 07:37:23 --> Helper loaded: file_helper
INFO - 2023-03-28 07:37:23 --> Helper loaded: form_helper
INFO - 2023-03-28 07:37:23 --> Helper loaded: my_helper
INFO - 2023-03-28 07:37:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:37:23 --> Controller Class Initialized
DEBUG - 2023-03-28 07:37:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:37:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:37:23 --> Final output sent to browser
DEBUG - 2023-03-28 07:37:23 --> Total execution time: 0.0448
INFO - 2023-03-28 07:37:27 --> Config Class Initialized
INFO - 2023-03-28 07:37:27 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:37:27 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:37:27 --> Utf8 Class Initialized
INFO - 2023-03-28 07:37:27 --> URI Class Initialized
INFO - 2023-03-28 07:37:27 --> Router Class Initialized
INFO - 2023-03-28 07:37:27 --> Output Class Initialized
INFO - 2023-03-28 07:37:27 --> Security Class Initialized
DEBUG - 2023-03-28 07:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:37:27 --> Input Class Initialized
INFO - 2023-03-28 07:37:27 --> Language Class Initialized
INFO - 2023-03-28 07:37:27 --> Language Class Initialized
INFO - 2023-03-28 07:37:27 --> Config Class Initialized
INFO - 2023-03-28 07:37:27 --> Loader Class Initialized
INFO - 2023-03-28 07:37:27 --> Helper loaded: url_helper
INFO - 2023-03-28 07:37:27 --> Helper loaded: file_helper
INFO - 2023-03-28 07:37:27 --> Helper loaded: form_helper
INFO - 2023-03-28 07:37:27 --> Helper loaded: my_helper
INFO - 2023-03-28 07:37:27 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:37:27 --> Controller Class Initialized
DEBUG - 2023-03-28 07:37:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-03-28 07:37:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:37:27 --> Final output sent to browser
DEBUG - 2023-03-28 07:37:27 --> Total execution time: 0.0858
INFO - 2023-03-28 07:37:28 --> Config Class Initialized
INFO - 2023-03-28 07:37:28 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:37:28 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:37:28 --> Utf8 Class Initialized
INFO - 2023-03-28 07:37:28 --> URI Class Initialized
INFO - 2023-03-28 07:37:28 --> Router Class Initialized
INFO - 2023-03-28 07:37:28 --> Output Class Initialized
INFO - 2023-03-28 07:37:28 --> Security Class Initialized
DEBUG - 2023-03-28 07:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:37:28 --> Input Class Initialized
INFO - 2023-03-28 07:37:28 --> Language Class Initialized
INFO - 2023-03-28 07:37:28 --> Language Class Initialized
INFO - 2023-03-28 07:37:28 --> Config Class Initialized
INFO - 2023-03-28 07:37:28 --> Loader Class Initialized
INFO - 2023-03-28 07:37:28 --> Helper loaded: url_helper
INFO - 2023-03-28 07:37:28 --> Helper loaded: file_helper
INFO - 2023-03-28 07:37:28 --> Helper loaded: form_helper
INFO - 2023-03-28 07:37:28 --> Helper loaded: my_helper
INFO - 2023-03-28 07:37:28 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:37:28 --> Controller Class Initialized
INFO - 2023-03-28 07:37:28 --> Final output sent to browser
DEBUG - 2023-03-28 07:37:28 --> Total execution time: 0.0486
INFO - 2023-03-28 07:39:00 --> Config Class Initialized
INFO - 2023-03-28 07:39:00 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:00 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:00 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:00 --> URI Class Initialized
INFO - 2023-03-28 07:39:00 --> Router Class Initialized
INFO - 2023-03-28 07:39:00 --> Output Class Initialized
INFO - 2023-03-28 07:39:00 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:00 --> Input Class Initialized
INFO - 2023-03-28 07:39:00 --> Language Class Initialized
INFO - 2023-03-28 07:39:00 --> Language Class Initialized
INFO - 2023-03-28 07:39:00 --> Config Class Initialized
INFO - 2023-03-28 07:39:00 --> Loader Class Initialized
INFO - 2023-03-28 07:39:00 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:00 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:00 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:00 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:00 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:00 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:39:01 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:01 --> Total execution time: 1.1831
INFO - 2023-03-28 07:39:06 --> Config Class Initialized
INFO - 2023-03-28 07:39:06 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:06 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:06 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:06 --> URI Class Initialized
INFO - 2023-03-28 07:39:06 --> Router Class Initialized
INFO - 2023-03-28 07:39:06 --> Output Class Initialized
INFO - 2023-03-28 07:39:06 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:06 --> Input Class Initialized
INFO - 2023-03-28 07:39:06 --> Language Class Initialized
INFO - 2023-03-28 07:39:06 --> Language Class Initialized
INFO - 2023-03-28 07:39:06 --> Config Class Initialized
INFO - 2023-03-28 07:39:06 --> Loader Class Initialized
INFO - 2023-03-28 07:39:06 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:06 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:06 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:06 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:06 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:06 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:39:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:06 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:06 --> Total execution time: 0.0317
INFO - 2023-03-28 07:39:07 --> Config Class Initialized
INFO - 2023-03-28 07:39:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:07 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:07 --> URI Class Initialized
INFO - 2023-03-28 07:39:07 --> Router Class Initialized
INFO - 2023-03-28 07:39:07 --> Output Class Initialized
INFO - 2023-03-28 07:39:07 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:07 --> Input Class Initialized
INFO - 2023-03-28 07:39:07 --> Language Class Initialized
INFO - 2023-03-28 07:39:07 --> Language Class Initialized
INFO - 2023-03-28 07:39:07 --> Config Class Initialized
INFO - 2023-03-28 07:39:07 --> Loader Class Initialized
INFO - 2023-03-28 07:39:07 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:07 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:07 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:07 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:07 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-03-28 07:39:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:08 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:08 --> Total execution time: 0.0460
INFO - 2023-03-28 07:39:09 --> Config Class Initialized
INFO - 2023-03-28 07:39:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:09 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:09 --> URI Class Initialized
INFO - 2023-03-28 07:39:09 --> Router Class Initialized
INFO - 2023-03-28 07:39:09 --> Output Class Initialized
INFO - 2023-03-28 07:39:09 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:09 --> Input Class Initialized
INFO - 2023-03-28 07:39:09 --> Language Class Initialized
INFO - 2023-03-28 07:39:09 --> Language Class Initialized
INFO - 2023-03-28 07:39:09 --> Config Class Initialized
INFO - 2023-03-28 07:39:09 --> Loader Class Initialized
INFO - 2023-03-28 07:39:09 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:09 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:09 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:09 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:09 --> Controller Class Initialized
INFO - 2023-03-28 07:39:09 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:09 --> Total execution time: 0.0237
INFO - 2023-03-28 07:39:10 --> Config Class Initialized
INFO - 2023-03-28 07:39:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:10 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:10 --> URI Class Initialized
INFO - 2023-03-28 07:39:10 --> Router Class Initialized
INFO - 2023-03-28 07:39:10 --> Output Class Initialized
INFO - 2023-03-28 07:39:10 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:10 --> Input Class Initialized
INFO - 2023-03-28 07:39:10 --> Language Class Initialized
INFO - 2023-03-28 07:39:10 --> Language Class Initialized
INFO - 2023-03-28 07:39:10 --> Config Class Initialized
INFO - 2023-03-28 07:39:10 --> Loader Class Initialized
INFO - 2023-03-28 07:39:10 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:10 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:10 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:10 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:10 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:39:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:10 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:10 --> Total execution time: 0.0304
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:11 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:11 --> URI Class Initialized
INFO - 2023-03-28 07:39:11 --> Router Class Initialized
INFO - 2023-03-28 07:39:11 --> Output Class Initialized
INFO - 2023-03-28 07:39:11 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:11 --> Input Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Loader Class Initialized
INFO - 2023-03-28 07:39:11 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:11 --> Controller Class Initialized
INFO - 2023-03-28 07:39:11 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:11 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:11 --> URI Class Initialized
INFO - 2023-03-28 07:39:11 --> Router Class Initialized
INFO - 2023-03-28 07:39:11 --> Output Class Initialized
INFO - 2023-03-28 07:39:11 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:11 --> Input Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Loader Class Initialized
INFO - 2023-03-28 07:39:11 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:11 --> Controller Class Initialized
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:11 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:11 --> URI Class Initialized
INFO - 2023-03-28 07:39:11 --> Router Class Initialized
INFO - 2023-03-28 07:39:11 --> Output Class Initialized
INFO - 2023-03-28 07:39:11 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:11 --> Input Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Language Class Initialized
INFO - 2023-03-28 07:39:11 --> Config Class Initialized
INFO - 2023-03-28 07:39:11 --> Loader Class Initialized
INFO - 2023-03-28 07:39:11 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:11 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:11 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 07:39:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:11 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:11 --> Total execution time: 0.0426
INFO - 2023-03-28 07:39:17 --> Config Class Initialized
INFO - 2023-03-28 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:17 --> URI Class Initialized
INFO - 2023-03-28 07:39:17 --> Router Class Initialized
INFO - 2023-03-28 07:39:17 --> Output Class Initialized
INFO - 2023-03-28 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:17 --> Input Class Initialized
INFO - 2023-03-28 07:39:17 --> Language Class Initialized
INFO - 2023-03-28 07:39:17 --> Language Class Initialized
INFO - 2023-03-28 07:39:17 --> Config Class Initialized
INFO - 2023-03-28 07:39:17 --> Loader Class Initialized
INFO - 2023-03-28 07:39:17 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:17 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:17 --> Controller Class Initialized
INFO - 2023-03-28 07:39:17 --> Helper loaded: cookie_helper
INFO - 2023-03-28 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:17 --> Total execution time: 0.0251
INFO - 2023-03-28 07:39:17 --> Config Class Initialized
INFO - 2023-03-28 07:39:17 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:17 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:17 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:17 --> URI Class Initialized
INFO - 2023-03-28 07:39:17 --> Router Class Initialized
INFO - 2023-03-28 07:39:17 --> Output Class Initialized
INFO - 2023-03-28 07:39:17 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:17 --> Input Class Initialized
INFO - 2023-03-28 07:39:17 --> Language Class Initialized
INFO - 2023-03-28 07:39:17 --> Language Class Initialized
INFO - 2023-03-28 07:39:17 --> Config Class Initialized
INFO - 2023-03-28 07:39:17 --> Loader Class Initialized
INFO - 2023-03-28 07:39:17 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:17 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:17 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:17 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 07:39:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:17 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:17 --> Total execution time: 0.0506
INFO - 2023-03-28 07:39:21 --> Config Class Initialized
INFO - 2023-03-28 07:39:21 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:21 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:21 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:21 --> URI Class Initialized
INFO - 2023-03-28 07:39:21 --> Router Class Initialized
INFO - 2023-03-28 07:39:21 --> Output Class Initialized
INFO - 2023-03-28 07:39:21 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:21 --> Input Class Initialized
INFO - 2023-03-28 07:39:21 --> Language Class Initialized
INFO - 2023-03-28 07:39:21 --> Language Class Initialized
INFO - 2023-03-28 07:39:21 --> Config Class Initialized
INFO - 2023-03-28 07:39:21 --> Loader Class Initialized
INFO - 2023-03-28 07:39:21 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:21 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:21 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:21 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:21 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:21 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 07:39:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:21 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:21 --> Total execution time: 0.0646
INFO - 2023-03-28 07:39:28 --> Config Class Initialized
INFO - 2023-03-28 07:39:28 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:28 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:28 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:28 --> URI Class Initialized
INFO - 2023-03-28 07:39:28 --> Router Class Initialized
INFO - 2023-03-28 07:39:28 --> Output Class Initialized
INFO - 2023-03-28 07:39:28 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:28 --> Input Class Initialized
INFO - 2023-03-28 07:39:28 --> Language Class Initialized
INFO - 2023-03-28 07:39:28 --> Language Class Initialized
INFO - 2023-03-28 07:39:28 --> Config Class Initialized
INFO - 2023-03-28 07:39:28 --> Loader Class Initialized
INFO - 2023-03-28 07:39:28 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:28 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:28 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:28 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:28 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:28 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 07:39:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:28 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:28 --> Total execution time: 0.0416
INFO - 2023-03-28 07:39:31 --> Config Class Initialized
INFO - 2023-03-28 07:39:31 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:31 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:31 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:31 --> URI Class Initialized
INFO - 2023-03-28 07:39:31 --> Router Class Initialized
INFO - 2023-03-28 07:39:31 --> Output Class Initialized
INFO - 2023-03-28 07:39:31 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:31 --> Input Class Initialized
INFO - 2023-03-28 07:39:31 --> Language Class Initialized
INFO - 2023-03-28 07:39:31 --> Language Class Initialized
INFO - 2023-03-28 07:39:31 --> Config Class Initialized
INFO - 2023-03-28 07:39:31 --> Loader Class Initialized
INFO - 2023-03-28 07:39:31 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:31 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:31 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:31 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:31 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:31 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:39:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:39:31 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:31 --> Total execution time: 0.0265
INFO - 2023-03-28 07:39:35 --> Config Class Initialized
INFO - 2023-03-28 07:39:35 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:39:35 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:39:35 --> Utf8 Class Initialized
INFO - 2023-03-28 07:39:35 --> URI Class Initialized
INFO - 2023-03-28 07:39:35 --> Router Class Initialized
INFO - 2023-03-28 07:39:35 --> Output Class Initialized
INFO - 2023-03-28 07:39:35 --> Security Class Initialized
DEBUG - 2023-03-28 07:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:39:35 --> Input Class Initialized
INFO - 2023-03-28 07:39:35 --> Language Class Initialized
INFO - 2023-03-28 07:39:35 --> Language Class Initialized
INFO - 2023-03-28 07:39:35 --> Config Class Initialized
INFO - 2023-03-28 07:39:35 --> Loader Class Initialized
INFO - 2023-03-28 07:39:35 --> Helper loaded: url_helper
INFO - 2023-03-28 07:39:35 --> Helper loaded: file_helper
INFO - 2023-03-28 07:39:35 --> Helper loaded: form_helper
INFO - 2023-03-28 07:39:35 --> Helper loaded: my_helper
INFO - 2023-03-28 07:39:35 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:39:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:39:35 --> Controller Class Initialized
DEBUG - 2023-03-28 07:39:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:39:37 --> Final output sent to browser
DEBUG - 2023-03-28 07:39:37 --> Total execution time: 1.1807
INFO - 2023-03-28 07:43:55 --> Config Class Initialized
INFO - 2023-03-28 07:43:55 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:43:55 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:43:55 --> Utf8 Class Initialized
INFO - 2023-03-28 07:43:55 --> URI Class Initialized
INFO - 2023-03-28 07:43:55 --> Router Class Initialized
INFO - 2023-03-28 07:43:55 --> Output Class Initialized
INFO - 2023-03-28 07:43:55 --> Security Class Initialized
DEBUG - 2023-03-28 07:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:43:55 --> Input Class Initialized
INFO - 2023-03-28 07:43:55 --> Language Class Initialized
INFO - 2023-03-28 07:43:55 --> Language Class Initialized
INFO - 2023-03-28 07:43:55 --> Config Class Initialized
INFO - 2023-03-28 07:43:55 --> Loader Class Initialized
INFO - 2023-03-28 07:43:55 --> Helper loaded: url_helper
INFO - 2023-03-28 07:43:55 --> Helper loaded: file_helper
INFO - 2023-03-28 07:43:55 --> Helper loaded: form_helper
INFO - 2023-03-28 07:43:55 --> Helper loaded: my_helper
INFO - 2023-03-28 07:43:55 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:43:55 --> Controller Class Initialized
DEBUG - 2023-03-28 07:43:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:43:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:43:55 --> Final output sent to browser
DEBUG - 2023-03-28 07:43:55 --> Total execution time: 0.0290
INFO - 2023-03-28 07:44:00 --> Config Class Initialized
INFO - 2023-03-28 07:44:00 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:00 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:00 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:00 --> URI Class Initialized
INFO - 2023-03-28 07:44:00 --> Router Class Initialized
INFO - 2023-03-28 07:44:00 --> Output Class Initialized
INFO - 2023-03-28 07:44:00 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:00 --> Input Class Initialized
INFO - 2023-03-28 07:44:00 --> Language Class Initialized
INFO - 2023-03-28 07:44:00 --> Language Class Initialized
INFO - 2023-03-28 07:44:00 --> Config Class Initialized
INFO - 2023-03-28 07:44:00 --> Loader Class Initialized
INFO - 2023-03-28 07:44:00 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:00 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:00 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:00 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:00 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:00 --> Controller Class Initialized
DEBUG - 2023-03-28 07:44:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:44:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:44:00 --> Final output sent to browser
DEBUG - 2023-03-28 07:44:00 --> Total execution time: 0.0799
INFO - 2023-03-28 07:44:01 --> Config Class Initialized
INFO - 2023-03-28 07:44:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:01 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:01 --> URI Class Initialized
INFO - 2023-03-28 07:44:01 --> Router Class Initialized
INFO - 2023-03-28 07:44:01 --> Output Class Initialized
INFO - 2023-03-28 07:44:01 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:01 --> Input Class Initialized
INFO - 2023-03-28 07:44:01 --> Language Class Initialized
INFO - 2023-03-28 07:44:01 --> Language Class Initialized
INFO - 2023-03-28 07:44:01 --> Config Class Initialized
INFO - 2023-03-28 07:44:01 --> Loader Class Initialized
INFO - 2023-03-28 07:44:01 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:01 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:01 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:01 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:01 --> Controller Class Initialized
INFO - 2023-03-28 07:44:04 --> Config Class Initialized
INFO - 2023-03-28 07:44:04 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:04 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:04 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:04 --> URI Class Initialized
INFO - 2023-03-28 07:44:04 --> Router Class Initialized
INFO - 2023-03-28 07:44:04 --> Output Class Initialized
INFO - 2023-03-28 07:44:04 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:04 --> Input Class Initialized
INFO - 2023-03-28 07:44:04 --> Language Class Initialized
INFO - 2023-03-28 07:44:04 --> Language Class Initialized
INFO - 2023-03-28 07:44:04 --> Config Class Initialized
INFO - 2023-03-28 07:44:04 --> Loader Class Initialized
INFO - 2023-03-28 07:44:04 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:04 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:04 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:04 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:04 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:04 --> Controller Class Initialized
DEBUG - 2023-03-28 07:44:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:44:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:44:04 --> Final output sent to browser
DEBUG - 2023-03-28 07:44:04 --> Total execution time: 0.0447
INFO - 2023-03-28 07:44:05 --> Config Class Initialized
INFO - 2023-03-28 07:44:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:05 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:05 --> URI Class Initialized
INFO - 2023-03-28 07:44:05 --> Router Class Initialized
INFO - 2023-03-28 07:44:05 --> Output Class Initialized
INFO - 2023-03-28 07:44:05 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:05 --> Input Class Initialized
INFO - 2023-03-28 07:44:05 --> Language Class Initialized
INFO - 2023-03-28 07:44:05 --> Language Class Initialized
INFO - 2023-03-28 07:44:05 --> Config Class Initialized
INFO - 2023-03-28 07:44:05 --> Loader Class Initialized
INFO - 2023-03-28 07:44:05 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:05 --> Controller Class Initialized
DEBUG - 2023-03-28 07:44:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:44:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:44:05 --> Final output sent to browser
DEBUG - 2023-03-28 07:44:05 --> Total execution time: 0.0241
INFO - 2023-03-28 07:44:05 --> Config Class Initialized
INFO - 2023-03-28 07:44:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:05 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:05 --> URI Class Initialized
INFO - 2023-03-28 07:44:05 --> Router Class Initialized
INFO - 2023-03-28 07:44:05 --> Output Class Initialized
INFO - 2023-03-28 07:44:05 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:05 --> Input Class Initialized
INFO - 2023-03-28 07:44:05 --> Language Class Initialized
INFO - 2023-03-28 07:44:05 --> Language Class Initialized
INFO - 2023-03-28 07:44:05 --> Config Class Initialized
INFO - 2023-03-28 07:44:05 --> Loader Class Initialized
INFO - 2023-03-28 07:44:05 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:05 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:05 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:05 --> Controller Class Initialized
INFO - 2023-03-28 07:44:13 --> Config Class Initialized
INFO - 2023-03-28 07:44:13 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:44:13 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:44:13 --> Utf8 Class Initialized
INFO - 2023-03-28 07:44:13 --> URI Class Initialized
INFO - 2023-03-28 07:44:13 --> Router Class Initialized
INFO - 2023-03-28 07:44:13 --> Output Class Initialized
INFO - 2023-03-28 07:44:13 --> Security Class Initialized
DEBUG - 2023-03-28 07:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:44:13 --> Input Class Initialized
INFO - 2023-03-28 07:44:13 --> Language Class Initialized
INFO - 2023-03-28 07:44:13 --> Language Class Initialized
INFO - 2023-03-28 07:44:13 --> Config Class Initialized
INFO - 2023-03-28 07:44:13 --> Loader Class Initialized
INFO - 2023-03-28 07:44:13 --> Helper loaded: url_helper
INFO - 2023-03-28 07:44:13 --> Helper loaded: file_helper
INFO - 2023-03-28 07:44:13 --> Helper loaded: form_helper
INFO - 2023-03-28 07:44:13 --> Helper loaded: my_helper
INFO - 2023-03-28 07:44:13 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:44:13 --> Controller Class Initialized
DEBUG - 2023-03-28 07:44:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:44:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:44:13 --> Final output sent to browser
DEBUG - 2023-03-28 07:44:13 --> Total execution time: 0.0278
INFO - 2023-03-28 07:45:09 --> Config Class Initialized
INFO - 2023-03-28 07:45:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:09 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:09 --> URI Class Initialized
INFO - 2023-03-28 07:45:09 --> Router Class Initialized
INFO - 2023-03-28 07:45:09 --> Output Class Initialized
INFO - 2023-03-28 07:45:09 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:09 --> Input Class Initialized
INFO - 2023-03-28 07:45:09 --> Language Class Initialized
INFO - 2023-03-28 07:45:09 --> Language Class Initialized
INFO - 2023-03-28 07:45:09 --> Config Class Initialized
INFO - 2023-03-28 07:45:09 --> Loader Class Initialized
INFO - 2023-03-28 07:45:09 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:09 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:45:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:09 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:09 --> Total execution time: 0.0268
INFO - 2023-03-28 07:45:09 --> Config Class Initialized
INFO - 2023-03-28 07:45:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:09 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:09 --> URI Class Initialized
INFO - 2023-03-28 07:45:09 --> Router Class Initialized
INFO - 2023-03-28 07:45:09 --> Output Class Initialized
INFO - 2023-03-28 07:45:09 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:09 --> Input Class Initialized
INFO - 2023-03-28 07:45:09 --> Language Class Initialized
INFO - 2023-03-28 07:45:09 --> Language Class Initialized
INFO - 2023-03-28 07:45:09 --> Config Class Initialized
INFO - 2023-03-28 07:45:09 --> Loader Class Initialized
INFO - 2023-03-28 07:45:09 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:09 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:09 --> Controller Class Initialized
INFO - 2023-03-28 07:45:10 --> Config Class Initialized
INFO - 2023-03-28 07:45:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:10 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:10 --> URI Class Initialized
INFO - 2023-03-28 07:45:10 --> Router Class Initialized
INFO - 2023-03-28 07:45:10 --> Output Class Initialized
INFO - 2023-03-28 07:45:10 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:10 --> Input Class Initialized
INFO - 2023-03-28 07:45:10 --> Language Class Initialized
INFO - 2023-03-28 07:45:10 --> Language Class Initialized
INFO - 2023-03-28 07:45:10 --> Config Class Initialized
INFO - 2023-03-28 07:45:10 --> Loader Class Initialized
INFO - 2023-03-28 07:45:10 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:10 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:10 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:10 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:10 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:45:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:10 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:10 --> Total execution time: 0.0290
INFO - 2023-03-28 07:45:11 --> Config Class Initialized
INFO - 2023-03-28 07:45:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:11 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:11 --> URI Class Initialized
INFO - 2023-03-28 07:45:11 --> Router Class Initialized
INFO - 2023-03-28 07:45:11 --> Output Class Initialized
INFO - 2023-03-28 07:45:11 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:11 --> Input Class Initialized
INFO - 2023-03-28 07:45:11 --> Language Class Initialized
INFO - 2023-03-28 07:45:11 --> Language Class Initialized
INFO - 2023-03-28 07:45:11 --> Config Class Initialized
INFO - 2023-03-28 07:45:11 --> Loader Class Initialized
INFO - 2023-03-28 07:45:11 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:11 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:45:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:11 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:11 --> Total execution time: 0.0300
INFO - 2023-03-28 07:45:11 --> Config Class Initialized
INFO - 2023-03-28 07:45:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:11 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:11 --> URI Class Initialized
INFO - 2023-03-28 07:45:11 --> Router Class Initialized
INFO - 2023-03-28 07:45:11 --> Output Class Initialized
INFO - 2023-03-28 07:45:11 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:11 --> Input Class Initialized
INFO - 2023-03-28 07:45:11 --> Language Class Initialized
INFO - 2023-03-28 07:45:11 --> Language Class Initialized
INFO - 2023-03-28 07:45:11 --> Config Class Initialized
INFO - 2023-03-28 07:45:11 --> Loader Class Initialized
INFO - 2023-03-28 07:45:11 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:11 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:11 --> Controller Class Initialized
INFO - 2023-03-28 07:45:14 --> Config Class Initialized
INFO - 2023-03-28 07:45:14 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:14 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:14 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:14 --> URI Class Initialized
INFO - 2023-03-28 07:45:14 --> Router Class Initialized
INFO - 2023-03-28 07:45:14 --> Output Class Initialized
INFO - 2023-03-28 07:45:14 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:14 --> Input Class Initialized
INFO - 2023-03-28 07:45:14 --> Language Class Initialized
INFO - 2023-03-28 07:45:14 --> Language Class Initialized
INFO - 2023-03-28 07:45:14 --> Config Class Initialized
INFO - 2023-03-28 07:45:14 --> Loader Class Initialized
INFO - 2023-03-28 07:45:14 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:14 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:14 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:14 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:14 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:14 --> Controller Class Initialized
INFO - 2023-03-28 07:45:14 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:14 --> Total execution time: 0.0415
INFO - 2023-03-28 07:45:21 --> Config Class Initialized
INFO - 2023-03-28 07:45:21 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:21 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:21 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:21 --> URI Class Initialized
INFO - 2023-03-28 07:45:21 --> Router Class Initialized
INFO - 2023-03-28 07:45:21 --> Output Class Initialized
INFO - 2023-03-28 07:45:21 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:21 --> Input Class Initialized
INFO - 2023-03-28 07:45:21 --> Language Class Initialized
INFO - 2023-03-28 07:45:21 --> Language Class Initialized
INFO - 2023-03-28 07:45:21 --> Config Class Initialized
INFO - 2023-03-28 07:45:21 --> Loader Class Initialized
INFO - 2023-03-28 07:45:21 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:21 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:21 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:21 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:21 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:21 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:45:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:21 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:21 --> Total execution time: 0.0283
INFO - 2023-03-28 07:45:24 --> Config Class Initialized
INFO - 2023-03-28 07:45:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:24 --> URI Class Initialized
INFO - 2023-03-28 07:45:24 --> Router Class Initialized
INFO - 2023-03-28 07:45:24 --> Output Class Initialized
INFO - 2023-03-28 07:45:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:24 --> Input Class Initialized
INFO - 2023-03-28 07:45:24 --> Language Class Initialized
INFO - 2023-03-28 07:45:24 --> Language Class Initialized
INFO - 2023-03-28 07:45:24 --> Config Class Initialized
INFO - 2023-03-28 07:45:24 --> Loader Class Initialized
INFO - 2023-03-28 07:45:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:24 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:45:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:24 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:24 --> Total execution time: 0.0407
INFO - 2023-03-28 07:45:24 --> Config Class Initialized
INFO - 2023-03-28 07:45:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:24 --> URI Class Initialized
INFO - 2023-03-28 07:45:24 --> Router Class Initialized
INFO - 2023-03-28 07:45:24 --> Output Class Initialized
INFO - 2023-03-28 07:45:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:24 --> Input Class Initialized
INFO - 2023-03-28 07:45:24 --> Language Class Initialized
INFO - 2023-03-28 07:45:24 --> Language Class Initialized
INFO - 2023-03-28 07:45:24 --> Config Class Initialized
INFO - 2023-03-28 07:45:24 --> Loader Class Initialized
INFO - 2023-03-28 07:45:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:24 --> Controller Class Initialized
INFO - 2023-03-28 07:45:25 --> Config Class Initialized
INFO - 2023-03-28 07:45:25 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:25 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:25 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:25 --> URI Class Initialized
INFO - 2023-03-28 07:45:25 --> Router Class Initialized
INFO - 2023-03-28 07:45:25 --> Output Class Initialized
INFO - 2023-03-28 07:45:25 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:25 --> Input Class Initialized
INFO - 2023-03-28 07:45:25 --> Language Class Initialized
INFO - 2023-03-28 07:45:25 --> Language Class Initialized
INFO - 2023-03-28 07:45:25 --> Config Class Initialized
INFO - 2023-03-28 07:45:25 --> Loader Class Initialized
INFO - 2023-03-28 07:45:25 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:25 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:25 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:25 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:25 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:25 --> Controller Class Initialized
INFO - 2023-03-28 07:45:25 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:25 --> Total execution time: 0.0443
INFO - 2023-03-28 07:45:32 --> Config Class Initialized
INFO - 2023-03-28 07:45:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:32 --> URI Class Initialized
INFO - 2023-03-28 07:45:32 --> Router Class Initialized
INFO - 2023-03-28 07:45:32 --> Output Class Initialized
INFO - 2023-03-28 07:45:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:32 --> Input Class Initialized
INFO - 2023-03-28 07:45:32 --> Language Class Initialized
INFO - 2023-03-28 07:45:32 --> Language Class Initialized
INFO - 2023-03-28 07:45:32 --> Config Class Initialized
INFO - 2023-03-28 07:45:32 --> Loader Class Initialized
INFO - 2023-03-28 07:45:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:32 --> Controller Class Initialized
INFO - 2023-03-28 07:45:32 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:32 --> Total execution time: 0.0263
INFO - 2023-03-28 07:45:32 --> Config Class Initialized
INFO - 2023-03-28 07:45:32 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:32 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:32 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:32 --> URI Class Initialized
INFO - 2023-03-28 07:45:32 --> Router Class Initialized
INFO - 2023-03-28 07:45:32 --> Output Class Initialized
INFO - 2023-03-28 07:45:32 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:32 --> Input Class Initialized
INFO - 2023-03-28 07:45:32 --> Language Class Initialized
INFO - 2023-03-28 07:45:32 --> Language Class Initialized
INFO - 2023-03-28 07:45:32 --> Config Class Initialized
INFO - 2023-03-28 07:45:32 --> Loader Class Initialized
INFO - 2023-03-28 07:45:32 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:32 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:32 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:32 --> Controller Class Initialized
INFO - 2023-03-28 07:45:33 --> Config Class Initialized
INFO - 2023-03-28 07:45:33 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:33 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:33 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:33 --> URI Class Initialized
INFO - 2023-03-28 07:45:33 --> Router Class Initialized
INFO - 2023-03-28 07:45:33 --> Output Class Initialized
INFO - 2023-03-28 07:45:33 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:33 --> Input Class Initialized
INFO - 2023-03-28 07:45:33 --> Language Class Initialized
INFO - 2023-03-28 07:45:33 --> Language Class Initialized
INFO - 2023-03-28 07:45:33 --> Config Class Initialized
INFO - 2023-03-28 07:45:33 --> Loader Class Initialized
INFO - 2023-03-28 07:45:33 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:33 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:33 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:33 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:33 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:33 --> Controller Class Initialized
INFO - 2023-03-28 07:45:33 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:33 --> Total execution time: 0.0464
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:38 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:38 --> URI Class Initialized
INFO - 2023-03-28 07:45:38 --> Router Class Initialized
INFO - 2023-03-28 07:45:38 --> Output Class Initialized
INFO - 2023-03-28 07:45:38 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:38 --> Input Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Loader Class Initialized
INFO - 2023-03-28 07:45:38 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:38 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:38 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:38 --> Total execution time: 0.0508
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:38 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:38 --> URI Class Initialized
INFO - 2023-03-28 07:45:38 --> Router Class Initialized
INFO - 2023-03-28 07:45:38 --> Output Class Initialized
INFO - 2023-03-28 07:45:38 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:38 --> Input Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Loader Class Initialized
INFO - 2023-03-28 07:45:38 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:38 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:45:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:38 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:38 --> Total execution time: 0.0479
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:38 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:38 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:38 --> URI Class Initialized
INFO - 2023-03-28 07:45:38 --> Router Class Initialized
INFO - 2023-03-28 07:45:38 --> Output Class Initialized
INFO - 2023-03-28 07:45:38 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:38 --> Input Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Language Class Initialized
INFO - 2023-03-28 07:45:38 --> Config Class Initialized
INFO - 2023-03-28 07:45:38 --> Loader Class Initialized
INFO - 2023-03-28 07:45:38 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:38 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:38 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:38 --> Controller Class Initialized
INFO - 2023-03-28 07:45:40 --> Config Class Initialized
INFO - 2023-03-28 07:45:40 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:40 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:40 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:40 --> URI Class Initialized
INFO - 2023-03-28 07:45:40 --> Router Class Initialized
INFO - 2023-03-28 07:45:40 --> Output Class Initialized
INFO - 2023-03-28 07:45:40 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:40 --> Input Class Initialized
INFO - 2023-03-28 07:45:40 --> Language Class Initialized
INFO - 2023-03-28 07:45:40 --> Language Class Initialized
INFO - 2023-03-28 07:45:40 --> Config Class Initialized
INFO - 2023-03-28 07:45:40 --> Loader Class Initialized
INFO - 2023-03-28 07:45:40 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:40 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:40 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:40 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:40 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:40 --> Controller Class Initialized
INFO - 2023-03-28 07:45:40 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:40 --> Total execution time: 0.0237
INFO - 2023-03-28 07:45:42 --> Config Class Initialized
INFO - 2023-03-28 07:45:42 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:42 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:42 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:42 --> URI Class Initialized
INFO - 2023-03-28 07:45:42 --> Router Class Initialized
INFO - 2023-03-28 07:45:42 --> Output Class Initialized
INFO - 2023-03-28 07:45:42 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:42 --> Input Class Initialized
INFO - 2023-03-28 07:45:42 --> Language Class Initialized
INFO - 2023-03-28 07:45:42 --> Language Class Initialized
INFO - 2023-03-28 07:45:42 --> Config Class Initialized
INFO - 2023-03-28 07:45:42 --> Loader Class Initialized
INFO - 2023-03-28 07:45:42 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:42 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:42 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:42 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:42 --> Total execution time: 0.0263
INFO - 2023-03-28 07:45:42 --> Config Class Initialized
INFO - 2023-03-28 07:45:42 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:42 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:42 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:42 --> URI Class Initialized
INFO - 2023-03-28 07:45:42 --> Router Class Initialized
INFO - 2023-03-28 07:45:42 --> Output Class Initialized
INFO - 2023-03-28 07:45:42 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:42 --> Input Class Initialized
INFO - 2023-03-28 07:45:42 --> Language Class Initialized
INFO - 2023-03-28 07:45:42 --> Language Class Initialized
INFO - 2023-03-28 07:45:42 --> Config Class Initialized
INFO - 2023-03-28 07:45:42 --> Loader Class Initialized
INFO - 2023-03-28 07:45:42 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:42 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:42 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:42 --> Controller Class Initialized
DEBUG - 2023-03-28 07:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:45:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:45:42 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:42 --> Total execution time: 0.0234
INFO - 2023-03-28 07:45:43 --> Config Class Initialized
INFO - 2023-03-28 07:45:43 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:43 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:43 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:43 --> URI Class Initialized
INFO - 2023-03-28 07:45:43 --> Router Class Initialized
INFO - 2023-03-28 07:45:43 --> Output Class Initialized
INFO - 2023-03-28 07:45:43 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:43 --> Input Class Initialized
INFO - 2023-03-28 07:45:43 --> Language Class Initialized
INFO - 2023-03-28 07:45:43 --> Language Class Initialized
INFO - 2023-03-28 07:45:43 --> Config Class Initialized
INFO - 2023-03-28 07:45:43 --> Loader Class Initialized
INFO - 2023-03-28 07:45:43 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:43 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:43 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:43 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:43 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:43 --> Controller Class Initialized
INFO - 2023-03-28 07:45:44 --> Config Class Initialized
INFO - 2023-03-28 07:45:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:44 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:44 --> URI Class Initialized
INFO - 2023-03-28 07:45:44 --> Router Class Initialized
INFO - 2023-03-28 07:45:44 --> Output Class Initialized
INFO - 2023-03-28 07:45:44 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:44 --> Input Class Initialized
INFO - 2023-03-28 07:45:44 --> Language Class Initialized
INFO - 2023-03-28 07:45:44 --> Language Class Initialized
INFO - 2023-03-28 07:45:44 --> Config Class Initialized
INFO - 2023-03-28 07:45:44 --> Loader Class Initialized
INFO - 2023-03-28 07:45:44 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:44 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:44 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:44 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:44 --> Controller Class Initialized
INFO - 2023-03-28 07:45:44 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:44 --> Total execution time: 0.0472
INFO - 2023-03-28 07:45:49 --> Config Class Initialized
INFO - 2023-03-28 07:45:49 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:45:49 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:45:49 --> Utf8 Class Initialized
INFO - 2023-03-28 07:45:49 --> URI Class Initialized
INFO - 2023-03-28 07:45:49 --> Router Class Initialized
INFO - 2023-03-28 07:45:49 --> Output Class Initialized
INFO - 2023-03-28 07:45:49 --> Security Class Initialized
DEBUG - 2023-03-28 07:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:45:49 --> Input Class Initialized
INFO - 2023-03-28 07:45:49 --> Language Class Initialized
INFO - 2023-03-28 07:45:49 --> Language Class Initialized
INFO - 2023-03-28 07:45:49 --> Config Class Initialized
INFO - 2023-03-28 07:45:49 --> Loader Class Initialized
INFO - 2023-03-28 07:45:49 --> Helper loaded: url_helper
INFO - 2023-03-28 07:45:49 --> Helper loaded: file_helper
INFO - 2023-03-28 07:45:49 --> Helper loaded: form_helper
INFO - 2023-03-28 07:45:49 --> Helper loaded: my_helper
INFO - 2023-03-28 07:45:49 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:45:49 --> Controller Class Initialized
INFO - 2023-03-28 07:45:49 --> Final output sent to browser
DEBUG - 2023-03-28 07:45:49 --> Total execution time: 0.0321
INFO - 2023-03-28 07:46:24 --> Config Class Initialized
INFO - 2023-03-28 07:46:24 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:24 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:24 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:24 --> URI Class Initialized
INFO - 2023-03-28 07:46:24 --> Router Class Initialized
INFO - 2023-03-28 07:46:24 --> Output Class Initialized
INFO - 2023-03-28 07:46:24 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:24 --> Input Class Initialized
INFO - 2023-03-28 07:46:24 --> Language Class Initialized
INFO - 2023-03-28 07:46:24 --> Language Class Initialized
INFO - 2023-03-28 07:46:24 --> Config Class Initialized
INFO - 2023-03-28 07:46:24 --> Loader Class Initialized
INFO - 2023-03-28 07:46:24 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:24 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:24 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:24 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:24 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:24 --> Controller Class Initialized
DEBUG - 2023-03-28 07:46:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:46:26 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:26 --> Total execution time: 1.2390
INFO - 2023-03-28 07:46:52 --> Config Class Initialized
INFO - 2023-03-28 07:46:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:52 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:52 --> URI Class Initialized
INFO - 2023-03-28 07:46:52 --> Router Class Initialized
INFO - 2023-03-28 07:46:52 --> Output Class Initialized
INFO - 2023-03-28 07:46:52 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:52 --> Input Class Initialized
INFO - 2023-03-28 07:46:52 --> Language Class Initialized
INFO - 2023-03-28 07:46:52 --> Language Class Initialized
INFO - 2023-03-28 07:46:52 --> Config Class Initialized
INFO - 2023-03-28 07:46:52 --> Loader Class Initialized
INFO - 2023-03-28 07:46:52 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:52 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:52 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:52 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:52 --> Controller Class Initialized
DEBUG - 2023-03-28 07:46:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:46:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:46:52 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:52 --> Total execution time: 0.0422
INFO - 2023-03-28 07:46:53 --> Config Class Initialized
INFO - 2023-03-28 07:46:53 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:53 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:53 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:53 --> URI Class Initialized
INFO - 2023-03-28 07:46:53 --> Router Class Initialized
INFO - 2023-03-28 07:46:53 --> Output Class Initialized
INFO - 2023-03-28 07:46:53 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:53 --> Input Class Initialized
INFO - 2023-03-28 07:46:53 --> Language Class Initialized
INFO - 2023-03-28 07:46:53 --> Language Class Initialized
INFO - 2023-03-28 07:46:53 --> Config Class Initialized
INFO - 2023-03-28 07:46:53 --> Loader Class Initialized
INFO - 2023-03-28 07:46:53 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:53 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:53 --> Controller Class Initialized
DEBUG - 2023-03-28 07:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:46:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:46:53 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:53 --> Total execution time: 0.0261
INFO - 2023-03-28 07:46:53 --> Config Class Initialized
INFO - 2023-03-28 07:46:53 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:53 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:53 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:53 --> URI Class Initialized
INFO - 2023-03-28 07:46:53 --> Router Class Initialized
INFO - 2023-03-28 07:46:53 --> Output Class Initialized
INFO - 2023-03-28 07:46:53 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:53 --> Input Class Initialized
INFO - 2023-03-28 07:46:53 --> Language Class Initialized
INFO - 2023-03-28 07:46:53 --> Language Class Initialized
INFO - 2023-03-28 07:46:53 --> Config Class Initialized
INFO - 2023-03-28 07:46:53 --> Loader Class Initialized
INFO - 2023-03-28 07:46:53 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:53 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:53 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:53 --> Controller Class Initialized
INFO - 2023-03-28 07:46:55 --> Config Class Initialized
INFO - 2023-03-28 07:46:55 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:55 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:55 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:55 --> URI Class Initialized
INFO - 2023-03-28 07:46:55 --> Router Class Initialized
INFO - 2023-03-28 07:46:55 --> Output Class Initialized
INFO - 2023-03-28 07:46:55 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:55 --> Input Class Initialized
INFO - 2023-03-28 07:46:55 --> Language Class Initialized
INFO - 2023-03-28 07:46:55 --> Language Class Initialized
INFO - 2023-03-28 07:46:55 --> Config Class Initialized
INFO - 2023-03-28 07:46:55 --> Loader Class Initialized
INFO - 2023-03-28 07:46:55 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:55 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:55 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:55 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:55 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:55 --> Controller Class Initialized
INFO - 2023-03-28 07:46:55 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:55 --> Total execution time: 0.0238
INFO - 2023-03-28 07:46:56 --> Config Class Initialized
INFO - 2023-03-28 07:46:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:56 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:56 --> URI Class Initialized
INFO - 2023-03-28 07:46:56 --> Router Class Initialized
INFO - 2023-03-28 07:46:56 --> Output Class Initialized
INFO - 2023-03-28 07:46:56 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:56 --> Input Class Initialized
INFO - 2023-03-28 07:46:56 --> Language Class Initialized
INFO - 2023-03-28 07:46:56 --> Language Class Initialized
INFO - 2023-03-28 07:46:56 --> Config Class Initialized
INFO - 2023-03-28 07:46:56 --> Loader Class Initialized
INFO - 2023-03-28 07:46:56 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:56 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:56 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:56 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:56 --> Controller Class Initialized
INFO - 2023-03-28 07:46:56 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:56 --> Total execution time: 0.0444
INFO - 2023-03-28 07:46:58 --> Config Class Initialized
INFO - 2023-03-28 07:46:58 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:58 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:58 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:58 --> URI Class Initialized
INFO - 2023-03-28 07:46:58 --> Router Class Initialized
INFO - 2023-03-28 07:46:58 --> Output Class Initialized
INFO - 2023-03-28 07:46:58 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:58 --> Input Class Initialized
INFO - 2023-03-28 07:46:58 --> Language Class Initialized
INFO - 2023-03-28 07:46:58 --> Language Class Initialized
INFO - 2023-03-28 07:46:58 --> Config Class Initialized
INFO - 2023-03-28 07:46:58 --> Loader Class Initialized
INFO - 2023-03-28 07:46:58 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:58 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:58 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:58 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:58 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:58 --> Controller Class Initialized
DEBUG - 2023-03-28 07:46:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 07:46:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:46:58 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:58 --> Total execution time: 0.0390
INFO - 2023-03-28 07:46:59 --> Config Class Initialized
INFO - 2023-03-28 07:46:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:59 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:59 --> URI Class Initialized
INFO - 2023-03-28 07:46:59 --> Router Class Initialized
INFO - 2023-03-28 07:46:59 --> Output Class Initialized
INFO - 2023-03-28 07:46:59 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:59 --> Input Class Initialized
INFO - 2023-03-28 07:46:59 --> Language Class Initialized
INFO - 2023-03-28 07:46:59 --> Language Class Initialized
INFO - 2023-03-28 07:46:59 --> Config Class Initialized
INFO - 2023-03-28 07:46:59 --> Loader Class Initialized
INFO - 2023-03-28 07:46:59 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:59 --> Controller Class Initialized
DEBUG - 2023-03-28 07:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-03-28 07:46:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:46:59 --> Final output sent to browser
DEBUG - 2023-03-28 07:46:59 --> Total execution time: 0.0238
INFO - 2023-03-28 07:46:59 --> Config Class Initialized
INFO - 2023-03-28 07:46:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:46:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:46:59 --> Utf8 Class Initialized
INFO - 2023-03-28 07:46:59 --> URI Class Initialized
INFO - 2023-03-28 07:46:59 --> Router Class Initialized
INFO - 2023-03-28 07:46:59 --> Output Class Initialized
INFO - 2023-03-28 07:46:59 --> Security Class Initialized
DEBUG - 2023-03-28 07:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:46:59 --> Input Class Initialized
INFO - 2023-03-28 07:46:59 --> Language Class Initialized
INFO - 2023-03-28 07:46:59 --> Language Class Initialized
INFO - 2023-03-28 07:46:59 --> Config Class Initialized
INFO - 2023-03-28 07:46:59 --> Loader Class Initialized
INFO - 2023-03-28 07:46:59 --> Helper loaded: url_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: file_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: form_helper
INFO - 2023-03-28 07:46:59 --> Helper loaded: my_helper
INFO - 2023-03-28 07:46:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:46:59 --> Controller Class Initialized
INFO - 2023-03-28 07:54:03 --> Config Class Initialized
INFO - 2023-03-28 07:54:03 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:54:03 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:54:03 --> Utf8 Class Initialized
INFO - 2023-03-28 07:54:03 --> URI Class Initialized
INFO - 2023-03-28 07:54:03 --> Router Class Initialized
INFO - 2023-03-28 07:54:03 --> Output Class Initialized
INFO - 2023-03-28 07:54:03 --> Security Class Initialized
DEBUG - 2023-03-28 07:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:54:03 --> Input Class Initialized
INFO - 2023-03-28 07:54:03 --> Language Class Initialized
INFO - 2023-03-28 07:54:03 --> Language Class Initialized
INFO - 2023-03-28 07:54:03 --> Config Class Initialized
INFO - 2023-03-28 07:54:03 --> Loader Class Initialized
INFO - 2023-03-28 07:54:03 --> Helper loaded: url_helper
INFO - 2023-03-28 07:54:03 --> Helper loaded: file_helper
INFO - 2023-03-28 07:54:03 --> Helper loaded: form_helper
INFO - 2023-03-28 07:54:03 --> Helper loaded: my_helper
INFO - 2023-03-28 07:54:03 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:54:03 --> Controller Class Initialized
INFO - 2023-03-28 07:54:03 --> Final output sent to browser
DEBUG - 2023-03-28 07:54:03 --> Total execution time: 0.0287
INFO - 2023-03-28 07:54:07 --> Config Class Initialized
INFO - 2023-03-28 07:54:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:54:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:54:07 --> Utf8 Class Initialized
INFO - 2023-03-28 07:54:07 --> URI Class Initialized
INFO - 2023-03-28 07:54:07 --> Router Class Initialized
INFO - 2023-03-28 07:54:07 --> Output Class Initialized
INFO - 2023-03-28 07:54:07 --> Security Class Initialized
DEBUG - 2023-03-28 07:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:54:07 --> Input Class Initialized
INFO - 2023-03-28 07:54:07 --> Language Class Initialized
INFO - 2023-03-28 07:54:07 --> Language Class Initialized
INFO - 2023-03-28 07:54:07 --> Config Class Initialized
INFO - 2023-03-28 07:54:07 --> Loader Class Initialized
INFO - 2023-03-28 07:54:07 --> Helper loaded: url_helper
INFO - 2023-03-28 07:54:07 --> Helper loaded: file_helper
INFO - 2023-03-28 07:54:07 --> Helper loaded: form_helper
INFO - 2023-03-28 07:54:07 --> Helper loaded: my_helper
INFO - 2023-03-28 07:54:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:54:07 --> Controller Class Initialized
DEBUG - 2023-03-28 07:54:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:54:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:54:07 --> Final output sent to browser
DEBUG - 2023-03-28 07:54:07 --> Total execution time: 0.0280
INFO - 2023-03-28 07:54:09 --> Config Class Initialized
INFO - 2023-03-28 07:54:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:54:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:54:09 --> Utf8 Class Initialized
INFO - 2023-03-28 07:54:09 --> URI Class Initialized
INFO - 2023-03-28 07:54:09 --> Router Class Initialized
INFO - 2023-03-28 07:54:09 --> Output Class Initialized
INFO - 2023-03-28 07:54:09 --> Security Class Initialized
DEBUG - 2023-03-28 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:54:09 --> Input Class Initialized
INFO - 2023-03-28 07:54:09 --> Language Class Initialized
INFO - 2023-03-28 07:54:09 --> Language Class Initialized
INFO - 2023-03-28 07:54:09 --> Config Class Initialized
INFO - 2023-03-28 07:54:09 --> Loader Class Initialized
INFO - 2023-03-28 07:54:09 --> Helper loaded: url_helper
INFO - 2023-03-28 07:54:09 --> Helper loaded: file_helper
INFO - 2023-03-28 07:54:09 --> Helper loaded: form_helper
INFO - 2023-03-28 07:54:09 --> Helper loaded: my_helper
INFO - 2023-03-28 07:54:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:54:09 --> Controller Class Initialized
DEBUG - 2023-03-28 07:54:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 07:54:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:54:09 --> Final output sent to browser
DEBUG - 2023-03-28 07:54:09 --> Total execution time: 0.0494
INFO - 2023-03-28 07:54:10 --> Config Class Initialized
INFO - 2023-03-28 07:54:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:54:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:54:10 --> Utf8 Class Initialized
INFO - 2023-03-28 07:54:10 --> URI Class Initialized
INFO - 2023-03-28 07:54:10 --> Router Class Initialized
INFO - 2023-03-28 07:54:10 --> Output Class Initialized
INFO - 2023-03-28 07:54:10 --> Security Class Initialized
DEBUG - 2023-03-28 07:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:54:10 --> Input Class Initialized
INFO - 2023-03-28 07:54:10 --> Language Class Initialized
INFO - 2023-03-28 07:54:10 --> Language Class Initialized
INFO - 2023-03-28 07:54:10 --> Config Class Initialized
INFO - 2023-03-28 07:54:10 --> Loader Class Initialized
INFO - 2023-03-28 07:54:10 --> Helper loaded: url_helper
INFO - 2023-03-28 07:54:10 --> Helper loaded: file_helper
INFO - 2023-03-28 07:54:10 --> Helper loaded: form_helper
INFO - 2023-03-28 07:54:10 --> Helper loaded: my_helper
INFO - 2023-03-28 07:54:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:54:10 --> Controller Class Initialized
DEBUG - 2023-03-28 07:54:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 07:54:12 --> Final output sent to browser
DEBUG - 2023-03-28 07:54:12 --> Total execution time: 1.2161
INFO - 2023-03-28 07:56:28 --> Config Class Initialized
INFO - 2023-03-28 07:56:28 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:56:28 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:56:28 --> Utf8 Class Initialized
INFO - 2023-03-28 07:56:28 --> URI Class Initialized
INFO - 2023-03-28 07:56:28 --> Router Class Initialized
INFO - 2023-03-28 07:56:28 --> Output Class Initialized
INFO - 2023-03-28 07:56:28 --> Security Class Initialized
DEBUG - 2023-03-28 07:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:56:28 --> Input Class Initialized
INFO - 2023-03-28 07:56:28 --> Language Class Initialized
INFO - 2023-03-28 07:56:28 --> Language Class Initialized
INFO - 2023-03-28 07:56:28 --> Config Class Initialized
INFO - 2023-03-28 07:56:28 --> Loader Class Initialized
INFO - 2023-03-28 07:56:28 --> Helper loaded: url_helper
INFO - 2023-03-28 07:56:28 --> Helper loaded: file_helper
INFO - 2023-03-28 07:56:28 --> Helper loaded: form_helper
INFO - 2023-03-28 07:56:28 --> Helper loaded: my_helper
INFO - 2023-03-28 07:56:28 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:56:28 --> Controller Class Initialized
DEBUG - 2023-03-28 07:56:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-28 07:56:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 07:56:28 --> Final output sent to browser
DEBUG - 2023-03-28 07:56:28 --> Total execution time: 0.0298
INFO - 2023-03-28 07:56:29 --> Config Class Initialized
INFO - 2023-03-28 07:56:29 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:56:29 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:56:29 --> Utf8 Class Initialized
INFO - 2023-03-28 07:56:29 --> URI Class Initialized
INFO - 2023-03-28 07:56:29 --> Router Class Initialized
INFO - 2023-03-28 07:56:29 --> Output Class Initialized
INFO - 2023-03-28 07:56:29 --> Security Class Initialized
DEBUG - 2023-03-28 07:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:56:29 --> Input Class Initialized
INFO - 2023-03-28 07:56:29 --> Language Class Initialized
INFO - 2023-03-28 07:56:29 --> Language Class Initialized
INFO - 2023-03-28 07:56:29 --> Config Class Initialized
INFO - 2023-03-28 07:56:29 --> Loader Class Initialized
INFO - 2023-03-28 07:56:29 --> Helper loaded: url_helper
INFO - 2023-03-28 07:56:29 --> Helper loaded: file_helper
INFO - 2023-03-28 07:56:29 --> Helper loaded: form_helper
INFO - 2023-03-28 07:56:29 --> Helper loaded: my_helper
INFO - 2023-03-28 07:56:29 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:56:29 --> Controller Class Initialized
ERROR - 2023-03-28 07:56:29 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 238
DEBUG - 2023-03-28 07:56:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:56:30 --> Final output sent to browser
DEBUG - 2023-03-28 07:56:30 --> Total execution time: 1.1839
INFO - 2023-03-28 07:57:27 --> Config Class Initialized
INFO - 2023-03-28 07:57:27 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:57:27 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:57:27 --> Utf8 Class Initialized
INFO - 2023-03-28 07:57:27 --> URI Class Initialized
INFO - 2023-03-28 07:57:27 --> Router Class Initialized
INFO - 2023-03-28 07:57:27 --> Output Class Initialized
INFO - 2023-03-28 07:57:27 --> Security Class Initialized
DEBUG - 2023-03-28 07:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:57:27 --> Input Class Initialized
INFO - 2023-03-28 07:57:27 --> Language Class Initialized
INFO - 2023-03-28 07:57:27 --> Language Class Initialized
INFO - 2023-03-28 07:57:27 --> Config Class Initialized
INFO - 2023-03-28 07:57:27 --> Loader Class Initialized
INFO - 2023-03-28 07:57:27 --> Helper loaded: url_helper
INFO - 2023-03-28 07:57:27 --> Helper loaded: file_helper
INFO - 2023-03-28 07:57:27 --> Helper loaded: form_helper
INFO - 2023-03-28 07:57:27 --> Helper loaded: my_helper
INFO - 2023-03-28 07:57:27 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:57:27 --> Controller Class Initialized
DEBUG - 2023-03-28 07:57:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:57:29 --> Final output sent to browser
DEBUG - 2023-03-28 07:57:29 --> Total execution time: 1.2552
INFO - 2023-03-28 07:58:12 --> Config Class Initialized
INFO - 2023-03-28 07:58:12 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:58:12 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:58:12 --> Utf8 Class Initialized
INFO - 2023-03-28 07:58:12 --> URI Class Initialized
INFO - 2023-03-28 07:58:12 --> Router Class Initialized
INFO - 2023-03-28 07:58:12 --> Output Class Initialized
INFO - 2023-03-28 07:58:12 --> Security Class Initialized
DEBUG - 2023-03-28 07:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:58:12 --> Input Class Initialized
INFO - 2023-03-28 07:58:12 --> Language Class Initialized
INFO - 2023-03-28 07:58:12 --> Language Class Initialized
INFO - 2023-03-28 07:58:12 --> Config Class Initialized
INFO - 2023-03-28 07:58:12 --> Loader Class Initialized
INFO - 2023-03-28 07:58:12 --> Helper loaded: url_helper
INFO - 2023-03-28 07:58:12 --> Helper loaded: file_helper
INFO - 2023-03-28 07:58:12 --> Helper loaded: form_helper
INFO - 2023-03-28 07:58:12 --> Helper loaded: my_helper
INFO - 2023-03-28 07:58:12 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:58:12 --> Controller Class Initialized
DEBUG - 2023-03-28 07:58:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:58:14 --> Final output sent to browser
DEBUG - 2023-03-28 07:58:14 --> Total execution time: 1.1933
INFO - 2023-03-28 07:58:43 --> Config Class Initialized
INFO - 2023-03-28 07:58:43 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:58:43 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:58:43 --> Utf8 Class Initialized
INFO - 2023-03-28 07:58:43 --> URI Class Initialized
INFO - 2023-03-28 07:58:43 --> Router Class Initialized
INFO - 2023-03-28 07:58:43 --> Output Class Initialized
INFO - 2023-03-28 07:58:43 --> Security Class Initialized
DEBUG - 2023-03-28 07:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:58:43 --> Input Class Initialized
INFO - 2023-03-28 07:58:43 --> Language Class Initialized
INFO - 2023-03-28 07:58:43 --> Language Class Initialized
INFO - 2023-03-28 07:58:43 --> Config Class Initialized
INFO - 2023-03-28 07:58:43 --> Loader Class Initialized
INFO - 2023-03-28 07:58:43 --> Helper loaded: url_helper
INFO - 2023-03-28 07:58:43 --> Helper loaded: file_helper
INFO - 2023-03-28 07:58:43 --> Helper loaded: form_helper
INFO - 2023-03-28 07:58:43 --> Helper loaded: my_helper
INFO - 2023-03-28 07:58:43 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:58:43 --> Controller Class Initialized
DEBUG - 2023-03-28 07:58:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:58:44 --> Final output sent to browser
DEBUG - 2023-03-28 07:58:44 --> Total execution time: 1.1905
INFO - 2023-03-28 07:59:48 --> Config Class Initialized
INFO - 2023-03-28 07:59:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 07:59:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 07:59:48 --> Utf8 Class Initialized
INFO - 2023-03-28 07:59:48 --> URI Class Initialized
INFO - 2023-03-28 07:59:48 --> Router Class Initialized
INFO - 2023-03-28 07:59:48 --> Output Class Initialized
INFO - 2023-03-28 07:59:48 --> Security Class Initialized
DEBUG - 2023-03-28 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 07:59:48 --> Input Class Initialized
INFO - 2023-03-28 07:59:48 --> Language Class Initialized
INFO - 2023-03-28 07:59:48 --> Language Class Initialized
INFO - 2023-03-28 07:59:48 --> Config Class Initialized
INFO - 2023-03-28 07:59:48 --> Loader Class Initialized
INFO - 2023-03-28 07:59:48 --> Helper loaded: url_helper
INFO - 2023-03-28 07:59:48 --> Helper loaded: file_helper
INFO - 2023-03-28 07:59:48 --> Helper loaded: form_helper
INFO - 2023-03-28 07:59:48 --> Helper loaded: my_helper
INFO - 2023-03-28 07:59:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 07:59:49 --> Controller Class Initialized
DEBUG - 2023-03-28 07:59:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 07:59:50 --> Final output sent to browser
DEBUG - 2023-03-28 07:59:50 --> Total execution time: 1.1936
INFO - 2023-03-28 08:00:02 --> Config Class Initialized
INFO - 2023-03-28 08:00:02 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:00:02 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:00:02 --> Utf8 Class Initialized
INFO - 2023-03-28 08:00:02 --> URI Class Initialized
INFO - 2023-03-28 08:00:02 --> Router Class Initialized
INFO - 2023-03-28 08:00:02 --> Output Class Initialized
INFO - 2023-03-28 08:00:02 --> Security Class Initialized
DEBUG - 2023-03-28 08:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:00:02 --> Input Class Initialized
INFO - 2023-03-28 08:00:02 --> Language Class Initialized
INFO - 2023-03-28 08:00:02 --> Language Class Initialized
INFO - 2023-03-28 08:00:02 --> Config Class Initialized
INFO - 2023-03-28 08:00:02 --> Loader Class Initialized
INFO - 2023-03-28 08:00:02 --> Helper loaded: url_helper
INFO - 2023-03-28 08:00:02 --> Helper loaded: file_helper
INFO - 2023-03-28 08:00:02 --> Helper loaded: form_helper
INFO - 2023-03-28 08:00:02 --> Helper loaded: my_helper
INFO - 2023-03-28 08:00:02 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:00:02 --> Controller Class Initialized
DEBUG - 2023-03-28 08:00:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:00:04 --> Final output sent to browser
DEBUG - 2023-03-28 08:00:04 --> Total execution time: 1.2081
INFO - 2023-03-28 08:00:09 --> Config Class Initialized
INFO - 2023-03-28 08:00:09 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:00:09 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:00:09 --> Utf8 Class Initialized
INFO - 2023-03-28 08:00:09 --> URI Class Initialized
INFO - 2023-03-28 08:00:09 --> Router Class Initialized
INFO - 2023-03-28 08:00:09 --> Output Class Initialized
INFO - 2023-03-28 08:00:09 --> Security Class Initialized
DEBUG - 2023-03-28 08:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:00:09 --> Input Class Initialized
INFO - 2023-03-28 08:00:09 --> Language Class Initialized
INFO - 2023-03-28 08:00:09 --> Language Class Initialized
INFO - 2023-03-28 08:00:09 --> Config Class Initialized
INFO - 2023-03-28 08:00:09 --> Loader Class Initialized
INFO - 2023-03-28 08:00:09 --> Helper loaded: url_helper
INFO - 2023-03-28 08:00:09 --> Helper loaded: file_helper
INFO - 2023-03-28 08:00:09 --> Helper loaded: form_helper
INFO - 2023-03-28 08:00:09 --> Helper loaded: my_helper
INFO - 2023-03-28 08:00:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:00:09 --> Controller Class Initialized
DEBUG - 2023-03-28 08:00:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:00:10 --> Final output sent to browser
DEBUG - 2023-03-28 08:00:10 --> Total execution time: 1.1790
INFO - 2023-03-28 08:01:23 --> Config Class Initialized
INFO - 2023-03-28 08:01:23 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:01:23 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:01:23 --> Utf8 Class Initialized
INFO - 2023-03-28 08:01:23 --> URI Class Initialized
INFO - 2023-03-28 08:01:23 --> Router Class Initialized
INFO - 2023-03-28 08:01:23 --> Output Class Initialized
INFO - 2023-03-28 08:01:23 --> Security Class Initialized
DEBUG - 2023-03-28 08:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:01:23 --> Input Class Initialized
INFO - 2023-03-28 08:01:23 --> Language Class Initialized
INFO - 2023-03-28 08:01:23 --> Language Class Initialized
INFO - 2023-03-28 08:01:23 --> Config Class Initialized
INFO - 2023-03-28 08:01:23 --> Loader Class Initialized
INFO - 2023-03-28 08:01:23 --> Helper loaded: url_helper
INFO - 2023-03-28 08:01:23 --> Helper loaded: file_helper
INFO - 2023-03-28 08:01:23 --> Helper loaded: form_helper
INFO - 2023-03-28 08:01:23 --> Helper loaded: my_helper
INFO - 2023-03-28 08:01:23 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:01:23 --> Controller Class Initialized
DEBUG - 2023-03-28 08:01:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:01:24 --> Final output sent to browser
DEBUG - 2023-03-28 08:01:24 --> Total execution time: 1.2236
INFO - 2023-03-28 08:02:14 --> Config Class Initialized
INFO - 2023-03-28 08:02:14 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:02:14 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:02:14 --> Utf8 Class Initialized
INFO - 2023-03-28 08:02:14 --> URI Class Initialized
INFO - 2023-03-28 08:02:14 --> Router Class Initialized
INFO - 2023-03-28 08:02:14 --> Output Class Initialized
INFO - 2023-03-28 08:02:14 --> Security Class Initialized
DEBUG - 2023-03-28 08:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:02:14 --> Input Class Initialized
INFO - 2023-03-28 08:02:14 --> Language Class Initialized
INFO - 2023-03-28 08:02:14 --> Language Class Initialized
INFO - 2023-03-28 08:02:14 --> Config Class Initialized
INFO - 2023-03-28 08:02:14 --> Loader Class Initialized
INFO - 2023-03-28 08:02:14 --> Helper loaded: url_helper
INFO - 2023-03-28 08:02:14 --> Helper loaded: file_helper
INFO - 2023-03-28 08:02:14 --> Helper loaded: form_helper
INFO - 2023-03-28 08:02:14 --> Helper loaded: my_helper
INFO - 2023-03-28 08:02:14 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:02:14 --> Controller Class Initialized
DEBUG - 2023-03-28 08:02:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:02:15 --> Final output sent to browser
DEBUG - 2023-03-28 08:02:15 --> Total execution time: 1.1562
INFO - 2023-03-28 08:03:34 --> Config Class Initialized
INFO - 2023-03-28 08:03:34 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:34 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:34 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:34 --> URI Class Initialized
INFO - 2023-03-28 08:03:34 --> Router Class Initialized
INFO - 2023-03-28 08:03:34 --> Output Class Initialized
INFO - 2023-03-28 08:03:34 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:34 --> Input Class Initialized
INFO - 2023-03-28 08:03:34 --> Language Class Initialized
INFO - 2023-03-28 08:03:34 --> Language Class Initialized
INFO - 2023-03-28 08:03:34 --> Config Class Initialized
INFO - 2023-03-28 08:03:34 --> Loader Class Initialized
INFO - 2023-03-28 08:03:34 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:34 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:34 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:34 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:34 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:34 --> Controller Class Initialized
DEBUG - 2023-03-28 08:03:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:03:35 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:35 --> Total execution time: 1.2385
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:39 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:39 --> URI Class Initialized
INFO - 2023-03-28 08:03:39 --> Router Class Initialized
INFO - 2023-03-28 08:03:39 --> Output Class Initialized
INFO - 2023-03-28 08:03:39 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:39 --> Input Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Loader Class Initialized
INFO - 2023-03-28 08:03:39 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:39 --> Controller Class Initialized
INFO - 2023-03-28 08:03:39 --> Helper loaded: cookie_helper
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:39 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:39 --> URI Class Initialized
INFO - 2023-03-28 08:03:39 --> Router Class Initialized
INFO - 2023-03-28 08:03:39 --> Output Class Initialized
INFO - 2023-03-28 08:03:39 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:39 --> Input Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Loader Class Initialized
INFO - 2023-03-28 08:03:39 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:39 --> Controller Class Initialized
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:39 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:39 --> URI Class Initialized
INFO - 2023-03-28 08:03:39 --> Router Class Initialized
INFO - 2023-03-28 08:03:39 --> Output Class Initialized
INFO - 2023-03-28 08:03:39 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:39 --> Input Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Language Class Initialized
INFO - 2023-03-28 08:03:39 --> Config Class Initialized
INFO - 2023-03-28 08:03:39 --> Loader Class Initialized
INFO - 2023-03-28 08:03:39 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:39 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:39 --> Controller Class Initialized
DEBUG - 2023-03-28 08:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 08:03:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:03:39 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:39 --> Total execution time: 0.0400
INFO - 2023-03-28 08:03:44 --> Config Class Initialized
INFO - 2023-03-28 08:03:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:44 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:44 --> URI Class Initialized
INFO - 2023-03-28 08:03:44 --> Router Class Initialized
INFO - 2023-03-28 08:03:44 --> Output Class Initialized
INFO - 2023-03-28 08:03:44 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:44 --> Input Class Initialized
INFO - 2023-03-28 08:03:44 --> Language Class Initialized
INFO - 2023-03-28 08:03:44 --> Language Class Initialized
INFO - 2023-03-28 08:03:44 --> Config Class Initialized
INFO - 2023-03-28 08:03:44 --> Loader Class Initialized
INFO - 2023-03-28 08:03:44 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:44 --> Controller Class Initialized
INFO - 2023-03-28 08:03:44 --> Helper loaded: cookie_helper
INFO - 2023-03-28 08:03:44 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:44 --> Total execution time: 0.0448
INFO - 2023-03-28 08:03:44 --> Config Class Initialized
INFO - 2023-03-28 08:03:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:44 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:44 --> URI Class Initialized
INFO - 2023-03-28 08:03:44 --> Router Class Initialized
INFO - 2023-03-28 08:03:44 --> Output Class Initialized
INFO - 2023-03-28 08:03:44 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:44 --> Input Class Initialized
INFO - 2023-03-28 08:03:44 --> Language Class Initialized
INFO - 2023-03-28 08:03:44 --> Language Class Initialized
INFO - 2023-03-28 08:03:44 --> Config Class Initialized
INFO - 2023-03-28 08:03:44 --> Loader Class Initialized
INFO - 2023-03-28 08:03:44 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:44 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:44 --> Controller Class Initialized
DEBUG - 2023-03-28 08:03:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-03-28 08:03:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:03:44 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:44 --> Total execution time: 0.0672
INFO - 2023-03-28 08:03:53 --> Config Class Initialized
INFO - 2023-03-28 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:53 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:53 --> URI Class Initialized
INFO - 2023-03-28 08:03:53 --> Router Class Initialized
INFO - 2023-03-28 08:03:53 --> Output Class Initialized
INFO - 2023-03-28 08:03:53 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:53 --> Input Class Initialized
INFO - 2023-03-28 08:03:53 --> Language Class Initialized
INFO - 2023-03-28 08:03:53 --> Language Class Initialized
INFO - 2023-03-28 08:03:53 --> Config Class Initialized
INFO - 2023-03-28 08:03:53 --> Loader Class Initialized
INFO - 2023-03-28 08:03:53 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:53 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:53 --> Controller Class Initialized
DEBUG - 2023-03-28 08:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-03-28 08:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:03:53 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:53 --> Total execution time: 0.0585
INFO - 2023-03-28 08:03:53 --> Config Class Initialized
INFO - 2023-03-28 08:03:53 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:53 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:53 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:53 --> URI Class Initialized
INFO - 2023-03-28 08:03:53 --> Router Class Initialized
INFO - 2023-03-28 08:03:53 --> Output Class Initialized
INFO - 2023-03-28 08:03:53 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:53 --> Input Class Initialized
INFO - 2023-03-28 08:03:53 --> Language Class Initialized
INFO - 2023-03-28 08:03:53 --> Language Class Initialized
INFO - 2023-03-28 08:03:53 --> Config Class Initialized
INFO - 2023-03-28 08:03:53 --> Loader Class Initialized
INFO - 2023-03-28 08:03:53 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:53 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:53 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:53 --> Controller Class Initialized
INFO - 2023-03-28 08:03:59 --> Config Class Initialized
INFO - 2023-03-28 08:03:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:03:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:03:59 --> Utf8 Class Initialized
INFO - 2023-03-28 08:03:59 --> URI Class Initialized
INFO - 2023-03-28 08:03:59 --> Router Class Initialized
INFO - 2023-03-28 08:03:59 --> Output Class Initialized
INFO - 2023-03-28 08:03:59 --> Security Class Initialized
DEBUG - 2023-03-28 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:03:59 --> Input Class Initialized
INFO - 2023-03-28 08:03:59 --> Language Class Initialized
INFO - 2023-03-28 08:03:59 --> Language Class Initialized
INFO - 2023-03-28 08:03:59 --> Config Class Initialized
INFO - 2023-03-28 08:03:59 --> Loader Class Initialized
INFO - 2023-03-28 08:03:59 --> Helper loaded: url_helper
INFO - 2023-03-28 08:03:59 --> Helper loaded: file_helper
INFO - 2023-03-28 08:03:59 --> Helper loaded: form_helper
INFO - 2023-03-28 08:03:59 --> Helper loaded: my_helper
INFO - 2023-03-28 08:03:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:03:59 --> Controller Class Initialized
INFO - 2023-03-28 08:03:59 --> Final output sent to browser
DEBUG - 2023-03-28 08:03:59 --> Total execution time: 0.0532
INFO - 2023-03-28 08:04:39 --> Config Class Initialized
INFO - 2023-03-28 08:04:39 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:04:39 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:04:39 --> Utf8 Class Initialized
INFO - 2023-03-28 08:04:39 --> URI Class Initialized
INFO - 2023-03-28 08:04:39 --> Router Class Initialized
INFO - 2023-03-28 08:04:39 --> Output Class Initialized
INFO - 2023-03-28 08:04:39 --> Security Class Initialized
DEBUG - 2023-03-28 08:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:04:39 --> Input Class Initialized
INFO - 2023-03-28 08:04:39 --> Language Class Initialized
INFO - 2023-03-28 08:04:39 --> Language Class Initialized
INFO - 2023-03-28 08:04:39 --> Config Class Initialized
INFO - 2023-03-28 08:04:39 --> Loader Class Initialized
INFO - 2023-03-28 08:04:39 --> Helper loaded: url_helper
INFO - 2023-03-28 08:04:39 --> Helper loaded: file_helper
INFO - 2023-03-28 08:04:39 --> Helper loaded: form_helper
INFO - 2023-03-28 08:04:39 --> Helper loaded: my_helper
INFO - 2023-03-28 08:04:39 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:04:39 --> Controller Class Initialized
DEBUG - 2023-03-28 08:04:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 08:04:40 --> Final output sent to browser
DEBUG - 2023-03-28 08:04:40 --> Total execution time: 1.2048
INFO - 2023-03-28 08:04:44 --> Config Class Initialized
INFO - 2023-03-28 08:04:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:04:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:04:44 --> Utf8 Class Initialized
INFO - 2023-03-28 08:04:44 --> URI Class Initialized
INFO - 2023-03-28 08:04:44 --> Router Class Initialized
INFO - 2023-03-28 08:04:44 --> Output Class Initialized
INFO - 2023-03-28 08:04:44 --> Security Class Initialized
DEBUG - 2023-03-28 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:04:44 --> Input Class Initialized
INFO - 2023-03-28 08:04:44 --> Language Class Initialized
INFO - 2023-03-28 08:04:44 --> Language Class Initialized
INFO - 2023-03-28 08:04:44 --> Config Class Initialized
INFO - 2023-03-28 08:04:44 --> Loader Class Initialized
INFO - 2023-03-28 08:04:44 --> Helper loaded: url_helper
INFO - 2023-03-28 08:04:44 --> Helper loaded: file_helper
INFO - 2023-03-28 08:04:44 --> Helper loaded: form_helper
INFO - 2023-03-28 08:04:44 --> Helper loaded: my_helper
INFO - 2023-03-28 08:04:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:04:44 --> Controller Class Initialized
ERROR - 2023-03-28 08:04:44 --> Severity: Notice --> Undefined offset: 32 C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 641
ERROR - 2023-03-28 08:04:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 641
ERROR - 2023-03-28 08:04:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\myraportk13\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 641
DEBUG - 2023-03-28 08:04:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:04:45 --> Final output sent to browser
DEBUG - 2023-03-28 08:04:45 --> Total execution time: 1.3854
INFO - 2023-03-28 08:06:44 --> Config Class Initialized
INFO - 2023-03-28 08:06:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:44 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:44 --> URI Class Initialized
DEBUG - 2023-03-28 08:06:44 --> No URI present. Default controller set.
INFO - 2023-03-28 08:06:44 --> Router Class Initialized
INFO - 2023-03-28 08:06:44 --> Output Class Initialized
INFO - 2023-03-28 08:06:44 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:44 --> Input Class Initialized
INFO - 2023-03-28 08:06:44 --> Language Class Initialized
INFO - 2023-03-28 08:06:44 --> Language Class Initialized
INFO - 2023-03-28 08:06:44 --> Config Class Initialized
INFO - 2023-03-28 08:06:44 --> Loader Class Initialized
INFO - 2023-03-28 08:06:44 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:44 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:44 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:44 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:44 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-03-28 08:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:44 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:44 --> Total execution time: 0.0307
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:45 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:45 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:45 --> URI Class Initialized
INFO - 2023-03-28 08:06:45 --> Router Class Initialized
INFO - 2023-03-28 08:06:45 --> Output Class Initialized
INFO - 2023-03-28 08:06:45 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:45 --> Input Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Loader Class Initialized
INFO - 2023-03-28 08:06:45 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:45 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:45 --> Controller Class Initialized
INFO - 2023-03-28 08:06:45 --> Helper loaded: cookie_helper
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:45 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:45 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:45 --> URI Class Initialized
INFO - 2023-03-28 08:06:45 --> Router Class Initialized
INFO - 2023-03-28 08:06:45 --> Output Class Initialized
INFO - 2023-03-28 08:06:45 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:45 --> Input Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Loader Class Initialized
INFO - 2023-03-28 08:06:45 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:45 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:45 --> Controller Class Initialized
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:45 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:45 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:45 --> URI Class Initialized
INFO - 2023-03-28 08:06:45 --> Router Class Initialized
INFO - 2023-03-28 08:06:45 --> Output Class Initialized
INFO - 2023-03-28 08:06:45 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:45 --> Input Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Language Class Initialized
INFO - 2023-03-28 08:06:45 --> Config Class Initialized
INFO - 2023-03-28 08:06:45 --> Loader Class Initialized
INFO - 2023-03-28 08:06:45 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:45 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:45 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:45 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-28 08:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:45 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:45 --> Total execution time: 0.0454
INFO - 2023-03-28 08:06:49 --> Config Class Initialized
INFO - 2023-03-28 08:06:49 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:49 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:49 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:49 --> URI Class Initialized
INFO - 2023-03-28 08:06:49 --> Router Class Initialized
INFO - 2023-03-28 08:06:49 --> Output Class Initialized
INFO - 2023-03-28 08:06:49 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:49 --> Input Class Initialized
INFO - 2023-03-28 08:06:49 --> Language Class Initialized
INFO - 2023-03-28 08:06:49 --> Language Class Initialized
INFO - 2023-03-28 08:06:49 --> Config Class Initialized
INFO - 2023-03-28 08:06:49 --> Loader Class Initialized
INFO - 2023-03-28 08:06:49 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:49 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:49 --> Controller Class Initialized
INFO - 2023-03-28 08:06:49 --> Helper loaded: cookie_helper
INFO - 2023-03-28 08:06:49 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:49 --> Total execution time: 0.0417
INFO - 2023-03-28 08:06:49 --> Config Class Initialized
INFO - 2023-03-28 08:06:49 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:49 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:49 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:49 --> URI Class Initialized
INFO - 2023-03-28 08:06:49 --> Router Class Initialized
INFO - 2023-03-28 08:06:49 --> Output Class Initialized
INFO - 2023-03-28 08:06:49 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:49 --> Input Class Initialized
INFO - 2023-03-28 08:06:49 --> Language Class Initialized
INFO - 2023-03-28 08:06:49 --> Language Class Initialized
INFO - 2023-03-28 08:06:49 --> Config Class Initialized
INFO - 2023-03-28 08:06:49 --> Loader Class Initialized
INFO - 2023-03-28 08:06:49 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:49 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:49 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:49 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-28 08:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:49 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:49 --> Total execution time: 0.0376
INFO - 2023-03-28 08:06:50 --> Config Class Initialized
INFO - 2023-03-28 08:06:50 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:50 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:50 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:50 --> URI Class Initialized
INFO - 2023-03-28 08:06:50 --> Router Class Initialized
INFO - 2023-03-28 08:06:50 --> Output Class Initialized
INFO - 2023-03-28 08:06:50 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:50 --> Input Class Initialized
INFO - 2023-03-28 08:06:50 --> Language Class Initialized
INFO - 2023-03-28 08:06:50 --> Language Class Initialized
INFO - 2023-03-28 08:06:50 --> Config Class Initialized
INFO - 2023-03-28 08:06:50 --> Loader Class Initialized
INFO - 2023-03-28 08:06:50 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:50 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:50 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:50 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:50 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:50 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 08:06:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:50 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:50 --> Total execution time: 0.0268
INFO - 2023-03-28 08:06:54 --> Config Class Initialized
INFO - 2023-03-28 08:06:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:54 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:54 --> URI Class Initialized
INFO - 2023-03-28 08:06:54 --> Router Class Initialized
INFO - 2023-03-28 08:06:54 --> Output Class Initialized
INFO - 2023-03-28 08:06:54 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:54 --> Input Class Initialized
INFO - 2023-03-28 08:06:54 --> Language Class Initialized
INFO - 2023-03-28 08:06:54 --> Language Class Initialized
INFO - 2023-03-28 08:06:54 --> Config Class Initialized
INFO - 2023-03-28 08:06:54 --> Loader Class Initialized
INFO - 2023-03-28 08:06:54 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:54 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pss/views/list.php
DEBUG - 2023-03-28 08:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:54 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:54 --> Total execution time: 0.0768
INFO - 2023-03-28 08:06:54 --> Config Class Initialized
INFO - 2023-03-28 08:06:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:54 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:54 --> URI Class Initialized
INFO - 2023-03-28 08:06:54 --> Router Class Initialized
INFO - 2023-03-28 08:06:54 --> Output Class Initialized
INFO - 2023-03-28 08:06:54 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:54 --> Input Class Initialized
INFO - 2023-03-28 08:06:54 --> Language Class Initialized
INFO - 2023-03-28 08:06:54 --> Language Class Initialized
INFO - 2023-03-28 08:06:54 --> Config Class Initialized
INFO - 2023-03-28 08:06:54 --> Loader Class Initialized
INFO - 2023-03-28 08:06:54 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:54 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:54 --> Controller Class Initialized
INFO - 2023-03-28 08:06:56 --> Config Class Initialized
INFO - 2023-03-28 08:06:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:56 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:56 --> URI Class Initialized
INFO - 2023-03-28 08:06:56 --> Router Class Initialized
INFO - 2023-03-28 08:06:56 --> Output Class Initialized
INFO - 2023-03-28 08:06:56 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:56 --> Input Class Initialized
INFO - 2023-03-28 08:06:56 --> Language Class Initialized
INFO - 2023-03-28 08:06:56 --> Language Class Initialized
INFO - 2023-03-28 08:06:56 --> Config Class Initialized
INFO - 2023-03-28 08:06:56 --> Loader Class Initialized
INFO - 2023-03-28 08:06:56 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:56 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:56 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:56 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:56 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 08:06:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:56 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:56 --> Total execution time: 0.0254
INFO - 2023-03-28 08:06:59 --> Config Class Initialized
INFO - 2023-03-28 08:06:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:59 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:59 --> URI Class Initialized
INFO - 2023-03-28 08:06:59 --> Router Class Initialized
INFO - 2023-03-28 08:06:59 --> Output Class Initialized
INFO - 2023-03-28 08:06:59 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:59 --> Input Class Initialized
INFO - 2023-03-28 08:06:59 --> Language Class Initialized
INFO - 2023-03-28 08:06:59 --> Language Class Initialized
INFO - 2023-03-28 08:06:59 --> Config Class Initialized
INFO - 2023-03-28 08:06:59 --> Loader Class Initialized
INFO - 2023-03-28 08:06:59 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:59 --> Controller Class Initialized
DEBUG - 2023-03-28 08:06:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-03-28 08:06:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:06:59 --> Final output sent to browser
DEBUG - 2023-03-28 08:06:59 --> Total execution time: 0.0552
INFO - 2023-03-28 08:06:59 --> Config Class Initialized
INFO - 2023-03-28 08:06:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:06:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:06:59 --> Utf8 Class Initialized
INFO - 2023-03-28 08:06:59 --> URI Class Initialized
INFO - 2023-03-28 08:06:59 --> Router Class Initialized
INFO - 2023-03-28 08:06:59 --> Output Class Initialized
INFO - 2023-03-28 08:06:59 --> Security Class Initialized
DEBUG - 2023-03-28 08:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:06:59 --> Input Class Initialized
INFO - 2023-03-28 08:06:59 --> Language Class Initialized
INFO - 2023-03-28 08:06:59 --> Language Class Initialized
INFO - 2023-03-28 08:06:59 --> Config Class Initialized
INFO - 2023-03-28 08:06:59 --> Loader Class Initialized
INFO - 2023-03-28 08:06:59 --> Helper loaded: url_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: file_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: form_helper
INFO - 2023-03-28 08:06:59 --> Helper loaded: my_helper
INFO - 2023-03-28 08:06:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:06:59 --> Controller Class Initialized
INFO - 2023-03-28 08:07:01 --> Config Class Initialized
INFO - 2023-03-28 08:07:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:07:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:07:01 --> Utf8 Class Initialized
INFO - 2023-03-28 08:07:01 --> URI Class Initialized
INFO - 2023-03-28 08:07:01 --> Router Class Initialized
INFO - 2023-03-28 08:07:01 --> Output Class Initialized
INFO - 2023-03-28 08:07:01 --> Security Class Initialized
DEBUG - 2023-03-28 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:07:01 --> Input Class Initialized
INFO - 2023-03-28 08:07:01 --> Language Class Initialized
INFO - 2023-03-28 08:07:01 --> Language Class Initialized
INFO - 2023-03-28 08:07:01 --> Config Class Initialized
INFO - 2023-03-28 08:07:01 --> Loader Class Initialized
INFO - 2023-03-28 08:07:01 --> Helper loaded: url_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: file_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: form_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: my_helper
INFO - 2023-03-28 08:07:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:07:01 --> Controller Class Initialized
INFO - 2023-03-28 08:07:01 --> Final output sent to browser
DEBUG - 2023-03-28 08:07:01 --> Total execution time: 0.0251
INFO - 2023-03-28 08:07:01 --> Config Class Initialized
INFO - 2023-03-28 08:07:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:07:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:07:01 --> Utf8 Class Initialized
INFO - 2023-03-28 08:07:01 --> URI Class Initialized
INFO - 2023-03-28 08:07:01 --> Router Class Initialized
INFO - 2023-03-28 08:07:01 --> Output Class Initialized
INFO - 2023-03-28 08:07:01 --> Security Class Initialized
DEBUG - 2023-03-28 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:07:01 --> Input Class Initialized
INFO - 2023-03-28 08:07:01 --> Language Class Initialized
INFO - 2023-03-28 08:07:01 --> Language Class Initialized
INFO - 2023-03-28 08:07:01 --> Config Class Initialized
INFO - 2023-03-28 08:07:01 --> Loader Class Initialized
INFO - 2023-03-28 08:07:01 --> Helper loaded: url_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: file_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: form_helper
INFO - 2023-03-28 08:07:01 --> Helper loaded: my_helper
INFO - 2023-03-28 08:07:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:07:02 --> Controller Class Initialized
INFO - 2023-03-28 08:07:02 --> Final output sent to browser
DEBUG - 2023-03-28 08:07:02 --> Total execution time: 0.0432
INFO - 2023-03-28 08:07:02 --> Config Class Initialized
INFO - 2023-03-28 08:07:02 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:07:02 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:07:02 --> Utf8 Class Initialized
INFO - 2023-03-28 08:07:02 --> URI Class Initialized
INFO - 2023-03-28 08:07:02 --> Router Class Initialized
INFO - 2023-03-28 08:07:02 --> Output Class Initialized
INFO - 2023-03-28 08:07:02 --> Security Class Initialized
DEBUG - 2023-03-28 08:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:07:02 --> Input Class Initialized
INFO - 2023-03-28 08:07:02 --> Language Class Initialized
INFO - 2023-03-28 08:07:02 --> Language Class Initialized
INFO - 2023-03-28 08:07:02 --> Config Class Initialized
INFO - 2023-03-28 08:07:02 --> Loader Class Initialized
INFO - 2023-03-28 08:07:02 --> Helper loaded: url_helper
INFO - 2023-03-28 08:07:02 --> Helper loaded: file_helper
INFO - 2023-03-28 08:07:02 --> Helper loaded: form_helper
INFO - 2023-03-28 08:07:02 --> Helper loaded: my_helper
INFO - 2023-03-28 08:07:02 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:07:02 --> Controller Class Initialized
DEBUG - 2023-03-28 08:07:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 08:07:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:07:02 --> Final output sent to browser
DEBUG - 2023-03-28 08:07:02 --> Total execution time: 0.0271
INFO - 2023-03-28 08:15:52 --> Config Class Initialized
INFO - 2023-03-28 08:15:52 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:15:52 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:15:52 --> Utf8 Class Initialized
INFO - 2023-03-28 08:15:52 --> URI Class Initialized
INFO - 2023-03-28 08:15:52 --> Router Class Initialized
INFO - 2023-03-28 08:15:52 --> Output Class Initialized
INFO - 2023-03-28 08:15:52 --> Security Class Initialized
DEBUG - 2023-03-28 08:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:15:52 --> Input Class Initialized
INFO - 2023-03-28 08:15:52 --> Language Class Initialized
INFO - 2023-03-28 08:15:52 --> Language Class Initialized
INFO - 2023-03-28 08:15:52 --> Config Class Initialized
INFO - 2023-03-28 08:15:52 --> Loader Class Initialized
INFO - 2023-03-28 08:15:52 --> Helper loaded: url_helper
INFO - 2023-03-28 08:15:52 --> Helper loaded: file_helper
INFO - 2023-03-28 08:15:52 --> Helper loaded: form_helper
INFO - 2023-03-28 08:15:52 --> Helper loaded: my_helper
INFO - 2023-03-28 08:15:52 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:15:52 --> Controller Class Initialized
DEBUG - 2023-03-28 08:15:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 08:15:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:15:52 --> Final output sent to browser
DEBUG - 2023-03-28 08:15:52 --> Total execution time: 0.0459
INFO - 2023-03-28 08:15:54 --> Config Class Initialized
INFO - 2023-03-28 08:15:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:15:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:15:54 --> Utf8 Class Initialized
INFO - 2023-03-28 08:15:54 --> URI Class Initialized
INFO - 2023-03-28 08:15:54 --> Router Class Initialized
INFO - 2023-03-28 08:15:54 --> Output Class Initialized
INFO - 2023-03-28 08:15:54 --> Security Class Initialized
DEBUG - 2023-03-28 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:15:54 --> Input Class Initialized
INFO - 2023-03-28 08:15:54 --> Language Class Initialized
INFO - 2023-03-28 08:15:54 --> Language Class Initialized
INFO - 2023-03-28 08:15:54 --> Config Class Initialized
INFO - 2023-03-28 08:15:54 --> Loader Class Initialized
INFO - 2023-03-28 08:15:54 --> Helper loaded: url_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: file_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: form_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: my_helper
INFO - 2023-03-28 08:15:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:15:54 --> Controller Class Initialized
DEBUG - 2023-03-28 08:15:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-03-28 08:15:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:15:54 --> Final output sent to browser
DEBUG - 2023-03-28 08:15:54 --> Total execution time: 0.0365
INFO - 2023-03-28 08:15:54 --> Config Class Initialized
INFO - 2023-03-28 08:15:54 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:15:54 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:15:54 --> Utf8 Class Initialized
INFO - 2023-03-28 08:15:54 --> URI Class Initialized
INFO - 2023-03-28 08:15:54 --> Router Class Initialized
INFO - 2023-03-28 08:15:54 --> Output Class Initialized
INFO - 2023-03-28 08:15:54 --> Security Class Initialized
DEBUG - 2023-03-28 08:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:15:54 --> Input Class Initialized
INFO - 2023-03-28 08:15:54 --> Language Class Initialized
INFO - 2023-03-28 08:15:54 --> Language Class Initialized
INFO - 2023-03-28 08:15:54 --> Config Class Initialized
INFO - 2023-03-28 08:15:54 --> Loader Class Initialized
INFO - 2023-03-28 08:15:54 --> Helper loaded: url_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: file_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: form_helper
INFO - 2023-03-28 08:15:54 --> Helper loaded: my_helper
INFO - 2023-03-28 08:15:54 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:15:54 --> Controller Class Initialized
INFO - 2023-03-28 08:15:56 --> Config Class Initialized
INFO - 2023-03-28 08:15:56 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:15:56 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:15:56 --> Utf8 Class Initialized
INFO - 2023-03-28 08:15:56 --> URI Class Initialized
INFO - 2023-03-28 08:15:56 --> Router Class Initialized
INFO - 2023-03-28 08:15:56 --> Output Class Initialized
INFO - 2023-03-28 08:15:56 --> Security Class Initialized
DEBUG - 2023-03-28 08:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:15:56 --> Input Class Initialized
INFO - 2023-03-28 08:15:56 --> Language Class Initialized
INFO - 2023-03-28 08:15:56 --> Language Class Initialized
INFO - 2023-03-28 08:15:56 --> Config Class Initialized
INFO - 2023-03-28 08:15:56 --> Loader Class Initialized
INFO - 2023-03-28 08:15:56 --> Helper loaded: url_helper
INFO - 2023-03-28 08:15:56 --> Helper loaded: file_helper
INFO - 2023-03-28 08:15:56 --> Helper loaded: form_helper
INFO - 2023-03-28 08:15:56 --> Helper loaded: my_helper
INFO - 2023-03-28 08:15:56 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:15:56 --> Controller Class Initialized
DEBUG - 2023-03-28 08:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-28 08:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:15:56 --> Final output sent to browser
DEBUG - 2023-03-28 08:15:56 --> Total execution time: 0.0436
INFO - 2023-03-28 08:16:00 --> Config Class Initialized
INFO - 2023-03-28 08:16:00 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:00 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:00 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:00 --> URI Class Initialized
INFO - 2023-03-28 08:16:00 --> Router Class Initialized
INFO - 2023-03-28 08:16:00 --> Output Class Initialized
INFO - 2023-03-28 08:16:00 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:00 --> Input Class Initialized
INFO - 2023-03-28 08:16:00 --> Language Class Initialized
INFO - 2023-03-28 08:16:00 --> Language Class Initialized
INFO - 2023-03-28 08:16:00 --> Config Class Initialized
INFO - 2023-03-28 08:16:00 --> Loader Class Initialized
INFO - 2023-03-28 08:16:00 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:00 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:00 --> Controller Class Initialized
DEBUG - 2023-03-28 08:16:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pss/views/list.php
DEBUG - 2023-03-28 08:16:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:16:00 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:00 --> Total execution time: 0.0468
INFO - 2023-03-28 08:16:00 --> Config Class Initialized
INFO - 2023-03-28 08:16:00 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:00 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:00 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:00 --> URI Class Initialized
INFO - 2023-03-28 08:16:00 --> Router Class Initialized
INFO - 2023-03-28 08:16:00 --> Output Class Initialized
INFO - 2023-03-28 08:16:00 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:00 --> Input Class Initialized
INFO - 2023-03-28 08:16:00 --> Language Class Initialized
INFO - 2023-03-28 08:16:00 --> Language Class Initialized
INFO - 2023-03-28 08:16:00 --> Config Class Initialized
INFO - 2023-03-28 08:16:00 --> Loader Class Initialized
INFO - 2023-03-28 08:16:00 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:00 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:00 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:00 --> Controller Class Initialized
INFO - 2023-03-28 08:16:07 --> Config Class Initialized
INFO - 2023-03-28 08:16:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:07 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:07 --> URI Class Initialized
INFO - 2023-03-28 08:16:07 --> Router Class Initialized
INFO - 2023-03-28 08:16:07 --> Output Class Initialized
INFO - 2023-03-28 08:16:07 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:07 --> Input Class Initialized
INFO - 2023-03-28 08:16:07 --> Language Class Initialized
INFO - 2023-03-28 08:16:07 --> Language Class Initialized
INFO - 2023-03-28 08:16:07 --> Config Class Initialized
INFO - 2023-03-28 08:16:07 --> Loader Class Initialized
INFO - 2023-03-28 08:16:07 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:07 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:07 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:07 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:07 --> Controller Class Initialized
INFO - 2023-03-28 08:16:07 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:07 --> Total execution time: 0.0277
INFO - 2023-03-28 08:16:10 --> Config Class Initialized
INFO - 2023-03-28 08:16:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:10 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:10 --> URI Class Initialized
INFO - 2023-03-28 08:16:10 --> Router Class Initialized
INFO - 2023-03-28 08:16:10 --> Output Class Initialized
INFO - 2023-03-28 08:16:10 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:10 --> Input Class Initialized
INFO - 2023-03-28 08:16:10 --> Language Class Initialized
INFO - 2023-03-28 08:16:10 --> Language Class Initialized
INFO - 2023-03-28 08:16:10 --> Config Class Initialized
INFO - 2023-03-28 08:16:10 --> Loader Class Initialized
INFO - 2023-03-28 08:16:10 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:10 --> Controller Class Initialized
INFO - 2023-03-28 08:16:10 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:10 --> Total execution time: 0.0257
INFO - 2023-03-28 08:16:10 --> Config Class Initialized
INFO - 2023-03-28 08:16:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:10 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:10 --> URI Class Initialized
INFO - 2023-03-28 08:16:10 --> Router Class Initialized
INFO - 2023-03-28 08:16:10 --> Output Class Initialized
INFO - 2023-03-28 08:16:10 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:10 --> Input Class Initialized
INFO - 2023-03-28 08:16:10 --> Language Class Initialized
INFO - 2023-03-28 08:16:10 --> Language Class Initialized
INFO - 2023-03-28 08:16:10 --> Config Class Initialized
INFO - 2023-03-28 08:16:10 --> Loader Class Initialized
INFO - 2023-03-28 08:16:10 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:10 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:10 --> Controller Class Initialized
INFO - 2023-03-28 08:16:11 --> Config Class Initialized
INFO - 2023-03-28 08:16:11 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:11 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:11 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:11 --> URI Class Initialized
INFO - 2023-03-28 08:16:11 --> Router Class Initialized
INFO - 2023-03-28 08:16:11 --> Output Class Initialized
INFO - 2023-03-28 08:16:11 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:11 --> Input Class Initialized
INFO - 2023-03-28 08:16:11 --> Language Class Initialized
INFO - 2023-03-28 08:16:11 --> Language Class Initialized
INFO - 2023-03-28 08:16:11 --> Config Class Initialized
INFO - 2023-03-28 08:16:11 --> Loader Class Initialized
INFO - 2023-03-28 08:16:11 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:11 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:11 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:11 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:11 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:11 --> Controller Class Initialized
INFO - 2023-03-28 08:16:11 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:11 --> Total execution time: 0.0350
INFO - 2023-03-28 08:16:15 --> Config Class Initialized
INFO - 2023-03-28 08:16:15 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:15 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:15 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:15 --> URI Class Initialized
INFO - 2023-03-28 08:16:15 --> Router Class Initialized
INFO - 2023-03-28 08:16:15 --> Output Class Initialized
INFO - 2023-03-28 08:16:15 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:15 --> Input Class Initialized
INFO - 2023-03-28 08:16:15 --> Language Class Initialized
INFO - 2023-03-28 08:16:15 --> Language Class Initialized
INFO - 2023-03-28 08:16:15 --> Config Class Initialized
INFO - 2023-03-28 08:16:15 --> Loader Class Initialized
INFO - 2023-03-28 08:16:15 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:15 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:15 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:15 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:15 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:15 --> Controller Class Initialized
INFO - 2023-03-28 08:16:15 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:15 --> Total execution time: 0.0513
INFO - 2023-03-28 08:16:18 --> Config Class Initialized
INFO - 2023-03-28 08:16:18 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:16:18 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:16:18 --> Utf8 Class Initialized
INFO - 2023-03-28 08:16:18 --> URI Class Initialized
INFO - 2023-03-28 08:16:18 --> Router Class Initialized
INFO - 2023-03-28 08:16:18 --> Output Class Initialized
INFO - 2023-03-28 08:16:18 --> Security Class Initialized
DEBUG - 2023-03-28 08:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:16:18 --> Input Class Initialized
INFO - 2023-03-28 08:16:18 --> Language Class Initialized
INFO - 2023-03-28 08:16:18 --> Language Class Initialized
INFO - 2023-03-28 08:16:18 --> Config Class Initialized
INFO - 2023-03-28 08:16:18 --> Loader Class Initialized
INFO - 2023-03-28 08:16:18 --> Helper loaded: url_helper
INFO - 2023-03-28 08:16:18 --> Helper loaded: file_helper
INFO - 2023-03-28 08:16:18 --> Helper loaded: form_helper
INFO - 2023-03-28 08:16:18 --> Helper loaded: my_helper
INFO - 2023-03-28 08:16:18 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:16:18 --> Controller Class Initialized
DEBUG - 2023-03-28 08:16:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:16:19 --> Final output sent to browser
DEBUG - 2023-03-28 08:16:19 --> Total execution time: 1.2380
INFO - 2023-03-28 08:30:48 --> Config Class Initialized
INFO - 2023-03-28 08:30:48 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:30:48 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:30:48 --> Utf8 Class Initialized
INFO - 2023-03-28 08:30:48 --> URI Class Initialized
INFO - 2023-03-28 08:30:48 --> Router Class Initialized
INFO - 2023-03-28 08:30:48 --> Output Class Initialized
INFO - 2023-03-28 08:30:48 --> Security Class Initialized
DEBUG - 2023-03-28 08:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:30:48 --> Input Class Initialized
INFO - 2023-03-28 08:30:48 --> Language Class Initialized
INFO - 2023-03-28 08:30:48 --> Language Class Initialized
INFO - 2023-03-28 08:30:48 --> Config Class Initialized
INFO - 2023-03-28 08:30:48 --> Loader Class Initialized
INFO - 2023-03-28 08:30:48 --> Helper loaded: url_helper
INFO - 2023-03-28 08:30:48 --> Helper loaded: file_helper
INFO - 2023-03-28 08:30:48 --> Helper loaded: form_helper
INFO - 2023-03-28 08:30:48 --> Helper loaded: my_helper
INFO - 2023-03-28 08:30:48 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:30:48 --> Controller Class Initialized
DEBUG - 2023-03-28 08:30:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 08:30:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:30:48 --> Final output sent to browser
DEBUG - 2023-03-28 08:30:48 --> Total execution time: 0.0385
INFO - 2023-03-28 08:30:50 --> Config Class Initialized
INFO - 2023-03-28 08:30:50 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:30:50 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:30:50 --> Utf8 Class Initialized
INFO - 2023-03-28 08:30:50 --> URI Class Initialized
INFO - 2023-03-28 08:30:50 --> Router Class Initialized
INFO - 2023-03-28 08:30:50 --> Output Class Initialized
INFO - 2023-03-28 08:30:50 --> Security Class Initialized
DEBUG - 2023-03-28 08:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:30:50 --> Input Class Initialized
INFO - 2023-03-28 08:30:50 --> Language Class Initialized
INFO - 2023-03-28 08:30:50 --> Language Class Initialized
INFO - 2023-03-28 08:30:50 --> Config Class Initialized
INFO - 2023-03-28 08:30:50 --> Loader Class Initialized
INFO - 2023-03-28 08:30:50 --> Helper loaded: url_helper
INFO - 2023-03-28 08:30:50 --> Helper loaded: file_helper
INFO - 2023-03-28 08:30:50 --> Helper loaded: form_helper
INFO - 2023-03-28 08:30:50 --> Helper loaded: my_helper
INFO - 2023-03-28 08:30:50 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:30:50 --> Controller Class Initialized
DEBUG - 2023-03-28 08:30:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 08:30:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:30:50 --> Final output sent to browser
DEBUG - 2023-03-28 08:30:50 --> Total execution time: 0.0274
INFO - 2023-03-28 08:42:07 --> Config Class Initialized
INFO - 2023-03-28 08:42:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:42:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:42:07 --> Utf8 Class Initialized
INFO - 2023-03-28 08:42:07 --> URI Class Initialized
INFO - 2023-03-28 08:42:07 --> Router Class Initialized
INFO - 2023-03-28 08:42:07 --> Output Class Initialized
INFO - 2023-03-28 08:42:07 --> Security Class Initialized
DEBUG - 2023-03-28 08:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:42:07 --> Input Class Initialized
INFO - 2023-03-28 08:42:07 --> Language Class Initialized
INFO - 2023-03-28 08:42:07 --> Language Class Initialized
INFO - 2023-03-28 08:42:07 --> Config Class Initialized
INFO - 2023-03-28 08:42:07 --> Loader Class Initialized
INFO - 2023-03-28 08:42:07 --> Helper loaded: url_helper
INFO - 2023-03-28 08:42:07 --> Helper loaded: file_helper
INFO - 2023-03-28 08:42:07 --> Helper loaded: form_helper
INFO - 2023-03-28 08:42:07 --> Helper loaded: my_helper
INFO - 2023-03-28 08:42:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:42:07 --> Controller Class Initialized
DEBUG - 2023-03-28 08:42:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-03-28 08:42:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:42:07 --> Final output sent to browser
DEBUG - 2023-03-28 08:42:07 --> Total execution time: 0.0311
INFO - 2023-03-28 08:42:08 --> Config Class Initialized
INFO - 2023-03-28 08:42:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:42:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:42:08 --> Utf8 Class Initialized
INFO - 2023-03-28 08:42:08 --> URI Class Initialized
INFO - 2023-03-28 08:42:08 --> Router Class Initialized
INFO - 2023-03-28 08:42:08 --> Output Class Initialized
INFO - 2023-03-28 08:42:08 --> Security Class Initialized
DEBUG - 2023-03-28 08:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:42:08 --> Input Class Initialized
INFO - 2023-03-28 08:42:08 --> Language Class Initialized
ERROR - 2023-03-28 08:42:08 --> 404 Page Not Found: ../modules/n_catatan_homeroom/controllers/N_catatan_homeroom/index
INFO - 2023-03-28 08:43:05 --> Config Class Initialized
INFO - 2023-03-28 08:43:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:43:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:43:05 --> Utf8 Class Initialized
INFO - 2023-03-28 08:43:05 --> URI Class Initialized
INFO - 2023-03-28 08:43:05 --> Router Class Initialized
INFO - 2023-03-28 08:43:05 --> Output Class Initialized
INFO - 2023-03-28 08:43:05 --> Security Class Initialized
DEBUG - 2023-03-28 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:43:05 --> Input Class Initialized
INFO - 2023-03-28 08:43:05 --> Language Class Initialized
ERROR - 2023-03-28 08:43:05 --> 404 Page Not Found: ../modules/n_catatan_homeroom/controllers/N_catatan_homeroom/index
INFO - 2023-03-28 08:43:05 --> Config Class Initialized
INFO - 2023-03-28 08:43:05 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:43:05 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:43:05 --> Utf8 Class Initialized
INFO - 2023-03-28 08:43:05 --> URI Class Initialized
INFO - 2023-03-28 08:43:05 --> Router Class Initialized
INFO - 2023-03-28 08:43:05 --> Output Class Initialized
INFO - 2023-03-28 08:43:05 --> Security Class Initialized
DEBUG - 2023-03-28 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:43:05 --> Input Class Initialized
INFO - 2023-03-28 08:43:05 --> Language Class Initialized
ERROR - 2023-03-28 08:43:05 --> 404 Page Not Found: ../modules/n_catatan_homeroom/controllers/N_catatan_homeroom/index
INFO - 2023-03-28 08:44:07 --> Config Class Initialized
INFO - 2023-03-28 08:44:07 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:44:07 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:44:07 --> Utf8 Class Initialized
INFO - 2023-03-28 08:44:07 --> URI Class Initialized
INFO - 2023-03-28 08:44:07 --> Router Class Initialized
INFO - 2023-03-28 08:44:07 --> Output Class Initialized
INFO - 2023-03-28 08:44:07 --> Security Class Initialized
DEBUG - 2023-03-28 08:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:44:07 --> Input Class Initialized
INFO - 2023-03-28 08:44:07 --> Language Class Initialized
INFO - 2023-03-28 08:44:07 --> Language Class Initialized
INFO - 2023-03-28 08:44:07 --> Config Class Initialized
INFO - 2023-03-28 08:44:07 --> Loader Class Initialized
INFO - 2023-03-28 08:44:07 --> Helper loaded: url_helper
INFO - 2023-03-28 08:44:07 --> Helper loaded: file_helper
INFO - 2023-03-28 08:44:07 --> Helper loaded: form_helper
INFO - 2023-03-28 08:44:07 --> Helper loaded: my_helper
INFO - 2023-03-28 08:44:07 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:44:07 --> Controller Class Initialized
ERROR - 2023-03-28 08:44:07 --> Query error: Unknown column 'a.naik' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.naik, a.catatan_mid, a.catatan_final
                                                    FROM t_catatan_homeroom a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2023','8',b.id)
                                                    WHERE c.id_kelas = '8' AND a.ta = '20232'
INFO - 2023-03-28 08:44:07 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-28 08:45:01 --> Config Class Initialized
INFO - 2023-03-28 08:45:01 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:45:01 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:45:01 --> Utf8 Class Initialized
INFO - 2023-03-28 08:45:01 --> URI Class Initialized
INFO - 2023-03-28 08:45:01 --> Router Class Initialized
INFO - 2023-03-28 08:45:01 --> Output Class Initialized
INFO - 2023-03-28 08:45:01 --> Security Class Initialized
DEBUG - 2023-03-28 08:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:45:01 --> Input Class Initialized
INFO - 2023-03-28 08:45:01 --> Language Class Initialized
INFO - 2023-03-28 08:45:01 --> Language Class Initialized
INFO - 2023-03-28 08:45:01 --> Config Class Initialized
INFO - 2023-03-28 08:45:01 --> Loader Class Initialized
INFO - 2023-03-28 08:45:01 --> Helper loaded: url_helper
INFO - 2023-03-28 08:45:01 --> Helper loaded: file_helper
INFO - 2023-03-28 08:45:01 --> Helper loaded: form_helper
INFO - 2023-03-28 08:45:01 --> Helper loaded: my_helper
INFO - 2023-03-28 08:45:01 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:45:01 --> Controller Class Initialized
DEBUG - 2023-03-28 08:45:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:45:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:45:01 --> Final output sent to browser
DEBUG - 2023-03-28 08:45:01 --> Total execution time: 0.0491
INFO - 2023-03-28 08:45:31 --> Config Class Initialized
INFO - 2023-03-28 08:45:31 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:45:31 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:45:31 --> Utf8 Class Initialized
INFO - 2023-03-28 08:45:31 --> URI Class Initialized
INFO - 2023-03-28 08:45:31 --> Router Class Initialized
INFO - 2023-03-28 08:45:31 --> Output Class Initialized
INFO - 2023-03-28 08:45:31 --> Security Class Initialized
DEBUG - 2023-03-28 08:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:45:31 --> Input Class Initialized
INFO - 2023-03-28 08:45:31 --> Language Class Initialized
INFO - 2023-03-28 08:45:31 --> Language Class Initialized
INFO - 2023-03-28 08:45:31 --> Config Class Initialized
INFO - 2023-03-28 08:45:31 --> Loader Class Initialized
INFO - 2023-03-28 08:45:31 --> Helper loaded: url_helper
INFO - 2023-03-28 08:45:31 --> Helper loaded: file_helper
INFO - 2023-03-28 08:45:31 --> Helper loaded: form_helper
INFO - 2023-03-28 08:45:31 --> Helper loaded: my_helper
INFO - 2023-03-28 08:45:31 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:45:31 --> Controller Class Initialized
DEBUG - 2023-03-28 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:45:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:45:31 --> Final output sent to browser
DEBUG - 2023-03-28 08:45:31 --> Total execution time: 0.0399
INFO - 2023-03-28 08:45:49 --> Config Class Initialized
INFO - 2023-03-28 08:45:49 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:45:49 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:45:49 --> Utf8 Class Initialized
INFO - 2023-03-28 08:45:49 --> URI Class Initialized
INFO - 2023-03-28 08:45:49 --> Router Class Initialized
INFO - 2023-03-28 08:45:49 --> Output Class Initialized
INFO - 2023-03-28 08:45:49 --> Security Class Initialized
DEBUG - 2023-03-28 08:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:45:49 --> Input Class Initialized
INFO - 2023-03-28 08:45:49 --> Language Class Initialized
INFO - 2023-03-28 08:45:49 --> Language Class Initialized
INFO - 2023-03-28 08:45:49 --> Config Class Initialized
INFO - 2023-03-28 08:45:49 --> Loader Class Initialized
INFO - 2023-03-28 08:45:49 --> Helper loaded: url_helper
INFO - 2023-03-28 08:45:49 --> Helper loaded: file_helper
INFO - 2023-03-28 08:45:49 --> Helper loaded: form_helper
INFO - 2023-03-28 08:45:49 --> Helper loaded: my_helper
INFO - 2023-03-28 08:45:49 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:45:49 --> Controller Class Initialized
DEBUG - 2023-03-28 08:45:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:45:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:45:49 --> Final output sent to browser
DEBUG - 2023-03-28 08:45:49 --> Total execution time: 0.0280
INFO - 2023-03-28 08:45:59 --> Config Class Initialized
INFO - 2023-03-28 08:45:59 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:45:59 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:45:59 --> Utf8 Class Initialized
INFO - 2023-03-28 08:45:59 --> URI Class Initialized
INFO - 2023-03-28 08:45:59 --> Router Class Initialized
INFO - 2023-03-28 08:45:59 --> Output Class Initialized
INFO - 2023-03-28 08:45:59 --> Security Class Initialized
DEBUG - 2023-03-28 08:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:45:59 --> Input Class Initialized
INFO - 2023-03-28 08:45:59 --> Language Class Initialized
INFO - 2023-03-28 08:45:59 --> Language Class Initialized
INFO - 2023-03-28 08:45:59 --> Config Class Initialized
INFO - 2023-03-28 08:45:59 --> Loader Class Initialized
INFO - 2023-03-28 08:45:59 --> Helper loaded: url_helper
INFO - 2023-03-28 08:45:59 --> Helper loaded: file_helper
INFO - 2023-03-28 08:45:59 --> Helper loaded: form_helper
INFO - 2023-03-28 08:45:59 --> Helper loaded: my_helper
INFO - 2023-03-28 08:45:59 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:45:59 --> Controller Class Initialized
ERROR - 2023-03-28 08:45:59 --> Severity: Notice --> Undefined variable: naik C:\xampp\htdocs\myraportk13\application\modules\n_catatan_homeroom\controllers\N_catatan_homeroom.php 37
ERROR - 2023-03-28 08:45:59 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO t_catatan_homeroom (id_siswa,ta,catatan_mid,catatan_final) VALUES ('531','20232','','-','-')
INFO - 2023-03-28 08:45:59 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-28 08:46:04 --> Config Class Initialized
INFO - 2023-03-28 08:46:04 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:46:04 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:46:04 --> Utf8 Class Initialized
INFO - 2023-03-28 08:46:04 --> URI Class Initialized
INFO - 2023-03-28 08:46:04 --> Router Class Initialized
INFO - 2023-03-28 08:46:04 --> Output Class Initialized
INFO - 2023-03-28 08:46:04 --> Security Class Initialized
DEBUG - 2023-03-28 08:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:46:04 --> Input Class Initialized
INFO - 2023-03-28 08:46:04 --> Language Class Initialized
ERROR - 2023-03-28 08:46:04 --> 404 Page Not Found: /index
INFO - 2023-03-28 08:46:10 --> Config Class Initialized
INFO - 2023-03-28 08:46:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:46:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:46:10 --> Utf8 Class Initialized
INFO - 2023-03-28 08:46:10 --> URI Class Initialized
INFO - 2023-03-28 08:46:10 --> Router Class Initialized
INFO - 2023-03-28 08:46:10 --> Output Class Initialized
INFO - 2023-03-28 08:46:10 --> Security Class Initialized
DEBUG - 2023-03-28 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:46:10 --> Input Class Initialized
INFO - 2023-03-28 08:46:10 --> Language Class Initialized
INFO - 2023-03-28 08:46:10 --> Language Class Initialized
INFO - 2023-03-28 08:46:10 --> Config Class Initialized
INFO - 2023-03-28 08:46:10 --> Loader Class Initialized
INFO - 2023-03-28 08:46:10 --> Helper loaded: url_helper
INFO - 2023-03-28 08:46:10 --> Helper loaded: file_helper
INFO - 2023-03-28 08:46:10 --> Helper loaded: form_helper
INFO - 2023-03-28 08:46:10 --> Helper loaded: my_helper
INFO - 2023-03-28 08:46:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:46:10 --> Controller Class Initialized
DEBUG - 2023-03-28 08:46:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:46:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:46:10 --> Final output sent to browser
DEBUG - 2023-03-28 08:46:10 --> Total execution time: 0.0308
INFO - 2023-03-28 08:46:10 --> Config Class Initialized
INFO - 2023-03-28 08:46:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:46:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:46:10 --> Utf8 Class Initialized
INFO - 2023-03-28 08:46:10 --> URI Class Initialized
INFO - 2023-03-28 08:46:10 --> Router Class Initialized
INFO - 2023-03-28 08:46:10 --> Output Class Initialized
INFO - 2023-03-28 08:46:10 --> Security Class Initialized
DEBUG - 2023-03-28 08:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:46:10 --> Input Class Initialized
INFO - 2023-03-28 08:46:10 --> Language Class Initialized
ERROR - 2023-03-28 08:46:10 --> 404 Page Not Found: /index
INFO - 2023-03-28 08:46:15 --> Config Class Initialized
INFO - 2023-03-28 08:46:15 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:46:15 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:46:15 --> Utf8 Class Initialized
INFO - 2023-03-28 08:46:15 --> URI Class Initialized
INFO - 2023-03-28 08:46:15 --> Router Class Initialized
INFO - 2023-03-28 08:46:15 --> Output Class Initialized
INFO - 2023-03-28 08:46:15 --> Security Class Initialized
DEBUG - 2023-03-28 08:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:46:15 --> Input Class Initialized
INFO - 2023-03-28 08:46:15 --> Language Class Initialized
INFO - 2023-03-28 08:46:15 --> Language Class Initialized
INFO - 2023-03-28 08:46:15 --> Config Class Initialized
INFO - 2023-03-28 08:46:15 --> Loader Class Initialized
INFO - 2023-03-28 08:46:15 --> Helper loaded: url_helper
INFO - 2023-03-28 08:46:15 --> Helper loaded: file_helper
INFO - 2023-03-28 08:46:15 --> Helper loaded: form_helper
INFO - 2023-03-28 08:46:15 --> Helper loaded: my_helper
INFO - 2023-03-28 08:46:15 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:46:15 --> Controller Class Initialized
ERROR - 2023-03-28 08:46:15 --> Severity: Notice --> Undefined variable: naik C:\xampp\htdocs\myraportk13\application\modules\n_catatan_homeroom\controllers\N_catatan_homeroom.php 37
ERROR - 2023-03-28 08:46:15 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT INTO t_catatan_homeroom (id_siswa,ta,catatan_mid,catatan_final) VALUES ('531','20232','','-','-')
INFO - 2023-03-28 08:46:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-03-28 08:47:08 --> Config Class Initialized
INFO - 2023-03-28 08:47:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:47:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:47:08 --> Utf8 Class Initialized
INFO - 2023-03-28 08:47:08 --> URI Class Initialized
INFO - 2023-03-28 08:47:08 --> Router Class Initialized
INFO - 2023-03-28 08:47:08 --> Output Class Initialized
INFO - 2023-03-28 08:47:08 --> Security Class Initialized
DEBUG - 2023-03-28 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:47:08 --> Input Class Initialized
INFO - 2023-03-28 08:47:08 --> Language Class Initialized
INFO - 2023-03-28 08:47:08 --> Language Class Initialized
INFO - 2023-03-28 08:47:08 --> Config Class Initialized
INFO - 2023-03-28 08:47:08 --> Loader Class Initialized
INFO - 2023-03-28 08:47:08 --> Helper loaded: url_helper
INFO - 2023-03-28 08:47:08 --> Helper loaded: file_helper
INFO - 2023-03-28 08:47:08 --> Helper loaded: form_helper
INFO - 2023-03-28 08:47:08 --> Helper loaded: my_helper
INFO - 2023-03-28 08:47:08 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:47:08 --> Controller Class Initialized
DEBUG - 2023-03-28 08:47:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:47:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:47:08 --> Final output sent to browser
DEBUG - 2023-03-28 08:47:08 --> Total execution time: 0.0394
INFO - 2023-03-28 08:47:08 --> Config Class Initialized
INFO - 2023-03-28 08:47:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:47:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:47:08 --> Utf8 Class Initialized
INFO - 2023-03-28 08:47:08 --> URI Class Initialized
INFO - 2023-03-28 08:47:08 --> Router Class Initialized
INFO - 2023-03-28 08:47:08 --> Output Class Initialized
INFO - 2023-03-28 08:47:08 --> Security Class Initialized
DEBUG - 2023-03-28 08:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:47:08 --> Input Class Initialized
INFO - 2023-03-28 08:47:08 --> Language Class Initialized
ERROR - 2023-03-28 08:47:08 --> 404 Page Not Found: /index
INFO - 2023-03-28 08:47:10 --> Config Class Initialized
INFO - 2023-03-28 08:47:10 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:47:10 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:47:10 --> Utf8 Class Initialized
INFO - 2023-03-28 08:47:10 --> URI Class Initialized
INFO - 2023-03-28 08:47:10 --> Router Class Initialized
INFO - 2023-03-28 08:47:10 --> Output Class Initialized
INFO - 2023-03-28 08:47:10 --> Security Class Initialized
DEBUG - 2023-03-28 08:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:47:10 --> Input Class Initialized
INFO - 2023-03-28 08:47:10 --> Language Class Initialized
INFO - 2023-03-28 08:47:10 --> Language Class Initialized
INFO - 2023-03-28 08:47:10 --> Config Class Initialized
INFO - 2023-03-28 08:47:10 --> Loader Class Initialized
INFO - 2023-03-28 08:47:10 --> Helper loaded: url_helper
INFO - 2023-03-28 08:47:10 --> Helper loaded: file_helper
INFO - 2023-03-28 08:47:10 --> Helper loaded: form_helper
INFO - 2023-03-28 08:47:10 --> Helper loaded: my_helper
INFO - 2023-03-28 08:47:10 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:47:10 --> Controller Class Initialized
INFO - 2023-03-28 08:47:10 --> Final output sent to browser
DEBUG - 2023-03-28 08:47:10 --> Total execution time: 0.0326
INFO - 2023-03-28 08:47:12 --> Config Class Initialized
INFO - 2023-03-28 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:47:12 --> Utf8 Class Initialized
INFO - 2023-03-28 08:47:12 --> URI Class Initialized
INFO - 2023-03-28 08:47:12 --> Router Class Initialized
INFO - 2023-03-28 08:47:12 --> Output Class Initialized
INFO - 2023-03-28 08:47:12 --> Security Class Initialized
DEBUG - 2023-03-28 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:47:12 --> Input Class Initialized
INFO - 2023-03-28 08:47:12 --> Language Class Initialized
INFO - 2023-03-28 08:47:12 --> Language Class Initialized
INFO - 2023-03-28 08:47:12 --> Config Class Initialized
INFO - 2023-03-28 08:47:12 --> Loader Class Initialized
INFO - 2023-03-28 08:47:12 --> Helper loaded: url_helper
INFO - 2023-03-28 08:47:12 --> Helper loaded: file_helper
INFO - 2023-03-28 08:47:12 --> Helper loaded: form_helper
INFO - 2023-03-28 08:47:12 --> Helper loaded: my_helper
INFO - 2023-03-28 08:47:12 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:47:12 --> Controller Class Initialized
DEBUG - 2023-03-28 08:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-03-28 08:47:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 08:47:12 --> Final output sent to browser
DEBUG - 2023-03-28 08:47:12 --> Total execution time: 0.0355
INFO - 2023-03-28 08:47:12 --> Config Class Initialized
INFO - 2023-03-28 08:47:12 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:47:12 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:47:12 --> Utf8 Class Initialized
INFO - 2023-03-28 08:47:12 --> URI Class Initialized
INFO - 2023-03-28 08:47:12 --> Router Class Initialized
INFO - 2023-03-28 08:47:12 --> Output Class Initialized
INFO - 2023-03-28 08:47:12 --> Security Class Initialized
DEBUG - 2023-03-28 08:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:47:12 --> Input Class Initialized
INFO - 2023-03-28 08:47:12 --> Language Class Initialized
ERROR - 2023-03-28 08:47:12 --> 404 Page Not Found: /index
INFO - 2023-03-28 08:56:08 --> Config Class Initialized
INFO - 2023-03-28 08:56:08 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:56:08 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:56:09 --> Utf8 Class Initialized
INFO - 2023-03-28 08:56:09 --> URI Class Initialized
INFO - 2023-03-28 08:56:09 --> Router Class Initialized
INFO - 2023-03-28 08:56:09 --> Output Class Initialized
INFO - 2023-03-28 08:56:09 --> Security Class Initialized
DEBUG - 2023-03-28 08:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:56:09 --> Input Class Initialized
INFO - 2023-03-28 08:56:09 --> Language Class Initialized
INFO - 2023-03-28 08:56:09 --> Language Class Initialized
INFO - 2023-03-28 08:56:09 --> Config Class Initialized
INFO - 2023-03-28 08:56:09 --> Loader Class Initialized
INFO - 2023-03-28 08:56:09 --> Helper loaded: url_helper
INFO - 2023-03-28 08:56:09 --> Helper loaded: file_helper
INFO - 2023-03-28 08:56:09 --> Helper loaded: form_helper
INFO - 2023-03-28 08:56:09 --> Helper loaded: my_helper
INFO - 2023-03-28 08:56:09 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:56:09 --> Controller Class Initialized
DEBUG - 2023-03-28 08:56:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-28 08:56:10 --> Final output sent to browser
DEBUG - 2023-03-28 08:56:10 --> Total execution time: 1.3809
INFO - 2023-03-28 08:58:46 --> Config Class Initialized
INFO - 2023-03-28 08:58:46 --> Hooks Class Initialized
DEBUG - 2023-03-28 08:58:46 --> UTF-8 Support Enabled
INFO - 2023-03-28 08:58:46 --> Utf8 Class Initialized
INFO - 2023-03-28 08:58:46 --> URI Class Initialized
INFO - 2023-03-28 08:58:46 --> Router Class Initialized
INFO - 2023-03-28 08:58:46 --> Output Class Initialized
INFO - 2023-03-28 08:58:46 --> Security Class Initialized
DEBUG - 2023-03-28 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 08:58:46 --> Input Class Initialized
INFO - 2023-03-28 08:58:46 --> Language Class Initialized
INFO - 2023-03-28 08:58:46 --> Language Class Initialized
INFO - 2023-03-28 08:58:46 --> Config Class Initialized
INFO - 2023-03-28 08:58:46 --> Loader Class Initialized
INFO - 2023-03-28 08:58:46 --> Helper loaded: url_helper
INFO - 2023-03-28 08:58:46 --> Helper loaded: file_helper
INFO - 2023-03-28 08:58:46 --> Helper loaded: form_helper
INFO - 2023-03-28 08:58:46 --> Helper loaded: my_helper
INFO - 2023-03-28 08:58:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 08:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 08:58:46 --> Controller Class Initialized
DEBUG - 2023-03-28 08:58:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-28 08:58:47 --> Final output sent to browser
DEBUG - 2023-03-28 08:58:47 --> Total execution time: 1.1975
INFO - 2023-03-28 09:05:44 --> Config Class Initialized
INFO - 2023-03-28 09:05:44 --> Hooks Class Initialized
DEBUG - 2023-03-28 09:05:44 --> UTF-8 Support Enabled
INFO - 2023-03-28 09:05:44 --> Utf8 Class Initialized
INFO - 2023-03-28 09:05:44 --> URI Class Initialized
INFO - 2023-03-28 09:05:44 --> Router Class Initialized
INFO - 2023-03-28 09:05:44 --> Output Class Initialized
INFO - 2023-03-28 09:05:44 --> Security Class Initialized
DEBUG - 2023-03-28 09:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 09:05:44 --> Input Class Initialized
INFO - 2023-03-28 09:05:44 --> Language Class Initialized
INFO - 2023-03-28 09:05:44 --> Language Class Initialized
INFO - 2023-03-28 09:05:44 --> Config Class Initialized
INFO - 2023-03-28 09:05:44 --> Loader Class Initialized
INFO - 2023-03-28 09:05:44 --> Helper loaded: url_helper
INFO - 2023-03-28 09:05:44 --> Helper loaded: file_helper
INFO - 2023-03-28 09:05:44 --> Helper loaded: form_helper
INFO - 2023-03-28 09:05:44 --> Helper loaded: my_helper
INFO - 2023-03-28 09:05:44 --> Database Driver Class Initialized
DEBUG - 2023-03-28 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 09:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 09:05:44 --> Controller Class Initialized
DEBUG - 2023-03-28 09:05:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 09:05:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 09:05:44 --> Final output sent to browser
DEBUG - 2023-03-28 09:05:44 --> Total execution time: 0.0426
INFO - 2023-03-28 09:05:46 --> Config Class Initialized
INFO - 2023-03-28 09:05:46 --> Hooks Class Initialized
DEBUG - 2023-03-28 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-03-28 09:05:46 --> Utf8 Class Initialized
INFO - 2023-03-28 09:05:46 --> URI Class Initialized
INFO - 2023-03-28 09:05:46 --> Router Class Initialized
INFO - 2023-03-28 09:05:46 --> Output Class Initialized
INFO - 2023-03-28 09:05:46 --> Security Class Initialized
DEBUG - 2023-03-28 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 09:05:46 --> Input Class Initialized
INFO - 2023-03-28 09:05:46 --> Language Class Initialized
INFO - 2023-03-28 09:05:46 --> Language Class Initialized
INFO - 2023-03-28 09:05:46 --> Config Class Initialized
INFO - 2023-03-28 09:05:46 --> Loader Class Initialized
INFO - 2023-03-28 09:05:46 --> Helper loaded: url_helper
INFO - 2023-03-28 09:05:46 --> Helper loaded: file_helper
INFO - 2023-03-28 09:05:46 --> Helper loaded: form_helper
INFO - 2023-03-28 09:05:46 --> Helper loaded: my_helper
INFO - 2023-03-28 09:05:46 --> Database Driver Class Initialized
DEBUG - 2023-03-28 09:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 09:05:46 --> Controller Class Initialized
DEBUG - 2023-03-28 09:05:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-28 09:05:47 --> Final output sent to browser
DEBUG - 2023-03-28 09:05:47 --> Total execution time: 1.1373
INFO - 2023-03-28 10:14:26 --> Config Class Initialized
INFO - 2023-03-28 10:14:26 --> Hooks Class Initialized
DEBUG - 2023-03-28 10:14:26 --> UTF-8 Support Enabled
INFO - 2023-03-28 10:14:26 --> Utf8 Class Initialized
INFO - 2023-03-28 10:14:26 --> URI Class Initialized
INFO - 2023-03-28 10:14:26 --> Router Class Initialized
INFO - 2023-03-28 10:14:26 --> Output Class Initialized
INFO - 2023-03-28 10:14:26 --> Security Class Initialized
DEBUG - 2023-03-28 10:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-28 10:14:26 --> Input Class Initialized
INFO - 2023-03-28 10:14:26 --> Language Class Initialized
INFO - 2023-03-28 10:14:26 --> Language Class Initialized
INFO - 2023-03-28 10:14:26 --> Config Class Initialized
INFO - 2023-03-28 10:14:26 --> Loader Class Initialized
INFO - 2023-03-28 10:14:26 --> Helper loaded: url_helper
INFO - 2023-03-28 10:14:26 --> Helper loaded: file_helper
INFO - 2023-03-28 10:14:26 --> Helper loaded: form_helper
INFO - 2023-03-28 10:14:26 --> Helper loaded: my_helper
INFO - 2023-03-28 10:14:26 --> Database Driver Class Initialized
DEBUG - 2023-03-28 10:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-28 10:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-28 10:14:26 --> Controller Class Initialized
DEBUG - 2023-03-28 10:14:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-28 10:14:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-28 10:14:26 --> Final output sent to browser
DEBUG - 2023-03-28 10:14:26 --> Total execution time: 0.0596
