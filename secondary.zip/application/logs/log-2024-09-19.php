<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-19 07:58:09 --> Config Class Initialized
INFO - 2024-09-19 07:58:09 --> Hooks Class Initialized
DEBUG - 2024-09-19 07:58:10 --> UTF-8 Support Enabled
INFO - 2024-09-19 07:58:10 --> Utf8 Class Initialized
INFO - 2024-09-19 07:58:10 --> URI Class Initialized
INFO - 2024-09-19 07:58:10 --> Router Class Initialized
INFO - 2024-09-19 07:58:10 --> Output Class Initialized
INFO - 2024-09-19 07:58:10 --> Security Class Initialized
DEBUG - 2024-09-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 07:58:10 --> Input Class Initialized
INFO - 2024-09-19 07:58:10 --> Language Class Initialized
INFO - 2024-09-19 07:58:10 --> Language Class Initialized
INFO - 2024-09-19 07:58:10 --> Config Class Initialized
INFO - 2024-09-19 07:58:10 --> Loader Class Initialized
INFO - 2024-09-19 07:58:10 --> Helper loaded: url_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: file_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: form_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: my_helper
INFO - 2024-09-19 07:58:10 --> Database Driver Class Initialized
INFO - 2024-09-19 07:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 07:58:10 --> Controller Class Initialized
DEBUG - 2024-09-19 07:58:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-19 07:58:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 07:58:10 --> Final output sent to browser
DEBUG - 2024-09-19 07:58:10 --> Total execution time: 0.0776
INFO - 2024-09-19 07:58:10 --> Config Class Initialized
INFO - 2024-09-19 07:58:10 --> Hooks Class Initialized
DEBUG - 2024-09-19 07:58:10 --> UTF-8 Support Enabled
INFO - 2024-09-19 07:58:10 --> Utf8 Class Initialized
INFO - 2024-09-19 07:58:10 --> URI Class Initialized
INFO - 2024-09-19 07:58:10 --> Router Class Initialized
INFO - 2024-09-19 07:58:10 --> Output Class Initialized
INFO - 2024-09-19 07:58:10 --> Security Class Initialized
DEBUG - 2024-09-19 07:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 07:58:10 --> Input Class Initialized
INFO - 2024-09-19 07:58:10 --> Language Class Initialized
INFO - 2024-09-19 07:58:10 --> Language Class Initialized
INFO - 2024-09-19 07:58:10 --> Config Class Initialized
INFO - 2024-09-19 07:58:10 --> Loader Class Initialized
INFO - 2024-09-19 07:58:10 --> Helper loaded: url_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: file_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: form_helper
INFO - 2024-09-19 07:58:10 --> Helper loaded: my_helper
INFO - 2024-09-19 07:58:10 --> Database Driver Class Initialized
INFO - 2024-09-19 07:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 07:58:10 --> Controller Class Initialized
INFO - 2024-09-19 07:59:11 --> Config Class Initialized
INFO - 2024-09-19 07:59:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 07:59:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 07:59:11 --> Utf8 Class Initialized
INFO - 2024-09-19 07:59:11 --> URI Class Initialized
INFO - 2024-09-19 07:59:11 --> Router Class Initialized
INFO - 2024-09-19 07:59:11 --> Output Class Initialized
INFO - 2024-09-19 07:59:11 --> Security Class Initialized
DEBUG - 2024-09-19 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 07:59:11 --> Input Class Initialized
INFO - 2024-09-19 07:59:11 --> Language Class Initialized
INFO - 2024-09-19 07:59:11 --> Language Class Initialized
INFO - 2024-09-19 07:59:11 --> Config Class Initialized
INFO - 2024-09-19 07:59:11 --> Loader Class Initialized
INFO - 2024-09-19 07:59:11 --> Helper loaded: url_helper
INFO - 2024-09-19 07:59:11 --> Helper loaded: file_helper
INFO - 2024-09-19 07:59:11 --> Helper loaded: form_helper
INFO - 2024-09-19 07:59:11 --> Helper loaded: my_helper
INFO - 2024-09-19 07:59:11 --> Database Driver Class Initialized
INFO - 2024-09-19 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 07:59:11 --> Controller Class Initialized
INFO - 2024-09-19 07:59:11 --> Final output sent to browser
DEBUG - 2024-09-19 07:59:11 --> Total execution time: 0.0448
INFO - 2024-09-19 08:12:53 --> Config Class Initialized
INFO - 2024-09-19 08:12:53 --> Hooks Class Initialized
DEBUG - 2024-09-19 08:12:53 --> UTF-8 Support Enabled
INFO - 2024-09-19 08:12:53 --> Utf8 Class Initialized
INFO - 2024-09-19 08:12:53 --> URI Class Initialized
INFO - 2024-09-19 08:12:53 --> Router Class Initialized
INFO - 2024-09-19 08:12:53 --> Output Class Initialized
INFO - 2024-09-19 08:12:53 --> Security Class Initialized
DEBUG - 2024-09-19 08:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 08:12:53 --> Input Class Initialized
INFO - 2024-09-19 08:12:53 --> Language Class Initialized
INFO - 2024-09-19 08:12:53 --> Language Class Initialized
INFO - 2024-09-19 08:12:53 --> Config Class Initialized
INFO - 2024-09-19 08:12:53 --> Loader Class Initialized
INFO - 2024-09-19 08:12:53 --> Helper loaded: url_helper
INFO - 2024-09-19 08:12:53 --> Helper loaded: file_helper
INFO - 2024-09-19 08:12:53 --> Helper loaded: form_helper
INFO - 2024-09-19 08:12:53 --> Helper loaded: my_helper
INFO - 2024-09-19 08:12:53 --> Database Driver Class Initialized
INFO - 2024-09-19 08:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 08:12:53 --> Controller Class Initialized
DEBUG - 2024-09-19 08:12:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-19 08:12:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 08:12:53 --> Final output sent to browser
DEBUG - 2024-09-19 08:12:53 --> Total execution time: 0.0608
INFO - 2024-09-19 08:13:06 --> Config Class Initialized
INFO - 2024-09-19 08:13:06 --> Hooks Class Initialized
DEBUG - 2024-09-19 08:13:06 --> UTF-8 Support Enabled
INFO - 2024-09-19 08:13:06 --> Utf8 Class Initialized
INFO - 2024-09-19 08:13:06 --> URI Class Initialized
INFO - 2024-09-19 08:13:06 --> Router Class Initialized
INFO - 2024-09-19 08:13:06 --> Output Class Initialized
INFO - 2024-09-19 08:13:06 --> Security Class Initialized
DEBUG - 2024-09-19 08:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 08:13:06 --> Input Class Initialized
INFO - 2024-09-19 08:13:06 --> Language Class Initialized
INFO - 2024-09-19 08:13:06 --> Language Class Initialized
INFO - 2024-09-19 08:13:06 --> Config Class Initialized
INFO - 2024-09-19 08:13:06 --> Loader Class Initialized
INFO - 2024-09-19 08:13:06 --> Helper loaded: url_helper
INFO - 2024-09-19 08:13:06 --> Helper loaded: file_helper
INFO - 2024-09-19 08:13:06 --> Helper loaded: form_helper
INFO - 2024-09-19 08:13:06 --> Helper loaded: my_helper
INFO - 2024-09-19 08:13:06 --> Database Driver Class Initialized
INFO - 2024-09-19 08:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 08:13:06 --> Controller Class Initialized
INFO - 2024-09-19 11:15:22 --> Config Class Initialized
INFO - 2024-09-19 11:15:22 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:22 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:22 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:22 --> URI Class Initialized
INFO - 2024-09-19 11:15:22 --> Router Class Initialized
INFO - 2024-09-19 11:15:22 --> Output Class Initialized
INFO - 2024-09-19 11:15:22 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:22 --> Input Class Initialized
INFO - 2024-09-19 11:15:22 --> Language Class Initialized
INFO - 2024-09-19 11:15:22 --> Language Class Initialized
INFO - 2024-09-19 11:15:22 --> Config Class Initialized
INFO - 2024-09-19 11:15:22 --> Loader Class Initialized
INFO - 2024-09-19 11:15:22 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:22 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:22 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:22 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:22 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:22 --> Controller Class Initialized
INFO - 2024-09-19 11:15:24 --> Config Class Initialized
INFO - 2024-09-19 11:15:24 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:24 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:24 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:24 --> URI Class Initialized
INFO - 2024-09-19 11:15:24 --> Router Class Initialized
INFO - 2024-09-19 11:15:24 --> Output Class Initialized
INFO - 2024-09-19 11:15:24 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:24 --> Input Class Initialized
INFO - 2024-09-19 11:15:24 --> Language Class Initialized
INFO - 2024-09-19 11:15:24 --> Language Class Initialized
INFO - 2024-09-19 11:15:24 --> Config Class Initialized
INFO - 2024-09-19 11:15:24 --> Loader Class Initialized
INFO - 2024-09-19 11:15:24 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:24 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:24 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:24 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:24 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:24 --> Controller Class Initialized
DEBUG - 2024-09-19 11:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-09-19 11:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:15:24 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:24 --> Total execution time: 0.0366
INFO - 2024-09-19 11:15:35 --> Config Class Initialized
INFO - 2024-09-19 11:15:35 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:35 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:35 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:35 --> URI Class Initialized
INFO - 2024-09-19 11:15:35 --> Router Class Initialized
INFO - 2024-09-19 11:15:35 --> Output Class Initialized
INFO - 2024-09-19 11:15:35 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:35 --> Input Class Initialized
INFO - 2024-09-19 11:15:35 --> Language Class Initialized
INFO - 2024-09-19 11:15:35 --> Language Class Initialized
INFO - 2024-09-19 11:15:35 --> Config Class Initialized
INFO - 2024-09-19 11:15:35 --> Loader Class Initialized
INFO - 2024-09-19 11:15:35 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:35 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:35 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:35 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:35 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:35 --> Controller Class Initialized
INFO - 2024-09-19 11:15:35 --> Helper loaded: cookie_helper
INFO - 2024-09-19 11:15:35 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:35 --> Total execution time: 0.0347
INFO - 2024-09-19 11:15:36 --> Config Class Initialized
INFO - 2024-09-19 11:15:36 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:36 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:36 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:36 --> URI Class Initialized
INFO - 2024-09-19 11:15:36 --> Router Class Initialized
INFO - 2024-09-19 11:15:36 --> Output Class Initialized
INFO - 2024-09-19 11:15:36 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:36 --> Input Class Initialized
INFO - 2024-09-19 11:15:36 --> Language Class Initialized
INFO - 2024-09-19 11:15:36 --> Language Class Initialized
INFO - 2024-09-19 11:15:36 --> Config Class Initialized
INFO - 2024-09-19 11:15:36 --> Loader Class Initialized
INFO - 2024-09-19 11:15:36 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:36 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:36 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:36 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:36 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:36 --> Controller Class Initialized
DEBUG - 2024-09-19 11:15:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-19 11:15:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:15:36 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:36 --> Total execution time: 0.0314
INFO - 2024-09-19 11:15:38 --> Config Class Initialized
INFO - 2024-09-19 11:15:38 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:38 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:38 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:38 --> URI Class Initialized
INFO - 2024-09-19 11:15:38 --> Router Class Initialized
INFO - 2024-09-19 11:15:38 --> Output Class Initialized
INFO - 2024-09-19 11:15:38 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:38 --> Input Class Initialized
INFO - 2024-09-19 11:15:38 --> Language Class Initialized
INFO - 2024-09-19 11:15:38 --> Language Class Initialized
INFO - 2024-09-19 11:15:38 --> Config Class Initialized
INFO - 2024-09-19 11:15:38 --> Loader Class Initialized
INFO - 2024-09-19 11:15:38 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:38 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:38 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:38 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:38 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:38 --> Controller Class Initialized
DEBUG - 2024-09-19 11:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-19 11:15:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:15:38 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:38 --> Total execution time: 0.0324
INFO - 2024-09-19 11:15:43 --> Config Class Initialized
INFO - 2024-09-19 11:15:43 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:43 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:43 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:43 --> URI Class Initialized
INFO - 2024-09-19 11:15:43 --> Router Class Initialized
INFO - 2024-09-19 11:15:43 --> Output Class Initialized
INFO - 2024-09-19 11:15:43 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:43 --> Input Class Initialized
INFO - 2024-09-19 11:15:43 --> Language Class Initialized
INFO - 2024-09-19 11:15:43 --> Language Class Initialized
INFO - 2024-09-19 11:15:43 --> Config Class Initialized
INFO - 2024-09-19 11:15:43 --> Loader Class Initialized
INFO - 2024-09-19 11:15:43 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:43 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:43 --> Controller Class Initialized
DEBUG - 2024-09-19 11:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-09-19 11:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:15:43 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:43 --> Total execution time: 0.0352
INFO - 2024-09-19 11:15:43 --> Config Class Initialized
INFO - 2024-09-19 11:15:43 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:43 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:43 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:43 --> URI Class Initialized
INFO - 2024-09-19 11:15:43 --> Router Class Initialized
INFO - 2024-09-19 11:15:43 --> Output Class Initialized
INFO - 2024-09-19 11:15:43 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:43 --> Input Class Initialized
INFO - 2024-09-19 11:15:43 --> Language Class Initialized
INFO - 2024-09-19 11:15:43 --> Language Class Initialized
INFO - 2024-09-19 11:15:43 --> Config Class Initialized
INFO - 2024-09-19 11:15:43 --> Loader Class Initialized
INFO - 2024-09-19 11:15:43 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:43 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:43 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:43 --> Controller Class Initialized
INFO - 2024-09-19 11:15:46 --> Config Class Initialized
INFO - 2024-09-19 11:15:46 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:15:46 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:15:46 --> Utf8 Class Initialized
INFO - 2024-09-19 11:15:46 --> URI Class Initialized
INFO - 2024-09-19 11:15:46 --> Router Class Initialized
INFO - 2024-09-19 11:15:46 --> Output Class Initialized
INFO - 2024-09-19 11:15:46 --> Security Class Initialized
DEBUG - 2024-09-19 11:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:15:46 --> Input Class Initialized
INFO - 2024-09-19 11:15:46 --> Language Class Initialized
INFO - 2024-09-19 11:15:46 --> Language Class Initialized
INFO - 2024-09-19 11:15:46 --> Config Class Initialized
INFO - 2024-09-19 11:15:46 --> Loader Class Initialized
INFO - 2024-09-19 11:15:46 --> Helper loaded: url_helper
INFO - 2024-09-19 11:15:46 --> Helper loaded: file_helper
INFO - 2024-09-19 11:15:46 --> Helper loaded: form_helper
INFO - 2024-09-19 11:15:46 --> Helper loaded: my_helper
INFO - 2024-09-19 11:15:46 --> Database Driver Class Initialized
INFO - 2024-09-19 11:15:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:15:46 --> Controller Class Initialized
INFO - 2024-09-19 11:15:46 --> Final output sent to browser
DEBUG - 2024-09-19 11:15:46 --> Total execution time: 0.2067
INFO - 2024-09-19 11:16:55 --> Config Class Initialized
INFO - 2024-09-19 11:16:55 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:16:55 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:16:55 --> Utf8 Class Initialized
INFO - 2024-09-19 11:16:55 --> URI Class Initialized
INFO - 2024-09-19 11:16:55 --> Router Class Initialized
INFO - 2024-09-19 11:16:55 --> Output Class Initialized
INFO - 2024-09-19 11:16:55 --> Security Class Initialized
DEBUG - 2024-09-19 11:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:16:55 --> Input Class Initialized
INFO - 2024-09-19 11:16:55 --> Language Class Initialized
INFO - 2024-09-19 11:16:55 --> Language Class Initialized
INFO - 2024-09-19 11:16:55 --> Config Class Initialized
INFO - 2024-09-19 11:16:55 --> Loader Class Initialized
INFO - 2024-09-19 11:16:55 --> Helper loaded: url_helper
INFO - 2024-09-19 11:16:55 --> Helper loaded: file_helper
INFO - 2024-09-19 11:16:55 --> Helper loaded: form_helper
INFO - 2024-09-19 11:16:55 --> Helper loaded: my_helper
INFO - 2024-09-19 11:16:55 --> Database Driver Class Initialized
INFO - 2024-09-19 11:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:16:55 --> Controller Class Initialized
INFO - 2024-09-19 11:16:55 --> Final output sent to browser
DEBUG - 2024-09-19 11:16:55 --> Total execution time: 0.0788
INFO - 2024-09-19 11:20:00 --> Config Class Initialized
INFO - 2024-09-19 11:20:00 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:20:01 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:20:01 --> Utf8 Class Initialized
INFO - 2024-09-19 11:20:01 --> URI Class Initialized
INFO - 2024-09-19 11:20:01 --> Router Class Initialized
INFO - 2024-09-19 11:20:01 --> Output Class Initialized
INFO - 2024-09-19 11:20:01 --> Security Class Initialized
DEBUG - 2024-09-19 11:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:20:01 --> Input Class Initialized
INFO - 2024-09-19 11:20:01 --> Language Class Initialized
INFO - 2024-09-19 11:20:01 --> Language Class Initialized
INFO - 2024-09-19 11:20:01 --> Config Class Initialized
INFO - 2024-09-19 11:20:01 --> Loader Class Initialized
INFO - 2024-09-19 11:20:01 --> Helper loaded: url_helper
INFO - 2024-09-19 11:20:01 --> Helper loaded: file_helper
INFO - 2024-09-19 11:20:01 --> Helper loaded: form_helper
INFO - 2024-09-19 11:20:01 --> Helper loaded: my_helper
INFO - 2024-09-19 11:20:01 --> Database Driver Class Initialized
INFO - 2024-09-19 11:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:20:01 --> Controller Class Initialized
INFO - 2024-09-19 11:20:01 --> Final output sent to browser
DEBUG - 2024-09-19 11:20:01 --> Total execution time: 0.3087
INFO - 2024-09-19 11:20:05 --> Config Class Initialized
INFO - 2024-09-19 11:20:05 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:20:05 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:20:05 --> Utf8 Class Initialized
INFO - 2024-09-19 11:20:05 --> URI Class Initialized
INFO - 2024-09-19 11:20:05 --> Router Class Initialized
INFO - 2024-09-19 11:20:05 --> Output Class Initialized
INFO - 2024-09-19 11:20:05 --> Security Class Initialized
DEBUG - 2024-09-19 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:20:05 --> Input Class Initialized
INFO - 2024-09-19 11:20:05 --> Language Class Initialized
INFO - 2024-09-19 11:20:05 --> Language Class Initialized
INFO - 2024-09-19 11:20:05 --> Config Class Initialized
INFO - 2024-09-19 11:20:05 --> Loader Class Initialized
INFO - 2024-09-19 11:20:05 --> Helper loaded: url_helper
INFO - 2024-09-19 11:20:05 --> Helper loaded: file_helper
INFO - 2024-09-19 11:20:05 --> Helper loaded: form_helper
INFO - 2024-09-19 11:20:05 --> Helper loaded: my_helper
INFO - 2024-09-19 11:20:05 --> Database Driver Class Initialized
INFO - 2024-09-19 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:20:05 --> Controller Class Initialized
INFO - 2024-09-19 11:20:05 --> Final output sent to browser
DEBUG - 2024-09-19 11:20:05 --> Total execution time: 0.3402
INFO - 2024-09-19 11:20:16 --> Config Class Initialized
INFO - 2024-09-19 11:20:16 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:20:16 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:20:16 --> Utf8 Class Initialized
INFO - 2024-09-19 11:20:16 --> URI Class Initialized
INFO - 2024-09-19 11:20:16 --> Router Class Initialized
INFO - 2024-09-19 11:20:16 --> Output Class Initialized
INFO - 2024-09-19 11:20:16 --> Security Class Initialized
DEBUG - 2024-09-19 11:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:20:16 --> Input Class Initialized
INFO - 2024-09-19 11:20:16 --> Language Class Initialized
INFO - 2024-09-19 11:20:16 --> Language Class Initialized
INFO - 2024-09-19 11:20:16 --> Config Class Initialized
INFO - 2024-09-19 11:20:16 --> Loader Class Initialized
INFO - 2024-09-19 11:20:16 --> Helper loaded: url_helper
INFO - 2024-09-19 11:20:16 --> Helper loaded: file_helper
INFO - 2024-09-19 11:20:16 --> Helper loaded: form_helper
INFO - 2024-09-19 11:20:16 --> Helper loaded: my_helper
INFO - 2024-09-19 11:20:16 --> Database Driver Class Initialized
INFO - 2024-09-19 11:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:20:16 --> Controller Class Initialized
INFO - 2024-09-19 11:20:17 --> Final output sent to browser
DEBUG - 2024-09-19 11:20:17 --> Total execution time: 0.2047
INFO - 2024-09-19 11:23:38 --> Config Class Initialized
INFO - 2024-09-19 11:23:38 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:23:38 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:23:38 --> Utf8 Class Initialized
INFO - 2024-09-19 11:23:38 --> URI Class Initialized
INFO - 2024-09-19 11:23:38 --> Router Class Initialized
INFO - 2024-09-19 11:23:38 --> Output Class Initialized
INFO - 2024-09-19 11:23:38 --> Security Class Initialized
DEBUG - 2024-09-19 11:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:23:38 --> Input Class Initialized
INFO - 2024-09-19 11:23:38 --> Language Class Initialized
INFO - 2024-09-19 11:23:38 --> Language Class Initialized
INFO - 2024-09-19 11:23:38 --> Config Class Initialized
INFO - 2024-09-19 11:23:38 --> Loader Class Initialized
INFO - 2024-09-19 11:23:38 --> Helper loaded: url_helper
INFO - 2024-09-19 11:23:38 --> Helper loaded: file_helper
INFO - 2024-09-19 11:23:38 --> Helper loaded: form_helper
INFO - 2024-09-19 11:23:38 --> Helper loaded: my_helper
INFO - 2024-09-19 11:23:38 --> Database Driver Class Initialized
INFO - 2024-09-19 11:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:23:38 --> Controller Class Initialized
INFO - 2024-09-19 11:23:39 --> Final output sent to browser
DEBUG - 2024-09-19 11:23:39 --> Total execution time: 0.2457
INFO - 2024-09-19 11:23:46 --> Config Class Initialized
INFO - 2024-09-19 11:23:46 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:23:46 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:23:46 --> Utf8 Class Initialized
INFO - 2024-09-19 11:23:46 --> URI Class Initialized
INFO - 2024-09-19 11:23:46 --> Router Class Initialized
INFO - 2024-09-19 11:23:46 --> Output Class Initialized
INFO - 2024-09-19 11:23:46 --> Security Class Initialized
DEBUG - 2024-09-19 11:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:23:46 --> Input Class Initialized
INFO - 2024-09-19 11:23:46 --> Language Class Initialized
INFO - 2024-09-19 11:23:46 --> Language Class Initialized
INFO - 2024-09-19 11:23:46 --> Config Class Initialized
INFO - 2024-09-19 11:23:46 --> Loader Class Initialized
INFO - 2024-09-19 11:23:47 --> Helper loaded: url_helper
INFO - 2024-09-19 11:23:47 --> Helper loaded: file_helper
INFO - 2024-09-19 11:23:47 --> Helper loaded: form_helper
INFO - 2024-09-19 11:23:47 --> Helper loaded: my_helper
INFO - 2024-09-19 11:23:47 --> Database Driver Class Initialized
INFO - 2024-09-19 11:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:23:47 --> Controller Class Initialized
INFO - 2024-09-19 11:23:47 --> Final output sent to browser
DEBUG - 2024-09-19 11:23:47 --> Total execution time: 0.1442
INFO - 2024-09-19 11:23:51 --> Config Class Initialized
INFO - 2024-09-19 11:23:51 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:23:51 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:23:51 --> Utf8 Class Initialized
INFO - 2024-09-19 11:23:51 --> URI Class Initialized
INFO - 2024-09-19 11:23:51 --> Router Class Initialized
INFO - 2024-09-19 11:23:51 --> Output Class Initialized
INFO - 2024-09-19 11:23:51 --> Security Class Initialized
DEBUG - 2024-09-19 11:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:23:51 --> Input Class Initialized
INFO - 2024-09-19 11:23:51 --> Language Class Initialized
INFO - 2024-09-19 11:23:51 --> Language Class Initialized
INFO - 2024-09-19 11:23:51 --> Config Class Initialized
INFO - 2024-09-19 11:23:51 --> Loader Class Initialized
INFO - 2024-09-19 11:23:51 --> Helper loaded: url_helper
INFO - 2024-09-19 11:23:51 --> Helper loaded: file_helper
INFO - 2024-09-19 11:23:51 --> Helper loaded: form_helper
INFO - 2024-09-19 11:23:51 --> Helper loaded: my_helper
INFO - 2024-09-19 11:23:51 --> Database Driver Class Initialized
INFO - 2024-09-19 11:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:23:51 --> Controller Class Initialized
INFO - 2024-09-19 11:23:51 --> Final output sent to browser
DEBUG - 2024-09-19 11:23:51 --> Total execution time: 0.1336
INFO - 2024-09-19 11:23:52 --> Config Class Initialized
INFO - 2024-09-19 11:23:52 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:23:52 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:23:52 --> Utf8 Class Initialized
INFO - 2024-09-19 11:23:52 --> URI Class Initialized
INFO - 2024-09-19 11:23:52 --> Router Class Initialized
INFO - 2024-09-19 11:23:52 --> Output Class Initialized
INFO - 2024-09-19 11:23:52 --> Security Class Initialized
DEBUG - 2024-09-19 11:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:23:52 --> Input Class Initialized
INFO - 2024-09-19 11:23:52 --> Language Class Initialized
INFO - 2024-09-19 11:23:52 --> Language Class Initialized
INFO - 2024-09-19 11:23:52 --> Config Class Initialized
INFO - 2024-09-19 11:23:52 --> Loader Class Initialized
INFO - 2024-09-19 11:23:52 --> Helper loaded: url_helper
INFO - 2024-09-19 11:23:52 --> Helper loaded: file_helper
INFO - 2024-09-19 11:23:52 --> Helper loaded: form_helper
INFO - 2024-09-19 11:23:52 --> Helper loaded: my_helper
INFO - 2024-09-19 11:23:52 --> Database Driver Class Initialized
INFO - 2024-09-19 11:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:23:52 --> Controller Class Initialized
INFO - 2024-09-19 11:23:52 --> Final output sent to browser
DEBUG - 2024-09-19 11:23:52 --> Total execution time: 0.1456
INFO - 2024-09-19 11:23:54 --> Config Class Initialized
INFO - 2024-09-19 11:23:54 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:23:54 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:23:54 --> Utf8 Class Initialized
INFO - 2024-09-19 11:23:54 --> URI Class Initialized
INFO - 2024-09-19 11:23:54 --> Router Class Initialized
INFO - 2024-09-19 11:23:54 --> Output Class Initialized
INFO - 2024-09-19 11:23:54 --> Security Class Initialized
DEBUG - 2024-09-19 11:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:23:54 --> Input Class Initialized
INFO - 2024-09-19 11:23:54 --> Language Class Initialized
INFO - 2024-09-19 11:23:54 --> Language Class Initialized
INFO - 2024-09-19 11:23:54 --> Config Class Initialized
INFO - 2024-09-19 11:23:54 --> Loader Class Initialized
INFO - 2024-09-19 11:23:54 --> Helper loaded: url_helper
INFO - 2024-09-19 11:23:54 --> Helper loaded: file_helper
INFO - 2024-09-19 11:23:54 --> Helper loaded: form_helper
INFO - 2024-09-19 11:23:54 --> Helper loaded: my_helper
INFO - 2024-09-19 11:23:54 --> Database Driver Class Initialized
INFO - 2024-09-19 11:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:23:54 --> Controller Class Initialized
INFO - 2024-09-19 11:23:54 --> Final output sent to browser
DEBUG - 2024-09-19 11:23:54 --> Total execution time: 0.1640
INFO - 2024-09-19 11:24:08 --> Config Class Initialized
INFO - 2024-09-19 11:24:08 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:08 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:08 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:08 --> URI Class Initialized
INFO - 2024-09-19 11:24:08 --> Router Class Initialized
INFO - 2024-09-19 11:24:08 --> Output Class Initialized
INFO - 2024-09-19 11:24:08 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:08 --> Input Class Initialized
INFO - 2024-09-19 11:24:08 --> Language Class Initialized
INFO - 2024-09-19 11:24:08 --> Language Class Initialized
INFO - 2024-09-19 11:24:08 --> Config Class Initialized
INFO - 2024-09-19 11:24:08 --> Loader Class Initialized
INFO - 2024-09-19 11:24:08 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:08 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:08 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:08 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:08 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:08 --> Controller Class Initialized
INFO - 2024-09-19 11:24:09 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:09 --> Total execution time: 0.1570
INFO - 2024-09-19 11:24:33 --> Config Class Initialized
INFO - 2024-09-19 11:24:33 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:33 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:33 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:33 --> URI Class Initialized
INFO - 2024-09-19 11:24:33 --> Router Class Initialized
INFO - 2024-09-19 11:24:33 --> Output Class Initialized
INFO - 2024-09-19 11:24:33 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:33 --> Input Class Initialized
INFO - 2024-09-19 11:24:33 --> Language Class Initialized
INFO - 2024-09-19 11:24:33 --> Language Class Initialized
INFO - 2024-09-19 11:24:33 --> Config Class Initialized
INFO - 2024-09-19 11:24:33 --> Loader Class Initialized
INFO - 2024-09-19 11:24:33 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:33 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:33 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:33 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:33 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:33 --> Controller Class Initialized
INFO - 2024-09-19 11:24:33 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:33 --> Total execution time: 0.1212
INFO - 2024-09-19 11:24:43 --> Config Class Initialized
INFO - 2024-09-19 11:24:43 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:43 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:43 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:43 --> URI Class Initialized
INFO - 2024-09-19 11:24:43 --> Router Class Initialized
INFO - 2024-09-19 11:24:43 --> Output Class Initialized
INFO - 2024-09-19 11:24:43 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:43 --> Input Class Initialized
INFO - 2024-09-19 11:24:43 --> Language Class Initialized
INFO - 2024-09-19 11:24:43 --> Language Class Initialized
INFO - 2024-09-19 11:24:43 --> Config Class Initialized
INFO - 2024-09-19 11:24:43 --> Loader Class Initialized
INFO - 2024-09-19 11:24:43 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:43 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:43 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:43 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:43 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:43 --> Controller Class Initialized
INFO - 2024-09-19 11:24:43 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:43 --> Total execution time: 0.1744
INFO - 2024-09-19 11:24:50 --> Config Class Initialized
INFO - 2024-09-19 11:24:50 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:50 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:50 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:50 --> URI Class Initialized
INFO - 2024-09-19 11:24:50 --> Router Class Initialized
INFO - 2024-09-19 11:24:50 --> Output Class Initialized
INFO - 2024-09-19 11:24:50 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:50 --> Input Class Initialized
INFO - 2024-09-19 11:24:50 --> Language Class Initialized
INFO - 2024-09-19 11:24:50 --> Language Class Initialized
INFO - 2024-09-19 11:24:50 --> Config Class Initialized
INFO - 2024-09-19 11:24:50 --> Loader Class Initialized
INFO - 2024-09-19 11:24:50 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:50 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:50 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:50 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:50 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:50 --> Controller Class Initialized
INFO - 2024-09-19 11:24:50 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:50 --> Total execution time: 0.1217
INFO - 2024-09-19 11:24:52 --> Config Class Initialized
INFO - 2024-09-19 11:24:52 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:52 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:52 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:52 --> URI Class Initialized
INFO - 2024-09-19 11:24:52 --> Router Class Initialized
INFO - 2024-09-19 11:24:52 --> Output Class Initialized
INFO - 2024-09-19 11:24:52 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:52 --> Input Class Initialized
INFO - 2024-09-19 11:24:52 --> Language Class Initialized
INFO - 2024-09-19 11:24:52 --> Language Class Initialized
INFO - 2024-09-19 11:24:52 --> Config Class Initialized
INFO - 2024-09-19 11:24:52 --> Loader Class Initialized
INFO - 2024-09-19 11:24:52 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:52 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:52 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:52 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:52 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:52 --> Controller Class Initialized
INFO - 2024-09-19 11:24:53 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:53 --> Total execution time: 0.1332
INFO - 2024-09-19 11:24:55 --> Config Class Initialized
INFO - 2024-09-19 11:24:55 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:55 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:55 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:55 --> URI Class Initialized
INFO - 2024-09-19 11:24:55 --> Router Class Initialized
INFO - 2024-09-19 11:24:55 --> Output Class Initialized
INFO - 2024-09-19 11:24:55 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:55 --> Input Class Initialized
INFO - 2024-09-19 11:24:55 --> Language Class Initialized
INFO - 2024-09-19 11:24:55 --> Language Class Initialized
INFO - 2024-09-19 11:24:55 --> Config Class Initialized
INFO - 2024-09-19 11:24:55 --> Loader Class Initialized
INFO - 2024-09-19 11:24:55 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:55 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:55 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:55 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:55 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:55 --> Controller Class Initialized
INFO - 2024-09-19 11:24:55 --> Final output sent to browser
DEBUG - 2024-09-19 11:24:55 --> Total execution time: 0.4151
INFO - 2024-09-19 11:24:59 --> Config Class Initialized
INFO - 2024-09-19 11:24:59 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:24:59 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:24:59 --> Utf8 Class Initialized
INFO - 2024-09-19 11:24:59 --> URI Class Initialized
INFO - 2024-09-19 11:24:59 --> Router Class Initialized
INFO - 2024-09-19 11:24:59 --> Output Class Initialized
INFO - 2024-09-19 11:24:59 --> Security Class Initialized
DEBUG - 2024-09-19 11:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:24:59 --> Input Class Initialized
INFO - 2024-09-19 11:24:59 --> Language Class Initialized
INFO - 2024-09-19 11:24:59 --> Language Class Initialized
INFO - 2024-09-19 11:24:59 --> Config Class Initialized
INFO - 2024-09-19 11:24:59 --> Loader Class Initialized
INFO - 2024-09-19 11:24:59 --> Helper loaded: url_helper
INFO - 2024-09-19 11:24:59 --> Helper loaded: file_helper
INFO - 2024-09-19 11:24:59 --> Helper loaded: form_helper
INFO - 2024-09-19 11:24:59 --> Helper loaded: my_helper
INFO - 2024-09-19 11:24:59 --> Database Driver Class Initialized
INFO - 2024-09-19 11:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:24:59 --> Controller Class Initialized
INFO - 2024-09-19 11:25:00 --> Final output sent to browser
DEBUG - 2024-09-19 11:25:00 --> Total execution time: 0.1943
INFO - 2024-09-19 11:25:03 --> Config Class Initialized
INFO - 2024-09-19 11:25:03 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:25:03 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:25:03 --> Utf8 Class Initialized
INFO - 2024-09-19 11:25:03 --> URI Class Initialized
INFO - 2024-09-19 11:25:03 --> Router Class Initialized
INFO - 2024-09-19 11:25:03 --> Output Class Initialized
INFO - 2024-09-19 11:25:03 --> Security Class Initialized
DEBUG - 2024-09-19 11:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:25:03 --> Input Class Initialized
INFO - 2024-09-19 11:25:03 --> Language Class Initialized
INFO - 2024-09-19 11:25:03 --> Language Class Initialized
INFO - 2024-09-19 11:25:03 --> Config Class Initialized
INFO - 2024-09-19 11:25:03 --> Loader Class Initialized
INFO - 2024-09-19 11:25:03 --> Helper loaded: url_helper
INFO - 2024-09-19 11:25:03 --> Helper loaded: file_helper
INFO - 2024-09-19 11:25:03 --> Helper loaded: form_helper
INFO - 2024-09-19 11:25:03 --> Helper loaded: my_helper
INFO - 2024-09-19 11:25:03 --> Database Driver Class Initialized
INFO - 2024-09-19 11:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:25:03 --> Controller Class Initialized
INFO - 2024-09-19 11:25:03 --> Final output sent to browser
DEBUG - 2024-09-19 11:25:03 --> Total execution time: 0.0721
INFO - 2024-09-19 11:26:17 --> Config Class Initialized
INFO - 2024-09-19 11:26:17 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:26:17 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:26:17 --> Utf8 Class Initialized
INFO - 2024-09-19 11:26:17 --> URI Class Initialized
INFO - 2024-09-19 11:26:17 --> Router Class Initialized
INFO - 2024-09-19 11:26:17 --> Output Class Initialized
INFO - 2024-09-19 11:26:17 --> Security Class Initialized
DEBUG - 2024-09-19 11:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:26:17 --> Input Class Initialized
INFO - 2024-09-19 11:26:17 --> Language Class Initialized
INFO - 2024-09-19 11:26:17 --> Language Class Initialized
INFO - 2024-09-19 11:26:17 --> Config Class Initialized
INFO - 2024-09-19 11:26:17 --> Loader Class Initialized
INFO - 2024-09-19 11:26:17 --> Helper loaded: url_helper
INFO - 2024-09-19 11:26:17 --> Helper loaded: file_helper
INFO - 2024-09-19 11:26:17 --> Helper loaded: form_helper
INFO - 2024-09-19 11:26:17 --> Helper loaded: my_helper
INFO - 2024-09-19 11:26:17 --> Database Driver Class Initialized
INFO - 2024-09-19 11:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:26:17 --> Controller Class Initialized
INFO - 2024-09-19 11:26:17 --> Final output sent to browser
DEBUG - 2024-09-19 11:26:17 --> Total execution time: 0.1240
INFO - 2024-09-19 11:26:37 --> Config Class Initialized
INFO - 2024-09-19 11:26:37 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:26:37 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:26:37 --> Utf8 Class Initialized
INFO - 2024-09-19 11:26:37 --> URI Class Initialized
INFO - 2024-09-19 11:26:37 --> Router Class Initialized
INFO - 2024-09-19 11:26:37 --> Output Class Initialized
INFO - 2024-09-19 11:26:37 --> Security Class Initialized
DEBUG - 2024-09-19 11:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:26:37 --> Input Class Initialized
INFO - 2024-09-19 11:26:37 --> Language Class Initialized
INFO - 2024-09-19 11:26:37 --> Language Class Initialized
INFO - 2024-09-19 11:26:37 --> Config Class Initialized
INFO - 2024-09-19 11:26:37 --> Loader Class Initialized
INFO - 2024-09-19 11:26:37 --> Helper loaded: url_helper
INFO - 2024-09-19 11:26:37 --> Helper loaded: file_helper
INFO - 2024-09-19 11:26:37 --> Helper loaded: form_helper
INFO - 2024-09-19 11:26:37 --> Helper loaded: my_helper
INFO - 2024-09-19 11:26:37 --> Database Driver Class Initialized
INFO - 2024-09-19 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:26:37 --> Controller Class Initialized
INFO - 2024-09-19 11:26:37 --> Final output sent to browser
DEBUG - 2024-09-19 11:26:37 --> Total execution time: 0.3550
INFO - 2024-09-19 11:31:02 --> Config Class Initialized
INFO - 2024-09-19 11:31:02 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:31:02 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:31:02 --> Utf8 Class Initialized
INFO - 2024-09-19 11:31:02 --> URI Class Initialized
INFO - 2024-09-19 11:31:02 --> Router Class Initialized
INFO - 2024-09-19 11:31:02 --> Output Class Initialized
INFO - 2024-09-19 11:31:02 --> Security Class Initialized
DEBUG - 2024-09-19 11:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:31:02 --> Input Class Initialized
INFO - 2024-09-19 11:31:02 --> Language Class Initialized
INFO - 2024-09-19 11:31:02 --> Language Class Initialized
INFO - 2024-09-19 11:31:02 --> Config Class Initialized
INFO - 2024-09-19 11:31:02 --> Loader Class Initialized
INFO - 2024-09-19 11:31:02 --> Helper loaded: url_helper
INFO - 2024-09-19 11:31:02 --> Helper loaded: file_helper
INFO - 2024-09-19 11:31:02 --> Helper loaded: form_helper
INFO - 2024-09-19 11:31:02 --> Helper loaded: my_helper
INFO - 2024-09-19 11:31:02 --> Database Driver Class Initialized
INFO - 2024-09-19 11:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:31:02 --> Controller Class Initialized
INFO - 2024-09-19 11:31:02 --> Final output sent to browser
DEBUG - 2024-09-19 11:31:02 --> Total execution time: 0.2328
INFO - 2024-09-19 11:31:24 --> Config Class Initialized
INFO - 2024-09-19 11:31:24 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:31:24 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:31:24 --> Utf8 Class Initialized
INFO - 2024-09-19 11:31:24 --> URI Class Initialized
INFO - 2024-09-19 11:31:24 --> Router Class Initialized
INFO - 2024-09-19 11:31:24 --> Output Class Initialized
INFO - 2024-09-19 11:31:24 --> Security Class Initialized
DEBUG - 2024-09-19 11:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:31:24 --> Input Class Initialized
INFO - 2024-09-19 11:31:24 --> Language Class Initialized
INFO - 2024-09-19 11:31:24 --> Language Class Initialized
INFO - 2024-09-19 11:31:24 --> Config Class Initialized
INFO - 2024-09-19 11:31:24 --> Loader Class Initialized
INFO - 2024-09-19 11:31:24 --> Helper loaded: url_helper
INFO - 2024-09-19 11:31:24 --> Helper loaded: file_helper
INFO - 2024-09-19 11:31:24 --> Helper loaded: form_helper
INFO - 2024-09-19 11:31:24 --> Helper loaded: my_helper
INFO - 2024-09-19 11:31:24 --> Database Driver Class Initialized
INFO - 2024-09-19 11:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:31:24 --> Controller Class Initialized
INFO - 2024-09-19 11:31:24 --> Final output sent to browser
DEBUG - 2024-09-19 11:31:24 --> Total execution time: 0.1580
INFO - 2024-09-19 11:31:50 --> Config Class Initialized
INFO - 2024-09-19 11:31:50 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:31:50 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:31:50 --> Utf8 Class Initialized
INFO - 2024-09-19 11:31:50 --> URI Class Initialized
INFO - 2024-09-19 11:31:50 --> Router Class Initialized
INFO - 2024-09-19 11:31:50 --> Output Class Initialized
INFO - 2024-09-19 11:31:50 --> Security Class Initialized
DEBUG - 2024-09-19 11:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:31:50 --> Input Class Initialized
INFO - 2024-09-19 11:31:50 --> Language Class Initialized
INFO - 2024-09-19 11:31:50 --> Language Class Initialized
INFO - 2024-09-19 11:31:50 --> Config Class Initialized
INFO - 2024-09-19 11:31:50 --> Loader Class Initialized
INFO - 2024-09-19 11:31:50 --> Helper loaded: url_helper
INFO - 2024-09-19 11:31:50 --> Helper loaded: file_helper
INFO - 2024-09-19 11:31:50 --> Helper loaded: form_helper
INFO - 2024-09-19 11:31:50 --> Helper loaded: my_helper
INFO - 2024-09-19 11:31:50 --> Database Driver Class Initialized
INFO - 2024-09-19 11:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:31:50 --> Controller Class Initialized
INFO - 2024-09-19 11:31:50 --> Final output sent to browser
DEBUG - 2024-09-19 11:31:50 --> Total execution time: 0.0407
INFO - 2024-09-19 11:31:51 --> Config Class Initialized
INFO - 2024-09-19 11:31:51 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:31:51 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:31:51 --> Utf8 Class Initialized
INFO - 2024-09-19 11:31:51 --> URI Class Initialized
INFO - 2024-09-19 11:31:51 --> Router Class Initialized
INFO - 2024-09-19 11:31:51 --> Output Class Initialized
INFO - 2024-09-19 11:31:51 --> Security Class Initialized
DEBUG - 2024-09-19 11:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:31:51 --> Input Class Initialized
INFO - 2024-09-19 11:31:51 --> Language Class Initialized
INFO - 2024-09-19 11:31:51 --> Language Class Initialized
INFO - 2024-09-19 11:31:51 --> Config Class Initialized
INFO - 2024-09-19 11:31:51 --> Loader Class Initialized
INFO - 2024-09-19 11:31:51 --> Helper loaded: url_helper
INFO - 2024-09-19 11:31:51 --> Helper loaded: file_helper
INFO - 2024-09-19 11:31:51 --> Helper loaded: form_helper
INFO - 2024-09-19 11:31:51 --> Helper loaded: my_helper
INFO - 2024-09-19 11:31:51 --> Database Driver Class Initialized
INFO - 2024-09-19 11:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:31:51 --> Controller Class Initialized
INFO - 2024-09-19 11:31:51 --> Final output sent to browser
DEBUG - 2024-09-19 11:31:51 --> Total execution time: 0.0668
INFO - 2024-09-19 11:34:21 --> Config Class Initialized
INFO - 2024-09-19 11:34:21 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:34:21 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:34:21 --> Utf8 Class Initialized
INFO - 2024-09-19 11:34:21 --> URI Class Initialized
INFO - 2024-09-19 11:34:21 --> Router Class Initialized
INFO - 2024-09-19 11:34:21 --> Output Class Initialized
INFO - 2024-09-19 11:34:21 --> Security Class Initialized
DEBUG - 2024-09-19 11:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:34:21 --> Input Class Initialized
INFO - 2024-09-19 11:34:21 --> Language Class Initialized
INFO - 2024-09-19 11:34:21 --> Language Class Initialized
INFO - 2024-09-19 11:34:21 --> Config Class Initialized
INFO - 2024-09-19 11:34:21 --> Loader Class Initialized
INFO - 2024-09-19 11:34:21 --> Helper loaded: url_helper
INFO - 2024-09-19 11:34:21 --> Helper loaded: file_helper
INFO - 2024-09-19 11:34:21 --> Helper loaded: form_helper
INFO - 2024-09-19 11:34:21 --> Helper loaded: my_helper
INFO - 2024-09-19 11:34:21 --> Database Driver Class Initialized
INFO - 2024-09-19 11:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:34:21 --> Controller Class Initialized
INFO - 2024-09-19 11:34:21 --> Final output sent to browser
DEBUG - 2024-09-19 11:34:21 --> Total execution time: 0.2005
INFO - 2024-09-19 11:34:28 --> Config Class Initialized
INFO - 2024-09-19 11:34:28 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:34:28 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:34:28 --> Utf8 Class Initialized
INFO - 2024-09-19 11:34:28 --> URI Class Initialized
INFO - 2024-09-19 11:34:28 --> Router Class Initialized
INFO - 2024-09-19 11:34:28 --> Output Class Initialized
INFO - 2024-09-19 11:34:28 --> Security Class Initialized
DEBUG - 2024-09-19 11:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:34:28 --> Input Class Initialized
INFO - 2024-09-19 11:34:28 --> Language Class Initialized
INFO - 2024-09-19 11:34:28 --> Language Class Initialized
INFO - 2024-09-19 11:34:28 --> Config Class Initialized
INFO - 2024-09-19 11:34:28 --> Loader Class Initialized
INFO - 2024-09-19 11:34:28 --> Helper loaded: url_helper
INFO - 2024-09-19 11:34:28 --> Helper loaded: file_helper
INFO - 2024-09-19 11:34:28 --> Helper loaded: form_helper
INFO - 2024-09-19 11:34:28 --> Helper loaded: my_helper
INFO - 2024-09-19 11:34:28 --> Database Driver Class Initialized
INFO - 2024-09-19 11:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:34:28 --> Controller Class Initialized
DEBUG - 2024-09-19 11:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-19 11:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:34:28 --> Final output sent to browser
DEBUG - 2024-09-19 11:34:28 --> Total execution time: 0.0783
INFO - 2024-09-19 11:34:31 --> Config Class Initialized
INFO - 2024-09-19 11:34:31 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:34:31 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:34:31 --> Utf8 Class Initialized
INFO - 2024-09-19 11:34:31 --> URI Class Initialized
INFO - 2024-09-19 11:34:31 --> Router Class Initialized
INFO - 2024-09-19 11:34:31 --> Output Class Initialized
INFO - 2024-09-19 11:34:31 --> Security Class Initialized
DEBUG - 2024-09-19 11:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:34:31 --> Input Class Initialized
INFO - 2024-09-19 11:34:31 --> Language Class Initialized
INFO - 2024-09-19 11:34:31 --> Language Class Initialized
INFO - 2024-09-19 11:34:31 --> Config Class Initialized
INFO - 2024-09-19 11:34:31 --> Loader Class Initialized
INFO - 2024-09-19 11:34:31 --> Helper loaded: url_helper
INFO - 2024-09-19 11:34:31 --> Helper loaded: file_helper
INFO - 2024-09-19 11:34:31 --> Helper loaded: form_helper
INFO - 2024-09-19 11:34:31 --> Helper loaded: my_helper
INFO - 2024-09-19 11:34:31 --> Database Driver Class Initialized
INFO - 2024-09-19 11:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:34:31 --> Controller Class Initialized
DEBUG - 2024-09-19 11:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-19 11:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:34:31 --> Final output sent to browser
DEBUG - 2024-09-19 11:34:31 --> Total execution time: 0.0712
INFO - 2024-09-19 11:34:39 --> Config Class Initialized
INFO - 2024-09-19 11:34:39 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:34:39 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:34:39 --> Utf8 Class Initialized
INFO - 2024-09-19 11:34:39 --> URI Class Initialized
INFO - 2024-09-19 11:34:39 --> Router Class Initialized
INFO - 2024-09-19 11:34:39 --> Output Class Initialized
INFO - 2024-09-19 11:34:39 --> Security Class Initialized
DEBUG - 2024-09-19 11:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:34:39 --> Input Class Initialized
INFO - 2024-09-19 11:34:39 --> Language Class Initialized
INFO - 2024-09-19 11:34:39 --> Language Class Initialized
INFO - 2024-09-19 11:34:39 --> Config Class Initialized
INFO - 2024-09-19 11:34:39 --> Loader Class Initialized
INFO - 2024-09-19 11:34:39 --> Helper loaded: url_helper
INFO - 2024-09-19 11:34:39 --> Helper loaded: file_helper
INFO - 2024-09-19 11:34:39 --> Helper loaded: form_helper
INFO - 2024-09-19 11:34:39 --> Helper loaded: my_helper
INFO - 2024-09-19 11:34:39 --> Database Driver Class Initialized
INFO - 2024-09-19 11:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:34:39 --> Controller Class Initialized
INFO - 2024-09-19 11:34:39 --> Final output sent to browser
DEBUG - 2024-09-19 11:34:39 --> Total execution time: 0.0428
INFO - 2024-09-19 11:49:48 --> Config Class Initialized
INFO - 2024-09-19 11:49:48 --> Hooks Class Initialized
INFO - 2024-09-19 11:49:48 --> Config Class Initialized
INFO - 2024-09-19 11:49:48 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:49:48 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:49:48 --> Utf8 Class Initialized
DEBUG - 2024-09-19 11:49:48 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:49:48 --> Utf8 Class Initialized
INFO - 2024-09-19 11:49:48 --> URI Class Initialized
INFO - 2024-09-19 11:49:48 --> URI Class Initialized
INFO - 2024-09-19 11:49:48 --> Router Class Initialized
INFO - 2024-09-19 11:49:48 --> Router Class Initialized
INFO - 2024-09-19 11:49:48 --> Output Class Initialized
INFO - 2024-09-19 11:49:48 --> Output Class Initialized
INFO - 2024-09-19 11:49:48 --> Security Class Initialized
INFO - 2024-09-19 11:49:48 --> Security Class Initialized
DEBUG - 2024-09-19 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:49:48 --> Input Class Initialized
DEBUG - 2024-09-19 11:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:49:48 --> Input Class Initialized
INFO - 2024-09-19 11:49:48 --> Language Class Initialized
INFO - 2024-09-19 11:49:48 --> Language Class Initialized
INFO - 2024-09-19 11:49:48 --> Language Class Initialized
INFO - 2024-09-19 11:49:48 --> Config Class Initialized
INFO - 2024-09-19 11:49:48 --> Loader Class Initialized
INFO - 2024-09-19 11:49:48 --> Language Class Initialized
INFO - 2024-09-19 11:49:48 --> Config Class Initialized
INFO - 2024-09-19 11:49:48 --> Loader Class Initialized
INFO - 2024-09-19 11:49:48 --> Helper loaded: url_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: url_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: file_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: file_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: form_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: form_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: my_helper
INFO - 2024-09-19 11:49:48 --> Helper loaded: my_helper
INFO - 2024-09-19 11:49:48 --> Database Driver Class Initialized
INFO - 2024-09-19 11:49:48 --> Database Driver Class Initialized
INFO - 2024-09-19 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:49:48 --> Controller Class Initialized
INFO - 2024-09-19 11:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:49:48 --> Controller Class Initialized
INFO - 2024-09-19 11:49:48 --> Final output sent to browser
DEBUG - 2024-09-19 11:49:48 --> Total execution time: 0.0817
DEBUG - 2024-09-19 11:49:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-09-19 11:49:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 11:49:48 --> Final output sent to browser
DEBUG - 2024-09-19 11:49:48 --> Total execution time: 0.0850
INFO - 2024-09-19 11:50:37 --> Config Class Initialized
INFO - 2024-09-19 11:50:37 --> Hooks Class Initialized
DEBUG - 2024-09-19 11:50:37 --> UTF-8 Support Enabled
INFO - 2024-09-19 11:50:37 --> Utf8 Class Initialized
INFO - 2024-09-19 11:50:37 --> URI Class Initialized
INFO - 2024-09-19 11:50:37 --> Router Class Initialized
INFO - 2024-09-19 11:50:37 --> Output Class Initialized
INFO - 2024-09-19 11:50:37 --> Security Class Initialized
DEBUG - 2024-09-19 11:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 11:50:37 --> Input Class Initialized
INFO - 2024-09-19 11:50:37 --> Language Class Initialized
INFO - 2024-09-19 11:50:37 --> Language Class Initialized
INFO - 2024-09-19 11:50:37 --> Config Class Initialized
INFO - 2024-09-19 11:50:37 --> Loader Class Initialized
INFO - 2024-09-19 11:50:37 --> Helper loaded: url_helper
INFO - 2024-09-19 11:50:37 --> Helper loaded: file_helper
INFO - 2024-09-19 11:50:37 --> Helper loaded: form_helper
INFO - 2024-09-19 11:50:37 --> Helper loaded: my_helper
INFO - 2024-09-19 11:50:37 --> Database Driver Class Initialized
INFO - 2024-09-19 11:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 11:50:37 --> Controller Class Initialized
INFO - 2024-09-19 11:50:37 --> Final output sent to browser
DEBUG - 2024-09-19 11:50:37 --> Total execution time: 0.0293
INFO - 2024-09-19 12:04:03 --> Config Class Initialized
INFO - 2024-09-19 12:04:03 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:03 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:03 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:03 --> URI Class Initialized
INFO - 2024-09-19 12:04:03 --> Router Class Initialized
INFO - 2024-09-19 12:04:03 --> Output Class Initialized
INFO - 2024-09-19 12:04:03 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:03 --> Input Class Initialized
INFO - 2024-09-19 12:04:03 --> Language Class Initialized
INFO - 2024-09-19 12:04:03 --> Language Class Initialized
INFO - 2024-09-19 12:04:03 --> Config Class Initialized
INFO - 2024-09-19 12:04:03 --> Loader Class Initialized
INFO - 2024-09-19 12:04:03 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:03 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:03 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:03 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:03 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:03 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:03 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:09 --> Config Class Initialized
INFO - 2024-09-19 12:04:09 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:09 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:09 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:09 --> URI Class Initialized
INFO - 2024-09-19 12:04:09 --> Router Class Initialized
INFO - 2024-09-19 12:04:09 --> Output Class Initialized
INFO - 2024-09-19 12:04:09 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:09 --> Input Class Initialized
INFO - 2024-09-19 12:04:09 --> Language Class Initialized
INFO - 2024-09-19 12:04:09 --> Language Class Initialized
INFO - 2024-09-19 12:04:09 --> Config Class Initialized
INFO - 2024-09-19 12:04:09 --> Loader Class Initialized
INFO - 2024-09-19 12:04:09 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:09 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:09 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:09 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:09 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:09 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:11 --> Controller Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
ERROR - 2024-09-19 12:04:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:11 --> Controller Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
ERROR - 2024-09-19 12:04:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:11 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:11 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:11 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:11 --> URI Class Initialized
INFO - 2024-09-19 12:04:11 --> Router Class Initialized
INFO - 2024-09-19 12:04:11 --> Output Class Initialized
INFO - 2024-09-19 12:04:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:11 --> Input Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Language Class Initialized
INFO - 2024-09-19 12:04:11 --> Config Class Initialized
INFO - 2024-09-19 12:04:11 --> Loader Class Initialized
INFO - 2024-09-19 12:04:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:11 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:11 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:12 --> Controller Class Initialized
INFO - 2024-09-19 12:04:12 --> Config Class Initialized
INFO - 2024-09-19 12:04:12 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:12 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:12 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:12 --> URI Class Initialized
INFO - 2024-09-19 12:04:12 --> Router Class Initialized
INFO - 2024-09-19 12:04:12 --> Output Class Initialized
INFO - 2024-09-19 12:04:12 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:12 --> Input Class Initialized
INFO - 2024-09-19 12:04:12 --> Language Class Initialized
INFO - 2024-09-19 12:04:12 --> Language Class Initialized
INFO - 2024-09-19 12:04:12 --> Config Class Initialized
INFO - 2024-09-19 12:04:12 --> Loader Class Initialized
INFO - 2024-09-19 12:04:12 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:12 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:12 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:12 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:12 --> Database Driver Class Initialized
ERROR - 2024-09-19 12:04:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:12 --> Controller Class Initialized
ERROR - 2024-09-19 12:04:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's comprehension skills. You are beginning to understand the main ideas and detai' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20241', 'c', '51', '10', '73', '-', 'There is a noticeable betterment in the student's comprehension skills. You are beginning to understand the main ideas and details in reading assignments and are making efforts to grasp vocabulary and context within texts. Furthermore, in terms of writing, assignments are becoming more organized and structured, with fewer grammatical errors, although some persist. You are demonstrating increased clarity and coherence in conveying ideas in your writing. Regarding participation, you are engaging more frequently in classroom discussions, contributing occasionally to group activities, and taking initial steps to overcome shyness in verbal communication.')
INFO - 2024-09-19 12:04:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-09-19 12:04:15 --> Config Class Initialized
INFO - 2024-09-19 12:04:15 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:15 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:15 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:15 --> URI Class Initialized
INFO - 2024-09-19 12:04:15 --> Router Class Initialized
INFO - 2024-09-19 12:04:15 --> Output Class Initialized
INFO - 2024-09-19 12:04:15 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:15 --> Input Class Initialized
INFO - 2024-09-19 12:04:15 --> Language Class Initialized
INFO - 2024-09-19 12:04:15 --> Language Class Initialized
INFO - 2024-09-19 12:04:15 --> Config Class Initialized
INFO - 2024-09-19 12:04:15 --> Loader Class Initialized
INFO - 2024-09-19 12:04:15 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:15 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:15 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:15 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:15 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:15 --> Controller Class Initialized
INFO - 2024-09-19 12:04:15 --> Final output sent to browser
DEBUG - 2024-09-19 12:04:15 --> Total execution time: 0.0463
INFO - 2024-09-19 12:04:16 --> Config Class Initialized
INFO - 2024-09-19 12:04:16 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:04:16 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:04:16 --> Utf8 Class Initialized
INFO - 2024-09-19 12:04:16 --> URI Class Initialized
INFO - 2024-09-19 12:04:16 --> Router Class Initialized
INFO - 2024-09-19 12:04:16 --> Output Class Initialized
INFO - 2024-09-19 12:04:16 --> Security Class Initialized
DEBUG - 2024-09-19 12:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:04:16 --> Input Class Initialized
INFO - 2024-09-19 12:04:16 --> Language Class Initialized
INFO - 2024-09-19 12:04:16 --> Language Class Initialized
INFO - 2024-09-19 12:04:16 --> Config Class Initialized
INFO - 2024-09-19 12:04:16 --> Loader Class Initialized
INFO - 2024-09-19 12:04:16 --> Helper loaded: url_helper
INFO - 2024-09-19 12:04:16 --> Helper loaded: file_helper
INFO - 2024-09-19 12:04:16 --> Helper loaded: form_helper
INFO - 2024-09-19 12:04:16 --> Helper loaded: my_helper
INFO - 2024-09-19 12:04:16 --> Database Driver Class Initialized
INFO - 2024-09-19 12:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:04:16 --> Controller Class Initialized
INFO - 2024-09-19 12:04:16 --> Final output sent to browser
DEBUG - 2024-09-19 12:04:16 --> Total execution time: 0.0350
INFO - 2024-09-19 12:10:44 --> Config Class Initialized
INFO - 2024-09-19 12:10:44 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:10:44 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:10:44 --> Utf8 Class Initialized
INFO - 2024-09-19 12:10:44 --> URI Class Initialized
INFO - 2024-09-19 12:10:44 --> Router Class Initialized
INFO - 2024-09-19 12:10:44 --> Output Class Initialized
INFO - 2024-09-19 12:10:44 --> Security Class Initialized
DEBUG - 2024-09-19 12:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:10:44 --> Input Class Initialized
INFO - 2024-09-19 12:10:44 --> Language Class Initialized
INFO - 2024-09-19 12:10:44 --> Language Class Initialized
INFO - 2024-09-19 12:10:44 --> Config Class Initialized
INFO - 2024-09-19 12:10:44 --> Loader Class Initialized
INFO - 2024-09-19 12:10:44 --> Helper loaded: url_helper
INFO - 2024-09-19 12:10:44 --> Helper loaded: file_helper
INFO - 2024-09-19 12:10:44 --> Helper loaded: form_helper
INFO - 2024-09-19 12:10:44 --> Helper loaded: my_helper
INFO - 2024-09-19 12:10:44 --> Database Driver Class Initialized
INFO - 2024-09-19 12:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:10:44 --> Controller Class Initialized
DEBUG - 2024-09-19 12:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-09-19 12:10:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 12:10:44 --> Final output sent to browser
DEBUG - 2024-09-19 12:10:44 --> Total execution time: 0.0663
INFO - 2024-09-19 12:11:11 --> Config Class Initialized
INFO - 2024-09-19 12:11:11 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:11:11 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:11:11 --> Utf8 Class Initialized
INFO - 2024-09-19 12:11:11 --> URI Class Initialized
INFO - 2024-09-19 12:11:11 --> Router Class Initialized
INFO - 2024-09-19 12:11:11 --> Output Class Initialized
INFO - 2024-09-19 12:11:11 --> Security Class Initialized
DEBUG - 2024-09-19 12:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:11:11 --> Input Class Initialized
INFO - 2024-09-19 12:11:11 --> Language Class Initialized
INFO - 2024-09-19 12:11:11 --> Language Class Initialized
INFO - 2024-09-19 12:11:11 --> Config Class Initialized
INFO - 2024-09-19 12:11:11 --> Loader Class Initialized
INFO - 2024-09-19 12:11:11 --> Helper loaded: url_helper
INFO - 2024-09-19 12:11:11 --> Helper loaded: file_helper
INFO - 2024-09-19 12:11:11 --> Helper loaded: form_helper
INFO - 2024-09-19 12:11:11 --> Helper loaded: my_helper
INFO - 2024-09-19 12:11:11 --> Database Driver Class Initialized
INFO - 2024-09-19 12:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:11:11 --> Controller Class Initialized
DEBUG - 2024-09-19 12:11:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-09-19 12:11:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 12:11:11 --> Final output sent to browser
DEBUG - 2024-09-19 12:11:11 --> Total execution time: 0.1950
INFO - 2024-09-19 12:11:15 --> Config Class Initialized
INFO - 2024-09-19 12:11:15 --> Hooks Class Initialized
DEBUG - 2024-09-19 12:11:15 --> UTF-8 Support Enabled
INFO - 2024-09-19 12:11:15 --> Utf8 Class Initialized
INFO - 2024-09-19 12:11:15 --> URI Class Initialized
DEBUG - 2024-09-19 12:11:15 --> No URI present. Default controller set.
INFO - 2024-09-19 12:11:15 --> Router Class Initialized
INFO - 2024-09-19 12:11:15 --> Output Class Initialized
INFO - 2024-09-19 12:11:15 --> Security Class Initialized
DEBUG - 2024-09-19 12:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-19 12:11:15 --> Input Class Initialized
INFO - 2024-09-19 12:11:15 --> Language Class Initialized
INFO - 2024-09-19 12:11:15 --> Language Class Initialized
INFO - 2024-09-19 12:11:15 --> Config Class Initialized
INFO - 2024-09-19 12:11:15 --> Loader Class Initialized
INFO - 2024-09-19 12:11:15 --> Helper loaded: url_helper
INFO - 2024-09-19 12:11:15 --> Helper loaded: file_helper
INFO - 2024-09-19 12:11:15 --> Helper loaded: form_helper
INFO - 2024-09-19 12:11:15 --> Helper loaded: my_helper
INFO - 2024-09-19 12:11:15 --> Database Driver Class Initialized
INFO - 2024-09-19 12:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-19 12:11:15 --> Controller Class Initialized
DEBUG - 2024-09-19 12:11:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-09-19 12:11:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-19 12:11:15 --> Final output sent to browser
DEBUG - 2024-09-19 12:11:15 --> Total execution time: 0.0493
