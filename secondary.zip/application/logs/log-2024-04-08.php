<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-04-08 13:48:17 --> Config Class Initialized
INFO - 2024-04-08 13:48:17 --> Hooks Class Initialized
DEBUG - 2024-04-08 13:48:17 --> UTF-8 Support Enabled
INFO - 2024-04-08 13:48:17 --> Utf8 Class Initialized
INFO - 2024-04-08 13:48:17 --> URI Class Initialized
INFO - 2024-04-08 13:48:17 --> Router Class Initialized
INFO - 2024-04-08 13:48:17 --> Output Class Initialized
INFO - 2024-04-08 13:48:17 --> Security Class Initialized
DEBUG - 2024-04-08 13:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 13:48:17 --> Input Class Initialized
INFO - 2024-04-08 13:48:17 --> Language Class Initialized
INFO - 2024-04-08 13:48:17 --> Language Class Initialized
INFO - 2024-04-08 13:48:17 --> Config Class Initialized
INFO - 2024-04-08 13:48:17 --> Loader Class Initialized
INFO - 2024-04-08 13:48:17 --> Helper loaded: url_helper
INFO - 2024-04-08 13:48:17 --> Helper loaded: file_helper
INFO - 2024-04-08 13:48:17 --> Helper loaded: form_helper
INFO - 2024-04-08 13:48:17 --> Helper loaded: my_helper
INFO - 2024-04-08 13:48:17 --> Database Driver Class Initialized
INFO - 2024-04-08 13:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 13:48:17 --> Controller Class Initialized
DEBUG - 2024-04-08 13:48:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-04-08 13:48:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-08 13:48:17 --> Final output sent to browser
DEBUG - 2024-04-08 13:48:17 --> Total execution time: 0.0600
INFO - 2024-04-08 13:48:19 --> Config Class Initialized
INFO - 2024-04-08 13:48:19 --> Hooks Class Initialized
DEBUG - 2024-04-08 13:48:19 --> UTF-8 Support Enabled
INFO - 2024-04-08 13:48:19 --> Utf8 Class Initialized
INFO - 2024-04-08 13:48:19 --> URI Class Initialized
INFO - 2024-04-08 13:48:19 --> Router Class Initialized
INFO - 2024-04-08 13:48:19 --> Output Class Initialized
INFO - 2024-04-08 13:48:19 --> Security Class Initialized
DEBUG - 2024-04-08 13:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 13:48:19 --> Input Class Initialized
INFO - 2024-04-08 13:48:19 --> Language Class Initialized
INFO - 2024-04-08 13:48:19 --> Language Class Initialized
INFO - 2024-04-08 13:48:19 --> Config Class Initialized
INFO - 2024-04-08 13:48:19 --> Loader Class Initialized
INFO - 2024-04-08 13:48:19 --> Helper loaded: url_helper
INFO - 2024-04-08 13:48:19 --> Helper loaded: file_helper
INFO - 2024-04-08 13:48:19 --> Helper loaded: form_helper
INFO - 2024-04-08 13:48:19 --> Helper loaded: my_helper
INFO - 2024-04-08 13:48:19 --> Database Driver Class Initialized
INFO - 2024-04-08 13:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 13:48:19 --> Controller Class Initialized
INFO - 2024-04-08 20:25:59 --> Config Class Initialized
INFO - 2024-04-08 20:25:59 --> Hooks Class Initialized
DEBUG - 2024-04-08 20:25:59 --> UTF-8 Support Enabled
INFO - 2024-04-08 20:25:59 --> Utf8 Class Initialized
INFO - 2024-04-08 20:25:59 --> URI Class Initialized
INFO - 2024-04-08 20:25:59 --> Router Class Initialized
INFO - 2024-04-08 20:25:59 --> Output Class Initialized
INFO - 2024-04-08 20:25:59 --> Security Class Initialized
DEBUG - 2024-04-08 20:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 20:25:59 --> Input Class Initialized
INFO - 2024-04-08 20:25:59 --> Language Class Initialized
INFO - 2024-04-08 20:25:59 --> Language Class Initialized
INFO - 2024-04-08 20:25:59 --> Config Class Initialized
INFO - 2024-04-08 20:25:59 --> Loader Class Initialized
INFO - 2024-04-08 20:25:59 --> Helper loaded: url_helper
INFO - 2024-04-08 20:25:59 --> Helper loaded: file_helper
INFO - 2024-04-08 20:25:59 --> Helper loaded: form_helper
INFO - 2024-04-08 20:25:59 --> Helper loaded: my_helper
INFO - 2024-04-08 20:25:59 --> Database Driver Class Initialized
INFO - 2024-04-08 20:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 20:25:59 --> Controller Class Initialized
DEBUG - 2024-04-08 20:26:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-04-08 20:26:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-08 20:26:00 --> Final output sent to browser
DEBUG - 2024-04-08 20:26:00 --> Total execution time: 0.0607
INFO - 2024-04-08 20:26:00 --> Config Class Initialized
INFO - 2024-04-08 20:26:00 --> Hooks Class Initialized
DEBUG - 2024-04-08 20:26:00 --> UTF-8 Support Enabled
INFO - 2024-04-08 20:26:00 --> Utf8 Class Initialized
INFO - 2024-04-08 20:26:00 --> URI Class Initialized
INFO - 2024-04-08 20:26:00 --> Router Class Initialized
INFO - 2024-04-08 20:26:00 --> Output Class Initialized
INFO - 2024-04-08 20:26:00 --> Security Class Initialized
DEBUG - 2024-04-08 20:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 20:26:00 --> Input Class Initialized
INFO - 2024-04-08 20:26:00 --> Language Class Initialized
INFO - 2024-04-08 20:26:00 --> Language Class Initialized
INFO - 2024-04-08 20:26:00 --> Config Class Initialized
INFO - 2024-04-08 20:26:00 --> Loader Class Initialized
INFO - 2024-04-08 20:26:00 --> Helper loaded: url_helper
INFO - 2024-04-08 20:26:00 --> Helper loaded: file_helper
INFO - 2024-04-08 20:26:00 --> Helper loaded: form_helper
INFO - 2024-04-08 20:26:00 --> Helper loaded: my_helper
INFO - 2024-04-08 20:26:00 --> Database Driver Class Initialized
INFO - 2024-04-08 20:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 20:26:00 --> Controller Class Initialized
INFO - 2024-04-08 22:14:38 --> Config Class Initialized
INFO - 2024-04-08 22:14:38 --> Hooks Class Initialized
DEBUG - 2024-04-08 22:14:38 --> UTF-8 Support Enabled
INFO - 2024-04-08 22:14:38 --> Utf8 Class Initialized
INFO - 2024-04-08 22:14:38 --> URI Class Initialized
INFO - 2024-04-08 22:14:38 --> Router Class Initialized
INFO - 2024-04-08 22:14:38 --> Output Class Initialized
INFO - 2024-04-08 22:14:38 --> Security Class Initialized
DEBUG - 2024-04-08 22:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 22:14:38 --> Input Class Initialized
INFO - 2024-04-08 22:14:38 --> Language Class Initialized
INFO - 2024-04-08 22:14:38 --> Language Class Initialized
INFO - 2024-04-08 22:14:38 --> Config Class Initialized
INFO - 2024-04-08 22:14:38 --> Loader Class Initialized
INFO - 2024-04-08 22:14:38 --> Helper loaded: url_helper
INFO - 2024-04-08 22:14:38 --> Helper loaded: file_helper
INFO - 2024-04-08 22:14:38 --> Helper loaded: form_helper
INFO - 2024-04-08 22:14:38 --> Helper loaded: my_helper
INFO - 2024-04-08 22:14:38 --> Database Driver Class Initialized
INFO - 2024-04-08 22:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 22:14:38 --> Controller Class Initialized
DEBUG - 2024-04-08 22:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-04-08 22:14:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-04-08 22:14:38 --> Final output sent to browser
DEBUG - 2024-04-08 22:14:38 --> Total execution time: 0.0516
INFO - 2024-04-08 22:14:39 --> Config Class Initialized
INFO - 2024-04-08 22:14:39 --> Hooks Class Initialized
DEBUG - 2024-04-08 22:14:39 --> UTF-8 Support Enabled
INFO - 2024-04-08 22:14:39 --> Utf8 Class Initialized
INFO - 2024-04-08 22:14:39 --> URI Class Initialized
INFO - 2024-04-08 22:14:39 --> Router Class Initialized
INFO - 2024-04-08 22:14:39 --> Output Class Initialized
INFO - 2024-04-08 22:14:39 --> Security Class Initialized
DEBUG - 2024-04-08 22:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-04-08 22:14:39 --> Input Class Initialized
INFO - 2024-04-08 22:14:39 --> Language Class Initialized
INFO - 2024-04-08 22:14:39 --> Language Class Initialized
INFO - 2024-04-08 22:14:39 --> Config Class Initialized
INFO - 2024-04-08 22:14:39 --> Loader Class Initialized
INFO - 2024-04-08 22:14:39 --> Helper loaded: url_helper
INFO - 2024-04-08 22:14:39 --> Helper loaded: file_helper
INFO - 2024-04-08 22:14:39 --> Helper loaded: form_helper
INFO - 2024-04-08 22:14:39 --> Helper loaded: my_helper
INFO - 2024-04-08 22:14:39 --> Database Driver Class Initialized
INFO - 2024-04-08 22:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-04-08 22:14:39 --> Controller Class Initialized
