<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-14 06:14:20 --> Config Class Initialized
INFO - 2023-04-14 06:14:20 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:20 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:20 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:20 --> URI Class Initialized
DEBUG - 2023-04-14 06:14:21 --> No URI present. Default controller set.
INFO - 2023-04-14 06:14:21 --> Router Class Initialized
INFO - 2023-04-14 06:14:21 --> Output Class Initialized
INFO - 2023-04-14 06:14:21 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:21 --> Input Class Initialized
INFO - 2023-04-14 06:14:21 --> Language Class Initialized
INFO - 2023-04-14 06:14:21 --> Language Class Initialized
INFO - 2023-04-14 06:14:21 --> Config Class Initialized
INFO - 2023-04-14 06:14:21 --> Loader Class Initialized
INFO - 2023-04-14 06:14:21 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:21 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:21 --> Controller Class Initialized
INFO - 2023-04-14 06:14:21 --> Config Class Initialized
INFO - 2023-04-14 06:14:21 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:21 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:21 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:21 --> URI Class Initialized
INFO - 2023-04-14 06:14:21 --> Router Class Initialized
INFO - 2023-04-14 06:14:21 --> Output Class Initialized
INFO - 2023-04-14 06:14:21 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:21 --> Input Class Initialized
INFO - 2023-04-14 06:14:21 --> Language Class Initialized
INFO - 2023-04-14 06:14:21 --> Language Class Initialized
INFO - 2023-04-14 06:14:21 --> Config Class Initialized
INFO - 2023-04-14 06:14:21 --> Loader Class Initialized
INFO - 2023-04-14 06:14:21 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:21 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:21 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:21 --> Controller Class Initialized
DEBUG - 2023-04-14 06:14:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-14 06:14:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:14:21 --> Final output sent to browser
DEBUG - 2023-04-14 06:14:21 --> Total execution time: 0.0685
INFO - 2023-04-14 06:14:47 --> Config Class Initialized
INFO - 2023-04-14 06:14:47 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:47 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:47 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:47 --> URI Class Initialized
INFO - 2023-04-14 06:14:47 --> Router Class Initialized
INFO - 2023-04-14 06:14:47 --> Output Class Initialized
INFO - 2023-04-14 06:14:47 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:47 --> Input Class Initialized
INFO - 2023-04-14 06:14:47 --> Language Class Initialized
INFO - 2023-04-14 06:14:47 --> Language Class Initialized
INFO - 2023-04-14 06:14:47 --> Config Class Initialized
INFO - 2023-04-14 06:14:47 --> Loader Class Initialized
INFO - 2023-04-14 06:14:47 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:47 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:47 --> Controller Class Initialized
INFO - 2023-04-14 06:14:47 --> Helper loaded: cookie_helper
INFO - 2023-04-14 06:14:47 --> Final output sent to browser
DEBUG - 2023-04-14 06:14:47 --> Total execution time: 0.0459
INFO - 2023-04-14 06:14:47 --> Config Class Initialized
INFO - 2023-04-14 06:14:47 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:47 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:47 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:47 --> URI Class Initialized
INFO - 2023-04-14 06:14:47 --> Router Class Initialized
INFO - 2023-04-14 06:14:47 --> Output Class Initialized
INFO - 2023-04-14 06:14:47 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:47 --> Input Class Initialized
INFO - 2023-04-14 06:14:47 --> Language Class Initialized
INFO - 2023-04-14 06:14:47 --> Language Class Initialized
INFO - 2023-04-14 06:14:47 --> Config Class Initialized
INFO - 2023-04-14 06:14:47 --> Loader Class Initialized
INFO - 2023-04-14 06:14:47 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:47 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:47 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:47 --> Controller Class Initialized
DEBUG - 2023-04-14 06:14:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-14 06:14:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:14:47 --> Final output sent to browser
DEBUG - 2023-04-14 06:14:47 --> Total execution time: 0.0575
INFO - 2023-04-14 06:14:54 --> Config Class Initialized
INFO - 2023-04-14 06:14:54 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:54 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:54 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:54 --> URI Class Initialized
INFO - 2023-04-14 06:14:54 --> Router Class Initialized
INFO - 2023-04-14 06:14:54 --> Output Class Initialized
INFO - 2023-04-14 06:14:54 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:54 --> Input Class Initialized
INFO - 2023-04-14 06:14:54 --> Language Class Initialized
INFO - 2023-04-14 06:14:54 --> Language Class Initialized
INFO - 2023-04-14 06:14:54 --> Config Class Initialized
INFO - 2023-04-14 06:14:54 --> Loader Class Initialized
INFO - 2023-04-14 06:14:54 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:54 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:54 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:54 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:54 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:54 --> Controller Class Initialized
DEBUG - 2023-04-14 06:14:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-04-14 06:14:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:14:54 --> Final output sent to browser
DEBUG - 2023-04-14 06:14:54 --> Total execution time: 0.0798
INFO - 2023-04-14 06:14:58 --> Config Class Initialized
INFO - 2023-04-14 06:14:58 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:14:58 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:14:58 --> Utf8 Class Initialized
INFO - 2023-04-14 06:14:58 --> URI Class Initialized
INFO - 2023-04-14 06:14:58 --> Router Class Initialized
INFO - 2023-04-14 06:14:58 --> Output Class Initialized
INFO - 2023-04-14 06:14:58 --> Security Class Initialized
DEBUG - 2023-04-14 06:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:14:58 --> Input Class Initialized
INFO - 2023-04-14 06:14:58 --> Language Class Initialized
INFO - 2023-04-14 06:14:58 --> Language Class Initialized
INFO - 2023-04-14 06:14:58 --> Config Class Initialized
INFO - 2023-04-14 06:14:58 --> Loader Class Initialized
INFO - 2023-04-14 06:14:58 --> Helper loaded: url_helper
INFO - 2023-04-14 06:14:58 --> Helper loaded: file_helper
INFO - 2023-04-14 06:14:58 --> Helper loaded: form_helper
INFO - 2023-04-14 06:14:58 --> Helper loaded: my_helper
INFO - 2023-04-14 06:14:58 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:14:58 --> Controller Class Initialized
DEBUG - 2023-04-14 06:14:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-14 06:14:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:14:58 --> Final output sent to browser
DEBUG - 2023-04-14 06:14:58 --> Total execution time: 0.0809
INFO - 2023-04-14 06:15:08 --> Config Class Initialized
INFO - 2023-04-14 06:15:08 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:15:08 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:15:08 --> Utf8 Class Initialized
INFO - 2023-04-14 06:15:08 --> URI Class Initialized
INFO - 2023-04-14 06:15:08 --> Router Class Initialized
INFO - 2023-04-14 06:15:08 --> Output Class Initialized
INFO - 2023-04-14 06:15:08 --> Security Class Initialized
DEBUG - 2023-04-14 06:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:15:08 --> Input Class Initialized
INFO - 2023-04-14 06:15:08 --> Language Class Initialized
INFO - 2023-04-14 06:15:08 --> Language Class Initialized
INFO - 2023-04-14 06:15:08 --> Config Class Initialized
INFO - 2023-04-14 06:15:08 --> Loader Class Initialized
INFO - 2023-04-14 06:15:08 --> Helper loaded: url_helper
INFO - 2023-04-14 06:15:08 --> Helper loaded: file_helper
INFO - 2023-04-14 06:15:08 --> Helper loaded: form_helper
INFO - 2023-04-14 06:15:08 --> Helper loaded: my_helper
INFO - 2023-04-14 06:15:08 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:15:08 --> Controller Class Initialized
DEBUG - 2023-04-14 06:15:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-14 06:15:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:15:08 --> Final output sent to browser
DEBUG - 2023-04-14 06:15:08 --> Total execution time: 0.0828
INFO - 2023-04-14 06:15:22 --> Config Class Initialized
INFO - 2023-04-14 06:15:22 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:15:22 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:15:22 --> Utf8 Class Initialized
INFO - 2023-04-14 06:15:22 --> URI Class Initialized
INFO - 2023-04-14 06:15:22 --> Router Class Initialized
INFO - 2023-04-14 06:15:22 --> Output Class Initialized
INFO - 2023-04-14 06:15:22 --> Security Class Initialized
DEBUG - 2023-04-14 06:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:15:22 --> Input Class Initialized
INFO - 2023-04-14 06:15:22 --> Language Class Initialized
INFO - 2023-04-14 06:15:22 --> Language Class Initialized
INFO - 2023-04-14 06:15:22 --> Config Class Initialized
INFO - 2023-04-14 06:15:22 --> Loader Class Initialized
INFO - 2023-04-14 06:15:22 --> Helper loaded: url_helper
INFO - 2023-04-14 06:15:22 --> Helper loaded: file_helper
INFO - 2023-04-14 06:15:22 --> Helper loaded: form_helper
INFO - 2023-04-14 06:15:22 --> Helper loaded: my_helper
INFO - 2023-04-14 06:15:22 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:15:22 --> Controller Class Initialized
DEBUG - 2023-04-14 06:15:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-04-14 06:15:24 --> Final output sent to browser
DEBUG - 2023-04-14 06:15:24 --> Total execution time: 1.9545
INFO - 2023-04-14 06:15:35 --> Config Class Initialized
INFO - 2023-04-14 06:15:35 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:15:35 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:15:35 --> Utf8 Class Initialized
INFO - 2023-04-14 06:15:35 --> URI Class Initialized
INFO - 2023-04-14 06:15:35 --> Router Class Initialized
INFO - 2023-04-14 06:15:35 --> Output Class Initialized
INFO - 2023-04-14 06:15:35 --> Security Class Initialized
DEBUG - 2023-04-14 06:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:15:35 --> Input Class Initialized
INFO - 2023-04-14 06:15:35 --> Language Class Initialized
INFO - 2023-04-14 06:15:35 --> Language Class Initialized
INFO - 2023-04-14 06:15:35 --> Config Class Initialized
INFO - 2023-04-14 06:15:35 --> Loader Class Initialized
INFO - 2023-04-14 06:15:35 --> Helper loaded: url_helper
INFO - 2023-04-14 06:15:35 --> Helper loaded: file_helper
INFO - 2023-04-14 06:15:35 --> Helper loaded: form_helper
INFO - 2023-04-14 06:15:35 --> Helper loaded: my_helper
INFO - 2023-04-14 06:15:35 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:15:35 --> Controller Class Initialized
DEBUG - 2023-04-14 06:15:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-04-14 06:15:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:15:35 --> Final output sent to browser
DEBUG - 2023-04-14 06:15:35 --> Total execution time: 0.0602
INFO - 2023-04-14 06:16:07 --> Config Class Initialized
INFO - 2023-04-14 06:16:07 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:07 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:07 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:07 --> URI Class Initialized
INFO - 2023-04-14 06:16:07 --> Router Class Initialized
INFO - 2023-04-14 06:16:07 --> Output Class Initialized
INFO - 2023-04-14 06:16:07 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:07 --> Input Class Initialized
INFO - 2023-04-14 06:16:07 --> Language Class Initialized
INFO - 2023-04-14 06:16:07 --> Language Class Initialized
INFO - 2023-04-14 06:16:07 --> Config Class Initialized
INFO - 2023-04-14 06:16:07 --> Loader Class Initialized
INFO - 2023-04-14 06:16:07 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:07 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:07 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:07 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:07 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:07 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:16:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:07 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:07 --> Total execution time: 0.0733
INFO - 2023-04-14 06:16:20 --> Config Class Initialized
INFO - 2023-04-14 06:16:20 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:20 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:20 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:20 --> URI Class Initialized
INFO - 2023-04-14 06:16:20 --> Router Class Initialized
INFO - 2023-04-14 06:16:20 --> Output Class Initialized
INFO - 2023-04-14 06:16:20 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:20 --> Input Class Initialized
INFO - 2023-04-14 06:16:20 --> Language Class Initialized
INFO - 2023-04-14 06:16:20 --> Language Class Initialized
INFO - 2023-04-14 06:16:20 --> Config Class Initialized
INFO - 2023-04-14 06:16:20 --> Loader Class Initialized
INFO - 2023-04-14 06:16:20 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:20 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:20 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-04-14 06:16:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:20 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:20 --> Total execution time: 0.1280
INFO - 2023-04-14 06:16:20 --> Config Class Initialized
INFO - 2023-04-14 06:16:20 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:20 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:20 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:20 --> URI Class Initialized
INFO - 2023-04-14 06:16:20 --> Router Class Initialized
INFO - 2023-04-14 06:16:20 --> Output Class Initialized
INFO - 2023-04-14 06:16:20 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:20 --> Input Class Initialized
INFO - 2023-04-14 06:16:20 --> Language Class Initialized
INFO - 2023-04-14 06:16:20 --> Language Class Initialized
INFO - 2023-04-14 06:16:20 --> Config Class Initialized
INFO - 2023-04-14 06:16:20 --> Loader Class Initialized
INFO - 2023-04-14 06:16:20 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:20 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:20 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:20 --> Controller Class Initialized
INFO - 2023-04-14 06:16:23 --> Config Class Initialized
INFO - 2023-04-14 06:16:23 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:23 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:23 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:23 --> URI Class Initialized
INFO - 2023-04-14 06:16:23 --> Router Class Initialized
INFO - 2023-04-14 06:16:23 --> Output Class Initialized
INFO - 2023-04-14 06:16:23 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:23 --> Input Class Initialized
INFO - 2023-04-14 06:16:23 --> Language Class Initialized
INFO - 2023-04-14 06:16:23 --> Language Class Initialized
INFO - 2023-04-14 06:16:23 --> Config Class Initialized
INFO - 2023-04-14 06:16:23 --> Loader Class Initialized
INFO - 2023-04-14 06:16:23 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:23 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:23 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:23 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:23 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:23 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:16:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:23 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:23 --> Total execution time: 0.0272
INFO - 2023-04-14 06:16:25 --> Config Class Initialized
INFO - 2023-04-14 06:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:25 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:25 --> URI Class Initialized
INFO - 2023-04-14 06:16:25 --> Router Class Initialized
INFO - 2023-04-14 06:16:25 --> Output Class Initialized
INFO - 2023-04-14 06:16:25 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:25 --> Input Class Initialized
INFO - 2023-04-14 06:16:25 --> Language Class Initialized
INFO - 2023-04-14 06:16:25 --> Language Class Initialized
INFO - 2023-04-14 06:16:25 --> Config Class Initialized
INFO - 2023-04-14 06:16:25 --> Loader Class Initialized
INFO - 2023-04-14 06:16:25 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:25 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:25 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-04-14 06:16:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:25 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:25 --> Total execution time: 0.0240
INFO - 2023-04-14 06:16:25 --> Config Class Initialized
INFO - 2023-04-14 06:16:25 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:25 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:25 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:25 --> URI Class Initialized
INFO - 2023-04-14 06:16:25 --> Router Class Initialized
INFO - 2023-04-14 06:16:25 --> Output Class Initialized
INFO - 2023-04-14 06:16:25 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:25 --> Input Class Initialized
INFO - 2023-04-14 06:16:25 --> Language Class Initialized
INFO - 2023-04-14 06:16:25 --> Language Class Initialized
INFO - 2023-04-14 06:16:25 --> Config Class Initialized
INFO - 2023-04-14 06:16:25 --> Loader Class Initialized
INFO - 2023-04-14 06:16:25 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:25 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:25 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:25 --> Controller Class Initialized
INFO - 2023-04-14 06:16:27 --> Config Class Initialized
INFO - 2023-04-14 06:16:27 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:27 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:27 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:27 --> URI Class Initialized
INFO - 2023-04-14 06:16:27 --> Router Class Initialized
INFO - 2023-04-14 06:16:27 --> Output Class Initialized
INFO - 2023-04-14 06:16:27 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:27 --> Input Class Initialized
INFO - 2023-04-14 06:16:27 --> Language Class Initialized
INFO - 2023-04-14 06:16:27 --> Language Class Initialized
INFO - 2023-04-14 06:16:27 --> Config Class Initialized
INFO - 2023-04-14 06:16:27 --> Loader Class Initialized
INFO - 2023-04-14 06:16:27 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:27 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:27 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:27 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:27 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:27 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:16:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:27 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:27 --> Total execution time: 0.0451
INFO - 2023-04-14 06:16:28 --> Config Class Initialized
INFO - 2023-04-14 06:16:28 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:28 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:28 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:28 --> URI Class Initialized
INFO - 2023-04-14 06:16:28 --> Router Class Initialized
INFO - 2023-04-14 06:16:28 --> Output Class Initialized
INFO - 2023-04-14 06:16:28 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:28 --> Input Class Initialized
INFO - 2023-04-14 06:16:28 --> Language Class Initialized
INFO - 2023-04-14 06:16:28 --> Language Class Initialized
INFO - 2023-04-14 06:16:28 --> Config Class Initialized
INFO - 2023-04-14 06:16:28 --> Loader Class Initialized
INFO - 2023-04-14 06:16:28 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:28 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:28 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-04-14 06:16:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:28 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:28 --> Total execution time: 0.0558
INFO - 2023-04-14 06:16:28 --> Config Class Initialized
INFO - 2023-04-14 06:16:28 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:28 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:28 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:28 --> URI Class Initialized
INFO - 2023-04-14 06:16:28 --> Router Class Initialized
INFO - 2023-04-14 06:16:28 --> Output Class Initialized
INFO - 2023-04-14 06:16:28 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:28 --> Input Class Initialized
INFO - 2023-04-14 06:16:28 --> Language Class Initialized
INFO - 2023-04-14 06:16:28 --> Language Class Initialized
INFO - 2023-04-14 06:16:28 --> Config Class Initialized
INFO - 2023-04-14 06:16:28 --> Loader Class Initialized
INFO - 2023-04-14 06:16:28 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:28 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:28 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:28 --> Controller Class Initialized
INFO - 2023-04-14 06:16:30 --> Config Class Initialized
INFO - 2023-04-14 06:16:30 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:30 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:30 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:30 --> URI Class Initialized
INFO - 2023-04-14 06:16:30 --> Router Class Initialized
INFO - 2023-04-14 06:16:30 --> Output Class Initialized
INFO - 2023-04-14 06:16:30 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:30 --> Input Class Initialized
INFO - 2023-04-14 06:16:30 --> Language Class Initialized
INFO - 2023-04-14 06:16:30 --> Language Class Initialized
INFO - 2023-04-14 06:16:30 --> Config Class Initialized
INFO - 2023-04-14 06:16:30 --> Loader Class Initialized
INFO - 2023-04-14 06:16:30 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:30 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:30 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:30 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:30 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:30 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:16:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:30 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:30 --> Total execution time: 0.0269
INFO - 2023-04-14 06:16:31 --> Config Class Initialized
INFO - 2023-04-14 06:16:31 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:31 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:31 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:31 --> URI Class Initialized
INFO - 2023-04-14 06:16:31 --> Router Class Initialized
INFO - 2023-04-14 06:16:31 --> Output Class Initialized
INFO - 2023-04-14 06:16:31 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:31 --> Input Class Initialized
INFO - 2023-04-14 06:16:31 --> Language Class Initialized
INFO - 2023-04-14 06:16:31 --> Language Class Initialized
INFO - 2023-04-14 06:16:31 --> Config Class Initialized
INFO - 2023-04-14 06:16:31 --> Loader Class Initialized
INFO - 2023-04-14 06:16:31 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:31 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:31 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pss/views/list.php
DEBUG - 2023-04-14 06:16:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:31 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:31 --> Total execution time: 0.0552
INFO - 2023-04-14 06:16:31 --> Config Class Initialized
INFO - 2023-04-14 06:16:31 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:31 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:31 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:31 --> URI Class Initialized
INFO - 2023-04-14 06:16:31 --> Router Class Initialized
INFO - 2023-04-14 06:16:31 --> Output Class Initialized
INFO - 2023-04-14 06:16:31 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:31 --> Input Class Initialized
INFO - 2023-04-14 06:16:31 --> Language Class Initialized
INFO - 2023-04-14 06:16:31 --> Language Class Initialized
INFO - 2023-04-14 06:16:31 --> Config Class Initialized
INFO - 2023-04-14 06:16:31 --> Loader Class Initialized
INFO - 2023-04-14 06:16:31 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:31 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:31 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:31 --> Controller Class Initialized
INFO - 2023-04-14 06:16:32 --> Config Class Initialized
INFO - 2023-04-14 06:16:32 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:32 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:32 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:32 --> URI Class Initialized
INFO - 2023-04-14 06:16:32 --> Router Class Initialized
INFO - 2023-04-14 06:16:32 --> Output Class Initialized
INFO - 2023-04-14 06:16:32 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:32 --> Input Class Initialized
INFO - 2023-04-14 06:16:32 --> Language Class Initialized
INFO - 2023-04-14 06:16:32 --> Language Class Initialized
INFO - 2023-04-14 06:16:32 --> Config Class Initialized
INFO - 2023-04-14 06:16:32 --> Loader Class Initialized
INFO - 2023-04-14 06:16:32 --> Helper loaded: url_helper
INFO - 2023-04-14 06:16:32 --> Helper loaded: file_helper
INFO - 2023-04-14 06:16:32 --> Helper loaded: form_helper
INFO - 2023-04-14 06:16:32 --> Helper loaded: my_helper
INFO - 2023-04-14 06:16:32 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:16:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:16:32 --> Controller Class Initialized
DEBUG - 2023-04-14 06:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:16:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:16:32 --> Final output sent to browser
DEBUG - 2023-04-14 06:16:32 --> Total execution time: 0.0467
INFO - 2023-04-14 06:16:52 --> Config Class Initialized
INFO - 2023-04-14 06:16:52 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:16:52 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:16:52 --> Utf8 Class Initialized
INFO - 2023-04-14 06:16:52 --> URI Class Initialized
INFO - 2023-04-14 06:16:52 --> Router Class Initialized
INFO - 2023-04-14 06:16:52 --> Output Class Initialized
INFO - 2023-04-14 06:16:52 --> Security Class Initialized
DEBUG - 2023-04-14 06:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:16:52 --> Input Class Initialized
INFO - 2023-04-14 06:16:52 --> Language Class Initialized
ERROR - 2023-04-14 06:16:52 --> 404 Page Not Found: /index
INFO - 2023-04-14 06:19:34 --> Config Class Initialized
INFO - 2023-04-14 06:19:34 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:19:34 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:19:34 --> Utf8 Class Initialized
INFO - 2023-04-14 06:19:34 --> URI Class Initialized
INFO - 2023-04-14 06:19:34 --> Router Class Initialized
INFO - 2023-04-14 06:19:34 --> Output Class Initialized
INFO - 2023-04-14 06:19:34 --> Security Class Initialized
DEBUG - 2023-04-14 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:19:34 --> Input Class Initialized
INFO - 2023-04-14 06:19:34 --> Language Class Initialized
INFO - 2023-04-14 06:19:34 --> Language Class Initialized
INFO - 2023-04-14 06:19:34 --> Config Class Initialized
INFO - 2023-04-14 06:19:34 --> Loader Class Initialized
INFO - 2023-04-14 06:19:34 --> Helper loaded: url_helper
INFO - 2023-04-14 06:19:34 --> Helper loaded: file_helper
INFO - 2023-04-14 06:19:34 --> Helper loaded: form_helper
INFO - 2023-04-14 06:19:34 --> Helper loaded: my_helper
INFO - 2023-04-14 06:19:34 --> Database Driver Class Initialized
DEBUG - 2023-04-14 06:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-14 06:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-14 06:19:34 --> Controller Class Initialized
DEBUG - 2023-04-14 06:19:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-14 06:19:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-14 06:19:34 --> Final output sent to browser
DEBUG - 2023-04-14 06:19:34 --> Total execution time: 0.0270
INFO - 2023-04-14 06:19:34 --> Config Class Initialized
INFO - 2023-04-14 06:19:34 --> Hooks Class Initialized
DEBUG - 2023-04-14 06:19:34 --> UTF-8 Support Enabled
INFO - 2023-04-14 06:19:34 --> Utf8 Class Initialized
INFO - 2023-04-14 06:19:34 --> URI Class Initialized
INFO - 2023-04-14 06:19:34 --> Router Class Initialized
INFO - 2023-04-14 06:19:34 --> Output Class Initialized
INFO - 2023-04-14 06:19:34 --> Security Class Initialized
DEBUG - 2023-04-14 06:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-14 06:19:34 --> Input Class Initialized
INFO - 2023-04-14 06:19:34 --> Language Class Initialized
ERROR - 2023-04-14 06:19:34 --> 404 Page Not Found: /index
