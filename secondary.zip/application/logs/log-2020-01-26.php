<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-26 12:11:25 --> Config Class Initialized
INFO - 2020-01-26 12:11:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:11:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:11:25 --> Utf8 Class Initialized
INFO - 2020-01-26 12:11:25 --> URI Class Initialized
ERROR - 2020-01-26 12:11:25 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 239
DEBUG - 2020-01-26 12:11:25 --> No URI present. Default controller set.
INFO - 2020-01-26 12:11:25 --> Router Class Initialized
INFO - 2020-01-26 12:11:25 --> Output Class Initialized
INFO - 2020-01-26 12:11:25 --> Security Class Initialized
DEBUG - 2020-01-26 12:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:11:25 --> Input Class Initialized
INFO - 2020-01-26 12:11:25 --> Language Class Initialized
INFO - 2020-01-26 12:11:25 --> Language Class Initialized
INFO - 2020-01-26 12:11:25 --> Config Class Initialized
INFO - 2020-01-26 12:11:25 --> Loader Class Initialized
INFO - 2020-01-26 12:11:25 --> Helper loaded: url_helper
INFO - 2020-01-26 12:11:25 --> Helper loaded: file_helper
INFO - 2020-01-26 12:11:25 --> Helper loaded: form_helper
INFO - 2020-01-26 12:11:25 --> Helper loaded: my_helper
INFO - 2020-01-26 12:11:25 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:11:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_nilai' E:\xampp\htdocs\_2020\nilaik13_ci\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2020-01-26 12:11:25 --> Unable to connect to the database
INFO - 2020-01-26 12:11:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 12:11:41 --> Config Class Initialized
INFO - 2020-01-26 12:11:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:11:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:11:41 --> Utf8 Class Initialized
INFO - 2020-01-26 12:11:41 --> URI Class Initialized
ERROR - 2020-01-26 12:11:41 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 239
DEBUG - 2020-01-26 12:11:41 --> No URI present. Default controller set.
INFO - 2020-01-26 12:11:41 --> Router Class Initialized
INFO - 2020-01-26 12:11:41 --> Output Class Initialized
INFO - 2020-01-26 12:11:41 --> Security Class Initialized
DEBUG - 2020-01-26 12:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:11:41 --> Input Class Initialized
INFO - 2020-01-26 12:11:41 --> Language Class Initialized
INFO - 2020-01-26 12:11:41 --> Language Class Initialized
INFO - 2020-01-26 12:11:41 --> Config Class Initialized
INFO - 2020-01-26 12:11:41 --> Loader Class Initialized
INFO - 2020-01-26 12:11:41 --> Helper loaded: url_helper
INFO - 2020-01-26 12:11:41 --> Helper loaded: file_helper
INFO - 2020-01-26 12:11:41 --> Helper loaded: form_helper
INFO - 2020-01-26 12:11:41 --> Helper loaded: my_helper
INFO - 2020-01-26 12:11:41 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:11:41 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:11:41 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:11:41 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:11:41 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:11:41 --> Controller Class Initialized
ERROR - 2020-01-26 12:11:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:12:21 --> Config Class Initialized
INFO - 2020-01-26 12:12:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:12:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:12:21 --> Utf8 Class Initialized
INFO - 2020-01-26 12:12:21 --> URI Class Initialized
ERROR - 2020-01-26 12:12:21 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 239
DEBUG - 2020-01-26 12:12:21 --> No URI present. Default controller set.
INFO - 2020-01-26 12:12:21 --> Router Class Initialized
INFO - 2020-01-26 12:12:21 --> Output Class Initialized
INFO - 2020-01-26 12:12:21 --> Security Class Initialized
DEBUG - 2020-01-26 12:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:12:21 --> Input Class Initialized
INFO - 2020-01-26 12:12:21 --> Language Class Initialized
INFO - 2020-01-26 12:12:21 --> Language Class Initialized
INFO - 2020-01-26 12:12:21 --> Config Class Initialized
INFO - 2020-01-26 12:12:21 --> Loader Class Initialized
INFO - 2020-01-26 12:12:21 --> Helper loaded: url_helper
INFO - 2020-01-26 12:12:21 --> Helper loaded: file_helper
INFO - 2020-01-26 12:12:21 --> Helper loaded: form_helper
INFO - 2020-01-26 12:12:21 --> Helper loaded: my_helper
INFO - 2020-01-26 12:12:21 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:12:21 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:12:21 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:12:21 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:12:21 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:12:22 --> Controller Class Initialized
ERROR - 2020-01-26 12:12:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:12:31 --> Config Class Initialized
INFO - 2020-01-26 12:12:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:12:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:12:31 --> Utf8 Class Initialized
INFO - 2020-01-26 12:12:31 --> URI Class Initialized
ERROR - 2020-01-26 12:12:31 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX../../Modules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:12:31 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX../../Modules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:12:38 --> Config Class Initialized
INFO - 2020-01-26 12:12:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:12:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:12:38 --> Utf8 Class Initialized
INFO - 2020-01-26 12:12:38 --> URI Class Initialized
ERROR - 2020-01-26 12:12:38 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:12:38 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:13:55 --> Config Class Initialized
INFO - 2020-01-26 12:13:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:13:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:13:55 --> Utf8 Class Initialized
INFO - 2020-01-26 12:13:55 --> URI Class Initialized
ERROR - 2020-01-26 12:13:55 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXMX/Modules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:13:55 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXMX/Modules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:13:56 --> Config Class Initialized
INFO - 2020-01-26 12:13:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:13:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:13:56 --> Utf8 Class Initialized
INFO - 2020-01-26 12:13:56 --> URI Class Initialized
ERROR - 2020-01-26 12:13:56 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXMX/Modules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:13:56 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXMX/Modules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:14:04 --> Config Class Initialized
INFO - 2020-01-26 12:14:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:14:04 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:14:04 --> Utf8 Class Initialized
INFO - 2020-01-26 12:14:04 --> URI Class Initialized
ERROR - 2020-01-26 12:14:04 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:14:04 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:14:10 --> Config Class Initialized
INFO - 2020-01-26 12:14:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:14:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:14:10 --> Utf8 Class Initialized
INFO - 2020-01-26 12:14:10 --> URI Class Initialized
ERROR - 2020-01-26 12:14:10 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 239
DEBUG - 2020-01-26 12:14:10 --> No URI present. Default controller set.
INFO - 2020-01-26 12:14:10 --> Router Class Initialized
INFO - 2020-01-26 12:14:10 --> Output Class Initialized
INFO - 2020-01-26 12:14:10 --> Security Class Initialized
DEBUG - 2020-01-26 12:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:14:10 --> Input Class Initialized
INFO - 2020-01-26 12:14:10 --> Language Class Initialized
INFO - 2020-01-26 12:14:10 --> Language Class Initialized
INFO - 2020-01-26 12:14:10 --> Config Class Initialized
INFO - 2020-01-26 12:14:10 --> Loader Class Initialized
INFO - 2020-01-26 12:14:10 --> Helper loaded: url_helper
INFO - 2020-01-26 12:14:10 --> Helper loaded: file_helper
INFO - 2020-01-26 12:14:10 --> Helper loaded: form_helper
INFO - 2020-01-26 12:14:10 --> Helper loaded: my_helper
INFO - 2020-01-26 12:14:10 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:14:10 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:14:10 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:14:10 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:14:10 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:14:10 --> Controller Class Initialized
ERROR - 2020-01-26 12:14:10 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:14:59 --> Config Class Initialized
INFO - 2020-01-26 12:14:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:14:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:14:59 --> Utf8 Class Initialized
INFO - 2020-01-26 12:14:59 --> URI Class Initialized
ERROR - 2020-01-26 12:14:59 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:14:59 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:15:43 --> Config Class Initialized
INFO - 2020-01-26 12:15:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:15:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:15:43 --> Utf8 Class Initialized
INFO - 2020-01-26 12:15:43 --> URI Class Initialized
ERROR - 2020-01-26 12:15:43 --> Severity: 8192 --> strpos(): Non-string needles will be interpreted as strings in the future. Use an explicit chr() call to preserve the current behavior E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 239
DEBUG - 2020-01-26 12:15:43 --> No URI present. Default controller set.
INFO - 2020-01-26 12:15:43 --> Router Class Initialized
INFO - 2020-01-26 12:15:43 --> Output Class Initialized
INFO - 2020-01-26 12:15:43 --> Security Class Initialized
DEBUG - 2020-01-26 12:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:15:43 --> Input Class Initialized
INFO - 2020-01-26 12:15:43 --> Language Class Initialized
INFO - 2020-01-26 12:15:43 --> Language Class Initialized
INFO - 2020-01-26 12:15:43 --> Config Class Initialized
INFO - 2020-01-26 12:15:43 --> Loader Class Initialized
INFO - 2020-01-26 12:15:43 --> Helper loaded: url_helper
INFO - 2020-01-26 12:15:43 --> Helper loaded: file_helper
INFO - 2020-01-26 12:15:43 --> Helper loaded: form_helper
INFO - 2020-01-26 12:15:43 --> Helper loaded: my_helper
INFO - 2020-01-26 12:15:43 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:15:43 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:15:43 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:15:43 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:15:43 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:15:43 --> Controller Class Initialized
ERROR - 2020-01-26 12:15:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:17:42 --> Config Class Initialized
INFO - 2020-01-26 12:17:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:17:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:17:42 --> Utf8 Class Initialized
INFO - 2020-01-26 12:17:42 --> URI Class Initialized
DEBUG - 2020-01-26 12:17:42 --> No URI present. Default controller set.
INFO - 2020-01-26 12:17:42 --> Router Class Initialized
INFO - 2020-01-26 12:17:42 --> Output Class Initialized
INFO - 2020-01-26 12:17:42 --> Security Class Initialized
DEBUG - 2020-01-26 12:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:17:42 --> Input Class Initialized
INFO - 2020-01-26 12:17:42 --> Language Class Initialized
INFO - 2020-01-26 12:17:42 --> Language Class Initialized
INFO - 2020-01-26 12:17:42 --> Config Class Initialized
INFO - 2020-01-26 12:17:42 --> Loader Class Initialized
INFO - 2020-01-26 12:17:42 --> Helper loaded: url_helper
INFO - 2020-01-26 12:17:42 --> Helper loaded: file_helper
INFO - 2020-01-26 12:17:42 --> Helper loaded: form_helper
INFO - 2020-01-26 12:17:43 --> Helper loaded: my_helper
INFO - 2020-01-26 12:17:43 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> session_regenerate_id(): Cannot regenerate session id - headers already sent E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 644
INFO - 2020-01-26 12:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:17:43 --> Controller Class Initialized
ERROR - 2020-01-26 12:17:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:17:55 --> Config Class Initialized
INFO - 2020-01-26 12:17:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:17:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:17:55 --> Utf8 Class Initialized
INFO - 2020-01-26 12:17:55 --> URI Class Initialized
ERROR - 2020-01-26 12:17:55 --> Severity: Warning --> require(E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php): failed to open stream: No such file or directory E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
ERROR - 2020-01-26 12:17:55 --> Severity: Compile Error --> require(): Failed opening required 'E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MXModules.php' (include_path='E:\xampp\php\PEAR') E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Router.php 4
INFO - 2020-01-26 12:17:59 --> Config Class Initialized
INFO - 2020-01-26 12:17:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:17:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:17:59 --> Utf8 Class Initialized
INFO - 2020-01-26 12:17:59 --> URI Class Initialized
DEBUG - 2020-01-26 12:17:59 --> No URI present. Default controller set.
INFO - 2020-01-26 12:17:59 --> Router Class Initialized
INFO - 2020-01-26 12:17:59 --> Output Class Initialized
INFO - 2020-01-26 12:17:59 --> Security Class Initialized
DEBUG - 2020-01-26 12:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:17:59 --> Input Class Initialized
INFO - 2020-01-26 12:18:00 --> Language Class Initialized
INFO - 2020-01-26 12:18:00 --> Language Class Initialized
INFO - 2020-01-26 12:18:00 --> Config Class Initialized
INFO - 2020-01-26 12:18:00 --> Loader Class Initialized
INFO - 2020-01-26 12:18:00 --> Helper loaded: url_helper
INFO - 2020-01-26 12:18:00 --> Helper loaded: file_helper
INFO - 2020-01-26 12:18:00 --> Helper loaded: form_helper
INFO - 2020-01-26 12:18:00 --> Helper loaded: my_helper
INFO - 2020-01-26 12:18:00 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:18:00 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:18:00 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:18:00 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:18:00 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:18:00 --> Controller Class Initialized
ERROR - 2020-01-26 12:18:00 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:18:12 --> Config Class Initialized
INFO - 2020-01-26 12:18:12 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:18:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:18:12 --> Utf8 Class Initialized
INFO - 2020-01-26 12:18:12 --> URI Class Initialized
DEBUG - 2020-01-26 12:18:12 --> No URI present. Default controller set.
INFO - 2020-01-26 12:18:12 --> Router Class Initialized
INFO - 2020-01-26 12:18:12 --> Output Class Initialized
INFO - 2020-01-26 12:18:12 --> Security Class Initialized
DEBUG - 2020-01-26 12:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:18:12 --> Input Class Initialized
INFO - 2020-01-26 12:18:12 --> Language Class Initialized
INFO - 2020-01-26 12:18:12 --> Language Class Initialized
INFO - 2020-01-26 12:18:12 --> Config Class Initialized
INFO - 2020-01-26 12:18:12 --> Loader Class Initialized
INFO - 2020-01-26 12:18:12 --> Helper loaded: url_helper
INFO - 2020-01-26 12:18:12 --> Helper loaded: file_helper
INFO - 2020-01-26 12:18:12 --> Helper loaded: form_helper
INFO - 2020-01-26 12:18:12 --> Helper loaded: my_helper
INFO - 2020-01-26 12:18:12 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:18:12 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:18:12 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:18:12 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
DEBUG - 2020-01-26 12:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:18:12 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 108
INFO - 2020-01-26 12:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:18:12 --> Controller Class Initialized
ERROR - 2020-01-26 12:18:12 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:272) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:19:41 --> Config Class Initialized
INFO - 2020-01-26 12:19:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:19:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:19:41 --> Utf8 Class Initialized
INFO - 2020-01-26 12:19:41 --> URI Class Initialized
DEBUG - 2020-01-26 12:19:41 --> No URI present. Default controller set.
INFO - 2020-01-26 12:19:41 --> Router Class Initialized
INFO - 2020-01-26 12:19:41 --> Output Class Initialized
INFO - 2020-01-26 12:19:41 --> Security Class Initialized
DEBUG - 2020-01-26 12:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:19:41 --> Input Class Initialized
INFO - 2020-01-26 12:19:41 --> Language Class Initialized
INFO - 2020-01-26 12:19:41 --> Language Class Initialized
INFO - 2020-01-26 12:19:41 --> Config Class Initialized
INFO - 2020-01-26 12:19:41 --> Loader Class Initialized
INFO - 2020-01-26 12:19:41 --> Helper loaded: url_helper
INFO - 2020-01-26 12:19:41 --> Helper loaded: file_helper
INFO - 2020-01-26 12:19:41 --> Helper loaded: form_helper
INFO - 2020-01-26 12:19:41 --> Helper loaded: my_helper
INFO - 2020-01-26 12:19:41 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 314
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 315
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 316
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 317
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 375
DEBUG - 2020-01-26 12:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:19:41 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 110
ERROR - 2020-01-26 12:19:42 --> Severity: Notice --> session_start(): A session had already been started - ignoring E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 143
INFO - 2020-01-26 12:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:19:42 --> Controller Class Initialized
ERROR - 2020-01-26 12:19:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:271) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:19:47 --> Config Class Initialized
INFO - 2020-01-26 12:19:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:19:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:19:47 --> Utf8 Class Initialized
INFO - 2020-01-26 12:19:47 --> URI Class Initialized
DEBUG - 2020-01-26 12:19:47 --> No URI present. Default controller set.
INFO - 2020-01-26 12:19:47 --> Router Class Initialized
INFO - 2020-01-26 12:19:47 --> Output Class Initialized
INFO - 2020-01-26 12:19:47 --> Security Class Initialized
DEBUG - 2020-01-26 12:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:19:47 --> Input Class Initialized
INFO - 2020-01-26 12:19:47 --> Language Class Initialized
INFO - 2020-01-26 12:19:47 --> Language Class Initialized
INFO - 2020-01-26 12:19:47 --> Config Class Initialized
INFO - 2020-01-26 12:19:47 --> Loader Class Initialized
INFO - 2020-01-26 12:19:47 --> Helper loaded: url_helper
INFO - 2020-01-26 12:19:47 --> Helper loaded: file_helper
INFO - 2020-01-26 12:19:47 --> Helper loaded: form_helper
INFO - 2020-01-26 12:19:48 --> Helper loaded: my_helper
INFO - 2020-01-26 12:19:48 --> Database Driver Class Initialized
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 282
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 294
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 304
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): A session is active. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 314
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 315
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 316
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 317
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 375
DEBUG - 2020-01-26 12:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when session is active E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 110
ERROR - 2020-01-26 12:19:48 --> Severity: Notice --> session_start(): A session had already been started - ignoring E:\xampp\htdocs\_2020\nilaik13_ci\system\libraries\Session\Session.php 143
INFO - 2020-01-26 12:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:19:48 --> Controller Class Initialized
ERROR - 2020-01-26 12:19:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at E:\xampp\htdocs\_2020\nilaik13_ci\system\core\Exceptions.php:271) E:\xampp\htdocs\_2020\nilaik13_ci\system\helpers\url_helper.php 564
INFO - 2020-01-26 12:21:06 --> Config Class Initialized
INFO - 2020-01-26 12:21:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:21:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:21:06 --> Utf8 Class Initialized
INFO - 2020-01-26 12:21:06 --> URI Class Initialized
DEBUG - 2020-01-26 12:21:06 --> No URI present. Default controller set.
INFO - 2020-01-26 12:21:06 --> Router Class Initialized
INFO - 2020-01-26 12:21:06 --> Output Class Initialized
INFO - 2020-01-26 12:21:06 --> Security Class Initialized
DEBUG - 2020-01-26 12:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:21:06 --> Input Class Initialized
INFO - 2020-01-26 12:21:07 --> Language Class Initialized
INFO - 2020-01-26 12:21:07 --> Language Class Initialized
INFO - 2020-01-26 12:21:07 --> Config Class Initialized
INFO - 2020-01-26 12:21:07 --> Loader Class Initialized
INFO - 2020-01-26 12:21:07 --> Helper loaded: url_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: file_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: form_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: my_helper
INFO - 2020-01-26 12:21:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:21:07 --> Controller Class Initialized
INFO - 2020-01-26 12:21:07 --> Config Class Initialized
INFO - 2020-01-26 12:21:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:21:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:21:07 --> Utf8 Class Initialized
INFO - 2020-01-26 12:21:07 --> URI Class Initialized
INFO - 2020-01-26 12:21:07 --> Router Class Initialized
INFO - 2020-01-26 12:21:07 --> Output Class Initialized
INFO - 2020-01-26 12:21:07 --> Security Class Initialized
DEBUG - 2020-01-26 12:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:21:07 --> Input Class Initialized
INFO - 2020-01-26 12:21:07 --> Language Class Initialized
INFO - 2020-01-26 12:21:07 --> Language Class Initialized
INFO - 2020-01-26 12:21:07 --> Config Class Initialized
INFO - 2020-01-26 12:21:07 --> Loader Class Initialized
INFO - 2020-01-26 12:21:07 --> Helper loaded: url_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: file_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: form_helper
INFO - 2020-01-26 12:21:07 --> Helper loaded: my_helper
INFO - 2020-01-26 12:21:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:21:07 --> Controller Class Initialized
ERROR - 2020-01-26 12:21:07 --> Severity: error --> Exception: Call to undefined method MY_Loader::_ci_object_to_array() E:\xampp\htdocs\_2020\nilaik13_ci\application\third_party\MX\Loader.php 300
INFO - 2020-01-26 12:23:17 --> Config Class Initialized
INFO - 2020-01-26 12:23:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:23:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:23:17 --> Utf8 Class Initialized
INFO - 2020-01-26 12:23:17 --> URI Class Initialized
INFO - 2020-01-26 12:23:17 --> Router Class Initialized
INFO - 2020-01-26 12:23:17 --> Output Class Initialized
INFO - 2020-01-26 12:23:17 --> Security Class Initialized
DEBUG - 2020-01-26 12:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:23:17 --> Input Class Initialized
INFO - 2020-01-26 12:23:17 --> Language Class Initialized
INFO - 2020-01-26 12:23:17 --> Language Class Initialized
INFO - 2020-01-26 12:23:17 --> Config Class Initialized
INFO - 2020-01-26 12:23:17 --> Loader Class Initialized
INFO - 2020-01-26 12:23:17 --> Helper loaded: url_helper
INFO - 2020-01-26 12:23:17 --> Helper loaded: file_helper
INFO - 2020-01-26 12:23:17 --> Helper loaded: form_helper
INFO - 2020-01-26 12:23:17 --> Helper loaded: my_helper
INFO - 2020-01-26 12:23:17 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:23:18 --> Controller Class Initialized
DEBUG - 2020-01-26 12:23:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 12:23:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:23:18 --> Final output sent to browser
DEBUG - 2020-01-26 12:23:18 --> Total execution time: 0.4708
INFO - 2020-01-26 12:23:23 --> Config Class Initialized
INFO - 2020-01-26 12:23:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:23:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:23:23 --> Utf8 Class Initialized
INFO - 2020-01-26 12:23:23 --> URI Class Initialized
INFO - 2020-01-26 12:23:23 --> Router Class Initialized
INFO - 2020-01-26 12:23:23 --> Output Class Initialized
INFO - 2020-01-26 12:23:23 --> Security Class Initialized
DEBUG - 2020-01-26 12:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:23:23 --> Input Class Initialized
INFO - 2020-01-26 12:23:23 --> Language Class Initialized
INFO - 2020-01-26 12:23:23 --> Language Class Initialized
INFO - 2020-01-26 12:23:23 --> Config Class Initialized
INFO - 2020-01-26 12:23:23 --> Loader Class Initialized
INFO - 2020-01-26 12:23:23 --> Helper loaded: url_helper
INFO - 2020-01-26 12:23:23 --> Helper loaded: file_helper
INFO - 2020-01-26 12:23:23 --> Helper loaded: form_helper
INFO - 2020-01-26 12:23:23 --> Helper loaded: my_helper
INFO - 2020-01-26 12:23:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:23:23 --> Controller Class Initialized
INFO - 2020-01-26 12:23:23 --> Final output sent to browser
DEBUG - 2020-01-26 12:23:23 --> Total execution time: 0.4455
INFO - 2020-01-26 12:24:51 --> Config Class Initialized
INFO - 2020-01-26 12:24:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:24:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:24:51 --> Utf8 Class Initialized
INFO - 2020-01-26 12:24:51 --> URI Class Initialized
INFO - 2020-01-26 12:24:51 --> Router Class Initialized
INFO - 2020-01-26 12:24:51 --> Output Class Initialized
INFO - 2020-01-26 12:24:51 --> Security Class Initialized
DEBUG - 2020-01-26 12:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:24:51 --> Input Class Initialized
INFO - 2020-01-26 12:24:51 --> Language Class Initialized
INFO - 2020-01-26 12:24:51 --> Language Class Initialized
INFO - 2020-01-26 12:24:51 --> Config Class Initialized
INFO - 2020-01-26 12:24:51 --> Loader Class Initialized
INFO - 2020-01-26 12:24:51 --> Helper loaded: url_helper
INFO - 2020-01-26 12:24:51 --> Helper loaded: file_helper
INFO - 2020-01-26 12:24:51 --> Helper loaded: form_helper
INFO - 2020-01-26 12:24:51 --> Helper loaded: my_helper
INFO - 2020-01-26 12:24:51 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:24:51 --> Controller Class Initialized
INFO - 2020-01-26 12:24:51 --> Helper loaded: cookie_helper
INFO - 2020-01-26 12:24:51 --> Final output sent to browser
DEBUG - 2020-01-26 12:24:51 --> Total execution time: 0.4473
INFO - 2020-01-26 12:24:52 --> Config Class Initialized
INFO - 2020-01-26 12:24:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:24:53 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:24:53 --> Utf8 Class Initialized
INFO - 2020-01-26 12:24:53 --> URI Class Initialized
INFO - 2020-01-26 12:24:53 --> Router Class Initialized
INFO - 2020-01-26 12:24:53 --> Output Class Initialized
INFO - 2020-01-26 12:24:53 --> Security Class Initialized
DEBUG - 2020-01-26 12:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:24:53 --> Input Class Initialized
INFO - 2020-01-26 12:24:53 --> Language Class Initialized
INFO - 2020-01-26 12:24:53 --> Language Class Initialized
INFO - 2020-01-26 12:24:53 --> Config Class Initialized
INFO - 2020-01-26 12:24:53 --> Loader Class Initialized
INFO - 2020-01-26 12:24:53 --> Helper loaded: url_helper
INFO - 2020-01-26 12:24:53 --> Helper loaded: file_helper
INFO - 2020-01-26 12:24:53 --> Helper loaded: form_helper
INFO - 2020-01-26 12:24:53 --> Helper loaded: my_helper
INFO - 2020-01-26 12:24:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:24:53 --> Controller Class Initialized
DEBUG - 2020-01-26 12:24:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 12:24:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:24:53 --> Final output sent to browser
DEBUG - 2020-01-26 12:24:53 --> Total execution time: 0.5311
INFO - 2020-01-26 12:24:54 --> Config Class Initialized
INFO - 2020-01-26 12:24:54 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:24:54 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:24:54 --> Utf8 Class Initialized
INFO - 2020-01-26 12:24:54 --> URI Class Initialized
INFO - 2020-01-26 12:24:54 --> Router Class Initialized
INFO - 2020-01-26 12:24:54 --> Output Class Initialized
INFO - 2020-01-26 12:24:55 --> Security Class Initialized
DEBUG - 2020-01-26 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:24:55 --> Input Class Initialized
INFO - 2020-01-26 12:24:55 --> Language Class Initialized
INFO - 2020-01-26 12:24:55 --> Language Class Initialized
INFO - 2020-01-26 12:24:55 --> Config Class Initialized
INFO - 2020-01-26 12:24:55 --> Loader Class Initialized
INFO - 2020-01-26 12:24:55 --> Helper loaded: url_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: file_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: form_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: my_helper
INFO - 2020-01-26 12:24:55 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:24:55 --> Controller Class Initialized
DEBUG - 2020-01-26 12:24:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 12:24:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:24:55 --> Final output sent to browser
DEBUG - 2020-01-26 12:24:55 --> Total execution time: 0.4618
INFO - 2020-01-26 12:24:55 --> Config Class Initialized
INFO - 2020-01-26 12:24:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:24:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:24:55 --> Utf8 Class Initialized
INFO - 2020-01-26 12:24:55 --> URI Class Initialized
INFO - 2020-01-26 12:24:55 --> Router Class Initialized
INFO - 2020-01-26 12:24:55 --> Output Class Initialized
INFO - 2020-01-26 12:24:55 --> Security Class Initialized
DEBUG - 2020-01-26 12:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:24:55 --> Input Class Initialized
INFO - 2020-01-26 12:24:55 --> Language Class Initialized
INFO - 2020-01-26 12:24:55 --> Language Class Initialized
INFO - 2020-01-26 12:24:55 --> Config Class Initialized
INFO - 2020-01-26 12:24:55 --> Loader Class Initialized
INFO - 2020-01-26 12:24:55 --> Helper loaded: url_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: file_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: form_helper
INFO - 2020-01-26 12:24:55 --> Helper loaded: my_helper
INFO - 2020-01-26 12:24:55 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:24:55 --> Controller Class Initialized
INFO - 2020-01-26 12:25:00 --> Config Class Initialized
INFO - 2020-01-26 12:25:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:00 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:00 --> URI Class Initialized
INFO - 2020-01-26 12:25:00 --> Router Class Initialized
INFO - 2020-01-26 12:25:00 --> Output Class Initialized
INFO - 2020-01-26 12:25:00 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:00 --> Input Class Initialized
INFO - 2020-01-26 12:25:00 --> Language Class Initialized
INFO - 2020-01-26 12:25:00 --> Language Class Initialized
INFO - 2020-01-26 12:25:00 --> Config Class Initialized
INFO - 2020-01-26 12:25:00 --> Loader Class Initialized
INFO - 2020-01-26 12:25:00 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:00 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:00 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:00 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:00 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 12:25:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:00 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:00 --> Total execution time: 0.5923
INFO - 2020-01-26 12:25:01 --> Config Class Initialized
INFO - 2020-01-26 12:25:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:01 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:01 --> URI Class Initialized
INFO - 2020-01-26 12:25:01 --> Router Class Initialized
INFO - 2020-01-26 12:25:01 --> Output Class Initialized
INFO - 2020-01-26 12:25:01 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:01 --> Input Class Initialized
INFO - 2020-01-26 12:25:01 --> Language Class Initialized
INFO - 2020-01-26 12:25:01 --> Language Class Initialized
INFO - 2020-01-26 12:25:01 --> Config Class Initialized
INFO - 2020-01-26 12:25:01 --> Loader Class Initialized
INFO - 2020-01-26 12:25:01 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:01 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:01 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:01 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:01 --> Controller Class Initialized
INFO - 2020-01-26 12:25:04 --> Config Class Initialized
INFO - 2020-01-26 12:25:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:04 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:04 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:04 --> URI Class Initialized
INFO - 2020-01-26 12:25:04 --> Router Class Initialized
INFO - 2020-01-26 12:25:04 --> Output Class Initialized
INFO - 2020-01-26 12:25:04 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:04 --> Input Class Initialized
INFO - 2020-01-26 12:25:04 --> Language Class Initialized
INFO - 2020-01-26 12:25:04 --> Language Class Initialized
INFO - 2020-01-26 12:25:04 --> Config Class Initialized
INFO - 2020-01-26 12:25:04 --> Loader Class Initialized
INFO - 2020-01-26 12:25:04 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:04 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:04 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:04 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:04 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 12:25:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:04 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:04 --> Total execution time: 0.5445
INFO - 2020-01-26 12:25:05 --> Config Class Initialized
INFO - 2020-01-26 12:25:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:05 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:05 --> URI Class Initialized
INFO - 2020-01-26 12:25:05 --> Router Class Initialized
INFO - 2020-01-26 12:25:05 --> Output Class Initialized
INFO - 2020-01-26 12:25:05 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:05 --> Input Class Initialized
INFO - 2020-01-26 12:25:05 --> Language Class Initialized
INFO - 2020-01-26 12:25:05 --> Language Class Initialized
INFO - 2020-01-26 12:25:05 --> Config Class Initialized
INFO - 2020-01-26 12:25:05 --> Loader Class Initialized
INFO - 2020-01-26 12:25:05 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:05 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:05 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:05 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:05 --> Controller Class Initialized
INFO - 2020-01-26 12:25:08 --> Config Class Initialized
INFO - 2020-01-26 12:25:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:08 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:08 --> URI Class Initialized
INFO - 2020-01-26 12:25:08 --> Router Class Initialized
INFO - 2020-01-26 12:25:08 --> Output Class Initialized
INFO - 2020-01-26 12:25:08 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:08 --> Input Class Initialized
INFO - 2020-01-26 12:25:08 --> Language Class Initialized
INFO - 2020-01-26 12:25:08 --> Language Class Initialized
INFO - 2020-01-26 12:25:08 --> Config Class Initialized
INFO - 2020-01-26 12:25:08 --> Loader Class Initialized
INFO - 2020-01-26 12:25:08 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:08 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:08 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:08 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:09 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-26 12:25:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:09 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:09 --> Total execution time: 0.5732
INFO - 2020-01-26 12:25:09 --> Config Class Initialized
INFO - 2020-01-26 12:25:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:09 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:09 --> URI Class Initialized
INFO - 2020-01-26 12:25:09 --> Router Class Initialized
INFO - 2020-01-26 12:25:09 --> Output Class Initialized
INFO - 2020-01-26 12:25:09 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:09 --> Input Class Initialized
INFO - 2020-01-26 12:25:09 --> Language Class Initialized
INFO - 2020-01-26 12:25:09 --> Language Class Initialized
INFO - 2020-01-26 12:25:09 --> Config Class Initialized
INFO - 2020-01-26 12:25:09 --> Loader Class Initialized
INFO - 2020-01-26 12:25:09 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:09 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:09 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:09 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:09 --> Controller Class Initialized
INFO - 2020-01-26 12:25:14 --> Config Class Initialized
INFO - 2020-01-26 12:25:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:14 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:15 --> URI Class Initialized
INFO - 2020-01-26 12:25:15 --> Router Class Initialized
INFO - 2020-01-26 12:25:15 --> Output Class Initialized
INFO - 2020-01-26 12:25:15 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:15 --> Input Class Initialized
INFO - 2020-01-26 12:25:15 --> Language Class Initialized
INFO - 2020-01-26 12:25:15 --> Language Class Initialized
INFO - 2020-01-26 12:25:15 --> Config Class Initialized
INFO - 2020-01-26 12:25:15 --> Loader Class Initialized
INFO - 2020-01-26 12:25:15 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:15 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-26 12:25:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:15 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:15 --> Total execution time: 0.5638
INFO - 2020-01-26 12:25:15 --> Config Class Initialized
INFO - 2020-01-26 12:25:15 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:15 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:15 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:15 --> URI Class Initialized
INFO - 2020-01-26 12:25:15 --> Router Class Initialized
INFO - 2020-01-26 12:25:15 --> Output Class Initialized
INFO - 2020-01-26 12:25:15 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:15 --> Input Class Initialized
INFO - 2020-01-26 12:25:15 --> Language Class Initialized
INFO - 2020-01-26 12:25:15 --> Language Class Initialized
INFO - 2020-01-26 12:25:15 --> Config Class Initialized
INFO - 2020-01-26 12:25:15 --> Loader Class Initialized
INFO - 2020-01-26 12:25:15 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:15 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:16 --> Controller Class Initialized
INFO - 2020-01-26 12:25:18 --> Config Class Initialized
INFO - 2020-01-26 12:25:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:18 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:18 --> URI Class Initialized
INFO - 2020-01-26 12:25:18 --> Router Class Initialized
INFO - 2020-01-26 12:25:18 --> Output Class Initialized
INFO - 2020-01-26 12:25:18 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:18 --> Input Class Initialized
INFO - 2020-01-26 12:25:18 --> Language Class Initialized
INFO - 2020-01-26 12:25:18 --> Language Class Initialized
INFO - 2020-01-26 12:25:18 --> Config Class Initialized
INFO - 2020-01-26 12:25:18 --> Loader Class Initialized
INFO - 2020-01-26 12:25:18 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:18 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:18 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:18 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:18 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 12:25:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:18 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:18 --> Total execution time: 0.5005
INFO - 2020-01-26 12:25:19 --> Config Class Initialized
INFO - 2020-01-26 12:25:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:19 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:19 --> URI Class Initialized
INFO - 2020-01-26 12:25:19 --> Router Class Initialized
INFO - 2020-01-26 12:25:19 --> Output Class Initialized
INFO - 2020-01-26 12:25:19 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:19 --> Input Class Initialized
INFO - 2020-01-26 12:25:19 --> Language Class Initialized
INFO - 2020-01-26 12:25:19 --> Language Class Initialized
INFO - 2020-01-26 12:25:19 --> Config Class Initialized
INFO - 2020-01-26 12:25:19 --> Loader Class Initialized
INFO - 2020-01-26 12:25:19 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:19 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:19 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:19 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:19 --> Controller Class Initialized
INFO - 2020-01-26 12:25:20 --> Config Class Initialized
INFO - 2020-01-26 12:25:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:20 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:20 --> URI Class Initialized
INFO - 2020-01-26 12:25:20 --> Router Class Initialized
INFO - 2020-01-26 12:25:20 --> Output Class Initialized
INFO - 2020-01-26 12:25:20 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:20 --> Input Class Initialized
INFO - 2020-01-26 12:25:20 --> Language Class Initialized
INFO - 2020-01-26 12:25:21 --> Language Class Initialized
INFO - 2020-01-26 12:25:21 --> Config Class Initialized
INFO - 2020-01-26 12:25:21 --> Loader Class Initialized
INFO - 2020-01-26 12:25:21 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:21 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 12:25:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:21 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:21 --> Total execution time: 0.5473
INFO - 2020-01-26 12:25:21 --> Config Class Initialized
INFO - 2020-01-26 12:25:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:21 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:21 --> URI Class Initialized
INFO - 2020-01-26 12:25:21 --> Router Class Initialized
INFO - 2020-01-26 12:25:21 --> Output Class Initialized
INFO - 2020-01-26 12:25:21 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:21 --> Input Class Initialized
INFO - 2020-01-26 12:25:21 --> Language Class Initialized
INFO - 2020-01-26 12:25:21 --> Language Class Initialized
INFO - 2020-01-26 12:25:21 --> Config Class Initialized
INFO - 2020-01-26 12:25:21 --> Loader Class Initialized
INFO - 2020-01-26 12:25:21 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:21 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:21 --> Controller Class Initialized
INFO - 2020-01-26 12:25:27 --> Config Class Initialized
INFO - 2020-01-26 12:25:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:27 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:27 --> URI Class Initialized
INFO - 2020-01-26 12:25:27 --> Router Class Initialized
INFO - 2020-01-26 12:25:27 --> Output Class Initialized
INFO - 2020-01-26 12:25:27 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:27 --> Input Class Initialized
INFO - 2020-01-26 12:25:28 --> Language Class Initialized
INFO - 2020-01-26 12:25:28 --> Language Class Initialized
INFO - 2020-01-26 12:25:28 --> Config Class Initialized
INFO - 2020-01-26 12:25:28 --> Loader Class Initialized
INFO - 2020-01-26 12:25:28 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:28 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:28 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:28 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:28 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 12:25:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:28 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:28 --> Total execution time: 0.5265
INFO - 2020-01-26 12:25:32 --> Config Class Initialized
INFO - 2020-01-26 12:25:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:32 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:32 --> URI Class Initialized
INFO - 2020-01-26 12:25:32 --> Router Class Initialized
INFO - 2020-01-26 12:25:32 --> Output Class Initialized
INFO - 2020-01-26 12:25:32 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:32 --> Input Class Initialized
INFO - 2020-01-26 12:25:32 --> Language Class Initialized
INFO - 2020-01-26 12:25:32 --> Language Class Initialized
INFO - 2020-01-26 12:25:32 --> Config Class Initialized
INFO - 2020-01-26 12:25:32 --> Loader Class Initialized
INFO - 2020-01-26 12:25:32 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:32 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:32 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:32 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:32 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 12:25:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:32 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:32 --> Total execution time: 0.5901
INFO - 2020-01-26 12:25:37 --> Config Class Initialized
INFO - 2020-01-26 12:25:37 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:38 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:38 --> URI Class Initialized
INFO - 2020-01-26 12:25:38 --> Router Class Initialized
INFO - 2020-01-26 12:25:38 --> Output Class Initialized
INFO - 2020-01-26 12:25:38 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:38 --> Input Class Initialized
INFO - 2020-01-26 12:25:38 --> Language Class Initialized
INFO - 2020-01-26 12:25:38 --> Language Class Initialized
INFO - 2020-01-26 12:25:38 --> Config Class Initialized
INFO - 2020-01-26 12:25:38 --> Loader Class Initialized
INFO - 2020-01-26 12:25:38 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:38 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:38 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:38 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:38 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:38 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 12:25:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:38 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:38 --> Total execution time: 0.5761
INFO - 2020-01-26 12:25:38 --> Config Class Initialized
INFO - 2020-01-26 12:25:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:38 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:38 --> URI Class Initialized
INFO - 2020-01-26 12:25:38 --> Router Class Initialized
INFO - 2020-01-26 12:25:38 --> Output Class Initialized
INFO - 2020-01-26 12:25:38 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:39 --> Input Class Initialized
INFO - 2020-01-26 12:25:39 --> Language Class Initialized
INFO - 2020-01-26 12:25:39 --> Language Class Initialized
INFO - 2020-01-26 12:25:39 --> Config Class Initialized
INFO - 2020-01-26 12:25:39 --> Loader Class Initialized
INFO - 2020-01-26 12:25:39 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:39 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:39 --> Controller Class Initialized
INFO - 2020-01-26 12:25:39 --> Config Class Initialized
INFO - 2020-01-26 12:25:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:39 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:39 --> URI Class Initialized
INFO - 2020-01-26 12:25:39 --> Router Class Initialized
INFO - 2020-01-26 12:25:39 --> Output Class Initialized
INFO - 2020-01-26 12:25:39 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:39 --> Input Class Initialized
INFO - 2020-01-26 12:25:39 --> Language Class Initialized
INFO - 2020-01-26 12:25:39 --> Language Class Initialized
INFO - 2020-01-26 12:25:39 --> Config Class Initialized
INFO - 2020-01-26 12:25:39 --> Loader Class Initialized
INFO - 2020-01-26 12:25:39 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:39 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:40 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 12:25:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:40 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:40 --> Total execution time: 0.5585
INFO - 2020-01-26 12:25:41 --> Config Class Initialized
INFO - 2020-01-26 12:25:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:41 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:41 --> URI Class Initialized
INFO - 2020-01-26 12:25:42 --> Router Class Initialized
INFO - 2020-01-26 12:25:42 --> Output Class Initialized
INFO - 2020-01-26 12:25:42 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:42 --> Input Class Initialized
INFO - 2020-01-26 12:25:42 --> Language Class Initialized
INFO - 2020-01-26 12:25:42 --> Language Class Initialized
INFO - 2020-01-26 12:25:42 --> Config Class Initialized
INFO - 2020-01-26 12:25:42 --> Loader Class Initialized
INFO - 2020-01-26 12:25:42 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:42 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:42 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:42 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:42 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 12:25:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:42 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:42 --> Total execution time: 0.5643
INFO - 2020-01-26 12:25:42 --> Config Class Initialized
INFO - 2020-01-26 12:25:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:42 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:42 --> URI Class Initialized
INFO - 2020-01-26 12:25:42 --> Router Class Initialized
INFO - 2020-01-26 12:25:42 --> Output Class Initialized
INFO - 2020-01-26 12:25:42 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:42 --> Input Class Initialized
INFO - 2020-01-26 12:25:42 --> Language Class Initialized
INFO - 2020-01-26 12:25:42 --> Language Class Initialized
INFO - 2020-01-26 12:25:42 --> Config Class Initialized
INFO - 2020-01-26 12:25:42 --> Loader Class Initialized
INFO - 2020-01-26 12:25:42 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:42 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:42 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:43 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:43 --> Controller Class Initialized
INFO - 2020-01-26 12:25:48 --> Config Class Initialized
INFO - 2020-01-26 12:25:48 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:48 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:48 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:48 --> URI Class Initialized
INFO - 2020-01-26 12:25:48 --> Router Class Initialized
INFO - 2020-01-26 12:25:48 --> Output Class Initialized
INFO - 2020-01-26 12:25:48 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:48 --> Input Class Initialized
INFO - 2020-01-26 12:25:48 --> Language Class Initialized
INFO - 2020-01-26 12:25:48 --> Language Class Initialized
INFO - 2020-01-26 12:25:48 --> Config Class Initialized
INFO - 2020-01-26 12:25:48 --> Loader Class Initialized
INFO - 2020-01-26 12:25:48 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:48 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:48 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:48 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:48 --> Controller Class Initialized
DEBUG - 2020-01-26 12:25:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_walikelas/views/list.php
DEBUG - 2020-01-26 12:25:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:25:48 --> Final output sent to browser
DEBUG - 2020-01-26 12:25:48 --> Total execution time: 0.5731
INFO - 2020-01-26 12:25:49 --> Config Class Initialized
INFO - 2020-01-26 12:25:49 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:25:49 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:25:49 --> Utf8 Class Initialized
INFO - 2020-01-26 12:25:49 --> URI Class Initialized
INFO - 2020-01-26 12:25:49 --> Router Class Initialized
INFO - 2020-01-26 12:25:49 --> Output Class Initialized
INFO - 2020-01-26 12:25:49 --> Security Class Initialized
DEBUG - 2020-01-26 12:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:25:49 --> Input Class Initialized
INFO - 2020-01-26 12:25:49 --> Language Class Initialized
INFO - 2020-01-26 12:25:49 --> Language Class Initialized
INFO - 2020-01-26 12:25:49 --> Config Class Initialized
INFO - 2020-01-26 12:25:49 --> Loader Class Initialized
INFO - 2020-01-26 12:25:49 --> Helper loaded: url_helper
INFO - 2020-01-26 12:25:49 --> Helper loaded: file_helper
INFO - 2020-01-26 12:25:49 --> Helper loaded: form_helper
INFO - 2020-01-26 12:25:49 --> Helper loaded: my_helper
INFO - 2020-01-26 12:25:49 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:25:49 --> Controller Class Initialized
INFO - 2020-01-26 12:26:02 --> Config Class Initialized
INFO - 2020-01-26 12:26:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:02 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:02 --> URI Class Initialized
INFO - 2020-01-26 12:26:02 --> Router Class Initialized
INFO - 2020-01-26 12:26:02 --> Output Class Initialized
INFO - 2020-01-26 12:26:02 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:02 --> Input Class Initialized
INFO - 2020-01-26 12:26:02 --> Language Class Initialized
INFO - 2020-01-26 12:26:02 --> Language Class Initialized
INFO - 2020-01-26 12:26:02 --> Config Class Initialized
INFO - 2020-01-26 12:26:03 --> Loader Class Initialized
INFO - 2020-01-26 12:26:03 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:03 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:03 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:03 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:03 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 12:26:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:03 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:03 --> Total execution time: 0.6609
INFO - 2020-01-26 12:26:03 --> Config Class Initialized
INFO - 2020-01-26 12:26:03 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:03 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:03 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:03 --> URI Class Initialized
INFO - 2020-01-26 12:26:03 --> Router Class Initialized
INFO - 2020-01-26 12:26:03 --> Output Class Initialized
INFO - 2020-01-26 12:26:03 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:03 --> Input Class Initialized
INFO - 2020-01-26 12:26:03 --> Language Class Initialized
INFO - 2020-01-26 12:26:03 --> Language Class Initialized
INFO - 2020-01-26 12:26:03 --> Config Class Initialized
INFO - 2020-01-26 12:26:03 --> Loader Class Initialized
INFO - 2020-01-26 12:26:04 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:04 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:04 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:04 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:04 --> Controller Class Initialized
INFO - 2020-01-26 12:26:08 --> Config Class Initialized
INFO - 2020-01-26 12:26:08 --> Hooks Class Initialized
INFO - 2020-01-26 12:26:08 --> Config Class Initialized
INFO - 2020-01-26 12:26:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:08 --> Utf8 Class Initialized
DEBUG - 2020-01-26 12:26:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:08 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:08 --> URI Class Initialized
INFO - 2020-01-26 12:26:08 --> URI Class Initialized
INFO - 2020-01-26 12:26:08 --> Router Class Initialized
INFO - 2020-01-26 12:26:08 --> Output Class Initialized
INFO - 2020-01-26 12:26:08 --> Router Class Initialized
INFO - 2020-01-26 12:26:08 --> Security Class Initialized
INFO - 2020-01-26 12:26:08 --> Output Class Initialized
DEBUG - 2020-01-26 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:08 --> Security Class Initialized
INFO - 2020-01-26 12:26:08 --> Input Class Initialized
DEBUG - 2020-01-26 12:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:08 --> Input Class Initialized
INFO - 2020-01-26 12:26:08 --> Language Class Initialized
INFO - 2020-01-26 12:26:08 --> Language Class Initialized
INFO - 2020-01-26 12:26:08 --> Language Class Initialized
INFO - 2020-01-26 12:26:08 --> Config Class Initialized
INFO - 2020-01-26 12:26:08 --> Language Class Initialized
INFO - 2020-01-26 12:26:08 --> Config Class Initialized
INFO - 2020-01-26 12:26:08 --> Loader Class Initialized
INFO - 2020-01-26 12:26:08 --> Loader Class Initialized
INFO - 2020-01-26 12:26:08 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:08 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:09 --> Controller Class Initialized
INFO - 2020-01-26 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:09 --> Controller Class Initialized
INFO - 2020-01-26 12:26:09 --> Helper loaded: cookie_helper
INFO - 2020-01-26 12:26:09 --> Helper loaded: cookie_helper
INFO - 2020-01-26 12:26:09 --> Config Class Initialized
INFO - 2020-01-26 12:26:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:09 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:09 --> URI Class Initialized
INFO - 2020-01-26 12:26:09 --> Router Class Initialized
INFO - 2020-01-26 12:26:09 --> Output Class Initialized
INFO - 2020-01-26 12:26:09 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:09 --> Input Class Initialized
INFO - 2020-01-26 12:26:09 --> Language Class Initialized
INFO - 2020-01-26 12:26:09 --> Language Class Initialized
INFO - 2020-01-26 12:26:09 --> Config Class Initialized
INFO - 2020-01-26 12:26:09 --> Loader Class Initialized
INFO - 2020-01-26 12:26:09 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:09 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:09 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:09 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:09 --> Controller Class Initialized
INFO - 2020-01-26 12:26:09 --> Config Class Initialized
INFO - 2020-01-26 12:26:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:09 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:09 --> URI Class Initialized
INFO - 2020-01-26 12:26:09 --> Router Class Initialized
INFO - 2020-01-26 12:26:09 --> Output Class Initialized
INFO - 2020-01-26 12:26:09 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:10 --> Input Class Initialized
INFO - 2020-01-26 12:26:10 --> Language Class Initialized
INFO - 2020-01-26 12:26:10 --> Language Class Initialized
INFO - 2020-01-26 12:26:10 --> Config Class Initialized
INFO - 2020-01-26 12:26:10 --> Loader Class Initialized
INFO - 2020-01-26 12:26:10 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:10 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:10 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:10 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:10 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 12:26:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:10 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:10 --> Total execution time: 0.7261
INFO - 2020-01-26 12:26:15 --> Config Class Initialized
INFO - 2020-01-26 12:26:15 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:15 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:15 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:15 --> URI Class Initialized
INFO - 2020-01-26 12:26:15 --> Router Class Initialized
INFO - 2020-01-26 12:26:15 --> Output Class Initialized
INFO - 2020-01-26 12:26:15 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:15 --> Input Class Initialized
INFO - 2020-01-26 12:26:15 --> Language Class Initialized
INFO - 2020-01-26 12:26:15 --> Language Class Initialized
INFO - 2020-01-26 12:26:15 --> Config Class Initialized
INFO - 2020-01-26 12:26:15 --> Loader Class Initialized
INFO - 2020-01-26 12:26:15 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:15 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:15 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:15 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:16 --> Controller Class Initialized
INFO - 2020-01-26 12:26:16 --> Helper loaded: cookie_helper
INFO - 2020-01-26 12:26:16 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:16 --> Total execution time: 0.6349
INFO - 2020-01-26 12:26:17 --> Config Class Initialized
INFO - 2020-01-26 12:26:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:17 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:17 --> URI Class Initialized
INFO - 2020-01-26 12:26:17 --> Router Class Initialized
INFO - 2020-01-26 12:26:17 --> Output Class Initialized
INFO - 2020-01-26 12:26:17 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:17 --> Input Class Initialized
INFO - 2020-01-26 12:26:17 --> Language Class Initialized
INFO - 2020-01-26 12:26:18 --> Language Class Initialized
INFO - 2020-01-26 12:26:18 --> Config Class Initialized
INFO - 2020-01-26 12:26:18 --> Loader Class Initialized
INFO - 2020-01-26 12:26:18 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:18 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:18 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:18 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:18 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 12:26:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:18 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:18 --> Total execution time: 0.7577
INFO - 2020-01-26 12:26:19 --> Config Class Initialized
INFO - 2020-01-26 12:26:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:19 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:19 --> URI Class Initialized
INFO - 2020-01-26 12:26:19 --> Router Class Initialized
INFO - 2020-01-26 12:26:19 --> Output Class Initialized
INFO - 2020-01-26 12:26:19 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:20 --> Input Class Initialized
INFO - 2020-01-26 12:26:20 --> Language Class Initialized
INFO - 2020-01-26 12:26:20 --> Language Class Initialized
INFO - 2020-01-26 12:26:20 --> Config Class Initialized
INFO - 2020-01-26 12:26:20 --> Loader Class Initialized
INFO - 2020-01-26 12:26:20 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:20 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:20 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:20 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:20 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:20 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 12:26:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:20 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:20 --> Total execution time: 0.7296
INFO - 2020-01-26 12:26:22 --> Config Class Initialized
INFO - 2020-01-26 12:26:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:22 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:22 --> URI Class Initialized
INFO - 2020-01-26 12:26:22 --> Router Class Initialized
INFO - 2020-01-26 12:26:22 --> Output Class Initialized
INFO - 2020-01-26 12:26:22 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:22 --> Input Class Initialized
INFO - 2020-01-26 12:26:22 --> Language Class Initialized
INFO - 2020-01-26 12:26:22 --> Language Class Initialized
INFO - 2020-01-26 12:26:22 --> Config Class Initialized
INFO - 2020-01-26 12:26:22 --> Loader Class Initialized
INFO - 2020-01-26 12:26:22 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:22 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:22 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:22 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:22 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-26 12:26:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:22 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:22 --> Total execution time: 0.6750
INFO - 2020-01-26 12:26:23 --> Config Class Initialized
INFO - 2020-01-26 12:26:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:23 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:23 --> URI Class Initialized
INFO - 2020-01-26 12:26:23 --> Router Class Initialized
INFO - 2020-01-26 12:26:23 --> Output Class Initialized
INFO - 2020-01-26 12:26:23 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:23 --> Input Class Initialized
INFO - 2020-01-26 12:26:23 --> Language Class Initialized
INFO - 2020-01-26 12:26:23 --> Language Class Initialized
INFO - 2020-01-26 12:26:23 --> Config Class Initialized
INFO - 2020-01-26 12:26:23 --> Loader Class Initialized
INFO - 2020-01-26 12:26:23 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:23 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:23 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:23 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:23 --> Controller Class Initialized
INFO - 2020-01-26 12:26:28 --> Config Class Initialized
INFO - 2020-01-26 12:26:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:28 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:28 --> URI Class Initialized
INFO - 2020-01-26 12:26:28 --> Router Class Initialized
INFO - 2020-01-26 12:26:28 --> Output Class Initialized
INFO - 2020-01-26 12:26:28 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:28 --> Input Class Initialized
INFO - 2020-01-26 12:26:28 --> Language Class Initialized
INFO - 2020-01-26 12:26:28 --> Language Class Initialized
INFO - 2020-01-26 12:26:28 --> Config Class Initialized
INFO - 2020-01-26 12:26:28 --> Loader Class Initialized
INFO - 2020-01-26 12:26:28 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:28 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:28 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:28 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:28 --> Controller Class Initialized
INFO - 2020-01-26 12:26:28 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:28 --> Total execution time: 0.6057
INFO - 2020-01-26 12:26:30 --> Config Class Initialized
INFO - 2020-01-26 12:26:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:30 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:30 --> URI Class Initialized
INFO - 2020-01-26 12:26:30 --> Router Class Initialized
INFO - 2020-01-26 12:26:30 --> Output Class Initialized
INFO - 2020-01-26 12:26:30 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:30 --> Input Class Initialized
INFO - 2020-01-26 12:26:30 --> Language Class Initialized
INFO - 2020-01-26 12:26:30 --> Language Class Initialized
INFO - 2020-01-26 12:26:30 --> Config Class Initialized
INFO - 2020-01-26 12:26:30 --> Loader Class Initialized
INFO - 2020-01-26 12:26:30 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:30 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:30 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:30 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:30 --> Controller Class Initialized
INFO - 2020-01-26 12:26:30 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:31 --> Total execution time: 0.6065
INFO - 2020-01-26 12:26:31 --> Config Class Initialized
INFO - 2020-01-26 12:26:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:31 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:31 --> URI Class Initialized
INFO - 2020-01-26 12:26:31 --> Router Class Initialized
INFO - 2020-01-26 12:26:31 --> Output Class Initialized
INFO - 2020-01-26 12:26:31 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:31 --> Input Class Initialized
INFO - 2020-01-26 12:26:31 --> Language Class Initialized
INFO - 2020-01-26 12:26:31 --> Language Class Initialized
INFO - 2020-01-26 12:26:31 --> Config Class Initialized
INFO - 2020-01-26 12:26:31 --> Loader Class Initialized
INFO - 2020-01-26 12:26:31 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:31 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:31 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:31 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:31 --> Controller Class Initialized
INFO - 2020-01-26 12:26:31 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:31 --> Total execution time: 0.5887
INFO - 2020-01-26 12:26:33 --> Config Class Initialized
INFO - 2020-01-26 12:26:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:33 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:33 --> URI Class Initialized
INFO - 2020-01-26 12:26:33 --> Router Class Initialized
INFO - 2020-01-26 12:26:33 --> Output Class Initialized
INFO - 2020-01-26 12:26:33 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:33 --> Input Class Initialized
INFO - 2020-01-26 12:26:33 --> Language Class Initialized
INFO - 2020-01-26 12:26:33 --> Language Class Initialized
INFO - 2020-01-26 12:26:33 --> Config Class Initialized
INFO - 2020-01-26 12:26:33 --> Loader Class Initialized
INFO - 2020-01-26 12:26:33 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:33 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:33 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:33 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:33 --> Controller Class Initialized
INFO - 2020-01-26 12:26:33 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:34 --> Total execution time: 0.6699
INFO - 2020-01-26 12:26:38 --> Config Class Initialized
INFO - 2020-01-26 12:26:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:38 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:38 --> URI Class Initialized
INFO - 2020-01-26 12:26:38 --> Router Class Initialized
INFO - 2020-01-26 12:26:38 --> Output Class Initialized
INFO - 2020-01-26 12:26:39 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:39 --> Input Class Initialized
INFO - 2020-01-26 12:26:39 --> Language Class Initialized
INFO - 2020-01-26 12:26:39 --> Language Class Initialized
INFO - 2020-01-26 12:26:39 --> Config Class Initialized
INFO - 2020-01-26 12:26:39 --> Loader Class Initialized
INFO - 2020-01-26 12:26:39 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:39 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:39 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:39 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:39 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:39 --> Controller Class Initialized
INFO - 2020-01-26 12:26:39 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:39 --> Total execution time: 0.6238
INFO - 2020-01-26 12:26:39 --> Config Class Initialized
INFO - 2020-01-26 12:26:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:39 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:39 --> URI Class Initialized
INFO - 2020-01-26 12:26:39 --> Router Class Initialized
INFO - 2020-01-26 12:26:39 --> Output Class Initialized
INFO - 2020-01-26 12:26:39 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:39 --> Input Class Initialized
INFO - 2020-01-26 12:26:39 --> Language Class Initialized
INFO - 2020-01-26 12:26:39 --> Language Class Initialized
INFO - 2020-01-26 12:26:39 --> Config Class Initialized
INFO - 2020-01-26 12:26:39 --> Loader Class Initialized
INFO - 2020-01-26 12:26:39 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:39 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:40 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:40 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:40 --> Controller Class Initialized
INFO - 2020-01-26 12:26:47 --> Config Class Initialized
INFO - 2020-01-26 12:26:48 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:48 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:48 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:48 --> URI Class Initialized
INFO - 2020-01-26 12:26:48 --> Router Class Initialized
INFO - 2020-01-26 12:26:48 --> Output Class Initialized
INFO - 2020-01-26 12:26:48 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:48 --> Input Class Initialized
INFO - 2020-01-26 12:26:48 --> Language Class Initialized
INFO - 2020-01-26 12:26:48 --> Language Class Initialized
INFO - 2020-01-26 12:26:48 --> Config Class Initialized
INFO - 2020-01-26 12:26:48 --> Loader Class Initialized
INFO - 2020-01-26 12:26:48 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:48 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:48 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:48 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:48 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 12:26:48 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:48 --> Total execution time: 0.7219
INFO - 2020-01-26 12:26:52 --> Config Class Initialized
INFO - 2020-01-26 12:26:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:52 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:52 --> URI Class Initialized
INFO - 2020-01-26 12:26:52 --> Router Class Initialized
INFO - 2020-01-26 12:26:52 --> Output Class Initialized
INFO - 2020-01-26 12:26:52 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:52 --> Input Class Initialized
INFO - 2020-01-26 12:26:52 --> Language Class Initialized
INFO - 2020-01-26 12:26:52 --> Language Class Initialized
INFO - 2020-01-26 12:26:52 --> Config Class Initialized
INFO - 2020-01-26 12:26:52 --> Loader Class Initialized
INFO - 2020-01-26 12:26:52 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:52 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:52 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:52 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:52 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:52 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-26 12:26:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:26:52 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:52 --> Total execution time: 0.7198
INFO - 2020-01-26 12:26:57 --> Config Class Initialized
INFO - 2020-01-26 12:26:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:26:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:26:57 --> Utf8 Class Initialized
INFO - 2020-01-26 12:26:57 --> URI Class Initialized
INFO - 2020-01-26 12:26:57 --> Router Class Initialized
INFO - 2020-01-26 12:26:57 --> Output Class Initialized
INFO - 2020-01-26 12:26:57 --> Security Class Initialized
DEBUG - 2020-01-26 12:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:26:57 --> Input Class Initialized
INFO - 2020-01-26 12:26:57 --> Language Class Initialized
INFO - 2020-01-26 12:26:57 --> Language Class Initialized
INFO - 2020-01-26 12:26:57 --> Config Class Initialized
INFO - 2020-01-26 12:26:57 --> Loader Class Initialized
INFO - 2020-01-26 12:26:57 --> Helper loaded: url_helper
INFO - 2020-01-26 12:26:57 --> Helper loaded: file_helper
INFO - 2020-01-26 12:26:57 --> Helper loaded: form_helper
INFO - 2020-01-26 12:26:57 --> Helper loaded: my_helper
INFO - 2020-01-26 12:26:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:26:57 --> Controller Class Initialized
DEBUG - 2020-01-26 12:26:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 12:26:57 --> Final output sent to browser
DEBUG - 2020-01-26 12:26:58 --> Total execution time: 0.7548
INFO - 2020-01-26 12:27:00 --> Config Class Initialized
INFO - 2020-01-26 12:27:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:00 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:00 --> URI Class Initialized
INFO - 2020-01-26 12:27:00 --> Router Class Initialized
INFO - 2020-01-26 12:27:00 --> Output Class Initialized
INFO - 2020-01-26 12:27:00 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:00 --> Input Class Initialized
INFO - 2020-01-26 12:27:00 --> Language Class Initialized
INFO - 2020-01-26 12:27:01 --> Language Class Initialized
INFO - 2020-01-26 12:27:01 --> Config Class Initialized
INFO - 2020-01-26 12:27:01 --> Loader Class Initialized
INFO - 2020-01-26 12:27:01 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:01 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:01 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:01 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:01 --> Controller Class Initialized
DEBUG - 2020-01-26 12:27:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-26 12:27:01 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:01 --> Total execution time: 0.9242
INFO - 2020-01-26 12:27:06 --> Config Class Initialized
INFO - 2020-01-26 12:27:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:06 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:06 --> URI Class Initialized
INFO - 2020-01-26 12:27:06 --> Router Class Initialized
INFO - 2020-01-26 12:27:06 --> Output Class Initialized
INFO - 2020-01-26 12:27:06 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:06 --> Input Class Initialized
INFO - 2020-01-26 12:27:06 --> Language Class Initialized
INFO - 2020-01-26 12:27:06 --> Language Class Initialized
INFO - 2020-01-26 12:27:06 --> Config Class Initialized
INFO - 2020-01-26 12:27:06 --> Loader Class Initialized
INFO - 2020-01-26 12:27:06 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:06 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:06 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:06 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:06 --> Controller Class Initialized
DEBUG - 2020-01-26 12:27:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-26 12:27:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:27:06 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:07 --> Total execution time: 0.9226
INFO - 2020-01-26 12:27:07 --> Config Class Initialized
INFO - 2020-01-26 12:27:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:07 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:07 --> URI Class Initialized
INFO - 2020-01-26 12:27:07 --> Router Class Initialized
INFO - 2020-01-26 12:27:08 --> Output Class Initialized
INFO - 2020-01-26 12:27:08 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:08 --> Input Class Initialized
INFO - 2020-01-26 12:27:08 --> Language Class Initialized
INFO - 2020-01-26 12:27:08 --> Language Class Initialized
INFO - 2020-01-26 12:27:08 --> Config Class Initialized
INFO - 2020-01-26 12:27:08 --> Loader Class Initialized
INFO - 2020-01-26 12:27:08 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:08 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:08 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:08 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:08 --> Controller Class Initialized
DEBUG - 2020-01-26 12:27:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 12:27:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:27:08 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:08 --> Total execution time: 0.8345
INFO - 2020-01-26 12:27:22 --> Config Class Initialized
INFO - 2020-01-26 12:27:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:22 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:22 --> URI Class Initialized
INFO - 2020-01-26 12:27:22 --> Router Class Initialized
INFO - 2020-01-26 12:27:22 --> Output Class Initialized
INFO - 2020-01-26 12:27:22 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:22 --> Input Class Initialized
INFO - 2020-01-26 12:27:22 --> Language Class Initialized
INFO - 2020-01-26 12:27:22 --> Language Class Initialized
INFO - 2020-01-26 12:27:22 --> Config Class Initialized
INFO - 2020-01-26 12:27:22 --> Loader Class Initialized
INFO - 2020-01-26 12:27:22 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:22 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:22 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:22 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:22 --> Controller Class Initialized
DEBUG - 2020-01-26 12:27:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_absensi/views/list.php
DEBUG - 2020-01-26 12:27:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:27:22 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:22 --> Total execution time: 0.7446
INFO - 2020-01-26 12:27:25 --> Config Class Initialized
INFO - 2020-01-26 12:27:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:25 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:25 --> URI Class Initialized
INFO - 2020-01-26 12:27:25 --> Router Class Initialized
INFO - 2020-01-26 12:27:25 --> Output Class Initialized
INFO - 2020-01-26 12:27:25 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:25 --> Input Class Initialized
INFO - 2020-01-26 12:27:25 --> Language Class Initialized
INFO - 2020-01-26 12:27:25 --> Language Class Initialized
INFO - 2020-01-26 12:27:25 --> Config Class Initialized
INFO - 2020-01-26 12:27:25 --> Loader Class Initialized
INFO - 2020-01-26 12:27:25 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:25 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:25 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:25 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:26 --> Controller Class Initialized
DEBUG - 2020-01-26 12:27:26 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_ekstra/views/list.php
DEBUG - 2020-01-26 12:27:26 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:27:26 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:26 --> Total execution time: 0.8207
INFO - 2020-01-26 12:27:28 --> Config Class Initialized
INFO - 2020-01-26 12:27:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:27:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:27:28 --> Utf8 Class Initialized
INFO - 2020-01-26 12:27:28 --> URI Class Initialized
INFO - 2020-01-26 12:27:28 --> Router Class Initialized
INFO - 2020-01-26 12:27:28 --> Output Class Initialized
INFO - 2020-01-26 12:27:28 --> Security Class Initialized
DEBUG - 2020-01-26 12:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:27:28 --> Input Class Initialized
INFO - 2020-01-26 12:27:28 --> Language Class Initialized
INFO - 2020-01-26 12:27:28 --> Language Class Initialized
INFO - 2020-01-26 12:27:28 --> Config Class Initialized
INFO - 2020-01-26 12:27:28 --> Loader Class Initialized
INFO - 2020-01-26 12:27:28 --> Helper loaded: url_helper
INFO - 2020-01-26 12:27:28 --> Helper loaded: file_helper
INFO - 2020-01-26 12:27:28 --> Helper loaded: form_helper
INFO - 2020-01-26 12:27:29 --> Helper loaded: my_helper
INFO - 2020-01-26 12:27:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:27:29 --> Controller Class Initialized
INFO - 2020-01-26 12:27:29 --> Final output sent to browser
DEBUG - 2020-01-26 12:27:29 --> Total execution time: 0.6717
INFO - 2020-01-26 12:28:39 --> Config Class Initialized
INFO - 2020-01-26 12:28:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:28:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:28:39 --> Utf8 Class Initialized
INFO - 2020-01-26 12:28:39 --> URI Class Initialized
INFO - 2020-01-26 12:28:39 --> Router Class Initialized
INFO - 2020-01-26 12:28:40 --> Output Class Initialized
INFO - 2020-01-26 12:28:40 --> Security Class Initialized
DEBUG - 2020-01-26 12:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:28:40 --> Input Class Initialized
INFO - 2020-01-26 12:28:40 --> Language Class Initialized
INFO - 2020-01-26 12:28:40 --> Language Class Initialized
INFO - 2020-01-26 12:28:40 --> Config Class Initialized
INFO - 2020-01-26 12:28:40 --> Loader Class Initialized
INFO - 2020-01-26 12:28:40 --> Helper loaded: url_helper
INFO - 2020-01-26 12:28:40 --> Helper loaded: file_helper
INFO - 2020-01-26 12:28:40 --> Helper loaded: form_helper
INFO - 2020-01-26 12:28:40 --> Helper loaded: my_helper
INFO - 2020-01-26 12:28:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:28:40 --> Controller Class Initialized
INFO - 2020-01-26 12:28:40 --> Final output sent to browser
DEBUG - 2020-01-26 12:28:40 --> Total execution time: 0.6604
INFO - 2020-01-26 12:28:55 --> Config Class Initialized
INFO - 2020-01-26 12:28:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:28:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:28:55 --> Utf8 Class Initialized
INFO - 2020-01-26 12:28:55 --> URI Class Initialized
INFO - 2020-01-26 12:28:55 --> Router Class Initialized
INFO - 2020-01-26 12:28:55 --> Output Class Initialized
INFO - 2020-01-26 12:28:55 --> Security Class Initialized
DEBUG - 2020-01-26 12:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:28:56 --> Input Class Initialized
INFO - 2020-01-26 12:28:56 --> Language Class Initialized
INFO - 2020-01-26 12:28:56 --> Language Class Initialized
INFO - 2020-01-26 12:28:56 --> Config Class Initialized
INFO - 2020-01-26 12:28:56 --> Loader Class Initialized
INFO - 2020-01-26 12:28:56 --> Helper loaded: url_helper
INFO - 2020-01-26 12:28:56 --> Helper loaded: file_helper
INFO - 2020-01-26 12:28:56 --> Helper loaded: form_helper
INFO - 2020-01-26 12:28:56 --> Helper loaded: my_helper
INFO - 2020-01-26 12:28:56 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:28:56 --> Controller Class Initialized
INFO - 2020-01-26 12:28:56 --> Final output sent to browser
DEBUG - 2020-01-26 12:28:56 --> Total execution time: 0.6732
INFO - 2020-01-26 12:28:59 --> Config Class Initialized
INFO - 2020-01-26 12:28:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:28:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:28:59 --> Utf8 Class Initialized
INFO - 2020-01-26 12:28:59 --> URI Class Initialized
INFO - 2020-01-26 12:28:59 --> Router Class Initialized
INFO - 2020-01-26 12:28:59 --> Output Class Initialized
INFO - 2020-01-26 12:28:59 --> Security Class Initialized
DEBUG - 2020-01-26 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:28:59 --> Input Class Initialized
INFO - 2020-01-26 12:28:59 --> Language Class Initialized
INFO - 2020-01-26 12:28:59 --> Language Class Initialized
INFO - 2020-01-26 12:28:59 --> Config Class Initialized
INFO - 2020-01-26 12:28:59 --> Loader Class Initialized
INFO - 2020-01-26 12:28:59 --> Helper loaded: url_helper
INFO - 2020-01-26 12:28:59 --> Helper loaded: file_helper
INFO - 2020-01-26 12:28:59 --> Helper loaded: form_helper
INFO - 2020-01-26 12:28:59 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:00 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-26 12:29:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:00 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:00 --> Total execution time: 0.8075
INFO - 2020-01-26 12:29:10 --> Config Class Initialized
INFO - 2020-01-26 12:29:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:10 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:10 --> URI Class Initialized
INFO - 2020-01-26 12:29:10 --> Router Class Initialized
INFO - 2020-01-26 12:29:10 --> Output Class Initialized
INFO - 2020-01-26 12:29:10 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:10 --> Input Class Initialized
INFO - 2020-01-26 12:29:10 --> Language Class Initialized
INFO - 2020-01-26 12:29:11 --> Language Class Initialized
INFO - 2020-01-26 12:29:11 --> Config Class Initialized
INFO - 2020-01-26 12:29:11 --> Loader Class Initialized
INFO - 2020-01-26 12:29:11 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:11 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:11 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:11 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:11 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_absensi/views/list.php
DEBUG - 2020-01-26 12:29:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:11 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:11 --> Total execution time: 0.9041
INFO - 2020-01-26 12:29:14 --> Config Class Initialized
INFO - 2020-01-26 12:29:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:14 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:14 --> URI Class Initialized
INFO - 2020-01-26 12:29:14 --> Router Class Initialized
INFO - 2020-01-26 12:29:14 --> Output Class Initialized
INFO - 2020-01-26 12:29:14 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:15 --> Input Class Initialized
INFO - 2020-01-26 12:29:15 --> Language Class Initialized
INFO - 2020-01-26 12:29:15 --> Language Class Initialized
INFO - 2020-01-26 12:29:15 --> Config Class Initialized
INFO - 2020-01-26 12:29:15 --> Loader Class Initialized
INFO - 2020-01-26 12:29:15 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:15 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:15 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:15 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:15 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_ekstra/views/list.php
DEBUG - 2020-01-26 12:29:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:15 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:15 --> Total execution time: 0.8292
INFO - 2020-01-26 12:29:18 --> Config Class Initialized
INFO - 2020-01-26 12:29:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:18 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:18 --> URI Class Initialized
INFO - 2020-01-26 12:29:18 --> Router Class Initialized
INFO - 2020-01-26 12:29:18 --> Output Class Initialized
INFO - 2020-01-26 12:29:18 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:18 --> Input Class Initialized
INFO - 2020-01-26 12:29:18 --> Language Class Initialized
INFO - 2020-01-26 12:29:18 --> Language Class Initialized
INFO - 2020-01-26 12:29:18 --> Config Class Initialized
INFO - 2020-01-26 12:29:18 --> Loader Class Initialized
INFO - 2020-01-26 12:29:18 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:18 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:19 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:19 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:19 --> Controller Class Initialized
INFO - 2020-01-26 12:29:19 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:19 --> Total execution time: 0.7152
INFO - 2020-01-26 12:29:23 --> Config Class Initialized
INFO - 2020-01-26 12:29:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:23 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:23 --> URI Class Initialized
INFO - 2020-01-26 12:29:23 --> Router Class Initialized
INFO - 2020-01-26 12:29:23 --> Output Class Initialized
INFO - 2020-01-26 12:29:23 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:24 --> Input Class Initialized
INFO - 2020-01-26 12:29:24 --> Language Class Initialized
INFO - 2020-01-26 12:29:24 --> Language Class Initialized
INFO - 2020-01-26 12:29:24 --> Config Class Initialized
INFO - 2020-01-26 12:29:24 --> Loader Class Initialized
INFO - 2020-01-26 12:29:24 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:24 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:24 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:24 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:24 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:24 --> Controller Class Initialized
INFO - 2020-01-26 12:29:24 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:24 --> Total execution time: 0.7395
INFO - 2020-01-26 12:29:29 --> Config Class Initialized
INFO - 2020-01-26 12:29:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:29 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:29 --> URI Class Initialized
INFO - 2020-01-26 12:29:29 --> Router Class Initialized
INFO - 2020-01-26 12:29:29 --> Output Class Initialized
INFO - 2020-01-26 12:29:30 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:30 --> Input Class Initialized
INFO - 2020-01-26 12:29:30 --> Language Class Initialized
INFO - 2020-01-26 12:29:30 --> Language Class Initialized
INFO - 2020-01-26 12:29:30 --> Config Class Initialized
INFO - 2020-01-26 12:29:30 --> Loader Class Initialized
INFO - 2020-01-26 12:29:30 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:30 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:30 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:30 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:30 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_prestasi/views/list.php
DEBUG - 2020-01-26 12:29:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:30 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:30 --> Total execution time: 0.8043
INFO - 2020-01-26 12:29:30 --> Config Class Initialized
INFO - 2020-01-26 12:29:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:30 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:30 --> URI Class Initialized
INFO - 2020-01-26 12:29:30 --> Router Class Initialized
INFO - 2020-01-26 12:29:30 --> Output Class Initialized
INFO - 2020-01-26 12:29:31 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:31 --> Input Class Initialized
INFO - 2020-01-26 12:29:31 --> Language Class Initialized
INFO - 2020-01-26 12:29:31 --> Language Class Initialized
INFO - 2020-01-26 12:29:31 --> Config Class Initialized
INFO - 2020-01-26 12:29:31 --> Loader Class Initialized
INFO - 2020-01-26 12:29:31 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:31 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:31 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:31 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:31 --> Controller Class Initialized
INFO - 2020-01-26 12:29:35 --> Config Class Initialized
INFO - 2020-01-26 12:29:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:36 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:36 --> URI Class Initialized
INFO - 2020-01-26 12:29:36 --> Router Class Initialized
INFO - 2020-01-26 12:29:36 --> Output Class Initialized
INFO - 2020-01-26 12:29:36 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:36 --> Input Class Initialized
INFO - 2020-01-26 12:29:36 --> Language Class Initialized
INFO - 2020-01-26 12:29:36 --> Language Class Initialized
INFO - 2020-01-26 12:29:36 --> Config Class Initialized
INFO - 2020-01-26 12:29:36 --> Loader Class Initialized
INFO - 2020-01-26 12:29:36 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:36 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:36 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:36 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:36 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_catatan/views/list.php
DEBUG - 2020-01-26 12:29:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:36 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:36 --> Total execution time: 0.8191
INFO - 2020-01-26 12:29:40 --> Config Class Initialized
INFO - 2020-01-26 12:29:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:40 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:40 --> URI Class Initialized
INFO - 2020-01-26 12:29:40 --> Router Class Initialized
INFO - 2020-01-26 12:29:40 --> Output Class Initialized
INFO - 2020-01-26 12:29:40 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:40 --> Input Class Initialized
INFO - 2020-01-26 12:29:40 --> Language Class Initialized
INFO - 2020-01-26 12:29:40 --> Language Class Initialized
INFO - 2020-01-26 12:29:40 --> Config Class Initialized
INFO - 2020-01-26 12:29:40 --> Loader Class Initialized
INFO - 2020-01-26 12:29:40 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:40 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:40 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:40 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:41 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-26 12:29:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:29:41 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:41 --> Total execution time: 0.8594
INFO - 2020-01-26 12:29:43 --> Config Class Initialized
INFO - 2020-01-26 12:29:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:43 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:43 --> URI Class Initialized
INFO - 2020-01-26 12:29:43 --> Router Class Initialized
INFO - 2020-01-26 12:29:43 --> Output Class Initialized
INFO - 2020-01-26 12:29:43 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:43 --> Input Class Initialized
INFO - 2020-01-26 12:29:44 --> Language Class Initialized
INFO - 2020-01-26 12:29:44 --> Language Class Initialized
INFO - 2020-01-26 12:29:44 --> Config Class Initialized
INFO - 2020-01-26 12:29:44 --> Loader Class Initialized
INFO - 2020-01-26 12:29:44 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:44 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:44 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:44 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:44 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-01-26 12:29:44 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:44 --> Total execution time: 0.8748
INFO - 2020-01-26 12:29:49 --> Config Class Initialized
INFO - 2020-01-26 12:29:49 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:49 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:49 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:49 --> URI Class Initialized
INFO - 2020-01-26 12:29:49 --> Router Class Initialized
INFO - 2020-01-26 12:29:49 --> Output Class Initialized
INFO - 2020-01-26 12:29:49 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:49 --> Input Class Initialized
INFO - 2020-01-26 12:29:50 --> Language Class Initialized
INFO - 2020-01-26 12:29:50 --> Language Class Initialized
INFO - 2020-01-26 12:29:50 --> Config Class Initialized
INFO - 2020-01-26 12:29:50 --> Loader Class Initialized
INFO - 2020-01-26 12:29:50 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:50 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:50 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:50 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:50 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:50 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-01-26 12:29:50 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:50 --> Total execution time: 0.8364
INFO - 2020-01-26 12:29:57 --> Config Class Initialized
INFO - 2020-01-26 12:29:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:29:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:29:57 --> Utf8 Class Initialized
INFO - 2020-01-26 12:29:57 --> URI Class Initialized
INFO - 2020-01-26 12:29:57 --> Router Class Initialized
INFO - 2020-01-26 12:29:58 --> Output Class Initialized
INFO - 2020-01-26 12:29:58 --> Security Class Initialized
DEBUG - 2020-01-26 12:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:29:58 --> Input Class Initialized
INFO - 2020-01-26 12:29:58 --> Language Class Initialized
INFO - 2020-01-26 12:29:58 --> Language Class Initialized
INFO - 2020-01-26 12:29:58 --> Config Class Initialized
INFO - 2020-01-26 12:29:58 --> Loader Class Initialized
INFO - 2020-01-26 12:29:58 --> Helper loaded: url_helper
INFO - 2020-01-26 12:29:58 --> Helper loaded: file_helper
INFO - 2020-01-26 12:29:58 --> Helper loaded: form_helper
INFO - 2020-01-26 12:29:58 --> Helper loaded: my_helper
INFO - 2020-01-26 12:29:58 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:29:58 --> Controller Class Initialized
DEBUG - 2020-01-26 12:29:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-01-26 12:29:58 --> Final output sent to browser
DEBUG - 2020-01-26 12:29:58 --> Total execution time: 0.8547
INFO - 2020-01-26 12:30:02 --> Config Class Initialized
INFO - 2020-01-26 12:30:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:30:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:30:02 --> Utf8 Class Initialized
INFO - 2020-01-26 12:30:02 --> URI Class Initialized
INFO - 2020-01-26 12:30:03 --> Router Class Initialized
INFO - 2020-01-26 12:30:03 --> Output Class Initialized
INFO - 2020-01-26 12:30:03 --> Security Class Initialized
DEBUG - 2020-01-26 12:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:30:03 --> Input Class Initialized
INFO - 2020-01-26 12:30:03 --> Language Class Initialized
INFO - 2020-01-26 12:30:03 --> Language Class Initialized
INFO - 2020-01-26 12:30:03 --> Config Class Initialized
INFO - 2020-01-26 12:30:03 --> Loader Class Initialized
INFO - 2020-01-26 12:30:03 --> Helper loaded: url_helper
INFO - 2020-01-26 12:30:03 --> Helper loaded: file_helper
INFO - 2020-01-26 12:30:03 --> Helper loaded: form_helper
INFO - 2020-01-26 12:30:03 --> Helper loaded: my_helper
INFO - 2020-01-26 12:30:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:30:03 --> Controller Class Initialized
DEBUG - 2020-01-26 12:30:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-26 12:30:03 --> Final output sent to browser
DEBUG - 2020-01-26 12:30:03 --> Total execution time: 1.0405
INFO - 2020-01-26 12:30:59 --> Config Class Initialized
INFO - 2020-01-26 12:30:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:30:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:30:59 --> Utf8 Class Initialized
INFO - 2020-01-26 12:30:59 --> URI Class Initialized
INFO - 2020-01-26 12:30:59 --> Router Class Initialized
INFO - 2020-01-26 12:30:59 --> Output Class Initialized
INFO - 2020-01-26 12:30:59 --> Security Class Initialized
DEBUG - 2020-01-26 12:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:30:59 --> Input Class Initialized
INFO - 2020-01-26 12:30:59 --> Language Class Initialized
INFO - 2020-01-26 12:30:59 --> Language Class Initialized
INFO - 2020-01-26 12:30:59 --> Config Class Initialized
INFO - 2020-01-26 12:30:59 --> Loader Class Initialized
INFO - 2020-01-26 12:30:59 --> Helper loaded: url_helper
INFO - 2020-01-26 12:30:59 --> Helper loaded: file_helper
INFO - 2020-01-26 12:30:59 --> Helper loaded: form_helper
INFO - 2020-01-26 12:30:59 --> Helper loaded: my_helper
INFO - 2020-01-26 12:30:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:00 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-01-26 12:31:00 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:00 --> Total execution time: 0.8812
INFO - 2020-01-26 12:31:05 --> Config Class Initialized
INFO - 2020-01-26 12:31:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:31:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:31:05 --> Utf8 Class Initialized
INFO - 2020-01-26 12:31:05 --> URI Class Initialized
INFO - 2020-01-26 12:31:05 --> Router Class Initialized
INFO - 2020-01-26 12:31:05 --> Output Class Initialized
INFO - 2020-01-26 12:31:05 --> Security Class Initialized
DEBUG - 2020-01-26 12:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:31:05 --> Input Class Initialized
INFO - 2020-01-26 12:31:05 --> Language Class Initialized
INFO - 2020-01-26 12:31:05 --> Language Class Initialized
INFO - 2020-01-26 12:31:05 --> Config Class Initialized
INFO - 2020-01-26 12:31:05 --> Loader Class Initialized
INFO - 2020-01-26 12:31:05 --> Helper loaded: url_helper
INFO - 2020-01-26 12:31:06 --> Helper loaded: file_helper
INFO - 2020-01-26 12:31:06 --> Helper loaded: form_helper
INFO - 2020-01-26 12:31:06 --> Helper loaded: my_helper
INFO - 2020-01-26 12:31:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:06 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-01-26 12:31:06 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:06 --> Total execution time: 1.0511
INFO - 2020-01-26 12:31:22 --> Config Class Initialized
INFO - 2020-01-26 12:31:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:31:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:31:22 --> Utf8 Class Initialized
INFO - 2020-01-26 12:31:22 --> URI Class Initialized
INFO - 2020-01-26 12:31:22 --> Router Class Initialized
INFO - 2020-01-26 12:31:22 --> Output Class Initialized
INFO - 2020-01-26 12:31:22 --> Security Class Initialized
DEBUG - 2020-01-26 12:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:31:22 --> Input Class Initialized
INFO - 2020-01-26 12:31:22 --> Language Class Initialized
INFO - 2020-01-26 12:31:22 --> Language Class Initialized
INFO - 2020-01-26 12:31:22 --> Config Class Initialized
INFO - 2020-01-26 12:31:22 --> Loader Class Initialized
INFO - 2020-01-26 12:31:22 --> Helper loaded: url_helper
INFO - 2020-01-26 12:31:22 --> Helper loaded: file_helper
INFO - 2020-01-26 12:31:22 --> Helper loaded: form_helper
INFO - 2020-01-26 12:31:22 --> Helper loaded: my_helper
INFO - 2020-01-26 12:31:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:22 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-01-26 12:31:23 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:23 --> Total execution time: 0.8726
INFO - 2020-01-26 12:31:31 --> Config Class Initialized
INFO - 2020-01-26 12:31:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:31:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:31:31 --> Utf8 Class Initialized
INFO - 2020-01-26 12:31:31 --> URI Class Initialized
INFO - 2020-01-26 12:31:31 --> Router Class Initialized
INFO - 2020-01-26 12:31:31 --> Output Class Initialized
INFO - 2020-01-26 12:31:31 --> Security Class Initialized
DEBUG - 2020-01-26 12:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:31:31 --> Input Class Initialized
INFO - 2020-01-26 12:31:31 --> Language Class Initialized
INFO - 2020-01-26 12:31:31 --> Language Class Initialized
INFO - 2020-01-26 12:31:31 --> Config Class Initialized
INFO - 2020-01-26 12:31:31 --> Loader Class Initialized
INFO - 2020-01-26 12:31:31 --> Helper loaded: url_helper
INFO - 2020-01-26 12:31:31 --> Helper loaded: file_helper
INFO - 2020-01-26 12:31:31 --> Helper loaded: form_helper
INFO - 2020-01-26 12:31:31 --> Helper loaded: my_helper
INFO - 2020-01-26 12:31:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:31 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-01-26 12:31:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 12:31:31 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:31 --> Total execution time: 0.8634
INFO - 2020-01-26 12:31:33 --> Config Class Initialized
INFO - 2020-01-26 12:31:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:31:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:31:33 --> Utf8 Class Initialized
INFO - 2020-01-26 12:31:33 --> URI Class Initialized
INFO - 2020-01-26 12:31:33 --> Router Class Initialized
INFO - 2020-01-26 12:31:33 --> Output Class Initialized
INFO - 2020-01-26 12:31:33 --> Security Class Initialized
DEBUG - 2020-01-26 12:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:31:33 --> Input Class Initialized
INFO - 2020-01-26 12:31:33 --> Language Class Initialized
INFO - 2020-01-26 12:31:33 --> Language Class Initialized
INFO - 2020-01-26 12:31:33 --> Config Class Initialized
INFO - 2020-01-26 12:31:33 --> Loader Class Initialized
INFO - 2020-01-26 12:31:33 --> Helper loaded: url_helper
INFO - 2020-01-26 12:31:34 --> Helper loaded: file_helper
INFO - 2020-01-26 12:31:34 --> Helper loaded: form_helper
INFO - 2020-01-26 12:31:34 --> Helper loaded: my_helper
INFO - 2020-01-26 12:31:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:34 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak.php
INFO - 2020-01-26 12:31:34 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:34 --> Total execution time: 0.9408
INFO - 2020-01-26 12:31:41 --> Config Class Initialized
INFO - 2020-01-26 12:31:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 12:31:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 12:31:41 --> Utf8 Class Initialized
INFO - 2020-01-26 12:31:41 --> URI Class Initialized
INFO - 2020-01-26 12:31:41 --> Router Class Initialized
INFO - 2020-01-26 12:31:41 --> Output Class Initialized
INFO - 2020-01-26 12:31:41 --> Security Class Initialized
DEBUG - 2020-01-26 12:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 12:31:41 --> Input Class Initialized
INFO - 2020-01-26 12:31:41 --> Language Class Initialized
INFO - 2020-01-26 12:31:41 --> Language Class Initialized
INFO - 2020-01-26 12:31:41 --> Config Class Initialized
INFO - 2020-01-26 12:31:41 --> Loader Class Initialized
INFO - 2020-01-26 12:31:41 --> Helper loaded: url_helper
INFO - 2020-01-26 12:31:41 --> Helper loaded: file_helper
INFO - 2020-01-26 12:31:42 --> Helper loaded: form_helper
INFO - 2020-01-26 12:31:42 --> Helper loaded: my_helper
INFO - 2020-01-26 12:31:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 12:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 12:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 12:31:42 --> Controller Class Initialized
DEBUG - 2020-01-26 12:31:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-01-26 12:31:42 --> Final output sent to browser
DEBUG - 2020-01-26 12:31:42 --> Total execution time: 0.8886
INFO - 2020-01-26 13:05:53 --> Config Class Initialized
INFO - 2020-01-26 13:05:53 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:05:53 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:05:53 --> Utf8 Class Initialized
INFO - 2020-01-26 13:05:53 --> URI Class Initialized
INFO - 2020-01-26 13:05:53 --> Router Class Initialized
INFO - 2020-01-26 13:05:53 --> Output Class Initialized
INFO - 2020-01-26 13:05:53 --> Security Class Initialized
DEBUG - 2020-01-26 13:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:05:53 --> Input Class Initialized
INFO - 2020-01-26 13:05:54 --> Language Class Initialized
INFO - 2020-01-26 13:05:54 --> Language Class Initialized
INFO - 2020-01-26 13:05:54 --> Config Class Initialized
INFO - 2020-01-26 13:05:54 --> Loader Class Initialized
INFO - 2020-01-26 13:05:54 --> Helper loaded: url_helper
INFO - 2020-01-26 13:05:54 --> Helper loaded: file_helper
INFO - 2020-01-26 13:05:54 --> Helper loaded: form_helper
INFO - 2020-01-26 13:05:54 --> Helper loaded: my_helper
INFO - 2020-01-26 13:05:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:05:54 --> Controller Class Initialized
DEBUG - 2020-01-26 13:05:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2020-01-26 13:05:54 --> Final output sent to browser
DEBUG - 2020-01-26 13:05:54 --> Total execution time: 0.9172
INFO - 2020-01-26 13:06:01 --> Config Class Initialized
INFO - 2020-01-26 13:06:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:01 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:01 --> URI Class Initialized
INFO - 2020-01-26 13:06:01 --> Router Class Initialized
INFO - 2020-01-26 13:06:01 --> Output Class Initialized
INFO - 2020-01-26 13:06:01 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:01 --> Input Class Initialized
INFO - 2020-01-26 13:06:01 --> Language Class Initialized
INFO - 2020-01-26 13:06:01 --> Language Class Initialized
INFO - 2020-01-26 13:06:01 --> Config Class Initialized
INFO - 2020-01-26 13:06:01 --> Loader Class Initialized
INFO - 2020-01-26 13:06:01 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:01 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:02 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:02 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:02 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-01-26 13:06:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:02 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:02 --> Total execution time: 1.2233
INFO - 2020-01-26 13:06:08 --> Config Class Initialized
INFO - 2020-01-26 13:06:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:08 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:08 --> URI Class Initialized
INFO - 2020-01-26 13:06:08 --> Router Class Initialized
INFO - 2020-01-26 13:06:08 --> Output Class Initialized
INFO - 2020-01-26 13:06:08 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:08 --> Input Class Initialized
INFO - 2020-01-26 13:06:08 --> Language Class Initialized
INFO - 2020-01-26 13:06:08 --> Language Class Initialized
INFO - 2020-01-26 13:06:08 --> Config Class Initialized
INFO - 2020-01-26 13:06:08 --> Loader Class Initialized
INFO - 2020-01-26 13:06:09 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:09 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:09 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:09 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:09 --> Controller Class Initialized
INFO - 2020-01-26 13:06:09 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:06:09 --> Config Class Initialized
INFO - 2020-01-26 13:06:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:09 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:09 --> URI Class Initialized
INFO - 2020-01-26 13:06:09 --> Router Class Initialized
INFO - 2020-01-26 13:06:09 --> Output Class Initialized
INFO - 2020-01-26 13:06:09 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:09 --> Input Class Initialized
INFO - 2020-01-26 13:06:09 --> Language Class Initialized
INFO - 2020-01-26 13:06:10 --> Language Class Initialized
INFO - 2020-01-26 13:06:10 --> Config Class Initialized
INFO - 2020-01-26 13:06:10 --> Loader Class Initialized
INFO - 2020-01-26 13:06:10 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:10 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:10 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:10 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:10 --> Controller Class Initialized
INFO - 2020-01-26 13:06:10 --> Config Class Initialized
INFO - 2020-01-26 13:06:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:10 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:10 --> URI Class Initialized
INFO - 2020-01-26 13:06:10 --> Router Class Initialized
INFO - 2020-01-26 13:06:10 --> Output Class Initialized
INFO - 2020-01-26 13:06:10 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:10 --> Input Class Initialized
INFO - 2020-01-26 13:06:10 --> Language Class Initialized
INFO - 2020-01-26 13:06:10 --> Language Class Initialized
INFO - 2020-01-26 13:06:11 --> Config Class Initialized
INFO - 2020-01-26 13:06:11 --> Loader Class Initialized
INFO - 2020-01-26 13:06:11 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:11 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:11 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:11 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:11 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 13:06:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:11 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:11 --> Total execution time: 1.0570
INFO - 2020-01-26 13:06:16 --> Config Class Initialized
INFO - 2020-01-26 13:06:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:16 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:16 --> URI Class Initialized
INFO - 2020-01-26 13:06:16 --> Router Class Initialized
INFO - 2020-01-26 13:06:16 --> Output Class Initialized
INFO - 2020-01-26 13:06:16 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:16 --> Input Class Initialized
INFO - 2020-01-26 13:06:16 --> Language Class Initialized
INFO - 2020-01-26 13:06:16 --> Language Class Initialized
INFO - 2020-01-26 13:06:16 --> Config Class Initialized
INFO - 2020-01-26 13:06:16 --> Loader Class Initialized
INFO - 2020-01-26 13:06:16 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:16 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:16 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:16 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:16 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:16 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 13:06:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:17 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:17 --> Total execution time: 0.9940
INFO - 2020-01-26 13:06:17 --> Config Class Initialized
INFO - 2020-01-26 13:06:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:18 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:18 --> URI Class Initialized
DEBUG - 2020-01-26 13:06:18 --> No URI present. Default controller set.
INFO - 2020-01-26 13:06:18 --> Router Class Initialized
INFO - 2020-01-26 13:06:18 --> Output Class Initialized
INFO - 2020-01-26 13:06:18 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:18 --> Input Class Initialized
INFO - 2020-01-26 13:06:18 --> Language Class Initialized
INFO - 2020-01-26 13:06:18 --> Language Class Initialized
INFO - 2020-01-26 13:06:18 --> Config Class Initialized
INFO - 2020-01-26 13:06:18 --> Loader Class Initialized
INFO - 2020-01-26 13:06:18 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:18 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:18 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:18 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:18 --> Controller Class Initialized
INFO - 2020-01-26 13:06:18 --> Config Class Initialized
INFO - 2020-01-26 13:06:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:18 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:19 --> URI Class Initialized
INFO - 2020-01-26 13:06:19 --> Router Class Initialized
INFO - 2020-01-26 13:06:19 --> Output Class Initialized
INFO - 2020-01-26 13:06:19 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:19 --> Input Class Initialized
INFO - 2020-01-26 13:06:19 --> Language Class Initialized
INFO - 2020-01-26 13:06:19 --> Language Class Initialized
INFO - 2020-01-26 13:06:19 --> Config Class Initialized
INFO - 2020-01-26 13:06:19 --> Loader Class Initialized
INFO - 2020-01-26 13:06:19 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:19 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:19 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:19 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:19 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 13:06:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:19 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:19 --> Total execution time: 0.9255
INFO - 2020-01-26 13:06:29 --> Config Class Initialized
INFO - 2020-01-26 13:06:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:29 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:29 --> URI Class Initialized
INFO - 2020-01-26 13:06:29 --> Router Class Initialized
INFO - 2020-01-26 13:06:29 --> Output Class Initialized
INFO - 2020-01-26 13:06:29 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:29 --> Input Class Initialized
INFO - 2020-01-26 13:06:29 --> Language Class Initialized
INFO - 2020-01-26 13:06:29 --> Language Class Initialized
INFO - 2020-01-26 13:06:29 --> Config Class Initialized
INFO - 2020-01-26 13:06:29 --> Loader Class Initialized
INFO - 2020-01-26 13:06:29 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:30 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:30 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:30 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:30 --> Controller Class Initialized
INFO - 2020-01-26 13:06:30 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:30 --> Total execution time: 0.8843
INFO - 2020-01-26 13:06:35 --> Config Class Initialized
INFO - 2020-01-26 13:06:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:36 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:36 --> URI Class Initialized
INFO - 2020-01-26 13:06:36 --> Router Class Initialized
INFO - 2020-01-26 13:06:36 --> Output Class Initialized
INFO - 2020-01-26 13:06:36 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:36 --> Input Class Initialized
INFO - 2020-01-26 13:06:36 --> Language Class Initialized
INFO - 2020-01-26 13:06:36 --> Language Class Initialized
INFO - 2020-01-26 13:06:36 --> Config Class Initialized
INFO - 2020-01-26 13:06:36 --> Loader Class Initialized
INFO - 2020-01-26 13:06:36 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:36 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:36 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:36 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:36 --> Controller Class Initialized
INFO - 2020-01-26 13:06:36 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:06:36 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:36 --> Total execution time: 1.0023
INFO - 2020-01-26 13:06:41 --> Config Class Initialized
INFO - 2020-01-26 13:06:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:41 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:41 --> URI Class Initialized
INFO - 2020-01-26 13:06:41 --> Router Class Initialized
INFO - 2020-01-26 13:06:41 --> Output Class Initialized
INFO - 2020-01-26 13:06:41 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:41 --> Input Class Initialized
INFO - 2020-01-26 13:06:41 --> Language Class Initialized
INFO - 2020-01-26 13:06:41 --> Language Class Initialized
INFO - 2020-01-26 13:06:41 --> Config Class Initialized
INFO - 2020-01-26 13:06:41 --> Loader Class Initialized
INFO - 2020-01-26 13:06:41 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:41 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:42 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:42 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:42 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 13:06:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:42 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:42 --> Total execution time: 1.0737
INFO - 2020-01-26 13:06:50 --> Config Class Initialized
INFO - 2020-01-26 13:06:50 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:50 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:50 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:50 --> URI Class Initialized
INFO - 2020-01-26 13:06:50 --> Router Class Initialized
INFO - 2020-01-26 13:06:50 --> Output Class Initialized
INFO - 2020-01-26 13:06:50 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:50 --> Input Class Initialized
INFO - 2020-01-26 13:06:50 --> Language Class Initialized
INFO - 2020-01-26 13:06:50 --> Language Class Initialized
INFO - 2020-01-26 13:06:50 --> Config Class Initialized
INFO - 2020-01-26 13:06:50 --> Loader Class Initialized
INFO - 2020-01-26 13:06:50 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:50 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:50 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:50 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:50 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:51 --> Controller Class Initialized
DEBUG - 2020-01-26 13:06:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 13:06:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:06:51 --> Final output sent to browser
DEBUG - 2020-01-26 13:06:51 --> Total execution time: 1.0267
INFO - 2020-01-26 13:06:51 --> Config Class Initialized
INFO - 2020-01-26 13:06:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:06:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:06:51 --> Utf8 Class Initialized
INFO - 2020-01-26 13:06:51 --> URI Class Initialized
INFO - 2020-01-26 13:06:51 --> Router Class Initialized
INFO - 2020-01-26 13:06:51 --> Output Class Initialized
INFO - 2020-01-26 13:06:51 --> Security Class Initialized
DEBUG - 2020-01-26 13:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:06:51 --> Input Class Initialized
INFO - 2020-01-26 13:06:51 --> Language Class Initialized
INFO - 2020-01-26 13:06:51 --> Language Class Initialized
INFO - 2020-01-26 13:06:51 --> Config Class Initialized
INFO - 2020-01-26 13:06:51 --> Loader Class Initialized
INFO - 2020-01-26 13:06:52 --> Helper loaded: url_helper
INFO - 2020-01-26 13:06:52 --> Helper loaded: file_helper
INFO - 2020-01-26 13:06:52 --> Helper loaded: form_helper
INFO - 2020-01-26 13:06:52 --> Helper loaded: my_helper
INFO - 2020-01-26 13:06:52 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:06:52 --> Controller Class Initialized
INFO - 2020-01-26 13:07:01 --> Config Class Initialized
INFO - 2020-01-26 13:07:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:02 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:02 --> URI Class Initialized
INFO - 2020-01-26 13:07:02 --> Router Class Initialized
INFO - 2020-01-26 13:07:02 --> Output Class Initialized
INFO - 2020-01-26 13:07:02 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:02 --> Input Class Initialized
INFO - 2020-01-26 13:07:02 --> Language Class Initialized
INFO - 2020-01-26 13:07:02 --> Language Class Initialized
INFO - 2020-01-26 13:07:02 --> Config Class Initialized
INFO - 2020-01-26 13:07:02 --> Loader Class Initialized
INFO - 2020-01-26 13:07:02 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:02 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:02 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:02 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:02 --> Controller Class Initialized
DEBUG - 2020-01-26 13:07:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 13:07:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:07:03 --> Final output sent to browser
DEBUG - 2020-01-26 13:07:03 --> Total execution time: 1.1219
INFO - 2020-01-26 13:07:03 --> Config Class Initialized
INFO - 2020-01-26 13:07:03 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:03 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:03 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:03 --> URI Class Initialized
INFO - 2020-01-26 13:07:03 --> Router Class Initialized
INFO - 2020-01-26 13:07:03 --> Output Class Initialized
INFO - 2020-01-26 13:07:03 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:03 --> Input Class Initialized
INFO - 2020-01-26 13:07:03 --> Language Class Initialized
INFO - 2020-01-26 13:07:03 --> Language Class Initialized
INFO - 2020-01-26 13:07:03 --> Config Class Initialized
INFO - 2020-01-26 13:07:03 --> Loader Class Initialized
INFO - 2020-01-26 13:07:03 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:04 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:04 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:04 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:04 --> Controller Class Initialized
INFO - 2020-01-26 13:07:10 --> Config Class Initialized
INFO - 2020-01-26 13:07:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:10 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:10 --> URI Class Initialized
INFO - 2020-01-26 13:07:10 --> Router Class Initialized
INFO - 2020-01-26 13:07:10 --> Output Class Initialized
INFO - 2020-01-26 13:07:10 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:10 --> Input Class Initialized
INFO - 2020-01-26 13:07:10 --> Language Class Initialized
INFO - 2020-01-26 13:07:10 --> Language Class Initialized
INFO - 2020-01-26 13:07:10 --> Config Class Initialized
INFO - 2020-01-26 13:07:10 --> Loader Class Initialized
INFO - 2020-01-26 13:07:10 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:10 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:10 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:11 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:11 --> Controller Class Initialized
DEBUG - 2020-01-26 13:07:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-01-26 13:07:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:07:11 --> Final output sent to browser
DEBUG - 2020-01-26 13:07:11 --> Total execution time: 1.2016
INFO - 2020-01-26 13:07:13 --> Config Class Initialized
INFO - 2020-01-26 13:07:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:13 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:13 --> URI Class Initialized
INFO - 2020-01-26 13:07:13 --> Router Class Initialized
INFO - 2020-01-26 13:07:13 --> Output Class Initialized
INFO - 2020-01-26 13:07:13 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:13 --> Input Class Initialized
INFO - 2020-01-26 13:07:14 --> Language Class Initialized
INFO - 2020-01-26 13:07:14 --> Language Class Initialized
INFO - 2020-01-26 13:07:14 --> Config Class Initialized
INFO - 2020-01-26 13:07:14 --> Loader Class Initialized
INFO - 2020-01-26 13:07:14 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:14 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:14 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:14 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:14 --> Controller Class Initialized
DEBUG - 2020-01-26 13:07:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 13:07:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:07:14 --> Final output sent to browser
DEBUG - 2020-01-26 13:07:14 --> Total execution time: 1.1696
INFO - 2020-01-26 13:07:14 --> Config Class Initialized
INFO - 2020-01-26 13:07:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:15 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:15 --> URI Class Initialized
INFO - 2020-01-26 13:07:15 --> Router Class Initialized
INFO - 2020-01-26 13:07:15 --> Output Class Initialized
INFO - 2020-01-26 13:07:15 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:15 --> Input Class Initialized
INFO - 2020-01-26 13:07:15 --> Language Class Initialized
INFO - 2020-01-26 13:07:15 --> Language Class Initialized
INFO - 2020-01-26 13:07:15 --> Config Class Initialized
INFO - 2020-01-26 13:07:15 --> Loader Class Initialized
INFO - 2020-01-26 13:07:15 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:15 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:15 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:15 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:15 --> Controller Class Initialized
INFO - 2020-01-26 13:07:29 --> Config Class Initialized
INFO - 2020-01-26 13:07:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:29 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:29 --> URI Class Initialized
INFO - 2020-01-26 13:07:29 --> Router Class Initialized
INFO - 2020-01-26 13:07:29 --> Output Class Initialized
INFO - 2020-01-26 13:07:29 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:29 --> Input Class Initialized
INFO - 2020-01-26 13:07:29 --> Language Class Initialized
INFO - 2020-01-26 13:07:29 --> Language Class Initialized
INFO - 2020-01-26 13:07:29 --> Config Class Initialized
INFO - 2020-01-26 13:07:29 --> Loader Class Initialized
INFO - 2020-01-26 13:07:29 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:29 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:29 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:29 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:30 --> Controller Class Initialized
INFO - 2020-01-26 13:07:32 --> Config Class Initialized
INFO - 2020-01-26 13:07:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:32 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:32 --> URI Class Initialized
INFO - 2020-01-26 13:07:32 --> Router Class Initialized
INFO - 2020-01-26 13:07:32 --> Output Class Initialized
INFO - 2020-01-26 13:07:32 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:32 --> Input Class Initialized
INFO - 2020-01-26 13:07:32 --> Language Class Initialized
INFO - 2020-01-26 13:07:32 --> Language Class Initialized
INFO - 2020-01-26 13:07:32 --> Config Class Initialized
INFO - 2020-01-26 13:07:32 --> Loader Class Initialized
INFO - 2020-01-26 13:07:32 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:32 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:32 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:32 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:33 --> Controller Class Initialized
INFO - 2020-01-26 13:07:41 --> Config Class Initialized
INFO - 2020-01-26 13:07:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:41 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:41 --> URI Class Initialized
INFO - 2020-01-26 13:07:41 --> Router Class Initialized
INFO - 2020-01-26 13:07:41 --> Output Class Initialized
INFO - 2020-01-26 13:07:42 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:42 --> Input Class Initialized
INFO - 2020-01-26 13:07:42 --> Language Class Initialized
INFO - 2020-01-26 13:07:42 --> Language Class Initialized
INFO - 2020-01-26 13:07:42 --> Config Class Initialized
INFO - 2020-01-26 13:07:42 --> Loader Class Initialized
INFO - 2020-01-26 13:07:42 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:42 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:42 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:42 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:42 --> Controller Class Initialized
INFO - 2020-01-26 13:07:42 --> Final output sent to browser
DEBUG - 2020-01-26 13:07:42 --> Total execution time: 0.9789
INFO - 2020-01-26 13:07:42 --> Config Class Initialized
INFO - 2020-01-26 13:07:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:42 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:42 --> URI Class Initialized
INFO - 2020-01-26 13:07:43 --> Router Class Initialized
INFO - 2020-01-26 13:07:43 --> Output Class Initialized
INFO - 2020-01-26 13:07:43 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:43 --> Input Class Initialized
INFO - 2020-01-26 13:07:43 --> Language Class Initialized
INFO - 2020-01-26 13:07:43 --> Language Class Initialized
INFO - 2020-01-26 13:07:43 --> Config Class Initialized
INFO - 2020-01-26 13:07:43 --> Loader Class Initialized
INFO - 2020-01-26 13:07:43 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:43 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:43 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:43 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:43 --> Controller Class Initialized
INFO - 2020-01-26 13:07:55 --> Config Class Initialized
INFO - 2020-01-26 13:07:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:55 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:55 --> URI Class Initialized
INFO - 2020-01-26 13:07:55 --> Router Class Initialized
INFO - 2020-01-26 13:07:55 --> Output Class Initialized
INFO - 2020-01-26 13:07:55 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:55 --> Input Class Initialized
INFO - 2020-01-26 13:07:55 --> Language Class Initialized
INFO - 2020-01-26 13:07:55 --> Language Class Initialized
INFO - 2020-01-26 13:07:55 --> Config Class Initialized
INFO - 2020-01-26 13:07:55 --> Loader Class Initialized
INFO - 2020-01-26 13:07:55 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:55 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:55 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:55 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:55 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:56 --> Controller Class Initialized
INFO - 2020-01-26 13:07:56 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:07:56 --> Config Class Initialized
INFO - 2020-01-26 13:07:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:56 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:56 --> URI Class Initialized
INFO - 2020-01-26 13:07:56 --> Router Class Initialized
INFO - 2020-01-26 13:07:56 --> Output Class Initialized
INFO - 2020-01-26 13:07:56 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:56 --> Input Class Initialized
INFO - 2020-01-26 13:07:56 --> Language Class Initialized
INFO - 2020-01-26 13:07:56 --> Language Class Initialized
INFO - 2020-01-26 13:07:56 --> Config Class Initialized
INFO - 2020-01-26 13:07:56 --> Loader Class Initialized
INFO - 2020-01-26 13:07:56 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:56 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:56 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:56 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:56 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:57 --> Controller Class Initialized
INFO - 2020-01-26 13:07:57 --> Config Class Initialized
INFO - 2020-01-26 13:07:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:07:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:07:57 --> Utf8 Class Initialized
INFO - 2020-01-26 13:07:57 --> URI Class Initialized
INFO - 2020-01-26 13:07:57 --> Router Class Initialized
INFO - 2020-01-26 13:07:57 --> Output Class Initialized
INFO - 2020-01-26 13:07:57 --> Security Class Initialized
DEBUG - 2020-01-26 13:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:07:57 --> Input Class Initialized
INFO - 2020-01-26 13:07:57 --> Language Class Initialized
INFO - 2020-01-26 13:07:57 --> Language Class Initialized
INFO - 2020-01-26 13:07:57 --> Config Class Initialized
INFO - 2020-01-26 13:07:57 --> Loader Class Initialized
INFO - 2020-01-26 13:07:57 --> Helper loaded: url_helper
INFO - 2020-01-26 13:07:57 --> Helper loaded: file_helper
INFO - 2020-01-26 13:07:57 --> Helper loaded: form_helper
INFO - 2020-01-26 13:07:57 --> Helper loaded: my_helper
INFO - 2020-01-26 13:07:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:07:58 --> Controller Class Initialized
DEBUG - 2020-01-26 13:07:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 13:07:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:07:58 --> Final output sent to browser
DEBUG - 2020-01-26 13:07:58 --> Total execution time: 1.0770
INFO - 2020-01-26 13:08:02 --> Config Class Initialized
INFO - 2020-01-26 13:08:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:02 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:02 --> URI Class Initialized
INFO - 2020-01-26 13:08:02 --> Router Class Initialized
INFO - 2020-01-26 13:08:02 --> Output Class Initialized
INFO - 2020-01-26 13:08:02 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:02 --> Input Class Initialized
INFO - 2020-01-26 13:08:02 --> Language Class Initialized
INFO - 2020-01-26 13:08:02 --> Language Class Initialized
INFO - 2020-01-26 13:08:03 --> Config Class Initialized
INFO - 2020-01-26 13:08:03 --> Loader Class Initialized
INFO - 2020-01-26 13:08:03 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:03 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:03 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:03 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:03 --> Controller Class Initialized
INFO - 2020-01-26 13:08:03 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:08:03 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:03 --> Total execution time: 1.3094
INFO - 2020-01-26 13:08:05 --> Config Class Initialized
INFO - 2020-01-26 13:08:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:05 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:05 --> URI Class Initialized
INFO - 2020-01-26 13:08:05 --> Router Class Initialized
INFO - 2020-01-26 13:08:05 --> Output Class Initialized
INFO - 2020-01-26 13:08:05 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:05 --> Input Class Initialized
INFO - 2020-01-26 13:08:05 --> Language Class Initialized
INFO - 2020-01-26 13:08:05 --> Language Class Initialized
INFO - 2020-01-26 13:08:05 --> Config Class Initialized
INFO - 2020-01-26 13:08:05 --> Loader Class Initialized
INFO - 2020-01-26 13:08:05 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:05 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:05 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:06 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:06 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-01-26 13:08:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:08:06 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:06 --> Total execution time: 1.4322
INFO - 2020-01-26 13:08:07 --> Config Class Initialized
INFO - 2020-01-26 13:08:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:08 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:08 --> URI Class Initialized
INFO - 2020-01-26 13:08:08 --> Router Class Initialized
INFO - 2020-01-26 13:08:08 --> Output Class Initialized
INFO - 2020-01-26 13:08:08 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:08 --> Input Class Initialized
INFO - 2020-01-26 13:08:08 --> Language Class Initialized
INFO - 2020-01-26 13:08:08 --> Language Class Initialized
INFO - 2020-01-26 13:08:08 --> Config Class Initialized
INFO - 2020-01-26 13:08:08 --> Loader Class Initialized
INFO - 2020-01-26 13:08:08 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:08 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:08 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:08 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:09 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/list.php
DEBUG - 2020-01-26 13:08:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:08:09 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:09 --> Total execution time: 1.2692
INFO - 2020-01-26 13:08:11 --> Config Class Initialized
INFO - 2020-01-26 13:08:11 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:11 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:11 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:11 --> URI Class Initialized
INFO - 2020-01-26 13:08:11 --> Router Class Initialized
INFO - 2020-01-26 13:08:11 --> Output Class Initialized
INFO - 2020-01-26 13:08:11 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:11 --> Input Class Initialized
INFO - 2020-01-26 13:08:11 --> Language Class Initialized
INFO - 2020-01-26 13:08:11 --> Language Class Initialized
INFO - 2020-01-26 13:08:11 --> Config Class Initialized
INFO - 2020-01-26 13:08:11 --> Loader Class Initialized
INFO - 2020-01-26 13:08:11 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:12 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:12 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:12 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:12 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/cetak_sampul1.php
INFO - 2020-01-26 13:08:12 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:12 --> Total execution time: 1.3514
INFO - 2020-01-26 13:08:18 --> Config Class Initialized
INFO - 2020-01-26 13:08:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:18 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:18 --> URI Class Initialized
INFO - 2020-01-26 13:08:18 --> Router Class Initialized
INFO - 2020-01-26 13:08:18 --> Output Class Initialized
INFO - 2020-01-26 13:08:18 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:18 --> Input Class Initialized
INFO - 2020-01-26 13:08:18 --> Language Class Initialized
INFO - 2020-01-26 13:08:18 --> Language Class Initialized
INFO - 2020-01-26 13:08:18 --> Config Class Initialized
INFO - 2020-01-26 13:08:18 --> Loader Class Initialized
INFO - 2020-01-26 13:08:18 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:18 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:18 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:18 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:19 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/cetak_sampul2.php
INFO - 2020-01-26 13:08:19 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:19 --> Total execution time: 1.1809
INFO - 2020-01-26 13:08:27 --> Config Class Initialized
INFO - 2020-01-26 13:08:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:27 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:27 --> URI Class Initialized
INFO - 2020-01-26 13:08:27 --> Router Class Initialized
INFO - 2020-01-26 13:08:27 --> Output Class Initialized
INFO - 2020-01-26 13:08:27 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:27 --> Input Class Initialized
INFO - 2020-01-26 13:08:27 --> Language Class Initialized
INFO - 2020-01-26 13:08:27 --> Language Class Initialized
INFO - 2020-01-26 13:08:27 --> Config Class Initialized
INFO - 2020-01-26 13:08:27 --> Loader Class Initialized
INFO - 2020-01-26 13:08:27 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:28 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:28 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:28 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:28 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/cetak_sampul4.php
INFO - 2020-01-26 13:08:28 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:28 --> Total execution time: 1.1139
INFO - 2020-01-26 13:08:34 --> Config Class Initialized
INFO - 2020-01-26 13:08:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:35 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:35 --> URI Class Initialized
INFO - 2020-01-26 13:08:35 --> Router Class Initialized
INFO - 2020-01-26 13:08:35 --> Output Class Initialized
INFO - 2020-01-26 13:08:35 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:35 --> Input Class Initialized
INFO - 2020-01-26 13:08:35 --> Language Class Initialized
INFO - 2020-01-26 13:08:35 --> Language Class Initialized
INFO - 2020-01-26 13:08:35 --> Config Class Initialized
INFO - 2020-01-26 13:08:35 --> Loader Class Initialized
INFO - 2020-01-26 13:08:35 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:35 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:35 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:35 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:35 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:35 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2020-01-26 13:08:36 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:36 --> Total execution time: 1.1063
INFO - 2020-01-26 13:08:55 --> Config Class Initialized
INFO - 2020-01-26 13:08:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:08:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:08:56 --> Utf8 Class Initialized
INFO - 2020-01-26 13:08:56 --> URI Class Initialized
INFO - 2020-01-26 13:08:56 --> Router Class Initialized
INFO - 2020-01-26 13:08:56 --> Output Class Initialized
INFO - 2020-01-26 13:08:56 --> Security Class Initialized
DEBUG - 2020-01-26 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:08:56 --> Input Class Initialized
INFO - 2020-01-26 13:08:56 --> Language Class Initialized
INFO - 2020-01-26 13:08:56 --> Language Class Initialized
INFO - 2020-01-26 13:08:56 --> Config Class Initialized
INFO - 2020-01-26 13:08:56 --> Loader Class Initialized
INFO - 2020-01-26 13:08:56 --> Helper loaded: url_helper
INFO - 2020-01-26 13:08:56 --> Helper loaded: file_helper
INFO - 2020-01-26 13:08:56 --> Helper loaded: form_helper
INFO - 2020-01-26 13:08:56 --> Helper loaded: my_helper
INFO - 2020-01-26 13:08:56 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:08:56 --> Controller Class Initialized
DEBUG - 2020-01-26 13:08:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2020-01-26 13:08:57 --> Final output sent to browser
DEBUG - 2020-01-26 13:08:57 --> Total execution time: 1.1234
INFO - 2020-01-26 13:09:13 --> Config Class Initialized
INFO - 2020-01-26 13:09:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:09:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:09:13 --> Utf8 Class Initialized
INFO - 2020-01-26 13:09:13 --> URI Class Initialized
INFO - 2020-01-26 13:09:13 --> Router Class Initialized
INFO - 2020-01-26 13:09:13 --> Output Class Initialized
INFO - 2020-01-26 13:09:13 --> Security Class Initialized
DEBUG - 2020-01-26 13:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:09:13 --> Input Class Initialized
INFO - 2020-01-26 13:09:13 --> Language Class Initialized
INFO - 2020-01-26 13:09:13 --> Language Class Initialized
INFO - 2020-01-26 13:09:13 --> Config Class Initialized
INFO - 2020-01-26 13:09:13 --> Loader Class Initialized
INFO - 2020-01-26 13:09:13 --> Helper loaded: url_helper
INFO - 2020-01-26 13:09:13 --> Helper loaded: file_helper
INFO - 2020-01-26 13:09:13 --> Helper loaded: form_helper
INFO - 2020-01-26 13:09:13 --> Helper loaded: my_helper
INFO - 2020-01-26 13:09:13 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:09:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:09:14 --> Controller Class Initialized
DEBUG - 2020-01-26 13:09:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/lihat_raport/views/list.php
DEBUG - 2020-01-26 13:09:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:09:14 --> Final output sent to browser
DEBUG - 2020-01-26 13:09:14 --> Total execution time: 1.1738
INFO - 2020-01-26 13:09:14 --> Config Class Initialized
INFO - 2020-01-26 13:09:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:09:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:09:14 --> Utf8 Class Initialized
INFO - 2020-01-26 13:09:14 --> URI Class Initialized
DEBUG - 2020-01-26 13:09:14 --> No URI present. Default controller set.
INFO - 2020-01-26 13:09:14 --> Router Class Initialized
INFO - 2020-01-26 13:09:14 --> Output Class Initialized
INFO - 2020-01-26 13:09:14 --> Security Class Initialized
DEBUG - 2020-01-26 13:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:09:15 --> Input Class Initialized
INFO - 2020-01-26 13:09:15 --> Language Class Initialized
INFO - 2020-01-26 13:09:15 --> Language Class Initialized
INFO - 2020-01-26 13:09:15 --> Config Class Initialized
INFO - 2020-01-26 13:09:15 --> Loader Class Initialized
INFO - 2020-01-26 13:09:15 --> Helper loaded: url_helper
INFO - 2020-01-26 13:09:15 --> Helper loaded: file_helper
INFO - 2020-01-26 13:09:15 --> Helper loaded: form_helper
INFO - 2020-01-26 13:09:15 --> Helper loaded: my_helper
INFO - 2020-01-26 13:09:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:09:15 --> Controller Class Initialized
DEBUG - 2020-01-26 13:09:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-01-26 13:09:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:09:15 --> Final output sent to browser
DEBUG - 2020-01-26 13:09:15 --> Total execution time: 1.2061
INFO - 2020-01-26 13:10:59 --> Config Class Initialized
INFO - 2020-01-26 13:10:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:10:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:10:59 --> Utf8 Class Initialized
INFO - 2020-01-26 13:10:59 --> URI Class Initialized
INFO - 2020-01-26 13:10:59 --> Router Class Initialized
INFO - 2020-01-26 13:10:59 --> Output Class Initialized
INFO - 2020-01-26 13:10:59 --> Security Class Initialized
DEBUG - 2020-01-26 13:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:10:59 --> Input Class Initialized
INFO - 2020-01-26 13:10:59 --> Language Class Initialized
INFO - 2020-01-26 13:10:59 --> Language Class Initialized
INFO - 2020-01-26 13:10:59 --> Config Class Initialized
INFO - 2020-01-26 13:10:59 --> Loader Class Initialized
INFO - 2020-01-26 13:10:59 --> Helper loaded: url_helper
INFO - 2020-01-26 13:10:59 --> Helper loaded: file_helper
INFO - 2020-01-26 13:10:59 --> Helper loaded: form_helper
INFO - 2020-01-26 13:10:59 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:00 --> Controller Class Initialized
INFO - 2020-01-26 13:11:00 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:11:00 --> Config Class Initialized
INFO - 2020-01-26 13:11:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:00 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:00 --> URI Class Initialized
INFO - 2020-01-26 13:11:00 --> Router Class Initialized
INFO - 2020-01-26 13:11:00 --> Output Class Initialized
INFO - 2020-01-26 13:11:00 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:00 --> Input Class Initialized
INFO - 2020-01-26 13:11:00 --> Language Class Initialized
INFO - 2020-01-26 13:11:00 --> Language Class Initialized
INFO - 2020-01-26 13:11:00 --> Config Class Initialized
INFO - 2020-01-26 13:11:01 --> Loader Class Initialized
INFO - 2020-01-26 13:11:01 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:01 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:01 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:01 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:01 --> Controller Class Initialized
INFO - 2020-01-26 13:11:01 --> Config Class Initialized
INFO - 2020-01-26 13:11:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:01 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:01 --> URI Class Initialized
INFO - 2020-01-26 13:11:01 --> Router Class Initialized
INFO - 2020-01-26 13:11:01 --> Output Class Initialized
INFO - 2020-01-26 13:11:01 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:01 --> Input Class Initialized
INFO - 2020-01-26 13:11:02 --> Language Class Initialized
INFO - 2020-01-26 13:11:02 --> Language Class Initialized
INFO - 2020-01-26 13:11:02 --> Config Class Initialized
INFO - 2020-01-26 13:11:02 --> Loader Class Initialized
INFO - 2020-01-26 13:11:02 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:02 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:02 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:02 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:02 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 13:11:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:02 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:02 --> Total execution time: 1.2991
INFO - 2020-01-26 13:11:09 --> Config Class Initialized
INFO - 2020-01-26 13:11:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:09 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:09 --> URI Class Initialized
INFO - 2020-01-26 13:11:09 --> Router Class Initialized
INFO - 2020-01-26 13:11:09 --> Output Class Initialized
INFO - 2020-01-26 13:11:09 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:09 --> Input Class Initialized
INFO - 2020-01-26 13:11:09 --> Language Class Initialized
INFO - 2020-01-26 13:11:09 --> Language Class Initialized
INFO - 2020-01-26 13:11:09 --> Config Class Initialized
INFO - 2020-01-26 13:11:09 --> Loader Class Initialized
INFO - 2020-01-26 13:11:10 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:10 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:10 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:10 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:10 --> Controller Class Initialized
INFO - 2020-01-26 13:11:10 --> Helper loaded: cookie_helper
INFO - 2020-01-26 13:11:10 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:10 --> Total execution time: 1.2322
INFO - 2020-01-26 13:11:11 --> Config Class Initialized
INFO - 2020-01-26 13:11:11 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:12 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:12 --> URI Class Initialized
INFO - 2020-01-26 13:11:12 --> Router Class Initialized
INFO - 2020-01-26 13:11:12 --> Output Class Initialized
INFO - 2020-01-26 13:11:12 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:12 --> Input Class Initialized
INFO - 2020-01-26 13:11:12 --> Language Class Initialized
INFO - 2020-01-26 13:11:12 --> Language Class Initialized
INFO - 2020-01-26 13:11:12 --> Config Class Initialized
INFO - 2020-01-26 13:11:12 --> Loader Class Initialized
INFO - 2020-01-26 13:11:12 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:12 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:12 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:13 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:13 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:13 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 13:11:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:13 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:13 --> Total execution time: 1.6649
INFO - 2020-01-26 13:11:24 --> Config Class Initialized
INFO - 2020-01-26 13:11:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:24 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:24 --> URI Class Initialized
INFO - 2020-01-26 13:11:24 --> Router Class Initialized
INFO - 2020-01-26 13:11:24 --> Output Class Initialized
INFO - 2020-01-26 13:11:24 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:24 --> Input Class Initialized
INFO - 2020-01-26 13:11:24 --> Language Class Initialized
INFO - 2020-01-26 13:11:24 --> Language Class Initialized
INFO - 2020-01-26 13:11:24 --> Config Class Initialized
INFO - 2020-01-26 13:11:25 --> Loader Class Initialized
INFO - 2020-01-26 13:11:25 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:25 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:25 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:25 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:25 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_walikelas/views/list.php
DEBUG - 2020-01-26 13:11:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:25 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:25 --> Total execution time: 1.1057
INFO - 2020-01-26 13:11:25 --> Config Class Initialized
INFO - 2020-01-26 13:11:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:25 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:25 --> URI Class Initialized
INFO - 2020-01-26 13:11:25 --> Router Class Initialized
INFO - 2020-01-26 13:11:26 --> Output Class Initialized
INFO - 2020-01-26 13:11:26 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:26 --> Input Class Initialized
INFO - 2020-01-26 13:11:26 --> Language Class Initialized
INFO - 2020-01-26 13:11:26 --> Language Class Initialized
INFO - 2020-01-26 13:11:26 --> Config Class Initialized
INFO - 2020-01-26 13:11:26 --> Loader Class Initialized
INFO - 2020-01-26 13:11:26 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:26 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:26 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:26 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:26 --> Controller Class Initialized
INFO - 2020-01-26 13:11:29 --> Config Class Initialized
INFO - 2020-01-26 13:11:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:30 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:30 --> URI Class Initialized
INFO - 2020-01-26 13:11:30 --> Router Class Initialized
INFO - 2020-01-26 13:11:30 --> Output Class Initialized
INFO - 2020-01-26 13:11:30 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:30 --> Input Class Initialized
INFO - 2020-01-26 13:11:30 --> Language Class Initialized
INFO - 2020-01-26 13:11:30 --> Language Class Initialized
INFO - 2020-01-26 13:11:30 --> Config Class Initialized
INFO - 2020-01-26 13:11:30 --> Loader Class Initialized
INFO - 2020-01-26 13:11:30 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:30 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:30 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:30 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:30 --> Controller Class Initialized
INFO - 2020-01-26 13:11:30 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:30 --> Total execution time: 1.0836
INFO - 2020-01-26 13:11:39 --> Config Class Initialized
INFO - 2020-01-26 13:11:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:39 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:40 --> URI Class Initialized
INFO - 2020-01-26 13:11:40 --> Router Class Initialized
INFO - 2020-01-26 13:11:40 --> Output Class Initialized
INFO - 2020-01-26 13:11:40 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:40 --> Input Class Initialized
INFO - 2020-01-26 13:11:40 --> Language Class Initialized
INFO - 2020-01-26 13:11:40 --> Language Class Initialized
INFO - 2020-01-26 13:11:40 --> Config Class Initialized
INFO - 2020-01-26 13:11:40 --> Loader Class Initialized
INFO - 2020-01-26 13:11:40 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:40 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:40 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:40 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:40 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 13:11:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:40 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:41 --> Total execution time: 1.1391
INFO - 2020-01-26 13:11:41 --> Config Class Initialized
INFO - 2020-01-26 13:11:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:41 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:41 --> URI Class Initialized
INFO - 2020-01-26 13:11:41 --> Router Class Initialized
INFO - 2020-01-26 13:11:41 --> Output Class Initialized
INFO - 2020-01-26 13:11:41 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:41 --> Input Class Initialized
INFO - 2020-01-26 13:11:41 --> Language Class Initialized
INFO - 2020-01-26 13:11:41 --> Language Class Initialized
INFO - 2020-01-26 13:11:41 --> Config Class Initialized
INFO - 2020-01-26 13:11:41 --> Loader Class Initialized
INFO - 2020-01-26 13:11:41 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:42 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:42 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:42 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:42 --> Controller Class Initialized
INFO - 2020-01-26 13:11:43 --> Config Class Initialized
INFO - 2020-01-26 13:11:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:43 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:43 --> URI Class Initialized
INFO - 2020-01-26 13:11:44 --> Router Class Initialized
INFO - 2020-01-26 13:11:44 --> Output Class Initialized
INFO - 2020-01-26 13:11:44 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:44 --> Input Class Initialized
INFO - 2020-01-26 13:11:44 --> Language Class Initialized
INFO - 2020-01-26 13:11:44 --> Language Class Initialized
INFO - 2020-01-26 13:11:44 --> Config Class Initialized
INFO - 2020-01-26 13:11:44 --> Loader Class Initialized
INFO - 2020-01-26 13:11:44 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:44 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:44 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:44 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:44 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 13:11:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:44 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:45 --> Total execution time: 1.1685
INFO - 2020-01-26 13:11:45 --> Config Class Initialized
INFO - 2020-01-26 13:11:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:45 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:45 --> URI Class Initialized
INFO - 2020-01-26 13:11:45 --> Router Class Initialized
INFO - 2020-01-26 13:11:45 --> Output Class Initialized
INFO - 2020-01-26 13:11:45 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:45 --> Input Class Initialized
INFO - 2020-01-26 13:11:45 --> Language Class Initialized
INFO - 2020-01-26 13:11:45 --> Language Class Initialized
INFO - 2020-01-26 13:11:45 --> Config Class Initialized
INFO - 2020-01-26 13:11:45 --> Loader Class Initialized
INFO - 2020-01-26 13:11:45 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:45 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:45 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:45 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:46 --> Controller Class Initialized
INFO - 2020-01-26 13:11:51 --> Config Class Initialized
INFO - 2020-01-26 13:11:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:51 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:51 --> URI Class Initialized
INFO - 2020-01-26 13:11:51 --> Router Class Initialized
INFO - 2020-01-26 13:11:51 --> Output Class Initialized
INFO - 2020-01-26 13:11:51 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:51 --> Input Class Initialized
INFO - 2020-01-26 13:11:51 --> Language Class Initialized
INFO - 2020-01-26 13:11:51 --> Language Class Initialized
INFO - 2020-01-26 13:11:51 --> Config Class Initialized
INFO - 2020-01-26 13:11:51 --> Loader Class Initialized
INFO - 2020-01-26 13:11:51 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:51 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:51 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:51 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:52 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:52 --> Controller Class Initialized
DEBUG - 2020-01-26 13:11:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 13:11:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:11:52 --> Final output sent to browser
DEBUG - 2020-01-26 13:11:52 --> Total execution time: 1.1601
INFO - 2020-01-26 13:11:52 --> Config Class Initialized
INFO - 2020-01-26 13:11:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:11:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:11:52 --> Utf8 Class Initialized
INFO - 2020-01-26 13:11:52 --> URI Class Initialized
INFO - 2020-01-26 13:11:52 --> Router Class Initialized
INFO - 2020-01-26 13:11:52 --> Output Class Initialized
INFO - 2020-01-26 13:11:52 --> Security Class Initialized
DEBUG - 2020-01-26 13:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:11:52 --> Input Class Initialized
INFO - 2020-01-26 13:11:53 --> Language Class Initialized
INFO - 2020-01-26 13:11:53 --> Language Class Initialized
INFO - 2020-01-26 13:11:53 --> Config Class Initialized
INFO - 2020-01-26 13:11:53 --> Loader Class Initialized
INFO - 2020-01-26 13:11:53 --> Helper loaded: url_helper
INFO - 2020-01-26 13:11:53 --> Helper loaded: file_helper
INFO - 2020-01-26 13:11:53 --> Helper loaded: form_helper
INFO - 2020-01-26 13:11:53 --> Helper loaded: my_helper
INFO - 2020-01-26 13:11:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:11:53 --> Controller Class Initialized
INFO - 2020-01-26 13:12:04 --> Config Class Initialized
INFO - 2020-01-26 13:12:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:05 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:05 --> URI Class Initialized
INFO - 2020-01-26 13:12:05 --> Router Class Initialized
INFO - 2020-01-26 13:12:05 --> Output Class Initialized
INFO - 2020-01-26 13:12:05 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:05 --> Input Class Initialized
INFO - 2020-01-26 13:12:05 --> Language Class Initialized
INFO - 2020-01-26 13:12:05 --> Language Class Initialized
INFO - 2020-01-26 13:12:05 --> Config Class Initialized
INFO - 2020-01-26 13:12:05 --> Loader Class Initialized
INFO - 2020-01-26 13:12:05 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:05 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:05 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:05 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:06 --> Controller Class Initialized
DEBUG - 2020-01-26 13:12:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-26 13:12:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:12:06 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:06 --> Total execution time: 1.4027
INFO - 2020-01-26 13:12:06 --> Config Class Initialized
INFO - 2020-01-26 13:12:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:06 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:06 --> URI Class Initialized
INFO - 2020-01-26 13:12:06 --> Router Class Initialized
INFO - 2020-01-26 13:12:07 --> Output Class Initialized
INFO - 2020-01-26 13:12:07 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:07 --> Input Class Initialized
INFO - 2020-01-26 13:12:07 --> Language Class Initialized
INFO - 2020-01-26 13:12:07 --> Language Class Initialized
INFO - 2020-01-26 13:12:07 --> Config Class Initialized
INFO - 2020-01-26 13:12:07 --> Loader Class Initialized
INFO - 2020-01-26 13:12:07 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:07 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:07 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:07 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:07 --> Controller Class Initialized
INFO - 2020-01-26 13:12:11 --> Config Class Initialized
INFO - 2020-01-26 13:12:11 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:11 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:11 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:11 --> URI Class Initialized
INFO - 2020-01-26 13:12:11 --> Router Class Initialized
INFO - 2020-01-26 13:12:12 --> Output Class Initialized
INFO - 2020-01-26 13:12:12 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:12 --> Input Class Initialized
INFO - 2020-01-26 13:12:12 --> Language Class Initialized
INFO - 2020-01-26 13:12:12 --> Language Class Initialized
INFO - 2020-01-26 13:12:12 --> Config Class Initialized
INFO - 2020-01-26 13:12:12 --> Loader Class Initialized
INFO - 2020-01-26 13:12:12 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:12 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:12 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:12 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:12 --> Controller Class Initialized
INFO - 2020-01-26 13:12:19 --> Config Class Initialized
INFO - 2020-01-26 13:12:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:19 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:19 --> URI Class Initialized
INFO - 2020-01-26 13:12:20 --> Router Class Initialized
INFO - 2020-01-26 13:12:20 --> Output Class Initialized
INFO - 2020-01-26 13:12:20 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:20 --> Input Class Initialized
INFO - 2020-01-26 13:12:20 --> Language Class Initialized
INFO - 2020-01-26 13:12:20 --> Language Class Initialized
INFO - 2020-01-26 13:12:20 --> Config Class Initialized
INFO - 2020-01-26 13:12:20 --> Loader Class Initialized
INFO - 2020-01-26 13:12:20 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:20 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:20 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:20 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:20 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:20 --> Controller Class Initialized
INFO - 2020-01-26 13:12:20 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:20 --> Total execution time: 1.0926
INFO - 2020-01-26 13:12:24 --> Config Class Initialized
INFO - 2020-01-26 13:12:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:24 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:24 --> URI Class Initialized
INFO - 2020-01-26 13:12:24 --> Router Class Initialized
INFO - 2020-01-26 13:12:24 --> Output Class Initialized
INFO - 2020-01-26 13:12:24 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:24 --> Input Class Initialized
INFO - 2020-01-26 13:12:24 --> Language Class Initialized
INFO - 2020-01-26 13:12:24 --> Language Class Initialized
INFO - 2020-01-26 13:12:24 --> Config Class Initialized
INFO - 2020-01-26 13:12:24 --> Loader Class Initialized
INFO - 2020-01-26 13:12:24 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:24 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:24 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:25 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:25 --> Controller Class Initialized
INFO - 2020-01-26 13:12:25 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:25 --> Total execution time: 1.1463
INFO - 2020-01-26 13:12:33 --> Config Class Initialized
INFO - 2020-01-26 13:12:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:33 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:33 --> URI Class Initialized
INFO - 2020-01-26 13:12:33 --> Router Class Initialized
INFO - 2020-01-26 13:12:33 --> Output Class Initialized
INFO - 2020-01-26 13:12:33 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:33 --> Input Class Initialized
INFO - 2020-01-26 13:12:33 --> Language Class Initialized
INFO - 2020-01-26 13:12:34 --> Language Class Initialized
INFO - 2020-01-26 13:12:34 --> Config Class Initialized
INFO - 2020-01-26 13:12:34 --> Loader Class Initialized
INFO - 2020-01-26 13:12:34 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:34 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:34 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:34 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:34 --> Controller Class Initialized
DEBUG - 2020-01-26 13:12:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 13:12:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:12:34 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:34 --> Total execution time: 1.2628
INFO - 2020-01-26 13:12:34 --> Config Class Initialized
INFO - 2020-01-26 13:12:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:35 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:35 --> URI Class Initialized
INFO - 2020-01-26 13:12:35 --> Router Class Initialized
INFO - 2020-01-26 13:12:35 --> Output Class Initialized
INFO - 2020-01-26 13:12:35 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:35 --> Input Class Initialized
INFO - 2020-01-26 13:12:35 --> Language Class Initialized
INFO - 2020-01-26 13:12:35 --> Language Class Initialized
INFO - 2020-01-26 13:12:35 --> Config Class Initialized
INFO - 2020-01-26 13:12:35 --> Loader Class Initialized
INFO - 2020-01-26 13:12:35 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:35 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:35 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:35 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:35 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:36 --> Controller Class Initialized
INFO - 2020-01-26 13:12:39 --> Config Class Initialized
INFO - 2020-01-26 13:12:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:39 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:39 --> URI Class Initialized
INFO - 2020-01-26 13:12:39 --> Router Class Initialized
INFO - 2020-01-26 13:12:39 --> Output Class Initialized
INFO - 2020-01-26 13:12:39 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:39 --> Input Class Initialized
INFO - 2020-01-26 13:12:39 --> Language Class Initialized
INFO - 2020-01-26 13:12:40 --> Language Class Initialized
INFO - 2020-01-26 13:12:40 --> Config Class Initialized
INFO - 2020-01-26 13:12:40 --> Loader Class Initialized
INFO - 2020-01-26 13:12:40 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:40 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:40 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:40 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:40 --> Controller Class Initialized
DEBUG - 2020-01-26 13:12:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 13:12:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:12:40 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:40 --> Total execution time: 1.2459
INFO - 2020-01-26 13:12:40 --> Config Class Initialized
INFO - 2020-01-26 13:12:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:41 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:41 --> URI Class Initialized
INFO - 2020-01-26 13:12:41 --> Router Class Initialized
INFO - 2020-01-26 13:12:41 --> Output Class Initialized
INFO - 2020-01-26 13:12:41 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:41 --> Input Class Initialized
INFO - 2020-01-26 13:12:41 --> Language Class Initialized
INFO - 2020-01-26 13:12:41 --> Language Class Initialized
INFO - 2020-01-26 13:12:41 --> Config Class Initialized
INFO - 2020-01-26 13:12:41 --> Loader Class Initialized
INFO - 2020-01-26 13:12:41 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:41 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:41 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:41 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:42 --> Controller Class Initialized
INFO - 2020-01-26 13:12:44 --> Config Class Initialized
INFO - 2020-01-26 13:12:44 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:12:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:12:45 --> Utf8 Class Initialized
INFO - 2020-01-26 13:12:45 --> URI Class Initialized
INFO - 2020-01-26 13:12:45 --> Router Class Initialized
INFO - 2020-01-26 13:12:45 --> Output Class Initialized
INFO - 2020-01-26 13:12:45 --> Security Class Initialized
DEBUG - 2020-01-26 13:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:12:45 --> Input Class Initialized
INFO - 2020-01-26 13:12:45 --> Language Class Initialized
INFO - 2020-01-26 13:12:45 --> Language Class Initialized
INFO - 2020-01-26 13:12:45 --> Config Class Initialized
INFO - 2020-01-26 13:12:45 --> Loader Class Initialized
INFO - 2020-01-26 13:12:45 --> Helper loaded: url_helper
INFO - 2020-01-26 13:12:45 --> Helper loaded: file_helper
INFO - 2020-01-26 13:12:45 --> Helper loaded: form_helper
INFO - 2020-01-26 13:12:45 --> Helper loaded: my_helper
INFO - 2020-01-26 13:12:45 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:12:45 --> Controller Class Initialized
INFO - 2020-01-26 13:12:46 --> Final output sent to browser
DEBUG - 2020-01-26 13:12:46 --> Total execution time: 1.1758
INFO - 2020-01-26 13:13:12 --> Config Class Initialized
INFO - 2020-01-26 13:13:12 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:13:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:13:12 --> Utf8 Class Initialized
INFO - 2020-01-26 13:13:13 --> URI Class Initialized
INFO - 2020-01-26 13:13:13 --> Router Class Initialized
INFO - 2020-01-26 13:13:13 --> Output Class Initialized
INFO - 2020-01-26 13:13:13 --> Security Class Initialized
DEBUG - 2020-01-26 13:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:13:13 --> Input Class Initialized
INFO - 2020-01-26 13:13:13 --> Language Class Initialized
INFO - 2020-01-26 13:13:13 --> Language Class Initialized
INFO - 2020-01-26 13:13:13 --> Config Class Initialized
INFO - 2020-01-26 13:13:13 --> Loader Class Initialized
INFO - 2020-01-26 13:13:13 --> Helper loaded: url_helper
INFO - 2020-01-26 13:13:13 --> Helper loaded: file_helper
INFO - 2020-01-26 13:13:13 --> Helper loaded: form_helper
INFO - 2020-01-26 13:13:13 --> Helper loaded: my_helper
INFO - 2020-01-26 13:13:13 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:13:13 --> Controller Class Initialized
INFO - 2020-01-26 13:13:13 --> Final output sent to browser
DEBUG - 2020-01-26 13:13:13 --> Total execution time: 1.1270
INFO - 2020-01-26 13:13:14 --> Config Class Initialized
INFO - 2020-01-26 13:13:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:13:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:13:14 --> Utf8 Class Initialized
INFO - 2020-01-26 13:13:14 --> URI Class Initialized
INFO - 2020-01-26 13:13:14 --> Router Class Initialized
INFO - 2020-01-26 13:13:14 --> Output Class Initialized
INFO - 2020-01-26 13:13:14 --> Security Class Initialized
DEBUG - 2020-01-26 13:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:13:14 --> Input Class Initialized
INFO - 2020-01-26 13:13:14 --> Language Class Initialized
INFO - 2020-01-26 13:13:14 --> Language Class Initialized
INFO - 2020-01-26 13:13:14 --> Config Class Initialized
INFO - 2020-01-26 13:13:14 --> Loader Class Initialized
INFO - 2020-01-26 13:13:14 --> Helper loaded: url_helper
INFO - 2020-01-26 13:13:14 --> Helper loaded: file_helper
INFO - 2020-01-26 13:13:14 --> Helper loaded: form_helper
INFO - 2020-01-26 13:13:14 --> Helper loaded: my_helper
INFO - 2020-01-26 13:13:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:13:15 --> Controller Class Initialized
INFO - 2020-01-26 13:13:21 --> Config Class Initialized
INFO - 2020-01-26 13:13:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:13:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:13:21 --> Utf8 Class Initialized
INFO - 2020-01-26 13:13:21 --> URI Class Initialized
INFO - 2020-01-26 13:13:21 --> Router Class Initialized
INFO - 2020-01-26 13:13:21 --> Output Class Initialized
INFO - 2020-01-26 13:13:21 --> Security Class Initialized
DEBUG - 2020-01-26 13:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:13:21 --> Input Class Initialized
INFO - 2020-01-26 13:13:21 --> Language Class Initialized
INFO - 2020-01-26 13:13:21 --> Language Class Initialized
INFO - 2020-01-26 13:13:21 --> Config Class Initialized
INFO - 2020-01-26 13:13:21 --> Loader Class Initialized
INFO - 2020-01-26 13:13:21 --> Helper loaded: url_helper
INFO - 2020-01-26 13:13:21 --> Helper loaded: file_helper
INFO - 2020-01-26 13:13:21 --> Helper loaded: form_helper
INFO - 2020-01-26 13:13:21 --> Helper loaded: my_helper
INFO - 2020-01-26 13:13:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:13:22 --> Controller Class Initialized
DEBUG - 2020-01-26 13:13:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 13:13:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:13:22 --> Final output sent to browser
DEBUG - 2020-01-26 13:13:22 --> Total execution time: 1.2528
INFO - 2020-01-26 13:13:26 --> Config Class Initialized
INFO - 2020-01-26 13:13:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:13:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:13:26 --> Utf8 Class Initialized
INFO - 2020-01-26 13:13:26 --> URI Class Initialized
INFO - 2020-01-26 13:13:26 --> Router Class Initialized
INFO - 2020-01-26 13:13:26 --> Output Class Initialized
INFO - 2020-01-26 13:13:26 --> Security Class Initialized
DEBUG - 2020-01-26 13:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:13:26 --> Input Class Initialized
INFO - 2020-01-26 13:13:26 --> Language Class Initialized
INFO - 2020-01-26 13:13:27 --> Language Class Initialized
INFO - 2020-01-26 13:13:27 --> Config Class Initialized
INFO - 2020-01-26 13:13:27 --> Loader Class Initialized
INFO - 2020-01-26 13:13:27 --> Helper loaded: url_helper
INFO - 2020-01-26 13:13:27 --> Helper loaded: file_helper
INFO - 2020-01-26 13:13:27 --> Helper loaded: form_helper
INFO - 2020-01-26 13:13:27 --> Helper loaded: my_helper
INFO - 2020-01-26 13:13:27 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:13:27 --> Controller Class Initialized
DEBUG - 2020-01-26 13:13:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 13:13:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:13:27 --> Final output sent to browser
DEBUG - 2020-01-26 13:13:27 --> Total execution time: 1.3089
INFO - 2020-01-26 13:14:06 --> Config Class Initialized
INFO - 2020-01-26 13:14:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:14:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:14:06 --> Utf8 Class Initialized
INFO - 2020-01-26 13:14:06 --> URI Class Initialized
INFO - 2020-01-26 13:14:06 --> Router Class Initialized
INFO - 2020-01-26 13:14:06 --> Output Class Initialized
INFO - 2020-01-26 13:14:06 --> Security Class Initialized
DEBUG - 2020-01-26 13:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:14:06 --> Input Class Initialized
INFO - 2020-01-26 13:14:06 --> Language Class Initialized
INFO - 2020-01-26 13:14:06 --> Language Class Initialized
INFO - 2020-01-26 13:14:06 --> Config Class Initialized
INFO - 2020-01-26 13:14:06 --> Loader Class Initialized
INFO - 2020-01-26 13:14:07 --> Helper loaded: url_helper
INFO - 2020-01-26 13:14:07 --> Helper loaded: file_helper
INFO - 2020-01-26 13:14:07 --> Helper loaded: form_helper
INFO - 2020-01-26 13:14:07 --> Helper loaded: my_helper
INFO - 2020-01-26 13:14:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:14:07 --> Controller Class Initialized
DEBUG - 2020-01-26 13:14:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 13:14:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:14:07 --> Final output sent to browser
DEBUG - 2020-01-26 13:14:07 --> Total execution time: 1.5176
INFO - 2020-01-26 13:55:27 --> Config Class Initialized
INFO - 2020-01-26 13:55:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:55:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:55:27 --> Utf8 Class Initialized
INFO - 2020-01-26 13:55:27 --> URI Class Initialized
INFO - 2020-01-26 13:55:28 --> Router Class Initialized
INFO - 2020-01-26 13:55:28 --> Output Class Initialized
INFO - 2020-01-26 13:55:28 --> Security Class Initialized
DEBUG - 2020-01-26 13:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:55:28 --> Input Class Initialized
INFO - 2020-01-26 13:55:28 --> Language Class Initialized
INFO - 2020-01-26 13:55:28 --> Language Class Initialized
INFO - 2020-01-26 13:55:28 --> Config Class Initialized
INFO - 2020-01-26 13:55:28 --> Loader Class Initialized
INFO - 2020-01-26 13:55:28 --> Helper loaded: url_helper
INFO - 2020-01-26 13:55:28 --> Helper loaded: file_helper
INFO - 2020-01-26 13:55:28 --> Helper loaded: form_helper
INFO - 2020-01-26 13:55:28 --> Helper loaded: my_helper
INFO - 2020-01-26 13:55:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:55:29 --> Controller Class Initialized
DEBUG - 2020-01-26 13:55:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 13:55:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:55:29 --> Final output sent to browser
DEBUG - 2020-01-26 13:55:29 --> Total execution time: 1.7688
INFO - 2020-01-26 13:55:29 --> Config Class Initialized
INFO - 2020-01-26 13:55:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:55:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:55:29 --> Utf8 Class Initialized
INFO - 2020-01-26 13:55:29 --> URI Class Initialized
INFO - 2020-01-26 13:55:29 --> Router Class Initialized
INFO - 2020-01-26 13:55:30 --> Output Class Initialized
INFO - 2020-01-26 13:55:30 --> Security Class Initialized
DEBUG - 2020-01-26 13:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:55:30 --> Input Class Initialized
INFO - 2020-01-26 13:55:30 --> Language Class Initialized
INFO - 2020-01-26 13:55:30 --> Language Class Initialized
INFO - 2020-01-26 13:55:30 --> Config Class Initialized
INFO - 2020-01-26 13:55:30 --> Loader Class Initialized
INFO - 2020-01-26 13:55:30 --> Helper loaded: url_helper
INFO - 2020-01-26 13:55:30 --> Helper loaded: file_helper
INFO - 2020-01-26 13:55:30 --> Helper loaded: form_helper
INFO - 2020-01-26 13:55:30 --> Helper loaded: my_helper
INFO - 2020-01-26 13:55:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:55:30 --> Controller Class Initialized
INFO - 2020-01-26 13:55:39 --> Config Class Initialized
INFO - 2020-01-26 13:55:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:55:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:55:39 --> Utf8 Class Initialized
INFO - 2020-01-26 13:55:39 --> URI Class Initialized
INFO - 2020-01-26 13:55:39 --> Router Class Initialized
INFO - 2020-01-26 13:55:39 --> Output Class Initialized
INFO - 2020-01-26 13:55:39 --> Security Class Initialized
DEBUG - 2020-01-26 13:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:55:39 --> Input Class Initialized
INFO - 2020-01-26 13:55:39 --> Language Class Initialized
INFO - 2020-01-26 13:55:40 --> Language Class Initialized
INFO - 2020-01-26 13:55:40 --> Config Class Initialized
INFO - 2020-01-26 13:55:40 --> Loader Class Initialized
INFO - 2020-01-26 13:55:40 --> Helper loaded: url_helper
INFO - 2020-01-26 13:55:40 --> Helper loaded: file_helper
INFO - 2020-01-26 13:55:40 --> Helper loaded: form_helper
INFO - 2020-01-26 13:55:40 --> Helper loaded: my_helper
INFO - 2020-01-26 13:55:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:55:40 --> Controller Class Initialized
DEBUG - 2020-01-26 13:55:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 13:55:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:55:40 --> Final output sent to browser
DEBUG - 2020-01-26 13:55:40 --> Total execution time: 1.3079
INFO - 2020-01-26 13:55:51 --> Config Class Initialized
INFO - 2020-01-26 13:55:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:55:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:55:51 --> Utf8 Class Initialized
INFO - 2020-01-26 13:55:51 --> URI Class Initialized
INFO - 2020-01-26 13:55:51 --> Router Class Initialized
INFO - 2020-01-26 13:55:51 --> Output Class Initialized
INFO - 2020-01-26 13:55:51 --> Security Class Initialized
DEBUG - 2020-01-26 13:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:55:52 --> Input Class Initialized
INFO - 2020-01-26 13:55:52 --> Language Class Initialized
INFO - 2020-01-26 13:55:52 --> Language Class Initialized
INFO - 2020-01-26 13:55:52 --> Config Class Initialized
INFO - 2020-01-26 13:55:52 --> Loader Class Initialized
INFO - 2020-01-26 13:55:52 --> Helper loaded: url_helper
INFO - 2020-01-26 13:55:52 --> Helper loaded: file_helper
INFO - 2020-01-26 13:55:52 --> Helper loaded: form_helper
INFO - 2020-01-26 13:55:52 --> Helper loaded: my_helper
INFO - 2020-01-26 13:55:52 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:55:52 --> Controller Class Initialized
DEBUG - 2020-01-26 13:55:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 13:55:52 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:55:52 --> Final output sent to browser
DEBUG - 2020-01-26 13:55:53 --> Total execution time: 1.3081
INFO - 2020-01-26 13:55:53 --> Config Class Initialized
INFO - 2020-01-26 13:55:53 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:55:53 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:55:53 --> Utf8 Class Initialized
INFO - 2020-01-26 13:55:53 --> URI Class Initialized
INFO - 2020-01-26 13:55:53 --> Router Class Initialized
INFO - 2020-01-26 13:55:53 --> Output Class Initialized
INFO - 2020-01-26 13:55:53 --> Security Class Initialized
DEBUG - 2020-01-26 13:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:55:53 --> Input Class Initialized
INFO - 2020-01-26 13:55:53 --> Language Class Initialized
INFO - 2020-01-26 13:55:53 --> Language Class Initialized
INFO - 2020-01-26 13:55:53 --> Config Class Initialized
INFO - 2020-01-26 13:55:53 --> Loader Class Initialized
INFO - 2020-01-26 13:55:53 --> Helper loaded: url_helper
INFO - 2020-01-26 13:55:54 --> Helper loaded: file_helper
INFO - 2020-01-26 13:55:54 --> Helper loaded: form_helper
INFO - 2020-01-26 13:55:54 --> Helper loaded: my_helper
INFO - 2020-01-26 13:55:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:55:54 --> Controller Class Initialized
INFO - 2020-01-26 13:56:09 --> Config Class Initialized
INFO - 2020-01-26 13:56:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:09 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:09 --> URI Class Initialized
INFO - 2020-01-26 13:56:09 --> Router Class Initialized
INFO - 2020-01-26 13:56:09 --> Output Class Initialized
INFO - 2020-01-26 13:56:10 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:10 --> Input Class Initialized
INFO - 2020-01-26 13:56:10 --> Language Class Initialized
INFO - 2020-01-26 13:56:10 --> Language Class Initialized
INFO - 2020-01-26 13:56:10 --> Config Class Initialized
INFO - 2020-01-26 13:56:10 --> Loader Class Initialized
INFO - 2020-01-26 13:56:10 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:10 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:10 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:10 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:10 --> Controller Class Initialized
INFO - 2020-01-26 13:56:10 --> Final output sent to browser
DEBUG - 2020-01-26 13:56:11 --> Total execution time: 1.3842
INFO - 2020-01-26 13:56:20 --> Config Class Initialized
INFO - 2020-01-26 13:56:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:20 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:20 --> URI Class Initialized
INFO - 2020-01-26 13:56:20 --> Router Class Initialized
INFO - 2020-01-26 13:56:20 --> Output Class Initialized
INFO - 2020-01-26 13:56:20 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:20 --> Input Class Initialized
INFO - 2020-01-26 13:56:20 --> Language Class Initialized
INFO - 2020-01-26 13:56:20 --> Language Class Initialized
INFO - 2020-01-26 13:56:20 --> Config Class Initialized
INFO - 2020-01-26 13:56:20 --> Loader Class Initialized
INFO - 2020-01-26 13:56:20 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:20 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:21 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:21 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:21 --> Config Class Initialized
INFO - 2020-01-26 13:56:21 --> Hooks Class Initialized
INFO - 2020-01-26 13:56:21 --> Controller Class Initialized
DEBUG - 2020-01-26 13:56:21 --> UTF-8 Support Enabled
DEBUG - 2020-01-26 13:56:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
INFO - 2020-01-26 13:56:21 --> Utf8 Class Initialized
DEBUG - 2020-01-26 13:56:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:56:21 --> Final output sent to browser
INFO - 2020-01-26 13:56:21 --> URI Class Initialized
DEBUG - 2020-01-26 13:56:21 --> Total execution time: 1.3285
INFO - 2020-01-26 13:56:21 --> Router Class Initialized
INFO - 2020-01-26 13:56:21 --> Output Class Initialized
INFO - 2020-01-26 13:56:21 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:21 --> Input Class Initialized
INFO - 2020-01-26 13:56:21 --> Language Class Initialized
INFO - 2020-01-26 13:56:21 --> Language Class Initialized
INFO - 2020-01-26 13:56:21 --> Config Class Initialized
INFO - 2020-01-26 13:56:21 --> Loader Class Initialized
INFO - 2020-01-26 13:56:22 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:22 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:22 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:22 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:22 --> Controller Class Initialized
DEBUG - 2020-01-26 13:56:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 13:56:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:56:22 --> Final output sent to browser
DEBUG - 2020-01-26 13:56:22 --> Total execution time: 1.2920
INFO - 2020-01-26 13:56:22 --> Config Class Initialized
INFO - 2020-01-26 13:56:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:23 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:23 --> URI Class Initialized
INFO - 2020-01-26 13:56:23 --> Router Class Initialized
INFO - 2020-01-26 13:56:23 --> Output Class Initialized
INFO - 2020-01-26 13:56:23 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:23 --> Input Class Initialized
INFO - 2020-01-26 13:56:23 --> Language Class Initialized
INFO - 2020-01-26 13:56:23 --> Language Class Initialized
INFO - 2020-01-26 13:56:23 --> Config Class Initialized
INFO - 2020-01-26 13:56:23 --> Loader Class Initialized
INFO - 2020-01-26 13:56:23 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:23 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:23 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:23 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:23 --> Controller Class Initialized
INFO - 2020-01-26 13:56:28 --> Config Class Initialized
INFO - 2020-01-26 13:56:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:28 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:28 --> URI Class Initialized
INFO - 2020-01-26 13:56:28 --> Router Class Initialized
INFO - 2020-01-26 13:56:28 --> Output Class Initialized
INFO - 2020-01-26 13:56:28 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:28 --> Input Class Initialized
INFO - 2020-01-26 13:56:28 --> Language Class Initialized
INFO - 2020-01-26 13:56:28 --> Language Class Initialized
INFO - 2020-01-26 13:56:28 --> Config Class Initialized
INFO - 2020-01-26 13:56:28 --> Loader Class Initialized
INFO - 2020-01-26 13:56:28 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:28 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:28 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:29 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:29 --> Controller Class Initialized
ERROR - 2020-01-26 13:56:29 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-01-26 13:56:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/form.php
DEBUG - 2020-01-26 13:56:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:56:29 --> Final output sent to browser
DEBUG - 2020-01-26 13:56:29 --> Total execution time: 1.4802
INFO - 2020-01-26 13:56:36 --> Config Class Initialized
INFO - 2020-01-26 13:56:36 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:36 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:36 --> URI Class Initialized
INFO - 2020-01-26 13:56:37 --> Router Class Initialized
INFO - 2020-01-26 13:56:37 --> Output Class Initialized
INFO - 2020-01-26 13:56:37 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:37 --> Input Class Initialized
INFO - 2020-01-26 13:56:37 --> Language Class Initialized
INFO - 2020-01-26 13:56:37 --> Language Class Initialized
INFO - 2020-01-26 13:56:37 --> Config Class Initialized
INFO - 2020-01-26 13:56:37 --> Loader Class Initialized
INFO - 2020-01-26 13:56:37 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:37 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:37 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:37 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:37 --> Controller Class Initialized
DEBUG - 2020-01-26 13:56:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 13:56:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:56:38 --> Final output sent to browser
DEBUG - 2020-01-26 13:56:38 --> Total execution time: 1.3760
INFO - 2020-01-26 13:56:38 --> Config Class Initialized
INFO - 2020-01-26 13:56:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:56:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:56:38 --> Utf8 Class Initialized
INFO - 2020-01-26 13:56:38 --> URI Class Initialized
INFO - 2020-01-26 13:56:38 --> Router Class Initialized
INFO - 2020-01-26 13:56:38 --> Output Class Initialized
INFO - 2020-01-26 13:56:38 --> Security Class Initialized
DEBUG - 2020-01-26 13:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:56:38 --> Input Class Initialized
INFO - 2020-01-26 13:56:38 --> Language Class Initialized
INFO - 2020-01-26 13:56:39 --> Language Class Initialized
INFO - 2020-01-26 13:56:39 --> Config Class Initialized
INFO - 2020-01-26 13:56:39 --> Loader Class Initialized
INFO - 2020-01-26 13:56:39 --> Helper loaded: url_helper
INFO - 2020-01-26 13:56:39 --> Helper loaded: file_helper
INFO - 2020-01-26 13:56:39 --> Helper loaded: form_helper
INFO - 2020-01-26 13:56:39 --> Helper loaded: my_helper
INFO - 2020-01-26 13:56:39 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:56:39 --> Controller Class Initialized
INFO - 2020-01-26 13:57:01 --> Config Class Initialized
INFO - 2020-01-26 13:57:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:01 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:01 --> URI Class Initialized
INFO - 2020-01-26 13:57:01 --> Router Class Initialized
INFO - 2020-01-26 13:57:01 --> Output Class Initialized
INFO - 2020-01-26 13:57:02 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:02 --> Input Class Initialized
INFO - 2020-01-26 13:57:02 --> Language Class Initialized
INFO - 2020-01-26 13:57:02 --> Language Class Initialized
INFO - 2020-01-26 13:57:02 --> Config Class Initialized
INFO - 2020-01-26 13:57:02 --> Loader Class Initialized
INFO - 2020-01-26 13:57:02 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:02 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:02 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:02 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:02 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:02 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2020-01-26 13:57:03 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:05 --> Config Class Initialized
INFO - 2020-01-26 13:57:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:05 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:06 --> URI Class Initialized
INFO - 2020-01-26 13:57:06 --> Router Class Initialized
INFO - 2020-01-26 13:57:06 --> Output Class Initialized
INFO - 2020-01-26 13:57:06 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:06 --> Input Class Initialized
INFO - 2020-01-26 13:57:06 --> Language Class Initialized
INFO - 2020-01-26 13:57:06 --> Language Class Initialized
INFO - 2020-01-26 13:57:06 --> Config Class Initialized
INFO - 2020-01-26 13:57:06 --> Loader Class Initialized
INFO - 2020-01-26 13:57:06 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:06 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:06 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:06 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:07 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:07 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2020-01-26 13:57:07 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:08 --> Config Class Initialized
INFO - 2020-01-26 13:57:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:09 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:09 --> URI Class Initialized
INFO - 2020-01-26 13:57:09 --> Router Class Initialized
INFO - 2020-01-26 13:57:09 --> Output Class Initialized
INFO - 2020-01-26 13:57:09 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:09 --> Input Class Initialized
INFO - 2020-01-26 13:57:09 --> Language Class Initialized
INFO - 2020-01-26 13:57:09 --> Language Class Initialized
INFO - 2020-01-26 13:57:09 --> Config Class Initialized
INFO - 2020-01-26 13:57:09 --> Loader Class Initialized
INFO - 2020-01-26 13:57:09 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:09 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:09 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:09 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:10 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:10 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '1'
INFO - 2020-01-26 13:57:10 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:16 --> Config Class Initialized
INFO - 2020-01-26 13:57:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:16 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:16 --> URI Class Initialized
INFO - 2020-01-26 13:57:16 --> Router Class Initialized
INFO - 2020-01-26 13:57:16 --> Output Class Initialized
INFO - 2020-01-26 13:57:16 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:16 --> Input Class Initialized
INFO - 2020-01-26 13:57:16 --> Language Class Initialized
INFO - 2020-01-26 13:57:16 --> Language Class Initialized
INFO - 2020-01-26 13:57:16 --> Config Class Initialized
INFO - 2020-01-26 13:57:16 --> Loader Class Initialized
INFO - 2020-01-26 13:57:16 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:16 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:17 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:17 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:17 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:17 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:17 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-01-26 13:57:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:18 --> Config Class Initialized
INFO - 2020-01-26 13:57:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:18 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:18 --> URI Class Initialized
INFO - 2020-01-26 13:57:18 --> Router Class Initialized
INFO - 2020-01-26 13:57:19 --> Output Class Initialized
INFO - 2020-01-26 13:57:19 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:19 --> Input Class Initialized
INFO - 2020-01-26 13:57:19 --> Language Class Initialized
INFO - 2020-01-26 13:57:19 --> Language Class Initialized
INFO - 2020-01-26 13:57:19 --> Config Class Initialized
INFO - 2020-01-26 13:57:19 --> Loader Class Initialized
INFO - 2020-01-26 13:57:19 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:19 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:19 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:19 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:19 --> Controller Class Initialized
DEBUG - 2020-01-26 13:57:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 13:57:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 13:57:20 --> Final output sent to browser
DEBUG - 2020-01-26 13:57:20 --> Total execution time: 1.4696
INFO - 2020-01-26 13:57:20 --> Config Class Initialized
INFO - 2020-01-26 13:57:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:20 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:20 --> URI Class Initialized
INFO - 2020-01-26 13:57:20 --> Router Class Initialized
INFO - 2020-01-26 13:57:20 --> Output Class Initialized
INFO - 2020-01-26 13:57:20 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:20 --> Input Class Initialized
INFO - 2020-01-26 13:57:20 --> Language Class Initialized
INFO - 2020-01-26 13:57:21 --> Language Class Initialized
INFO - 2020-01-26 13:57:21 --> Config Class Initialized
INFO - 2020-01-26 13:57:21 --> Loader Class Initialized
INFO - 2020-01-26 13:57:21 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:21 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:21 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:21 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:21 --> Controller Class Initialized
INFO - 2020-01-26 13:57:24 --> Config Class Initialized
INFO - 2020-01-26 13:57:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:24 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:24 --> URI Class Initialized
INFO - 2020-01-26 13:57:24 --> Router Class Initialized
INFO - 2020-01-26 13:57:24 --> Output Class Initialized
INFO - 2020-01-26 13:57:25 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:25 --> Input Class Initialized
INFO - 2020-01-26 13:57:25 --> Language Class Initialized
INFO - 2020-01-26 13:57:25 --> Language Class Initialized
INFO - 2020-01-26 13:57:25 --> Config Class Initialized
INFO - 2020-01-26 13:57:25 --> Loader Class Initialized
INFO - 2020-01-26 13:57:25 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:25 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:25 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:25 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:25 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:25 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-01-26 13:57:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:29 --> Config Class Initialized
INFO - 2020-01-26 13:57:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:30 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:30 --> URI Class Initialized
INFO - 2020-01-26 13:57:30 --> Router Class Initialized
INFO - 2020-01-26 13:57:30 --> Output Class Initialized
INFO - 2020-01-26 13:57:30 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:30 --> Input Class Initialized
INFO - 2020-01-26 13:57:30 --> Language Class Initialized
INFO - 2020-01-26 13:57:30 --> Language Class Initialized
INFO - 2020-01-26 13:57:30 --> Config Class Initialized
INFO - 2020-01-26 13:57:30 --> Loader Class Initialized
INFO - 2020-01-26 13:57:30 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:30 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:30 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:30 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:31 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:31 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-01-26 13:57:31 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 13:57:37 --> Config Class Initialized
INFO - 2020-01-26 13:57:37 --> Hooks Class Initialized
DEBUG - 2020-01-26 13:57:37 --> UTF-8 Support Enabled
INFO - 2020-01-26 13:57:37 --> Utf8 Class Initialized
INFO - 2020-01-26 13:57:37 --> URI Class Initialized
INFO - 2020-01-26 13:57:37 --> Router Class Initialized
INFO - 2020-01-26 13:57:37 --> Output Class Initialized
INFO - 2020-01-26 13:57:37 --> Security Class Initialized
DEBUG - 2020-01-26 13:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 13:57:37 --> Input Class Initialized
INFO - 2020-01-26 13:57:38 --> Language Class Initialized
INFO - 2020-01-26 13:57:38 --> Language Class Initialized
INFO - 2020-01-26 13:57:38 --> Config Class Initialized
INFO - 2020-01-26 13:57:38 --> Loader Class Initialized
INFO - 2020-01-26 13:57:38 --> Helper loaded: url_helper
INFO - 2020-01-26 13:57:38 --> Helper loaded: file_helper
INFO - 2020-01-26 13:57:38 --> Helper loaded: form_helper
INFO - 2020-01-26 13:57:38 --> Helper loaded: my_helper
INFO - 2020-01-26 13:57:38 --> Database Driver Class Initialized
DEBUG - 2020-01-26 13:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 13:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 13:57:38 --> Controller Class Initialized
ERROR - 2020-01-26 13:57:38 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilaik13`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-01-26 13:57:38 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-26 14:02:18 --> Config Class Initialized
INFO - 2020-01-26 14:02:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:18 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:18 --> URI Class Initialized
INFO - 2020-01-26 14:02:18 --> Router Class Initialized
INFO - 2020-01-26 14:02:18 --> Output Class Initialized
INFO - 2020-01-26 14:02:18 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:18 --> Input Class Initialized
INFO - 2020-01-26 14:02:18 --> Language Class Initialized
INFO - 2020-01-26 14:02:18 --> Language Class Initialized
INFO - 2020-01-26 14:02:18 --> Config Class Initialized
INFO - 2020-01-26 14:02:18 --> Loader Class Initialized
INFO - 2020-01-26 14:02:18 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:19 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:19 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:19 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:19 --> Controller Class Initialized
INFO - 2020-01-26 14:02:19 --> Final output sent to browser
DEBUG - 2020-01-26 14:02:19 --> Total execution time: 1.2908
INFO - 2020-01-26 14:02:24 --> Config Class Initialized
INFO - 2020-01-26 14:02:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:24 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:24 --> URI Class Initialized
INFO - 2020-01-26 14:02:24 --> Router Class Initialized
INFO - 2020-01-26 14:02:24 --> Output Class Initialized
INFO - 2020-01-26 14:02:24 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:24 --> Input Class Initialized
INFO - 2020-01-26 14:02:24 --> Language Class Initialized
INFO - 2020-01-26 14:02:24 --> Language Class Initialized
INFO - 2020-01-26 14:02:25 --> Config Class Initialized
INFO - 2020-01-26 14:02:25 --> Loader Class Initialized
INFO - 2020-01-26 14:02:25 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:25 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:25 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:25 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:25 --> Controller Class Initialized
INFO - 2020-01-26 14:02:25 --> Final output sent to browser
DEBUG - 2020-01-26 14:02:25 --> Total execution time: 1.2682
INFO - 2020-01-26 14:02:25 --> Config Class Initialized
INFO - 2020-01-26 14:02:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:25 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:26 --> URI Class Initialized
INFO - 2020-01-26 14:02:26 --> Router Class Initialized
INFO - 2020-01-26 14:02:26 --> Output Class Initialized
INFO - 2020-01-26 14:02:26 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:26 --> Input Class Initialized
INFO - 2020-01-26 14:02:26 --> Language Class Initialized
INFO - 2020-01-26 14:02:26 --> Language Class Initialized
INFO - 2020-01-26 14:02:26 --> Config Class Initialized
INFO - 2020-01-26 14:02:26 --> Loader Class Initialized
INFO - 2020-01-26 14:02:26 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:26 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:26 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:26 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:26 --> Controller Class Initialized
INFO - 2020-01-26 14:02:32 --> Config Class Initialized
INFO - 2020-01-26 14:02:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:32 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:32 --> URI Class Initialized
INFO - 2020-01-26 14:02:32 --> Router Class Initialized
INFO - 2020-01-26 14:02:32 --> Output Class Initialized
INFO - 2020-01-26 14:02:32 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:32 --> Input Class Initialized
INFO - 2020-01-26 14:02:32 --> Language Class Initialized
INFO - 2020-01-26 14:02:32 --> Language Class Initialized
INFO - 2020-01-26 14:02:32 --> Config Class Initialized
INFO - 2020-01-26 14:02:33 --> Loader Class Initialized
INFO - 2020-01-26 14:02:33 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:33 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:33 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:33 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:33 --> Controller Class Initialized
INFO - 2020-01-26 14:02:33 --> Final output sent to browser
DEBUG - 2020-01-26 14:02:33 --> Total execution time: 1.3077
INFO - 2020-01-26 14:02:39 --> Config Class Initialized
INFO - 2020-01-26 14:02:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:39 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:39 --> URI Class Initialized
INFO - 2020-01-26 14:02:39 --> Router Class Initialized
INFO - 2020-01-26 14:02:40 --> Output Class Initialized
INFO - 2020-01-26 14:02:40 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:40 --> Input Class Initialized
INFO - 2020-01-26 14:02:40 --> Language Class Initialized
INFO - 2020-01-26 14:02:40 --> Language Class Initialized
INFO - 2020-01-26 14:02:40 --> Config Class Initialized
INFO - 2020-01-26 14:02:40 --> Loader Class Initialized
INFO - 2020-01-26 14:02:40 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:40 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:40 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:40 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:40 --> Controller Class Initialized
INFO - 2020-01-26 14:02:40 --> Final output sent to browser
DEBUG - 2020-01-26 14:02:40 --> Total execution time: 1.2664
INFO - 2020-01-26 14:02:41 --> Config Class Initialized
INFO - 2020-01-26 14:02:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:41 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:41 --> URI Class Initialized
INFO - 2020-01-26 14:02:41 --> Router Class Initialized
INFO - 2020-01-26 14:02:41 --> Output Class Initialized
INFO - 2020-01-26 14:02:41 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:41 --> Input Class Initialized
INFO - 2020-01-26 14:02:41 --> Language Class Initialized
INFO - 2020-01-26 14:02:41 --> Language Class Initialized
INFO - 2020-01-26 14:02:41 --> Config Class Initialized
INFO - 2020-01-26 14:02:41 --> Loader Class Initialized
INFO - 2020-01-26 14:02:41 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:42 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:42 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:42 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:42 --> Controller Class Initialized
INFO - 2020-01-26 14:02:55 --> Config Class Initialized
INFO - 2020-01-26 14:02:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:02:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:02:55 --> Utf8 Class Initialized
INFO - 2020-01-26 14:02:55 --> URI Class Initialized
INFO - 2020-01-26 14:02:55 --> Router Class Initialized
INFO - 2020-01-26 14:02:55 --> Output Class Initialized
INFO - 2020-01-26 14:02:55 --> Security Class Initialized
DEBUG - 2020-01-26 14:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:02:55 --> Input Class Initialized
INFO - 2020-01-26 14:02:56 --> Language Class Initialized
INFO - 2020-01-26 14:02:56 --> Language Class Initialized
INFO - 2020-01-26 14:02:56 --> Config Class Initialized
INFO - 2020-01-26 14:02:56 --> Loader Class Initialized
INFO - 2020-01-26 14:02:56 --> Helper loaded: url_helper
INFO - 2020-01-26 14:02:56 --> Helper loaded: file_helper
INFO - 2020-01-26 14:02:56 --> Helper loaded: form_helper
INFO - 2020-01-26 14:02:56 --> Helper loaded: my_helper
INFO - 2020-01-26 14:02:56 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:02:56 --> Controller Class Initialized
INFO - 2020-01-26 14:02:56 --> Final output sent to browser
DEBUG - 2020-01-26 14:02:56 --> Total execution time: 1.3298
INFO - 2020-01-26 14:03:07 --> Config Class Initialized
INFO - 2020-01-26 14:03:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:07 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:07 --> URI Class Initialized
INFO - 2020-01-26 14:03:08 --> Router Class Initialized
INFO - 2020-01-26 14:03:08 --> Output Class Initialized
INFO - 2020-01-26 14:03:08 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:08 --> Input Class Initialized
INFO - 2020-01-26 14:03:08 --> Language Class Initialized
INFO - 2020-01-26 14:03:08 --> Language Class Initialized
INFO - 2020-01-26 14:03:08 --> Config Class Initialized
INFO - 2020-01-26 14:03:08 --> Loader Class Initialized
INFO - 2020-01-26 14:03:08 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:08 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:08 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:08 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:09 --> Controller Class Initialized
INFO - 2020-01-26 14:03:09 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:09 --> Total execution time: 1.4423
INFO - 2020-01-26 14:03:09 --> Config Class Initialized
INFO - 2020-01-26 14:03:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:09 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:09 --> URI Class Initialized
INFO - 2020-01-26 14:03:09 --> Router Class Initialized
INFO - 2020-01-26 14:03:09 --> Output Class Initialized
INFO - 2020-01-26 14:03:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:10 --> Input Class Initialized
INFO - 2020-01-26 14:03:10 --> Language Class Initialized
INFO - 2020-01-26 14:03:10 --> Language Class Initialized
INFO - 2020-01-26 14:03:10 --> Config Class Initialized
INFO - 2020-01-26 14:03:10 --> Loader Class Initialized
INFO - 2020-01-26 14:03:10 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:10 --> Controller Class Initialized
INFO - 2020-01-26 14:03:13 --> Config Class Initialized
INFO - 2020-01-26 14:03:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:14 --> URI Class Initialized
INFO - 2020-01-26 14:03:14 --> Router Class Initialized
INFO - 2020-01-26 14:03:14 --> Output Class Initialized
INFO - 2020-01-26 14:03:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:14 --> Input Class Initialized
INFO - 2020-01-26 14:03:14 --> Language Class Initialized
INFO - 2020-01-26 14:03:14 --> Language Class Initialized
INFO - 2020-01-26 14:03:14 --> Config Class Initialized
INFO - 2020-01-26 14:03:14 --> Loader Class Initialized
INFO - 2020-01-26 14:03:14 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:14 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:14 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:14 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:15 --> Controller Class Initialized
INFO - 2020-01-26 14:03:15 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:15 --> Total execution time: 1.3311
INFO - 2020-01-26 14:03:30 --> Config Class Initialized
INFO - 2020-01-26 14:03:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:30 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:31 --> URI Class Initialized
INFO - 2020-01-26 14:03:31 --> Router Class Initialized
INFO - 2020-01-26 14:03:31 --> Output Class Initialized
INFO - 2020-01-26 14:03:31 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:31 --> Input Class Initialized
INFO - 2020-01-26 14:03:31 --> Language Class Initialized
INFO - 2020-01-26 14:03:31 --> Language Class Initialized
INFO - 2020-01-26 14:03:31 --> Config Class Initialized
INFO - 2020-01-26 14:03:31 --> Loader Class Initialized
INFO - 2020-01-26 14:03:31 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:31 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:31 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:31 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:32 --> Controller Class Initialized
INFO - 2020-01-26 14:03:32 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:32 --> Total execution time: 1.3016
INFO - 2020-01-26 14:03:32 --> Config Class Initialized
INFO - 2020-01-26 14:03:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:32 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:32 --> URI Class Initialized
INFO - 2020-01-26 14:03:32 --> Router Class Initialized
INFO - 2020-01-26 14:03:32 --> Output Class Initialized
INFO - 2020-01-26 14:03:32 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:32 --> Input Class Initialized
INFO - 2020-01-26 14:03:32 --> Language Class Initialized
INFO - 2020-01-26 14:03:32 --> Language Class Initialized
INFO - 2020-01-26 14:03:33 --> Config Class Initialized
INFO - 2020-01-26 14:03:33 --> Loader Class Initialized
INFO - 2020-01-26 14:03:33 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:33 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:33 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:33 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:33 --> Controller Class Initialized
INFO - 2020-01-26 14:03:35 --> Config Class Initialized
INFO - 2020-01-26 14:03:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:35 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:35 --> URI Class Initialized
INFO - 2020-01-26 14:03:35 --> Router Class Initialized
INFO - 2020-01-26 14:03:36 --> Output Class Initialized
INFO - 2020-01-26 14:03:36 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:36 --> Input Class Initialized
INFO - 2020-01-26 14:03:36 --> Language Class Initialized
INFO - 2020-01-26 14:03:36 --> Language Class Initialized
INFO - 2020-01-26 14:03:36 --> Config Class Initialized
INFO - 2020-01-26 14:03:36 --> Loader Class Initialized
INFO - 2020-01-26 14:03:36 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:36 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:36 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:36 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:36 --> Controller Class Initialized
INFO - 2020-01-26 14:03:37 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:37 --> Total execution time: 1.3519
INFO - 2020-01-26 14:03:45 --> Config Class Initialized
INFO - 2020-01-26 14:03:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:45 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:45 --> URI Class Initialized
INFO - 2020-01-26 14:03:45 --> Router Class Initialized
INFO - 2020-01-26 14:03:45 --> Output Class Initialized
INFO - 2020-01-26 14:03:45 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:46 --> Input Class Initialized
INFO - 2020-01-26 14:03:46 --> Language Class Initialized
INFO - 2020-01-26 14:03:46 --> Language Class Initialized
INFO - 2020-01-26 14:03:46 --> Config Class Initialized
INFO - 2020-01-26 14:03:46 --> Loader Class Initialized
INFO - 2020-01-26 14:03:46 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:46 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:46 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:46 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:46 --> Controller Class Initialized
INFO - 2020-01-26 14:03:46 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:46 --> Total execution time: 1.3058
INFO - 2020-01-26 14:03:46 --> Config Class Initialized
INFO - 2020-01-26 14:03:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:47 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:47 --> URI Class Initialized
INFO - 2020-01-26 14:03:47 --> Router Class Initialized
INFO - 2020-01-26 14:03:47 --> Output Class Initialized
INFO - 2020-01-26 14:03:47 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:47 --> Input Class Initialized
INFO - 2020-01-26 14:03:47 --> Language Class Initialized
INFO - 2020-01-26 14:03:47 --> Language Class Initialized
INFO - 2020-01-26 14:03:47 --> Config Class Initialized
INFO - 2020-01-26 14:03:47 --> Loader Class Initialized
INFO - 2020-01-26 14:03:47 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:47 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:47 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:48 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:48 --> Controller Class Initialized
INFO - 2020-01-26 14:03:54 --> Config Class Initialized
INFO - 2020-01-26 14:03:54 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:03:54 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:03:54 --> Utf8 Class Initialized
INFO - 2020-01-26 14:03:54 --> URI Class Initialized
INFO - 2020-01-26 14:03:54 --> Router Class Initialized
INFO - 2020-01-26 14:03:54 --> Output Class Initialized
INFO - 2020-01-26 14:03:54 --> Security Class Initialized
DEBUG - 2020-01-26 14:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:03:55 --> Input Class Initialized
INFO - 2020-01-26 14:03:55 --> Language Class Initialized
INFO - 2020-01-26 14:03:55 --> Language Class Initialized
INFO - 2020-01-26 14:03:55 --> Config Class Initialized
INFO - 2020-01-26 14:03:55 --> Loader Class Initialized
INFO - 2020-01-26 14:03:55 --> Helper loaded: url_helper
INFO - 2020-01-26 14:03:55 --> Helper loaded: file_helper
INFO - 2020-01-26 14:03:55 --> Helper loaded: form_helper
INFO - 2020-01-26 14:03:55 --> Helper loaded: my_helper
INFO - 2020-01-26 14:03:55 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:03:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:03:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:03:55 --> Controller Class Initialized
INFO - 2020-01-26 14:03:55 --> Final output sent to browser
DEBUG - 2020-01-26 14:03:55 --> Total execution time: 1.3544
INFO - 2020-01-26 14:04:06 --> Config Class Initialized
INFO - 2020-01-26 14:04:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:04:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:04:06 --> Utf8 Class Initialized
INFO - 2020-01-26 14:04:06 --> URI Class Initialized
INFO - 2020-01-26 14:04:06 --> Router Class Initialized
INFO - 2020-01-26 14:04:06 --> Output Class Initialized
INFO - 2020-01-26 14:04:06 --> Security Class Initialized
DEBUG - 2020-01-26 14:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:04:06 --> Input Class Initialized
INFO - 2020-01-26 14:04:06 --> Language Class Initialized
INFO - 2020-01-26 14:04:07 --> Language Class Initialized
INFO - 2020-01-26 14:04:07 --> Config Class Initialized
INFO - 2020-01-26 14:04:07 --> Loader Class Initialized
INFO - 2020-01-26 14:04:07 --> Helper loaded: url_helper
INFO - 2020-01-26 14:04:07 --> Helper loaded: file_helper
INFO - 2020-01-26 14:04:07 --> Helper loaded: form_helper
INFO - 2020-01-26 14:04:07 --> Helper loaded: my_helper
INFO - 2020-01-26 14:04:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:04:07 --> Controller Class Initialized
INFO - 2020-01-26 14:04:07 --> Final output sent to browser
DEBUG - 2020-01-26 14:04:07 --> Total execution time: 1.5139
INFO - 2020-01-26 14:04:07 --> Config Class Initialized
INFO - 2020-01-26 14:04:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:04:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:04:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:04:08 --> URI Class Initialized
INFO - 2020-01-26 14:04:08 --> Router Class Initialized
INFO - 2020-01-26 14:04:08 --> Output Class Initialized
INFO - 2020-01-26 14:04:08 --> Security Class Initialized
DEBUG - 2020-01-26 14:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:04:08 --> Input Class Initialized
INFO - 2020-01-26 14:04:08 --> Language Class Initialized
INFO - 2020-01-26 14:04:08 --> Language Class Initialized
INFO - 2020-01-26 14:04:08 --> Config Class Initialized
INFO - 2020-01-26 14:04:08 --> Loader Class Initialized
INFO - 2020-01-26 14:04:08 --> Helper loaded: url_helper
INFO - 2020-01-26 14:04:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:04:09 --> Helper loaded: form_helper
INFO - 2020-01-26 14:04:09 --> Helper loaded: my_helper
INFO - 2020-01-26 14:04:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:04:09 --> Controller Class Initialized
INFO - 2020-01-26 14:06:06 --> Config Class Initialized
INFO - 2020-01-26 14:06:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:06:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:06:06 --> Utf8 Class Initialized
INFO - 2020-01-26 14:06:06 --> URI Class Initialized
INFO - 2020-01-26 14:06:06 --> Router Class Initialized
INFO - 2020-01-26 14:06:06 --> Output Class Initialized
INFO - 2020-01-26 14:06:07 --> Security Class Initialized
DEBUG - 2020-01-26 14:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:06:07 --> Input Class Initialized
INFO - 2020-01-26 14:06:07 --> Language Class Initialized
INFO - 2020-01-26 14:06:07 --> Language Class Initialized
INFO - 2020-01-26 14:06:07 --> Config Class Initialized
INFO - 2020-01-26 14:06:07 --> Loader Class Initialized
INFO - 2020-01-26 14:06:07 --> Helper loaded: url_helper
INFO - 2020-01-26 14:06:07 --> Helper loaded: file_helper
INFO - 2020-01-26 14:06:07 --> Helper loaded: form_helper
INFO - 2020-01-26 14:06:07 --> Helper loaded: my_helper
INFO - 2020-01-26 14:06:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:06:08 --> Controller Class Initialized
DEBUG - 2020-01-26 14:06:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 14:06:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:06:08 --> Final output sent to browser
DEBUG - 2020-01-26 14:06:08 --> Total execution time: 1.7202
INFO - 2020-01-26 14:06:08 --> Config Class Initialized
INFO - 2020-01-26 14:06:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:06:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:06:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:06:08 --> URI Class Initialized
INFO - 2020-01-26 14:06:08 --> Router Class Initialized
INFO - 2020-01-26 14:06:09 --> Output Class Initialized
INFO - 2020-01-26 14:06:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:06:09 --> Input Class Initialized
INFO - 2020-01-26 14:06:09 --> Language Class Initialized
INFO - 2020-01-26 14:06:09 --> Language Class Initialized
INFO - 2020-01-26 14:06:09 --> Config Class Initialized
INFO - 2020-01-26 14:06:09 --> Loader Class Initialized
INFO - 2020-01-26 14:06:09 --> Helper loaded: url_helper
INFO - 2020-01-26 14:06:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:06:09 --> Helper loaded: form_helper
INFO - 2020-01-26 14:06:09 --> Helper loaded: my_helper
INFO - 2020-01-26 14:06:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:06:10 --> Controller Class Initialized
INFO - 2020-01-26 14:06:58 --> Config Class Initialized
INFO - 2020-01-26 14:06:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:06:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:06:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:06:58 --> URI Class Initialized
INFO - 2020-01-26 14:06:58 --> Router Class Initialized
INFO - 2020-01-26 14:06:58 --> Output Class Initialized
INFO - 2020-01-26 14:06:58 --> Security Class Initialized
DEBUG - 2020-01-26 14:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:06:58 --> Input Class Initialized
INFO - 2020-01-26 14:06:58 --> Language Class Initialized
INFO - 2020-01-26 14:06:58 --> Language Class Initialized
INFO - 2020-01-26 14:06:59 --> Config Class Initialized
INFO - 2020-01-26 14:06:59 --> Loader Class Initialized
INFO - 2020-01-26 14:06:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:06:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:06:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:06:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:06:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:06:59 --> Controller Class Initialized
DEBUG - 2020-01-26 14:06:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_walikelas/views/list.php
DEBUG - 2020-01-26 14:06:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:06:59 --> Final output sent to browser
DEBUG - 2020-01-26 14:06:59 --> Total execution time: 1.6144
INFO - 2020-01-26 14:07:00 --> Config Class Initialized
INFO - 2020-01-26 14:07:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:00 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:00 --> URI Class Initialized
INFO - 2020-01-26 14:07:00 --> Router Class Initialized
INFO - 2020-01-26 14:07:00 --> Output Class Initialized
INFO - 2020-01-26 14:07:00 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:01 --> Input Class Initialized
INFO - 2020-01-26 14:07:01 --> Language Class Initialized
INFO - 2020-01-26 14:07:01 --> Language Class Initialized
INFO - 2020-01-26 14:07:01 --> Config Class Initialized
INFO - 2020-01-26 14:07:01 --> Loader Class Initialized
INFO - 2020-01-26 14:07:01 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:01 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:01 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:01 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:01 --> Controller Class Initialized
INFO - 2020-01-26 14:07:02 --> Config Class Initialized
INFO - 2020-01-26 14:07:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:02 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:02 --> URI Class Initialized
INFO - 2020-01-26 14:07:02 --> Router Class Initialized
INFO - 2020-01-26 14:07:03 --> Output Class Initialized
INFO - 2020-01-26 14:07:03 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:03 --> Input Class Initialized
INFO - 2020-01-26 14:07:03 --> Language Class Initialized
INFO - 2020-01-26 14:07:03 --> Language Class Initialized
INFO - 2020-01-26 14:07:03 --> Config Class Initialized
INFO - 2020-01-26 14:07:03 --> Loader Class Initialized
INFO - 2020-01-26 14:07:03 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:03 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:03 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:03 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:04 --> Controller Class Initialized
DEBUG - 2020-01-26 14:07:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-26 14:07:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:07:04 --> Final output sent to browser
DEBUG - 2020-01-26 14:07:04 --> Total execution time: 1.9275
INFO - 2020-01-26 14:07:04 --> Config Class Initialized
INFO - 2020-01-26 14:07:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:04 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:04 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:05 --> URI Class Initialized
INFO - 2020-01-26 14:07:05 --> Router Class Initialized
INFO - 2020-01-26 14:07:05 --> Output Class Initialized
INFO - 2020-01-26 14:07:05 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:05 --> Input Class Initialized
INFO - 2020-01-26 14:07:05 --> Language Class Initialized
INFO - 2020-01-26 14:07:05 --> Language Class Initialized
INFO - 2020-01-26 14:07:05 --> Config Class Initialized
INFO - 2020-01-26 14:07:05 --> Loader Class Initialized
INFO - 2020-01-26 14:07:05 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:05 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:05 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:05 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:06 --> Controller Class Initialized
INFO - 2020-01-26 14:07:06 --> Config Class Initialized
INFO - 2020-01-26 14:07:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:07 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:07 --> URI Class Initialized
INFO - 2020-01-26 14:07:07 --> Router Class Initialized
INFO - 2020-01-26 14:07:07 --> Output Class Initialized
INFO - 2020-01-26 14:07:07 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:07 --> Input Class Initialized
INFO - 2020-01-26 14:07:07 --> Language Class Initialized
INFO - 2020-01-26 14:07:07 --> Language Class Initialized
INFO - 2020-01-26 14:07:07 --> Config Class Initialized
INFO - 2020-01-26 14:07:08 --> Loader Class Initialized
INFO - 2020-01-26 14:07:08 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:08 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:08 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:08 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:08 --> Controller Class Initialized
DEBUG - 2020-01-26 14:07:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 14:07:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:07:08 --> Final output sent to browser
DEBUG - 2020-01-26 14:07:08 --> Total execution time: 1.8779
INFO - 2020-01-26 14:07:09 --> Config Class Initialized
INFO - 2020-01-26 14:07:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:09 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:09 --> URI Class Initialized
INFO - 2020-01-26 14:07:09 --> Router Class Initialized
INFO - 2020-01-26 14:07:09 --> Output Class Initialized
INFO - 2020-01-26 14:07:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:09 --> Input Class Initialized
INFO - 2020-01-26 14:07:09 --> Language Class Initialized
INFO - 2020-01-26 14:07:09 --> Language Class Initialized
INFO - 2020-01-26 14:07:10 --> Config Class Initialized
INFO - 2020-01-26 14:07:10 --> Loader Class Initialized
INFO - 2020-01-26 14:07:10 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:10 --> Controller Class Initialized
INFO - 2020-01-26 14:07:14 --> Config Class Initialized
INFO - 2020-01-26 14:07:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:14 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:14 --> URI Class Initialized
INFO - 2020-01-26 14:07:14 --> Router Class Initialized
INFO - 2020-01-26 14:07:14 --> Output Class Initialized
INFO - 2020-01-26 14:07:15 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:15 --> Input Class Initialized
INFO - 2020-01-26 14:07:15 --> Language Class Initialized
INFO - 2020-01-26 14:07:15 --> Language Class Initialized
INFO - 2020-01-26 14:07:15 --> Config Class Initialized
INFO - 2020-01-26 14:07:15 --> Loader Class Initialized
INFO - 2020-01-26 14:07:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:15 --> Controller Class Initialized
INFO - 2020-01-26 14:07:16 --> Final output sent to browser
DEBUG - 2020-01-26 14:07:16 --> Total execution time: 1.5489
INFO - 2020-01-26 14:07:16 --> Config Class Initialized
INFO - 2020-01-26 14:07:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:07:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:07:16 --> Utf8 Class Initialized
INFO - 2020-01-26 14:07:16 --> URI Class Initialized
INFO - 2020-01-26 14:07:16 --> Router Class Initialized
INFO - 2020-01-26 14:07:16 --> Output Class Initialized
INFO - 2020-01-26 14:07:16 --> Security Class Initialized
DEBUG - 2020-01-26 14:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:07:16 --> Input Class Initialized
INFO - 2020-01-26 14:07:16 --> Language Class Initialized
INFO - 2020-01-26 14:07:16 --> Language Class Initialized
INFO - 2020-01-26 14:07:16 --> Config Class Initialized
INFO - 2020-01-26 14:07:17 --> Loader Class Initialized
INFO - 2020-01-26 14:07:17 --> Helper loaded: url_helper
INFO - 2020-01-26 14:07:17 --> Helper loaded: file_helper
INFO - 2020-01-26 14:07:17 --> Helper loaded: form_helper
INFO - 2020-01-26 14:07:17 --> Helper loaded: my_helper
INFO - 2020-01-26 14:07:17 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:07:17 --> Controller Class Initialized
INFO - 2020-01-26 14:13:58 --> Config Class Initialized
INFO - 2020-01-26 14:13:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:13:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:13:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:13:58 --> URI Class Initialized
INFO - 2020-01-26 14:13:59 --> Router Class Initialized
INFO - 2020-01-26 14:13:59 --> Output Class Initialized
INFO - 2020-01-26 14:13:59 --> Security Class Initialized
DEBUG - 2020-01-26 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:13:59 --> Input Class Initialized
INFO - 2020-01-26 14:13:59 --> Language Class Initialized
INFO - 2020-01-26 14:13:59 --> Language Class Initialized
INFO - 2020-01-26 14:13:59 --> Config Class Initialized
INFO - 2020-01-26 14:13:59 --> Loader Class Initialized
INFO - 2020-01-26 14:13:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:13:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:13:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:13:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:13:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:00 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 14:14:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:00 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:00 --> Total execution time: 1.7241
INFO - 2020-01-26 14:14:00 --> Config Class Initialized
INFO - 2020-01-26 14:14:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:01 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:01 --> URI Class Initialized
INFO - 2020-01-26 14:14:01 --> Router Class Initialized
INFO - 2020-01-26 14:14:01 --> Output Class Initialized
INFO - 2020-01-26 14:14:01 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:01 --> Input Class Initialized
INFO - 2020-01-26 14:14:01 --> Config Class Initialized
INFO - 2020-01-26 14:14:01 --> Hooks Class Initialized
INFO - 2020-01-26 14:14:01 --> Language Class Initialized
DEBUG - 2020-01-26 14:14:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:01 --> Language Class Initialized
INFO - 2020-01-26 14:14:01 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:01 --> Config Class Initialized
INFO - 2020-01-26 14:14:01 --> Loader Class Initialized
INFO - 2020-01-26 14:14:01 --> URI Class Initialized
INFO - 2020-01-26 14:14:02 --> Helper loaded: url_helper
DEBUG - 2020-01-26 14:14:02 --> No URI present. Default controller set.
INFO - 2020-01-26 14:14:02 --> Router Class Initialized
INFO - 2020-01-26 14:14:02 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:02 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:02 --> Output Class Initialized
INFO - 2020-01-26 14:14:02 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:02 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:02 --> Database Driver Class Initialized
INFO - 2020-01-26 14:14:02 --> Input Class Initialized
DEBUG - 2020-01-26 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:02 --> Language Class Initialized
INFO - 2020-01-26 14:14:02 --> Controller Class Initialized
INFO - 2020-01-26 14:14:02 --> Language Class Initialized
INFO - 2020-01-26 14:14:02 --> Config Class Initialized
INFO - 2020-01-26 14:14:02 --> Loader Class Initialized
INFO - 2020-01-26 14:14:02 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:02 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:02 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:03 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:03 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 14:14:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:03 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:03 --> Total execution time: 1.9308
INFO - 2020-01-26 14:14:05 --> Config Class Initialized
INFO - 2020-01-26 14:14:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:05 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:05 --> URI Class Initialized
INFO - 2020-01-26 14:14:05 --> Router Class Initialized
INFO - 2020-01-26 14:14:05 --> Output Class Initialized
INFO - 2020-01-26 14:14:05 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:05 --> Input Class Initialized
INFO - 2020-01-26 14:14:05 --> Language Class Initialized
INFO - 2020-01-26 14:14:06 --> Language Class Initialized
INFO - 2020-01-26 14:14:06 --> Config Class Initialized
INFO - 2020-01-26 14:14:06 --> Loader Class Initialized
INFO - 2020-01-26 14:14:06 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:06 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:06 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:06 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:06 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 14:14:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:07 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:07 --> Total execution time: 1.9374
INFO - 2020-01-26 14:14:07 --> Config Class Initialized
INFO - 2020-01-26 14:14:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:07 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:07 --> URI Class Initialized
INFO - 2020-01-26 14:14:07 --> Router Class Initialized
INFO - 2020-01-26 14:14:07 --> Config Class Initialized
INFO - 2020-01-26 14:14:07 --> Hooks Class Initialized
INFO - 2020-01-26 14:14:08 --> Output Class Initialized
INFO - 2020-01-26 14:14:08 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:08 --> Utf8 Class Initialized
DEBUG - 2020-01-26 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:08 --> Input Class Initialized
INFO - 2020-01-26 14:14:08 --> URI Class Initialized
INFO - 2020-01-26 14:14:08 --> Language Class Initialized
INFO - 2020-01-26 14:14:08 --> Router Class Initialized
INFO - 2020-01-26 14:14:08 --> Output Class Initialized
INFO - 2020-01-26 14:14:08 --> Language Class Initialized
INFO - 2020-01-26 14:14:08 --> Config Class Initialized
INFO - 2020-01-26 14:14:08 --> Security Class Initialized
INFO - 2020-01-26 14:14:08 --> Loader Class Initialized
DEBUG - 2020-01-26 14:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:08 --> Input Class Initialized
INFO - 2020-01-26 14:14:08 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:08 --> Language Class Initialized
INFO - 2020-01-26 14:14:08 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:08 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:08 --> Language Class Initialized
INFO - 2020-01-26 14:14:08 --> Config Class Initialized
INFO - 2020-01-26 14:14:08 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:08 --> Loader Class Initialized
INFO - 2020-01-26 14:14:08 --> Database Driver Class Initialized
INFO - 2020-01-26 14:14:08 --> Helper loaded: url_helper
DEBUG - 2020-01-26 14:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:09 --> Controller Class Initialized
INFO - 2020-01-26 14:14:09 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:09 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:09 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 14:14:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:09 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:09 --> Total execution time: 1.8174
INFO - 2020-01-26 14:14:10 --> Config Class Initialized
INFO - 2020-01-26 14:14:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:10 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:10 --> URI Class Initialized
INFO - 2020-01-26 14:14:10 --> Router Class Initialized
INFO - 2020-01-26 14:14:10 --> Output Class Initialized
INFO - 2020-01-26 14:14:10 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:10 --> Input Class Initialized
INFO - 2020-01-26 14:14:10 --> Language Class Initialized
INFO - 2020-01-26 14:14:10 --> Language Class Initialized
INFO - 2020-01-26 14:14:11 --> Config Class Initialized
INFO - 2020-01-26 14:14:11 --> Config Class Initialized
INFO - 2020-01-26 14:14:11 --> Hooks Class Initialized
INFO - 2020-01-26 14:14:11 --> Loader Class Initialized
INFO - 2020-01-26 14:14:11 --> Helper loaded: url_helper
DEBUG - 2020-01-26 14:14:11 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:11 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:11 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:11 --> URI Class Initialized
INFO - 2020-01-26 14:14:11 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:11 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:11 --> Router Class Initialized
INFO - 2020-01-26 14:14:11 --> Output Class Initialized
INFO - 2020-01-26 14:14:11 --> Database Driver Class Initialized
INFO - 2020-01-26 14:14:11 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-26 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:11 --> Input Class Initialized
INFO - 2020-01-26 14:14:11 --> Controller Class Initialized
INFO - 2020-01-26 14:14:11 --> Language Class Initialized
INFO - 2020-01-26 14:14:11 --> Language Class Initialized
INFO - 2020-01-26 14:14:12 --> Config Class Initialized
INFO - 2020-01-26 14:14:12 --> Loader Class Initialized
INFO - 2020-01-26 14:14:12 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:12 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:12 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:12 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:12 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 14:14:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:13 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:13 --> Total execution time: 1.9250
INFO - 2020-01-26 14:14:13 --> Config Class Initialized
INFO - 2020-01-26 14:14:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:13 --> URI Class Initialized
INFO - 2020-01-26 14:14:13 --> Router Class Initialized
INFO - 2020-01-26 14:14:13 --> Output Class Initialized
INFO - 2020-01-26 14:14:13 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:13 --> Input Class Initialized
INFO - 2020-01-26 14:14:14 --> Language Class Initialized
INFO - 2020-01-26 14:14:14 --> Language Class Initialized
INFO - 2020-01-26 14:14:14 --> Config Class Initialized
INFO - 2020-01-26 14:14:14 --> Loader Class Initialized
INFO - 2020-01-26 14:14:14 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:14 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:14 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:14 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:14 --> Controller Class Initialized
INFO - 2020-01-26 14:14:20 --> Config Class Initialized
INFO - 2020-01-26 14:14:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:20 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:20 --> URI Class Initialized
INFO - 2020-01-26 14:14:20 --> Router Class Initialized
INFO - 2020-01-26 14:14:20 --> Output Class Initialized
INFO - 2020-01-26 14:14:20 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:20 --> Input Class Initialized
INFO - 2020-01-26 14:14:20 --> Language Class Initialized
INFO - 2020-01-26 14:14:20 --> Language Class Initialized
INFO - 2020-01-26 14:14:21 --> Config Class Initialized
INFO - 2020-01-26 14:14:21 --> Loader Class Initialized
INFO - 2020-01-26 14:14:21 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:21 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:21 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:21 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:21 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_mapel/views/list.php
DEBUG - 2020-01-26 14:14:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:21 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:21 --> Total execution time: 1.6290
INFO - 2020-01-26 14:14:22 --> Config Class Initialized
INFO - 2020-01-26 14:14:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:22 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:22 --> URI Class Initialized
INFO - 2020-01-26 14:14:22 --> Router Class Initialized
INFO - 2020-01-26 14:14:22 --> Output Class Initialized
INFO - 2020-01-26 14:14:22 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:22 --> Input Class Initialized
INFO - 2020-01-26 14:14:22 --> Language Class Initialized
INFO - 2020-01-26 14:14:22 --> Language Class Initialized
INFO - 2020-01-26 14:14:22 --> Config Class Initialized
INFO - 2020-01-26 14:14:23 --> Loader Class Initialized
INFO - 2020-01-26 14:14:23 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:23 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:23 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:23 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:23 --> Controller Class Initialized
INFO - 2020-01-26 14:14:26 --> Config Class Initialized
INFO - 2020-01-26 14:14:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:26 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:26 --> URI Class Initialized
INFO - 2020-01-26 14:14:26 --> Router Class Initialized
INFO - 2020-01-26 14:14:26 --> Output Class Initialized
INFO - 2020-01-26 14:14:26 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:27 --> Input Class Initialized
INFO - 2020-01-26 14:14:27 --> Language Class Initialized
INFO - 2020-01-26 14:14:27 --> Language Class Initialized
INFO - 2020-01-26 14:14:27 --> Config Class Initialized
INFO - 2020-01-26 14:14:27 --> Loader Class Initialized
INFO - 2020-01-26 14:14:27 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:27 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:27 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:27 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:27 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:27 --> Controller Class Initialized
INFO - 2020-01-26 14:14:27 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:27 --> Total execution time: 1.4996
INFO - 2020-01-26 14:14:36 --> Config Class Initialized
INFO - 2020-01-26 14:14:36 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:36 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:36 --> URI Class Initialized
INFO - 2020-01-26 14:14:36 --> Router Class Initialized
INFO - 2020-01-26 14:14:36 --> Output Class Initialized
INFO - 2020-01-26 14:14:36 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:36 --> Input Class Initialized
INFO - 2020-01-26 14:14:36 --> Language Class Initialized
INFO - 2020-01-26 14:14:36 --> Language Class Initialized
INFO - 2020-01-26 14:14:36 --> Config Class Initialized
INFO - 2020-01-26 14:14:36 --> Loader Class Initialized
INFO - 2020-01-26 14:14:36 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:37 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:37 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:37 --> Controller Class Initialized
INFO - 2020-01-26 14:14:40 --> Config Class Initialized
INFO - 2020-01-26 14:14:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:40 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:40 --> URI Class Initialized
INFO - 2020-01-26 14:14:40 --> Router Class Initialized
INFO - 2020-01-26 14:14:40 --> Output Class Initialized
INFO - 2020-01-26 14:14:40 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:40 --> Input Class Initialized
INFO - 2020-01-26 14:14:40 --> Language Class Initialized
INFO - 2020-01-26 14:14:40 --> Language Class Initialized
INFO - 2020-01-26 14:14:41 --> Config Class Initialized
INFO - 2020-01-26 14:14:41 --> Loader Class Initialized
INFO - 2020-01-26 14:14:41 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:41 --> Controller Class Initialized
INFO - 2020-01-26 14:14:41 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:41 --> Total execution time: 1.5236
INFO - 2020-01-26 14:14:56 --> Config Class Initialized
INFO - 2020-01-26 14:14:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:56 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:56 --> URI Class Initialized
INFO - 2020-01-26 14:14:56 --> Router Class Initialized
INFO - 2020-01-26 14:14:56 --> Output Class Initialized
INFO - 2020-01-26 14:14:56 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:56 --> Input Class Initialized
INFO - 2020-01-26 14:14:56 --> Language Class Initialized
INFO - 2020-01-26 14:14:57 --> Language Class Initialized
INFO - 2020-01-26 14:14:57 --> Config Class Initialized
INFO - 2020-01-26 14:14:57 --> Loader Class Initialized
INFO - 2020-01-26 14:14:57 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:57 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:57 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:57 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:57 --> Controller Class Initialized
DEBUG - 2020-01-26 14:14:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 14:14:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:14:57 --> Final output sent to browser
DEBUG - 2020-01-26 14:14:58 --> Total execution time: 1.6467
INFO - 2020-01-26 14:14:58 --> Config Class Initialized
INFO - 2020-01-26 14:14:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:14:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:14:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:14:58 --> URI Class Initialized
INFO - 2020-01-26 14:14:58 --> Router Class Initialized
INFO - 2020-01-26 14:14:58 --> Output Class Initialized
INFO - 2020-01-26 14:14:58 --> Security Class Initialized
DEBUG - 2020-01-26 14:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:14:58 --> Input Class Initialized
INFO - 2020-01-26 14:14:58 --> Language Class Initialized
INFO - 2020-01-26 14:14:58 --> Language Class Initialized
INFO - 2020-01-26 14:14:59 --> Config Class Initialized
INFO - 2020-01-26 14:14:59 --> Loader Class Initialized
INFO - 2020-01-26 14:14:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:14:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:14:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:14:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:14:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:14:59 --> Controller Class Initialized
INFO - 2020-01-26 14:15:01 --> Config Class Initialized
INFO - 2020-01-26 14:15:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:15:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:15:02 --> Utf8 Class Initialized
INFO - 2020-01-26 14:15:02 --> URI Class Initialized
INFO - 2020-01-26 14:15:02 --> Router Class Initialized
INFO - 2020-01-26 14:15:02 --> Output Class Initialized
INFO - 2020-01-26 14:15:02 --> Security Class Initialized
DEBUG - 2020-01-26 14:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:15:02 --> Input Class Initialized
INFO - 2020-01-26 14:15:02 --> Language Class Initialized
INFO - 2020-01-26 14:15:02 --> Language Class Initialized
INFO - 2020-01-26 14:15:02 --> Config Class Initialized
INFO - 2020-01-26 14:15:02 --> Loader Class Initialized
INFO - 2020-01-26 14:15:03 --> Helper loaded: url_helper
INFO - 2020-01-26 14:15:03 --> Helper loaded: file_helper
INFO - 2020-01-26 14:15:03 --> Helper loaded: form_helper
INFO - 2020-01-26 14:15:03 --> Helper loaded: my_helper
INFO - 2020-01-26 14:15:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:15:03 --> Controller Class Initialized
DEBUG - 2020-01-26 14:15:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 14:15:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:15:03 --> Final output sent to browser
DEBUG - 2020-01-26 14:15:03 --> Total execution time: 2.0171
INFO - 2020-01-26 14:15:04 --> Config Class Initialized
INFO - 2020-01-26 14:15:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:15:04 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:15:04 --> Utf8 Class Initialized
INFO - 2020-01-26 14:15:04 --> URI Class Initialized
INFO - 2020-01-26 14:15:04 --> Router Class Initialized
INFO - 2020-01-26 14:15:04 --> Output Class Initialized
INFO - 2020-01-26 14:15:04 --> Security Class Initialized
DEBUG - 2020-01-26 14:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:15:04 --> Input Class Initialized
INFO - 2020-01-26 14:15:04 --> Language Class Initialized
INFO - 2020-01-26 14:15:05 --> Language Class Initialized
INFO - 2020-01-26 14:15:05 --> Config Class Initialized
INFO - 2020-01-26 14:15:05 --> Loader Class Initialized
INFO - 2020-01-26 14:15:05 --> Helper loaded: url_helper
INFO - 2020-01-26 14:15:05 --> Helper loaded: file_helper
INFO - 2020-01-26 14:15:05 --> Helper loaded: form_helper
INFO - 2020-01-26 14:15:05 --> Helper loaded: my_helper
INFO - 2020-01-26 14:15:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:15:05 --> Controller Class Initialized
INFO - 2020-01-26 14:15:09 --> Config Class Initialized
INFO - 2020-01-26 14:15:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:15:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:15:09 --> Utf8 Class Initialized
INFO - 2020-01-26 14:15:09 --> URI Class Initialized
INFO - 2020-01-26 14:15:10 --> Router Class Initialized
INFO - 2020-01-26 14:15:10 --> Output Class Initialized
INFO - 2020-01-26 14:15:10 --> Security Class Initialized
DEBUG - 2020-01-26 14:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:15:10 --> Input Class Initialized
INFO - 2020-01-26 14:15:10 --> Language Class Initialized
INFO - 2020-01-26 14:15:10 --> Language Class Initialized
INFO - 2020-01-26 14:15:10 --> Config Class Initialized
INFO - 2020-01-26 14:15:10 --> Loader Class Initialized
INFO - 2020-01-26 14:15:10 --> Helper loaded: url_helper
INFO - 2020-01-26 14:15:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:15:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:15:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:15:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:15:11 --> Controller Class Initialized
INFO - 2020-01-26 14:15:13 --> Config Class Initialized
INFO - 2020-01-26 14:15:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:15:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:15:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:15:13 --> URI Class Initialized
INFO - 2020-01-26 14:15:13 --> Router Class Initialized
INFO - 2020-01-26 14:15:13 --> Output Class Initialized
INFO - 2020-01-26 14:15:13 --> Security Class Initialized
DEBUG - 2020-01-26 14:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:15:13 --> Input Class Initialized
INFO - 2020-01-26 14:15:13 --> Language Class Initialized
INFO - 2020-01-26 14:15:13 --> Language Class Initialized
INFO - 2020-01-26 14:15:13 --> Config Class Initialized
INFO - 2020-01-26 14:15:14 --> Loader Class Initialized
INFO - 2020-01-26 14:15:14 --> Helper loaded: url_helper
INFO - 2020-01-26 14:15:14 --> Helper loaded: file_helper
INFO - 2020-01-26 14:15:14 --> Helper loaded: form_helper
INFO - 2020-01-26 14:15:14 --> Helper loaded: my_helper
INFO - 2020-01-26 14:15:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:15:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:15:14 --> Controller Class Initialized
INFO - 2020-01-26 14:16:21 --> Config Class Initialized
INFO - 2020-01-26 14:16:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:21 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:21 --> URI Class Initialized
INFO - 2020-01-26 14:16:21 --> Router Class Initialized
INFO - 2020-01-26 14:16:21 --> Output Class Initialized
INFO - 2020-01-26 14:16:21 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:21 --> Input Class Initialized
INFO - 2020-01-26 14:16:21 --> Language Class Initialized
INFO - 2020-01-26 14:16:22 --> Language Class Initialized
INFO - 2020-01-26 14:16:22 --> Config Class Initialized
INFO - 2020-01-26 14:16:22 --> Loader Class Initialized
INFO - 2020-01-26 14:16:22 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:22 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:22 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:22 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:22 --> Controller Class Initialized
INFO - 2020-01-26 14:16:24 --> Config Class Initialized
INFO - 2020-01-26 14:16:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:24 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:24 --> URI Class Initialized
INFO - 2020-01-26 14:16:24 --> Router Class Initialized
INFO - 2020-01-26 14:16:24 --> Output Class Initialized
INFO - 2020-01-26 14:16:24 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:25 --> Input Class Initialized
INFO - 2020-01-26 14:16:25 --> Language Class Initialized
INFO - 2020-01-26 14:16:25 --> Language Class Initialized
INFO - 2020-01-26 14:16:25 --> Config Class Initialized
INFO - 2020-01-26 14:16:25 --> Loader Class Initialized
INFO - 2020-01-26 14:16:25 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:25 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:25 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:25 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:25 --> Controller Class Initialized
INFO - 2020-01-26 14:16:28 --> Config Class Initialized
INFO - 2020-01-26 14:16:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:28 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:28 --> URI Class Initialized
INFO - 2020-01-26 14:16:28 --> Router Class Initialized
INFO - 2020-01-26 14:16:28 --> Output Class Initialized
INFO - 2020-01-26 14:16:28 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:28 --> Input Class Initialized
INFO - 2020-01-26 14:16:28 --> Language Class Initialized
INFO - 2020-01-26 14:16:28 --> Language Class Initialized
INFO - 2020-01-26 14:16:29 --> Config Class Initialized
INFO - 2020-01-26 14:16:29 --> Loader Class Initialized
INFO - 2020-01-26 14:16:29 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:29 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:29 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:29 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:29 --> Controller Class Initialized
INFO - 2020-01-26 14:16:31 --> Config Class Initialized
INFO - 2020-01-26 14:16:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:31 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:32 --> URI Class Initialized
INFO - 2020-01-26 14:16:32 --> Router Class Initialized
INFO - 2020-01-26 14:16:32 --> Output Class Initialized
INFO - 2020-01-26 14:16:32 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:32 --> Input Class Initialized
INFO - 2020-01-26 14:16:32 --> Language Class Initialized
INFO - 2020-01-26 14:16:32 --> Language Class Initialized
INFO - 2020-01-26 14:16:32 --> Config Class Initialized
INFO - 2020-01-26 14:16:32 --> Loader Class Initialized
INFO - 2020-01-26 14:16:32 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:32 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:32 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:32 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:33 --> Controller Class Initialized
INFO - 2020-01-26 14:16:35 --> Config Class Initialized
INFO - 2020-01-26 14:16:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:35 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:35 --> URI Class Initialized
INFO - 2020-01-26 14:16:35 --> Router Class Initialized
INFO - 2020-01-26 14:16:35 --> Output Class Initialized
INFO - 2020-01-26 14:16:35 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:35 --> Input Class Initialized
INFO - 2020-01-26 14:16:36 --> Language Class Initialized
INFO - 2020-01-26 14:16:36 --> Config Class Initialized
INFO - 2020-01-26 14:16:36 --> Hooks Class Initialized
INFO - 2020-01-26 14:16:36 --> Language Class Initialized
INFO - 2020-01-26 14:16:36 --> Config Class Initialized
DEBUG - 2020-01-26 14:16:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:36 --> Loader Class Initialized
INFO - 2020-01-26 14:16:36 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:36 --> URI Class Initialized
INFO - 2020-01-26 14:16:36 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:36 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:36 --> Router Class Initialized
INFO - 2020-01-26 14:16:36 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:36 --> Output Class Initialized
INFO - 2020-01-26 14:16:36 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:36 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:36 --> Database Driver Class Initialized
INFO - 2020-01-26 14:16:36 --> Input Class Initialized
DEBUG - 2020-01-26 14:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:36 --> Language Class Initialized
INFO - 2020-01-26 14:16:36 --> Config Class Initialized
INFO - 2020-01-26 14:16:36 --> Hooks Class Initialized
INFO - 2020-01-26 14:16:36 --> Controller Class Initialized
INFO - 2020-01-26 14:16:36 --> Language Class Initialized
INFO - 2020-01-26 14:16:36 --> Config Class Initialized
DEBUG - 2020-01-26 14:16:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:36 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:36 --> Loader Class Initialized
INFO - 2020-01-26 14:16:37 --> URI Class Initialized
INFO - 2020-01-26 14:16:37 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:37 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:37 --> Router Class Initialized
INFO - 2020-01-26 14:16:37 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:37 --> Output Class Initialized
INFO - 2020-01-26 14:16:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:37 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:37 --> Database Driver Class Initialized
INFO - 2020-01-26 14:16:37 --> Input Class Initialized
DEBUG - 2020-01-26 14:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:37 --> Language Class Initialized
INFO - 2020-01-26 14:16:37 --> Controller Class Initialized
INFO - 2020-01-26 14:16:37 --> Language Class Initialized
INFO - 2020-01-26 14:16:37 --> Config Class Initialized
INFO - 2020-01-26 14:16:37 --> Loader Class Initialized
INFO - 2020-01-26 14:16:37 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:37 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:37 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:38 --> Controller Class Initialized
INFO - 2020-01-26 14:16:39 --> Config Class Initialized
INFO - 2020-01-26 14:16:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:16:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:40 --> Utf8 Class Initialized
INFO - 2020-01-26 14:16:40 --> URI Class Initialized
INFO - 2020-01-26 14:16:40 --> Router Class Initialized
INFO - 2020-01-26 14:16:40 --> Config Class Initialized
INFO - 2020-01-26 14:16:40 --> Hooks Class Initialized
INFO - 2020-01-26 14:16:40 --> Output Class Initialized
INFO - 2020-01-26 14:16:40 --> Security Class Initialized
DEBUG - 2020-01-26 14:16:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:16:40 --> Utf8 Class Initialized
DEBUG - 2020-01-26 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:40 --> Input Class Initialized
INFO - 2020-01-26 14:16:40 --> URI Class Initialized
INFO - 2020-01-26 14:16:40 --> Language Class Initialized
INFO - 2020-01-26 14:16:40 --> Router Class Initialized
INFO - 2020-01-26 14:16:40 --> Output Class Initialized
INFO - 2020-01-26 14:16:40 --> Language Class Initialized
INFO - 2020-01-26 14:16:40 --> Config Class Initialized
INFO - 2020-01-26 14:16:40 --> Security Class Initialized
INFO - 2020-01-26 14:16:40 --> Loader Class Initialized
DEBUG - 2020-01-26 14:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:16:40 --> Input Class Initialized
INFO - 2020-01-26 14:16:40 --> Helper loaded: url_helper
INFO - 2020-01-26 14:16:41 --> Language Class Initialized
INFO - 2020-01-26 14:16:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:41 --> Language Class Initialized
INFO - 2020-01-26 14:16:41 --> Config Class Initialized
INFO - 2020-01-26 14:16:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:41 --> Loader Class Initialized
INFO - 2020-01-26 14:16:41 --> Database Driver Class Initialized
INFO - 2020-01-26 14:16:41 --> Helper loaded: url_helper
DEBUG - 2020-01-26 14:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:16:41 --> Controller Class Initialized
INFO - 2020-01-26 14:16:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:16:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:16:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:16:41 --> Controller Class Initialized
INFO - 2020-01-26 14:17:12 --> Config Class Initialized
INFO - 2020-01-26 14:17:12 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:13 --> URI Class Initialized
INFO - 2020-01-26 14:17:13 --> Router Class Initialized
INFO - 2020-01-26 14:17:13 --> Output Class Initialized
INFO - 2020-01-26 14:17:13 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:13 --> Input Class Initialized
INFO - 2020-01-26 14:17:13 --> Language Class Initialized
INFO - 2020-01-26 14:17:13 --> Language Class Initialized
INFO - 2020-01-26 14:17:13 --> Config Class Initialized
INFO - 2020-01-26 14:17:13 --> Loader Class Initialized
INFO - 2020-01-26 14:17:13 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:13 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:13 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:14 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:14 --> Controller Class Initialized
DEBUG - 2020-01-26 14:17:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 14:17:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:17:14 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:14 --> Total execution time: 1.8238
INFO - 2020-01-26 14:17:14 --> Config Class Initialized
INFO - 2020-01-26 14:17:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:15 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:15 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:15 --> URI Class Initialized
INFO - 2020-01-26 14:17:15 --> Router Class Initialized
INFO - 2020-01-26 14:17:15 --> Output Class Initialized
INFO - 2020-01-26 14:17:15 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:15 --> Input Class Initialized
INFO - 2020-01-26 14:17:15 --> Language Class Initialized
INFO - 2020-01-26 14:17:15 --> Language Class Initialized
INFO - 2020-01-26 14:17:15 --> Config Class Initialized
INFO - 2020-01-26 14:17:15 --> Loader Class Initialized
INFO - 2020-01-26 14:17:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:16 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:16 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:16 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:16 --> Controller Class Initialized
INFO - 2020-01-26 14:17:31 --> Config Class Initialized
INFO - 2020-01-26 14:17:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:31 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:31 --> URI Class Initialized
INFO - 2020-01-26 14:17:31 --> Router Class Initialized
INFO - 2020-01-26 14:17:31 --> Output Class Initialized
INFO - 2020-01-26 14:17:31 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:31 --> Input Class Initialized
INFO - 2020-01-26 14:17:31 --> Language Class Initialized
INFO - 2020-01-26 14:17:32 --> Language Class Initialized
INFO - 2020-01-26 14:17:32 --> Config Class Initialized
INFO - 2020-01-26 14:17:32 --> Loader Class Initialized
INFO - 2020-01-26 14:17:32 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:32 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:32 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:32 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:32 --> Controller Class Initialized
DEBUG - 2020-01-26 14:17:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_ekstra/views/list.php
DEBUG - 2020-01-26 14:17:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:17:33 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:33 --> Total execution time: 1.8592
INFO - 2020-01-26 14:17:33 --> Config Class Initialized
INFO - 2020-01-26 14:17:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:33 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:33 --> URI Class Initialized
INFO - 2020-01-26 14:17:33 --> Router Class Initialized
INFO - 2020-01-26 14:17:33 --> Output Class Initialized
INFO - 2020-01-26 14:17:33 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:34 --> Input Class Initialized
INFO - 2020-01-26 14:17:34 --> Language Class Initialized
INFO - 2020-01-26 14:17:34 --> Config Class Initialized
INFO - 2020-01-26 14:17:34 --> Language Class Initialized
INFO - 2020-01-26 14:17:34 --> Hooks Class Initialized
INFO - 2020-01-26 14:17:34 --> Config Class Initialized
INFO - 2020-01-26 14:17:34 --> Loader Class Initialized
DEBUG - 2020-01-26 14:17:34 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:34 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:34 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:34 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:34 --> URI Class Initialized
INFO - 2020-01-26 14:17:34 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:34 --> Router Class Initialized
INFO - 2020-01-26 14:17:34 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:34 --> Output Class Initialized
INFO - 2020-01-26 14:17:34 --> Security Class Initialized
INFO - 2020-01-26 14:17:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2020-01-26 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:34 --> Input Class Initialized
INFO - 2020-01-26 14:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:34 --> Controller Class Initialized
INFO - 2020-01-26 14:17:34 --> Language Class Initialized
INFO - 2020-01-26 14:17:34 --> Language Class Initialized
INFO - 2020-01-26 14:17:35 --> Config Class Initialized
INFO - 2020-01-26 14:17:35 --> Loader Class Initialized
INFO - 2020-01-26 14:17:35 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:35 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:35 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:35 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:35 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:35 --> Controller Class Initialized
INFO - 2020-01-26 14:17:35 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:35 --> Total execution time: 1.6128
INFO - 2020-01-26 14:17:38 --> Config Class Initialized
INFO - 2020-01-26 14:17:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:39 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:39 --> URI Class Initialized
INFO - 2020-01-26 14:17:39 --> Router Class Initialized
INFO - 2020-01-26 14:17:39 --> Output Class Initialized
INFO - 2020-01-26 14:17:39 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:39 --> Input Class Initialized
INFO - 2020-01-26 14:17:39 --> Language Class Initialized
INFO - 2020-01-26 14:17:39 --> Language Class Initialized
INFO - 2020-01-26 14:17:39 --> Config Class Initialized
INFO - 2020-01-26 14:17:39 --> Loader Class Initialized
INFO - 2020-01-26 14:17:39 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:39 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:39 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:40 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:40 --> Controller Class Initialized
INFO - 2020-01-26 14:17:40 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:40 --> Total execution time: 1.6182
INFO - 2020-01-26 14:17:40 --> Config Class Initialized
INFO - 2020-01-26 14:17:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:40 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:40 --> URI Class Initialized
INFO - 2020-01-26 14:17:40 --> Router Class Initialized
INFO - 2020-01-26 14:17:41 --> Output Class Initialized
INFO - 2020-01-26 14:17:41 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:41 --> Input Class Initialized
INFO - 2020-01-26 14:17:41 --> Language Class Initialized
INFO - 2020-01-26 14:17:41 --> Language Class Initialized
INFO - 2020-01-26 14:17:41 --> Config Class Initialized
INFO - 2020-01-26 14:17:41 --> Loader Class Initialized
INFO - 2020-01-26 14:17:41 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:42 --> Controller Class Initialized
INFO - 2020-01-26 14:17:42 --> Config Class Initialized
INFO - 2020-01-26 14:17:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:43 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:43 --> URI Class Initialized
INFO - 2020-01-26 14:17:43 --> Router Class Initialized
INFO - 2020-01-26 14:17:43 --> Output Class Initialized
INFO - 2020-01-26 14:17:43 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:43 --> Input Class Initialized
INFO - 2020-01-26 14:17:43 --> Language Class Initialized
INFO - 2020-01-26 14:17:43 --> Language Class Initialized
INFO - 2020-01-26 14:17:43 --> Config Class Initialized
INFO - 2020-01-26 14:17:43 --> Loader Class Initialized
INFO - 2020-01-26 14:17:43 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:44 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:44 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:44 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:44 --> Controller Class Initialized
INFO - 2020-01-26 14:17:44 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:44 --> Total execution time: 1.6613
INFO - 2020-01-26 14:17:51 --> Config Class Initialized
INFO - 2020-01-26 14:17:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:51 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:51 --> URI Class Initialized
INFO - 2020-01-26 14:17:51 --> Router Class Initialized
INFO - 2020-01-26 14:17:52 --> Output Class Initialized
INFO - 2020-01-26 14:17:52 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:52 --> Input Class Initialized
INFO - 2020-01-26 14:17:52 --> Language Class Initialized
INFO - 2020-01-26 14:17:52 --> Language Class Initialized
INFO - 2020-01-26 14:17:52 --> Config Class Initialized
INFO - 2020-01-26 14:17:52 --> Loader Class Initialized
INFO - 2020-01-26 14:17:52 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:52 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:52 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:52 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:52 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:53 --> Controller Class Initialized
INFO - 2020-01-26 14:17:53 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:53 --> Total execution time: 1.5943
INFO - 2020-01-26 14:17:53 --> Config Class Initialized
INFO - 2020-01-26 14:17:53 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:53 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:53 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:53 --> URI Class Initialized
INFO - 2020-01-26 14:17:53 --> Router Class Initialized
INFO - 2020-01-26 14:17:53 --> Output Class Initialized
INFO - 2020-01-26 14:17:53 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:54 --> Input Class Initialized
INFO - 2020-01-26 14:17:54 --> Language Class Initialized
INFO - 2020-01-26 14:17:54 --> Language Class Initialized
INFO - 2020-01-26 14:17:54 --> Config Class Initialized
INFO - 2020-01-26 14:17:54 --> Loader Class Initialized
INFO - 2020-01-26 14:17:54 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:54 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:54 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:54 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:54 --> Controller Class Initialized
INFO - 2020-01-26 14:17:55 --> Config Class Initialized
INFO - 2020-01-26 14:17:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:17:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:17:56 --> Utf8 Class Initialized
INFO - 2020-01-26 14:17:56 --> URI Class Initialized
INFO - 2020-01-26 14:17:56 --> Router Class Initialized
INFO - 2020-01-26 14:17:56 --> Output Class Initialized
INFO - 2020-01-26 14:17:56 --> Security Class Initialized
DEBUG - 2020-01-26 14:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:17:56 --> Input Class Initialized
INFO - 2020-01-26 14:17:56 --> Language Class Initialized
INFO - 2020-01-26 14:17:56 --> Language Class Initialized
INFO - 2020-01-26 14:17:56 --> Config Class Initialized
INFO - 2020-01-26 14:17:56 --> Loader Class Initialized
INFO - 2020-01-26 14:17:57 --> Helper loaded: url_helper
INFO - 2020-01-26 14:17:57 --> Helper loaded: file_helper
INFO - 2020-01-26 14:17:57 --> Helper loaded: form_helper
INFO - 2020-01-26 14:17:57 --> Helper loaded: my_helper
INFO - 2020-01-26 14:17:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:17:57 --> Controller Class Initialized
INFO - 2020-01-26 14:17:57 --> Final output sent to browser
DEBUG - 2020-01-26 14:17:57 --> Total execution time: 1.7652
INFO - 2020-01-26 14:18:03 --> Config Class Initialized
INFO - 2020-01-26 14:18:03 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:03 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:03 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:03 --> URI Class Initialized
INFO - 2020-01-26 14:18:03 --> Router Class Initialized
INFO - 2020-01-26 14:18:03 --> Output Class Initialized
INFO - 2020-01-26 14:18:03 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:03 --> Input Class Initialized
INFO - 2020-01-26 14:18:03 --> Language Class Initialized
INFO - 2020-01-26 14:18:03 --> Language Class Initialized
INFO - 2020-01-26 14:18:04 --> Config Class Initialized
INFO - 2020-01-26 14:18:04 --> Loader Class Initialized
INFO - 2020-01-26 14:18:04 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:04 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:04 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:04 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:04 --> Controller Class Initialized
INFO - 2020-01-26 14:18:04 --> Final output sent to browser
DEBUG - 2020-01-26 14:18:04 --> Total execution time: 1.8247
INFO - 2020-01-26 14:18:05 --> Config Class Initialized
INFO - 2020-01-26 14:18:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:05 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:05 --> URI Class Initialized
INFO - 2020-01-26 14:18:05 --> Router Class Initialized
INFO - 2020-01-26 14:18:05 --> Output Class Initialized
INFO - 2020-01-26 14:18:05 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:05 --> Input Class Initialized
INFO - 2020-01-26 14:18:05 --> Language Class Initialized
INFO - 2020-01-26 14:18:05 --> Language Class Initialized
INFO - 2020-01-26 14:18:06 --> Config Class Initialized
INFO - 2020-01-26 14:18:06 --> Loader Class Initialized
INFO - 2020-01-26 14:18:06 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:06 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:06 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:06 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:06 --> Controller Class Initialized
INFO - 2020-01-26 14:18:11 --> Config Class Initialized
INFO - 2020-01-26 14:18:11 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:11 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:11 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:11 --> URI Class Initialized
INFO - 2020-01-26 14:18:11 --> Router Class Initialized
INFO - 2020-01-26 14:18:11 --> Output Class Initialized
INFO - 2020-01-26 14:18:11 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:12 --> Input Class Initialized
INFO - 2020-01-26 14:18:12 --> Language Class Initialized
INFO - 2020-01-26 14:18:12 --> Language Class Initialized
INFO - 2020-01-26 14:18:12 --> Config Class Initialized
INFO - 2020-01-26 14:18:12 --> Loader Class Initialized
INFO - 2020-01-26 14:18:12 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:12 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:12 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:12 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:13 --> Controller Class Initialized
DEBUG - 2020-01-26 14:18:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 14:18:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:18:13 --> Final output sent to browser
DEBUG - 2020-01-26 14:18:13 --> Total execution time: 2.2957
INFO - 2020-01-26 14:18:13 --> Config Class Initialized
INFO - 2020-01-26 14:18:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:14 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:14 --> URI Class Initialized
INFO - 2020-01-26 14:18:14 --> Router Class Initialized
INFO - 2020-01-26 14:18:14 --> Output Class Initialized
INFO - 2020-01-26 14:18:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:14 --> Input Class Initialized
INFO - 2020-01-26 14:18:14 --> Language Class Initialized
INFO - 2020-01-26 14:18:14 --> Language Class Initialized
INFO - 2020-01-26 14:18:14 --> Config Class Initialized
INFO - 2020-01-26 14:18:15 --> Loader Class Initialized
INFO - 2020-01-26 14:18:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:15 --> Controller Class Initialized
INFO - 2020-01-26 14:18:29 --> Config Class Initialized
INFO - 2020-01-26 14:18:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:29 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:29 --> URI Class Initialized
INFO - 2020-01-26 14:18:29 --> Router Class Initialized
INFO - 2020-01-26 14:18:29 --> Output Class Initialized
INFO - 2020-01-26 14:18:30 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:30 --> Input Class Initialized
INFO - 2020-01-26 14:18:30 --> Language Class Initialized
INFO - 2020-01-26 14:18:30 --> Language Class Initialized
INFO - 2020-01-26 14:18:30 --> Config Class Initialized
INFO - 2020-01-26 14:18:30 --> Loader Class Initialized
INFO - 2020-01-26 14:18:30 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:30 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:30 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:30 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:31 --> Controller Class Initialized
INFO - 2020-01-26 14:18:31 --> Final output sent to browser
DEBUG - 2020-01-26 14:18:31 --> Total execution time: 1.8409
INFO - 2020-01-26 14:18:36 --> Config Class Initialized
INFO - 2020-01-26 14:18:36 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:18:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:18:36 --> Utf8 Class Initialized
INFO - 2020-01-26 14:18:36 --> URI Class Initialized
INFO - 2020-01-26 14:18:36 --> Router Class Initialized
INFO - 2020-01-26 14:18:37 --> Output Class Initialized
INFO - 2020-01-26 14:18:37 --> Security Class Initialized
DEBUG - 2020-01-26 14:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:18:37 --> Input Class Initialized
INFO - 2020-01-26 14:18:37 --> Language Class Initialized
INFO - 2020-01-26 14:18:37 --> Language Class Initialized
INFO - 2020-01-26 14:18:37 --> Config Class Initialized
INFO - 2020-01-26 14:18:37 --> Loader Class Initialized
INFO - 2020-01-26 14:18:37 --> Helper loaded: url_helper
INFO - 2020-01-26 14:18:37 --> Helper loaded: file_helper
INFO - 2020-01-26 14:18:37 --> Helper loaded: form_helper
INFO - 2020-01-26 14:18:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:18:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:18:38 --> Controller Class Initialized
INFO - 2020-01-26 14:18:38 --> Final output sent to browser
DEBUG - 2020-01-26 14:18:38 --> Total execution time: 1.7943
INFO - 2020-01-26 14:20:14 --> Config Class Initialized
INFO - 2020-01-26 14:20:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:14 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:14 --> URI Class Initialized
INFO - 2020-01-26 14:20:14 --> Router Class Initialized
INFO - 2020-01-26 14:20:14 --> Output Class Initialized
INFO - 2020-01-26 14:20:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:14 --> Input Class Initialized
INFO - 2020-01-26 14:20:14 --> Language Class Initialized
INFO - 2020-01-26 14:20:14 --> Language Class Initialized
INFO - 2020-01-26 14:20:15 --> Config Class Initialized
INFO - 2020-01-26 14:20:15 --> Loader Class Initialized
INFO - 2020-01-26 14:20:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:20:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:20:15 --> Controller Class Initialized
INFO - 2020-01-26 14:20:15 --> Final output sent to browser
DEBUG - 2020-01-26 14:20:15 --> Total execution time: 1.6695
INFO - 2020-01-26 14:20:15 --> Config Class Initialized
INFO - 2020-01-26 14:20:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:16 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:16 --> URI Class Initialized
INFO - 2020-01-26 14:20:16 --> Router Class Initialized
INFO - 2020-01-26 14:20:16 --> Output Class Initialized
INFO - 2020-01-26 14:20:16 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:16 --> Input Class Initialized
INFO - 2020-01-26 14:20:16 --> Language Class Initialized
INFO - 2020-01-26 14:20:16 --> Language Class Initialized
INFO - 2020-01-26 14:20:16 --> Config Class Initialized
INFO - 2020-01-26 14:20:17 --> Loader Class Initialized
INFO - 2020-01-26 14:20:17 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:17 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:17 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:17 --> Helper loaded: my_helper
INFO - 2020-01-26 14:20:17 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:20:17 --> Controller Class Initialized
INFO - 2020-01-26 14:20:41 --> Config Class Initialized
INFO - 2020-01-26 14:20:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:42 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:42 --> URI Class Initialized
INFO - 2020-01-26 14:20:42 --> Router Class Initialized
INFO - 2020-01-26 14:20:42 --> Output Class Initialized
INFO - 2020-01-26 14:20:42 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:42 --> Input Class Initialized
INFO - 2020-01-26 14:20:42 --> Language Class Initialized
INFO - 2020-01-26 14:20:42 --> Language Class Initialized
INFO - 2020-01-26 14:20:42 --> Config Class Initialized
INFO - 2020-01-26 14:20:43 --> Loader Class Initialized
INFO - 2020-01-26 14:20:43 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:43 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:43 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:43 --> Helper loaded: my_helper
INFO - 2020-01-26 14:20:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:20:43 --> Controller Class Initialized
INFO - 2020-01-26 14:20:43 --> Final output sent to browser
DEBUG - 2020-01-26 14:20:43 --> Total execution time: 1.8280
INFO - 2020-01-26 14:20:44 --> Config Class Initialized
INFO - 2020-01-26 14:20:44 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:45 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:45 --> URI Class Initialized
INFO - 2020-01-26 14:20:45 --> Router Class Initialized
INFO - 2020-01-26 14:20:45 --> Output Class Initialized
INFO - 2020-01-26 14:20:45 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:45 --> Input Class Initialized
INFO - 2020-01-26 14:20:45 --> Language Class Initialized
INFO - 2020-01-26 14:20:45 --> Language Class Initialized
INFO - 2020-01-26 14:20:45 --> Config Class Initialized
INFO - 2020-01-26 14:20:46 --> Loader Class Initialized
INFO - 2020-01-26 14:20:46 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:46 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:46 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:46 --> Helper loaded: my_helper
INFO - 2020-01-26 14:20:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:20:46 --> Controller Class Initialized
INFO - 2020-01-26 14:20:47 --> Final output sent to browser
DEBUG - 2020-01-26 14:20:47 --> Total execution time: 2.1238
INFO - 2020-01-26 14:20:47 --> Config Class Initialized
INFO - 2020-01-26 14:20:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:47 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:47 --> URI Class Initialized
INFO - 2020-01-26 14:20:47 --> Router Class Initialized
INFO - 2020-01-26 14:20:48 --> Output Class Initialized
INFO - 2020-01-26 14:20:48 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:48 --> Input Class Initialized
INFO - 2020-01-26 14:20:48 --> Language Class Initialized
INFO - 2020-01-26 14:20:48 --> Language Class Initialized
INFO - 2020-01-26 14:20:48 --> Config Class Initialized
INFO - 2020-01-26 14:20:48 --> Loader Class Initialized
INFO - 2020-01-26 14:20:48 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:48 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:48 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:48 --> Helper loaded: my_helper
INFO - 2020-01-26 14:20:49 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:20:49 --> Controller Class Initialized
INFO - 2020-01-26 14:20:58 --> Config Class Initialized
INFO - 2020-01-26 14:20:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:20:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:20:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:20:58 --> URI Class Initialized
INFO - 2020-01-26 14:20:59 --> Router Class Initialized
INFO - 2020-01-26 14:20:59 --> Output Class Initialized
INFO - 2020-01-26 14:20:59 --> Security Class Initialized
DEBUG - 2020-01-26 14:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:20:59 --> Input Class Initialized
INFO - 2020-01-26 14:20:59 --> Language Class Initialized
INFO - 2020-01-26 14:20:59 --> Language Class Initialized
INFO - 2020-01-26 14:20:59 --> Config Class Initialized
INFO - 2020-01-26 14:20:59 --> Loader Class Initialized
INFO - 2020-01-26 14:20:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:20:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:20:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:20:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:00 --> Controller Class Initialized
INFO - 2020-01-26 14:21:00 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:00 --> Total execution time: 1.6775
INFO - 2020-01-26 14:21:00 --> Config Class Initialized
INFO - 2020-01-26 14:21:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:00 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:01 --> URI Class Initialized
INFO - 2020-01-26 14:21:01 --> Router Class Initialized
INFO - 2020-01-26 14:21:01 --> Output Class Initialized
INFO - 2020-01-26 14:21:01 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:01 --> Input Class Initialized
INFO - 2020-01-26 14:21:01 --> Language Class Initialized
INFO - 2020-01-26 14:21:01 --> Language Class Initialized
INFO - 2020-01-26 14:21:01 --> Config Class Initialized
INFO - 2020-01-26 14:21:01 --> Loader Class Initialized
INFO - 2020-01-26 14:21:01 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:02 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:02 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:02 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:02 --> Controller Class Initialized
INFO - 2020-01-26 14:21:09 --> Config Class Initialized
INFO - 2020-01-26 14:21:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:10 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:10 --> URI Class Initialized
INFO - 2020-01-26 14:21:10 --> Router Class Initialized
INFO - 2020-01-26 14:21:10 --> Output Class Initialized
INFO - 2020-01-26 14:21:10 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:10 --> Input Class Initialized
INFO - 2020-01-26 14:21:10 --> Language Class Initialized
INFO - 2020-01-26 14:21:10 --> Language Class Initialized
INFO - 2020-01-26 14:21:11 --> Config Class Initialized
INFO - 2020-01-26 14:21:11 --> Loader Class Initialized
INFO - 2020-01-26 14:21:11 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:11 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:11 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:11 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:11 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:21:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:12 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:12 --> Total execution time: 2.2279
INFO - 2020-01-26 14:21:13 --> Config Class Initialized
INFO - 2020-01-26 14:21:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:14 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:14 --> URI Class Initialized
INFO - 2020-01-26 14:21:14 --> Router Class Initialized
INFO - 2020-01-26 14:21:14 --> Output Class Initialized
INFO - 2020-01-26 14:21:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:14 --> Input Class Initialized
INFO - 2020-01-26 14:21:14 --> Language Class Initialized
INFO - 2020-01-26 14:21:14 --> Language Class Initialized
INFO - 2020-01-26 14:21:14 --> Config Class Initialized
INFO - 2020-01-26 14:21:15 --> Loader Class Initialized
INFO - 2020-01-26 14:21:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:15 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:21:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:16 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:16 --> Total execution time: 2.2793
INFO - 2020-01-26 14:21:23 --> Config Class Initialized
INFO - 2020-01-26 14:21:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:24 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:24 --> URI Class Initialized
INFO - 2020-01-26 14:21:24 --> Router Class Initialized
INFO - 2020-01-26 14:21:24 --> Output Class Initialized
INFO - 2020-01-26 14:21:24 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:24 --> Input Class Initialized
INFO - 2020-01-26 14:21:24 --> Language Class Initialized
INFO - 2020-01-26 14:21:24 --> Language Class Initialized
INFO - 2020-01-26 14:21:24 --> Config Class Initialized
INFO - 2020-01-26 14:21:25 --> Loader Class Initialized
INFO - 2020-01-26 14:21:25 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:25 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:25 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:25 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:25 --> Controller Class Initialized
INFO - 2020-01-26 14:21:25 --> Config Class Initialized
INFO - 2020-01-26 14:21:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:26 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:26 --> URI Class Initialized
INFO - 2020-01-26 14:21:26 --> Router Class Initialized
INFO - 2020-01-26 14:21:26 --> Output Class Initialized
INFO - 2020-01-26 14:21:26 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:26 --> Input Class Initialized
INFO - 2020-01-26 14:21:26 --> Language Class Initialized
INFO - 2020-01-26 14:21:26 --> Language Class Initialized
INFO - 2020-01-26 14:21:26 --> Config Class Initialized
INFO - 2020-01-26 14:21:26 --> Loader Class Initialized
INFO - 2020-01-26 14:21:26 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:26 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:27 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:27 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:27 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:27 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:21:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:27 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:27 --> Total execution time: 1.8751
INFO - 2020-01-26 14:21:33 --> Config Class Initialized
INFO - 2020-01-26 14:21:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:33 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:33 --> URI Class Initialized
INFO - 2020-01-26 14:21:33 --> Router Class Initialized
INFO - 2020-01-26 14:21:33 --> Output Class Initialized
INFO - 2020-01-26 14:21:33 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:33 --> Input Class Initialized
INFO - 2020-01-26 14:21:34 --> Language Class Initialized
INFO - 2020-01-26 14:21:34 --> Language Class Initialized
INFO - 2020-01-26 14:21:34 --> Config Class Initialized
INFO - 2020-01-26 14:21:34 --> Loader Class Initialized
INFO - 2020-01-26 14:21:34 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:34 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:34 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:34 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:34 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:21:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:35 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:35 --> Total execution time: 2.0672
INFO - 2020-01-26 14:21:37 --> Config Class Initialized
INFO - 2020-01-26 14:21:37 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:37 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:37 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:37 --> URI Class Initialized
INFO - 2020-01-26 14:21:37 --> Router Class Initialized
INFO - 2020-01-26 14:21:37 --> Output Class Initialized
INFO - 2020-01-26 14:21:37 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:38 --> Input Class Initialized
INFO - 2020-01-26 14:21:38 --> Language Class Initialized
INFO - 2020-01-26 14:21:38 --> Language Class Initialized
INFO - 2020-01-26 14:21:38 --> Config Class Initialized
INFO - 2020-01-26 14:21:38 --> Loader Class Initialized
INFO - 2020-01-26 14:21:38 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:38 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:38 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:38 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:38 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:38 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:21:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:39 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:39 --> Total execution time: 1.9462
INFO - 2020-01-26 14:21:47 --> Config Class Initialized
INFO - 2020-01-26 14:21:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:47 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:47 --> URI Class Initialized
INFO - 2020-01-26 14:21:47 --> Router Class Initialized
INFO - 2020-01-26 14:21:47 --> Output Class Initialized
INFO - 2020-01-26 14:21:48 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:48 --> Input Class Initialized
INFO - 2020-01-26 14:21:48 --> Language Class Initialized
INFO - 2020-01-26 14:21:48 --> Language Class Initialized
INFO - 2020-01-26 14:21:48 --> Config Class Initialized
INFO - 2020-01-26 14:21:48 --> Loader Class Initialized
INFO - 2020-01-26 14:21:48 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:48 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:48 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:48 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:49 --> Controller Class Initialized
INFO - 2020-01-26 14:21:49 --> Config Class Initialized
INFO - 2020-01-26 14:21:49 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:21:49 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:21:49 --> Utf8 Class Initialized
INFO - 2020-01-26 14:21:49 --> URI Class Initialized
INFO - 2020-01-26 14:21:49 --> Router Class Initialized
INFO - 2020-01-26 14:21:49 --> Output Class Initialized
INFO - 2020-01-26 14:21:49 --> Security Class Initialized
DEBUG - 2020-01-26 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:21:49 --> Input Class Initialized
INFO - 2020-01-26 14:21:50 --> Language Class Initialized
INFO - 2020-01-26 14:21:50 --> Language Class Initialized
INFO - 2020-01-26 14:21:50 --> Config Class Initialized
INFO - 2020-01-26 14:21:50 --> Loader Class Initialized
INFO - 2020-01-26 14:21:50 --> Helper loaded: url_helper
INFO - 2020-01-26 14:21:50 --> Helper loaded: file_helper
INFO - 2020-01-26 14:21:50 --> Helper loaded: form_helper
INFO - 2020-01-26 14:21:50 --> Helper loaded: my_helper
INFO - 2020-01-26 14:21:50 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:21:50 --> Controller Class Initialized
DEBUG - 2020-01-26 14:21:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:21:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:21:51 --> Final output sent to browser
DEBUG - 2020-01-26 14:21:51 --> Total execution time: 2.0467
INFO - 2020-01-26 14:22:51 --> Config Class Initialized
INFO - 2020-01-26 14:22:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:22:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:22:52 --> Utf8 Class Initialized
INFO - 2020-01-26 14:22:52 --> URI Class Initialized
INFO - 2020-01-26 14:22:52 --> Router Class Initialized
INFO - 2020-01-26 14:22:52 --> Output Class Initialized
INFO - 2020-01-26 14:22:52 --> Security Class Initialized
DEBUG - 2020-01-26 14:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:22:52 --> Input Class Initialized
INFO - 2020-01-26 14:22:52 --> Language Class Initialized
INFO - 2020-01-26 14:22:52 --> Language Class Initialized
INFO - 2020-01-26 14:22:52 --> Config Class Initialized
INFO - 2020-01-26 14:22:52 --> Loader Class Initialized
INFO - 2020-01-26 14:22:53 --> Helper loaded: url_helper
INFO - 2020-01-26 14:22:53 --> Helper loaded: file_helper
INFO - 2020-01-26 14:22:53 --> Helper loaded: form_helper
INFO - 2020-01-26 14:22:53 --> Helper loaded: my_helper
INFO - 2020-01-26 14:22:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:22:53 --> Controller Class Initialized
DEBUG - 2020-01-26 14:22:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:22:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:22:53 --> Final output sent to browser
DEBUG - 2020-01-26 14:22:53 --> Total execution time: 1.9636
INFO - 2020-01-26 14:23:09 --> Config Class Initialized
INFO - 2020-01-26 14:23:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:09 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:09 --> URI Class Initialized
INFO - 2020-01-26 14:23:09 --> Router Class Initialized
INFO - 2020-01-26 14:23:09 --> Output Class Initialized
INFO - 2020-01-26 14:23:10 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:10 --> Input Class Initialized
INFO - 2020-01-26 14:23:10 --> Language Class Initialized
INFO - 2020-01-26 14:23:10 --> Language Class Initialized
INFO - 2020-01-26 14:23:10 --> Config Class Initialized
INFO - 2020-01-26 14:23:10 --> Loader Class Initialized
INFO - 2020-01-26 14:23:10 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:11 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:11 --> Controller Class Initialized
INFO - 2020-01-26 14:23:11 --> Config Class Initialized
INFO - 2020-01-26 14:23:11 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:11 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:11 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:11 --> URI Class Initialized
INFO - 2020-01-26 14:23:11 --> Router Class Initialized
INFO - 2020-01-26 14:23:12 --> Output Class Initialized
INFO - 2020-01-26 14:23:12 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:12 --> Input Class Initialized
INFO - 2020-01-26 14:23:12 --> Language Class Initialized
INFO - 2020-01-26 14:23:12 --> Language Class Initialized
INFO - 2020-01-26 14:23:12 --> Config Class Initialized
INFO - 2020-01-26 14:23:12 --> Loader Class Initialized
INFO - 2020-01-26 14:23:12 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:12 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:13 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:13 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:13 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:13 --> Controller Class Initialized
DEBUG - 2020-01-26 14:23:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:23:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:23:13 --> Final output sent to browser
DEBUG - 2020-01-26 14:23:13 --> Total execution time: 2.2963
INFO - 2020-01-26 14:23:17 --> Config Class Initialized
INFO - 2020-01-26 14:23:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:17 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:17 --> URI Class Initialized
INFO - 2020-01-26 14:23:17 --> Router Class Initialized
INFO - 2020-01-26 14:23:17 --> Output Class Initialized
INFO - 2020-01-26 14:23:17 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:17 --> Input Class Initialized
INFO - 2020-01-26 14:23:18 --> Language Class Initialized
INFO - 2020-01-26 14:23:18 --> Language Class Initialized
INFO - 2020-01-26 14:23:18 --> Config Class Initialized
INFO - 2020-01-26 14:23:18 --> Loader Class Initialized
INFO - 2020-01-26 14:23:18 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:18 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:18 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:18 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:18 --> Controller Class Initialized
DEBUG - 2020-01-26 14:23:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 14:23:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:23:19 --> Final output sent to browser
DEBUG - 2020-01-26 14:23:19 --> Total execution time: 2.0648
INFO - 2020-01-26 14:23:19 --> Config Class Initialized
INFO - 2020-01-26 14:23:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:19 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:19 --> URI Class Initialized
INFO - 2020-01-26 14:23:20 --> Router Class Initialized
INFO - 2020-01-26 14:23:20 --> Output Class Initialized
INFO - 2020-01-26 14:23:20 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:20 --> Input Class Initialized
INFO - 2020-01-26 14:23:20 --> Language Class Initialized
INFO - 2020-01-26 14:23:20 --> Language Class Initialized
INFO - 2020-01-26 14:23:20 --> Config Class Initialized
INFO - 2020-01-26 14:23:20 --> Loader Class Initialized
INFO - 2020-01-26 14:23:20 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:20 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:21 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:21 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:21 --> Controller Class Initialized
INFO - 2020-01-26 14:23:41 --> Config Class Initialized
INFO - 2020-01-26 14:23:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:41 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:41 --> URI Class Initialized
INFO - 2020-01-26 14:23:41 --> Router Class Initialized
INFO - 2020-01-26 14:23:41 --> Output Class Initialized
INFO - 2020-01-26 14:23:41 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:41 --> Input Class Initialized
INFO - 2020-01-26 14:23:42 --> Language Class Initialized
INFO - 2020-01-26 14:23:42 --> Language Class Initialized
INFO - 2020-01-26 14:23:42 --> Config Class Initialized
INFO - 2020-01-26 14:23:42 --> Loader Class Initialized
INFO - 2020-01-26 14:23:42 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:42 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:42 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:42 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:43 --> Controller Class Initialized
DEBUG - 2020-01-26 14:23:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_kelas/views/list.php
DEBUG - 2020-01-26 14:23:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:23:43 --> Final output sent to browser
DEBUG - 2020-01-26 14:23:43 --> Total execution time: 2.0779
INFO - 2020-01-26 14:23:43 --> Config Class Initialized
INFO - 2020-01-26 14:23:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:43 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:43 --> URI Class Initialized
INFO - 2020-01-26 14:23:44 --> Router Class Initialized
INFO - 2020-01-26 14:23:44 --> Output Class Initialized
INFO - 2020-01-26 14:23:44 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:44 --> Input Class Initialized
INFO - 2020-01-26 14:23:44 --> Language Class Initialized
INFO - 2020-01-26 14:23:44 --> Language Class Initialized
INFO - 2020-01-26 14:23:44 --> Config Class Initialized
INFO - 2020-01-26 14:23:44 --> Loader Class Initialized
INFO - 2020-01-26 14:23:44 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:44 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:44 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:45 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:45 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:45 --> Controller Class Initialized
INFO - 2020-01-26 14:23:47 --> Config Class Initialized
INFO - 2020-01-26 14:23:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:47 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:47 --> URI Class Initialized
INFO - 2020-01-26 14:23:47 --> Router Class Initialized
INFO - 2020-01-26 14:23:47 --> Output Class Initialized
INFO - 2020-01-26 14:23:48 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:48 --> Input Class Initialized
INFO - 2020-01-26 14:23:48 --> Language Class Initialized
INFO - 2020-01-26 14:23:48 --> Language Class Initialized
INFO - 2020-01-26 14:23:48 --> Config Class Initialized
INFO - 2020-01-26 14:23:48 --> Loader Class Initialized
INFO - 2020-01-26 14:23:48 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:48 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:48 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:48 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:49 --> Controller Class Initialized
INFO - 2020-01-26 14:23:49 --> Final output sent to browser
DEBUG - 2020-01-26 14:23:49 --> Total execution time: 1.8910
INFO - 2020-01-26 14:23:51 --> Config Class Initialized
INFO - 2020-01-26 14:23:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:52 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:52 --> URI Class Initialized
INFO - 2020-01-26 14:23:52 --> Router Class Initialized
INFO - 2020-01-26 14:23:52 --> Output Class Initialized
INFO - 2020-01-26 14:23:52 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:52 --> Input Class Initialized
INFO - 2020-01-26 14:23:52 --> Language Class Initialized
INFO - 2020-01-26 14:23:52 --> Language Class Initialized
INFO - 2020-01-26 14:23:52 --> Config Class Initialized
INFO - 2020-01-26 14:23:52 --> Loader Class Initialized
INFO - 2020-01-26 14:23:53 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:53 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:53 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:53 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:53 --> Controller Class Initialized
DEBUG - 2020-01-26 14:23:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:23:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:23:53 --> Final output sent to browser
DEBUG - 2020-01-26 14:23:53 --> Total execution time: 1.9829
INFO - 2020-01-26 14:23:58 --> Config Class Initialized
INFO - 2020-01-26 14:23:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:23:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:23:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:23:58 --> URI Class Initialized
INFO - 2020-01-26 14:23:58 --> Router Class Initialized
INFO - 2020-01-26 14:23:58 --> Output Class Initialized
INFO - 2020-01-26 14:23:58 --> Security Class Initialized
DEBUG - 2020-01-26 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:23:58 --> Input Class Initialized
INFO - 2020-01-26 14:23:58 --> Language Class Initialized
INFO - 2020-01-26 14:23:59 --> Language Class Initialized
INFO - 2020-01-26 14:23:59 --> Config Class Initialized
INFO - 2020-01-26 14:23:59 --> Loader Class Initialized
INFO - 2020-01-26 14:23:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:23:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:23:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:23:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:23:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:23:59 --> Controller Class Initialized
DEBUG - 2020-01-26 14:23:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:24:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:24:00 --> Final output sent to browser
DEBUG - 2020-01-26 14:24:00 --> Total execution time: 2.0404
INFO - 2020-01-26 14:24:08 --> Config Class Initialized
INFO - 2020-01-26 14:24:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:24:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:24:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:24:08 --> URI Class Initialized
INFO - 2020-01-26 14:24:08 --> Router Class Initialized
INFO - 2020-01-26 14:24:08 --> Output Class Initialized
INFO - 2020-01-26 14:24:08 --> Security Class Initialized
DEBUG - 2020-01-26 14:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:24:09 --> Input Class Initialized
INFO - 2020-01-26 14:24:09 --> Language Class Initialized
INFO - 2020-01-26 14:24:09 --> Language Class Initialized
INFO - 2020-01-26 14:24:09 --> Config Class Initialized
INFO - 2020-01-26 14:24:09 --> Loader Class Initialized
INFO - 2020-01-26 14:24:09 --> Helper loaded: url_helper
INFO - 2020-01-26 14:24:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:24:09 --> Helper loaded: form_helper
INFO - 2020-01-26 14:24:09 --> Helper loaded: my_helper
INFO - 2020-01-26 14:24:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:24:10 --> Controller Class Initialized
INFO - 2020-01-26 14:24:10 --> Config Class Initialized
INFO - 2020-01-26 14:24:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:24:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:24:10 --> Utf8 Class Initialized
INFO - 2020-01-26 14:24:10 --> URI Class Initialized
INFO - 2020-01-26 14:24:10 --> Router Class Initialized
INFO - 2020-01-26 14:24:10 --> Output Class Initialized
INFO - 2020-01-26 14:24:11 --> Security Class Initialized
DEBUG - 2020-01-26 14:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:24:11 --> Input Class Initialized
INFO - 2020-01-26 14:24:11 --> Language Class Initialized
INFO - 2020-01-26 14:24:11 --> Language Class Initialized
INFO - 2020-01-26 14:24:11 --> Config Class Initialized
INFO - 2020-01-26 14:24:11 --> Loader Class Initialized
INFO - 2020-01-26 14:24:11 --> Helper loaded: url_helper
INFO - 2020-01-26 14:24:11 --> Helper loaded: file_helper
INFO - 2020-01-26 14:24:11 --> Helper loaded: form_helper
INFO - 2020-01-26 14:24:11 --> Helper loaded: my_helper
INFO - 2020-01-26 14:24:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:24:12 --> Controller Class Initialized
DEBUG - 2020-01-26 14:24:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:24:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:24:12 --> Final output sent to browser
DEBUG - 2020-01-26 14:24:12 --> Total execution time: 2.2973
INFO - 2020-01-26 14:24:16 --> Config Class Initialized
INFO - 2020-01-26 14:24:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:24:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:24:17 --> Utf8 Class Initialized
INFO - 2020-01-26 14:24:17 --> URI Class Initialized
INFO - 2020-01-26 14:24:17 --> Router Class Initialized
INFO - 2020-01-26 14:24:17 --> Output Class Initialized
INFO - 2020-01-26 14:24:17 --> Security Class Initialized
DEBUG - 2020-01-26 14:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:24:17 --> Input Class Initialized
INFO - 2020-01-26 14:24:17 --> Language Class Initialized
INFO - 2020-01-26 14:24:17 --> Language Class Initialized
INFO - 2020-01-26 14:24:17 --> Config Class Initialized
INFO - 2020-01-26 14:24:18 --> Loader Class Initialized
INFO - 2020-01-26 14:24:18 --> Helper loaded: url_helper
INFO - 2020-01-26 14:24:18 --> Helper loaded: file_helper
INFO - 2020-01-26 14:24:18 --> Helper loaded: form_helper
INFO - 2020-01-26 14:24:18 --> Helper loaded: my_helper
INFO - 2020-01-26 14:24:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:24:18 --> Controller Class Initialized
DEBUG - 2020-01-26 14:24:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:24:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:24:18 --> Final output sent to browser
DEBUG - 2020-01-26 14:24:19 --> Total execution time: 2.0657
INFO - 2020-01-26 14:24:40 --> Config Class Initialized
INFO - 2020-01-26 14:24:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:24:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:24:40 --> Utf8 Class Initialized
INFO - 2020-01-26 14:24:40 --> URI Class Initialized
INFO - 2020-01-26 14:24:40 --> Router Class Initialized
INFO - 2020-01-26 14:24:41 --> Output Class Initialized
INFO - 2020-01-26 14:24:41 --> Security Class Initialized
DEBUG - 2020-01-26 14:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:24:41 --> Input Class Initialized
INFO - 2020-01-26 14:24:41 --> Language Class Initialized
INFO - 2020-01-26 14:24:41 --> Language Class Initialized
INFO - 2020-01-26 14:24:41 --> Config Class Initialized
INFO - 2020-01-26 14:24:41 --> Loader Class Initialized
INFO - 2020-01-26 14:24:41 --> Helper loaded: url_helper
INFO - 2020-01-26 14:24:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:24:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:24:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:24:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:24:42 --> Controller Class Initialized
DEBUG - 2020-01-26 14:24:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:24:42 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:24:42 --> Final output sent to browser
DEBUG - 2020-01-26 14:24:42 --> Total execution time: 2.0908
INFO - 2020-01-26 14:31:12 --> Config Class Initialized
INFO - 2020-01-26 14:31:12 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:31:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:31:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:31:13 --> URI Class Initialized
INFO - 2020-01-26 14:31:13 --> Router Class Initialized
INFO - 2020-01-26 14:31:13 --> Output Class Initialized
INFO - 2020-01-26 14:31:13 --> Security Class Initialized
DEBUG - 2020-01-26 14:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:31:13 --> Input Class Initialized
INFO - 2020-01-26 14:31:13 --> Language Class Initialized
INFO - 2020-01-26 14:31:13 --> Language Class Initialized
INFO - 2020-01-26 14:31:13 --> Config Class Initialized
INFO - 2020-01-26 14:31:13 --> Loader Class Initialized
INFO - 2020-01-26 14:31:14 --> Helper loaded: url_helper
INFO - 2020-01-26 14:31:14 --> Helper loaded: file_helper
INFO - 2020-01-26 14:31:14 --> Helper loaded: form_helper
INFO - 2020-01-26 14:31:14 --> Helper loaded: my_helper
INFO - 2020-01-26 14:31:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:31:14 --> Controller Class Initialized
DEBUG - 2020-01-26 14:31:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:31:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:31:14 --> Final output sent to browser
DEBUG - 2020-01-26 14:31:15 --> Total execution time: 2.1250
INFO - 2020-01-26 14:35:54 --> Config Class Initialized
INFO - 2020-01-26 14:35:54 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:35:54 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:35:54 --> Utf8 Class Initialized
INFO - 2020-01-26 14:35:54 --> URI Class Initialized
INFO - 2020-01-26 14:35:54 --> Router Class Initialized
INFO - 2020-01-26 14:35:55 --> Output Class Initialized
INFO - 2020-01-26 14:35:55 --> Security Class Initialized
DEBUG - 2020-01-26 14:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:35:55 --> Input Class Initialized
INFO - 2020-01-26 14:35:55 --> Language Class Initialized
INFO - 2020-01-26 14:35:55 --> Language Class Initialized
INFO - 2020-01-26 14:35:55 --> Config Class Initialized
INFO - 2020-01-26 14:35:55 --> Loader Class Initialized
INFO - 2020-01-26 14:35:55 --> Helper loaded: url_helper
INFO - 2020-01-26 14:35:55 --> Helper loaded: file_helper
INFO - 2020-01-26 14:35:55 --> Helper loaded: form_helper
INFO - 2020-01-26 14:35:56 --> Helper loaded: my_helper
INFO - 2020-01-26 14:35:56 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:35:56 --> Controller Class Initialized
INFO - 2020-01-26 14:36:06 --> Config Class Initialized
INFO - 2020-01-26 14:36:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:36:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:36:06 --> Utf8 Class Initialized
INFO - 2020-01-26 14:36:06 --> URI Class Initialized
INFO - 2020-01-26 14:36:06 --> Router Class Initialized
INFO - 2020-01-26 14:36:07 --> Output Class Initialized
INFO - 2020-01-26 14:36:07 --> Security Class Initialized
DEBUG - 2020-01-26 14:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:36:07 --> Input Class Initialized
INFO - 2020-01-26 14:36:07 --> Language Class Initialized
INFO - 2020-01-26 14:36:07 --> Language Class Initialized
INFO - 2020-01-26 14:36:07 --> Config Class Initialized
INFO - 2020-01-26 14:36:07 --> Loader Class Initialized
INFO - 2020-01-26 14:36:07 --> Helper loaded: url_helper
INFO - 2020-01-26 14:36:07 --> Helper loaded: file_helper
INFO - 2020-01-26 14:36:08 --> Helper loaded: form_helper
INFO - 2020-01-26 14:36:08 --> Helper loaded: my_helper
INFO - 2020-01-26 14:36:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:36:08 --> Controller Class Initialized
DEBUG - 2020-01-26 14:36:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:36:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:36:08 --> Final output sent to browser
DEBUG - 2020-01-26 14:36:09 --> Total execution time: 2.4157
INFO - 2020-01-26 14:37:38 --> Config Class Initialized
INFO - 2020-01-26 14:37:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:37:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:37:38 --> Utf8 Class Initialized
INFO - 2020-01-26 14:37:39 --> URI Class Initialized
INFO - 2020-01-26 14:37:39 --> Router Class Initialized
INFO - 2020-01-26 14:37:39 --> Output Class Initialized
INFO - 2020-01-26 14:37:39 --> Security Class Initialized
DEBUG - 2020-01-26 14:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:37:39 --> Input Class Initialized
INFO - 2020-01-26 14:37:39 --> Language Class Initialized
INFO - 2020-01-26 14:37:39 --> Language Class Initialized
INFO - 2020-01-26 14:37:39 --> Config Class Initialized
INFO - 2020-01-26 14:37:39 --> Loader Class Initialized
INFO - 2020-01-26 14:37:39 --> Helper loaded: url_helper
INFO - 2020-01-26 14:37:39 --> Helper loaded: file_helper
INFO - 2020-01-26 14:37:40 --> Helper loaded: form_helper
INFO - 2020-01-26 14:37:40 --> Helper loaded: my_helper
INFO - 2020-01-26 14:37:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:37:40 --> Controller Class Initialized
DEBUG - 2020-01-26 14:37:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:37:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:37:40 --> Final output sent to browser
DEBUG - 2020-01-26 14:37:40 --> Total execution time: 2.0908
INFO - 2020-01-26 14:38:06 --> Config Class Initialized
INFO - 2020-01-26 14:38:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:38:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:38:06 --> Utf8 Class Initialized
INFO - 2020-01-26 14:38:06 --> URI Class Initialized
INFO - 2020-01-26 14:38:06 --> Router Class Initialized
INFO - 2020-01-26 14:38:06 --> Output Class Initialized
INFO - 2020-01-26 14:38:07 --> Security Class Initialized
DEBUG - 2020-01-26 14:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:38:07 --> Input Class Initialized
INFO - 2020-01-26 14:38:07 --> Language Class Initialized
INFO - 2020-01-26 14:38:07 --> Language Class Initialized
INFO - 2020-01-26 14:38:07 --> Config Class Initialized
INFO - 2020-01-26 14:38:07 --> Loader Class Initialized
INFO - 2020-01-26 14:38:07 --> Helper loaded: url_helper
INFO - 2020-01-26 14:38:07 --> Helper loaded: file_helper
INFO - 2020-01-26 14:38:07 --> Helper loaded: form_helper
INFO - 2020-01-26 14:38:08 --> Helper loaded: my_helper
INFO - 2020-01-26 14:38:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:38:08 --> Controller Class Initialized
DEBUG - 2020-01-26 14:38:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 14:38:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:38:08 --> Final output sent to browser
DEBUG - 2020-01-26 14:38:08 --> Total execution time: 2.4083
INFO - 2020-01-26 14:38:09 --> Config Class Initialized
INFO - 2020-01-26 14:38:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:38:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:38:09 --> Utf8 Class Initialized
INFO - 2020-01-26 14:38:09 --> URI Class Initialized
INFO - 2020-01-26 14:38:09 --> Router Class Initialized
INFO - 2020-01-26 14:38:09 --> Output Class Initialized
INFO - 2020-01-26 14:38:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:38:09 --> Input Class Initialized
INFO - 2020-01-26 14:38:10 --> Language Class Initialized
INFO - 2020-01-26 14:38:10 --> Language Class Initialized
INFO - 2020-01-26 14:38:10 --> Config Class Initialized
INFO - 2020-01-26 14:38:10 --> Loader Class Initialized
INFO - 2020-01-26 14:38:10 --> Helper loaded: url_helper
INFO - 2020-01-26 14:38:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:38:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:38:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:38:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:38:10 --> Controller Class Initialized
INFO - 2020-01-26 14:39:18 --> Config Class Initialized
INFO - 2020-01-26 14:39:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:39:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:39:18 --> Utf8 Class Initialized
INFO - 2020-01-26 14:39:18 --> URI Class Initialized
INFO - 2020-01-26 14:39:18 --> Router Class Initialized
INFO - 2020-01-26 14:39:18 --> Output Class Initialized
INFO - 2020-01-26 14:39:18 --> Security Class Initialized
DEBUG - 2020-01-26 14:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:39:19 --> Input Class Initialized
INFO - 2020-01-26 14:39:19 --> Language Class Initialized
INFO - 2020-01-26 14:39:19 --> Language Class Initialized
INFO - 2020-01-26 14:39:19 --> Config Class Initialized
INFO - 2020-01-26 14:39:19 --> Loader Class Initialized
INFO - 2020-01-26 14:39:19 --> Helper loaded: url_helper
INFO - 2020-01-26 14:39:19 --> Helper loaded: file_helper
INFO - 2020-01-26 14:39:19 --> Helper loaded: form_helper
INFO - 2020-01-26 14:39:19 --> Helper loaded: my_helper
INFO - 2020-01-26 14:39:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:39:20 --> Controller Class Initialized
DEBUG - 2020-01-26 14:39:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/tahun/views/list.php
DEBUG - 2020-01-26 14:39:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:39:20 --> Final output sent to browser
DEBUG - 2020-01-26 14:39:20 --> Total execution time: 2.1737
INFO - 2020-01-26 14:39:20 --> Config Class Initialized
INFO - 2020-01-26 14:39:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:39:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:39:20 --> Config Class Initialized
INFO - 2020-01-26 14:39:21 --> Hooks Class Initialized
INFO - 2020-01-26 14:39:21 --> Utf8 Class Initialized
INFO - 2020-01-26 14:39:21 --> URI Class Initialized
DEBUG - 2020-01-26 14:39:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:39:21 --> Utf8 Class Initialized
INFO - 2020-01-26 14:39:21 --> Router Class Initialized
INFO - 2020-01-26 14:39:21 --> URI Class Initialized
INFO - 2020-01-26 14:39:21 --> Output Class Initialized
INFO - 2020-01-26 14:39:21 --> Security Class Initialized
INFO - 2020-01-26 14:39:21 --> Router Class Initialized
INFO - 2020-01-26 14:39:21 --> Output Class Initialized
DEBUG - 2020-01-26 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:39:21 --> Input Class Initialized
INFO - 2020-01-26 14:39:21 --> Security Class Initialized
INFO - 2020-01-26 14:39:21 --> Language Class Initialized
DEBUG - 2020-01-26 14:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:39:21 --> Input Class Initialized
INFO - 2020-01-26 14:39:21 --> Language Class Initialized
INFO - 2020-01-26 14:39:21 --> Config Class Initialized
INFO - 2020-01-26 14:39:21 --> Language Class Initialized
INFO - 2020-01-26 14:39:21 --> Loader Class Initialized
INFO - 2020-01-26 14:39:21 --> Language Class Initialized
INFO - 2020-01-26 14:39:22 --> Config Class Initialized
INFO - 2020-01-26 14:39:22 --> Helper loaded: url_helper
INFO - 2020-01-26 14:39:22 --> Loader Class Initialized
INFO - 2020-01-26 14:39:22 --> Helper loaded: file_helper
INFO - 2020-01-26 14:39:22 --> Helper loaded: url_helper
INFO - 2020-01-26 14:39:22 --> Helper loaded: form_helper
INFO - 2020-01-26 14:39:22 --> Helper loaded: file_helper
INFO - 2020-01-26 14:39:22 --> Helper loaded: my_helper
INFO - 2020-01-26 14:39:22 --> Helper loaded: form_helper
INFO - 2020-01-26 14:39:22 --> Database Driver Class Initialized
INFO - 2020-01-26 14:39:22 --> Helper loaded: my_helper
DEBUG - 2020-01-26 14:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:39:22 --> Database Driver Class Initialized
INFO - 2020-01-26 14:39:22 --> Controller Class Initialized
DEBUG - 2020-01-26 14:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:39:22 --> Controller Class Initialized
DEBUG - 2020-01-26 14:39:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:39:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:39:23 --> Final output sent to browser
DEBUG - 2020-01-26 14:39:23 --> Total execution time: 2.0561
INFO - 2020-01-26 14:40:08 --> Config Class Initialized
INFO - 2020-01-26 14:40:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:40:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:40:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:40:08 --> URI Class Initialized
INFO - 2020-01-26 14:40:08 --> Router Class Initialized
INFO - 2020-01-26 14:40:08 --> Output Class Initialized
INFO - 2020-01-26 14:40:08 --> Security Class Initialized
DEBUG - 2020-01-26 14:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:40:09 --> Input Class Initialized
INFO - 2020-01-26 14:40:09 --> Language Class Initialized
INFO - 2020-01-26 14:40:09 --> Language Class Initialized
INFO - 2020-01-26 14:40:09 --> Config Class Initialized
INFO - 2020-01-26 14:40:09 --> Loader Class Initialized
INFO - 2020-01-26 14:40:09 --> Helper loaded: url_helper
INFO - 2020-01-26 14:40:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:40:09 --> Helper loaded: form_helper
INFO - 2020-01-26 14:40:09 --> Helper loaded: my_helper
INFO - 2020-01-26 14:40:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:40:10 --> Controller Class Initialized
DEBUG - 2020-01-26 14:40:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:40:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:40:10 --> Final output sent to browser
DEBUG - 2020-01-26 14:40:10 --> Total execution time: 2.4586
INFO - 2020-01-26 14:43:10 --> Config Class Initialized
INFO - 2020-01-26 14:43:10 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:43:10 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:43:11 --> Utf8 Class Initialized
INFO - 2020-01-26 14:43:11 --> URI Class Initialized
INFO - 2020-01-26 14:43:11 --> Router Class Initialized
INFO - 2020-01-26 14:43:11 --> Output Class Initialized
INFO - 2020-01-26 14:43:11 --> Security Class Initialized
DEBUG - 2020-01-26 14:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:43:11 --> Input Class Initialized
INFO - 2020-01-26 14:43:11 --> Language Class Initialized
INFO - 2020-01-26 14:43:11 --> Language Class Initialized
INFO - 2020-01-26 14:43:12 --> Config Class Initialized
INFO - 2020-01-26 14:43:12 --> Loader Class Initialized
INFO - 2020-01-26 14:43:12 --> Helper loaded: url_helper
INFO - 2020-01-26 14:43:12 --> Helper loaded: file_helper
INFO - 2020-01-26 14:43:12 --> Helper loaded: form_helper
INFO - 2020-01-26 14:43:12 --> Helper loaded: my_helper
INFO - 2020-01-26 14:43:12 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:43:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:43:13 --> Controller Class Initialized
DEBUG - 2020-01-26 14:43:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:43:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:43:13 --> Final output sent to browser
DEBUG - 2020-01-26 14:43:13 --> Total execution time: 2.6631
INFO - 2020-01-26 14:45:15 --> Config Class Initialized
INFO - 2020-01-26 14:45:15 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:45:15 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:45:15 --> Utf8 Class Initialized
INFO - 2020-01-26 14:45:16 --> URI Class Initialized
INFO - 2020-01-26 14:45:16 --> Router Class Initialized
INFO - 2020-01-26 14:45:16 --> Output Class Initialized
INFO - 2020-01-26 14:45:16 --> Security Class Initialized
DEBUG - 2020-01-26 14:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:45:16 --> Input Class Initialized
INFO - 2020-01-26 14:45:16 --> Language Class Initialized
INFO - 2020-01-26 14:45:16 --> Language Class Initialized
INFO - 2020-01-26 14:45:16 --> Config Class Initialized
INFO - 2020-01-26 14:45:16 --> Loader Class Initialized
INFO - 2020-01-26 14:45:16 --> Helper loaded: url_helper
INFO - 2020-01-26 14:45:17 --> Helper loaded: file_helper
INFO - 2020-01-26 14:45:17 --> Helper loaded: form_helper
INFO - 2020-01-26 14:45:17 --> Helper loaded: my_helper
INFO - 2020-01-26 14:45:17 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:45:17 --> Controller Class Initialized
DEBUG - 2020-01-26 14:45:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:45:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:45:17 --> Final output sent to browser
DEBUG - 2020-01-26 14:45:17 --> Total execution time: 2.1563
INFO - 2020-01-26 14:46:26 --> Config Class Initialized
INFO - 2020-01-26 14:46:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:46:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:46:27 --> Utf8 Class Initialized
INFO - 2020-01-26 14:46:27 --> URI Class Initialized
INFO - 2020-01-26 14:46:27 --> Router Class Initialized
INFO - 2020-01-26 14:46:27 --> Output Class Initialized
INFO - 2020-01-26 14:46:27 --> Security Class Initialized
DEBUG - 2020-01-26 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:46:27 --> Input Class Initialized
INFO - 2020-01-26 14:46:27 --> Language Class Initialized
INFO - 2020-01-26 14:46:27 --> Language Class Initialized
INFO - 2020-01-26 14:46:27 --> Config Class Initialized
INFO - 2020-01-26 14:46:27 --> Loader Class Initialized
INFO - 2020-01-26 14:46:28 --> Helper loaded: url_helper
INFO - 2020-01-26 14:46:28 --> Helper loaded: file_helper
INFO - 2020-01-26 14:46:28 --> Helper loaded: form_helper
INFO - 2020-01-26 14:46:28 --> Helper loaded: my_helper
INFO - 2020-01-26 14:46:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:46:28 --> Controller Class Initialized
DEBUG - 2020-01-26 14:46:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:46:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:46:28 --> Final output sent to browser
DEBUG - 2020-01-26 14:46:29 --> Total execution time: 2.1244
INFO - 2020-01-26 14:46:30 --> Config Class Initialized
INFO - 2020-01-26 14:46:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:46:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:46:31 --> Utf8 Class Initialized
INFO - 2020-01-26 14:46:31 --> URI Class Initialized
INFO - 2020-01-26 14:46:31 --> Router Class Initialized
INFO - 2020-01-26 14:46:31 --> Output Class Initialized
INFO - 2020-01-26 14:46:31 --> Security Class Initialized
DEBUG - 2020-01-26 14:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:46:31 --> Input Class Initialized
INFO - 2020-01-26 14:46:31 --> Language Class Initialized
INFO - 2020-01-26 14:46:31 --> Language Class Initialized
INFO - 2020-01-26 14:46:32 --> Config Class Initialized
INFO - 2020-01-26 14:46:32 --> Loader Class Initialized
INFO - 2020-01-26 14:46:32 --> Helper loaded: url_helper
INFO - 2020-01-26 14:46:32 --> Helper loaded: file_helper
INFO - 2020-01-26 14:46:32 --> Helper loaded: form_helper
INFO - 2020-01-26 14:46:32 --> Helper loaded: my_helper
INFO - 2020-01-26 14:46:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:46:32 --> Controller Class Initialized
DEBUG - 2020-01-26 14:46:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:46:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:46:33 --> Final output sent to browser
DEBUG - 2020-01-26 14:46:33 --> Total execution time: 2.2558
INFO - 2020-01-26 14:47:08 --> Config Class Initialized
INFO - 2020-01-26 14:47:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:08 --> URI Class Initialized
INFO - 2020-01-26 14:47:09 --> Router Class Initialized
INFO - 2020-01-26 14:47:09 --> Output Class Initialized
INFO - 2020-01-26 14:47:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:09 --> Input Class Initialized
INFO - 2020-01-26 14:47:09 --> Language Class Initialized
INFO - 2020-01-26 14:47:09 --> Language Class Initialized
INFO - 2020-01-26 14:47:09 --> Config Class Initialized
INFO - 2020-01-26 14:47:09 --> Loader Class Initialized
INFO - 2020-01-26 14:47:09 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:09 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:10 --> Controller Class Initialized
DEBUG - 2020-01-26 14:47:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 14:47:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:10 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:11 --> Total execution time: 2.5204
INFO - 2020-01-26 14:47:16 --> Config Class Initialized
INFO - 2020-01-26 14:47:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:17 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:17 --> URI Class Initialized
INFO - 2020-01-26 14:47:17 --> Router Class Initialized
INFO - 2020-01-26 14:47:17 --> Output Class Initialized
INFO - 2020-01-26 14:47:17 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:17 --> Input Class Initialized
INFO - 2020-01-26 14:47:17 --> Language Class Initialized
INFO - 2020-01-26 14:47:17 --> Language Class Initialized
INFO - 2020-01-26 14:47:17 --> Config Class Initialized
INFO - 2020-01-26 14:47:18 --> Loader Class Initialized
INFO - 2020-01-26 14:47:18 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:18 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:18 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:18 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:18 --> Controller Class Initialized
INFO - 2020-01-26 14:47:18 --> Config Class Initialized
INFO - 2020-01-26 14:47:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:19 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:19 --> URI Class Initialized
INFO - 2020-01-26 14:47:19 --> Router Class Initialized
INFO - 2020-01-26 14:47:19 --> Output Class Initialized
INFO - 2020-01-26 14:47:19 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:19 --> Input Class Initialized
INFO - 2020-01-26 14:47:19 --> Language Class Initialized
INFO - 2020-01-26 14:47:19 --> Language Class Initialized
INFO - 2020-01-26 14:47:19 --> Config Class Initialized
INFO - 2020-01-26 14:47:19 --> Loader Class Initialized
INFO - 2020-01-26 14:47:20 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:20 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:20 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:20 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:20 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:20 --> Controller Class Initialized
DEBUG - 2020-01-26 14:47:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:47:20 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:20 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:21 --> Total execution time: 2.1349
INFO - 2020-01-26 14:47:35 --> Config Class Initialized
INFO - 2020-01-26 14:47:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:35 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:35 --> URI Class Initialized
INFO - 2020-01-26 14:47:35 --> Router Class Initialized
INFO - 2020-01-26 14:47:36 --> Output Class Initialized
INFO - 2020-01-26 14:47:36 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:36 --> Input Class Initialized
INFO - 2020-01-26 14:47:36 --> Language Class Initialized
INFO - 2020-01-26 14:47:36 --> Language Class Initialized
INFO - 2020-01-26 14:47:36 --> Config Class Initialized
INFO - 2020-01-26 14:47:36 --> Loader Class Initialized
INFO - 2020-01-26 14:47:36 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:36 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:36 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:37 --> Controller Class Initialized
DEBUG - 2020-01-26 14:47:37 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-26 14:47:37 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:37 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:37 --> Total execution time: 2.1759
INFO - 2020-01-26 14:47:37 --> Config Class Initialized
INFO - 2020-01-26 14:47:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:38 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:38 --> URI Class Initialized
INFO - 2020-01-26 14:47:38 --> Router Class Initialized
INFO - 2020-01-26 14:47:38 --> Output Class Initialized
INFO - 2020-01-26 14:47:38 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:38 --> Input Class Initialized
INFO - 2020-01-26 14:47:38 --> Language Class Initialized
INFO - 2020-01-26 14:47:38 --> Language Class Initialized
INFO - 2020-01-26 14:47:39 --> Config Class Initialized
INFO - 2020-01-26 14:47:39 --> Loader Class Initialized
INFO - 2020-01-26 14:47:39 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:39 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:39 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:39 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:39 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:39 --> Controller Class Initialized
INFO - 2020-01-26 14:47:41 --> Config Class Initialized
INFO - 2020-01-26 14:47:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:41 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:41 --> URI Class Initialized
INFO - 2020-01-26 14:47:42 --> Router Class Initialized
INFO - 2020-01-26 14:47:42 --> Output Class Initialized
INFO - 2020-01-26 14:47:42 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:42 --> Input Class Initialized
INFO - 2020-01-26 14:47:42 --> Language Class Initialized
INFO - 2020-01-26 14:47:42 --> Language Class Initialized
INFO - 2020-01-26 14:47:42 --> Config Class Initialized
INFO - 2020-01-26 14:47:42 --> Loader Class Initialized
INFO - 2020-01-26 14:47:42 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:42 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:43 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:43 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:43 --> Controller Class Initialized
ERROR - 2020-01-26 14:47:43 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-01-26 14:47:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/form.php
DEBUG - 2020-01-26 14:47:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:43 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:44 --> Total execution time: 2.3475
INFO - 2020-01-26 14:47:52 --> Config Class Initialized
INFO - 2020-01-26 14:47:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:52 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:52 --> URI Class Initialized
INFO - 2020-01-26 14:47:52 --> Router Class Initialized
INFO - 2020-01-26 14:47:52 --> Output Class Initialized
INFO - 2020-01-26 14:47:52 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:52 --> Input Class Initialized
INFO - 2020-01-26 14:47:53 --> Language Class Initialized
INFO - 2020-01-26 14:47:53 --> Language Class Initialized
INFO - 2020-01-26 14:47:53 --> Config Class Initialized
INFO - 2020-01-26 14:47:53 --> Loader Class Initialized
INFO - 2020-01-26 14:47:53 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:53 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:53 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:53 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:54 --> Controller Class Initialized
DEBUG - 2020-01-26 14:47:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 14:47:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:54 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:54 --> Total execution time: 2.1952
INFO - 2020-01-26 14:47:57 --> Config Class Initialized
INFO - 2020-01-26 14:47:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:57 --> Utf8 Class Initialized
INFO - 2020-01-26 14:47:57 --> URI Class Initialized
INFO - 2020-01-26 14:47:57 --> Router Class Initialized
INFO - 2020-01-26 14:47:57 --> Output Class Initialized
INFO - 2020-01-26 14:47:57 --> Security Class Initialized
DEBUG - 2020-01-26 14:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:47:58 --> Input Class Initialized
INFO - 2020-01-26 14:47:58 --> Language Class Initialized
INFO - 2020-01-26 14:47:58 --> Language Class Initialized
INFO - 2020-01-26 14:47:58 --> Config Class Initialized
INFO - 2020-01-26 14:47:58 --> Loader Class Initialized
INFO - 2020-01-26 14:47:58 --> Helper loaded: url_helper
INFO - 2020-01-26 14:47:58 --> Helper loaded: file_helper
INFO - 2020-01-26 14:47:58 --> Helper loaded: form_helper
INFO - 2020-01-26 14:47:58 --> Helper loaded: my_helper
INFO - 2020-01-26 14:47:58 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:47:59 --> Controller Class Initialized
DEBUG - 2020-01-26 14:47:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:47:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:47:59 --> Final output sent to browser
DEBUG - 2020-01-26 14:47:59 --> Total execution time: 2.1750
INFO - 2020-01-26 14:47:59 --> Config Class Initialized
INFO - 2020-01-26 14:47:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:47:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:47:59 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:00 --> URI Class Initialized
INFO - 2020-01-26 14:48:00 --> Router Class Initialized
INFO - 2020-01-26 14:48:00 --> Output Class Initialized
INFO - 2020-01-26 14:48:00 --> Security Class Initialized
DEBUG - 2020-01-26 14:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:01 --> Input Class Initialized
INFO - 2020-01-26 14:48:01 --> Config Class Initialized
INFO - 2020-01-26 14:48:01 --> Hooks Class Initialized
INFO - 2020-01-26 14:48:01 --> Language Class Initialized
DEBUG - 2020-01-26 14:48:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:48:01 --> Language Class Initialized
INFO - 2020-01-26 14:48:01 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:01 --> Config Class Initialized
INFO - 2020-01-26 14:48:01 --> Loader Class Initialized
INFO - 2020-01-26 14:48:01 --> URI Class Initialized
INFO - 2020-01-26 14:48:01 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:01 --> Router Class Initialized
INFO - 2020-01-26 14:48:01 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:01 --> Output Class Initialized
INFO - 2020-01-26 14:48:02 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:02 --> Security Class Initialized
INFO - 2020-01-26 14:48:02 --> Helper loaded: my_helper
DEBUG - 2020-01-26 14:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:02 --> Input Class Initialized
INFO - 2020-01-26 14:48:02 --> Database Driver Class Initialized
INFO - 2020-01-26 14:48:02 --> Language Class Initialized
DEBUG - 2020-01-26 14:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:02 --> Language Class Initialized
INFO - 2020-01-26 14:48:02 --> Config Class Initialized
INFO - 2020-01-26 14:48:02 --> Controller Class Initialized
INFO - 2020-01-26 14:48:02 --> Loader Class Initialized
INFO - 2020-01-26 14:48:02 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:02 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:03 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:03 --> Helper loaded: my_helper
INFO - 2020-01-26 14:48:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:03 --> Controller Class Initialized
DEBUG - 2020-01-26 14:48:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 14:48:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:48:03 --> Final output sent to browser
DEBUG - 2020-01-26 14:48:04 --> Total execution time: 2.5626
INFO - 2020-01-26 14:48:27 --> Config Class Initialized
INFO - 2020-01-26 14:48:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:48:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:48:27 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:27 --> URI Class Initialized
INFO - 2020-01-26 14:48:28 --> Router Class Initialized
INFO - 2020-01-26 14:48:28 --> Output Class Initialized
INFO - 2020-01-26 14:48:28 --> Security Class Initialized
DEBUG - 2020-01-26 14:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:28 --> Input Class Initialized
INFO - 2020-01-26 14:48:28 --> Language Class Initialized
INFO - 2020-01-26 14:48:28 --> Language Class Initialized
INFO - 2020-01-26 14:48:28 --> Config Class Initialized
INFO - 2020-01-26 14:48:28 --> Loader Class Initialized
INFO - 2020-01-26 14:48:28 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:28 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:28 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:29 --> Helper loaded: my_helper
INFO - 2020-01-26 14:48:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:29 --> Controller Class Initialized
INFO - 2020-01-26 14:48:29 --> Config Class Initialized
INFO - 2020-01-26 14:48:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:48:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:48:29 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:29 --> URI Class Initialized
INFO - 2020-01-26 14:48:30 --> Router Class Initialized
INFO - 2020-01-26 14:48:30 --> Output Class Initialized
INFO - 2020-01-26 14:48:30 --> Security Class Initialized
DEBUG - 2020-01-26 14:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:30 --> Input Class Initialized
INFO - 2020-01-26 14:48:30 --> Language Class Initialized
INFO - 2020-01-26 14:48:30 --> Language Class Initialized
INFO - 2020-01-26 14:48:30 --> Config Class Initialized
INFO - 2020-01-26 14:48:30 --> Loader Class Initialized
INFO - 2020-01-26 14:48:30 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:30 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:30 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:31 --> Helper loaded: my_helper
INFO - 2020-01-26 14:48:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:31 --> Controller Class Initialized
DEBUG - 2020-01-26 14:48:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:48:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:48:31 --> Final output sent to browser
DEBUG - 2020-01-26 14:48:31 --> Total execution time: 2.1349
INFO - 2020-01-26 14:48:31 --> Config Class Initialized
INFO - 2020-01-26 14:48:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:48:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:48:32 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:32 --> URI Class Initialized
INFO - 2020-01-26 14:48:32 --> Router Class Initialized
INFO - 2020-01-26 14:48:32 --> Output Class Initialized
INFO - 2020-01-26 14:48:32 --> Security Class Initialized
DEBUG - 2020-01-26 14:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:32 --> Input Class Initialized
INFO - 2020-01-26 14:48:32 --> Language Class Initialized
INFO - 2020-01-26 14:48:32 --> Language Class Initialized
INFO - 2020-01-26 14:48:33 --> Config Class Initialized
INFO - 2020-01-26 14:48:33 --> Loader Class Initialized
INFO - 2020-01-26 14:48:33 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:33 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:33 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:33 --> Helper loaded: my_helper
INFO - 2020-01-26 14:48:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:33 --> Controller Class Initialized
INFO - 2020-01-26 14:48:45 --> Config Class Initialized
INFO - 2020-01-26 14:48:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:48:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:48:45 --> Utf8 Class Initialized
INFO - 2020-01-26 14:48:45 --> URI Class Initialized
INFO - 2020-01-26 14:48:46 --> Router Class Initialized
INFO - 2020-01-26 14:48:46 --> Output Class Initialized
INFO - 2020-01-26 14:48:46 --> Security Class Initialized
DEBUG - 2020-01-26 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:48:46 --> Input Class Initialized
INFO - 2020-01-26 14:48:46 --> Language Class Initialized
INFO - 2020-01-26 14:48:46 --> Language Class Initialized
INFO - 2020-01-26 14:48:46 --> Config Class Initialized
INFO - 2020-01-26 14:48:46 --> Loader Class Initialized
INFO - 2020-01-26 14:48:46 --> Helper loaded: url_helper
INFO - 2020-01-26 14:48:46 --> Helper loaded: file_helper
INFO - 2020-01-26 14:48:47 --> Helper loaded: form_helper
INFO - 2020-01-26 14:48:47 --> Helper loaded: my_helper
INFO - 2020-01-26 14:48:47 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:48:47 --> Controller Class Initialized
DEBUG - 2020-01-26 14:48:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 14:48:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:48:47 --> Final output sent to browser
DEBUG - 2020-01-26 14:48:47 --> Total execution time: 2.1986
INFO - 2020-01-26 14:49:26 --> Config Class Initialized
INFO - 2020-01-26 14:49:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:49:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:49:26 --> Utf8 Class Initialized
INFO - 2020-01-26 14:49:26 --> URI Class Initialized
INFO - 2020-01-26 14:49:26 --> Router Class Initialized
INFO - 2020-01-26 14:49:26 --> Output Class Initialized
INFO - 2020-01-26 14:49:26 --> Security Class Initialized
DEBUG - 2020-01-26 14:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:49:26 --> Input Class Initialized
INFO - 2020-01-26 14:49:26 --> Language Class Initialized
INFO - 2020-01-26 14:49:27 --> Language Class Initialized
INFO - 2020-01-26 14:49:27 --> Config Class Initialized
INFO - 2020-01-26 14:49:27 --> Loader Class Initialized
INFO - 2020-01-26 14:49:27 --> Helper loaded: url_helper
INFO - 2020-01-26 14:49:27 --> Helper loaded: file_helper
INFO - 2020-01-26 14:49:27 --> Helper loaded: form_helper
INFO - 2020-01-26 14:49:27 --> Helper loaded: my_helper
INFO - 2020-01-26 14:49:27 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:49:27 --> Controller Class Initialized
INFO - 2020-01-26 14:49:28 --> Config Class Initialized
INFO - 2020-01-26 14:49:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:49:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:49:28 --> Utf8 Class Initialized
INFO - 2020-01-26 14:49:28 --> URI Class Initialized
INFO - 2020-01-26 14:49:28 --> Router Class Initialized
INFO - 2020-01-26 14:49:28 --> Output Class Initialized
INFO - 2020-01-26 14:49:28 --> Security Class Initialized
DEBUG - 2020-01-26 14:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:49:28 --> Input Class Initialized
INFO - 2020-01-26 14:49:28 --> Language Class Initialized
INFO - 2020-01-26 14:49:29 --> Language Class Initialized
INFO - 2020-01-26 14:49:29 --> Config Class Initialized
INFO - 2020-01-26 14:49:29 --> Loader Class Initialized
INFO - 2020-01-26 14:49:29 --> Helper loaded: url_helper
INFO - 2020-01-26 14:49:29 --> Helper loaded: file_helper
INFO - 2020-01-26 14:49:29 --> Helper loaded: form_helper
INFO - 2020-01-26 14:49:29 --> Helper loaded: my_helper
INFO - 2020-01-26 14:49:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:49:29 --> Controller Class Initialized
DEBUG - 2020-01-26 14:49:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:49:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:49:30 --> Final output sent to browser
DEBUG - 2020-01-26 14:49:30 --> Total execution time: 2.1658
INFO - 2020-01-26 14:49:30 --> Config Class Initialized
INFO - 2020-01-26 14:49:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:49:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:49:30 --> Utf8 Class Initialized
INFO - 2020-01-26 14:49:30 --> URI Class Initialized
INFO - 2020-01-26 14:49:31 --> Router Class Initialized
INFO - 2020-01-26 14:49:31 --> Output Class Initialized
INFO - 2020-01-26 14:49:31 --> Security Class Initialized
DEBUG - 2020-01-26 14:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:49:31 --> Input Class Initialized
INFO - 2020-01-26 14:49:31 --> Language Class Initialized
INFO - 2020-01-26 14:49:31 --> Language Class Initialized
INFO - 2020-01-26 14:49:31 --> Config Class Initialized
INFO - 2020-01-26 14:49:31 --> Loader Class Initialized
INFO - 2020-01-26 14:49:31 --> Helper loaded: url_helper
INFO - 2020-01-26 14:49:31 --> Helper loaded: file_helper
INFO - 2020-01-26 14:49:32 --> Helper loaded: form_helper
INFO - 2020-01-26 14:49:32 --> Helper loaded: my_helper
INFO - 2020-01-26 14:49:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:49:32 --> Controller Class Initialized
INFO - 2020-01-26 14:54:25 --> Config Class Initialized
INFO - 2020-01-26 14:54:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:54:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:54:25 --> Utf8 Class Initialized
INFO - 2020-01-26 14:54:25 --> URI Class Initialized
INFO - 2020-01-26 14:54:25 --> Router Class Initialized
INFO - 2020-01-26 14:54:25 --> Output Class Initialized
INFO - 2020-01-26 14:54:25 --> Security Class Initialized
DEBUG - 2020-01-26 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:54:26 --> Input Class Initialized
INFO - 2020-01-26 14:54:26 --> Language Class Initialized
INFO - 2020-01-26 14:54:26 --> Language Class Initialized
INFO - 2020-01-26 14:54:26 --> Config Class Initialized
INFO - 2020-01-26 14:54:26 --> Loader Class Initialized
INFO - 2020-01-26 14:54:26 --> Helper loaded: url_helper
INFO - 2020-01-26 14:54:26 --> Helper loaded: file_helper
INFO - 2020-01-26 14:54:26 --> Helper loaded: form_helper
INFO - 2020-01-26 14:54:26 --> Helper loaded: my_helper
INFO - 2020-01-26 14:54:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:54:27 --> Controller Class Initialized
DEBUG - 2020-01-26 14:54:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:54:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:54:27 --> Final output sent to browser
DEBUG - 2020-01-26 14:54:27 --> Total execution time: 2.2810
INFO - 2020-01-26 14:54:27 --> Config Class Initialized
INFO - 2020-01-26 14:54:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:54:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:54:28 --> Utf8 Class Initialized
INFO - 2020-01-26 14:54:28 --> URI Class Initialized
INFO - 2020-01-26 14:54:28 --> Router Class Initialized
INFO - 2020-01-26 14:54:28 --> Output Class Initialized
INFO - 2020-01-26 14:54:28 --> Security Class Initialized
DEBUG - 2020-01-26 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:54:28 --> Input Class Initialized
INFO - 2020-01-26 14:54:28 --> Language Class Initialized
INFO - 2020-01-26 14:54:28 --> Language Class Initialized
INFO - 2020-01-26 14:54:29 --> Config Class Initialized
INFO - 2020-01-26 14:54:29 --> Loader Class Initialized
INFO - 2020-01-26 14:54:29 --> Helper loaded: url_helper
INFO - 2020-01-26 14:54:29 --> Helper loaded: file_helper
INFO - 2020-01-26 14:54:29 --> Helper loaded: form_helper
INFO - 2020-01-26 14:54:29 --> Helper loaded: my_helper
INFO - 2020-01-26 14:54:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:54:29 --> Controller Class Initialized
INFO - 2020-01-26 14:54:30 --> Config Class Initialized
INFO - 2020-01-26 14:54:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:54:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:54:30 --> Utf8 Class Initialized
INFO - 2020-01-26 14:54:30 --> URI Class Initialized
INFO - 2020-01-26 14:54:30 --> Router Class Initialized
INFO - 2020-01-26 14:54:30 --> Output Class Initialized
INFO - 2020-01-26 14:54:31 --> Security Class Initialized
DEBUG - 2020-01-26 14:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:54:31 --> Input Class Initialized
INFO - 2020-01-26 14:54:31 --> Language Class Initialized
INFO - 2020-01-26 14:54:31 --> Language Class Initialized
INFO - 2020-01-26 14:54:31 --> Config Class Initialized
INFO - 2020-01-26 14:54:31 --> Loader Class Initialized
INFO - 2020-01-26 14:54:31 --> Helper loaded: url_helper
INFO - 2020-01-26 14:54:31 --> Helper loaded: file_helper
INFO - 2020-01-26 14:54:31 --> Helper loaded: form_helper
INFO - 2020-01-26 14:54:32 --> Helper loaded: my_helper
INFO - 2020-01-26 14:54:32 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:54:32 --> Controller Class Initialized
DEBUG - 2020-01-26 14:54:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 14:54:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:54:32 --> Final output sent to browser
DEBUG - 2020-01-26 14:54:32 --> Total execution time: 2.2540
INFO - 2020-01-26 14:54:39 --> Config Class Initialized
INFO - 2020-01-26 14:54:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:54:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:54:40 --> Utf8 Class Initialized
INFO - 2020-01-26 14:54:40 --> URI Class Initialized
INFO - 2020-01-26 14:54:40 --> Router Class Initialized
INFO - 2020-01-26 14:54:40 --> Output Class Initialized
INFO - 2020-01-26 14:54:40 --> Security Class Initialized
DEBUG - 2020-01-26 14:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:54:40 --> Input Class Initialized
INFO - 2020-01-26 14:54:40 --> Language Class Initialized
INFO - 2020-01-26 14:54:40 --> Language Class Initialized
INFO - 2020-01-26 14:54:41 --> Config Class Initialized
INFO - 2020-01-26 14:54:41 --> Loader Class Initialized
INFO - 2020-01-26 14:54:41 --> Helper loaded: url_helper
INFO - 2020-01-26 14:54:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:54:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:54:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:54:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:54:41 --> Controller Class Initialized
INFO - 2020-01-26 14:55:42 --> Config Class Initialized
INFO - 2020-01-26 14:55:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:55:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:55:42 --> Utf8 Class Initialized
INFO - 2020-01-26 14:55:43 --> URI Class Initialized
INFO - 2020-01-26 14:55:43 --> Router Class Initialized
INFO - 2020-01-26 14:55:43 --> Output Class Initialized
INFO - 2020-01-26 14:55:43 --> Security Class Initialized
DEBUG - 2020-01-26 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:55:43 --> Input Class Initialized
INFO - 2020-01-26 14:55:43 --> Language Class Initialized
INFO - 2020-01-26 14:55:43 --> Language Class Initialized
INFO - 2020-01-26 14:55:43 --> Config Class Initialized
INFO - 2020-01-26 14:55:43 --> Loader Class Initialized
INFO - 2020-01-26 14:55:43 --> Helper loaded: url_helper
INFO - 2020-01-26 14:55:44 --> Helper loaded: file_helper
INFO - 2020-01-26 14:55:44 --> Helper loaded: form_helper
INFO - 2020-01-26 14:55:44 --> Helper loaded: my_helper
INFO - 2020-01-26 14:55:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:55:44 --> Controller Class Initialized
DEBUG - 2020-01-26 14:55:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 14:55:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:55:44 --> Final output sent to browser
DEBUG - 2020-01-26 14:55:45 --> Total execution time: 2.2921
INFO - 2020-01-26 14:55:49 --> Config Class Initialized
INFO - 2020-01-26 14:55:49 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:55:49 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:55:49 --> Utf8 Class Initialized
INFO - 2020-01-26 14:55:49 --> URI Class Initialized
INFO - 2020-01-26 14:55:49 --> Router Class Initialized
INFO - 2020-01-26 14:55:49 --> Output Class Initialized
INFO - 2020-01-26 14:55:49 --> Security Class Initialized
DEBUG - 2020-01-26 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:55:50 --> Input Class Initialized
INFO - 2020-01-26 14:55:50 --> Language Class Initialized
INFO - 2020-01-26 14:55:50 --> Language Class Initialized
INFO - 2020-01-26 14:55:50 --> Config Class Initialized
INFO - 2020-01-26 14:55:50 --> Loader Class Initialized
INFO - 2020-01-26 14:55:50 --> Helper loaded: url_helper
INFO - 2020-01-26 14:55:50 --> Helper loaded: file_helper
INFO - 2020-01-26 14:55:50 --> Helper loaded: form_helper
INFO - 2020-01-26 14:55:50 --> Helper loaded: my_helper
INFO - 2020-01-26 14:55:50 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:55:51 --> Controller Class Initialized
DEBUG - 2020-01-26 14:55:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 14:55:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:55:51 --> Final output sent to browser
DEBUG - 2020-01-26 14:55:51 --> Total execution time: 2.3048
INFO - 2020-01-26 14:55:58 --> Config Class Initialized
INFO - 2020-01-26 14:55:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:55:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:55:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:55:58 --> URI Class Initialized
INFO - 2020-01-26 14:55:58 --> Router Class Initialized
INFO - 2020-01-26 14:55:58 --> Output Class Initialized
INFO - 2020-01-26 14:55:59 --> Security Class Initialized
DEBUG - 2020-01-26 14:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:55:59 --> Input Class Initialized
INFO - 2020-01-26 14:55:59 --> Language Class Initialized
INFO - 2020-01-26 14:55:59 --> Language Class Initialized
INFO - 2020-01-26 14:55:59 --> Config Class Initialized
INFO - 2020-01-26 14:55:59 --> Loader Class Initialized
INFO - 2020-01-26 14:55:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:55:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:55:59 --> Helper loaded: form_helper
INFO - 2020-01-26 14:55:59 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:00 --> Controller Class Initialized
INFO - 2020-01-26 14:56:00 --> Config Class Initialized
INFO - 2020-01-26 14:56:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:00 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:00 --> URI Class Initialized
INFO - 2020-01-26 14:56:01 --> Router Class Initialized
INFO - 2020-01-26 14:56:01 --> Output Class Initialized
INFO - 2020-01-26 14:56:01 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:01 --> Input Class Initialized
INFO - 2020-01-26 14:56:01 --> Language Class Initialized
INFO - 2020-01-26 14:56:01 --> Language Class Initialized
INFO - 2020-01-26 14:56:01 --> Config Class Initialized
INFO - 2020-01-26 14:56:01 --> Loader Class Initialized
INFO - 2020-01-26 14:56:02 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:02 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:02 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:02 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:02 --> Controller Class Initialized
DEBUG - 2020-01-26 14:56:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:56:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:56:03 --> Final output sent to browser
DEBUG - 2020-01-26 14:56:03 --> Total execution time: 2.6101
INFO - 2020-01-26 14:56:03 --> Config Class Initialized
INFO - 2020-01-26 14:56:03 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:03 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:03 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:03 --> URI Class Initialized
INFO - 2020-01-26 14:56:04 --> Router Class Initialized
INFO - 2020-01-26 14:56:04 --> Output Class Initialized
INFO - 2020-01-26 14:56:04 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:04 --> Input Class Initialized
INFO - 2020-01-26 14:56:04 --> Language Class Initialized
INFO - 2020-01-26 14:56:04 --> Language Class Initialized
INFO - 2020-01-26 14:56:04 --> Config Class Initialized
INFO - 2020-01-26 14:56:04 --> Loader Class Initialized
INFO - 2020-01-26 14:56:04 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:04 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:05 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:05 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:05 --> Controller Class Initialized
INFO - 2020-01-26 14:56:27 --> Config Class Initialized
INFO - 2020-01-26 14:56:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:27 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:28 --> URI Class Initialized
INFO - 2020-01-26 14:56:28 --> Router Class Initialized
INFO - 2020-01-26 14:56:28 --> Output Class Initialized
INFO - 2020-01-26 14:56:28 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:28 --> Input Class Initialized
INFO - 2020-01-26 14:56:28 --> Language Class Initialized
INFO - 2020-01-26 14:56:28 --> Language Class Initialized
INFO - 2020-01-26 14:56:28 --> Config Class Initialized
INFO - 2020-01-26 14:56:28 --> Loader Class Initialized
INFO - 2020-01-26 14:56:28 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:29 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:29 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:29 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:29 --> Controller Class Initialized
DEBUG - 2020-01-26 14:56:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 14:56:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:56:29 --> Final output sent to browser
DEBUG - 2020-01-26 14:56:30 --> Total execution time: 2.2888
INFO - 2020-01-26 14:56:30 --> Config Class Initialized
INFO - 2020-01-26 14:56:30 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:30 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:30 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:30 --> URI Class Initialized
INFO - 2020-01-26 14:56:30 --> Router Class Initialized
INFO - 2020-01-26 14:56:30 --> Output Class Initialized
INFO - 2020-01-26 14:56:30 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:31 --> Input Class Initialized
INFO - 2020-01-26 14:56:31 --> Language Class Initialized
INFO - 2020-01-26 14:56:31 --> Language Class Initialized
INFO - 2020-01-26 14:56:31 --> Config Class Initialized
INFO - 2020-01-26 14:56:31 --> Loader Class Initialized
INFO - 2020-01-26 14:56:31 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:31 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:31 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:31 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:32 --> Controller Class Initialized
INFO - 2020-01-26 14:56:33 --> Config Class Initialized
INFO - 2020-01-26 14:56:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:33 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:33 --> URI Class Initialized
INFO - 2020-01-26 14:56:33 --> Router Class Initialized
INFO - 2020-01-26 14:56:33 --> Output Class Initialized
INFO - 2020-01-26 14:56:33 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:33 --> Input Class Initialized
INFO - 2020-01-26 14:56:34 --> Language Class Initialized
INFO - 2020-01-26 14:56:34 --> Language Class Initialized
INFO - 2020-01-26 14:56:34 --> Config Class Initialized
INFO - 2020-01-26 14:56:34 --> Loader Class Initialized
INFO - 2020-01-26 14:56:34 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:34 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:34 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:34 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:35 --> Controller Class Initialized
DEBUG - 2020-01-26 14:56:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_walikelas/views/list.php
DEBUG - 2020-01-26 14:56:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:56:35 --> Final output sent to browser
DEBUG - 2020-01-26 14:56:35 --> Total execution time: 2.3369
INFO - 2020-01-26 14:56:35 --> Config Class Initialized
INFO - 2020-01-26 14:56:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:36 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:36 --> URI Class Initialized
INFO - 2020-01-26 14:56:36 --> Router Class Initialized
INFO - 2020-01-26 14:56:36 --> Output Class Initialized
INFO - 2020-01-26 14:56:36 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:36 --> Input Class Initialized
INFO - 2020-01-26 14:56:36 --> Language Class Initialized
INFO - 2020-01-26 14:56:36 --> Language Class Initialized
INFO - 2020-01-26 14:56:36 --> Config Class Initialized
INFO - 2020-01-26 14:56:36 --> Loader Class Initialized
INFO - 2020-01-26 14:56:37 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:37 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:37 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:37 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:37 --> Controller Class Initialized
INFO - 2020-01-26 14:56:39 --> Config Class Initialized
INFO - 2020-01-26 14:56:39 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:39 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:39 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:39 --> URI Class Initialized
INFO - 2020-01-26 14:56:40 --> Router Class Initialized
INFO - 2020-01-26 14:56:40 --> Output Class Initialized
INFO - 2020-01-26 14:56:40 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:40 --> Input Class Initialized
INFO - 2020-01-26 14:56:40 --> Language Class Initialized
INFO - 2020-01-26 14:56:40 --> Language Class Initialized
INFO - 2020-01-26 14:56:40 --> Config Class Initialized
INFO - 2020-01-26 14:56:40 --> Loader Class Initialized
INFO - 2020-01-26 14:56:40 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:41 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:41 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:41 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:41 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:41 --> Controller Class Initialized
INFO - 2020-01-26 14:56:41 --> Final output sent to browser
DEBUG - 2020-01-26 14:56:41 --> Total execution time: 2.1703
INFO - 2020-01-26 14:56:44 --> Config Class Initialized
INFO - 2020-01-26 14:56:44 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:44 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:44 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:44 --> URI Class Initialized
INFO - 2020-01-26 14:56:45 --> Router Class Initialized
INFO - 2020-01-26 14:56:45 --> Output Class Initialized
INFO - 2020-01-26 14:56:45 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:45 --> Input Class Initialized
INFO - 2020-01-26 14:56:45 --> Language Class Initialized
INFO - 2020-01-26 14:56:45 --> Language Class Initialized
INFO - 2020-01-26 14:56:45 --> Config Class Initialized
INFO - 2020-01-26 14:56:45 --> Loader Class Initialized
INFO - 2020-01-26 14:56:45 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:45 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:46 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:46 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:46 --> Controller Class Initialized
INFO - 2020-01-26 14:56:46 --> Final output sent to browser
DEBUG - 2020-01-26 14:56:46 --> Total execution time: 2.0652
INFO - 2020-01-26 14:56:46 --> Config Class Initialized
INFO - 2020-01-26 14:56:46 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:47 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:47 --> URI Class Initialized
INFO - 2020-01-26 14:56:47 --> Router Class Initialized
INFO - 2020-01-26 14:56:47 --> Output Class Initialized
INFO - 2020-01-26 14:56:47 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:47 --> Input Class Initialized
INFO - 2020-01-26 14:56:47 --> Language Class Initialized
INFO - 2020-01-26 14:56:47 --> Language Class Initialized
INFO - 2020-01-26 14:56:48 --> Config Class Initialized
INFO - 2020-01-26 14:56:48 --> Loader Class Initialized
INFO - 2020-01-26 14:56:48 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:48 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:48 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:48 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:48 --> Controller Class Initialized
INFO - 2020-01-26 14:56:54 --> Config Class Initialized
INFO - 2020-01-26 14:56:54 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:54 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:54 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:54 --> URI Class Initialized
INFO - 2020-01-26 14:56:54 --> Router Class Initialized
INFO - 2020-01-26 14:56:54 --> Output Class Initialized
INFO - 2020-01-26 14:56:54 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:55 --> Input Class Initialized
INFO - 2020-01-26 14:56:55 --> Language Class Initialized
INFO - 2020-01-26 14:56:55 --> Language Class Initialized
INFO - 2020-01-26 14:56:55 --> Config Class Initialized
INFO - 2020-01-26 14:56:55 --> Loader Class Initialized
INFO - 2020-01-26 14:56:55 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:55 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:55 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:55 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:55 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:56 --> Controller Class Initialized
INFO - 2020-01-26 14:56:56 --> Helper loaded: cookie_helper
INFO - 2020-01-26 14:56:56 --> Config Class Initialized
INFO - 2020-01-26 14:56:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:56 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:56 --> URI Class Initialized
INFO - 2020-01-26 14:56:56 --> Router Class Initialized
INFO - 2020-01-26 14:56:56 --> Output Class Initialized
INFO - 2020-01-26 14:56:57 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:57 --> Input Class Initialized
INFO - 2020-01-26 14:56:57 --> Language Class Initialized
INFO - 2020-01-26 14:56:57 --> Language Class Initialized
INFO - 2020-01-26 14:56:57 --> Config Class Initialized
INFO - 2020-01-26 14:56:57 --> Loader Class Initialized
INFO - 2020-01-26 14:56:57 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:57 --> Helper loaded: file_helper
INFO - 2020-01-26 14:56:57 --> Helper loaded: form_helper
INFO - 2020-01-26 14:56:58 --> Helper loaded: my_helper
INFO - 2020-01-26 14:56:58 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:56:58 --> Controller Class Initialized
INFO - 2020-01-26 14:56:58 --> Config Class Initialized
INFO - 2020-01-26 14:56:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:56:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:56:58 --> Utf8 Class Initialized
INFO - 2020-01-26 14:56:58 --> URI Class Initialized
INFO - 2020-01-26 14:56:59 --> Router Class Initialized
INFO - 2020-01-26 14:56:59 --> Output Class Initialized
INFO - 2020-01-26 14:56:59 --> Security Class Initialized
DEBUG - 2020-01-26 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:56:59 --> Input Class Initialized
INFO - 2020-01-26 14:56:59 --> Language Class Initialized
INFO - 2020-01-26 14:56:59 --> Language Class Initialized
INFO - 2020-01-26 14:56:59 --> Config Class Initialized
INFO - 2020-01-26 14:56:59 --> Loader Class Initialized
INFO - 2020-01-26 14:56:59 --> Helper loaded: url_helper
INFO - 2020-01-26 14:56:59 --> Helper loaded: file_helper
INFO - 2020-01-26 14:57:00 --> Helper loaded: form_helper
INFO - 2020-01-26 14:57:00 --> Helper loaded: my_helper
INFO - 2020-01-26 14:57:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:57:00 --> Controller Class Initialized
DEBUG - 2020-01-26 14:57:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 14:57:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:57:01 --> Final output sent to browser
DEBUG - 2020-01-26 14:57:01 --> Total execution time: 2.4685
INFO - 2020-01-26 14:57:08 --> Config Class Initialized
INFO - 2020-01-26 14:57:08 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:57:08 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:57:08 --> Utf8 Class Initialized
INFO - 2020-01-26 14:57:08 --> URI Class Initialized
INFO - 2020-01-26 14:57:08 --> Router Class Initialized
INFO - 2020-01-26 14:57:09 --> Output Class Initialized
INFO - 2020-01-26 14:57:09 --> Security Class Initialized
DEBUG - 2020-01-26 14:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:57:09 --> Input Class Initialized
INFO - 2020-01-26 14:57:09 --> Language Class Initialized
INFO - 2020-01-26 14:57:09 --> Language Class Initialized
INFO - 2020-01-26 14:57:09 --> Config Class Initialized
INFO - 2020-01-26 14:57:09 --> Loader Class Initialized
INFO - 2020-01-26 14:57:09 --> Helper loaded: url_helper
INFO - 2020-01-26 14:57:10 --> Helper loaded: file_helper
INFO - 2020-01-26 14:57:10 --> Helper loaded: form_helper
INFO - 2020-01-26 14:57:10 --> Helper loaded: my_helper
INFO - 2020-01-26 14:57:10 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:57:10 --> Controller Class Initialized
DEBUG - 2020-01-26 14:57:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 14:57:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:57:11 --> Final output sent to browser
DEBUG - 2020-01-26 14:57:11 --> Total execution time: 2.7365
INFO - 2020-01-26 14:57:13 --> Config Class Initialized
INFO - 2020-01-26 14:57:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:57:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:57:13 --> Utf8 Class Initialized
INFO - 2020-01-26 14:57:13 --> URI Class Initialized
INFO - 2020-01-26 14:57:13 --> Router Class Initialized
INFO - 2020-01-26 14:57:14 --> Output Class Initialized
INFO - 2020-01-26 14:57:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:57:14 --> Input Class Initialized
INFO - 2020-01-26 14:57:14 --> Language Class Initialized
INFO - 2020-01-26 14:57:14 --> Language Class Initialized
INFO - 2020-01-26 14:57:14 --> Config Class Initialized
INFO - 2020-01-26 14:57:14 --> Loader Class Initialized
INFO - 2020-01-26 14:57:14 --> Helper loaded: url_helper
INFO - 2020-01-26 14:57:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:57:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:57:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:57:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:57:15 --> Controller Class Initialized
DEBUG - 2020-01-26 14:57:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 14:57:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:57:16 --> Final output sent to browser
DEBUG - 2020-01-26 14:57:16 --> Total execution time: 2.9044
INFO - 2020-01-26 14:58:01 --> Config Class Initialized
INFO - 2020-01-26 14:58:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:58:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:58:02 --> Utf8 Class Initialized
INFO - 2020-01-26 14:58:02 --> URI Class Initialized
INFO - 2020-01-26 14:58:02 --> Router Class Initialized
INFO - 2020-01-26 14:58:02 --> Output Class Initialized
INFO - 2020-01-26 14:58:02 --> Security Class Initialized
DEBUG - 2020-01-26 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:58:02 --> Input Class Initialized
INFO - 2020-01-26 14:58:02 --> Language Class Initialized
INFO - 2020-01-26 14:58:03 --> Language Class Initialized
INFO - 2020-01-26 14:58:03 --> Config Class Initialized
INFO - 2020-01-26 14:58:03 --> Loader Class Initialized
INFO - 2020-01-26 14:58:03 --> Helper loaded: url_helper
INFO - 2020-01-26 14:58:03 --> Helper loaded: file_helper
INFO - 2020-01-26 14:58:03 --> Helper loaded: form_helper
INFO - 2020-01-26 14:58:03 --> Helper loaded: my_helper
INFO - 2020-01-26 14:58:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:58:04 --> Controller Class Initialized
INFO - 2020-01-26 14:58:04 --> Helper loaded: cookie_helper
INFO - 2020-01-26 14:58:04 --> Final output sent to browser
DEBUG - 2020-01-26 14:58:04 --> Total execution time: 2.6755
INFO - 2020-01-26 14:58:05 --> Config Class Initialized
INFO - 2020-01-26 14:58:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:58:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:58:06 --> Utf8 Class Initialized
INFO - 2020-01-26 14:58:06 --> URI Class Initialized
INFO - 2020-01-26 14:58:06 --> Router Class Initialized
INFO - 2020-01-26 14:58:06 --> Output Class Initialized
INFO - 2020-01-26 14:58:06 --> Security Class Initialized
DEBUG - 2020-01-26 14:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:58:07 --> Input Class Initialized
INFO - 2020-01-26 14:58:07 --> Language Class Initialized
INFO - 2020-01-26 14:58:07 --> Language Class Initialized
INFO - 2020-01-26 14:58:07 --> Config Class Initialized
INFO - 2020-01-26 14:58:07 --> Loader Class Initialized
INFO - 2020-01-26 14:58:07 --> Helper loaded: url_helper
INFO - 2020-01-26 14:58:07 --> Helper loaded: file_helper
INFO - 2020-01-26 14:58:07 --> Helper loaded: form_helper
INFO - 2020-01-26 14:58:07 --> Helper loaded: my_helper
INFO - 2020-01-26 14:58:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:58:08 --> Controller Class Initialized
DEBUG - 2020-01-26 14:58:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 14:58:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:58:08 --> Final output sent to browser
DEBUG - 2020-01-26 14:58:08 --> Total execution time: 2.8191
INFO - 2020-01-26 14:58:14 --> Config Class Initialized
INFO - 2020-01-26 14:58:14 --> Hooks Class Initialized
DEBUG - 2020-01-26 14:58:14 --> UTF-8 Support Enabled
INFO - 2020-01-26 14:58:14 --> Utf8 Class Initialized
INFO - 2020-01-26 14:58:14 --> URI Class Initialized
INFO - 2020-01-26 14:58:14 --> Router Class Initialized
INFO - 2020-01-26 14:58:14 --> Output Class Initialized
INFO - 2020-01-26 14:58:14 --> Security Class Initialized
DEBUG - 2020-01-26 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 14:58:15 --> Input Class Initialized
INFO - 2020-01-26 14:58:15 --> Language Class Initialized
INFO - 2020-01-26 14:58:15 --> Language Class Initialized
INFO - 2020-01-26 14:58:15 --> Config Class Initialized
INFO - 2020-01-26 14:58:15 --> Loader Class Initialized
INFO - 2020-01-26 14:58:15 --> Helper loaded: url_helper
INFO - 2020-01-26 14:58:15 --> Helper loaded: file_helper
INFO - 2020-01-26 14:58:15 --> Helper loaded: form_helper
INFO - 2020-01-26 14:58:15 --> Helper loaded: my_helper
INFO - 2020-01-26 14:58:16 --> Database Driver Class Initialized
DEBUG - 2020-01-26 14:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 14:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 14:58:16 --> Controller Class Initialized
DEBUG - 2020-01-26 14:58:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 14:58:16 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 14:58:16 --> Final output sent to browser
DEBUG - 2020-01-26 14:58:16 --> Total execution time: 2.6696
INFO - 2020-01-26 15:00:04 --> Config Class Initialized
INFO - 2020-01-26 15:00:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:00:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:00:05 --> Utf8 Class Initialized
INFO - 2020-01-26 15:00:05 --> URI Class Initialized
INFO - 2020-01-26 15:00:05 --> Router Class Initialized
INFO - 2020-01-26 15:00:05 --> Output Class Initialized
INFO - 2020-01-26 15:00:05 --> Security Class Initialized
DEBUG - 2020-01-26 15:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:00:06 --> Input Class Initialized
INFO - 2020-01-26 15:00:06 --> Language Class Initialized
INFO - 2020-01-26 15:00:06 --> Language Class Initialized
INFO - 2020-01-26 15:00:06 --> Config Class Initialized
INFO - 2020-01-26 15:00:06 --> Loader Class Initialized
INFO - 2020-01-26 15:00:06 --> Helper loaded: url_helper
INFO - 2020-01-26 15:00:06 --> Helper loaded: file_helper
INFO - 2020-01-26 15:00:07 --> Helper loaded: form_helper
INFO - 2020-01-26 15:00:07 --> Helper loaded: my_helper
INFO - 2020-01-26 15:00:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:00:07 --> Controller Class Initialized
DEBUG - 2020-01-26 15:00:07 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:00:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:00:08 --> Final output sent to browser
DEBUG - 2020-01-26 15:00:08 --> Total execution time: 3.5099
INFO - 2020-01-26 15:00:09 --> Config Class Initialized
INFO - 2020-01-26 15:00:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:00:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:00:09 --> Utf8 Class Initialized
INFO - 2020-01-26 15:00:10 --> URI Class Initialized
INFO - 2020-01-26 15:00:10 --> Router Class Initialized
INFO - 2020-01-26 15:00:10 --> Output Class Initialized
INFO - 2020-01-26 15:00:10 --> Security Class Initialized
DEBUG - 2020-01-26 15:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:00:10 --> Input Class Initialized
INFO - 2020-01-26 15:00:10 --> Language Class Initialized
INFO - 2020-01-26 15:00:10 --> Language Class Initialized
INFO - 2020-01-26 15:00:11 --> Config Class Initialized
INFO - 2020-01-26 15:00:11 --> Loader Class Initialized
INFO - 2020-01-26 15:00:11 --> Helper loaded: url_helper
INFO - 2020-01-26 15:00:11 --> Helper loaded: file_helper
INFO - 2020-01-26 15:00:11 --> Helper loaded: form_helper
INFO - 2020-01-26 15:00:11 --> Helper loaded: my_helper
INFO - 2020-01-26 15:00:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:00:12 --> Controller Class Initialized
DEBUG - 2020-01-26 15:00:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:00:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:00:12 --> Final output sent to browser
DEBUG - 2020-01-26 15:00:12 --> Total execution time: 3.0602
INFO - 2020-01-26 15:00:19 --> Config Class Initialized
INFO - 2020-01-26 15:00:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:00:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:00:19 --> Utf8 Class Initialized
INFO - 2020-01-26 15:00:19 --> URI Class Initialized
INFO - 2020-01-26 15:00:19 --> Router Class Initialized
INFO - 2020-01-26 15:00:19 --> Output Class Initialized
INFO - 2020-01-26 15:00:20 --> Security Class Initialized
DEBUG - 2020-01-26 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:00:20 --> Input Class Initialized
INFO - 2020-01-26 15:00:20 --> Language Class Initialized
INFO - 2020-01-26 15:00:20 --> Language Class Initialized
INFO - 2020-01-26 15:00:20 --> Config Class Initialized
INFO - 2020-01-26 15:00:20 --> Loader Class Initialized
INFO - 2020-01-26 15:00:20 --> Helper loaded: url_helper
INFO - 2020-01-26 15:00:20 --> Helper loaded: file_helper
INFO - 2020-01-26 15:00:20 --> Helper loaded: form_helper
INFO - 2020-01-26 15:00:21 --> Helper loaded: my_helper
INFO - 2020-01-26 15:00:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:00:21 --> Controller Class Initialized
DEBUG - 2020-01-26 15:00:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-26 15:00:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:00:21 --> Final output sent to browser
DEBUG - 2020-01-26 15:00:21 --> Total execution time: 2.5576
INFO - 2020-01-26 15:00:22 --> Config Class Initialized
INFO - 2020-01-26 15:00:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:00:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:00:22 --> Utf8 Class Initialized
INFO - 2020-01-26 15:00:22 --> URI Class Initialized
INFO - 2020-01-26 15:00:22 --> Router Class Initialized
INFO - 2020-01-26 15:00:22 --> Output Class Initialized
INFO - 2020-01-26 15:00:22 --> Security Class Initialized
DEBUG - 2020-01-26 15:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:00:23 --> Input Class Initialized
INFO - 2020-01-26 15:00:23 --> Language Class Initialized
INFO - 2020-01-26 15:00:23 --> Language Class Initialized
INFO - 2020-01-26 15:00:23 --> Config Class Initialized
INFO - 2020-01-26 15:00:23 --> Loader Class Initialized
INFO - 2020-01-26 15:00:23 --> Helper loaded: url_helper
INFO - 2020-01-26 15:00:23 --> Helper loaded: file_helper
INFO - 2020-01-26 15:00:23 --> Helper loaded: form_helper
INFO - 2020-01-26 15:00:23 --> Helper loaded: my_helper
INFO - 2020-01-26 15:00:24 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:00:24 --> Controller Class Initialized
INFO - 2020-01-26 15:00:27 --> Config Class Initialized
INFO - 2020-01-26 15:00:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:00:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:00:27 --> Utf8 Class Initialized
INFO - 2020-01-26 15:00:27 --> URI Class Initialized
INFO - 2020-01-26 15:00:27 --> Router Class Initialized
INFO - 2020-01-26 15:00:27 --> Output Class Initialized
INFO - 2020-01-26 15:00:27 --> Security Class Initialized
DEBUG - 2020-01-26 15:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:00:28 --> Input Class Initialized
INFO - 2020-01-26 15:00:28 --> Language Class Initialized
INFO - 2020-01-26 15:00:28 --> Language Class Initialized
INFO - 2020-01-26 15:00:28 --> Config Class Initialized
INFO - 2020-01-26 15:00:28 --> Loader Class Initialized
INFO - 2020-01-26 15:00:28 --> Helper loaded: url_helper
INFO - 2020-01-26 15:00:28 --> Helper loaded: file_helper
INFO - 2020-01-26 15:00:28 --> Helper loaded: form_helper
INFO - 2020-01-26 15:00:28 --> Helper loaded: my_helper
INFO - 2020-01-26 15:00:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:00:29 --> Controller Class Initialized
INFO - 2020-01-26 15:00:29 --> Final output sent to browser
DEBUG - 2020-01-26 15:00:29 --> Total execution time: 2.2302
INFO - 2020-01-26 15:01:02 --> Config Class Initialized
INFO - 2020-01-26 15:01:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:01:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:01:02 --> Utf8 Class Initialized
INFO - 2020-01-26 15:01:02 --> URI Class Initialized
INFO - 2020-01-26 15:01:02 --> Router Class Initialized
INFO - 2020-01-26 15:01:02 --> Output Class Initialized
INFO - 2020-01-26 15:01:02 --> Security Class Initialized
DEBUG - 2020-01-26 15:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:01:03 --> Input Class Initialized
INFO - 2020-01-26 15:01:03 --> Language Class Initialized
INFO - 2020-01-26 15:01:03 --> Language Class Initialized
INFO - 2020-01-26 15:01:03 --> Config Class Initialized
INFO - 2020-01-26 15:01:03 --> Loader Class Initialized
INFO - 2020-01-26 15:01:03 --> Helper loaded: url_helper
INFO - 2020-01-26 15:01:03 --> Helper loaded: file_helper
INFO - 2020-01-26 15:01:03 --> Helper loaded: form_helper
INFO - 2020-01-26 15:01:03 --> Helper loaded: my_helper
INFO - 2020-01-26 15:01:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:01:04 --> Controller Class Initialized
INFO - 2020-01-26 15:01:04 --> Final output sent to browser
DEBUG - 2020-01-26 15:01:04 --> Total execution time: 2.2722
INFO - 2020-01-26 15:01:04 --> Config Class Initialized
INFO - 2020-01-26 15:01:04 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:01:04 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:01:05 --> Utf8 Class Initialized
INFO - 2020-01-26 15:01:05 --> URI Class Initialized
INFO - 2020-01-26 15:01:05 --> Router Class Initialized
INFO - 2020-01-26 15:01:05 --> Output Class Initialized
INFO - 2020-01-26 15:01:05 --> Security Class Initialized
DEBUG - 2020-01-26 15:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:01:05 --> Input Class Initialized
INFO - 2020-01-26 15:01:05 --> Language Class Initialized
INFO - 2020-01-26 15:01:06 --> Language Class Initialized
INFO - 2020-01-26 15:01:06 --> Config Class Initialized
INFO - 2020-01-26 15:01:06 --> Loader Class Initialized
INFO - 2020-01-26 15:01:06 --> Helper loaded: url_helper
INFO - 2020-01-26 15:01:06 --> Helper loaded: file_helper
INFO - 2020-01-26 15:01:06 --> Helper loaded: form_helper
INFO - 2020-01-26 15:01:06 --> Helper loaded: my_helper
INFO - 2020-01-26 15:01:06 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:01:07 --> Controller Class Initialized
INFO - 2020-01-26 15:01:23 --> Config Class Initialized
INFO - 2020-01-26 15:01:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:01:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:01:23 --> Utf8 Class Initialized
INFO - 2020-01-26 15:01:23 --> URI Class Initialized
INFO - 2020-01-26 15:01:23 --> Router Class Initialized
INFO - 2020-01-26 15:01:23 --> Output Class Initialized
INFO - 2020-01-26 15:01:23 --> Security Class Initialized
DEBUG - 2020-01-26 15:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:01:23 --> Input Class Initialized
INFO - 2020-01-26 15:01:23 --> Language Class Initialized
INFO - 2020-01-26 15:01:24 --> Language Class Initialized
INFO - 2020-01-26 15:01:24 --> Config Class Initialized
INFO - 2020-01-26 15:01:24 --> Loader Class Initialized
INFO - 2020-01-26 15:01:24 --> Helper loaded: url_helper
INFO - 2020-01-26 15:01:24 --> Helper loaded: file_helper
INFO - 2020-01-26 15:01:24 --> Helper loaded: form_helper
INFO - 2020-01-26 15:01:24 --> Helper loaded: my_helper
INFO - 2020-01-26 15:01:24 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:01:25 --> Controller Class Initialized
INFO - 2020-01-26 15:01:25 --> Final output sent to browser
DEBUG - 2020-01-26 15:01:25 --> Total execution time: 2.1406
INFO - 2020-01-26 15:01:45 --> Config Class Initialized
INFO - 2020-01-26 15:01:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:01:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:01:45 --> Utf8 Class Initialized
INFO - 2020-01-26 15:01:45 --> URI Class Initialized
INFO - 2020-01-26 15:01:45 --> Router Class Initialized
INFO - 2020-01-26 15:01:46 --> Output Class Initialized
INFO - 2020-01-26 15:01:46 --> Security Class Initialized
DEBUG - 2020-01-26 15:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:01:46 --> Input Class Initialized
INFO - 2020-01-26 15:01:46 --> Language Class Initialized
INFO - 2020-01-26 15:01:46 --> Language Class Initialized
INFO - 2020-01-26 15:01:46 --> Config Class Initialized
INFO - 2020-01-26 15:01:46 --> Loader Class Initialized
INFO - 2020-01-26 15:01:46 --> Helper loaded: url_helper
INFO - 2020-01-26 15:01:47 --> Helper loaded: file_helper
INFO - 2020-01-26 15:01:47 --> Helper loaded: form_helper
INFO - 2020-01-26 15:01:47 --> Helper loaded: my_helper
INFO - 2020-01-26 15:01:47 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:01:47 --> Controller Class Initialized
INFO - 2020-01-26 15:01:47 --> Final output sent to browser
DEBUG - 2020-01-26 15:01:47 --> Total execution time: 2.3289
INFO - 2020-01-26 15:01:52 --> Config Class Initialized
INFO - 2020-01-26 15:01:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:01:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:01:52 --> Utf8 Class Initialized
INFO - 2020-01-26 15:01:52 --> URI Class Initialized
INFO - 2020-01-26 15:01:52 --> Router Class Initialized
INFO - 2020-01-26 15:01:52 --> Output Class Initialized
INFO - 2020-01-26 15:01:52 --> Security Class Initialized
DEBUG - 2020-01-26 15:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:01:52 --> Input Class Initialized
INFO - 2020-01-26 15:01:53 --> Language Class Initialized
INFO - 2020-01-26 15:01:53 --> Language Class Initialized
INFO - 2020-01-26 15:01:53 --> Config Class Initialized
INFO - 2020-01-26 15:01:53 --> Loader Class Initialized
INFO - 2020-01-26 15:01:53 --> Helper loaded: url_helper
INFO - 2020-01-26 15:01:53 --> Helper loaded: file_helper
INFO - 2020-01-26 15:01:53 --> Helper loaded: form_helper
INFO - 2020-01-26 15:01:53 --> Helper loaded: my_helper
INFO - 2020-01-26 15:01:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:01:54 --> Controller Class Initialized
INFO - 2020-01-26 15:01:54 --> Final output sent to browser
DEBUG - 2020-01-26 15:01:54 --> Total execution time: 2.4102
INFO - 2020-01-26 15:02:35 --> Config Class Initialized
INFO - 2020-01-26 15:02:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:02:36 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:02:36 --> Utf8 Class Initialized
INFO - 2020-01-26 15:02:36 --> URI Class Initialized
INFO - 2020-01-26 15:02:36 --> Router Class Initialized
INFO - 2020-01-26 15:02:36 --> Output Class Initialized
INFO - 2020-01-26 15:02:36 --> Security Class Initialized
DEBUG - 2020-01-26 15:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:02:36 --> Input Class Initialized
INFO - 2020-01-26 15:02:36 --> Language Class Initialized
INFO - 2020-01-26 15:02:36 --> Language Class Initialized
INFO - 2020-01-26 15:02:36 --> Config Class Initialized
INFO - 2020-01-26 15:02:37 --> Loader Class Initialized
INFO - 2020-01-26 15:02:37 --> Helper loaded: url_helper
INFO - 2020-01-26 15:02:37 --> Helper loaded: file_helper
INFO - 2020-01-26 15:02:37 --> Helper loaded: form_helper
INFO - 2020-01-26 15:02:37 --> Helper loaded: my_helper
INFO - 2020-01-26 15:02:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:02:37 --> Controller Class Initialized
INFO - 2020-01-26 15:02:37 --> Final output sent to browser
DEBUG - 2020-01-26 15:02:38 --> Total execution time: 2.1379
INFO - 2020-01-26 15:02:38 --> Config Class Initialized
INFO - 2020-01-26 15:02:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:02:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:02:38 --> Utf8 Class Initialized
INFO - 2020-01-26 15:02:38 --> URI Class Initialized
INFO - 2020-01-26 15:02:38 --> Router Class Initialized
INFO - 2020-01-26 15:02:38 --> Output Class Initialized
INFO - 2020-01-26 15:02:38 --> Security Class Initialized
DEBUG - 2020-01-26 15:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:02:39 --> Input Class Initialized
INFO - 2020-01-26 15:02:39 --> Language Class Initialized
INFO - 2020-01-26 15:02:39 --> Language Class Initialized
INFO - 2020-01-26 15:02:39 --> Config Class Initialized
INFO - 2020-01-26 15:02:39 --> Loader Class Initialized
INFO - 2020-01-26 15:02:39 --> Helper loaded: url_helper
INFO - 2020-01-26 15:02:39 --> Helper loaded: file_helper
INFO - 2020-01-26 15:02:39 --> Helper loaded: form_helper
INFO - 2020-01-26 15:02:39 --> Helper loaded: my_helper
INFO - 2020-01-26 15:02:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:02:40 --> Controller Class Initialized
INFO - 2020-01-26 15:02:43 --> Config Class Initialized
INFO - 2020-01-26 15:02:43 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:02:44 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:02:44 --> Utf8 Class Initialized
INFO - 2020-01-26 15:02:44 --> URI Class Initialized
INFO - 2020-01-26 15:02:44 --> Router Class Initialized
INFO - 2020-01-26 15:02:44 --> Output Class Initialized
INFO - 2020-01-26 15:02:44 --> Security Class Initialized
DEBUG - 2020-01-26 15:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:02:44 --> Input Class Initialized
INFO - 2020-01-26 15:02:44 --> Language Class Initialized
INFO - 2020-01-26 15:02:44 --> Language Class Initialized
INFO - 2020-01-26 15:02:45 --> Config Class Initialized
INFO - 2020-01-26 15:02:45 --> Loader Class Initialized
INFO - 2020-01-26 15:02:45 --> Helper loaded: url_helper
INFO - 2020-01-26 15:02:45 --> Helper loaded: file_helper
INFO - 2020-01-26 15:02:45 --> Helper loaded: form_helper
INFO - 2020-01-26 15:02:45 --> Helper loaded: my_helper
INFO - 2020-01-26 15:02:45 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:02:45 --> Controller Class Initialized
INFO - 2020-01-26 15:02:46 --> Final output sent to browser
DEBUG - 2020-01-26 15:02:46 --> Total execution time: 2.2090
INFO - 2020-01-26 15:02:47 --> Config Class Initialized
INFO - 2020-01-26 15:02:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:02:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:02:47 --> Utf8 Class Initialized
INFO - 2020-01-26 15:02:47 --> URI Class Initialized
INFO - 2020-01-26 15:02:47 --> Router Class Initialized
INFO - 2020-01-26 15:02:47 --> Output Class Initialized
INFO - 2020-01-26 15:02:47 --> Security Class Initialized
DEBUG - 2020-01-26 15:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:02:48 --> Input Class Initialized
INFO - 2020-01-26 15:02:48 --> Language Class Initialized
INFO - 2020-01-26 15:02:48 --> Language Class Initialized
INFO - 2020-01-26 15:02:48 --> Config Class Initialized
INFO - 2020-01-26 15:02:48 --> Loader Class Initialized
INFO - 2020-01-26 15:02:48 --> Helper loaded: url_helper
INFO - 2020-01-26 15:02:48 --> Helper loaded: file_helper
INFO - 2020-01-26 15:02:48 --> Helper loaded: form_helper
INFO - 2020-01-26 15:02:48 --> Helper loaded: my_helper
INFO - 2020-01-26 15:02:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:02:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:02:49 --> Controller Class Initialized
INFO - 2020-01-26 15:02:49 --> Final output sent to browser
DEBUG - 2020-01-26 15:02:49 --> Total execution time: 2.1329
INFO - 2020-01-26 15:02:55 --> Config Class Initialized
INFO - 2020-01-26 15:02:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:02:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:02:55 --> Utf8 Class Initialized
INFO - 2020-01-26 15:02:55 --> URI Class Initialized
INFO - 2020-01-26 15:02:55 --> Router Class Initialized
INFO - 2020-01-26 15:02:55 --> Output Class Initialized
INFO - 2020-01-26 15:02:55 --> Security Class Initialized
DEBUG - 2020-01-26 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:02:56 --> Input Class Initialized
INFO - 2020-01-26 15:02:56 --> Language Class Initialized
INFO - 2020-01-26 15:02:56 --> Language Class Initialized
INFO - 2020-01-26 15:02:56 --> Config Class Initialized
INFO - 2020-01-26 15:02:56 --> Loader Class Initialized
INFO - 2020-01-26 15:02:56 --> Helper loaded: url_helper
INFO - 2020-01-26 15:02:56 --> Helper loaded: file_helper
INFO - 2020-01-26 15:02:56 --> Helper loaded: form_helper
INFO - 2020-01-26 15:02:56 --> Helper loaded: my_helper
INFO - 2020-01-26 15:02:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:02:57 --> Controller Class Initialized
DEBUG - 2020-01-26 15:02:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 15:02:57 --> Final output sent to browser
DEBUG - 2020-01-26 15:02:57 --> Total execution time: 2.5368
INFO - 2020-01-26 15:03:27 --> Config Class Initialized
INFO - 2020-01-26 15:03:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:03:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:03:27 --> Utf8 Class Initialized
INFO - 2020-01-26 15:03:27 --> URI Class Initialized
INFO - 2020-01-26 15:03:27 --> Router Class Initialized
INFO - 2020-01-26 15:03:27 --> Output Class Initialized
INFO - 2020-01-26 15:03:27 --> Security Class Initialized
DEBUG - 2020-01-26 15:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:03:28 --> Input Class Initialized
INFO - 2020-01-26 15:03:28 --> Language Class Initialized
INFO - 2020-01-26 15:03:28 --> Language Class Initialized
INFO - 2020-01-26 15:03:28 --> Config Class Initialized
INFO - 2020-01-26 15:03:28 --> Loader Class Initialized
INFO - 2020-01-26 15:03:28 --> Helper loaded: url_helper
INFO - 2020-01-26 15:03:28 --> Helper loaded: file_helper
INFO - 2020-01-26 15:03:28 --> Helper loaded: form_helper
INFO - 2020-01-26 15:03:28 --> Helper loaded: my_helper
INFO - 2020-01-26 15:03:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:03:29 --> Controller Class Initialized
INFO - 2020-01-26 15:03:29 --> Final output sent to browser
DEBUG - 2020-01-26 15:03:29 --> Total execution time: 2.1779
INFO - 2020-01-26 15:04:00 --> Config Class Initialized
INFO - 2020-01-26 15:04:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:04:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:04:01 --> Utf8 Class Initialized
INFO - 2020-01-26 15:04:01 --> URI Class Initialized
INFO - 2020-01-26 15:04:01 --> Router Class Initialized
INFO - 2020-01-26 15:04:01 --> Output Class Initialized
INFO - 2020-01-26 15:04:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:04:01 --> Input Class Initialized
INFO - 2020-01-26 15:04:01 --> Language Class Initialized
INFO - 2020-01-26 15:04:01 --> Language Class Initialized
INFO - 2020-01-26 15:04:02 --> Config Class Initialized
INFO - 2020-01-26 15:04:02 --> Loader Class Initialized
INFO - 2020-01-26 15:04:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:04:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:04:02 --> Helper loaded: form_helper
INFO - 2020-01-26 15:04:02 --> Helper loaded: my_helper
INFO - 2020-01-26 15:04:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:04:03 --> Controller Class Initialized
INFO - 2020-01-26 15:04:03 --> Final output sent to browser
DEBUG - 2020-01-26 15:04:03 --> Total execution time: 2.6058
INFO - 2020-01-26 15:04:05 --> Config Class Initialized
INFO - 2020-01-26 15:04:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:04:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:04:05 --> Utf8 Class Initialized
INFO - 2020-01-26 15:04:05 --> URI Class Initialized
INFO - 2020-01-26 15:04:05 --> Router Class Initialized
INFO - 2020-01-26 15:04:06 --> Output Class Initialized
INFO - 2020-01-26 15:04:06 --> Security Class Initialized
DEBUG - 2020-01-26 15:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:04:06 --> Input Class Initialized
INFO - 2020-01-26 15:04:06 --> Language Class Initialized
INFO - 2020-01-26 15:04:06 --> Language Class Initialized
INFO - 2020-01-26 15:04:06 --> Config Class Initialized
INFO - 2020-01-26 15:04:06 --> Loader Class Initialized
INFO - 2020-01-26 15:04:07 --> Helper loaded: url_helper
INFO - 2020-01-26 15:04:07 --> Helper loaded: file_helper
INFO - 2020-01-26 15:04:07 --> Helper loaded: form_helper
INFO - 2020-01-26 15:04:07 --> Helper loaded: my_helper
INFO - 2020-01-26 15:04:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:04:07 --> Controller Class Initialized
INFO - 2020-01-26 15:04:08 --> Final output sent to browser
DEBUG - 2020-01-26 15:04:08 --> Total execution time: 2.6672
INFO - 2020-01-26 15:04:35 --> Config Class Initialized
INFO - 2020-01-26 15:04:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:04:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:04:35 --> Utf8 Class Initialized
INFO - 2020-01-26 15:04:35 --> URI Class Initialized
INFO - 2020-01-26 15:04:35 --> Router Class Initialized
INFO - 2020-01-26 15:04:35 --> Output Class Initialized
INFO - 2020-01-26 15:04:35 --> Security Class Initialized
DEBUG - 2020-01-26 15:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:04:35 --> Input Class Initialized
INFO - 2020-01-26 15:04:36 --> Language Class Initialized
INFO - 2020-01-26 15:04:36 --> Language Class Initialized
INFO - 2020-01-26 15:04:36 --> Config Class Initialized
INFO - 2020-01-26 15:04:36 --> Loader Class Initialized
INFO - 2020-01-26 15:04:36 --> Helper loaded: url_helper
INFO - 2020-01-26 15:04:36 --> Helper loaded: file_helper
INFO - 2020-01-26 15:04:36 --> Helper loaded: form_helper
INFO - 2020-01-26 15:04:36 --> Helper loaded: my_helper
INFO - 2020-01-26 15:04:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:04:37 --> Controller Class Initialized
INFO - 2020-01-26 15:04:37 --> Final output sent to browser
DEBUG - 2020-01-26 15:04:37 --> Total execution time: 2.3399
INFO - 2020-01-26 15:04:40 --> Config Class Initialized
INFO - 2020-01-26 15:04:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:04:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:04:40 --> Utf8 Class Initialized
INFO - 2020-01-26 15:04:41 --> URI Class Initialized
INFO - 2020-01-26 15:04:41 --> Router Class Initialized
INFO - 2020-01-26 15:04:41 --> Output Class Initialized
INFO - 2020-01-26 15:04:41 --> Security Class Initialized
DEBUG - 2020-01-26 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:04:41 --> Input Class Initialized
INFO - 2020-01-26 15:04:41 --> Language Class Initialized
INFO - 2020-01-26 15:04:41 --> Language Class Initialized
INFO - 2020-01-26 15:04:41 --> Config Class Initialized
INFO - 2020-01-26 15:04:42 --> Loader Class Initialized
INFO - 2020-01-26 15:04:42 --> Helper loaded: url_helper
INFO - 2020-01-26 15:04:42 --> Helper loaded: file_helper
INFO - 2020-01-26 15:04:42 --> Helper loaded: form_helper
INFO - 2020-01-26 15:04:42 --> Helper loaded: my_helper
INFO - 2020-01-26 15:04:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:04:42 --> Controller Class Initialized
DEBUG - 2020-01-26 15:04:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 15:04:43 --> Final output sent to browser
DEBUG - 2020-01-26 15:04:43 --> Total execution time: 2.6236
INFO - 2020-01-26 15:04:56 --> Config Class Initialized
INFO - 2020-01-26 15:04:56 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:04:56 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:04:56 --> Utf8 Class Initialized
INFO - 2020-01-26 15:04:56 --> URI Class Initialized
INFO - 2020-01-26 15:04:57 --> Router Class Initialized
INFO - 2020-01-26 15:04:57 --> Output Class Initialized
INFO - 2020-01-26 15:04:57 --> Security Class Initialized
DEBUG - 2020-01-26 15:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:04:57 --> Input Class Initialized
INFO - 2020-01-26 15:04:57 --> Language Class Initialized
INFO - 2020-01-26 15:04:57 --> Language Class Initialized
INFO - 2020-01-26 15:04:57 --> Config Class Initialized
INFO - 2020-01-26 15:04:57 --> Loader Class Initialized
INFO - 2020-01-26 15:04:57 --> Helper loaded: url_helper
INFO - 2020-01-26 15:04:58 --> Helper loaded: file_helper
INFO - 2020-01-26 15:04:58 --> Helper loaded: form_helper
INFO - 2020-01-26 15:04:58 --> Helper loaded: my_helper
INFO - 2020-01-26 15:04:58 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:04:58 --> Controller Class Initialized
INFO - 2020-01-26 15:04:58 --> Final output sent to browser
DEBUG - 2020-01-26 15:04:58 --> Total execution time: 2.1755
INFO - 2020-01-26 15:05:00 --> Config Class Initialized
INFO - 2020-01-26 15:05:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:05:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:05:00 --> Utf8 Class Initialized
INFO - 2020-01-26 15:05:00 --> URI Class Initialized
INFO - 2020-01-26 15:05:00 --> Router Class Initialized
INFO - 2020-01-26 15:05:00 --> Output Class Initialized
INFO - 2020-01-26 15:05:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:05:01 --> Input Class Initialized
INFO - 2020-01-26 15:05:01 --> Language Class Initialized
INFO - 2020-01-26 15:05:01 --> Language Class Initialized
INFO - 2020-01-26 15:05:01 --> Config Class Initialized
INFO - 2020-01-26 15:05:01 --> Loader Class Initialized
INFO - 2020-01-26 15:05:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:05:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:05:02 --> Helper loaded: form_helper
INFO - 2020-01-26 15:05:02 --> Helper loaded: my_helper
INFO - 2020-01-26 15:05:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:05:03 --> Controller Class Initialized
DEBUG - 2020-01-26 15:05:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 15:05:03 --> Final output sent to browser
DEBUG - 2020-01-26 15:05:03 --> Total execution time: 3.3846
INFO - 2020-01-26 15:05:23 --> Config Class Initialized
INFO - 2020-01-26 15:05:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:05:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:05:24 --> Utf8 Class Initialized
INFO - 2020-01-26 15:05:24 --> URI Class Initialized
INFO - 2020-01-26 15:05:24 --> Router Class Initialized
INFO - 2020-01-26 15:05:24 --> Output Class Initialized
INFO - 2020-01-26 15:05:24 --> Security Class Initialized
DEBUG - 2020-01-26 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:05:24 --> Input Class Initialized
INFO - 2020-01-26 15:05:24 --> Language Class Initialized
INFO - 2020-01-26 15:05:25 --> Language Class Initialized
INFO - 2020-01-26 15:05:25 --> Config Class Initialized
INFO - 2020-01-26 15:05:25 --> Loader Class Initialized
INFO - 2020-01-26 15:05:25 --> Helper loaded: url_helper
INFO - 2020-01-26 15:05:25 --> Helper loaded: file_helper
INFO - 2020-01-26 15:05:25 --> Helper loaded: form_helper
INFO - 2020-01-26 15:05:25 --> Helper loaded: my_helper
INFO - 2020-01-26 15:05:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:05:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:05:26 --> Controller Class Initialized
INFO - 2020-01-26 15:05:26 --> Final output sent to browser
DEBUG - 2020-01-26 15:05:26 --> Total execution time: 2.2298
INFO - 2020-01-26 15:05:27 --> Config Class Initialized
INFO - 2020-01-26 15:05:27 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:05:27 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:05:27 --> Utf8 Class Initialized
INFO - 2020-01-26 15:05:27 --> URI Class Initialized
INFO - 2020-01-26 15:05:27 --> Router Class Initialized
INFO - 2020-01-26 15:05:27 --> Output Class Initialized
INFO - 2020-01-26 15:05:27 --> Security Class Initialized
DEBUG - 2020-01-26 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:05:27 --> Input Class Initialized
INFO - 2020-01-26 15:05:28 --> Language Class Initialized
INFO - 2020-01-26 15:05:28 --> Language Class Initialized
INFO - 2020-01-26 15:05:28 --> Config Class Initialized
INFO - 2020-01-26 15:05:28 --> Loader Class Initialized
INFO - 2020-01-26 15:05:28 --> Helper loaded: url_helper
INFO - 2020-01-26 15:05:28 --> Helper loaded: file_helper
INFO - 2020-01-26 15:05:28 --> Helper loaded: form_helper
INFO - 2020-01-26 15:05:28 --> Helper loaded: my_helper
INFO - 2020-01-26 15:05:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:05:29 --> Controller Class Initialized
INFO - 2020-01-26 15:05:29 --> Final output sent to browser
DEBUG - 2020-01-26 15:05:29 --> Total execution time: 2.2060
INFO - 2020-01-26 15:05:34 --> Config Class Initialized
INFO - 2020-01-26 15:05:34 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:05:34 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:05:34 --> Utf8 Class Initialized
INFO - 2020-01-26 15:05:34 --> URI Class Initialized
INFO - 2020-01-26 15:05:34 --> Router Class Initialized
INFO - 2020-01-26 15:05:35 --> Output Class Initialized
INFO - 2020-01-26 15:05:35 --> Security Class Initialized
DEBUG - 2020-01-26 15:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:05:35 --> Input Class Initialized
INFO - 2020-01-26 15:05:35 --> Language Class Initialized
INFO - 2020-01-26 15:05:35 --> Language Class Initialized
INFO - 2020-01-26 15:05:35 --> Config Class Initialized
INFO - 2020-01-26 15:05:35 --> Loader Class Initialized
INFO - 2020-01-26 15:05:35 --> Helper loaded: url_helper
INFO - 2020-01-26 15:05:35 --> Helper loaded: file_helper
INFO - 2020-01-26 15:05:36 --> Helper loaded: form_helper
INFO - 2020-01-26 15:05:36 --> Helper loaded: my_helper
INFO - 2020-01-26 15:05:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:05:36 --> Controller Class Initialized
INFO - 2020-01-26 15:05:36 --> Final output sent to browser
DEBUG - 2020-01-26 15:05:36 --> Total execution time: 2.3445
INFO - 2020-01-26 15:05:38 --> Config Class Initialized
INFO - 2020-01-26 15:05:38 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:05:38 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:05:38 --> Utf8 Class Initialized
INFO - 2020-01-26 15:05:38 --> URI Class Initialized
INFO - 2020-01-26 15:05:38 --> Router Class Initialized
INFO - 2020-01-26 15:05:38 --> Output Class Initialized
INFO - 2020-01-26 15:05:38 --> Security Class Initialized
DEBUG - 2020-01-26 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:05:39 --> Input Class Initialized
INFO - 2020-01-26 15:05:39 --> Language Class Initialized
INFO - 2020-01-26 15:05:39 --> Language Class Initialized
INFO - 2020-01-26 15:05:39 --> Config Class Initialized
INFO - 2020-01-26 15:05:39 --> Loader Class Initialized
INFO - 2020-01-26 15:05:39 --> Helper loaded: url_helper
INFO - 2020-01-26 15:05:39 --> Helper loaded: file_helper
INFO - 2020-01-26 15:05:39 --> Helper loaded: form_helper
INFO - 2020-01-26 15:05:40 --> Helper loaded: my_helper
INFO - 2020-01-26 15:05:40 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:05:40 --> Controller Class Initialized
DEBUG - 2020-01-26 15:05:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 15:05:40 --> Final output sent to browser
DEBUG - 2020-01-26 15:05:40 --> Total execution time: 2.6287
INFO - 2020-01-26 15:28:21 --> Config Class Initialized
INFO - 2020-01-26 15:28:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:21 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:21 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:21 --> URI Class Initialized
INFO - 2020-01-26 15:28:22 --> Router Class Initialized
INFO - 2020-01-26 15:28:22 --> Output Class Initialized
INFO - 2020-01-26 15:28:22 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:22 --> Input Class Initialized
INFO - 2020-01-26 15:28:22 --> Language Class Initialized
INFO - 2020-01-26 15:28:22 --> Language Class Initialized
INFO - 2020-01-26 15:28:22 --> Config Class Initialized
INFO - 2020-01-26 15:28:22 --> Loader Class Initialized
INFO - 2020-01-26 15:28:23 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:23 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:23 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:23 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:23 --> Controller Class Initialized
INFO - 2020-01-26 15:28:24 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:28:24 --> Config Class Initialized
INFO - 2020-01-26 15:28:24 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:24 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:24 --> URI Class Initialized
INFO - 2020-01-26 15:28:24 --> Router Class Initialized
INFO - 2020-01-26 15:28:24 --> Output Class Initialized
INFO - 2020-01-26 15:28:24 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:25 --> Input Class Initialized
INFO - 2020-01-26 15:28:25 --> Language Class Initialized
INFO - 2020-01-26 15:28:25 --> Language Class Initialized
INFO - 2020-01-26 15:28:25 --> Config Class Initialized
INFO - 2020-01-26 15:28:25 --> Loader Class Initialized
INFO - 2020-01-26 15:28:25 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:25 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:25 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:26 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:26 --> Controller Class Initialized
INFO - 2020-01-26 15:28:26 --> Config Class Initialized
INFO - 2020-01-26 15:28:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:26 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:27 --> URI Class Initialized
INFO - 2020-01-26 15:28:27 --> Router Class Initialized
INFO - 2020-01-26 15:28:27 --> Output Class Initialized
INFO - 2020-01-26 15:28:27 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:27 --> Input Class Initialized
INFO - 2020-01-26 15:28:27 --> Language Class Initialized
INFO - 2020-01-26 15:28:27 --> Language Class Initialized
INFO - 2020-01-26 15:28:27 --> Config Class Initialized
INFO - 2020-01-26 15:28:28 --> Loader Class Initialized
INFO - 2020-01-26 15:28:28 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:28 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:28 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:28 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:28 --> Controller Class Initialized
DEBUG - 2020-01-26 15:28:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 15:28:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:28:29 --> Final output sent to browser
DEBUG - 2020-01-26 15:28:29 --> Total execution time: 2.6399
INFO - 2020-01-26 15:28:37 --> Config Class Initialized
INFO - 2020-01-26 15:28:37 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:37 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:37 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:37 --> URI Class Initialized
INFO - 2020-01-26 15:28:37 --> Router Class Initialized
INFO - 2020-01-26 15:28:38 --> Output Class Initialized
INFO - 2020-01-26 15:28:38 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:38 --> Input Class Initialized
INFO - 2020-01-26 15:28:38 --> Language Class Initialized
INFO - 2020-01-26 15:28:38 --> Language Class Initialized
INFO - 2020-01-26 15:28:38 --> Config Class Initialized
INFO - 2020-01-26 15:28:38 --> Loader Class Initialized
INFO - 2020-01-26 15:28:38 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:39 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:39 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:39 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:39 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:39 --> Controller Class Initialized
INFO - 2020-01-26 15:28:39 --> Final output sent to browser
DEBUG - 2020-01-26 15:28:39 --> Total execution time: 2.3922
INFO - 2020-01-26 15:28:47 --> Config Class Initialized
INFO - 2020-01-26 15:28:47 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:47 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:47 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:47 --> URI Class Initialized
INFO - 2020-01-26 15:28:47 --> Router Class Initialized
INFO - 2020-01-26 15:28:47 --> Output Class Initialized
INFO - 2020-01-26 15:28:48 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:48 --> Input Class Initialized
INFO - 2020-01-26 15:28:48 --> Language Class Initialized
INFO - 2020-01-26 15:28:48 --> Language Class Initialized
INFO - 2020-01-26 15:28:48 --> Config Class Initialized
INFO - 2020-01-26 15:28:48 --> Loader Class Initialized
INFO - 2020-01-26 15:28:48 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:48 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:48 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:49 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:49 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:49 --> Controller Class Initialized
INFO - 2020-01-26 15:28:49 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:28:49 --> Final output sent to browser
DEBUG - 2020-01-26 15:28:49 --> Total execution time: 2.4582
INFO - 2020-01-26 15:28:51 --> Config Class Initialized
INFO - 2020-01-26 15:28:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:52 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:52 --> URI Class Initialized
INFO - 2020-01-26 15:28:52 --> Router Class Initialized
INFO - 2020-01-26 15:28:52 --> Output Class Initialized
INFO - 2020-01-26 15:28:52 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:52 --> Input Class Initialized
INFO - 2020-01-26 15:28:53 --> Language Class Initialized
INFO - 2020-01-26 15:28:53 --> Language Class Initialized
INFO - 2020-01-26 15:28:53 --> Config Class Initialized
INFO - 2020-01-26 15:28:53 --> Loader Class Initialized
INFO - 2020-01-26 15:28:53 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:53 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:53 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:53 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:54 --> Controller Class Initialized
DEBUG - 2020-01-26 15:28:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 15:28:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:28:54 --> Final output sent to browser
DEBUG - 2020-01-26 15:28:54 --> Total execution time: 3.0526
INFO - 2020-01-26 15:28:57 --> Config Class Initialized
INFO - 2020-01-26 15:28:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:28:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:28:57 --> Utf8 Class Initialized
INFO - 2020-01-26 15:28:57 --> URI Class Initialized
INFO - 2020-01-26 15:28:58 --> Router Class Initialized
INFO - 2020-01-26 15:28:58 --> Output Class Initialized
INFO - 2020-01-26 15:28:58 --> Security Class Initialized
DEBUG - 2020-01-26 15:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:28:58 --> Input Class Initialized
INFO - 2020-01-26 15:28:58 --> Language Class Initialized
INFO - 2020-01-26 15:28:58 --> Language Class Initialized
INFO - 2020-01-26 15:28:58 --> Config Class Initialized
INFO - 2020-01-26 15:28:58 --> Loader Class Initialized
INFO - 2020-01-26 15:28:59 --> Helper loaded: url_helper
INFO - 2020-01-26 15:28:59 --> Helper loaded: file_helper
INFO - 2020-01-26 15:28:59 --> Helper loaded: form_helper
INFO - 2020-01-26 15:28:59 --> Helper loaded: my_helper
INFO - 2020-01-26 15:28:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:28:59 --> Controller Class Initialized
DEBUG - 2020-01-26 15:28:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-01-26 15:29:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:29:00 --> Final output sent to browser
DEBUG - 2020-01-26 15:29:00 --> Total execution time: 2.8058
INFO - 2020-01-26 15:29:12 --> Config Class Initialized
INFO - 2020-01-26 15:29:12 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:29:12 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:29:12 --> Utf8 Class Initialized
INFO - 2020-01-26 15:29:12 --> URI Class Initialized
INFO - 2020-01-26 15:29:12 --> Router Class Initialized
INFO - 2020-01-26 15:29:12 --> Output Class Initialized
INFO - 2020-01-26 15:29:12 --> Security Class Initialized
DEBUG - 2020-01-26 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:29:13 --> Input Class Initialized
INFO - 2020-01-26 15:29:13 --> Language Class Initialized
INFO - 2020-01-26 15:29:13 --> Language Class Initialized
INFO - 2020-01-26 15:29:13 --> Config Class Initialized
INFO - 2020-01-26 15:29:13 --> Loader Class Initialized
INFO - 2020-01-26 15:29:13 --> Helper loaded: url_helper
INFO - 2020-01-26 15:29:13 --> Helper loaded: file_helper
INFO - 2020-01-26 15:29:13 --> Helper loaded: form_helper
INFO - 2020-01-26 15:29:14 --> Helper loaded: my_helper
INFO - 2020-01-26 15:29:14 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:29:14 --> Controller Class Initialized
INFO - 2020-01-26 15:29:31 --> Config Class Initialized
INFO - 2020-01-26 15:29:31 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:29:31 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:29:31 --> Utf8 Class Initialized
INFO - 2020-01-26 15:29:31 --> URI Class Initialized
INFO - 2020-01-26 15:29:31 --> Router Class Initialized
INFO - 2020-01-26 15:29:31 --> Output Class Initialized
INFO - 2020-01-26 15:29:32 --> Security Class Initialized
DEBUG - 2020-01-26 15:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:29:32 --> Input Class Initialized
INFO - 2020-01-26 15:29:32 --> Language Class Initialized
INFO - 2020-01-26 15:29:32 --> Language Class Initialized
INFO - 2020-01-26 15:29:32 --> Config Class Initialized
INFO - 2020-01-26 15:29:32 --> Loader Class Initialized
INFO - 2020-01-26 15:29:32 --> Helper loaded: url_helper
INFO - 2020-01-26 15:29:32 --> Helper loaded: file_helper
INFO - 2020-01-26 15:29:32 --> Helper loaded: form_helper
INFO - 2020-01-26 15:29:33 --> Helper loaded: my_helper
INFO - 2020-01-26 15:29:33 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:29:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:29:33 --> Controller Class Initialized
INFO - 2020-01-26 15:29:41 --> Config Class Initialized
INFO - 2020-01-26 15:29:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:29:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:29:41 --> Utf8 Class Initialized
INFO - 2020-01-26 15:29:41 --> URI Class Initialized
INFO - 2020-01-26 15:29:41 --> Router Class Initialized
INFO - 2020-01-26 15:29:41 --> Output Class Initialized
INFO - 2020-01-26 15:29:42 --> Security Class Initialized
DEBUG - 2020-01-26 15:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:29:42 --> Input Class Initialized
INFO - 2020-01-26 15:29:42 --> Language Class Initialized
INFO - 2020-01-26 15:29:42 --> Language Class Initialized
INFO - 2020-01-26 15:29:42 --> Config Class Initialized
INFO - 2020-01-26 15:29:42 --> Loader Class Initialized
INFO - 2020-01-26 15:29:42 --> Helper loaded: url_helper
INFO - 2020-01-26 15:29:42 --> Helper loaded: file_helper
INFO - 2020-01-26 15:29:43 --> Helper loaded: form_helper
INFO - 2020-01-26 15:29:43 --> Helper loaded: my_helper
INFO - 2020-01-26 15:29:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:29:43 --> Controller Class Initialized
DEBUG - 2020-01-26 15:29:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-26 15:29:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:29:43 --> Final output sent to browser
DEBUG - 2020-01-26 15:29:44 --> Total execution time: 2.8394
INFO - 2020-01-26 15:29:44 --> Config Class Initialized
INFO - 2020-01-26 15:29:44 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:29:44 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:29:44 --> Utf8 Class Initialized
INFO - 2020-01-26 15:29:44 --> URI Class Initialized
INFO - 2020-01-26 15:29:44 --> Router Class Initialized
INFO - 2020-01-26 15:29:45 --> Output Class Initialized
INFO - 2020-01-26 15:29:45 --> Security Class Initialized
DEBUG - 2020-01-26 15:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:29:45 --> Input Class Initialized
INFO - 2020-01-26 15:29:45 --> Language Class Initialized
INFO - 2020-01-26 15:29:45 --> Language Class Initialized
INFO - 2020-01-26 15:29:45 --> Config Class Initialized
INFO - 2020-01-26 15:29:45 --> Loader Class Initialized
INFO - 2020-01-26 15:29:45 --> Helper loaded: url_helper
INFO - 2020-01-26 15:29:45 --> Helper loaded: file_helper
INFO - 2020-01-26 15:29:46 --> Helper loaded: form_helper
INFO - 2020-01-26 15:29:46 --> Helper loaded: my_helper
INFO - 2020-01-26 15:29:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:29:46 --> Controller Class Initialized
INFO - 2020-01-26 15:29:57 --> Config Class Initialized
INFO - 2020-01-26 15:29:57 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:29:57 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:29:57 --> Utf8 Class Initialized
INFO - 2020-01-26 15:29:57 --> URI Class Initialized
INFO - 2020-01-26 15:29:58 --> Router Class Initialized
INFO - 2020-01-26 15:29:58 --> Output Class Initialized
INFO - 2020-01-26 15:29:58 --> Security Class Initialized
DEBUG - 2020-01-26 15:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:29:58 --> Input Class Initialized
INFO - 2020-01-26 15:29:58 --> Language Class Initialized
INFO - 2020-01-26 15:29:58 --> Language Class Initialized
INFO - 2020-01-26 15:29:58 --> Config Class Initialized
INFO - 2020-01-26 15:29:58 --> Loader Class Initialized
INFO - 2020-01-26 15:29:58 --> Helper loaded: url_helper
INFO - 2020-01-26 15:29:59 --> Helper loaded: file_helper
INFO - 2020-01-26 15:29:59 --> Helper loaded: form_helper
INFO - 2020-01-26 15:29:59 --> Helper loaded: my_helper
INFO - 2020-01-26 15:29:59 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:29:59 --> Controller Class Initialized
DEBUG - 2020-01-26 15:29:59 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 15:30:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:00 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:00 --> Total execution time: 2.7693
INFO - 2020-01-26 15:30:00 --> Config Class Initialized
INFO - 2020-01-26 15:30:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:01 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:01 --> URI Class Initialized
INFO - 2020-01-26 15:30:01 --> Router Class Initialized
INFO - 2020-01-26 15:30:01 --> Output Class Initialized
INFO - 2020-01-26 15:30:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:01 --> Input Class Initialized
INFO - 2020-01-26 15:30:01 --> Language Class Initialized
INFO - 2020-01-26 15:30:01 --> Language Class Initialized
INFO - 2020-01-26 15:30:02 --> Config Class Initialized
INFO - 2020-01-26 15:30:02 --> Loader Class Initialized
INFO - 2020-01-26 15:30:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:02 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:02 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:03 --> Controller Class Initialized
INFO - 2020-01-26 15:30:06 --> Config Class Initialized
INFO - 2020-01-26 15:30:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:07 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:07 --> URI Class Initialized
INFO - 2020-01-26 15:30:07 --> Router Class Initialized
INFO - 2020-01-26 15:30:07 --> Output Class Initialized
INFO - 2020-01-26 15:30:07 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:07 --> Input Class Initialized
INFO - 2020-01-26 15:30:08 --> Language Class Initialized
INFO - 2020-01-26 15:30:08 --> Language Class Initialized
INFO - 2020-01-26 15:30:08 --> Config Class Initialized
INFO - 2020-01-26 15:30:08 --> Loader Class Initialized
INFO - 2020-01-26 15:30:08 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:08 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:08 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:08 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:09 --> Controller Class Initialized
DEBUG - 2020-01-26 15:30:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 15:30:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:09 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:10 --> Total execution time: 3.2470
INFO - 2020-01-26 15:30:19 --> Config Class Initialized
INFO - 2020-01-26 15:30:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:19 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:19 --> URI Class Initialized
INFO - 2020-01-26 15:30:19 --> Router Class Initialized
INFO - 2020-01-26 15:30:19 --> Output Class Initialized
INFO - 2020-01-26 15:30:20 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:20 --> Input Class Initialized
INFO - 2020-01-26 15:30:20 --> Language Class Initialized
INFO - 2020-01-26 15:30:20 --> Language Class Initialized
INFO - 2020-01-26 15:30:20 --> Config Class Initialized
INFO - 2020-01-26 15:30:20 --> Loader Class Initialized
INFO - 2020-01-26 15:30:20 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:20 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:21 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:21 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:21 --> Controller Class Initialized
INFO - 2020-01-26 15:30:21 --> Config Class Initialized
INFO - 2020-01-26 15:30:21 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:22 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:22 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:22 --> URI Class Initialized
INFO - 2020-01-26 15:30:22 --> Router Class Initialized
INFO - 2020-01-26 15:30:22 --> Output Class Initialized
INFO - 2020-01-26 15:30:22 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:22 --> Input Class Initialized
INFO - 2020-01-26 15:30:22 --> Language Class Initialized
INFO - 2020-01-26 15:30:23 --> Language Class Initialized
INFO - 2020-01-26 15:30:23 --> Config Class Initialized
INFO - 2020-01-26 15:30:23 --> Loader Class Initialized
INFO - 2020-01-26 15:30:23 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:23 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:23 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:23 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:23 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:24 --> Controller Class Initialized
DEBUG - 2020-01-26 15:30:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 15:30:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:24 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:24 --> Total execution time: 2.6787
INFO - 2020-01-26 15:30:24 --> Config Class Initialized
INFO - 2020-01-26 15:30:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:25 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:25 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:25 --> URI Class Initialized
INFO - 2020-01-26 15:30:25 --> Router Class Initialized
INFO - 2020-01-26 15:30:25 --> Output Class Initialized
INFO - 2020-01-26 15:30:25 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:25 --> Input Class Initialized
INFO - 2020-01-26 15:30:25 --> Language Class Initialized
INFO - 2020-01-26 15:30:26 --> Language Class Initialized
INFO - 2020-01-26 15:30:26 --> Config Class Initialized
INFO - 2020-01-26 15:30:26 --> Loader Class Initialized
INFO - 2020-01-26 15:30:26 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:26 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:26 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:26 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:27 --> Controller Class Initialized
INFO - 2020-01-26 15:30:31 --> Config Class Initialized
INFO - 2020-01-26 15:30:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:32 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:32 --> URI Class Initialized
INFO - 2020-01-26 15:30:32 --> Router Class Initialized
INFO - 2020-01-26 15:30:32 --> Output Class Initialized
INFO - 2020-01-26 15:30:32 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:33 --> Input Class Initialized
INFO - 2020-01-26 15:30:33 --> Language Class Initialized
INFO - 2020-01-26 15:30:33 --> Language Class Initialized
INFO - 2020-01-26 15:30:33 --> Config Class Initialized
INFO - 2020-01-26 15:30:33 --> Loader Class Initialized
INFO - 2020-01-26 15:30:33 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:33 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:33 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:33 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:34 --> Controller Class Initialized
DEBUG - 2020-01-26 15:30:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/form.php
DEBUG - 2020-01-26 15:30:34 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:34 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:34 --> Total execution time: 2.7576
INFO - 2020-01-26 15:30:42 --> Config Class Initialized
INFO - 2020-01-26 15:30:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:43 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:43 --> URI Class Initialized
INFO - 2020-01-26 15:30:43 --> Router Class Initialized
INFO - 2020-01-26 15:30:43 --> Output Class Initialized
INFO - 2020-01-26 15:30:43 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:43 --> Input Class Initialized
INFO - 2020-01-26 15:30:44 --> Language Class Initialized
INFO - 2020-01-26 15:30:44 --> Language Class Initialized
INFO - 2020-01-26 15:30:44 --> Config Class Initialized
INFO - 2020-01-26 15:30:44 --> Loader Class Initialized
INFO - 2020-01-26 15:30:44 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:44 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:44 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:44 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:45 --> Controller Class Initialized
INFO - 2020-01-26 15:30:45 --> Config Class Initialized
INFO - 2020-01-26 15:30:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:45 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:45 --> URI Class Initialized
INFO - 2020-01-26 15:30:45 --> Router Class Initialized
INFO - 2020-01-26 15:30:46 --> Output Class Initialized
INFO - 2020-01-26 15:30:46 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:46 --> Input Class Initialized
INFO - 2020-01-26 15:30:46 --> Language Class Initialized
INFO - 2020-01-26 15:30:46 --> Language Class Initialized
INFO - 2020-01-26 15:30:46 --> Config Class Initialized
INFO - 2020-01-26 15:30:46 --> Loader Class Initialized
INFO - 2020-01-26 15:30:47 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:47 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:47 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:47 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:47 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:47 --> Controller Class Initialized
DEBUG - 2020-01-26 15:30:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 15:30:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:48 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:48 --> Total execution time: 2.8707
INFO - 2020-01-26 15:30:48 --> Config Class Initialized
INFO - 2020-01-26 15:30:48 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:48 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:49 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:49 --> URI Class Initialized
INFO - 2020-01-26 15:30:49 --> Router Class Initialized
INFO - 2020-01-26 15:30:49 --> Output Class Initialized
INFO - 2020-01-26 15:30:49 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:49 --> Input Class Initialized
INFO - 2020-01-26 15:30:49 --> Language Class Initialized
INFO - 2020-01-26 15:30:49 --> Language Class Initialized
INFO - 2020-01-26 15:30:49 --> Config Class Initialized
INFO - 2020-01-26 15:30:50 --> Loader Class Initialized
INFO - 2020-01-26 15:30:50 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:50 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:50 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:50 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:50 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:50 --> Controller Class Initialized
INFO - 2020-01-26 15:30:55 --> Config Class Initialized
INFO - 2020-01-26 15:30:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:30:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:30:56 --> Utf8 Class Initialized
INFO - 2020-01-26 15:30:56 --> URI Class Initialized
INFO - 2020-01-26 15:30:56 --> Router Class Initialized
INFO - 2020-01-26 15:30:56 --> Output Class Initialized
INFO - 2020-01-26 15:30:56 --> Security Class Initialized
DEBUG - 2020-01-26 15:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:30:56 --> Input Class Initialized
INFO - 2020-01-26 15:30:56 --> Language Class Initialized
INFO - 2020-01-26 15:30:57 --> Language Class Initialized
INFO - 2020-01-26 15:30:57 --> Config Class Initialized
INFO - 2020-01-26 15:30:57 --> Loader Class Initialized
INFO - 2020-01-26 15:30:57 --> Helper loaded: url_helper
INFO - 2020-01-26 15:30:57 --> Helper loaded: file_helper
INFO - 2020-01-26 15:30:57 --> Helper loaded: form_helper
INFO - 2020-01-26 15:30:57 --> Helper loaded: my_helper
INFO - 2020-01-26 15:30:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:30:58 --> Controller Class Initialized
DEBUG - 2020-01-26 15:30:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 15:30:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:30:58 --> Final output sent to browser
DEBUG - 2020-01-26 15:30:58 --> Total execution time: 2.9457
INFO - 2020-01-26 15:31:07 --> Config Class Initialized
INFO - 2020-01-26 15:31:07 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:07 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:08 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:08 --> URI Class Initialized
INFO - 2020-01-26 15:31:08 --> Router Class Initialized
INFO - 2020-01-26 15:31:08 --> Output Class Initialized
INFO - 2020-01-26 15:31:08 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:08 --> Input Class Initialized
INFO - 2020-01-26 15:31:08 --> Language Class Initialized
INFO - 2020-01-26 15:31:09 --> Language Class Initialized
INFO - 2020-01-26 15:31:09 --> Config Class Initialized
INFO - 2020-01-26 15:31:09 --> Loader Class Initialized
INFO - 2020-01-26 15:31:09 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:09 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:09 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:09 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:09 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:10 --> Controller Class Initialized
INFO - 2020-01-26 15:31:10 --> Final output sent to browser
DEBUG - 2020-01-26 15:31:10 --> Total execution time: 2.8024
INFO - 2020-01-26 15:31:16 --> Config Class Initialized
INFO - 2020-01-26 15:31:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:16 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:17 --> URI Class Initialized
INFO - 2020-01-26 15:31:17 --> Router Class Initialized
INFO - 2020-01-26 15:31:17 --> Output Class Initialized
INFO - 2020-01-26 15:31:17 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:17 --> Input Class Initialized
INFO - 2020-01-26 15:31:17 --> Language Class Initialized
INFO - 2020-01-26 15:31:17 --> Language Class Initialized
INFO - 2020-01-26 15:31:17 --> Config Class Initialized
INFO - 2020-01-26 15:31:18 --> Loader Class Initialized
INFO - 2020-01-26 15:31:18 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:18 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:18 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:18 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:18 --> Controller Class Initialized
INFO - 2020-01-26 15:31:19 --> Final output sent to browser
DEBUG - 2020-01-26 15:31:19 --> Total execution time: 2.5471
INFO - 2020-01-26 15:31:20 --> Config Class Initialized
INFO - 2020-01-26 15:31:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:20 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:21 --> URI Class Initialized
INFO - 2020-01-26 15:31:21 --> Router Class Initialized
INFO - 2020-01-26 15:31:21 --> Output Class Initialized
INFO - 2020-01-26 15:31:21 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:21 --> Input Class Initialized
INFO - 2020-01-26 15:31:21 --> Language Class Initialized
INFO - 2020-01-26 15:31:21 --> Language Class Initialized
INFO - 2020-01-26 15:31:22 --> Config Class Initialized
INFO - 2020-01-26 15:31:22 --> Loader Class Initialized
INFO - 2020-01-26 15:31:22 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:22 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:22 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:22 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:23 --> Controller Class Initialized
DEBUG - 2020-01-26 15:31:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/form.php
DEBUG - 2020-01-26 15:31:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:31:23 --> Final output sent to browser
DEBUG - 2020-01-26 15:31:23 --> Total execution time: 2.9521
INFO - 2020-01-26 15:31:32 --> Config Class Initialized
INFO - 2020-01-26 15:31:32 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:32 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:32 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:32 --> URI Class Initialized
INFO - 2020-01-26 15:31:32 --> Router Class Initialized
INFO - 2020-01-26 15:31:32 --> Output Class Initialized
INFO - 2020-01-26 15:31:33 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:33 --> Input Class Initialized
INFO - 2020-01-26 15:31:33 --> Language Class Initialized
INFO - 2020-01-26 15:31:33 --> Language Class Initialized
INFO - 2020-01-26 15:31:33 --> Config Class Initialized
INFO - 2020-01-26 15:31:33 --> Loader Class Initialized
INFO - 2020-01-26 15:31:33 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:33 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:34 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:34 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:34 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:34 --> Controller Class Initialized
INFO - 2020-01-26 15:31:34 --> Config Class Initialized
INFO - 2020-01-26 15:31:34 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:35 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:35 --> URI Class Initialized
INFO - 2020-01-26 15:31:35 --> Router Class Initialized
INFO - 2020-01-26 15:31:35 --> Output Class Initialized
INFO - 2020-01-26 15:31:35 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:35 --> Input Class Initialized
INFO - 2020-01-26 15:31:36 --> Language Class Initialized
INFO - 2020-01-26 15:31:36 --> Language Class Initialized
INFO - 2020-01-26 15:31:36 --> Config Class Initialized
INFO - 2020-01-26 15:31:36 --> Loader Class Initialized
INFO - 2020-01-26 15:31:36 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:36 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:36 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:36 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:37 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:37 --> Controller Class Initialized
DEBUG - 2020-01-26 15:31:37 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_kelas/views/list.php
DEBUG - 2020-01-26 15:31:37 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:31:37 --> Final output sent to browser
DEBUG - 2020-01-26 15:31:37 --> Total execution time: 2.8736
INFO - 2020-01-26 15:31:44 --> Config Class Initialized
INFO - 2020-01-26 15:31:44 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:44 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:44 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:45 --> URI Class Initialized
INFO - 2020-01-26 15:31:45 --> Router Class Initialized
INFO - 2020-01-26 15:31:45 --> Output Class Initialized
INFO - 2020-01-26 15:31:45 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:45 --> Input Class Initialized
INFO - 2020-01-26 15:31:45 --> Language Class Initialized
INFO - 2020-01-26 15:31:45 --> Language Class Initialized
INFO - 2020-01-26 15:31:46 --> Config Class Initialized
INFO - 2020-01-26 15:31:46 --> Loader Class Initialized
INFO - 2020-01-26 15:31:46 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:46 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:46 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:46 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:46 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:47 --> Controller Class Initialized
DEBUG - 2020-01-26 15:31:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/set_mapel/views/list.php
DEBUG - 2020-01-26 15:31:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:31:47 --> Final output sent to browser
DEBUG - 2020-01-26 15:31:47 --> Total execution time: 2.9401
INFO - 2020-01-26 15:31:47 --> Config Class Initialized
INFO - 2020-01-26 15:31:48 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:48 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:48 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:48 --> URI Class Initialized
INFO - 2020-01-26 15:31:48 --> Router Class Initialized
INFO - 2020-01-26 15:31:48 --> Output Class Initialized
INFO - 2020-01-26 15:31:48 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:48 --> Input Class Initialized
INFO - 2020-01-26 15:31:49 --> Language Class Initialized
INFO - 2020-01-26 15:31:49 --> Language Class Initialized
INFO - 2020-01-26 15:31:49 --> Config Class Initialized
INFO - 2020-01-26 15:31:49 --> Loader Class Initialized
INFO - 2020-01-26 15:31:49 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:49 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:49 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:49 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:49 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:50 --> Controller Class Initialized
INFO - 2020-01-26 15:31:55 --> Config Class Initialized
INFO - 2020-01-26 15:31:55 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:55 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:56 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:56 --> URI Class Initialized
INFO - 2020-01-26 15:31:56 --> Router Class Initialized
INFO - 2020-01-26 15:31:56 --> Output Class Initialized
INFO - 2020-01-26 15:31:56 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:56 --> Input Class Initialized
INFO - 2020-01-26 15:31:57 --> Language Class Initialized
INFO - 2020-01-26 15:31:57 --> Language Class Initialized
INFO - 2020-01-26 15:31:57 --> Config Class Initialized
INFO - 2020-01-26 15:31:57 --> Loader Class Initialized
INFO - 2020-01-26 15:31:57 --> Helper loaded: url_helper
INFO - 2020-01-26 15:31:57 --> Helper loaded: file_helper
INFO - 2020-01-26 15:31:57 --> Helper loaded: form_helper
INFO - 2020-01-26 15:31:57 --> Helper loaded: my_helper
INFO - 2020-01-26 15:31:57 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:31:58 --> Controller Class Initialized
INFO - 2020-01-26 15:31:58 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:31:58 --> Config Class Initialized
INFO - 2020-01-26 15:31:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:31:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:31:59 --> Utf8 Class Initialized
INFO - 2020-01-26 15:31:59 --> URI Class Initialized
INFO - 2020-01-26 15:31:59 --> Router Class Initialized
INFO - 2020-01-26 15:31:59 --> Output Class Initialized
INFO - 2020-01-26 15:31:59 --> Security Class Initialized
DEBUG - 2020-01-26 15:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:31:59 --> Input Class Initialized
INFO - 2020-01-26 15:31:59 --> Language Class Initialized
INFO - 2020-01-26 15:32:00 --> Language Class Initialized
INFO - 2020-01-26 15:32:00 --> Config Class Initialized
INFO - 2020-01-26 15:32:00 --> Loader Class Initialized
INFO - 2020-01-26 15:32:00 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:00 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:00 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:00 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:01 --> Controller Class Initialized
INFO - 2020-01-26 15:32:01 --> Config Class Initialized
INFO - 2020-01-26 15:32:02 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:02 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:02 --> URI Class Initialized
INFO - 2020-01-26 15:32:03 --> Router Class Initialized
INFO - 2020-01-26 15:32:03 --> Output Class Initialized
INFO - 2020-01-26 15:32:03 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:03 --> Input Class Initialized
INFO - 2020-01-26 15:32:04 --> Language Class Initialized
INFO - 2020-01-26 15:32:04 --> Language Class Initialized
INFO - 2020-01-26 15:32:04 --> Config Class Initialized
INFO - 2020-01-26 15:32:04 --> Loader Class Initialized
INFO - 2020-01-26 15:32:04 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:04 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:05 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:05 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:05 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:06 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 15:32:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:32:06 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:06 --> Total execution time: 4.6279
INFO - 2020-01-26 15:32:18 --> Config Class Initialized
INFO - 2020-01-26 15:32:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:18 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:18 --> URI Class Initialized
INFO - 2020-01-26 15:32:18 --> Router Class Initialized
INFO - 2020-01-26 15:32:18 --> Output Class Initialized
INFO - 2020-01-26 15:32:18 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:19 --> Input Class Initialized
INFO - 2020-01-26 15:32:19 --> Language Class Initialized
INFO - 2020-01-26 15:32:19 --> Language Class Initialized
INFO - 2020-01-26 15:32:19 --> Config Class Initialized
INFO - 2020-01-26 15:32:19 --> Loader Class Initialized
INFO - 2020-01-26 15:32:19 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:19 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:19 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:20 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:20 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:20 --> Controller Class Initialized
INFO - 2020-01-26 15:32:20 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:32:20 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:20 --> Total execution time: 2.6028
INFO - 2020-01-26 15:32:22 --> Config Class Initialized
INFO - 2020-01-26 15:32:22 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:23 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:23 --> URI Class Initialized
INFO - 2020-01-26 15:32:23 --> Router Class Initialized
INFO - 2020-01-26 15:32:23 --> Output Class Initialized
INFO - 2020-01-26 15:32:23 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:24 --> Input Class Initialized
INFO - 2020-01-26 15:32:24 --> Language Class Initialized
INFO - 2020-01-26 15:32:24 --> Language Class Initialized
INFO - 2020-01-26 15:32:24 --> Config Class Initialized
INFO - 2020-01-26 15:32:24 --> Loader Class Initialized
INFO - 2020-01-26 15:32:24 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:24 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:24 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:25 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:25 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:25 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 15:32:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:32:26 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:26 --> Total execution time: 3.2596
INFO - 2020-01-26 15:32:29 --> Config Class Initialized
INFO - 2020-01-26 15:32:29 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:29 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:29 --> URI Class Initialized
INFO - 2020-01-26 15:32:29 --> Router Class Initialized
INFO - 2020-01-26 15:32:30 --> Output Class Initialized
INFO - 2020-01-26 15:32:30 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:30 --> Input Class Initialized
INFO - 2020-01-26 15:32:30 --> Language Class Initialized
INFO - 2020-01-26 15:32:30 --> Language Class Initialized
INFO - 2020-01-26 15:32:30 --> Config Class Initialized
INFO - 2020-01-26 15:32:30 --> Loader Class Initialized
INFO - 2020-01-26 15:32:31 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:31 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:31 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:31 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:31 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:32:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:32:32 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:32 --> Total execution time: 2.9469
INFO - 2020-01-26 15:32:33 --> Config Class Initialized
INFO - 2020-01-26 15:32:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:34 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:34 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:34 --> URI Class Initialized
INFO - 2020-01-26 15:32:34 --> Router Class Initialized
INFO - 2020-01-26 15:32:34 --> Output Class Initialized
INFO - 2020-01-26 15:32:34 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:34 --> Input Class Initialized
INFO - 2020-01-26 15:32:35 --> Language Class Initialized
INFO - 2020-01-26 15:32:35 --> Language Class Initialized
INFO - 2020-01-26 15:32:35 --> Config Class Initialized
INFO - 2020-01-26 15:32:35 --> Loader Class Initialized
INFO - 2020-01-26 15:32:35 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:35 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:35 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:35 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:36 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:36 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-26 15:32:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:32:36 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:36 --> Total execution time: 2.9363
INFO - 2020-01-26 15:32:42 --> Config Class Initialized
INFO - 2020-01-26 15:32:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:43 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:43 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:43 --> URI Class Initialized
INFO - 2020-01-26 15:32:43 --> Router Class Initialized
INFO - 2020-01-26 15:32:43 --> Output Class Initialized
INFO - 2020-01-26 15:32:43 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:44 --> Input Class Initialized
INFO - 2020-01-26 15:32:44 --> Language Class Initialized
INFO - 2020-01-26 15:32:44 --> Language Class Initialized
INFO - 2020-01-26 15:32:44 --> Config Class Initialized
INFO - 2020-01-26 15:32:44 --> Loader Class Initialized
INFO - 2020-01-26 15:32:44 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:44 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:44 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:45 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:45 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:45 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:45 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-26 15:32:45 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:46 --> Total execution time: 3.0528
INFO - 2020-01-26 15:32:50 --> Config Class Initialized
INFO - 2020-01-26 15:32:50 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:32:50 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:32:50 --> Utf8 Class Initialized
INFO - 2020-01-26 15:32:51 --> URI Class Initialized
INFO - 2020-01-26 15:32:51 --> Router Class Initialized
INFO - 2020-01-26 15:32:51 --> Output Class Initialized
INFO - 2020-01-26 15:32:51 --> Security Class Initialized
DEBUG - 2020-01-26 15:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:32:51 --> Input Class Initialized
INFO - 2020-01-26 15:32:51 --> Language Class Initialized
INFO - 2020-01-26 15:32:52 --> Language Class Initialized
INFO - 2020-01-26 15:32:52 --> Config Class Initialized
INFO - 2020-01-26 15:32:52 --> Loader Class Initialized
INFO - 2020-01-26 15:32:52 --> Helper loaded: url_helper
INFO - 2020-01-26 15:32:52 --> Helper loaded: file_helper
INFO - 2020-01-26 15:32:52 --> Helper loaded: form_helper
INFO - 2020-01-26 15:32:52 --> Helper loaded: my_helper
INFO - 2020-01-26 15:32:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:32:53 --> Controller Class Initialized
DEBUG - 2020-01-26 15:32:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-01-26 15:32:53 --> Final output sent to browser
DEBUG - 2020-01-26 15:32:53 --> Total execution time: 3.2903
INFO - 2020-01-26 15:33:00 --> Config Class Initialized
INFO - 2020-01-26 15:33:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:33:01 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:33:01 --> Utf8 Class Initialized
INFO - 2020-01-26 15:33:01 --> URI Class Initialized
INFO - 2020-01-26 15:33:01 --> Router Class Initialized
INFO - 2020-01-26 15:33:01 --> Output Class Initialized
INFO - 2020-01-26 15:33:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:33:02 --> Input Class Initialized
INFO - 2020-01-26 15:33:02 --> Language Class Initialized
INFO - 2020-01-26 15:33:02 --> Language Class Initialized
INFO - 2020-01-26 15:33:02 --> Config Class Initialized
INFO - 2020-01-26 15:33:02 --> Loader Class Initialized
INFO - 2020-01-26 15:33:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:33:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:33:03 --> Helper loaded: form_helper
INFO - 2020-01-26 15:33:03 --> Helper loaded: my_helper
INFO - 2020-01-26 15:33:03 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:33:03 --> Controller Class Initialized
DEBUG - 2020-01-26 15:33:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-26 15:33:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:33:04 --> Final output sent to browser
DEBUG - 2020-01-26 15:33:04 --> Total execution time: 3.6268
INFO - 2020-01-26 15:33:06 --> Config Class Initialized
INFO - 2020-01-26 15:33:06 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:33:06 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:33:06 --> Utf8 Class Initialized
INFO - 2020-01-26 15:33:06 --> URI Class Initialized
INFO - 2020-01-26 15:33:06 --> Router Class Initialized
INFO - 2020-01-26 15:33:06 --> Output Class Initialized
INFO - 2020-01-26 15:33:07 --> Security Class Initialized
DEBUG - 2020-01-26 15:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:33:07 --> Input Class Initialized
INFO - 2020-01-26 15:33:07 --> Language Class Initialized
INFO - 2020-01-26 15:33:07 --> Language Class Initialized
INFO - 2020-01-26 15:33:07 --> Config Class Initialized
INFO - 2020-01-26 15:33:07 --> Loader Class Initialized
INFO - 2020-01-26 15:33:08 --> Helper loaded: url_helper
INFO - 2020-01-26 15:33:08 --> Helper loaded: file_helper
INFO - 2020-01-26 15:33:08 --> Helper loaded: form_helper
INFO - 2020-01-26 15:33:08 --> Helper loaded: my_helper
INFO - 2020-01-26 15:33:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:33:09 --> Controller Class Initialized
DEBUG - 2020-01-26 15:33:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:33:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:33:09 --> Final output sent to browser
DEBUG - 2020-01-26 15:33:09 --> Total execution time: 3.3696
INFO - 2020-01-26 15:33:20 --> Config Class Initialized
INFO - 2020-01-26 15:33:20 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:33:20 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:33:20 --> Utf8 Class Initialized
INFO - 2020-01-26 15:33:21 --> URI Class Initialized
INFO - 2020-01-26 15:33:21 --> Router Class Initialized
INFO - 2020-01-26 15:33:21 --> Output Class Initialized
INFO - 2020-01-26 15:33:21 --> Security Class Initialized
DEBUG - 2020-01-26 15:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:33:21 --> Input Class Initialized
INFO - 2020-01-26 15:33:21 --> Language Class Initialized
INFO - 2020-01-26 15:33:21 --> Language Class Initialized
INFO - 2020-01-26 15:33:21 --> Config Class Initialized
INFO - 2020-01-26 15:33:22 --> Loader Class Initialized
INFO - 2020-01-26 15:33:22 --> Helper loaded: url_helper
INFO - 2020-01-26 15:33:22 --> Helper loaded: file_helper
INFO - 2020-01-26 15:33:22 --> Helper loaded: form_helper
INFO - 2020-01-26 15:33:22 --> Helper loaded: my_helper
INFO - 2020-01-26 15:33:22 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:33:23 --> Controller Class Initialized
DEBUG - 2020-01-26 15:33:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-26 15:33:23 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:33:23 --> Final output sent to browser
DEBUG - 2020-01-26 15:33:23 --> Total execution time: 2.9246
INFO - 2020-01-26 15:33:23 --> Config Class Initialized
INFO - 2020-01-26 15:33:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:33:24 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:33:24 --> Utf8 Class Initialized
INFO - 2020-01-26 15:33:24 --> URI Class Initialized
INFO - 2020-01-26 15:33:24 --> Router Class Initialized
INFO - 2020-01-26 15:33:24 --> Output Class Initialized
INFO - 2020-01-26 15:33:24 --> Security Class Initialized
DEBUG - 2020-01-26 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:33:24 --> Input Class Initialized
INFO - 2020-01-26 15:33:25 --> Language Class Initialized
INFO - 2020-01-26 15:33:25 --> Language Class Initialized
INFO - 2020-01-26 15:33:25 --> Config Class Initialized
INFO - 2020-01-26 15:33:25 --> Loader Class Initialized
INFO - 2020-01-26 15:33:25 --> Helper loaded: url_helper
INFO - 2020-01-26 15:33:25 --> Helper loaded: file_helper
INFO - 2020-01-26 15:33:25 --> Helper loaded: form_helper
INFO - 2020-01-26 15:33:25 --> Helper loaded: my_helper
INFO - 2020-01-26 15:33:26 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:33:26 --> Controller Class Initialized
INFO - 2020-01-26 15:36:13 --> Config Class Initialized
INFO - 2020-01-26 15:36:13 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:13 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:13 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:14 --> URI Class Initialized
INFO - 2020-01-26 15:36:14 --> Router Class Initialized
INFO - 2020-01-26 15:36:14 --> Output Class Initialized
INFO - 2020-01-26 15:36:14 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:14 --> Input Class Initialized
INFO - 2020-01-26 15:36:14 --> Language Class Initialized
INFO - 2020-01-26 15:36:14 --> Language Class Initialized
INFO - 2020-01-26 15:36:15 --> Config Class Initialized
INFO - 2020-01-26 15:36:15 --> Loader Class Initialized
INFO - 2020-01-26 15:36:15 --> Helper loaded: url_helper
INFO - 2020-01-26 15:36:15 --> Helper loaded: file_helper
INFO - 2020-01-26 15:36:15 --> Helper loaded: form_helper
INFO - 2020-01-26 15:36:15 --> Helper loaded: my_helper
INFO - 2020-01-26 15:36:15 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:36:16 --> Controller Class Initialized
INFO - 2020-01-26 15:36:16 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:36:16 --> Config Class Initialized
INFO - 2020-01-26 15:36:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:16 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:16 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:16 --> URI Class Initialized
INFO - 2020-01-26 15:36:17 --> Router Class Initialized
INFO - 2020-01-26 15:36:17 --> Output Class Initialized
INFO - 2020-01-26 15:36:17 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:17 --> Input Class Initialized
INFO - 2020-01-26 15:36:17 --> Language Class Initialized
INFO - 2020-01-26 15:36:17 --> Language Class Initialized
INFO - 2020-01-26 15:36:17 --> Config Class Initialized
INFO - 2020-01-26 15:36:18 --> Loader Class Initialized
INFO - 2020-01-26 15:36:18 --> Helper loaded: url_helper
INFO - 2020-01-26 15:36:18 --> Helper loaded: file_helper
INFO - 2020-01-26 15:36:18 --> Helper loaded: form_helper
INFO - 2020-01-26 15:36:18 --> Helper loaded: my_helper
INFO - 2020-01-26 15:36:18 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:36:19 --> Controller Class Initialized
INFO - 2020-01-26 15:36:19 --> Config Class Initialized
INFO - 2020-01-26 15:36:19 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:19 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:19 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:19 --> URI Class Initialized
INFO - 2020-01-26 15:36:19 --> Router Class Initialized
INFO - 2020-01-26 15:36:19 --> Output Class Initialized
INFO - 2020-01-26 15:36:19 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:20 --> Input Class Initialized
INFO - 2020-01-26 15:36:20 --> Language Class Initialized
INFO - 2020-01-26 15:36:20 --> Language Class Initialized
INFO - 2020-01-26 15:36:20 --> Config Class Initialized
INFO - 2020-01-26 15:36:20 --> Loader Class Initialized
INFO - 2020-01-26 15:36:20 --> Helper loaded: url_helper
INFO - 2020-01-26 15:36:20 --> Helper loaded: file_helper
INFO - 2020-01-26 15:36:21 --> Helper loaded: form_helper
INFO - 2020-01-26 15:36:21 --> Helper loaded: my_helper
INFO - 2020-01-26 15:36:21 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:36:21 --> Controller Class Initialized
DEBUG - 2020-01-26 15:36:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 15:36:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:36:22 --> Final output sent to browser
DEBUG - 2020-01-26 15:36:22 --> Total execution time: 2.8852
INFO - 2020-01-26 15:36:28 --> Config Class Initialized
INFO - 2020-01-26 15:36:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:28 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:29 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:29 --> URI Class Initialized
INFO - 2020-01-26 15:36:29 --> Router Class Initialized
INFO - 2020-01-26 15:36:29 --> Output Class Initialized
INFO - 2020-01-26 15:36:29 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:29 --> Input Class Initialized
INFO - 2020-01-26 15:36:29 --> Language Class Initialized
INFO - 2020-01-26 15:36:29 --> Language Class Initialized
INFO - 2020-01-26 15:36:30 --> Config Class Initialized
INFO - 2020-01-26 15:36:30 --> Loader Class Initialized
INFO - 2020-01-26 15:36:30 --> Helper loaded: url_helper
INFO - 2020-01-26 15:36:30 --> Helper loaded: file_helper
INFO - 2020-01-26 15:36:30 --> Helper loaded: form_helper
INFO - 2020-01-26 15:36:30 --> Helper loaded: my_helper
INFO - 2020-01-26 15:36:30 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:36:31 --> Controller Class Initialized
INFO - 2020-01-26 15:36:31 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:36:31 --> Final output sent to browser
DEBUG - 2020-01-26 15:36:31 --> Total execution time: 2.7387
INFO - 2020-01-26 15:36:33 --> Config Class Initialized
INFO - 2020-01-26 15:36:33 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:33 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:33 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:33 --> URI Class Initialized
INFO - 2020-01-26 15:36:33 --> Router Class Initialized
INFO - 2020-01-26 15:36:34 --> Output Class Initialized
INFO - 2020-01-26 15:36:34 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:34 --> Input Class Initialized
INFO - 2020-01-26 15:36:34 --> Language Class Initialized
INFO - 2020-01-26 15:36:34 --> Language Class Initialized
INFO - 2020-01-26 15:36:34 --> Config Class Initialized
INFO - 2020-01-26 15:36:35 --> Loader Class Initialized
INFO - 2020-01-26 15:36:35 --> Helper loaded: url_helper
INFO - 2020-01-26 15:36:35 --> Helper loaded: file_helper
INFO - 2020-01-26 15:36:35 --> Helper loaded: form_helper
INFO - 2020-01-26 15:36:35 --> Helper loaded: my_helper
INFO - 2020-01-26 15:36:35 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:36:36 --> Controller Class Initialized
DEBUG - 2020-01-26 15:36:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 15:36:36 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:36:36 --> Final output sent to browser
DEBUG - 2020-01-26 15:36:36 --> Total execution time: 3.4632
INFO - 2020-01-26 15:36:58 --> Config Class Initialized
INFO - 2020-01-26 15:36:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:36:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:36:59 --> Utf8 Class Initialized
INFO - 2020-01-26 15:36:59 --> URI Class Initialized
INFO - 2020-01-26 15:36:59 --> Router Class Initialized
INFO - 2020-01-26 15:36:59 --> Output Class Initialized
INFO - 2020-01-26 15:36:59 --> Security Class Initialized
DEBUG - 2020-01-26 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:36:59 --> Input Class Initialized
INFO - 2020-01-26 15:37:00 --> Language Class Initialized
INFO - 2020-01-26 15:37:00 --> Language Class Initialized
INFO - 2020-01-26 15:37:00 --> Config Class Initialized
INFO - 2020-01-26 15:37:00 --> Loader Class Initialized
INFO - 2020-01-26 15:37:00 --> Helper loaded: url_helper
INFO - 2020-01-26 15:37:00 --> Helper loaded: file_helper
INFO - 2020-01-26 15:37:00 --> Helper loaded: form_helper
INFO - 2020-01-26 15:37:01 --> Helper loaded: my_helper
INFO - 2020-01-26 15:37:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:37:01 --> Controller Class Initialized
DEBUG - 2020-01-26 15:37:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 15:37:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:37:02 --> Final output sent to browser
DEBUG - 2020-01-26 15:37:02 --> Total execution time: 3.3279
INFO - 2020-01-26 15:38:52 --> Config Class Initialized
INFO - 2020-01-26 15:38:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:38:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:38:52 --> Utf8 Class Initialized
INFO - 2020-01-26 15:38:52 --> URI Class Initialized
INFO - 2020-01-26 15:38:52 --> Router Class Initialized
INFO - 2020-01-26 15:38:53 --> Output Class Initialized
INFO - 2020-01-26 15:38:53 --> Security Class Initialized
DEBUG - 2020-01-26 15:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:38:53 --> Input Class Initialized
INFO - 2020-01-26 15:38:53 --> Language Class Initialized
INFO - 2020-01-26 15:38:53 --> Language Class Initialized
INFO - 2020-01-26 15:38:53 --> Config Class Initialized
INFO - 2020-01-26 15:38:54 --> Loader Class Initialized
INFO - 2020-01-26 15:38:54 --> Helper loaded: url_helper
INFO - 2020-01-26 15:38:54 --> Helper loaded: file_helper
INFO - 2020-01-26 15:38:54 --> Helper loaded: form_helper
INFO - 2020-01-26 15:38:54 --> Helper loaded: my_helper
INFO - 2020-01-26 15:38:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:38:55 --> Controller Class Initialized
DEBUG - 2020-01-26 15:38:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-26 15:38:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:38:55 --> Final output sent to browser
DEBUG - 2020-01-26 15:38:55 --> Total execution time: 3.1993
INFO - 2020-01-26 15:40:25 --> Config Class Initialized
INFO - 2020-01-26 15:40:25 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:40:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:40:26 --> Utf8 Class Initialized
INFO - 2020-01-26 15:40:26 --> URI Class Initialized
INFO - 2020-01-26 15:40:26 --> Router Class Initialized
INFO - 2020-01-26 15:40:26 --> Output Class Initialized
INFO - 2020-01-26 15:40:26 --> Security Class Initialized
DEBUG - 2020-01-26 15:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:40:26 --> Input Class Initialized
INFO - 2020-01-26 15:40:27 --> Language Class Initialized
INFO - 2020-01-26 15:40:27 --> Language Class Initialized
INFO - 2020-01-26 15:40:27 --> Config Class Initialized
INFO - 2020-01-26 15:40:27 --> Loader Class Initialized
INFO - 2020-01-26 15:40:27 --> Helper loaded: url_helper
INFO - 2020-01-26 15:40:27 --> Helper loaded: file_helper
INFO - 2020-01-26 15:40:27 --> Helper loaded: form_helper
INFO - 2020-01-26 15:40:27 --> Helper loaded: my_helper
INFO - 2020-01-26 15:40:28 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:40:28 --> Controller Class Initialized
DEBUG - 2020-01-26 15:40:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 15:40:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:40:28 --> Final output sent to browser
DEBUG - 2020-01-26 15:40:29 --> Total execution time: 3.1854
INFO - 2020-01-26 15:40:35 --> Config Class Initialized
INFO - 2020-01-26 15:40:35 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:40:35 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:40:36 --> Utf8 Class Initialized
INFO - 2020-01-26 15:40:36 --> URI Class Initialized
INFO - 2020-01-26 15:40:36 --> Router Class Initialized
INFO - 2020-01-26 15:40:36 --> Output Class Initialized
INFO - 2020-01-26 15:40:36 --> Security Class Initialized
DEBUG - 2020-01-26 15:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:40:36 --> Input Class Initialized
INFO - 2020-01-26 15:40:37 --> Language Class Initialized
INFO - 2020-01-26 15:40:37 --> Language Class Initialized
INFO - 2020-01-26 15:40:37 --> Config Class Initialized
INFO - 2020-01-26 15:40:37 --> Loader Class Initialized
INFO - 2020-01-26 15:40:37 --> Helper loaded: url_helper
INFO - 2020-01-26 15:40:37 --> Helper loaded: file_helper
INFO - 2020-01-26 15:40:37 --> Helper loaded: form_helper
INFO - 2020-01-26 15:40:37 --> Helper loaded: my_helper
INFO - 2020-01-26 15:40:38 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:40:38 --> Controller Class Initialized
DEBUG - 2020-01-26 15:40:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/cetak.php
INFO - 2020-01-26 15:40:38 --> Final output sent to browser
DEBUG - 2020-01-26 15:40:39 --> Total execution time: 3.3153
INFO - 2020-01-26 15:41:00 --> Config Class Initialized
INFO - 2020-01-26 15:41:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:00 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:00 --> URI Class Initialized
INFO - 2020-01-26 15:41:01 --> Router Class Initialized
INFO - 2020-01-26 15:41:01 --> Output Class Initialized
INFO - 2020-01-26 15:41:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:01 --> Input Class Initialized
INFO - 2020-01-26 15:41:01 --> Language Class Initialized
INFO - 2020-01-26 15:41:01 --> Language Class Initialized
INFO - 2020-01-26 15:41:02 --> Config Class Initialized
INFO - 2020-01-26 15:41:02 --> Loader Class Initialized
INFO - 2020-01-26 15:41:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:41:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:41:02 --> Helper loaded: form_helper
INFO - 2020-01-26 15:41:02 --> Helper loaded: my_helper
INFO - 2020-01-26 15:41:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:41:03 --> Controller Class Initialized
DEBUG - 2020-01-26 15:41:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:41:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:41:03 --> Final output sent to browser
DEBUG - 2020-01-26 15:41:04 --> Total execution time: 3.6685
INFO - 2020-01-26 15:41:09 --> Config Class Initialized
INFO - 2020-01-26 15:41:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:09 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:09 --> URI Class Initialized
INFO - 2020-01-26 15:41:09 --> Router Class Initialized
INFO - 2020-01-26 15:41:10 --> Output Class Initialized
INFO - 2020-01-26 15:41:10 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:10 --> Input Class Initialized
INFO - 2020-01-26 15:41:10 --> Language Class Initialized
INFO - 2020-01-26 15:41:10 --> Language Class Initialized
INFO - 2020-01-26 15:41:10 --> Config Class Initialized
INFO - 2020-01-26 15:41:11 --> Loader Class Initialized
INFO - 2020-01-26 15:41:11 --> Helper loaded: url_helper
INFO - 2020-01-26 15:41:11 --> Helper loaded: file_helper
INFO - 2020-01-26 15:41:11 --> Helper loaded: form_helper
INFO - 2020-01-26 15:41:11 --> Helper loaded: my_helper
INFO - 2020-01-26 15:41:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:41:12 --> Controller Class Initialized
DEBUG - 2020-01-26 15:41:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-26 15:41:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:41:12 --> Final output sent to browser
DEBUG - 2020-01-26 15:41:12 --> Total execution time: 3.5887
INFO - 2020-01-26 15:41:17 --> Config Class Initialized
INFO - 2020-01-26 15:41:17 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:17 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:17 --> URI Class Initialized
INFO - 2020-01-26 15:41:17 --> Router Class Initialized
INFO - 2020-01-26 15:41:17 --> Output Class Initialized
INFO - 2020-01-26 15:41:18 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:18 --> Input Class Initialized
INFO - 2020-01-26 15:41:18 --> Language Class Initialized
INFO - 2020-01-26 15:41:18 --> Language Class Initialized
INFO - 2020-01-26 15:41:18 --> Config Class Initialized
INFO - 2020-01-26 15:41:18 --> Loader Class Initialized
INFO - 2020-01-26 15:41:18 --> Helper loaded: url_helper
INFO - 2020-01-26 15:41:19 --> Helper loaded: file_helper
INFO - 2020-01-26 15:41:19 --> Helper loaded: form_helper
INFO - 2020-01-26 15:41:19 --> Helper loaded: my_helper
INFO - 2020-01-26 15:41:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:41:19 --> Controller Class Initialized
INFO - 2020-01-26 15:41:19 --> Final output sent to browser
DEBUG - 2020-01-26 15:41:19 --> Total execution time: 2.5705
INFO - 2020-01-26 15:41:42 --> Config Class Initialized
INFO - 2020-01-26 15:41:42 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:42 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:42 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:42 --> URI Class Initialized
INFO - 2020-01-26 15:41:42 --> Router Class Initialized
INFO - 2020-01-26 15:41:42 --> Output Class Initialized
INFO - 2020-01-26 15:41:43 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:43 --> Input Class Initialized
INFO - 2020-01-26 15:41:43 --> Language Class Initialized
INFO - 2020-01-26 15:41:43 --> Language Class Initialized
INFO - 2020-01-26 15:41:43 --> Config Class Initialized
INFO - 2020-01-26 15:41:43 --> Loader Class Initialized
INFO - 2020-01-26 15:41:43 --> Helper loaded: url_helper
INFO - 2020-01-26 15:41:43 --> Helper loaded: file_helper
INFO - 2020-01-26 15:41:44 --> Helper loaded: form_helper
INFO - 2020-01-26 15:41:44 --> Helper loaded: my_helper
INFO - 2020-01-26 15:41:44 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:41:44 --> Controller Class Initialized
INFO - 2020-01-26 15:41:44 --> Final output sent to browser
DEBUG - 2020-01-26 15:41:44 --> Total execution time: 2.5306
INFO - 2020-01-26 15:41:45 --> Config Class Initialized
INFO - 2020-01-26 15:41:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:45 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:45 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:45 --> URI Class Initialized
INFO - 2020-01-26 15:41:45 --> Router Class Initialized
INFO - 2020-01-26 15:41:45 --> Output Class Initialized
INFO - 2020-01-26 15:41:46 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:46 --> Input Class Initialized
INFO - 2020-01-26 15:41:46 --> Language Class Initialized
INFO - 2020-01-26 15:41:46 --> Language Class Initialized
INFO - 2020-01-26 15:41:46 --> Config Class Initialized
INFO - 2020-01-26 15:41:46 --> Loader Class Initialized
INFO - 2020-01-26 15:41:46 --> Helper loaded: url_helper
INFO - 2020-01-26 15:41:47 --> Helper loaded: file_helper
INFO - 2020-01-26 15:41:47 --> Helper loaded: form_helper
INFO - 2020-01-26 15:41:47 --> Helper loaded: my_helper
INFO - 2020-01-26 15:41:47 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:41:47 --> Controller Class Initialized
DEBUG - 2020-01-26 15:41:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-01-26 15:41:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:41:48 --> Final output sent to browser
DEBUG - 2020-01-26 15:41:48 --> Total execution time: 3.1937
INFO - 2020-01-26 15:41:58 --> Config Class Initialized
INFO - 2020-01-26 15:41:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:41:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:41:58 --> Utf8 Class Initialized
INFO - 2020-01-26 15:41:58 --> URI Class Initialized
INFO - 2020-01-26 15:41:58 --> Router Class Initialized
INFO - 2020-01-26 15:41:59 --> Output Class Initialized
INFO - 2020-01-26 15:41:59 --> Security Class Initialized
DEBUG - 2020-01-26 15:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:41:59 --> Input Class Initialized
INFO - 2020-01-26 15:41:59 --> Language Class Initialized
INFO - 2020-01-26 15:41:59 --> Language Class Initialized
INFO - 2020-01-26 15:41:59 --> Config Class Initialized
INFO - 2020-01-26 15:42:00 --> Loader Class Initialized
INFO - 2020-01-26 15:42:00 --> Helper loaded: url_helper
INFO - 2020-01-26 15:42:00 --> Helper loaded: file_helper
INFO - 2020-01-26 15:42:00 --> Helper loaded: form_helper
INFO - 2020-01-26 15:42:00 --> Helper loaded: my_helper
INFO - 2020-01-26 15:42:00 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:42:01 --> Controller Class Initialized
DEBUG - 2020-01-26 15:42:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-26 15:42:01 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:42:01 --> Final output sent to browser
DEBUG - 2020-01-26 15:42:01 --> Total execution time: 3.4402
INFO - 2020-01-26 15:42:04 --> Config Class Initialized
INFO - 2020-01-26 15:42:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:42:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:42:05 --> Utf8 Class Initialized
INFO - 2020-01-26 15:42:05 --> URI Class Initialized
INFO - 2020-01-26 15:42:05 --> Router Class Initialized
INFO - 2020-01-26 15:42:05 --> Output Class Initialized
INFO - 2020-01-26 15:42:05 --> Security Class Initialized
DEBUG - 2020-01-26 15:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:42:06 --> Input Class Initialized
INFO - 2020-01-26 15:42:06 --> Language Class Initialized
INFO - 2020-01-26 15:42:06 --> Language Class Initialized
INFO - 2020-01-26 15:42:06 --> Config Class Initialized
INFO - 2020-01-26 15:42:06 --> Loader Class Initialized
INFO - 2020-01-26 15:42:06 --> Helper loaded: url_helper
INFO - 2020-01-26 15:42:07 --> Helper loaded: file_helper
INFO - 2020-01-26 15:42:07 --> Helper loaded: form_helper
INFO - 2020-01-26 15:42:07 --> Helper loaded: my_helper
INFO - 2020-01-26 15:42:07 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:42:07 --> Controller Class Initialized
DEBUG - 2020-01-26 15:42:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-26 15:42:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:42:08 --> Final output sent to browser
DEBUG - 2020-01-26 15:42:08 --> Total execution time: 3.5365
INFO - 2020-01-26 15:42:08 --> Config Class Initialized
INFO - 2020-01-26 15:42:09 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:42:09 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:42:09 --> Utf8 Class Initialized
INFO - 2020-01-26 15:42:09 --> URI Class Initialized
INFO - 2020-01-26 15:42:09 --> Router Class Initialized
INFO - 2020-01-26 15:42:09 --> Output Class Initialized
INFO - 2020-01-26 15:42:09 --> Security Class Initialized
DEBUG - 2020-01-26 15:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:42:10 --> Input Class Initialized
INFO - 2020-01-26 15:42:10 --> Language Class Initialized
INFO - 2020-01-26 15:42:10 --> Language Class Initialized
INFO - 2020-01-26 15:42:10 --> Config Class Initialized
INFO - 2020-01-26 15:42:10 --> Loader Class Initialized
INFO - 2020-01-26 15:42:10 --> Helper loaded: url_helper
INFO - 2020-01-26 15:42:11 --> Helper loaded: file_helper
INFO - 2020-01-26 15:42:11 --> Helper loaded: form_helper
INFO - 2020-01-26 15:42:11 --> Helper loaded: my_helper
INFO - 2020-01-26 15:42:11 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:42:11 --> Controller Class Initialized
INFO - 2020-01-26 15:42:18 --> Config Class Initialized
INFO - 2020-01-26 15:42:18 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:42:18 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:42:18 --> Utf8 Class Initialized
INFO - 2020-01-26 15:42:18 --> URI Class Initialized
INFO - 2020-01-26 15:42:19 --> Router Class Initialized
INFO - 2020-01-26 15:42:19 --> Output Class Initialized
INFO - 2020-01-26 15:42:19 --> Security Class Initialized
DEBUG - 2020-01-26 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:42:19 --> Input Class Initialized
INFO - 2020-01-26 15:42:19 --> Language Class Initialized
INFO - 2020-01-26 15:42:19 --> Language Class Initialized
INFO - 2020-01-26 15:42:19 --> Config Class Initialized
INFO - 2020-01-26 15:42:20 --> Loader Class Initialized
INFO - 2020-01-26 15:42:20 --> Helper loaded: url_helper
INFO - 2020-01-26 15:42:20 --> Helper loaded: file_helper
INFO - 2020-01-26 15:42:20 --> Helper loaded: form_helper
INFO - 2020-01-26 15:42:20 --> Helper loaded: my_helper
INFO - 2020-01-26 15:42:20 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:42:21 --> Controller Class Initialized
DEBUG - 2020-01-26 15:42:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 15:42:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:42:21 --> Final output sent to browser
DEBUG - 2020-01-26 15:42:21 --> Total execution time: 3.3577
INFO - 2020-01-26 15:42:58 --> Config Class Initialized
INFO - 2020-01-26 15:42:58 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:42:58 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:42:58 --> Utf8 Class Initialized
INFO - 2020-01-26 15:42:59 --> URI Class Initialized
INFO - 2020-01-26 15:42:59 --> Router Class Initialized
INFO - 2020-01-26 15:42:59 --> Output Class Initialized
INFO - 2020-01-26 15:42:59 --> Security Class Initialized
DEBUG - 2020-01-26 15:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:42:59 --> Input Class Initialized
INFO - 2020-01-26 15:42:59 --> Language Class Initialized
INFO - 2020-01-26 15:42:59 --> Language Class Initialized
INFO - 2020-01-26 15:43:00 --> Config Class Initialized
INFO - 2020-01-26 15:43:00 --> Loader Class Initialized
INFO - 2020-01-26 15:43:00 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:00 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:00 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:00 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:01 --> Controller Class Initialized
INFO - 2020-01-26 15:43:01 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:43:01 --> Config Class Initialized
INFO - 2020-01-26 15:43:01 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:02 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:02 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:02 --> URI Class Initialized
INFO - 2020-01-26 15:43:02 --> Router Class Initialized
INFO - 2020-01-26 15:43:02 --> Output Class Initialized
INFO - 2020-01-26 15:43:02 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:03 --> Input Class Initialized
INFO - 2020-01-26 15:43:03 --> Language Class Initialized
INFO - 2020-01-26 15:43:03 --> Language Class Initialized
INFO - 2020-01-26 15:43:03 --> Config Class Initialized
INFO - 2020-01-26 15:43:03 --> Loader Class Initialized
INFO - 2020-01-26 15:43:03 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:04 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:04 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:04 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:04 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:05 --> Controller Class Initialized
INFO - 2020-01-26 15:43:05 --> Config Class Initialized
INFO - 2020-01-26 15:43:05 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:05 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:05 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:05 --> URI Class Initialized
INFO - 2020-01-26 15:43:06 --> Router Class Initialized
INFO - 2020-01-26 15:43:06 --> Output Class Initialized
INFO - 2020-01-26 15:43:06 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:06 --> Input Class Initialized
INFO - 2020-01-26 15:43:06 --> Language Class Initialized
INFO - 2020-01-26 15:43:07 --> Language Class Initialized
INFO - 2020-01-26 15:43:07 --> Config Class Initialized
INFO - 2020-01-26 15:43:07 --> Loader Class Initialized
INFO - 2020-01-26 15:43:07 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:07 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:07 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:08 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:08 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:09 --> Controller Class Initialized
DEBUG - 2020-01-26 15:43:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 15:43:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:43:10 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:10 --> Total execution time: 5.1892
INFO - 2020-01-26 15:43:16 --> Config Class Initialized
INFO - 2020-01-26 15:43:16 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:17 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:17 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:17 --> URI Class Initialized
INFO - 2020-01-26 15:43:17 --> Router Class Initialized
INFO - 2020-01-26 15:43:17 --> Output Class Initialized
INFO - 2020-01-26 15:43:17 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:18 --> Input Class Initialized
INFO - 2020-01-26 15:43:18 --> Language Class Initialized
INFO - 2020-01-26 15:43:18 --> Language Class Initialized
INFO - 2020-01-26 15:43:18 --> Config Class Initialized
INFO - 2020-01-26 15:43:18 --> Loader Class Initialized
INFO - 2020-01-26 15:43:19 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:19 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:19 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:19 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:19 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:20 --> Controller Class Initialized
INFO - 2020-01-26 15:43:20 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:43:20 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:20 --> Total execution time: 4.0723
INFO - 2020-01-26 15:43:23 --> Config Class Initialized
INFO - 2020-01-26 15:43:23 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:23 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:23 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:24 --> URI Class Initialized
INFO - 2020-01-26 15:43:24 --> Router Class Initialized
INFO - 2020-01-26 15:43:24 --> Output Class Initialized
INFO - 2020-01-26 15:43:24 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:24 --> Input Class Initialized
INFO - 2020-01-26 15:43:25 --> Language Class Initialized
INFO - 2020-01-26 15:43:25 --> Language Class Initialized
INFO - 2020-01-26 15:43:25 --> Config Class Initialized
INFO - 2020-01-26 15:43:25 --> Loader Class Initialized
INFO - 2020-01-26 15:43:25 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:26 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:26 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:26 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:26 --> Database Driver Class Initialized
INFO - 2020-01-26 15:43:26 --> Config Class Initialized
INFO - 2020-01-26 15:43:26 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-01-26 15:43:26 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:27 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:27 --> Controller Class Initialized
INFO - 2020-01-26 15:43:27 --> URI Class Initialized
DEBUG - 2020-01-26 15:43:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 15:43:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:43:27 --> Router Class Initialized
INFO - 2020-01-26 15:43:27 --> Final output sent to browser
INFO - 2020-01-26 15:43:27 --> Output Class Initialized
DEBUG - 2020-01-26 15:43:27 --> Total execution time: 4.5363
INFO - 2020-01-26 15:43:27 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:28 --> Input Class Initialized
INFO - 2020-01-26 15:43:28 --> Language Class Initialized
INFO - 2020-01-26 15:43:28 --> Language Class Initialized
INFO - 2020-01-26 15:43:28 --> Config Class Initialized
INFO - 2020-01-26 15:43:28 --> Loader Class Initialized
INFO - 2020-01-26 15:43:28 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:29 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:29 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:29 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:29 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:29 --> Controller Class Initialized
DEBUG - 2020-01-26 15:43:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-26 15:43:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:43:30 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:30 --> Total execution time: 3.6593
INFO - 2020-01-26 15:43:40 --> Config Class Initialized
INFO - 2020-01-26 15:43:41 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:41 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:41 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:41 --> URI Class Initialized
INFO - 2020-01-26 15:43:41 --> Router Class Initialized
INFO - 2020-01-26 15:43:41 --> Output Class Initialized
INFO - 2020-01-26 15:43:41 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:42 --> Input Class Initialized
INFO - 2020-01-26 15:43:42 --> Language Class Initialized
INFO - 2020-01-26 15:43:42 --> Language Class Initialized
INFO - 2020-01-26 15:43:42 --> Config Class Initialized
INFO - 2020-01-26 15:43:42 --> Loader Class Initialized
INFO - 2020-01-26 15:43:42 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:42 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:43 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:43 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:43 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:43 --> Controller Class Initialized
INFO - 2020-01-26 15:43:43 --> Helper loaded: cookie_helper
INFO - 2020-01-26 15:43:43 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:44 --> Total execution time: 2.9384
INFO - 2020-01-26 15:43:45 --> Config Class Initialized
INFO - 2020-01-26 15:43:45 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:46 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:46 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:46 --> URI Class Initialized
INFO - 2020-01-26 15:43:46 --> Router Class Initialized
INFO - 2020-01-26 15:43:46 --> Output Class Initialized
INFO - 2020-01-26 15:43:46 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:46 --> Input Class Initialized
INFO - 2020-01-26 15:43:47 --> Language Class Initialized
INFO - 2020-01-26 15:43:47 --> Language Class Initialized
INFO - 2020-01-26 15:43:47 --> Config Class Initialized
INFO - 2020-01-26 15:43:47 --> Loader Class Initialized
INFO - 2020-01-26 15:43:47 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:47 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:47 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:47 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:48 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:48 --> Controller Class Initialized
DEBUG - 2020-01-26 15:43:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-26 15:43:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:43:48 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:49 --> Total execution time: 3.0182
INFO - 2020-01-26 15:43:51 --> Config Class Initialized
INFO - 2020-01-26 15:43:51 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:43:51 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:43:51 --> Utf8 Class Initialized
INFO - 2020-01-26 15:43:52 --> URI Class Initialized
INFO - 2020-01-26 15:43:52 --> Router Class Initialized
INFO - 2020-01-26 15:43:52 --> Output Class Initialized
INFO - 2020-01-26 15:43:52 --> Security Class Initialized
DEBUG - 2020-01-26 15:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:43:52 --> Input Class Initialized
INFO - 2020-01-26 15:43:52 --> Language Class Initialized
INFO - 2020-01-26 15:43:52 --> Language Class Initialized
INFO - 2020-01-26 15:43:53 --> Config Class Initialized
INFO - 2020-01-26 15:43:53 --> Loader Class Initialized
INFO - 2020-01-26 15:43:53 --> Helper loaded: url_helper
INFO - 2020-01-26 15:43:53 --> Helper loaded: file_helper
INFO - 2020-01-26 15:43:53 --> Helper loaded: form_helper
INFO - 2020-01-26 15:43:53 --> Helper loaded: my_helper
INFO - 2020-01-26 15:43:53 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:43:54 --> Controller Class Initialized
DEBUG - 2020-01-26 15:43:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 15:43:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:43:54 --> Final output sent to browser
DEBUG - 2020-01-26 15:43:54 --> Total execution time: 2.9600
INFO - 2020-01-26 15:50:40 --> Config Class Initialized
INFO - 2020-01-26 15:50:40 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:50:40 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:50:40 --> Utf8 Class Initialized
INFO - 2020-01-26 15:50:40 --> URI Class Initialized
INFO - 2020-01-26 15:50:41 --> Router Class Initialized
INFO - 2020-01-26 15:50:41 --> Output Class Initialized
INFO - 2020-01-26 15:50:41 --> Security Class Initialized
DEBUG - 2020-01-26 15:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:50:41 --> Input Class Initialized
INFO - 2020-01-26 15:50:41 --> Language Class Initialized
INFO - 2020-01-26 15:50:41 --> Language Class Initialized
INFO - 2020-01-26 15:50:41 --> Config Class Initialized
INFO - 2020-01-26 15:50:41 --> Loader Class Initialized
INFO - 2020-01-26 15:50:42 --> Helper loaded: url_helper
INFO - 2020-01-26 15:50:42 --> Helper loaded: file_helper
INFO - 2020-01-26 15:50:42 --> Helper loaded: form_helper
INFO - 2020-01-26 15:50:42 --> Helper loaded: my_helper
INFO - 2020-01-26 15:50:42 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:50:42 --> Controller Class Initialized
DEBUG - 2020-01-26 15:50:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-26 15:50:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:50:43 --> Final output sent to browser
DEBUG - 2020-01-26 15:50:43 --> Total execution time: 2.9584
INFO - 2020-01-26 15:50:58 --> Config Class Initialized
INFO - 2020-01-26 15:50:59 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:50:59 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:50:59 --> Utf8 Class Initialized
INFO - 2020-01-26 15:50:59 --> URI Class Initialized
INFO - 2020-01-26 15:50:59 --> Router Class Initialized
INFO - 2020-01-26 15:50:59 --> Output Class Initialized
INFO - 2020-01-26 15:50:59 --> Security Class Initialized
DEBUG - 2020-01-26 15:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:51:00 --> Input Class Initialized
INFO - 2020-01-26 15:51:00 --> Language Class Initialized
INFO - 2020-01-26 15:51:00 --> Language Class Initialized
INFO - 2020-01-26 15:51:00 --> Config Class Initialized
INFO - 2020-01-26 15:51:00 --> Loader Class Initialized
INFO - 2020-01-26 15:51:01 --> Helper loaded: url_helper
INFO - 2020-01-26 15:51:01 --> Helper loaded: file_helper
INFO - 2020-01-26 15:51:01 --> Helper loaded: form_helper
INFO - 2020-01-26 15:51:01 --> Helper loaded: my_helper
INFO - 2020-01-26 15:51:01 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:51:02 --> Controller Class Initialized
DEBUG - 2020-01-26 15:51:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-01-26 15:51:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:51:02 --> Final output sent to browser
DEBUG - 2020-01-26 15:51:02 --> Total execution time: 3.6184
INFO - 2020-01-26 15:52:28 --> Config Class Initialized
INFO - 2020-01-26 15:52:28 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:52:29 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:52:29 --> Utf8 Class Initialized
INFO - 2020-01-26 15:52:29 --> URI Class Initialized
INFO - 2020-01-26 15:52:29 --> Router Class Initialized
INFO - 2020-01-26 15:52:29 --> Output Class Initialized
INFO - 2020-01-26 15:52:29 --> Security Class Initialized
DEBUG - 2020-01-26 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:52:29 --> Input Class Initialized
INFO - 2020-01-26 15:52:30 --> Language Class Initialized
INFO - 2020-01-26 15:52:30 --> Language Class Initialized
INFO - 2020-01-26 15:52:30 --> Config Class Initialized
INFO - 2020-01-26 15:52:30 --> Loader Class Initialized
INFO - 2020-01-26 15:52:30 --> Helper loaded: url_helper
INFO - 2020-01-26 15:52:30 --> Helper loaded: file_helper
INFO - 2020-01-26 15:52:30 --> Helper loaded: form_helper
INFO - 2020-01-26 15:52:30 --> Helper loaded: my_helper
INFO - 2020-01-26 15:52:31 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:52:31 --> Controller Class Initialized
DEBUG - 2020-01-26 15:52:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-01-26 15:52:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:52:31 --> Final output sent to browser
DEBUG - 2020-01-26 15:52:32 --> Total execution time: 3.0430
INFO - 2020-01-26 15:52:52 --> Config Class Initialized
INFO - 2020-01-26 15:52:52 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:52:52 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:52:52 --> Utf8 Class Initialized
INFO - 2020-01-26 15:52:52 --> URI Class Initialized
INFO - 2020-01-26 15:52:52 --> Router Class Initialized
INFO - 2020-01-26 15:52:52 --> Output Class Initialized
INFO - 2020-01-26 15:52:53 --> Security Class Initialized
DEBUG - 2020-01-26 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:52:53 --> Input Class Initialized
INFO - 2020-01-26 15:52:53 --> Language Class Initialized
INFO - 2020-01-26 15:52:53 --> Language Class Initialized
INFO - 2020-01-26 15:52:53 --> Config Class Initialized
INFO - 2020-01-26 15:52:53 --> Loader Class Initialized
INFO - 2020-01-26 15:52:53 --> Helper loaded: url_helper
INFO - 2020-01-26 15:52:53 --> Helper loaded: file_helper
INFO - 2020-01-26 15:52:54 --> Helper loaded: form_helper
INFO - 2020-01-26 15:52:54 --> Helper loaded: my_helper
INFO - 2020-01-26 15:52:54 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:52:54 --> Controller Class Initialized
DEBUG - 2020-01-26 15:52:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_absensi/views/list.php
DEBUG - 2020-01-26 15:52:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:52:55 --> Final output sent to browser
DEBUG - 2020-01-26 15:52:55 --> Total execution time: 2.9066
INFO - 2020-01-26 15:53:00 --> Config Class Initialized
INFO - 2020-01-26 15:53:00 --> Hooks Class Initialized
DEBUG - 2020-01-26 15:53:00 --> UTF-8 Support Enabled
INFO - 2020-01-26 15:53:00 --> Utf8 Class Initialized
INFO - 2020-01-26 15:53:00 --> URI Class Initialized
INFO - 2020-01-26 15:53:00 --> Router Class Initialized
INFO - 2020-01-26 15:53:01 --> Output Class Initialized
INFO - 2020-01-26 15:53:01 --> Security Class Initialized
DEBUG - 2020-01-26 15:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-26 15:53:01 --> Input Class Initialized
INFO - 2020-01-26 15:53:01 --> Language Class Initialized
INFO - 2020-01-26 15:53:01 --> Language Class Initialized
INFO - 2020-01-26 15:53:02 --> Config Class Initialized
INFO - 2020-01-26 15:53:02 --> Loader Class Initialized
INFO - 2020-01-26 15:53:02 --> Helper loaded: url_helper
INFO - 2020-01-26 15:53:02 --> Helper loaded: file_helper
INFO - 2020-01-26 15:53:02 --> Helper loaded: form_helper
INFO - 2020-01-26 15:53:02 --> Helper loaded: my_helper
INFO - 2020-01-26 15:53:02 --> Database Driver Class Initialized
DEBUG - 2020-01-26 15:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-26 15:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-26 15:53:03 --> Controller Class Initialized
DEBUG - 2020-01-26 15:53:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_ekstra/views/list.php
DEBUG - 2020-01-26 15:53:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-26 15:53:03 --> Final output sent to browser
DEBUG - 2020-01-26 15:53:03 --> Total execution time: 3.4960
