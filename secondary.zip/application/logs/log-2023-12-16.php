<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-16 09:53:25 --> Config Class Initialized
INFO - 2023-12-16 09:53:25 --> Hooks Class Initialized
DEBUG - 2023-12-16 09:53:25 --> UTF-8 Support Enabled
INFO - 2023-12-16 09:53:25 --> Utf8 Class Initialized
INFO - 2023-12-16 09:53:25 --> URI Class Initialized
INFO - 2023-12-16 09:53:25 --> Router Class Initialized
INFO - 2023-12-16 09:53:25 --> Output Class Initialized
INFO - 2023-12-16 09:53:25 --> Security Class Initialized
DEBUG - 2023-12-16 09:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 09:53:25 --> Input Class Initialized
INFO - 2023-12-16 09:53:25 --> Language Class Initialized
INFO - 2023-12-16 09:53:25 --> Language Class Initialized
INFO - 2023-12-16 09:53:25 --> Config Class Initialized
INFO - 2023-12-16 09:53:25 --> Loader Class Initialized
INFO - 2023-12-16 09:53:25 --> Helper loaded: url_helper
INFO - 2023-12-16 09:53:25 --> Helper loaded: file_helper
INFO - 2023-12-16 09:53:25 --> Helper loaded: form_helper
INFO - 2023-12-16 09:53:25 --> Helper loaded: my_helper
INFO - 2023-12-16 09:53:25 --> Database Driver Class Initialized
INFO - 2023-12-16 09:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 09:53:25 --> Controller Class Initialized
DEBUG - 2023-12-16 09:53:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 09:53:28 --> Config Class Initialized
INFO - 2023-12-16 09:53:28 --> Hooks Class Initialized
DEBUG - 2023-12-16 09:53:28 --> UTF-8 Support Enabled
INFO - 2023-12-16 09:53:28 --> Utf8 Class Initialized
INFO - 2023-12-16 09:53:28 --> URI Class Initialized
INFO - 2023-12-16 09:53:28 --> Router Class Initialized
INFO - 2023-12-16 09:53:28 --> Output Class Initialized
INFO - 2023-12-16 09:53:28 --> Security Class Initialized
DEBUG - 2023-12-16 09:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 09:53:28 --> Input Class Initialized
INFO - 2023-12-16 09:53:28 --> Language Class Initialized
INFO - 2023-12-16 09:53:28 --> Language Class Initialized
INFO - 2023-12-16 09:53:28 --> Config Class Initialized
INFO - 2023-12-16 09:53:28 --> Loader Class Initialized
INFO - 2023-12-16 09:53:28 --> Helper loaded: url_helper
INFO - 2023-12-16 09:53:28 --> Helper loaded: file_helper
INFO - 2023-12-16 09:53:28 --> Helper loaded: form_helper
INFO - 2023-12-16 09:53:28 --> Helper loaded: my_helper
INFO - 2023-12-16 09:53:28 --> Database Driver Class Initialized
INFO - 2023-12-16 09:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 09:53:28 --> Controller Class Initialized
DEBUG - 2023-12-16 09:53:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 09:53:33 --> Final output sent to browser
DEBUG - 2023-12-16 09:53:33 --> Total execution time: 7.4672
INFO - 2023-12-16 09:53:35 --> Final output sent to browser
DEBUG - 2023-12-16 09:53:35 --> Total execution time: 7.3499
INFO - 2023-12-16 09:53:35 --> Config Class Initialized
INFO - 2023-12-16 09:53:35 --> Hooks Class Initialized
DEBUG - 2023-12-16 09:53:35 --> UTF-8 Support Enabled
INFO - 2023-12-16 09:53:35 --> Utf8 Class Initialized
INFO - 2023-12-16 09:53:35 --> URI Class Initialized
INFO - 2023-12-16 09:53:35 --> Router Class Initialized
INFO - 2023-12-16 09:53:35 --> Output Class Initialized
INFO - 2023-12-16 09:53:35 --> Security Class Initialized
DEBUG - 2023-12-16 09:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 09:53:35 --> Input Class Initialized
INFO - 2023-12-16 09:53:35 --> Language Class Initialized
INFO - 2023-12-16 09:53:35 --> Language Class Initialized
INFO - 2023-12-16 09:53:35 --> Config Class Initialized
INFO - 2023-12-16 09:53:35 --> Loader Class Initialized
INFO - 2023-12-16 09:53:35 --> Helper loaded: url_helper
INFO - 2023-12-16 09:53:35 --> Helper loaded: file_helper
INFO - 2023-12-16 09:53:35 --> Helper loaded: form_helper
INFO - 2023-12-16 09:53:35 --> Helper loaded: my_helper
INFO - 2023-12-16 09:53:35 --> Database Driver Class Initialized
INFO - 2023-12-16 09:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 09:53:35 --> Controller Class Initialized
DEBUG - 2023-12-16 09:53:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 09:53:41 --> Final output sent to browser
DEBUG - 2023-12-16 09:53:41 --> Total execution time: 5.7441
INFO - 2023-12-16 11:08:06 --> Config Class Initialized
INFO - 2023-12-16 11:08:06 --> Hooks Class Initialized
DEBUG - 2023-12-16 11:08:06 --> UTF-8 Support Enabled
INFO - 2023-12-16 11:08:06 --> Utf8 Class Initialized
INFO - 2023-12-16 11:08:06 --> URI Class Initialized
INFO - 2023-12-16 11:08:06 --> Router Class Initialized
INFO - 2023-12-16 11:08:06 --> Output Class Initialized
INFO - 2023-12-16 11:08:06 --> Security Class Initialized
DEBUG - 2023-12-16 11:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 11:08:06 --> Input Class Initialized
INFO - 2023-12-16 11:08:06 --> Language Class Initialized
INFO - 2023-12-16 11:08:06 --> Language Class Initialized
INFO - 2023-12-16 11:08:06 --> Config Class Initialized
INFO - 2023-12-16 11:08:06 --> Loader Class Initialized
INFO - 2023-12-16 11:08:06 --> Helper loaded: url_helper
INFO - 2023-12-16 11:08:06 --> Helper loaded: file_helper
INFO - 2023-12-16 11:08:06 --> Helper loaded: form_helper
INFO - 2023-12-16 11:08:06 --> Helper loaded: my_helper
INFO - 2023-12-16 11:08:06 --> Database Driver Class Initialized
INFO - 2023-12-16 11:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 11:08:06 --> Controller Class Initialized
DEBUG - 2023-12-16 11:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-16 11:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-16 11:08:06 --> Final output sent to browser
DEBUG - 2023-12-16 11:08:06 --> Total execution time: 0.0619
INFO - 2023-12-16 13:03:45 --> Config Class Initialized
INFO - 2023-12-16 13:03:45 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:45 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:45 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:45 --> URI Class Initialized
INFO - 2023-12-16 13:03:45 --> Router Class Initialized
INFO - 2023-12-16 13:03:45 --> Output Class Initialized
INFO - 2023-12-16 13:03:45 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:45 --> Input Class Initialized
INFO - 2023-12-16 13:03:45 --> Language Class Initialized
INFO - 2023-12-16 13:03:45 --> Language Class Initialized
INFO - 2023-12-16 13:03:45 --> Config Class Initialized
INFO - 2023-12-16 13:03:45 --> Loader Class Initialized
INFO - 2023-12-16 13:03:45 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:45 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:45 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:45 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:45 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:45 --> Controller Class Initialized
INFO - 2023-12-16 13:03:45 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:03:45 --> Final output sent to browser
DEBUG - 2023-12-16 13:03:45 --> Total execution time: 0.0646
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:46 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:46 --> URI Class Initialized
INFO - 2023-12-16 13:03:46 --> Router Class Initialized
INFO - 2023-12-16 13:03:46 --> Output Class Initialized
INFO - 2023-12-16 13:03:46 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:46 --> Input Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Loader Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:46 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:46 --> Controller Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:46 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:46 --> URI Class Initialized
INFO - 2023-12-16 13:03:46 --> Router Class Initialized
INFO - 2023-12-16 13:03:46 --> Output Class Initialized
INFO - 2023-12-16 13:03:46 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:46 --> Input Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Loader Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:46 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:46 --> Controller Class Initialized
DEBUG - 2023-12-16 13:03:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-16 13:03:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-16 13:03:46 --> Final output sent to browser
DEBUG - 2023-12-16 13:03:46 --> Total execution time: 0.0341
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:46 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:46 --> URI Class Initialized
INFO - 2023-12-16 13:03:46 --> Router Class Initialized
INFO - 2023-12-16 13:03:46 --> Output Class Initialized
INFO - 2023-12-16 13:03:46 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:46 --> Input Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Loader Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:46 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:46 --> Controller Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:03:46 --> Final output sent to browser
DEBUG - 2023-12-16 13:03:46 --> Total execution time: 0.0398
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:46 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:46 --> URI Class Initialized
INFO - 2023-12-16 13:03:46 --> Router Class Initialized
INFO - 2023-12-16 13:03:46 --> Output Class Initialized
INFO - 2023-12-16 13:03:46 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:46 --> Input Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Loader Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:46 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:46 --> Controller Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:46 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:46 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:46 --> URI Class Initialized
INFO - 2023-12-16 13:03:46 --> Router Class Initialized
INFO - 2023-12-16 13:03:46 --> Output Class Initialized
INFO - 2023-12-16 13:03:46 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:46 --> Input Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Language Class Initialized
INFO - 2023-12-16 13:03:46 --> Config Class Initialized
INFO - 2023-12-16 13:03:46 --> Loader Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:46 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:46 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:46 --> Controller Class Initialized
INFO - 2023-12-16 13:03:46 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:03:47 --> Config Class Initialized
INFO - 2023-12-16 13:03:47 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:47 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:47 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:47 --> URI Class Initialized
INFO - 2023-12-16 13:03:47 --> Router Class Initialized
INFO - 2023-12-16 13:03:47 --> Output Class Initialized
INFO - 2023-12-16 13:03:47 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:47 --> Input Class Initialized
INFO - 2023-12-16 13:03:47 --> Language Class Initialized
INFO - 2023-12-16 13:03:47 --> Language Class Initialized
INFO - 2023-12-16 13:03:47 --> Config Class Initialized
INFO - 2023-12-16 13:03:47 --> Loader Class Initialized
INFO - 2023-12-16 13:03:47 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:47 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:47 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:47 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:47 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:47 --> Controller Class Initialized
DEBUG - 2023-12-16 13:03:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-16 13:03:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-16 13:03:47 --> Final output sent to browser
DEBUG - 2023-12-16 13:03:47 --> Total execution time: 0.0619
INFO - 2023-12-16 13:03:57 --> Config Class Initialized
INFO - 2023-12-16 13:03:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:57 --> URI Class Initialized
INFO - 2023-12-16 13:03:57 --> Router Class Initialized
INFO - 2023-12-16 13:03:57 --> Output Class Initialized
INFO - 2023-12-16 13:03:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:57 --> Input Class Initialized
INFO - 2023-12-16 13:03:57 --> Language Class Initialized
INFO - 2023-12-16 13:03:57 --> Language Class Initialized
INFO - 2023-12-16 13:03:57 --> Config Class Initialized
INFO - 2023-12-16 13:03:57 --> Loader Class Initialized
INFO - 2023-12-16 13:03:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:57 --> Controller Class Initialized
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:03:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:03:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:03:59 --> Config Class Initialized
INFO - 2023-12-16 13:03:59 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:03:59 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:03:59 --> Utf8 Class Initialized
INFO - 2023-12-16 13:03:59 --> URI Class Initialized
INFO - 2023-12-16 13:03:59 --> Router Class Initialized
INFO - 2023-12-16 13:03:59 --> Output Class Initialized
INFO - 2023-12-16 13:03:59 --> Security Class Initialized
DEBUG - 2023-12-16 13:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:03:59 --> Input Class Initialized
INFO - 2023-12-16 13:03:59 --> Language Class Initialized
INFO - 2023-12-16 13:03:59 --> Language Class Initialized
INFO - 2023-12-16 13:03:59 --> Config Class Initialized
INFO - 2023-12-16 13:03:59 --> Loader Class Initialized
INFO - 2023-12-16 13:03:59 --> Helper loaded: url_helper
INFO - 2023-12-16 13:03:59 --> Helper loaded: file_helper
INFO - 2023-12-16 13:03:59 --> Helper loaded: form_helper
INFO - 2023-12-16 13:03:59 --> Helper loaded: my_helper
INFO - 2023-12-16 13:03:59 --> Database Driver Class Initialized
INFO - 2023-12-16 13:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:03:59 --> Controller Class Initialized
DEBUG - 2023-12-16 13:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:04:10 --> Final output sent to browser
DEBUG - 2023-12-16 13:04:10 --> Total execution time: 11.0197
INFO - 2023-12-16 13:04:12 --> Config Class Initialized
INFO - 2023-12-16 13:04:12 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:04:12 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:04:12 --> Utf8 Class Initialized
INFO - 2023-12-16 13:04:12 --> URI Class Initialized
INFO - 2023-12-16 13:04:12 --> Router Class Initialized
INFO - 2023-12-16 13:04:12 --> Output Class Initialized
INFO - 2023-12-16 13:04:12 --> Security Class Initialized
DEBUG - 2023-12-16 13:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:04:12 --> Input Class Initialized
INFO - 2023-12-16 13:04:12 --> Language Class Initialized
INFO - 2023-12-16 13:04:12 --> Language Class Initialized
INFO - 2023-12-16 13:04:12 --> Config Class Initialized
INFO - 2023-12-16 13:04:12 --> Loader Class Initialized
INFO - 2023-12-16 13:04:12 --> Helper loaded: url_helper
INFO - 2023-12-16 13:04:12 --> Helper loaded: file_helper
INFO - 2023-12-16 13:04:12 --> Helper loaded: form_helper
INFO - 2023-12-16 13:04:12 --> Helper loaded: my_helper
INFO - 2023-12-16 13:04:12 --> Database Driver Class Initialized
INFO - 2023-12-16 13:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:04:12 --> Controller Class Initialized
DEBUG - 2023-12-16 13:04:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:04:18 --> Final output sent to browser
DEBUG - 2023-12-16 13:04:18 --> Total execution time: 5.7006
INFO - 2023-12-16 13:21:55 --> Config Class Initialized
INFO - 2023-12-16 13:21:55 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:55 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:55 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:55 --> URI Class Initialized
INFO - 2023-12-16 13:21:55 --> Router Class Initialized
INFO - 2023-12-16 13:21:55 --> Output Class Initialized
INFO - 2023-12-16 13:21:55 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:55 --> Input Class Initialized
INFO - 2023-12-16 13:21:55 --> Language Class Initialized
INFO - 2023-12-16 13:21:55 --> Language Class Initialized
INFO - 2023-12-16 13:21:55 --> Config Class Initialized
INFO - 2023-12-16 13:21:55 --> Loader Class Initialized
INFO - 2023-12-16 13:21:55 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:55 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:55 --> Controller Class Initialized
INFO - 2023-12-16 13:21:55 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:21:55 --> Final output sent to browser
DEBUG - 2023-12-16 13:21:55 --> Total execution time: 0.0427
INFO - 2023-12-16 13:21:55 --> Config Class Initialized
INFO - 2023-12-16 13:21:55 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:55 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:55 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:55 --> URI Class Initialized
INFO - 2023-12-16 13:21:55 --> Router Class Initialized
INFO - 2023-12-16 13:21:55 --> Output Class Initialized
INFO - 2023-12-16 13:21:55 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:55 --> Input Class Initialized
INFO - 2023-12-16 13:21:55 --> Language Class Initialized
INFO - 2023-12-16 13:21:55 --> Language Class Initialized
INFO - 2023-12-16 13:21:55 --> Config Class Initialized
INFO - 2023-12-16 13:21:55 --> Loader Class Initialized
INFO - 2023-12-16 13:21:55 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:55 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:55 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:55 --> Controller Class Initialized
INFO - 2023-12-16 13:21:55 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:21:56 --> Config Class Initialized
INFO - 2023-12-16 13:21:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:56 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:56 --> URI Class Initialized
INFO - 2023-12-16 13:21:56 --> Router Class Initialized
INFO - 2023-12-16 13:21:56 --> Output Class Initialized
INFO - 2023-12-16 13:21:56 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:56 --> Input Class Initialized
INFO - 2023-12-16 13:21:56 --> Language Class Initialized
INFO - 2023-12-16 13:21:56 --> Language Class Initialized
INFO - 2023-12-16 13:21:56 --> Config Class Initialized
INFO - 2023-12-16 13:21:56 --> Loader Class Initialized
INFO - 2023-12-16 13:21:56 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:56 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:56 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:56 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:56 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:56 --> Controller Class Initialized
DEBUG - 2023-12-16 13:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-16 13:21:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-16 13:21:56 --> Final output sent to browser
DEBUG - 2023-12-16 13:21:56 --> Total execution time: 0.0651
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:57 --> URI Class Initialized
INFO - 2023-12-16 13:21:57 --> Router Class Initialized
INFO - 2023-12-16 13:21:57 --> Output Class Initialized
INFO - 2023-12-16 13:21:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:57 --> Input Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Loader Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:57 --> Controller Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:21:57 --> Final output sent to browser
DEBUG - 2023-12-16 13:21:57 --> Total execution time: 0.0325
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:57 --> URI Class Initialized
INFO - 2023-12-16 13:21:57 --> Router Class Initialized
INFO - 2023-12-16 13:21:57 --> Output Class Initialized
INFO - 2023-12-16 13:21:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:57 --> Input Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Loader Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:57 --> Controller Class Initialized
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:57 --> URI Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:21:57 --> Router Class Initialized
INFO - 2023-12-16 13:21:57 --> Output Class Initialized
INFO - 2023-12-16 13:21:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:57 --> Input Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Loader Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:57 --> Controller Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: cookie_helper
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:21:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:21:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:21:57 --> URI Class Initialized
INFO - 2023-12-16 13:21:57 --> Router Class Initialized
INFO - 2023-12-16 13:21:57 --> Output Class Initialized
INFO - 2023-12-16 13:21:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:21:57 --> Input Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Language Class Initialized
INFO - 2023-12-16 13:21:57 --> Config Class Initialized
INFO - 2023-12-16 13:21:57 --> Loader Class Initialized
INFO - 2023-12-16 13:21:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:21:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:21:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:21:57 --> Controller Class Initialized
DEBUG - 2023-12-16 13:21:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-16 13:21:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-16 13:21:57 --> Final output sent to browser
DEBUG - 2023-12-16 13:21:57 --> Total execution time: 0.0452
INFO - 2023-12-16 13:22:07 --> Config Class Initialized
INFO - 2023-12-16 13:22:07 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:07 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:07 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:07 --> URI Class Initialized
INFO - 2023-12-16 13:22:07 --> Router Class Initialized
INFO - 2023-12-16 13:22:07 --> Output Class Initialized
INFO - 2023-12-16 13:22:07 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:07 --> Input Class Initialized
INFO - 2023-12-16 13:22:07 --> Language Class Initialized
INFO - 2023-12-16 13:22:07 --> Language Class Initialized
INFO - 2023-12-16 13:22:07 --> Config Class Initialized
INFO - 2023-12-16 13:22:07 --> Loader Class Initialized
INFO - 2023-12-16 13:22:07 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:07 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:07 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:07 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:07 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:07 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:22:13 --> Final output sent to browser
DEBUG - 2023-12-16 13:22:13 --> Total execution time: 5.5082
INFO - 2023-12-16 13:22:13 --> Config Class Initialized
INFO - 2023-12-16 13:22:13 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:13 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:13 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:13 --> URI Class Initialized
INFO - 2023-12-16 13:22:13 --> Router Class Initialized
INFO - 2023-12-16 13:22:13 --> Output Class Initialized
INFO - 2023-12-16 13:22:13 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:13 --> Input Class Initialized
INFO - 2023-12-16 13:22:13 --> Language Class Initialized
INFO - 2023-12-16 13:22:13 --> Language Class Initialized
INFO - 2023-12-16 13:22:13 --> Config Class Initialized
INFO - 2023-12-16 13:22:13 --> Loader Class Initialized
INFO - 2023-12-16 13:22:13 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:13 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:13 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:13 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:14 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:14 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:22:17 --> Config Class Initialized
INFO - 2023-12-16 13:22:17 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:17 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:17 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:17 --> URI Class Initialized
INFO - 2023-12-16 13:22:17 --> Router Class Initialized
INFO - 2023-12-16 13:22:17 --> Output Class Initialized
INFO - 2023-12-16 13:22:17 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:17 --> Input Class Initialized
INFO - 2023-12-16 13:22:17 --> Language Class Initialized
INFO - 2023-12-16 13:22:17 --> Language Class Initialized
INFO - 2023-12-16 13:22:17 --> Config Class Initialized
INFO - 2023-12-16 13:22:17 --> Loader Class Initialized
INFO - 2023-12-16 13:22:17 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:17 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:17 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:17 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:18 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:18 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:22:23 --> Config Class Initialized
INFO - 2023-12-16 13:22:23 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:23 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:23 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:23 --> URI Class Initialized
INFO - 2023-12-16 13:22:23 --> Router Class Initialized
INFO - 2023-12-16 13:22:23 --> Output Class Initialized
INFO - 2023-12-16 13:22:23 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:23 --> Input Class Initialized
INFO - 2023-12-16 13:22:23 --> Language Class Initialized
INFO - 2023-12-16 13:22:23 --> Language Class Initialized
INFO - 2023-12-16 13:22:23 --> Config Class Initialized
INFO - 2023-12-16 13:22:23 --> Loader Class Initialized
INFO - 2023-12-16 13:22:23 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:23 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:23 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:23 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:23 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:23 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:22:28 --> Final output sent to browser
DEBUG - 2023-12-16 13:22:28 --> Total execution time: 4.6672
INFO - 2023-12-16 13:22:52 --> Config Class Initialized
INFO - 2023-12-16 13:22:52 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:52 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:52 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:52 --> URI Class Initialized
INFO - 2023-12-16 13:22:52 --> Router Class Initialized
INFO - 2023-12-16 13:22:52 --> Output Class Initialized
INFO - 2023-12-16 13:22:52 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:52 --> Input Class Initialized
INFO - 2023-12-16 13:22:52 --> Language Class Initialized
INFO - 2023-12-16 13:22:52 --> Language Class Initialized
INFO - 2023-12-16 13:22:52 --> Config Class Initialized
INFO - 2023-12-16 13:22:52 --> Loader Class Initialized
INFO - 2023-12-16 13:22:52 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:52 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:52 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:52 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:52 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:52 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:22:56 --> Final output sent to browser
DEBUG - 2023-12-16 13:22:56 --> Total execution time: 4.4078
INFO - 2023-12-16 13:22:57 --> Config Class Initialized
INFO - 2023-12-16 13:22:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:22:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:22:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:22:57 --> URI Class Initialized
INFO - 2023-12-16 13:22:57 --> Router Class Initialized
INFO - 2023-12-16 13:22:57 --> Output Class Initialized
INFO - 2023-12-16 13:22:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:22:57 --> Input Class Initialized
INFO - 2023-12-16 13:22:57 --> Language Class Initialized
INFO - 2023-12-16 13:22:57 --> Language Class Initialized
INFO - 2023-12-16 13:22:57 --> Config Class Initialized
INFO - 2023-12-16 13:22:57 --> Loader Class Initialized
INFO - 2023-12-16 13:22:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:22:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:22:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:22:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:22:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:22:57 --> Controller Class Initialized
DEBUG - 2023-12-16 13:22:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:23:02 --> Config Class Initialized
INFO - 2023-12-16 13:23:02 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:23:02 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:23:02 --> Utf8 Class Initialized
INFO - 2023-12-16 13:23:02 --> URI Class Initialized
INFO - 2023-12-16 13:23:02 --> Router Class Initialized
INFO - 2023-12-16 13:23:02 --> Output Class Initialized
INFO - 2023-12-16 13:23:02 --> Security Class Initialized
DEBUG - 2023-12-16 13:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:23:02 --> Input Class Initialized
INFO - 2023-12-16 13:23:02 --> Language Class Initialized
INFO - 2023-12-16 13:23:02 --> Language Class Initialized
INFO - 2023-12-16 13:23:02 --> Config Class Initialized
INFO - 2023-12-16 13:23:02 --> Loader Class Initialized
INFO - 2023-12-16 13:23:02 --> Helper loaded: url_helper
INFO - 2023-12-16 13:23:02 --> Helper loaded: file_helper
INFO - 2023-12-16 13:23:02 --> Helper loaded: form_helper
INFO - 2023-12-16 13:23:02 --> Helper loaded: my_helper
INFO - 2023-12-16 13:23:02 --> Database Driver Class Initialized
INFO - 2023-12-16 13:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:23:02 --> Controller Class Initialized
DEBUG - 2023-12-16 13:23:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:23:07 --> Final output sent to browser
DEBUG - 2023-12-16 13:23:07 --> Total execution time: 4.8414
INFO - 2023-12-16 13:23:07 --> Config Class Initialized
INFO - 2023-12-16 13:23:07 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:23:07 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:23:07 --> Utf8 Class Initialized
INFO - 2023-12-16 13:23:07 --> URI Class Initialized
INFO - 2023-12-16 13:23:07 --> Router Class Initialized
INFO - 2023-12-16 13:23:07 --> Output Class Initialized
INFO - 2023-12-16 13:23:07 --> Security Class Initialized
DEBUG - 2023-12-16 13:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:23:07 --> Input Class Initialized
INFO - 2023-12-16 13:23:07 --> Language Class Initialized
INFO - 2023-12-16 13:23:07 --> Language Class Initialized
INFO - 2023-12-16 13:23:07 --> Config Class Initialized
INFO - 2023-12-16 13:23:07 --> Loader Class Initialized
INFO - 2023-12-16 13:23:07 --> Helper loaded: url_helper
INFO - 2023-12-16 13:23:07 --> Helper loaded: file_helper
INFO - 2023-12-16 13:23:07 --> Helper loaded: form_helper
INFO - 2023-12-16 13:23:07 --> Helper loaded: my_helper
INFO - 2023-12-16 13:23:07 --> Database Driver Class Initialized
INFO - 2023-12-16 13:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:23:07 --> Controller Class Initialized
DEBUG - 2023-12-16 13:23:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-16 13:23:13 --> Final output sent to browser
DEBUG - 2023-12-16 13:23:13 --> Total execution time: 5.6251
INFO - 2023-12-16 13:24:10 --> Config Class Initialized
INFO - 2023-12-16 13:24:10 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:24:10 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:24:10 --> Utf8 Class Initialized
INFO - 2023-12-16 13:24:10 --> URI Class Initialized
INFO - 2023-12-16 13:24:10 --> Router Class Initialized
INFO - 2023-12-16 13:24:10 --> Output Class Initialized
INFO - 2023-12-16 13:24:10 --> Security Class Initialized
DEBUG - 2023-12-16 13:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:24:10 --> Input Class Initialized
INFO - 2023-12-16 13:24:10 --> Language Class Initialized
INFO - 2023-12-16 13:24:10 --> Language Class Initialized
INFO - 2023-12-16 13:24:10 --> Config Class Initialized
INFO - 2023-12-16 13:24:10 --> Loader Class Initialized
INFO - 2023-12-16 13:24:10 --> Helper loaded: url_helper
INFO - 2023-12-16 13:24:10 --> Helper loaded: file_helper
INFO - 2023-12-16 13:24:10 --> Helper loaded: form_helper
INFO - 2023-12-16 13:24:10 --> Helper loaded: my_helper
INFO - 2023-12-16 13:24:10 --> Database Driver Class Initialized
INFO - 2023-12-16 13:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:24:10 --> Controller Class Initialized
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:10 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:24:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:24:16 --> Final output sent to browser
DEBUG - 2023-12-16 13:24:16 --> Total execution time: 5.8205
INFO - 2023-12-16 13:24:16 --> Config Class Initialized
INFO - 2023-12-16 13:24:16 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:24:16 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:24:16 --> Utf8 Class Initialized
INFO - 2023-12-16 13:24:16 --> URI Class Initialized
INFO - 2023-12-16 13:24:16 --> Router Class Initialized
INFO - 2023-12-16 13:24:16 --> Output Class Initialized
INFO - 2023-12-16 13:24:16 --> Security Class Initialized
DEBUG - 2023-12-16 13:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:24:16 --> Input Class Initialized
INFO - 2023-12-16 13:24:16 --> Language Class Initialized
INFO - 2023-12-16 13:24:16 --> Language Class Initialized
INFO - 2023-12-16 13:24:16 --> Config Class Initialized
INFO - 2023-12-16 13:24:16 --> Loader Class Initialized
INFO - 2023-12-16 13:24:16 --> Helper loaded: url_helper
INFO - 2023-12-16 13:24:16 --> Helper loaded: file_helper
INFO - 2023-12-16 13:24:16 --> Helper loaded: form_helper
INFO - 2023-12-16 13:24:16 --> Helper loaded: my_helper
INFO - 2023-12-16 13:24:16 --> Database Driver Class Initialized
INFO - 2023-12-16 13:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:24:16 --> Controller Class Initialized
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:16 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:24:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:24:18 --> Config Class Initialized
INFO - 2023-12-16 13:24:18 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:24:18 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:24:18 --> Utf8 Class Initialized
INFO - 2023-12-16 13:24:18 --> URI Class Initialized
INFO - 2023-12-16 13:24:18 --> Router Class Initialized
INFO - 2023-12-16 13:24:18 --> Output Class Initialized
INFO - 2023-12-16 13:24:18 --> Security Class Initialized
DEBUG - 2023-12-16 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:24:18 --> Input Class Initialized
INFO - 2023-12-16 13:24:18 --> Language Class Initialized
INFO - 2023-12-16 13:24:18 --> Language Class Initialized
INFO - 2023-12-16 13:24:18 --> Config Class Initialized
INFO - 2023-12-16 13:24:18 --> Loader Class Initialized
INFO - 2023-12-16 13:24:18 --> Helper loaded: url_helper
INFO - 2023-12-16 13:24:18 --> Helper loaded: file_helper
INFO - 2023-12-16 13:24:18 --> Helper loaded: form_helper
INFO - 2023-12-16 13:24:18 --> Helper loaded: my_helper
INFO - 2023-12-16 13:24:18 --> Database Driver Class Initialized
INFO - 2023-12-16 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:24:18 --> Controller Class Initialized
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:18 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:24:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:24:28 --> Final output sent to browser
DEBUG - 2023-12-16 13:24:28 --> Total execution time: 9.3308
INFO - 2023-12-16 13:24:28 --> Config Class Initialized
INFO - 2023-12-16 13:24:28 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:24:28 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:24:28 --> Utf8 Class Initialized
INFO - 2023-12-16 13:24:28 --> URI Class Initialized
INFO - 2023-12-16 13:24:28 --> Router Class Initialized
INFO - 2023-12-16 13:24:28 --> Output Class Initialized
INFO - 2023-12-16 13:24:28 --> Security Class Initialized
DEBUG - 2023-12-16 13:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:24:28 --> Input Class Initialized
INFO - 2023-12-16 13:24:28 --> Language Class Initialized
INFO - 2023-12-16 13:24:28 --> Language Class Initialized
INFO - 2023-12-16 13:24:28 --> Config Class Initialized
INFO - 2023-12-16 13:24:28 --> Loader Class Initialized
INFO - 2023-12-16 13:24:28 --> Helper loaded: url_helper
INFO - 2023-12-16 13:24:28 --> Helper loaded: file_helper
INFO - 2023-12-16 13:24:28 --> Helper loaded: form_helper
INFO - 2023-12-16 13:24:28 --> Helper loaded: my_helper
INFO - 2023-12-16 13:24:28 --> Database Driver Class Initialized
INFO - 2023-12-16 13:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:24:28 --> Controller Class Initialized
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:24:28 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:24:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:24:33 --> Final output sent to browser
DEBUG - 2023-12-16 13:24:33 --> Total execution time: 5.5616
INFO - 2023-12-16 13:28:47 --> Config Class Initialized
INFO - 2023-12-16 13:28:47 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:28:47 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:28:47 --> Utf8 Class Initialized
INFO - 2023-12-16 13:28:47 --> URI Class Initialized
INFO - 2023-12-16 13:28:47 --> Config Class Initialized
INFO - 2023-12-16 13:28:47 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:28:47 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:28:47 --> Utf8 Class Initialized
INFO - 2023-12-16 13:28:47 --> URI Class Initialized
INFO - 2023-12-16 13:28:47 --> Router Class Initialized
INFO - 2023-12-16 13:28:47 --> Output Class Initialized
INFO - 2023-12-16 13:28:47 --> Security Class Initialized
DEBUG - 2023-12-16 13:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:28:47 --> Input Class Initialized
INFO - 2023-12-16 13:28:47 --> Language Class Initialized
INFO - 2023-12-16 13:28:47 --> Router Class Initialized
INFO - 2023-12-16 13:28:47 --> Output Class Initialized
INFO - 2023-12-16 13:28:47 --> Security Class Initialized
DEBUG - 2023-12-16 13:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:28:47 --> Input Class Initialized
INFO - 2023-12-16 13:28:47 --> Language Class Initialized
INFO - 2023-12-16 13:28:47 --> Language Class Initialized
INFO - 2023-12-16 13:28:47 --> Config Class Initialized
INFO - 2023-12-16 13:28:47 --> Loader Class Initialized
INFO - 2023-12-16 13:28:47 --> Helper loaded: url_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: file_helper
INFO - 2023-12-16 13:28:47 --> Language Class Initialized
INFO - 2023-12-16 13:28:47 --> Config Class Initialized
INFO - 2023-12-16 13:28:47 --> Loader Class Initialized
INFO - 2023-12-16 13:28:47 --> Helper loaded: url_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: file_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: form_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: my_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: form_helper
INFO - 2023-12-16 13:28:47 --> Helper loaded: my_helper
INFO - 2023-12-16 13:28:47 --> Database Driver Class Initialized
INFO - 2023-12-16 13:28:47 --> Database Driver Class Initialized
INFO - 2023-12-16 13:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:28:47 --> Controller Class Initialized
INFO - 2023-12-16 13:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:28:47 --> Controller Class Initialized
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:47 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:28:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
DEBUG - 2023-12-16 13:28:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:28:55 --> Final output sent to browser
DEBUG - 2023-12-16 13:28:55 --> Total execution time: 8.3135
INFO - 2023-12-16 13:28:56 --> Final output sent to browser
DEBUG - 2023-12-16 13:28:56 --> Total execution time: 8.5706
INFO - 2023-12-16 13:28:56 --> Config Class Initialized
INFO - 2023-12-16 13:28:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:28:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:28:56 --> Utf8 Class Initialized
INFO - 2023-12-16 13:28:56 --> URI Class Initialized
INFO - 2023-12-16 13:28:56 --> Router Class Initialized
INFO - 2023-12-16 13:28:56 --> Output Class Initialized
INFO - 2023-12-16 13:28:56 --> Security Class Initialized
DEBUG - 2023-12-16 13:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:28:56 --> Input Class Initialized
INFO - 2023-12-16 13:28:56 --> Language Class Initialized
INFO - 2023-12-16 13:28:56 --> Language Class Initialized
INFO - 2023-12-16 13:28:56 --> Config Class Initialized
INFO - 2023-12-16 13:28:56 --> Loader Class Initialized
INFO - 2023-12-16 13:28:56 --> Helper loaded: url_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: file_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: form_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: my_helper
INFO - 2023-12-16 13:28:56 --> Database Driver Class Initialized
INFO - 2023-12-16 13:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:28:56 --> Controller Class Initialized
DEBUG - 2023-12-16 13:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:28:56 --> Config Class Initialized
INFO - 2023-12-16 13:28:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:28:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:28:56 --> Utf8 Class Initialized
INFO - 2023-12-16 13:28:56 --> URI Class Initialized
INFO - 2023-12-16 13:28:56 --> Router Class Initialized
INFO - 2023-12-16 13:28:56 --> Output Class Initialized
INFO - 2023-12-16 13:28:56 --> Security Class Initialized
DEBUG - 2023-12-16 13:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:28:56 --> Input Class Initialized
INFO - 2023-12-16 13:28:56 --> Language Class Initialized
INFO - 2023-12-16 13:28:56 --> Language Class Initialized
INFO - 2023-12-16 13:28:56 --> Config Class Initialized
INFO - 2023-12-16 13:28:56 --> Loader Class Initialized
INFO - 2023-12-16 13:28:56 --> Helper loaded: url_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: file_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: form_helper
INFO - 2023-12-16 13:28:56 --> Helper loaded: my_helper
INFO - 2023-12-16 13:28:56 --> Database Driver Class Initialized
INFO - 2023-12-16 13:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:28:56 --> Controller Class Initialized
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:56 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:28:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:28:58 --> Config Class Initialized
INFO - 2023-12-16 13:28:58 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:28:58 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:28:58 --> Utf8 Class Initialized
INFO - 2023-12-16 13:28:58 --> URI Class Initialized
INFO - 2023-12-16 13:28:58 --> Router Class Initialized
INFO - 2023-12-16 13:28:58 --> Output Class Initialized
INFO - 2023-12-16 13:28:58 --> Security Class Initialized
DEBUG - 2023-12-16 13:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:28:58 --> Input Class Initialized
INFO - 2023-12-16 13:28:58 --> Language Class Initialized
INFO - 2023-12-16 13:28:58 --> Language Class Initialized
INFO - 2023-12-16 13:28:58 --> Config Class Initialized
INFO - 2023-12-16 13:28:58 --> Loader Class Initialized
INFO - 2023-12-16 13:28:58 --> Helper loaded: url_helper
INFO - 2023-12-16 13:28:58 --> Helper loaded: file_helper
INFO - 2023-12-16 13:28:58 --> Helper loaded: form_helper
INFO - 2023-12-16 13:28:58 --> Helper loaded: my_helper
INFO - 2023-12-16 13:28:58 --> Database Driver Class Initialized
INFO - 2023-12-16 13:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:28:58 --> Controller Class Initialized
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:28:58 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:28:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:29:08 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:08 --> Total execution time: 12.0933
INFO - 2023-12-16 13:29:13 --> Config Class Initialized
INFO - 2023-12-16 13:29:13 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:29:13 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:29:13 --> Utf8 Class Initialized
INFO - 2023-12-16 13:29:13 --> URI Class Initialized
INFO - 2023-12-16 13:29:13 --> Router Class Initialized
INFO - 2023-12-16 13:29:13 --> Output Class Initialized
INFO - 2023-12-16 13:29:13 --> Security Class Initialized
DEBUG - 2023-12-16 13:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:29:13 --> Input Class Initialized
INFO - 2023-12-16 13:29:13 --> Language Class Initialized
INFO - 2023-12-16 13:29:13 --> Language Class Initialized
INFO - 2023-12-16 13:29:13 --> Config Class Initialized
INFO - 2023-12-16 13:29:13 --> Loader Class Initialized
INFO - 2023-12-16 13:29:13 --> Helper loaded: url_helper
INFO - 2023-12-16 13:29:13 --> Helper loaded: file_helper
INFO - 2023-12-16 13:29:13 --> Helper loaded: form_helper
INFO - 2023-12-16 13:29:13 --> Helper loaded: my_helper
INFO - 2023-12-16 13:29:13 --> Database Driver Class Initialized
INFO - 2023-12-16 13:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:29:13 --> Controller Class Initialized
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-16 13:29:13 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-16 13:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-16 13:29:18 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:18 --> Total execution time: 5.4031
INFO - 2023-12-16 13:29:39 --> Config Class Initialized
INFO - 2023-12-16 13:29:39 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:29:39 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:29:39 --> Utf8 Class Initialized
INFO - 2023-12-16 13:29:39 --> URI Class Initialized
INFO - 2023-12-16 13:29:39 --> Router Class Initialized
INFO - 2023-12-16 13:29:39 --> Output Class Initialized
INFO - 2023-12-16 13:29:39 --> Security Class Initialized
DEBUG - 2023-12-16 13:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:29:39 --> Input Class Initialized
INFO - 2023-12-16 13:29:39 --> Language Class Initialized
INFO - 2023-12-16 13:29:39 --> Language Class Initialized
INFO - 2023-12-16 13:29:39 --> Config Class Initialized
INFO - 2023-12-16 13:29:39 --> Loader Class Initialized
INFO - 2023-12-16 13:29:39 --> Helper loaded: url_helper
INFO - 2023-12-16 13:29:39 --> Helper loaded: file_helper
INFO - 2023-12-16 13:29:39 --> Helper loaded: form_helper
INFO - 2023-12-16 13:29:39 --> Helper loaded: my_helper
INFO - 2023-12-16 13:29:39 --> Database Driver Class Initialized
INFO - 2023-12-16 13:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:29:39 --> Controller Class Initialized
DEBUG - 2023-12-16 13:29:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:29:40 --> Config Class Initialized
INFO - 2023-12-16 13:29:40 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:29:40 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:29:40 --> Utf8 Class Initialized
INFO - 2023-12-16 13:29:40 --> URI Class Initialized
INFO - 2023-12-16 13:29:40 --> Router Class Initialized
INFO - 2023-12-16 13:29:40 --> Output Class Initialized
INFO - 2023-12-16 13:29:40 --> Security Class Initialized
DEBUG - 2023-12-16 13:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:29:40 --> Input Class Initialized
INFO - 2023-12-16 13:29:40 --> Language Class Initialized
INFO - 2023-12-16 13:29:40 --> Language Class Initialized
INFO - 2023-12-16 13:29:40 --> Config Class Initialized
INFO - 2023-12-16 13:29:40 --> Loader Class Initialized
INFO - 2023-12-16 13:29:40 --> Helper loaded: url_helper
INFO - 2023-12-16 13:29:40 --> Helper loaded: file_helper
INFO - 2023-12-16 13:29:40 --> Helper loaded: form_helper
INFO - 2023-12-16 13:29:40 --> Helper loaded: my_helper
INFO - 2023-12-16 13:29:40 --> Database Driver Class Initialized
INFO - 2023-12-16 13:29:42 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:42 --> Total execution time: 3.5912
INFO - 2023-12-16 13:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:29:42 --> Controller Class Initialized
DEBUG - 2023-12-16 13:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:29:43 --> Config Class Initialized
INFO - 2023-12-16 13:29:43 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:29:43 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:29:43 --> Utf8 Class Initialized
INFO - 2023-12-16 13:29:43 --> URI Class Initialized
INFO - 2023-12-16 13:29:43 --> Router Class Initialized
INFO - 2023-12-16 13:29:43 --> Output Class Initialized
INFO - 2023-12-16 13:29:43 --> Security Class Initialized
DEBUG - 2023-12-16 13:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:29:43 --> Input Class Initialized
INFO - 2023-12-16 13:29:43 --> Language Class Initialized
INFO - 2023-12-16 13:29:43 --> Language Class Initialized
INFO - 2023-12-16 13:29:43 --> Config Class Initialized
INFO - 2023-12-16 13:29:43 --> Loader Class Initialized
INFO - 2023-12-16 13:29:43 --> Helper loaded: url_helper
INFO - 2023-12-16 13:29:43 --> Helper loaded: file_helper
INFO - 2023-12-16 13:29:43 --> Helper loaded: form_helper
INFO - 2023-12-16 13:29:43 --> Helper loaded: my_helper
INFO - 2023-12-16 13:29:43 --> Database Driver Class Initialized
INFO - 2023-12-16 13:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:29:43 --> Controller Class Initialized
DEBUG - 2023-12-16 13:29:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:29:49 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:49 --> Total execution time: 9.1763
INFO - 2023-12-16 13:29:50 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:50 --> Total execution time: 6.8933
INFO - 2023-12-16 13:29:50 --> Config Class Initialized
INFO - 2023-12-16 13:29:50 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:29:50 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:29:50 --> Utf8 Class Initialized
INFO - 2023-12-16 13:29:50 --> URI Class Initialized
INFO - 2023-12-16 13:29:50 --> Router Class Initialized
INFO - 2023-12-16 13:29:50 --> Output Class Initialized
INFO - 2023-12-16 13:29:50 --> Security Class Initialized
DEBUG - 2023-12-16 13:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:29:50 --> Input Class Initialized
INFO - 2023-12-16 13:29:50 --> Language Class Initialized
INFO - 2023-12-16 13:29:50 --> Language Class Initialized
INFO - 2023-12-16 13:29:50 --> Config Class Initialized
INFO - 2023-12-16 13:29:50 --> Loader Class Initialized
INFO - 2023-12-16 13:29:50 --> Helper loaded: url_helper
INFO - 2023-12-16 13:29:50 --> Helper loaded: file_helper
INFO - 2023-12-16 13:29:50 --> Helper loaded: form_helper
INFO - 2023-12-16 13:29:50 --> Helper loaded: my_helper
INFO - 2023-12-16 13:29:50 --> Database Driver Class Initialized
INFO - 2023-12-16 13:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:29:50 --> Controller Class Initialized
DEBUG - 2023-12-16 13:29:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:29:54 --> Final output sent to browser
DEBUG - 2023-12-16 13:29:54 --> Total execution time: 3.8849
INFO - 2023-12-16 13:43:57 --> Config Class Initialized
INFO - 2023-12-16 13:43:57 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:43:57 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:43:57 --> Utf8 Class Initialized
INFO - 2023-12-16 13:43:57 --> URI Class Initialized
INFO - 2023-12-16 13:43:57 --> Router Class Initialized
INFO - 2023-12-16 13:43:57 --> Output Class Initialized
INFO - 2023-12-16 13:43:57 --> Security Class Initialized
DEBUG - 2023-12-16 13:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:43:57 --> Input Class Initialized
INFO - 2023-12-16 13:43:57 --> Language Class Initialized
INFO - 2023-12-16 13:43:57 --> Language Class Initialized
INFO - 2023-12-16 13:43:57 --> Config Class Initialized
INFO - 2023-12-16 13:43:57 --> Loader Class Initialized
INFO - 2023-12-16 13:43:57 --> Helper loaded: url_helper
INFO - 2023-12-16 13:43:57 --> Helper loaded: file_helper
INFO - 2023-12-16 13:43:57 --> Helper loaded: form_helper
INFO - 2023-12-16 13:43:57 --> Helper loaded: my_helper
INFO - 2023-12-16 13:43:57 --> Database Driver Class Initialized
INFO - 2023-12-16 13:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:43:57 --> Controller Class Initialized
DEBUG - 2023-12-16 13:43:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:44:01 --> Config Class Initialized
INFO - 2023-12-16 13:44:01 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:44:01 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:44:01 --> Utf8 Class Initialized
INFO - 2023-12-16 13:44:01 --> URI Class Initialized
INFO - 2023-12-16 13:44:01 --> Router Class Initialized
INFO - 2023-12-16 13:44:01 --> Output Class Initialized
INFO - 2023-12-16 13:44:01 --> Security Class Initialized
DEBUG - 2023-12-16 13:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:44:01 --> Input Class Initialized
INFO - 2023-12-16 13:44:01 --> Language Class Initialized
INFO - 2023-12-16 13:44:01 --> Language Class Initialized
INFO - 2023-12-16 13:44:01 --> Config Class Initialized
INFO - 2023-12-16 13:44:01 --> Loader Class Initialized
INFO - 2023-12-16 13:44:01 --> Helper loaded: url_helper
INFO - 2023-12-16 13:44:01 --> Helper loaded: file_helper
INFO - 2023-12-16 13:44:01 --> Helper loaded: form_helper
INFO - 2023-12-16 13:44:01 --> Helper loaded: my_helper
INFO - 2023-12-16 13:44:01 --> Database Driver Class Initialized
INFO - 2023-12-16 13:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:44:01 --> Controller Class Initialized
DEBUG - 2023-12-16 13:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:44:06 --> Final output sent to browser
DEBUG - 2023-12-16 13:44:06 --> Total execution time: 8.5686
INFO - 2023-12-16 13:44:06 --> Config Class Initialized
INFO - 2023-12-16 13:44:06 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:44:06 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:44:06 --> Utf8 Class Initialized
INFO - 2023-12-16 13:44:06 --> URI Class Initialized
INFO - 2023-12-16 13:44:06 --> Router Class Initialized
INFO - 2023-12-16 13:44:06 --> Output Class Initialized
INFO - 2023-12-16 13:44:06 --> Security Class Initialized
DEBUG - 2023-12-16 13:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:44:06 --> Input Class Initialized
INFO - 2023-12-16 13:44:06 --> Language Class Initialized
INFO - 2023-12-16 13:44:06 --> Language Class Initialized
INFO - 2023-12-16 13:44:06 --> Config Class Initialized
INFO - 2023-12-16 13:44:06 --> Loader Class Initialized
INFO - 2023-12-16 13:44:06 --> Helper loaded: url_helper
INFO - 2023-12-16 13:44:06 --> Helper loaded: file_helper
INFO - 2023-12-16 13:44:06 --> Helper loaded: form_helper
INFO - 2023-12-16 13:44:06 --> Helper loaded: my_helper
INFO - 2023-12-16 13:44:06 --> Database Driver Class Initialized
INFO - 2023-12-16 13:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:44:06 --> Controller Class Initialized
DEBUG - 2023-12-16 13:44:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:44:08 --> Final output sent to browser
DEBUG - 2023-12-16 13:44:08 --> Total execution time: 7.5174
INFO - 2023-12-16 13:44:08 --> Config Class Initialized
INFO - 2023-12-16 13:44:08 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:44:08 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:44:08 --> Utf8 Class Initialized
INFO - 2023-12-16 13:44:08 --> URI Class Initialized
INFO - 2023-12-16 13:44:08 --> Router Class Initialized
INFO - 2023-12-16 13:44:08 --> Output Class Initialized
INFO - 2023-12-16 13:44:08 --> Security Class Initialized
DEBUG - 2023-12-16 13:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:44:08 --> Input Class Initialized
INFO - 2023-12-16 13:44:08 --> Language Class Initialized
INFO - 2023-12-16 13:44:09 --> Language Class Initialized
INFO - 2023-12-16 13:44:09 --> Config Class Initialized
INFO - 2023-12-16 13:44:09 --> Loader Class Initialized
INFO - 2023-12-16 13:44:09 --> Helper loaded: url_helper
INFO - 2023-12-16 13:44:09 --> Helper loaded: file_helper
INFO - 2023-12-16 13:44:09 --> Helper loaded: form_helper
INFO - 2023-12-16 13:44:09 --> Helper loaded: my_helper
INFO - 2023-12-16 13:44:09 --> Database Driver Class Initialized
INFO - 2023-12-16 13:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:44:09 --> Controller Class Initialized
DEBUG - 2023-12-16 13:44:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-16 13:44:15 --> Final output sent to browser
DEBUG - 2023-12-16 13:44:15 --> Total execution time: 6.8392
INFO - 2023-12-16 13:44:16 --> Final output sent to browser
DEBUG - 2023-12-16 13:44:16 --> Total execution time: 9.7938
INFO - 2023-12-16 13:45:54 --> Config Class Initialized
INFO - 2023-12-16 13:45:54 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:45:54 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:45:54 --> Utf8 Class Initialized
INFO - 2023-12-16 13:45:54 --> URI Class Initialized
INFO - 2023-12-16 13:45:54 --> Router Class Initialized
INFO - 2023-12-16 13:45:54 --> Output Class Initialized
INFO - 2023-12-16 13:45:54 --> Security Class Initialized
DEBUG - 2023-12-16 13:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:45:54 --> Input Class Initialized
INFO - 2023-12-16 13:45:54 --> Language Class Initialized
INFO - 2023-12-16 13:45:54 --> Language Class Initialized
INFO - 2023-12-16 13:45:54 --> Config Class Initialized
INFO - 2023-12-16 13:45:54 --> Loader Class Initialized
INFO - 2023-12-16 13:45:54 --> Helper loaded: url_helper
INFO - 2023-12-16 13:45:54 --> Helper loaded: file_helper
INFO - 2023-12-16 13:45:54 --> Helper loaded: form_helper
INFO - 2023-12-16 13:45:54 --> Helper loaded: my_helper
INFO - 2023-12-16 13:45:54 --> Database Driver Class Initialized
INFO - 2023-12-16 13:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:45:54 --> Controller Class Initialized
DEBUG - 2023-12-16 13:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:45:56 --> Config Class Initialized
INFO - 2023-12-16 13:45:56 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:45:56 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:45:56 --> Utf8 Class Initialized
INFO - 2023-12-16 13:45:56 --> URI Class Initialized
INFO - 2023-12-16 13:45:56 --> Router Class Initialized
INFO - 2023-12-16 13:45:56 --> Output Class Initialized
INFO - 2023-12-16 13:45:56 --> Security Class Initialized
DEBUG - 2023-12-16 13:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:45:56 --> Input Class Initialized
INFO - 2023-12-16 13:45:56 --> Language Class Initialized
INFO - 2023-12-16 13:45:56 --> Language Class Initialized
INFO - 2023-12-16 13:45:56 --> Config Class Initialized
INFO - 2023-12-16 13:45:56 --> Loader Class Initialized
INFO - 2023-12-16 13:45:56 --> Helper loaded: url_helper
INFO - 2023-12-16 13:45:56 --> Helper loaded: file_helper
INFO - 2023-12-16 13:45:56 --> Helper loaded: form_helper
INFO - 2023-12-16 13:45:56 --> Helper loaded: my_helper
INFO - 2023-12-16 13:45:56 --> Database Driver Class Initialized
INFO - 2023-12-16 13:46:00 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:00 --> Total execution time: 5.4191
INFO - 2023-12-16 13:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:46:00 --> Controller Class Initialized
DEBUG - 2023-12-16 13:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:46:00 --> Config Class Initialized
INFO - 2023-12-16 13:46:00 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:46:00 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:46:00 --> Utf8 Class Initialized
INFO - 2023-12-16 13:46:00 --> URI Class Initialized
INFO - 2023-12-16 13:46:00 --> Router Class Initialized
INFO - 2023-12-16 13:46:00 --> Output Class Initialized
INFO - 2023-12-16 13:46:00 --> Security Class Initialized
DEBUG - 2023-12-16 13:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:46:00 --> Input Class Initialized
INFO - 2023-12-16 13:46:00 --> Language Class Initialized
INFO - 2023-12-16 13:46:00 --> Language Class Initialized
INFO - 2023-12-16 13:46:00 --> Config Class Initialized
INFO - 2023-12-16 13:46:00 --> Loader Class Initialized
INFO - 2023-12-16 13:46:00 --> Helper loaded: url_helper
INFO - 2023-12-16 13:46:00 --> Helper loaded: file_helper
INFO - 2023-12-16 13:46:00 --> Helper loaded: form_helper
INFO - 2023-12-16 13:46:00 --> Helper loaded: my_helper
INFO - 2023-12-16 13:46:00 --> Database Driver Class Initialized
INFO - 2023-12-16 13:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:46:00 --> Controller Class Initialized
DEBUG - 2023-12-16 13:46:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:46:02 --> Config Class Initialized
INFO - 2023-12-16 13:46:02 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:46:02 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:46:02 --> Utf8 Class Initialized
INFO - 2023-12-16 13:46:02 --> URI Class Initialized
INFO - 2023-12-16 13:46:02 --> Router Class Initialized
INFO - 2023-12-16 13:46:02 --> Output Class Initialized
INFO - 2023-12-16 13:46:02 --> Security Class Initialized
DEBUG - 2023-12-16 13:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:46:02 --> Input Class Initialized
INFO - 2023-12-16 13:46:02 --> Language Class Initialized
INFO - 2023-12-16 13:46:02 --> Language Class Initialized
INFO - 2023-12-16 13:46:02 --> Config Class Initialized
INFO - 2023-12-16 13:46:02 --> Loader Class Initialized
INFO - 2023-12-16 13:46:02 --> Helper loaded: url_helper
INFO - 2023-12-16 13:46:02 --> Helper loaded: file_helper
INFO - 2023-12-16 13:46:02 --> Helper loaded: form_helper
INFO - 2023-12-16 13:46:02 --> Helper loaded: my_helper
INFO - 2023-12-16 13:46:02 --> Database Driver Class Initialized
INFO - 2023-12-16 13:46:12 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:12 --> Total execution time: 15.9513
INFO - 2023-12-16 13:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:46:12 --> Controller Class Initialized
DEBUG - 2023-12-16 13:46:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:46:12 --> Config Class Initialized
INFO - 2023-12-16 13:46:12 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:46:12 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:46:12 --> Utf8 Class Initialized
INFO - 2023-12-16 13:46:12 --> URI Class Initialized
INFO - 2023-12-16 13:46:12 --> Router Class Initialized
INFO - 2023-12-16 13:46:12 --> Output Class Initialized
INFO - 2023-12-16 13:46:12 --> Security Class Initialized
DEBUG - 2023-12-16 13:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:46:12 --> Input Class Initialized
INFO - 2023-12-16 13:46:12 --> Language Class Initialized
INFO - 2023-12-16 13:46:12 --> Language Class Initialized
INFO - 2023-12-16 13:46:12 --> Config Class Initialized
INFO - 2023-12-16 13:46:12 --> Loader Class Initialized
INFO - 2023-12-16 13:46:12 --> Helper loaded: url_helper
INFO - 2023-12-16 13:46:12 --> Helper loaded: file_helper
INFO - 2023-12-16 13:46:12 --> Helper loaded: form_helper
INFO - 2023-12-16 13:46:12 --> Helper loaded: my_helper
INFO - 2023-12-16 13:46:12 --> Database Driver Class Initialized
INFO - 2023-12-16 13:46:12 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:12 --> Total execution time: 12.4830
INFO - 2023-12-16 13:46:18 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:18 --> Total execution time: 16.1055
INFO - 2023-12-16 13:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:46:18 --> Controller Class Initialized
DEBUG - 2023-12-16 13:46:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:46:18 --> Config Class Initialized
INFO - 2023-12-16 13:46:18 --> Hooks Class Initialized
DEBUG - 2023-12-16 13:46:18 --> UTF-8 Support Enabled
INFO - 2023-12-16 13:46:18 --> Utf8 Class Initialized
INFO - 2023-12-16 13:46:18 --> URI Class Initialized
INFO - 2023-12-16 13:46:18 --> Router Class Initialized
INFO - 2023-12-16 13:46:18 --> Output Class Initialized
INFO - 2023-12-16 13:46:18 --> Security Class Initialized
DEBUG - 2023-12-16 13:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-16 13:46:18 --> Input Class Initialized
INFO - 2023-12-16 13:46:18 --> Language Class Initialized
INFO - 2023-12-16 13:46:18 --> Language Class Initialized
INFO - 2023-12-16 13:46:18 --> Config Class Initialized
INFO - 2023-12-16 13:46:18 --> Loader Class Initialized
INFO - 2023-12-16 13:46:18 --> Helper loaded: url_helper
INFO - 2023-12-16 13:46:18 --> Helper loaded: file_helper
INFO - 2023-12-16 13:46:18 --> Helper loaded: form_helper
INFO - 2023-12-16 13:46:18 --> Helper loaded: my_helper
INFO - 2023-12-16 13:46:18 --> Database Driver Class Initialized
INFO - 2023-12-16 13:46:24 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:24 --> Total execution time: 11.8320
INFO - 2023-12-16 13:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-16 13:46:24 --> Controller Class Initialized
DEBUG - 2023-12-16 13:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-16 13:46:30 --> Final output sent to browser
DEBUG - 2023-12-16 13:46:30 --> Total execution time: 11.6462
