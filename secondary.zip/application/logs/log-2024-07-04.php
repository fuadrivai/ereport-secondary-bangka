<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-04 11:13:23 --> Config Class Initialized
INFO - 2024-07-04 11:13:23 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:13:23 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:13:23 --> Utf8 Class Initialized
INFO - 2024-07-04 11:13:23 --> URI Class Initialized
INFO - 2024-07-04 11:13:23 --> Router Class Initialized
INFO - 2024-07-04 11:13:23 --> Output Class Initialized
INFO - 2024-07-04 11:13:23 --> Security Class Initialized
DEBUG - 2024-07-04 11:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:13:23 --> Input Class Initialized
INFO - 2024-07-04 11:13:23 --> Language Class Initialized
INFO - 2024-07-04 11:13:23 --> Language Class Initialized
INFO - 2024-07-04 11:13:23 --> Config Class Initialized
INFO - 2024-07-04 11:13:23 --> Loader Class Initialized
INFO - 2024-07-04 11:13:23 --> Helper loaded: url_helper
INFO - 2024-07-04 11:13:23 --> Helper loaded: file_helper
INFO - 2024-07-04 11:13:23 --> Helper loaded: form_helper
INFO - 2024-07-04 11:13:23 --> Helper loaded: my_helper
INFO - 2024-07-04 11:13:23 --> Database Driver Class Initialized
INFO - 2024-07-04 11:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:13:23 --> Controller Class Initialized
DEBUG - 2024-07-04 11:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-04 11:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-04 11:13:24 --> Final output sent to browser
DEBUG - 2024-07-04 11:13:24 --> Total execution time: 0.0629
INFO - 2024-07-04 11:13:26 --> Config Class Initialized
INFO - 2024-07-04 11:13:26 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:13:26 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:13:26 --> Utf8 Class Initialized
INFO - 2024-07-04 11:13:26 --> URI Class Initialized
INFO - 2024-07-04 11:13:26 --> Router Class Initialized
INFO - 2024-07-04 11:13:26 --> Output Class Initialized
INFO - 2024-07-04 11:13:26 --> Security Class Initialized
DEBUG - 2024-07-04 11:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:13:26 --> Input Class Initialized
INFO - 2024-07-04 11:13:26 --> Language Class Initialized
INFO - 2024-07-04 11:13:26 --> Language Class Initialized
INFO - 2024-07-04 11:13:26 --> Config Class Initialized
INFO - 2024-07-04 11:13:26 --> Loader Class Initialized
INFO - 2024-07-04 11:13:26 --> Helper loaded: url_helper
INFO - 2024-07-04 11:13:26 --> Helper loaded: file_helper
INFO - 2024-07-04 11:13:26 --> Helper loaded: form_helper
INFO - 2024-07-04 11:13:26 --> Helper loaded: my_helper
INFO - 2024-07-04 11:13:26 --> Database Driver Class Initialized
INFO - 2024-07-04 11:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:13:26 --> Controller Class Initialized
DEBUG - 2024-07-04 11:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-04 11:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-04 11:13:26 --> Final output sent to browser
DEBUG - 2024-07-04 11:13:26 --> Total execution time: 0.0696
INFO - 2024-07-04 11:13:27 --> Config Class Initialized
INFO - 2024-07-04 11:13:27 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:13:27 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:13:27 --> Utf8 Class Initialized
INFO - 2024-07-04 11:13:27 --> URI Class Initialized
INFO - 2024-07-04 11:13:27 --> Router Class Initialized
INFO - 2024-07-04 11:13:27 --> Output Class Initialized
INFO - 2024-07-04 11:13:27 --> Security Class Initialized
DEBUG - 2024-07-04 11:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:13:27 --> Input Class Initialized
INFO - 2024-07-04 11:13:27 --> Language Class Initialized
ERROR - 2024-07-04 11:13:27 --> 404 Page Not Found: /index
INFO - 2024-07-04 11:13:27 --> Config Class Initialized
INFO - 2024-07-04 11:13:27 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:13:27 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:13:27 --> Utf8 Class Initialized
INFO - 2024-07-04 11:13:27 --> URI Class Initialized
INFO - 2024-07-04 11:13:27 --> Router Class Initialized
INFO - 2024-07-04 11:13:27 --> Output Class Initialized
INFO - 2024-07-04 11:13:27 --> Security Class Initialized
DEBUG - 2024-07-04 11:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:13:27 --> Input Class Initialized
INFO - 2024-07-04 11:13:27 --> Language Class Initialized
INFO - 2024-07-04 11:13:27 --> Language Class Initialized
INFO - 2024-07-04 11:13:27 --> Config Class Initialized
INFO - 2024-07-04 11:13:27 --> Loader Class Initialized
INFO - 2024-07-04 11:13:27 --> Helper loaded: url_helper
INFO - 2024-07-04 11:13:27 --> Helper loaded: file_helper
INFO - 2024-07-04 11:13:27 --> Helper loaded: form_helper
INFO - 2024-07-04 11:13:27 --> Helper loaded: my_helper
INFO - 2024-07-04 11:13:27 --> Database Driver Class Initialized
INFO - 2024-07-04 11:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:13:27 --> Controller Class Initialized
INFO - 2024-07-04 11:22:56 --> Config Class Initialized
INFO - 2024-07-04 11:22:56 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:22:56 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:22:56 --> Utf8 Class Initialized
INFO - 2024-07-04 11:22:56 --> URI Class Initialized
INFO - 2024-07-04 11:22:56 --> Router Class Initialized
INFO - 2024-07-04 11:22:56 --> Output Class Initialized
INFO - 2024-07-04 11:22:56 --> Security Class Initialized
DEBUG - 2024-07-04 11:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:22:56 --> Input Class Initialized
INFO - 2024-07-04 11:22:56 --> Language Class Initialized
INFO - 2024-07-04 11:22:56 --> Language Class Initialized
INFO - 2024-07-04 11:22:56 --> Config Class Initialized
INFO - 2024-07-04 11:22:56 --> Loader Class Initialized
INFO - 2024-07-04 11:22:56 --> Helper loaded: url_helper
INFO - 2024-07-04 11:22:56 --> Helper loaded: file_helper
INFO - 2024-07-04 11:22:56 --> Helper loaded: form_helper
INFO - 2024-07-04 11:22:56 --> Helper loaded: my_helper
INFO - 2024-07-04 11:22:56 --> Database Driver Class Initialized
INFO - 2024-07-04 11:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:22:56 --> Controller Class Initialized
DEBUG - 2024-07-04 11:22:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-04 11:22:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-04 11:22:56 --> Final output sent to browser
DEBUG - 2024-07-04 11:22:56 --> Total execution time: 0.0292
INFO - 2024-07-04 11:23:06 --> Config Class Initialized
INFO - 2024-07-04 11:23:06 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:06 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:06 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:06 --> URI Class Initialized
INFO - 2024-07-04 11:23:06 --> Router Class Initialized
INFO - 2024-07-04 11:23:06 --> Output Class Initialized
INFO - 2024-07-04 11:23:06 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:06 --> Input Class Initialized
INFO - 2024-07-04 11:23:06 --> Language Class Initialized
INFO - 2024-07-04 11:23:06 --> Language Class Initialized
INFO - 2024-07-04 11:23:06 --> Config Class Initialized
INFO - 2024-07-04 11:23:06 --> Loader Class Initialized
INFO - 2024-07-04 11:23:06 --> Helper loaded: url_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: file_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: form_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: my_helper
INFO - 2024-07-04 11:23:06 --> Database Driver Class Initialized
INFO - 2024-07-04 11:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:23:06 --> Controller Class Initialized
INFO - 2024-07-04 11:23:06 --> Helper loaded: cookie_helper
INFO - 2024-07-04 11:23:06 --> Final output sent to browser
DEBUG - 2024-07-04 11:23:06 --> Total execution time: 0.0599
INFO - 2024-07-04 11:23:06 --> Config Class Initialized
INFO - 2024-07-04 11:23:06 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:06 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:06 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:06 --> URI Class Initialized
INFO - 2024-07-04 11:23:06 --> Router Class Initialized
INFO - 2024-07-04 11:23:06 --> Output Class Initialized
INFO - 2024-07-04 11:23:06 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:06 --> Input Class Initialized
INFO - 2024-07-04 11:23:06 --> Language Class Initialized
INFO - 2024-07-04 11:23:06 --> Language Class Initialized
INFO - 2024-07-04 11:23:06 --> Config Class Initialized
INFO - 2024-07-04 11:23:06 --> Loader Class Initialized
INFO - 2024-07-04 11:23:06 --> Helper loaded: url_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: file_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: form_helper
INFO - 2024-07-04 11:23:06 --> Helper loaded: my_helper
INFO - 2024-07-04 11:23:06 --> Database Driver Class Initialized
INFO - 2024-07-04 11:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:23:06 --> Controller Class Initialized
DEBUG - 2024-07-04 11:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-04 11:23:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-04 11:23:06 --> Final output sent to browser
DEBUG - 2024-07-04 11:23:06 --> Total execution time: 0.0390
INFO - 2024-07-04 11:23:12 --> Config Class Initialized
INFO - 2024-07-04 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:12 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:12 --> URI Class Initialized
INFO - 2024-07-04 11:23:12 --> Router Class Initialized
INFO - 2024-07-04 11:23:12 --> Output Class Initialized
INFO - 2024-07-04 11:23:12 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:12 --> Input Class Initialized
INFO - 2024-07-04 11:23:12 --> Language Class Initialized
INFO - 2024-07-04 11:23:12 --> Language Class Initialized
INFO - 2024-07-04 11:23:12 --> Config Class Initialized
INFO - 2024-07-04 11:23:12 --> Loader Class Initialized
INFO - 2024-07-04 11:23:12 --> Helper loaded: url_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: file_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: form_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: my_helper
INFO - 2024-07-04 11:23:12 --> Database Driver Class Initialized
INFO - 2024-07-04 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:23:12 --> Controller Class Initialized
DEBUG - 2024-07-04 11:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-07-04 11:23:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-04 11:23:12 --> Final output sent to browser
DEBUG - 2024-07-04 11:23:12 --> Total execution time: 0.0496
INFO - 2024-07-04 11:23:12 --> Config Class Initialized
INFO - 2024-07-04 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:12 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:12 --> URI Class Initialized
INFO - 2024-07-04 11:23:12 --> Router Class Initialized
INFO - 2024-07-04 11:23:12 --> Output Class Initialized
INFO - 2024-07-04 11:23:12 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:12 --> Input Class Initialized
INFO - 2024-07-04 11:23:12 --> Language Class Initialized
ERROR - 2024-07-04 11:23:12 --> 404 Page Not Found: /index
INFO - 2024-07-04 11:23:12 --> Config Class Initialized
INFO - 2024-07-04 11:23:12 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:12 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:12 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:12 --> URI Class Initialized
INFO - 2024-07-04 11:23:12 --> Router Class Initialized
INFO - 2024-07-04 11:23:12 --> Output Class Initialized
INFO - 2024-07-04 11:23:12 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:12 --> Input Class Initialized
INFO - 2024-07-04 11:23:12 --> Language Class Initialized
INFO - 2024-07-04 11:23:12 --> Language Class Initialized
INFO - 2024-07-04 11:23:12 --> Config Class Initialized
INFO - 2024-07-04 11:23:12 --> Loader Class Initialized
INFO - 2024-07-04 11:23:12 --> Helper loaded: url_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: file_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: form_helper
INFO - 2024-07-04 11:23:12 --> Helper loaded: my_helper
INFO - 2024-07-04 11:23:12 --> Database Driver Class Initialized
INFO - 2024-07-04 11:23:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:23:12 --> Controller Class Initialized
INFO - 2024-07-04 11:23:19 --> Config Class Initialized
INFO - 2024-07-04 11:23:19 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:23:19 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:23:19 --> Utf8 Class Initialized
INFO - 2024-07-04 11:23:19 --> URI Class Initialized
INFO - 2024-07-04 11:23:19 --> Router Class Initialized
INFO - 2024-07-04 11:23:19 --> Output Class Initialized
INFO - 2024-07-04 11:23:19 --> Security Class Initialized
DEBUG - 2024-07-04 11:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:23:19 --> Input Class Initialized
INFO - 2024-07-04 11:23:19 --> Language Class Initialized
INFO - 2024-07-04 11:23:19 --> Language Class Initialized
INFO - 2024-07-04 11:23:19 --> Config Class Initialized
INFO - 2024-07-04 11:23:19 --> Loader Class Initialized
INFO - 2024-07-04 11:23:19 --> Helper loaded: url_helper
INFO - 2024-07-04 11:23:19 --> Helper loaded: file_helper
INFO - 2024-07-04 11:23:19 --> Helper loaded: form_helper
INFO - 2024-07-04 11:23:19 --> Helper loaded: my_helper
INFO - 2024-07-04 11:23:19 --> Database Driver Class Initialized
INFO - 2024-07-04 11:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:23:19 --> Controller Class Initialized
INFO - 2024-07-04 11:23:19 --> Final output sent to browser
DEBUG - 2024-07-04 11:23:19 --> Total execution time: 0.0276
INFO - 2024-07-04 11:25:24 --> Config Class Initialized
INFO - 2024-07-04 11:25:24 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:25:24 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:25:24 --> Utf8 Class Initialized
INFO - 2024-07-04 11:25:24 --> URI Class Initialized
INFO - 2024-07-04 11:25:24 --> Router Class Initialized
INFO - 2024-07-04 11:25:24 --> Output Class Initialized
INFO - 2024-07-04 11:25:24 --> Security Class Initialized
DEBUG - 2024-07-04 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:25:24 --> Input Class Initialized
INFO - 2024-07-04 11:25:24 --> Language Class Initialized
INFO - 2024-07-04 11:25:24 --> Language Class Initialized
INFO - 2024-07-04 11:25:24 --> Config Class Initialized
INFO - 2024-07-04 11:25:24 --> Loader Class Initialized
INFO - 2024-07-04 11:25:24 --> Helper loaded: url_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: file_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: form_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: my_helper
INFO - 2024-07-04 11:25:24 --> Database Driver Class Initialized
INFO - 2024-07-04 11:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:25:24 --> Controller Class Initialized
INFO - 2024-07-04 11:25:24 --> Final output sent to browser
DEBUG - 2024-07-04 11:25:24 --> Total execution time: 0.0288
INFO - 2024-07-04 11:25:24 --> Config Class Initialized
INFO - 2024-07-04 11:25:24 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:25:24 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:25:24 --> Utf8 Class Initialized
INFO - 2024-07-04 11:25:24 --> URI Class Initialized
INFO - 2024-07-04 11:25:24 --> Router Class Initialized
INFO - 2024-07-04 11:25:24 --> Output Class Initialized
INFO - 2024-07-04 11:25:24 --> Security Class Initialized
DEBUG - 2024-07-04 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:25:24 --> Input Class Initialized
INFO - 2024-07-04 11:25:24 --> Language Class Initialized
ERROR - 2024-07-04 11:25:24 --> 404 Page Not Found: /index
INFO - 2024-07-04 11:25:24 --> Config Class Initialized
INFO - 2024-07-04 11:25:24 --> Hooks Class Initialized
DEBUG - 2024-07-04 11:25:24 --> UTF-8 Support Enabled
INFO - 2024-07-04 11:25:24 --> Utf8 Class Initialized
INFO - 2024-07-04 11:25:24 --> URI Class Initialized
INFO - 2024-07-04 11:25:24 --> Router Class Initialized
INFO - 2024-07-04 11:25:24 --> Output Class Initialized
INFO - 2024-07-04 11:25:24 --> Security Class Initialized
DEBUG - 2024-07-04 11:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-04 11:25:24 --> Input Class Initialized
INFO - 2024-07-04 11:25:24 --> Language Class Initialized
INFO - 2024-07-04 11:25:24 --> Language Class Initialized
INFO - 2024-07-04 11:25:24 --> Config Class Initialized
INFO - 2024-07-04 11:25:24 --> Loader Class Initialized
INFO - 2024-07-04 11:25:24 --> Helper loaded: url_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: file_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: form_helper
INFO - 2024-07-04 11:25:24 --> Helper loaded: my_helper
INFO - 2024-07-04 11:25:24 --> Database Driver Class Initialized
INFO - 2024-07-04 11:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-04 11:25:24 --> Controller Class Initialized
