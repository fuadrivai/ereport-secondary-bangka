<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-02 15:47:14 --> Config Class Initialized
INFO - 2024-05-02 15:47:14 --> Hooks Class Initialized
DEBUG - 2024-05-02 15:47:14 --> UTF-8 Support Enabled
INFO - 2024-05-02 15:47:14 --> Utf8 Class Initialized
INFO - 2024-05-02 15:47:14 --> URI Class Initialized
INFO - 2024-05-02 15:47:14 --> Router Class Initialized
INFO - 2024-05-02 15:47:14 --> Output Class Initialized
INFO - 2024-05-02 15:47:14 --> Security Class Initialized
DEBUG - 2024-05-02 15:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-02 15:47:14 --> Input Class Initialized
INFO - 2024-05-02 15:47:14 --> Language Class Initialized
INFO - 2024-05-02 15:47:14 --> Language Class Initialized
INFO - 2024-05-02 15:47:14 --> Config Class Initialized
INFO - 2024-05-02 15:47:14 --> Loader Class Initialized
INFO - 2024-05-02 15:47:14 --> Helper loaded: url_helper
INFO - 2024-05-02 15:47:14 --> Helper loaded: file_helper
INFO - 2024-05-02 15:47:14 --> Helper loaded: form_helper
INFO - 2024-05-02 15:47:14 --> Helper loaded: my_helper
INFO - 2024-05-02 15:47:14 --> Database Driver Class Initialized
INFO - 2024-05-02 15:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-02 15:47:14 --> Controller Class Initialized
DEBUG - 2024-05-02 15:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-02 15:47:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-02 15:47:14 --> Final output sent to browser
DEBUG - 2024-05-02 15:47:14 --> Total execution time: 0.0533
