<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-23 14:11:49 --> Config Class Initialized
INFO - 2023-08-23 14:11:49 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:11:49 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:11:49 --> Utf8 Class Initialized
INFO - 2023-08-23 14:11:49 --> URI Class Initialized
INFO - 2023-08-23 14:11:49 --> Router Class Initialized
INFO - 2023-08-23 14:11:49 --> Output Class Initialized
INFO - 2023-08-23 14:11:49 --> Security Class Initialized
DEBUG - 2023-08-23 14:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:11:49 --> Input Class Initialized
INFO - 2023-08-23 14:11:49 --> Language Class Initialized
INFO - 2023-08-23 14:11:49 --> Language Class Initialized
INFO - 2023-08-23 14:11:49 --> Config Class Initialized
INFO - 2023-08-23 14:11:49 --> Loader Class Initialized
INFO - 2023-08-23 14:11:49 --> Helper loaded: url_helper
INFO - 2023-08-23 14:11:49 --> Helper loaded: file_helper
INFO - 2023-08-23 14:11:49 --> Helper loaded: form_helper
INFO - 2023-08-23 14:11:49 --> Helper loaded: my_helper
INFO - 2023-08-23 14:11:49 --> Database Driver Class Initialized
INFO - 2023-08-23 14:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:11:49 --> Controller Class Initialized
DEBUG - 2023-08-23 14:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-23 14:11:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:11:49 --> Final output sent to browser
DEBUG - 2023-08-23 14:11:49 --> Total execution time: 0.2026
INFO - 2023-08-23 14:11:51 --> Config Class Initialized
INFO - 2023-08-23 14:11:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:11:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:11:51 --> Utf8 Class Initialized
INFO - 2023-08-23 14:11:51 --> URI Class Initialized
INFO - 2023-08-23 14:11:51 --> Router Class Initialized
INFO - 2023-08-23 14:11:51 --> Output Class Initialized
INFO - 2023-08-23 14:11:51 --> Security Class Initialized
DEBUG - 2023-08-23 14:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:11:51 --> Input Class Initialized
INFO - 2023-08-23 14:11:51 --> Language Class Initialized
INFO - 2023-08-23 14:11:51 --> Language Class Initialized
INFO - 2023-08-23 14:11:51 --> Config Class Initialized
INFO - 2023-08-23 14:11:51 --> Loader Class Initialized
INFO - 2023-08-23 14:11:51 --> Helper loaded: url_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: file_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: form_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: my_helper
INFO - 2023-08-23 14:11:51 --> Database Driver Class Initialized
INFO - 2023-08-23 14:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:11:51 --> Controller Class Initialized
INFO - 2023-08-23 14:11:51 --> Helper loaded: cookie_helper
INFO - 2023-08-23 14:11:51 --> Final output sent to browser
DEBUG - 2023-08-23 14:11:51 --> Total execution time: 0.0591
INFO - 2023-08-23 14:11:51 --> Config Class Initialized
INFO - 2023-08-23 14:11:51 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:11:51 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:11:51 --> Utf8 Class Initialized
INFO - 2023-08-23 14:11:51 --> URI Class Initialized
INFO - 2023-08-23 14:11:51 --> Router Class Initialized
INFO - 2023-08-23 14:11:51 --> Output Class Initialized
INFO - 2023-08-23 14:11:51 --> Security Class Initialized
DEBUG - 2023-08-23 14:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:11:51 --> Input Class Initialized
INFO - 2023-08-23 14:11:51 --> Language Class Initialized
INFO - 2023-08-23 14:11:51 --> Language Class Initialized
INFO - 2023-08-23 14:11:51 --> Config Class Initialized
INFO - 2023-08-23 14:11:51 --> Loader Class Initialized
INFO - 2023-08-23 14:11:51 --> Helper loaded: url_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: file_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: form_helper
INFO - 2023-08-23 14:11:51 --> Helper loaded: my_helper
INFO - 2023-08-23 14:11:51 --> Database Driver Class Initialized
INFO - 2023-08-23 14:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:11:51 --> Controller Class Initialized
DEBUG - 2023-08-23 14:11:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-23 14:11:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:11:52 --> Final output sent to browser
DEBUG - 2023-08-23 14:11:52 --> Total execution time: 0.0947
INFO - 2023-08-23 14:15:24 --> Config Class Initialized
INFO - 2023-08-23 14:15:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:15:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:15:24 --> Utf8 Class Initialized
INFO - 2023-08-23 14:15:24 --> URI Class Initialized
INFO - 2023-08-23 14:15:24 --> Router Class Initialized
INFO - 2023-08-23 14:15:24 --> Output Class Initialized
INFO - 2023-08-23 14:15:24 --> Security Class Initialized
DEBUG - 2023-08-23 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:15:24 --> Input Class Initialized
INFO - 2023-08-23 14:15:24 --> Language Class Initialized
INFO - 2023-08-23 14:15:24 --> Language Class Initialized
INFO - 2023-08-23 14:15:24 --> Config Class Initialized
INFO - 2023-08-23 14:15:24 --> Loader Class Initialized
INFO - 2023-08-23 14:15:24 --> Helper loaded: url_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: file_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: form_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: my_helper
INFO - 2023-08-23 14:15:24 --> Database Driver Class Initialized
INFO - 2023-08-23 14:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:15:24 --> Controller Class Initialized
DEBUG - 2023-08-23 14:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-08-23 14:15:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:15:24 --> Final output sent to browser
DEBUG - 2023-08-23 14:15:24 --> Total execution time: 0.1011
INFO - 2023-08-23 14:15:24 --> Config Class Initialized
INFO - 2023-08-23 14:15:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:15:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:15:24 --> Utf8 Class Initialized
INFO - 2023-08-23 14:15:24 --> URI Class Initialized
INFO - 2023-08-23 14:15:24 --> Router Class Initialized
INFO - 2023-08-23 14:15:24 --> Output Class Initialized
INFO - 2023-08-23 14:15:24 --> Security Class Initialized
DEBUG - 2023-08-23 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:15:24 --> Input Class Initialized
INFO - 2023-08-23 14:15:24 --> Language Class Initialized
ERROR - 2023-08-23 14:15:24 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:15:24 --> Config Class Initialized
INFO - 2023-08-23 14:15:24 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:15:24 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:15:24 --> Utf8 Class Initialized
INFO - 2023-08-23 14:15:24 --> URI Class Initialized
INFO - 2023-08-23 14:15:24 --> Router Class Initialized
INFO - 2023-08-23 14:15:24 --> Output Class Initialized
INFO - 2023-08-23 14:15:24 --> Security Class Initialized
DEBUG - 2023-08-23 14:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:15:24 --> Input Class Initialized
INFO - 2023-08-23 14:15:24 --> Language Class Initialized
INFO - 2023-08-23 14:15:24 --> Language Class Initialized
INFO - 2023-08-23 14:15:24 --> Config Class Initialized
INFO - 2023-08-23 14:15:24 --> Loader Class Initialized
INFO - 2023-08-23 14:15:24 --> Helper loaded: url_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: file_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: form_helper
INFO - 2023-08-23 14:15:24 --> Helper loaded: my_helper
INFO - 2023-08-23 14:15:24 --> Database Driver Class Initialized
INFO - 2023-08-23 14:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:15:24 --> Controller Class Initialized
INFO - 2023-08-23 14:15:25 --> Config Class Initialized
INFO - 2023-08-23 14:15:25 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:15:25 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:15:25 --> Utf8 Class Initialized
INFO - 2023-08-23 14:15:25 --> URI Class Initialized
INFO - 2023-08-23 14:15:25 --> Router Class Initialized
INFO - 2023-08-23 14:15:25 --> Output Class Initialized
INFO - 2023-08-23 14:15:25 --> Security Class Initialized
DEBUG - 2023-08-23 14:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:15:25 --> Input Class Initialized
INFO - 2023-08-23 14:15:25 --> Language Class Initialized
INFO - 2023-08-23 14:15:25 --> Language Class Initialized
INFO - 2023-08-23 14:15:25 --> Config Class Initialized
INFO - 2023-08-23 14:15:25 --> Loader Class Initialized
INFO - 2023-08-23 14:15:25 --> Helper loaded: url_helper
INFO - 2023-08-23 14:15:25 --> Helper loaded: file_helper
INFO - 2023-08-23 14:15:25 --> Helper loaded: form_helper
INFO - 2023-08-23 14:15:25 --> Helper loaded: my_helper
INFO - 2023-08-23 14:15:25 --> Database Driver Class Initialized
INFO - 2023-08-23 14:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:15:25 --> Controller Class Initialized
ERROR - 2023-08-23 14:15:25 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2023-08-23 14:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2023-08-23 14:15:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:15:25 --> Final output sent to browser
DEBUG - 2023-08-23 14:15:25 --> Total execution time: 0.0514
INFO - 2023-08-23 14:17:30 --> Config Class Initialized
INFO - 2023-08-23 14:17:30 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:31 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:31 --> URI Class Initialized
INFO - 2023-08-23 14:17:31 --> Router Class Initialized
INFO - 2023-08-23 14:17:31 --> Output Class Initialized
INFO - 2023-08-23 14:17:31 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:31 --> Input Class Initialized
INFO - 2023-08-23 14:17:31 --> Language Class Initialized
INFO - 2023-08-23 14:17:31 --> Language Class Initialized
INFO - 2023-08-23 14:17:31 --> Config Class Initialized
INFO - 2023-08-23 14:17:31 --> Loader Class Initialized
INFO - 2023-08-23 14:17:31 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:31 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:31 --> Controller Class Initialized
INFO - 2023-08-23 14:17:31 --> Upload Class Initialized
INFO - 2023-08-23 14:17:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-08-23 14:17:31 --> The upload path does not appear to be valid.
INFO - 2023-08-23 14:17:31 --> Config Class Initialized
INFO - 2023-08-23 14:17:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:31 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:31 --> URI Class Initialized
INFO - 2023-08-23 14:17:31 --> Router Class Initialized
INFO - 2023-08-23 14:17:31 --> Output Class Initialized
INFO - 2023-08-23 14:17:31 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:31 --> Input Class Initialized
INFO - 2023-08-23 14:17:31 --> Language Class Initialized
INFO - 2023-08-23 14:17:31 --> Language Class Initialized
INFO - 2023-08-23 14:17:31 --> Config Class Initialized
INFO - 2023-08-23 14:17:31 --> Loader Class Initialized
INFO - 2023-08-23 14:17:31 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:31 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:31 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:31 --> Controller Class Initialized
DEBUG - 2023-08-23 14:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-08-23 14:17:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:17:31 --> Final output sent to browser
DEBUG - 2023-08-23 14:17:31 --> Total execution time: 0.0484
INFO - 2023-08-23 14:17:31 --> Config Class Initialized
INFO - 2023-08-23 14:17:31 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:31 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:31 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:31 --> URI Class Initialized
INFO - 2023-08-23 14:17:31 --> Router Class Initialized
INFO - 2023-08-23 14:17:31 --> Output Class Initialized
INFO - 2023-08-23 14:17:31 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:31 --> Input Class Initialized
INFO - 2023-08-23 14:17:31 --> Language Class Initialized
ERROR - 2023-08-23 14:17:31 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:17:32 --> Config Class Initialized
INFO - 2023-08-23 14:17:32 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:32 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:32 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:32 --> URI Class Initialized
INFO - 2023-08-23 14:17:32 --> Router Class Initialized
INFO - 2023-08-23 14:17:32 --> Output Class Initialized
INFO - 2023-08-23 14:17:32 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:32 --> Input Class Initialized
INFO - 2023-08-23 14:17:32 --> Language Class Initialized
INFO - 2023-08-23 14:17:32 --> Language Class Initialized
INFO - 2023-08-23 14:17:32 --> Config Class Initialized
INFO - 2023-08-23 14:17:32 --> Loader Class Initialized
INFO - 2023-08-23 14:17:32 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:32 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:32 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:32 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:32 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:32 --> Controller Class Initialized
INFO - 2023-08-23 14:17:36 --> Config Class Initialized
INFO - 2023-08-23 14:17:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:36 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:36 --> URI Class Initialized
INFO - 2023-08-23 14:17:36 --> Router Class Initialized
INFO - 2023-08-23 14:17:36 --> Output Class Initialized
INFO - 2023-08-23 14:17:36 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:36 --> Input Class Initialized
INFO - 2023-08-23 14:17:36 --> Language Class Initialized
INFO - 2023-08-23 14:17:36 --> Language Class Initialized
INFO - 2023-08-23 14:17:36 --> Config Class Initialized
INFO - 2023-08-23 14:17:36 --> Loader Class Initialized
INFO - 2023-08-23 14:17:36 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:36 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:36 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:36 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:36 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:36 --> Controller Class Initialized
DEBUG - 2023-08-23 14:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-08-23 14:17:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:17:36 --> Final output sent to browser
DEBUG - 2023-08-23 14:17:36 --> Total execution time: 0.0894
INFO - 2023-08-23 14:17:36 --> Config Class Initialized
INFO - 2023-08-23 14:17:36 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:36 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:36 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:36 --> URI Class Initialized
INFO - 2023-08-23 14:17:36 --> Router Class Initialized
INFO - 2023-08-23 14:17:36 --> Output Class Initialized
INFO - 2023-08-23 14:17:36 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:36 --> Input Class Initialized
INFO - 2023-08-23 14:17:36 --> Language Class Initialized
ERROR - 2023-08-23 14:17:36 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:17:37 --> Config Class Initialized
INFO - 2023-08-23 14:17:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:37 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:37 --> URI Class Initialized
INFO - 2023-08-23 14:17:37 --> Router Class Initialized
INFO - 2023-08-23 14:17:37 --> Output Class Initialized
INFO - 2023-08-23 14:17:37 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:37 --> Input Class Initialized
INFO - 2023-08-23 14:17:37 --> Language Class Initialized
INFO - 2023-08-23 14:17:37 --> Language Class Initialized
INFO - 2023-08-23 14:17:37 --> Config Class Initialized
INFO - 2023-08-23 14:17:37 --> Loader Class Initialized
INFO - 2023-08-23 14:17:37 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:37 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:37 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:37 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:37 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:37 --> Controller Class Initialized
INFO - 2023-08-23 14:17:39 --> Config Class Initialized
INFO - 2023-08-23 14:17:39 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:39 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:39 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:39 --> URI Class Initialized
INFO - 2023-08-23 14:17:39 --> Router Class Initialized
INFO - 2023-08-23 14:17:39 --> Output Class Initialized
INFO - 2023-08-23 14:17:39 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:39 --> Input Class Initialized
INFO - 2023-08-23 14:17:39 --> Language Class Initialized
INFO - 2023-08-23 14:17:39 --> Language Class Initialized
INFO - 2023-08-23 14:17:39 --> Config Class Initialized
INFO - 2023-08-23 14:17:39 --> Loader Class Initialized
INFO - 2023-08-23 14:17:39 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:39 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:39 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:39 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:39 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:39 --> Controller Class Initialized
DEBUG - 2023-08-23 14:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2023-08-23 14:17:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:17:39 --> Final output sent to browser
DEBUG - 2023-08-23 14:17:39 --> Total execution time: 0.0406
INFO - 2023-08-23 14:17:41 --> Config Class Initialized
INFO - 2023-08-23 14:17:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:41 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:41 --> URI Class Initialized
INFO - 2023-08-23 14:17:41 --> Router Class Initialized
INFO - 2023-08-23 14:17:41 --> Output Class Initialized
INFO - 2023-08-23 14:17:41 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:41 --> Input Class Initialized
INFO - 2023-08-23 14:17:41 --> Language Class Initialized
INFO - 2023-08-23 14:17:41 --> Language Class Initialized
INFO - 2023-08-23 14:17:41 --> Config Class Initialized
INFO - 2023-08-23 14:17:41 --> Loader Class Initialized
INFO - 2023-08-23 14:17:41 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:41 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:41 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:41 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:41 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:41 --> Controller Class Initialized
ERROR - 2023-08-23 14:17:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 47
ERROR - 2023-08-23 14:17:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2023-08-23 14:17:41 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2023-08-23 14:17:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2023-08-23 14:17:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:17:41 --> Final output sent to browser
DEBUG - 2023-08-23 14:17:41 --> Total execution time: 0.0459
INFO - 2023-08-23 14:17:48 --> Config Class Initialized
INFO - 2023-08-23 14:17:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:48 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:48 --> URI Class Initialized
INFO - 2023-08-23 14:17:48 --> Router Class Initialized
INFO - 2023-08-23 14:17:48 --> Output Class Initialized
INFO - 2023-08-23 14:17:48 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:48 --> Input Class Initialized
INFO - 2023-08-23 14:17:48 --> Language Class Initialized
INFO - 2023-08-23 14:17:48 --> Language Class Initialized
INFO - 2023-08-23 14:17:48 --> Config Class Initialized
INFO - 2023-08-23 14:17:48 --> Loader Class Initialized
INFO - 2023-08-23 14:17:48 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:48 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:48 --> Controller Class Initialized
INFO - 2023-08-23 14:17:48 --> Config Class Initialized
INFO - 2023-08-23 14:17:48 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:17:48 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:17:48 --> Utf8 Class Initialized
INFO - 2023-08-23 14:17:48 --> URI Class Initialized
INFO - 2023-08-23 14:17:48 --> Router Class Initialized
INFO - 2023-08-23 14:17:48 --> Output Class Initialized
INFO - 2023-08-23 14:17:48 --> Security Class Initialized
DEBUG - 2023-08-23 14:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:17:48 --> Input Class Initialized
INFO - 2023-08-23 14:17:48 --> Language Class Initialized
INFO - 2023-08-23 14:17:48 --> Language Class Initialized
INFO - 2023-08-23 14:17:48 --> Config Class Initialized
INFO - 2023-08-23 14:17:48 --> Loader Class Initialized
INFO - 2023-08-23 14:17:48 --> Helper loaded: url_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: file_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: form_helper
INFO - 2023-08-23 14:17:48 --> Helper loaded: my_helper
INFO - 2023-08-23 14:17:48 --> Database Driver Class Initialized
INFO - 2023-08-23 14:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:17:48 --> Controller Class Initialized
DEBUG - 2023-08-23 14:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2023-08-23 14:17:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:17:48 --> Final output sent to browser
DEBUG - 2023-08-23 14:17:48 --> Total execution time: 0.0350
INFO - 2023-08-23 14:50:33 --> Config Class Initialized
INFO - 2023-08-23 14:50:33 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:33 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:33 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:33 --> URI Class Initialized
INFO - 2023-08-23 14:50:33 --> Router Class Initialized
INFO - 2023-08-23 14:50:33 --> Output Class Initialized
INFO - 2023-08-23 14:50:33 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:33 --> Input Class Initialized
INFO - 2023-08-23 14:50:33 --> Language Class Initialized
INFO - 2023-08-23 14:50:33 --> Language Class Initialized
INFO - 2023-08-23 14:50:33 --> Config Class Initialized
INFO - 2023-08-23 14:50:33 --> Loader Class Initialized
INFO - 2023-08-23 14:50:33 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:33 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:33 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:33 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:33 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:34 --> Controller Class Initialized
DEBUG - 2023-08-23 14:50:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-08-23 14:50:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:50:34 --> Final output sent to browser
DEBUG - 2023-08-23 14:50:34 --> Total execution time: 0.3018
INFO - 2023-08-23 14:50:34 --> Config Class Initialized
INFO - 2023-08-23 14:50:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:34 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:34 --> URI Class Initialized
INFO - 2023-08-23 14:50:34 --> Router Class Initialized
INFO - 2023-08-23 14:50:34 --> Output Class Initialized
INFO - 2023-08-23 14:50:34 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:34 --> Input Class Initialized
INFO - 2023-08-23 14:50:34 --> Language Class Initialized
ERROR - 2023-08-23 14:50:34 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:50:34 --> Config Class Initialized
INFO - 2023-08-23 14:50:34 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:34 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:34 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:34 --> URI Class Initialized
INFO - 2023-08-23 14:50:34 --> Router Class Initialized
INFO - 2023-08-23 14:50:34 --> Output Class Initialized
INFO - 2023-08-23 14:50:34 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:34 --> Input Class Initialized
INFO - 2023-08-23 14:50:34 --> Language Class Initialized
INFO - 2023-08-23 14:50:34 --> Language Class Initialized
INFO - 2023-08-23 14:50:34 --> Config Class Initialized
INFO - 2023-08-23 14:50:34 --> Loader Class Initialized
INFO - 2023-08-23 14:50:34 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:34 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:34 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:34 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:34 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:34 --> Controller Class Initialized
INFO - 2023-08-23 14:50:37 --> Config Class Initialized
INFO - 2023-08-23 14:50:37 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:37 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:37 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:37 --> URI Class Initialized
INFO - 2023-08-23 14:50:37 --> Router Class Initialized
INFO - 2023-08-23 14:50:37 --> Output Class Initialized
INFO - 2023-08-23 14:50:37 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:37 --> Input Class Initialized
INFO - 2023-08-23 14:50:37 --> Language Class Initialized
INFO - 2023-08-23 14:50:37 --> Language Class Initialized
INFO - 2023-08-23 14:50:37 --> Config Class Initialized
INFO - 2023-08-23 14:50:37 --> Loader Class Initialized
INFO - 2023-08-23 14:50:37 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:37 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:37 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:37 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:37 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:37 --> Controller Class Initialized
DEBUG - 2023-08-23 14:50:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-08-23 14:50:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:50:37 --> Final output sent to browser
DEBUG - 2023-08-23 14:50:37 --> Total execution time: 0.0882
INFO - 2023-08-23 14:50:38 --> Config Class Initialized
INFO - 2023-08-23 14:50:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:38 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:38 --> URI Class Initialized
INFO - 2023-08-23 14:50:38 --> Router Class Initialized
INFO - 2023-08-23 14:50:38 --> Output Class Initialized
INFO - 2023-08-23 14:50:38 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:38 --> Input Class Initialized
INFO - 2023-08-23 14:50:38 --> Language Class Initialized
ERROR - 2023-08-23 14:50:38 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:50:38 --> Config Class Initialized
INFO - 2023-08-23 14:50:38 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:38 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:38 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:38 --> URI Class Initialized
INFO - 2023-08-23 14:50:38 --> Router Class Initialized
INFO - 2023-08-23 14:50:38 --> Output Class Initialized
INFO - 2023-08-23 14:50:38 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:38 --> Input Class Initialized
INFO - 2023-08-23 14:50:38 --> Language Class Initialized
INFO - 2023-08-23 14:50:38 --> Language Class Initialized
INFO - 2023-08-23 14:50:38 --> Config Class Initialized
INFO - 2023-08-23 14:50:38 --> Loader Class Initialized
INFO - 2023-08-23 14:50:38 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:38 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:38 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:38 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:38 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:38 --> Controller Class Initialized
INFO - 2023-08-23 14:50:40 --> Config Class Initialized
INFO - 2023-08-23 14:50:40 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:40 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:40 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:40 --> URI Class Initialized
INFO - 2023-08-23 14:50:40 --> Router Class Initialized
INFO - 2023-08-23 14:50:40 --> Output Class Initialized
INFO - 2023-08-23 14:50:40 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:40 --> Input Class Initialized
INFO - 2023-08-23 14:50:40 --> Language Class Initialized
INFO - 2023-08-23 14:50:40 --> Language Class Initialized
INFO - 2023-08-23 14:50:40 --> Config Class Initialized
INFO - 2023-08-23 14:50:40 --> Loader Class Initialized
INFO - 2023-08-23 14:50:40 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:40 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:40 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:40 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:40 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:40 --> Controller Class Initialized
DEBUG - 2023-08-23 14:50:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-08-23 14:50:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:50:40 --> Final output sent to browser
DEBUG - 2023-08-23 14:50:40 --> Total execution time: 0.2917
INFO - 2023-08-23 14:50:41 --> Config Class Initialized
INFO - 2023-08-23 14:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:41 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:41 --> URI Class Initialized
INFO - 2023-08-23 14:50:41 --> Router Class Initialized
INFO - 2023-08-23 14:50:41 --> Output Class Initialized
INFO - 2023-08-23 14:50:41 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:41 --> Input Class Initialized
INFO - 2023-08-23 14:50:41 --> Language Class Initialized
ERROR - 2023-08-23 14:50:41 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:50:41 --> Config Class Initialized
INFO - 2023-08-23 14:50:41 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:50:41 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:50:41 --> Utf8 Class Initialized
INFO - 2023-08-23 14:50:41 --> URI Class Initialized
INFO - 2023-08-23 14:50:41 --> Router Class Initialized
INFO - 2023-08-23 14:50:41 --> Output Class Initialized
INFO - 2023-08-23 14:50:41 --> Security Class Initialized
DEBUG - 2023-08-23 14:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:50:41 --> Input Class Initialized
INFO - 2023-08-23 14:50:41 --> Language Class Initialized
INFO - 2023-08-23 14:50:41 --> Language Class Initialized
INFO - 2023-08-23 14:50:41 --> Config Class Initialized
INFO - 2023-08-23 14:50:41 --> Loader Class Initialized
INFO - 2023-08-23 14:50:41 --> Helper loaded: url_helper
INFO - 2023-08-23 14:50:41 --> Helper loaded: file_helper
INFO - 2023-08-23 14:50:41 --> Helper loaded: form_helper
INFO - 2023-08-23 14:50:41 --> Helper loaded: my_helper
INFO - 2023-08-23 14:50:41 --> Database Driver Class Initialized
INFO - 2023-08-23 14:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:50:41 --> Controller Class Initialized
INFO - 2023-08-23 14:54:04 --> Config Class Initialized
INFO - 2023-08-23 14:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:54:04 --> Utf8 Class Initialized
INFO - 2023-08-23 14:54:04 --> URI Class Initialized
INFO - 2023-08-23 14:54:04 --> Router Class Initialized
INFO - 2023-08-23 14:54:04 --> Output Class Initialized
INFO - 2023-08-23 14:54:04 --> Security Class Initialized
DEBUG - 2023-08-23 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:54:04 --> Input Class Initialized
INFO - 2023-08-23 14:54:04 --> Language Class Initialized
INFO - 2023-08-23 14:54:04 --> Language Class Initialized
INFO - 2023-08-23 14:54:04 --> Config Class Initialized
INFO - 2023-08-23 14:54:04 --> Loader Class Initialized
INFO - 2023-08-23 14:54:04 --> Helper loaded: url_helper
INFO - 2023-08-23 14:54:04 --> Helper loaded: file_helper
INFO - 2023-08-23 14:54:04 --> Helper loaded: form_helper
INFO - 2023-08-23 14:54:04 --> Helper loaded: my_helper
INFO - 2023-08-23 14:54:04 --> Database Driver Class Initialized
INFO - 2023-08-23 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:54:04 --> Controller Class Initialized
DEBUG - 2023-08-23 14:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-08-23 14:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:54:04 --> Final output sent to browser
DEBUG - 2023-08-23 14:54:04 --> Total execution time: 0.4152
INFO - 2023-08-23 14:54:04 --> Config Class Initialized
INFO - 2023-08-23 14:54:04 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:54:04 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:54:04 --> Utf8 Class Initialized
INFO - 2023-08-23 14:54:04 --> URI Class Initialized
INFO - 2023-08-23 14:54:04 --> Router Class Initialized
INFO - 2023-08-23 14:54:04 --> Output Class Initialized
INFO - 2023-08-23 14:54:04 --> Security Class Initialized
DEBUG - 2023-08-23 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:54:04 --> Input Class Initialized
INFO - 2023-08-23 14:54:04 --> Language Class Initialized
ERROR - 2023-08-23 14:54:04 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:54:05 --> Config Class Initialized
INFO - 2023-08-23 14:54:05 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:54:05 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:54:05 --> Utf8 Class Initialized
INFO - 2023-08-23 14:54:05 --> URI Class Initialized
INFO - 2023-08-23 14:54:05 --> Router Class Initialized
INFO - 2023-08-23 14:54:05 --> Output Class Initialized
INFO - 2023-08-23 14:54:05 --> Security Class Initialized
DEBUG - 2023-08-23 14:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:54:05 --> Input Class Initialized
INFO - 2023-08-23 14:54:05 --> Language Class Initialized
INFO - 2023-08-23 14:54:05 --> Language Class Initialized
INFO - 2023-08-23 14:54:05 --> Config Class Initialized
INFO - 2023-08-23 14:54:05 --> Loader Class Initialized
INFO - 2023-08-23 14:54:05 --> Helper loaded: url_helper
INFO - 2023-08-23 14:54:05 --> Helper loaded: file_helper
INFO - 2023-08-23 14:54:05 --> Helper loaded: form_helper
INFO - 2023-08-23 14:54:05 --> Helper loaded: my_helper
INFO - 2023-08-23 14:54:05 --> Database Driver Class Initialized
INFO - 2023-08-23 14:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:54:05 --> Controller Class Initialized
INFO - 2023-08-23 14:57:20 --> Config Class Initialized
INFO - 2023-08-23 14:57:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:57:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:57:20 --> Utf8 Class Initialized
INFO - 2023-08-23 14:57:20 --> URI Class Initialized
INFO - 2023-08-23 14:57:20 --> Router Class Initialized
INFO - 2023-08-23 14:57:20 --> Output Class Initialized
INFO - 2023-08-23 14:57:20 --> Security Class Initialized
DEBUG - 2023-08-23 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:57:20 --> Input Class Initialized
INFO - 2023-08-23 14:57:20 --> Language Class Initialized
INFO - 2023-08-23 14:57:20 --> Language Class Initialized
INFO - 2023-08-23 14:57:20 --> Config Class Initialized
INFO - 2023-08-23 14:57:20 --> Loader Class Initialized
INFO - 2023-08-23 14:57:20 --> Helper loaded: url_helper
INFO - 2023-08-23 14:57:20 --> Helper loaded: file_helper
INFO - 2023-08-23 14:57:20 --> Helper loaded: form_helper
INFO - 2023-08-23 14:57:20 --> Helper loaded: my_helper
INFO - 2023-08-23 14:57:20 --> Database Driver Class Initialized
INFO - 2023-08-23 14:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:57:20 --> Controller Class Initialized
DEBUG - 2023-08-23 14:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-08-23 14:57:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:57:20 --> Final output sent to browser
DEBUG - 2023-08-23 14:57:20 --> Total execution time: 0.0723
INFO - 2023-08-23 14:57:20 --> Config Class Initialized
INFO - 2023-08-23 14:57:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:57:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:57:20 --> Utf8 Class Initialized
INFO - 2023-08-23 14:57:20 --> URI Class Initialized
INFO - 2023-08-23 14:57:20 --> Router Class Initialized
INFO - 2023-08-23 14:57:20 --> Output Class Initialized
INFO - 2023-08-23 14:57:20 --> Security Class Initialized
DEBUG - 2023-08-23 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:57:20 --> Input Class Initialized
INFO - 2023-08-23 14:57:20 --> Language Class Initialized
ERROR - 2023-08-23 14:57:20 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:57:21 --> Config Class Initialized
INFO - 2023-08-23 14:57:21 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:57:21 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:57:21 --> Utf8 Class Initialized
INFO - 2023-08-23 14:57:21 --> URI Class Initialized
INFO - 2023-08-23 14:57:21 --> Router Class Initialized
INFO - 2023-08-23 14:57:21 --> Output Class Initialized
INFO - 2023-08-23 14:57:21 --> Security Class Initialized
DEBUG - 2023-08-23 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:57:21 --> Input Class Initialized
INFO - 2023-08-23 14:57:21 --> Language Class Initialized
INFO - 2023-08-23 14:57:21 --> Language Class Initialized
INFO - 2023-08-23 14:57:21 --> Config Class Initialized
INFO - 2023-08-23 14:57:21 --> Loader Class Initialized
INFO - 2023-08-23 14:57:21 --> Helper loaded: url_helper
INFO - 2023-08-23 14:57:21 --> Helper loaded: file_helper
INFO - 2023-08-23 14:57:21 --> Helper loaded: form_helper
INFO - 2023-08-23 14:57:21 --> Helper loaded: my_helper
INFO - 2023-08-23 14:57:21 --> Database Driver Class Initialized
INFO - 2023-08-23 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:57:21 --> Controller Class Initialized
INFO - 2023-08-23 14:58:11 --> Config Class Initialized
INFO - 2023-08-23 14:58:11 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:11 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:11 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:11 --> URI Class Initialized
INFO - 2023-08-23 14:58:11 --> Router Class Initialized
INFO - 2023-08-23 14:58:11 --> Output Class Initialized
INFO - 2023-08-23 14:58:11 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:11 --> Input Class Initialized
INFO - 2023-08-23 14:58:11 --> Language Class Initialized
INFO - 2023-08-23 14:58:11 --> Language Class Initialized
INFO - 2023-08-23 14:58:11 --> Config Class Initialized
INFO - 2023-08-23 14:58:11 --> Loader Class Initialized
INFO - 2023-08-23 14:58:11 --> Helper loaded: url_helper
INFO - 2023-08-23 14:58:11 --> Helper loaded: file_helper
INFO - 2023-08-23 14:58:11 --> Helper loaded: form_helper
INFO - 2023-08-23 14:58:11 --> Helper loaded: my_helper
INFO - 2023-08-23 14:58:11 --> Database Driver Class Initialized
INFO - 2023-08-23 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:58:12 --> Controller Class Initialized
DEBUG - 2023-08-23 14:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-08-23 14:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:58:12 --> Final output sent to browser
DEBUG - 2023-08-23 14:58:12 --> Total execution time: 0.1062
INFO - 2023-08-23 14:58:12 --> Config Class Initialized
INFO - 2023-08-23 14:58:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:12 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:12 --> URI Class Initialized
INFO - 2023-08-23 14:58:12 --> Router Class Initialized
INFO - 2023-08-23 14:58:12 --> Output Class Initialized
INFO - 2023-08-23 14:58:12 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:12 --> Input Class Initialized
INFO - 2023-08-23 14:58:12 --> Language Class Initialized
ERROR - 2023-08-23 14:58:12 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:58:12 --> Config Class Initialized
INFO - 2023-08-23 14:58:12 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:12 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:12 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:12 --> URI Class Initialized
INFO - 2023-08-23 14:58:12 --> Router Class Initialized
INFO - 2023-08-23 14:58:12 --> Output Class Initialized
INFO - 2023-08-23 14:58:12 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:12 --> Input Class Initialized
INFO - 2023-08-23 14:58:12 --> Language Class Initialized
INFO - 2023-08-23 14:58:12 --> Language Class Initialized
INFO - 2023-08-23 14:58:12 --> Config Class Initialized
INFO - 2023-08-23 14:58:12 --> Loader Class Initialized
INFO - 2023-08-23 14:58:12 --> Helper loaded: url_helper
INFO - 2023-08-23 14:58:12 --> Helper loaded: file_helper
INFO - 2023-08-23 14:58:12 --> Helper loaded: form_helper
INFO - 2023-08-23 14:58:12 --> Helper loaded: my_helper
INFO - 2023-08-23 14:58:12 --> Database Driver Class Initialized
INFO - 2023-08-23 14:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:58:12 --> Controller Class Initialized
INFO - 2023-08-23 14:58:13 --> Config Class Initialized
INFO - 2023-08-23 14:58:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:13 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:13 --> URI Class Initialized
INFO - 2023-08-23 14:58:13 --> Router Class Initialized
INFO - 2023-08-23 14:58:13 --> Output Class Initialized
INFO - 2023-08-23 14:58:13 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:13 --> Input Class Initialized
INFO - 2023-08-23 14:58:13 --> Language Class Initialized
INFO - 2023-08-23 14:58:13 --> Language Class Initialized
INFO - 2023-08-23 14:58:13 --> Config Class Initialized
INFO - 2023-08-23 14:58:13 --> Loader Class Initialized
INFO - 2023-08-23 14:58:13 --> Helper loaded: url_helper
INFO - 2023-08-23 14:58:13 --> Helper loaded: file_helper
INFO - 2023-08-23 14:58:13 --> Helper loaded: form_helper
INFO - 2023-08-23 14:58:13 --> Helper loaded: my_helper
INFO - 2023-08-23 14:58:13 --> Database Driver Class Initialized
INFO - 2023-08-23 14:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:58:13 --> Controller Class Initialized
DEBUG - 2023-08-23 14:58:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-08-23 14:58:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:58:13 --> Final output sent to browser
DEBUG - 2023-08-23 14:58:13 --> Total execution time: 0.2205
INFO - 2023-08-23 14:58:13 --> Config Class Initialized
INFO - 2023-08-23 14:58:13 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:13 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:13 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:14 --> URI Class Initialized
INFO - 2023-08-23 14:58:14 --> Router Class Initialized
INFO - 2023-08-23 14:58:14 --> Output Class Initialized
INFO - 2023-08-23 14:58:14 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:14 --> Input Class Initialized
INFO - 2023-08-23 14:58:14 --> Language Class Initialized
ERROR - 2023-08-23 14:58:14 --> 404 Page Not Found: /index
INFO - 2023-08-23 14:58:14 --> Config Class Initialized
INFO - 2023-08-23 14:58:14 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:14 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:14 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:14 --> URI Class Initialized
INFO - 2023-08-23 14:58:14 --> Router Class Initialized
INFO - 2023-08-23 14:58:14 --> Output Class Initialized
INFO - 2023-08-23 14:58:14 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:14 --> Input Class Initialized
INFO - 2023-08-23 14:58:14 --> Language Class Initialized
INFO - 2023-08-23 14:58:14 --> Language Class Initialized
INFO - 2023-08-23 14:58:14 --> Config Class Initialized
INFO - 2023-08-23 14:58:14 --> Loader Class Initialized
INFO - 2023-08-23 14:58:14 --> Helper loaded: url_helper
INFO - 2023-08-23 14:58:14 --> Helper loaded: file_helper
INFO - 2023-08-23 14:58:14 --> Helper loaded: form_helper
INFO - 2023-08-23 14:58:14 --> Helper loaded: my_helper
INFO - 2023-08-23 14:58:15 --> Database Driver Class Initialized
INFO - 2023-08-23 14:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:58:15 --> Controller Class Initialized
INFO - 2023-08-23 14:58:20 --> Config Class Initialized
INFO - 2023-08-23 14:58:20 --> Hooks Class Initialized
DEBUG - 2023-08-23 14:58:20 --> UTF-8 Support Enabled
INFO - 2023-08-23 14:58:20 --> Utf8 Class Initialized
INFO - 2023-08-23 14:58:20 --> URI Class Initialized
DEBUG - 2023-08-23 14:58:20 --> No URI present. Default controller set.
INFO - 2023-08-23 14:58:20 --> Router Class Initialized
INFO - 2023-08-23 14:58:20 --> Output Class Initialized
INFO - 2023-08-23 14:58:20 --> Security Class Initialized
DEBUG - 2023-08-23 14:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-23 14:58:20 --> Input Class Initialized
INFO - 2023-08-23 14:58:20 --> Language Class Initialized
INFO - 2023-08-23 14:58:20 --> Language Class Initialized
INFO - 2023-08-23 14:58:20 --> Config Class Initialized
INFO - 2023-08-23 14:58:20 --> Loader Class Initialized
INFO - 2023-08-23 14:58:20 --> Helper loaded: url_helper
INFO - 2023-08-23 14:58:20 --> Helper loaded: file_helper
INFO - 2023-08-23 14:58:20 --> Helper loaded: form_helper
INFO - 2023-08-23 14:58:20 --> Helper loaded: my_helper
INFO - 2023-08-23 14:58:20 --> Database Driver Class Initialized
INFO - 2023-08-23 14:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-23 14:58:20 --> Controller Class Initialized
DEBUG - 2023-08-23 14:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-08-23 14:58:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-23 14:58:20 --> Final output sent to browser
DEBUG - 2023-08-23 14:58:20 --> Total execution time: 0.1398
