<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-18 09:09:21 --> Config Class Initialized
INFO - 2024-08-18 09:09:21 --> Hooks Class Initialized
DEBUG - 2024-08-18 09:09:21 --> UTF-8 Support Enabled
INFO - 2024-08-18 09:09:21 --> Utf8 Class Initialized
INFO - 2024-08-18 09:09:21 --> URI Class Initialized
INFO - 2024-08-18 09:09:21 --> Router Class Initialized
INFO - 2024-08-18 09:09:21 --> Output Class Initialized
INFO - 2024-08-18 09:09:21 --> Security Class Initialized
DEBUG - 2024-08-18 09:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 09:09:21 --> Input Class Initialized
INFO - 2024-08-18 09:09:21 --> Language Class Initialized
INFO - 2024-08-18 09:09:21 --> Language Class Initialized
INFO - 2024-08-18 09:09:21 --> Config Class Initialized
INFO - 2024-08-18 09:09:21 --> Loader Class Initialized
INFO - 2024-08-18 09:09:21 --> Helper loaded: url_helper
INFO - 2024-08-18 09:09:21 --> Helper loaded: file_helper
INFO - 2024-08-18 09:09:21 --> Helper loaded: form_helper
INFO - 2024-08-18 09:09:21 --> Helper loaded: my_helper
INFO - 2024-08-18 09:09:21 --> Database Driver Class Initialized
INFO - 2024-08-18 09:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 09:09:21 --> Controller Class Initialized
INFO - 2024-08-18 09:09:21 --> Helper loaded: cookie_helper
INFO - 2024-08-18 09:09:21 --> Final output sent to browser
DEBUG - 2024-08-18 09:09:21 --> Total execution time: 0.0733
INFO - 2024-08-18 09:09:22 --> Config Class Initialized
INFO - 2024-08-18 09:09:22 --> Hooks Class Initialized
DEBUG - 2024-08-18 09:09:22 --> UTF-8 Support Enabled
INFO - 2024-08-18 09:09:22 --> Utf8 Class Initialized
INFO - 2024-08-18 09:09:22 --> URI Class Initialized
INFO - 2024-08-18 09:09:22 --> Router Class Initialized
INFO - 2024-08-18 09:09:22 --> Output Class Initialized
INFO - 2024-08-18 09:09:22 --> Security Class Initialized
DEBUG - 2024-08-18 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 09:09:22 --> Input Class Initialized
INFO - 2024-08-18 09:09:22 --> Language Class Initialized
INFO - 2024-08-18 09:09:22 --> Language Class Initialized
INFO - 2024-08-18 09:09:22 --> Config Class Initialized
INFO - 2024-08-18 09:09:22 --> Loader Class Initialized
INFO - 2024-08-18 09:09:22 --> Helper loaded: url_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: file_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: form_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: my_helper
INFO - 2024-08-18 09:09:22 --> Database Driver Class Initialized
INFO - 2024-08-18 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 09:09:22 --> Controller Class Initialized
INFO - 2024-08-18 09:09:22 --> Helper loaded: cookie_helper
INFO - 2024-08-18 09:09:22 --> Config Class Initialized
INFO - 2024-08-18 09:09:22 --> Hooks Class Initialized
DEBUG - 2024-08-18 09:09:22 --> UTF-8 Support Enabled
INFO - 2024-08-18 09:09:22 --> Utf8 Class Initialized
INFO - 2024-08-18 09:09:22 --> URI Class Initialized
INFO - 2024-08-18 09:09:22 --> Router Class Initialized
INFO - 2024-08-18 09:09:22 --> Output Class Initialized
INFO - 2024-08-18 09:09:22 --> Security Class Initialized
DEBUG - 2024-08-18 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 09:09:22 --> Input Class Initialized
INFO - 2024-08-18 09:09:22 --> Language Class Initialized
INFO - 2024-08-18 09:09:22 --> Language Class Initialized
INFO - 2024-08-18 09:09:22 --> Config Class Initialized
INFO - 2024-08-18 09:09:22 --> Loader Class Initialized
INFO - 2024-08-18 09:09:22 --> Helper loaded: url_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: file_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: form_helper
INFO - 2024-08-18 09:09:22 --> Helper loaded: my_helper
INFO - 2024-08-18 09:09:22 --> Database Driver Class Initialized
INFO - 2024-08-18 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 09:09:22 --> Controller Class Initialized
DEBUG - 2024-08-18 09:09:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-18 09:09:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-18 09:09:22 --> Final output sent to browser
DEBUG - 2024-08-18 09:09:22 --> Total execution time: 0.0481
INFO - 2024-08-18 09:09:32 --> Config Class Initialized
INFO - 2024-08-18 09:09:32 --> Hooks Class Initialized
DEBUG - 2024-08-18 09:09:32 --> UTF-8 Support Enabled
INFO - 2024-08-18 09:09:32 --> Utf8 Class Initialized
INFO - 2024-08-18 09:09:32 --> URI Class Initialized
INFO - 2024-08-18 09:09:32 --> Router Class Initialized
INFO - 2024-08-18 09:09:32 --> Output Class Initialized
INFO - 2024-08-18 09:09:32 --> Security Class Initialized
DEBUG - 2024-08-18 09:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-18 09:09:32 --> Input Class Initialized
INFO - 2024-08-18 09:09:32 --> Language Class Initialized
INFO - 2024-08-18 09:09:32 --> Language Class Initialized
INFO - 2024-08-18 09:09:32 --> Config Class Initialized
INFO - 2024-08-18 09:09:32 --> Loader Class Initialized
INFO - 2024-08-18 09:09:32 --> Helper loaded: url_helper
INFO - 2024-08-18 09:09:32 --> Helper loaded: file_helper
INFO - 2024-08-18 09:09:32 --> Helper loaded: form_helper
INFO - 2024-08-18 09:09:32 --> Helper loaded: my_helper
INFO - 2024-08-18 09:09:32 --> Database Driver Class Initialized
INFO - 2024-08-18 09:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-18 09:09:32 --> Controller Class Initialized
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-18 09:09:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-18 09:09:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-18 09:09:35 --> Final output sent to browser
DEBUG - 2024-08-18 09:09:35 --> Total execution time: 3.2300
