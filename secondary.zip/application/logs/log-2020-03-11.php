<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-03-11 07:30:43 --> Config Class Initialized
INFO - 2020-03-11 07:30:43 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:30:43 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:30:43 --> Utf8 Class Initialized
INFO - 2020-03-11 07:30:43 --> URI Class Initialized
DEBUG - 2020-03-11 07:30:43 --> No URI present. Default controller set.
INFO - 2020-03-11 07:30:43 --> Router Class Initialized
INFO - 2020-03-11 07:30:43 --> Output Class Initialized
INFO - 2020-03-11 07:30:43 --> Security Class Initialized
DEBUG - 2020-03-11 07:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:30:43 --> Input Class Initialized
INFO - 2020-03-11 07:30:43 --> Language Class Initialized
INFO - 2020-03-11 07:30:43 --> Language Class Initialized
INFO - 2020-03-11 07:30:43 --> Config Class Initialized
INFO - 2020-03-11 07:30:43 --> Loader Class Initialized
INFO - 2020-03-11 07:30:43 --> Helper loaded: url_helper
INFO - 2020-03-11 07:30:43 --> Helper loaded: file_helper
INFO - 2020-03-11 07:30:43 --> Helper loaded: form_helper
INFO - 2020-03-11 07:30:43 --> Helper loaded: my_helper
INFO - 2020-03-11 07:30:43 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:30:43 --> Controller Class Initialized
INFO - 2020-03-11 07:30:44 --> Config Class Initialized
INFO - 2020-03-11 07:30:44 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:30:44 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:30:44 --> Utf8 Class Initialized
INFO - 2020-03-11 07:30:44 --> URI Class Initialized
INFO - 2020-03-11 07:30:44 --> Router Class Initialized
INFO - 2020-03-11 07:30:44 --> Output Class Initialized
INFO - 2020-03-11 07:30:44 --> Security Class Initialized
DEBUG - 2020-03-11 07:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:30:44 --> Input Class Initialized
INFO - 2020-03-11 07:30:44 --> Language Class Initialized
INFO - 2020-03-11 07:30:44 --> Language Class Initialized
INFO - 2020-03-11 07:30:44 --> Config Class Initialized
INFO - 2020-03-11 07:30:44 --> Loader Class Initialized
INFO - 2020-03-11 07:30:44 --> Helper loaded: url_helper
INFO - 2020-03-11 07:30:44 --> Helper loaded: file_helper
INFO - 2020-03-11 07:30:44 --> Helper loaded: form_helper
INFO - 2020-03-11 07:30:44 --> Helper loaded: my_helper
INFO - 2020-03-11 07:30:44 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:30:44 --> Controller Class Initialized
DEBUG - 2020-03-11 07:30:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-11 07:30:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 07:30:44 --> Final output sent to browser
DEBUG - 2020-03-11 07:30:44 --> Total execution time: 0.3493
INFO - 2020-03-11 07:31:15 --> Config Class Initialized
INFO - 2020-03-11 07:31:15 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:15 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:15 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:15 --> URI Class Initialized
INFO - 2020-03-11 07:31:15 --> Router Class Initialized
INFO - 2020-03-11 07:31:15 --> Output Class Initialized
INFO - 2020-03-11 07:31:15 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:15 --> Input Class Initialized
INFO - 2020-03-11 07:31:15 --> Language Class Initialized
INFO - 2020-03-11 07:31:15 --> Language Class Initialized
INFO - 2020-03-11 07:31:15 --> Config Class Initialized
INFO - 2020-03-11 07:31:15 --> Loader Class Initialized
INFO - 2020-03-11 07:31:15 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:15 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:15 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:15 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:15 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:15 --> Controller Class Initialized
INFO - 2020-03-11 07:31:15 --> Helper loaded: cookie_helper
INFO - 2020-03-11 07:31:15 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:15 --> Total execution time: 0.3479
INFO - 2020-03-11 07:31:16 --> Config Class Initialized
INFO - 2020-03-11 07:31:16 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:16 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:16 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:16 --> URI Class Initialized
INFO - 2020-03-11 07:31:16 --> Router Class Initialized
INFO - 2020-03-11 07:31:16 --> Output Class Initialized
INFO - 2020-03-11 07:31:16 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:16 --> Input Class Initialized
INFO - 2020-03-11 07:31:16 --> Language Class Initialized
INFO - 2020-03-11 07:31:16 --> Language Class Initialized
INFO - 2020-03-11 07:31:16 --> Config Class Initialized
INFO - 2020-03-11 07:31:16 --> Loader Class Initialized
INFO - 2020-03-11 07:31:16 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:16 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:16 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:16 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:16 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:16 --> Controller Class Initialized
DEBUG - 2020-03-11 07:31:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-03-11 07:31:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 07:31:16 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:16 --> Total execution time: 0.4165
INFO - 2020-03-11 07:31:24 --> Config Class Initialized
INFO - 2020-03-11 07:31:24 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:24 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:24 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:24 --> URI Class Initialized
INFO - 2020-03-11 07:31:24 --> Router Class Initialized
INFO - 2020-03-11 07:31:24 --> Output Class Initialized
INFO - 2020-03-11 07:31:24 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:24 --> Input Class Initialized
INFO - 2020-03-11 07:31:24 --> Language Class Initialized
INFO - 2020-03-11 07:31:24 --> Language Class Initialized
INFO - 2020-03-11 07:31:24 --> Config Class Initialized
INFO - 2020-03-11 07:31:24 --> Loader Class Initialized
INFO - 2020-03-11 07:31:24 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:24 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:24 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:24 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:24 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:24 --> Controller Class Initialized
DEBUG - 2020-03-11 07:31:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-03-11 07:31:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 07:31:24 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:24 --> Total execution time: 0.3720
INFO - 2020-03-11 07:31:25 --> Config Class Initialized
INFO - 2020-03-11 07:31:25 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:25 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:25 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:25 --> URI Class Initialized
INFO - 2020-03-11 07:31:25 --> Router Class Initialized
INFO - 2020-03-11 07:31:25 --> Output Class Initialized
INFO - 2020-03-11 07:31:25 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:25 --> Input Class Initialized
INFO - 2020-03-11 07:31:25 --> Language Class Initialized
INFO - 2020-03-11 07:31:25 --> Language Class Initialized
INFO - 2020-03-11 07:31:25 --> Config Class Initialized
INFO - 2020-03-11 07:31:25 --> Loader Class Initialized
INFO - 2020-03-11 07:31:26 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:26 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:26 --> Controller Class Initialized
DEBUG - 2020-03-11 07:31:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-11 07:31:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 07:31:26 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:26 --> Total execution time: 0.3290
INFO - 2020-03-11 07:31:26 --> Config Class Initialized
INFO - 2020-03-11 07:31:26 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:26 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:26 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:26 --> URI Class Initialized
INFO - 2020-03-11 07:31:26 --> Router Class Initialized
INFO - 2020-03-11 07:31:26 --> Output Class Initialized
INFO - 2020-03-11 07:31:26 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:26 --> Input Class Initialized
INFO - 2020-03-11 07:31:26 --> Language Class Initialized
INFO - 2020-03-11 07:31:26 --> Language Class Initialized
INFO - 2020-03-11 07:31:26 --> Config Class Initialized
INFO - 2020-03-11 07:31:26 --> Loader Class Initialized
INFO - 2020-03-11 07:31:26 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:26 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:26 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:26 --> Controller Class Initialized
INFO - 2020-03-11 07:31:27 --> Config Class Initialized
INFO - 2020-03-11 07:31:27 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:27 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:27 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:27 --> URI Class Initialized
INFO - 2020-03-11 07:31:27 --> Router Class Initialized
INFO - 2020-03-11 07:31:27 --> Output Class Initialized
INFO - 2020-03-11 07:31:27 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:27 --> Input Class Initialized
INFO - 2020-03-11 07:31:27 --> Language Class Initialized
INFO - 2020-03-11 07:31:27 --> Language Class Initialized
INFO - 2020-03-11 07:31:27 --> Config Class Initialized
INFO - 2020-03-11 07:31:27 --> Loader Class Initialized
INFO - 2020-03-11 07:31:27 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:27 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:27 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:27 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:27 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:27 --> Controller Class Initialized
INFO - 2020-03-11 07:31:31 --> Config Class Initialized
INFO - 2020-03-11 07:31:31 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:31 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:31 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:31 --> URI Class Initialized
INFO - 2020-03-11 07:31:31 --> Router Class Initialized
INFO - 2020-03-11 07:31:31 --> Output Class Initialized
INFO - 2020-03-11 07:31:31 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:31 --> Input Class Initialized
INFO - 2020-03-11 07:31:31 --> Language Class Initialized
INFO - 2020-03-11 07:31:31 --> Language Class Initialized
INFO - 2020-03-11 07:31:31 --> Config Class Initialized
INFO - 2020-03-11 07:31:31 --> Loader Class Initialized
INFO - 2020-03-11 07:31:31 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:31 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:31 --> Controller Class Initialized
DEBUG - 2020-03-11 07:31:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-03-11 07:31:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 07:31:31 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:31 --> Total execution time: 0.3186
INFO - 2020-03-11 07:31:31 --> Config Class Initialized
INFO - 2020-03-11 07:31:31 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:31 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:31 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:31 --> URI Class Initialized
INFO - 2020-03-11 07:31:31 --> Router Class Initialized
INFO - 2020-03-11 07:31:31 --> Output Class Initialized
INFO - 2020-03-11 07:31:31 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:31 --> Input Class Initialized
INFO - 2020-03-11 07:31:31 --> Language Class Initialized
INFO - 2020-03-11 07:31:31 --> Language Class Initialized
INFO - 2020-03-11 07:31:31 --> Config Class Initialized
INFO - 2020-03-11 07:31:31 --> Loader Class Initialized
INFO - 2020-03-11 07:31:31 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:31 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:31 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:32 --> Controller Class Initialized
INFO - 2020-03-11 07:31:35 --> Config Class Initialized
INFO - 2020-03-11 07:31:35 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:35 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:35 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:35 --> URI Class Initialized
INFO - 2020-03-11 07:31:35 --> Router Class Initialized
INFO - 2020-03-11 07:31:35 --> Output Class Initialized
INFO - 2020-03-11 07:31:35 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:35 --> Input Class Initialized
INFO - 2020-03-11 07:31:35 --> Language Class Initialized
INFO - 2020-03-11 07:31:35 --> Language Class Initialized
INFO - 2020-03-11 07:31:35 --> Config Class Initialized
INFO - 2020-03-11 07:31:35 --> Loader Class Initialized
INFO - 2020-03-11 07:31:36 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:36 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:36 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:36 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:36 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:36 --> Controller Class Initialized
INFO - 2020-03-11 07:31:36 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:36 --> Total execution time: 0.3068
INFO - 2020-03-11 07:31:39 --> Config Class Initialized
INFO - 2020-03-11 07:31:39 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:39 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:39 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:39 --> URI Class Initialized
INFO - 2020-03-11 07:31:39 --> Router Class Initialized
INFO - 2020-03-11 07:31:39 --> Output Class Initialized
INFO - 2020-03-11 07:31:39 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:39 --> Input Class Initialized
INFO - 2020-03-11 07:31:39 --> Language Class Initialized
INFO - 2020-03-11 07:31:39 --> Language Class Initialized
INFO - 2020-03-11 07:31:39 --> Config Class Initialized
INFO - 2020-03-11 07:31:39 --> Loader Class Initialized
INFO - 2020-03-11 07:31:39 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:39 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:39 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:39 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:40 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:40 --> Controller Class Initialized
INFO - 2020-03-11 07:31:40 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:40 --> Total execution time: 0.2606
INFO - 2020-03-11 07:31:40 --> Config Class Initialized
INFO - 2020-03-11 07:31:40 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:40 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:40 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:40 --> URI Class Initialized
INFO - 2020-03-11 07:31:40 --> Router Class Initialized
INFO - 2020-03-11 07:31:40 --> Output Class Initialized
INFO - 2020-03-11 07:31:40 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:40 --> Input Class Initialized
INFO - 2020-03-11 07:31:40 --> Language Class Initialized
INFO - 2020-03-11 07:31:40 --> Language Class Initialized
INFO - 2020-03-11 07:31:40 --> Config Class Initialized
INFO - 2020-03-11 07:31:40 --> Loader Class Initialized
INFO - 2020-03-11 07:31:40 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:40 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:40 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:40 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:40 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:40 --> Controller Class Initialized
INFO - 2020-03-11 07:31:42 --> Config Class Initialized
INFO - 2020-03-11 07:31:42 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:42 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:42 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:42 --> URI Class Initialized
INFO - 2020-03-11 07:31:42 --> Router Class Initialized
INFO - 2020-03-11 07:31:42 --> Output Class Initialized
INFO - 2020-03-11 07:31:42 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:42 --> Input Class Initialized
INFO - 2020-03-11 07:31:42 --> Language Class Initialized
INFO - 2020-03-11 07:31:42 --> Language Class Initialized
INFO - 2020-03-11 07:31:42 --> Config Class Initialized
INFO - 2020-03-11 07:31:42 --> Loader Class Initialized
INFO - 2020-03-11 07:31:42 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:42 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:42 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:42 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:42 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:42 --> Controller Class Initialized
INFO - 2020-03-11 07:31:42 --> Final output sent to browser
DEBUG - 2020-03-11 07:31:42 --> Total execution time: 0.2403
INFO - 2020-03-11 07:31:44 --> Config Class Initialized
INFO - 2020-03-11 07:31:44 --> Hooks Class Initialized
DEBUG - 2020-03-11 07:31:44 --> UTF-8 Support Enabled
INFO - 2020-03-11 07:31:44 --> Utf8 Class Initialized
INFO - 2020-03-11 07:31:44 --> URI Class Initialized
INFO - 2020-03-11 07:31:44 --> Router Class Initialized
INFO - 2020-03-11 07:31:44 --> Output Class Initialized
INFO - 2020-03-11 07:31:44 --> Security Class Initialized
DEBUG - 2020-03-11 07:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 07:31:44 --> Input Class Initialized
INFO - 2020-03-11 07:31:44 --> Language Class Initialized
INFO - 2020-03-11 07:31:44 --> Language Class Initialized
INFO - 2020-03-11 07:31:44 --> Config Class Initialized
INFO - 2020-03-11 07:31:44 --> Loader Class Initialized
INFO - 2020-03-11 07:31:44 --> Helper loaded: url_helper
INFO - 2020-03-11 07:31:44 --> Helper loaded: file_helper
INFO - 2020-03-11 07:31:44 --> Helper loaded: form_helper
INFO - 2020-03-11 07:31:44 --> Helper loaded: my_helper
INFO - 2020-03-11 07:31:44 --> Database Driver Class Initialized
DEBUG - 2020-03-11 07:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 07:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 07:31:44 --> Controller Class Initialized
INFO - 2020-03-11 11:44:56 --> Config Class Initialized
INFO - 2020-03-11 11:44:56 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:44:56 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:44:56 --> Utf8 Class Initialized
INFO - 2020-03-11 11:44:56 --> URI Class Initialized
DEBUG - 2020-03-11 11:44:56 --> No URI present. Default controller set.
INFO - 2020-03-11 11:44:56 --> Router Class Initialized
INFO - 2020-03-11 11:44:56 --> Output Class Initialized
INFO - 2020-03-11 11:44:56 --> Security Class Initialized
DEBUG - 2020-03-11 11:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:44:56 --> Input Class Initialized
INFO - 2020-03-11 11:44:56 --> Language Class Initialized
INFO - 2020-03-11 11:44:56 --> Language Class Initialized
INFO - 2020-03-11 11:44:56 --> Config Class Initialized
INFO - 2020-03-11 11:44:56 --> Loader Class Initialized
INFO - 2020-03-11 11:44:56 --> Helper loaded: url_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: file_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: form_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: my_helper
INFO - 2020-03-11 11:44:57 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:44:57 --> Controller Class Initialized
INFO - 2020-03-11 11:44:57 --> Config Class Initialized
INFO - 2020-03-11 11:44:57 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:44:57 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:44:57 --> Utf8 Class Initialized
INFO - 2020-03-11 11:44:57 --> URI Class Initialized
INFO - 2020-03-11 11:44:57 --> Router Class Initialized
INFO - 2020-03-11 11:44:57 --> Output Class Initialized
INFO - 2020-03-11 11:44:57 --> Security Class Initialized
DEBUG - 2020-03-11 11:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:44:57 --> Input Class Initialized
INFO - 2020-03-11 11:44:57 --> Language Class Initialized
INFO - 2020-03-11 11:44:57 --> Language Class Initialized
INFO - 2020-03-11 11:44:57 --> Config Class Initialized
INFO - 2020-03-11 11:44:57 --> Loader Class Initialized
INFO - 2020-03-11 11:44:57 --> Helper loaded: url_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: file_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: form_helper
INFO - 2020-03-11 11:44:57 --> Helper loaded: my_helper
INFO - 2020-03-11 11:44:57 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:44:57 --> Controller Class Initialized
DEBUG - 2020-03-11 11:44:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-11 11:44:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:44:57 --> Final output sent to browser
DEBUG - 2020-03-11 11:44:57 --> Total execution time: 0.3195
INFO - 2020-03-11 11:45:36 --> Config Class Initialized
INFO - 2020-03-11 11:45:36 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:36 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:36 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:36 --> URI Class Initialized
INFO - 2020-03-11 11:45:37 --> Router Class Initialized
INFO - 2020-03-11 11:45:37 --> Output Class Initialized
INFO - 2020-03-11 11:45:37 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:37 --> Input Class Initialized
INFO - 2020-03-11 11:45:37 --> Language Class Initialized
INFO - 2020-03-11 11:45:37 --> Language Class Initialized
INFO - 2020-03-11 11:45:37 --> Config Class Initialized
INFO - 2020-03-11 11:45:37 --> Loader Class Initialized
INFO - 2020-03-11 11:45:37 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:37 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:37 --> Controller Class Initialized
INFO - 2020-03-11 11:45:37 --> Helper loaded: cookie_helper
INFO - 2020-03-11 11:45:37 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:37 --> Total execution time: 0.3431
INFO - 2020-03-11 11:45:37 --> Config Class Initialized
INFO - 2020-03-11 11:45:37 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:37 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:37 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:37 --> URI Class Initialized
INFO - 2020-03-11 11:45:37 --> Router Class Initialized
INFO - 2020-03-11 11:45:37 --> Output Class Initialized
INFO - 2020-03-11 11:45:37 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:37 --> Input Class Initialized
INFO - 2020-03-11 11:45:37 --> Language Class Initialized
INFO - 2020-03-11 11:45:37 --> Language Class Initialized
INFO - 2020-03-11 11:45:37 --> Config Class Initialized
INFO - 2020-03-11 11:45:37 --> Loader Class Initialized
INFO - 2020-03-11 11:45:37 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:37 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:37 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:37 --> Controller Class Initialized
DEBUG - 2020-03-11 11:45:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-11 11:45:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:45:37 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:37 --> Total execution time: 0.3844
INFO - 2020-03-11 11:45:40 --> Config Class Initialized
INFO - 2020-03-11 11:45:40 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:40 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:40 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:40 --> URI Class Initialized
INFO - 2020-03-11 11:45:40 --> Router Class Initialized
INFO - 2020-03-11 11:45:40 --> Output Class Initialized
INFO - 2020-03-11 11:45:40 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:40 --> Input Class Initialized
INFO - 2020-03-11 11:45:40 --> Language Class Initialized
INFO - 2020-03-11 11:45:41 --> Language Class Initialized
INFO - 2020-03-11 11:45:41 --> Config Class Initialized
INFO - 2020-03-11 11:45:41 --> Loader Class Initialized
INFO - 2020-03-11 11:45:41 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:41 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:41 --> Controller Class Initialized
DEBUG - 2020-03-11 11:45:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-03-11 11:45:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:45:41 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:41 --> Total execution time: 0.3198
INFO - 2020-03-11 11:45:41 --> Config Class Initialized
INFO - 2020-03-11 11:45:41 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:41 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:41 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:41 --> URI Class Initialized
INFO - 2020-03-11 11:45:41 --> Router Class Initialized
INFO - 2020-03-11 11:45:41 --> Output Class Initialized
INFO - 2020-03-11 11:45:41 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:41 --> Input Class Initialized
INFO - 2020-03-11 11:45:41 --> Language Class Initialized
INFO - 2020-03-11 11:45:41 --> Language Class Initialized
INFO - 2020-03-11 11:45:41 --> Config Class Initialized
INFO - 2020-03-11 11:45:41 --> Loader Class Initialized
INFO - 2020-03-11 11:45:41 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:41 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:41 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:41 --> Controller Class Initialized
INFO - 2020-03-11 11:45:44 --> Config Class Initialized
INFO - 2020-03-11 11:45:44 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:44 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:44 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:44 --> URI Class Initialized
INFO - 2020-03-11 11:45:44 --> Router Class Initialized
INFO - 2020-03-11 11:45:44 --> Output Class Initialized
INFO - 2020-03-11 11:45:44 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:44 --> Input Class Initialized
INFO - 2020-03-11 11:45:44 --> Language Class Initialized
INFO - 2020-03-11 11:45:44 --> Language Class Initialized
INFO - 2020-03-11 11:45:44 --> Config Class Initialized
INFO - 2020-03-11 11:45:44 --> Loader Class Initialized
INFO - 2020-03-11 11:45:44 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:44 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:44 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:44 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:44 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:44 --> Controller Class Initialized
INFO - 2020-03-11 11:45:44 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:44 --> Total execution time: 0.3198
INFO - 2020-03-11 11:45:44 --> Config Class Initialized
INFO - 2020-03-11 11:45:44 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:44 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:44 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:44 --> URI Class Initialized
INFO - 2020-03-11 11:45:45 --> Router Class Initialized
INFO - 2020-03-11 11:45:45 --> Output Class Initialized
INFO - 2020-03-11 11:45:45 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:45 --> Input Class Initialized
INFO - 2020-03-11 11:45:45 --> Language Class Initialized
INFO - 2020-03-11 11:45:45 --> Language Class Initialized
INFO - 2020-03-11 11:45:45 --> Config Class Initialized
INFO - 2020-03-11 11:45:45 --> Loader Class Initialized
INFO - 2020-03-11 11:45:45 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:45 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:45 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:45 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:45 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:45 --> Controller Class Initialized
INFO - 2020-03-11 11:45:48 --> Config Class Initialized
INFO - 2020-03-11 11:45:48 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:48 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:48 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:48 --> URI Class Initialized
INFO - 2020-03-11 11:45:48 --> Router Class Initialized
INFO - 2020-03-11 11:45:48 --> Output Class Initialized
INFO - 2020-03-11 11:45:48 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:48 --> Input Class Initialized
INFO - 2020-03-11 11:45:48 --> Language Class Initialized
INFO - 2020-03-11 11:45:48 --> Language Class Initialized
INFO - 2020-03-11 11:45:48 --> Config Class Initialized
INFO - 2020-03-11 11:45:48 --> Loader Class Initialized
INFO - 2020-03-11 11:45:48 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:48 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:48 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:48 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:48 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:48 --> Controller Class Initialized
ERROR - 2020-03-11 11:45:48 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 231
DEBUG - 2020-03-11 11:45:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-03-11 11:45:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:45:48 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:48 --> Total execution time: 0.3641
INFO - 2020-03-11 11:45:55 --> Config Class Initialized
INFO - 2020-03-11 11:45:55 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:55 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:55 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:55 --> URI Class Initialized
INFO - 2020-03-11 11:45:55 --> Router Class Initialized
INFO - 2020-03-11 11:45:55 --> Output Class Initialized
INFO - 2020-03-11 11:45:55 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:55 --> Input Class Initialized
INFO - 2020-03-11 11:45:55 --> Language Class Initialized
INFO - 2020-03-11 11:45:55 --> Language Class Initialized
INFO - 2020-03-11 11:45:55 --> Config Class Initialized
INFO - 2020-03-11 11:45:55 --> Loader Class Initialized
INFO - 2020-03-11 11:45:55 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:55 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:55 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:55 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:55 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:55 --> Controller Class Initialized
INFO - 2020-03-11 11:45:55 --> Helper loaded: cookie_helper
INFO - 2020-03-11 11:45:55 --> Config Class Initialized
INFO - 2020-03-11 11:45:55 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:55 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:55 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:55 --> URI Class Initialized
INFO - 2020-03-11 11:45:55 --> Router Class Initialized
INFO - 2020-03-11 11:45:55 --> Output Class Initialized
INFO - 2020-03-11 11:45:55 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:55 --> Input Class Initialized
INFO - 2020-03-11 11:45:56 --> Language Class Initialized
INFO - 2020-03-11 11:45:56 --> Language Class Initialized
INFO - 2020-03-11 11:45:56 --> Config Class Initialized
INFO - 2020-03-11 11:45:56 --> Loader Class Initialized
INFO - 2020-03-11 11:45:56 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:56 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:56 --> Controller Class Initialized
INFO - 2020-03-11 11:45:56 --> Config Class Initialized
INFO - 2020-03-11 11:45:56 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:45:56 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:45:56 --> Utf8 Class Initialized
INFO - 2020-03-11 11:45:56 --> URI Class Initialized
INFO - 2020-03-11 11:45:56 --> Router Class Initialized
INFO - 2020-03-11 11:45:56 --> Output Class Initialized
INFO - 2020-03-11 11:45:56 --> Security Class Initialized
DEBUG - 2020-03-11 11:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:45:56 --> Input Class Initialized
INFO - 2020-03-11 11:45:56 --> Language Class Initialized
INFO - 2020-03-11 11:45:56 --> Language Class Initialized
INFO - 2020-03-11 11:45:56 --> Config Class Initialized
INFO - 2020-03-11 11:45:56 --> Loader Class Initialized
INFO - 2020-03-11 11:45:56 --> Helper loaded: url_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: file_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: form_helper
INFO - 2020-03-11 11:45:56 --> Helper loaded: my_helper
INFO - 2020-03-11 11:45:56 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:45:56 --> Controller Class Initialized
DEBUG - 2020-03-11 11:45:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-11 11:45:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:45:56 --> Final output sent to browser
DEBUG - 2020-03-11 11:45:56 --> Total execution time: 0.2791
INFO - 2020-03-11 11:46:02 --> Config Class Initialized
INFO - 2020-03-11 11:46:02 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:46:02 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:46:02 --> Utf8 Class Initialized
INFO - 2020-03-11 11:46:02 --> URI Class Initialized
INFO - 2020-03-11 11:46:02 --> Router Class Initialized
INFO - 2020-03-11 11:46:02 --> Output Class Initialized
INFO - 2020-03-11 11:46:02 --> Security Class Initialized
DEBUG - 2020-03-11 11:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:46:02 --> Input Class Initialized
INFO - 2020-03-11 11:46:02 --> Language Class Initialized
INFO - 2020-03-11 11:46:02 --> Language Class Initialized
INFO - 2020-03-11 11:46:02 --> Config Class Initialized
INFO - 2020-03-11 11:46:02 --> Loader Class Initialized
INFO - 2020-03-11 11:46:02 --> Helper loaded: url_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: file_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: form_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: my_helper
INFO - 2020-03-11 11:46:02 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:46:02 --> Controller Class Initialized
INFO - 2020-03-11 11:46:02 --> Helper loaded: cookie_helper
INFO - 2020-03-11 11:46:02 --> Final output sent to browser
DEBUG - 2020-03-11 11:46:02 --> Total execution time: 0.3091
INFO - 2020-03-11 11:46:02 --> Config Class Initialized
INFO - 2020-03-11 11:46:02 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:46:02 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:46:02 --> Utf8 Class Initialized
INFO - 2020-03-11 11:46:02 --> URI Class Initialized
INFO - 2020-03-11 11:46:02 --> Router Class Initialized
INFO - 2020-03-11 11:46:02 --> Output Class Initialized
INFO - 2020-03-11 11:46:02 --> Security Class Initialized
DEBUG - 2020-03-11 11:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:46:02 --> Input Class Initialized
INFO - 2020-03-11 11:46:02 --> Language Class Initialized
INFO - 2020-03-11 11:46:02 --> Language Class Initialized
INFO - 2020-03-11 11:46:02 --> Config Class Initialized
INFO - 2020-03-11 11:46:02 --> Loader Class Initialized
INFO - 2020-03-11 11:46:02 --> Helper loaded: url_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: file_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: form_helper
INFO - 2020-03-11 11:46:02 --> Helper loaded: my_helper
INFO - 2020-03-11 11:46:02 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:46:02 --> Controller Class Initialized
DEBUG - 2020-03-11 11:46:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-11 11:46:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:46:02 --> Final output sent to browser
DEBUG - 2020-03-11 11:46:02 --> Total execution time: 0.3488
INFO - 2020-03-11 11:46:06 --> Config Class Initialized
INFO - 2020-03-11 11:46:06 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:46:06 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:46:06 --> Utf8 Class Initialized
INFO - 2020-03-11 11:46:06 --> URI Class Initialized
INFO - 2020-03-11 11:46:06 --> Router Class Initialized
INFO - 2020-03-11 11:46:06 --> Output Class Initialized
INFO - 2020-03-11 11:46:06 --> Security Class Initialized
DEBUG - 2020-03-11 11:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:46:06 --> Input Class Initialized
INFO - 2020-03-11 11:46:06 --> Language Class Initialized
INFO - 2020-03-11 11:46:06 --> Language Class Initialized
INFO - 2020-03-11 11:46:06 --> Config Class Initialized
INFO - 2020-03-11 11:46:06 --> Loader Class Initialized
INFO - 2020-03-11 11:46:06 --> Helper loaded: url_helper
INFO - 2020-03-11 11:46:06 --> Helper loaded: file_helper
INFO - 2020-03-11 11:46:06 --> Helper loaded: form_helper
INFO - 2020-03-11 11:46:06 --> Helper loaded: my_helper
INFO - 2020-03-11 11:46:06 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:46:06 --> Controller Class Initialized
DEBUG - 2020-03-11 11:46:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/lihat_raport/views/list.php
DEBUG - 2020-03-11 11:46:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 11:46:06 --> Final output sent to browser
DEBUG - 2020-03-11 11:46:06 --> Total execution time: 0.3745
INFO - 2020-03-11 11:52:33 --> Config Class Initialized
INFO - 2020-03-11 11:52:33 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:52:33 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:52:33 --> Utf8 Class Initialized
INFO - 2020-03-11 11:52:33 --> URI Class Initialized
INFO - 2020-03-11 11:52:33 --> Router Class Initialized
INFO - 2020-03-11 11:52:33 --> Output Class Initialized
INFO - 2020-03-11 11:52:33 --> Security Class Initialized
DEBUG - 2020-03-11 11:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:52:33 --> Input Class Initialized
INFO - 2020-03-11 11:52:33 --> Language Class Initialized
INFO - 2020-03-11 11:52:33 --> Language Class Initialized
INFO - 2020-03-11 11:52:33 --> Config Class Initialized
INFO - 2020-03-11 11:52:33 --> Loader Class Initialized
INFO - 2020-03-11 11:52:33 --> Helper loaded: url_helper
INFO - 2020-03-11 11:52:33 --> Helper loaded: file_helper
INFO - 2020-03-11 11:52:33 --> Helper loaded: form_helper
INFO - 2020-03-11 11:52:33 --> Helper loaded: my_helper
INFO - 2020-03-11 11:52:33 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:52:33 --> Controller Class Initialized
DEBUG - 2020-03-11 11:52:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/lihat_raport/views/cetak_sampul1.php
INFO - 2020-03-11 11:52:33 --> Final output sent to browser
DEBUG - 2020-03-11 11:52:34 --> Total execution time: 0.3514
INFO - 2020-03-11 11:52:38 --> Config Class Initialized
INFO - 2020-03-11 11:52:38 --> Hooks Class Initialized
DEBUG - 2020-03-11 11:52:38 --> UTF-8 Support Enabled
INFO - 2020-03-11 11:52:38 --> Utf8 Class Initialized
INFO - 2020-03-11 11:52:38 --> URI Class Initialized
INFO - 2020-03-11 11:52:38 --> Router Class Initialized
INFO - 2020-03-11 11:52:38 --> Output Class Initialized
INFO - 2020-03-11 11:52:38 --> Security Class Initialized
DEBUG - 2020-03-11 11:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 11:52:38 --> Input Class Initialized
INFO - 2020-03-11 11:52:38 --> Language Class Initialized
INFO - 2020-03-11 11:52:38 --> Language Class Initialized
INFO - 2020-03-11 11:52:38 --> Config Class Initialized
INFO - 2020-03-11 11:52:38 --> Loader Class Initialized
INFO - 2020-03-11 11:52:38 --> Helper loaded: url_helper
INFO - 2020-03-11 11:52:38 --> Helper loaded: file_helper
INFO - 2020-03-11 11:52:38 --> Helper loaded: form_helper
INFO - 2020-03-11 11:52:38 --> Helper loaded: my_helper
INFO - 2020-03-11 11:52:38 --> Database Driver Class Initialized
DEBUG - 2020-03-11 11:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 11:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 11:52:38 --> Controller Class Initialized
DEBUG - 2020-03-11 11:52:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/lihat_raport/views/cetak_rapot.php
INFO - 2020-03-11 11:52:39 --> Final output sent to browser
DEBUG - 2020-03-11 11:52:39 --> Total execution time: 0.4482
INFO - 2020-03-11 12:19:37 --> Config Class Initialized
INFO - 2020-03-11 12:19:37 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:19:37 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:19:37 --> Utf8 Class Initialized
INFO - 2020-03-11 12:19:37 --> URI Class Initialized
DEBUG - 2020-03-11 12:19:37 --> No URI present. Default controller set.
INFO - 2020-03-11 12:19:37 --> Router Class Initialized
INFO - 2020-03-11 12:19:37 --> Output Class Initialized
INFO - 2020-03-11 12:19:37 --> Security Class Initialized
DEBUG - 2020-03-11 12:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:19:37 --> Input Class Initialized
INFO - 2020-03-11 12:19:37 --> Language Class Initialized
INFO - 2020-03-11 12:19:37 --> Language Class Initialized
INFO - 2020-03-11 12:19:37 --> Config Class Initialized
INFO - 2020-03-11 12:19:37 --> Loader Class Initialized
INFO - 2020-03-11 12:19:37 --> Helper loaded: url_helper
INFO - 2020-03-11 12:19:37 --> Helper loaded: file_helper
INFO - 2020-03-11 12:19:37 --> Helper loaded: form_helper
INFO - 2020-03-11 12:19:37 --> Helper loaded: my_helper
INFO - 2020-03-11 12:19:37 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:19:37 --> Controller Class Initialized
DEBUG - 2020-03-11 12:19:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-03-11 12:19:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:19:37 --> Final output sent to browser
DEBUG - 2020-03-11 12:19:37 --> Total execution time: 0.3167
INFO - 2020-03-11 12:19:48 --> Config Class Initialized
INFO - 2020-03-11 12:19:48 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:19:48 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:19:48 --> Utf8 Class Initialized
INFO - 2020-03-11 12:19:48 --> URI Class Initialized
INFO - 2020-03-11 12:19:48 --> Router Class Initialized
INFO - 2020-03-11 12:19:48 --> Output Class Initialized
INFO - 2020-03-11 12:19:48 --> Security Class Initialized
DEBUG - 2020-03-11 12:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:19:48 --> Input Class Initialized
INFO - 2020-03-11 12:19:48 --> Language Class Initialized
INFO - 2020-03-11 12:19:48 --> Language Class Initialized
INFO - 2020-03-11 12:19:48 --> Config Class Initialized
INFO - 2020-03-11 12:19:48 --> Loader Class Initialized
INFO - 2020-03-11 12:19:48 --> Helper loaded: url_helper
INFO - 2020-03-11 12:19:48 --> Helper loaded: file_helper
INFO - 2020-03-11 12:19:48 --> Helper loaded: form_helper
INFO - 2020-03-11 12:19:48 --> Helper loaded: my_helper
INFO - 2020-03-11 12:19:48 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:19:48 --> Controller Class Initialized
DEBUG - 2020-03-11 12:19:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/lihat_raport/views/list.php
DEBUG - 2020-03-11 12:19:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:19:48 --> Final output sent to browser
DEBUG - 2020-03-11 12:19:48 --> Total execution time: 0.3029
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:20 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:20 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:20 --> URI Class Initialized
INFO - 2020-03-11 12:20:20 --> Router Class Initialized
INFO - 2020-03-11 12:20:20 --> Output Class Initialized
INFO - 2020-03-11 12:20:20 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:20 --> Input Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Loader Class Initialized
INFO - 2020-03-11 12:20:20 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:20 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:20 --> Controller Class Initialized
INFO - 2020-03-11 12:20:20 --> Helper loaded: cookie_helper
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:20 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:20 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:20 --> URI Class Initialized
INFO - 2020-03-11 12:20:20 --> Router Class Initialized
INFO - 2020-03-11 12:20:20 --> Output Class Initialized
INFO - 2020-03-11 12:20:20 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:20 --> Input Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Loader Class Initialized
INFO - 2020-03-11 12:20:20 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:20 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:20 --> Controller Class Initialized
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:20 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:20 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:20 --> URI Class Initialized
INFO - 2020-03-11 12:20:20 --> Router Class Initialized
INFO - 2020-03-11 12:20:20 --> Output Class Initialized
INFO - 2020-03-11 12:20:20 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:20 --> Input Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Language Class Initialized
INFO - 2020-03-11 12:20:20 --> Config Class Initialized
INFO - 2020-03-11 12:20:20 --> Loader Class Initialized
INFO - 2020-03-11 12:20:20 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:20 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:20 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:21 --> Controller Class Initialized
DEBUG - 2020-03-11 12:20:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-03-11 12:20:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:20:21 --> Final output sent to browser
DEBUG - 2020-03-11 12:20:21 --> Total execution time: 0.3019
INFO - 2020-03-11 12:20:29 --> Config Class Initialized
INFO - 2020-03-11 12:20:29 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:29 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:29 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:29 --> URI Class Initialized
INFO - 2020-03-11 12:20:29 --> Router Class Initialized
INFO - 2020-03-11 12:20:29 --> Output Class Initialized
INFO - 2020-03-11 12:20:29 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:29 --> Input Class Initialized
INFO - 2020-03-11 12:20:29 --> Language Class Initialized
INFO - 2020-03-11 12:20:29 --> Language Class Initialized
INFO - 2020-03-11 12:20:29 --> Config Class Initialized
INFO - 2020-03-11 12:20:29 --> Loader Class Initialized
INFO - 2020-03-11 12:20:29 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:29 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:29 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:29 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:29 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:29 --> Controller Class Initialized
INFO - 2020-03-11 12:20:29 --> Helper loaded: cookie_helper
INFO - 2020-03-11 12:20:29 --> Final output sent to browser
DEBUG - 2020-03-11 12:20:29 --> Total execution time: 0.3382
INFO - 2020-03-11 12:20:29 --> Config Class Initialized
INFO - 2020-03-11 12:20:29 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:29 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:29 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:29 --> URI Class Initialized
INFO - 2020-03-11 12:20:30 --> Router Class Initialized
INFO - 2020-03-11 12:20:30 --> Output Class Initialized
INFO - 2020-03-11 12:20:30 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:30 --> Input Class Initialized
INFO - 2020-03-11 12:20:30 --> Language Class Initialized
INFO - 2020-03-11 12:20:30 --> Language Class Initialized
INFO - 2020-03-11 12:20:30 --> Config Class Initialized
INFO - 2020-03-11 12:20:30 --> Loader Class Initialized
INFO - 2020-03-11 12:20:30 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:30 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:30 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:30 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:30 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:30 --> Controller Class Initialized
DEBUG - 2020-03-11 12:20:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-03-11 12:20:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:20:30 --> Final output sent to browser
DEBUG - 2020-03-11 12:20:30 --> Total execution time: 0.3362
INFO - 2020-03-11 12:20:34 --> Config Class Initialized
INFO - 2020-03-11 12:20:34 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:20:34 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:20:34 --> Utf8 Class Initialized
INFO - 2020-03-11 12:20:34 --> URI Class Initialized
INFO - 2020-03-11 12:20:34 --> Router Class Initialized
INFO - 2020-03-11 12:20:34 --> Output Class Initialized
INFO - 2020-03-11 12:20:35 --> Security Class Initialized
DEBUG - 2020-03-11 12:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:20:35 --> Input Class Initialized
INFO - 2020-03-11 12:20:35 --> Language Class Initialized
INFO - 2020-03-11 12:20:35 --> Language Class Initialized
INFO - 2020-03-11 12:20:35 --> Config Class Initialized
INFO - 2020-03-11 12:20:35 --> Loader Class Initialized
INFO - 2020-03-11 12:20:35 --> Helper loaded: url_helper
INFO - 2020-03-11 12:20:35 --> Helper loaded: file_helper
INFO - 2020-03-11 12:20:35 --> Helper loaded: form_helper
INFO - 2020-03-11 12:20:35 --> Helper loaded: my_helper
INFO - 2020-03-11 12:20:35 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:20:35 --> Controller Class Initialized
DEBUG - 2020-03-11 12:20:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-03-11 12:20:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:20:35 --> Final output sent to browser
DEBUG - 2020-03-11 12:20:35 --> Total execution time: 0.3322
INFO - 2020-03-11 12:26:03 --> Config Class Initialized
INFO - 2020-03-11 12:26:03 --> Hooks Class Initialized
DEBUG - 2020-03-11 12:26:03 --> UTF-8 Support Enabled
INFO - 2020-03-11 12:26:03 --> Utf8 Class Initialized
INFO - 2020-03-11 12:26:03 --> URI Class Initialized
INFO - 2020-03-11 12:26:03 --> Router Class Initialized
INFO - 2020-03-11 12:26:03 --> Output Class Initialized
INFO - 2020-03-11 12:26:03 --> Security Class Initialized
DEBUG - 2020-03-11 12:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-03-11 12:26:03 --> Input Class Initialized
INFO - 2020-03-11 12:26:03 --> Language Class Initialized
INFO - 2020-03-11 12:26:03 --> Language Class Initialized
INFO - 2020-03-11 12:26:03 --> Config Class Initialized
INFO - 2020-03-11 12:26:03 --> Loader Class Initialized
INFO - 2020-03-11 12:26:03 --> Helper loaded: url_helper
INFO - 2020-03-11 12:26:03 --> Helper loaded: file_helper
INFO - 2020-03-11 12:26:03 --> Helper loaded: form_helper
INFO - 2020-03-11 12:26:03 --> Helper loaded: my_helper
INFO - 2020-03-11 12:26:03 --> Database Driver Class Initialized
DEBUG - 2020-03-11 12:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-03-11 12:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-03-11 12:26:03 --> Controller Class Initialized
DEBUG - 2020-03-11 12:26:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-03-11 12:26:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-03-11 12:26:03 --> Final output sent to browser
DEBUG - 2020-03-11 12:26:03 --> Total execution time: 0.3357
