<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-01-31 01:14:10 --> Config Class Initialized
INFO - 2020-01-31 01:14:10 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:10 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:10 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:10 --> URI Class Initialized
INFO - 2020-01-31 01:14:10 --> Router Class Initialized
INFO - 2020-01-31 01:14:10 --> Output Class Initialized
INFO - 2020-01-31 01:14:10 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:10 --> Input Class Initialized
INFO - 2020-01-31 01:14:10 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Config Class Initialized
INFO - 2020-01-31 01:14:11 --> Loader Class Initialized
INFO - 2020-01-31 01:14:11 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:11 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:11 --> Controller Class Initialized
INFO - 2020-01-31 01:14:11 --> Helper loaded: cookie_helper
INFO - 2020-01-31 01:14:11 --> Config Class Initialized
INFO - 2020-01-31 01:14:11 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:11 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:11 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:11 --> URI Class Initialized
INFO - 2020-01-31 01:14:11 --> Router Class Initialized
INFO - 2020-01-31 01:14:11 --> Output Class Initialized
INFO - 2020-01-31 01:14:11 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:11 --> Input Class Initialized
INFO - 2020-01-31 01:14:11 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Config Class Initialized
INFO - 2020-01-31 01:14:11 --> Loader Class Initialized
INFO - 2020-01-31 01:14:11 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:11 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:11 --> Controller Class Initialized
INFO - 2020-01-31 01:14:11 --> Config Class Initialized
INFO - 2020-01-31 01:14:11 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:11 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:11 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:11 --> URI Class Initialized
INFO - 2020-01-31 01:14:11 --> Router Class Initialized
INFO - 2020-01-31 01:14:11 --> Output Class Initialized
INFO - 2020-01-31 01:14:11 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:11 --> Input Class Initialized
INFO - 2020-01-31 01:14:11 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Language Class Initialized
INFO - 2020-01-31 01:14:11 --> Config Class Initialized
INFO - 2020-01-31 01:14:11 --> Loader Class Initialized
INFO - 2020-01-31 01:14:11 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:11 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:11 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:11 --> Controller Class Initialized
DEBUG - 2020-01-31 01:14:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 01:14:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:14:11 --> Final output sent to browser
DEBUG - 2020-01-31 01:14:11 --> Total execution time: 0.2684
INFO - 2020-01-31 01:14:40 --> Config Class Initialized
INFO - 2020-01-31 01:14:40 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:40 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:40 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:40 --> URI Class Initialized
INFO - 2020-01-31 01:14:40 --> Router Class Initialized
INFO - 2020-01-31 01:14:40 --> Output Class Initialized
INFO - 2020-01-31 01:14:40 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:40 --> Input Class Initialized
INFO - 2020-01-31 01:14:40 --> Language Class Initialized
INFO - 2020-01-31 01:14:40 --> Language Class Initialized
INFO - 2020-01-31 01:14:40 --> Config Class Initialized
INFO - 2020-01-31 01:14:40 --> Loader Class Initialized
INFO - 2020-01-31 01:14:40 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:40 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:40 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:40 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:40 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:40 --> Controller Class Initialized
INFO - 2020-01-31 01:14:41 --> Helper loaded: cookie_helper
INFO - 2020-01-31 01:14:41 --> Final output sent to browser
DEBUG - 2020-01-31 01:14:41 --> Total execution time: 0.3770
INFO - 2020-01-31 01:14:41 --> Config Class Initialized
INFO - 2020-01-31 01:14:41 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:41 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:41 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:41 --> URI Class Initialized
INFO - 2020-01-31 01:14:41 --> Router Class Initialized
INFO - 2020-01-31 01:14:41 --> Output Class Initialized
INFO - 2020-01-31 01:14:41 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:41 --> Input Class Initialized
INFO - 2020-01-31 01:14:41 --> Language Class Initialized
INFO - 2020-01-31 01:14:41 --> Language Class Initialized
INFO - 2020-01-31 01:14:41 --> Config Class Initialized
INFO - 2020-01-31 01:14:41 --> Loader Class Initialized
INFO - 2020-01-31 01:14:41 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:41 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:41 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:41 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:41 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:41 --> Controller Class Initialized
DEBUG - 2020-01-31 01:14:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 01:14:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:14:41 --> Final output sent to browser
DEBUG - 2020-01-31 01:14:41 --> Total execution time: 0.4356
INFO - 2020-01-31 01:14:49 --> Config Class Initialized
INFO - 2020-01-31 01:14:49 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:49 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:49 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:49 --> URI Class Initialized
INFO - 2020-01-31 01:14:49 --> Router Class Initialized
INFO - 2020-01-31 01:14:49 --> Output Class Initialized
INFO - 2020-01-31 01:14:49 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:49 --> Input Class Initialized
INFO - 2020-01-31 01:14:49 --> Language Class Initialized
INFO - 2020-01-31 01:14:49 --> Language Class Initialized
INFO - 2020-01-31 01:14:49 --> Config Class Initialized
INFO - 2020-01-31 01:14:49 --> Loader Class Initialized
INFO - 2020-01-31 01:14:49 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:49 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:50 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:50 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:50 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:50 --> Controller Class Initialized
DEBUG - 2020-01-31 01:14:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-31 01:14:50 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:14:50 --> Final output sent to browser
DEBUG - 2020-01-31 01:14:50 --> Total execution time: 0.3118
INFO - 2020-01-31 01:14:55 --> Config Class Initialized
INFO - 2020-01-31 01:14:55 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:14:55 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:14:55 --> Utf8 Class Initialized
INFO - 2020-01-31 01:14:55 --> URI Class Initialized
INFO - 2020-01-31 01:14:55 --> Router Class Initialized
INFO - 2020-01-31 01:14:55 --> Output Class Initialized
INFO - 2020-01-31 01:14:55 --> Security Class Initialized
DEBUG - 2020-01-31 01:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:14:55 --> Input Class Initialized
INFO - 2020-01-31 01:14:55 --> Language Class Initialized
INFO - 2020-01-31 01:14:55 --> Language Class Initialized
INFO - 2020-01-31 01:14:55 --> Config Class Initialized
INFO - 2020-01-31 01:14:55 --> Loader Class Initialized
INFO - 2020-01-31 01:14:55 --> Helper loaded: url_helper
INFO - 2020-01-31 01:14:55 --> Helper loaded: file_helper
INFO - 2020-01-31 01:14:55 --> Helper loaded: form_helper
INFO - 2020-01-31 01:14:55 --> Helper loaded: my_helper
INFO - 2020-01-31 01:14:55 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:14:55 --> Controller Class Initialized
DEBUG - 2020-01-31 01:14:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-31 01:14:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:14:55 --> Final output sent to browser
DEBUG - 2020-01-31 01:14:55 --> Total execution time: 0.3984
INFO - 2020-01-31 01:15:09 --> Config Class Initialized
INFO - 2020-01-31 01:15:09 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:15:09 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:15:09 --> Utf8 Class Initialized
INFO - 2020-01-31 01:15:09 --> URI Class Initialized
INFO - 2020-01-31 01:15:09 --> Router Class Initialized
INFO - 2020-01-31 01:15:09 --> Output Class Initialized
INFO - 2020-01-31 01:15:09 --> Security Class Initialized
DEBUG - 2020-01-31 01:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:15:09 --> Input Class Initialized
INFO - 2020-01-31 01:15:09 --> Language Class Initialized
INFO - 2020-01-31 01:15:09 --> Language Class Initialized
INFO - 2020-01-31 01:15:09 --> Config Class Initialized
INFO - 2020-01-31 01:15:09 --> Loader Class Initialized
INFO - 2020-01-31 01:15:09 --> Helper loaded: url_helper
INFO - 2020-01-31 01:15:09 --> Helper loaded: file_helper
INFO - 2020-01-31 01:15:09 --> Helper loaded: form_helper
INFO - 2020-01-31 01:15:09 --> Helper loaded: my_helper
INFO - 2020-01-31 01:15:09 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:15:10 --> Controller Class Initialized
DEBUG - 2020-01-31 01:15:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-31 01:15:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:15:10 --> Final output sent to browser
DEBUG - 2020-01-31 01:15:10 --> Total execution time: 0.3373
INFO - 2020-01-31 01:15:12 --> Config Class Initialized
INFO - 2020-01-31 01:15:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:15:12 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:15:12 --> Utf8 Class Initialized
INFO - 2020-01-31 01:15:12 --> URI Class Initialized
INFO - 2020-01-31 01:15:12 --> Router Class Initialized
INFO - 2020-01-31 01:15:12 --> Output Class Initialized
INFO - 2020-01-31 01:15:12 --> Security Class Initialized
DEBUG - 2020-01-31 01:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:15:12 --> Input Class Initialized
INFO - 2020-01-31 01:15:12 --> Language Class Initialized
INFO - 2020-01-31 01:15:12 --> Language Class Initialized
INFO - 2020-01-31 01:15:12 --> Config Class Initialized
INFO - 2020-01-31 01:15:12 --> Loader Class Initialized
INFO - 2020-01-31 01:15:12 --> Helper loaded: url_helper
INFO - 2020-01-31 01:15:12 --> Helper loaded: file_helper
INFO - 2020-01-31 01:15:12 --> Helper loaded: form_helper
INFO - 2020-01-31 01:15:12 --> Helper loaded: my_helper
INFO - 2020-01-31 01:15:12 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:15:13 --> Controller Class Initialized
DEBUG - 2020-01-31 01:15:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-31 01:15:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 01:15:13 --> Final output sent to browser
DEBUG - 2020-01-31 01:15:13 --> Total execution time: 0.4292
INFO - 2020-01-31 01:15:13 --> Config Class Initialized
INFO - 2020-01-31 01:15:13 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:15:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:15:13 --> Utf8 Class Initialized
INFO - 2020-01-31 01:15:13 --> URI Class Initialized
INFO - 2020-01-31 01:15:13 --> Router Class Initialized
INFO - 2020-01-31 01:15:13 --> Output Class Initialized
INFO - 2020-01-31 01:15:13 --> Security Class Initialized
DEBUG - 2020-01-31 01:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:15:13 --> Input Class Initialized
INFO - 2020-01-31 01:15:13 --> Language Class Initialized
INFO - 2020-01-31 01:15:13 --> Language Class Initialized
INFO - 2020-01-31 01:15:13 --> Config Class Initialized
INFO - 2020-01-31 01:15:13 --> Loader Class Initialized
INFO - 2020-01-31 01:15:13 --> Helper loaded: url_helper
INFO - 2020-01-31 01:15:13 --> Helper loaded: file_helper
INFO - 2020-01-31 01:15:13 --> Helper loaded: form_helper
INFO - 2020-01-31 01:15:13 --> Helper loaded: my_helper
INFO - 2020-01-31 01:15:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:15:13 --> Controller Class Initialized
INFO - 2020-01-31 01:15:16 --> Config Class Initialized
INFO - 2020-01-31 01:15:16 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:15:16 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:15:16 --> Utf8 Class Initialized
INFO - 2020-01-31 01:15:16 --> URI Class Initialized
INFO - 2020-01-31 01:15:16 --> Router Class Initialized
INFO - 2020-01-31 01:15:16 --> Output Class Initialized
INFO - 2020-01-31 01:15:16 --> Security Class Initialized
DEBUG - 2020-01-31 01:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:15:16 --> Input Class Initialized
INFO - 2020-01-31 01:15:16 --> Language Class Initialized
INFO - 2020-01-31 01:15:16 --> Language Class Initialized
INFO - 2020-01-31 01:15:16 --> Config Class Initialized
INFO - 2020-01-31 01:15:16 --> Loader Class Initialized
INFO - 2020-01-31 01:15:16 --> Helper loaded: url_helper
INFO - 2020-01-31 01:15:16 --> Helper loaded: file_helper
INFO - 2020-01-31 01:15:16 --> Helper loaded: form_helper
INFO - 2020-01-31 01:15:16 --> Helper loaded: my_helper
INFO - 2020-01-31 01:15:16 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:15:16 --> Controller Class Initialized
INFO - 2020-01-31 01:15:16 --> Final output sent to browser
DEBUG - 2020-01-31 01:15:16 --> Total execution time: 0.2196
INFO - 2020-01-31 01:15:18 --> Config Class Initialized
INFO - 2020-01-31 01:15:18 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:15:18 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:15:18 --> Utf8 Class Initialized
INFO - 2020-01-31 01:15:18 --> URI Class Initialized
INFO - 2020-01-31 01:15:18 --> Router Class Initialized
INFO - 2020-01-31 01:15:18 --> Output Class Initialized
INFO - 2020-01-31 01:15:18 --> Security Class Initialized
DEBUG - 2020-01-31 01:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:15:18 --> Input Class Initialized
INFO - 2020-01-31 01:15:18 --> Language Class Initialized
INFO - 2020-01-31 01:15:18 --> Language Class Initialized
INFO - 2020-01-31 01:15:18 --> Config Class Initialized
INFO - 2020-01-31 01:15:18 --> Loader Class Initialized
INFO - 2020-01-31 01:15:18 --> Helper loaded: url_helper
INFO - 2020-01-31 01:15:18 --> Helper loaded: file_helper
INFO - 2020-01-31 01:15:18 --> Helper loaded: form_helper
INFO - 2020-01-31 01:15:18 --> Helper loaded: my_helper
INFO - 2020-01-31 01:15:18 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:15:18 --> Controller Class Initialized
DEBUG - 2020-01-31 01:15:18 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-01-31 01:15:18 --> Final output sent to browser
DEBUG - 2020-01-31 01:15:18 --> Total execution time: 0.5182
INFO - 2020-01-31 01:23:15 --> Config Class Initialized
INFO - 2020-01-31 01:23:15 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:23:15 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:23:15 --> Utf8 Class Initialized
INFO - 2020-01-31 01:23:15 --> URI Class Initialized
INFO - 2020-01-31 01:23:15 --> Router Class Initialized
INFO - 2020-01-31 01:23:15 --> Output Class Initialized
INFO - 2020-01-31 01:23:15 --> Security Class Initialized
DEBUG - 2020-01-31 01:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:23:15 --> Input Class Initialized
INFO - 2020-01-31 01:23:15 --> Language Class Initialized
INFO - 2020-01-31 01:23:15 --> Language Class Initialized
INFO - 2020-01-31 01:23:15 --> Config Class Initialized
INFO - 2020-01-31 01:23:15 --> Loader Class Initialized
INFO - 2020-01-31 01:23:15 --> Helper loaded: url_helper
INFO - 2020-01-31 01:23:15 --> Helper loaded: file_helper
INFO - 2020-01-31 01:23:15 --> Helper loaded: form_helper
INFO - 2020-01-31 01:23:15 --> Helper loaded: my_helper
INFO - 2020-01-31 01:23:15 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:23:15 --> Controller Class Initialized
INFO - 2020-01-31 01:23:15 --> Final output sent to browser
DEBUG - 2020-01-31 01:23:15 --> Total execution time: 0.2324
INFO - 2020-01-31 01:23:16 --> Config Class Initialized
INFO - 2020-01-31 01:23:16 --> Hooks Class Initialized
DEBUG - 2020-01-31 01:23:16 --> UTF-8 Support Enabled
INFO - 2020-01-31 01:23:16 --> Utf8 Class Initialized
INFO - 2020-01-31 01:23:16 --> URI Class Initialized
INFO - 2020-01-31 01:23:16 --> Router Class Initialized
INFO - 2020-01-31 01:23:16 --> Output Class Initialized
INFO - 2020-01-31 01:23:16 --> Security Class Initialized
DEBUG - 2020-01-31 01:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 01:23:17 --> Input Class Initialized
INFO - 2020-01-31 01:23:17 --> Language Class Initialized
INFO - 2020-01-31 01:23:17 --> Language Class Initialized
INFO - 2020-01-31 01:23:17 --> Config Class Initialized
INFO - 2020-01-31 01:23:17 --> Loader Class Initialized
INFO - 2020-01-31 01:23:17 --> Helper loaded: url_helper
INFO - 2020-01-31 01:23:17 --> Helper loaded: file_helper
INFO - 2020-01-31 01:23:17 --> Helper loaded: form_helper
INFO - 2020-01-31 01:23:17 --> Helper loaded: my_helper
INFO - 2020-01-31 01:23:17 --> Database Driver Class Initialized
DEBUG - 2020-01-31 01:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 01:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 01:23:17 --> Controller Class Initialized
INFO - 2020-01-31 01:23:17 --> Final output sent to browser
DEBUG - 2020-01-31 01:23:17 --> Total execution time: 0.2571
INFO - 2020-01-31 02:45:56 --> Config Class Initialized
INFO - 2020-01-31 02:45:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:45:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:45:56 --> Utf8 Class Initialized
INFO - 2020-01-31 02:45:56 --> URI Class Initialized
INFO - 2020-01-31 02:45:56 --> Router Class Initialized
INFO - 2020-01-31 02:45:56 --> Output Class Initialized
INFO - 2020-01-31 02:45:56 --> Security Class Initialized
DEBUG - 2020-01-31 02:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:45:56 --> Input Class Initialized
INFO - 2020-01-31 02:45:56 --> Language Class Initialized
INFO - 2020-01-31 02:45:56 --> Language Class Initialized
INFO - 2020-01-31 02:45:56 --> Config Class Initialized
INFO - 2020-01-31 02:45:56 --> Loader Class Initialized
INFO - 2020-01-31 02:45:56 --> Helper loaded: url_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: file_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: form_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: my_helper
INFO - 2020-01-31 02:45:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:45:56 --> Controller Class Initialized
INFO - 2020-01-31 02:45:56 --> Helper loaded: cookie_helper
INFO - 2020-01-31 02:45:56 --> Config Class Initialized
INFO - 2020-01-31 02:45:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:45:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:45:56 --> Utf8 Class Initialized
INFO - 2020-01-31 02:45:56 --> URI Class Initialized
INFO - 2020-01-31 02:45:56 --> Router Class Initialized
INFO - 2020-01-31 02:45:56 --> Output Class Initialized
INFO - 2020-01-31 02:45:56 --> Security Class Initialized
DEBUG - 2020-01-31 02:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:45:56 --> Input Class Initialized
INFO - 2020-01-31 02:45:56 --> Language Class Initialized
INFO - 2020-01-31 02:45:56 --> Language Class Initialized
INFO - 2020-01-31 02:45:56 --> Config Class Initialized
INFO - 2020-01-31 02:45:56 --> Loader Class Initialized
INFO - 2020-01-31 02:45:56 --> Helper loaded: url_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: file_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: form_helper
INFO - 2020-01-31 02:45:56 --> Helper loaded: my_helper
INFO - 2020-01-31 02:45:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:45:56 --> Controller Class Initialized
INFO - 2020-01-31 02:45:57 --> Config Class Initialized
INFO - 2020-01-31 02:45:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:45:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:45:57 --> Utf8 Class Initialized
INFO - 2020-01-31 02:45:57 --> URI Class Initialized
INFO - 2020-01-31 02:45:57 --> Router Class Initialized
INFO - 2020-01-31 02:45:57 --> Output Class Initialized
INFO - 2020-01-31 02:45:57 --> Security Class Initialized
DEBUG - 2020-01-31 02:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:45:57 --> Input Class Initialized
INFO - 2020-01-31 02:45:57 --> Language Class Initialized
INFO - 2020-01-31 02:45:57 --> Language Class Initialized
INFO - 2020-01-31 02:45:57 --> Config Class Initialized
INFO - 2020-01-31 02:45:57 --> Loader Class Initialized
INFO - 2020-01-31 02:45:57 --> Helper loaded: url_helper
INFO - 2020-01-31 02:45:57 --> Helper loaded: file_helper
INFO - 2020-01-31 02:45:57 --> Helper loaded: form_helper
INFO - 2020-01-31 02:45:57 --> Helper loaded: my_helper
INFO - 2020-01-31 02:45:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:45:57 --> Controller Class Initialized
DEBUG - 2020-01-31 02:45:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 02:45:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:45:57 --> Final output sent to browser
DEBUG - 2020-01-31 02:45:57 --> Total execution time: 0.3085
INFO - 2020-01-31 02:46:01 --> Config Class Initialized
INFO - 2020-01-31 02:46:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:01 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:01 --> URI Class Initialized
INFO - 2020-01-31 02:46:01 --> Router Class Initialized
INFO - 2020-01-31 02:46:01 --> Output Class Initialized
INFO - 2020-01-31 02:46:01 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:01 --> Input Class Initialized
INFO - 2020-01-31 02:46:01 --> Language Class Initialized
INFO - 2020-01-31 02:46:01 --> Language Class Initialized
INFO - 2020-01-31 02:46:01 --> Config Class Initialized
INFO - 2020-01-31 02:46:01 --> Loader Class Initialized
INFO - 2020-01-31 02:46:01 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:01 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:01 --> Controller Class Initialized
INFO - 2020-01-31 02:46:01 --> Helper loaded: cookie_helper
INFO - 2020-01-31 02:46:01 --> Final output sent to browser
DEBUG - 2020-01-31 02:46:01 --> Total execution time: 0.3244
INFO - 2020-01-31 02:46:01 --> Config Class Initialized
INFO - 2020-01-31 02:46:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:01 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:01 --> URI Class Initialized
INFO - 2020-01-31 02:46:01 --> Router Class Initialized
INFO - 2020-01-31 02:46:01 --> Output Class Initialized
INFO - 2020-01-31 02:46:01 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:01 --> Input Class Initialized
INFO - 2020-01-31 02:46:01 --> Language Class Initialized
INFO - 2020-01-31 02:46:01 --> Language Class Initialized
INFO - 2020-01-31 02:46:01 --> Config Class Initialized
INFO - 2020-01-31 02:46:01 --> Loader Class Initialized
INFO - 2020-01-31 02:46:01 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:01 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:01 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:01 --> Controller Class Initialized
DEBUG - 2020-01-31 02:46:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 02:46:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:46:02 --> Final output sent to browser
DEBUG - 2020-01-31 02:46:02 --> Total execution time: 0.3745
INFO - 2020-01-31 02:46:03 --> Config Class Initialized
INFO - 2020-01-31 02:46:03 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:03 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:03 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:03 --> URI Class Initialized
INFO - 2020-01-31 02:46:03 --> Router Class Initialized
INFO - 2020-01-31 02:46:03 --> Output Class Initialized
INFO - 2020-01-31 02:46:03 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:03 --> Input Class Initialized
INFO - 2020-01-31 02:46:03 --> Language Class Initialized
INFO - 2020-01-31 02:46:03 --> Language Class Initialized
INFO - 2020-01-31 02:46:03 --> Config Class Initialized
INFO - 2020-01-31 02:46:03 --> Loader Class Initialized
INFO - 2020-01-31 02:46:03 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:03 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:03 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:03 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:03 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:03 --> Controller Class Initialized
DEBUG - 2020-01-31 02:46:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-31 02:46:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:46:03 --> Final output sent to browser
DEBUG - 2020-01-31 02:46:03 --> Total execution time: 0.3314
INFO - 2020-01-31 02:46:04 --> Config Class Initialized
INFO - 2020-01-31 02:46:04 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:04 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:04 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:04 --> URI Class Initialized
INFO - 2020-01-31 02:46:04 --> Router Class Initialized
INFO - 2020-01-31 02:46:04 --> Output Class Initialized
INFO - 2020-01-31 02:46:04 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:04 --> Input Class Initialized
INFO - 2020-01-31 02:46:04 --> Language Class Initialized
INFO - 2020-01-31 02:46:04 --> Language Class Initialized
INFO - 2020-01-31 02:46:04 --> Config Class Initialized
INFO - 2020-01-31 02:46:04 --> Loader Class Initialized
INFO - 2020-01-31 02:46:04 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:04 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:04 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:04 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:04 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:04 --> Controller Class Initialized
INFO - 2020-01-31 02:46:09 --> Config Class Initialized
INFO - 2020-01-31 02:46:09 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:09 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:09 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:09 --> URI Class Initialized
INFO - 2020-01-31 02:46:09 --> Router Class Initialized
INFO - 2020-01-31 02:46:09 --> Output Class Initialized
INFO - 2020-01-31 02:46:10 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:10 --> Input Class Initialized
INFO - 2020-01-31 02:46:10 --> Language Class Initialized
ERROR - 2020-01-31 02:46:10 --> 404 Page Not Found: /index
INFO - 2020-01-31 02:46:12 --> Config Class Initialized
INFO - 2020-01-31 02:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:12 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:12 --> URI Class Initialized
INFO - 2020-01-31 02:46:12 --> Router Class Initialized
INFO - 2020-01-31 02:46:12 --> Output Class Initialized
INFO - 2020-01-31 02:46:12 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:12 --> Input Class Initialized
INFO - 2020-01-31 02:46:12 --> Language Class Initialized
INFO - 2020-01-31 02:46:12 --> Language Class Initialized
INFO - 2020-01-31 02:46:12 --> Config Class Initialized
INFO - 2020-01-31 02:46:12 --> Loader Class Initialized
INFO - 2020-01-31 02:46:12 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:12 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:12 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:12 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:12 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:12 --> Controller Class Initialized
DEBUG - 2020-01-31 02:46:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-31 02:46:12 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:46:12 --> Final output sent to browser
DEBUG - 2020-01-31 02:46:12 --> Total execution time: 0.3246
INFO - 2020-01-31 02:46:12 --> Config Class Initialized
INFO - 2020-01-31 02:46:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:12 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:12 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:12 --> URI Class Initialized
INFO - 2020-01-31 02:46:12 --> Router Class Initialized
INFO - 2020-01-31 02:46:12 --> Output Class Initialized
INFO - 2020-01-31 02:46:12 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:12 --> Config Class Initialized
INFO - 2020-01-31 02:46:12 --> Input Class Initialized
INFO - 2020-01-31 02:46:12 --> Hooks Class Initialized
INFO - 2020-01-31 02:46:13 --> Language Class Initialized
DEBUG - 2020-01-31 02:46:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:13 --> Utf8 Class Initialized
ERROR - 2020-01-31 02:46:13 --> 404 Page Not Found: /index
INFO - 2020-01-31 02:46:13 --> URI Class Initialized
INFO - 2020-01-31 02:46:13 --> Router Class Initialized
INFO - 2020-01-31 02:46:13 --> Output Class Initialized
INFO - 2020-01-31 02:46:13 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:13 --> Input Class Initialized
INFO - 2020-01-31 02:46:13 --> Language Class Initialized
INFO - 2020-01-31 02:46:13 --> Language Class Initialized
INFO - 2020-01-31 02:46:13 --> Config Class Initialized
INFO - 2020-01-31 02:46:13 --> Loader Class Initialized
INFO - 2020-01-31 02:46:13 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:13 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:13 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:13 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:13 --> Controller Class Initialized
INFO - 2020-01-31 02:46:16 --> Config Class Initialized
INFO - 2020-01-31 02:46:16 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:16 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:16 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:16 --> URI Class Initialized
INFO - 2020-01-31 02:46:16 --> Router Class Initialized
INFO - 2020-01-31 02:46:16 --> Output Class Initialized
INFO - 2020-01-31 02:46:16 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:16 --> Input Class Initialized
INFO - 2020-01-31 02:46:16 --> Language Class Initialized
INFO - 2020-01-31 02:46:16 --> Language Class Initialized
INFO - 2020-01-31 02:46:16 --> Config Class Initialized
INFO - 2020-01-31 02:46:16 --> Loader Class Initialized
INFO - 2020-01-31 02:46:16 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:16 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:16 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:16 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:17 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:17 --> Controller Class Initialized
DEBUG - 2020-01-31 02:46:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-31 02:46:17 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:46:17 --> Final output sent to browser
DEBUG - 2020-01-31 02:46:17 --> Total execution time: 0.3399
INFO - 2020-01-31 02:46:17 --> Config Class Initialized
INFO - 2020-01-31 02:46:17 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:46:17 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:17 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:17 --> URI Class Initialized
INFO - 2020-01-31 02:46:17 --> Config Class Initialized
INFO - 2020-01-31 02:46:17 --> Hooks Class Initialized
INFO - 2020-01-31 02:46:17 --> Router Class Initialized
INFO - 2020-01-31 02:46:17 --> Output Class Initialized
DEBUG - 2020-01-31 02:46:17 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:46:17 --> Utf8 Class Initialized
INFO - 2020-01-31 02:46:17 --> Security Class Initialized
INFO - 2020-01-31 02:46:17 --> URI Class Initialized
DEBUG - 2020-01-31 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:17 --> Input Class Initialized
INFO - 2020-01-31 02:46:17 --> Router Class Initialized
INFO - 2020-01-31 02:46:17 --> Language Class Initialized
INFO - 2020-01-31 02:46:17 --> Output Class Initialized
ERROR - 2020-01-31 02:46:17 --> 404 Page Not Found: /index
INFO - 2020-01-31 02:46:17 --> Security Class Initialized
DEBUG - 2020-01-31 02:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:46:17 --> Input Class Initialized
INFO - 2020-01-31 02:46:17 --> Language Class Initialized
INFO - 2020-01-31 02:46:17 --> Language Class Initialized
INFO - 2020-01-31 02:46:17 --> Config Class Initialized
INFO - 2020-01-31 02:46:17 --> Loader Class Initialized
INFO - 2020-01-31 02:46:17 --> Helper loaded: url_helper
INFO - 2020-01-31 02:46:18 --> Helper loaded: file_helper
INFO - 2020-01-31 02:46:18 --> Helper loaded: form_helper
INFO - 2020-01-31 02:46:18 --> Helper loaded: my_helper
INFO - 2020-01-31 02:46:18 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:46:18 --> Controller Class Initialized
INFO - 2020-01-31 02:56:41 --> Config Class Initialized
INFO - 2020-01-31 02:56:41 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:56:41 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:56:41 --> Utf8 Class Initialized
INFO - 2020-01-31 02:56:41 --> URI Class Initialized
INFO - 2020-01-31 02:56:41 --> Router Class Initialized
INFO - 2020-01-31 02:56:41 --> Output Class Initialized
INFO - 2020-01-31 02:56:41 --> Security Class Initialized
DEBUG - 2020-01-31 02:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:56:41 --> Input Class Initialized
INFO - 2020-01-31 02:56:41 --> Language Class Initialized
INFO - 2020-01-31 02:56:41 --> Language Class Initialized
INFO - 2020-01-31 02:56:41 --> Config Class Initialized
INFO - 2020-01-31 02:56:41 --> Loader Class Initialized
INFO - 2020-01-31 02:56:41 --> Helper loaded: url_helper
INFO - 2020-01-31 02:56:41 --> Helper loaded: file_helper
INFO - 2020-01-31 02:56:41 --> Helper loaded: form_helper
INFO - 2020-01-31 02:56:41 --> Helper loaded: my_helper
INFO - 2020-01-31 02:56:41 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:56:41 --> Controller Class Initialized
DEBUG - 2020-01-31 02:56:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-31 02:56:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:56:41 --> Final output sent to browser
DEBUG - 2020-01-31 02:56:41 --> Total execution time: 0.3084
INFO - 2020-01-31 02:56:42 --> Config Class Initialized
INFO - 2020-01-31 02:56:42 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:56:42 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:56:42 --> Config Class Initialized
INFO - 2020-01-31 02:56:42 --> Hooks Class Initialized
INFO - 2020-01-31 02:56:42 --> Utf8 Class Initialized
DEBUG - 2020-01-31 02:56:42 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:56:42 --> URI Class Initialized
INFO - 2020-01-31 02:56:42 --> Utf8 Class Initialized
INFO - 2020-01-31 02:56:42 --> Router Class Initialized
INFO - 2020-01-31 02:56:42 --> URI Class Initialized
INFO - 2020-01-31 02:56:42 --> Output Class Initialized
INFO - 2020-01-31 02:56:42 --> Security Class Initialized
INFO - 2020-01-31 02:56:42 --> Router Class Initialized
DEBUG - 2020-01-31 02:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:56:42 --> Output Class Initialized
INFO - 2020-01-31 02:56:42 --> Input Class Initialized
INFO - 2020-01-31 02:56:42 --> Security Class Initialized
INFO - 2020-01-31 02:56:42 --> Language Class Initialized
DEBUG - 2020-01-31 02:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:56:42 --> Input Class Initialized
ERROR - 2020-01-31 02:56:42 --> 404 Page Not Found: /index
INFO - 2020-01-31 02:56:42 --> Language Class Initialized
INFO - 2020-01-31 02:56:42 --> Language Class Initialized
INFO - 2020-01-31 02:56:42 --> Config Class Initialized
INFO - 2020-01-31 02:56:42 --> Loader Class Initialized
INFO - 2020-01-31 02:56:42 --> Helper loaded: url_helper
INFO - 2020-01-31 02:56:42 --> Helper loaded: file_helper
INFO - 2020-01-31 02:56:42 --> Helper loaded: form_helper
INFO - 2020-01-31 02:56:42 --> Helper loaded: my_helper
INFO - 2020-01-31 02:56:42 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:56:42 --> Controller Class Initialized
INFO - 2020-01-31 02:58:02 --> Config Class Initialized
INFO - 2020-01-31 02:58:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:58:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:58:02 --> Utf8 Class Initialized
INFO - 2020-01-31 02:58:02 --> URI Class Initialized
INFO - 2020-01-31 02:58:02 --> Router Class Initialized
INFO - 2020-01-31 02:58:02 --> Output Class Initialized
INFO - 2020-01-31 02:58:02 --> Security Class Initialized
DEBUG - 2020-01-31 02:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:58:02 --> Input Class Initialized
INFO - 2020-01-31 02:58:02 --> Language Class Initialized
INFO - 2020-01-31 02:58:02 --> Language Class Initialized
INFO - 2020-01-31 02:58:02 --> Config Class Initialized
INFO - 2020-01-31 02:58:02 --> Loader Class Initialized
INFO - 2020-01-31 02:58:02 --> Helper loaded: url_helper
INFO - 2020-01-31 02:58:02 --> Helper loaded: file_helper
INFO - 2020-01-31 02:58:02 --> Helper loaded: form_helper
INFO - 2020-01-31 02:58:02 --> Helper loaded: my_helper
INFO - 2020-01-31 02:58:02 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:58:02 --> Controller Class Initialized
DEBUG - 2020-01-31 02:58:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_siswa/views/list.php
DEBUG - 2020-01-31 02:58:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 02:58:02 --> Final output sent to browser
DEBUG - 2020-01-31 02:58:03 --> Total execution time: 0.4284
INFO - 2020-01-31 02:58:03 --> Config Class Initialized
INFO - 2020-01-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:58:03 --> Utf8 Class Initialized
INFO - 2020-01-31 02:58:03 --> URI Class Initialized
INFO - 2020-01-31 02:58:03 --> Router Class Initialized
INFO - 2020-01-31 02:58:03 --> Output Class Initialized
INFO - 2020-01-31 02:58:03 --> Security Class Initialized
INFO - 2020-01-31 02:58:03 --> Config Class Initialized
INFO - 2020-01-31 02:58:03 --> Hooks Class Initialized
DEBUG - 2020-01-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:58:03 --> Input Class Initialized
DEBUG - 2020-01-31 02:58:03 --> UTF-8 Support Enabled
INFO - 2020-01-31 02:58:03 --> Utf8 Class Initialized
INFO - 2020-01-31 02:58:03 --> Language Class Initialized
INFO - 2020-01-31 02:58:03 --> URI Class Initialized
ERROR - 2020-01-31 02:58:03 --> 404 Page Not Found: /index
INFO - 2020-01-31 02:58:03 --> Router Class Initialized
INFO - 2020-01-31 02:58:03 --> Output Class Initialized
INFO - 2020-01-31 02:58:03 --> Security Class Initialized
DEBUG - 2020-01-31 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 02:58:03 --> Input Class Initialized
INFO - 2020-01-31 02:58:03 --> Language Class Initialized
INFO - 2020-01-31 02:58:03 --> Language Class Initialized
INFO - 2020-01-31 02:58:03 --> Config Class Initialized
INFO - 2020-01-31 02:58:03 --> Loader Class Initialized
INFO - 2020-01-31 02:58:03 --> Helper loaded: url_helper
INFO - 2020-01-31 02:58:03 --> Helper loaded: file_helper
INFO - 2020-01-31 02:58:03 --> Helper loaded: form_helper
INFO - 2020-01-31 02:58:03 --> Helper loaded: my_helper
INFO - 2020-01-31 02:58:04 --> Database Driver Class Initialized
DEBUG - 2020-01-31 02:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 02:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 02:58:04 --> Controller Class Initialized
INFO - 2020-01-31 04:17:52 --> Config Class Initialized
INFO - 2020-01-31 04:17:52 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:17:52 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:17:52 --> Utf8 Class Initialized
INFO - 2020-01-31 04:17:52 --> URI Class Initialized
INFO - 2020-01-31 04:17:52 --> Router Class Initialized
INFO - 2020-01-31 04:17:52 --> Output Class Initialized
INFO - 2020-01-31 04:17:52 --> Security Class Initialized
DEBUG - 2020-01-31 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:17:52 --> Input Class Initialized
INFO - 2020-01-31 04:17:52 --> Language Class Initialized
INFO - 2020-01-31 04:17:52 --> Language Class Initialized
INFO - 2020-01-31 04:17:52 --> Config Class Initialized
INFO - 2020-01-31 04:17:52 --> Loader Class Initialized
INFO - 2020-01-31 04:17:52 --> Helper loaded: url_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: file_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: form_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: my_helper
INFO - 2020-01-31 04:17:52 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:17:52 --> Controller Class Initialized
INFO - 2020-01-31 04:17:52 --> Helper loaded: cookie_helper
INFO - 2020-01-31 04:17:52 --> Config Class Initialized
INFO - 2020-01-31 04:17:52 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:17:52 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:17:52 --> Utf8 Class Initialized
INFO - 2020-01-31 04:17:52 --> URI Class Initialized
INFO - 2020-01-31 04:17:52 --> Router Class Initialized
INFO - 2020-01-31 04:17:52 --> Output Class Initialized
INFO - 2020-01-31 04:17:52 --> Security Class Initialized
DEBUG - 2020-01-31 04:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:17:52 --> Input Class Initialized
INFO - 2020-01-31 04:17:52 --> Language Class Initialized
INFO - 2020-01-31 04:17:52 --> Language Class Initialized
INFO - 2020-01-31 04:17:52 --> Config Class Initialized
INFO - 2020-01-31 04:17:52 --> Loader Class Initialized
INFO - 2020-01-31 04:17:52 --> Helper loaded: url_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: file_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: form_helper
INFO - 2020-01-31 04:17:52 --> Helper loaded: my_helper
INFO - 2020-01-31 04:17:52 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:17:52 --> Controller Class Initialized
INFO - 2020-01-31 04:17:52 --> Config Class Initialized
INFO - 2020-01-31 04:17:53 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:17:53 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:17:53 --> Utf8 Class Initialized
INFO - 2020-01-31 04:17:53 --> URI Class Initialized
INFO - 2020-01-31 04:17:53 --> Router Class Initialized
INFO - 2020-01-31 04:17:53 --> Output Class Initialized
INFO - 2020-01-31 04:17:53 --> Security Class Initialized
DEBUG - 2020-01-31 04:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:17:53 --> Input Class Initialized
INFO - 2020-01-31 04:17:53 --> Language Class Initialized
INFO - 2020-01-31 04:17:53 --> Language Class Initialized
INFO - 2020-01-31 04:17:53 --> Config Class Initialized
INFO - 2020-01-31 04:17:53 --> Loader Class Initialized
INFO - 2020-01-31 04:17:53 --> Helper loaded: url_helper
INFO - 2020-01-31 04:17:53 --> Helper loaded: file_helper
INFO - 2020-01-31 04:17:53 --> Helper loaded: form_helper
INFO - 2020-01-31 04:17:53 --> Helper loaded: my_helper
INFO - 2020-01-31 04:17:53 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:17:53 --> Controller Class Initialized
DEBUG - 2020-01-31 04:17:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 04:17:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 04:17:53 --> Final output sent to browser
DEBUG - 2020-01-31 04:17:53 --> Total execution time: 0.3468
INFO - 2020-01-31 04:18:01 --> Config Class Initialized
INFO - 2020-01-31 04:18:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:18:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:18:01 --> Utf8 Class Initialized
INFO - 2020-01-31 04:18:01 --> URI Class Initialized
INFO - 2020-01-31 04:18:01 --> Router Class Initialized
INFO - 2020-01-31 04:18:01 --> Output Class Initialized
INFO - 2020-01-31 04:18:02 --> Security Class Initialized
DEBUG - 2020-01-31 04:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:18:02 --> Input Class Initialized
INFO - 2020-01-31 04:18:02 --> Language Class Initialized
INFO - 2020-01-31 04:18:02 --> Language Class Initialized
INFO - 2020-01-31 04:18:02 --> Config Class Initialized
INFO - 2020-01-31 04:18:02 --> Loader Class Initialized
INFO - 2020-01-31 04:18:02 --> Helper loaded: url_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: file_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: form_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: my_helper
INFO - 2020-01-31 04:18:02 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:18:02 --> Controller Class Initialized
INFO - 2020-01-31 04:18:02 --> Helper loaded: cookie_helper
INFO - 2020-01-31 04:18:02 --> Final output sent to browser
DEBUG - 2020-01-31 04:18:02 --> Total execution time: 0.3551
INFO - 2020-01-31 04:18:02 --> Config Class Initialized
INFO - 2020-01-31 04:18:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:18:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:18:02 --> Utf8 Class Initialized
INFO - 2020-01-31 04:18:02 --> URI Class Initialized
INFO - 2020-01-31 04:18:02 --> Router Class Initialized
INFO - 2020-01-31 04:18:02 --> Output Class Initialized
INFO - 2020-01-31 04:18:02 --> Security Class Initialized
DEBUG - 2020-01-31 04:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:18:02 --> Input Class Initialized
INFO - 2020-01-31 04:18:02 --> Language Class Initialized
INFO - 2020-01-31 04:18:02 --> Language Class Initialized
INFO - 2020-01-31 04:18:02 --> Config Class Initialized
INFO - 2020-01-31 04:18:02 --> Loader Class Initialized
INFO - 2020-01-31 04:18:02 --> Helper loaded: url_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: file_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: form_helper
INFO - 2020-01-31 04:18:02 --> Helper loaded: my_helper
INFO - 2020-01-31 04:18:02 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:18:02 --> Controller Class Initialized
DEBUG - 2020-01-31 04:18:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 04:18:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 04:18:02 --> Final output sent to browser
DEBUG - 2020-01-31 04:18:02 --> Total execution time: 0.4139
INFO - 2020-01-31 04:18:11 --> Config Class Initialized
INFO - 2020-01-31 04:18:11 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:18:11 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:18:11 --> Utf8 Class Initialized
INFO - 2020-01-31 04:18:11 --> URI Class Initialized
INFO - 2020-01-31 04:18:11 --> Router Class Initialized
INFO - 2020-01-31 04:18:11 --> Output Class Initialized
INFO - 2020-01-31 04:18:11 --> Security Class Initialized
DEBUG - 2020-01-31 04:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:18:11 --> Input Class Initialized
INFO - 2020-01-31 04:18:11 --> Language Class Initialized
INFO - 2020-01-31 04:18:11 --> Language Class Initialized
INFO - 2020-01-31 04:18:11 --> Config Class Initialized
INFO - 2020-01-31 04:18:11 --> Loader Class Initialized
INFO - 2020-01-31 04:18:11 --> Helper loaded: url_helper
INFO - 2020-01-31 04:18:11 --> Helper loaded: file_helper
INFO - 2020-01-31 04:18:11 --> Helper loaded: form_helper
INFO - 2020-01-31 04:18:11 --> Helper loaded: my_helper
INFO - 2020-01-31 04:18:11 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:18:11 --> Controller Class Initialized
DEBUG - 2020-01-31 04:18:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-31 04:18:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 04:18:11 --> Final output sent to browser
DEBUG - 2020-01-31 04:18:11 --> Total execution time: 0.3261
INFO - 2020-01-31 04:18:22 --> Config Class Initialized
INFO - 2020-01-31 04:18:22 --> Hooks Class Initialized
DEBUG - 2020-01-31 04:18:22 --> UTF-8 Support Enabled
INFO - 2020-01-31 04:18:22 --> Utf8 Class Initialized
INFO - 2020-01-31 04:18:22 --> URI Class Initialized
INFO - 2020-01-31 04:18:22 --> Router Class Initialized
INFO - 2020-01-31 04:18:22 --> Output Class Initialized
INFO - 2020-01-31 04:18:22 --> Security Class Initialized
DEBUG - 2020-01-31 04:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 04:18:22 --> Input Class Initialized
INFO - 2020-01-31 04:18:22 --> Language Class Initialized
INFO - 2020-01-31 04:18:22 --> Language Class Initialized
INFO - 2020-01-31 04:18:22 --> Config Class Initialized
INFO - 2020-01-31 04:18:22 --> Loader Class Initialized
INFO - 2020-01-31 04:18:22 --> Helper loaded: url_helper
INFO - 2020-01-31 04:18:22 --> Helper loaded: file_helper
INFO - 2020-01-31 04:18:22 --> Helper loaded: form_helper
INFO - 2020-01-31 04:18:22 --> Helper loaded: my_helper
INFO - 2020-01-31 04:18:22 --> Database Driver Class Initialized
DEBUG - 2020-01-31 04:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 04:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 04:18:22 --> Controller Class Initialized
DEBUG - 2020-01-31 04:18:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-31 04:18:22 --> Final output sent to browser
DEBUG - 2020-01-31 04:18:22 --> Total execution time: 0.3588
INFO - 2020-01-31 07:45:34 --> Config Class Initialized
INFO - 2020-01-31 07:45:34 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:34 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:34 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:34 --> URI Class Initialized
DEBUG - 2020-01-31 07:45:34 --> No URI present. Default controller set.
INFO - 2020-01-31 07:45:34 --> Router Class Initialized
INFO - 2020-01-31 07:45:34 --> Output Class Initialized
INFO - 2020-01-31 07:45:34 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:34 --> Input Class Initialized
INFO - 2020-01-31 07:45:34 --> Language Class Initialized
INFO - 2020-01-31 07:45:34 --> Language Class Initialized
INFO - 2020-01-31 07:45:34 --> Config Class Initialized
INFO - 2020-01-31 07:45:34 --> Loader Class Initialized
INFO - 2020-01-31 07:45:34 --> Helper loaded: url_helper
INFO - 2020-01-31 07:45:34 --> Helper loaded: file_helper
INFO - 2020-01-31 07:45:34 --> Helper loaded: form_helper
INFO - 2020-01-31 07:45:34 --> Helper loaded: my_helper
INFO - 2020-01-31 07:45:34 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:45:34 --> Controller Class Initialized
INFO - 2020-01-31 07:45:34 --> Config Class Initialized
INFO - 2020-01-31 07:45:34 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:34 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:35 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:35 --> URI Class Initialized
INFO - 2020-01-31 07:45:35 --> Router Class Initialized
INFO - 2020-01-31 07:45:35 --> Output Class Initialized
INFO - 2020-01-31 07:45:35 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:35 --> Input Class Initialized
INFO - 2020-01-31 07:45:35 --> Language Class Initialized
INFO - 2020-01-31 07:45:35 --> Language Class Initialized
INFO - 2020-01-31 07:45:35 --> Config Class Initialized
INFO - 2020-01-31 07:45:35 --> Loader Class Initialized
INFO - 2020-01-31 07:45:35 --> Helper loaded: url_helper
INFO - 2020-01-31 07:45:35 --> Helper loaded: file_helper
INFO - 2020-01-31 07:45:35 --> Helper loaded: form_helper
INFO - 2020-01-31 07:45:35 --> Helper loaded: my_helper
INFO - 2020-01-31 07:45:35 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:45:35 --> Controller Class Initialized
DEBUG - 2020-01-31 07:45:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 07:45:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:45:35 --> Final output sent to browser
DEBUG - 2020-01-31 07:45:35 --> Total execution time: 0.3311
INFO - 2020-01-31 07:45:47 --> Config Class Initialized
INFO - 2020-01-31 07:45:47 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:47 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:47 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:47 --> URI Class Initialized
INFO - 2020-01-31 07:45:47 --> Router Class Initialized
INFO - 2020-01-31 07:45:47 --> Output Class Initialized
INFO - 2020-01-31 07:45:47 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:47 --> Input Class Initialized
INFO - 2020-01-31 07:45:47 --> Language Class Initialized
INFO - 2020-01-31 07:45:47 --> Language Class Initialized
INFO - 2020-01-31 07:45:47 --> Config Class Initialized
INFO - 2020-01-31 07:45:47 --> Loader Class Initialized
INFO - 2020-01-31 07:45:47 --> Helper loaded: url_helper
INFO - 2020-01-31 07:45:47 --> Helper loaded: file_helper
INFO - 2020-01-31 07:45:47 --> Helper loaded: form_helper
INFO - 2020-01-31 07:45:47 --> Helper loaded: my_helper
INFO - 2020-01-31 07:45:47 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:45:48 --> Controller Class Initialized
INFO - 2020-01-31 07:45:48 --> Helper loaded: cookie_helper
INFO - 2020-01-31 07:45:48 --> Final output sent to browser
DEBUG - 2020-01-31 07:45:48 --> Total execution time: 0.3400
INFO - 2020-01-31 07:45:48 --> Config Class Initialized
INFO - 2020-01-31 07:45:48 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:48 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:48 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:48 --> URI Class Initialized
INFO - 2020-01-31 07:45:48 --> Router Class Initialized
INFO - 2020-01-31 07:45:48 --> Output Class Initialized
INFO - 2020-01-31 07:45:48 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:48 --> Input Class Initialized
INFO - 2020-01-31 07:45:48 --> Language Class Initialized
INFO - 2020-01-31 07:45:48 --> Language Class Initialized
INFO - 2020-01-31 07:45:48 --> Config Class Initialized
INFO - 2020-01-31 07:45:48 --> Loader Class Initialized
INFO - 2020-01-31 07:45:48 --> Helper loaded: url_helper
INFO - 2020-01-31 07:45:48 --> Helper loaded: file_helper
INFO - 2020-01-31 07:45:48 --> Helper loaded: form_helper
INFO - 2020-01-31 07:45:48 --> Helper loaded: my_helper
INFO - 2020-01-31 07:45:48 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:45:48 --> Controller Class Initialized
DEBUG - 2020-01-31 07:45:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 07:45:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:45:48 --> Final output sent to browser
DEBUG - 2020-01-31 07:45:48 --> Total execution time: 0.4398
INFO - 2020-01-31 07:45:53 --> Config Class Initialized
INFO - 2020-01-31 07:45:53 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:53 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:53 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:53 --> URI Class Initialized
INFO - 2020-01-31 07:45:53 --> Router Class Initialized
INFO - 2020-01-31 07:45:53 --> Output Class Initialized
INFO - 2020-01-31 07:45:53 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:53 --> Input Class Initialized
INFO - 2020-01-31 07:45:53 --> Language Class Initialized
INFO - 2020-01-31 07:45:53 --> Language Class Initialized
INFO - 2020-01-31 07:45:53 --> Config Class Initialized
INFO - 2020-01-31 07:45:53 --> Loader Class Initialized
INFO - 2020-01-31 07:45:53 --> Helper loaded: url_helper
INFO - 2020-01-31 07:45:53 --> Helper loaded: file_helper
INFO - 2020-01-31 07:45:53 --> Helper loaded: form_helper
INFO - 2020-01-31 07:45:53 --> Helper loaded: my_helper
INFO - 2020-01-31 07:45:53 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:45:53 --> Controller Class Initialized
DEBUG - 2020-01-31 07:45:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-31 07:45:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:45:54 --> Final output sent to browser
DEBUG - 2020-01-31 07:45:54 --> Total execution time: 0.3373
INFO - 2020-01-31 07:45:59 --> Config Class Initialized
INFO - 2020-01-31 07:45:59 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:45:59 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:45:59 --> Utf8 Class Initialized
INFO - 2020-01-31 07:45:59 --> URI Class Initialized
INFO - 2020-01-31 07:45:59 --> Router Class Initialized
INFO - 2020-01-31 07:45:59 --> Output Class Initialized
INFO - 2020-01-31 07:45:59 --> Security Class Initialized
DEBUG - 2020-01-31 07:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:45:59 --> Input Class Initialized
INFO - 2020-01-31 07:45:59 --> Language Class Initialized
INFO - 2020-01-31 07:45:59 --> Language Class Initialized
INFO - 2020-01-31 07:45:59 --> Config Class Initialized
INFO - 2020-01-31 07:45:59 --> Loader Class Initialized
INFO - 2020-01-31 07:45:59 --> Helper loaded: url_helper
INFO - 2020-01-31 07:46:00 --> Helper loaded: file_helper
INFO - 2020-01-31 07:46:00 --> Helper loaded: form_helper
INFO - 2020-01-31 07:46:00 --> Helper loaded: my_helper
INFO - 2020-01-31 07:46:00 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:46:00 --> Controller Class Initialized
DEBUG - 2020-01-31 07:46:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-01-31 07:46:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:46:00 --> Final output sent to browser
DEBUG - 2020-01-31 07:46:00 --> Total execution time: 0.3291
INFO - 2020-01-31 07:46:01 --> Config Class Initialized
INFO - 2020-01-31 07:46:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:46:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:46:01 --> Utf8 Class Initialized
INFO - 2020-01-31 07:46:01 --> URI Class Initialized
INFO - 2020-01-31 07:46:01 --> Router Class Initialized
INFO - 2020-01-31 07:46:01 --> Output Class Initialized
INFO - 2020-01-31 07:46:01 --> Security Class Initialized
DEBUG - 2020-01-31 07:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:46:01 --> Input Class Initialized
INFO - 2020-01-31 07:46:01 --> Language Class Initialized
INFO - 2020-01-31 07:46:01 --> Language Class Initialized
INFO - 2020-01-31 07:46:01 --> Config Class Initialized
INFO - 2020-01-31 07:46:01 --> Loader Class Initialized
INFO - 2020-01-31 07:46:01 --> Helper loaded: url_helper
INFO - 2020-01-31 07:46:01 --> Helper loaded: file_helper
INFO - 2020-01-31 07:46:01 --> Helper loaded: form_helper
INFO - 2020-01-31 07:46:01 --> Helper loaded: my_helper
INFO - 2020-01-31 07:46:01 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:46:01 --> Controller Class Initialized
DEBUG - 2020-01-31 07:46:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_leger/views/cetak.php
INFO - 2020-01-31 07:46:02 --> Final output sent to browser
DEBUG - 2020-01-31 07:46:02 --> Total execution time: 0.9946
INFO - 2020-01-31 07:46:27 --> Config Class Initialized
INFO - 2020-01-31 07:46:27 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:46:27 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:46:27 --> Utf8 Class Initialized
INFO - 2020-01-31 07:46:27 --> URI Class Initialized
INFO - 2020-01-31 07:46:27 --> Router Class Initialized
INFO - 2020-01-31 07:46:27 --> Output Class Initialized
INFO - 2020-01-31 07:46:27 --> Security Class Initialized
DEBUG - 2020-01-31 07:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:46:28 --> Input Class Initialized
INFO - 2020-01-31 07:46:28 --> Language Class Initialized
INFO - 2020-01-31 07:46:28 --> Language Class Initialized
INFO - 2020-01-31 07:46:28 --> Config Class Initialized
INFO - 2020-01-31 07:46:28 --> Loader Class Initialized
INFO - 2020-01-31 07:46:28 --> Helper loaded: url_helper
INFO - 2020-01-31 07:46:28 --> Helper loaded: file_helper
INFO - 2020-01-31 07:46:28 --> Helper loaded: form_helper
INFO - 2020-01-31 07:46:28 --> Helper loaded: my_helper
INFO - 2020-01-31 07:46:28 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:46:28 --> Controller Class Initialized
DEBUG - 2020-01-31 07:46:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-31 07:46:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:46:28 --> Final output sent to browser
DEBUG - 2020-01-31 07:46:28 --> Total execution time: 0.3603
INFO - 2020-01-31 07:46:29 --> Config Class Initialized
INFO - 2020-01-31 07:46:29 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:46:29 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:46:29 --> Utf8 Class Initialized
INFO - 2020-01-31 07:46:29 --> URI Class Initialized
INFO - 2020-01-31 07:46:29 --> Router Class Initialized
INFO - 2020-01-31 07:46:29 --> Output Class Initialized
INFO - 2020-01-31 07:46:29 --> Security Class Initialized
DEBUG - 2020-01-31 07:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:46:29 --> Input Class Initialized
INFO - 2020-01-31 07:46:29 --> Language Class Initialized
INFO - 2020-01-31 07:46:29 --> Language Class Initialized
INFO - 2020-01-31 07:46:29 --> Config Class Initialized
INFO - 2020-01-31 07:46:29 --> Loader Class Initialized
INFO - 2020-01-31 07:46:29 --> Helper loaded: url_helper
INFO - 2020-01-31 07:46:29 --> Helper loaded: file_helper
INFO - 2020-01-31 07:46:29 --> Helper loaded: form_helper
INFO - 2020-01-31 07:46:29 --> Helper loaded: my_helper
INFO - 2020-01-31 07:46:29 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:46:29 --> Controller Class Initialized
DEBUG - 2020-01-31 07:46:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-31 07:46:29 --> Final output sent to browser
DEBUG - 2020-01-31 07:46:29 --> Total execution time: 0.4655
INFO - 2020-01-31 07:55:00 --> Config Class Initialized
INFO - 2020-01-31 07:55:00 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:55:00 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:55:00 --> Utf8 Class Initialized
INFO - 2020-01-31 07:55:00 --> URI Class Initialized
INFO - 2020-01-31 07:55:00 --> Router Class Initialized
INFO - 2020-01-31 07:55:00 --> Output Class Initialized
INFO - 2020-01-31 07:55:00 --> Security Class Initialized
DEBUG - 2020-01-31 07:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:55:00 --> Input Class Initialized
INFO - 2020-01-31 07:55:00 --> Language Class Initialized
INFO - 2020-01-31 07:55:00 --> Language Class Initialized
INFO - 2020-01-31 07:55:00 --> Config Class Initialized
INFO - 2020-01-31 07:55:00 --> Loader Class Initialized
INFO - 2020-01-31 07:55:00 --> Helper loaded: url_helper
INFO - 2020-01-31 07:55:00 --> Helper loaded: file_helper
INFO - 2020-01-31 07:55:00 --> Helper loaded: form_helper
INFO - 2020-01-31 07:55:00 --> Helper loaded: my_helper
INFO - 2020-01-31 07:55:00 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:55:00 --> Controller Class Initialized
DEBUG - 2020-01-31 07:55:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/list.php
DEBUG - 2020-01-31 07:55:00 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:55:00 --> Final output sent to browser
DEBUG - 2020-01-31 07:55:00 --> Total execution time: 0.3069
INFO - 2020-01-31 07:55:02 --> Config Class Initialized
INFO - 2020-01-31 07:55:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:55:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:55:02 --> Utf8 Class Initialized
INFO - 2020-01-31 07:55:02 --> URI Class Initialized
INFO - 2020-01-31 07:55:02 --> Router Class Initialized
INFO - 2020-01-31 07:55:02 --> Output Class Initialized
INFO - 2020-01-31 07:55:02 --> Security Class Initialized
DEBUG - 2020-01-31 07:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:55:02 --> Input Class Initialized
INFO - 2020-01-31 07:55:02 --> Language Class Initialized
ERROR - 2020-01-31 07:55:02 --> 404 Page Not Found: /index
INFO - 2020-01-31 07:56:08 --> Config Class Initialized
INFO - 2020-01-31 07:56:08 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:56:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:56:08 --> Utf8 Class Initialized
INFO - 2020-01-31 07:56:08 --> URI Class Initialized
INFO - 2020-01-31 07:56:08 --> Router Class Initialized
INFO - 2020-01-31 07:56:08 --> Output Class Initialized
INFO - 2020-01-31 07:56:08 --> Security Class Initialized
DEBUG - 2020-01-31 07:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:56:08 --> Input Class Initialized
INFO - 2020-01-31 07:56:08 --> Language Class Initialized
ERROR - 2020-01-31 07:56:08 --> 404 Page Not Found: ../modules/cetak_raport_pts/controllers/Cetak_raport_pts/index
INFO - 2020-01-31 07:56:31 --> Config Class Initialized
INFO - 2020-01-31 07:56:31 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:56:31 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:56:31 --> Utf8 Class Initialized
INFO - 2020-01-31 07:56:31 --> URI Class Initialized
INFO - 2020-01-31 07:56:31 --> Router Class Initialized
INFO - 2020-01-31 07:56:31 --> Output Class Initialized
INFO - 2020-01-31 07:56:31 --> Security Class Initialized
DEBUG - 2020-01-31 07:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:56:31 --> Input Class Initialized
INFO - 2020-01-31 07:56:31 --> Language Class Initialized
INFO - 2020-01-31 07:56:31 --> Language Class Initialized
INFO - 2020-01-31 07:56:31 --> Config Class Initialized
INFO - 2020-01-31 07:56:31 --> Loader Class Initialized
INFO - 2020-01-31 07:56:31 --> Helper loaded: url_helper
INFO - 2020-01-31 07:56:31 --> Helper loaded: file_helper
INFO - 2020-01-31 07:56:31 --> Helper loaded: form_helper
INFO - 2020-01-31 07:56:31 --> Helper loaded: my_helper
INFO - 2020-01-31 07:56:31 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:56:31 --> Controller Class Initialized
DEBUG - 2020-01-31 07:56:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-01-31 07:56:31 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:56:31 --> Final output sent to browser
DEBUG - 2020-01-31 07:56:31 --> Total execution time: 0.3493
INFO - 2020-01-31 07:57:09 --> Config Class Initialized
INFO - 2020-01-31 07:57:09 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:57:09 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:57:10 --> Utf8 Class Initialized
INFO - 2020-01-31 07:57:10 --> URI Class Initialized
INFO - 2020-01-31 07:57:10 --> Router Class Initialized
INFO - 2020-01-31 07:57:10 --> Output Class Initialized
INFO - 2020-01-31 07:57:10 --> Security Class Initialized
DEBUG - 2020-01-31 07:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:57:10 --> Input Class Initialized
INFO - 2020-01-31 07:57:10 --> Language Class Initialized
INFO - 2020-01-31 07:57:10 --> Language Class Initialized
INFO - 2020-01-31 07:57:10 --> Config Class Initialized
INFO - 2020-01-31 07:57:10 --> Loader Class Initialized
INFO - 2020-01-31 07:57:10 --> Helper loaded: url_helper
INFO - 2020-01-31 07:57:10 --> Helper loaded: file_helper
INFO - 2020-01-31 07:57:10 --> Helper loaded: form_helper
INFO - 2020-01-31 07:57:10 --> Helper loaded: my_helper
INFO - 2020-01-31 07:57:10 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:57:10 --> Controller Class Initialized
DEBUG - 2020-01-31 07:57:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-01-31 07:57:10 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:57:10 --> Final output sent to browser
DEBUG - 2020-01-31 07:57:10 --> Total execution time: 0.3563
INFO - 2020-01-31 07:57:17 --> Config Class Initialized
INFO - 2020-01-31 07:57:18 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:57:18 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:57:18 --> Utf8 Class Initialized
INFO - 2020-01-31 07:57:18 --> URI Class Initialized
INFO - 2020-01-31 07:57:18 --> Router Class Initialized
INFO - 2020-01-31 07:57:18 --> Output Class Initialized
INFO - 2020-01-31 07:57:18 --> Security Class Initialized
DEBUG - 2020-01-31 07:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:57:18 --> Input Class Initialized
INFO - 2020-01-31 07:57:18 --> Language Class Initialized
INFO - 2020-01-31 07:57:18 --> Language Class Initialized
INFO - 2020-01-31 07:57:18 --> Config Class Initialized
INFO - 2020-01-31 07:57:18 --> Loader Class Initialized
INFO - 2020-01-31 07:57:18 --> Helper loaded: url_helper
INFO - 2020-01-31 07:57:18 --> Helper loaded: file_helper
INFO - 2020-01-31 07:57:18 --> Helper loaded: form_helper
INFO - 2020-01-31 07:57:18 --> Helper loaded: my_helper
INFO - 2020-01-31 07:57:18 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:57:18 --> Controller Class Initialized
INFO - 2020-01-31 07:57:51 --> Config Class Initialized
INFO - 2020-01-31 07:57:51 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:57:51 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:57:51 --> Utf8 Class Initialized
INFO - 2020-01-31 07:57:51 --> URI Class Initialized
INFO - 2020-01-31 07:57:51 --> Router Class Initialized
INFO - 2020-01-31 07:57:51 --> Output Class Initialized
INFO - 2020-01-31 07:57:51 --> Security Class Initialized
DEBUG - 2020-01-31 07:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:57:51 --> Input Class Initialized
INFO - 2020-01-31 07:57:51 --> Language Class Initialized
INFO - 2020-01-31 07:57:51 --> Language Class Initialized
INFO - 2020-01-31 07:57:51 --> Config Class Initialized
INFO - 2020-01-31 07:57:51 --> Loader Class Initialized
INFO - 2020-01-31 07:57:51 --> Helper loaded: url_helper
INFO - 2020-01-31 07:57:51 --> Helper loaded: file_helper
INFO - 2020-01-31 07:57:51 --> Helper loaded: form_helper
INFO - 2020-01-31 07:57:51 --> Helper loaded: my_helper
INFO - 2020-01-31 07:57:51 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:57:51 --> Controller Class Initialized
DEBUG - 2020-01-31 07:57:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-01-31 07:57:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 07:57:51 --> Final output sent to browser
DEBUG - 2020-01-31 07:57:51 --> Total execution time: 0.3449
INFO - 2020-01-31 07:58:00 --> Config Class Initialized
INFO - 2020-01-31 07:58:00 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:58:00 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:58:00 --> Utf8 Class Initialized
INFO - 2020-01-31 07:58:00 --> URI Class Initialized
INFO - 2020-01-31 07:58:00 --> Router Class Initialized
INFO - 2020-01-31 07:58:00 --> Output Class Initialized
INFO - 2020-01-31 07:58:00 --> Security Class Initialized
DEBUG - 2020-01-31 07:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:58:00 --> Input Class Initialized
INFO - 2020-01-31 07:58:00 --> Language Class Initialized
INFO - 2020-01-31 07:58:00 --> Language Class Initialized
INFO - 2020-01-31 07:58:00 --> Config Class Initialized
INFO - 2020-01-31 07:58:00 --> Loader Class Initialized
INFO - 2020-01-31 07:58:00 --> Helper loaded: url_helper
INFO - 2020-01-31 07:58:00 --> Helper loaded: file_helper
INFO - 2020-01-31 07:58:00 --> Helper loaded: form_helper
INFO - 2020-01-31 07:58:00 --> Helper loaded: my_helper
INFO - 2020-01-31 07:58:00 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:58:00 --> Controller Class Initialized
INFO - 2020-01-31 07:58:49 --> Config Class Initialized
INFO - 2020-01-31 07:58:49 --> Hooks Class Initialized
DEBUG - 2020-01-31 07:58:49 --> UTF-8 Support Enabled
INFO - 2020-01-31 07:58:49 --> Utf8 Class Initialized
INFO - 2020-01-31 07:58:49 --> URI Class Initialized
INFO - 2020-01-31 07:58:49 --> Router Class Initialized
INFO - 2020-01-31 07:58:49 --> Output Class Initialized
INFO - 2020-01-31 07:58:49 --> Security Class Initialized
DEBUG - 2020-01-31 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 07:58:49 --> Input Class Initialized
INFO - 2020-01-31 07:58:49 --> Language Class Initialized
INFO - 2020-01-31 07:58:49 --> Language Class Initialized
INFO - 2020-01-31 07:58:49 --> Config Class Initialized
INFO - 2020-01-31 07:58:49 --> Loader Class Initialized
INFO - 2020-01-31 07:58:49 --> Helper loaded: url_helper
INFO - 2020-01-31 07:58:49 --> Helper loaded: file_helper
INFO - 2020-01-31 07:58:49 --> Helper loaded: form_helper
INFO - 2020-01-31 07:58:49 --> Helper loaded: my_helper
INFO - 2020-01-31 07:58:49 --> Database Driver Class Initialized
DEBUG - 2020-01-31 07:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 07:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 07:58:49 --> Controller Class Initialized
DEBUG - 2020-01-31 07:58:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 07:58:49 --> Final output sent to browser
DEBUG - 2020-01-31 07:58:49 --> Total execution time: 0.3562
INFO - 2020-01-31 08:02:13 --> Config Class Initialized
INFO - 2020-01-31 08:02:13 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:02:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:02:13 --> Utf8 Class Initialized
INFO - 2020-01-31 08:02:13 --> URI Class Initialized
INFO - 2020-01-31 08:02:13 --> Router Class Initialized
INFO - 2020-01-31 08:02:13 --> Output Class Initialized
INFO - 2020-01-31 08:02:13 --> Security Class Initialized
DEBUG - 2020-01-31 08:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:02:13 --> Input Class Initialized
INFO - 2020-01-31 08:02:13 --> Language Class Initialized
INFO - 2020-01-31 08:02:13 --> Language Class Initialized
INFO - 2020-01-31 08:02:13 --> Config Class Initialized
INFO - 2020-01-31 08:02:13 --> Loader Class Initialized
INFO - 2020-01-31 08:02:13 --> Helper loaded: url_helper
INFO - 2020-01-31 08:02:13 --> Helper loaded: file_helper
INFO - 2020-01-31 08:02:13 --> Helper loaded: form_helper
INFO - 2020-01-31 08:02:13 --> Helper loaded: my_helper
INFO - 2020-01-31 08:02:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:02:13 --> Controller Class Initialized
DEBUG - 2020-01-31 08:02:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-31 08:02:13 --> Final output sent to browser
DEBUG - 2020-01-31 08:02:13 --> Total execution time: 0.3544
INFO - 2020-01-31 08:02:19 --> Config Class Initialized
INFO - 2020-01-31 08:02:19 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:02:19 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:02:19 --> Utf8 Class Initialized
INFO - 2020-01-31 08:02:19 --> URI Class Initialized
INFO - 2020-01-31 08:02:19 --> Router Class Initialized
INFO - 2020-01-31 08:02:19 --> Output Class Initialized
INFO - 2020-01-31 08:02:19 --> Security Class Initialized
DEBUG - 2020-01-31 08:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:02:19 --> Input Class Initialized
INFO - 2020-01-31 08:02:19 --> Language Class Initialized
INFO - 2020-01-31 08:02:19 --> Language Class Initialized
INFO - 2020-01-31 08:02:19 --> Config Class Initialized
INFO - 2020-01-31 08:02:19 --> Loader Class Initialized
INFO - 2020-01-31 08:02:19 --> Helper loaded: url_helper
INFO - 2020-01-31 08:02:19 --> Helper loaded: file_helper
INFO - 2020-01-31 08:02:19 --> Helper loaded: form_helper
INFO - 2020-01-31 08:02:19 --> Helper loaded: my_helper
INFO - 2020-01-31 08:02:19 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:02:19 --> Controller Class Initialized
DEBUG - 2020-01-31 08:02:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:02:19 --> Final output sent to browser
DEBUG - 2020-01-31 08:02:19 --> Total execution time: 0.3434
INFO - 2020-01-31 08:03:21 --> Config Class Initialized
INFO - 2020-01-31 08:03:21 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:03:21 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:03:21 --> Utf8 Class Initialized
INFO - 2020-01-31 08:03:21 --> URI Class Initialized
INFO - 2020-01-31 08:03:21 --> Router Class Initialized
INFO - 2020-01-31 08:03:21 --> Output Class Initialized
INFO - 2020-01-31 08:03:21 --> Security Class Initialized
DEBUG - 2020-01-31 08:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:03:21 --> Input Class Initialized
INFO - 2020-01-31 08:03:21 --> Language Class Initialized
INFO - 2020-01-31 08:03:21 --> Language Class Initialized
INFO - 2020-01-31 08:03:21 --> Config Class Initialized
INFO - 2020-01-31 08:03:21 --> Loader Class Initialized
INFO - 2020-01-31 08:03:21 --> Helper loaded: url_helper
INFO - 2020-01-31 08:03:21 --> Helper loaded: file_helper
INFO - 2020-01-31 08:03:21 --> Helper loaded: form_helper
INFO - 2020-01-31 08:03:21 --> Helper loaded: my_helper
INFO - 2020-01-31 08:03:21 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:03:21 --> Controller Class Initialized
DEBUG - 2020-01-31 08:03:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:03:21 --> Final output sent to browser
DEBUG - 2020-01-31 08:03:21 --> Total execution time: 0.3424
INFO - 2020-01-31 08:03:24 --> Config Class Initialized
INFO - 2020-01-31 08:03:24 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:03:24 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:03:24 --> Utf8 Class Initialized
INFO - 2020-01-31 08:03:24 --> URI Class Initialized
INFO - 2020-01-31 08:03:24 --> Router Class Initialized
INFO - 2020-01-31 08:03:24 --> Output Class Initialized
INFO - 2020-01-31 08:03:24 --> Security Class Initialized
DEBUG - 2020-01-31 08:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:03:24 --> Input Class Initialized
INFO - 2020-01-31 08:03:24 --> Language Class Initialized
INFO - 2020-01-31 08:03:24 --> Language Class Initialized
INFO - 2020-01-31 08:03:24 --> Config Class Initialized
INFO - 2020-01-31 08:03:24 --> Loader Class Initialized
INFO - 2020-01-31 08:03:24 --> Helper loaded: url_helper
INFO - 2020-01-31 08:03:24 --> Helper loaded: file_helper
INFO - 2020-01-31 08:03:24 --> Helper loaded: form_helper
INFO - 2020-01-31 08:03:24 --> Helper loaded: my_helper
INFO - 2020-01-31 08:03:24 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:03:24 --> Controller Class Initialized
DEBUG - 2020-01-31 08:03:24 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-31 08:03:24 --> Final output sent to browser
DEBUG - 2020-01-31 08:03:24 --> Total execution time: 0.3480
INFO - 2020-01-31 08:03:45 --> Config Class Initialized
INFO - 2020-01-31 08:03:45 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:03:45 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:03:45 --> Utf8 Class Initialized
INFO - 2020-01-31 08:03:45 --> URI Class Initialized
INFO - 2020-01-31 08:03:45 --> Router Class Initialized
INFO - 2020-01-31 08:03:45 --> Output Class Initialized
INFO - 2020-01-31 08:03:45 --> Security Class Initialized
DEBUG - 2020-01-31 08:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:03:45 --> Input Class Initialized
INFO - 2020-01-31 08:03:45 --> Language Class Initialized
INFO - 2020-01-31 08:03:45 --> Language Class Initialized
INFO - 2020-01-31 08:03:45 --> Config Class Initialized
INFO - 2020-01-31 08:03:45 --> Loader Class Initialized
INFO - 2020-01-31 08:03:45 --> Helper loaded: url_helper
INFO - 2020-01-31 08:03:45 --> Helper loaded: file_helper
INFO - 2020-01-31 08:03:46 --> Helper loaded: form_helper
INFO - 2020-01-31 08:03:46 --> Helper loaded: my_helper
INFO - 2020-01-31 08:03:46 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:03:46 --> Controller Class Initialized
DEBUG - 2020-01-31 08:03:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:03:46 --> Final output sent to browser
DEBUG - 2020-01-31 08:03:46 --> Total execution time: 0.3796
INFO - 2020-01-31 08:03:47 --> Config Class Initialized
INFO - 2020-01-31 08:03:47 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:03:47 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:03:47 --> Utf8 Class Initialized
INFO - 2020-01-31 08:03:47 --> URI Class Initialized
INFO - 2020-01-31 08:03:47 --> Router Class Initialized
INFO - 2020-01-31 08:03:47 --> Output Class Initialized
INFO - 2020-01-31 08:03:47 --> Security Class Initialized
DEBUG - 2020-01-31 08:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:03:47 --> Input Class Initialized
INFO - 2020-01-31 08:03:47 --> Language Class Initialized
INFO - 2020-01-31 08:03:47 --> Language Class Initialized
INFO - 2020-01-31 08:03:47 --> Config Class Initialized
INFO - 2020-01-31 08:03:47 --> Loader Class Initialized
INFO - 2020-01-31 08:03:47 --> Helper loaded: url_helper
INFO - 2020-01-31 08:03:47 --> Helper loaded: file_helper
INFO - 2020-01-31 08:03:47 --> Helper loaded: form_helper
INFO - 2020-01-31 08:03:47 --> Helper loaded: my_helper
INFO - 2020-01-31 08:03:47 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:03:47 --> Controller Class Initialized
DEBUG - 2020-01-31 08:03:47 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-01-31 08:03:47 --> Final output sent to browser
DEBUG - 2020-01-31 08:03:47 --> Total execution time: 0.3521
INFO - 2020-01-31 08:04:26 --> Config Class Initialized
INFO - 2020-01-31 08:04:26 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:04:26 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:04:26 --> Utf8 Class Initialized
INFO - 2020-01-31 08:04:26 --> URI Class Initialized
INFO - 2020-01-31 08:04:26 --> Router Class Initialized
INFO - 2020-01-31 08:04:26 --> Output Class Initialized
INFO - 2020-01-31 08:04:26 --> Security Class Initialized
DEBUG - 2020-01-31 08:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:04:26 --> Input Class Initialized
INFO - 2020-01-31 08:04:26 --> Language Class Initialized
INFO - 2020-01-31 08:04:26 --> Language Class Initialized
INFO - 2020-01-31 08:04:26 --> Config Class Initialized
INFO - 2020-01-31 08:04:26 --> Loader Class Initialized
INFO - 2020-01-31 08:04:26 --> Helper loaded: url_helper
INFO - 2020-01-31 08:04:26 --> Helper loaded: file_helper
INFO - 2020-01-31 08:04:26 --> Helper loaded: form_helper
INFO - 2020-01-31 08:04:26 --> Helper loaded: my_helper
INFO - 2020-01-31 08:04:26 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:04:26 --> Controller Class Initialized
DEBUG - 2020-01-31 08:04:26 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:04:26 --> Final output sent to browser
DEBUG - 2020-01-31 08:04:26 --> Total execution time: 0.3386
INFO - 2020-01-31 08:04:41 --> Config Class Initialized
INFO - 2020-01-31 08:04:41 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:04:41 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:04:41 --> Utf8 Class Initialized
INFO - 2020-01-31 08:04:41 --> URI Class Initialized
INFO - 2020-01-31 08:04:41 --> Router Class Initialized
INFO - 2020-01-31 08:04:41 --> Output Class Initialized
INFO - 2020-01-31 08:04:41 --> Security Class Initialized
DEBUG - 2020-01-31 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:04:41 --> Input Class Initialized
INFO - 2020-01-31 08:04:41 --> Language Class Initialized
INFO - 2020-01-31 08:04:41 --> Language Class Initialized
INFO - 2020-01-31 08:04:41 --> Config Class Initialized
INFO - 2020-01-31 08:04:41 --> Loader Class Initialized
INFO - 2020-01-31 08:04:41 --> Helper loaded: url_helper
INFO - 2020-01-31 08:04:41 --> Helper loaded: file_helper
INFO - 2020-01-31 08:04:41 --> Helper loaded: form_helper
INFO - 2020-01-31 08:04:41 --> Helper loaded: my_helper
INFO - 2020-01-31 08:04:41 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:04:41 --> Controller Class Initialized
DEBUG - 2020-01-31 08:04:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:04:41 --> Final output sent to browser
DEBUG - 2020-01-31 08:04:41 --> Total execution time: 0.3586
INFO - 2020-01-31 08:04:48 --> Config Class Initialized
INFO - 2020-01-31 08:04:48 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:04:48 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:04:48 --> Utf8 Class Initialized
INFO - 2020-01-31 08:04:48 --> URI Class Initialized
INFO - 2020-01-31 08:04:48 --> Router Class Initialized
INFO - 2020-01-31 08:04:48 --> Output Class Initialized
INFO - 2020-01-31 08:04:48 --> Security Class Initialized
DEBUG - 2020-01-31 08:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:04:48 --> Input Class Initialized
INFO - 2020-01-31 08:04:48 --> Language Class Initialized
INFO - 2020-01-31 08:04:48 --> Language Class Initialized
INFO - 2020-01-31 08:04:48 --> Config Class Initialized
INFO - 2020-01-31 08:04:48 --> Loader Class Initialized
INFO - 2020-01-31 08:04:48 --> Helper loaded: url_helper
INFO - 2020-01-31 08:04:48 --> Helper loaded: file_helper
INFO - 2020-01-31 08:04:48 --> Helper loaded: form_helper
INFO - 2020-01-31 08:04:48 --> Helper loaded: my_helper
INFO - 2020-01-31 08:04:48 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:04:48 --> Controller Class Initialized
DEBUG - 2020-01-31 08:04:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:04:48 --> Final output sent to browser
DEBUG - 2020-01-31 08:04:48 --> Total execution time: 0.3457
INFO - 2020-01-31 08:05:29 --> Config Class Initialized
INFO - 2020-01-31 08:05:29 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:05:29 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:05:29 --> Utf8 Class Initialized
INFO - 2020-01-31 08:05:29 --> URI Class Initialized
INFO - 2020-01-31 08:05:29 --> Router Class Initialized
INFO - 2020-01-31 08:05:29 --> Output Class Initialized
INFO - 2020-01-31 08:05:29 --> Security Class Initialized
DEBUG - 2020-01-31 08:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:05:29 --> Input Class Initialized
INFO - 2020-01-31 08:05:29 --> Language Class Initialized
INFO - 2020-01-31 08:05:29 --> Language Class Initialized
INFO - 2020-01-31 08:05:29 --> Config Class Initialized
INFO - 2020-01-31 08:05:29 --> Loader Class Initialized
INFO - 2020-01-31 08:05:29 --> Helper loaded: url_helper
INFO - 2020-01-31 08:05:29 --> Helper loaded: file_helper
INFO - 2020-01-31 08:05:29 --> Helper loaded: form_helper
INFO - 2020-01-31 08:05:29 --> Helper loaded: my_helper
INFO - 2020-01-31 08:05:29 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:05:29 --> Controller Class Initialized
DEBUG - 2020-01-31 08:05:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:05:29 --> Final output sent to browser
DEBUG - 2020-01-31 08:05:29 --> Total execution time: 0.3774
INFO - 2020-01-31 08:06:38 --> Config Class Initialized
INFO - 2020-01-31 08:06:38 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:06:38 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:06:38 --> Utf8 Class Initialized
INFO - 2020-01-31 08:06:38 --> URI Class Initialized
INFO - 2020-01-31 08:06:38 --> Router Class Initialized
INFO - 2020-01-31 08:06:38 --> Output Class Initialized
INFO - 2020-01-31 08:06:38 --> Security Class Initialized
DEBUG - 2020-01-31 08:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:06:38 --> Input Class Initialized
INFO - 2020-01-31 08:06:38 --> Language Class Initialized
INFO - 2020-01-31 08:06:38 --> Language Class Initialized
INFO - 2020-01-31 08:06:38 --> Config Class Initialized
INFO - 2020-01-31 08:06:38 --> Loader Class Initialized
INFO - 2020-01-31 08:06:38 --> Helper loaded: url_helper
INFO - 2020-01-31 08:06:38 --> Helper loaded: file_helper
INFO - 2020-01-31 08:06:38 --> Helper loaded: form_helper
INFO - 2020-01-31 08:06:38 --> Helper loaded: my_helper
INFO - 2020-01-31 08:06:38 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:06:38 --> Controller Class Initialized
DEBUG - 2020-01-31 08:06:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:06:38 --> Final output sent to browser
DEBUG - 2020-01-31 08:06:38 --> Total execution time: 0.3578
INFO - 2020-01-31 08:06:53 --> Config Class Initialized
INFO - 2020-01-31 08:06:53 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:06:53 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:06:53 --> Utf8 Class Initialized
INFO - 2020-01-31 08:06:53 --> URI Class Initialized
INFO - 2020-01-31 08:06:53 --> Router Class Initialized
INFO - 2020-01-31 08:06:53 --> Output Class Initialized
INFO - 2020-01-31 08:06:53 --> Security Class Initialized
DEBUG - 2020-01-31 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:06:53 --> Input Class Initialized
INFO - 2020-01-31 08:06:53 --> Language Class Initialized
INFO - 2020-01-31 08:06:53 --> Language Class Initialized
INFO - 2020-01-31 08:06:53 --> Config Class Initialized
INFO - 2020-01-31 08:06:53 --> Loader Class Initialized
INFO - 2020-01-31 08:06:53 --> Helper loaded: url_helper
INFO - 2020-01-31 08:06:53 --> Helper loaded: file_helper
INFO - 2020-01-31 08:06:53 --> Helper loaded: form_helper
INFO - 2020-01-31 08:06:53 --> Helper loaded: my_helper
INFO - 2020-01-31 08:06:53 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:06:53 --> Controller Class Initialized
DEBUG - 2020-01-31 08:06:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:06:53 --> Final output sent to browser
DEBUG - 2020-01-31 08:06:53 --> Total execution time: 0.3571
INFO - 2020-01-31 08:07:14 --> Config Class Initialized
INFO - 2020-01-31 08:07:14 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:07:14 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:07:14 --> Utf8 Class Initialized
INFO - 2020-01-31 08:07:14 --> URI Class Initialized
INFO - 2020-01-31 08:07:14 --> Router Class Initialized
INFO - 2020-01-31 08:07:14 --> Output Class Initialized
INFO - 2020-01-31 08:07:14 --> Security Class Initialized
DEBUG - 2020-01-31 08:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:07:14 --> Input Class Initialized
INFO - 2020-01-31 08:07:14 --> Language Class Initialized
INFO - 2020-01-31 08:07:14 --> Language Class Initialized
INFO - 2020-01-31 08:07:14 --> Config Class Initialized
INFO - 2020-01-31 08:07:14 --> Loader Class Initialized
INFO - 2020-01-31 08:07:14 --> Helper loaded: url_helper
INFO - 2020-01-31 08:07:14 --> Helper loaded: file_helper
INFO - 2020-01-31 08:07:14 --> Helper loaded: form_helper
INFO - 2020-01-31 08:07:14 --> Helper loaded: my_helper
INFO - 2020-01-31 08:07:14 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:07:14 --> Controller Class Initialized
DEBUG - 2020-01-31 08:07:14 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:07:14 --> Final output sent to browser
DEBUG - 2020-01-31 08:07:14 --> Total execution time: 0.3837
INFO - 2020-01-31 08:07:37 --> Config Class Initialized
INFO - 2020-01-31 08:07:37 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:07:37 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:07:37 --> Utf8 Class Initialized
INFO - 2020-01-31 08:07:37 --> URI Class Initialized
INFO - 2020-01-31 08:07:37 --> Router Class Initialized
INFO - 2020-01-31 08:07:37 --> Output Class Initialized
INFO - 2020-01-31 08:07:37 --> Security Class Initialized
DEBUG - 2020-01-31 08:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:07:37 --> Input Class Initialized
INFO - 2020-01-31 08:07:37 --> Language Class Initialized
INFO - 2020-01-31 08:07:37 --> Language Class Initialized
INFO - 2020-01-31 08:07:37 --> Config Class Initialized
INFO - 2020-01-31 08:07:37 --> Loader Class Initialized
INFO - 2020-01-31 08:07:37 --> Helper loaded: url_helper
INFO - 2020-01-31 08:07:37 --> Helper loaded: file_helper
INFO - 2020-01-31 08:07:37 --> Helper loaded: form_helper
INFO - 2020-01-31 08:07:37 --> Helper loaded: my_helper
INFO - 2020-01-31 08:07:37 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:07:37 --> Controller Class Initialized
DEBUG - 2020-01-31 08:07:37 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:07:37 --> Final output sent to browser
DEBUG - 2020-01-31 08:07:37 --> Total execution time: 0.3709
INFO - 2020-01-31 08:07:57 --> Config Class Initialized
INFO - 2020-01-31 08:07:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:07:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:07:57 --> Utf8 Class Initialized
INFO - 2020-01-31 08:07:57 --> URI Class Initialized
INFO - 2020-01-31 08:07:57 --> Router Class Initialized
INFO - 2020-01-31 08:07:57 --> Output Class Initialized
INFO - 2020-01-31 08:07:57 --> Security Class Initialized
DEBUG - 2020-01-31 08:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:07:57 --> Input Class Initialized
INFO - 2020-01-31 08:07:57 --> Language Class Initialized
INFO - 2020-01-31 08:07:57 --> Language Class Initialized
INFO - 2020-01-31 08:07:57 --> Config Class Initialized
INFO - 2020-01-31 08:07:57 --> Loader Class Initialized
INFO - 2020-01-31 08:07:57 --> Helper loaded: url_helper
INFO - 2020-01-31 08:07:57 --> Helper loaded: file_helper
INFO - 2020-01-31 08:07:57 --> Helper loaded: form_helper
INFO - 2020-01-31 08:07:57 --> Helper loaded: my_helper
INFO - 2020-01-31 08:07:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:07:57 --> Controller Class Initialized
DEBUG - 2020-01-31 08:07:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:07:57 --> Final output sent to browser
DEBUG - 2020-01-31 08:07:57 --> Total execution time: 0.3526
INFO - 2020-01-31 08:08:39 --> Config Class Initialized
INFO - 2020-01-31 08:08:39 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:08:39 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:08:39 --> Utf8 Class Initialized
INFO - 2020-01-31 08:08:39 --> URI Class Initialized
INFO - 2020-01-31 08:08:39 --> Router Class Initialized
INFO - 2020-01-31 08:08:39 --> Output Class Initialized
INFO - 2020-01-31 08:08:39 --> Security Class Initialized
DEBUG - 2020-01-31 08:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:08:39 --> Input Class Initialized
INFO - 2020-01-31 08:08:39 --> Language Class Initialized
INFO - 2020-01-31 08:08:39 --> Language Class Initialized
INFO - 2020-01-31 08:08:39 --> Config Class Initialized
INFO - 2020-01-31 08:08:39 --> Loader Class Initialized
INFO - 2020-01-31 08:08:39 --> Helper loaded: url_helper
INFO - 2020-01-31 08:08:39 --> Helper loaded: file_helper
INFO - 2020-01-31 08:08:39 --> Helper loaded: form_helper
INFO - 2020-01-31 08:08:39 --> Helper loaded: my_helper
INFO - 2020-01-31 08:08:39 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:08:39 --> Controller Class Initialized
DEBUG - 2020-01-31 08:08:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:08:39 --> Final output sent to browser
DEBUG - 2020-01-31 08:08:39 --> Total execution time: 0.3680
INFO - 2020-01-31 08:09:05 --> Config Class Initialized
INFO - 2020-01-31 08:09:05 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:09:05 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:09:05 --> Utf8 Class Initialized
INFO - 2020-01-31 08:09:05 --> URI Class Initialized
INFO - 2020-01-31 08:09:05 --> Router Class Initialized
INFO - 2020-01-31 08:09:05 --> Output Class Initialized
INFO - 2020-01-31 08:09:05 --> Security Class Initialized
DEBUG - 2020-01-31 08:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:09:05 --> Input Class Initialized
INFO - 2020-01-31 08:09:05 --> Language Class Initialized
INFO - 2020-01-31 08:09:05 --> Language Class Initialized
INFO - 2020-01-31 08:09:05 --> Config Class Initialized
INFO - 2020-01-31 08:09:05 --> Loader Class Initialized
INFO - 2020-01-31 08:09:05 --> Helper loaded: url_helper
INFO - 2020-01-31 08:09:05 --> Helper loaded: file_helper
INFO - 2020-01-31 08:09:05 --> Helper loaded: form_helper
INFO - 2020-01-31 08:09:05 --> Helper loaded: my_helper
INFO - 2020-01-31 08:09:05 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:09:05 --> Controller Class Initialized
DEBUG - 2020-01-31 08:09:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:09:05 --> Final output sent to browser
DEBUG - 2020-01-31 08:09:05 --> Total execution time: 0.3757
INFO - 2020-01-31 08:09:21 --> Config Class Initialized
INFO - 2020-01-31 08:09:21 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:09:21 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:09:21 --> Utf8 Class Initialized
INFO - 2020-01-31 08:09:21 --> URI Class Initialized
INFO - 2020-01-31 08:09:21 --> Router Class Initialized
INFO - 2020-01-31 08:09:21 --> Output Class Initialized
INFO - 2020-01-31 08:09:21 --> Security Class Initialized
DEBUG - 2020-01-31 08:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:09:21 --> Input Class Initialized
INFO - 2020-01-31 08:09:21 --> Language Class Initialized
INFO - 2020-01-31 08:09:21 --> Language Class Initialized
INFO - 2020-01-31 08:09:21 --> Config Class Initialized
INFO - 2020-01-31 08:09:21 --> Loader Class Initialized
INFO - 2020-01-31 08:09:21 --> Helper loaded: url_helper
INFO - 2020-01-31 08:09:21 --> Helper loaded: file_helper
INFO - 2020-01-31 08:09:21 --> Helper loaded: form_helper
INFO - 2020-01-31 08:09:21 --> Helper loaded: my_helper
INFO - 2020-01-31 08:09:21 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:09:21 --> Controller Class Initialized
DEBUG - 2020-01-31 08:09:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:09:21 --> Final output sent to browser
DEBUG - 2020-01-31 08:09:21 --> Total execution time: 0.3781
INFO - 2020-01-31 08:09:29 --> Config Class Initialized
INFO - 2020-01-31 08:09:29 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:09:29 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:09:29 --> Utf8 Class Initialized
INFO - 2020-01-31 08:09:29 --> URI Class Initialized
INFO - 2020-01-31 08:09:29 --> Router Class Initialized
INFO - 2020-01-31 08:09:29 --> Output Class Initialized
INFO - 2020-01-31 08:09:29 --> Security Class Initialized
DEBUG - 2020-01-31 08:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:09:29 --> Input Class Initialized
INFO - 2020-01-31 08:09:29 --> Language Class Initialized
INFO - 2020-01-31 08:09:29 --> Language Class Initialized
INFO - 2020-01-31 08:09:29 --> Config Class Initialized
INFO - 2020-01-31 08:09:29 --> Loader Class Initialized
INFO - 2020-01-31 08:09:29 --> Helper loaded: url_helper
INFO - 2020-01-31 08:09:29 --> Helper loaded: file_helper
INFO - 2020-01-31 08:09:29 --> Helper loaded: form_helper
INFO - 2020-01-31 08:09:29 --> Helper loaded: my_helper
INFO - 2020-01-31 08:09:29 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:09:29 --> Controller Class Initialized
DEBUG - 2020-01-31 08:09:29 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:09:29 --> Final output sent to browser
DEBUG - 2020-01-31 08:09:29 --> Total execution time: 0.3620
INFO - 2020-01-31 08:10:13 --> Config Class Initialized
INFO - 2020-01-31 08:10:13 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:10:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:10:13 --> Utf8 Class Initialized
INFO - 2020-01-31 08:10:13 --> URI Class Initialized
INFO - 2020-01-31 08:10:13 --> Router Class Initialized
INFO - 2020-01-31 08:10:13 --> Output Class Initialized
INFO - 2020-01-31 08:10:13 --> Security Class Initialized
DEBUG - 2020-01-31 08:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:10:13 --> Input Class Initialized
INFO - 2020-01-31 08:10:13 --> Language Class Initialized
INFO - 2020-01-31 08:10:13 --> Language Class Initialized
INFO - 2020-01-31 08:10:13 --> Config Class Initialized
INFO - 2020-01-31 08:10:13 --> Loader Class Initialized
INFO - 2020-01-31 08:10:13 --> Helper loaded: url_helper
INFO - 2020-01-31 08:10:13 --> Helper loaded: file_helper
INFO - 2020-01-31 08:10:13 --> Helper loaded: form_helper
INFO - 2020-01-31 08:10:13 --> Helper loaded: my_helper
INFO - 2020-01-31 08:10:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:10:13 --> Controller Class Initialized
DEBUG - 2020-01-31 08:10:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:10:13 --> Final output sent to browser
DEBUG - 2020-01-31 08:10:13 --> Total execution time: 0.3568
INFO - 2020-01-31 08:10:38 --> Config Class Initialized
INFO - 2020-01-31 08:10:38 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:10:38 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:10:38 --> Utf8 Class Initialized
INFO - 2020-01-31 08:10:38 --> URI Class Initialized
INFO - 2020-01-31 08:10:38 --> Router Class Initialized
INFO - 2020-01-31 08:10:38 --> Output Class Initialized
INFO - 2020-01-31 08:10:38 --> Security Class Initialized
DEBUG - 2020-01-31 08:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:10:38 --> Input Class Initialized
INFO - 2020-01-31 08:10:38 --> Language Class Initialized
INFO - 2020-01-31 08:10:38 --> Language Class Initialized
INFO - 2020-01-31 08:10:38 --> Config Class Initialized
INFO - 2020-01-31 08:10:38 --> Loader Class Initialized
INFO - 2020-01-31 08:10:38 --> Helper loaded: url_helper
INFO - 2020-01-31 08:10:38 --> Helper loaded: file_helper
INFO - 2020-01-31 08:10:38 --> Helper loaded: form_helper
INFO - 2020-01-31 08:10:38 --> Helper loaded: my_helper
INFO - 2020-01-31 08:10:38 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:10:38 --> Controller Class Initialized
DEBUG - 2020-01-31 08:10:38 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:10:38 --> Final output sent to browser
DEBUG - 2020-01-31 08:10:38 --> Total execution time: 0.4024
INFO - 2020-01-31 08:10:55 --> Config Class Initialized
INFO - 2020-01-31 08:10:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:10:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:10:56 --> Utf8 Class Initialized
INFO - 2020-01-31 08:10:56 --> URI Class Initialized
INFO - 2020-01-31 08:10:56 --> Router Class Initialized
INFO - 2020-01-31 08:10:56 --> Output Class Initialized
INFO - 2020-01-31 08:10:56 --> Security Class Initialized
DEBUG - 2020-01-31 08:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:10:56 --> Input Class Initialized
INFO - 2020-01-31 08:10:56 --> Language Class Initialized
INFO - 2020-01-31 08:10:56 --> Language Class Initialized
INFO - 2020-01-31 08:10:56 --> Config Class Initialized
INFO - 2020-01-31 08:10:56 --> Loader Class Initialized
INFO - 2020-01-31 08:10:56 --> Helper loaded: url_helper
INFO - 2020-01-31 08:10:56 --> Helper loaded: file_helper
INFO - 2020-01-31 08:10:56 --> Helper loaded: form_helper
INFO - 2020-01-31 08:10:56 --> Helper loaded: my_helper
INFO - 2020-01-31 08:10:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:10:56 --> Controller Class Initialized
DEBUG - 2020-01-31 08:10:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:10:56 --> Final output sent to browser
DEBUG - 2020-01-31 08:10:56 --> Total execution time: 0.3973
INFO - 2020-01-31 08:11:01 --> Config Class Initialized
INFO - 2020-01-31 08:11:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:11:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:11:01 --> Utf8 Class Initialized
INFO - 2020-01-31 08:11:01 --> URI Class Initialized
INFO - 2020-01-31 08:11:01 --> Router Class Initialized
INFO - 2020-01-31 08:11:01 --> Output Class Initialized
INFO - 2020-01-31 08:11:01 --> Security Class Initialized
DEBUG - 2020-01-31 08:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:11:01 --> Input Class Initialized
INFO - 2020-01-31 08:11:01 --> Language Class Initialized
INFO - 2020-01-31 08:11:01 --> Language Class Initialized
INFO - 2020-01-31 08:11:01 --> Config Class Initialized
INFO - 2020-01-31 08:11:01 --> Loader Class Initialized
INFO - 2020-01-31 08:11:01 --> Helper loaded: url_helper
INFO - 2020-01-31 08:11:01 --> Helper loaded: file_helper
INFO - 2020-01-31 08:11:01 --> Helper loaded: form_helper
INFO - 2020-01-31 08:11:01 --> Helper loaded: my_helper
INFO - 2020-01-31 08:11:01 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:11:01 --> Controller Class Initialized
DEBUG - 2020-01-31 08:11:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:11:02 --> Final output sent to browser
DEBUG - 2020-01-31 08:11:02 --> Total execution time: 0.4278
INFO - 2020-01-31 08:11:30 --> Config Class Initialized
INFO - 2020-01-31 08:11:30 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:11:30 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:11:30 --> Utf8 Class Initialized
INFO - 2020-01-31 08:11:30 --> URI Class Initialized
INFO - 2020-01-31 08:11:30 --> Router Class Initialized
INFO - 2020-01-31 08:11:30 --> Output Class Initialized
INFO - 2020-01-31 08:11:30 --> Security Class Initialized
DEBUG - 2020-01-31 08:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:11:30 --> Input Class Initialized
INFO - 2020-01-31 08:11:30 --> Language Class Initialized
INFO - 2020-01-31 08:11:30 --> Language Class Initialized
INFO - 2020-01-31 08:11:30 --> Config Class Initialized
INFO - 2020-01-31 08:11:30 --> Loader Class Initialized
INFO - 2020-01-31 08:11:30 --> Helper loaded: url_helper
INFO - 2020-01-31 08:11:30 --> Helper loaded: file_helper
INFO - 2020-01-31 08:11:30 --> Helper loaded: form_helper
INFO - 2020-01-31 08:11:30 --> Helper loaded: my_helper
INFO - 2020-01-31 08:11:30 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:11:30 --> Controller Class Initialized
DEBUG - 2020-01-31 08:11:30 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:11:30 --> Final output sent to browser
DEBUG - 2020-01-31 08:11:30 --> Total execution time: 0.3623
INFO - 2020-01-31 08:11:48 --> Config Class Initialized
INFO - 2020-01-31 08:11:48 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:11:48 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:11:48 --> Utf8 Class Initialized
INFO - 2020-01-31 08:11:48 --> URI Class Initialized
INFO - 2020-01-31 08:11:48 --> Router Class Initialized
INFO - 2020-01-31 08:11:48 --> Output Class Initialized
INFO - 2020-01-31 08:11:48 --> Security Class Initialized
DEBUG - 2020-01-31 08:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:11:48 --> Input Class Initialized
INFO - 2020-01-31 08:11:48 --> Language Class Initialized
INFO - 2020-01-31 08:11:48 --> Language Class Initialized
INFO - 2020-01-31 08:11:48 --> Config Class Initialized
INFO - 2020-01-31 08:11:48 --> Loader Class Initialized
INFO - 2020-01-31 08:11:48 --> Helper loaded: url_helper
INFO - 2020-01-31 08:11:48 --> Helper loaded: file_helper
INFO - 2020-01-31 08:11:48 --> Helper loaded: form_helper
INFO - 2020-01-31 08:11:48 --> Helper loaded: my_helper
INFO - 2020-01-31 08:11:48 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:11:48 --> Controller Class Initialized
DEBUG - 2020-01-31 08:11:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:11:48 --> Final output sent to browser
DEBUG - 2020-01-31 08:11:48 --> Total execution time: 0.3710
INFO - 2020-01-31 08:14:27 --> Config Class Initialized
INFO - 2020-01-31 08:14:27 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:14:27 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:14:27 --> Utf8 Class Initialized
INFO - 2020-01-31 08:14:27 --> URI Class Initialized
INFO - 2020-01-31 08:14:27 --> Router Class Initialized
INFO - 2020-01-31 08:14:27 --> Output Class Initialized
INFO - 2020-01-31 08:14:27 --> Security Class Initialized
DEBUG - 2020-01-31 08:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:14:27 --> Input Class Initialized
INFO - 2020-01-31 08:14:27 --> Language Class Initialized
INFO - 2020-01-31 08:14:27 --> Language Class Initialized
INFO - 2020-01-31 08:14:27 --> Config Class Initialized
INFO - 2020-01-31 08:14:27 --> Loader Class Initialized
INFO - 2020-01-31 08:14:27 --> Helper loaded: url_helper
INFO - 2020-01-31 08:14:27 --> Helper loaded: file_helper
INFO - 2020-01-31 08:14:27 --> Helper loaded: form_helper
INFO - 2020-01-31 08:14:27 --> Helper loaded: my_helper
INFO - 2020-01-31 08:14:27 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:14:27 --> Controller Class Initialized
ERROR - 2020-01-31 08:14:27 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 188
DEBUG - 2020-01-31 08:14:27 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:14:27 --> Final output sent to browser
DEBUG - 2020-01-31 08:14:27 --> Total execution time: 0.3694
INFO - 2020-01-31 08:22:54 --> Config Class Initialized
INFO - 2020-01-31 08:22:54 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:22:54 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:22:54 --> Utf8 Class Initialized
INFO - 2020-01-31 08:22:54 --> URI Class Initialized
INFO - 2020-01-31 08:22:54 --> Router Class Initialized
INFO - 2020-01-31 08:22:54 --> Output Class Initialized
INFO - 2020-01-31 08:22:54 --> Security Class Initialized
DEBUG - 2020-01-31 08:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:22:54 --> Input Class Initialized
INFO - 2020-01-31 08:22:54 --> Language Class Initialized
INFO - 2020-01-31 08:22:55 --> Language Class Initialized
INFO - 2020-01-31 08:22:55 --> Config Class Initialized
INFO - 2020-01-31 08:22:55 --> Loader Class Initialized
INFO - 2020-01-31 08:22:55 --> Helper loaded: url_helper
INFO - 2020-01-31 08:22:55 --> Helper loaded: file_helper
INFO - 2020-01-31 08:22:55 --> Helper loaded: form_helper
INFO - 2020-01-31 08:22:55 --> Helper loaded: my_helper
INFO - 2020-01-31 08:22:55 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:22:55 --> Controller Class Initialized
ERROR - 2020-01-31 08:22:55 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 184
DEBUG - 2020-01-31 08:22:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:22:55 --> Final output sent to browser
DEBUG - 2020-01-31 08:22:55 --> Total execution time: 0.4299
INFO - 2020-01-31 08:23:53 --> Config Class Initialized
INFO - 2020-01-31 08:23:53 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:23:53 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:23:53 --> Utf8 Class Initialized
INFO - 2020-01-31 08:23:53 --> URI Class Initialized
INFO - 2020-01-31 08:23:53 --> Router Class Initialized
INFO - 2020-01-31 08:23:53 --> Output Class Initialized
INFO - 2020-01-31 08:23:53 --> Security Class Initialized
DEBUG - 2020-01-31 08:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:23:53 --> Input Class Initialized
INFO - 2020-01-31 08:23:53 --> Language Class Initialized
INFO - 2020-01-31 08:23:53 --> Language Class Initialized
INFO - 2020-01-31 08:23:54 --> Config Class Initialized
INFO - 2020-01-31 08:23:54 --> Loader Class Initialized
INFO - 2020-01-31 08:23:54 --> Helper loaded: url_helper
INFO - 2020-01-31 08:23:54 --> Helper loaded: file_helper
INFO - 2020-01-31 08:23:54 --> Helper loaded: form_helper
INFO - 2020-01-31 08:23:54 --> Helper loaded: my_helper
INFO - 2020-01-31 08:23:54 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:23:54 --> Controller Class Initialized
ERROR - 2020-01-31 08:23:54 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 184
DEBUG - 2020-01-31 08:23:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:23:54 --> Final output sent to browser
DEBUG - 2020-01-31 08:23:54 --> Total execution time: 0.3700
INFO - 2020-01-31 08:26:35 --> Config Class Initialized
INFO - 2020-01-31 08:26:35 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:26:35 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:26:35 --> Utf8 Class Initialized
INFO - 2020-01-31 08:26:35 --> URI Class Initialized
INFO - 2020-01-31 08:26:35 --> Router Class Initialized
INFO - 2020-01-31 08:26:35 --> Output Class Initialized
INFO - 2020-01-31 08:26:35 --> Security Class Initialized
DEBUG - 2020-01-31 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:26:35 --> Input Class Initialized
INFO - 2020-01-31 08:26:35 --> Language Class Initialized
INFO - 2020-01-31 08:26:35 --> Language Class Initialized
INFO - 2020-01-31 08:26:35 --> Config Class Initialized
INFO - 2020-01-31 08:26:35 --> Loader Class Initialized
INFO - 2020-01-31 08:26:35 --> Helper loaded: url_helper
INFO - 2020-01-31 08:26:35 --> Helper loaded: file_helper
INFO - 2020-01-31 08:26:35 --> Helper loaded: form_helper
INFO - 2020-01-31 08:26:35 --> Helper loaded: my_helper
INFO - 2020-01-31 08:26:35 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:26:35 --> Controller Class Initialized
ERROR - 2020-01-31 08:26:35 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
ERROR - 2020-01-31 08:26:35 --> Severity: Notice --> Undefined variable: nilai_keterampilan E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 204
ERROR - 2020-01-31 08:26:35 --> Severity: Notice --> Undefined variable: nilai_keterampilan E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 204
ERROR - 2020-01-31 08:26:35 --> Severity: Notice --> Undefined variable: nilai_keterampilan E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 204
DEBUG - 2020-01-31 08:26:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:26:35 --> Final output sent to browser
DEBUG - 2020-01-31 08:26:35 --> Total execution time: 0.3971
INFO - 2020-01-31 08:27:33 --> Config Class Initialized
INFO - 2020-01-31 08:27:33 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:27:33 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:27:33 --> Utf8 Class Initialized
INFO - 2020-01-31 08:27:33 --> URI Class Initialized
INFO - 2020-01-31 08:27:33 --> Router Class Initialized
INFO - 2020-01-31 08:27:33 --> Output Class Initialized
INFO - 2020-01-31 08:27:33 --> Security Class Initialized
DEBUG - 2020-01-31 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:27:33 --> Input Class Initialized
INFO - 2020-01-31 08:27:33 --> Language Class Initialized
INFO - 2020-01-31 08:27:33 --> Language Class Initialized
INFO - 2020-01-31 08:27:33 --> Config Class Initialized
INFO - 2020-01-31 08:27:33 --> Loader Class Initialized
INFO - 2020-01-31 08:27:33 --> Helper loaded: url_helper
INFO - 2020-01-31 08:27:33 --> Helper loaded: file_helper
INFO - 2020-01-31 08:27:33 --> Helper loaded: form_helper
INFO - 2020-01-31 08:27:33 --> Helper loaded: my_helper
INFO - 2020-01-31 08:27:33 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:27:33 --> Controller Class Initialized
ERROR - 2020-01-31 08:27:33 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:27:33 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:27:33 --> Final output sent to browser
DEBUG - 2020-01-31 08:27:33 --> Total execution time: 0.3729
INFO - 2020-01-31 08:28:43 --> Config Class Initialized
INFO - 2020-01-31 08:28:43 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:28:43 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:28:43 --> Utf8 Class Initialized
INFO - 2020-01-31 08:28:43 --> URI Class Initialized
INFO - 2020-01-31 08:28:43 --> Router Class Initialized
INFO - 2020-01-31 08:28:43 --> Output Class Initialized
INFO - 2020-01-31 08:28:43 --> Security Class Initialized
DEBUG - 2020-01-31 08:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:28:43 --> Input Class Initialized
INFO - 2020-01-31 08:28:43 --> Language Class Initialized
INFO - 2020-01-31 08:28:43 --> Language Class Initialized
INFO - 2020-01-31 08:28:43 --> Config Class Initialized
INFO - 2020-01-31 08:28:43 --> Loader Class Initialized
INFO - 2020-01-31 08:28:43 --> Helper loaded: url_helper
INFO - 2020-01-31 08:28:43 --> Helper loaded: file_helper
INFO - 2020-01-31 08:28:43 --> Helper loaded: form_helper
INFO - 2020-01-31 08:28:43 --> Helper loaded: my_helper
INFO - 2020-01-31 08:28:43 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:28:43 --> Controller Class Initialized
ERROR - 2020-01-31 08:28:43 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:28:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:28:43 --> Final output sent to browser
DEBUG - 2020-01-31 08:28:43 --> Total execution time: 0.3778
INFO - 2020-01-31 08:30:11 --> Config Class Initialized
INFO - 2020-01-31 08:30:11 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:30:11 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:30:11 --> Utf8 Class Initialized
INFO - 2020-01-31 08:30:11 --> URI Class Initialized
INFO - 2020-01-31 08:30:11 --> Router Class Initialized
INFO - 2020-01-31 08:30:11 --> Output Class Initialized
INFO - 2020-01-31 08:30:11 --> Security Class Initialized
DEBUG - 2020-01-31 08:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:30:11 --> Input Class Initialized
INFO - 2020-01-31 08:30:11 --> Language Class Initialized
INFO - 2020-01-31 08:30:11 --> Language Class Initialized
INFO - 2020-01-31 08:30:11 --> Config Class Initialized
INFO - 2020-01-31 08:30:11 --> Loader Class Initialized
INFO - 2020-01-31 08:30:11 --> Helper loaded: url_helper
INFO - 2020-01-31 08:30:11 --> Helper loaded: file_helper
INFO - 2020-01-31 08:30:11 --> Helper loaded: form_helper
INFO - 2020-01-31 08:30:11 --> Helper loaded: my_helper
INFO - 2020-01-31 08:30:11 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:30:11 --> Controller Class Initialized
ERROR - 2020-01-31 08:30:11 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:30:11 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:30:11 --> Final output sent to browser
DEBUG - 2020-01-31 08:30:11 --> Total execution time: 0.4164
INFO - 2020-01-31 08:30:13 --> Config Class Initialized
INFO - 2020-01-31 08:30:13 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:30:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:30:13 --> Utf8 Class Initialized
INFO - 2020-01-31 08:30:13 --> URI Class Initialized
INFO - 2020-01-31 08:30:13 --> Router Class Initialized
INFO - 2020-01-31 08:30:13 --> Output Class Initialized
INFO - 2020-01-31 08:30:13 --> Security Class Initialized
DEBUG - 2020-01-31 08:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:30:13 --> Input Class Initialized
INFO - 2020-01-31 08:30:13 --> Language Class Initialized
INFO - 2020-01-31 08:30:13 --> Language Class Initialized
INFO - 2020-01-31 08:30:13 --> Config Class Initialized
INFO - 2020-01-31 08:30:13 --> Loader Class Initialized
INFO - 2020-01-31 08:30:13 --> Helper loaded: url_helper
INFO - 2020-01-31 08:30:13 --> Helper loaded: file_helper
INFO - 2020-01-31 08:30:13 --> Helper loaded: form_helper
INFO - 2020-01-31 08:30:13 --> Helper loaded: my_helper
INFO - 2020-01-31 08:30:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:30:13 --> Controller Class Initialized
ERROR - 2020-01-31 08:30:13 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:30:13 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:30:13 --> Final output sent to browser
DEBUG - 2020-01-31 08:30:13 --> Total execution time: 0.3694
INFO - 2020-01-31 08:30:35 --> Config Class Initialized
INFO - 2020-01-31 08:30:35 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:30:35 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:30:35 --> Utf8 Class Initialized
INFO - 2020-01-31 08:30:35 --> URI Class Initialized
INFO - 2020-01-31 08:30:35 --> Router Class Initialized
INFO - 2020-01-31 08:30:35 --> Output Class Initialized
INFO - 2020-01-31 08:30:35 --> Security Class Initialized
DEBUG - 2020-01-31 08:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:30:35 --> Input Class Initialized
INFO - 2020-01-31 08:30:35 --> Language Class Initialized
INFO - 2020-01-31 08:30:35 --> Language Class Initialized
INFO - 2020-01-31 08:30:35 --> Config Class Initialized
INFO - 2020-01-31 08:30:35 --> Loader Class Initialized
INFO - 2020-01-31 08:30:35 --> Helper loaded: url_helper
INFO - 2020-01-31 08:30:35 --> Helper loaded: file_helper
INFO - 2020-01-31 08:30:35 --> Helper loaded: form_helper
INFO - 2020-01-31 08:30:35 --> Helper loaded: my_helper
INFO - 2020-01-31 08:30:35 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:30:35 --> Controller Class Initialized
ERROR - 2020-01-31 08:30:35 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:30:35 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:30:35 --> Final output sent to browser
DEBUG - 2020-01-31 08:30:35 --> Total execution time: 0.3509
INFO - 2020-01-31 08:31:14 --> Config Class Initialized
INFO - 2020-01-31 08:31:15 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:31:15 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:31:15 --> Utf8 Class Initialized
INFO - 2020-01-31 08:31:15 --> URI Class Initialized
INFO - 2020-01-31 08:31:15 --> Router Class Initialized
INFO - 2020-01-31 08:31:15 --> Output Class Initialized
INFO - 2020-01-31 08:31:15 --> Security Class Initialized
DEBUG - 2020-01-31 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:31:15 --> Input Class Initialized
INFO - 2020-01-31 08:31:15 --> Language Class Initialized
INFO - 2020-01-31 08:31:15 --> Language Class Initialized
INFO - 2020-01-31 08:31:15 --> Config Class Initialized
INFO - 2020-01-31 08:31:15 --> Loader Class Initialized
INFO - 2020-01-31 08:31:15 --> Helper loaded: url_helper
INFO - 2020-01-31 08:31:15 --> Helper loaded: file_helper
INFO - 2020-01-31 08:31:15 --> Helper loaded: form_helper
INFO - 2020-01-31 08:31:15 --> Helper loaded: my_helper
INFO - 2020-01-31 08:31:15 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:31:15 --> Controller Class Initialized
ERROR - 2020-01-31 08:31:15 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:31:15 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:31:15 --> Final output sent to browser
DEBUG - 2020-01-31 08:31:15 --> Total execution time: 0.3741
INFO - 2020-01-31 08:31:39 --> Config Class Initialized
INFO - 2020-01-31 08:31:39 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:31:39 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:31:39 --> Utf8 Class Initialized
INFO - 2020-01-31 08:31:39 --> URI Class Initialized
INFO - 2020-01-31 08:31:39 --> Router Class Initialized
INFO - 2020-01-31 08:31:39 --> Output Class Initialized
INFO - 2020-01-31 08:31:39 --> Security Class Initialized
DEBUG - 2020-01-31 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:31:39 --> Input Class Initialized
INFO - 2020-01-31 08:31:39 --> Language Class Initialized
INFO - 2020-01-31 08:31:39 --> Language Class Initialized
INFO - 2020-01-31 08:31:39 --> Config Class Initialized
INFO - 2020-01-31 08:31:39 --> Loader Class Initialized
INFO - 2020-01-31 08:31:39 --> Helper loaded: url_helper
INFO - 2020-01-31 08:31:39 --> Helper loaded: file_helper
INFO - 2020-01-31 08:31:39 --> Helper loaded: form_helper
INFO - 2020-01-31 08:31:39 --> Helper loaded: my_helper
INFO - 2020-01-31 08:31:39 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:31:39 --> Controller Class Initialized
ERROR - 2020-01-31 08:31:39 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:31:39 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:31:39 --> Final output sent to browser
DEBUG - 2020-01-31 08:31:39 --> Total execution time: 0.3838
INFO - 2020-01-31 08:31:54 --> Config Class Initialized
INFO - 2020-01-31 08:31:54 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:31:54 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:31:54 --> Utf8 Class Initialized
INFO - 2020-01-31 08:31:54 --> URI Class Initialized
INFO - 2020-01-31 08:31:54 --> Router Class Initialized
INFO - 2020-01-31 08:31:54 --> Output Class Initialized
INFO - 2020-01-31 08:31:54 --> Security Class Initialized
DEBUG - 2020-01-31 08:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:31:54 --> Input Class Initialized
INFO - 2020-01-31 08:31:54 --> Language Class Initialized
INFO - 2020-01-31 08:31:54 --> Language Class Initialized
INFO - 2020-01-31 08:31:54 --> Config Class Initialized
INFO - 2020-01-31 08:31:54 --> Loader Class Initialized
INFO - 2020-01-31 08:31:54 --> Helper loaded: url_helper
INFO - 2020-01-31 08:31:54 --> Helper loaded: file_helper
INFO - 2020-01-31 08:31:54 --> Helper loaded: form_helper
INFO - 2020-01-31 08:31:54 --> Helper loaded: my_helper
INFO - 2020-01-31 08:31:54 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:31:54 --> Controller Class Initialized
ERROR - 2020-01-31 08:31:54 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:31:55 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:31:55 --> Final output sent to browser
DEBUG - 2020-01-31 08:31:55 --> Total execution time: 0.3647
INFO - 2020-01-31 08:32:08 --> Config Class Initialized
INFO - 2020-01-31 08:32:08 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:32:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:32:08 --> Utf8 Class Initialized
INFO - 2020-01-31 08:32:08 --> URI Class Initialized
INFO - 2020-01-31 08:32:08 --> Router Class Initialized
INFO - 2020-01-31 08:32:08 --> Output Class Initialized
INFO - 2020-01-31 08:32:08 --> Security Class Initialized
DEBUG - 2020-01-31 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:32:08 --> Input Class Initialized
INFO - 2020-01-31 08:32:08 --> Language Class Initialized
INFO - 2020-01-31 08:32:08 --> Language Class Initialized
INFO - 2020-01-31 08:32:08 --> Config Class Initialized
INFO - 2020-01-31 08:32:08 --> Loader Class Initialized
INFO - 2020-01-31 08:32:08 --> Helper loaded: url_helper
INFO - 2020-01-31 08:32:08 --> Helper loaded: file_helper
INFO - 2020-01-31 08:32:08 --> Helper loaded: form_helper
INFO - 2020-01-31 08:32:08 --> Helper loaded: my_helper
INFO - 2020-01-31 08:32:08 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:32:08 --> Controller Class Initialized
ERROR - 2020-01-31 08:32:08 --> Severity: Notice --> Undefined index: nilai_utama E:\xampp\htdocs\_2020\nilaik13_ci\application\modules\cetak_raport_pts\controllers\Cetak_raport_pts.php 171
DEBUG - 2020-01-31 08:32:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:32:08 --> Final output sent to browser
DEBUG - 2020-01-31 08:32:08 --> Total execution time: 0.3776
INFO - 2020-01-31 08:32:54 --> Config Class Initialized
INFO - 2020-01-31 08:32:54 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:32:54 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:32:54 --> Utf8 Class Initialized
INFO - 2020-01-31 08:32:54 --> URI Class Initialized
INFO - 2020-01-31 08:32:54 --> Router Class Initialized
INFO - 2020-01-31 08:32:54 --> Output Class Initialized
INFO - 2020-01-31 08:32:54 --> Security Class Initialized
DEBUG - 2020-01-31 08:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:32:54 --> Input Class Initialized
INFO - 2020-01-31 08:32:54 --> Language Class Initialized
INFO - 2020-01-31 08:32:54 --> Language Class Initialized
INFO - 2020-01-31 08:32:54 --> Config Class Initialized
INFO - 2020-01-31 08:32:54 --> Loader Class Initialized
INFO - 2020-01-31 08:32:54 --> Helper loaded: url_helper
INFO - 2020-01-31 08:32:54 --> Helper loaded: file_helper
INFO - 2020-01-31 08:32:54 --> Helper loaded: form_helper
INFO - 2020-01-31 08:32:54 --> Helper loaded: my_helper
INFO - 2020-01-31 08:32:54 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:32:54 --> Controller Class Initialized
DEBUG - 2020-01-31 08:32:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:32:54 --> Final output sent to browser
DEBUG - 2020-01-31 08:32:54 --> Total execution time: 0.3635
INFO - 2020-01-31 08:47:07 --> Config Class Initialized
INFO - 2020-01-31 08:47:07 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:07 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:07 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:07 --> URI Class Initialized
INFO - 2020-01-31 08:47:07 --> Router Class Initialized
INFO - 2020-01-31 08:47:07 --> Output Class Initialized
INFO - 2020-01-31 08:47:07 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:07 --> Input Class Initialized
INFO - 2020-01-31 08:47:07 --> Language Class Initialized
INFO - 2020-01-31 08:47:07 --> Language Class Initialized
INFO - 2020-01-31 08:47:07 --> Config Class Initialized
INFO - 2020-01-31 08:47:07 --> Loader Class Initialized
INFO - 2020-01-31 08:47:07 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:07 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:07 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:07 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:07 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:08 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:08 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:47:08 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:08 --> Total execution time: 0.3836
INFO - 2020-01-31 08:47:19 --> Config Class Initialized
INFO - 2020-01-31 08:47:19 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:19 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:19 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:19 --> URI Class Initialized
INFO - 2020-01-31 08:47:19 --> Router Class Initialized
INFO - 2020-01-31 08:47:19 --> Output Class Initialized
INFO - 2020-01-31 08:47:19 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:19 --> Input Class Initialized
INFO - 2020-01-31 08:47:19 --> Language Class Initialized
INFO - 2020-01-31 08:47:19 --> Language Class Initialized
INFO - 2020-01-31 08:47:19 --> Config Class Initialized
INFO - 2020-01-31 08:47:19 --> Loader Class Initialized
INFO - 2020-01-31 08:47:19 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:19 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:19 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:19 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:19 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:19 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-01-31 08:47:19 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 08:47:19 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:19 --> Total execution time: 0.3867
INFO - 2020-01-31 08:47:20 --> Config Class Initialized
INFO - 2020-01-31 08:47:20 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:20 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:20 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:20 --> URI Class Initialized
INFO - 2020-01-31 08:47:20 --> Router Class Initialized
INFO - 2020-01-31 08:47:20 --> Output Class Initialized
INFO - 2020-01-31 08:47:20 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:20 --> Input Class Initialized
INFO - 2020-01-31 08:47:20 --> Language Class Initialized
INFO - 2020-01-31 08:47:20 --> Language Class Initialized
INFO - 2020-01-31 08:47:20 --> Config Class Initialized
INFO - 2020-01-31 08:47:20 --> Loader Class Initialized
INFO - 2020-01-31 08:47:20 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:20 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:20 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:21 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:21 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:21 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-01-31 08:47:21 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 08:47:21 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:21 --> Total execution time: 0.3999
INFO - 2020-01-31 08:47:22 --> Config Class Initialized
INFO - 2020-01-31 08:47:22 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:22 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:22 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:22 --> URI Class Initialized
INFO - 2020-01-31 08:47:22 --> Router Class Initialized
INFO - 2020-01-31 08:47:22 --> Output Class Initialized
INFO - 2020-01-31 08:47:22 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:22 --> Input Class Initialized
INFO - 2020-01-31 08:47:22 --> Language Class Initialized
INFO - 2020-01-31 08:47:22 --> Language Class Initialized
INFO - 2020-01-31 08:47:22 --> Config Class Initialized
INFO - 2020-01-31 08:47:22 --> Loader Class Initialized
INFO - 2020-01-31 08:47:22 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:22 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:22 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:22 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:22 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:22 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-01-31 08:47:22 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 08:47:22 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:23 --> Total execution time: 0.4110
INFO - 2020-01-31 08:47:23 --> Config Class Initialized
INFO - 2020-01-31 08:47:23 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:23 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:23 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:23 --> URI Class Initialized
INFO - 2020-01-31 08:47:23 --> Router Class Initialized
INFO - 2020-01-31 08:47:23 --> Output Class Initialized
INFO - 2020-01-31 08:47:23 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:23 --> Input Class Initialized
INFO - 2020-01-31 08:47:23 --> Language Class Initialized
INFO - 2020-01-31 08:47:23 --> Language Class Initialized
INFO - 2020-01-31 08:47:23 --> Config Class Initialized
INFO - 2020-01-31 08:47:23 --> Loader Class Initialized
INFO - 2020-01-31 08:47:23 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:23 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:23 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:23 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:23 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:23 --> Controller Class Initialized
INFO - 2020-01-31 08:47:25 --> Config Class Initialized
INFO - 2020-01-31 08:47:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:25 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:25 --> URI Class Initialized
INFO - 2020-01-31 08:47:25 --> Router Class Initialized
INFO - 2020-01-31 08:47:25 --> Output Class Initialized
INFO - 2020-01-31 08:47:25 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:25 --> Input Class Initialized
INFO - 2020-01-31 08:47:25 --> Language Class Initialized
INFO - 2020-01-31 08:47:25 --> Language Class Initialized
INFO - 2020-01-31 08:47:25 --> Config Class Initialized
INFO - 2020-01-31 08:47:25 --> Loader Class Initialized
INFO - 2020-01-31 08:47:25 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:25 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:25 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:25 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:25 --> Controller Class Initialized
INFO - 2020-01-31 08:47:25 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:25 --> Total execution time: 0.3241
INFO - 2020-01-31 08:47:40 --> Config Class Initialized
INFO - 2020-01-31 08:47:40 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:40 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:40 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:40 --> URI Class Initialized
INFO - 2020-01-31 08:47:40 --> Router Class Initialized
INFO - 2020-01-31 08:47:40 --> Output Class Initialized
INFO - 2020-01-31 08:47:40 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:40 --> Input Class Initialized
INFO - 2020-01-31 08:47:40 --> Language Class Initialized
INFO - 2020-01-31 08:47:41 --> Language Class Initialized
INFO - 2020-01-31 08:47:41 --> Config Class Initialized
INFO - 2020-01-31 08:47:41 --> Loader Class Initialized
INFO - 2020-01-31 08:47:41 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:41 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:41 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:41 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:41 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:41 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2020-01-31 08:47:41 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 08:47:41 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:41 --> Total execution time: 0.4239
INFO - 2020-01-31 08:47:42 --> Config Class Initialized
INFO - 2020-01-31 08:47:42 --> Hooks Class Initialized
DEBUG - 2020-01-31 08:47:42 --> UTF-8 Support Enabled
INFO - 2020-01-31 08:47:42 --> Utf8 Class Initialized
INFO - 2020-01-31 08:47:42 --> URI Class Initialized
INFO - 2020-01-31 08:47:42 --> Router Class Initialized
INFO - 2020-01-31 08:47:42 --> Output Class Initialized
INFO - 2020-01-31 08:47:42 --> Security Class Initialized
DEBUG - 2020-01-31 08:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 08:47:42 --> Input Class Initialized
INFO - 2020-01-31 08:47:42 --> Language Class Initialized
INFO - 2020-01-31 08:47:43 --> Language Class Initialized
INFO - 2020-01-31 08:47:43 --> Config Class Initialized
INFO - 2020-01-31 08:47:43 --> Loader Class Initialized
INFO - 2020-01-31 08:47:43 --> Helper loaded: url_helper
INFO - 2020-01-31 08:47:43 --> Helper loaded: file_helper
INFO - 2020-01-31 08:47:43 --> Helper loaded: form_helper
INFO - 2020-01-31 08:47:43 --> Helper loaded: my_helper
INFO - 2020-01-31 08:47:43 --> Database Driver Class Initialized
DEBUG - 2020-01-31 08:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 08:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 08:47:43 --> Controller Class Initialized
DEBUG - 2020-01-31 08:47:43 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/Cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2020-01-31 08:47:43 --> Final output sent to browser
DEBUG - 2020-01-31 08:47:43 --> Total execution time: 0.4232
INFO - 2020-01-31 13:31:55 --> Config Class Initialized
INFO - 2020-01-31 13:31:55 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:31:55 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:31:55 --> Utf8 Class Initialized
INFO - 2020-01-31 13:31:55 --> URI Class Initialized
INFO - 2020-01-31 13:31:55 --> Router Class Initialized
INFO - 2020-01-31 13:31:55 --> Output Class Initialized
INFO - 2020-01-31 13:31:55 --> Security Class Initialized
DEBUG - 2020-01-31 13:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:31:55 --> Input Class Initialized
INFO - 2020-01-31 13:31:55 --> Language Class Initialized
INFO - 2020-01-31 13:31:55 --> Language Class Initialized
INFO - 2020-01-31 13:31:55 --> Config Class Initialized
INFO - 2020-01-31 13:31:55 --> Loader Class Initialized
INFO - 2020-01-31 13:31:55 --> Helper loaded: url_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: file_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: form_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: my_helper
INFO - 2020-01-31 13:31:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:31:56 --> Controller Class Initialized
INFO - 2020-01-31 13:31:56 --> Helper loaded: cookie_helper
INFO - 2020-01-31 13:31:56 --> Config Class Initialized
INFO - 2020-01-31 13:31:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:31:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:31:56 --> Utf8 Class Initialized
INFO - 2020-01-31 13:31:56 --> URI Class Initialized
INFO - 2020-01-31 13:31:56 --> Router Class Initialized
INFO - 2020-01-31 13:31:56 --> Output Class Initialized
INFO - 2020-01-31 13:31:56 --> Security Class Initialized
DEBUG - 2020-01-31 13:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:31:56 --> Input Class Initialized
INFO - 2020-01-31 13:31:56 --> Language Class Initialized
INFO - 2020-01-31 13:31:56 --> Language Class Initialized
INFO - 2020-01-31 13:31:56 --> Config Class Initialized
INFO - 2020-01-31 13:31:56 --> Loader Class Initialized
INFO - 2020-01-31 13:31:56 --> Helper loaded: url_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: file_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: form_helper
INFO - 2020-01-31 13:31:56 --> Helper loaded: my_helper
INFO - 2020-01-31 13:31:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:31:57 --> Controller Class Initialized
INFO - 2020-01-31 13:31:57 --> Config Class Initialized
INFO - 2020-01-31 13:31:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:31:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:31:57 --> Utf8 Class Initialized
INFO - 2020-01-31 13:31:57 --> URI Class Initialized
INFO - 2020-01-31 13:31:57 --> Router Class Initialized
INFO - 2020-01-31 13:31:57 --> Output Class Initialized
INFO - 2020-01-31 13:31:57 --> Security Class Initialized
DEBUG - 2020-01-31 13:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:31:57 --> Input Class Initialized
INFO - 2020-01-31 13:31:57 --> Language Class Initialized
INFO - 2020-01-31 13:31:57 --> Language Class Initialized
INFO - 2020-01-31 13:31:57 --> Config Class Initialized
INFO - 2020-01-31 13:31:57 --> Loader Class Initialized
INFO - 2020-01-31 13:31:57 --> Helper loaded: url_helper
INFO - 2020-01-31 13:31:57 --> Helper loaded: file_helper
INFO - 2020-01-31 13:31:57 --> Helper loaded: form_helper
INFO - 2020-01-31 13:31:57 --> Helper loaded: my_helper
INFO - 2020-01-31 13:31:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:31:57 --> Controller Class Initialized
DEBUG - 2020-01-31 13:31:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 13:31:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:31:57 --> Final output sent to browser
DEBUG - 2020-01-31 13:31:57 --> Total execution time: 0.4056
INFO - 2020-01-31 13:32:02 --> Config Class Initialized
INFO - 2020-01-31 13:32:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:32:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:32:02 --> Utf8 Class Initialized
INFO - 2020-01-31 13:32:02 --> URI Class Initialized
INFO - 2020-01-31 13:32:02 --> Router Class Initialized
INFO - 2020-01-31 13:32:02 --> Output Class Initialized
INFO - 2020-01-31 13:32:02 --> Security Class Initialized
DEBUG - 2020-01-31 13:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:32:02 --> Input Class Initialized
INFO - 2020-01-31 13:32:02 --> Language Class Initialized
INFO - 2020-01-31 13:32:02 --> Language Class Initialized
INFO - 2020-01-31 13:32:02 --> Config Class Initialized
INFO - 2020-01-31 13:32:02 --> Loader Class Initialized
INFO - 2020-01-31 13:32:02 --> Helper loaded: url_helper
INFO - 2020-01-31 13:32:02 --> Helper loaded: file_helper
INFO - 2020-01-31 13:32:02 --> Helper loaded: form_helper
INFO - 2020-01-31 13:32:02 --> Helper loaded: my_helper
INFO - 2020-01-31 13:32:02 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:32:03 --> Controller Class Initialized
DEBUG - 2020-01-31 13:32:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 13:32:03 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:32:03 --> Final output sent to browser
DEBUG - 2020-01-31 13:32:03 --> Total execution time: 0.4658
INFO - 2020-01-31 13:32:08 --> Config Class Initialized
INFO - 2020-01-31 13:32:08 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:32:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:32:08 --> Utf8 Class Initialized
INFO - 2020-01-31 13:32:08 --> URI Class Initialized
INFO - 2020-01-31 13:32:08 --> Router Class Initialized
INFO - 2020-01-31 13:32:08 --> Output Class Initialized
INFO - 2020-01-31 13:32:08 --> Security Class Initialized
DEBUG - 2020-01-31 13:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:32:08 --> Input Class Initialized
INFO - 2020-01-31 13:32:08 --> Language Class Initialized
INFO - 2020-01-31 13:32:08 --> Language Class Initialized
INFO - 2020-01-31 13:32:08 --> Config Class Initialized
INFO - 2020-01-31 13:32:09 --> Loader Class Initialized
INFO - 2020-01-31 13:32:09 --> Helper loaded: url_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: file_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: form_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: my_helper
INFO - 2020-01-31 13:32:09 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:32:09 --> Controller Class Initialized
INFO - 2020-01-31 13:32:09 --> Helper loaded: cookie_helper
INFO - 2020-01-31 13:32:09 --> Final output sent to browser
DEBUG - 2020-01-31 13:32:09 --> Total execution time: 0.4379
INFO - 2020-01-31 13:32:09 --> Config Class Initialized
INFO - 2020-01-31 13:32:09 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:32:09 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:32:09 --> Utf8 Class Initialized
INFO - 2020-01-31 13:32:09 --> URI Class Initialized
INFO - 2020-01-31 13:32:09 --> Router Class Initialized
INFO - 2020-01-31 13:32:09 --> Output Class Initialized
INFO - 2020-01-31 13:32:09 --> Security Class Initialized
DEBUG - 2020-01-31 13:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:32:09 --> Input Class Initialized
INFO - 2020-01-31 13:32:09 --> Language Class Initialized
INFO - 2020-01-31 13:32:09 --> Language Class Initialized
INFO - 2020-01-31 13:32:09 --> Config Class Initialized
INFO - 2020-01-31 13:32:09 --> Loader Class Initialized
INFO - 2020-01-31 13:32:09 --> Helper loaded: url_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: file_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: form_helper
INFO - 2020-01-31 13:32:09 --> Helper loaded: my_helper
INFO - 2020-01-31 13:32:09 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:32:09 --> Controller Class Initialized
DEBUG - 2020-01-31 13:32:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:32:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:32:09 --> Final output sent to browser
DEBUG - 2020-01-31 13:32:09 --> Total execution time: 0.5878
INFO - 2020-01-31 13:32:25 --> Config Class Initialized
INFO - 2020-01-31 13:32:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:32:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:32:25 --> Utf8 Class Initialized
INFO - 2020-01-31 13:32:25 --> URI Class Initialized
INFO - 2020-01-31 13:32:25 --> Router Class Initialized
INFO - 2020-01-31 13:32:25 --> Output Class Initialized
INFO - 2020-01-31 13:32:25 --> Security Class Initialized
DEBUG - 2020-01-31 13:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:32:25 --> Input Class Initialized
INFO - 2020-01-31 13:32:25 --> Language Class Initialized
INFO - 2020-01-31 13:32:25 --> Language Class Initialized
INFO - 2020-01-31 13:32:25 --> Config Class Initialized
INFO - 2020-01-31 13:32:25 --> Loader Class Initialized
INFO - 2020-01-31 13:32:25 --> Helper loaded: url_helper
INFO - 2020-01-31 13:32:25 --> Helper loaded: file_helper
INFO - 2020-01-31 13:32:25 --> Helper loaded: form_helper
INFO - 2020-01-31 13:32:25 --> Helper loaded: my_helper
INFO - 2020-01-31 13:32:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:32:25 --> Controller Class Initialized
DEBUG - 2020-01-31 13:32:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:32:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:32:25 --> Final output sent to browser
DEBUG - 2020-01-31 13:32:26 --> Total execution time: 0.4321
INFO - 2020-01-31 13:33:44 --> Config Class Initialized
INFO - 2020-01-31 13:33:44 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:33:44 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:33:44 --> Utf8 Class Initialized
INFO - 2020-01-31 13:33:44 --> URI Class Initialized
INFO - 2020-01-31 13:33:44 --> Router Class Initialized
INFO - 2020-01-31 13:33:44 --> Output Class Initialized
INFO - 2020-01-31 13:33:44 --> Security Class Initialized
DEBUG - 2020-01-31 13:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:33:44 --> Input Class Initialized
INFO - 2020-01-31 13:33:44 --> Language Class Initialized
INFO - 2020-01-31 13:33:44 --> Language Class Initialized
INFO - 2020-01-31 13:33:44 --> Config Class Initialized
INFO - 2020-01-31 13:33:44 --> Loader Class Initialized
INFO - 2020-01-31 13:33:44 --> Helper loaded: url_helper
INFO - 2020-01-31 13:33:44 --> Helper loaded: file_helper
INFO - 2020-01-31 13:33:44 --> Helper loaded: form_helper
INFO - 2020-01-31 13:33:44 --> Helper loaded: my_helper
INFO - 2020-01-31 13:33:44 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:33:44 --> Controller Class Initialized
DEBUG - 2020-01-31 13:33:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:33:44 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:33:44 --> Final output sent to browser
DEBUG - 2020-01-31 13:33:44 --> Total execution time: 0.5715
INFO - 2020-01-31 13:33:47 --> Config Class Initialized
INFO - 2020-01-31 13:33:48 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:33:48 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:33:48 --> Utf8 Class Initialized
INFO - 2020-01-31 13:33:48 --> URI Class Initialized
INFO - 2020-01-31 13:33:48 --> Router Class Initialized
INFO - 2020-01-31 13:33:48 --> Output Class Initialized
INFO - 2020-01-31 13:33:48 --> Security Class Initialized
DEBUG - 2020-01-31 13:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:33:48 --> Input Class Initialized
INFO - 2020-01-31 13:33:48 --> Language Class Initialized
INFO - 2020-01-31 13:33:48 --> Language Class Initialized
INFO - 2020-01-31 13:33:48 --> Config Class Initialized
INFO - 2020-01-31 13:33:48 --> Loader Class Initialized
INFO - 2020-01-31 13:33:48 --> Helper loaded: url_helper
INFO - 2020-01-31 13:33:48 --> Helper loaded: file_helper
INFO - 2020-01-31 13:33:48 --> Helper loaded: form_helper
INFO - 2020-01-31 13:33:48 --> Helper loaded: my_helper
INFO - 2020-01-31 13:33:48 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:33:48 --> Controller Class Initialized
DEBUG - 2020-01-31 13:33:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:33:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:33:48 --> Final output sent to browser
DEBUG - 2020-01-31 13:33:48 --> Total execution time: 0.4861
INFO - 2020-01-31 13:34:03 --> Config Class Initialized
INFO - 2020-01-31 13:34:03 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:03 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:03 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:03 --> URI Class Initialized
INFO - 2020-01-31 13:34:03 --> Router Class Initialized
INFO - 2020-01-31 13:34:03 --> Output Class Initialized
INFO - 2020-01-31 13:34:03 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:03 --> Input Class Initialized
INFO - 2020-01-31 13:34:03 --> Language Class Initialized
INFO - 2020-01-31 13:34:03 --> Language Class Initialized
INFO - 2020-01-31 13:34:03 --> Config Class Initialized
INFO - 2020-01-31 13:34:03 --> Loader Class Initialized
INFO - 2020-01-31 13:34:03 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:04 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:04 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:04 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:04 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:04 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:34:04 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:04 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:04 --> Total execution time: 0.5157
INFO - 2020-01-31 13:34:08 --> Config Class Initialized
INFO - 2020-01-31 13:34:08 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:08 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:08 --> URI Class Initialized
INFO - 2020-01-31 13:34:08 --> Router Class Initialized
INFO - 2020-01-31 13:34:08 --> Output Class Initialized
INFO - 2020-01-31 13:34:08 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:08 --> Input Class Initialized
INFO - 2020-01-31 13:34:08 --> Language Class Initialized
INFO - 2020-01-31 13:34:08 --> Language Class Initialized
INFO - 2020-01-31 13:34:08 --> Config Class Initialized
INFO - 2020-01-31 13:34:08 --> Loader Class Initialized
INFO - 2020-01-31 13:34:08 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:08 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:08 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:08 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:08 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:08 --> Controller Class Initialized
INFO - 2020-01-31 13:34:08 --> Helper loaded: cookie_helper
INFO - 2020-01-31 13:34:08 --> Config Class Initialized
INFO - 2020-01-31 13:34:08 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:08 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:08 --> URI Class Initialized
INFO - 2020-01-31 13:34:08 --> Router Class Initialized
INFO - 2020-01-31 13:34:08 --> Output Class Initialized
INFO - 2020-01-31 13:34:08 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:08 --> Input Class Initialized
INFO - 2020-01-31 13:34:08 --> Language Class Initialized
INFO - 2020-01-31 13:34:08 --> Language Class Initialized
INFO - 2020-01-31 13:34:08 --> Config Class Initialized
INFO - 2020-01-31 13:34:09 --> Loader Class Initialized
INFO - 2020-01-31 13:34:09 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:09 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:09 --> Controller Class Initialized
INFO - 2020-01-31 13:34:09 --> Config Class Initialized
INFO - 2020-01-31 13:34:09 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:09 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:09 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:09 --> URI Class Initialized
INFO - 2020-01-31 13:34:09 --> Router Class Initialized
INFO - 2020-01-31 13:34:09 --> Output Class Initialized
INFO - 2020-01-31 13:34:09 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:09 --> Input Class Initialized
INFO - 2020-01-31 13:34:09 --> Language Class Initialized
INFO - 2020-01-31 13:34:09 --> Language Class Initialized
INFO - 2020-01-31 13:34:09 --> Config Class Initialized
INFO - 2020-01-31 13:34:09 --> Loader Class Initialized
INFO - 2020-01-31 13:34:09 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:09 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:09 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:09 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 13:34:09 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:09 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:09 --> Total execution time: 0.3868
INFO - 2020-01-31 13:34:24 --> Config Class Initialized
INFO - 2020-01-31 13:34:24 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:24 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:25 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:25 --> URI Class Initialized
INFO - 2020-01-31 13:34:25 --> Router Class Initialized
INFO - 2020-01-31 13:34:25 --> Output Class Initialized
INFO - 2020-01-31 13:34:25 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:25 --> Input Class Initialized
INFO - 2020-01-31 13:34:25 --> Language Class Initialized
INFO - 2020-01-31 13:34:25 --> Language Class Initialized
INFO - 2020-01-31 13:34:25 --> Config Class Initialized
INFO - 2020-01-31 13:34:25 --> Loader Class Initialized
INFO - 2020-01-31 13:34:25 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:25 --> Controller Class Initialized
INFO - 2020-01-31 13:34:25 --> Helper loaded: cookie_helper
INFO - 2020-01-31 13:34:25 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:25 --> Total execution time: 0.3958
INFO - 2020-01-31 13:34:25 --> Config Class Initialized
INFO - 2020-01-31 13:34:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:25 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:25 --> URI Class Initialized
INFO - 2020-01-31 13:34:25 --> Router Class Initialized
INFO - 2020-01-31 13:34:25 --> Output Class Initialized
INFO - 2020-01-31 13:34:25 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:25 --> Input Class Initialized
INFO - 2020-01-31 13:34:25 --> Language Class Initialized
INFO - 2020-01-31 13:34:25 --> Language Class Initialized
INFO - 2020-01-31 13:34:25 --> Config Class Initialized
INFO - 2020-01-31 13:34:25 --> Loader Class Initialized
INFO - 2020-01-31 13:34:25 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:25 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:25 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:34:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:25 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:25 --> Total execution time: 0.4798
INFO - 2020-01-31 13:34:45 --> Config Class Initialized
INFO - 2020-01-31 13:34:45 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:45 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:45 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:45 --> URI Class Initialized
INFO - 2020-01-31 13:34:45 --> Router Class Initialized
INFO - 2020-01-31 13:34:45 --> Output Class Initialized
INFO - 2020-01-31 13:34:45 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:45 --> Input Class Initialized
INFO - 2020-01-31 13:34:45 --> Language Class Initialized
INFO - 2020-01-31 13:34:45 --> Language Class Initialized
INFO - 2020-01-31 13:34:45 --> Config Class Initialized
INFO - 2020-01-31 13:34:45 --> Loader Class Initialized
INFO - 2020-01-31 13:34:45 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:45 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:45 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:45 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:45 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:46 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-01-31 13:34:46 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:46 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:46 --> Total execution time: 0.4359
INFO - 2020-01-31 13:34:47 --> Config Class Initialized
INFO - 2020-01-31 13:34:47 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:47 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:47 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:47 --> URI Class Initialized
INFO - 2020-01-31 13:34:47 --> Router Class Initialized
INFO - 2020-01-31 13:34:47 --> Output Class Initialized
INFO - 2020-01-31 13:34:47 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:47 --> Input Class Initialized
INFO - 2020-01-31 13:34:47 --> Language Class Initialized
INFO - 2020-01-31 13:34:47 --> Language Class Initialized
INFO - 2020-01-31 13:34:47 --> Config Class Initialized
INFO - 2020-01-31 13:34:47 --> Loader Class Initialized
INFO - 2020-01-31 13:34:47 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:47 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:47 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:47 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:47 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:48 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:34:48 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:48 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:48 --> Total execution time: 0.6178
INFO - 2020-01-31 13:34:56 --> Config Class Initialized
INFO - 2020-01-31 13:34:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:34:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:34:56 --> Utf8 Class Initialized
INFO - 2020-01-31 13:34:56 --> URI Class Initialized
INFO - 2020-01-31 13:34:56 --> Router Class Initialized
INFO - 2020-01-31 13:34:56 --> Output Class Initialized
INFO - 2020-01-31 13:34:56 --> Security Class Initialized
DEBUG - 2020-01-31 13:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:34:56 --> Input Class Initialized
INFO - 2020-01-31 13:34:57 --> Language Class Initialized
INFO - 2020-01-31 13:34:57 --> Language Class Initialized
INFO - 2020-01-31 13:34:57 --> Config Class Initialized
INFO - 2020-01-31 13:34:57 --> Loader Class Initialized
INFO - 2020-01-31 13:34:57 --> Helper loaded: url_helper
INFO - 2020-01-31 13:34:57 --> Helper loaded: file_helper
INFO - 2020-01-31 13:34:57 --> Helper loaded: form_helper
INFO - 2020-01-31 13:34:57 --> Helper loaded: my_helper
INFO - 2020-01-31 13:34:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:34:57 --> Controller Class Initialized
DEBUG - 2020-01-31 13:34:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:34:57 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:34:57 --> Final output sent to browser
DEBUG - 2020-01-31 13:34:57 --> Total execution time: 0.6479
INFO - 2020-01-31 13:35:04 --> Config Class Initialized
INFO - 2020-01-31 13:35:04 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:35:04 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:35:04 --> Utf8 Class Initialized
INFO - 2020-01-31 13:35:04 --> URI Class Initialized
INFO - 2020-01-31 13:35:04 --> Router Class Initialized
INFO - 2020-01-31 13:35:04 --> Output Class Initialized
INFO - 2020-01-31 13:35:04 --> Security Class Initialized
DEBUG - 2020-01-31 13:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:35:04 --> Input Class Initialized
INFO - 2020-01-31 13:35:04 --> Language Class Initialized
INFO - 2020-01-31 13:35:04 --> Language Class Initialized
INFO - 2020-01-31 13:35:04 --> Config Class Initialized
INFO - 2020-01-31 13:35:04 --> Loader Class Initialized
INFO - 2020-01-31 13:35:04 --> Helper loaded: url_helper
INFO - 2020-01-31 13:35:04 --> Helper loaded: file_helper
INFO - 2020-01-31 13:35:04 --> Helper loaded: form_helper
INFO - 2020-01-31 13:35:04 --> Helper loaded: my_helper
INFO - 2020-01-31 13:35:05 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:35:05 --> Controller Class Initialized
DEBUG - 2020-01-31 13:35:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:35:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:35:05 --> Final output sent to browser
DEBUG - 2020-01-31 13:35:05 --> Total execution time: 0.5956
INFO - 2020-01-31 13:35:33 --> Config Class Initialized
INFO - 2020-01-31 13:35:33 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:35:33 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:35:33 --> Utf8 Class Initialized
INFO - 2020-01-31 13:35:33 --> URI Class Initialized
INFO - 2020-01-31 13:35:33 --> Router Class Initialized
INFO - 2020-01-31 13:35:33 --> Output Class Initialized
INFO - 2020-01-31 13:35:33 --> Security Class Initialized
DEBUG - 2020-01-31 13:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:35:33 --> Input Class Initialized
INFO - 2020-01-31 13:35:33 --> Language Class Initialized
INFO - 2020-01-31 13:35:33 --> Language Class Initialized
INFO - 2020-01-31 13:35:33 --> Config Class Initialized
INFO - 2020-01-31 13:35:33 --> Loader Class Initialized
INFO - 2020-01-31 13:35:33 --> Helper loaded: url_helper
INFO - 2020-01-31 13:35:33 --> Helper loaded: file_helper
INFO - 2020-01-31 13:35:33 --> Helper loaded: form_helper
ERROR - 2020-01-31 13:35:33 --> Severity: Parsing Error --> syntax error, unexpected ';' E:\xampp\htdocs\_2020\nilaik13_ci\application\helpers\my_helper.php 110
INFO - 2020-01-31 13:36:28 --> Config Class Initialized
INFO - 2020-01-31 13:36:28 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:36:28 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:36:28 --> Utf8 Class Initialized
INFO - 2020-01-31 13:36:28 --> URI Class Initialized
INFO - 2020-01-31 13:36:28 --> Router Class Initialized
INFO - 2020-01-31 13:36:28 --> Output Class Initialized
INFO - 2020-01-31 13:36:28 --> Security Class Initialized
DEBUG - 2020-01-31 13:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:36:28 --> Input Class Initialized
INFO - 2020-01-31 13:36:28 --> Language Class Initialized
INFO - 2020-01-31 13:36:28 --> Language Class Initialized
INFO - 2020-01-31 13:36:28 --> Config Class Initialized
INFO - 2020-01-31 13:36:28 --> Loader Class Initialized
INFO - 2020-01-31 13:36:28 --> Helper loaded: url_helper
INFO - 2020-01-31 13:36:28 --> Helper loaded: file_helper
INFO - 2020-01-31 13:36:28 --> Helper loaded: form_helper
INFO - 2020-01-31 13:36:28 --> Helper loaded: my_helper
INFO - 2020-01-31 13:36:28 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:36:28 --> Controller Class Initialized
DEBUG - 2020-01-31 13:36:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:36:28 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:36:28 --> Final output sent to browser
DEBUG - 2020-01-31 13:36:28 --> Total execution time: 0.4578
INFO - 2020-01-31 13:39:26 --> Config Class Initialized
INFO - 2020-01-31 13:39:26 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:39:26 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:39:26 --> Utf8 Class Initialized
INFO - 2020-01-31 13:39:26 --> URI Class Initialized
INFO - 2020-01-31 13:39:26 --> Router Class Initialized
INFO - 2020-01-31 13:39:26 --> Output Class Initialized
INFO - 2020-01-31 13:39:26 --> Security Class Initialized
DEBUG - 2020-01-31 13:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:39:26 --> Input Class Initialized
INFO - 2020-01-31 13:39:26 --> Language Class Initialized
INFO - 2020-01-31 13:39:26 --> Language Class Initialized
INFO - 2020-01-31 13:39:26 --> Config Class Initialized
INFO - 2020-01-31 13:39:26 --> Loader Class Initialized
INFO - 2020-01-31 13:39:26 --> Helper loaded: url_helper
INFO - 2020-01-31 13:39:26 --> Helper loaded: file_helper
INFO - 2020-01-31 13:39:26 --> Helper loaded: form_helper
INFO - 2020-01-31 13:39:26 --> Helper loaded: my_helper
INFO - 2020-01-31 13:39:26 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:39:26 --> Controller Class Initialized
DEBUG - 2020-01-31 13:39:26 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:39:26 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:39:26 --> Final output sent to browser
DEBUG - 2020-01-31 13:39:26 --> Total execution time: 0.5118
INFO - 2020-01-31 13:39:39 --> Config Class Initialized
INFO - 2020-01-31 13:39:39 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:39:39 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:39:39 --> Utf8 Class Initialized
INFO - 2020-01-31 13:39:39 --> URI Class Initialized
INFO - 2020-01-31 13:39:39 --> Router Class Initialized
INFO - 2020-01-31 13:39:40 --> Output Class Initialized
INFO - 2020-01-31 13:39:40 --> Security Class Initialized
DEBUG - 2020-01-31 13:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:39:40 --> Input Class Initialized
INFO - 2020-01-31 13:39:40 --> Language Class Initialized
INFO - 2020-01-31 13:39:40 --> Language Class Initialized
INFO - 2020-01-31 13:39:40 --> Config Class Initialized
INFO - 2020-01-31 13:39:40 --> Loader Class Initialized
INFO - 2020-01-31 13:39:40 --> Helper loaded: url_helper
INFO - 2020-01-31 13:39:40 --> Helper loaded: file_helper
INFO - 2020-01-31 13:39:40 --> Helper loaded: form_helper
INFO - 2020-01-31 13:39:40 --> Helper loaded: my_helper
INFO - 2020-01-31 13:39:40 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:39:40 --> Controller Class Initialized
DEBUG - 2020-01-31 13:39:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:39:40 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:39:40 --> Final output sent to browser
DEBUG - 2020-01-31 13:39:40 --> Total execution time: 0.4872
INFO - 2020-01-31 13:39:53 --> Config Class Initialized
INFO - 2020-01-31 13:39:53 --> Hooks Class Initialized
DEBUG - 2020-01-31 13:39:53 --> UTF-8 Support Enabled
INFO - 2020-01-31 13:39:53 --> Utf8 Class Initialized
INFO - 2020-01-31 13:39:53 --> URI Class Initialized
INFO - 2020-01-31 13:39:53 --> Router Class Initialized
INFO - 2020-01-31 13:39:53 --> Output Class Initialized
INFO - 2020-01-31 13:39:53 --> Security Class Initialized
DEBUG - 2020-01-31 13:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 13:39:53 --> Input Class Initialized
INFO - 2020-01-31 13:39:53 --> Language Class Initialized
INFO - 2020-01-31 13:39:53 --> Language Class Initialized
INFO - 2020-01-31 13:39:53 --> Config Class Initialized
INFO - 2020-01-31 13:39:53 --> Loader Class Initialized
INFO - 2020-01-31 13:39:53 --> Helper loaded: url_helper
INFO - 2020-01-31 13:39:53 --> Helper loaded: file_helper
INFO - 2020-01-31 13:39:53 --> Helper loaded: form_helper
INFO - 2020-01-31 13:39:53 --> Helper loaded: my_helper
INFO - 2020-01-31 13:39:53 --> Database Driver Class Initialized
DEBUG - 2020-01-31 13:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 13:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 13:39:53 --> Controller Class Initialized
DEBUG - 2020-01-31 13:39:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 13:39:53 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 13:39:53 --> Final output sent to browser
DEBUG - 2020-01-31 13:39:53 --> Total execution time: 0.4686
INFO - 2020-01-31 14:16:51 --> Config Class Initialized
INFO - 2020-01-31 14:16:51 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:16:51 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:16:51 --> Utf8 Class Initialized
INFO - 2020-01-31 14:16:51 --> URI Class Initialized
DEBUG - 2020-01-31 14:16:51 --> No URI present. Default controller set.
INFO - 2020-01-31 14:16:51 --> Router Class Initialized
INFO - 2020-01-31 14:16:51 --> Output Class Initialized
INFO - 2020-01-31 14:16:51 --> Security Class Initialized
DEBUG - 2020-01-31 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:16:51 --> Input Class Initialized
INFO - 2020-01-31 14:16:51 --> Language Class Initialized
INFO - 2020-01-31 14:16:51 --> Language Class Initialized
INFO - 2020-01-31 14:16:51 --> Config Class Initialized
INFO - 2020-01-31 14:16:51 --> Loader Class Initialized
INFO - 2020-01-31 14:16:51 --> Helper loaded: url_helper
INFO - 2020-01-31 14:16:51 --> Helper loaded: file_helper
INFO - 2020-01-31 14:16:51 --> Helper loaded: form_helper
INFO - 2020-01-31 14:16:51 --> Helper loaded: my_helper
INFO - 2020-01-31 14:16:51 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:16:51 --> Controller Class Initialized
DEBUG - 2020-01-31 14:16:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 14:16:51 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:16:51 --> Final output sent to browser
DEBUG - 2020-01-31 14:16:52 --> Total execution time: 0.4849
INFO - 2020-01-31 14:16:57 --> Config Class Initialized
INFO - 2020-01-31 14:16:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:16:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:16:57 --> Utf8 Class Initialized
INFO - 2020-01-31 14:16:57 --> URI Class Initialized
INFO - 2020-01-31 14:16:57 --> Router Class Initialized
INFO - 2020-01-31 14:16:57 --> Output Class Initialized
INFO - 2020-01-31 14:16:57 --> Security Class Initialized
DEBUG - 2020-01-31 14:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:16:57 --> Input Class Initialized
INFO - 2020-01-31 14:16:57 --> Language Class Initialized
INFO - 2020-01-31 14:16:57 --> Language Class Initialized
INFO - 2020-01-31 14:16:57 --> Config Class Initialized
INFO - 2020-01-31 14:16:57 --> Loader Class Initialized
INFO - 2020-01-31 14:16:57 --> Helper loaded: url_helper
INFO - 2020-01-31 14:16:57 --> Helper loaded: file_helper
INFO - 2020-01-31 14:16:57 --> Helper loaded: form_helper
INFO - 2020-01-31 14:16:57 --> Helper loaded: my_helper
INFO - 2020-01-31 14:16:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:16:57 --> Controller Class Initialized
INFO - 2020-01-31 14:16:57 --> Helper loaded: cookie_helper
INFO - 2020-01-31 14:16:57 --> Config Class Initialized
INFO - 2020-01-31 14:16:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:16:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:16:57 --> Utf8 Class Initialized
INFO - 2020-01-31 14:16:58 --> URI Class Initialized
INFO - 2020-01-31 14:16:58 --> Router Class Initialized
INFO - 2020-01-31 14:16:58 --> Output Class Initialized
INFO - 2020-01-31 14:16:58 --> Security Class Initialized
DEBUG - 2020-01-31 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:16:58 --> Input Class Initialized
INFO - 2020-01-31 14:16:58 --> Language Class Initialized
INFO - 2020-01-31 14:16:58 --> Language Class Initialized
INFO - 2020-01-31 14:16:58 --> Config Class Initialized
INFO - 2020-01-31 14:16:58 --> Loader Class Initialized
INFO - 2020-01-31 14:16:58 --> Helper loaded: url_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: file_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: form_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: my_helper
INFO - 2020-01-31 14:16:58 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:16:58 --> Controller Class Initialized
INFO - 2020-01-31 14:16:58 --> Config Class Initialized
INFO - 2020-01-31 14:16:58 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:16:58 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:16:58 --> Utf8 Class Initialized
INFO - 2020-01-31 14:16:58 --> URI Class Initialized
INFO - 2020-01-31 14:16:58 --> Router Class Initialized
INFO - 2020-01-31 14:16:58 --> Output Class Initialized
INFO - 2020-01-31 14:16:58 --> Security Class Initialized
DEBUG - 2020-01-31 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:16:58 --> Input Class Initialized
INFO - 2020-01-31 14:16:58 --> Language Class Initialized
INFO - 2020-01-31 14:16:58 --> Language Class Initialized
INFO - 2020-01-31 14:16:58 --> Config Class Initialized
INFO - 2020-01-31 14:16:58 --> Loader Class Initialized
INFO - 2020-01-31 14:16:58 --> Helper loaded: url_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: file_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: form_helper
INFO - 2020-01-31 14:16:58 --> Helper loaded: my_helper
INFO - 2020-01-31 14:16:58 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:16:58 --> Controller Class Initialized
DEBUG - 2020-01-31 14:16:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 14:16:58 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:16:58 --> Final output sent to browser
DEBUG - 2020-01-31 14:16:58 --> Total execution time: 0.4362
INFO - 2020-01-31 14:17:04 --> Config Class Initialized
INFO - 2020-01-31 14:17:04 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:17:04 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:17:04 --> Utf8 Class Initialized
INFO - 2020-01-31 14:17:04 --> URI Class Initialized
INFO - 2020-01-31 14:17:04 --> Router Class Initialized
INFO - 2020-01-31 14:17:04 --> Output Class Initialized
INFO - 2020-01-31 14:17:04 --> Security Class Initialized
DEBUG - 2020-01-31 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:17:04 --> Input Class Initialized
INFO - 2020-01-31 14:17:04 --> Language Class Initialized
INFO - 2020-01-31 14:17:04 --> Language Class Initialized
INFO - 2020-01-31 14:17:04 --> Config Class Initialized
INFO - 2020-01-31 14:17:04 --> Loader Class Initialized
INFO - 2020-01-31 14:17:04 --> Helper loaded: url_helper
INFO - 2020-01-31 14:17:04 --> Helper loaded: file_helper
INFO - 2020-01-31 14:17:04 --> Helper loaded: form_helper
INFO - 2020-01-31 14:17:04 --> Helper loaded: my_helper
INFO - 2020-01-31 14:17:04 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:17:04 --> Controller Class Initialized
INFO - 2020-01-31 14:17:04 --> Helper loaded: cookie_helper
INFO - 2020-01-31 14:17:04 --> Final output sent to browser
DEBUG - 2020-01-31 14:17:04 --> Total execution time: 0.4235
INFO - 2020-01-31 14:17:04 --> Config Class Initialized
INFO - 2020-01-31 14:17:04 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:17:04 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:17:04 --> Utf8 Class Initialized
INFO - 2020-01-31 14:17:04 --> URI Class Initialized
INFO - 2020-01-31 14:17:04 --> Router Class Initialized
INFO - 2020-01-31 14:17:04 --> Output Class Initialized
INFO - 2020-01-31 14:17:04 --> Security Class Initialized
DEBUG - 2020-01-31 14:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:17:04 --> Input Class Initialized
INFO - 2020-01-31 14:17:04 --> Language Class Initialized
INFO - 2020-01-31 14:17:04 --> Language Class Initialized
INFO - 2020-01-31 14:17:04 --> Config Class Initialized
INFO - 2020-01-31 14:17:04 --> Loader Class Initialized
INFO - 2020-01-31 14:17:04 --> Helper loaded: url_helper
INFO - 2020-01-31 14:17:04 --> Helper loaded: file_helper
INFO - 2020-01-31 14:17:04 --> Helper loaded: form_helper
INFO - 2020-01-31 14:17:05 --> Helper loaded: my_helper
INFO - 2020-01-31 14:17:05 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:17:05 --> Controller Class Initialized
DEBUG - 2020-01-31 14:17:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/home/views/v_home.php
DEBUG - 2020-01-31 14:17:05 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:17:05 --> Final output sent to browser
DEBUG - 2020-01-31 14:17:05 --> Total execution time: 0.5769
INFO - 2020-01-31 14:17:06 --> Config Class Initialized
INFO - 2020-01-31 14:17:06 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:17:06 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:17:06 --> Utf8 Class Initialized
INFO - 2020-01-31 14:17:06 --> URI Class Initialized
INFO - 2020-01-31 14:17:06 --> Router Class Initialized
INFO - 2020-01-31 14:17:06 --> Output Class Initialized
INFO - 2020-01-31 14:17:06 --> Security Class Initialized
DEBUG - 2020-01-31 14:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:17:06 --> Input Class Initialized
INFO - 2020-01-31 14:17:06 --> Language Class Initialized
INFO - 2020-01-31 14:17:06 --> Language Class Initialized
INFO - 2020-01-31 14:17:06 --> Config Class Initialized
INFO - 2020-01-31 14:17:06 --> Loader Class Initialized
INFO - 2020-01-31 14:17:06 --> Helper loaded: url_helper
INFO - 2020-01-31 14:17:06 --> Helper loaded: file_helper
INFO - 2020-01-31 14:17:06 --> Helper loaded: form_helper
INFO - 2020-01-31 14:17:06 --> Helper loaded: my_helper
INFO - 2020-01-31 14:17:06 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:17:06 --> Controller Class Initialized
DEBUG - 2020-01-31 14:17:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:17:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:17:06 --> Final output sent to browser
DEBUG - 2020-01-31 14:17:06 --> Total execution time: 0.5355
INFO - 2020-01-31 14:17:07 --> Config Class Initialized
INFO - 2020-01-31 14:17:07 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:17:07 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:17:07 --> Utf8 Class Initialized
INFO - 2020-01-31 14:17:07 --> URI Class Initialized
INFO - 2020-01-31 14:17:07 --> Router Class Initialized
INFO - 2020-01-31 14:17:07 --> Output Class Initialized
INFO - 2020-01-31 14:17:07 --> Security Class Initialized
DEBUG - 2020-01-31 14:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:17:07 --> Input Class Initialized
INFO - 2020-01-31 14:17:07 --> Language Class Initialized
INFO - 2020-01-31 14:17:07 --> Language Class Initialized
INFO - 2020-01-31 14:17:07 --> Config Class Initialized
INFO - 2020-01-31 14:17:07 --> Loader Class Initialized
INFO - 2020-01-31 14:17:07 --> Helper loaded: url_helper
INFO - 2020-01-31 14:17:07 --> Helper loaded: file_helper
INFO - 2020-01-31 14:17:07 --> Helper loaded: form_helper
INFO - 2020-01-31 14:17:07 --> Helper loaded: my_helper
INFO - 2020-01-31 14:17:07 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:17:07 --> Controller Class Initialized
INFO - 2020-01-31 14:17:12 --> Config Class Initialized
INFO - 2020-01-31 14:17:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:17:13 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:17:13 --> Utf8 Class Initialized
INFO - 2020-01-31 14:17:13 --> URI Class Initialized
INFO - 2020-01-31 14:17:13 --> Router Class Initialized
INFO - 2020-01-31 14:17:13 --> Output Class Initialized
INFO - 2020-01-31 14:17:13 --> Security Class Initialized
DEBUG - 2020-01-31 14:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:17:13 --> Input Class Initialized
INFO - 2020-01-31 14:17:13 --> Language Class Initialized
INFO - 2020-01-31 14:17:13 --> Language Class Initialized
INFO - 2020-01-31 14:17:13 --> Config Class Initialized
INFO - 2020-01-31 14:17:13 --> Loader Class Initialized
INFO - 2020-01-31 14:17:13 --> Helper loaded: url_helper
INFO - 2020-01-31 14:17:13 --> Helper loaded: file_helper
INFO - 2020-01-31 14:17:13 --> Helper loaded: form_helper
INFO - 2020-01-31 14:17:13 --> Helper loaded: my_helper
INFO - 2020-01-31 14:17:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:17:13 --> Controller Class Initialized
INFO - 2020-01-31 14:17:13 --> Final output sent to browser
DEBUG - 2020-01-31 14:17:13 --> Total execution time: 0.4437
INFO - 2020-01-31 14:19:26 --> Config Class Initialized
INFO - 2020-01-31 14:19:26 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:19:26 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:19:26 --> Utf8 Class Initialized
INFO - 2020-01-31 14:19:26 --> URI Class Initialized
INFO - 2020-01-31 14:19:26 --> Router Class Initialized
INFO - 2020-01-31 14:19:26 --> Output Class Initialized
INFO - 2020-01-31 14:19:26 --> Security Class Initialized
DEBUG - 2020-01-31 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:19:26 --> Input Class Initialized
INFO - 2020-01-31 14:19:26 --> Language Class Initialized
INFO - 2020-01-31 14:19:26 --> Language Class Initialized
INFO - 2020-01-31 14:19:26 --> Config Class Initialized
INFO - 2020-01-31 14:19:26 --> Loader Class Initialized
INFO - 2020-01-31 14:19:26 --> Helper loaded: url_helper
INFO - 2020-01-31 14:19:26 --> Helper loaded: file_helper
INFO - 2020-01-31 14:19:26 --> Helper loaded: form_helper
INFO - 2020-01-31 14:19:26 --> Helper loaded: my_helper
INFO - 2020-01-31 14:19:26 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:19:26 --> Controller Class Initialized
INFO - 2020-01-31 14:19:26 --> Final output sent to browser
DEBUG - 2020-01-31 14:19:26 --> Total execution time: 0.4445
INFO - 2020-01-31 14:19:38 --> Config Class Initialized
INFO - 2020-01-31 14:19:38 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:19:38 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:19:38 --> Utf8 Class Initialized
INFO - 2020-01-31 14:19:38 --> URI Class Initialized
INFO - 2020-01-31 14:19:38 --> Router Class Initialized
INFO - 2020-01-31 14:19:38 --> Output Class Initialized
INFO - 2020-01-31 14:19:38 --> Security Class Initialized
DEBUG - 2020-01-31 14:19:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:19:38 --> Input Class Initialized
INFO - 2020-01-31 14:19:38 --> Language Class Initialized
INFO - 2020-01-31 14:19:38 --> Language Class Initialized
INFO - 2020-01-31 14:19:38 --> Config Class Initialized
INFO - 2020-01-31 14:19:38 --> Loader Class Initialized
INFO - 2020-01-31 14:19:38 --> Helper loaded: url_helper
INFO - 2020-01-31 14:19:38 --> Helper loaded: file_helper
INFO - 2020-01-31 14:19:38 --> Helper loaded: form_helper
INFO - 2020-01-31 14:19:38 --> Helper loaded: my_helper
INFO - 2020-01-31 14:19:38 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:19:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:19:38 --> Controller Class Initialized
INFO - 2020-01-31 14:20:00 --> Final output sent to browser
DEBUG - 2020-01-31 14:20:00 --> Total execution time: 21.6728
INFO - 2020-01-31 14:20:06 --> Config Class Initialized
INFO - 2020-01-31 14:20:06 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:06 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:06 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:06 --> URI Class Initialized
INFO - 2020-01-31 14:20:06 --> Router Class Initialized
INFO - 2020-01-31 14:20:06 --> Output Class Initialized
INFO - 2020-01-31 14:20:06 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:06 --> Input Class Initialized
INFO - 2020-01-31 14:20:06 --> Language Class Initialized
INFO - 2020-01-31 14:20:06 --> Language Class Initialized
INFO - 2020-01-31 14:20:06 --> Config Class Initialized
INFO - 2020-01-31 14:20:06 --> Loader Class Initialized
INFO - 2020-01-31 14:20:06 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:06 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:06 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:06 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:06 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:06 --> Controller Class Initialized
DEBUG - 2020-01-31 14:20:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:20:06 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:20:06 --> Final output sent to browser
DEBUG - 2020-01-31 14:20:06 --> Total execution time: 0.5095
INFO - 2020-01-31 14:20:06 --> Config Class Initialized
INFO - 2020-01-31 14:20:06 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:06 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:06 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:06 --> URI Class Initialized
INFO - 2020-01-31 14:20:06 --> Router Class Initialized
INFO - 2020-01-31 14:20:07 --> Output Class Initialized
INFO - 2020-01-31 14:20:07 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:07 --> Input Class Initialized
INFO - 2020-01-31 14:20:07 --> Language Class Initialized
INFO - 2020-01-31 14:20:07 --> Language Class Initialized
INFO - 2020-01-31 14:20:07 --> Config Class Initialized
INFO - 2020-01-31 14:20:07 --> Loader Class Initialized
INFO - 2020-01-31 14:20:07 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:07 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:07 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:07 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:07 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:07 --> Controller Class Initialized
INFO - 2020-01-31 14:20:10 --> Config Class Initialized
INFO - 2020-01-31 14:20:10 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:10 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:10 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:10 --> URI Class Initialized
INFO - 2020-01-31 14:20:10 --> Router Class Initialized
INFO - 2020-01-31 14:20:10 --> Output Class Initialized
INFO - 2020-01-31 14:20:10 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:10 --> Input Class Initialized
INFO - 2020-01-31 14:20:10 --> Language Class Initialized
INFO - 2020-01-31 14:20:10 --> Language Class Initialized
INFO - 2020-01-31 14:20:10 --> Config Class Initialized
INFO - 2020-01-31 14:20:10 --> Loader Class Initialized
INFO - 2020-01-31 14:20:10 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:10 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:10 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:10 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:10 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:10 --> Controller Class Initialized
INFO - 2020-01-31 14:20:12 --> Config Class Initialized
INFO - 2020-01-31 14:20:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:12 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:12 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:12 --> URI Class Initialized
INFO - 2020-01-31 14:20:12 --> Router Class Initialized
INFO - 2020-01-31 14:20:13 --> Output Class Initialized
INFO - 2020-01-31 14:20:13 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:13 --> Input Class Initialized
INFO - 2020-01-31 14:20:13 --> Language Class Initialized
INFO - 2020-01-31 14:20:13 --> Language Class Initialized
INFO - 2020-01-31 14:20:13 --> Config Class Initialized
INFO - 2020-01-31 14:20:13 --> Loader Class Initialized
INFO - 2020-01-31 14:20:13 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:13 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:13 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:13 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:13 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:13 --> Controller Class Initialized
INFO - 2020-01-31 14:20:15 --> Config Class Initialized
INFO - 2020-01-31 14:20:15 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:15 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:15 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:15 --> URI Class Initialized
INFO - 2020-01-31 14:20:15 --> Router Class Initialized
INFO - 2020-01-31 14:20:15 --> Output Class Initialized
INFO - 2020-01-31 14:20:15 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:15 --> Input Class Initialized
INFO - 2020-01-31 14:20:15 --> Language Class Initialized
INFO - 2020-01-31 14:20:15 --> Language Class Initialized
INFO - 2020-01-31 14:20:15 --> Config Class Initialized
INFO - 2020-01-31 14:20:15 --> Loader Class Initialized
INFO - 2020-01-31 14:20:15 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:15 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:15 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:15 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:16 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:16 --> Controller Class Initialized
INFO - 2020-01-31 14:20:16 --> Config Class Initialized
INFO - 2020-01-31 14:20:16 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:16 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:16 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:16 --> URI Class Initialized
INFO - 2020-01-31 14:20:16 --> Router Class Initialized
INFO - 2020-01-31 14:20:16 --> Output Class Initialized
INFO - 2020-01-31 14:20:16 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:16 --> Input Class Initialized
INFO - 2020-01-31 14:20:16 --> Language Class Initialized
INFO - 2020-01-31 14:20:16 --> Language Class Initialized
INFO - 2020-01-31 14:20:16 --> Config Class Initialized
INFO - 2020-01-31 14:20:16 --> Loader Class Initialized
INFO - 2020-01-31 14:20:16 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:16 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:16 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:16 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:16 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:16 --> Controller Class Initialized
INFO - 2020-01-31 14:20:25 --> Config Class Initialized
INFO - 2020-01-31 14:20:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:25 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:25 --> URI Class Initialized
INFO - 2020-01-31 14:20:25 --> Router Class Initialized
INFO - 2020-01-31 14:20:25 --> Output Class Initialized
INFO - 2020-01-31 14:20:25 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:25 --> Input Class Initialized
INFO - 2020-01-31 14:20:25 --> Language Class Initialized
INFO - 2020-01-31 14:20:25 --> Language Class Initialized
INFO - 2020-01-31 14:20:25 --> Config Class Initialized
INFO - 2020-01-31 14:20:25 --> Loader Class Initialized
INFO - 2020-01-31 14:20:25 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:25 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:25 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:25 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:25 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:25 --> Controller Class Initialized
DEBUG - 2020-01-31 14:20:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:20:25 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:20:25 --> Final output sent to browser
DEBUG - 2020-01-31 14:20:25 --> Total execution time: 0.4352
INFO - 2020-01-31 14:20:25 --> Config Class Initialized
INFO - 2020-01-31 14:20:25 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:25 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:25 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:25 --> URI Class Initialized
INFO - 2020-01-31 14:20:25 --> Router Class Initialized
INFO - 2020-01-31 14:20:25 --> Output Class Initialized
INFO - 2020-01-31 14:20:25 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:25 --> Input Class Initialized
INFO - 2020-01-31 14:20:25 --> Language Class Initialized
INFO - 2020-01-31 14:20:25 --> Language Class Initialized
INFO - 2020-01-31 14:20:25 --> Config Class Initialized
INFO - 2020-01-31 14:20:25 --> Loader Class Initialized
INFO - 2020-01-31 14:20:26 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:26 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:26 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:26 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:26 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:26 --> Controller Class Initialized
INFO - 2020-01-31 14:20:30 --> Config Class Initialized
INFO - 2020-01-31 14:20:30 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:20:30 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:20:30 --> Utf8 Class Initialized
INFO - 2020-01-31 14:20:30 --> URI Class Initialized
INFO - 2020-01-31 14:20:30 --> Router Class Initialized
INFO - 2020-01-31 14:20:30 --> Output Class Initialized
INFO - 2020-01-31 14:20:30 --> Security Class Initialized
DEBUG - 2020-01-31 14:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:20:30 --> Input Class Initialized
INFO - 2020-01-31 14:20:30 --> Language Class Initialized
INFO - 2020-01-31 14:20:30 --> Language Class Initialized
INFO - 2020-01-31 14:20:30 --> Config Class Initialized
INFO - 2020-01-31 14:20:30 --> Loader Class Initialized
INFO - 2020-01-31 14:20:30 --> Helper loaded: url_helper
INFO - 2020-01-31 14:20:30 --> Helper loaded: file_helper
INFO - 2020-01-31 14:20:30 --> Helper loaded: form_helper
INFO - 2020-01-31 14:20:30 --> Helper loaded: my_helper
INFO - 2020-01-31 14:20:30 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:20:30 --> Controller Class Initialized
INFO - 2020-01-31 14:22:02 --> Config Class Initialized
INFO - 2020-01-31 14:22:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:02 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:02 --> URI Class Initialized
INFO - 2020-01-31 14:22:02 --> Router Class Initialized
INFO - 2020-01-31 14:22:02 --> Output Class Initialized
INFO - 2020-01-31 14:22:02 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:02 --> Input Class Initialized
INFO - 2020-01-31 14:22:02 --> Language Class Initialized
INFO - 2020-01-31 14:22:02 --> Language Class Initialized
INFO - 2020-01-31 14:22:02 --> Config Class Initialized
INFO - 2020-01-31 14:22:02 --> Loader Class Initialized
INFO - 2020-01-31 14:22:02 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:02 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:02 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:02 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:02 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:02 --> Controller Class Initialized
DEBUG - 2020-01-31 14:22:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:22:02 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:22:02 --> Final output sent to browser
DEBUG - 2020-01-31 14:22:02 --> Total execution time: 0.4992
INFO - 2020-01-31 14:22:02 --> Config Class Initialized
INFO - 2020-01-31 14:22:02 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:02 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:02 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:02 --> URI Class Initialized
INFO - 2020-01-31 14:22:02 --> Router Class Initialized
INFO - 2020-01-31 14:22:02 --> Output Class Initialized
INFO - 2020-01-31 14:22:02 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:03 --> Input Class Initialized
INFO - 2020-01-31 14:22:03 --> Language Class Initialized
INFO - 2020-01-31 14:22:03 --> Language Class Initialized
INFO - 2020-01-31 14:22:03 --> Config Class Initialized
INFO - 2020-01-31 14:22:03 --> Loader Class Initialized
INFO - 2020-01-31 14:22:03 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:03 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:03 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:03 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:03 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:03 --> Controller Class Initialized
INFO - 2020-01-31 14:22:10 --> Config Class Initialized
INFO - 2020-01-31 14:22:10 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:10 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:10 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:10 --> URI Class Initialized
INFO - 2020-01-31 14:22:10 --> Router Class Initialized
INFO - 2020-01-31 14:22:10 --> Output Class Initialized
INFO - 2020-01-31 14:22:10 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:10 --> Input Class Initialized
INFO - 2020-01-31 14:22:10 --> Language Class Initialized
INFO - 2020-01-31 14:22:10 --> Language Class Initialized
INFO - 2020-01-31 14:22:10 --> Config Class Initialized
INFO - 2020-01-31 14:22:10 --> Loader Class Initialized
INFO - 2020-01-31 14:22:10 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:10 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:10 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:10 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:10 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:10 --> Controller Class Initialized
INFO - 2020-01-31 14:22:10 --> Final output sent to browser
DEBUG - 2020-01-31 14:22:10 --> Total execution time: 0.4286
INFO - 2020-01-31 14:22:15 --> Config Class Initialized
INFO - 2020-01-31 14:22:15 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:15 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:15 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:15 --> URI Class Initialized
INFO - 2020-01-31 14:22:15 --> Router Class Initialized
INFO - 2020-01-31 14:22:15 --> Output Class Initialized
INFO - 2020-01-31 14:22:15 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:15 --> Input Class Initialized
INFO - 2020-01-31 14:22:15 --> Language Class Initialized
INFO - 2020-01-31 14:22:15 --> Language Class Initialized
INFO - 2020-01-31 14:22:15 --> Config Class Initialized
INFO - 2020-01-31 14:22:15 --> Loader Class Initialized
INFO - 2020-01-31 14:22:15 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:15 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:15 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:15 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:15 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:15 --> Controller Class Initialized
INFO - 2020-01-31 14:22:15 --> Final output sent to browser
DEBUG - 2020-01-31 14:22:15 --> Total execution time: 0.3930
INFO - 2020-01-31 14:22:15 --> Config Class Initialized
INFO - 2020-01-31 14:22:15 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:15 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:15 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:15 --> URI Class Initialized
INFO - 2020-01-31 14:22:15 --> Router Class Initialized
INFO - 2020-01-31 14:22:15 --> Output Class Initialized
INFO - 2020-01-31 14:22:15 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:15 --> Input Class Initialized
INFO - 2020-01-31 14:22:15 --> Language Class Initialized
INFO - 2020-01-31 14:22:15 --> Language Class Initialized
INFO - 2020-01-31 14:22:16 --> Config Class Initialized
INFO - 2020-01-31 14:22:16 --> Loader Class Initialized
INFO - 2020-01-31 14:22:16 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:16 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:16 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:16 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:16 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:16 --> Controller Class Initialized
INFO - 2020-01-31 14:22:27 --> Config Class Initialized
INFO - 2020-01-31 14:22:27 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:22:27 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:22:27 --> Utf8 Class Initialized
INFO - 2020-01-31 14:22:27 --> URI Class Initialized
INFO - 2020-01-31 14:22:27 --> Router Class Initialized
INFO - 2020-01-31 14:22:27 --> Output Class Initialized
INFO - 2020-01-31 14:22:27 --> Security Class Initialized
DEBUG - 2020-01-31 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:22:27 --> Input Class Initialized
INFO - 2020-01-31 14:22:27 --> Language Class Initialized
INFO - 2020-01-31 14:22:27 --> Language Class Initialized
INFO - 2020-01-31 14:22:27 --> Config Class Initialized
INFO - 2020-01-31 14:22:27 --> Loader Class Initialized
INFO - 2020-01-31 14:22:27 --> Helper loaded: url_helper
INFO - 2020-01-31 14:22:27 --> Helper loaded: file_helper
INFO - 2020-01-31 14:22:27 --> Helper loaded: form_helper
INFO - 2020-01-31 14:22:27 --> Helper loaded: my_helper
INFO - 2020-01-31 14:22:27 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:22:27 --> Controller Class Initialized
INFO - 2020-01-31 14:22:27 --> Final output sent to browser
DEBUG - 2020-01-31 14:22:27 --> Total execution time: 0.3664
INFO - 2020-01-31 14:55:49 --> Config Class Initialized
INFO - 2020-01-31 14:55:49 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:55:49 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:55:49 --> Utf8 Class Initialized
INFO - 2020-01-31 14:55:49 --> URI Class Initialized
INFO - 2020-01-31 14:55:49 --> Router Class Initialized
INFO - 2020-01-31 14:55:49 --> Output Class Initialized
INFO - 2020-01-31 14:55:49 --> Security Class Initialized
DEBUG - 2020-01-31 14:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:55:49 --> Input Class Initialized
INFO - 2020-01-31 14:55:49 --> Language Class Initialized
INFO - 2020-01-31 14:55:49 --> Language Class Initialized
INFO - 2020-01-31 14:55:49 --> Config Class Initialized
INFO - 2020-01-31 14:55:49 --> Loader Class Initialized
INFO - 2020-01-31 14:55:49 --> Helper loaded: url_helper
INFO - 2020-01-31 14:55:49 --> Helper loaded: file_helper
INFO - 2020-01-31 14:55:49 --> Helper loaded: form_helper
INFO - 2020-01-31 14:55:49 --> Helper loaded: my_helper
INFO - 2020-01-31 14:55:49 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:55:49 --> Controller Class Initialized
DEBUG - 2020-01-31 14:55:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:55:49 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:55:49 --> Final output sent to browser
DEBUG - 2020-01-31 14:55:49 --> Total execution time: 0.4425
INFO - 2020-01-31 14:55:50 --> Config Class Initialized
INFO - 2020-01-31 14:55:50 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:55:50 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:55:50 --> Utf8 Class Initialized
INFO - 2020-01-31 14:55:50 --> URI Class Initialized
INFO - 2020-01-31 14:55:50 --> Router Class Initialized
INFO - 2020-01-31 14:55:50 --> Output Class Initialized
INFO - 2020-01-31 14:55:50 --> Security Class Initialized
DEBUG - 2020-01-31 14:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:55:50 --> Input Class Initialized
INFO - 2020-01-31 14:55:50 --> Language Class Initialized
INFO - 2020-01-31 14:55:50 --> Language Class Initialized
INFO - 2020-01-31 14:55:50 --> Config Class Initialized
INFO - 2020-01-31 14:55:50 --> Loader Class Initialized
INFO - 2020-01-31 14:55:50 --> Helper loaded: url_helper
INFO - 2020-01-31 14:55:50 --> Helper loaded: file_helper
INFO - 2020-01-31 14:55:50 --> Helper loaded: form_helper
INFO - 2020-01-31 14:55:50 --> Helper loaded: my_helper
INFO - 2020-01-31 14:55:50 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:55:50 --> Controller Class Initialized
INFO - 2020-01-31 14:56:29 --> Config Class Initialized
INFO - 2020-01-31 14:56:29 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:56:29 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:56:29 --> Utf8 Class Initialized
INFO - 2020-01-31 14:56:29 --> URI Class Initialized
INFO - 2020-01-31 14:56:29 --> Router Class Initialized
INFO - 2020-01-31 14:56:29 --> Output Class Initialized
INFO - 2020-01-31 14:56:29 --> Security Class Initialized
DEBUG - 2020-01-31 14:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:56:29 --> Input Class Initialized
INFO - 2020-01-31 14:56:29 --> Language Class Initialized
INFO - 2020-01-31 14:56:29 --> Language Class Initialized
INFO - 2020-01-31 14:56:29 --> Config Class Initialized
INFO - 2020-01-31 14:56:29 --> Loader Class Initialized
INFO - 2020-01-31 14:56:29 --> Helper loaded: url_helper
INFO - 2020-01-31 14:56:29 --> Helper loaded: file_helper
INFO - 2020-01-31 14:56:29 --> Helper loaded: form_helper
INFO - 2020-01-31 14:56:29 --> Helper loaded: my_helper
INFO - 2020-01-31 14:56:29 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:56:29 --> Controller Class Initialized
INFO - 2020-01-31 14:56:50 --> Final output sent to browser
DEBUG - 2020-01-31 14:56:50 --> Total execution time: 21.0631
INFO - 2020-01-31 14:56:54 --> Config Class Initialized
INFO - 2020-01-31 14:56:54 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:56:54 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:56:54 --> Utf8 Class Initialized
INFO - 2020-01-31 14:56:54 --> URI Class Initialized
INFO - 2020-01-31 14:56:54 --> Router Class Initialized
INFO - 2020-01-31 14:56:54 --> Output Class Initialized
INFO - 2020-01-31 14:56:54 --> Security Class Initialized
DEBUG - 2020-01-31 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:56:54 --> Input Class Initialized
INFO - 2020-01-31 14:56:54 --> Language Class Initialized
INFO - 2020-01-31 14:56:54 --> Language Class Initialized
INFO - 2020-01-31 14:56:54 --> Config Class Initialized
INFO - 2020-01-31 14:56:54 --> Loader Class Initialized
INFO - 2020-01-31 14:56:54 --> Helper loaded: url_helper
INFO - 2020-01-31 14:56:54 --> Helper loaded: file_helper
INFO - 2020-01-31 14:56:54 --> Helper loaded: form_helper
INFO - 2020-01-31 14:56:54 --> Helper loaded: my_helper
INFO - 2020-01-31 14:56:54 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:56:54 --> Controller Class Initialized
DEBUG - 2020-01-31 14:56:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 14:56:54 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 14:56:54 --> Final output sent to browser
DEBUG - 2020-01-31 14:56:54 --> Total execution time: 0.4248
INFO - 2020-01-31 14:56:54 --> Config Class Initialized
INFO - 2020-01-31 14:56:54 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:56:54 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:56:54 --> Utf8 Class Initialized
INFO - 2020-01-31 14:56:55 --> URI Class Initialized
INFO - 2020-01-31 14:56:55 --> Router Class Initialized
INFO - 2020-01-31 14:56:55 --> Output Class Initialized
INFO - 2020-01-31 14:56:55 --> Security Class Initialized
DEBUG - 2020-01-31 14:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:56:55 --> Input Class Initialized
INFO - 2020-01-31 14:56:55 --> Language Class Initialized
INFO - 2020-01-31 14:56:55 --> Language Class Initialized
INFO - 2020-01-31 14:56:55 --> Config Class Initialized
INFO - 2020-01-31 14:56:55 --> Loader Class Initialized
INFO - 2020-01-31 14:56:55 --> Helper loaded: url_helper
INFO - 2020-01-31 14:56:55 --> Helper loaded: file_helper
INFO - 2020-01-31 14:56:55 --> Helper loaded: form_helper
INFO - 2020-01-31 14:56:55 --> Helper loaded: my_helper
INFO - 2020-01-31 14:56:55 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:56:55 --> Controller Class Initialized
INFO - 2020-01-31 14:56:57 --> Config Class Initialized
INFO - 2020-01-31 14:56:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:56:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:56:57 --> Utf8 Class Initialized
INFO - 2020-01-31 14:56:57 --> URI Class Initialized
INFO - 2020-01-31 14:56:57 --> Router Class Initialized
INFO - 2020-01-31 14:56:57 --> Output Class Initialized
INFO - 2020-01-31 14:56:57 --> Security Class Initialized
DEBUG - 2020-01-31 14:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:56:57 --> Input Class Initialized
INFO - 2020-01-31 14:56:57 --> Language Class Initialized
INFO - 2020-01-31 14:56:57 --> Language Class Initialized
INFO - 2020-01-31 14:56:57 --> Config Class Initialized
INFO - 2020-01-31 14:56:57 --> Loader Class Initialized
INFO - 2020-01-31 14:56:57 --> Helper loaded: url_helper
INFO - 2020-01-31 14:56:57 --> Helper loaded: file_helper
INFO - 2020-01-31 14:56:57 --> Helper loaded: form_helper
INFO - 2020-01-31 14:56:57 --> Helper loaded: my_helper
INFO - 2020-01-31 14:56:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:56:57 --> Controller Class Initialized
INFO - 2020-01-31 14:56:59 --> Config Class Initialized
INFO - 2020-01-31 14:56:59 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:56:59 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:56:59 --> Utf8 Class Initialized
INFO - 2020-01-31 14:56:59 --> URI Class Initialized
INFO - 2020-01-31 14:56:59 --> Router Class Initialized
INFO - 2020-01-31 14:56:59 --> Output Class Initialized
INFO - 2020-01-31 14:56:59 --> Security Class Initialized
DEBUG - 2020-01-31 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:56:59 --> Input Class Initialized
INFO - 2020-01-31 14:56:59 --> Language Class Initialized
INFO - 2020-01-31 14:56:59 --> Language Class Initialized
INFO - 2020-01-31 14:56:59 --> Config Class Initialized
INFO - 2020-01-31 14:56:59 --> Loader Class Initialized
INFO - 2020-01-31 14:56:59 --> Helper loaded: url_helper
INFO - 2020-01-31 14:56:59 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:00 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:00 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:00 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:00 --> Controller Class Initialized
INFO - 2020-01-31 14:57:07 --> Config Class Initialized
INFO - 2020-01-31 14:57:07 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:07 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:07 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:07 --> URI Class Initialized
INFO - 2020-01-31 14:57:07 --> Router Class Initialized
INFO - 2020-01-31 14:57:07 --> Output Class Initialized
INFO - 2020-01-31 14:57:07 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:07 --> Input Class Initialized
INFO - 2020-01-31 14:57:07 --> Language Class Initialized
INFO - 2020-01-31 14:57:07 --> Language Class Initialized
INFO - 2020-01-31 14:57:07 --> Config Class Initialized
INFO - 2020-01-31 14:57:07 --> Loader Class Initialized
INFO - 2020-01-31 14:57:07 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:07 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:07 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:07 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:07 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:07 --> Controller Class Initialized
INFO - 2020-01-31 14:57:07 --> Final output sent to browser
DEBUG - 2020-01-31 14:57:07 --> Total execution time: 0.4762
INFO - 2020-01-31 14:57:07 --> Config Class Initialized
INFO - 2020-01-31 14:57:07 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:08 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:08 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:08 --> URI Class Initialized
INFO - 2020-01-31 14:57:08 --> Router Class Initialized
INFO - 2020-01-31 14:57:08 --> Output Class Initialized
INFO - 2020-01-31 14:57:08 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:08 --> Input Class Initialized
INFO - 2020-01-31 14:57:08 --> Language Class Initialized
INFO - 2020-01-31 14:57:08 --> Language Class Initialized
INFO - 2020-01-31 14:57:08 --> Config Class Initialized
INFO - 2020-01-31 14:57:08 --> Loader Class Initialized
INFO - 2020-01-31 14:57:08 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:08 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:08 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:08 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:08 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:08 --> Controller Class Initialized
INFO - 2020-01-31 14:57:11 --> Config Class Initialized
INFO - 2020-01-31 14:57:11 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:11 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:12 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:12 --> URI Class Initialized
INFO - 2020-01-31 14:57:12 --> Router Class Initialized
INFO - 2020-01-31 14:57:12 --> Output Class Initialized
INFO - 2020-01-31 14:57:12 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:12 --> Input Class Initialized
INFO - 2020-01-31 14:57:12 --> Language Class Initialized
INFO - 2020-01-31 14:57:12 --> Language Class Initialized
INFO - 2020-01-31 14:57:12 --> Config Class Initialized
INFO - 2020-01-31 14:57:12 --> Loader Class Initialized
INFO - 2020-01-31 14:57:12 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:12 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:12 --> Controller Class Initialized
INFO - 2020-01-31 14:57:12 --> Final output sent to browser
DEBUG - 2020-01-31 14:57:12 --> Total execution time: 0.4706
INFO - 2020-01-31 14:57:12 --> Config Class Initialized
INFO - 2020-01-31 14:57:12 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:12 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:12 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:12 --> URI Class Initialized
INFO - 2020-01-31 14:57:12 --> Router Class Initialized
INFO - 2020-01-31 14:57:12 --> Output Class Initialized
INFO - 2020-01-31 14:57:12 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:12 --> Input Class Initialized
INFO - 2020-01-31 14:57:12 --> Language Class Initialized
INFO - 2020-01-31 14:57:12 --> Language Class Initialized
INFO - 2020-01-31 14:57:12 --> Config Class Initialized
INFO - 2020-01-31 14:57:12 --> Loader Class Initialized
INFO - 2020-01-31 14:57:12 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:12 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:12 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:12 --> Controller Class Initialized
INFO - 2020-01-31 14:57:24 --> Config Class Initialized
INFO - 2020-01-31 14:57:24 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:24 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:24 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:24 --> URI Class Initialized
INFO - 2020-01-31 14:57:24 --> Router Class Initialized
INFO - 2020-01-31 14:57:24 --> Output Class Initialized
INFO - 2020-01-31 14:57:24 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:24 --> Input Class Initialized
INFO - 2020-01-31 14:57:24 --> Language Class Initialized
INFO - 2020-01-31 14:57:24 --> Language Class Initialized
INFO - 2020-01-31 14:57:24 --> Config Class Initialized
INFO - 2020-01-31 14:57:24 --> Loader Class Initialized
INFO - 2020-01-31 14:57:24 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:24 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:24 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:24 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:24 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:24 --> Controller Class Initialized
INFO - 2020-01-31 14:57:24 --> Final output sent to browser
DEBUG - 2020-01-31 14:57:24 --> Total execution time: 0.3525
INFO - 2020-01-31 14:57:27 --> Config Class Initialized
INFO - 2020-01-31 14:57:27 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:27 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:27 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:27 --> URI Class Initialized
INFO - 2020-01-31 14:57:27 --> Router Class Initialized
INFO - 2020-01-31 14:57:27 --> Output Class Initialized
INFO - 2020-01-31 14:57:27 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:27 --> Input Class Initialized
INFO - 2020-01-31 14:57:27 --> Language Class Initialized
INFO - 2020-01-31 14:57:27 --> Language Class Initialized
INFO - 2020-01-31 14:57:27 --> Config Class Initialized
INFO - 2020-01-31 14:57:27 --> Loader Class Initialized
INFO - 2020-01-31 14:57:27 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:27 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:27 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:27 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:27 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:27 --> Controller Class Initialized
INFO - 2020-01-31 14:57:27 --> Final output sent to browser
DEBUG - 2020-01-31 14:57:27 --> Total execution time: 0.3669
INFO - 2020-01-31 14:57:30 --> Config Class Initialized
INFO - 2020-01-31 14:57:30 --> Hooks Class Initialized
DEBUG - 2020-01-31 14:57:30 --> UTF-8 Support Enabled
INFO - 2020-01-31 14:57:30 --> Utf8 Class Initialized
INFO - 2020-01-31 14:57:30 --> URI Class Initialized
INFO - 2020-01-31 14:57:30 --> Router Class Initialized
INFO - 2020-01-31 14:57:30 --> Output Class Initialized
INFO - 2020-01-31 14:57:30 --> Security Class Initialized
DEBUG - 2020-01-31 14:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 14:57:30 --> Input Class Initialized
INFO - 2020-01-31 14:57:30 --> Language Class Initialized
INFO - 2020-01-31 14:57:30 --> Language Class Initialized
INFO - 2020-01-31 14:57:30 --> Config Class Initialized
INFO - 2020-01-31 14:57:30 --> Loader Class Initialized
INFO - 2020-01-31 14:57:30 --> Helper loaded: url_helper
INFO - 2020-01-31 14:57:30 --> Helper loaded: file_helper
INFO - 2020-01-31 14:57:30 --> Helper loaded: form_helper
INFO - 2020-01-31 14:57:30 --> Helper loaded: my_helper
INFO - 2020-01-31 14:57:30 --> Database Driver Class Initialized
DEBUG - 2020-01-31 14:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 14:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 14:57:30 --> Controller Class Initialized
INFO - 2020-01-31 14:57:30 --> Final output sent to browser
DEBUG - 2020-01-31 14:57:30 --> Total execution time: 0.3765
INFO - 2020-01-31 15:01:01 --> Config Class Initialized
INFO - 2020-01-31 15:01:01 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:01:01 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:01:01 --> Utf8 Class Initialized
INFO - 2020-01-31 15:01:01 --> URI Class Initialized
INFO - 2020-01-31 15:01:01 --> Router Class Initialized
INFO - 2020-01-31 15:01:01 --> Output Class Initialized
INFO - 2020-01-31 15:01:01 --> Security Class Initialized
DEBUG - 2020-01-31 15:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:01:01 --> Input Class Initialized
INFO - 2020-01-31 15:01:01 --> Language Class Initialized
INFO - 2020-01-31 15:01:01 --> Language Class Initialized
INFO - 2020-01-31 15:01:01 --> Config Class Initialized
INFO - 2020-01-31 15:01:01 --> Loader Class Initialized
INFO - 2020-01-31 15:01:01 --> Helper loaded: url_helper
INFO - 2020-01-31 15:01:02 --> Helper loaded: file_helper
INFO - 2020-01-31 15:01:02 --> Helper loaded: form_helper
INFO - 2020-01-31 15:01:02 --> Helper loaded: my_helper
INFO - 2020-01-31 15:01:02 --> Database Driver Class Initialized
ERROR - 2020-01-31 15:01:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'db_nilaik13' E:\xampp\htdocs\_2020\nilaik13_ci\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2020-01-31 15:01:02 --> Unable to connect to the database
INFO - 2020-01-31 15:01:02 --> Language file loaded: language/english/db_lang.php
INFO - 2020-01-31 15:01:56 --> Config Class Initialized
INFO - 2020-01-31 15:01:56 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:01:56 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:01:56 --> Utf8 Class Initialized
INFO - 2020-01-31 15:01:56 --> URI Class Initialized
INFO - 2020-01-31 15:01:56 --> Router Class Initialized
INFO - 2020-01-31 15:01:56 --> Output Class Initialized
INFO - 2020-01-31 15:01:56 --> Security Class Initialized
DEBUG - 2020-01-31 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:01:56 --> Input Class Initialized
INFO - 2020-01-31 15:01:56 --> Language Class Initialized
INFO - 2020-01-31 15:01:56 --> Language Class Initialized
INFO - 2020-01-31 15:01:56 --> Config Class Initialized
INFO - 2020-01-31 15:01:56 --> Loader Class Initialized
INFO - 2020-01-31 15:01:56 --> Helper loaded: url_helper
INFO - 2020-01-31 15:01:56 --> Helper loaded: file_helper
INFO - 2020-01-31 15:01:56 --> Helper loaded: form_helper
INFO - 2020-01-31 15:01:56 --> Helper loaded: my_helper
INFO - 2020-01-31 15:01:56 --> Database Driver Class Initialized
DEBUG - 2020-01-31 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 15:01:56 --> Controller Class Initialized
DEBUG - 2020-01-31 15:01:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/data_guru/views/list.php
DEBUG - 2020-01-31 15:01:56 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 15:01:56 --> Final output sent to browser
DEBUG - 2020-01-31 15:01:56 --> Total execution time: 0.5611
INFO - 2020-01-31 15:01:57 --> Config Class Initialized
INFO - 2020-01-31 15:01:57 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:01:57 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:01:57 --> Utf8 Class Initialized
INFO - 2020-01-31 15:01:57 --> URI Class Initialized
INFO - 2020-01-31 15:01:57 --> Router Class Initialized
INFO - 2020-01-31 15:01:57 --> Output Class Initialized
INFO - 2020-01-31 15:01:57 --> Security Class Initialized
DEBUG - 2020-01-31 15:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:01:57 --> Input Class Initialized
INFO - 2020-01-31 15:01:57 --> Language Class Initialized
INFO - 2020-01-31 15:01:57 --> Language Class Initialized
INFO - 2020-01-31 15:01:57 --> Config Class Initialized
INFO - 2020-01-31 15:01:57 --> Loader Class Initialized
INFO - 2020-01-31 15:01:57 --> Helper loaded: url_helper
INFO - 2020-01-31 15:01:57 --> Helper loaded: file_helper
INFO - 2020-01-31 15:01:57 --> Helper loaded: form_helper
INFO - 2020-01-31 15:01:57 --> Helper loaded: my_helper
INFO - 2020-01-31 15:01:57 --> Database Driver Class Initialized
DEBUG - 2020-01-31 15:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 15:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 15:01:57 --> Controller Class Initialized
INFO - 2020-01-31 15:03:30 --> Config Class Initialized
INFO - 2020-01-31 15:03:30 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:03:30 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:03:30 --> Utf8 Class Initialized
INFO - 2020-01-31 15:03:30 --> URI Class Initialized
INFO - 2020-01-31 15:03:30 --> Router Class Initialized
INFO - 2020-01-31 15:03:30 --> Output Class Initialized
INFO - 2020-01-31 15:03:31 --> Security Class Initialized
DEBUG - 2020-01-31 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:03:31 --> Input Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Config Class Initialized
INFO - 2020-01-31 15:03:31 --> Loader Class Initialized
INFO - 2020-01-31 15:03:31 --> Helper loaded: url_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: file_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: form_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: my_helper
INFO - 2020-01-31 15:03:31 --> Database Driver Class Initialized
DEBUG - 2020-01-31 15:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 15:03:31 --> Controller Class Initialized
INFO - 2020-01-31 15:03:31 --> Helper loaded: cookie_helper
INFO - 2020-01-31 15:03:31 --> Config Class Initialized
INFO - 2020-01-31 15:03:31 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:03:31 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:03:31 --> Utf8 Class Initialized
INFO - 2020-01-31 15:03:31 --> URI Class Initialized
INFO - 2020-01-31 15:03:31 --> Router Class Initialized
INFO - 2020-01-31 15:03:31 --> Output Class Initialized
INFO - 2020-01-31 15:03:31 --> Security Class Initialized
DEBUG - 2020-01-31 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:03:31 --> Input Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Config Class Initialized
INFO - 2020-01-31 15:03:31 --> Loader Class Initialized
INFO - 2020-01-31 15:03:31 --> Helper loaded: url_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: file_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: form_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: my_helper
INFO - 2020-01-31 15:03:31 --> Database Driver Class Initialized
DEBUG - 2020-01-31 15:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 15:03:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 15:03:31 --> Controller Class Initialized
INFO - 2020-01-31 15:03:31 --> Config Class Initialized
INFO - 2020-01-31 15:03:31 --> Hooks Class Initialized
DEBUG - 2020-01-31 15:03:31 --> UTF-8 Support Enabled
INFO - 2020-01-31 15:03:31 --> Utf8 Class Initialized
INFO - 2020-01-31 15:03:31 --> URI Class Initialized
INFO - 2020-01-31 15:03:31 --> Router Class Initialized
INFO - 2020-01-31 15:03:31 --> Output Class Initialized
INFO - 2020-01-31 15:03:31 --> Security Class Initialized
DEBUG - 2020-01-31 15:03:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-01-31 15:03:31 --> Input Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Language Class Initialized
INFO - 2020-01-31 15:03:31 --> Config Class Initialized
INFO - 2020-01-31 15:03:31 --> Loader Class Initialized
INFO - 2020-01-31 15:03:31 --> Helper loaded: url_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: file_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: form_helper
INFO - 2020-01-31 15:03:31 --> Helper loaded: my_helper
INFO - 2020-01-31 15:03:31 --> Database Driver Class Initialized
DEBUG - 2020-01-31 15:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-01-31 15:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-01-31 15:03:32 --> Controller Class Initialized
DEBUG - 2020-01-31 15:03:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\modules/login/views/login.php
DEBUG - 2020-01-31 15:03:32 --> File loaded: E:\xampp\htdocs\_2020\nilaik13_ci\application\views\template_utama.php
INFO - 2020-01-31 15:03:32 --> Final output sent to browser
DEBUG - 2020-01-31 15:03:32 --> Total execution time: 0.3971
