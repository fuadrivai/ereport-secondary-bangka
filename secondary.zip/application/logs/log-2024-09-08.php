<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-08 00:20:57 --> Config Class Initialized
INFO - 2024-09-08 00:20:57 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:20:57 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:20:57 --> Utf8 Class Initialized
INFO - 2024-09-08 00:20:57 --> URI Class Initialized
INFO - 2024-09-08 00:20:57 --> Router Class Initialized
INFO - 2024-09-08 00:20:57 --> Output Class Initialized
INFO - 2024-09-08 00:20:57 --> Security Class Initialized
DEBUG - 2024-09-08 00:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:20:57 --> Input Class Initialized
INFO - 2024-09-08 00:20:57 --> Language Class Initialized
INFO - 2024-09-08 00:20:57 --> Language Class Initialized
INFO - 2024-09-08 00:20:57 --> Config Class Initialized
INFO - 2024-09-08 00:20:57 --> Loader Class Initialized
INFO - 2024-09-08 00:20:57 --> Helper loaded: url_helper
INFO - 2024-09-08 00:20:57 --> Helper loaded: file_helper
INFO - 2024-09-08 00:20:57 --> Helper loaded: form_helper
INFO - 2024-09-08 00:20:57 --> Helper loaded: my_helper
INFO - 2024-09-08 00:20:57 --> Database Driver Class Initialized
INFO - 2024-09-08 00:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:20:57 --> Controller Class Initialized
INFO - 2024-09-08 00:20:57 --> Helper loaded: cookie_helper
INFO - 2024-09-08 00:20:57 --> Final output sent to browser
DEBUG - 2024-09-08 00:20:57 --> Total execution time: 0.0545
INFO - 2024-09-08 00:20:59 --> Config Class Initialized
INFO - 2024-09-08 00:20:59 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:20:59 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:20:59 --> Utf8 Class Initialized
INFO - 2024-09-08 00:20:59 --> URI Class Initialized
INFO - 2024-09-08 00:20:59 --> Router Class Initialized
INFO - 2024-09-08 00:20:59 --> Output Class Initialized
INFO - 2024-09-08 00:20:59 --> Security Class Initialized
DEBUG - 2024-09-08 00:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:20:59 --> Input Class Initialized
INFO - 2024-09-08 00:20:59 --> Language Class Initialized
INFO - 2024-09-08 00:20:59 --> Language Class Initialized
INFO - 2024-09-08 00:20:59 --> Config Class Initialized
INFO - 2024-09-08 00:20:59 --> Loader Class Initialized
INFO - 2024-09-08 00:20:59 --> Helper loaded: url_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: file_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: form_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: my_helper
INFO - 2024-09-08 00:20:59 --> Database Driver Class Initialized
INFO - 2024-09-08 00:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:20:59 --> Controller Class Initialized
INFO - 2024-09-08 00:20:59 --> Helper loaded: cookie_helper
INFO - 2024-09-08 00:20:59 --> Config Class Initialized
INFO - 2024-09-08 00:20:59 --> Hooks Class Initialized
DEBUG - 2024-09-08 00:20:59 --> UTF-8 Support Enabled
INFO - 2024-09-08 00:20:59 --> Utf8 Class Initialized
INFO - 2024-09-08 00:20:59 --> URI Class Initialized
INFO - 2024-09-08 00:20:59 --> Router Class Initialized
INFO - 2024-09-08 00:20:59 --> Output Class Initialized
INFO - 2024-09-08 00:20:59 --> Security Class Initialized
DEBUG - 2024-09-08 00:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-08 00:20:59 --> Input Class Initialized
INFO - 2024-09-08 00:20:59 --> Language Class Initialized
INFO - 2024-09-08 00:20:59 --> Language Class Initialized
INFO - 2024-09-08 00:20:59 --> Config Class Initialized
INFO - 2024-09-08 00:20:59 --> Loader Class Initialized
INFO - 2024-09-08 00:20:59 --> Helper loaded: url_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: file_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: form_helper
INFO - 2024-09-08 00:20:59 --> Helper loaded: my_helper
INFO - 2024-09-08 00:20:59 --> Database Driver Class Initialized
INFO - 2024-09-08 00:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-08 00:20:59 --> Controller Class Initialized
DEBUG - 2024-09-08 00:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-08 00:20:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-08 00:20:59 --> Final output sent to browser
DEBUG - 2024-09-08 00:20:59 --> Total execution time: 0.0927
