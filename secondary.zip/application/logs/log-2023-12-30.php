<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:34 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:34 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:34 --> URI Class Initialized
INFO - 2023-12-30 08:42:34 --> Router Class Initialized
INFO - 2023-12-30 08:42:34 --> Output Class Initialized
INFO - 2023-12-30 08:42:34 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:34 --> Input Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Loader Class Initialized
INFO - 2023-12-30 08:42:34 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:34 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:34 --> Controller Class Initialized
INFO - 2023-12-30 08:42:34 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:42:34 --> Final output sent to browser
DEBUG - 2023-12-30 08:42:34 --> Total execution time: 0.0950
INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:34 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:34 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:34 --> URI Class Initialized
INFO - 2023-12-30 08:42:34 --> Router Class Initialized
INFO - 2023-12-30 08:42:34 --> Output Class Initialized
INFO - 2023-12-30 08:42:34 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:34 --> Input Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Loader Class Initialized
INFO - 2023-12-30 08:42:34 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:34 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:34 --> Controller Class Initialized
INFO - 2023-12-30 08:42:34 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:34 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:34 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:34 --> URI Class Initialized
INFO - 2023-12-30 08:42:34 --> Router Class Initialized
INFO - 2023-12-30 08:42:34 --> Output Class Initialized
INFO - 2023-12-30 08:42:34 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:34 --> Input Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Language Class Initialized
INFO - 2023-12-30 08:42:34 --> Config Class Initialized
INFO - 2023-12-30 08:42:34 --> Loader Class Initialized
INFO - 2023-12-30 08:42:34 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:34 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:34 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:34 --> Controller Class Initialized
DEBUG - 2023-12-30 08:42:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-30 08:42:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-30 08:42:34 --> Final output sent to browser
DEBUG - 2023-12-30 08:42:34 --> Total execution time: 0.0517
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:35 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:35 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:35 --> URI Class Initialized
INFO - 2023-12-30 08:42:35 --> Router Class Initialized
INFO - 2023-12-30 08:42:35 --> Output Class Initialized
INFO - 2023-12-30 08:42:35 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:35 --> Input Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Loader Class Initialized
INFO - 2023-12-30 08:42:35 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:35 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:35 --> Controller Class Initialized
INFO - 2023-12-30 08:42:35 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:42:35 --> Final output sent to browser
DEBUG - 2023-12-30 08:42:35 --> Total execution time: 0.0308
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:35 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:35 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:35 --> URI Class Initialized
INFO - 2023-12-30 08:42:35 --> Router Class Initialized
INFO - 2023-12-30 08:42:35 --> Output Class Initialized
INFO - 2023-12-30 08:42:35 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:35 --> Input Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Loader Class Initialized
INFO - 2023-12-30 08:42:35 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:35 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:35 --> Controller Class Initialized
INFO - 2023-12-30 08:42:35 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:35 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:35 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:35 --> URI Class Initialized
INFO - 2023-12-30 08:42:35 --> Router Class Initialized
INFO - 2023-12-30 08:42:35 --> Output Class Initialized
INFO - 2023-12-30 08:42:35 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:35 --> Input Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Language Class Initialized
INFO - 2023-12-30 08:42:35 --> Config Class Initialized
INFO - 2023-12-30 08:42:35 --> Loader Class Initialized
INFO - 2023-12-30 08:42:35 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:35 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:35 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:35 --> Controller Class Initialized
INFO - 2023-12-30 08:42:36 --> Helper loaded: cookie_helper
INFO - 2023-12-30 08:42:36 --> Config Class Initialized
INFO - 2023-12-30 08:42:36 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:36 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:36 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:36 --> URI Class Initialized
INFO - 2023-12-30 08:42:36 --> Router Class Initialized
INFO - 2023-12-30 08:42:36 --> Output Class Initialized
INFO - 2023-12-30 08:42:36 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:36 --> Input Class Initialized
INFO - 2023-12-30 08:42:36 --> Language Class Initialized
INFO - 2023-12-30 08:42:36 --> Language Class Initialized
INFO - 2023-12-30 08:42:36 --> Config Class Initialized
INFO - 2023-12-30 08:42:36 --> Loader Class Initialized
INFO - 2023-12-30 08:42:36 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:36 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:36 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:36 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:36 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:36 --> Controller Class Initialized
DEBUG - 2023-12-30 08:42:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-30 08:42:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-30 08:42:36 --> Final output sent to browser
DEBUG - 2023-12-30 08:42:36 --> Total execution time: 0.0622
INFO - 2023-12-30 08:42:42 --> Config Class Initialized
INFO - 2023-12-30 08:42:42 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:42:42 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:42:42 --> Utf8 Class Initialized
INFO - 2023-12-30 08:42:42 --> URI Class Initialized
INFO - 2023-12-30 08:42:42 --> Router Class Initialized
INFO - 2023-12-30 08:42:42 --> Output Class Initialized
INFO - 2023-12-30 08:42:42 --> Security Class Initialized
DEBUG - 2023-12-30 08:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:42:42 --> Input Class Initialized
INFO - 2023-12-30 08:42:42 --> Language Class Initialized
INFO - 2023-12-30 08:42:42 --> Language Class Initialized
INFO - 2023-12-30 08:42:42 --> Config Class Initialized
INFO - 2023-12-30 08:42:42 --> Loader Class Initialized
INFO - 2023-12-30 08:42:42 --> Helper loaded: url_helper
INFO - 2023-12-30 08:42:42 --> Helper loaded: file_helper
INFO - 2023-12-30 08:42:42 --> Helper loaded: form_helper
INFO - 2023-12-30 08:42:42 --> Helper loaded: my_helper
INFO - 2023-12-30 08:42:42 --> Database Driver Class Initialized
INFO - 2023-12-30 08:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:42:42 --> Controller Class Initialized
DEBUG - 2023-12-30 08:42:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-30 08:42:46 --> Final output sent to browser
DEBUG - 2023-12-30 08:42:46 --> Total execution time: 4.6606
INFO - 2023-12-30 08:45:04 --> Config Class Initialized
INFO - 2023-12-30 08:45:04 --> Hooks Class Initialized
DEBUG - 2023-12-30 08:45:04 --> UTF-8 Support Enabled
INFO - 2023-12-30 08:45:04 --> Utf8 Class Initialized
INFO - 2023-12-30 08:45:04 --> URI Class Initialized
INFO - 2023-12-30 08:45:04 --> Router Class Initialized
INFO - 2023-12-30 08:45:04 --> Output Class Initialized
INFO - 2023-12-30 08:45:04 --> Security Class Initialized
DEBUG - 2023-12-30 08:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-30 08:45:04 --> Input Class Initialized
INFO - 2023-12-30 08:45:04 --> Language Class Initialized
INFO - 2023-12-30 08:45:04 --> Language Class Initialized
INFO - 2023-12-30 08:45:04 --> Config Class Initialized
INFO - 2023-12-30 08:45:04 --> Loader Class Initialized
INFO - 2023-12-30 08:45:04 --> Helper loaded: url_helper
INFO - 2023-12-30 08:45:04 --> Helper loaded: file_helper
INFO - 2023-12-30 08:45:05 --> Helper loaded: form_helper
INFO - 2023-12-30 08:45:05 --> Helper loaded: my_helper
INFO - 2023-12-30 08:45:05 --> Database Driver Class Initialized
INFO - 2023-12-30 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-30 08:45:05 --> Controller Class Initialized
DEBUG - 2023-12-30 08:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-30 08:45:07 --> Final output sent to browser
DEBUG - 2023-12-30 08:45:07 --> Total execution time: 2.0918
