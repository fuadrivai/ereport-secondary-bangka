<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-02-03 02:10:46 --> Config Class Initialized
INFO - 2020-02-03 02:10:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:10:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:10:46 --> Utf8 Class Initialized
INFO - 2020-02-03 02:10:47 --> URI Class Initialized
DEBUG - 2020-02-03 02:10:47 --> No URI present. Default controller set.
INFO - 2020-02-03 02:10:47 --> Router Class Initialized
INFO - 2020-02-03 02:10:47 --> Output Class Initialized
INFO - 2020-02-03 02:10:47 --> Security Class Initialized
DEBUG - 2020-02-03 02:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:10:47 --> Input Class Initialized
INFO - 2020-02-03 02:10:47 --> Language Class Initialized
INFO - 2020-02-03 02:10:47 --> Language Class Initialized
INFO - 2020-02-03 02:10:47 --> Config Class Initialized
INFO - 2020-02-03 02:10:47 --> Loader Class Initialized
INFO - 2020-02-03 02:10:47 --> Helper loaded: url_helper
INFO - 2020-02-03 02:10:47 --> Helper loaded: file_helper
INFO - 2020-02-03 02:10:47 --> Helper loaded: form_helper
INFO - 2020-02-03 02:10:47 --> Helper loaded: my_helper
INFO - 2020-02-03 02:10:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:10:47 --> Controller Class Initialized
INFO - 2020-02-03 02:10:47 --> Config Class Initialized
INFO - 2020-02-03 02:10:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:10:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:10:47 --> Utf8 Class Initialized
INFO - 2020-02-03 02:10:47 --> URI Class Initialized
INFO - 2020-02-03 02:10:47 --> Router Class Initialized
INFO - 2020-02-03 02:10:47 --> Output Class Initialized
INFO - 2020-02-03 02:10:47 --> Security Class Initialized
DEBUG - 2020-02-03 02:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:10:47 --> Input Class Initialized
INFO - 2020-02-03 02:10:47 --> Language Class Initialized
INFO - 2020-02-03 02:10:47 --> Language Class Initialized
INFO - 2020-02-03 02:10:47 --> Config Class Initialized
INFO - 2020-02-03 02:10:47 --> Loader Class Initialized
INFO - 2020-02-03 02:10:48 --> Helper loaded: url_helper
INFO - 2020-02-03 02:10:48 --> Helper loaded: file_helper
INFO - 2020-02-03 02:10:48 --> Helper loaded: form_helper
INFO - 2020-02-03 02:10:48 --> Helper loaded: my_helper
INFO - 2020-02-03 02:10:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:10:48 --> Controller Class Initialized
DEBUG - 2020-02-03 02:10:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:10:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:10:48 --> Final output sent to browser
DEBUG - 2020-02-03 02:10:48 --> Total execution time: 0.5355
INFO - 2020-02-03 02:13:31 --> Config Class Initialized
INFO - 2020-02-03 02:13:31 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:13:31 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:13:31 --> Utf8 Class Initialized
INFO - 2020-02-03 02:13:31 --> URI Class Initialized
INFO - 2020-02-03 02:13:31 --> Router Class Initialized
INFO - 2020-02-03 02:13:31 --> Output Class Initialized
INFO - 2020-02-03 02:13:31 --> Security Class Initialized
DEBUG - 2020-02-03 02:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:13:31 --> Input Class Initialized
INFO - 2020-02-03 02:13:31 --> Language Class Initialized
INFO - 2020-02-03 02:13:31 --> Language Class Initialized
INFO - 2020-02-03 02:13:31 --> Config Class Initialized
INFO - 2020-02-03 02:13:31 --> Loader Class Initialized
INFO - 2020-02-03 02:13:31 --> Helper loaded: url_helper
INFO - 2020-02-03 02:13:31 --> Helper loaded: file_helper
INFO - 2020-02-03 02:13:31 --> Helper loaded: form_helper
INFO - 2020-02-03 02:13:31 --> Helper loaded: my_helper
INFO - 2020-02-03 02:13:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:13:31 --> Controller Class Initialized
DEBUG - 2020-02-03 02:13:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:13:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:13:31 --> Final output sent to browser
DEBUG - 2020-02-03 02:13:31 --> Total execution time: 0.2820
INFO - 2020-02-03 02:13:45 --> Config Class Initialized
INFO - 2020-02-03 02:13:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:13:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:13:45 --> Utf8 Class Initialized
INFO - 2020-02-03 02:13:45 --> URI Class Initialized
INFO - 2020-02-03 02:13:45 --> Router Class Initialized
INFO - 2020-02-03 02:13:45 --> Output Class Initialized
INFO - 2020-02-03 02:13:45 --> Security Class Initialized
DEBUG - 2020-02-03 02:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:13:45 --> Input Class Initialized
INFO - 2020-02-03 02:13:45 --> Language Class Initialized
INFO - 2020-02-03 02:13:45 --> Language Class Initialized
INFO - 2020-02-03 02:13:45 --> Config Class Initialized
INFO - 2020-02-03 02:13:45 --> Loader Class Initialized
INFO - 2020-02-03 02:13:45 --> Helper loaded: url_helper
INFO - 2020-02-03 02:13:45 --> Helper loaded: file_helper
INFO - 2020-02-03 02:13:45 --> Helper loaded: form_helper
INFO - 2020-02-03 02:13:45 --> Helper loaded: my_helper
INFO - 2020-02-03 02:13:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:13:45 --> Controller Class Initialized
DEBUG - 2020-02-03 02:13:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:13:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:13:45 --> Final output sent to browser
DEBUG - 2020-02-03 02:13:45 --> Total execution time: 0.2807
INFO - 2020-02-03 02:14:33 --> Config Class Initialized
INFO - 2020-02-03 02:14:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:14:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:14:33 --> Utf8 Class Initialized
INFO - 2020-02-03 02:14:33 --> URI Class Initialized
INFO - 2020-02-03 02:14:33 --> Router Class Initialized
INFO - 2020-02-03 02:14:33 --> Output Class Initialized
INFO - 2020-02-03 02:14:33 --> Security Class Initialized
DEBUG - 2020-02-03 02:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:14:34 --> Input Class Initialized
INFO - 2020-02-03 02:14:34 --> Language Class Initialized
INFO - 2020-02-03 02:14:34 --> Language Class Initialized
INFO - 2020-02-03 02:14:34 --> Config Class Initialized
INFO - 2020-02-03 02:14:34 --> Loader Class Initialized
INFO - 2020-02-03 02:14:34 --> Helper loaded: url_helper
INFO - 2020-02-03 02:14:34 --> Helper loaded: file_helper
INFO - 2020-02-03 02:14:34 --> Helper loaded: form_helper
INFO - 2020-02-03 02:14:34 --> Helper loaded: my_helper
INFO - 2020-02-03 02:14:34 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:14:34 --> Controller Class Initialized
DEBUG - 2020-02-03 02:14:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:14:34 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:14:34 --> Final output sent to browser
DEBUG - 2020-02-03 02:14:34 --> Total execution time: 0.2810
INFO - 2020-02-03 02:18:13 --> Config Class Initialized
INFO - 2020-02-03 02:18:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:18:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:18:13 --> Utf8 Class Initialized
INFO - 2020-02-03 02:18:13 --> URI Class Initialized
INFO - 2020-02-03 02:18:13 --> Router Class Initialized
INFO - 2020-02-03 02:18:13 --> Output Class Initialized
INFO - 2020-02-03 02:18:13 --> Security Class Initialized
DEBUG - 2020-02-03 02:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:18:13 --> Input Class Initialized
INFO - 2020-02-03 02:18:13 --> Language Class Initialized
INFO - 2020-02-03 02:18:13 --> Language Class Initialized
INFO - 2020-02-03 02:18:13 --> Config Class Initialized
INFO - 2020-02-03 02:18:13 --> Loader Class Initialized
INFO - 2020-02-03 02:18:13 --> Helper loaded: url_helper
INFO - 2020-02-03 02:18:13 --> Helper loaded: file_helper
INFO - 2020-02-03 02:18:13 --> Helper loaded: form_helper
INFO - 2020-02-03 02:18:13 --> Helper loaded: my_helper
INFO - 2020-02-03 02:18:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:18:13 --> Controller Class Initialized
DEBUG - 2020-02-03 02:18:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:18:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:18:13 --> Final output sent to browser
DEBUG - 2020-02-03 02:18:13 --> Total execution time: 0.2901
INFO - 2020-02-03 02:18:40 --> Config Class Initialized
INFO - 2020-02-03 02:18:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:18:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:18:40 --> Utf8 Class Initialized
INFO - 2020-02-03 02:18:40 --> URI Class Initialized
INFO - 2020-02-03 02:18:40 --> Router Class Initialized
INFO - 2020-02-03 02:18:40 --> Output Class Initialized
INFO - 2020-02-03 02:18:40 --> Security Class Initialized
DEBUG - 2020-02-03 02:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:18:40 --> Input Class Initialized
INFO - 2020-02-03 02:18:40 --> Language Class Initialized
INFO - 2020-02-03 02:18:40 --> Language Class Initialized
INFO - 2020-02-03 02:18:40 --> Config Class Initialized
INFO - 2020-02-03 02:18:40 --> Loader Class Initialized
INFO - 2020-02-03 02:18:40 --> Helper loaded: url_helper
INFO - 2020-02-03 02:18:40 --> Helper loaded: file_helper
INFO - 2020-02-03 02:18:40 --> Helper loaded: form_helper
INFO - 2020-02-03 02:18:40 --> Helper loaded: my_helper
INFO - 2020-02-03 02:18:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:18:40 --> Controller Class Initialized
DEBUG - 2020-02-03 02:18:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:18:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:18:40 --> Final output sent to browser
DEBUG - 2020-02-03 02:18:40 --> Total execution time: 0.3174
INFO - 2020-02-03 02:19:10 --> Config Class Initialized
INFO - 2020-02-03 02:19:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:19:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:19:10 --> Utf8 Class Initialized
INFO - 2020-02-03 02:19:10 --> URI Class Initialized
INFO - 2020-02-03 02:19:10 --> Router Class Initialized
INFO - 2020-02-03 02:19:10 --> Output Class Initialized
INFO - 2020-02-03 02:19:10 --> Security Class Initialized
DEBUG - 2020-02-03 02:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:19:10 --> Input Class Initialized
INFO - 2020-02-03 02:19:10 --> Language Class Initialized
INFO - 2020-02-03 02:19:10 --> Language Class Initialized
INFO - 2020-02-03 02:19:10 --> Config Class Initialized
INFO - 2020-02-03 02:19:10 --> Loader Class Initialized
INFO - 2020-02-03 02:19:10 --> Helper loaded: url_helper
INFO - 2020-02-03 02:19:10 --> Helper loaded: file_helper
INFO - 2020-02-03 02:19:10 --> Helper loaded: form_helper
INFO - 2020-02-03 02:19:10 --> Helper loaded: my_helper
INFO - 2020-02-03 02:19:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:19:10 --> Controller Class Initialized
DEBUG - 2020-02-03 02:19:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:19:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:19:10 --> Final output sent to browser
DEBUG - 2020-02-03 02:19:10 --> Total execution time: 0.2808
INFO - 2020-02-03 02:19:12 --> Config Class Initialized
INFO - 2020-02-03 02:19:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:19:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:19:12 --> Utf8 Class Initialized
INFO - 2020-02-03 02:19:12 --> URI Class Initialized
INFO - 2020-02-03 02:19:12 --> Router Class Initialized
INFO - 2020-02-03 02:19:12 --> Output Class Initialized
INFO - 2020-02-03 02:19:12 --> Security Class Initialized
DEBUG - 2020-02-03 02:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:19:12 --> Input Class Initialized
INFO - 2020-02-03 02:19:12 --> Language Class Initialized
INFO - 2020-02-03 02:19:12 --> Language Class Initialized
INFO - 2020-02-03 02:19:12 --> Config Class Initialized
INFO - 2020-02-03 02:19:12 --> Loader Class Initialized
INFO - 2020-02-03 02:19:12 --> Helper loaded: url_helper
INFO - 2020-02-03 02:19:12 --> Helper loaded: file_helper
INFO - 2020-02-03 02:19:12 --> Helper loaded: form_helper
INFO - 2020-02-03 02:19:12 --> Helper loaded: my_helper
INFO - 2020-02-03 02:19:12 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:19:12 --> Controller Class Initialized
DEBUG - 2020-02-03 02:19:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:19:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:19:12 --> Final output sent to browser
DEBUG - 2020-02-03 02:19:12 --> Total execution time: 0.3224
INFO - 2020-02-03 02:19:17 --> Config Class Initialized
INFO - 2020-02-03 02:19:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:19:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:19:17 --> Utf8 Class Initialized
INFO - 2020-02-03 02:19:17 --> URI Class Initialized
INFO - 2020-02-03 02:19:17 --> Router Class Initialized
INFO - 2020-02-03 02:19:17 --> Output Class Initialized
INFO - 2020-02-03 02:19:17 --> Security Class Initialized
DEBUG - 2020-02-03 02:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:19:17 --> Input Class Initialized
INFO - 2020-02-03 02:19:17 --> Language Class Initialized
INFO - 2020-02-03 02:19:17 --> Language Class Initialized
INFO - 2020-02-03 02:19:17 --> Config Class Initialized
INFO - 2020-02-03 02:19:17 --> Loader Class Initialized
INFO - 2020-02-03 02:19:17 --> Helper loaded: url_helper
INFO - 2020-02-03 02:19:17 --> Helper loaded: file_helper
INFO - 2020-02-03 02:19:17 --> Helper loaded: form_helper
INFO - 2020-02-03 02:19:18 --> Helper loaded: my_helper
INFO - 2020-02-03 02:19:18 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:19:18 --> Controller Class Initialized
DEBUG - 2020-02-03 02:19:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:19:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:19:18 --> Final output sent to browser
DEBUG - 2020-02-03 02:19:18 --> Total execution time: 0.2689
INFO - 2020-02-03 02:19:44 --> Config Class Initialized
INFO - 2020-02-03 02:19:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:19:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:19:44 --> Utf8 Class Initialized
INFO - 2020-02-03 02:19:44 --> URI Class Initialized
INFO - 2020-02-03 02:19:44 --> Router Class Initialized
INFO - 2020-02-03 02:19:44 --> Output Class Initialized
INFO - 2020-02-03 02:19:44 --> Security Class Initialized
DEBUG - 2020-02-03 02:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:19:44 --> Input Class Initialized
INFO - 2020-02-03 02:19:44 --> Language Class Initialized
INFO - 2020-02-03 02:19:44 --> Language Class Initialized
INFO - 2020-02-03 02:19:44 --> Config Class Initialized
INFO - 2020-02-03 02:19:44 --> Loader Class Initialized
INFO - 2020-02-03 02:19:44 --> Helper loaded: url_helper
INFO - 2020-02-03 02:19:45 --> Helper loaded: file_helper
INFO - 2020-02-03 02:19:45 --> Helper loaded: form_helper
INFO - 2020-02-03 02:19:45 --> Helper loaded: my_helper
INFO - 2020-02-03 02:19:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:19:45 --> Controller Class Initialized
DEBUG - 2020-02-03 02:19:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:19:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:19:45 --> Final output sent to browser
DEBUG - 2020-02-03 02:19:45 --> Total execution time: 0.2867
INFO - 2020-02-03 02:19:55 --> Config Class Initialized
INFO - 2020-02-03 02:19:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:19:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:19:55 --> Utf8 Class Initialized
INFO - 2020-02-03 02:19:55 --> URI Class Initialized
INFO - 2020-02-03 02:19:55 --> Router Class Initialized
INFO - 2020-02-03 02:19:55 --> Output Class Initialized
INFO - 2020-02-03 02:19:55 --> Security Class Initialized
DEBUG - 2020-02-03 02:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:19:55 --> Input Class Initialized
INFO - 2020-02-03 02:19:55 --> Language Class Initialized
INFO - 2020-02-03 02:19:55 --> Language Class Initialized
INFO - 2020-02-03 02:19:55 --> Config Class Initialized
INFO - 2020-02-03 02:19:55 --> Loader Class Initialized
INFO - 2020-02-03 02:19:55 --> Helper loaded: url_helper
INFO - 2020-02-03 02:19:55 --> Helper loaded: file_helper
INFO - 2020-02-03 02:19:55 --> Helper loaded: form_helper
INFO - 2020-02-03 02:19:55 --> Helper loaded: my_helper
INFO - 2020-02-03 02:19:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:19:55 --> Controller Class Initialized
DEBUG - 2020-02-03 02:19:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 02:19:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:19:55 --> Final output sent to browser
DEBUG - 2020-02-03 02:19:55 --> Total execution time: 0.2952
INFO - 2020-02-03 02:20:09 --> Config Class Initialized
INFO - 2020-02-03 02:20:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:20:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:20:09 --> Utf8 Class Initialized
INFO - 2020-02-03 02:20:09 --> URI Class Initialized
INFO - 2020-02-03 02:20:09 --> Router Class Initialized
INFO - 2020-02-03 02:20:09 --> Output Class Initialized
INFO - 2020-02-03 02:20:09 --> Security Class Initialized
DEBUG - 2020-02-03 02:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:20:09 --> Input Class Initialized
INFO - 2020-02-03 02:20:10 --> Language Class Initialized
INFO - 2020-02-03 02:20:10 --> Language Class Initialized
INFO - 2020-02-03 02:20:10 --> Config Class Initialized
INFO - 2020-02-03 02:20:10 --> Loader Class Initialized
INFO - 2020-02-03 02:20:10 --> Helper loaded: url_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: file_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: form_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: my_helper
INFO - 2020-02-03 02:20:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:20:10 --> Controller Class Initialized
INFO - 2020-02-03 02:20:10 --> Helper loaded: cookie_helper
INFO - 2020-02-03 02:20:10 --> Final output sent to browser
DEBUG - 2020-02-03 02:20:10 --> Total execution time: 0.3074
INFO - 2020-02-03 02:20:10 --> Config Class Initialized
INFO - 2020-02-03 02:20:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:20:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:20:10 --> Utf8 Class Initialized
INFO - 2020-02-03 02:20:10 --> URI Class Initialized
INFO - 2020-02-03 02:20:10 --> Router Class Initialized
INFO - 2020-02-03 02:20:10 --> Output Class Initialized
INFO - 2020-02-03 02:20:10 --> Security Class Initialized
DEBUG - 2020-02-03 02:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:20:10 --> Input Class Initialized
INFO - 2020-02-03 02:20:10 --> Language Class Initialized
INFO - 2020-02-03 02:20:10 --> Language Class Initialized
INFO - 2020-02-03 02:20:10 --> Config Class Initialized
INFO - 2020-02-03 02:20:10 --> Loader Class Initialized
INFO - 2020-02-03 02:20:10 --> Helper loaded: url_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: file_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: form_helper
INFO - 2020-02-03 02:20:10 --> Helper loaded: my_helper
INFO - 2020-02-03 02:20:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:20:10 --> Controller Class Initialized
DEBUG - 2020-02-03 02:20:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:20:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:20:10 --> Final output sent to browser
DEBUG - 2020-02-03 02:20:10 --> Total execution time: 0.3353
INFO - 2020-02-03 02:20:18 --> Config Class Initialized
INFO - 2020-02-03 02:20:18 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:20:18 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:20:18 --> Utf8 Class Initialized
INFO - 2020-02-03 02:20:18 --> URI Class Initialized
INFO - 2020-02-03 02:20:18 --> Router Class Initialized
INFO - 2020-02-03 02:20:18 --> Output Class Initialized
INFO - 2020-02-03 02:20:18 --> Security Class Initialized
DEBUG - 2020-02-03 02:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:20:18 --> Input Class Initialized
INFO - 2020-02-03 02:20:18 --> Language Class Initialized
INFO - 2020-02-03 02:20:18 --> Language Class Initialized
INFO - 2020-02-03 02:20:18 --> Config Class Initialized
INFO - 2020-02-03 02:20:18 --> Loader Class Initialized
INFO - 2020-02-03 02:20:18 --> Helper loaded: url_helper
INFO - 2020-02-03 02:20:18 --> Helper loaded: file_helper
INFO - 2020-02-03 02:20:18 --> Helper loaded: form_helper
INFO - 2020-02-03 02:20:18 --> Helper loaded: my_helper
INFO - 2020-02-03 02:20:18 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:20:18 --> Controller Class Initialized
DEBUG - 2020-02-03 02:20:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-03 02:20:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:20:18 --> Final output sent to browser
DEBUG - 2020-02-03 02:20:18 --> Total execution time: 0.3813
INFO - 2020-02-03 02:20:19 --> Config Class Initialized
INFO - 2020-02-03 02:20:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:20:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:20:19 --> Utf8 Class Initialized
INFO - 2020-02-03 02:20:19 --> URI Class Initialized
INFO - 2020-02-03 02:20:19 --> Router Class Initialized
INFO - 2020-02-03 02:20:19 --> Output Class Initialized
INFO - 2020-02-03 02:20:19 --> Security Class Initialized
DEBUG - 2020-02-03 02:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:20:19 --> Input Class Initialized
INFO - 2020-02-03 02:20:19 --> Language Class Initialized
INFO - 2020-02-03 02:20:19 --> Language Class Initialized
INFO - 2020-02-03 02:20:19 --> Config Class Initialized
INFO - 2020-02-03 02:20:19 --> Loader Class Initialized
INFO - 2020-02-03 02:20:19 --> Helper loaded: url_helper
INFO - 2020-02-03 02:20:19 --> Helper loaded: file_helper
INFO - 2020-02-03 02:20:19 --> Helper loaded: form_helper
INFO - 2020-02-03 02:20:19 --> Helper loaded: my_helper
INFO - 2020-02-03 02:20:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:20:19 --> Controller Class Initialized
INFO - 2020-02-03 02:20:22 --> Config Class Initialized
INFO - 2020-02-03 02:20:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:20:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:20:22 --> Utf8 Class Initialized
INFO - 2020-02-03 02:20:22 --> URI Class Initialized
DEBUG - 2020-02-03 02:20:22 --> No URI present. Default controller set.
INFO - 2020-02-03 02:20:22 --> Router Class Initialized
INFO - 2020-02-03 02:20:22 --> Output Class Initialized
INFO - 2020-02-03 02:20:22 --> Security Class Initialized
DEBUG - 2020-02-03 02:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:20:22 --> Input Class Initialized
INFO - 2020-02-03 02:20:22 --> Language Class Initialized
INFO - 2020-02-03 02:20:22 --> Language Class Initialized
INFO - 2020-02-03 02:20:22 --> Config Class Initialized
INFO - 2020-02-03 02:20:22 --> Loader Class Initialized
INFO - 2020-02-03 02:20:22 --> Helper loaded: url_helper
INFO - 2020-02-03 02:20:22 --> Helper loaded: file_helper
INFO - 2020-02-03 02:20:22 --> Helper loaded: form_helper
INFO - 2020-02-03 02:20:22 --> Helper loaded: my_helper
INFO - 2020-02-03 02:20:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:20:22 --> Controller Class Initialized
DEBUG - 2020-02-03 02:20:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:20:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:20:22 --> Final output sent to browser
DEBUG - 2020-02-03 02:20:22 --> Total execution time: 0.3622
INFO - 2020-02-03 02:21:30 --> Config Class Initialized
INFO - 2020-02-03 02:21:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:21:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:21:30 --> Utf8 Class Initialized
INFO - 2020-02-03 02:21:30 --> URI Class Initialized
DEBUG - 2020-02-03 02:21:30 --> No URI present. Default controller set.
INFO - 2020-02-03 02:21:30 --> Router Class Initialized
INFO - 2020-02-03 02:21:30 --> Output Class Initialized
INFO - 2020-02-03 02:21:30 --> Security Class Initialized
DEBUG - 2020-02-03 02:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:21:30 --> Input Class Initialized
INFO - 2020-02-03 02:21:30 --> Language Class Initialized
INFO - 2020-02-03 02:21:30 --> Language Class Initialized
INFO - 2020-02-03 02:21:30 --> Config Class Initialized
INFO - 2020-02-03 02:21:30 --> Loader Class Initialized
INFO - 2020-02-03 02:21:30 --> Helper loaded: url_helper
INFO - 2020-02-03 02:21:30 --> Helper loaded: file_helper
INFO - 2020-02-03 02:21:30 --> Helper loaded: form_helper
INFO - 2020-02-03 02:21:30 --> Helper loaded: my_helper
INFO - 2020-02-03 02:21:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:21:30 --> Controller Class Initialized
DEBUG - 2020-02-03 02:21:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:21:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:21:30 --> Final output sent to browser
DEBUG - 2020-02-03 02:21:30 --> Total execution time: 0.3090
INFO - 2020-02-03 02:21:51 --> Config Class Initialized
INFO - 2020-02-03 02:21:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:21:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:21:51 --> Utf8 Class Initialized
INFO - 2020-02-03 02:21:51 --> URI Class Initialized
DEBUG - 2020-02-03 02:21:51 --> No URI present. Default controller set.
INFO - 2020-02-03 02:21:51 --> Router Class Initialized
INFO - 2020-02-03 02:21:51 --> Output Class Initialized
INFO - 2020-02-03 02:21:51 --> Security Class Initialized
DEBUG - 2020-02-03 02:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:21:51 --> Input Class Initialized
INFO - 2020-02-03 02:21:51 --> Language Class Initialized
INFO - 2020-02-03 02:21:51 --> Language Class Initialized
INFO - 2020-02-03 02:21:51 --> Config Class Initialized
INFO - 2020-02-03 02:21:51 --> Loader Class Initialized
INFO - 2020-02-03 02:21:51 --> Helper loaded: url_helper
INFO - 2020-02-03 02:21:51 --> Helper loaded: file_helper
INFO - 2020-02-03 02:21:51 --> Helper loaded: form_helper
INFO - 2020-02-03 02:21:51 --> Helper loaded: my_helper
INFO - 2020-02-03 02:21:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:21:51 --> Controller Class Initialized
DEBUG - 2020-02-03 02:21:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:21:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:21:51 --> Final output sent to browser
DEBUG - 2020-02-03 02:21:51 --> Total execution time: 0.3093
INFO - 2020-02-03 02:21:58 --> Config Class Initialized
INFO - 2020-02-03 02:21:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:21:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:21:58 --> Utf8 Class Initialized
INFO - 2020-02-03 02:21:58 --> URI Class Initialized
DEBUG - 2020-02-03 02:21:58 --> No URI present. Default controller set.
INFO - 2020-02-03 02:21:58 --> Router Class Initialized
INFO - 2020-02-03 02:21:58 --> Output Class Initialized
INFO - 2020-02-03 02:21:58 --> Security Class Initialized
DEBUG - 2020-02-03 02:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:21:58 --> Input Class Initialized
INFO - 2020-02-03 02:21:58 --> Language Class Initialized
INFO - 2020-02-03 02:21:58 --> Language Class Initialized
INFO - 2020-02-03 02:21:58 --> Config Class Initialized
INFO - 2020-02-03 02:21:58 --> Loader Class Initialized
INFO - 2020-02-03 02:21:58 --> Helper loaded: url_helper
INFO - 2020-02-03 02:21:58 --> Helper loaded: file_helper
INFO - 2020-02-03 02:21:58 --> Helper loaded: form_helper
INFO - 2020-02-03 02:21:58 --> Helper loaded: my_helper
INFO - 2020-02-03 02:21:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:21:58 --> Controller Class Initialized
DEBUG - 2020-02-03 02:21:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:21:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:21:58 --> Final output sent to browser
DEBUG - 2020-02-03 02:21:58 --> Total execution time: 0.3289
INFO - 2020-02-03 02:22:07 --> Config Class Initialized
INFO - 2020-02-03 02:22:07 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:22:07 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:22:07 --> Utf8 Class Initialized
INFO - 2020-02-03 02:22:07 --> URI Class Initialized
DEBUG - 2020-02-03 02:22:08 --> No URI present. Default controller set.
INFO - 2020-02-03 02:22:08 --> Router Class Initialized
INFO - 2020-02-03 02:22:08 --> Output Class Initialized
INFO - 2020-02-03 02:22:08 --> Security Class Initialized
DEBUG - 2020-02-03 02:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:22:08 --> Input Class Initialized
INFO - 2020-02-03 02:22:08 --> Language Class Initialized
INFO - 2020-02-03 02:22:08 --> Language Class Initialized
INFO - 2020-02-03 02:22:08 --> Config Class Initialized
INFO - 2020-02-03 02:22:08 --> Loader Class Initialized
INFO - 2020-02-03 02:22:08 --> Helper loaded: url_helper
INFO - 2020-02-03 02:22:08 --> Helper loaded: file_helper
INFO - 2020-02-03 02:22:08 --> Helper loaded: form_helper
INFO - 2020-02-03 02:22:08 --> Helper loaded: my_helper
INFO - 2020-02-03 02:22:08 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:22:08 --> Controller Class Initialized
DEBUG - 2020-02-03 02:22:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:22:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:22:08 --> Final output sent to browser
DEBUG - 2020-02-03 02:22:08 --> Total execution time: 0.3265
INFO - 2020-02-03 02:22:20 --> Config Class Initialized
INFO - 2020-02-03 02:22:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:22:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:22:20 --> Utf8 Class Initialized
INFO - 2020-02-03 02:22:20 --> URI Class Initialized
DEBUG - 2020-02-03 02:22:20 --> No URI present. Default controller set.
INFO - 2020-02-03 02:22:20 --> Router Class Initialized
INFO - 2020-02-03 02:22:20 --> Output Class Initialized
INFO - 2020-02-03 02:22:20 --> Security Class Initialized
DEBUG - 2020-02-03 02:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:22:21 --> Input Class Initialized
INFO - 2020-02-03 02:22:21 --> Language Class Initialized
INFO - 2020-02-03 02:22:21 --> Language Class Initialized
INFO - 2020-02-03 02:22:21 --> Config Class Initialized
INFO - 2020-02-03 02:22:21 --> Loader Class Initialized
INFO - 2020-02-03 02:22:21 --> Helper loaded: url_helper
INFO - 2020-02-03 02:22:21 --> Helper loaded: file_helper
INFO - 2020-02-03 02:22:21 --> Helper loaded: form_helper
INFO - 2020-02-03 02:22:21 --> Helper loaded: my_helper
INFO - 2020-02-03 02:22:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:22:21 --> Controller Class Initialized
DEBUG - 2020-02-03 02:22:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:22:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:22:21 --> Final output sent to browser
DEBUG - 2020-02-03 02:22:21 --> Total execution time: 0.3051
INFO - 2020-02-03 02:22:36 --> Config Class Initialized
INFO - 2020-02-03 02:22:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:22:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:22:36 --> Utf8 Class Initialized
INFO - 2020-02-03 02:22:36 --> URI Class Initialized
DEBUG - 2020-02-03 02:22:36 --> No URI present. Default controller set.
INFO - 2020-02-03 02:22:36 --> Router Class Initialized
INFO - 2020-02-03 02:22:36 --> Output Class Initialized
INFO - 2020-02-03 02:22:36 --> Security Class Initialized
DEBUG - 2020-02-03 02:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:22:37 --> Input Class Initialized
INFO - 2020-02-03 02:22:37 --> Language Class Initialized
INFO - 2020-02-03 02:22:37 --> Language Class Initialized
INFO - 2020-02-03 02:22:37 --> Config Class Initialized
INFO - 2020-02-03 02:22:37 --> Loader Class Initialized
INFO - 2020-02-03 02:22:37 --> Helper loaded: url_helper
INFO - 2020-02-03 02:22:37 --> Helper loaded: file_helper
INFO - 2020-02-03 02:22:37 --> Helper loaded: form_helper
INFO - 2020-02-03 02:22:37 --> Helper loaded: my_helper
INFO - 2020-02-03 02:22:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:22:37 --> Controller Class Initialized
DEBUG - 2020-02-03 02:22:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:22:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:22:37 --> Final output sent to browser
DEBUG - 2020-02-03 02:22:37 --> Total execution time: 0.2954
INFO - 2020-02-03 02:22:46 --> Config Class Initialized
INFO - 2020-02-03 02:22:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:22:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:22:46 --> Utf8 Class Initialized
INFO - 2020-02-03 02:22:46 --> URI Class Initialized
DEBUG - 2020-02-03 02:22:46 --> No URI present. Default controller set.
INFO - 2020-02-03 02:22:46 --> Router Class Initialized
INFO - 2020-02-03 02:22:46 --> Output Class Initialized
INFO - 2020-02-03 02:22:46 --> Security Class Initialized
DEBUG - 2020-02-03 02:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:22:46 --> Input Class Initialized
INFO - 2020-02-03 02:22:46 --> Language Class Initialized
INFO - 2020-02-03 02:22:46 --> Language Class Initialized
INFO - 2020-02-03 02:22:46 --> Config Class Initialized
INFO - 2020-02-03 02:22:46 --> Loader Class Initialized
INFO - 2020-02-03 02:22:46 --> Helper loaded: url_helper
INFO - 2020-02-03 02:22:46 --> Helper loaded: file_helper
INFO - 2020-02-03 02:22:46 --> Helper loaded: form_helper
INFO - 2020-02-03 02:22:46 --> Helper loaded: my_helper
INFO - 2020-02-03 02:22:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:22:46 --> Controller Class Initialized
DEBUG - 2020-02-03 02:22:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:22:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:22:46 --> Final output sent to browser
DEBUG - 2020-02-03 02:22:46 --> Total execution time: 0.3381
INFO - 2020-02-03 02:22:56 --> Config Class Initialized
INFO - 2020-02-03 02:22:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:22:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:22:56 --> Utf8 Class Initialized
INFO - 2020-02-03 02:22:56 --> URI Class Initialized
DEBUG - 2020-02-03 02:22:56 --> No URI present. Default controller set.
INFO - 2020-02-03 02:22:56 --> Router Class Initialized
INFO - 2020-02-03 02:22:56 --> Output Class Initialized
INFO - 2020-02-03 02:22:56 --> Security Class Initialized
DEBUG - 2020-02-03 02:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:22:56 --> Input Class Initialized
INFO - 2020-02-03 02:22:56 --> Language Class Initialized
INFO - 2020-02-03 02:22:56 --> Language Class Initialized
INFO - 2020-02-03 02:22:56 --> Config Class Initialized
INFO - 2020-02-03 02:22:56 --> Loader Class Initialized
INFO - 2020-02-03 02:22:56 --> Helper loaded: url_helper
INFO - 2020-02-03 02:22:56 --> Helper loaded: file_helper
INFO - 2020-02-03 02:22:56 --> Helper loaded: form_helper
INFO - 2020-02-03 02:22:56 --> Helper loaded: my_helper
INFO - 2020-02-03 02:22:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:22:56 --> Controller Class Initialized
DEBUG - 2020-02-03 02:22:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:22:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:22:56 --> Final output sent to browser
DEBUG - 2020-02-03 02:22:56 --> Total execution time: 0.3244
INFO - 2020-02-03 02:23:02 --> Config Class Initialized
INFO - 2020-02-03 02:23:02 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:02 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:02 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:02 --> URI Class Initialized
DEBUG - 2020-02-03 02:23:02 --> No URI present. Default controller set.
INFO - 2020-02-03 02:23:02 --> Router Class Initialized
INFO - 2020-02-03 02:23:02 --> Output Class Initialized
INFO - 2020-02-03 02:23:02 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:02 --> Input Class Initialized
INFO - 2020-02-03 02:23:02 --> Language Class Initialized
INFO - 2020-02-03 02:23:02 --> Language Class Initialized
INFO - 2020-02-03 02:23:02 --> Config Class Initialized
INFO - 2020-02-03 02:23:02 --> Loader Class Initialized
INFO - 2020-02-03 02:23:02 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:02 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:02 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:02 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:02 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:02 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:23:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:02 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:02 --> Total execution time: 0.3080
INFO - 2020-02-03 02:23:11 --> Config Class Initialized
INFO - 2020-02-03 02:23:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:11 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:11 --> URI Class Initialized
INFO - 2020-02-03 02:23:11 --> Router Class Initialized
INFO - 2020-02-03 02:23:11 --> Output Class Initialized
INFO - 2020-02-03 02:23:11 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:11 --> Input Class Initialized
INFO - 2020-02-03 02:23:11 --> Language Class Initialized
INFO - 2020-02-03 02:23:11 --> Language Class Initialized
INFO - 2020-02-03 02:23:11 --> Config Class Initialized
INFO - 2020-02-03 02:23:11 --> Loader Class Initialized
INFO - 2020-02-03 02:23:11 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:11 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:11 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:11 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:11 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 02:23:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:11 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:11 --> Total execution time: 0.3224
INFO - 2020-02-03 02:23:13 --> Config Class Initialized
INFO - 2020-02-03 02:23:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:13 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:13 --> URI Class Initialized
INFO - 2020-02-03 02:23:13 --> Router Class Initialized
INFO - 2020-02-03 02:23:13 --> Output Class Initialized
INFO - 2020-02-03 02:23:13 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:13 --> Input Class Initialized
INFO - 2020-02-03 02:23:13 --> Language Class Initialized
INFO - 2020-02-03 02:23:13 --> Language Class Initialized
INFO - 2020-02-03 02:23:13 --> Config Class Initialized
INFO - 2020-02-03 02:23:13 --> Loader Class Initialized
INFO - 2020-02-03 02:23:13 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:13 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:13 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:13 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:14 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 02:23:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:14 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:14 --> Total execution time: 0.3239
INFO - 2020-02-03 02:23:14 --> Config Class Initialized
INFO - 2020-02-03 02:23:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:14 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:14 --> URI Class Initialized
INFO - 2020-02-03 02:23:14 --> Router Class Initialized
INFO - 2020-02-03 02:23:14 --> Output Class Initialized
INFO - 2020-02-03 02:23:14 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:14 --> Input Class Initialized
INFO - 2020-02-03 02:23:14 --> Language Class Initialized
INFO - 2020-02-03 02:23:14 --> Language Class Initialized
INFO - 2020-02-03 02:23:14 --> Config Class Initialized
INFO - 2020-02-03 02:23:14 --> Loader Class Initialized
INFO - 2020-02-03 02:23:14 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:14 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:14 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:14 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:14 --> Controller Class Initialized
INFO - 2020-02-03 02:23:16 --> Config Class Initialized
INFO - 2020-02-03 02:23:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:16 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:16 --> URI Class Initialized
INFO - 2020-02-03 02:23:16 --> Router Class Initialized
INFO - 2020-02-03 02:23:16 --> Output Class Initialized
INFO - 2020-02-03 02:23:16 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:16 --> Input Class Initialized
INFO - 2020-02-03 02:23:16 --> Language Class Initialized
INFO - 2020-02-03 02:23:16 --> Language Class Initialized
INFO - 2020-02-03 02:23:16 --> Config Class Initialized
INFO - 2020-02-03 02:23:16 --> Loader Class Initialized
INFO - 2020-02-03 02:23:16 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:16 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:16 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:16 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:16 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 02:23:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:16 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:17 --> Total execution time: 0.3461
INFO - 2020-02-03 02:23:17 --> Config Class Initialized
INFO - 2020-02-03 02:23:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:17 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:17 --> URI Class Initialized
INFO - 2020-02-03 02:23:17 --> Router Class Initialized
INFO - 2020-02-03 02:23:17 --> Output Class Initialized
INFO - 2020-02-03 02:23:17 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:17 --> Input Class Initialized
INFO - 2020-02-03 02:23:17 --> Language Class Initialized
INFO - 2020-02-03 02:23:17 --> Language Class Initialized
INFO - 2020-02-03 02:23:17 --> Config Class Initialized
INFO - 2020-02-03 02:23:17 --> Loader Class Initialized
INFO - 2020-02-03 02:23:17 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:17 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:17 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:17 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:17 --> Controller Class Initialized
INFO - 2020-02-03 02:23:25 --> Config Class Initialized
INFO - 2020-02-03 02:23:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:25 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:25 --> URI Class Initialized
INFO - 2020-02-03 02:23:25 --> Router Class Initialized
INFO - 2020-02-03 02:23:25 --> Output Class Initialized
INFO - 2020-02-03 02:23:25 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:25 --> Input Class Initialized
INFO - 2020-02-03 02:23:25 --> Language Class Initialized
INFO - 2020-02-03 02:23:25 --> Language Class Initialized
INFO - 2020-02-03 02:23:25 --> Config Class Initialized
INFO - 2020-02-03 02:23:25 --> Loader Class Initialized
INFO - 2020-02-03 02:23:25 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:25 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 02:23:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:25 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:25 --> Total execution time: 0.2919
INFO - 2020-02-03 02:23:25 --> Config Class Initialized
INFO - 2020-02-03 02:23:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:25 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:25 --> URI Class Initialized
INFO - 2020-02-03 02:23:25 --> Router Class Initialized
INFO - 2020-02-03 02:23:25 --> Output Class Initialized
INFO - 2020-02-03 02:23:25 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:25 --> Input Class Initialized
INFO - 2020-02-03 02:23:25 --> Language Class Initialized
INFO - 2020-02-03 02:23:25 --> Language Class Initialized
INFO - 2020-02-03 02:23:25 --> Config Class Initialized
INFO - 2020-02-03 02:23:25 --> Loader Class Initialized
INFO - 2020-02-03 02:23:25 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:25 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:25 --> Controller Class Initialized
INFO - 2020-02-03 02:23:44 --> Config Class Initialized
INFO - 2020-02-03 02:23:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:23:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:23:44 --> Utf8 Class Initialized
INFO - 2020-02-03 02:23:44 --> URI Class Initialized
DEBUG - 2020-02-03 02:23:44 --> No URI present. Default controller set.
INFO - 2020-02-03 02:23:44 --> Router Class Initialized
INFO - 2020-02-03 02:23:44 --> Output Class Initialized
INFO - 2020-02-03 02:23:44 --> Security Class Initialized
DEBUG - 2020-02-03 02:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:23:44 --> Input Class Initialized
INFO - 2020-02-03 02:23:44 --> Language Class Initialized
INFO - 2020-02-03 02:23:44 --> Language Class Initialized
INFO - 2020-02-03 02:23:44 --> Config Class Initialized
INFO - 2020-02-03 02:23:44 --> Loader Class Initialized
INFO - 2020-02-03 02:23:44 --> Helper loaded: url_helper
INFO - 2020-02-03 02:23:44 --> Helper loaded: file_helper
INFO - 2020-02-03 02:23:44 --> Helper loaded: form_helper
INFO - 2020-02-03 02:23:44 --> Helper loaded: my_helper
INFO - 2020-02-03 02:23:44 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:23:44 --> Controller Class Initialized
DEBUG - 2020-02-03 02:23:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:23:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:23:44 --> Final output sent to browser
DEBUG - 2020-02-03 02:23:44 --> Total execution time: 0.3249
INFO - 2020-02-03 02:24:05 --> Config Class Initialized
INFO - 2020-02-03 02:24:05 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:05 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:05 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:05 --> URI Class Initialized
INFO - 2020-02-03 02:24:05 --> Router Class Initialized
INFO - 2020-02-03 02:24:05 --> Output Class Initialized
INFO - 2020-02-03 02:24:05 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:05 --> Input Class Initialized
INFO - 2020-02-03 02:24:05 --> Language Class Initialized
INFO - 2020-02-03 02:24:05 --> Language Class Initialized
INFO - 2020-02-03 02:24:05 --> Config Class Initialized
INFO - 2020-02-03 02:24:06 --> Loader Class Initialized
INFO - 2020-02-03 02:24:06 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:06 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 02:24:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:06 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:06 --> Total execution time: 0.3543
INFO - 2020-02-03 02:24:06 --> Config Class Initialized
INFO - 2020-02-03 02:24:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:06 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:06 --> URI Class Initialized
INFO - 2020-02-03 02:24:06 --> Router Class Initialized
INFO - 2020-02-03 02:24:06 --> Output Class Initialized
INFO - 2020-02-03 02:24:06 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:06 --> Input Class Initialized
INFO - 2020-02-03 02:24:06 --> Language Class Initialized
INFO - 2020-02-03 02:24:06 --> Language Class Initialized
INFO - 2020-02-03 02:24:06 --> Config Class Initialized
INFO - 2020-02-03 02:24:06 --> Loader Class Initialized
INFO - 2020-02-03 02:24:06 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:06 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:06 --> Controller Class Initialized
INFO - 2020-02-03 02:24:08 --> Config Class Initialized
INFO - 2020-02-03 02:24:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:08 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:08 --> URI Class Initialized
INFO - 2020-02-03 02:24:08 --> Router Class Initialized
INFO - 2020-02-03 02:24:08 --> Output Class Initialized
INFO - 2020-02-03 02:24:08 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:08 --> Input Class Initialized
INFO - 2020-02-03 02:24:08 --> Language Class Initialized
INFO - 2020-02-03 02:24:09 --> Language Class Initialized
INFO - 2020-02-03 02:24:09 --> Config Class Initialized
INFO - 2020-02-03 02:24:09 --> Loader Class Initialized
INFO - 2020-02-03 02:24:09 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:09 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-03 02:24:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:09 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:09 --> Total execution time: 0.3355
INFO - 2020-02-03 02:24:09 --> Config Class Initialized
INFO - 2020-02-03 02:24:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:09 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:09 --> URI Class Initialized
INFO - 2020-02-03 02:24:09 --> Router Class Initialized
INFO - 2020-02-03 02:24:09 --> Output Class Initialized
INFO - 2020-02-03 02:24:09 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:09 --> Input Class Initialized
INFO - 2020-02-03 02:24:09 --> Language Class Initialized
INFO - 2020-02-03 02:24:09 --> Language Class Initialized
INFO - 2020-02-03 02:24:09 --> Config Class Initialized
INFO - 2020-02-03 02:24:09 --> Loader Class Initialized
INFO - 2020-02-03 02:24:09 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:09 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:09 --> Controller Class Initialized
INFO - 2020-02-03 02:24:10 --> Config Class Initialized
INFO - 2020-02-03 02:24:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:10 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:10 --> URI Class Initialized
INFO - 2020-02-03 02:24:10 --> Router Class Initialized
INFO - 2020-02-03 02:24:10 --> Output Class Initialized
INFO - 2020-02-03 02:24:10 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:10 --> Input Class Initialized
INFO - 2020-02-03 02:24:10 --> Language Class Initialized
INFO - 2020-02-03 02:24:10 --> Language Class Initialized
INFO - 2020-02-03 02:24:10 --> Config Class Initialized
INFO - 2020-02-03 02:24:10 --> Loader Class Initialized
INFO - 2020-02-03 02:24:10 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:10 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:10 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:10 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:11 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 02:24:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:11 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:11 --> Total execution time: 0.3516
INFO - 2020-02-03 02:24:11 --> Config Class Initialized
INFO - 2020-02-03 02:24:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:11 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:11 --> URI Class Initialized
INFO - 2020-02-03 02:24:11 --> Router Class Initialized
INFO - 2020-02-03 02:24:11 --> Output Class Initialized
INFO - 2020-02-03 02:24:11 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:11 --> Input Class Initialized
INFO - 2020-02-03 02:24:11 --> Language Class Initialized
INFO - 2020-02-03 02:24:11 --> Language Class Initialized
INFO - 2020-02-03 02:24:11 --> Config Class Initialized
INFO - 2020-02-03 02:24:11 --> Loader Class Initialized
INFO - 2020-02-03 02:24:11 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:11 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:11 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:11 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:11 --> Controller Class Initialized
INFO - 2020-02-03 02:24:12 --> Config Class Initialized
INFO - 2020-02-03 02:24:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:12 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:12 --> URI Class Initialized
INFO - 2020-02-03 02:24:12 --> Router Class Initialized
INFO - 2020-02-03 02:24:12 --> Output Class Initialized
INFO - 2020-02-03 02:24:12 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:12 --> Input Class Initialized
INFO - 2020-02-03 02:24:12 --> Language Class Initialized
INFO - 2020-02-03 02:24:12 --> Language Class Initialized
INFO - 2020-02-03 02:24:12 --> Config Class Initialized
INFO - 2020-02-03 02:24:12 --> Loader Class Initialized
INFO - 2020-02-03 02:24:12 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:12 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:12 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:12 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:12 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:12 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-03 02:24:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:13 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:13 --> Total execution time: 0.3374
INFO - 2020-02-03 02:24:13 --> Config Class Initialized
INFO - 2020-02-03 02:24:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:13 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:13 --> URI Class Initialized
INFO - 2020-02-03 02:24:13 --> Router Class Initialized
INFO - 2020-02-03 02:24:13 --> Output Class Initialized
INFO - 2020-02-03 02:24:13 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:13 --> Input Class Initialized
INFO - 2020-02-03 02:24:13 --> Language Class Initialized
INFO - 2020-02-03 02:24:13 --> Language Class Initialized
INFO - 2020-02-03 02:24:13 --> Config Class Initialized
INFO - 2020-02-03 02:24:13 --> Loader Class Initialized
INFO - 2020-02-03 02:24:13 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:13 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:13 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:13 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:13 --> Controller Class Initialized
INFO - 2020-02-03 02:24:15 --> Config Class Initialized
INFO - 2020-02-03 02:24:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:15 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:15 --> URI Class Initialized
INFO - 2020-02-03 02:24:16 --> Router Class Initialized
INFO - 2020-02-03 02:24:16 --> Output Class Initialized
INFO - 2020-02-03 02:24:16 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:16 --> Input Class Initialized
INFO - 2020-02-03 02:24:16 --> Language Class Initialized
INFO - 2020-02-03 02:24:16 --> Language Class Initialized
INFO - 2020-02-03 02:24:16 --> Config Class Initialized
INFO - 2020-02-03 02:24:16 --> Loader Class Initialized
INFO - 2020-02-03 02:24:16 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:16 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-03 02:24:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:16 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:16 --> Total execution time: 0.3597
INFO - 2020-02-03 02:24:16 --> Config Class Initialized
INFO - 2020-02-03 02:24:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:16 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:16 --> URI Class Initialized
INFO - 2020-02-03 02:24:16 --> Router Class Initialized
INFO - 2020-02-03 02:24:16 --> Output Class Initialized
INFO - 2020-02-03 02:24:16 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:16 --> Input Class Initialized
INFO - 2020-02-03 02:24:16 --> Language Class Initialized
INFO - 2020-02-03 02:24:16 --> Language Class Initialized
INFO - 2020-02-03 02:24:16 --> Config Class Initialized
INFO - 2020-02-03 02:24:16 --> Loader Class Initialized
INFO - 2020-02-03 02:24:16 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:16 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:16 --> Controller Class Initialized
INFO - 2020-02-03 02:24:17 --> Config Class Initialized
INFO - 2020-02-03 02:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:17 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:17 --> URI Class Initialized
INFO - 2020-02-03 02:24:17 --> Router Class Initialized
INFO - 2020-02-03 02:24:17 --> Output Class Initialized
INFO - 2020-02-03 02:24:17 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:17 --> Input Class Initialized
INFO - 2020-02-03 02:24:17 --> Language Class Initialized
INFO - 2020-02-03 02:24:17 --> Language Class Initialized
INFO - 2020-02-03 02:24:17 --> Config Class Initialized
INFO - 2020-02-03 02:24:17 --> Loader Class Initialized
INFO - 2020-02-03 02:24:17 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:17 --> Controller Class Initialized
DEBUG - 2020-02-03 02:24:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 02:24:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:24:17 --> Final output sent to browser
DEBUG - 2020-02-03 02:24:17 --> Total execution time: 0.2872
INFO - 2020-02-03 02:24:17 --> Config Class Initialized
INFO - 2020-02-03 02:24:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:24:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:24:17 --> Utf8 Class Initialized
INFO - 2020-02-03 02:24:17 --> URI Class Initialized
INFO - 2020-02-03 02:24:17 --> Router Class Initialized
INFO - 2020-02-03 02:24:17 --> Output Class Initialized
INFO - 2020-02-03 02:24:17 --> Security Class Initialized
DEBUG - 2020-02-03 02:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:24:17 --> Input Class Initialized
INFO - 2020-02-03 02:24:17 --> Language Class Initialized
INFO - 2020-02-03 02:24:17 --> Language Class Initialized
INFO - 2020-02-03 02:24:17 --> Config Class Initialized
INFO - 2020-02-03 02:24:17 --> Loader Class Initialized
INFO - 2020-02-03 02:24:17 --> Helper loaded: url_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: file_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: form_helper
INFO - 2020-02-03 02:24:17 --> Helper loaded: my_helper
INFO - 2020-02-03 02:24:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:24:17 --> Controller Class Initialized
INFO - 2020-02-03 02:25:25 --> Config Class Initialized
INFO - 2020-02-03 02:25:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:25:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:25:25 --> Utf8 Class Initialized
INFO - 2020-02-03 02:25:25 --> URI Class Initialized
INFO - 2020-02-03 02:25:25 --> Router Class Initialized
INFO - 2020-02-03 02:25:25 --> Output Class Initialized
INFO - 2020-02-03 02:25:25 --> Security Class Initialized
DEBUG - 2020-02-03 02:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:25:25 --> Input Class Initialized
INFO - 2020-02-03 02:25:25 --> Language Class Initialized
INFO - 2020-02-03 02:25:25 --> Language Class Initialized
INFO - 2020-02-03 02:25:25 --> Config Class Initialized
INFO - 2020-02-03 02:25:25 --> Loader Class Initialized
INFO - 2020-02-03 02:25:25 --> Helper loaded: url_helper
INFO - 2020-02-03 02:25:25 --> Helper loaded: file_helper
INFO - 2020-02-03 02:25:25 --> Helper loaded: form_helper
INFO - 2020-02-03 02:25:25 --> Helper loaded: my_helper
INFO - 2020-02-03 02:25:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:25:26 --> Controller Class Initialized
DEBUG - 2020-02-03 02:25:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 02:25:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:25:26 --> Final output sent to browser
DEBUG - 2020-02-03 02:25:26 --> Total execution time: 0.3339
INFO - 2020-02-03 02:25:26 --> Config Class Initialized
INFO - 2020-02-03 02:25:26 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:25:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:25:26 --> Utf8 Class Initialized
INFO - 2020-02-03 02:25:26 --> URI Class Initialized
INFO - 2020-02-03 02:25:26 --> Router Class Initialized
INFO - 2020-02-03 02:25:26 --> Output Class Initialized
INFO - 2020-02-03 02:25:26 --> Security Class Initialized
DEBUG - 2020-02-03 02:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:25:26 --> Input Class Initialized
INFO - 2020-02-03 02:25:26 --> Language Class Initialized
INFO - 2020-02-03 02:25:26 --> Language Class Initialized
INFO - 2020-02-03 02:25:26 --> Config Class Initialized
INFO - 2020-02-03 02:25:26 --> Loader Class Initialized
INFO - 2020-02-03 02:25:26 --> Helper loaded: url_helper
INFO - 2020-02-03 02:25:26 --> Helper loaded: file_helper
INFO - 2020-02-03 02:25:26 --> Helper loaded: form_helper
INFO - 2020-02-03 02:25:26 --> Helper loaded: my_helper
INFO - 2020-02-03 02:25:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:25:26 --> Controller Class Initialized
INFO - 2020-02-03 02:25:27 --> Config Class Initialized
INFO - 2020-02-03 02:25:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:25:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:25:27 --> Utf8 Class Initialized
INFO - 2020-02-03 02:25:27 --> URI Class Initialized
DEBUG - 2020-02-03 02:25:27 --> No URI present. Default controller set.
INFO - 2020-02-03 02:25:27 --> Router Class Initialized
INFO - 2020-02-03 02:25:28 --> Output Class Initialized
INFO - 2020-02-03 02:25:28 --> Security Class Initialized
DEBUG - 2020-02-03 02:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:25:28 --> Input Class Initialized
INFO - 2020-02-03 02:25:28 --> Language Class Initialized
INFO - 2020-02-03 02:25:28 --> Language Class Initialized
INFO - 2020-02-03 02:25:28 --> Config Class Initialized
INFO - 2020-02-03 02:25:28 --> Loader Class Initialized
INFO - 2020-02-03 02:25:28 --> Helper loaded: url_helper
INFO - 2020-02-03 02:25:28 --> Helper loaded: file_helper
INFO - 2020-02-03 02:25:28 --> Helper loaded: form_helper
INFO - 2020-02-03 02:25:28 --> Helper loaded: my_helper
INFO - 2020-02-03 02:25:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:25:28 --> Controller Class Initialized
DEBUG - 2020-02-03 02:25:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:25:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:25:28 --> Final output sent to browser
DEBUG - 2020-02-03 02:25:28 --> Total execution time: 0.3633
INFO - 2020-02-03 02:25:56 --> Config Class Initialized
INFO - 2020-02-03 02:25:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 02:25:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 02:25:56 --> Utf8 Class Initialized
INFO - 2020-02-03 02:25:56 --> URI Class Initialized
DEBUG - 2020-02-03 02:25:56 --> No URI present. Default controller set.
INFO - 2020-02-03 02:25:56 --> Router Class Initialized
INFO - 2020-02-03 02:25:56 --> Output Class Initialized
INFO - 2020-02-03 02:25:56 --> Security Class Initialized
DEBUG - 2020-02-03 02:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 02:25:56 --> Input Class Initialized
INFO - 2020-02-03 02:25:56 --> Language Class Initialized
INFO - 2020-02-03 02:25:56 --> Language Class Initialized
INFO - 2020-02-03 02:25:56 --> Config Class Initialized
INFO - 2020-02-03 02:25:56 --> Loader Class Initialized
INFO - 2020-02-03 02:25:56 --> Helper loaded: url_helper
INFO - 2020-02-03 02:25:56 --> Helper loaded: file_helper
INFO - 2020-02-03 02:25:57 --> Helper loaded: form_helper
INFO - 2020-02-03 02:25:57 --> Helper loaded: my_helper
INFO - 2020-02-03 02:25:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 02:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 02:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 02:25:57 --> Controller Class Initialized
DEBUG - 2020-02-03 02:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 02:25:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 02:25:57 --> Final output sent to browser
DEBUG - 2020-02-03 02:25:57 --> Total execution time: 0.3459
INFO - 2020-02-03 03:28:13 --> Config Class Initialized
INFO - 2020-02-03 03:28:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:28:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:28:13 --> Utf8 Class Initialized
INFO - 2020-02-03 03:28:13 --> URI Class Initialized
DEBUG - 2020-02-03 03:28:13 --> No URI present. Default controller set.
INFO - 2020-02-03 03:28:13 --> Router Class Initialized
INFO - 2020-02-03 03:28:13 --> Output Class Initialized
INFO - 2020-02-03 03:28:13 --> Security Class Initialized
DEBUG - 2020-02-03 03:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:28:13 --> Input Class Initialized
INFO - 2020-02-03 03:28:13 --> Language Class Initialized
INFO - 2020-02-03 03:28:13 --> Language Class Initialized
INFO - 2020-02-03 03:28:13 --> Config Class Initialized
INFO - 2020-02-03 03:28:13 --> Loader Class Initialized
INFO - 2020-02-03 03:28:13 --> Helper loaded: url_helper
INFO - 2020-02-03 03:28:13 --> Helper loaded: file_helper
INFO - 2020-02-03 03:28:13 --> Helper loaded: form_helper
INFO - 2020-02-03 03:28:13 --> Helper loaded: my_helper
INFO - 2020-02-03 03:28:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:28:14 --> Controller Class Initialized
DEBUG - 2020-02-03 03:28:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:28:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:28:14 --> Final output sent to browser
DEBUG - 2020-02-03 03:28:14 --> Total execution time: 1.0867
INFO - 2020-02-03 03:28:50 --> Config Class Initialized
INFO - 2020-02-03 03:28:50 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:28:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:28:50 --> Utf8 Class Initialized
INFO - 2020-02-03 03:28:50 --> URI Class Initialized
DEBUG - 2020-02-03 03:28:50 --> No URI present. Default controller set.
INFO - 2020-02-03 03:28:50 --> Router Class Initialized
INFO - 2020-02-03 03:28:50 --> Output Class Initialized
INFO - 2020-02-03 03:28:50 --> Security Class Initialized
DEBUG - 2020-02-03 03:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:28:50 --> Input Class Initialized
INFO - 2020-02-03 03:28:50 --> Language Class Initialized
INFO - 2020-02-03 03:28:50 --> Language Class Initialized
INFO - 2020-02-03 03:28:50 --> Config Class Initialized
INFO - 2020-02-03 03:28:50 --> Loader Class Initialized
INFO - 2020-02-03 03:28:50 --> Helper loaded: url_helper
INFO - 2020-02-03 03:28:50 --> Helper loaded: file_helper
INFO - 2020-02-03 03:28:50 --> Helper loaded: form_helper
INFO - 2020-02-03 03:28:50 --> Helper loaded: my_helper
INFO - 2020-02-03 03:28:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:28:50 --> Controller Class Initialized
DEBUG - 2020-02-03 03:28:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:28:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:28:50 --> Final output sent to browser
DEBUG - 2020-02-03 03:28:50 --> Total execution time: 0.3629
INFO - 2020-02-03 03:29:22 --> Config Class Initialized
INFO - 2020-02-03 03:29:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:29:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:29:22 --> Utf8 Class Initialized
INFO - 2020-02-03 03:29:22 --> URI Class Initialized
DEBUG - 2020-02-03 03:29:22 --> No URI present. Default controller set.
INFO - 2020-02-03 03:29:22 --> Router Class Initialized
INFO - 2020-02-03 03:29:22 --> Output Class Initialized
INFO - 2020-02-03 03:29:22 --> Security Class Initialized
DEBUG - 2020-02-03 03:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:29:22 --> Input Class Initialized
INFO - 2020-02-03 03:29:22 --> Language Class Initialized
INFO - 2020-02-03 03:29:22 --> Language Class Initialized
INFO - 2020-02-03 03:29:22 --> Config Class Initialized
INFO - 2020-02-03 03:29:22 --> Loader Class Initialized
INFO - 2020-02-03 03:29:22 --> Helper loaded: url_helper
INFO - 2020-02-03 03:29:22 --> Helper loaded: file_helper
INFO - 2020-02-03 03:29:22 --> Helper loaded: form_helper
INFO - 2020-02-03 03:29:22 --> Helper loaded: my_helper
INFO - 2020-02-03 03:29:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:29:22 --> Controller Class Initialized
DEBUG - 2020-02-03 03:29:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:29:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:29:22 --> Final output sent to browser
DEBUG - 2020-02-03 03:29:22 --> Total execution time: 0.4053
INFO - 2020-02-03 03:30:03 --> Config Class Initialized
INFO - 2020-02-03 03:30:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:30:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:30:03 --> Utf8 Class Initialized
INFO - 2020-02-03 03:30:03 --> URI Class Initialized
DEBUG - 2020-02-03 03:30:03 --> No URI present. Default controller set.
INFO - 2020-02-03 03:30:03 --> Router Class Initialized
INFO - 2020-02-03 03:30:03 --> Output Class Initialized
INFO - 2020-02-03 03:30:03 --> Security Class Initialized
DEBUG - 2020-02-03 03:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:30:03 --> Input Class Initialized
INFO - 2020-02-03 03:30:03 --> Language Class Initialized
INFO - 2020-02-03 03:30:03 --> Language Class Initialized
INFO - 2020-02-03 03:30:03 --> Config Class Initialized
INFO - 2020-02-03 03:30:03 --> Loader Class Initialized
INFO - 2020-02-03 03:30:03 --> Helper loaded: url_helper
INFO - 2020-02-03 03:30:03 --> Helper loaded: file_helper
INFO - 2020-02-03 03:30:03 --> Helper loaded: form_helper
INFO - 2020-02-03 03:30:03 --> Helper loaded: my_helper
INFO - 2020-02-03 03:30:03 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:30:03 --> Controller Class Initialized
DEBUG - 2020-02-03 03:30:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:30:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:30:04 --> Final output sent to browser
DEBUG - 2020-02-03 03:30:04 --> Total execution time: 0.4068
INFO - 2020-02-03 03:30:23 --> Config Class Initialized
INFO - 2020-02-03 03:30:23 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:30:23 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:30:23 --> Utf8 Class Initialized
INFO - 2020-02-03 03:30:23 --> URI Class Initialized
DEBUG - 2020-02-03 03:30:23 --> No URI present. Default controller set.
INFO - 2020-02-03 03:30:23 --> Router Class Initialized
INFO - 2020-02-03 03:30:23 --> Output Class Initialized
INFO - 2020-02-03 03:30:23 --> Security Class Initialized
DEBUG - 2020-02-03 03:30:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:30:24 --> Input Class Initialized
INFO - 2020-02-03 03:30:24 --> Language Class Initialized
INFO - 2020-02-03 03:30:24 --> Language Class Initialized
INFO - 2020-02-03 03:30:24 --> Config Class Initialized
INFO - 2020-02-03 03:30:24 --> Loader Class Initialized
INFO - 2020-02-03 03:30:24 --> Helper loaded: url_helper
INFO - 2020-02-03 03:30:24 --> Helper loaded: file_helper
INFO - 2020-02-03 03:30:24 --> Helper loaded: form_helper
INFO - 2020-02-03 03:30:24 --> Helper loaded: my_helper
INFO - 2020-02-03 03:30:24 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:30:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:30:24 --> Controller Class Initialized
DEBUG - 2020-02-03 03:30:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:30:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:30:24 --> Final output sent to browser
DEBUG - 2020-02-03 03:30:24 --> Total execution time: 0.3814
INFO - 2020-02-03 03:30:55 --> Config Class Initialized
INFO - 2020-02-03 03:30:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:30:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:30:55 --> Utf8 Class Initialized
INFO - 2020-02-03 03:30:55 --> URI Class Initialized
DEBUG - 2020-02-03 03:30:55 --> No URI present. Default controller set.
INFO - 2020-02-03 03:30:55 --> Router Class Initialized
INFO - 2020-02-03 03:30:56 --> Output Class Initialized
INFO - 2020-02-03 03:30:56 --> Security Class Initialized
DEBUG - 2020-02-03 03:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:30:56 --> Input Class Initialized
INFO - 2020-02-03 03:30:56 --> Language Class Initialized
INFO - 2020-02-03 03:30:56 --> Language Class Initialized
INFO - 2020-02-03 03:30:56 --> Config Class Initialized
INFO - 2020-02-03 03:30:56 --> Loader Class Initialized
INFO - 2020-02-03 03:30:56 --> Helper loaded: url_helper
INFO - 2020-02-03 03:30:56 --> Helper loaded: file_helper
INFO - 2020-02-03 03:30:56 --> Helper loaded: form_helper
INFO - 2020-02-03 03:30:56 --> Helper loaded: my_helper
INFO - 2020-02-03 03:30:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:30:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:30:56 --> Controller Class Initialized
DEBUG - 2020-02-03 03:30:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:30:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:30:56 --> Final output sent to browser
DEBUG - 2020-02-03 03:30:56 --> Total execution time: 0.4571
INFO - 2020-02-03 03:31:15 --> Config Class Initialized
INFO - 2020-02-03 03:31:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:31:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:31:15 --> Utf8 Class Initialized
INFO - 2020-02-03 03:31:15 --> URI Class Initialized
DEBUG - 2020-02-03 03:31:15 --> No URI present. Default controller set.
INFO - 2020-02-03 03:31:15 --> Router Class Initialized
INFO - 2020-02-03 03:31:15 --> Output Class Initialized
INFO - 2020-02-03 03:31:15 --> Security Class Initialized
DEBUG - 2020-02-03 03:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:31:15 --> Input Class Initialized
INFO - 2020-02-03 03:31:15 --> Language Class Initialized
INFO - 2020-02-03 03:31:15 --> Language Class Initialized
INFO - 2020-02-03 03:31:15 --> Config Class Initialized
INFO - 2020-02-03 03:31:15 --> Loader Class Initialized
INFO - 2020-02-03 03:31:15 --> Helper loaded: url_helper
INFO - 2020-02-03 03:31:15 --> Helper loaded: file_helper
INFO - 2020-02-03 03:31:15 --> Helper loaded: form_helper
INFO - 2020-02-03 03:31:15 --> Helper loaded: my_helper
INFO - 2020-02-03 03:31:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:31:15 --> Controller Class Initialized
DEBUG - 2020-02-03 03:31:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:31:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:31:15 --> Final output sent to browser
DEBUG - 2020-02-03 03:31:15 --> Total execution time: 0.3831
INFO - 2020-02-03 03:31:29 --> Config Class Initialized
INFO - 2020-02-03 03:31:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:31:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:31:29 --> Utf8 Class Initialized
INFO - 2020-02-03 03:31:29 --> URI Class Initialized
DEBUG - 2020-02-03 03:31:29 --> No URI present. Default controller set.
INFO - 2020-02-03 03:31:29 --> Router Class Initialized
INFO - 2020-02-03 03:31:29 --> Output Class Initialized
INFO - 2020-02-03 03:31:29 --> Security Class Initialized
DEBUG - 2020-02-03 03:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:31:29 --> Input Class Initialized
INFO - 2020-02-03 03:31:29 --> Language Class Initialized
INFO - 2020-02-03 03:31:29 --> Language Class Initialized
INFO - 2020-02-03 03:31:29 --> Config Class Initialized
INFO - 2020-02-03 03:31:29 --> Loader Class Initialized
INFO - 2020-02-03 03:31:29 --> Helper loaded: url_helper
INFO - 2020-02-03 03:31:29 --> Helper loaded: file_helper
INFO - 2020-02-03 03:31:29 --> Helper loaded: form_helper
INFO - 2020-02-03 03:31:29 --> Helper loaded: my_helper
INFO - 2020-02-03 03:31:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:31:30 --> Controller Class Initialized
DEBUG - 2020-02-03 03:31:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:31:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:31:30 --> Final output sent to browser
DEBUG - 2020-02-03 03:31:30 --> Total execution time: 0.3851
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:38:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:38:55 --> Utf8 Class Initialized
INFO - 2020-02-03 03:38:55 --> URI Class Initialized
INFO - 2020-02-03 03:38:55 --> Router Class Initialized
INFO - 2020-02-03 03:38:55 --> Output Class Initialized
INFO - 2020-02-03 03:38:55 --> Security Class Initialized
DEBUG - 2020-02-03 03:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:38:55 --> Input Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:55 --> Loader Class Initialized
INFO - 2020-02-03 03:38:55 --> Helper loaded: url_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: file_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: form_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: my_helper
INFO - 2020-02-03 03:38:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:38:55 --> Controller Class Initialized
INFO - 2020-02-03 03:38:55 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:38:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:38:55 --> Utf8 Class Initialized
INFO - 2020-02-03 03:38:55 --> URI Class Initialized
INFO - 2020-02-03 03:38:55 --> Router Class Initialized
INFO - 2020-02-03 03:38:55 --> Output Class Initialized
INFO - 2020-02-03 03:38:55 --> Security Class Initialized
DEBUG - 2020-02-03 03:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:38:55 --> Input Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:55 --> Loader Class Initialized
INFO - 2020-02-03 03:38:55 --> Helper loaded: url_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: file_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: form_helper
INFO - 2020-02-03 03:38:55 --> Helper loaded: my_helper
INFO - 2020-02-03 03:38:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:38:55 --> Controller Class Initialized
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:38:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:38:55 --> Utf8 Class Initialized
INFO - 2020-02-03 03:38:55 --> URI Class Initialized
INFO - 2020-02-03 03:38:55 --> Router Class Initialized
INFO - 2020-02-03 03:38:55 --> Output Class Initialized
INFO - 2020-02-03 03:38:55 --> Security Class Initialized
DEBUG - 2020-02-03 03:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:38:55 --> Input Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Language Class Initialized
INFO - 2020-02-03 03:38:55 --> Config Class Initialized
INFO - 2020-02-03 03:38:56 --> Loader Class Initialized
INFO - 2020-02-03 03:38:56 --> Helper loaded: url_helper
INFO - 2020-02-03 03:38:56 --> Helper loaded: file_helper
INFO - 2020-02-03 03:38:56 --> Helper loaded: form_helper
INFO - 2020-02-03 03:38:56 --> Helper loaded: my_helper
INFO - 2020-02-03 03:38:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:38:56 --> Controller Class Initialized
DEBUG - 2020-02-03 03:38:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 03:38:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:38:56 --> Final output sent to browser
DEBUG - 2020-02-03 03:38:56 --> Total execution time: 0.3116
INFO - 2020-02-03 03:39:41 --> Config Class Initialized
INFO - 2020-02-03 03:39:41 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:39:41 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:39:41 --> Utf8 Class Initialized
INFO - 2020-02-03 03:39:41 --> URI Class Initialized
INFO - 2020-02-03 03:39:41 --> Router Class Initialized
INFO - 2020-02-03 03:39:41 --> Output Class Initialized
INFO - 2020-02-03 03:39:41 --> Security Class Initialized
DEBUG - 2020-02-03 03:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:39:41 --> Input Class Initialized
INFO - 2020-02-03 03:39:41 --> Language Class Initialized
INFO - 2020-02-03 03:39:41 --> Language Class Initialized
INFO - 2020-02-03 03:39:41 --> Config Class Initialized
INFO - 2020-02-03 03:39:41 --> Loader Class Initialized
INFO - 2020-02-03 03:39:41 --> Helper loaded: url_helper
INFO - 2020-02-03 03:39:41 --> Helper loaded: file_helper
INFO - 2020-02-03 03:39:41 --> Helper loaded: form_helper
INFO - 2020-02-03 03:39:41 --> Helper loaded: my_helper
INFO - 2020-02-03 03:39:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:39:41 --> Controller Class Initialized
DEBUG - 2020-02-03 03:39:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 03:39:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:39:41 --> Final output sent to browser
DEBUG - 2020-02-03 03:39:41 --> Total execution time: 0.4255
INFO - 2020-02-03 03:39:49 --> Config Class Initialized
INFO - 2020-02-03 03:39:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:39:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:39:49 --> Utf8 Class Initialized
INFO - 2020-02-03 03:39:49 --> URI Class Initialized
INFO - 2020-02-03 03:39:49 --> Router Class Initialized
INFO - 2020-02-03 03:39:49 --> Output Class Initialized
INFO - 2020-02-03 03:39:49 --> Security Class Initialized
DEBUG - 2020-02-03 03:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:39:49 --> Input Class Initialized
INFO - 2020-02-03 03:39:49 --> Language Class Initialized
INFO - 2020-02-03 03:39:49 --> Language Class Initialized
INFO - 2020-02-03 03:39:49 --> Config Class Initialized
INFO - 2020-02-03 03:39:49 --> Loader Class Initialized
INFO - 2020-02-03 03:39:49 --> Helper loaded: url_helper
INFO - 2020-02-03 03:39:49 --> Helper loaded: file_helper
INFO - 2020-02-03 03:39:49 --> Helper loaded: form_helper
INFO - 2020-02-03 03:39:49 --> Helper loaded: my_helper
INFO - 2020-02-03 03:39:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:39:49 --> Controller Class Initialized
INFO - 2020-02-03 03:39:49 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:39:49 --> Final output sent to browser
DEBUG - 2020-02-03 03:39:49 --> Total execution time: 0.3751
INFO - 2020-02-03 03:39:49 --> Config Class Initialized
INFO - 2020-02-03 03:39:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:39:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:39:50 --> Utf8 Class Initialized
INFO - 2020-02-03 03:39:50 --> URI Class Initialized
INFO - 2020-02-03 03:39:50 --> Router Class Initialized
INFO - 2020-02-03 03:39:50 --> Output Class Initialized
INFO - 2020-02-03 03:39:50 --> Security Class Initialized
DEBUG - 2020-02-03 03:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:39:50 --> Input Class Initialized
INFO - 2020-02-03 03:39:50 --> Language Class Initialized
INFO - 2020-02-03 03:39:50 --> Language Class Initialized
INFO - 2020-02-03 03:39:50 --> Config Class Initialized
INFO - 2020-02-03 03:39:50 --> Loader Class Initialized
INFO - 2020-02-03 03:39:50 --> Helper loaded: url_helper
INFO - 2020-02-03 03:39:50 --> Helper loaded: file_helper
INFO - 2020-02-03 03:39:50 --> Helper loaded: form_helper
INFO - 2020-02-03 03:39:50 --> Helper loaded: my_helper
INFO - 2020-02-03 03:39:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:39:50 --> Controller Class Initialized
DEBUG - 2020-02-03 03:39:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 03:39:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:39:50 --> Final output sent to browser
DEBUG - 2020-02-03 03:39:50 --> Total execution time: 0.3822
INFO - 2020-02-03 03:40:37 --> Config Class Initialized
INFO - 2020-02-03 03:40:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:37 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:37 --> URI Class Initialized
INFO - 2020-02-03 03:40:37 --> Router Class Initialized
INFO - 2020-02-03 03:40:37 --> Output Class Initialized
INFO - 2020-02-03 03:40:37 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:37 --> Input Class Initialized
INFO - 2020-02-03 03:40:37 --> Language Class Initialized
INFO - 2020-02-03 03:40:37 --> Language Class Initialized
INFO - 2020-02-03 03:40:37 --> Config Class Initialized
INFO - 2020-02-03 03:40:37 --> Loader Class Initialized
INFO - 2020-02-03 03:40:37 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:38 --> Controller Class Initialized
INFO - 2020-02-03 03:40:38 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:40:38 --> Config Class Initialized
INFO - 2020-02-03 03:40:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:38 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:38 --> URI Class Initialized
INFO - 2020-02-03 03:40:38 --> Router Class Initialized
INFO - 2020-02-03 03:40:38 --> Output Class Initialized
INFO - 2020-02-03 03:40:38 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:38 --> Input Class Initialized
INFO - 2020-02-03 03:40:38 --> Language Class Initialized
INFO - 2020-02-03 03:40:38 --> Language Class Initialized
INFO - 2020-02-03 03:40:38 --> Config Class Initialized
INFO - 2020-02-03 03:40:38 --> Loader Class Initialized
INFO - 2020-02-03 03:40:38 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:38 --> Controller Class Initialized
INFO - 2020-02-03 03:40:38 --> Config Class Initialized
INFO - 2020-02-03 03:40:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:38 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:38 --> URI Class Initialized
INFO - 2020-02-03 03:40:38 --> Router Class Initialized
INFO - 2020-02-03 03:40:38 --> Output Class Initialized
INFO - 2020-02-03 03:40:38 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:38 --> Input Class Initialized
INFO - 2020-02-03 03:40:38 --> Language Class Initialized
INFO - 2020-02-03 03:40:38 --> Language Class Initialized
INFO - 2020-02-03 03:40:38 --> Config Class Initialized
INFO - 2020-02-03 03:40:38 --> Loader Class Initialized
INFO - 2020-02-03 03:40:38 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:38 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:38 --> Controller Class Initialized
DEBUG - 2020-02-03 03:40:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 03:40:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:40:38 --> Final output sent to browser
DEBUG - 2020-02-03 03:40:38 --> Total execution time: 0.3590
INFO - 2020-02-03 03:40:45 --> Config Class Initialized
INFO - 2020-02-03 03:40:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:45 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:45 --> URI Class Initialized
INFO - 2020-02-03 03:40:45 --> Router Class Initialized
INFO - 2020-02-03 03:40:45 --> Output Class Initialized
INFO - 2020-02-03 03:40:45 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:45 --> Input Class Initialized
INFO - 2020-02-03 03:40:45 --> Language Class Initialized
INFO - 2020-02-03 03:40:45 --> Language Class Initialized
INFO - 2020-02-03 03:40:45 --> Config Class Initialized
INFO - 2020-02-03 03:40:45 --> Loader Class Initialized
INFO - 2020-02-03 03:40:45 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:45 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:45 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:45 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:45 --> Controller Class Initialized
INFO - 2020-02-03 03:40:45 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:40:45 --> Final output sent to browser
DEBUG - 2020-02-03 03:40:45 --> Total execution time: 0.3548
INFO - 2020-02-03 03:40:45 --> Config Class Initialized
INFO - 2020-02-03 03:40:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:45 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:45 --> URI Class Initialized
INFO - 2020-02-03 03:40:45 --> Router Class Initialized
INFO - 2020-02-03 03:40:45 --> Output Class Initialized
INFO - 2020-02-03 03:40:45 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:45 --> Input Class Initialized
INFO - 2020-02-03 03:40:45 --> Language Class Initialized
INFO - 2020-02-03 03:40:46 --> Language Class Initialized
INFO - 2020-02-03 03:40:46 --> Config Class Initialized
INFO - 2020-02-03 03:40:46 --> Loader Class Initialized
INFO - 2020-02-03 03:40:46 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:46 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:46 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:46 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:46 --> Controller Class Initialized
DEBUG - 2020-02-03 03:40:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 03:40:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:40:46 --> Final output sent to browser
DEBUG - 2020-02-03 03:40:46 --> Total execution time: 0.3735
INFO - 2020-02-03 03:40:51 --> Config Class Initialized
INFO - 2020-02-03 03:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:51 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:51 --> URI Class Initialized
INFO - 2020-02-03 03:40:51 --> Router Class Initialized
INFO - 2020-02-03 03:40:51 --> Output Class Initialized
INFO - 2020-02-03 03:40:51 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:51 --> Input Class Initialized
INFO - 2020-02-03 03:40:51 --> Language Class Initialized
INFO - 2020-02-03 03:40:52 --> Language Class Initialized
INFO - 2020-02-03 03:40:52 --> Config Class Initialized
INFO - 2020-02-03 03:40:52 --> Loader Class Initialized
INFO - 2020-02-03 03:40:52 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:52 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:52 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:52 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:52 --> Controller Class Initialized
DEBUG - 2020-02-03 03:40:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-03 03:40:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:40:52 --> Final output sent to browser
DEBUG - 2020-02-03 03:40:52 --> Total execution time: 0.3859
INFO - 2020-02-03 03:40:53 --> Config Class Initialized
INFO - 2020-02-03 03:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:40:53 --> Utf8 Class Initialized
INFO - 2020-02-03 03:40:53 --> URI Class Initialized
DEBUG - 2020-02-03 03:40:53 --> No URI present. Default controller set.
INFO - 2020-02-03 03:40:53 --> Router Class Initialized
INFO - 2020-02-03 03:40:53 --> Output Class Initialized
INFO - 2020-02-03 03:40:53 --> Security Class Initialized
DEBUG - 2020-02-03 03:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:40:53 --> Input Class Initialized
INFO - 2020-02-03 03:40:53 --> Language Class Initialized
INFO - 2020-02-03 03:40:53 --> Language Class Initialized
INFO - 2020-02-03 03:40:54 --> Config Class Initialized
INFO - 2020-02-03 03:40:54 --> Loader Class Initialized
INFO - 2020-02-03 03:40:54 --> Helper loaded: url_helper
INFO - 2020-02-03 03:40:54 --> Helper loaded: file_helper
INFO - 2020-02-03 03:40:54 --> Helper loaded: form_helper
INFO - 2020-02-03 03:40:54 --> Helper loaded: my_helper
INFO - 2020-02-03 03:40:54 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:40:54 --> Controller Class Initialized
DEBUG - 2020-02-03 03:40:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 03:40:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:40:54 --> Final output sent to browser
DEBUG - 2020-02-03 03:40:54 --> Total execution time: 0.3672
INFO - 2020-02-03 03:43:16 --> Config Class Initialized
INFO - 2020-02-03 03:43:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:43:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:43:16 --> Utf8 Class Initialized
INFO - 2020-02-03 03:43:16 --> URI Class Initialized
INFO - 2020-02-03 03:43:16 --> Router Class Initialized
INFO - 2020-02-03 03:43:16 --> Output Class Initialized
INFO - 2020-02-03 03:43:16 --> Security Class Initialized
DEBUG - 2020-02-03 03:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:43:16 --> Input Class Initialized
INFO - 2020-02-03 03:43:16 --> Language Class Initialized
INFO - 2020-02-03 03:43:16 --> Language Class Initialized
INFO - 2020-02-03 03:43:16 --> Config Class Initialized
INFO - 2020-02-03 03:43:16 --> Loader Class Initialized
INFO - 2020-02-03 03:43:16 --> Helper loaded: url_helper
INFO - 2020-02-03 03:43:16 --> Helper loaded: file_helper
INFO - 2020-02-03 03:43:16 --> Helper loaded: form_helper
INFO - 2020-02-03 03:43:16 --> Helper loaded: my_helper
INFO - 2020-02-03 03:43:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:43:16 --> Controller Class Initialized
DEBUG - 2020-02-03 03:43:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-02-03 03:43:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:43:16 --> Final output sent to browser
DEBUG - 2020-02-03 03:43:16 --> Total execution time: 0.3847
INFO - 2020-02-03 03:43:18 --> Config Class Initialized
INFO - 2020-02-03 03:43:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:43:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:43:19 --> Utf8 Class Initialized
INFO - 2020-02-03 03:43:19 --> URI Class Initialized
INFO - 2020-02-03 03:43:19 --> Router Class Initialized
INFO - 2020-02-03 03:43:19 --> Output Class Initialized
INFO - 2020-02-03 03:43:19 --> Security Class Initialized
DEBUG - 2020-02-03 03:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:43:19 --> Input Class Initialized
INFO - 2020-02-03 03:43:19 --> Language Class Initialized
INFO - 2020-02-03 03:43:19 --> Language Class Initialized
INFO - 2020-02-03 03:43:19 --> Config Class Initialized
INFO - 2020-02-03 03:43:19 --> Loader Class Initialized
INFO - 2020-02-03 03:43:19 --> Helper loaded: url_helper
INFO - 2020-02-03 03:43:19 --> Helper loaded: file_helper
INFO - 2020-02-03 03:43:19 --> Helper loaded: form_helper
INFO - 2020-02-03 03:43:19 --> Helper loaded: my_helper
INFO - 2020-02-03 03:43:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:43:19 --> Controller Class Initialized
DEBUG - 2020-02-03 03:43:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-03 03:43:19 --> Final output sent to browser
DEBUG - 2020-02-03 03:43:19 --> Total execution time: 0.6453
INFO - 2020-02-03 03:56:25 --> Config Class Initialized
INFO - 2020-02-03 03:56:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:25 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:25 --> URI Class Initialized
INFO - 2020-02-03 03:56:25 --> Router Class Initialized
INFO - 2020-02-03 03:56:25 --> Output Class Initialized
INFO - 2020-02-03 03:56:25 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:25 --> Input Class Initialized
INFO - 2020-02-03 03:56:25 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Config Class Initialized
INFO - 2020-02-03 03:56:26 --> Loader Class Initialized
INFO - 2020-02-03 03:56:26 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:26 --> Controller Class Initialized
INFO - 2020-02-03 03:56:26 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:56:26 --> Config Class Initialized
INFO - 2020-02-03 03:56:26 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:26 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:26 --> URI Class Initialized
INFO - 2020-02-03 03:56:26 --> Router Class Initialized
INFO - 2020-02-03 03:56:26 --> Output Class Initialized
INFO - 2020-02-03 03:56:26 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:26 --> Input Class Initialized
INFO - 2020-02-03 03:56:26 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Config Class Initialized
INFO - 2020-02-03 03:56:26 --> Loader Class Initialized
INFO - 2020-02-03 03:56:26 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:26 --> Controller Class Initialized
INFO - 2020-02-03 03:56:26 --> Config Class Initialized
INFO - 2020-02-03 03:56:26 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:26 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:26 --> URI Class Initialized
INFO - 2020-02-03 03:56:26 --> Router Class Initialized
INFO - 2020-02-03 03:56:26 --> Output Class Initialized
INFO - 2020-02-03 03:56:26 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:26 --> Input Class Initialized
INFO - 2020-02-03 03:56:26 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Language Class Initialized
INFO - 2020-02-03 03:56:26 --> Config Class Initialized
INFO - 2020-02-03 03:56:26 --> Loader Class Initialized
INFO - 2020-02-03 03:56:26 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:26 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:27 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:27 --> Controller Class Initialized
DEBUG - 2020-02-03 03:56:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 03:56:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:56:27 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:27 --> Total execution time: 0.3739
INFO - 2020-02-03 03:56:32 --> Config Class Initialized
INFO - 2020-02-03 03:56:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:32 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:32 --> URI Class Initialized
INFO - 2020-02-03 03:56:32 --> Router Class Initialized
INFO - 2020-02-03 03:56:32 --> Output Class Initialized
INFO - 2020-02-03 03:56:32 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:32 --> Input Class Initialized
INFO - 2020-02-03 03:56:32 --> Language Class Initialized
INFO - 2020-02-03 03:56:32 --> Language Class Initialized
INFO - 2020-02-03 03:56:32 --> Config Class Initialized
INFO - 2020-02-03 03:56:32 --> Loader Class Initialized
INFO - 2020-02-03 03:56:32 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:32 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:32 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:32 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:32 --> Controller Class Initialized
INFO - 2020-02-03 03:56:32 --> Helper loaded: cookie_helper
INFO - 2020-02-03 03:56:32 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:32 --> Total execution time: 0.3540
INFO - 2020-02-03 03:56:32 --> Config Class Initialized
INFO - 2020-02-03 03:56:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:32 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:32 --> URI Class Initialized
INFO - 2020-02-03 03:56:32 --> Router Class Initialized
INFO - 2020-02-03 03:56:32 --> Output Class Initialized
INFO - 2020-02-03 03:56:32 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:33 --> Input Class Initialized
INFO - 2020-02-03 03:56:33 --> Language Class Initialized
INFO - 2020-02-03 03:56:33 --> Language Class Initialized
INFO - 2020-02-03 03:56:33 --> Config Class Initialized
INFO - 2020-02-03 03:56:33 --> Loader Class Initialized
INFO - 2020-02-03 03:56:33 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:33 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:33 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:33 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:33 --> Controller Class Initialized
DEBUG - 2020-02-03 03:56:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 03:56:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:56:33 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:33 --> Total execution time: 0.3789
INFO - 2020-02-03 03:56:36 --> Config Class Initialized
INFO - 2020-02-03 03:56:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:36 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:36 --> URI Class Initialized
INFO - 2020-02-03 03:56:36 --> Router Class Initialized
INFO - 2020-02-03 03:56:36 --> Output Class Initialized
INFO - 2020-02-03 03:56:36 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:36 --> Input Class Initialized
INFO - 2020-02-03 03:56:36 --> Language Class Initialized
INFO - 2020-02-03 03:56:36 --> Language Class Initialized
INFO - 2020-02-03 03:56:36 --> Config Class Initialized
INFO - 2020-02-03 03:56:36 --> Loader Class Initialized
INFO - 2020-02-03 03:56:36 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:36 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:36 --> Controller Class Initialized
DEBUG - 2020-02-03 03:56:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 03:56:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:56:36 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:36 --> Total execution time: 0.3881
INFO - 2020-02-03 03:56:36 --> Config Class Initialized
INFO - 2020-02-03 03:56:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:36 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:36 --> URI Class Initialized
INFO - 2020-02-03 03:56:36 --> Router Class Initialized
INFO - 2020-02-03 03:56:36 --> Output Class Initialized
INFO - 2020-02-03 03:56:36 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:36 --> Input Class Initialized
INFO - 2020-02-03 03:56:36 --> Language Class Initialized
INFO - 2020-02-03 03:56:36 --> Language Class Initialized
INFO - 2020-02-03 03:56:36 --> Config Class Initialized
INFO - 2020-02-03 03:56:36 --> Loader Class Initialized
INFO - 2020-02-03 03:56:36 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:36 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:36 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:36 --> Controller Class Initialized
INFO - 2020-02-03 03:56:38 --> Config Class Initialized
INFO - 2020-02-03 03:56:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:38 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:38 --> URI Class Initialized
INFO - 2020-02-03 03:56:39 --> Router Class Initialized
INFO - 2020-02-03 03:56:39 --> Output Class Initialized
INFO - 2020-02-03 03:56:39 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:39 --> Input Class Initialized
INFO - 2020-02-03 03:56:39 --> Language Class Initialized
INFO - 2020-02-03 03:56:39 --> Language Class Initialized
INFO - 2020-02-03 03:56:39 --> Config Class Initialized
INFO - 2020-02-03 03:56:39 --> Loader Class Initialized
INFO - 2020-02-03 03:56:39 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:39 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:39 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:39 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:39 --> Controller Class Initialized
INFO - 2020-02-03 03:56:39 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:39 --> Total execution time: 0.3436
INFO - 2020-02-03 03:56:44 --> Config Class Initialized
INFO - 2020-02-03 03:56:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:44 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:44 --> URI Class Initialized
INFO - 2020-02-03 03:56:44 --> Router Class Initialized
INFO - 2020-02-03 03:56:44 --> Output Class Initialized
INFO - 2020-02-03 03:56:44 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:44 --> Input Class Initialized
INFO - 2020-02-03 03:56:44 --> Language Class Initialized
INFO - 2020-02-03 03:56:44 --> Language Class Initialized
INFO - 2020-02-03 03:56:44 --> Config Class Initialized
INFO - 2020-02-03 03:56:44 --> Loader Class Initialized
INFO - 2020-02-03 03:56:45 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:45 --> Controller Class Initialized
DEBUG - 2020-02-03 03:56:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 03:56:45 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:56:45 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:45 --> Total execution time: 0.3553
INFO - 2020-02-03 03:56:45 --> Config Class Initialized
INFO - 2020-02-03 03:56:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:45 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:45 --> URI Class Initialized
INFO - 2020-02-03 03:56:45 --> Router Class Initialized
INFO - 2020-02-03 03:56:45 --> Output Class Initialized
INFO - 2020-02-03 03:56:45 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:45 --> Input Class Initialized
INFO - 2020-02-03 03:56:45 --> Language Class Initialized
INFO - 2020-02-03 03:56:45 --> Language Class Initialized
INFO - 2020-02-03 03:56:45 --> Config Class Initialized
INFO - 2020-02-03 03:56:45 --> Loader Class Initialized
INFO - 2020-02-03 03:56:45 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:45 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:45 --> Controller Class Initialized
INFO - 2020-02-03 03:56:46 --> Config Class Initialized
INFO - 2020-02-03 03:56:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:46 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:46 --> URI Class Initialized
INFO - 2020-02-03 03:56:46 --> Router Class Initialized
INFO - 2020-02-03 03:56:46 --> Output Class Initialized
INFO - 2020-02-03 03:56:46 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:47 --> Input Class Initialized
INFO - 2020-02-03 03:56:47 --> Language Class Initialized
INFO - 2020-02-03 03:56:47 --> Language Class Initialized
INFO - 2020-02-03 03:56:47 --> Config Class Initialized
INFO - 2020-02-03 03:56:47 --> Loader Class Initialized
INFO - 2020-02-03 03:56:47 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:47 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:47 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:47 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:47 --> Controller Class Initialized
INFO - 2020-02-03 03:56:47 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:47 --> Total execution time: 0.3280
INFO - 2020-02-03 03:56:56 --> Config Class Initialized
INFO - 2020-02-03 03:56:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:56 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:56 --> URI Class Initialized
INFO - 2020-02-03 03:56:56 --> Router Class Initialized
INFO - 2020-02-03 03:56:56 --> Output Class Initialized
INFO - 2020-02-03 03:56:56 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:56 --> Input Class Initialized
INFO - 2020-02-03 03:56:56 --> Language Class Initialized
INFO - 2020-02-03 03:56:56 --> Language Class Initialized
INFO - 2020-02-03 03:56:56 --> Config Class Initialized
INFO - 2020-02-03 03:56:56 --> Loader Class Initialized
INFO - 2020-02-03 03:56:56 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:56 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:56 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:56 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:56 --> Controller Class Initialized
DEBUG - 2020-02-03 03:56:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 03:56:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:56:56 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:56 --> Total execution time: 0.3979
INFO - 2020-02-03 03:56:56 --> Config Class Initialized
INFO - 2020-02-03 03:56:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:56 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:56 --> URI Class Initialized
INFO - 2020-02-03 03:56:56 --> Router Class Initialized
INFO - 2020-02-03 03:56:56 --> Output Class Initialized
INFO - 2020-02-03 03:56:56 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:56 --> Input Class Initialized
INFO - 2020-02-03 03:56:56 --> Language Class Initialized
INFO - 2020-02-03 03:56:56 --> Language Class Initialized
INFO - 2020-02-03 03:56:56 --> Config Class Initialized
INFO - 2020-02-03 03:56:56 --> Loader Class Initialized
INFO - 2020-02-03 03:56:56 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:57 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:57 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:57 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:57 --> Controller Class Initialized
INFO - 2020-02-03 03:56:58 --> Config Class Initialized
INFO - 2020-02-03 03:56:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:56:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:56:58 --> Utf8 Class Initialized
INFO - 2020-02-03 03:56:58 --> URI Class Initialized
INFO - 2020-02-03 03:56:58 --> Router Class Initialized
INFO - 2020-02-03 03:56:58 --> Output Class Initialized
INFO - 2020-02-03 03:56:58 --> Security Class Initialized
DEBUG - 2020-02-03 03:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:56:58 --> Input Class Initialized
INFO - 2020-02-03 03:56:58 --> Language Class Initialized
INFO - 2020-02-03 03:56:58 --> Language Class Initialized
INFO - 2020-02-03 03:56:58 --> Config Class Initialized
INFO - 2020-02-03 03:56:58 --> Loader Class Initialized
INFO - 2020-02-03 03:56:58 --> Helper loaded: url_helper
INFO - 2020-02-03 03:56:58 --> Helper loaded: file_helper
INFO - 2020-02-03 03:56:58 --> Helper loaded: form_helper
INFO - 2020-02-03 03:56:58 --> Helper loaded: my_helper
INFO - 2020-02-03 03:56:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:56:58 --> Controller Class Initialized
INFO - 2020-02-03 03:56:58 --> Final output sent to browser
DEBUG - 2020-02-03 03:56:58 --> Total execution time: 0.3348
INFO - 2020-02-03 03:57:27 --> Config Class Initialized
INFO - 2020-02-03 03:57:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:27 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:27 --> URI Class Initialized
INFO - 2020-02-03 03:57:27 --> Router Class Initialized
INFO - 2020-02-03 03:57:27 --> Output Class Initialized
INFO - 2020-02-03 03:57:27 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:27 --> Input Class Initialized
INFO - 2020-02-03 03:57:27 --> Language Class Initialized
INFO - 2020-02-03 03:57:27 --> Language Class Initialized
INFO - 2020-02-03 03:57:27 --> Config Class Initialized
INFO - 2020-02-03 03:57:27 --> Loader Class Initialized
INFO - 2020-02-03 03:57:27 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:27 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:27 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:27 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:28 --> Controller Class Initialized
DEBUG - 2020-02-03 03:57:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 03:57:28 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:57:28 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:28 --> Total execution time: 0.3945
INFO - 2020-02-03 03:57:28 --> Config Class Initialized
INFO - 2020-02-03 03:57:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:28 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:28 --> URI Class Initialized
INFO - 2020-02-03 03:57:28 --> Router Class Initialized
INFO - 2020-02-03 03:57:28 --> Output Class Initialized
INFO - 2020-02-03 03:57:28 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:28 --> Input Class Initialized
INFO - 2020-02-03 03:57:28 --> Language Class Initialized
INFO - 2020-02-03 03:57:28 --> Language Class Initialized
INFO - 2020-02-03 03:57:28 --> Config Class Initialized
INFO - 2020-02-03 03:57:28 --> Loader Class Initialized
INFO - 2020-02-03 03:57:28 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:28 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:28 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:28 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:28 --> Controller Class Initialized
INFO - 2020-02-03 03:57:28 --> Config Class Initialized
INFO - 2020-02-03 03:57:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:28 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:28 --> URI Class Initialized
INFO - 2020-02-03 03:57:28 --> Router Class Initialized
INFO - 2020-02-03 03:57:28 --> Output Class Initialized
INFO - 2020-02-03 03:57:28 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:29 --> Input Class Initialized
INFO - 2020-02-03 03:57:29 --> Language Class Initialized
INFO - 2020-02-03 03:57:29 --> Language Class Initialized
INFO - 2020-02-03 03:57:29 --> Config Class Initialized
INFO - 2020-02-03 03:57:29 --> Loader Class Initialized
INFO - 2020-02-03 03:57:29 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:29 --> Controller Class Initialized
DEBUG - 2020-02-03 03:57:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-03 03:57:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:57:29 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:29 --> Total execution time: 0.4201
INFO - 2020-02-03 03:57:29 --> Config Class Initialized
INFO - 2020-02-03 03:57:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:29 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:29 --> URI Class Initialized
INFO - 2020-02-03 03:57:29 --> Router Class Initialized
INFO - 2020-02-03 03:57:29 --> Output Class Initialized
INFO - 2020-02-03 03:57:29 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:29 --> Input Class Initialized
INFO - 2020-02-03 03:57:29 --> Language Class Initialized
INFO - 2020-02-03 03:57:29 --> Language Class Initialized
INFO - 2020-02-03 03:57:29 --> Config Class Initialized
INFO - 2020-02-03 03:57:29 --> Loader Class Initialized
INFO - 2020-02-03 03:57:29 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:29 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:29 --> Controller Class Initialized
INFO - 2020-02-03 03:57:30 --> Config Class Initialized
INFO - 2020-02-03 03:57:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:30 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:30 --> URI Class Initialized
INFO - 2020-02-03 03:57:30 --> Router Class Initialized
INFO - 2020-02-03 03:57:30 --> Output Class Initialized
INFO - 2020-02-03 03:57:30 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:30 --> Input Class Initialized
INFO - 2020-02-03 03:57:30 --> Language Class Initialized
INFO - 2020-02-03 03:57:30 --> Language Class Initialized
INFO - 2020-02-03 03:57:30 --> Config Class Initialized
INFO - 2020-02-03 03:57:30 --> Loader Class Initialized
INFO - 2020-02-03 03:57:30 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:30 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:30 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:30 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:30 --> Controller Class Initialized
ERROR - 2020-02-03 03:57:30 --> Severity: Notice --> Undefined variable: status_form E:\xampp\htdocs\_2020\myraport\application\modules\data_siswa\views\form.php 223
DEBUG - 2020-02-03 03:57:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form.php
DEBUG - 2020-02-03 03:57:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:57:30 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:30 --> Total execution time: 0.4346
INFO - 2020-02-03 03:57:33 --> Config Class Initialized
INFO - 2020-02-03 03:57:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:33 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:33 --> URI Class Initialized
INFO - 2020-02-03 03:57:33 --> Router Class Initialized
INFO - 2020-02-03 03:57:33 --> Output Class Initialized
INFO - 2020-02-03 03:57:33 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:33 --> Input Class Initialized
INFO - 2020-02-03 03:57:33 --> Language Class Initialized
INFO - 2020-02-03 03:57:33 --> Language Class Initialized
INFO - 2020-02-03 03:57:33 --> Config Class Initialized
INFO - 2020-02-03 03:57:33 --> Loader Class Initialized
INFO - 2020-02-03 03:57:33 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:33 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:33 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:33 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:33 --> Controller Class Initialized
DEBUG - 2020-02-03 03:57:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 03:57:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:57:33 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:33 --> Total execution time: 0.4140
INFO - 2020-02-03 03:57:33 --> Config Class Initialized
INFO - 2020-02-03 03:57:34 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:34 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:34 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:34 --> URI Class Initialized
INFO - 2020-02-03 03:57:34 --> Router Class Initialized
INFO - 2020-02-03 03:57:34 --> Output Class Initialized
INFO - 2020-02-03 03:57:34 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:34 --> Input Class Initialized
INFO - 2020-02-03 03:57:34 --> Language Class Initialized
INFO - 2020-02-03 03:57:34 --> Language Class Initialized
INFO - 2020-02-03 03:57:34 --> Config Class Initialized
INFO - 2020-02-03 03:57:34 --> Loader Class Initialized
INFO - 2020-02-03 03:57:34 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:34 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:34 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:34 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:34 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:34 --> Controller Class Initialized
INFO - 2020-02-03 03:57:37 --> Config Class Initialized
INFO - 2020-02-03 03:57:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:37 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:37 --> URI Class Initialized
INFO - 2020-02-03 03:57:37 --> Router Class Initialized
INFO - 2020-02-03 03:57:37 --> Output Class Initialized
INFO - 2020-02-03 03:57:37 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:37 --> Input Class Initialized
INFO - 2020-02-03 03:57:37 --> Language Class Initialized
INFO - 2020-02-03 03:57:37 --> Language Class Initialized
INFO - 2020-02-03 03:57:37 --> Config Class Initialized
INFO - 2020-02-03 03:57:37 --> Loader Class Initialized
INFO - 2020-02-03 03:57:37 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:37 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:37 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:37 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:37 --> Controller Class Initialized
DEBUG - 2020-02-03 03:57:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 03:57:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:57:37 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:37 --> Total execution time: 0.3948
INFO - 2020-02-03 03:57:37 --> Config Class Initialized
INFO - 2020-02-03 03:57:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:37 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:37 --> URI Class Initialized
INFO - 2020-02-03 03:57:37 --> Router Class Initialized
INFO - 2020-02-03 03:57:37 --> Output Class Initialized
INFO - 2020-02-03 03:57:37 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:38 --> Input Class Initialized
INFO - 2020-02-03 03:57:38 --> Language Class Initialized
INFO - 2020-02-03 03:57:38 --> Language Class Initialized
INFO - 2020-02-03 03:57:38 --> Config Class Initialized
INFO - 2020-02-03 03:57:38 --> Loader Class Initialized
INFO - 2020-02-03 03:57:38 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:38 --> Controller Class Initialized
INFO - 2020-02-03 03:57:38 --> Config Class Initialized
INFO - 2020-02-03 03:57:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:57:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:57:38 --> Utf8 Class Initialized
INFO - 2020-02-03 03:57:38 --> URI Class Initialized
INFO - 2020-02-03 03:57:38 --> Router Class Initialized
INFO - 2020-02-03 03:57:38 --> Output Class Initialized
INFO - 2020-02-03 03:57:38 --> Security Class Initialized
DEBUG - 2020-02-03 03:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:57:38 --> Input Class Initialized
INFO - 2020-02-03 03:57:38 --> Language Class Initialized
INFO - 2020-02-03 03:57:38 --> Language Class Initialized
INFO - 2020-02-03 03:57:38 --> Config Class Initialized
INFO - 2020-02-03 03:57:38 --> Loader Class Initialized
INFO - 2020-02-03 03:57:38 --> Helper loaded: url_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: file_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: form_helper
INFO - 2020-02-03 03:57:38 --> Helper loaded: my_helper
INFO - 2020-02-03 03:57:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:57:38 --> Controller Class Initialized
INFO - 2020-02-03 03:57:38 --> Final output sent to browser
DEBUG - 2020-02-03 03:57:38 --> Total execution time: 0.3393
INFO - 2020-02-03 03:58:14 --> Config Class Initialized
INFO - 2020-02-03 03:58:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:58:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:14 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:14 --> URI Class Initialized
INFO - 2020-02-03 03:58:15 --> Router Class Initialized
INFO - 2020-02-03 03:58:15 --> Output Class Initialized
INFO - 2020-02-03 03:58:15 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:15 --> Config Class Initialized
INFO - 2020-02-03 03:58:15 --> Input Class Initialized
INFO - 2020-02-03 03:58:15 --> Hooks Class Initialized
INFO - 2020-02-03 03:58:15 --> Language Class Initialized
DEBUG - 2020-02-03 03:58:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:15 --> Utf8 Class Initialized
ERROR - 2020-02-03 03:58:15 --> 404 Page Not Found: /index
INFO - 2020-02-03 03:58:15 --> URI Class Initialized
INFO - 2020-02-03 03:58:15 --> Router Class Initialized
INFO - 2020-02-03 03:58:15 --> Output Class Initialized
INFO - 2020-02-03 03:58:15 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:15 --> Input Class Initialized
INFO - 2020-02-03 03:58:15 --> Language Class Initialized
ERROR - 2020-02-03 03:58:15 --> 404 Page Not Found: /index
INFO - 2020-02-03 03:58:18 --> Config Class Initialized
INFO - 2020-02-03 03:58:18 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:58:18 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:18 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:18 --> URI Class Initialized
INFO - 2020-02-03 03:58:18 --> Router Class Initialized
INFO - 2020-02-03 03:58:18 --> Output Class Initialized
INFO - 2020-02-03 03:58:18 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:18 --> Input Class Initialized
INFO - 2020-02-03 03:58:18 --> Language Class Initialized
INFO - 2020-02-03 03:58:18 --> Language Class Initialized
INFO - 2020-02-03 03:58:18 --> Config Class Initialized
INFO - 2020-02-03 03:58:18 --> Loader Class Initialized
INFO - 2020-02-03 03:58:18 --> Helper loaded: url_helper
INFO - 2020-02-03 03:58:18 --> Helper loaded: file_helper
INFO - 2020-02-03 03:58:18 --> Helper loaded: form_helper
INFO - 2020-02-03 03:58:18 --> Helper loaded: my_helper
INFO - 2020-02-03 03:58:18 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:58:18 --> Controller Class Initialized
DEBUG - 2020-02-03 03:58:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 03:58:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:58:18 --> Final output sent to browser
DEBUG - 2020-02-03 03:58:18 --> Total execution time: 0.4907
INFO - 2020-02-03 03:58:18 --> Config Class Initialized
INFO - 2020-02-03 03:58:18 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:58:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:19 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:19 --> Config Class Initialized
INFO - 2020-02-03 03:58:19 --> Hooks Class Initialized
INFO - 2020-02-03 03:58:19 --> URI Class Initialized
DEBUG - 2020-02-03 03:58:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:19 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:19 --> URI Class Initialized
INFO - 2020-02-03 03:58:19 --> Router Class Initialized
INFO - 2020-02-03 03:58:19 --> Config Class Initialized
INFO - 2020-02-03 03:58:19 --> Router Class Initialized
INFO - 2020-02-03 03:58:19 --> Output Class Initialized
INFO - 2020-02-03 03:58:19 --> Hooks Class Initialized
INFO - 2020-02-03 03:58:19 --> Security Class Initialized
INFO - 2020-02-03 03:58:19 --> Output Class Initialized
DEBUG - 2020-02-03 03:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:19 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:19 --> Input Class Initialized
INFO - 2020-02-03 03:58:19 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:19 --> Language Class Initialized
DEBUG - 2020-02-03 03:58:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2020-02-03 03:58:19 --> 404 Page Not Found: /index
INFO - 2020-02-03 03:58:19 --> URI Class Initialized
INFO - 2020-02-03 03:58:19 --> Input Class Initialized
INFO - 2020-02-03 03:58:19 --> Language Class Initialized
ERROR - 2020-02-03 03:58:19 --> 404 Page Not Found: /index
INFO - 2020-02-03 03:58:19 --> Router Class Initialized
INFO - 2020-02-03 03:58:19 --> Output Class Initialized
INFO - 2020-02-03 03:58:19 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:19 --> Input Class Initialized
INFO - 2020-02-03 03:58:19 --> Language Class Initialized
INFO - 2020-02-03 03:58:19 --> Language Class Initialized
INFO - 2020-02-03 03:58:19 --> Config Class Initialized
INFO - 2020-02-03 03:58:19 --> Loader Class Initialized
INFO - 2020-02-03 03:58:19 --> Helper loaded: url_helper
INFO - 2020-02-03 03:58:19 --> Helper loaded: file_helper
INFO - 2020-02-03 03:58:19 --> Helper loaded: form_helper
INFO - 2020-02-03 03:58:19 --> Helper loaded: my_helper
INFO - 2020-02-03 03:58:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:58:19 --> Controller Class Initialized
INFO - 2020-02-03 03:58:22 --> Config Class Initialized
INFO - 2020-02-03 03:58:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:58:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:58:22 --> Utf8 Class Initialized
INFO - 2020-02-03 03:58:22 --> URI Class Initialized
INFO - 2020-02-03 03:58:22 --> Router Class Initialized
INFO - 2020-02-03 03:58:22 --> Output Class Initialized
INFO - 2020-02-03 03:58:22 --> Security Class Initialized
DEBUG - 2020-02-03 03:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:58:22 --> Input Class Initialized
INFO - 2020-02-03 03:58:22 --> Language Class Initialized
INFO - 2020-02-03 03:58:22 --> Language Class Initialized
INFO - 2020-02-03 03:58:22 --> Config Class Initialized
INFO - 2020-02-03 03:58:22 --> Loader Class Initialized
INFO - 2020-02-03 03:58:22 --> Helper loaded: url_helper
INFO - 2020-02-03 03:58:22 --> Helper loaded: file_helper
INFO - 2020-02-03 03:58:22 --> Helper loaded: form_helper
INFO - 2020-02-03 03:58:22 --> Helper loaded: my_helper
INFO - 2020-02-03 03:58:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:58:22 --> Controller Class Initialized
INFO - 2020-02-03 03:58:22 --> Final output sent to browser
DEBUG - 2020-02-03 03:58:22 --> Total execution time: 0.3790
INFO - 2020-02-03 03:59:14 --> Config Class Initialized
INFO - 2020-02-03 03:59:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:14 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:14 --> URI Class Initialized
INFO - 2020-02-03 03:59:14 --> Router Class Initialized
INFO - 2020-02-03 03:59:14 --> Output Class Initialized
INFO - 2020-02-03 03:59:14 --> Security Class Initialized
DEBUG - 2020-02-03 03:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:14 --> Input Class Initialized
INFO - 2020-02-03 03:59:14 --> Language Class Initialized
INFO - 2020-02-03 03:59:14 --> Language Class Initialized
INFO - 2020-02-03 03:59:14 --> Config Class Initialized
INFO - 2020-02-03 03:59:14 --> Loader Class Initialized
INFO - 2020-02-03 03:59:14 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:14 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:14 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:14 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:14 --> Controller Class Initialized
DEBUG - 2020-02-03 03:59:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 03:59:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:59:14 --> Final output sent to browser
DEBUG - 2020-02-03 03:59:14 --> Total execution time: 0.5943
INFO - 2020-02-03 03:59:15 --> Config Class Initialized
INFO - 2020-02-03 03:59:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:15 --> Config Class Initialized
INFO - 2020-02-03 03:59:15 --> Hooks Class Initialized
INFO - 2020-02-03 03:59:15 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:15 --> URI Class Initialized
DEBUG - 2020-02-03 03:59:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:15 --> Config Class Initialized
INFO - 2020-02-03 03:59:15 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:15 --> Hooks Class Initialized
INFO - 2020-02-03 03:59:15 --> Router Class Initialized
INFO - 2020-02-03 03:59:15 --> Output Class Initialized
DEBUG - 2020-02-03 03:59:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:15 --> URI Class Initialized
INFO - 2020-02-03 03:59:15 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:15 --> Security Class Initialized
INFO - 2020-02-03 03:59:15 --> Router Class Initialized
INFO - 2020-02-03 03:59:15 --> URI Class Initialized
DEBUG - 2020-02-03 03:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:15 --> Output Class Initialized
INFO - 2020-02-03 03:59:15 --> Security Class Initialized
INFO - 2020-02-03 03:59:15 --> Router Class Initialized
INFO - 2020-02-03 03:59:15 --> Input Class Initialized
DEBUG - 2020-02-03 03:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:15 --> Input Class Initialized
INFO - 2020-02-03 03:59:15 --> Language Class Initialized
INFO - 2020-02-03 03:59:15 --> Output Class Initialized
INFO - 2020-02-03 03:59:15 --> Language Class Initialized
ERROR - 2020-02-03 03:59:15 --> 404 Page Not Found: /index
INFO - 2020-02-03 03:59:15 --> Security Class Initialized
ERROR - 2020-02-03 03:59:15 --> 404 Page Not Found: /index
DEBUG - 2020-02-03 03:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:15 --> Input Class Initialized
INFO - 2020-02-03 03:59:15 --> Language Class Initialized
INFO - 2020-02-03 03:59:15 --> Language Class Initialized
INFO - 2020-02-03 03:59:15 --> Config Class Initialized
INFO - 2020-02-03 03:59:15 --> Loader Class Initialized
INFO - 2020-02-03 03:59:15 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:15 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:15 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:15 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:15 --> Controller Class Initialized
INFO - 2020-02-03 03:59:16 --> Config Class Initialized
INFO - 2020-02-03 03:59:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:16 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:16 --> URI Class Initialized
INFO - 2020-02-03 03:59:16 --> Router Class Initialized
INFO - 2020-02-03 03:59:16 --> Output Class Initialized
INFO - 2020-02-03 03:59:16 --> Security Class Initialized
DEBUG - 2020-02-03 03:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:16 --> Input Class Initialized
INFO - 2020-02-03 03:59:16 --> Language Class Initialized
INFO - 2020-02-03 03:59:16 --> Language Class Initialized
INFO - 2020-02-03 03:59:16 --> Config Class Initialized
INFO - 2020-02-03 03:59:17 --> Loader Class Initialized
INFO - 2020-02-03 03:59:17 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:17 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:17 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:17 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:17 --> Controller Class Initialized
INFO - 2020-02-03 03:59:17 --> Final output sent to browser
DEBUG - 2020-02-03 03:59:17 --> Total execution time: 0.3769
INFO - 2020-02-03 03:59:19 --> Config Class Initialized
INFO - 2020-02-03 03:59:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:20 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:20 --> URI Class Initialized
INFO - 2020-02-03 03:59:20 --> Router Class Initialized
INFO - 2020-02-03 03:59:20 --> Output Class Initialized
INFO - 2020-02-03 03:59:20 --> Security Class Initialized
DEBUG - 2020-02-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:20 --> Input Class Initialized
INFO - 2020-02-03 03:59:20 --> Language Class Initialized
INFO - 2020-02-03 03:59:20 --> Language Class Initialized
INFO - 2020-02-03 03:59:20 --> Config Class Initialized
INFO - 2020-02-03 03:59:20 --> Loader Class Initialized
INFO - 2020-02-03 03:59:20 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:20 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:20 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:20 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:20 --> Controller Class Initialized
DEBUG - 2020-02-03 03:59:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 03:59:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 03:59:20 --> Final output sent to browser
DEBUG - 2020-02-03 03:59:20 --> Total execution time: 0.4423
INFO - 2020-02-03 03:59:20 --> Config Class Initialized
INFO - 2020-02-03 03:59:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:20 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:20 --> URI Class Initialized
INFO - 2020-02-03 03:59:20 --> Router Class Initialized
INFO - 2020-02-03 03:59:20 --> Output Class Initialized
INFO - 2020-02-03 03:59:20 --> Security Class Initialized
DEBUG - 2020-02-03 03:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:20 --> Input Class Initialized
INFO - 2020-02-03 03:59:20 --> Language Class Initialized
INFO - 2020-02-03 03:59:20 --> Language Class Initialized
INFO - 2020-02-03 03:59:20 --> Config Class Initialized
INFO - 2020-02-03 03:59:20 --> Loader Class Initialized
INFO - 2020-02-03 03:59:20 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:21 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:21 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:21 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:21 --> Controller Class Initialized
INFO - 2020-02-03 03:59:22 --> Config Class Initialized
INFO - 2020-02-03 03:59:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 03:59:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 03:59:22 --> Utf8 Class Initialized
INFO - 2020-02-03 03:59:22 --> URI Class Initialized
INFO - 2020-02-03 03:59:22 --> Router Class Initialized
INFO - 2020-02-03 03:59:22 --> Output Class Initialized
INFO - 2020-02-03 03:59:22 --> Security Class Initialized
DEBUG - 2020-02-03 03:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 03:59:22 --> Input Class Initialized
INFO - 2020-02-03 03:59:22 --> Language Class Initialized
INFO - 2020-02-03 03:59:22 --> Language Class Initialized
INFO - 2020-02-03 03:59:22 --> Config Class Initialized
INFO - 2020-02-03 03:59:22 --> Loader Class Initialized
INFO - 2020-02-03 03:59:22 --> Helper loaded: url_helper
INFO - 2020-02-03 03:59:22 --> Helper loaded: file_helper
INFO - 2020-02-03 03:59:22 --> Helper loaded: form_helper
INFO - 2020-02-03 03:59:22 --> Helper loaded: my_helper
INFO - 2020-02-03 03:59:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 03:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 03:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 03:59:22 --> Controller Class Initialized
INFO - 2020-02-03 03:59:22 --> Final output sent to browser
DEBUG - 2020-02-03 03:59:22 --> Total execution time: 0.3505
INFO - 2020-02-03 04:00:55 --> Config Class Initialized
INFO - 2020-02-03 04:00:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:00:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:00:55 --> Utf8 Class Initialized
INFO - 2020-02-03 04:00:55 --> URI Class Initialized
INFO - 2020-02-03 04:00:55 --> Router Class Initialized
INFO - 2020-02-03 04:00:55 --> Output Class Initialized
INFO - 2020-02-03 04:00:55 --> Security Class Initialized
DEBUG - 2020-02-03 04:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:00:55 --> Input Class Initialized
INFO - 2020-02-03 04:00:55 --> Language Class Initialized
INFO - 2020-02-03 04:00:55 --> Language Class Initialized
INFO - 2020-02-03 04:00:55 --> Config Class Initialized
INFO - 2020-02-03 04:00:55 --> Loader Class Initialized
INFO - 2020-02-03 04:00:55 --> Helper loaded: url_helper
INFO - 2020-02-03 04:00:55 --> Helper loaded: file_helper
INFO - 2020-02-03 04:00:55 --> Helper loaded: form_helper
INFO - 2020-02-03 04:00:55 --> Helper loaded: my_helper
INFO - 2020-02-03 04:00:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:00:55 --> Controller Class Initialized
DEBUG - 2020-02-03 04:00:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:00:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:00:55 --> Final output sent to browser
DEBUG - 2020-02-03 04:00:55 --> Total execution time: 0.4243
INFO - 2020-02-03 04:00:55 --> Config Class Initialized
INFO - 2020-02-03 04:00:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:00:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:00:55 --> Utf8 Class Initialized
INFO - 2020-02-03 04:00:55 --> URI Class Initialized
INFO - 2020-02-03 04:00:56 --> Router Class Initialized
INFO - 2020-02-03 04:00:56 --> Output Class Initialized
INFO - 2020-02-03 04:00:56 --> Security Class Initialized
DEBUG - 2020-02-03 04:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:00:56 --> Input Class Initialized
INFO - 2020-02-03 04:00:56 --> Language Class Initialized
INFO - 2020-02-03 04:00:56 --> Language Class Initialized
INFO - 2020-02-03 04:00:56 --> Config Class Initialized
INFO - 2020-02-03 04:00:56 --> Loader Class Initialized
INFO - 2020-02-03 04:00:56 --> Helper loaded: url_helper
INFO - 2020-02-03 04:00:56 --> Helper loaded: file_helper
INFO - 2020-02-03 04:00:56 --> Helper loaded: form_helper
INFO - 2020-02-03 04:00:56 --> Helper loaded: my_helper
INFO - 2020-02-03 04:00:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:00:56 --> Controller Class Initialized
INFO - 2020-02-03 04:00:57 --> Config Class Initialized
INFO - 2020-02-03 04:00:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:00:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:00:57 --> Utf8 Class Initialized
INFO - 2020-02-03 04:00:57 --> URI Class Initialized
INFO - 2020-02-03 04:00:57 --> Router Class Initialized
INFO - 2020-02-03 04:00:57 --> Output Class Initialized
INFO - 2020-02-03 04:00:57 --> Security Class Initialized
DEBUG - 2020-02-03 04:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:00:57 --> Input Class Initialized
INFO - 2020-02-03 04:00:57 --> Language Class Initialized
INFO - 2020-02-03 04:00:57 --> Language Class Initialized
INFO - 2020-02-03 04:00:57 --> Config Class Initialized
INFO - 2020-02-03 04:00:57 --> Loader Class Initialized
INFO - 2020-02-03 04:00:57 --> Helper loaded: url_helper
INFO - 2020-02-03 04:00:57 --> Helper loaded: file_helper
INFO - 2020-02-03 04:00:57 --> Helper loaded: form_helper
INFO - 2020-02-03 04:00:57 --> Helper loaded: my_helper
INFO - 2020-02-03 04:00:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:00:57 --> Controller Class Initialized
INFO - 2020-02-03 04:00:57 --> Final output sent to browser
DEBUG - 2020-02-03 04:00:57 --> Total execution time: 0.3420
INFO - 2020-02-03 04:00:59 --> Config Class Initialized
INFO - 2020-02-03 04:00:59 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:00:59 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:00:59 --> Utf8 Class Initialized
INFO - 2020-02-03 04:00:59 --> URI Class Initialized
INFO - 2020-02-03 04:00:59 --> Router Class Initialized
INFO - 2020-02-03 04:00:59 --> Output Class Initialized
INFO - 2020-02-03 04:00:59 --> Security Class Initialized
DEBUG - 2020-02-03 04:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:00:59 --> Input Class Initialized
INFO - 2020-02-03 04:00:59 --> Language Class Initialized
INFO - 2020-02-03 04:00:59 --> Language Class Initialized
INFO - 2020-02-03 04:00:59 --> Config Class Initialized
INFO - 2020-02-03 04:00:59 --> Loader Class Initialized
INFO - 2020-02-03 04:00:59 --> Helper loaded: url_helper
INFO - 2020-02-03 04:00:59 --> Helper loaded: file_helper
INFO - 2020-02-03 04:00:59 --> Helper loaded: form_helper
INFO - 2020-02-03 04:00:59 --> Helper loaded: my_helper
INFO - 2020-02-03 04:00:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:00:59 --> Controller Class Initialized
DEBUG - 2020-02-03 04:00:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:00:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:00:59 --> Final output sent to browser
DEBUG - 2020-02-03 04:00:59 --> Total execution time: 0.4502
INFO - 2020-02-03 04:00:59 --> Config Class Initialized
INFO - 2020-02-03 04:00:59 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:00:59 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:00:59 --> Utf8 Class Initialized
INFO - 2020-02-03 04:00:59 --> URI Class Initialized
INFO - 2020-02-03 04:00:59 --> Router Class Initialized
INFO - 2020-02-03 04:00:59 --> Output Class Initialized
INFO - 2020-02-03 04:00:59 --> Security Class Initialized
DEBUG - 2020-02-03 04:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:01:00 --> Input Class Initialized
INFO - 2020-02-03 04:01:00 --> Language Class Initialized
INFO - 2020-02-03 04:01:00 --> Language Class Initialized
INFO - 2020-02-03 04:01:00 --> Config Class Initialized
INFO - 2020-02-03 04:01:00 --> Loader Class Initialized
INFO - 2020-02-03 04:01:00 --> Helper loaded: url_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: file_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: form_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: my_helper
INFO - 2020-02-03 04:01:00 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:01:00 --> Controller Class Initialized
INFO - 2020-02-03 04:01:00 --> Config Class Initialized
INFO - 2020-02-03 04:01:00 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:01:00 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:01:00 --> Utf8 Class Initialized
INFO - 2020-02-03 04:01:00 --> URI Class Initialized
INFO - 2020-02-03 04:01:00 --> Router Class Initialized
INFO - 2020-02-03 04:01:00 --> Output Class Initialized
INFO - 2020-02-03 04:01:00 --> Security Class Initialized
DEBUG - 2020-02-03 04:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:01:00 --> Input Class Initialized
INFO - 2020-02-03 04:01:00 --> Language Class Initialized
INFO - 2020-02-03 04:01:00 --> Language Class Initialized
INFO - 2020-02-03 04:01:00 --> Config Class Initialized
INFO - 2020-02-03 04:01:00 --> Loader Class Initialized
INFO - 2020-02-03 04:01:00 --> Helper loaded: url_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: file_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: form_helper
INFO - 2020-02-03 04:01:00 --> Helper loaded: my_helper
INFO - 2020-02-03 04:01:00 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:01:00 --> Controller Class Initialized
INFO - 2020-02-03 04:01:00 --> Final output sent to browser
DEBUG - 2020-02-03 04:01:00 --> Total execution time: 0.3836
INFO - 2020-02-03 04:03:53 --> Config Class Initialized
INFO - 2020-02-03 04:03:53 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:03:53 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:03:53 --> Utf8 Class Initialized
INFO - 2020-02-03 04:03:53 --> URI Class Initialized
INFO - 2020-02-03 04:03:53 --> Router Class Initialized
INFO - 2020-02-03 04:03:53 --> Output Class Initialized
INFO - 2020-02-03 04:03:53 --> Security Class Initialized
DEBUG - 2020-02-03 04:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:03:53 --> Input Class Initialized
INFO - 2020-02-03 04:03:53 --> Language Class Initialized
INFO - 2020-02-03 04:03:53 --> Language Class Initialized
INFO - 2020-02-03 04:03:53 --> Config Class Initialized
INFO - 2020-02-03 04:03:53 --> Loader Class Initialized
INFO - 2020-02-03 04:03:53 --> Helper loaded: url_helper
INFO - 2020-02-03 04:03:53 --> Helper loaded: file_helper
INFO - 2020-02-03 04:03:53 --> Helper loaded: form_helper
INFO - 2020-02-03 04:03:53 --> Helper loaded: my_helper
INFO - 2020-02-03 04:03:53 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:03:53 --> Controller Class Initialized
DEBUG - 2020-02-03 04:03:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:03:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:03:53 --> Final output sent to browser
DEBUG - 2020-02-03 04:03:53 --> Total execution time: 0.3884
INFO - 2020-02-03 04:03:54 --> Config Class Initialized
INFO - 2020-02-03 04:03:54 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:03:54 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:03:54 --> Utf8 Class Initialized
INFO - 2020-02-03 04:03:54 --> URI Class Initialized
INFO - 2020-02-03 04:03:54 --> Router Class Initialized
INFO - 2020-02-03 04:03:54 --> Output Class Initialized
INFO - 2020-02-03 04:03:54 --> Security Class Initialized
DEBUG - 2020-02-03 04:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:03:54 --> Input Class Initialized
INFO - 2020-02-03 04:03:54 --> Language Class Initialized
INFO - 2020-02-03 04:03:54 --> Language Class Initialized
INFO - 2020-02-03 04:03:54 --> Config Class Initialized
INFO - 2020-02-03 04:03:54 --> Loader Class Initialized
INFO - 2020-02-03 04:03:54 --> Helper loaded: url_helper
INFO - 2020-02-03 04:03:54 --> Helper loaded: file_helper
INFO - 2020-02-03 04:03:54 --> Helper loaded: form_helper
INFO - 2020-02-03 04:03:54 --> Helper loaded: my_helper
INFO - 2020-02-03 04:03:54 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:03:54 --> Controller Class Initialized
INFO - 2020-02-03 04:03:55 --> Config Class Initialized
INFO - 2020-02-03 04:03:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:03:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:03:55 --> Utf8 Class Initialized
INFO - 2020-02-03 04:03:55 --> URI Class Initialized
INFO - 2020-02-03 04:03:55 --> Router Class Initialized
INFO - 2020-02-03 04:03:55 --> Output Class Initialized
INFO - 2020-02-03 04:03:55 --> Security Class Initialized
DEBUG - 2020-02-03 04:03:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:03:55 --> Input Class Initialized
INFO - 2020-02-03 04:03:55 --> Language Class Initialized
INFO - 2020-02-03 04:03:55 --> Language Class Initialized
INFO - 2020-02-03 04:03:55 --> Config Class Initialized
INFO - 2020-02-03 04:03:55 --> Loader Class Initialized
INFO - 2020-02-03 04:03:56 --> Helper loaded: url_helper
INFO - 2020-02-03 04:03:56 --> Helper loaded: file_helper
INFO - 2020-02-03 04:03:56 --> Helper loaded: form_helper
INFO - 2020-02-03 04:03:56 --> Helper loaded: my_helper
INFO - 2020-02-03 04:03:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:03:56 --> Controller Class Initialized
INFO - 2020-02-03 04:03:56 --> Final output sent to browser
DEBUG - 2020-02-03 04:03:56 --> Total execution time: 0.3695
INFO - 2020-02-03 04:05:30 --> Config Class Initialized
INFO - 2020-02-03 04:05:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:30 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:30 --> URI Class Initialized
INFO - 2020-02-03 04:05:30 --> Router Class Initialized
INFO - 2020-02-03 04:05:30 --> Output Class Initialized
INFO - 2020-02-03 04:05:30 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:30 --> Input Class Initialized
INFO - 2020-02-03 04:05:30 --> Language Class Initialized
INFO - 2020-02-03 04:05:30 --> Language Class Initialized
INFO - 2020-02-03 04:05:30 --> Config Class Initialized
INFO - 2020-02-03 04:05:30 --> Loader Class Initialized
INFO - 2020-02-03 04:05:30 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:30 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:30 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:30 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:30 --> Controller Class Initialized
DEBUG - 2020-02-03 04:05:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:05:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:05:30 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:30 --> Total execution time: 0.4048
INFO - 2020-02-03 04:05:31 --> Config Class Initialized
INFO - 2020-02-03 04:05:31 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:31 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:31 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:31 --> URI Class Initialized
INFO - 2020-02-03 04:05:31 --> Router Class Initialized
INFO - 2020-02-03 04:05:31 --> Output Class Initialized
INFO - 2020-02-03 04:05:31 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:31 --> Input Class Initialized
INFO - 2020-02-03 04:05:31 --> Language Class Initialized
INFO - 2020-02-03 04:05:31 --> Language Class Initialized
INFO - 2020-02-03 04:05:31 --> Config Class Initialized
INFO - 2020-02-03 04:05:31 --> Loader Class Initialized
INFO - 2020-02-03 04:05:31 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:31 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:31 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:31 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:31 --> Controller Class Initialized
INFO - 2020-02-03 04:05:32 --> Config Class Initialized
INFO - 2020-02-03 04:05:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:32 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:32 --> URI Class Initialized
INFO - 2020-02-03 04:05:32 --> Router Class Initialized
INFO - 2020-02-03 04:05:32 --> Output Class Initialized
INFO - 2020-02-03 04:05:32 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:32 --> Input Class Initialized
INFO - 2020-02-03 04:05:32 --> Language Class Initialized
INFO - 2020-02-03 04:05:32 --> Language Class Initialized
INFO - 2020-02-03 04:05:32 --> Config Class Initialized
INFO - 2020-02-03 04:05:32 --> Loader Class Initialized
INFO - 2020-02-03 04:05:32 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:32 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:32 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:32 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:32 --> Controller Class Initialized
INFO - 2020-02-03 04:05:32 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:32 --> Total execution time: 0.3509
INFO - 2020-02-03 04:05:35 --> Config Class Initialized
INFO - 2020-02-03 04:05:35 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:35 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:35 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:35 --> URI Class Initialized
INFO - 2020-02-03 04:05:35 --> Router Class Initialized
INFO - 2020-02-03 04:05:35 --> Output Class Initialized
INFO - 2020-02-03 04:05:35 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:35 --> Input Class Initialized
INFO - 2020-02-03 04:05:35 --> Language Class Initialized
INFO - 2020-02-03 04:05:35 --> Language Class Initialized
INFO - 2020-02-03 04:05:35 --> Config Class Initialized
INFO - 2020-02-03 04:05:35 --> Loader Class Initialized
INFO - 2020-02-03 04:05:35 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:35 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:35 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:35 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:35 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:35 --> Controller Class Initialized
DEBUG - 2020-02-03 04:05:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:05:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:05:35 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:35 --> Total execution time: 0.4173
INFO - 2020-02-03 04:05:35 --> Config Class Initialized
INFO - 2020-02-03 04:05:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:36 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:36 --> URI Class Initialized
INFO - 2020-02-03 04:05:36 --> Router Class Initialized
INFO - 2020-02-03 04:05:36 --> Output Class Initialized
INFO - 2020-02-03 04:05:36 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:36 --> Input Class Initialized
INFO - 2020-02-03 04:05:36 --> Language Class Initialized
INFO - 2020-02-03 04:05:36 --> Language Class Initialized
INFO - 2020-02-03 04:05:36 --> Config Class Initialized
INFO - 2020-02-03 04:05:36 --> Loader Class Initialized
INFO - 2020-02-03 04:05:36 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:36 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:36 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:36 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:36 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:36 --> Controller Class Initialized
INFO - 2020-02-03 04:05:38 --> Config Class Initialized
INFO - 2020-02-03 04:05:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:38 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:38 --> URI Class Initialized
INFO - 2020-02-03 04:05:38 --> Router Class Initialized
INFO - 2020-02-03 04:05:38 --> Output Class Initialized
INFO - 2020-02-03 04:05:38 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:38 --> Input Class Initialized
INFO - 2020-02-03 04:05:38 --> Language Class Initialized
INFO - 2020-02-03 04:05:38 --> Language Class Initialized
INFO - 2020-02-03 04:05:38 --> Config Class Initialized
INFO - 2020-02-03 04:05:38 --> Loader Class Initialized
INFO - 2020-02-03 04:05:38 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:38 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:38 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:38 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:38 --> Controller Class Initialized
INFO - 2020-02-03 04:05:38 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:38 --> Total execution time: 0.3611
INFO - 2020-02-03 04:05:45 --> Config Class Initialized
INFO - 2020-02-03 04:05:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:45 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:45 --> URI Class Initialized
INFO - 2020-02-03 04:05:45 --> Router Class Initialized
INFO - 2020-02-03 04:05:45 --> Output Class Initialized
INFO - 2020-02-03 04:05:45 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:45 --> Input Class Initialized
INFO - 2020-02-03 04:05:45 --> Language Class Initialized
INFO - 2020-02-03 04:05:46 --> Language Class Initialized
INFO - 2020-02-03 04:05:46 --> Config Class Initialized
INFO - 2020-02-03 04:05:46 --> Loader Class Initialized
INFO - 2020-02-03 04:05:46 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:46 --> Controller Class Initialized
DEBUG - 2020-02-03 04:05:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:05:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:05:46 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:46 --> Total execution time: 0.4152
INFO - 2020-02-03 04:05:46 --> Config Class Initialized
INFO - 2020-02-03 04:05:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:46 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:46 --> URI Class Initialized
INFO - 2020-02-03 04:05:46 --> Router Class Initialized
INFO - 2020-02-03 04:05:46 --> Output Class Initialized
INFO - 2020-02-03 04:05:46 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:46 --> Input Class Initialized
INFO - 2020-02-03 04:05:46 --> Language Class Initialized
INFO - 2020-02-03 04:05:46 --> Language Class Initialized
INFO - 2020-02-03 04:05:46 --> Config Class Initialized
INFO - 2020-02-03 04:05:46 --> Loader Class Initialized
INFO - 2020-02-03 04:05:46 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:46 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:46 --> Controller Class Initialized
INFO - 2020-02-03 04:05:47 --> Config Class Initialized
INFO - 2020-02-03 04:05:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:05:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:05:47 --> Utf8 Class Initialized
INFO - 2020-02-03 04:05:47 --> URI Class Initialized
INFO - 2020-02-03 04:05:47 --> Router Class Initialized
INFO - 2020-02-03 04:05:47 --> Output Class Initialized
INFO - 2020-02-03 04:05:47 --> Security Class Initialized
DEBUG - 2020-02-03 04:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:05:47 --> Input Class Initialized
INFO - 2020-02-03 04:05:47 --> Language Class Initialized
INFO - 2020-02-03 04:05:48 --> Language Class Initialized
INFO - 2020-02-03 04:05:48 --> Config Class Initialized
INFO - 2020-02-03 04:05:48 --> Loader Class Initialized
INFO - 2020-02-03 04:05:48 --> Helper loaded: url_helper
INFO - 2020-02-03 04:05:48 --> Helper loaded: file_helper
INFO - 2020-02-03 04:05:48 --> Helper loaded: form_helper
INFO - 2020-02-03 04:05:48 --> Helper loaded: my_helper
INFO - 2020-02-03 04:05:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:05:48 --> Controller Class Initialized
INFO - 2020-02-03 04:05:48 --> Final output sent to browser
DEBUG - 2020-02-03 04:05:48 --> Total execution time: 0.3823
INFO - 2020-02-03 04:06:10 --> Config Class Initialized
INFO - 2020-02-03 04:06:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:06:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:06:10 --> Utf8 Class Initialized
INFO - 2020-02-03 04:06:10 --> URI Class Initialized
INFO - 2020-02-03 04:06:10 --> Router Class Initialized
INFO - 2020-02-03 04:06:10 --> Output Class Initialized
INFO - 2020-02-03 04:06:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:06:10 --> Input Class Initialized
INFO - 2020-02-03 04:06:10 --> Language Class Initialized
INFO - 2020-02-03 04:06:10 --> Language Class Initialized
INFO - 2020-02-03 04:06:10 --> Config Class Initialized
INFO - 2020-02-03 04:06:10 --> Loader Class Initialized
INFO - 2020-02-03 04:06:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:06:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:06:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:06:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:06:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:06:10 --> Controller Class Initialized
DEBUG - 2020-02-03 04:06:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:06:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:06:10 --> Final output sent to browser
DEBUG - 2020-02-03 04:06:10 --> Total execution time: 0.5216
INFO - 2020-02-03 04:07:53 --> Config Class Initialized
INFO - 2020-02-03 04:07:53 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:07:53 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:07:53 --> Utf8 Class Initialized
INFO - 2020-02-03 04:07:53 --> URI Class Initialized
INFO - 2020-02-03 04:07:53 --> Router Class Initialized
INFO - 2020-02-03 04:07:53 --> Output Class Initialized
INFO - 2020-02-03 04:07:53 --> Security Class Initialized
DEBUG - 2020-02-03 04:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:07:53 --> Input Class Initialized
INFO - 2020-02-03 04:07:53 --> Language Class Initialized
INFO - 2020-02-03 04:07:53 --> Language Class Initialized
INFO - 2020-02-03 04:07:53 --> Config Class Initialized
INFO - 2020-02-03 04:07:53 --> Loader Class Initialized
INFO - 2020-02-03 04:07:53 --> Helper loaded: url_helper
INFO - 2020-02-03 04:07:53 --> Helper loaded: file_helper
INFO - 2020-02-03 04:07:53 --> Helper loaded: form_helper
INFO - 2020-02-03 04:07:53 --> Helper loaded: my_helper
INFO - 2020-02-03 04:07:53 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:07:53 --> Controller Class Initialized
DEBUG - 2020-02-03 04:07:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:07:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:07:53 --> Final output sent to browser
DEBUG - 2020-02-03 04:07:53 --> Total execution time: 0.3801
INFO - 2020-02-03 04:07:54 --> Config Class Initialized
INFO - 2020-02-03 04:07:54 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:07:54 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:07:54 --> Utf8 Class Initialized
INFO - 2020-02-03 04:07:54 --> URI Class Initialized
INFO - 2020-02-03 04:07:54 --> Router Class Initialized
INFO - 2020-02-03 04:07:54 --> Output Class Initialized
INFO - 2020-02-03 04:07:54 --> Security Class Initialized
DEBUG - 2020-02-03 04:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:07:54 --> Input Class Initialized
INFO - 2020-02-03 04:07:54 --> Language Class Initialized
INFO - 2020-02-03 04:07:54 --> Language Class Initialized
INFO - 2020-02-03 04:07:54 --> Config Class Initialized
INFO - 2020-02-03 04:07:54 --> Loader Class Initialized
INFO - 2020-02-03 04:07:54 --> Helper loaded: url_helper
INFO - 2020-02-03 04:07:54 --> Helper loaded: file_helper
INFO - 2020-02-03 04:07:54 --> Helper loaded: form_helper
INFO - 2020-02-03 04:07:54 --> Helper loaded: my_helper
INFO - 2020-02-03 04:07:54 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:07:54 --> Controller Class Initialized
INFO - 2020-02-03 04:07:55 --> Config Class Initialized
INFO - 2020-02-03 04:07:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:07:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:07:55 --> Utf8 Class Initialized
INFO - 2020-02-03 04:07:55 --> URI Class Initialized
INFO - 2020-02-03 04:07:55 --> Router Class Initialized
INFO - 2020-02-03 04:07:55 --> Output Class Initialized
INFO - 2020-02-03 04:07:55 --> Security Class Initialized
DEBUG - 2020-02-03 04:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:07:55 --> Input Class Initialized
INFO - 2020-02-03 04:07:55 --> Language Class Initialized
INFO - 2020-02-03 04:07:55 --> Language Class Initialized
INFO - 2020-02-03 04:07:55 --> Config Class Initialized
INFO - 2020-02-03 04:07:55 --> Loader Class Initialized
INFO - 2020-02-03 04:07:55 --> Helper loaded: url_helper
INFO - 2020-02-03 04:07:55 --> Helper loaded: file_helper
INFO - 2020-02-03 04:07:55 --> Helper loaded: form_helper
INFO - 2020-02-03 04:07:55 --> Helper loaded: my_helper
INFO - 2020-02-03 04:07:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:07:56 --> Controller Class Initialized
INFO - 2020-02-03 04:07:56 --> Final output sent to browser
DEBUG - 2020-02-03 04:07:56 --> Total execution time: 0.3940
INFO - 2020-02-03 04:07:57 --> Config Class Initialized
INFO - 2020-02-03 04:07:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:07:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:07:57 --> Utf8 Class Initialized
INFO - 2020-02-03 04:07:57 --> URI Class Initialized
INFO - 2020-02-03 04:07:57 --> Router Class Initialized
INFO - 2020-02-03 04:07:57 --> Output Class Initialized
INFO - 2020-02-03 04:07:57 --> Security Class Initialized
DEBUG - 2020-02-03 04:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:07:57 --> Input Class Initialized
INFO - 2020-02-03 04:07:57 --> Language Class Initialized
INFO - 2020-02-03 04:07:57 --> Language Class Initialized
INFO - 2020-02-03 04:07:57 --> Config Class Initialized
INFO - 2020-02-03 04:07:57 --> Loader Class Initialized
INFO - 2020-02-03 04:07:57 --> Helper loaded: url_helper
INFO - 2020-02-03 04:07:57 --> Helper loaded: file_helper
INFO - 2020-02-03 04:07:57 --> Helper loaded: form_helper
INFO - 2020-02-03 04:07:57 --> Helper loaded: my_helper
INFO - 2020-02-03 04:07:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:07:58 --> Controller Class Initialized
DEBUG - 2020-02-03 04:07:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:07:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:07:58 --> Final output sent to browser
DEBUG - 2020-02-03 04:07:58 --> Total execution time: 0.4808
INFO - 2020-02-03 04:08:05 --> Config Class Initialized
INFO - 2020-02-03 04:08:05 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:05 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:05 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:05 --> URI Class Initialized
INFO - 2020-02-03 04:08:05 --> Router Class Initialized
INFO - 2020-02-03 04:08:05 --> Output Class Initialized
INFO - 2020-02-03 04:08:05 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:05 --> Input Class Initialized
INFO - 2020-02-03 04:08:05 --> Language Class Initialized
INFO - 2020-02-03 04:08:05 --> Language Class Initialized
INFO - 2020-02-03 04:08:05 --> Config Class Initialized
INFO - 2020-02-03 04:08:05 --> Loader Class Initialized
INFO - 2020-02-03 04:08:05 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:05 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:05 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:05 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:05 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:05 --> Controller Class Initialized
DEBUG - 2020-02-03 04:08:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:08:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:08:05 --> Final output sent to browser
DEBUG - 2020-02-03 04:08:05 --> Total execution time: 0.4271
INFO - 2020-02-03 04:08:06 --> Config Class Initialized
INFO - 2020-02-03 04:08:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:06 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:06 --> URI Class Initialized
INFO - 2020-02-03 04:08:06 --> Router Class Initialized
INFO - 2020-02-03 04:08:06 --> Output Class Initialized
INFO - 2020-02-03 04:08:06 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:06 --> Input Class Initialized
INFO - 2020-02-03 04:08:06 --> Language Class Initialized
INFO - 2020-02-03 04:08:06 --> Language Class Initialized
INFO - 2020-02-03 04:08:06 --> Config Class Initialized
INFO - 2020-02-03 04:08:06 --> Loader Class Initialized
INFO - 2020-02-03 04:08:06 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:06 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:06 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:06 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:06 --> Controller Class Initialized
INFO - 2020-02-03 04:08:07 --> Config Class Initialized
INFO - 2020-02-03 04:08:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:08 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:08 --> URI Class Initialized
INFO - 2020-02-03 04:08:08 --> Router Class Initialized
INFO - 2020-02-03 04:08:08 --> Output Class Initialized
INFO - 2020-02-03 04:08:08 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:08 --> Input Class Initialized
INFO - 2020-02-03 04:08:08 --> Language Class Initialized
INFO - 2020-02-03 04:08:08 --> Language Class Initialized
INFO - 2020-02-03 04:08:08 --> Config Class Initialized
INFO - 2020-02-03 04:08:08 --> Loader Class Initialized
INFO - 2020-02-03 04:08:08 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:08 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:08 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:08 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:08 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:08 --> Controller Class Initialized
INFO - 2020-02-03 04:08:08 --> Final output sent to browser
DEBUG - 2020-02-03 04:08:08 --> Total execution time: 0.3927
INFO - 2020-02-03 04:08:09 --> Config Class Initialized
INFO - 2020-02-03 04:08:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:09 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:10 --> URI Class Initialized
INFO - 2020-02-03 04:08:10 --> Router Class Initialized
INFO - 2020-02-03 04:08:10 --> Output Class Initialized
INFO - 2020-02-03 04:08:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:10 --> Input Class Initialized
INFO - 2020-02-03 04:08:10 --> Language Class Initialized
INFO - 2020-02-03 04:08:10 --> Language Class Initialized
INFO - 2020-02-03 04:08:10 --> Config Class Initialized
INFO - 2020-02-03 04:08:10 --> Loader Class Initialized
INFO - 2020-02-03 04:08:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:10 --> Controller Class Initialized
DEBUG - 2020-02-03 04:08:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:08:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:08:10 --> Final output sent to browser
DEBUG - 2020-02-03 04:08:10 --> Total execution time: 0.4591
INFO - 2020-02-03 04:08:10 --> Config Class Initialized
INFO - 2020-02-03 04:08:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:10 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:10 --> URI Class Initialized
INFO - 2020-02-03 04:08:10 --> Router Class Initialized
INFO - 2020-02-03 04:08:10 --> Output Class Initialized
INFO - 2020-02-03 04:08:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:10 --> Input Class Initialized
INFO - 2020-02-03 04:08:10 --> Language Class Initialized
INFO - 2020-02-03 04:08:10 --> Language Class Initialized
INFO - 2020-02-03 04:08:10 --> Config Class Initialized
INFO - 2020-02-03 04:08:10 --> Loader Class Initialized
INFO - 2020-02-03 04:08:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:10 --> Controller Class Initialized
INFO - 2020-02-03 04:08:11 --> Config Class Initialized
INFO - 2020-02-03 04:08:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:12 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:12 --> URI Class Initialized
INFO - 2020-02-03 04:08:12 --> Router Class Initialized
INFO - 2020-02-03 04:08:12 --> Output Class Initialized
INFO - 2020-02-03 04:08:12 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:12 --> Input Class Initialized
INFO - 2020-02-03 04:08:12 --> Language Class Initialized
INFO - 2020-02-03 04:08:12 --> Language Class Initialized
INFO - 2020-02-03 04:08:12 --> Config Class Initialized
INFO - 2020-02-03 04:08:12 --> Loader Class Initialized
INFO - 2020-02-03 04:08:12 --> Helper loaded: url_helper
INFO - 2020-02-03 04:08:12 --> Helper loaded: file_helper
INFO - 2020-02-03 04:08:12 --> Helper loaded: form_helper
INFO - 2020-02-03 04:08:12 --> Helper loaded: my_helper
INFO - 2020-02-03 04:08:12 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:08:12 --> Controller Class Initialized
INFO - 2020-02-03 04:08:12 --> Final output sent to browser
DEBUG - 2020-02-03 04:08:12 --> Total execution time: 0.4106
INFO - 2020-02-03 04:08:22 --> Config Class Initialized
INFO - 2020-02-03 04:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:22 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:22 --> Config Class Initialized
INFO - 2020-02-03 04:08:22 --> URI Class Initialized
INFO - 2020-02-03 04:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:08:22 --> Router Class Initialized
INFO - 2020-02-03 04:08:22 --> Utf8 Class Initialized
INFO - 2020-02-03 04:08:22 --> Output Class Initialized
INFO - 2020-02-03 04:08:22 --> URI Class Initialized
INFO - 2020-02-03 04:08:22 --> Security Class Initialized
INFO - 2020-02-03 04:08:23 --> Router Class Initialized
DEBUG - 2020-02-03 04:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:23 --> Input Class Initialized
INFO - 2020-02-03 04:08:23 --> Output Class Initialized
INFO - 2020-02-03 04:08:23 --> Language Class Initialized
ERROR - 2020-02-03 04:08:23 --> 404 Page Not Found: /index
INFO - 2020-02-03 04:08:23 --> Security Class Initialized
DEBUG - 2020-02-03 04:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:08:23 --> Input Class Initialized
INFO - 2020-02-03 04:08:23 --> Language Class Initialized
ERROR - 2020-02-03 04:08:23 --> 404 Page Not Found: /index
INFO - 2020-02-03 04:09:56 --> Config Class Initialized
INFO - 2020-02-03 04:09:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:09:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:09:56 --> Utf8 Class Initialized
INFO - 2020-02-03 04:09:56 --> URI Class Initialized
INFO - 2020-02-03 04:09:56 --> Router Class Initialized
INFO - 2020-02-03 04:09:56 --> Output Class Initialized
INFO - 2020-02-03 04:09:56 --> Security Class Initialized
DEBUG - 2020-02-03 04:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:09:56 --> Input Class Initialized
INFO - 2020-02-03 04:09:56 --> Language Class Initialized
INFO - 2020-02-03 04:09:56 --> Language Class Initialized
INFO - 2020-02-03 04:09:56 --> Config Class Initialized
INFO - 2020-02-03 04:09:56 --> Loader Class Initialized
INFO - 2020-02-03 04:09:56 --> Helper loaded: url_helper
INFO - 2020-02-03 04:09:56 --> Helper loaded: file_helper
INFO - 2020-02-03 04:09:56 --> Helper loaded: form_helper
INFO - 2020-02-03 04:09:56 --> Helper loaded: my_helper
INFO - 2020-02-03 04:09:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:09:56 --> Controller Class Initialized
DEBUG - 2020-02-03 04:09:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:09:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:09:56 --> Final output sent to browser
DEBUG - 2020-02-03 04:09:56 --> Total execution time: 0.4030
INFO - 2020-02-03 04:09:56 --> Config Class Initialized
INFO - 2020-02-03 04:09:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:09:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:09:57 --> Utf8 Class Initialized
INFO - 2020-02-03 04:09:57 --> URI Class Initialized
INFO - 2020-02-03 04:09:57 --> Router Class Initialized
INFO - 2020-02-03 04:09:57 --> Output Class Initialized
INFO - 2020-02-03 04:09:57 --> Security Class Initialized
INFO - 2020-02-03 04:09:57 --> Config Class Initialized
INFO - 2020-02-03 04:09:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:09:57 --> Input Class Initialized
DEBUG - 2020-02-03 04:09:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:09:57 --> Utf8 Class Initialized
INFO - 2020-02-03 04:09:57 --> Language Class Initialized
ERROR - 2020-02-03 04:09:57 --> 404 Page Not Found: /index
INFO - 2020-02-03 04:09:57 --> URI Class Initialized
INFO - 2020-02-03 04:09:57 --> Router Class Initialized
INFO - 2020-02-03 04:09:57 --> Output Class Initialized
INFO - 2020-02-03 04:09:57 --> Security Class Initialized
DEBUG - 2020-02-03 04:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:09:57 --> Input Class Initialized
INFO - 2020-02-03 04:09:57 --> Language Class Initialized
INFO - 2020-02-03 04:09:57 --> Language Class Initialized
INFO - 2020-02-03 04:09:57 --> Config Class Initialized
INFO - 2020-02-03 04:09:57 --> Loader Class Initialized
INFO - 2020-02-03 04:09:57 --> Helper loaded: url_helper
INFO - 2020-02-03 04:09:57 --> Helper loaded: file_helper
INFO - 2020-02-03 04:09:57 --> Helper loaded: form_helper
INFO - 2020-02-03 04:09:57 --> Helper loaded: my_helper
INFO - 2020-02-03 04:09:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:09:57 --> Controller Class Initialized
INFO - 2020-02-03 04:10:01 --> Config Class Initialized
INFO - 2020-02-03 04:10:01 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:01 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:01 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:01 --> URI Class Initialized
INFO - 2020-02-03 04:10:01 --> Router Class Initialized
INFO - 2020-02-03 04:10:01 --> Output Class Initialized
INFO - 2020-02-03 04:10:01 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:01 --> Input Class Initialized
INFO - 2020-02-03 04:10:01 --> Language Class Initialized
INFO - 2020-02-03 04:10:01 --> Language Class Initialized
INFO - 2020-02-03 04:10:01 --> Config Class Initialized
INFO - 2020-02-03 04:10:01 --> Loader Class Initialized
INFO - 2020-02-03 04:10:01 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:01 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:01 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:01 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:01 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:01 --> Controller Class Initialized
INFO - 2020-02-03 04:10:01 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:01 --> Total execution time: 0.4997
INFO - 2020-02-03 04:10:06 --> Config Class Initialized
INFO - 2020-02-03 04:10:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:06 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:06 --> URI Class Initialized
INFO - 2020-02-03 04:10:06 --> Router Class Initialized
INFO - 2020-02-03 04:10:06 --> Output Class Initialized
INFO - 2020-02-03 04:10:06 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:06 --> Input Class Initialized
INFO - 2020-02-03 04:10:06 --> Language Class Initialized
INFO - 2020-02-03 04:10:06 --> Language Class Initialized
INFO - 2020-02-03 04:10:06 --> Config Class Initialized
INFO - 2020-02-03 04:10:06 --> Loader Class Initialized
INFO - 2020-02-03 04:10:06 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:06 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:06 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:06 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:06 --> Controller Class Initialized
DEBUG - 2020-02-03 04:10:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:10:06 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:10:06 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:06 --> Total execution time: 0.4872
INFO - 2020-02-03 04:10:06 --> Config Class Initialized
INFO - 2020-02-03 04:10:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:06 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:06 --> URI Class Initialized
INFO - 2020-02-03 04:10:06 --> Router Class Initialized
INFO - 2020-02-03 04:10:06 --> Output Class Initialized
INFO - 2020-02-03 04:10:07 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:07 --> Input Class Initialized
INFO - 2020-02-03 04:10:07 --> Language Class Initialized
INFO - 2020-02-03 04:10:07 --> Language Class Initialized
INFO - 2020-02-03 04:10:07 --> Config Class Initialized
INFO - 2020-02-03 04:10:07 --> Loader Class Initialized
INFO - 2020-02-03 04:10:07 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:07 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:07 --> Controller Class Initialized
INFO - 2020-02-03 04:10:07 --> Config Class Initialized
INFO - 2020-02-03 04:10:07 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:07 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:07 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:07 --> URI Class Initialized
INFO - 2020-02-03 04:10:07 --> Router Class Initialized
INFO - 2020-02-03 04:10:07 --> Output Class Initialized
INFO - 2020-02-03 04:10:07 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:07 --> Input Class Initialized
INFO - 2020-02-03 04:10:07 --> Language Class Initialized
INFO - 2020-02-03 04:10:07 --> Language Class Initialized
INFO - 2020-02-03 04:10:07 --> Config Class Initialized
INFO - 2020-02-03 04:10:07 --> Loader Class Initialized
INFO - 2020-02-03 04:10:07 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:07 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:07 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:07 --> Controller Class Initialized
INFO - 2020-02-03 04:10:07 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:07 --> Total execution time: 0.3994
INFO - 2020-02-03 04:10:09 --> Config Class Initialized
INFO - 2020-02-03 04:10:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:10 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:10 --> URI Class Initialized
INFO - 2020-02-03 04:10:10 --> Router Class Initialized
INFO - 2020-02-03 04:10:10 --> Output Class Initialized
INFO - 2020-02-03 04:10:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:10 --> Input Class Initialized
INFO - 2020-02-03 04:10:10 --> Language Class Initialized
INFO - 2020-02-03 04:10:10 --> Language Class Initialized
INFO - 2020-02-03 04:10:10 --> Config Class Initialized
INFO - 2020-02-03 04:10:10 --> Loader Class Initialized
INFO - 2020-02-03 04:10:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:10 --> Controller Class Initialized
INFO - 2020-02-03 04:10:10 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:10 --> Total execution time: 0.4357
INFO - 2020-02-03 04:10:13 --> Config Class Initialized
INFO - 2020-02-03 04:10:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:13 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:13 --> URI Class Initialized
INFO - 2020-02-03 04:10:13 --> Router Class Initialized
INFO - 2020-02-03 04:10:13 --> Output Class Initialized
INFO - 2020-02-03 04:10:13 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:13 --> Input Class Initialized
INFO - 2020-02-03 04:10:13 --> Language Class Initialized
INFO - 2020-02-03 04:10:13 --> Language Class Initialized
INFO - 2020-02-03 04:10:13 --> Config Class Initialized
INFO - 2020-02-03 04:10:13 --> Loader Class Initialized
INFO - 2020-02-03 04:10:13 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:13 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:13 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:13 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:13 --> Controller Class Initialized
DEBUG - 2020-02-03 04:10:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 04:10:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:10:13 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:13 --> Total execution time: 0.4952
INFO - 2020-02-03 04:10:13 --> Config Class Initialized
INFO - 2020-02-03 04:10:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:13 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:13 --> URI Class Initialized
INFO - 2020-02-03 04:10:13 --> Router Class Initialized
INFO - 2020-02-03 04:10:13 --> Output Class Initialized
INFO - 2020-02-03 04:10:13 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:13 --> Input Class Initialized
INFO - 2020-02-03 04:10:13 --> Language Class Initialized
INFO - 2020-02-03 04:10:13 --> Language Class Initialized
INFO - 2020-02-03 04:10:13 --> Config Class Initialized
INFO - 2020-02-03 04:10:13 --> Loader Class Initialized
INFO - 2020-02-03 04:10:14 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:14 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:14 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:14 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:14 --> Controller Class Initialized
INFO - 2020-02-03 04:10:14 --> Config Class Initialized
INFO - 2020-02-03 04:10:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:14 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:15 --> URI Class Initialized
INFO - 2020-02-03 04:10:15 --> Router Class Initialized
INFO - 2020-02-03 04:10:15 --> Output Class Initialized
INFO - 2020-02-03 04:10:15 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:15 --> Input Class Initialized
INFO - 2020-02-03 04:10:15 --> Language Class Initialized
INFO - 2020-02-03 04:10:15 --> Language Class Initialized
INFO - 2020-02-03 04:10:15 --> Config Class Initialized
INFO - 2020-02-03 04:10:15 --> Loader Class Initialized
INFO - 2020-02-03 04:10:15 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:15 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:15 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:15 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:15 --> Controller Class Initialized
INFO - 2020-02-03 04:10:15 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:15 --> Total execution time: 0.4339
INFO - 2020-02-03 04:10:21 --> Config Class Initialized
INFO - 2020-02-03 04:10:21 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:21 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:21 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:21 --> URI Class Initialized
DEBUG - 2020-02-03 04:10:21 --> No URI present. Default controller set.
INFO - 2020-02-03 04:10:21 --> Router Class Initialized
INFO - 2020-02-03 04:10:21 --> Output Class Initialized
INFO - 2020-02-03 04:10:21 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:21 --> Input Class Initialized
INFO - 2020-02-03 04:10:21 --> Language Class Initialized
INFO - 2020-02-03 04:10:21 --> Language Class Initialized
INFO - 2020-02-03 04:10:21 --> Config Class Initialized
INFO - 2020-02-03 04:10:21 --> Loader Class Initialized
INFO - 2020-02-03 04:10:21 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:21 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:21 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:21 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:21 --> Controller Class Initialized
DEBUG - 2020-02-03 04:10:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:10:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:10:21 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:21 --> Total execution time: 0.4563
INFO - 2020-02-03 04:10:28 --> Config Class Initialized
INFO - 2020-02-03 04:10:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:28 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:28 --> URI Class Initialized
INFO - 2020-02-03 04:10:28 --> Router Class Initialized
INFO - 2020-02-03 04:10:28 --> Output Class Initialized
INFO - 2020-02-03 04:10:28 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:28 --> Input Class Initialized
INFO - 2020-02-03 04:10:28 --> Language Class Initialized
INFO - 2020-02-03 04:10:28 --> Language Class Initialized
INFO - 2020-02-03 04:10:28 --> Config Class Initialized
INFO - 2020-02-03 04:10:28 --> Loader Class Initialized
INFO - 2020-02-03 04:10:28 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:28 --> Controller Class Initialized
INFO - 2020-02-03 04:10:28 --> Helper loaded: cookie_helper
INFO - 2020-02-03 04:10:28 --> Config Class Initialized
INFO - 2020-02-03 04:10:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:28 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:28 --> URI Class Initialized
INFO - 2020-02-03 04:10:28 --> Router Class Initialized
INFO - 2020-02-03 04:10:28 --> Output Class Initialized
INFO - 2020-02-03 04:10:28 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:28 --> Input Class Initialized
INFO - 2020-02-03 04:10:28 --> Language Class Initialized
INFO - 2020-02-03 04:10:28 --> Language Class Initialized
INFO - 2020-02-03 04:10:28 --> Config Class Initialized
INFO - 2020-02-03 04:10:28 --> Loader Class Initialized
INFO - 2020-02-03 04:10:28 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:28 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:28 --> Controller Class Initialized
INFO - 2020-02-03 04:10:28 --> Config Class Initialized
INFO - 2020-02-03 04:10:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:28 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:28 --> URI Class Initialized
INFO - 2020-02-03 04:10:28 --> Router Class Initialized
INFO - 2020-02-03 04:10:28 --> Output Class Initialized
INFO - 2020-02-03 04:10:29 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:29 --> Input Class Initialized
INFO - 2020-02-03 04:10:29 --> Language Class Initialized
INFO - 2020-02-03 04:10:29 --> Language Class Initialized
INFO - 2020-02-03 04:10:29 --> Config Class Initialized
INFO - 2020-02-03 04:10:29 --> Loader Class Initialized
INFO - 2020-02-03 04:10:29 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:29 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:29 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:29 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:29 --> Controller Class Initialized
DEBUG - 2020-02-03 04:10:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 04:10:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:10:29 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:29 --> Total execution time: 0.3848
INFO - 2020-02-03 04:10:37 --> Config Class Initialized
INFO - 2020-02-03 04:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:37 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:37 --> URI Class Initialized
INFO - 2020-02-03 04:10:37 --> Router Class Initialized
INFO - 2020-02-03 04:10:37 --> Output Class Initialized
INFO - 2020-02-03 04:10:37 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:37 --> Input Class Initialized
INFO - 2020-02-03 04:10:37 --> Language Class Initialized
INFO - 2020-02-03 04:10:37 --> Language Class Initialized
INFO - 2020-02-03 04:10:37 --> Config Class Initialized
INFO - 2020-02-03 04:10:37 --> Loader Class Initialized
INFO - 2020-02-03 04:10:37 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:37 --> Controller Class Initialized
INFO - 2020-02-03 04:10:37 --> Helper loaded: cookie_helper
INFO - 2020-02-03 04:10:37 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:37 --> Total execution time: 0.4000
INFO - 2020-02-03 04:10:37 --> Config Class Initialized
INFO - 2020-02-03 04:10:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:10:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:10:37 --> Utf8 Class Initialized
INFO - 2020-02-03 04:10:37 --> URI Class Initialized
INFO - 2020-02-03 04:10:37 --> Router Class Initialized
INFO - 2020-02-03 04:10:37 --> Output Class Initialized
INFO - 2020-02-03 04:10:37 --> Security Class Initialized
DEBUG - 2020-02-03 04:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:10:37 --> Input Class Initialized
INFO - 2020-02-03 04:10:37 --> Language Class Initialized
INFO - 2020-02-03 04:10:37 --> Language Class Initialized
INFO - 2020-02-03 04:10:37 --> Config Class Initialized
INFO - 2020-02-03 04:10:37 --> Loader Class Initialized
INFO - 2020-02-03 04:10:37 --> Helper loaded: url_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: file_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: form_helper
INFO - 2020-02-03 04:10:37 --> Helper loaded: my_helper
INFO - 2020-02-03 04:10:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:10:37 --> Controller Class Initialized
DEBUG - 2020-02-03 04:10:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 04:10:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:10:38 --> Final output sent to browser
DEBUG - 2020-02-03 04:10:38 --> Total execution time: 0.4519
INFO - 2020-02-03 04:12:22 --> Config Class Initialized
INFO - 2020-02-03 04:12:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:12:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:12:22 --> Utf8 Class Initialized
INFO - 2020-02-03 04:12:22 --> URI Class Initialized
INFO - 2020-02-03 04:12:22 --> Router Class Initialized
INFO - 2020-02-03 04:12:22 --> Output Class Initialized
INFO - 2020-02-03 04:12:22 --> Security Class Initialized
DEBUG - 2020-02-03 04:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:12:22 --> Input Class Initialized
INFO - 2020-02-03 04:12:22 --> Language Class Initialized
INFO - 2020-02-03 04:12:22 --> Language Class Initialized
INFO - 2020-02-03 04:12:22 --> Config Class Initialized
INFO - 2020-02-03 04:12:22 --> Loader Class Initialized
INFO - 2020-02-03 04:12:22 --> Helper loaded: url_helper
INFO - 2020-02-03 04:12:22 --> Helper loaded: file_helper
INFO - 2020-02-03 04:12:22 --> Helper loaded: form_helper
INFO - 2020-02-03 04:12:22 --> Helper loaded: my_helper
INFO - 2020-02-03 04:12:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:12:22 --> Controller Class Initialized
DEBUG - 2020-02-03 04:12:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 04:12:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:12:22 --> Final output sent to browser
DEBUG - 2020-02-03 04:12:22 --> Total execution time: 0.4227
INFO - 2020-02-03 04:12:29 --> Config Class Initialized
INFO - 2020-02-03 04:12:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:12:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:12:30 --> Utf8 Class Initialized
INFO - 2020-02-03 04:12:30 --> URI Class Initialized
INFO - 2020-02-03 04:12:30 --> Router Class Initialized
INFO - 2020-02-03 04:12:30 --> Output Class Initialized
INFO - 2020-02-03 04:12:30 --> Security Class Initialized
DEBUG - 2020-02-03 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:12:30 --> Input Class Initialized
INFO - 2020-02-03 04:12:30 --> Language Class Initialized
INFO - 2020-02-03 04:12:30 --> Language Class Initialized
INFO - 2020-02-03 04:12:30 --> Config Class Initialized
INFO - 2020-02-03 04:12:30 --> Loader Class Initialized
INFO - 2020-02-03 04:12:30 --> Helper loaded: url_helper
INFO - 2020-02-03 04:12:30 --> Helper loaded: file_helper
INFO - 2020-02-03 04:12:30 --> Helper loaded: form_helper
INFO - 2020-02-03 04:12:30 --> Helper loaded: my_helper
INFO - 2020-02-03 04:12:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:12:30 --> Controller Class Initialized
DEBUG - 2020-02-03 04:12:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 04:12:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:12:30 --> Final output sent to browser
DEBUG - 2020-02-03 04:12:30 --> Total execution time: 0.4072
INFO - 2020-02-03 04:27:25 --> Config Class Initialized
INFO - 2020-02-03 04:27:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:27:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:27:25 --> Utf8 Class Initialized
INFO - 2020-02-03 04:27:25 --> URI Class Initialized
INFO - 2020-02-03 04:27:25 --> Router Class Initialized
INFO - 2020-02-03 04:27:25 --> Output Class Initialized
INFO - 2020-02-03 04:27:25 --> Security Class Initialized
DEBUG - 2020-02-03 04:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:27:25 --> Input Class Initialized
INFO - 2020-02-03 04:27:25 --> Language Class Initialized
INFO - 2020-02-03 04:27:25 --> Language Class Initialized
INFO - 2020-02-03 04:27:25 --> Config Class Initialized
INFO - 2020-02-03 04:27:25 --> Loader Class Initialized
INFO - 2020-02-03 04:27:25 --> Helper loaded: url_helper
INFO - 2020-02-03 04:27:25 --> Helper loaded: file_helper
INFO - 2020-02-03 04:27:25 --> Helper loaded: form_helper
INFO - 2020-02-03 04:27:25 --> Helper loaded: my_helper
INFO - 2020-02-03 04:27:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:27:26 --> Controller Class Initialized
DEBUG - 2020-02-03 04:27:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-02-03 04:27:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:27:26 --> Final output sent to browser
DEBUG - 2020-02-03 04:27:26 --> Total execution time: 0.4463
INFO - 2020-02-03 04:27:47 --> Config Class Initialized
INFO - 2020-02-03 04:27:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:27:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:27:47 --> Utf8 Class Initialized
INFO - 2020-02-03 04:27:47 --> URI Class Initialized
INFO - 2020-02-03 04:27:47 --> Router Class Initialized
INFO - 2020-02-03 04:27:47 --> Output Class Initialized
INFO - 2020-02-03 04:27:47 --> Security Class Initialized
DEBUG - 2020-02-03 04:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:27:47 --> Input Class Initialized
INFO - 2020-02-03 04:27:47 --> Language Class Initialized
INFO - 2020-02-03 04:27:47 --> Language Class Initialized
INFO - 2020-02-03 04:27:47 --> Config Class Initialized
INFO - 2020-02-03 04:27:47 --> Loader Class Initialized
INFO - 2020-02-03 04:27:47 --> Helper loaded: url_helper
INFO - 2020-02-03 04:27:47 --> Helper loaded: file_helper
INFO - 2020-02-03 04:27:47 --> Helper loaded: form_helper
INFO - 2020-02-03 04:27:47 --> Helper loaded: my_helper
INFO - 2020-02-03 04:27:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:27:47 --> Controller Class Initialized
DEBUG - 2020-02-03 04:27:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-02-03 04:27:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:27:47 --> Final output sent to browser
DEBUG - 2020-02-03 04:27:47 --> Total execution time: 0.4605
INFO - 2020-02-03 04:27:48 --> Config Class Initialized
INFO - 2020-02-03 04:27:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:27:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:27:48 --> Utf8 Class Initialized
INFO - 2020-02-03 04:27:48 --> URI Class Initialized
INFO - 2020-02-03 04:27:48 --> Router Class Initialized
INFO - 2020-02-03 04:27:48 --> Output Class Initialized
INFO - 2020-02-03 04:27:48 --> Security Class Initialized
DEBUG - 2020-02-03 04:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:27:48 --> Input Class Initialized
INFO - 2020-02-03 04:27:48 --> Language Class Initialized
INFO - 2020-02-03 04:27:48 --> Language Class Initialized
INFO - 2020-02-03 04:27:48 --> Config Class Initialized
INFO - 2020-02-03 04:27:48 --> Loader Class Initialized
INFO - 2020-02-03 04:27:48 --> Helper loaded: url_helper
INFO - 2020-02-03 04:27:48 --> Helper loaded: file_helper
INFO - 2020-02-03 04:27:48 --> Helper loaded: form_helper
INFO - 2020-02-03 04:27:48 --> Helper loaded: my_helper
INFO - 2020-02-03 04:27:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:27:48 --> Controller Class Initialized
INFO - 2020-02-03 04:27:53 --> Config Class Initialized
INFO - 2020-02-03 04:27:53 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:27:53 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:27:53 --> Utf8 Class Initialized
INFO - 2020-02-03 04:27:53 --> URI Class Initialized
INFO - 2020-02-03 04:27:53 --> Router Class Initialized
INFO - 2020-02-03 04:27:53 --> Output Class Initialized
INFO - 2020-02-03 04:27:53 --> Security Class Initialized
DEBUG - 2020-02-03 04:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:27:53 --> Input Class Initialized
INFO - 2020-02-03 04:27:53 --> Language Class Initialized
INFO - 2020-02-03 04:27:53 --> Language Class Initialized
INFO - 2020-02-03 04:27:53 --> Config Class Initialized
INFO - 2020-02-03 04:27:53 --> Loader Class Initialized
INFO - 2020-02-03 04:27:53 --> Helper loaded: url_helper
INFO - 2020-02-03 04:27:53 --> Helper loaded: file_helper
INFO - 2020-02-03 04:27:53 --> Helper loaded: form_helper
INFO - 2020-02-03 04:27:53 --> Helper loaded: my_helper
INFO - 2020-02-03 04:27:53 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:27:53 --> Controller Class Initialized
DEBUG - 2020-02-03 04:27:54 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-02-03 04:27:54 --> Final output sent to browser
DEBUG - 2020-02-03 04:27:54 --> Total execution time: 0.7306
INFO - 2020-02-03 04:28:04 --> Config Class Initialized
INFO - 2020-02-03 04:28:04 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:04 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:04 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:04 --> URI Class Initialized
INFO - 2020-02-03 04:28:04 --> Router Class Initialized
INFO - 2020-02-03 04:28:04 --> Output Class Initialized
INFO - 2020-02-03 04:28:04 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:04 --> Input Class Initialized
INFO - 2020-02-03 04:28:04 --> Language Class Initialized
INFO - 2020-02-03 04:28:04 --> Language Class Initialized
INFO - 2020-02-03 04:28:04 --> Config Class Initialized
INFO - 2020-02-03 04:28:04 --> Loader Class Initialized
INFO - 2020-02-03 04:28:04 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:04 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:04 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:04 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:04 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:04 --> Controller Class Initialized
DEBUG - 2020-02-03 04:28:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/n_absensi/views/list.php
DEBUG - 2020-02-03 04:28:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:28:04 --> Final output sent to browser
DEBUG - 2020-02-03 04:28:04 --> Total execution time: 0.4645
INFO - 2020-02-03 04:28:07 --> Config Class Initialized
INFO - 2020-02-03 04:28:07 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:07 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:07 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:07 --> URI Class Initialized
DEBUG - 2020-02-03 04:28:07 --> No URI present. Default controller set.
INFO - 2020-02-03 04:28:07 --> Router Class Initialized
INFO - 2020-02-03 04:28:07 --> Output Class Initialized
INFO - 2020-02-03 04:28:07 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:07 --> Input Class Initialized
INFO - 2020-02-03 04:28:07 --> Language Class Initialized
INFO - 2020-02-03 04:28:07 --> Language Class Initialized
INFO - 2020-02-03 04:28:07 --> Config Class Initialized
INFO - 2020-02-03 04:28:07 --> Loader Class Initialized
INFO - 2020-02-03 04:28:07 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:07 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:07 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:07 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:07 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:07 --> Controller Class Initialized
DEBUG - 2020-02-03 04:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home_guru.php
DEBUG - 2020-02-03 04:28:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:28:07 --> Final output sent to browser
DEBUG - 2020-02-03 04:28:07 --> Total execution time: 0.4505
INFO - 2020-02-03 04:28:10 --> Config Class Initialized
INFO - 2020-02-03 04:28:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:10 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:10 --> URI Class Initialized
INFO - 2020-02-03 04:28:10 --> Router Class Initialized
INFO - 2020-02-03 04:28:10 --> Output Class Initialized
INFO - 2020-02-03 04:28:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:10 --> Input Class Initialized
INFO - 2020-02-03 04:28:10 --> Language Class Initialized
INFO - 2020-02-03 04:28:10 --> Language Class Initialized
INFO - 2020-02-03 04:28:10 --> Config Class Initialized
INFO - 2020-02-03 04:28:10 --> Loader Class Initialized
INFO - 2020-02-03 04:28:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:10 --> Controller Class Initialized
INFO - 2020-02-03 04:28:10 --> Helper loaded: cookie_helper
INFO - 2020-02-03 04:28:10 --> Config Class Initialized
INFO - 2020-02-03 04:28:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:10 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:10 --> URI Class Initialized
INFO - 2020-02-03 04:28:10 --> Router Class Initialized
INFO - 2020-02-03 04:28:10 --> Output Class Initialized
INFO - 2020-02-03 04:28:10 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:10 --> Input Class Initialized
INFO - 2020-02-03 04:28:10 --> Language Class Initialized
INFO - 2020-02-03 04:28:10 --> Language Class Initialized
INFO - 2020-02-03 04:28:10 --> Config Class Initialized
INFO - 2020-02-03 04:28:10 --> Loader Class Initialized
INFO - 2020-02-03 04:28:10 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:10 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:11 --> Controller Class Initialized
INFO - 2020-02-03 04:28:11 --> Config Class Initialized
INFO - 2020-02-03 04:28:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:11 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:11 --> URI Class Initialized
INFO - 2020-02-03 04:28:11 --> Router Class Initialized
INFO - 2020-02-03 04:28:11 --> Output Class Initialized
INFO - 2020-02-03 04:28:11 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:11 --> Input Class Initialized
INFO - 2020-02-03 04:28:11 --> Language Class Initialized
INFO - 2020-02-03 04:28:11 --> Language Class Initialized
INFO - 2020-02-03 04:28:11 --> Config Class Initialized
INFO - 2020-02-03 04:28:11 --> Loader Class Initialized
INFO - 2020-02-03 04:28:11 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:11 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:11 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:11 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:11 --> Controller Class Initialized
DEBUG - 2020-02-03 04:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 04:28:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:28:11 --> Final output sent to browser
DEBUG - 2020-02-03 04:28:11 --> Total execution time: 0.4662
INFO - 2020-02-03 04:28:16 --> Config Class Initialized
INFO - 2020-02-03 04:28:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:16 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:16 --> URI Class Initialized
INFO - 2020-02-03 04:28:16 --> Router Class Initialized
INFO - 2020-02-03 04:28:16 --> Output Class Initialized
INFO - 2020-02-03 04:28:16 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:16 --> Input Class Initialized
INFO - 2020-02-03 04:28:16 --> Language Class Initialized
INFO - 2020-02-03 04:28:16 --> Language Class Initialized
INFO - 2020-02-03 04:28:16 --> Config Class Initialized
INFO - 2020-02-03 04:28:16 --> Loader Class Initialized
INFO - 2020-02-03 04:28:16 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:16 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:16 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:16 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:16 --> Controller Class Initialized
INFO - 2020-02-03 04:28:16 --> Helper loaded: cookie_helper
INFO - 2020-02-03 04:28:16 --> Final output sent to browser
DEBUG - 2020-02-03 04:28:16 --> Total execution time: 0.4078
INFO - 2020-02-03 04:28:16 --> Config Class Initialized
INFO - 2020-02-03 04:28:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:28:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:28:16 --> Utf8 Class Initialized
INFO - 2020-02-03 04:28:16 --> URI Class Initialized
INFO - 2020-02-03 04:28:16 --> Router Class Initialized
INFO - 2020-02-03 04:28:16 --> Output Class Initialized
INFO - 2020-02-03 04:28:16 --> Security Class Initialized
DEBUG - 2020-02-03 04:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:28:17 --> Input Class Initialized
INFO - 2020-02-03 04:28:17 --> Language Class Initialized
INFO - 2020-02-03 04:28:17 --> Language Class Initialized
INFO - 2020-02-03 04:28:17 --> Config Class Initialized
INFO - 2020-02-03 04:28:17 --> Loader Class Initialized
INFO - 2020-02-03 04:28:17 --> Helper loaded: url_helper
INFO - 2020-02-03 04:28:17 --> Helper loaded: file_helper
INFO - 2020-02-03 04:28:17 --> Helper loaded: form_helper
INFO - 2020-02-03 04:28:17 --> Helper loaded: my_helper
INFO - 2020-02-03 04:28:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:28:17 --> Controller Class Initialized
DEBUG - 2020-02-03 04:28:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:28:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:28:17 --> Final output sent to browser
DEBUG - 2020-02-03 04:28:17 --> Total execution time: 0.4428
INFO - 2020-02-03 04:31:49 --> Config Class Initialized
INFO - 2020-02-03 04:31:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:31:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:31:49 --> Utf8 Class Initialized
INFO - 2020-02-03 04:31:49 --> URI Class Initialized
INFO - 2020-02-03 04:31:49 --> Router Class Initialized
INFO - 2020-02-03 04:31:50 --> Output Class Initialized
INFO - 2020-02-03 04:31:50 --> Security Class Initialized
DEBUG - 2020-02-03 04:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:31:50 --> Input Class Initialized
INFO - 2020-02-03 04:31:50 --> Language Class Initialized
INFO - 2020-02-03 04:31:50 --> Language Class Initialized
INFO - 2020-02-03 04:31:50 --> Config Class Initialized
INFO - 2020-02-03 04:31:50 --> Loader Class Initialized
INFO - 2020-02-03 04:31:50 --> Helper loaded: url_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: file_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: form_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: my_helper
INFO - 2020-02-03 04:31:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:31:50 --> Controller Class Initialized
DEBUG - 2020-02-03 04:31:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 04:31:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:31:50 --> Final output sent to browser
DEBUG - 2020-02-03 04:31:50 --> Total execution time: 0.3926
INFO - 2020-02-03 04:31:50 --> Config Class Initialized
INFO - 2020-02-03 04:31:50 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:31:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:31:50 --> Utf8 Class Initialized
INFO - 2020-02-03 04:31:50 --> URI Class Initialized
INFO - 2020-02-03 04:31:50 --> Router Class Initialized
INFO - 2020-02-03 04:31:50 --> Output Class Initialized
INFO - 2020-02-03 04:31:50 --> Security Class Initialized
DEBUG - 2020-02-03 04:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:31:50 --> Input Class Initialized
INFO - 2020-02-03 04:31:50 --> Language Class Initialized
INFO - 2020-02-03 04:31:50 --> Language Class Initialized
INFO - 2020-02-03 04:31:50 --> Config Class Initialized
INFO - 2020-02-03 04:31:50 --> Loader Class Initialized
INFO - 2020-02-03 04:31:50 --> Helper loaded: url_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: file_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: form_helper
INFO - 2020-02-03 04:31:50 --> Helper loaded: my_helper
INFO - 2020-02-03 04:31:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:31:50 --> Controller Class Initialized
INFO - 2020-02-03 04:31:51 --> Config Class Initialized
INFO - 2020-02-03 04:31:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:31:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:31:51 --> Utf8 Class Initialized
INFO - 2020-02-03 04:31:51 --> URI Class Initialized
INFO - 2020-02-03 04:31:51 --> Router Class Initialized
INFO - 2020-02-03 04:31:51 --> Output Class Initialized
INFO - 2020-02-03 04:31:51 --> Security Class Initialized
DEBUG - 2020-02-03 04:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:31:51 --> Input Class Initialized
INFO - 2020-02-03 04:31:51 --> Language Class Initialized
INFO - 2020-02-03 04:31:51 --> Language Class Initialized
INFO - 2020-02-03 04:31:51 --> Config Class Initialized
INFO - 2020-02-03 04:31:51 --> Loader Class Initialized
INFO - 2020-02-03 04:31:51 --> Helper loaded: url_helper
INFO - 2020-02-03 04:31:51 --> Helper loaded: file_helper
INFO - 2020-02-03 04:31:51 --> Helper loaded: form_helper
INFO - 2020-02-03 04:31:51 --> Helper loaded: my_helper
INFO - 2020-02-03 04:31:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:31:51 --> Controller Class Initialized
INFO - 2020-02-03 04:31:51 --> Final output sent to browser
DEBUG - 2020-02-03 04:31:51 --> Total execution time: 0.3836
INFO - 2020-02-03 04:32:13 --> Config Class Initialized
INFO - 2020-02-03 04:32:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:13 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:13 --> URI Class Initialized
INFO - 2020-02-03 04:32:13 --> Router Class Initialized
INFO - 2020-02-03 04:32:13 --> Output Class Initialized
INFO - 2020-02-03 04:32:13 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:13 --> Input Class Initialized
INFO - 2020-02-03 04:32:13 --> Language Class Initialized
INFO - 2020-02-03 04:32:13 --> Language Class Initialized
INFO - 2020-02-03 04:32:13 --> Config Class Initialized
INFO - 2020-02-03 04:32:13 --> Loader Class Initialized
INFO - 2020-02-03 04:32:13 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:13 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:13 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:13 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:13 --> Controller Class Initialized
DEBUG - 2020-02-03 04:32:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-03 04:32:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:32:13 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:14 --> Total execution time: 0.4456
INFO - 2020-02-03 04:32:14 --> Config Class Initialized
INFO - 2020-02-03 04:32:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:14 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:14 --> URI Class Initialized
INFO - 2020-02-03 04:32:14 --> Router Class Initialized
INFO - 2020-02-03 04:32:14 --> Output Class Initialized
INFO - 2020-02-03 04:32:14 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:14 --> Input Class Initialized
INFO - 2020-02-03 04:32:14 --> Language Class Initialized
INFO - 2020-02-03 04:32:14 --> Language Class Initialized
INFO - 2020-02-03 04:32:14 --> Config Class Initialized
INFO - 2020-02-03 04:32:14 --> Loader Class Initialized
INFO - 2020-02-03 04:32:14 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:14 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:14 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:14 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:14 --> Controller Class Initialized
INFO - 2020-02-03 04:32:25 --> Config Class Initialized
INFO - 2020-02-03 04:32:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:26 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:26 --> URI Class Initialized
INFO - 2020-02-03 04:32:26 --> Router Class Initialized
INFO - 2020-02-03 04:32:26 --> Output Class Initialized
INFO - 2020-02-03 04:32:26 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:26 --> Input Class Initialized
INFO - 2020-02-03 04:32:26 --> Language Class Initialized
INFO - 2020-02-03 04:32:26 --> Language Class Initialized
INFO - 2020-02-03 04:32:26 --> Config Class Initialized
INFO - 2020-02-03 04:32:26 --> Loader Class Initialized
INFO - 2020-02-03 04:32:26 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:26 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:26 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:26 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:26 --> Controller Class Initialized
DEBUG - 2020-02-03 04:32:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-02-03 04:32:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:32:26 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:26 --> Total execution time: 0.5075
INFO - 2020-02-03 04:32:30 --> Config Class Initialized
INFO - 2020-02-03 04:32:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:30 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:30 --> URI Class Initialized
INFO - 2020-02-03 04:32:30 --> Router Class Initialized
INFO - 2020-02-03 04:32:30 --> Output Class Initialized
INFO - 2020-02-03 04:32:30 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:30 --> Input Class Initialized
INFO - 2020-02-03 04:32:30 --> Language Class Initialized
INFO - 2020-02-03 04:32:30 --> Language Class Initialized
INFO - 2020-02-03 04:32:30 --> Config Class Initialized
INFO - 2020-02-03 04:32:30 --> Loader Class Initialized
INFO - 2020-02-03 04:32:30 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:30 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:30 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:30 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:30 --> Controller Class Initialized
DEBUG - 2020-02-03 04:32:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 04:32:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:32:30 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:30 --> Total execution time: 0.4731
INFO - 2020-02-03 04:32:30 --> Config Class Initialized
INFO - 2020-02-03 04:32:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:31 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:31 --> URI Class Initialized
INFO - 2020-02-03 04:32:31 --> Router Class Initialized
INFO - 2020-02-03 04:32:31 --> Output Class Initialized
INFO - 2020-02-03 04:32:31 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:31 --> Input Class Initialized
INFO - 2020-02-03 04:32:31 --> Language Class Initialized
INFO - 2020-02-03 04:32:31 --> Language Class Initialized
INFO - 2020-02-03 04:32:31 --> Config Class Initialized
INFO - 2020-02-03 04:32:31 --> Loader Class Initialized
INFO - 2020-02-03 04:32:31 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:31 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:31 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:31 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:31 --> Controller Class Initialized
INFO - 2020-02-03 04:32:34 --> Config Class Initialized
INFO - 2020-02-03 04:32:34 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:34 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:34 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:34 --> URI Class Initialized
INFO - 2020-02-03 04:32:34 --> Router Class Initialized
INFO - 2020-02-03 04:32:34 --> Output Class Initialized
INFO - 2020-02-03 04:32:34 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:34 --> Input Class Initialized
INFO - 2020-02-03 04:32:34 --> Language Class Initialized
INFO - 2020-02-03 04:32:34 --> Language Class Initialized
INFO - 2020-02-03 04:32:34 --> Config Class Initialized
INFO - 2020-02-03 04:32:34 --> Loader Class Initialized
INFO - 2020-02-03 04:32:34 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:34 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:34 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:34 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:34 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:34 --> Controller Class Initialized
INFO - 2020-02-03 04:32:34 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:34 --> Total execution time: 0.3868
INFO - 2020-02-03 04:32:45 --> Config Class Initialized
INFO - 2020-02-03 04:32:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:46 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:46 --> URI Class Initialized
INFO - 2020-02-03 04:32:46 --> Router Class Initialized
INFO - 2020-02-03 04:32:46 --> Output Class Initialized
INFO - 2020-02-03 04:32:46 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:46 --> Input Class Initialized
INFO - 2020-02-03 04:32:46 --> Language Class Initialized
INFO - 2020-02-03 04:32:46 --> Language Class Initialized
INFO - 2020-02-03 04:32:46 --> Config Class Initialized
INFO - 2020-02-03 04:32:46 --> Loader Class Initialized
INFO - 2020-02-03 04:32:46 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:46 --> Controller Class Initialized
DEBUG - 2020-02-03 04:32:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-03 04:32:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:32:46 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:46 --> Total execution time: 0.4753
INFO - 2020-02-03 04:32:46 --> Config Class Initialized
INFO - 2020-02-03 04:32:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:46 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:46 --> URI Class Initialized
INFO - 2020-02-03 04:32:46 --> Router Class Initialized
INFO - 2020-02-03 04:32:46 --> Output Class Initialized
INFO - 2020-02-03 04:32:46 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:46 --> Input Class Initialized
INFO - 2020-02-03 04:32:46 --> Language Class Initialized
INFO - 2020-02-03 04:32:46 --> Language Class Initialized
INFO - 2020-02-03 04:32:46 --> Config Class Initialized
INFO - 2020-02-03 04:32:46 --> Loader Class Initialized
INFO - 2020-02-03 04:32:46 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:46 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:47 --> Controller Class Initialized
INFO - 2020-02-03 04:32:51 --> Config Class Initialized
INFO - 2020-02-03 04:32:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:32:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:32:51 --> Utf8 Class Initialized
INFO - 2020-02-03 04:32:51 --> URI Class Initialized
INFO - 2020-02-03 04:32:51 --> Router Class Initialized
INFO - 2020-02-03 04:32:51 --> Output Class Initialized
INFO - 2020-02-03 04:32:51 --> Security Class Initialized
DEBUG - 2020-02-03 04:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:32:51 --> Input Class Initialized
INFO - 2020-02-03 04:32:51 --> Language Class Initialized
INFO - 2020-02-03 04:32:51 --> Language Class Initialized
INFO - 2020-02-03 04:32:51 --> Config Class Initialized
INFO - 2020-02-03 04:32:51 --> Loader Class Initialized
INFO - 2020-02-03 04:32:51 --> Helper loaded: url_helper
INFO - 2020-02-03 04:32:51 --> Helper loaded: file_helper
INFO - 2020-02-03 04:32:51 --> Helper loaded: form_helper
INFO - 2020-02-03 04:32:51 --> Helper loaded: my_helper
INFO - 2020-02-03 04:32:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:32:51 --> Controller Class Initialized
INFO - 2020-02-03 04:32:51 --> Final output sent to browser
DEBUG - 2020-02-03 04:32:51 --> Total execution time: 0.3841
INFO - 2020-02-03 04:34:19 --> Config Class Initialized
INFO - 2020-02-03 04:34:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:19 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:19 --> URI Class Initialized
INFO - 2020-02-03 04:34:19 --> Router Class Initialized
INFO - 2020-02-03 04:34:19 --> Output Class Initialized
INFO - 2020-02-03 04:34:19 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:19 --> Input Class Initialized
INFO - 2020-02-03 04:34:19 --> Language Class Initialized
INFO - 2020-02-03 04:34:19 --> Language Class Initialized
INFO - 2020-02-03 04:34:19 --> Config Class Initialized
INFO - 2020-02-03 04:34:19 --> Loader Class Initialized
INFO - 2020-02-03 04:34:20 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:20 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:20 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:20 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:20 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-02-03 04:34:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:20 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:20 --> Total execution time: 0.4862
INFO - 2020-02-03 04:34:21 --> Config Class Initialized
INFO - 2020-02-03 04:34:21 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:21 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:21 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:21 --> URI Class Initialized
INFO - 2020-02-03 04:34:21 --> Router Class Initialized
INFO - 2020-02-03 04:34:21 --> Output Class Initialized
INFO - 2020-02-03 04:34:21 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:21 --> Input Class Initialized
INFO - 2020-02-03 04:34:21 --> Language Class Initialized
INFO - 2020-02-03 04:34:21 --> Language Class Initialized
INFO - 2020-02-03 04:34:21 --> Config Class Initialized
INFO - 2020-02-03 04:34:21 --> Loader Class Initialized
INFO - 2020-02-03 04:34:21 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:21 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:21 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:21 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:21 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-03 04:34:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:21 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:21 --> Total execution time: 0.4673
INFO - 2020-02-03 04:34:22 --> Config Class Initialized
INFO - 2020-02-03 04:34:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:22 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:22 --> URI Class Initialized
INFO - 2020-02-03 04:34:22 --> Router Class Initialized
INFO - 2020-02-03 04:34:22 --> Output Class Initialized
INFO - 2020-02-03 04:34:22 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:22 --> Input Class Initialized
INFO - 2020-02-03 04:34:22 --> Language Class Initialized
INFO - 2020-02-03 04:34:22 --> Language Class Initialized
INFO - 2020-02-03 04:34:22 --> Config Class Initialized
INFO - 2020-02-03 04:34:22 --> Loader Class Initialized
INFO - 2020-02-03 04:34:22 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:22 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:22 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:22 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:22 --> Controller Class Initialized
INFO - 2020-02-03 04:34:24 --> Config Class Initialized
INFO - 2020-02-03 04:34:24 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:24 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:24 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:24 --> URI Class Initialized
INFO - 2020-02-03 04:34:24 --> Router Class Initialized
INFO - 2020-02-03 04:34:24 --> Output Class Initialized
INFO - 2020-02-03 04:34:24 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:24 --> Input Class Initialized
INFO - 2020-02-03 04:34:24 --> Language Class Initialized
INFO - 2020-02-03 04:34:24 --> Language Class Initialized
INFO - 2020-02-03 04:34:24 --> Config Class Initialized
INFO - 2020-02-03 04:34:24 --> Loader Class Initialized
INFO - 2020-02-03 04:34:24 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:24 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:24 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:24 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:24 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:24 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 04:34:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:24 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:24 --> Total execution time: 0.4670
INFO - 2020-02-03 04:34:25 --> Config Class Initialized
INFO - 2020-02-03 04:34:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:25 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:25 --> URI Class Initialized
INFO - 2020-02-03 04:34:25 --> Router Class Initialized
INFO - 2020-02-03 04:34:25 --> Output Class Initialized
INFO - 2020-02-03 04:34:25 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:25 --> Input Class Initialized
INFO - 2020-02-03 04:34:25 --> Language Class Initialized
INFO - 2020-02-03 04:34:25 --> Language Class Initialized
INFO - 2020-02-03 04:34:25 --> Config Class Initialized
INFO - 2020-02-03 04:34:25 --> Loader Class Initialized
INFO - 2020-02-03 04:34:25 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:25 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:25 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:25 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:25 --> Controller Class Initialized
INFO - 2020-02-03 04:34:29 --> Config Class Initialized
INFO - 2020-02-03 04:34:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:29 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:29 --> URI Class Initialized
DEBUG - 2020-02-03 04:34:29 --> No URI present. Default controller set.
INFO - 2020-02-03 04:34:29 --> Router Class Initialized
INFO - 2020-02-03 04:34:29 --> Output Class Initialized
INFO - 2020-02-03 04:34:29 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:29 --> Input Class Initialized
INFO - 2020-02-03 04:34:29 --> Language Class Initialized
INFO - 2020-02-03 04:34:29 --> Language Class Initialized
INFO - 2020-02-03 04:34:29 --> Config Class Initialized
INFO - 2020-02-03 04:34:29 --> Loader Class Initialized
INFO - 2020-02-03 04:34:29 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:29 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:29 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:29 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:29 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:34:29 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:29 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:29 --> Total execution time: 0.4710
INFO - 2020-02-03 04:34:33 --> Config Class Initialized
INFO - 2020-02-03 04:34:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:33 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:33 --> URI Class Initialized
INFO - 2020-02-03 04:34:33 --> Router Class Initialized
INFO - 2020-02-03 04:34:33 --> Output Class Initialized
INFO - 2020-02-03 04:34:33 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:33 --> Input Class Initialized
INFO - 2020-02-03 04:34:33 --> Language Class Initialized
INFO - 2020-02-03 04:34:33 --> Language Class Initialized
INFO - 2020-02-03 04:34:33 --> Config Class Initialized
INFO - 2020-02-03 04:34:33 --> Loader Class Initialized
INFO - 2020-02-03 04:34:33 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:33 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:33 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:33 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:33 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 04:34:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:33 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:33 --> Total execution time: 0.4651
INFO - 2020-02-03 04:34:34 --> Config Class Initialized
INFO - 2020-02-03 04:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:34 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:34 --> URI Class Initialized
INFO - 2020-02-03 04:34:34 --> Router Class Initialized
INFO - 2020-02-03 04:34:34 --> Output Class Initialized
INFO - 2020-02-03 04:34:34 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:34 --> Input Class Initialized
INFO - 2020-02-03 04:34:34 --> Language Class Initialized
INFO - 2020-02-03 04:34:34 --> Language Class Initialized
INFO - 2020-02-03 04:34:34 --> Config Class Initialized
INFO - 2020-02-03 04:34:34 --> Loader Class Initialized
INFO - 2020-02-03 04:34:34 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:34 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:34 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:34 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:34 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:34 --> Controller Class Initialized
INFO - 2020-02-03 04:34:34 --> Config Class Initialized
INFO - 2020-02-03 04:34:34 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:34:34 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:34:34 --> Utf8 Class Initialized
INFO - 2020-02-03 04:34:34 --> URI Class Initialized
DEBUG - 2020-02-03 04:34:34 --> No URI present. Default controller set.
INFO - 2020-02-03 04:34:34 --> Router Class Initialized
INFO - 2020-02-03 04:34:34 --> Output Class Initialized
INFO - 2020-02-03 04:34:34 --> Security Class Initialized
DEBUG - 2020-02-03 04:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:34:34 --> Input Class Initialized
INFO - 2020-02-03 04:34:34 --> Language Class Initialized
INFO - 2020-02-03 04:34:35 --> Language Class Initialized
INFO - 2020-02-03 04:34:35 --> Config Class Initialized
INFO - 2020-02-03 04:34:35 --> Loader Class Initialized
INFO - 2020-02-03 04:34:35 --> Helper loaded: url_helper
INFO - 2020-02-03 04:34:35 --> Helper loaded: file_helper
INFO - 2020-02-03 04:34:35 --> Helper loaded: form_helper
INFO - 2020-02-03 04:34:35 --> Helper loaded: my_helper
INFO - 2020-02-03 04:34:35 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:34:35 --> Controller Class Initialized
DEBUG - 2020-02-03 04:34:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:34:35 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:34:35 --> Final output sent to browser
DEBUG - 2020-02-03 04:34:35 --> Total execution time: 0.4783
INFO - 2020-02-03 04:35:58 --> Config Class Initialized
INFO - 2020-02-03 04:35:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:35:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:35:58 --> Utf8 Class Initialized
INFO - 2020-02-03 04:35:58 --> URI Class Initialized
DEBUG - 2020-02-03 04:35:58 --> No URI present. Default controller set.
INFO - 2020-02-03 04:35:58 --> Router Class Initialized
INFO - 2020-02-03 04:35:58 --> Output Class Initialized
INFO - 2020-02-03 04:35:58 --> Security Class Initialized
DEBUG - 2020-02-03 04:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:35:58 --> Input Class Initialized
INFO - 2020-02-03 04:35:58 --> Language Class Initialized
INFO - 2020-02-03 04:35:58 --> Language Class Initialized
INFO - 2020-02-03 04:35:58 --> Config Class Initialized
INFO - 2020-02-03 04:35:58 --> Loader Class Initialized
INFO - 2020-02-03 04:35:58 --> Helper loaded: url_helper
INFO - 2020-02-03 04:35:58 --> Helper loaded: file_helper
INFO - 2020-02-03 04:35:58 --> Helper loaded: form_helper
INFO - 2020-02-03 04:35:58 --> Helper loaded: my_helper
INFO - 2020-02-03 04:35:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:35:59 --> Controller Class Initialized
DEBUG - 2020-02-03 04:35:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:35:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:35:59 --> Final output sent to browser
DEBUG - 2020-02-03 04:35:59 --> Total execution time: 0.4813
INFO - 2020-02-03 04:37:27 --> Config Class Initialized
INFO - 2020-02-03 04:37:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 04:37:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 04:37:27 --> Utf8 Class Initialized
INFO - 2020-02-03 04:37:27 --> URI Class Initialized
DEBUG - 2020-02-03 04:37:27 --> No URI present. Default controller set.
INFO - 2020-02-03 04:37:27 --> Router Class Initialized
INFO - 2020-02-03 04:37:27 --> Output Class Initialized
INFO - 2020-02-03 04:37:27 --> Security Class Initialized
DEBUG - 2020-02-03 04:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 04:37:27 --> Input Class Initialized
INFO - 2020-02-03 04:37:27 --> Language Class Initialized
INFO - 2020-02-03 04:37:27 --> Language Class Initialized
INFO - 2020-02-03 04:37:27 --> Config Class Initialized
INFO - 2020-02-03 04:37:27 --> Loader Class Initialized
INFO - 2020-02-03 04:37:27 --> Helper loaded: url_helper
INFO - 2020-02-03 04:37:27 --> Helper loaded: file_helper
INFO - 2020-02-03 04:37:27 --> Helper loaded: form_helper
INFO - 2020-02-03 04:37:27 --> Helper loaded: my_helper
INFO - 2020-02-03 04:37:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 04:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 04:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 04:37:27 --> Controller Class Initialized
DEBUG - 2020-02-03 04:37:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 04:37:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 04:37:27 --> Final output sent to browser
DEBUG - 2020-02-03 04:37:27 --> Total execution time: 0.4759
INFO - 2020-02-03 06:40:56 --> Config Class Initialized
INFO - 2020-02-03 06:40:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:40:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:40:56 --> Utf8 Class Initialized
INFO - 2020-02-03 06:40:56 --> URI Class Initialized
DEBUG - 2020-02-03 06:40:56 --> No URI present. Default controller set.
INFO - 2020-02-03 06:40:56 --> Router Class Initialized
INFO - 2020-02-03 06:40:56 --> Output Class Initialized
INFO - 2020-02-03 06:40:56 --> Security Class Initialized
DEBUG - 2020-02-03 06:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:40:57 --> Input Class Initialized
INFO - 2020-02-03 06:40:57 --> Language Class Initialized
INFO - 2020-02-03 06:40:57 --> Language Class Initialized
INFO - 2020-02-03 06:40:57 --> Config Class Initialized
INFO - 2020-02-03 06:40:57 --> Loader Class Initialized
INFO - 2020-02-03 06:40:57 --> Helper loaded: url_helper
INFO - 2020-02-03 06:40:57 --> Helper loaded: file_helper
INFO - 2020-02-03 06:40:57 --> Helper loaded: form_helper
INFO - 2020-02-03 06:40:57 --> Helper loaded: my_helper
INFO - 2020-02-03 06:40:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:40:57 --> Controller Class Initialized
INFO - 2020-02-03 06:40:57 --> Config Class Initialized
INFO - 2020-02-03 06:40:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:40:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:40:57 --> Utf8 Class Initialized
INFO - 2020-02-03 06:40:57 --> URI Class Initialized
INFO - 2020-02-03 06:40:57 --> Router Class Initialized
INFO - 2020-02-03 06:40:57 --> Output Class Initialized
INFO - 2020-02-03 06:40:57 --> Security Class Initialized
DEBUG - 2020-02-03 06:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:40:57 --> Input Class Initialized
INFO - 2020-02-03 06:40:57 --> Language Class Initialized
INFO - 2020-02-03 06:40:57 --> Language Class Initialized
INFO - 2020-02-03 06:40:57 --> Config Class Initialized
INFO - 2020-02-03 06:40:57 --> Loader Class Initialized
INFO - 2020-02-03 06:40:57 --> Helper loaded: url_helper
INFO - 2020-02-03 06:40:58 --> Helper loaded: file_helper
INFO - 2020-02-03 06:40:58 --> Helper loaded: form_helper
INFO - 2020-02-03 06:40:58 --> Helper loaded: my_helper
INFO - 2020-02-03 06:40:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:40:58 --> Controller Class Initialized
DEBUG - 2020-02-03 06:40:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 06:40:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 06:40:58 --> Final output sent to browser
DEBUG - 2020-02-03 06:40:58 --> Total execution time: 0.4639
INFO - 2020-02-03 06:41:03 --> Config Class Initialized
INFO - 2020-02-03 06:41:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:41:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:41:03 --> Utf8 Class Initialized
INFO - 2020-02-03 06:41:03 --> URI Class Initialized
INFO - 2020-02-03 06:41:03 --> Router Class Initialized
INFO - 2020-02-03 06:41:03 --> Output Class Initialized
INFO - 2020-02-03 06:41:03 --> Security Class Initialized
DEBUG - 2020-02-03 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:41:03 --> Input Class Initialized
INFO - 2020-02-03 06:41:03 --> Language Class Initialized
INFO - 2020-02-03 06:41:03 --> Language Class Initialized
INFO - 2020-02-03 06:41:03 --> Config Class Initialized
INFO - 2020-02-03 06:41:03 --> Loader Class Initialized
INFO - 2020-02-03 06:41:03 --> Helper loaded: url_helper
INFO - 2020-02-03 06:41:03 --> Helper loaded: file_helper
INFO - 2020-02-03 06:41:03 --> Helper loaded: form_helper
INFO - 2020-02-03 06:41:03 --> Helper loaded: my_helper
INFO - 2020-02-03 06:41:03 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:41:03 --> Controller Class Initialized
INFO - 2020-02-03 06:41:03 --> Helper loaded: cookie_helper
INFO - 2020-02-03 06:41:03 --> Final output sent to browser
DEBUG - 2020-02-03 06:41:03 --> Total execution time: 0.4617
INFO - 2020-02-03 06:41:03 --> Config Class Initialized
INFO - 2020-02-03 06:41:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:41:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:41:03 --> Utf8 Class Initialized
INFO - 2020-02-03 06:41:03 --> URI Class Initialized
INFO - 2020-02-03 06:41:03 --> Router Class Initialized
INFO - 2020-02-03 06:41:03 --> Output Class Initialized
INFO - 2020-02-03 06:41:03 --> Security Class Initialized
DEBUG - 2020-02-03 06:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:41:03 --> Input Class Initialized
INFO - 2020-02-03 06:41:03 --> Language Class Initialized
INFO - 2020-02-03 06:41:03 --> Language Class Initialized
INFO - 2020-02-03 06:41:03 --> Config Class Initialized
INFO - 2020-02-03 06:41:04 --> Loader Class Initialized
INFO - 2020-02-03 06:41:04 --> Helper loaded: url_helper
INFO - 2020-02-03 06:41:04 --> Helper loaded: file_helper
INFO - 2020-02-03 06:41:04 --> Helper loaded: form_helper
INFO - 2020-02-03 06:41:04 --> Helper loaded: my_helper
INFO - 2020-02-03 06:41:04 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:41:04 --> Controller Class Initialized
DEBUG - 2020-02-03 06:41:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 06:41:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 06:41:04 --> Final output sent to browser
DEBUG - 2020-02-03 06:41:04 --> Total execution time: 0.5341
INFO - 2020-02-03 06:42:21 --> Config Class Initialized
INFO - 2020-02-03 06:42:21 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:42:21 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:42:21 --> Utf8 Class Initialized
INFO - 2020-02-03 06:42:21 --> URI Class Initialized
INFO - 2020-02-03 06:42:21 --> Router Class Initialized
INFO - 2020-02-03 06:42:21 --> Output Class Initialized
INFO - 2020-02-03 06:42:22 --> Security Class Initialized
DEBUG - 2020-02-03 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:42:22 --> Input Class Initialized
INFO - 2020-02-03 06:42:22 --> Language Class Initialized
INFO - 2020-02-03 06:42:22 --> Language Class Initialized
INFO - 2020-02-03 06:42:22 --> Config Class Initialized
INFO - 2020-02-03 06:42:22 --> Loader Class Initialized
INFO - 2020-02-03 06:42:22 --> Helper loaded: url_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: file_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: form_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: my_helper
INFO - 2020-02-03 06:42:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:42:22 --> Controller Class Initialized
DEBUG - 2020-02-03 06:42:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 06:42:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 06:42:22 --> Final output sent to browser
DEBUG - 2020-02-03 06:42:22 --> Total execution time: 0.5060
INFO - 2020-02-03 06:42:22 --> Config Class Initialized
INFO - 2020-02-03 06:42:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:42:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:42:22 --> Utf8 Class Initialized
INFO - 2020-02-03 06:42:22 --> URI Class Initialized
INFO - 2020-02-03 06:42:22 --> Router Class Initialized
INFO - 2020-02-03 06:42:22 --> Output Class Initialized
INFO - 2020-02-03 06:42:22 --> Security Class Initialized
DEBUG - 2020-02-03 06:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:42:22 --> Input Class Initialized
INFO - 2020-02-03 06:42:22 --> Language Class Initialized
INFO - 2020-02-03 06:42:22 --> Language Class Initialized
INFO - 2020-02-03 06:42:22 --> Config Class Initialized
INFO - 2020-02-03 06:42:22 --> Loader Class Initialized
INFO - 2020-02-03 06:42:22 --> Helper loaded: url_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: file_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: form_helper
INFO - 2020-02-03 06:42:22 --> Helper loaded: my_helper
INFO - 2020-02-03 06:42:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:42:23 --> Controller Class Initialized
INFO - 2020-02-03 06:42:27 --> Config Class Initialized
INFO - 2020-02-03 06:42:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:42:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:42:27 --> Utf8 Class Initialized
INFO - 2020-02-03 06:42:27 --> URI Class Initialized
INFO - 2020-02-03 06:42:27 --> Router Class Initialized
INFO - 2020-02-03 06:42:27 --> Output Class Initialized
INFO - 2020-02-03 06:42:27 --> Security Class Initialized
DEBUG - 2020-02-03 06:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:42:27 --> Input Class Initialized
INFO - 2020-02-03 06:42:27 --> Language Class Initialized
INFO - 2020-02-03 06:42:27 --> Language Class Initialized
INFO - 2020-02-03 06:42:27 --> Config Class Initialized
INFO - 2020-02-03 06:42:27 --> Loader Class Initialized
INFO - 2020-02-03 06:42:27 --> Helper loaded: url_helper
INFO - 2020-02-03 06:42:27 --> Helper loaded: file_helper
INFO - 2020-02-03 06:42:27 --> Helper loaded: form_helper
INFO - 2020-02-03 06:42:27 --> Helper loaded: my_helper
INFO - 2020-02-03 06:42:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:42:27 --> Controller Class Initialized
DEBUG - 2020-02-03 06:42:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 06:42:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 06:42:27 --> Final output sent to browser
DEBUG - 2020-02-03 06:42:27 --> Total execution time: 0.5105
INFO - 2020-02-03 06:42:28 --> Config Class Initialized
INFO - 2020-02-03 06:42:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 06:42:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 06:42:28 --> Utf8 Class Initialized
INFO - 2020-02-03 06:42:28 --> URI Class Initialized
INFO - 2020-02-03 06:42:28 --> Router Class Initialized
INFO - 2020-02-03 06:42:28 --> Output Class Initialized
INFO - 2020-02-03 06:42:28 --> Security Class Initialized
DEBUG - 2020-02-03 06:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 06:42:28 --> Input Class Initialized
INFO - 2020-02-03 06:42:28 --> Language Class Initialized
INFO - 2020-02-03 06:42:28 --> Language Class Initialized
INFO - 2020-02-03 06:42:28 --> Config Class Initialized
INFO - 2020-02-03 06:42:28 --> Loader Class Initialized
INFO - 2020-02-03 06:42:28 --> Helper loaded: url_helper
INFO - 2020-02-03 06:42:28 --> Helper loaded: file_helper
INFO - 2020-02-03 06:42:28 --> Helper loaded: form_helper
INFO - 2020-02-03 06:42:28 --> Helper loaded: my_helper
INFO - 2020-02-03 06:42:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 06:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 06:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 06:42:28 --> Controller Class Initialized
INFO - 2020-02-03 07:12:03 --> Config Class Initialized
INFO - 2020-02-03 07:12:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:12:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:12:03 --> Utf8 Class Initialized
INFO - 2020-02-03 07:12:03 --> URI Class Initialized
INFO - 2020-02-03 07:12:03 --> Router Class Initialized
INFO - 2020-02-03 07:12:03 --> Output Class Initialized
INFO - 2020-02-03 07:12:03 --> Security Class Initialized
DEBUG - 2020-02-03 07:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:12:03 --> Input Class Initialized
INFO - 2020-02-03 07:12:03 --> Language Class Initialized
ERROR - 2020-02-03 07:12:03 --> 404 Page Not Found: ../modules/backup_db/controllers/Backup_db/db
INFO - 2020-02-03 07:12:16 --> Config Class Initialized
INFO - 2020-02-03 07:12:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:12:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:12:17 --> Utf8 Class Initialized
INFO - 2020-02-03 07:12:17 --> URI Class Initialized
INFO - 2020-02-03 07:12:17 --> Router Class Initialized
INFO - 2020-02-03 07:12:17 --> Output Class Initialized
INFO - 2020-02-03 07:12:17 --> Security Class Initialized
DEBUG - 2020-02-03 07:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:12:17 --> Input Class Initialized
INFO - 2020-02-03 07:12:17 --> Language Class Initialized
INFO - 2020-02-03 07:12:17 --> Language Class Initialized
INFO - 2020-02-03 07:12:17 --> Config Class Initialized
INFO - 2020-02-03 07:12:17 --> Loader Class Initialized
INFO - 2020-02-03 07:12:17 --> Helper loaded: url_helper
INFO - 2020-02-03 07:12:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:12:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:12:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:12:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:12:17 --> Controller Class Initialized
INFO - 2020-02-03 07:12:17 --> Database Utility Class Initialized
INFO - 2020-02-03 07:12:17 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:12:17 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 36
INFO - 2020-02-03 07:12:17 --> Helper loaded: download_helper
INFO - 2020-02-03 07:16:24 --> Config Class Initialized
INFO - 2020-02-03 07:16:24 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:16:24 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:16:24 --> Utf8 Class Initialized
INFO - 2020-02-03 07:16:24 --> URI Class Initialized
INFO - 2020-02-03 07:16:24 --> Router Class Initialized
INFO - 2020-02-03 07:16:24 --> Output Class Initialized
INFO - 2020-02-03 07:16:24 --> Security Class Initialized
DEBUG - 2020-02-03 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:16:24 --> Input Class Initialized
INFO - 2020-02-03 07:16:24 --> Language Class Initialized
INFO - 2020-02-03 07:16:25 --> Language Class Initialized
INFO - 2020-02-03 07:16:25 --> Config Class Initialized
INFO - 2020-02-03 07:16:25 --> Loader Class Initialized
INFO - 2020-02-03 07:16:25 --> Helper loaded: url_helper
INFO - 2020-02-03 07:16:25 --> Helper loaded: file_helper
INFO - 2020-02-03 07:16:25 --> Helper loaded: form_helper
INFO - 2020-02-03 07:16:25 --> Helper loaded: my_helper
INFO - 2020-02-03 07:16:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:16:25 --> Controller Class Initialized
INFO - 2020-02-03 07:16:25 --> Database Utility Class Initialized
INFO - 2020-02-03 07:16:25 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:16:25 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:16:25 --> Helper loaded: download_helper
INFO - 2020-02-03 07:17:16 --> Config Class Initialized
INFO - 2020-02-03 07:17:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:17:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:17:16 --> Utf8 Class Initialized
INFO - 2020-02-03 07:17:16 --> URI Class Initialized
INFO - 2020-02-03 07:17:16 --> Router Class Initialized
INFO - 2020-02-03 07:17:16 --> Output Class Initialized
INFO - 2020-02-03 07:17:16 --> Security Class Initialized
DEBUG - 2020-02-03 07:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:17:16 --> Input Class Initialized
INFO - 2020-02-03 07:17:16 --> Language Class Initialized
ERROR - 2020-02-03 07:17:16 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE) E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 42
INFO - 2020-02-03 07:17:22 --> Config Class Initialized
INFO - 2020-02-03 07:17:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:17:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:17:22 --> Utf8 Class Initialized
INFO - 2020-02-03 07:17:22 --> URI Class Initialized
INFO - 2020-02-03 07:17:22 --> Router Class Initialized
INFO - 2020-02-03 07:17:22 --> Output Class Initialized
INFO - 2020-02-03 07:17:22 --> Security Class Initialized
DEBUG - 2020-02-03 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:17:22 --> Input Class Initialized
INFO - 2020-02-03 07:17:22 --> Language Class Initialized
INFO - 2020-02-03 07:17:22 --> Language Class Initialized
INFO - 2020-02-03 07:17:22 --> Config Class Initialized
INFO - 2020-02-03 07:17:22 --> Loader Class Initialized
INFO - 2020-02-03 07:17:22 --> Helper loaded: url_helper
INFO - 2020-02-03 07:17:22 --> Helper loaded: file_helper
INFO - 2020-02-03 07:17:22 --> Helper loaded: form_helper
INFO - 2020-02-03 07:17:22 --> Helper loaded: my_helper
INFO - 2020-02-03 07:17:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:17:23 --> Controller Class Initialized
INFO - 2020-02-03 07:17:23 --> Database Utility Class Initialized
INFO - 2020-02-03 07:17:23 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:17:23 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:17:23 --> Helper loaded: download_helper
INFO - 2020-02-03 07:18:30 --> Config Class Initialized
INFO - 2020-02-03 07:18:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:18:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:18:30 --> Utf8 Class Initialized
INFO - 2020-02-03 07:18:30 --> URI Class Initialized
INFO - 2020-02-03 07:18:30 --> Router Class Initialized
INFO - 2020-02-03 07:18:30 --> Output Class Initialized
INFO - 2020-02-03 07:18:30 --> Security Class Initialized
DEBUG - 2020-02-03 07:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:18:30 --> Input Class Initialized
INFO - 2020-02-03 07:18:30 --> Language Class Initialized
INFO - 2020-02-03 07:18:30 --> Language Class Initialized
INFO - 2020-02-03 07:18:30 --> Config Class Initialized
INFO - 2020-02-03 07:18:30 --> Loader Class Initialized
INFO - 2020-02-03 07:18:30 --> Helper loaded: url_helper
INFO - 2020-02-03 07:18:30 --> Helper loaded: file_helper
INFO - 2020-02-03 07:18:30 --> Helper loaded: form_helper
INFO - 2020-02-03 07:18:30 --> Helper loaded: my_helper
INFO - 2020-02-03 07:18:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:18:30 --> Controller Class Initialized
INFO - 2020-02-03 07:18:30 --> Database Utility Class Initialized
INFO - 2020-02-03 07:18:30 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:18:30 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:18:30 --> Helper loaded: download_helper
INFO - 2020-02-03 07:18:59 --> Config Class Initialized
INFO - 2020-02-03 07:18:59 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:18:59 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:18:59 --> Utf8 Class Initialized
INFO - 2020-02-03 07:18:59 --> URI Class Initialized
INFO - 2020-02-03 07:18:59 --> Router Class Initialized
INFO - 2020-02-03 07:18:59 --> Output Class Initialized
INFO - 2020-02-03 07:18:59 --> Security Class Initialized
DEBUG - 2020-02-03 07:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:18:59 --> Input Class Initialized
INFO - 2020-02-03 07:18:59 --> Language Class Initialized
INFO - 2020-02-03 07:18:59 --> Language Class Initialized
INFO - 2020-02-03 07:18:59 --> Config Class Initialized
INFO - 2020-02-03 07:18:59 --> Loader Class Initialized
INFO - 2020-02-03 07:18:59 --> Helper loaded: url_helper
INFO - 2020-02-03 07:18:59 --> Helper loaded: file_helper
INFO - 2020-02-03 07:18:59 --> Helper loaded: form_helper
INFO - 2020-02-03 07:18:59 --> Helper loaded: my_helper
INFO - 2020-02-03 07:18:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:18:59 --> Controller Class Initialized
INFO - 2020-02-03 07:18:59 --> Database Utility Class Initialized
INFO - 2020-02-03 07:18:59 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:18:59 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:18:59 --> Helper loaded: download_helper
INFO - 2020-02-03 07:20:04 --> Config Class Initialized
INFO - 2020-02-03 07:20:04 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:20:04 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:20:04 --> Utf8 Class Initialized
INFO - 2020-02-03 07:20:04 --> URI Class Initialized
INFO - 2020-02-03 07:20:04 --> Router Class Initialized
INFO - 2020-02-03 07:20:04 --> Output Class Initialized
INFO - 2020-02-03 07:20:04 --> Security Class Initialized
DEBUG - 2020-02-03 07:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:20:04 --> Input Class Initialized
INFO - 2020-02-03 07:20:04 --> Language Class Initialized
INFO - 2020-02-03 07:20:05 --> Language Class Initialized
INFO - 2020-02-03 07:20:05 --> Config Class Initialized
INFO - 2020-02-03 07:20:05 --> Loader Class Initialized
INFO - 2020-02-03 07:20:05 --> Helper loaded: url_helper
INFO - 2020-02-03 07:20:05 --> Helper loaded: file_helper
INFO - 2020-02-03 07:20:05 --> Helper loaded: form_helper
INFO - 2020-02-03 07:20:05 --> Helper loaded: my_helper
INFO - 2020-02-03 07:20:05 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:20:05 --> Controller Class Initialized
INFO - 2020-02-03 07:20:05 --> Database Utility Class Initialized
INFO - 2020-02-03 07:20:05 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:20:05 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:20:05 --> Helper loaded: download_helper
INFO - 2020-02-03 07:27:00 --> Config Class Initialized
INFO - 2020-02-03 07:27:00 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:27:00 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:27:00 --> Utf8 Class Initialized
INFO - 2020-02-03 07:27:00 --> URI Class Initialized
INFO - 2020-02-03 07:27:00 --> Router Class Initialized
INFO - 2020-02-03 07:27:00 --> Output Class Initialized
INFO - 2020-02-03 07:27:00 --> Security Class Initialized
DEBUG - 2020-02-03 07:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:27:00 --> Input Class Initialized
INFO - 2020-02-03 07:27:00 --> Language Class Initialized
INFO - 2020-02-03 07:27:00 --> Language Class Initialized
INFO - 2020-02-03 07:27:00 --> Config Class Initialized
INFO - 2020-02-03 07:27:00 --> Loader Class Initialized
INFO - 2020-02-03 07:27:01 --> Helper loaded: url_helper
INFO - 2020-02-03 07:27:01 --> Helper loaded: file_helper
INFO - 2020-02-03 07:27:01 --> Helper loaded: form_helper
INFO - 2020-02-03 07:27:01 --> Helper loaded: my_helper
INFO - 2020-02-03 07:27:01 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:27:01 --> Controller Class Initialized
INFO - 2020-02-03 07:27:01 --> Database Utility Class Initialized
INFO - 2020-02-03 07:27:01 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:27:01 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
ERROR - 2020-02-03 07:27:01 --> Query error: Column count doesn't match value count at row 1 - Invalid query: INSERT into t_backupdb VALUES ('', '20182', 'Backup_db_TA20182_03-02-2020.zip')
INFO - 2020-02-03 07:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-03 07:27:15 --> Config Class Initialized
INFO - 2020-02-03 07:27:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:27:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:27:15 --> Utf8 Class Initialized
INFO - 2020-02-03 07:27:15 --> URI Class Initialized
INFO - 2020-02-03 07:27:15 --> Router Class Initialized
INFO - 2020-02-03 07:27:15 --> Output Class Initialized
INFO - 2020-02-03 07:27:15 --> Security Class Initialized
DEBUG - 2020-02-03 07:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:27:15 --> Input Class Initialized
INFO - 2020-02-03 07:27:15 --> Language Class Initialized
INFO - 2020-02-03 07:27:15 --> Language Class Initialized
INFO - 2020-02-03 07:27:15 --> Config Class Initialized
INFO - 2020-02-03 07:27:15 --> Loader Class Initialized
INFO - 2020-02-03 07:27:15 --> Helper loaded: url_helper
INFO - 2020-02-03 07:27:15 --> Helper loaded: file_helper
INFO - 2020-02-03 07:27:15 --> Helper loaded: form_helper
INFO - 2020-02-03 07:27:15 --> Helper loaded: my_helper
INFO - 2020-02-03 07:27:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:27:15 --> Controller Class Initialized
INFO - 2020-02-03 07:27:15 --> Database Utility Class Initialized
INFO - 2020-02-03 07:27:15 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:27:16 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:27:16 --> Helper loaded: download_helper
INFO - 2020-02-03 07:27:49 --> Config Class Initialized
INFO - 2020-02-03 07:27:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:27:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:27:49 --> Utf8 Class Initialized
INFO - 2020-02-03 07:27:50 --> URI Class Initialized
INFO - 2020-02-03 07:27:50 --> Router Class Initialized
INFO - 2020-02-03 07:27:50 --> Output Class Initialized
INFO - 2020-02-03 07:27:50 --> Security Class Initialized
DEBUG - 2020-02-03 07:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:27:50 --> Input Class Initialized
INFO - 2020-02-03 07:27:50 --> Language Class Initialized
INFO - 2020-02-03 07:27:50 --> Language Class Initialized
INFO - 2020-02-03 07:27:50 --> Config Class Initialized
INFO - 2020-02-03 07:27:50 --> Loader Class Initialized
INFO - 2020-02-03 07:27:50 --> Helper loaded: url_helper
INFO - 2020-02-03 07:27:50 --> Helper loaded: file_helper
INFO - 2020-02-03 07:27:50 --> Helper loaded: form_helper
INFO - 2020-02-03 07:27:50 --> Helper loaded: my_helper
INFO - 2020-02-03 07:27:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:27:50 --> Controller Class Initialized
INFO - 2020-02-03 07:27:50 --> Database Utility Class Initialized
INFO - 2020-02-03 07:27:50 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:27:50 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
ERROR - 2020-02-03 07:27:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''tahun_akademik, nama_file') VALUES ('20182', 'Backup_db_TA20182_03-02-2020.zip'' at line 1 - Invalid query: INSERT into t_backupdb ('tahun_akademik, nama_file') VALUES ('20182', 'Backup_db_TA20182_03-02-2020.zip')
INFO - 2020-02-03 07:27:50 --> Language file loaded: language/english/db_lang.php
INFO - 2020-02-03 07:28:20 --> Config Class Initialized
INFO - 2020-02-03 07:28:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:28:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:28:20 --> Utf8 Class Initialized
INFO - 2020-02-03 07:28:20 --> URI Class Initialized
INFO - 2020-02-03 07:28:20 --> Router Class Initialized
INFO - 2020-02-03 07:28:20 --> Output Class Initialized
INFO - 2020-02-03 07:28:20 --> Security Class Initialized
DEBUG - 2020-02-03 07:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:28:20 --> Input Class Initialized
INFO - 2020-02-03 07:28:20 --> Language Class Initialized
INFO - 2020-02-03 07:28:20 --> Language Class Initialized
INFO - 2020-02-03 07:28:20 --> Config Class Initialized
INFO - 2020-02-03 07:28:20 --> Loader Class Initialized
INFO - 2020-02-03 07:28:20 --> Helper loaded: url_helper
INFO - 2020-02-03 07:28:20 --> Helper loaded: file_helper
INFO - 2020-02-03 07:28:20 --> Helper loaded: form_helper
INFO - 2020-02-03 07:28:20 --> Helper loaded: my_helper
INFO - 2020-02-03 07:28:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:28:20 --> Controller Class Initialized
INFO - 2020-02-03 07:28:20 --> Database Utility Class Initialized
INFO - 2020-02-03 07:28:20 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:28:21 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 40
INFO - 2020-02-03 07:28:21 --> Helper loaded: download_helper
INFO - 2020-02-03 07:28:57 --> Config Class Initialized
INFO - 2020-02-03 07:28:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:28:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:28:57 --> Utf8 Class Initialized
INFO - 2020-02-03 07:28:57 --> URI Class Initialized
INFO - 2020-02-03 07:28:57 --> Router Class Initialized
INFO - 2020-02-03 07:28:58 --> Output Class Initialized
INFO - 2020-02-03 07:28:58 --> Security Class Initialized
DEBUG - 2020-02-03 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:28:58 --> Input Class Initialized
INFO - 2020-02-03 07:28:58 --> Language Class Initialized
INFO - 2020-02-03 07:28:58 --> Language Class Initialized
INFO - 2020-02-03 07:28:58 --> Config Class Initialized
INFO - 2020-02-03 07:28:58 --> Loader Class Initialized
INFO - 2020-02-03 07:28:58 --> Helper loaded: url_helper
INFO - 2020-02-03 07:28:58 --> Helper loaded: file_helper
INFO - 2020-02-03 07:28:58 --> Helper loaded: form_helper
INFO - 2020-02-03 07:28:58 --> Helper loaded: my_helper
INFO - 2020-02-03 07:28:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:28:58 --> Controller Class Initialized
DEBUG - 2020-02-03 07:28:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 07:28:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:28:58 --> Final output sent to browser
DEBUG - 2020-02-03 07:28:58 --> Total execution time: 0.5086
INFO - 2020-02-03 07:28:58 --> Config Class Initialized
INFO - 2020-02-03 07:28:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:28:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:28:58 --> Utf8 Class Initialized
INFO - 2020-02-03 07:28:58 --> URI Class Initialized
INFO - 2020-02-03 07:28:58 --> Router Class Initialized
INFO - 2020-02-03 07:28:58 --> Output Class Initialized
INFO - 2020-02-03 07:28:58 --> Security Class Initialized
DEBUG - 2020-02-03 07:28:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:28:58 --> Input Class Initialized
INFO - 2020-02-03 07:28:58 --> Language Class Initialized
INFO - 2020-02-03 07:28:59 --> Language Class Initialized
INFO - 2020-02-03 07:28:59 --> Config Class Initialized
INFO - 2020-02-03 07:28:59 --> Loader Class Initialized
INFO - 2020-02-03 07:28:59 --> Helper loaded: url_helper
INFO - 2020-02-03 07:28:59 --> Helper loaded: file_helper
INFO - 2020-02-03 07:28:59 --> Helper loaded: form_helper
INFO - 2020-02-03 07:28:59 --> Helper loaded: my_helper
INFO - 2020-02-03 07:28:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:28:59 --> Controller Class Initialized
INFO - 2020-02-03 07:32:58 --> Config Class Initialized
INFO - 2020-02-03 07:32:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:32:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:32:58 --> Utf8 Class Initialized
INFO - 2020-02-03 07:32:58 --> URI Class Initialized
INFO - 2020-02-03 07:32:58 --> Router Class Initialized
INFO - 2020-02-03 07:32:58 --> Output Class Initialized
INFO - 2020-02-03 07:32:58 --> Security Class Initialized
DEBUG - 2020-02-03 07:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:32:58 --> Input Class Initialized
INFO - 2020-02-03 07:32:58 --> Language Class Initialized
ERROR - 2020-02-03 07:32:58 --> 404 Page Not Found: ../modules/backup_db/controllers/Backup_db/index
INFO - 2020-02-03 07:33:50 --> Config Class Initialized
INFO - 2020-02-03 07:33:50 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:33:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:33:50 --> Utf8 Class Initialized
INFO - 2020-02-03 07:33:50 --> URI Class Initialized
INFO - 2020-02-03 07:33:50 --> Router Class Initialized
INFO - 2020-02-03 07:33:50 --> Output Class Initialized
INFO - 2020-02-03 07:33:50 --> Security Class Initialized
DEBUG - 2020-02-03 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:33:50 --> Input Class Initialized
INFO - 2020-02-03 07:33:50 --> Language Class Initialized
INFO - 2020-02-03 07:33:50 --> Language Class Initialized
INFO - 2020-02-03 07:33:51 --> Config Class Initialized
INFO - 2020-02-03 07:33:51 --> Loader Class Initialized
INFO - 2020-02-03 07:33:51 --> Helper loaded: url_helper
INFO - 2020-02-03 07:33:51 --> Helper loaded: file_helper
INFO - 2020-02-03 07:33:51 --> Helper loaded: form_helper
INFO - 2020-02-03 07:33:51 --> Helper loaded: my_helper
INFO - 2020-02-03 07:33:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:33:51 --> Controller Class Initialized
ERROR - 2020-02-03 07:33:51 --> Severity: Notice --> Undefined variable: admlevel E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php 136
DEBUG - 2020-02-03 07:33:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:33:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:33:51 --> Final output sent to browser
DEBUG - 2020-02-03 07:33:51 --> Total execution time: 0.6874
INFO - 2020-02-03 07:34:36 --> Config Class Initialized
INFO - 2020-02-03 07:34:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:34:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:34:36 --> Utf8 Class Initialized
INFO - 2020-02-03 07:34:36 --> URI Class Initialized
INFO - 2020-02-03 07:34:36 --> Router Class Initialized
INFO - 2020-02-03 07:34:36 --> Output Class Initialized
INFO - 2020-02-03 07:34:36 --> Security Class Initialized
DEBUG - 2020-02-03 07:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:34:36 --> Input Class Initialized
INFO - 2020-02-03 07:34:36 --> Language Class Initialized
INFO - 2020-02-03 07:34:36 --> Language Class Initialized
INFO - 2020-02-03 07:34:36 --> Config Class Initialized
INFO - 2020-02-03 07:34:36 --> Loader Class Initialized
INFO - 2020-02-03 07:34:36 --> Helper loaded: url_helper
INFO - 2020-02-03 07:34:36 --> Helper loaded: file_helper
INFO - 2020-02-03 07:34:36 --> Helper loaded: form_helper
INFO - 2020-02-03 07:34:37 --> Helper loaded: my_helper
INFO - 2020-02-03 07:34:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:34:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:34:37 --> Controller Class Initialized
DEBUG - 2020-02-03 07:34:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:34:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:34:37 --> Final output sent to browser
DEBUG - 2020-02-03 07:34:37 --> Total execution time: 0.6291
INFO - 2020-02-03 07:35:07 --> Config Class Initialized
INFO - 2020-02-03 07:35:07 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:35:07 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:35:07 --> Utf8 Class Initialized
INFO - 2020-02-03 07:35:07 --> URI Class Initialized
INFO - 2020-02-03 07:35:07 --> Router Class Initialized
INFO - 2020-02-03 07:35:07 --> Output Class Initialized
INFO - 2020-02-03 07:35:07 --> Security Class Initialized
DEBUG - 2020-02-03 07:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:35:07 --> Input Class Initialized
INFO - 2020-02-03 07:35:07 --> Language Class Initialized
INFO - 2020-02-03 07:35:07 --> Language Class Initialized
INFO - 2020-02-03 07:35:07 --> Config Class Initialized
INFO - 2020-02-03 07:35:07 --> Loader Class Initialized
INFO - 2020-02-03 07:35:07 --> Helper loaded: url_helper
INFO - 2020-02-03 07:35:07 --> Helper loaded: file_helper
INFO - 2020-02-03 07:35:07 --> Helper loaded: form_helper
INFO - 2020-02-03 07:35:07 --> Helper loaded: my_helper
INFO - 2020-02-03 07:35:07 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:35:07 --> Controller Class Initialized
DEBUG - 2020-02-03 07:35:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:35:07 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:35:08 --> Final output sent to browser
DEBUG - 2020-02-03 07:35:08 --> Total execution time: 0.6206
INFO - 2020-02-03 07:35:25 --> Config Class Initialized
INFO - 2020-02-03 07:35:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:35:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:35:25 --> Utf8 Class Initialized
INFO - 2020-02-03 07:35:25 --> URI Class Initialized
INFO - 2020-02-03 07:35:25 --> Router Class Initialized
INFO - 2020-02-03 07:35:25 --> Output Class Initialized
INFO - 2020-02-03 07:35:25 --> Security Class Initialized
DEBUG - 2020-02-03 07:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:35:25 --> Input Class Initialized
INFO - 2020-02-03 07:35:25 --> Language Class Initialized
INFO - 2020-02-03 07:35:25 --> Language Class Initialized
INFO - 2020-02-03 07:35:26 --> Config Class Initialized
INFO - 2020-02-03 07:35:26 --> Loader Class Initialized
INFO - 2020-02-03 07:35:26 --> Helper loaded: url_helper
INFO - 2020-02-03 07:35:26 --> Helper loaded: file_helper
INFO - 2020-02-03 07:35:26 --> Helper loaded: form_helper
INFO - 2020-02-03 07:35:26 --> Helper loaded: my_helper
INFO - 2020-02-03 07:35:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:35:26 --> Controller Class Initialized
DEBUG - 2020-02-03 07:35:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:35:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:35:26 --> Final output sent to browser
DEBUG - 2020-02-03 07:35:26 --> Total execution time: 0.5337
INFO - 2020-02-03 07:35:32 --> Config Class Initialized
INFO - 2020-02-03 07:35:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:35:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:35:32 --> Utf8 Class Initialized
INFO - 2020-02-03 07:35:32 --> URI Class Initialized
INFO - 2020-02-03 07:35:32 --> Router Class Initialized
INFO - 2020-02-03 07:35:32 --> Output Class Initialized
INFO - 2020-02-03 07:35:32 --> Security Class Initialized
DEBUG - 2020-02-03 07:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:35:32 --> Input Class Initialized
INFO - 2020-02-03 07:35:32 --> Language Class Initialized
ERROR - 2020-02-03 07:35:32 --> 404 Page Not Found: /index
INFO - 2020-02-03 07:35:36 --> Config Class Initialized
INFO - 2020-02-03 07:35:36 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:35:36 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:35:36 --> Utf8 Class Initialized
INFO - 2020-02-03 07:35:36 --> URI Class Initialized
INFO - 2020-02-03 07:35:36 --> Router Class Initialized
INFO - 2020-02-03 07:35:36 --> Output Class Initialized
INFO - 2020-02-03 07:35:36 --> Security Class Initialized
DEBUG - 2020-02-03 07:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:35:36 --> Input Class Initialized
INFO - 2020-02-03 07:35:36 --> Language Class Initialized
INFO - 2020-02-03 07:35:36 --> Language Class Initialized
INFO - 2020-02-03 07:35:36 --> Config Class Initialized
INFO - 2020-02-03 07:35:36 --> Loader Class Initialized
INFO - 2020-02-03 07:35:36 --> Helper loaded: url_helper
INFO - 2020-02-03 07:35:36 --> Helper loaded: file_helper
INFO - 2020-02-03 07:35:36 --> Helper loaded: form_helper
INFO - 2020-02-03 07:35:36 --> Helper loaded: my_helper
INFO - 2020-02-03 07:35:36 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:35:36 --> Controller Class Initialized
DEBUG - 2020-02-03 07:35:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:35:36 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:35:36 --> Final output sent to browser
DEBUG - 2020-02-03 07:35:36 --> Total execution time: 0.6998
INFO - 2020-02-03 07:35:37 --> Config Class Initialized
INFO - 2020-02-03 07:35:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:35:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:35:37 --> Utf8 Class Initialized
INFO - 2020-02-03 07:35:37 --> URI Class Initialized
INFO - 2020-02-03 07:35:37 --> Router Class Initialized
INFO - 2020-02-03 07:35:37 --> Output Class Initialized
INFO - 2020-02-03 07:35:37 --> Security Class Initialized
DEBUG - 2020-02-03 07:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:35:37 --> Input Class Initialized
INFO - 2020-02-03 07:35:37 --> Language Class Initialized
ERROR - 2020-02-03 07:35:37 --> 404 Page Not Found: /index
INFO - 2020-02-03 07:36:52 --> Config Class Initialized
INFO - 2020-02-03 07:36:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:36:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:36:52 --> Utf8 Class Initialized
INFO - 2020-02-03 07:36:52 --> URI Class Initialized
INFO - 2020-02-03 07:36:52 --> Router Class Initialized
INFO - 2020-02-03 07:36:52 --> Output Class Initialized
INFO - 2020-02-03 07:36:52 --> Security Class Initialized
DEBUG - 2020-02-03 07:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:36:52 --> Input Class Initialized
INFO - 2020-02-03 07:36:52 --> Language Class Initialized
INFO - 2020-02-03 07:36:52 --> Language Class Initialized
INFO - 2020-02-03 07:36:52 --> Config Class Initialized
INFO - 2020-02-03 07:36:52 --> Loader Class Initialized
INFO - 2020-02-03 07:36:52 --> Helper loaded: url_helper
INFO - 2020-02-03 07:36:52 --> Helper loaded: file_helper
INFO - 2020-02-03 07:36:52 --> Helper loaded: form_helper
INFO - 2020-02-03 07:36:52 --> Helper loaded: my_helper
INFO - 2020-02-03 07:36:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:36:52 --> Controller Class Initialized
DEBUG - 2020-02-03 07:36:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:36:52 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:36:52 --> Final output sent to browser
DEBUG - 2020-02-03 07:36:53 --> Total execution time: 0.5967
INFO - 2020-02-03 07:37:11 --> Config Class Initialized
INFO - 2020-02-03 07:37:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:37:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:37:11 --> Utf8 Class Initialized
INFO - 2020-02-03 07:37:11 --> URI Class Initialized
INFO - 2020-02-03 07:37:12 --> Router Class Initialized
INFO - 2020-02-03 07:37:12 --> Output Class Initialized
INFO - 2020-02-03 07:37:12 --> Security Class Initialized
DEBUG - 2020-02-03 07:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:37:12 --> Input Class Initialized
INFO - 2020-02-03 07:37:12 --> Language Class Initialized
ERROR - 2020-02-03 07:37:12 --> 404 Page Not Found: /index
INFO - 2020-02-03 07:37:39 --> Config Class Initialized
INFO - 2020-02-03 07:37:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:37:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:37:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:37:39 --> URI Class Initialized
INFO - 2020-02-03 07:37:39 --> Router Class Initialized
INFO - 2020-02-03 07:37:39 --> Output Class Initialized
INFO - 2020-02-03 07:37:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:37:39 --> Input Class Initialized
INFO - 2020-02-03 07:37:39 --> Language Class Initialized
INFO - 2020-02-03 07:37:39 --> Language Class Initialized
INFO - 2020-02-03 07:37:39 --> Config Class Initialized
INFO - 2020-02-03 07:37:39 --> Loader Class Initialized
INFO - 2020-02-03 07:37:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:37:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:37:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:37:39 --> Config Class Initialized
INFO - 2020-02-03 07:37:39 --> Hooks Class Initialized
INFO - 2020-02-03 07:37:39 --> Helper loaded: my_helper
DEBUG - 2020-02-03 07:37:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:37:39 --> Database Driver Class Initialized
INFO - 2020-02-03 07:37:39 --> Utf8 Class Initialized
DEBUG - 2020-02-03 07:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:37:39 --> URI Class Initialized
INFO - 2020-02-03 07:37:39 --> Controller Class Initialized
INFO - 2020-02-03 07:37:39 --> Router Class Initialized
INFO - 2020-02-03 07:37:39 --> Output Class Initialized
INFO - 2020-02-03 07:37:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:37:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 07:37:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
DEBUG - 2020-02-03 07:37:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:37:39 --> Input Class Initialized
INFO - 2020-02-03 07:37:39 --> Final output sent to browser
DEBUG - 2020-02-03 07:37:39 --> Total execution time: 0.6527
INFO - 2020-02-03 07:37:39 --> Language Class Initialized
INFO - 2020-02-03 07:37:39 --> Language Class Initialized
INFO - 2020-02-03 07:37:39 --> Config Class Initialized
INFO - 2020-02-03 07:37:39 --> Loader Class Initialized
INFO - 2020-02-03 07:37:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:37:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:37:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:37:39 --> Helper loaded: my_helper
INFO - 2020-02-03 07:37:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:37:40 --> Controller Class Initialized
DEBUG - 2020-02-03 07:37:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 07:37:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:37:40 --> Final output sent to browser
DEBUG - 2020-02-03 07:37:40 --> Total execution time: 0.5372
INFO - 2020-02-03 07:37:40 --> Config Class Initialized
INFO - 2020-02-03 07:37:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:37:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:37:40 --> Utf8 Class Initialized
INFO - 2020-02-03 07:37:40 --> URI Class Initialized
INFO - 2020-02-03 07:37:40 --> Router Class Initialized
INFO - 2020-02-03 07:37:40 --> Output Class Initialized
INFO - 2020-02-03 07:37:40 --> Config Class Initialized
INFO - 2020-02-03 07:37:40 --> Hooks Class Initialized
INFO - 2020-02-03 07:37:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:37:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:37:40 --> Utf8 Class Initialized
DEBUG - 2020-02-03 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:37:40 --> Input Class Initialized
INFO - 2020-02-03 07:37:40 --> URI Class Initialized
INFO - 2020-02-03 07:37:40 --> Language Class Initialized
INFO - 2020-02-03 07:37:40 --> Router Class Initialized
ERROR - 2020-02-03 07:37:40 --> 404 Page Not Found: /index
INFO - 2020-02-03 07:37:40 --> Output Class Initialized
INFO - 2020-02-03 07:37:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:37:41 --> Input Class Initialized
INFO - 2020-02-03 07:37:41 --> Language Class Initialized
INFO - 2020-02-03 07:37:41 --> Language Class Initialized
INFO - 2020-02-03 07:37:41 --> Config Class Initialized
INFO - 2020-02-03 07:37:41 --> Loader Class Initialized
INFO - 2020-02-03 07:37:41 --> Helper loaded: url_helper
INFO - 2020-02-03 07:37:41 --> Helper loaded: file_helper
INFO - 2020-02-03 07:37:41 --> Helper loaded: form_helper
INFO - 2020-02-03 07:37:41 --> Helper loaded: my_helper
INFO - 2020-02-03 07:37:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:37:41 --> Controller Class Initialized
INFO - 2020-02-03 07:38:38 --> Config Class Initialized
INFO - 2020-02-03 07:38:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:38:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:38:38 --> Utf8 Class Initialized
INFO - 2020-02-03 07:38:38 --> URI Class Initialized
INFO - 2020-02-03 07:38:38 --> Router Class Initialized
INFO - 2020-02-03 07:38:38 --> Output Class Initialized
INFO - 2020-02-03 07:38:38 --> Security Class Initialized
DEBUG - 2020-02-03 07:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:38:38 --> Input Class Initialized
INFO - 2020-02-03 07:38:38 --> Language Class Initialized
INFO - 2020-02-03 07:38:38 --> Language Class Initialized
INFO - 2020-02-03 07:38:38 --> Config Class Initialized
INFO - 2020-02-03 07:38:38 --> Loader Class Initialized
INFO - 2020-02-03 07:38:38 --> Helper loaded: url_helper
INFO - 2020-02-03 07:38:38 --> Helper loaded: file_helper
INFO - 2020-02-03 07:38:38 --> Helper loaded: form_helper
INFO - 2020-02-03 07:38:38 --> Helper loaded: my_helper
INFO - 2020-02-03 07:38:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:38:38 --> Controller Class Initialized
DEBUG - 2020-02-03 07:38:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:38:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:38:38 --> Final output sent to browser
DEBUG - 2020-02-03 07:38:38 --> Total execution time: 0.5265
INFO - 2020-02-03 07:38:39 --> Config Class Initialized
INFO - 2020-02-03 07:38:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:38:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:38:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:38:39 --> URI Class Initialized
INFO - 2020-02-03 07:38:39 --> Router Class Initialized
INFO - 2020-02-03 07:38:39 --> Output Class Initialized
INFO - 2020-02-03 07:38:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:38:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:38:39 --> Input Class Initialized
INFO - 2020-02-03 07:38:39 --> Language Class Initialized
INFO - 2020-02-03 07:38:39 --> Language Class Initialized
INFO - 2020-02-03 07:38:39 --> Config Class Initialized
INFO - 2020-02-03 07:38:39 --> Loader Class Initialized
INFO - 2020-02-03 07:38:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:38:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:38:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:38:39 --> Helper loaded: my_helper
INFO - 2020-02-03 07:38:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:38:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:38:39 --> Controller Class Initialized
INFO - 2020-02-03 07:40:23 --> Config Class Initialized
INFO - 2020-02-03 07:40:23 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:23 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:23 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:23 --> URI Class Initialized
INFO - 2020-02-03 07:40:23 --> Router Class Initialized
INFO - 2020-02-03 07:40:23 --> Output Class Initialized
INFO - 2020-02-03 07:40:23 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:23 --> Input Class Initialized
INFO - 2020-02-03 07:40:23 --> Language Class Initialized
INFO - 2020-02-03 07:40:24 --> Language Class Initialized
INFO - 2020-02-03 07:40:24 --> Config Class Initialized
INFO - 2020-02-03 07:40:24 --> Loader Class Initialized
INFO - 2020-02-03 07:40:24 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:24 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:24 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:40:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:24 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:24 --> Total execution time: 0.5592
INFO - 2020-02-03 07:40:24 --> Config Class Initialized
INFO - 2020-02-03 07:40:24 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:24 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:24 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:24 --> URI Class Initialized
INFO - 2020-02-03 07:40:24 --> Router Class Initialized
INFO - 2020-02-03 07:40:24 --> Output Class Initialized
INFO - 2020-02-03 07:40:24 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:24 --> Input Class Initialized
INFO - 2020-02-03 07:40:24 --> Language Class Initialized
INFO - 2020-02-03 07:40:24 --> Language Class Initialized
INFO - 2020-02-03 07:40:24 --> Config Class Initialized
INFO - 2020-02-03 07:40:24 --> Loader Class Initialized
INFO - 2020-02-03 07:40:24 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:24 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:24 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:25 --> Controller Class Initialized
INFO - 2020-02-03 07:40:32 --> Config Class Initialized
INFO - 2020-02-03 07:40:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:32 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:32 --> URI Class Initialized
INFO - 2020-02-03 07:40:32 --> Router Class Initialized
INFO - 2020-02-03 07:40:32 --> Output Class Initialized
INFO - 2020-02-03 07:40:32 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:32 --> Input Class Initialized
INFO - 2020-02-03 07:40:32 --> Language Class Initialized
INFO - 2020-02-03 07:40:32 --> Language Class Initialized
INFO - 2020-02-03 07:40:32 --> Config Class Initialized
INFO - 2020-02-03 07:40:32 --> Loader Class Initialized
INFO - 2020-02-03 07:40:32 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:32 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:32 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:32 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:32 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:40:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:32 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:32 --> Total execution time: 0.5679
INFO - 2020-02-03 07:40:33 --> Config Class Initialized
INFO - 2020-02-03 07:40:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:33 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:33 --> URI Class Initialized
INFO - 2020-02-03 07:40:33 --> Router Class Initialized
INFO - 2020-02-03 07:40:33 --> Output Class Initialized
INFO - 2020-02-03 07:40:33 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:33 --> Input Class Initialized
INFO - 2020-02-03 07:40:33 --> Language Class Initialized
INFO - 2020-02-03 07:40:33 --> Language Class Initialized
INFO - 2020-02-03 07:40:33 --> Config Class Initialized
INFO - 2020-02-03 07:40:33 --> Loader Class Initialized
INFO - 2020-02-03 07:40:33 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:33 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:33 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:33 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:33 --> Controller Class Initialized
INFO - 2020-02-03 07:40:38 --> Config Class Initialized
INFO - 2020-02-03 07:40:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:39 --> URI Class Initialized
INFO - 2020-02-03 07:40:39 --> Router Class Initialized
INFO - 2020-02-03 07:40:39 --> Output Class Initialized
INFO - 2020-02-03 07:40:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:39 --> Input Class Initialized
INFO - 2020-02-03 07:40:39 --> Language Class Initialized
INFO - 2020-02-03 07:40:39 --> Language Class Initialized
INFO - 2020-02-03 07:40:39 --> Config Class Initialized
INFO - 2020-02-03 07:40:39 --> Loader Class Initialized
INFO - 2020-02-03 07:40:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:39 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:39 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:40:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:39 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:39 --> Total execution time: 0.5136
INFO - 2020-02-03 07:40:39 --> Config Class Initialized
INFO - 2020-02-03 07:40:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:39 --> URI Class Initialized
INFO - 2020-02-03 07:40:39 --> Router Class Initialized
INFO - 2020-02-03 07:40:39 --> Output Class Initialized
INFO - 2020-02-03 07:40:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:39 --> Input Class Initialized
INFO - 2020-02-03 07:40:39 --> Language Class Initialized
INFO - 2020-02-03 07:40:39 --> Language Class Initialized
INFO - 2020-02-03 07:40:39 --> Config Class Initialized
INFO - 2020-02-03 07:40:39 --> Loader Class Initialized
INFO - 2020-02-03 07:40:40 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:40 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:40 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:40 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:40 --> Controller Class Initialized
INFO - 2020-02-03 07:40:46 --> Config Class Initialized
INFO - 2020-02-03 07:40:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:46 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:46 --> URI Class Initialized
INFO - 2020-02-03 07:40:46 --> Router Class Initialized
INFO - 2020-02-03 07:40:46 --> Output Class Initialized
INFO - 2020-02-03 07:40:46 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:46 --> Input Class Initialized
INFO - 2020-02-03 07:40:47 --> Language Class Initialized
INFO - 2020-02-03 07:40:47 --> Language Class Initialized
INFO - 2020-02-03 07:40:47 --> Config Class Initialized
INFO - 2020-02-03 07:40:47 --> Loader Class Initialized
INFO - 2020-02-03 07:40:47 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:47 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:47 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:47 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:47 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_ekstra/views/list.php
DEBUG - 2020-02-03 07:40:47 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:47 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:47 --> Total execution time: 0.6547
INFO - 2020-02-03 07:40:47 --> Config Class Initialized
INFO - 2020-02-03 07:40:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:47 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:47 --> URI Class Initialized
INFO - 2020-02-03 07:40:47 --> Router Class Initialized
INFO - 2020-02-03 07:40:47 --> Output Class Initialized
INFO - 2020-02-03 07:40:47 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:47 --> Input Class Initialized
INFO - 2020-02-03 07:40:47 --> Language Class Initialized
INFO - 2020-02-03 07:40:48 --> Language Class Initialized
INFO - 2020-02-03 07:40:48 --> Config Class Initialized
INFO - 2020-02-03 07:40:48 --> Loader Class Initialized
INFO - 2020-02-03 07:40:48 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:48 --> Controller Class Initialized
INFO - 2020-02-03 07:40:48 --> Config Class Initialized
INFO - 2020-02-03 07:40:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:48 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:48 --> URI Class Initialized
INFO - 2020-02-03 07:40:48 --> Router Class Initialized
INFO - 2020-02-03 07:40:48 --> Output Class Initialized
INFO - 2020-02-03 07:40:48 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:48 --> Input Class Initialized
INFO - 2020-02-03 07:40:48 --> Language Class Initialized
INFO - 2020-02-03 07:40:48 --> Language Class Initialized
INFO - 2020-02-03 07:40:48 --> Config Class Initialized
INFO - 2020-02-03 07:40:48 --> Loader Class Initialized
INFO - 2020-02-03 07:40:48 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:48 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:48 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_guru/views/list.php
DEBUG - 2020-02-03 07:40:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:48 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:48 --> Total execution time: 0.5348
INFO - 2020-02-03 07:40:48 --> Config Class Initialized
INFO - 2020-02-03 07:40:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:49 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:49 --> URI Class Initialized
INFO - 2020-02-03 07:40:49 --> Router Class Initialized
INFO - 2020-02-03 07:40:49 --> Output Class Initialized
INFO - 2020-02-03 07:40:49 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:49 --> Input Class Initialized
INFO - 2020-02-03 07:40:49 --> Language Class Initialized
INFO - 2020-02-03 07:40:49 --> Language Class Initialized
INFO - 2020-02-03 07:40:49 --> Config Class Initialized
INFO - 2020-02-03 07:40:49 --> Loader Class Initialized
INFO - 2020-02-03 07:40:49 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:49 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:49 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:49 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:49 --> Controller Class Initialized
INFO - 2020-02-03 07:40:49 --> Config Class Initialized
INFO - 2020-02-03 07:40:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:49 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:49 --> URI Class Initialized
INFO - 2020-02-03 07:40:49 --> Router Class Initialized
INFO - 2020-02-03 07:40:49 --> Output Class Initialized
INFO - 2020-02-03 07:40:50 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:50 --> Input Class Initialized
INFO - 2020-02-03 07:40:50 --> Language Class Initialized
INFO - 2020-02-03 07:40:50 --> Language Class Initialized
INFO - 2020-02-03 07:40:50 --> Config Class Initialized
INFO - 2020-02-03 07:40:50 --> Loader Class Initialized
INFO - 2020-02-03 07:40:50 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:50 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:50 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:50 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:50 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_siswa/views/list.php
DEBUG - 2020-02-03 07:40:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:50 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:50 --> Total execution time: 0.5564
INFO - 2020-02-03 07:40:50 --> Config Class Initialized
INFO - 2020-02-03 07:40:50 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:50 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:50 --> URI Class Initialized
INFO - 2020-02-03 07:40:50 --> Router Class Initialized
INFO - 2020-02-03 07:40:50 --> Output Class Initialized
INFO - 2020-02-03 07:40:50 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:50 --> Input Class Initialized
INFO - 2020-02-03 07:40:50 --> Language Class Initialized
INFO - 2020-02-03 07:40:50 --> Language Class Initialized
INFO - 2020-02-03 07:40:50 --> Config Class Initialized
INFO - 2020-02-03 07:40:50 --> Loader Class Initialized
INFO - 2020-02-03 07:40:50 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:50 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:51 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:51 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:51 --> Controller Class Initialized
INFO - 2020-02-03 07:40:51 --> Config Class Initialized
INFO - 2020-02-03 07:40:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:51 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:51 --> URI Class Initialized
INFO - 2020-02-03 07:40:51 --> Router Class Initialized
INFO - 2020-02-03 07:40:51 --> Output Class Initialized
INFO - 2020-02-03 07:40:51 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:51 --> Input Class Initialized
INFO - 2020-02-03 07:40:51 --> Language Class Initialized
INFO - 2020-02-03 07:40:51 --> Language Class Initialized
INFO - 2020-02-03 07:40:51 --> Config Class Initialized
INFO - 2020-02-03 07:40:51 --> Loader Class Initialized
INFO - 2020-02-03 07:40:51 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:51 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:51 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:51 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:51 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_kelas/views/list.php
DEBUG - 2020-02-03 07:40:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:51 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:52 --> Total execution time: 0.5931
INFO - 2020-02-03 07:40:52 --> Config Class Initialized
INFO - 2020-02-03 07:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:52 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:52 --> URI Class Initialized
INFO - 2020-02-03 07:40:52 --> Router Class Initialized
INFO - 2020-02-03 07:40:52 --> Output Class Initialized
INFO - 2020-02-03 07:40:52 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:52 --> Input Class Initialized
INFO - 2020-02-03 07:40:52 --> Language Class Initialized
INFO - 2020-02-03 07:40:52 --> Language Class Initialized
INFO - 2020-02-03 07:40:52 --> Config Class Initialized
INFO - 2020-02-03 07:40:52 --> Loader Class Initialized
INFO - 2020-02-03 07:40:52 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:52 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:52 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:52 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:52 --> Config Class Initialized
INFO - 2020-02-03 07:40:52 --> Database Driver Class Initialized
INFO - 2020-02-03 07:40:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-02-03 07:40:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:52 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:52 --> Controller Class Initialized
INFO - 2020-02-03 07:40:52 --> URI Class Initialized
INFO - 2020-02-03 07:40:52 --> Router Class Initialized
INFO - 2020-02-03 07:40:52 --> Output Class Initialized
INFO - 2020-02-03 07:40:52 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:52 --> Input Class Initialized
INFO - 2020-02-03 07:40:52 --> Language Class Initialized
INFO - 2020-02-03 07:40:52 --> Language Class Initialized
INFO - 2020-02-03 07:40:52 --> Config Class Initialized
INFO - 2020-02-03 07:40:53 --> Loader Class Initialized
INFO - 2020-02-03 07:40:53 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:53 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:53 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/data_mapel/views/list.php
DEBUG - 2020-02-03 07:40:53 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:53 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:53 --> Total execution time: 0.5987
INFO - 2020-02-03 07:40:53 --> Config Class Initialized
INFO - 2020-02-03 07:40:53 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:53 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:53 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:53 --> URI Class Initialized
INFO - 2020-02-03 07:40:53 --> Router Class Initialized
INFO - 2020-02-03 07:40:53 --> Output Class Initialized
INFO - 2020-02-03 07:40:53 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:53 --> Input Class Initialized
INFO - 2020-02-03 07:40:53 --> Language Class Initialized
INFO - 2020-02-03 07:40:53 --> Language Class Initialized
INFO - 2020-02-03 07:40:53 --> Config Class Initialized
INFO - 2020-02-03 07:40:53 --> Loader Class Initialized
INFO - 2020-02-03 07:40:53 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:53 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:53 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:53 --> Controller Class Initialized
INFO - 2020-02-03 07:40:55 --> Config Class Initialized
INFO - 2020-02-03 07:40:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:55 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:55 --> URI Class Initialized
INFO - 2020-02-03 07:40:55 --> Router Class Initialized
INFO - 2020-02-03 07:40:55 --> Output Class Initialized
INFO - 2020-02-03 07:40:55 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:55 --> Input Class Initialized
INFO - 2020-02-03 07:40:55 --> Language Class Initialized
INFO - 2020-02-03 07:40:55 --> Language Class Initialized
INFO - 2020-02-03 07:40:55 --> Config Class Initialized
INFO - 2020-02-03 07:40:55 --> Loader Class Initialized
INFO - 2020-02-03 07:40:56 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:56 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 07:40:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:56 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:56 --> Total execution time: 0.5874
INFO - 2020-02-03 07:40:56 --> Config Class Initialized
INFO - 2020-02-03 07:40:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:56 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:56 --> URI Class Initialized
INFO - 2020-02-03 07:40:56 --> Router Class Initialized
INFO - 2020-02-03 07:40:56 --> Output Class Initialized
INFO - 2020-02-03 07:40:56 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:56 --> Input Class Initialized
INFO - 2020-02-03 07:40:56 --> Language Class Initialized
INFO - 2020-02-03 07:40:56 --> Language Class Initialized
INFO - 2020-02-03 07:40:56 --> Config Class Initialized
INFO - 2020-02-03 07:40:56 --> Loader Class Initialized
INFO - 2020-02-03 07:40:56 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:56 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:57 --> Controller Class Initialized
INFO - 2020-02-03 07:40:58 --> Config Class Initialized
INFO - 2020-02-03 07:40:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:40:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:40:58 --> Utf8 Class Initialized
INFO - 2020-02-03 07:40:58 --> URI Class Initialized
INFO - 2020-02-03 07:40:58 --> Router Class Initialized
INFO - 2020-02-03 07:40:58 --> Output Class Initialized
INFO - 2020-02-03 07:40:58 --> Security Class Initialized
DEBUG - 2020-02-03 07:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:40:58 --> Input Class Initialized
INFO - 2020-02-03 07:40:58 --> Language Class Initialized
INFO - 2020-02-03 07:40:58 --> Language Class Initialized
INFO - 2020-02-03 07:40:58 --> Config Class Initialized
INFO - 2020-02-03 07:40:58 --> Loader Class Initialized
INFO - 2020-02-03 07:40:58 --> Helper loaded: url_helper
INFO - 2020-02-03 07:40:58 --> Helper loaded: file_helper
INFO - 2020-02-03 07:40:58 --> Helper loaded: form_helper
INFO - 2020-02-03 07:40:58 --> Helper loaded: my_helper
INFO - 2020-02-03 07:40:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:40:59 --> Controller Class Initialized
DEBUG - 2020-02-03 07:40:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 07:40:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:40:59 --> Final output sent to browser
DEBUG - 2020-02-03 07:40:59 --> Total execution time: 0.6431
INFO - 2020-02-03 07:41:01 --> Config Class Initialized
INFO - 2020-02-03 07:41:01 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:01 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:01 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:01 --> URI Class Initialized
INFO - 2020-02-03 07:41:01 --> Router Class Initialized
INFO - 2020-02-03 07:41:01 --> Output Class Initialized
INFO - 2020-02-03 07:41:01 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:01 --> Input Class Initialized
INFO - 2020-02-03 07:41:01 --> Language Class Initialized
INFO - 2020-02-03 07:41:01 --> Language Class Initialized
INFO - 2020-02-03 07:41:01 --> Config Class Initialized
INFO - 2020-02-03 07:41:01 --> Loader Class Initialized
INFO - 2020-02-03 07:41:01 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:01 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:01 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:01 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:01 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:01 --> Controller Class Initialized
DEBUG - 2020-02-03 07:41:01 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 07:41:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:41:02 --> Final output sent to browser
DEBUG - 2020-02-03 07:41:02 --> Total execution time: 0.6373
INFO - 2020-02-03 07:41:04 --> Config Class Initialized
INFO - 2020-02-03 07:41:04 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:04 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:04 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:04 --> URI Class Initialized
INFO - 2020-02-03 07:41:04 --> Router Class Initialized
INFO - 2020-02-03 07:41:04 --> Output Class Initialized
INFO - 2020-02-03 07:41:04 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:04 --> Input Class Initialized
INFO - 2020-02-03 07:41:04 --> Language Class Initialized
INFO - 2020-02-03 07:41:04 --> Language Class Initialized
INFO - 2020-02-03 07:41:04 --> Config Class Initialized
INFO - 2020-02-03 07:41:04 --> Loader Class Initialized
INFO - 2020-02-03 07:41:04 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:04 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:04 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:04 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:04 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:05 --> Controller Class Initialized
DEBUG - 2020-02-03 07:41:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-03 07:41:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:41:05 --> Final output sent to browser
DEBUG - 2020-02-03 07:41:05 --> Total execution time: 0.5733
INFO - 2020-02-03 07:41:05 --> Config Class Initialized
INFO - 2020-02-03 07:41:05 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:05 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:05 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:05 --> URI Class Initialized
INFO - 2020-02-03 07:41:05 --> Router Class Initialized
INFO - 2020-02-03 07:41:05 --> Output Class Initialized
INFO - 2020-02-03 07:41:05 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:05 --> Input Class Initialized
INFO - 2020-02-03 07:41:05 --> Language Class Initialized
INFO - 2020-02-03 07:41:05 --> Language Class Initialized
INFO - 2020-02-03 07:41:05 --> Config Class Initialized
INFO - 2020-02-03 07:41:05 --> Loader Class Initialized
INFO - 2020-02-03 07:41:05 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:05 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:05 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:05 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:05 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:05 --> Controller Class Initialized
INFO - 2020-02-03 07:41:11 --> Config Class Initialized
INFO - 2020-02-03 07:41:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:11 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:11 --> URI Class Initialized
INFO - 2020-02-03 07:41:11 --> Router Class Initialized
INFO - 2020-02-03 07:41:11 --> Output Class Initialized
INFO - 2020-02-03 07:41:11 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:11 --> Input Class Initialized
INFO - 2020-02-03 07:41:12 --> Language Class Initialized
INFO - 2020-02-03 07:41:12 --> Language Class Initialized
INFO - 2020-02-03 07:41:12 --> Config Class Initialized
INFO - 2020-02-03 07:41:12 --> Loader Class Initialized
INFO - 2020-02-03 07:41:12 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:12 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:12 --> Controller Class Initialized
DEBUG - 2020-02-03 07:41:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:41:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:41:12 --> Final output sent to browser
DEBUG - 2020-02-03 07:41:12 --> Total execution time: 0.5277
INFO - 2020-02-03 07:41:12 --> Config Class Initialized
INFO - 2020-02-03 07:41:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:12 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:12 --> URI Class Initialized
INFO - 2020-02-03 07:41:12 --> Router Class Initialized
INFO - 2020-02-03 07:41:12 --> Output Class Initialized
INFO - 2020-02-03 07:41:12 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:12 --> Input Class Initialized
INFO - 2020-02-03 07:41:12 --> Language Class Initialized
INFO - 2020-02-03 07:41:12 --> Language Class Initialized
INFO - 2020-02-03 07:41:12 --> Config Class Initialized
INFO - 2020-02-03 07:41:12 --> Loader Class Initialized
INFO - 2020-02-03 07:41:12 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:12 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:12 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:12 --> Controller Class Initialized
INFO - 2020-02-03 07:41:42 --> Config Class Initialized
INFO - 2020-02-03 07:41:42 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:42 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:42 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:42 --> URI Class Initialized
INFO - 2020-02-03 07:41:42 --> Router Class Initialized
INFO - 2020-02-03 07:41:42 --> Output Class Initialized
INFO - 2020-02-03 07:41:42 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:42 --> Input Class Initialized
INFO - 2020-02-03 07:41:42 --> Language Class Initialized
INFO - 2020-02-03 07:41:42 --> Language Class Initialized
INFO - 2020-02-03 07:41:42 --> Config Class Initialized
INFO - 2020-02-03 07:41:42 --> Loader Class Initialized
INFO - 2020-02-03 07:41:42 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:42 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:42 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:42 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:42 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:42 --> Controller Class Initialized
ERROR - 2020-02-03 07:41:42 --> Severity: Notice --> Undefined variable: detil_mp E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\views\list.php 6
ERROR - 2020-02-03 07:41:42 --> Severity: Notice --> Undefined variable: detil_mp E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\views\list.php 6
ERROR - 2020-02-03 07:41:42 --> Severity: Notice --> Undefined variable: detil_mp E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\views\list.php 6
DEBUG - 2020-02-03 07:41:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:41:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:41:42 --> Final output sent to browser
DEBUG - 2020-02-03 07:41:42 --> Total execution time: 0.6169
INFO - 2020-02-03 07:41:42 --> Config Class Initialized
INFO - 2020-02-03 07:41:42 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:41:42 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:41:43 --> Utf8 Class Initialized
INFO - 2020-02-03 07:41:43 --> URI Class Initialized
INFO - 2020-02-03 07:41:43 --> Router Class Initialized
INFO - 2020-02-03 07:41:43 --> Output Class Initialized
INFO - 2020-02-03 07:41:43 --> Security Class Initialized
DEBUG - 2020-02-03 07:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:41:43 --> Input Class Initialized
INFO - 2020-02-03 07:41:43 --> Language Class Initialized
INFO - 2020-02-03 07:41:43 --> Language Class Initialized
INFO - 2020-02-03 07:41:43 --> Config Class Initialized
INFO - 2020-02-03 07:41:43 --> Loader Class Initialized
INFO - 2020-02-03 07:41:43 --> Helper loaded: url_helper
INFO - 2020-02-03 07:41:43 --> Helper loaded: file_helper
INFO - 2020-02-03 07:41:43 --> Helper loaded: form_helper
INFO - 2020-02-03 07:41:43 --> Helper loaded: my_helper
INFO - 2020-02-03 07:41:43 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:41:43 --> Controller Class Initialized
INFO - 2020-02-03 07:42:40 --> Config Class Initialized
INFO - 2020-02-03 07:42:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:42:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:42:40 --> Utf8 Class Initialized
INFO - 2020-02-03 07:42:40 --> URI Class Initialized
INFO - 2020-02-03 07:42:40 --> Router Class Initialized
INFO - 2020-02-03 07:42:40 --> Output Class Initialized
INFO - 2020-02-03 07:42:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:42:40 --> Input Class Initialized
INFO - 2020-02-03 07:42:40 --> Language Class Initialized
INFO - 2020-02-03 07:42:40 --> Language Class Initialized
INFO - 2020-02-03 07:42:40 --> Config Class Initialized
INFO - 2020-02-03 07:42:40 --> Loader Class Initialized
INFO - 2020-02-03 07:42:40 --> Helper loaded: url_helper
INFO - 2020-02-03 07:42:40 --> Helper loaded: file_helper
INFO - 2020-02-03 07:42:40 --> Helper loaded: form_helper
INFO - 2020-02-03 07:42:40 --> Helper loaded: my_helper
INFO - 2020-02-03 07:42:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:42:40 --> Controller Class Initialized
DEBUG - 2020-02-03 07:42:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:42:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:42:40 --> Final output sent to browser
DEBUG - 2020-02-03 07:42:41 --> Total execution time: 0.5997
INFO - 2020-02-03 07:42:41 --> Config Class Initialized
INFO - 2020-02-03 07:42:41 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:42:41 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:42:41 --> Utf8 Class Initialized
INFO - 2020-02-03 07:42:41 --> URI Class Initialized
INFO - 2020-02-03 07:42:41 --> Router Class Initialized
INFO - 2020-02-03 07:42:41 --> Output Class Initialized
INFO - 2020-02-03 07:42:41 --> Security Class Initialized
DEBUG - 2020-02-03 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:42:41 --> Input Class Initialized
INFO - 2020-02-03 07:42:41 --> Language Class Initialized
INFO - 2020-02-03 07:42:41 --> Language Class Initialized
INFO - 2020-02-03 07:42:41 --> Config Class Initialized
INFO - 2020-02-03 07:42:41 --> Loader Class Initialized
INFO - 2020-02-03 07:42:41 --> Helper loaded: url_helper
INFO - 2020-02-03 07:42:41 --> Helper loaded: file_helper
INFO - 2020-02-03 07:42:41 --> Helper loaded: form_helper
INFO - 2020-02-03 07:42:41 --> Helper loaded: my_helper
INFO - 2020-02-03 07:42:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:42:41 --> Controller Class Initialized
INFO - 2020-02-03 07:43:51 --> Config Class Initialized
INFO - 2020-02-03 07:43:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:43:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:43:51 --> Utf8 Class Initialized
INFO - 2020-02-03 07:43:51 --> URI Class Initialized
INFO - 2020-02-03 07:43:51 --> Router Class Initialized
INFO - 2020-02-03 07:43:51 --> Output Class Initialized
INFO - 2020-02-03 07:43:51 --> Security Class Initialized
DEBUG - 2020-02-03 07:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:43:51 --> Input Class Initialized
INFO - 2020-02-03 07:43:51 --> Language Class Initialized
INFO - 2020-02-03 07:43:51 --> Language Class Initialized
INFO - 2020-02-03 07:43:51 --> Config Class Initialized
INFO - 2020-02-03 07:43:51 --> Loader Class Initialized
INFO - 2020-02-03 07:43:51 --> Helper loaded: url_helper
INFO - 2020-02-03 07:43:51 --> Helper loaded: file_helper
INFO - 2020-02-03 07:43:51 --> Helper loaded: form_helper
INFO - 2020-02-03 07:43:51 --> Helper loaded: my_helper
INFO - 2020-02-03 07:43:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:43:51 --> Controller Class Initialized
DEBUG - 2020-02-03 07:43:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:43:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:43:51 --> Final output sent to browser
DEBUG - 2020-02-03 07:43:51 --> Total execution time: 0.5738
INFO - 2020-02-03 07:43:52 --> Config Class Initialized
INFO - 2020-02-03 07:43:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:43:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:43:52 --> Utf8 Class Initialized
INFO - 2020-02-03 07:43:52 --> URI Class Initialized
INFO - 2020-02-03 07:43:52 --> Router Class Initialized
INFO - 2020-02-03 07:43:52 --> Output Class Initialized
INFO - 2020-02-03 07:43:52 --> Security Class Initialized
DEBUG - 2020-02-03 07:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:43:52 --> Input Class Initialized
INFO - 2020-02-03 07:43:52 --> Language Class Initialized
INFO - 2020-02-03 07:43:52 --> Language Class Initialized
INFO - 2020-02-03 07:43:52 --> Config Class Initialized
INFO - 2020-02-03 07:43:52 --> Loader Class Initialized
INFO - 2020-02-03 07:43:52 --> Helper loaded: url_helper
INFO - 2020-02-03 07:43:52 --> Helper loaded: file_helper
INFO - 2020-02-03 07:43:52 --> Helper loaded: form_helper
INFO - 2020-02-03 07:43:52 --> Helper loaded: my_helper
INFO - 2020-02-03 07:43:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:43:52 --> Controller Class Initialized
INFO - 2020-02-03 07:44:02 --> Config Class Initialized
INFO - 2020-02-03 07:44:02 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:02 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:02 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:02 --> URI Class Initialized
INFO - 2020-02-03 07:44:02 --> Router Class Initialized
INFO - 2020-02-03 07:44:02 --> Output Class Initialized
INFO - 2020-02-03 07:44:02 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:02 --> Input Class Initialized
INFO - 2020-02-03 07:44:02 --> Language Class Initialized
INFO - 2020-02-03 07:44:02 --> Language Class Initialized
INFO - 2020-02-03 07:44:02 --> Config Class Initialized
INFO - 2020-02-03 07:44:02 --> Loader Class Initialized
INFO - 2020-02-03 07:44:02 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:02 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:02 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:02 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:02 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:02 --> Controller Class Initialized
DEBUG - 2020-02-03 07:44:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:44:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:44:02 --> Final output sent to browser
DEBUG - 2020-02-03 07:44:02 --> Total execution time: 0.6027
INFO - 2020-02-03 07:44:03 --> Config Class Initialized
INFO - 2020-02-03 07:44:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:03 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:03 --> URI Class Initialized
INFO - 2020-02-03 07:44:03 --> Router Class Initialized
INFO - 2020-02-03 07:44:03 --> Output Class Initialized
INFO - 2020-02-03 07:44:03 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:03 --> Input Class Initialized
INFO - 2020-02-03 07:44:03 --> Language Class Initialized
INFO - 2020-02-03 07:44:03 --> Language Class Initialized
INFO - 2020-02-03 07:44:03 --> Config Class Initialized
INFO - 2020-02-03 07:44:03 --> Loader Class Initialized
INFO - 2020-02-03 07:44:03 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:03 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:03 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:03 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:03 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:03 --> Controller Class Initialized
INFO - 2020-02-03 07:44:29 --> Config Class Initialized
INFO - 2020-02-03 07:44:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:30 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:30 --> URI Class Initialized
INFO - 2020-02-03 07:44:30 --> Router Class Initialized
INFO - 2020-02-03 07:44:30 --> Output Class Initialized
INFO - 2020-02-03 07:44:30 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:30 --> Input Class Initialized
INFO - 2020-02-03 07:44:30 --> Language Class Initialized
INFO - 2020-02-03 07:44:30 --> Language Class Initialized
INFO - 2020-02-03 07:44:30 --> Config Class Initialized
INFO - 2020-02-03 07:44:30 --> Loader Class Initialized
INFO - 2020-02-03 07:44:30 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:30 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:30 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:30 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:30 --> Controller Class Initialized
DEBUG - 2020-02-03 07:44:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:44:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:44:30 --> Final output sent to browser
DEBUG - 2020-02-03 07:44:30 --> Total execution time: 0.5795
INFO - 2020-02-03 07:44:30 --> Config Class Initialized
INFO - 2020-02-03 07:44:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:30 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:30 --> URI Class Initialized
INFO - 2020-02-03 07:44:30 --> Router Class Initialized
INFO - 2020-02-03 07:44:30 --> Output Class Initialized
INFO - 2020-02-03 07:44:30 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:31 --> Input Class Initialized
INFO - 2020-02-03 07:44:31 --> Language Class Initialized
INFO - 2020-02-03 07:44:31 --> Language Class Initialized
INFO - 2020-02-03 07:44:31 --> Config Class Initialized
INFO - 2020-02-03 07:44:31 --> Loader Class Initialized
INFO - 2020-02-03 07:44:31 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:31 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:31 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:31 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:31 --> Controller Class Initialized
INFO - 2020-02-03 07:44:39 --> Config Class Initialized
INFO - 2020-02-03 07:44:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:39 --> URI Class Initialized
INFO - 2020-02-03 07:44:39 --> Router Class Initialized
INFO - 2020-02-03 07:44:39 --> Output Class Initialized
INFO - 2020-02-03 07:44:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:39 --> Input Class Initialized
INFO - 2020-02-03 07:44:39 --> Language Class Initialized
INFO - 2020-02-03 07:44:39 --> Language Class Initialized
INFO - 2020-02-03 07:44:39 --> Config Class Initialized
INFO - 2020-02-03 07:44:39 --> Loader Class Initialized
INFO - 2020-02-03 07:44:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:39 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:39 --> Controller Class Initialized
DEBUG - 2020-02-03 07:44:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:44:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:44:39 --> Final output sent to browser
DEBUG - 2020-02-03 07:44:39 --> Total execution time: 0.6151
INFO - 2020-02-03 07:44:39 --> Config Class Initialized
INFO - 2020-02-03 07:44:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:39 --> URI Class Initialized
INFO - 2020-02-03 07:44:40 --> Router Class Initialized
INFO - 2020-02-03 07:44:40 --> Output Class Initialized
INFO - 2020-02-03 07:44:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:40 --> Input Class Initialized
INFO - 2020-02-03 07:44:40 --> Language Class Initialized
INFO - 2020-02-03 07:44:40 --> Language Class Initialized
INFO - 2020-02-03 07:44:40 --> Config Class Initialized
INFO - 2020-02-03 07:44:40 --> Loader Class Initialized
INFO - 2020-02-03 07:44:40 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:40 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:40 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:40 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:40 --> Controller Class Initialized
INFO - 2020-02-03 07:44:43 --> Config Class Initialized
INFO - 2020-02-03 07:44:43 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:43 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:43 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:43 --> URI Class Initialized
INFO - 2020-02-03 07:44:43 --> Router Class Initialized
INFO - 2020-02-03 07:44:43 --> Output Class Initialized
INFO - 2020-02-03 07:44:43 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:43 --> Input Class Initialized
INFO - 2020-02-03 07:44:43 --> Language Class Initialized
INFO - 2020-02-03 07:44:43 --> Language Class Initialized
INFO - 2020-02-03 07:44:43 --> Config Class Initialized
INFO - 2020-02-03 07:44:43 --> Loader Class Initialized
INFO - 2020-02-03 07:44:43 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:43 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:43 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:43 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:43 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:43 --> Controller Class Initialized
DEBUG - 2020-02-03 07:44:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:44:43 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:44:43 --> Final output sent to browser
DEBUG - 2020-02-03 07:44:43 --> Total execution time: 0.7106
INFO - 2020-02-03 07:44:44 --> Config Class Initialized
INFO - 2020-02-03 07:44:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:44 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:44 --> URI Class Initialized
INFO - 2020-02-03 07:44:44 --> Router Class Initialized
INFO - 2020-02-03 07:44:44 --> Output Class Initialized
INFO - 2020-02-03 07:44:44 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:44 --> Input Class Initialized
INFO - 2020-02-03 07:44:44 --> Language Class Initialized
INFO - 2020-02-03 07:44:44 --> Language Class Initialized
INFO - 2020-02-03 07:44:44 --> Config Class Initialized
INFO - 2020-02-03 07:44:44 --> Loader Class Initialized
INFO - 2020-02-03 07:44:44 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:44 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:44 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:44 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:44 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:44 --> Controller Class Initialized
INFO - 2020-02-03 07:44:48 --> Config Class Initialized
INFO - 2020-02-03 07:44:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:48 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:48 --> URI Class Initialized
INFO - 2020-02-03 07:44:48 --> Router Class Initialized
INFO - 2020-02-03 07:44:48 --> Output Class Initialized
INFO - 2020-02-03 07:44:48 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:48 --> Input Class Initialized
INFO - 2020-02-03 07:44:48 --> Language Class Initialized
INFO - 2020-02-03 07:44:48 --> Language Class Initialized
INFO - 2020-02-03 07:44:48 --> Config Class Initialized
INFO - 2020-02-03 07:44:48 --> Loader Class Initialized
INFO - 2020-02-03 07:44:48 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:48 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:48 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:48 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:48 --> Controller Class Initialized
DEBUG - 2020-02-03 07:44:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:44:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:44:48 --> Final output sent to browser
DEBUG - 2020-02-03 07:44:48 --> Total execution time: 0.5944
INFO - 2020-02-03 07:44:48 --> Config Class Initialized
INFO - 2020-02-03 07:44:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:44:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:44:49 --> Utf8 Class Initialized
INFO - 2020-02-03 07:44:49 --> URI Class Initialized
INFO - 2020-02-03 07:44:49 --> Router Class Initialized
INFO - 2020-02-03 07:44:49 --> Output Class Initialized
INFO - 2020-02-03 07:44:49 --> Security Class Initialized
DEBUG - 2020-02-03 07:44:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:44:49 --> Input Class Initialized
INFO - 2020-02-03 07:44:49 --> Language Class Initialized
INFO - 2020-02-03 07:44:49 --> Language Class Initialized
INFO - 2020-02-03 07:44:49 --> Config Class Initialized
INFO - 2020-02-03 07:44:49 --> Loader Class Initialized
INFO - 2020-02-03 07:44:49 --> Helper loaded: url_helper
INFO - 2020-02-03 07:44:49 --> Helper loaded: file_helper
INFO - 2020-02-03 07:44:49 --> Helper loaded: form_helper
INFO - 2020-02-03 07:44:49 --> Helper loaded: my_helper
INFO - 2020-02-03 07:44:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:44:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:44:49 --> Controller Class Initialized
INFO - 2020-02-03 07:45:26 --> Config Class Initialized
INFO - 2020-02-03 07:45:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:45:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:45:27 --> Utf8 Class Initialized
INFO - 2020-02-03 07:45:27 --> URI Class Initialized
INFO - 2020-02-03 07:45:27 --> Router Class Initialized
INFO - 2020-02-03 07:45:27 --> Output Class Initialized
INFO - 2020-02-03 07:45:27 --> Security Class Initialized
DEBUG - 2020-02-03 07:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:45:27 --> Input Class Initialized
INFO - 2020-02-03 07:45:27 --> Language Class Initialized
INFO - 2020-02-03 07:45:27 --> Language Class Initialized
INFO - 2020-02-03 07:45:27 --> Config Class Initialized
INFO - 2020-02-03 07:45:27 --> Loader Class Initialized
INFO - 2020-02-03 07:45:27 --> Helper loaded: url_helper
INFO - 2020-02-03 07:45:27 --> Helper loaded: file_helper
INFO - 2020-02-03 07:45:27 --> Helper loaded: form_helper
INFO - 2020-02-03 07:45:27 --> Helper loaded: my_helper
INFO - 2020-02-03 07:45:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:45:27 --> Controller Class Initialized
DEBUG - 2020-02-03 07:45:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:45:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:45:27 --> Final output sent to browser
DEBUG - 2020-02-03 07:45:27 --> Total execution time: 0.6591
INFO - 2020-02-03 07:45:27 --> Config Class Initialized
INFO - 2020-02-03 07:45:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:45:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:45:28 --> Utf8 Class Initialized
INFO - 2020-02-03 07:45:28 --> URI Class Initialized
INFO - 2020-02-03 07:45:28 --> Router Class Initialized
INFO - 2020-02-03 07:45:28 --> Output Class Initialized
INFO - 2020-02-03 07:45:28 --> Security Class Initialized
DEBUG - 2020-02-03 07:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:45:28 --> Input Class Initialized
INFO - 2020-02-03 07:45:28 --> Language Class Initialized
INFO - 2020-02-03 07:45:28 --> Language Class Initialized
INFO - 2020-02-03 07:45:28 --> Config Class Initialized
INFO - 2020-02-03 07:45:28 --> Loader Class Initialized
INFO - 2020-02-03 07:45:28 --> Helper loaded: url_helper
INFO - 2020-02-03 07:45:28 --> Helper loaded: file_helper
INFO - 2020-02-03 07:45:28 --> Helper loaded: form_helper
INFO - 2020-02-03 07:45:28 --> Helper loaded: my_helper
INFO - 2020-02-03 07:45:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:45:28 --> Controller Class Initialized
INFO - 2020-02-03 07:45:29 --> Config Class Initialized
INFO - 2020-02-03 07:45:29 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:45:29 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:45:29 --> Utf8 Class Initialized
INFO - 2020-02-03 07:45:29 --> URI Class Initialized
INFO - 2020-02-03 07:45:29 --> Router Class Initialized
INFO - 2020-02-03 07:45:29 --> Output Class Initialized
INFO - 2020-02-03 07:45:29 --> Security Class Initialized
DEBUG - 2020-02-03 07:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:45:29 --> Input Class Initialized
INFO - 2020-02-03 07:45:29 --> Language Class Initialized
INFO - 2020-02-03 07:45:29 --> Language Class Initialized
INFO - 2020-02-03 07:45:29 --> Config Class Initialized
INFO - 2020-02-03 07:45:29 --> Loader Class Initialized
INFO - 2020-02-03 07:45:29 --> Helper loaded: url_helper
INFO - 2020-02-03 07:45:29 --> Helper loaded: file_helper
INFO - 2020-02-03 07:45:29 --> Helper loaded: form_helper
INFO - 2020-02-03 07:45:29 --> Helper loaded: my_helper
INFO - 2020-02-03 07:45:29 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:45:29 --> Controller Class Initialized
INFO - 2020-02-03 07:45:29 --> Database Utility Class Initialized
INFO - 2020-02-03 07:45:29 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:45:30 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:45:30 --> Helper loaded: download_helper
INFO - 2020-02-03 07:46:12 --> Config Class Initialized
INFO - 2020-02-03 07:46:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:12 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:12 --> URI Class Initialized
INFO - 2020-02-03 07:46:12 --> Router Class Initialized
INFO - 2020-02-03 07:46:12 --> Output Class Initialized
INFO - 2020-02-03 07:46:12 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:12 --> Input Class Initialized
INFO - 2020-02-03 07:46:12 --> Language Class Initialized
INFO - 2020-02-03 07:46:12 --> Language Class Initialized
INFO - 2020-02-03 07:46:12 --> Config Class Initialized
INFO - 2020-02-03 07:46:12 --> Loader Class Initialized
INFO - 2020-02-03 07:46:12 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:13 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:13 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:13 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:13 --> Controller Class Initialized
DEBUG - 2020-02-03 07:46:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:46:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:46:13 --> Final output sent to browser
DEBUG - 2020-02-03 07:46:13 --> Total execution time: 0.6837
INFO - 2020-02-03 07:46:13 --> Config Class Initialized
INFO - 2020-02-03 07:46:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:13 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:13 --> URI Class Initialized
INFO - 2020-02-03 07:46:13 --> Router Class Initialized
INFO - 2020-02-03 07:46:13 --> Output Class Initialized
INFO - 2020-02-03 07:46:13 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:13 --> Input Class Initialized
INFO - 2020-02-03 07:46:13 --> Language Class Initialized
INFO - 2020-02-03 07:46:13 --> Language Class Initialized
INFO - 2020-02-03 07:46:13 --> Config Class Initialized
INFO - 2020-02-03 07:46:13 --> Loader Class Initialized
INFO - 2020-02-03 07:46:13 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:13 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:14 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:14 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:14 --> Controller Class Initialized
INFO - 2020-02-03 07:46:15 --> Config Class Initialized
INFO - 2020-02-03 07:46:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:15 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:15 --> URI Class Initialized
INFO - 2020-02-03 07:46:15 --> Router Class Initialized
INFO - 2020-02-03 07:46:15 --> Output Class Initialized
INFO - 2020-02-03 07:46:15 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:15 --> Input Class Initialized
INFO - 2020-02-03 07:46:15 --> Language Class Initialized
INFO - 2020-02-03 07:46:15 --> Language Class Initialized
INFO - 2020-02-03 07:46:15 --> Config Class Initialized
INFO - 2020-02-03 07:46:15 --> Loader Class Initialized
INFO - 2020-02-03 07:46:15 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:15 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:15 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:15 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:15 --> Controller Class Initialized
INFO - 2020-02-03 07:46:15 --> Database Utility Class Initialized
INFO - 2020-02-03 07:46:15 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:46:16 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:46:16 --> Config Class Initialized
INFO - 2020-02-03 07:46:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:16 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:16 --> URI Class Initialized
INFO - 2020-02-03 07:46:16 --> Router Class Initialized
INFO - 2020-02-03 07:46:16 --> Output Class Initialized
INFO - 2020-02-03 07:46:16 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:16 --> Input Class Initialized
INFO - 2020-02-03 07:46:16 --> Language Class Initialized
INFO - 2020-02-03 07:46:16 --> Language Class Initialized
INFO - 2020-02-03 07:46:16 --> Config Class Initialized
INFO - 2020-02-03 07:46:16 --> Loader Class Initialized
INFO - 2020-02-03 07:46:16 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:16 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:16 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:16 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:16 --> Controller Class Initialized
DEBUG - 2020-02-03 07:46:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:46:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:46:16 --> Final output sent to browser
DEBUG - 2020-02-03 07:46:16 --> Total execution time: 0.5190
INFO - 2020-02-03 07:46:16 --> Config Class Initialized
INFO - 2020-02-03 07:46:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:17 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:17 --> URI Class Initialized
INFO - 2020-02-03 07:46:17 --> Router Class Initialized
INFO - 2020-02-03 07:46:17 --> Output Class Initialized
INFO - 2020-02-03 07:46:17 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:17 --> Input Class Initialized
INFO - 2020-02-03 07:46:17 --> Language Class Initialized
INFO - 2020-02-03 07:46:17 --> Language Class Initialized
INFO - 2020-02-03 07:46:17 --> Config Class Initialized
INFO - 2020-02-03 07:46:17 --> Loader Class Initialized
INFO - 2020-02-03 07:46:17 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:17 --> Controller Class Initialized
INFO - 2020-02-03 07:46:41 --> Config Class Initialized
INFO - 2020-02-03 07:46:41 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:41 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:41 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:41 --> URI Class Initialized
INFO - 2020-02-03 07:46:41 --> Router Class Initialized
INFO - 2020-02-03 07:46:41 --> Output Class Initialized
INFO - 2020-02-03 07:46:41 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:41 --> Input Class Initialized
INFO - 2020-02-03 07:46:41 --> Language Class Initialized
INFO - 2020-02-03 07:46:41 --> Language Class Initialized
INFO - 2020-02-03 07:46:41 --> Config Class Initialized
INFO - 2020-02-03 07:46:41 --> Loader Class Initialized
INFO - 2020-02-03 07:46:41 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:41 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:41 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:41 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:41 --> Controller Class Initialized
DEBUG - 2020-02-03 07:46:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:46:42 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:46:42 --> Final output sent to browser
DEBUG - 2020-02-03 07:46:42 --> Total execution time: 0.6234
INFO - 2020-02-03 07:46:42 --> Config Class Initialized
INFO - 2020-02-03 07:46:42 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:46:42 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:46:42 --> Utf8 Class Initialized
INFO - 2020-02-03 07:46:42 --> URI Class Initialized
INFO - 2020-02-03 07:46:42 --> Router Class Initialized
INFO - 2020-02-03 07:46:42 --> Output Class Initialized
INFO - 2020-02-03 07:46:42 --> Security Class Initialized
DEBUG - 2020-02-03 07:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:46:42 --> Input Class Initialized
INFO - 2020-02-03 07:46:42 --> Language Class Initialized
INFO - 2020-02-03 07:46:42 --> Language Class Initialized
INFO - 2020-02-03 07:46:42 --> Config Class Initialized
INFO - 2020-02-03 07:46:42 --> Loader Class Initialized
INFO - 2020-02-03 07:46:42 --> Helper loaded: url_helper
INFO - 2020-02-03 07:46:42 --> Helper loaded: file_helper
INFO - 2020-02-03 07:46:42 --> Helper loaded: form_helper
INFO - 2020-02-03 07:46:42 --> Helper loaded: my_helper
INFO - 2020-02-03 07:46:42 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:46:42 --> Controller Class Initialized
INFO - 2020-02-03 07:47:36 --> Config Class Initialized
INFO - 2020-02-03 07:47:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:47:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:47:37 --> Utf8 Class Initialized
INFO - 2020-02-03 07:47:37 --> URI Class Initialized
INFO - 2020-02-03 07:47:37 --> Router Class Initialized
INFO - 2020-02-03 07:47:37 --> Output Class Initialized
INFO - 2020-02-03 07:47:37 --> Security Class Initialized
DEBUG - 2020-02-03 07:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:47:37 --> Input Class Initialized
INFO - 2020-02-03 07:47:37 --> Language Class Initialized
INFO - 2020-02-03 07:47:37 --> Language Class Initialized
INFO - 2020-02-03 07:47:37 --> Config Class Initialized
INFO - 2020-02-03 07:47:37 --> Loader Class Initialized
INFO - 2020-02-03 07:47:37 --> Helper loaded: url_helper
INFO - 2020-02-03 07:47:37 --> Helper loaded: file_helper
INFO - 2020-02-03 07:47:37 --> Helper loaded: form_helper
INFO - 2020-02-03 07:47:37 --> Helper loaded: my_helper
INFO - 2020-02-03 07:47:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:47:37 --> Controller Class Initialized
DEBUG - 2020-02-03 07:47:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:47:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:47:37 --> Final output sent to browser
DEBUG - 2020-02-03 07:47:37 --> Total execution time: 0.7096
INFO - 2020-02-03 07:47:37 --> Config Class Initialized
INFO - 2020-02-03 07:47:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:47:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:47:38 --> Utf8 Class Initialized
INFO - 2020-02-03 07:47:38 --> URI Class Initialized
INFO - 2020-02-03 07:47:38 --> Router Class Initialized
INFO - 2020-02-03 07:47:38 --> Output Class Initialized
INFO - 2020-02-03 07:47:38 --> Security Class Initialized
DEBUG - 2020-02-03 07:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:47:38 --> Input Class Initialized
INFO - 2020-02-03 07:47:38 --> Language Class Initialized
INFO - 2020-02-03 07:47:38 --> Language Class Initialized
INFO - 2020-02-03 07:47:38 --> Config Class Initialized
INFO - 2020-02-03 07:47:38 --> Loader Class Initialized
INFO - 2020-02-03 07:47:38 --> Helper loaded: url_helper
INFO - 2020-02-03 07:47:38 --> Helper loaded: file_helper
INFO - 2020-02-03 07:47:38 --> Helper loaded: form_helper
INFO - 2020-02-03 07:47:38 --> Helper loaded: my_helper
INFO - 2020-02-03 07:47:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:47:38 --> Controller Class Initialized
INFO - 2020-02-03 07:47:39 --> Config Class Initialized
INFO - 2020-02-03 07:47:39 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:47:39 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:47:39 --> Utf8 Class Initialized
INFO - 2020-02-03 07:47:39 --> URI Class Initialized
INFO - 2020-02-03 07:47:39 --> Router Class Initialized
INFO - 2020-02-03 07:47:39 --> Output Class Initialized
INFO - 2020-02-03 07:47:39 --> Security Class Initialized
DEBUG - 2020-02-03 07:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:47:39 --> Input Class Initialized
INFO - 2020-02-03 07:47:39 --> Language Class Initialized
INFO - 2020-02-03 07:47:39 --> Language Class Initialized
INFO - 2020-02-03 07:47:39 --> Config Class Initialized
INFO - 2020-02-03 07:47:39 --> Loader Class Initialized
INFO - 2020-02-03 07:47:39 --> Helper loaded: url_helper
INFO - 2020-02-03 07:47:39 --> Helper loaded: file_helper
INFO - 2020-02-03 07:47:39 --> Helper loaded: form_helper
INFO - 2020-02-03 07:47:39 --> Helper loaded: my_helper
INFO - 2020-02-03 07:47:39 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:47:39 --> Controller Class Initialized
INFO - 2020-02-03 07:47:39 --> Database Utility Class Initialized
INFO - 2020-02-03 07:47:39 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:47:39 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:47:40 --> Config Class Initialized
INFO - 2020-02-03 07:47:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:47:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:47:40 --> Utf8 Class Initialized
INFO - 2020-02-03 07:47:40 --> URI Class Initialized
INFO - 2020-02-03 07:47:40 --> Router Class Initialized
INFO - 2020-02-03 07:47:40 --> Output Class Initialized
INFO - 2020-02-03 07:47:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:47:40 --> Input Class Initialized
INFO - 2020-02-03 07:47:40 --> Language Class Initialized
INFO - 2020-02-03 07:47:40 --> Language Class Initialized
INFO - 2020-02-03 07:47:40 --> Config Class Initialized
INFO - 2020-02-03 07:47:40 --> Loader Class Initialized
INFO - 2020-02-03 07:47:40 --> Helper loaded: url_helper
INFO - 2020-02-03 07:47:40 --> Helper loaded: file_helper
INFO - 2020-02-03 07:47:40 --> Helper loaded: form_helper
INFO - 2020-02-03 07:47:40 --> Helper loaded: my_helper
INFO - 2020-02-03 07:47:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:47:40 --> Controller Class Initialized
DEBUG - 2020-02-03 07:47:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:47:40 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:47:40 --> Final output sent to browser
DEBUG - 2020-02-03 07:47:40 --> Total execution time: 0.5100
INFO - 2020-02-03 07:47:40 --> Config Class Initialized
INFO - 2020-02-03 07:47:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:47:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:47:40 --> Utf8 Class Initialized
INFO - 2020-02-03 07:47:40 --> URI Class Initialized
INFO - 2020-02-03 07:47:40 --> Router Class Initialized
INFO - 2020-02-03 07:47:40 --> Output Class Initialized
INFO - 2020-02-03 07:47:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:47:40 --> Input Class Initialized
INFO - 2020-02-03 07:47:40 --> Language Class Initialized
INFO - 2020-02-03 07:47:40 --> Language Class Initialized
INFO - 2020-02-03 07:47:41 --> Config Class Initialized
INFO - 2020-02-03 07:47:41 --> Loader Class Initialized
INFO - 2020-02-03 07:47:41 --> Helper loaded: url_helper
INFO - 2020-02-03 07:47:41 --> Helper loaded: file_helper
INFO - 2020-02-03 07:47:41 --> Helper loaded: form_helper
INFO - 2020-02-03 07:47:41 --> Helper loaded: my_helper
INFO - 2020-02-03 07:47:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:47:41 --> Controller Class Initialized
INFO - 2020-02-03 07:49:32 --> Config Class Initialized
INFO - 2020-02-03 07:49:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:49:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:49:33 --> Utf8 Class Initialized
INFO - 2020-02-03 07:49:33 --> URI Class Initialized
INFO - 2020-02-03 07:49:33 --> Router Class Initialized
INFO - 2020-02-03 07:49:33 --> Output Class Initialized
INFO - 2020-02-03 07:49:33 --> Security Class Initialized
DEBUG - 2020-02-03 07:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:49:33 --> Input Class Initialized
INFO - 2020-02-03 07:49:33 --> Language Class Initialized
INFO - 2020-02-03 07:49:33 --> Language Class Initialized
INFO - 2020-02-03 07:49:33 --> Config Class Initialized
INFO - 2020-02-03 07:49:33 --> Loader Class Initialized
INFO - 2020-02-03 07:49:33 --> Helper loaded: url_helper
INFO - 2020-02-03 07:49:33 --> Helper loaded: file_helper
INFO - 2020-02-03 07:49:33 --> Helper loaded: form_helper
INFO - 2020-02-03 07:49:33 --> Helper loaded: my_helper
INFO - 2020-02-03 07:49:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:49:33 --> Controller Class Initialized
ERROR - 2020-02-03 07:49:33 --> Severity: Notice --> Undefined variable: d E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\views\list.php 37
DEBUG - 2020-02-03 07:49:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:49:33 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:49:33 --> Final output sent to browser
DEBUG - 2020-02-03 07:49:33 --> Total execution time: 0.6533
INFO - 2020-02-03 07:49:33 --> Config Class Initialized
INFO - 2020-02-03 07:49:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:49:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:49:33 --> Utf8 Class Initialized
INFO - 2020-02-03 07:49:34 --> URI Class Initialized
INFO - 2020-02-03 07:49:34 --> Router Class Initialized
INFO - 2020-02-03 07:49:34 --> Output Class Initialized
INFO - 2020-02-03 07:49:34 --> Security Class Initialized
DEBUG - 2020-02-03 07:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:49:34 --> Input Class Initialized
INFO - 2020-02-03 07:49:34 --> Language Class Initialized
INFO - 2020-02-03 07:49:34 --> Language Class Initialized
INFO - 2020-02-03 07:49:34 --> Config Class Initialized
INFO - 2020-02-03 07:49:34 --> Loader Class Initialized
INFO - 2020-02-03 07:49:34 --> Helper loaded: url_helper
INFO - 2020-02-03 07:49:34 --> Helper loaded: file_helper
INFO - 2020-02-03 07:49:34 --> Helper loaded: form_helper
INFO - 2020-02-03 07:49:34 --> Helper loaded: my_helper
INFO - 2020-02-03 07:49:34 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:49:34 --> Controller Class Initialized
INFO - 2020-02-03 07:53:16 --> Config Class Initialized
INFO - 2020-02-03 07:53:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:53:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:53:16 --> Utf8 Class Initialized
INFO - 2020-02-03 07:53:16 --> URI Class Initialized
INFO - 2020-02-03 07:53:16 --> Router Class Initialized
INFO - 2020-02-03 07:53:16 --> Output Class Initialized
INFO - 2020-02-03 07:53:16 --> Security Class Initialized
DEBUG - 2020-02-03 07:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:53:16 --> Input Class Initialized
INFO - 2020-02-03 07:53:16 --> Language Class Initialized
INFO - 2020-02-03 07:53:16 --> Language Class Initialized
INFO - 2020-02-03 07:53:16 --> Config Class Initialized
INFO - 2020-02-03 07:53:16 --> Loader Class Initialized
INFO - 2020-02-03 07:53:16 --> Helper loaded: url_helper
INFO - 2020-02-03 07:53:16 --> Helper loaded: file_helper
INFO - 2020-02-03 07:53:16 --> Helper loaded: form_helper
INFO - 2020-02-03 07:53:16 --> Helper loaded: my_helper
INFO - 2020-02-03 07:53:16 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:53:16 --> Controller Class Initialized
DEBUG - 2020-02-03 07:53:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:53:16 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:53:16 --> Final output sent to browser
DEBUG - 2020-02-03 07:53:16 --> Total execution time: 0.7315
INFO - 2020-02-03 07:53:17 --> Config Class Initialized
INFO - 2020-02-03 07:53:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:53:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:53:17 --> Utf8 Class Initialized
INFO - 2020-02-03 07:53:17 --> URI Class Initialized
INFO - 2020-02-03 07:53:17 --> Router Class Initialized
INFO - 2020-02-03 07:53:17 --> Output Class Initialized
INFO - 2020-02-03 07:53:17 --> Security Class Initialized
DEBUG - 2020-02-03 07:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:53:17 --> Input Class Initialized
INFO - 2020-02-03 07:53:17 --> Language Class Initialized
INFO - 2020-02-03 07:53:17 --> Language Class Initialized
INFO - 2020-02-03 07:53:17 --> Config Class Initialized
INFO - 2020-02-03 07:53:17 --> Loader Class Initialized
INFO - 2020-02-03 07:53:17 --> Helper loaded: url_helper
INFO - 2020-02-03 07:53:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:53:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:53:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:53:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:53:17 --> Controller Class Initialized
INFO - 2020-02-03 07:53:19 --> Config Class Initialized
INFO - 2020-02-03 07:53:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:53:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:53:19 --> Utf8 Class Initialized
INFO - 2020-02-03 07:53:19 --> URI Class Initialized
INFO - 2020-02-03 07:53:19 --> Router Class Initialized
INFO - 2020-02-03 07:53:19 --> Output Class Initialized
INFO - 2020-02-03 07:53:19 --> Security Class Initialized
DEBUG - 2020-02-03 07:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:53:19 --> Input Class Initialized
INFO - 2020-02-03 07:53:19 --> Language Class Initialized
INFO - 2020-02-03 07:53:19 --> Language Class Initialized
INFO - 2020-02-03 07:53:19 --> Config Class Initialized
INFO - 2020-02-03 07:53:19 --> Loader Class Initialized
INFO - 2020-02-03 07:53:19 --> Helper loaded: url_helper
INFO - 2020-02-03 07:53:19 --> Helper loaded: file_helper
INFO - 2020-02-03 07:53:19 --> Helper loaded: form_helper
INFO - 2020-02-03 07:53:19 --> Helper loaded: my_helper
INFO - 2020-02-03 07:53:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:53:19 --> Controller Class Initialized
INFO - 2020-02-03 07:53:19 --> Database Utility Class Initialized
INFO - 2020-02-03 07:53:19 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:53:19 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:53:19 --> Config Class Initialized
INFO - 2020-02-03 07:53:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:53:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:53:20 --> Utf8 Class Initialized
INFO - 2020-02-03 07:53:20 --> URI Class Initialized
INFO - 2020-02-03 07:53:20 --> Router Class Initialized
INFO - 2020-02-03 07:53:20 --> Output Class Initialized
INFO - 2020-02-03 07:53:20 --> Security Class Initialized
DEBUG - 2020-02-03 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:53:20 --> Input Class Initialized
INFO - 2020-02-03 07:53:20 --> Language Class Initialized
INFO - 2020-02-03 07:53:20 --> Language Class Initialized
INFO - 2020-02-03 07:53:20 --> Config Class Initialized
INFO - 2020-02-03 07:53:20 --> Loader Class Initialized
INFO - 2020-02-03 07:53:20 --> Helper loaded: url_helper
INFO - 2020-02-03 07:53:20 --> Helper loaded: file_helper
INFO - 2020-02-03 07:53:20 --> Helper loaded: form_helper
INFO - 2020-02-03 07:53:20 --> Helper loaded: my_helper
INFO - 2020-02-03 07:53:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:53:20 --> Controller Class Initialized
DEBUG - 2020-02-03 07:53:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:53:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:53:20 --> Final output sent to browser
DEBUG - 2020-02-03 07:53:20 --> Total execution time: 0.5589
INFO - 2020-02-03 07:53:20 --> Config Class Initialized
INFO - 2020-02-03 07:53:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:53:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:53:20 --> Utf8 Class Initialized
INFO - 2020-02-03 07:53:20 --> URI Class Initialized
INFO - 2020-02-03 07:53:20 --> Router Class Initialized
INFO - 2020-02-03 07:53:20 --> Output Class Initialized
INFO - 2020-02-03 07:53:20 --> Security Class Initialized
DEBUG - 2020-02-03 07:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:53:21 --> Input Class Initialized
INFO - 2020-02-03 07:53:21 --> Language Class Initialized
INFO - 2020-02-03 07:53:21 --> Language Class Initialized
INFO - 2020-02-03 07:53:21 --> Config Class Initialized
INFO - 2020-02-03 07:53:21 --> Loader Class Initialized
INFO - 2020-02-03 07:53:21 --> Helper loaded: url_helper
INFO - 2020-02-03 07:53:21 --> Helper loaded: file_helper
INFO - 2020-02-03 07:53:21 --> Helper loaded: form_helper
INFO - 2020-02-03 07:53:21 --> Helper loaded: my_helper
INFO - 2020-02-03 07:53:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:53:21 --> Controller Class Initialized
INFO - 2020-02-03 07:54:16 --> Config Class Initialized
INFO - 2020-02-03 07:54:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:16 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:16 --> URI Class Initialized
INFO - 2020-02-03 07:54:16 --> Router Class Initialized
INFO - 2020-02-03 07:54:16 --> Output Class Initialized
INFO - 2020-02-03 07:54:17 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:17 --> Input Class Initialized
INFO - 2020-02-03 07:54:17 --> Language Class Initialized
INFO - 2020-02-03 07:54:17 --> Language Class Initialized
INFO - 2020-02-03 07:54:17 --> Config Class Initialized
INFO - 2020-02-03 07:54:17 --> Loader Class Initialized
INFO - 2020-02-03 07:54:17 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:17 --> Controller Class Initialized
DEBUG - 2020-02-03 07:54:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:54:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:54:17 --> Final output sent to browser
DEBUG - 2020-02-03 07:54:17 --> Total execution time: 0.7798
INFO - 2020-02-03 07:54:17 --> Config Class Initialized
INFO - 2020-02-03 07:54:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:17 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:17 --> URI Class Initialized
INFO - 2020-02-03 07:54:18 --> Router Class Initialized
INFO - 2020-02-03 07:54:18 --> Output Class Initialized
INFO - 2020-02-03 07:54:18 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:18 --> Input Class Initialized
INFO - 2020-02-03 07:54:18 --> Language Class Initialized
INFO - 2020-02-03 07:54:18 --> Language Class Initialized
INFO - 2020-02-03 07:54:18 --> Config Class Initialized
INFO - 2020-02-03 07:54:18 --> Loader Class Initialized
INFO - 2020-02-03 07:54:18 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:18 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:18 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:18 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:18 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:18 --> Controller Class Initialized
INFO - 2020-02-03 07:54:19 --> Config Class Initialized
INFO - 2020-02-03 07:54:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:19 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:19 --> URI Class Initialized
INFO - 2020-02-03 07:54:19 --> Router Class Initialized
INFO - 2020-02-03 07:54:19 --> Output Class Initialized
INFO - 2020-02-03 07:54:19 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:19 --> Input Class Initialized
INFO - 2020-02-03 07:54:19 --> Language Class Initialized
INFO - 2020-02-03 07:54:19 --> Language Class Initialized
INFO - 2020-02-03 07:54:19 --> Config Class Initialized
INFO - 2020-02-03 07:54:19 --> Loader Class Initialized
INFO - 2020-02-03 07:54:19 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:19 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:19 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:19 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:19 --> Controller Class Initialized
INFO - 2020-02-03 07:54:19 --> Database Utility Class Initialized
INFO - 2020-02-03 07:54:19 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:54:20 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:54:20 --> Config Class Initialized
INFO - 2020-02-03 07:54:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:20 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:20 --> URI Class Initialized
INFO - 2020-02-03 07:54:20 --> Router Class Initialized
INFO - 2020-02-03 07:54:20 --> Output Class Initialized
INFO - 2020-02-03 07:54:20 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:20 --> Input Class Initialized
INFO - 2020-02-03 07:54:20 --> Language Class Initialized
INFO - 2020-02-03 07:54:20 --> Language Class Initialized
INFO - 2020-02-03 07:54:20 --> Config Class Initialized
INFO - 2020-02-03 07:54:20 --> Loader Class Initialized
INFO - 2020-02-03 07:54:20 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:20 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:20 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:20 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:20 --> Controller Class Initialized
DEBUG - 2020-02-03 07:54:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:54:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:54:20 --> Final output sent to browser
DEBUG - 2020-02-03 07:54:20 --> Total execution time: 0.5603
INFO - 2020-02-03 07:54:20 --> Config Class Initialized
INFO - 2020-02-03 07:54:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:20 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:21 --> URI Class Initialized
INFO - 2020-02-03 07:54:21 --> Router Class Initialized
INFO - 2020-02-03 07:54:21 --> Output Class Initialized
INFO - 2020-02-03 07:54:21 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:21 --> Input Class Initialized
INFO - 2020-02-03 07:54:21 --> Language Class Initialized
INFO - 2020-02-03 07:54:21 --> Language Class Initialized
INFO - 2020-02-03 07:54:21 --> Config Class Initialized
INFO - 2020-02-03 07:54:21 --> Loader Class Initialized
INFO - 2020-02-03 07:54:21 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:21 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:21 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:21 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:21 --> Controller Class Initialized
INFO - 2020-02-03 07:54:32 --> Config Class Initialized
INFO - 2020-02-03 07:54:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:32 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:32 --> URI Class Initialized
INFO - 2020-02-03 07:54:32 --> Router Class Initialized
INFO - 2020-02-03 07:54:32 --> Output Class Initialized
INFO - 2020-02-03 07:54:32 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:32 --> Input Class Initialized
INFO - 2020-02-03 07:54:32 --> Language Class Initialized
INFO - 2020-02-03 07:54:32 --> Language Class Initialized
INFO - 2020-02-03 07:54:32 --> Config Class Initialized
INFO - 2020-02-03 07:54:32 --> Loader Class Initialized
INFO - 2020-02-03 07:54:32 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:32 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:32 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:32 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:32 --> Controller Class Initialized
DEBUG - 2020-02-03 07:54:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:54:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:54:32 --> Final output sent to browser
DEBUG - 2020-02-03 07:54:33 --> Total execution time: 0.6563
INFO - 2020-02-03 07:54:33 --> Config Class Initialized
INFO - 2020-02-03 07:54:33 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:54:33 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:54:33 --> Utf8 Class Initialized
INFO - 2020-02-03 07:54:33 --> URI Class Initialized
INFO - 2020-02-03 07:54:33 --> Router Class Initialized
INFO - 2020-02-03 07:54:33 --> Output Class Initialized
INFO - 2020-02-03 07:54:33 --> Security Class Initialized
DEBUG - 2020-02-03 07:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:54:33 --> Input Class Initialized
INFO - 2020-02-03 07:54:33 --> Language Class Initialized
INFO - 2020-02-03 07:54:33 --> Language Class Initialized
INFO - 2020-02-03 07:54:33 --> Config Class Initialized
INFO - 2020-02-03 07:54:33 --> Loader Class Initialized
INFO - 2020-02-03 07:54:33 --> Helper loaded: url_helper
INFO - 2020-02-03 07:54:33 --> Helper loaded: file_helper
INFO - 2020-02-03 07:54:33 --> Helper loaded: form_helper
INFO - 2020-02-03 07:54:33 --> Helper loaded: my_helper
INFO - 2020-02-03 07:54:33 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:54:33 --> Controller Class Initialized
INFO - 2020-02-03 07:56:14 --> Config Class Initialized
INFO - 2020-02-03 07:56:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:56:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:56:14 --> Utf8 Class Initialized
INFO - 2020-02-03 07:56:14 --> URI Class Initialized
INFO - 2020-02-03 07:56:14 --> Router Class Initialized
INFO - 2020-02-03 07:56:14 --> Output Class Initialized
INFO - 2020-02-03 07:56:14 --> Security Class Initialized
DEBUG - 2020-02-03 07:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:56:14 --> Input Class Initialized
INFO - 2020-02-03 07:56:14 --> Language Class Initialized
INFO - 2020-02-03 07:56:14 --> Language Class Initialized
INFO - 2020-02-03 07:56:14 --> Config Class Initialized
INFO - 2020-02-03 07:56:14 --> Loader Class Initialized
INFO - 2020-02-03 07:56:14 --> Helper loaded: url_helper
INFO - 2020-02-03 07:56:14 --> Helper loaded: file_helper
INFO - 2020-02-03 07:56:14 --> Helper loaded: form_helper
INFO - 2020-02-03 07:56:14 --> Helper loaded: my_helper
INFO - 2020-02-03 07:56:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:56:15 --> Controller Class Initialized
DEBUG - 2020-02-03 07:56:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:56:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:56:15 --> Final output sent to browser
DEBUG - 2020-02-03 07:56:15 --> Total execution time: 0.7142
INFO - 2020-02-03 07:56:15 --> Config Class Initialized
INFO - 2020-02-03 07:56:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:56:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:56:15 --> Utf8 Class Initialized
INFO - 2020-02-03 07:56:15 --> URI Class Initialized
INFO - 2020-02-03 07:56:15 --> Router Class Initialized
INFO - 2020-02-03 07:56:15 --> Output Class Initialized
INFO - 2020-02-03 07:56:15 --> Security Class Initialized
DEBUG - 2020-02-03 07:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:56:15 --> Input Class Initialized
INFO - 2020-02-03 07:56:15 --> Language Class Initialized
INFO - 2020-02-03 07:56:15 --> Language Class Initialized
INFO - 2020-02-03 07:56:15 --> Config Class Initialized
INFO - 2020-02-03 07:56:15 --> Loader Class Initialized
INFO - 2020-02-03 07:56:15 --> Helper loaded: url_helper
INFO - 2020-02-03 07:56:15 --> Helper loaded: file_helper
INFO - 2020-02-03 07:56:15 --> Helper loaded: form_helper
INFO - 2020-02-03 07:56:15 --> Helper loaded: my_helper
INFO - 2020-02-03 07:56:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:56:16 --> Controller Class Initialized
INFO - 2020-02-03 07:56:16 --> Config Class Initialized
INFO - 2020-02-03 07:56:16 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:56:16 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:56:16 --> Utf8 Class Initialized
INFO - 2020-02-03 07:56:16 --> URI Class Initialized
INFO - 2020-02-03 07:56:16 --> Router Class Initialized
INFO - 2020-02-03 07:56:16 --> Output Class Initialized
INFO - 2020-02-03 07:56:16 --> Security Class Initialized
DEBUG - 2020-02-03 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:56:16 --> Input Class Initialized
INFO - 2020-02-03 07:56:16 --> Language Class Initialized
INFO - 2020-02-03 07:56:16 --> Language Class Initialized
INFO - 2020-02-03 07:56:16 --> Config Class Initialized
INFO - 2020-02-03 07:56:16 --> Loader Class Initialized
INFO - 2020-02-03 07:56:16 --> Helper loaded: url_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:56:17 --> Controller Class Initialized
INFO - 2020-02-03 07:56:17 --> Database Utility Class Initialized
INFO - 2020-02-03 07:56:17 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:56:17 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:56:17 --> Config Class Initialized
INFO - 2020-02-03 07:56:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:56:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:56:17 --> Utf8 Class Initialized
INFO - 2020-02-03 07:56:17 --> URI Class Initialized
INFO - 2020-02-03 07:56:17 --> Router Class Initialized
INFO - 2020-02-03 07:56:17 --> Output Class Initialized
INFO - 2020-02-03 07:56:17 --> Security Class Initialized
DEBUG - 2020-02-03 07:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:56:17 --> Input Class Initialized
INFO - 2020-02-03 07:56:17 --> Language Class Initialized
INFO - 2020-02-03 07:56:17 --> Language Class Initialized
INFO - 2020-02-03 07:56:17 --> Config Class Initialized
INFO - 2020-02-03 07:56:17 --> Loader Class Initialized
INFO - 2020-02-03 07:56:17 --> Helper loaded: url_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: file_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: form_helper
INFO - 2020-02-03 07:56:17 --> Helper loaded: my_helper
INFO - 2020-02-03 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:56:17 --> Controller Class Initialized
DEBUG - 2020-02-03 07:56:17 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:56:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:56:18 --> Final output sent to browser
DEBUG - 2020-02-03 07:56:18 --> Total execution time: 0.5385
INFO - 2020-02-03 07:56:19 --> Config Class Initialized
INFO - 2020-02-03 07:56:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:56:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:56:19 --> Utf8 Class Initialized
INFO - 2020-02-03 07:56:19 --> URI Class Initialized
INFO - 2020-02-03 07:56:19 --> Router Class Initialized
INFO - 2020-02-03 07:56:19 --> Output Class Initialized
INFO - 2020-02-03 07:56:19 --> Security Class Initialized
DEBUG - 2020-02-03 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:56:19 --> Input Class Initialized
INFO - 2020-02-03 07:56:19 --> Language Class Initialized
INFO - 2020-02-03 07:56:19 --> Language Class Initialized
INFO - 2020-02-03 07:56:19 --> Config Class Initialized
INFO - 2020-02-03 07:56:19 --> Loader Class Initialized
INFO - 2020-02-03 07:56:19 --> Helper loaded: url_helper
INFO - 2020-02-03 07:56:19 --> Helper loaded: file_helper
INFO - 2020-02-03 07:56:20 --> Helper loaded: form_helper
INFO - 2020-02-03 07:56:20 --> Helper loaded: my_helper
INFO - 2020-02-03 07:56:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:56:20 --> Controller Class Initialized
INFO - 2020-02-03 07:57:47 --> Config Class Initialized
INFO - 2020-02-03 07:57:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:57:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:57:47 --> Utf8 Class Initialized
INFO - 2020-02-03 07:57:47 --> URI Class Initialized
INFO - 2020-02-03 07:57:47 --> Router Class Initialized
INFO - 2020-02-03 07:57:47 --> Output Class Initialized
INFO - 2020-02-03 07:57:47 --> Security Class Initialized
DEBUG - 2020-02-03 07:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:57:47 --> Input Class Initialized
INFO - 2020-02-03 07:57:47 --> Language Class Initialized
ERROR - 2020-02-03 07:57:47 --> Severity: Parsing Error --> syntax error, unexpected ''" class="btn btn-xs btn-succe' (T_CONSTANT_ENCAPSED_STRING) E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 37
INFO - 2020-02-03 07:58:04 --> Config Class Initialized
INFO - 2020-02-03 07:58:04 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:04 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:04 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:04 --> URI Class Initialized
INFO - 2020-02-03 07:58:04 --> Router Class Initialized
INFO - 2020-02-03 07:58:04 --> Output Class Initialized
INFO - 2020-02-03 07:58:04 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:04 --> Input Class Initialized
INFO - 2020-02-03 07:58:04 --> Language Class Initialized
ERROR - 2020-02-03 07:58:04 --> Severity: Parsing Error --> syntax error, unexpected ''" class="btn btn-xs btn-succe' (T_CONSTANT_ENCAPSED_STRING) E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 37
INFO - 2020-02-03 07:58:13 --> Config Class Initialized
INFO - 2020-02-03 07:58:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:13 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:13 --> URI Class Initialized
INFO - 2020-02-03 07:58:13 --> Router Class Initialized
INFO - 2020-02-03 07:58:13 --> Output Class Initialized
INFO - 2020-02-03 07:58:13 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:13 --> Input Class Initialized
INFO - 2020-02-03 07:58:13 --> Language Class Initialized
ERROR - 2020-02-03 07:58:14 --> Severity: Parsing Error --> syntax error, unexpected ''" class="btn btn-xs btn-succe' (T_CONSTANT_ENCAPSED_STRING) E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 37
INFO - 2020-02-03 07:58:25 --> Config Class Initialized
INFO - 2020-02-03 07:58:25 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:25 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:25 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:25 --> URI Class Initialized
INFO - 2020-02-03 07:58:25 --> Router Class Initialized
INFO - 2020-02-03 07:58:25 --> Output Class Initialized
INFO - 2020-02-03 07:58:25 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:25 --> Input Class Initialized
INFO - 2020-02-03 07:58:25 --> Language Class Initialized
INFO - 2020-02-03 07:58:25 --> Language Class Initialized
INFO - 2020-02-03 07:58:25 --> Config Class Initialized
INFO - 2020-02-03 07:58:25 --> Loader Class Initialized
INFO - 2020-02-03 07:58:26 --> Helper loaded: url_helper
INFO - 2020-02-03 07:58:26 --> Helper loaded: file_helper
INFO - 2020-02-03 07:58:26 --> Helper loaded: form_helper
INFO - 2020-02-03 07:58:26 --> Helper loaded: my_helper
INFO - 2020-02-03 07:58:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:58:26 --> Controller Class Initialized
DEBUG - 2020-02-03 07:58:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:58:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:58:26 --> Final output sent to browser
DEBUG - 2020-02-03 07:58:26 --> Total execution time: 0.6037
INFO - 2020-02-03 07:58:26 --> Config Class Initialized
INFO - 2020-02-03 07:58:26 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:26 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:26 --> URI Class Initialized
INFO - 2020-02-03 07:58:26 --> Router Class Initialized
INFO - 2020-02-03 07:58:26 --> Output Class Initialized
INFO - 2020-02-03 07:58:26 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:26 --> Input Class Initialized
INFO - 2020-02-03 07:58:26 --> Language Class Initialized
INFO - 2020-02-03 07:58:26 --> Language Class Initialized
INFO - 2020-02-03 07:58:26 --> Config Class Initialized
INFO - 2020-02-03 07:58:26 --> Loader Class Initialized
INFO - 2020-02-03 07:58:26 --> Helper loaded: url_helper
INFO - 2020-02-03 07:58:26 --> Helper loaded: file_helper
INFO - 2020-02-03 07:58:27 --> Helper loaded: form_helper
INFO - 2020-02-03 07:58:27 --> Helper loaded: my_helper
INFO - 2020-02-03 07:58:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:58:27 --> Controller Class Initialized
INFO - 2020-02-03 07:58:40 --> Config Class Initialized
INFO - 2020-02-03 07:58:40 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:40 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:40 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:40 --> URI Class Initialized
INFO - 2020-02-03 07:58:40 --> Router Class Initialized
INFO - 2020-02-03 07:58:40 --> Output Class Initialized
INFO - 2020-02-03 07:58:40 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:40 --> Input Class Initialized
INFO - 2020-02-03 07:58:40 --> Language Class Initialized
INFO - 2020-02-03 07:58:40 --> Language Class Initialized
INFO - 2020-02-03 07:58:40 --> Config Class Initialized
INFO - 2020-02-03 07:58:40 --> Loader Class Initialized
INFO - 2020-02-03 07:58:40 --> Helper loaded: url_helper
INFO - 2020-02-03 07:58:40 --> Helper loaded: file_helper
INFO - 2020-02-03 07:58:40 --> Helper loaded: form_helper
INFO - 2020-02-03 07:58:40 --> Helper loaded: my_helper
INFO - 2020-02-03 07:58:40 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:58:41 --> Controller Class Initialized
DEBUG - 2020-02-03 07:58:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:58:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:58:41 --> Final output sent to browser
DEBUG - 2020-02-03 07:58:41 --> Total execution time: 0.6940
INFO - 2020-02-03 07:58:41 --> Config Class Initialized
INFO - 2020-02-03 07:58:41 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:58:41 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:58:41 --> Utf8 Class Initialized
INFO - 2020-02-03 07:58:41 --> URI Class Initialized
INFO - 2020-02-03 07:58:41 --> Router Class Initialized
INFO - 2020-02-03 07:58:41 --> Output Class Initialized
INFO - 2020-02-03 07:58:41 --> Security Class Initialized
DEBUG - 2020-02-03 07:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:58:41 --> Input Class Initialized
INFO - 2020-02-03 07:58:41 --> Language Class Initialized
INFO - 2020-02-03 07:58:41 --> Language Class Initialized
INFO - 2020-02-03 07:58:41 --> Config Class Initialized
INFO - 2020-02-03 07:58:41 --> Loader Class Initialized
INFO - 2020-02-03 07:58:41 --> Helper loaded: url_helper
INFO - 2020-02-03 07:58:41 --> Helper loaded: file_helper
INFO - 2020-02-03 07:58:41 --> Helper loaded: form_helper
INFO - 2020-02-03 07:58:41 --> Helper loaded: my_helper
INFO - 2020-02-03 07:58:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:58:42 --> Controller Class Initialized
INFO - 2020-02-03 07:59:09 --> Config Class Initialized
INFO - 2020-02-03 07:59:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:09 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:10 --> URI Class Initialized
INFO - 2020-02-03 07:59:10 --> Router Class Initialized
INFO - 2020-02-03 07:59:10 --> Output Class Initialized
INFO - 2020-02-03 07:59:10 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:10 --> Input Class Initialized
INFO - 2020-02-03 07:59:10 --> Language Class Initialized
INFO - 2020-02-03 07:59:10 --> Language Class Initialized
INFO - 2020-02-03 07:59:10 --> Config Class Initialized
INFO - 2020-02-03 07:59:10 --> Loader Class Initialized
INFO - 2020-02-03 07:59:10 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:10 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:10 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:10 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:10 --> Controller Class Initialized
DEBUG - 2020-02-03 07:59:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:59:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:59:10 --> Final output sent to browser
DEBUG - 2020-02-03 07:59:10 --> Total execution time: 0.6744
INFO - 2020-02-03 07:59:10 --> Config Class Initialized
INFO - 2020-02-03 07:59:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:10 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:10 --> URI Class Initialized
INFO - 2020-02-03 07:59:11 --> Router Class Initialized
INFO - 2020-02-03 07:59:11 --> Output Class Initialized
INFO - 2020-02-03 07:59:11 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:11 --> Input Class Initialized
INFO - 2020-02-03 07:59:11 --> Language Class Initialized
INFO - 2020-02-03 07:59:11 --> Language Class Initialized
INFO - 2020-02-03 07:59:11 --> Config Class Initialized
INFO - 2020-02-03 07:59:11 --> Loader Class Initialized
INFO - 2020-02-03 07:59:11 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:11 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:11 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:11 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:11 --> Controller Class Initialized
INFO - 2020-02-03 07:59:27 --> Config Class Initialized
INFO - 2020-02-03 07:59:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:27 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:27 --> URI Class Initialized
INFO - 2020-02-03 07:59:27 --> Router Class Initialized
INFO - 2020-02-03 07:59:27 --> Output Class Initialized
INFO - 2020-02-03 07:59:27 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:27 --> Input Class Initialized
INFO - 2020-02-03 07:59:27 --> Language Class Initialized
INFO - 2020-02-03 07:59:27 --> Language Class Initialized
INFO - 2020-02-03 07:59:27 --> Config Class Initialized
INFO - 2020-02-03 07:59:27 --> Loader Class Initialized
INFO - 2020-02-03 07:59:27 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:27 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:27 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:27 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:27 --> Controller Class Initialized
DEBUG - 2020-02-03 07:59:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:59:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:59:27 --> Final output sent to browser
DEBUG - 2020-02-03 07:59:27 --> Total execution time: 0.6925
INFO - 2020-02-03 07:59:28 --> Config Class Initialized
INFO - 2020-02-03 07:59:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:28 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:28 --> URI Class Initialized
INFO - 2020-02-03 07:59:28 --> Router Class Initialized
INFO - 2020-02-03 07:59:28 --> Output Class Initialized
INFO - 2020-02-03 07:59:28 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:28 --> Input Class Initialized
INFO - 2020-02-03 07:59:28 --> Language Class Initialized
INFO - 2020-02-03 07:59:28 --> Language Class Initialized
INFO - 2020-02-03 07:59:28 --> Config Class Initialized
INFO - 2020-02-03 07:59:28 --> Loader Class Initialized
INFO - 2020-02-03 07:59:28 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:28 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:28 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:28 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:28 --> Controller Class Initialized
INFO - 2020-02-03 07:59:46 --> Config Class Initialized
INFO - 2020-02-03 07:59:46 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:46 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:46 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:46 --> URI Class Initialized
INFO - 2020-02-03 07:59:46 --> Router Class Initialized
INFO - 2020-02-03 07:59:46 --> Output Class Initialized
INFO - 2020-02-03 07:59:46 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:46 --> Input Class Initialized
INFO - 2020-02-03 07:59:46 --> Language Class Initialized
INFO - 2020-02-03 07:59:46 --> Language Class Initialized
INFO - 2020-02-03 07:59:46 --> Config Class Initialized
INFO - 2020-02-03 07:59:46 --> Loader Class Initialized
INFO - 2020-02-03 07:59:46 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:46 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:46 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:46 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:46 --> Controller Class Initialized
DEBUG - 2020-02-03 07:59:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:59:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:59:47 --> Final output sent to browser
DEBUG - 2020-02-03 07:59:47 --> Total execution time: 0.8292
INFO - 2020-02-03 07:59:47 --> Config Class Initialized
INFO - 2020-02-03 07:59:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:47 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:47 --> URI Class Initialized
INFO - 2020-02-03 07:59:47 --> Router Class Initialized
INFO - 2020-02-03 07:59:47 --> Output Class Initialized
INFO - 2020-02-03 07:59:47 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:47 --> Input Class Initialized
INFO - 2020-02-03 07:59:47 --> Language Class Initialized
INFO - 2020-02-03 07:59:47 --> Language Class Initialized
INFO - 2020-02-03 07:59:47 --> Config Class Initialized
INFO - 2020-02-03 07:59:47 --> Loader Class Initialized
INFO - 2020-02-03 07:59:47 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:47 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:47 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:47 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:47 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:47 --> Controller Class Initialized
INFO - 2020-02-03 07:59:48 --> Config Class Initialized
INFO - 2020-02-03 07:59:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:48 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:48 --> URI Class Initialized
INFO - 2020-02-03 07:59:48 --> Router Class Initialized
INFO - 2020-02-03 07:59:48 --> Output Class Initialized
INFO - 2020-02-03 07:59:48 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:48 --> Input Class Initialized
INFO - 2020-02-03 07:59:48 --> Language Class Initialized
INFO - 2020-02-03 07:59:48 --> Language Class Initialized
INFO - 2020-02-03 07:59:48 --> Config Class Initialized
INFO - 2020-02-03 07:59:49 --> Loader Class Initialized
INFO - 2020-02-03 07:59:49 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:49 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:49 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:49 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:49 --> Controller Class Initialized
INFO - 2020-02-03 07:59:49 --> Database Utility Class Initialized
INFO - 2020-02-03 07:59:49 --> Zip Compression Class Initialized
ERROR - 2020-02-03 07:59:49 --> Severity: Runtime Notice --> Only variables should be assigned by reference E:\xampp\htdocs\_2020\myraport\application\modules\backup_db\controllers\Backup_db.php 88
INFO - 2020-02-03 07:59:49 --> Config Class Initialized
INFO - 2020-02-03 07:59:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:49 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:49 --> URI Class Initialized
INFO - 2020-02-03 07:59:49 --> Router Class Initialized
INFO - 2020-02-03 07:59:49 --> Output Class Initialized
INFO - 2020-02-03 07:59:49 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:49 --> Input Class Initialized
INFO - 2020-02-03 07:59:49 --> Language Class Initialized
INFO - 2020-02-03 07:59:49 --> Language Class Initialized
INFO - 2020-02-03 07:59:49 --> Config Class Initialized
INFO - 2020-02-03 07:59:50 --> Loader Class Initialized
INFO - 2020-02-03 07:59:50 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:50 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:50 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:50 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:50 --> Controller Class Initialized
DEBUG - 2020-02-03 07:59:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/backup_db/views/list.php
DEBUG - 2020-02-03 07:59:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 07:59:50 --> Final output sent to browser
DEBUG - 2020-02-03 07:59:50 --> Total execution time: 0.7026
INFO - 2020-02-03 07:59:52 --> Config Class Initialized
INFO - 2020-02-03 07:59:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 07:59:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 07:59:52 --> Utf8 Class Initialized
INFO - 2020-02-03 07:59:52 --> URI Class Initialized
INFO - 2020-02-03 07:59:52 --> Router Class Initialized
INFO - 2020-02-03 07:59:52 --> Output Class Initialized
INFO - 2020-02-03 07:59:52 --> Security Class Initialized
DEBUG - 2020-02-03 07:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 07:59:52 --> Input Class Initialized
INFO - 2020-02-03 07:59:52 --> Language Class Initialized
INFO - 2020-02-03 07:59:52 --> Language Class Initialized
INFO - 2020-02-03 07:59:52 --> Config Class Initialized
INFO - 2020-02-03 07:59:52 --> Loader Class Initialized
INFO - 2020-02-03 07:59:52 --> Helper loaded: url_helper
INFO - 2020-02-03 07:59:52 --> Helper loaded: file_helper
INFO - 2020-02-03 07:59:52 --> Helper loaded: form_helper
INFO - 2020-02-03 07:59:52 --> Helper loaded: my_helper
INFO - 2020-02-03 07:59:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 07:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 07:59:52 --> Controller Class Initialized
INFO - 2020-02-03 13:07:09 --> Config Class Initialized
INFO - 2020-02-03 13:07:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:09 --> URI Class Initialized
DEBUG - 2020-02-03 13:07:09 --> No URI present. Default controller set.
INFO - 2020-02-03 13:07:09 --> Router Class Initialized
INFO - 2020-02-03 13:07:09 --> Output Class Initialized
INFO - 2020-02-03 13:07:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:09 --> Input Class Initialized
INFO - 2020-02-03 13:07:09 --> Language Class Initialized
INFO - 2020-02-03 13:07:09 --> Language Class Initialized
INFO - 2020-02-03 13:07:09 --> Config Class Initialized
INFO - 2020-02-03 13:07:09 --> Loader Class Initialized
INFO - 2020-02-03 13:07:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:09 --> Controller Class Initialized
INFO - 2020-02-03 13:07:09 --> Config Class Initialized
INFO - 2020-02-03 13:07:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:09 --> URI Class Initialized
INFO - 2020-02-03 13:07:09 --> Router Class Initialized
INFO - 2020-02-03 13:07:10 --> Output Class Initialized
INFO - 2020-02-03 13:07:10 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:10 --> Input Class Initialized
INFO - 2020-02-03 13:07:10 --> Language Class Initialized
INFO - 2020-02-03 13:07:10 --> Language Class Initialized
INFO - 2020-02-03 13:07:10 --> Config Class Initialized
INFO - 2020-02-03 13:07:10 --> Loader Class Initialized
INFO - 2020-02-03 13:07:10 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:10 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:10 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:10 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:10 --> Controller Class Initialized
DEBUG - 2020-02-03 13:07:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/login/views/login.php
DEBUG - 2020-02-03 13:07:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:07:10 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:10 --> Total execution time: 0.5654
INFO - 2020-02-03 13:07:17 --> Config Class Initialized
INFO - 2020-02-03 13:07:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:17 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:17 --> URI Class Initialized
INFO - 2020-02-03 13:07:17 --> Router Class Initialized
INFO - 2020-02-03 13:07:17 --> Output Class Initialized
INFO - 2020-02-03 13:07:17 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:17 --> Input Class Initialized
INFO - 2020-02-03 13:07:17 --> Language Class Initialized
INFO - 2020-02-03 13:07:17 --> Language Class Initialized
INFO - 2020-02-03 13:07:17 --> Config Class Initialized
INFO - 2020-02-03 13:07:17 --> Loader Class Initialized
INFO - 2020-02-03 13:07:17 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:17 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:17 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:17 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:17 --> Controller Class Initialized
INFO - 2020-02-03 13:07:17 --> Helper loaded: cookie_helper
INFO - 2020-02-03 13:07:17 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:17 --> Total execution time: 0.5311
INFO - 2020-02-03 13:07:17 --> Config Class Initialized
INFO - 2020-02-03 13:07:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:17 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:17 --> URI Class Initialized
INFO - 2020-02-03 13:07:17 --> Router Class Initialized
INFO - 2020-02-03 13:07:17 --> Output Class Initialized
INFO - 2020-02-03 13:07:17 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:17 --> Input Class Initialized
INFO - 2020-02-03 13:07:17 --> Language Class Initialized
INFO - 2020-02-03 13:07:17 --> Language Class Initialized
INFO - 2020-02-03 13:07:17 --> Config Class Initialized
INFO - 2020-02-03 13:07:17 --> Loader Class Initialized
INFO - 2020-02-03 13:07:17 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:18 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:18 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:18 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:18 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:18 --> Controller Class Initialized
DEBUG - 2020-02-03 13:07:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/home/views/v_home.php
DEBUG - 2020-02-03 13:07:18 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:07:18 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:18 --> Total execution time: 0.5464
INFO - 2020-02-03 13:07:27 --> Config Class Initialized
INFO - 2020-02-03 13:07:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:27 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:27 --> URI Class Initialized
INFO - 2020-02-03 13:07:27 --> Router Class Initialized
INFO - 2020-02-03 13:07:27 --> Output Class Initialized
INFO - 2020-02-03 13:07:27 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:27 --> Input Class Initialized
INFO - 2020-02-03 13:07:27 --> Language Class Initialized
INFO - 2020-02-03 13:07:27 --> Language Class Initialized
INFO - 2020-02-03 13:07:27 --> Config Class Initialized
INFO - 2020-02-03 13:07:27 --> Loader Class Initialized
INFO - 2020-02-03 13:07:27 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:27 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:27 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:27 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:27 --> Controller Class Initialized
DEBUG - 2020-02-03 13:07:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 13:07:27 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:07:27 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:27 --> Total execution time: 0.5090
INFO - 2020-02-03 13:07:28 --> Config Class Initialized
INFO - 2020-02-03 13:07:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:28 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:28 --> URI Class Initialized
INFO - 2020-02-03 13:07:28 --> Router Class Initialized
INFO - 2020-02-03 13:07:28 --> Output Class Initialized
INFO - 2020-02-03 13:07:28 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:28 --> Input Class Initialized
INFO - 2020-02-03 13:07:28 --> Language Class Initialized
INFO - 2020-02-03 13:07:28 --> Language Class Initialized
INFO - 2020-02-03 13:07:28 --> Config Class Initialized
INFO - 2020-02-03 13:07:28 --> Loader Class Initialized
INFO - 2020-02-03 13:07:28 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:28 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:28 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:28 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:28 --> Controller Class Initialized
INFO - 2020-02-03 13:07:30 --> Config Class Initialized
INFO - 2020-02-03 13:07:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:30 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:30 --> URI Class Initialized
INFO - 2020-02-03 13:07:30 --> Router Class Initialized
INFO - 2020-02-03 13:07:30 --> Output Class Initialized
INFO - 2020-02-03 13:07:30 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:30 --> Input Class Initialized
INFO - 2020-02-03 13:07:30 --> Language Class Initialized
INFO - 2020-02-03 13:07:30 --> Language Class Initialized
INFO - 2020-02-03 13:07:30 --> Config Class Initialized
INFO - 2020-02-03 13:07:30 --> Loader Class Initialized
INFO - 2020-02-03 13:07:30 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:30 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:30 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:30 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:30 --> Controller Class Initialized
DEBUG - 2020-02-03 13:07:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:07:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:07:30 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:30 --> Total execution time: 0.5402
INFO - 2020-02-03 13:07:30 --> Config Class Initialized
INFO - 2020-02-03 13:07:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:30 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:30 --> URI Class Initialized
INFO - 2020-02-03 13:07:30 --> Router Class Initialized
INFO - 2020-02-03 13:07:30 --> Output Class Initialized
INFO - 2020-02-03 13:07:30 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:30 --> Input Class Initialized
INFO - 2020-02-03 13:07:31 --> Language Class Initialized
INFO - 2020-02-03 13:07:31 --> Language Class Initialized
INFO - 2020-02-03 13:07:31 --> Config Class Initialized
INFO - 2020-02-03 13:07:31 --> Loader Class Initialized
INFO - 2020-02-03 13:07:31 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:31 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:31 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:31 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:31 --> Controller Class Initialized
INFO - 2020-02-03 13:07:32 --> Config Class Initialized
INFO - 2020-02-03 13:07:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:32 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:32 --> URI Class Initialized
INFO - 2020-02-03 13:07:32 --> Router Class Initialized
INFO - 2020-02-03 13:07:32 --> Output Class Initialized
INFO - 2020-02-03 13:07:32 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:32 --> Input Class Initialized
INFO - 2020-02-03 13:07:32 --> Language Class Initialized
INFO - 2020-02-03 13:07:32 --> Language Class Initialized
INFO - 2020-02-03 13:07:32 --> Config Class Initialized
INFO - 2020-02-03 13:07:32 --> Loader Class Initialized
INFO - 2020-02-03 13:07:32 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:32 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:32 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:32 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:32 --> Controller Class Initialized
INFO - 2020-02-03 13:07:32 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:32 --> Total execution time: 0.5382
INFO - 2020-02-03 13:07:43 --> Config Class Initialized
INFO - 2020-02-03 13:07:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:44 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:44 --> URI Class Initialized
INFO - 2020-02-03 13:07:44 --> Router Class Initialized
INFO - 2020-02-03 13:07:44 --> Output Class Initialized
INFO - 2020-02-03 13:07:44 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:44 --> Input Class Initialized
INFO - 2020-02-03 13:07:44 --> Language Class Initialized
INFO - 2020-02-03 13:07:44 --> Language Class Initialized
INFO - 2020-02-03 13:07:44 --> Config Class Initialized
INFO - 2020-02-03 13:07:44 --> Loader Class Initialized
INFO - 2020-02-03 13:07:44 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:44 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:44 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:44 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:44 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:44 --> Controller Class Initialized
INFO - 2020-02-03 13:07:44 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:44 --> Total execution time: 0.5227
INFO - 2020-02-03 13:07:58 --> Config Class Initialized
INFO - 2020-02-03 13:07:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:07:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:07:58 --> Utf8 Class Initialized
INFO - 2020-02-03 13:07:58 --> URI Class Initialized
INFO - 2020-02-03 13:07:58 --> Router Class Initialized
INFO - 2020-02-03 13:07:58 --> Output Class Initialized
INFO - 2020-02-03 13:07:58 --> Security Class Initialized
DEBUG - 2020-02-03 13:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:07:58 --> Input Class Initialized
INFO - 2020-02-03 13:07:58 --> Language Class Initialized
INFO - 2020-02-03 13:07:58 --> Language Class Initialized
INFO - 2020-02-03 13:07:58 --> Config Class Initialized
INFO - 2020-02-03 13:07:58 --> Loader Class Initialized
INFO - 2020-02-03 13:07:58 --> Helper loaded: url_helper
INFO - 2020-02-03 13:07:59 --> Helper loaded: file_helper
INFO - 2020-02-03 13:07:59 --> Helper loaded: form_helper
INFO - 2020-02-03 13:07:59 --> Helper loaded: my_helper
INFO - 2020-02-03 13:07:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:07:59 --> Controller Class Initialized
INFO - 2020-02-03 13:07:59 --> Final output sent to browser
DEBUG - 2020-02-03 13:07:59 --> Total execution time: 0.5457
INFO - 2020-02-03 13:08:22 --> Config Class Initialized
INFO - 2020-02-03 13:08:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:23 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:23 --> URI Class Initialized
INFO - 2020-02-03 13:08:23 --> Router Class Initialized
INFO - 2020-02-03 13:08:23 --> Output Class Initialized
INFO - 2020-02-03 13:08:23 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:23 --> Input Class Initialized
INFO - 2020-02-03 13:08:23 --> Language Class Initialized
INFO - 2020-02-03 13:08:23 --> Language Class Initialized
INFO - 2020-02-03 13:08:23 --> Config Class Initialized
INFO - 2020-02-03 13:08:23 --> Loader Class Initialized
INFO - 2020-02-03 13:08:23 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:23 --> Controller Class Initialized
INFO - 2020-02-03 13:08:23 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:23 --> Total execution time: 0.5270
INFO - 2020-02-03 13:08:23 --> Config Class Initialized
INFO - 2020-02-03 13:08:23 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:23 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:23 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:23 --> URI Class Initialized
INFO - 2020-02-03 13:08:23 --> Router Class Initialized
INFO - 2020-02-03 13:08:23 --> Output Class Initialized
INFO - 2020-02-03 13:08:23 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:23 --> Input Class Initialized
INFO - 2020-02-03 13:08:23 --> Language Class Initialized
INFO - 2020-02-03 13:08:23 --> Language Class Initialized
INFO - 2020-02-03 13:08:23 --> Config Class Initialized
INFO - 2020-02-03 13:08:23 --> Loader Class Initialized
INFO - 2020-02-03 13:08:23 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:23 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:24 --> Controller Class Initialized
INFO - 2020-02-03 13:08:27 --> Config Class Initialized
INFO - 2020-02-03 13:08:27 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:27 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:27 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:27 --> URI Class Initialized
INFO - 2020-02-03 13:08:27 --> Router Class Initialized
INFO - 2020-02-03 13:08:27 --> Output Class Initialized
INFO - 2020-02-03 13:08:27 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:27 --> Input Class Initialized
INFO - 2020-02-03 13:08:27 --> Language Class Initialized
INFO - 2020-02-03 13:08:27 --> Language Class Initialized
INFO - 2020-02-03 13:08:27 --> Config Class Initialized
INFO - 2020-02-03 13:08:27 --> Loader Class Initialized
INFO - 2020-02-03 13:08:27 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:27 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:27 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:27 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:27 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:27 --> Controller Class Initialized
INFO - 2020-02-03 13:08:28 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:28 --> Total execution time: 0.5149
INFO - 2020-02-03 13:08:28 --> Config Class Initialized
INFO - 2020-02-03 13:08:28 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:28 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:28 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:28 --> URI Class Initialized
INFO - 2020-02-03 13:08:28 --> Router Class Initialized
INFO - 2020-02-03 13:08:28 --> Output Class Initialized
INFO - 2020-02-03 13:08:28 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:28 --> Input Class Initialized
INFO - 2020-02-03 13:08:28 --> Language Class Initialized
INFO - 2020-02-03 13:08:28 --> Language Class Initialized
INFO - 2020-02-03 13:08:28 --> Config Class Initialized
INFO - 2020-02-03 13:08:28 --> Loader Class Initialized
INFO - 2020-02-03 13:08:28 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:28 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:28 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:28 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:28 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:28 --> Controller Class Initialized
INFO - 2020-02-03 13:08:41 --> Config Class Initialized
INFO - 2020-02-03 13:08:41 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:41 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:41 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:41 --> URI Class Initialized
INFO - 2020-02-03 13:08:41 --> Router Class Initialized
INFO - 2020-02-03 13:08:41 --> Output Class Initialized
INFO - 2020-02-03 13:08:41 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:41 --> Input Class Initialized
INFO - 2020-02-03 13:08:41 --> Language Class Initialized
INFO - 2020-02-03 13:08:41 --> Language Class Initialized
INFO - 2020-02-03 13:08:41 --> Config Class Initialized
INFO - 2020-02-03 13:08:41 --> Loader Class Initialized
INFO - 2020-02-03 13:08:41 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:41 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:41 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:41 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:41 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:41 --> Controller Class Initialized
DEBUG - 2020-02-03 13:08:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:08:41 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:08:41 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:41 --> Total execution time: 0.5071
INFO - 2020-02-03 13:08:48 --> Config Class Initialized
INFO - 2020-02-03 13:08:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:48 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:48 --> URI Class Initialized
INFO - 2020-02-03 13:08:48 --> Router Class Initialized
INFO - 2020-02-03 13:08:48 --> Output Class Initialized
INFO - 2020-02-03 13:08:48 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:48 --> Input Class Initialized
INFO - 2020-02-03 13:08:48 --> Language Class Initialized
INFO - 2020-02-03 13:08:48 --> Language Class Initialized
INFO - 2020-02-03 13:08:48 --> Config Class Initialized
INFO - 2020-02-03 13:08:48 --> Loader Class Initialized
INFO - 2020-02-03 13:08:48 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:48 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:48 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:48 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:48 --> Controller Class Initialized
DEBUG - 2020-02-03 13:08:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 13:08:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:08:48 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:48 --> Total execution time: 0.5192
INFO - 2020-02-03 13:08:48 --> Config Class Initialized
INFO - 2020-02-03 13:08:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:49 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:49 --> URI Class Initialized
INFO - 2020-02-03 13:08:49 --> Router Class Initialized
INFO - 2020-02-03 13:08:49 --> Output Class Initialized
INFO - 2020-02-03 13:08:49 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:49 --> Input Class Initialized
INFO - 2020-02-03 13:08:49 --> Language Class Initialized
INFO - 2020-02-03 13:08:49 --> Language Class Initialized
INFO - 2020-02-03 13:08:49 --> Config Class Initialized
INFO - 2020-02-03 13:08:49 --> Loader Class Initialized
INFO - 2020-02-03 13:08:49 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:49 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:49 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:49 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:49 --> Controller Class Initialized
INFO - 2020-02-03 13:08:51 --> Config Class Initialized
INFO - 2020-02-03 13:08:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:51 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:51 --> URI Class Initialized
INFO - 2020-02-03 13:08:51 --> Router Class Initialized
INFO - 2020-02-03 13:08:51 --> Output Class Initialized
INFO - 2020-02-03 13:08:51 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:51 --> Input Class Initialized
INFO - 2020-02-03 13:08:51 --> Language Class Initialized
INFO - 2020-02-03 13:08:51 --> Language Class Initialized
INFO - 2020-02-03 13:08:51 --> Config Class Initialized
INFO - 2020-02-03 13:08:51 --> Loader Class Initialized
INFO - 2020-02-03 13:08:51 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:51 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:51 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:51 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:51 --> Controller Class Initialized
DEBUG - 2020-02-03 13:08:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-03 13:08:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:08:51 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:51 --> Total execution time: 0.5491
INFO - 2020-02-03 13:08:51 --> Config Class Initialized
INFO - 2020-02-03 13:08:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:51 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:51 --> URI Class Initialized
INFO - 2020-02-03 13:08:52 --> Router Class Initialized
INFO - 2020-02-03 13:08:52 --> Output Class Initialized
INFO - 2020-02-03 13:08:52 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:52 --> Input Class Initialized
INFO - 2020-02-03 13:08:52 --> Language Class Initialized
INFO - 2020-02-03 13:08:52 --> Language Class Initialized
INFO - 2020-02-03 13:08:52 --> Config Class Initialized
INFO - 2020-02-03 13:08:52 --> Loader Class Initialized
INFO - 2020-02-03 13:08:52 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:52 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:52 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:52 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:52 --> Controller Class Initialized
INFO - 2020-02-03 13:08:56 --> Config Class Initialized
INFO - 2020-02-03 13:08:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:56 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:56 --> URI Class Initialized
INFO - 2020-02-03 13:08:56 --> Router Class Initialized
INFO - 2020-02-03 13:08:56 --> Output Class Initialized
INFO - 2020-02-03 13:08:56 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:56 --> Input Class Initialized
INFO - 2020-02-03 13:08:56 --> Language Class Initialized
INFO - 2020-02-03 13:08:56 --> Language Class Initialized
INFO - 2020-02-03 13:08:56 --> Config Class Initialized
INFO - 2020-02-03 13:08:56 --> Loader Class Initialized
INFO - 2020-02-03 13:08:56 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:56 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:56 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:56 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:56 --> Controller Class Initialized
DEBUG - 2020-02-03 13:08:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:08:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:08:56 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:56 --> Total execution time: 0.5513
INFO - 2020-02-03 13:08:56 --> Config Class Initialized
INFO - 2020-02-03 13:08:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:57 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:57 --> URI Class Initialized
INFO - 2020-02-03 13:08:57 --> Router Class Initialized
INFO - 2020-02-03 13:08:57 --> Output Class Initialized
INFO - 2020-02-03 13:08:57 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:57 --> Input Class Initialized
INFO - 2020-02-03 13:08:57 --> Language Class Initialized
INFO - 2020-02-03 13:08:57 --> Language Class Initialized
INFO - 2020-02-03 13:08:57 --> Config Class Initialized
INFO - 2020-02-03 13:08:57 --> Loader Class Initialized
INFO - 2020-02-03 13:08:57 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:57 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:57 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:57 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:57 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:57 --> Controller Class Initialized
INFO - 2020-02-03 13:08:58 --> Config Class Initialized
INFO - 2020-02-03 13:08:58 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:58 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:58 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:59 --> URI Class Initialized
INFO - 2020-02-03 13:08:59 --> Router Class Initialized
INFO - 2020-02-03 13:08:59 --> Output Class Initialized
INFO - 2020-02-03 13:08:59 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:59 --> Input Class Initialized
INFO - 2020-02-03 13:08:59 --> Language Class Initialized
INFO - 2020-02-03 13:08:59 --> Language Class Initialized
INFO - 2020-02-03 13:08:59 --> Config Class Initialized
INFO - 2020-02-03 13:08:59 --> Loader Class Initialized
INFO - 2020-02-03 13:08:59 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:59 --> Controller Class Initialized
INFO - 2020-02-03 13:08:59 --> Final output sent to browser
DEBUG - 2020-02-03 13:08:59 --> Total execution time: 0.4712
INFO - 2020-02-03 13:08:59 --> Config Class Initialized
INFO - 2020-02-03 13:08:59 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:08:59 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:08:59 --> Utf8 Class Initialized
INFO - 2020-02-03 13:08:59 --> URI Class Initialized
INFO - 2020-02-03 13:08:59 --> Router Class Initialized
INFO - 2020-02-03 13:08:59 --> Output Class Initialized
INFO - 2020-02-03 13:08:59 --> Security Class Initialized
DEBUG - 2020-02-03 13:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:08:59 --> Input Class Initialized
INFO - 2020-02-03 13:08:59 --> Language Class Initialized
INFO - 2020-02-03 13:08:59 --> Language Class Initialized
INFO - 2020-02-03 13:08:59 --> Config Class Initialized
INFO - 2020-02-03 13:08:59 --> Loader Class Initialized
INFO - 2020-02-03 13:08:59 --> Helper loaded: url_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: file_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: form_helper
INFO - 2020-02-03 13:08:59 --> Helper loaded: my_helper
INFO - 2020-02-03 13:08:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:08:59 --> Controller Class Initialized
INFO - 2020-02-03 13:09:02 --> Config Class Initialized
INFO - 2020-02-03 13:09:02 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:02 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:02 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:02 --> URI Class Initialized
INFO - 2020-02-03 13:09:02 --> Router Class Initialized
INFO - 2020-02-03 13:09:02 --> Output Class Initialized
INFO - 2020-02-03 13:09:02 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:02 --> Input Class Initialized
INFO - 2020-02-03 13:09:02 --> Language Class Initialized
INFO - 2020-02-03 13:09:02 --> Language Class Initialized
INFO - 2020-02-03 13:09:02 --> Config Class Initialized
INFO - 2020-02-03 13:09:02 --> Loader Class Initialized
INFO - 2020-02-03 13:09:02 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:02 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:02 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:02 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:02 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:02 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-03 13:09:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:02 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:02 --> Total execution time: 0.5295
INFO - 2020-02-03 13:09:03 --> Config Class Initialized
INFO - 2020-02-03 13:09:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:03 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:03 --> URI Class Initialized
INFO - 2020-02-03 13:09:03 --> Router Class Initialized
INFO - 2020-02-03 13:09:03 --> Output Class Initialized
INFO - 2020-02-03 13:09:03 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:03 --> Input Class Initialized
INFO - 2020-02-03 13:09:03 --> Language Class Initialized
INFO - 2020-02-03 13:09:03 --> Language Class Initialized
INFO - 2020-02-03 13:09:03 --> Config Class Initialized
INFO - 2020-02-03 13:09:03 --> Loader Class Initialized
INFO - 2020-02-03 13:09:03 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:03 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:03 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:03 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:03 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:03 --> Controller Class Initialized
INFO - 2020-02-03 13:09:05 --> Config Class Initialized
INFO - 2020-02-03 13:09:05 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:05 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:05 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:05 --> URI Class Initialized
INFO - 2020-02-03 13:09:05 --> Router Class Initialized
INFO - 2020-02-03 13:09:05 --> Output Class Initialized
INFO - 2020-02-03 13:09:05 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:05 --> Input Class Initialized
INFO - 2020-02-03 13:09:05 --> Language Class Initialized
INFO - 2020-02-03 13:09:05 --> Language Class Initialized
INFO - 2020-02-03 13:09:05 --> Config Class Initialized
INFO - 2020-02-03 13:09:05 --> Loader Class Initialized
INFO - 2020-02-03 13:09:05 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:05 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:05 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:05 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:05 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:05 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_mapel/views/list.php
DEBUG - 2020-02-03 13:09:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:05 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:05 --> Total execution time: 0.5281
INFO - 2020-02-03 13:09:05 --> Config Class Initialized
INFO - 2020-02-03 13:09:05 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:05 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:05 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:05 --> URI Class Initialized
INFO - 2020-02-03 13:09:05 --> Router Class Initialized
INFO - 2020-02-03 13:09:05 --> Output Class Initialized
INFO - 2020-02-03 13:09:05 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:05 --> Input Class Initialized
INFO - 2020-02-03 13:09:05 --> Language Class Initialized
INFO - 2020-02-03 13:09:05 --> Language Class Initialized
INFO - 2020-02-03 13:09:05 --> Config Class Initialized
INFO - 2020-02-03 13:09:05 --> Loader Class Initialized
INFO - 2020-02-03 13:09:06 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:06 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:06 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:06 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:06 --> Controller Class Initialized
INFO - 2020-02-03 13:09:07 --> Config Class Initialized
INFO - 2020-02-03 13:09:07 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:07 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:07 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:07 --> URI Class Initialized
INFO - 2020-02-03 13:09:07 --> Router Class Initialized
INFO - 2020-02-03 13:09:07 --> Output Class Initialized
INFO - 2020-02-03 13:09:07 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:07 --> Input Class Initialized
INFO - 2020-02-03 13:09:07 --> Language Class Initialized
INFO - 2020-02-03 13:09:07 --> Language Class Initialized
INFO - 2020-02-03 13:09:08 --> Config Class Initialized
INFO - 2020-02-03 13:09:08 --> Loader Class Initialized
INFO - 2020-02-03 13:09:08 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:08 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:08 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:08 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:08 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:08 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:09:08 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:08 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:08 --> Total execution time: 0.6621
INFO - 2020-02-03 13:09:10 --> Config Class Initialized
INFO - 2020-02-03 13:09:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:10 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:10 --> URI Class Initialized
INFO - 2020-02-03 13:09:10 --> Router Class Initialized
INFO - 2020-02-03 13:09:10 --> Output Class Initialized
INFO - 2020-02-03 13:09:10 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:10 --> Input Class Initialized
INFO - 2020-02-03 13:09:10 --> Language Class Initialized
INFO - 2020-02-03 13:09:10 --> Language Class Initialized
INFO - 2020-02-03 13:09:10 --> Config Class Initialized
INFO - 2020-02-03 13:09:10 --> Loader Class Initialized
INFO - 2020-02-03 13:09:10 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:10 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:10 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:10 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:10 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:09:10 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:10 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:10 --> Total execution time: 0.5468
INFO - 2020-02-03 13:09:10 --> Config Class Initialized
INFO - 2020-02-03 13:09:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:11 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:11 --> URI Class Initialized
INFO - 2020-02-03 13:09:11 --> Router Class Initialized
INFO - 2020-02-03 13:09:11 --> Output Class Initialized
INFO - 2020-02-03 13:09:11 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:11 --> Input Class Initialized
INFO - 2020-02-03 13:09:11 --> Language Class Initialized
INFO - 2020-02-03 13:09:11 --> Language Class Initialized
INFO - 2020-02-03 13:09:11 --> Config Class Initialized
INFO - 2020-02-03 13:09:11 --> Loader Class Initialized
INFO - 2020-02-03 13:09:11 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:11 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:11 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:11 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:11 --> Controller Class Initialized
INFO - 2020-02-03 13:09:19 --> Config Class Initialized
INFO - 2020-02-03 13:09:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:19 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:19 --> URI Class Initialized
INFO - 2020-02-03 13:09:19 --> Router Class Initialized
INFO - 2020-02-03 13:09:19 --> Output Class Initialized
INFO - 2020-02-03 13:09:19 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:19 --> Input Class Initialized
INFO - 2020-02-03 13:09:19 --> Language Class Initialized
INFO - 2020-02-03 13:09:19 --> Language Class Initialized
INFO - 2020-02-03 13:09:19 --> Config Class Initialized
INFO - 2020-02-03 13:09:19 --> Loader Class Initialized
INFO - 2020-02-03 13:09:19 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:20 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:09:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:20 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:20 --> Total execution time: 0.5481
INFO - 2020-02-03 13:09:20 --> Config Class Initialized
INFO - 2020-02-03 13:09:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:20 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:20 --> URI Class Initialized
INFO - 2020-02-03 13:09:20 --> Router Class Initialized
INFO - 2020-02-03 13:09:20 --> Output Class Initialized
INFO - 2020-02-03 13:09:20 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:20 --> Input Class Initialized
INFO - 2020-02-03 13:09:20 --> Language Class Initialized
INFO - 2020-02-03 13:09:20 --> Language Class Initialized
INFO - 2020-02-03 13:09:20 --> Config Class Initialized
INFO - 2020-02-03 13:09:20 --> Loader Class Initialized
INFO - 2020-02-03 13:09:20 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:20 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:20 --> Controller Class Initialized
INFO - 2020-02-03 13:09:20 --> Config Class Initialized
INFO - 2020-02-03 13:09:21 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:21 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:21 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:21 --> URI Class Initialized
INFO - 2020-02-03 13:09:21 --> Router Class Initialized
INFO - 2020-02-03 13:09:21 --> Output Class Initialized
INFO - 2020-02-03 13:09:21 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:21 --> Input Class Initialized
INFO - 2020-02-03 13:09:21 --> Language Class Initialized
INFO - 2020-02-03 13:09:21 --> Language Class Initialized
INFO - 2020-02-03 13:09:21 --> Config Class Initialized
INFO - 2020-02-03 13:09:21 --> Loader Class Initialized
INFO - 2020-02-03 13:09:21 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:21 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:21 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:21 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:21 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:09:21 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:21 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:21 --> Total execution time: 0.5097
INFO - 2020-02-03 13:09:25 --> Config Class Initialized
INFO - 2020-02-03 13:09:26 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:26 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:26 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:26 --> URI Class Initialized
INFO - 2020-02-03 13:09:26 --> Router Class Initialized
INFO - 2020-02-03 13:09:26 --> Output Class Initialized
INFO - 2020-02-03 13:09:26 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:26 --> Input Class Initialized
INFO - 2020-02-03 13:09:26 --> Language Class Initialized
INFO - 2020-02-03 13:09:26 --> Language Class Initialized
INFO - 2020-02-03 13:09:26 --> Config Class Initialized
INFO - 2020-02-03 13:09:26 --> Loader Class Initialized
INFO - 2020-02-03 13:09:26 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:26 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:26 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:26 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:26 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:26 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:09:26 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:26 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:26 --> Total execution time: 0.5471
INFO - 2020-02-03 13:09:43 --> Config Class Initialized
INFO - 2020-02-03 13:09:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:44 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:44 --> URI Class Initialized
INFO - 2020-02-03 13:09:44 --> Router Class Initialized
INFO - 2020-02-03 13:09:44 --> Output Class Initialized
INFO - 2020-02-03 13:09:44 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:44 --> Input Class Initialized
INFO - 2020-02-03 13:09:44 --> Language Class Initialized
INFO - 2020-02-03 13:09:44 --> Language Class Initialized
INFO - 2020-02-03 13:09:44 --> Config Class Initialized
INFO - 2020-02-03 13:09:44 --> Loader Class Initialized
INFO - 2020-02-03 13:09:44 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:44 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:44 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:44 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:44 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:44 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:09:44 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:44 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:44 --> Total execution time: 0.5877
INFO - 2020-02-03 13:09:44 --> Config Class Initialized
INFO - 2020-02-03 13:09:44 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:44 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:44 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:44 --> URI Class Initialized
INFO - 2020-02-03 13:09:44 --> Router Class Initialized
INFO - 2020-02-03 13:09:44 --> Output Class Initialized
INFO - 2020-02-03 13:09:44 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:45 --> Input Class Initialized
INFO - 2020-02-03 13:09:45 --> Language Class Initialized
INFO - 2020-02-03 13:09:45 --> Language Class Initialized
INFO - 2020-02-03 13:09:45 --> Config Class Initialized
INFO - 2020-02-03 13:09:45 --> Loader Class Initialized
INFO - 2020-02-03 13:09:45 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:45 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:45 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:45 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:45 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:45 --> Controller Class Initialized
INFO - 2020-02-03 13:09:49 --> Config Class Initialized
INFO - 2020-02-03 13:09:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:49 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:49 --> URI Class Initialized
INFO - 2020-02-03 13:09:49 --> Router Class Initialized
INFO - 2020-02-03 13:09:49 --> Output Class Initialized
INFO - 2020-02-03 13:09:49 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:49 --> Input Class Initialized
INFO - 2020-02-03 13:09:49 --> Language Class Initialized
INFO - 2020-02-03 13:09:49 --> Language Class Initialized
INFO - 2020-02-03 13:09:49 --> Config Class Initialized
INFO - 2020-02-03 13:09:49 --> Loader Class Initialized
INFO - 2020-02-03 13:09:49 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:49 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:49 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:49 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:49 --> Controller Class Initialized
INFO - 2020-02-03 13:09:49 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:49 --> Total execution time: 0.5143
INFO - 2020-02-03 13:09:49 --> Config Class Initialized
INFO - 2020-02-03 13:09:49 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:49 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:49 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:49 --> URI Class Initialized
INFO - 2020-02-03 13:09:49 --> Router Class Initialized
INFO - 2020-02-03 13:09:49 --> Output Class Initialized
INFO - 2020-02-03 13:09:49 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:49 --> Input Class Initialized
INFO - 2020-02-03 13:09:50 --> Language Class Initialized
INFO - 2020-02-03 13:09:50 --> Language Class Initialized
INFO - 2020-02-03 13:09:50 --> Config Class Initialized
INFO - 2020-02-03 13:09:50 --> Loader Class Initialized
INFO - 2020-02-03 13:09:50 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:50 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:50 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:50 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:50 --> Controller Class Initialized
INFO - 2020-02-03 13:09:54 --> Config Class Initialized
INFO - 2020-02-03 13:09:54 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:54 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:54 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:54 --> URI Class Initialized
INFO - 2020-02-03 13:09:54 --> Router Class Initialized
INFO - 2020-02-03 13:09:54 --> Output Class Initialized
INFO - 2020-02-03 13:09:54 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:54 --> Input Class Initialized
INFO - 2020-02-03 13:09:54 --> Language Class Initialized
INFO - 2020-02-03 13:09:55 --> Language Class Initialized
INFO - 2020-02-03 13:09:55 --> Config Class Initialized
INFO - 2020-02-03 13:09:55 --> Loader Class Initialized
INFO - 2020-02-03 13:09:55 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:55 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:55 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:55 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:55 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:09:55 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:55 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:55 --> Total execution time: 0.5678
INFO - 2020-02-03 13:09:56 --> Config Class Initialized
INFO - 2020-02-03 13:09:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:09:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:09:56 --> Utf8 Class Initialized
INFO - 2020-02-03 13:09:56 --> URI Class Initialized
INFO - 2020-02-03 13:09:56 --> Router Class Initialized
INFO - 2020-02-03 13:09:56 --> Output Class Initialized
INFO - 2020-02-03 13:09:56 --> Security Class Initialized
DEBUG - 2020-02-03 13:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:09:56 --> Input Class Initialized
INFO - 2020-02-03 13:09:56 --> Language Class Initialized
INFO - 2020-02-03 13:09:56 --> Language Class Initialized
INFO - 2020-02-03 13:09:56 --> Config Class Initialized
INFO - 2020-02-03 13:09:56 --> Loader Class Initialized
INFO - 2020-02-03 13:09:56 --> Helper loaded: url_helper
INFO - 2020-02-03 13:09:56 --> Helper loaded: file_helper
INFO - 2020-02-03 13:09:56 --> Helper loaded: form_helper
INFO - 2020-02-03 13:09:56 --> Helper loaded: my_helper
INFO - 2020-02-03 13:09:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:09:56 --> Controller Class Initialized
DEBUG - 2020-02-03 13:09:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:09:57 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:09:57 --> Final output sent to browser
DEBUG - 2020-02-03 13:09:57 --> Total execution time: 0.6209
INFO - 2020-02-03 13:10:30 --> Config Class Initialized
INFO - 2020-02-03 13:10:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:10:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:10:30 --> Utf8 Class Initialized
INFO - 2020-02-03 13:10:30 --> URI Class Initialized
INFO - 2020-02-03 13:10:30 --> Router Class Initialized
INFO - 2020-02-03 13:10:30 --> Output Class Initialized
INFO - 2020-02-03 13:10:30 --> Security Class Initialized
DEBUG - 2020-02-03 13:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:10:31 --> Input Class Initialized
INFO - 2020-02-03 13:10:31 --> Language Class Initialized
INFO - 2020-02-03 13:10:31 --> Language Class Initialized
INFO - 2020-02-03 13:10:31 --> Config Class Initialized
INFO - 2020-02-03 13:10:31 --> Loader Class Initialized
INFO - 2020-02-03 13:10:31 --> Helper loaded: url_helper
INFO - 2020-02-03 13:10:31 --> Helper loaded: file_helper
INFO - 2020-02-03 13:10:31 --> Helper loaded: form_helper
INFO - 2020-02-03 13:10:31 --> Helper loaded: my_helper
INFO - 2020-02-03 13:10:31 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:10:31 --> Controller Class Initialized
DEBUG - 2020-02-03 13:10:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:10:31 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:10:31 --> Final output sent to browser
DEBUG - 2020-02-03 13:10:31 --> Total execution time: 0.6062
INFO - 2020-02-03 13:18:12 --> Config Class Initialized
INFO - 2020-02-03 13:18:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:18:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:18:12 --> Utf8 Class Initialized
INFO - 2020-02-03 13:18:12 --> URI Class Initialized
INFO - 2020-02-03 13:18:12 --> Router Class Initialized
INFO - 2020-02-03 13:18:12 --> Output Class Initialized
INFO - 2020-02-03 13:18:12 --> Security Class Initialized
DEBUG - 2020-02-03 13:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:18:12 --> Input Class Initialized
INFO - 2020-02-03 13:18:13 --> Language Class Initialized
INFO - 2020-02-03 13:18:13 --> Language Class Initialized
INFO - 2020-02-03 13:18:13 --> Config Class Initialized
INFO - 2020-02-03 13:18:13 --> Loader Class Initialized
INFO - 2020-02-03 13:18:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:18:13 --> Helper loaded: file_helper
INFO - 2020-02-03 13:18:13 --> Helper loaded: form_helper
INFO - 2020-02-03 13:18:13 --> Helper loaded: my_helper
INFO - 2020-02-03 13:18:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:18:13 --> Controller Class Initialized
DEBUG - 2020-02-03 13:18:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:18:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:18:13 --> Final output sent to browser
DEBUG - 2020-02-03 13:18:13 --> Total execution time: 0.5968
INFO - 2020-02-03 13:19:50 --> Config Class Initialized
INFO - 2020-02-03 13:19:50 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:50 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:50 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:50 --> URI Class Initialized
INFO - 2020-02-03 13:19:50 --> Router Class Initialized
INFO - 2020-02-03 13:19:50 --> Output Class Initialized
INFO - 2020-02-03 13:19:50 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:50 --> Input Class Initialized
INFO - 2020-02-03 13:19:50 --> Language Class Initialized
INFO - 2020-02-03 13:19:50 --> Language Class Initialized
INFO - 2020-02-03 13:19:50 --> Config Class Initialized
INFO - 2020-02-03 13:19:50 --> Loader Class Initialized
INFO - 2020-02-03 13:19:50 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:50 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:50 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:50 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:50 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:50 --> Controller Class Initialized
DEBUG - 2020-02-03 13:19:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:19:50 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:19:50 --> Final output sent to browser
DEBUG - 2020-02-03 13:19:51 --> Total execution time: 0.6015
INFO - 2020-02-03 13:19:51 --> Config Class Initialized
INFO - 2020-02-03 13:19:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:51 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:51 --> URI Class Initialized
INFO - 2020-02-03 13:19:51 --> Router Class Initialized
INFO - 2020-02-03 13:19:51 --> Output Class Initialized
INFO - 2020-02-03 13:19:51 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:51 --> Input Class Initialized
INFO - 2020-02-03 13:19:51 --> Language Class Initialized
INFO - 2020-02-03 13:19:51 --> Language Class Initialized
INFO - 2020-02-03 13:19:51 --> Config Class Initialized
INFO - 2020-02-03 13:19:51 --> Loader Class Initialized
INFO - 2020-02-03 13:19:51 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:51 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:51 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:51 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:51 --> Controller Class Initialized
INFO - 2020-02-03 13:19:54 --> Config Class Initialized
INFO - 2020-02-03 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:54 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:54 --> URI Class Initialized
INFO - 2020-02-03 13:19:54 --> Router Class Initialized
INFO - 2020-02-03 13:19:54 --> Output Class Initialized
INFO - 2020-02-03 13:19:54 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:54 --> Input Class Initialized
INFO - 2020-02-03 13:19:54 --> Language Class Initialized
INFO - 2020-02-03 13:19:54 --> Language Class Initialized
INFO - 2020-02-03 13:19:54 --> Config Class Initialized
INFO - 2020-02-03 13:19:54 --> Loader Class Initialized
INFO - 2020-02-03 13:19:54 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:54 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:54 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:54 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:54 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:54 --> Controller Class Initialized
INFO - 2020-02-03 13:19:54 --> Final output sent to browser
DEBUG - 2020-02-03 13:19:54 --> Total execution time: 0.4636
INFO - 2020-02-03 13:19:54 --> Config Class Initialized
INFO - 2020-02-03 13:19:54 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:54 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:54 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:54 --> URI Class Initialized
INFO - 2020-02-03 13:19:54 --> Router Class Initialized
INFO - 2020-02-03 13:19:54 --> Output Class Initialized
INFO - 2020-02-03 13:19:54 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:54 --> Input Class Initialized
INFO - 2020-02-03 13:19:54 --> Language Class Initialized
INFO - 2020-02-03 13:19:54 --> Language Class Initialized
INFO - 2020-02-03 13:19:54 --> Config Class Initialized
INFO - 2020-02-03 13:19:54 --> Loader Class Initialized
INFO - 2020-02-03 13:19:55 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:55 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:55 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:55 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:55 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:55 --> Controller Class Initialized
INFO - 2020-02-03 13:19:57 --> Config Class Initialized
INFO - 2020-02-03 13:19:57 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:57 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:57 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:57 --> URI Class Initialized
INFO - 2020-02-03 13:19:57 --> Router Class Initialized
INFO - 2020-02-03 13:19:57 --> Output Class Initialized
INFO - 2020-02-03 13:19:57 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:57 --> Input Class Initialized
INFO - 2020-02-03 13:19:57 --> Language Class Initialized
INFO - 2020-02-03 13:19:57 --> Language Class Initialized
INFO - 2020-02-03 13:19:58 --> Config Class Initialized
INFO - 2020-02-03 13:19:58 --> Loader Class Initialized
INFO - 2020-02-03 13:19:58 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:58 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:58 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:58 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:58 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:58 --> Controller Class Initialized
DEBUG - 2020-02-03 13:19:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:19:58 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:19:58 --> Final output sent to browser
DEBUG - 2020-02-03 13:19:58 --> Total execution time: 0.6154
INFO - 2020-02-03 13:19:59 --> Config Class Initialized
INFO - 2020-02-03 13:19:59 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:19:59 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:19:59 --> Utf8 Class Initialized
INFO - 2020-02-03 13:19:59 --> URI Class Initialized
INFO - 2020-02-03 13:19:59 --> Router Class Initialized
INFO - 2020-02-03 13:19:59 --> Output Class Initialized
INFO - 2020-02-03 13:19:59 --> Security Class Initialized
DEBUG - 2020-02-03 13:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:19:59 --> Input Class Initialized
INFO - 2020-02-03 13:19:59 --> Language Class Initialized
INFO - 2020-02-03 13:19:59 --> Language Class Initialized
INFO - 2020-02-03 13:19:59 --> Config Class Initialized
INFO - 2020-02-03 13:19:59 --> Loader Class Initialized
INFO - 2020-02-03 13:19:59 --> Helper loaded: url_helper
INFO - 2020-02-03 13:19:59 --> Helper loaded: file_helper
INFO - 2020-02-03 13:19:59 --> Helper loaded: form_helper
INFO - 2020-02-03 13:19:59 --> Helper loaded: my_helper
INFO - 2020-02-03 13:19:59 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:19:59 --> Controller Class Initialized
DEBUG - 2020-02-03 13:19:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:19:59 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:19:59 --> Final output sent to browser
DEBUG - 2020-02-03 13:19:59 --> Total execution time: 0.5456
INFO - 2020-02-03 13:21:45 --> Config Class Initialized
INFO - 2020-02-03 13:21:45 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:21:45 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:21:45 --> Utf8 Class Initialized
INFO - 2020-02-03 13:21:45 --> URI Class Initialized
INFO - 2020-02-03 13:21:45 --> Router Class Initialized
INFO - 2020-02-03 13:21:45 --> Output Class Initialized
INFO - 2020-02-03 13:21:45 --> Security Class Initialized
DEBUG - 2020-02-03 13:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:21:45 --> Input Class Initialized
INFO - 2020-02-03 13:21:45 --> Language Class Initialized
INFO - 2020-02-03 13:21:45 --> Language Class Initialized
INFO - 2020-02-03 13:21:45 --> Config Class Initialized
INFO - 2020-02-03 13:21:46 --> Loader Class Initialized
INFO - 2020-02-03 13:21:46 --> Helper loaded: url_helper
INFO - 2020-02-03 13:21:46 --> Helper loaded: file_helper
INFO - 2020-02-03 13:21:46 --> Helper loaded: form_helper
INFO - 2020-02-03 13:21:46 --> Helper loaded: my_helper
INFO - 2020-02-03 13:21:46 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:21:46 --> Controller Class Initialized
DEBUG - 2020-02-03 13:21:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:21:46 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:21:46 --> Final output sent to browser
DEBUG - 2020-02-03 13:21:46 --> Total execution time: 0.6267
INFO - 2020-02-03 13:24:51 --> Config Class Initialized
INFO - 2020-02-03 13:24:51 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:24:51 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:24:51 --> Utf8 Class Initialized
INFO - 2020-02-03 13:24:51 --> URI Class Initialized
INFO - 2020-02-03 13:24:51 --> Router Class Initialized
INFO - 2020-02-03 13:24:51 --> Output Class Initialized
INFO - 2020-02-03 13:24:51 --> Security Class Initialized
DEBUG - 2020-02-03 13:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:24:51 --> Input Class Initialized
INFO - 2020-02-03 13:24:51 --> Language Class Initialized
INFO - 2020-02-03 13:24:51 --> Language Class Initialized
INFO - 2020-02-03 13:24:51 --> Config Class Initialized
INFO - 2020-02-03 13:24:51 --> Loader Class Initialized
INFO - 2020-02-03 13:24:51 --> Helper loaded: url_helper
INFO - 2020-02-03 13:24:51 --> Helper loaded: file_helper
INFO - 2020-02-03 13:24:51 --> Helper loaded: form_helper
INFO - 2020-02-03 13:24:51 --> Helper loaded: my_helper
INFO - 2020-02-03 13:24:51 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:24:51 --> Controller Class Initialized
DEBUG - 2020-02-03 13:24:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_walikelas/views/list.php
DEBUG - 2020-02-03 13:24:51 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:24:51 --> Final output sent to browser
DEBUG - 2020-02-03 13:24:51 --> Total execution time: 0.5470
INFO - 2020-02-03 13:24:52 --> Config Class Initialized
INFO - 2020-02-03 13:24:52 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:24:52 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:24:52 --> Utf8 Class Initialized
INFO - 2020-02-03 13:24:52 --> URI Class Initialized
INFO - 2020-02-03 13:24:52 --> Router Class Initialized
INFO - 2020-02-03 13:24:52 --> Output Class Initialized
INFO - 2020-02-03 13:24:52 --> Security Class Initialized
DEBUG - 2020-02-03 13:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:24:52 --> Input Class Initialized
INFO - 2020-02-03 13:24:52 --> Language Class Initialized
INFO - 2020-02-03 13:24:52 --> Language Class Initialized
INFO - 2020-02-03 13:24:52 --> Config Class Initialized
INFO - 2020-02-03 13:24:52 --> Loader Class Initialized
INFO - 2020-02-03 13:24:52 --> Helper loaded: url_helper
INFO - 2020-02-03 13:24:52 --> Helper loaded: file_helper
INFO - 2020-02-03 13:24:52 --> Helper loaded: form_helper
INFO - 2020-02-03 13:24:52 --> Helper loaded: my_helper
INFO - 2020-02-03 13:24:52 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:24:52 --> Controller Class Initialized
INFO - 2020-02-03 13:24:55 --> Config Class Initialized
INFO - 2020-02-03 13:24:55 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:24:55 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:24:55 --> Utf8 Class Initialized
INFO - 2020-02-03 13:24:55 --> URI Class Initialized
INFO - 2020-02-03 13:24:55 --> Router Class Initialized
INFO - 2020-02-03 13:24:55 --> Output Class Initialized
INFO - 2020-02-03 13:24:55 --> Security Class Initialized
DEBUG - 2020-02-03 13:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:24:55 --> Input Class Initialized
INFO - 2020-02-03 13:24:56 --> Language Class Initialized
INFO - 2020-02-03 13:24:56 --> Language Class Initialized
INFO - 2020-02-03 13:24:56 --> Config Class Initialized
INFO - 2020-02-03 13:24:56 --> Loader Class Initialized
INFO - 2020-02-03 13:24:56 --> Helper loaded: url_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: file_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: form_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: my_helper
INFO - 2020-02-03 13:24:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:24:56 --> Controller Class Initialized
DEBUG - 2020-02-03 13:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:24:56 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:24:56 --> Final output sent to browser
DEBUG - 2020-02-03 13:24:56 --> Total execution time: 0.5702
INFO - 2020-02-03 13:24:56 --> Config Class Initialized
INFO - 2020-02-03 13:24:56 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:24:56 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:24:56 --> Utf8 Class Initialized
INFO - 2020-02-03 13:24:56 --> URI Class Initialized
INFO - 2020-02-03 13:24:56 --> Router Class Initialized
INFO - 2020-02-03 13:24:56 --> Output Class Initialized
INFO - 2020-02-03 13:24:56 --> Security Class Initialized
DEBUG - 2020-02-03 13:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:24:56 --> Input Class Initialized
INFO - 2020-02-03 13:24:56 --> Language Class Initialized
INFO - 2020-02-03 13:24:56 --> Language Class Initialized
INFO - 2020-02-03 13:24:56 --> Config Class Initialized
INFO - 2020-02-03 13:24:56 --> Loader Class Initialized
INFO - 2020-02-03 13:24:56 --> Helper loaded: url_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: file_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: form_helper
INFO - 2020-02-03 13:24:56 --> Helper loaded: my_helper
INFO - 2020-02-03 13:24:56 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:24:57 --> Controller Class Initialized
INFO - 2020-02-03 13:25:09 --> Config Class Initialized
INFO - 2020-02-03 13:25:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:25:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:25:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:25:09 --> URI Class Initialized
INFO - 2020-02-03 13:25:09 --> Router Class Initialized
INFO - 2020-02-03 13:25:09 --> Output Class Initialized
INFO - 2020-02-03 13:25:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:25:09 --> Input Class Initialized
INFO - 2020-02-03 13:25:09 --> Language Class Initialized
INFO - 2020-02-03 13:25:09 --> Language Class Initialized
INFO - 2020-02-03 13:25:09 --> Config Class Initialized
INFO - 2020-02-03 13:25:09 --> Loader Class Initialized
INFO - 2020-02-03 13:25:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:25:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:25:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:25:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:25:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:25:09 --> Controller Class Initialized
INFO - 2020-02-03 13:25:09 --> Final output sent to browser
DEBUG - 2020-02-03 13:25:09 --> Total execution time: 0.5254
INFO - 2020-02-03 13:25:42 --> Config Class Initialized
INFO - 2020-02-03 13:25:42 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:25:42 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:25:42 --> Utf8 Class Initialized
INFO - 2020-02-03 13:25:42 --> URI Class Initialized
INFO - 2020-02-03 13:25:42 --> Router Class Initialized
INFO - 2020-02-03 13:25:42 --> Output Class Initialized
INFO - 2020-02-03 13:25:42 --> Security Class Initialized
DEBUG - 2020-02-03 13:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:25:42 --> Input Class Initialized
INFO - 2020-02-03 13:25:42 --> Language Class Initialized
INFO - 2020-02-03 13:25:42 --> Language Class Initialized
INFO - 2020-02-03 13:25:42 --> Config Class Initialized
INFO - 2020-02-03 13:25:42 --> Loader Class Initialized
INFO - 2020-02-03 13:25:42 --> Helper loaded: url_helper
INFO - 2020-02-03 13:25:42 --> Helper loaded: file_helper
INFO - 2020-02-03 13:25:42 --> Helper loaded: form_helper
INFO - 2020-02-03 13:25:42 --> Helper loaded: my_helper
INFO - 2020-02-03 13:25:42 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:25:42 --> Controller Class Initialized
INFO - 2020-02-03 13:25:42 --> Final output sent to browser
DEBUG - 2020-02-03 13:25:42 --> Total execution time: 0.5467
INFO - 2020-02-03 13:26:06 --> Config Class Initialized
INFO - 2020-02-03 13:26:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:06 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:06 --> URI Class Initialized
INFO - 2020-02-03 13:26:06 --> Router Class Initialized
INFO - 2020-02-03 13:26:06 --> Output Class Initialized
INFO - 2020-02-03 13:26:06 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:06 --> Input Class Initialized
INFO - 2020-02-03 13:26:06 --> Language Class Initialized
INFO - 2020-02-03 13:26:06 --> Language Class Initialized
INFO - 2020-02-03 13:26:06 --> Config Class Initialized
INFO - 2020-02-03 13:26:06 --> Loader Class Initialized
INFO - 2020-02-03 13:26:06 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:06 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:06 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:06 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:06 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:06 --> Controller Class Initialized
INFO - 2020-02-03 13:26:06 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:06 --> Total execution time: 0.5003
INFO - 2020-02-03 13:26:06 --> Config Class Initialized
INFO - 2020-02-03 13:26:06 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:06 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:06 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:06 --> URI Class Initialized
INFO - 2020-02-03 13:26:06 --> Router Class Initialized
INFO - 2020-02-03 13:26:06 --> Output Class Initialized
INFO - 2020-02-03 13:26:06 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:07 --> Input Class Initialized
INFO - 2020-02-03 13:26:07 --> Language Class Initialized
INFO - 2020-02-03 13:26:07 --> Language Class Initialized
INFO - 2020-02-03 13:26:07 --> Config Class Initialized
INFO - 2020-02-03 13:26:07 --> Loader Class Initialized
INFO - 2020-02-03 13:26:07 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:07 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:07 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:07 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:07 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:07 --> Controller Class Initialized
INFO - 2020-02-03 13:26:08 --> Config Class Initialized
INFO - 2020-02-03 13:26:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:09 --> URI Class Initialized
INFO - 2020-02-03 13:26:09 --> Router Class Initialized
INFO - 2020-02-03 13:26:09 --> Output Class Initialized
INFO - 2020-02-03 13:26:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:09 --> Input Class Initialized
INFO - 2020-02-03 13:26:09 --> Language Class Initialized
INFO - 2020-02-03 13:26:09 --> Language Class Initialized
INFO - 2020-02-03 13:26:09 --> Config Class Initialized
INFO - 2020-02-03 13:26:09 --> Loader Class Initialized
INFO - 2020-02-03 13:26:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:09 --> Controller Class Initialized
INFO - 2020-02-03 13:26:09 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:09 --> Total execution time: 0.4871
INFO - 2020-02-03 13:26:09 --> Config Class Initialized
INFO - 2020-02-03 13:26:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:09 --> URI Class Initialized
INFO - 2020-02-03 13:26:09 --> Router Class Initialized
INFO - 2020-02-03 13:26:09 --> Output Class Initialized
INFO - 2020-02-03 13:26:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:09 --> Input Class Initialized
INFO - 2020-02-03 13:26:09 --> Language Class Initialized
INFO - 2020-02-03 13:26:09 --> Language Class Initialized
INFO - 2020-02-03 13:26:09 --> Config Class Initialized
INFO - 2020-02-03 13:26:09 --> Loader Class Initialized
INFO - 2020-02-03 13:26:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:10 --> Controller Class Initialized
INFO - 2020-02-03 13:26:12 --> Config Class Initialized
INFO - 2020-02-03 13:26:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:12 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:12 --> URI Class Initialized
INFO - 2020-02-03 13:26:12 --> Router Class Initialized
INFO - 2020-02-03 13:26:12 --> Output Class Initialized
INFO - 2020-02-03 13:26:12 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:12 --> Input Class Initialized
INFO - 2020-02-03 13:26:13 --> Language Class Initialized
INFO - 2020-02-03 13:26:13 --> Language Class Initialized
INFO - 2020-02-03 13:26:13 --> Config Class Initialized
INFO - 2020-02-03 13:26:13 --> Loader Class Initialized
INFO - 2020-02-03 13:26:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:13 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:13 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:13 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:13 --> Controller Class Initialized
DEBUG - 2020-02-03 13:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:26:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:26:13 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:13 --> Total execution time: 0.6618
INFO - 2020-02-03 13:26:13 --> Config Class Initialized
INFO - 2020-02-03 13:26:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:13 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:13 --> URI Class Initialized
INFO - 2020-02-03 13:26:13 --> Router Class Initialized
INFO - 2020-02-03 13:26:13 --> Output Class Initialized
INFO - 2020-02-03 13:26:13 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:13 --> Input Class Initialized
INFO - 2020-02-03 13:26:13 --> Language Class Initialized
INFO - 2020-02-03 13:26:13 --> Language Class Initialized
INFO - 2020-02-03 13:26:13 --> Config Class Initialized
INFO - 2020-02-03 13:26:13 --> Loader Class Initialized
INFO - 2020-02-03 13:26:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:14 --> Controller Class Initialized
INFO - 2020-02-03 13:26:14 --> Config Class Initialized
INFO - 2020-02-03 13:26:14 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:14 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:14 --> URI Class Initialized
INFO - 2020-02-03 13:26:14 --> Router Class Initialized
INFO - 2020-02-03 13:26:14 --> Output Class Initialized
INFO - 2020-02-03 13:26:14 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:14 --> Input Class Initialized
INFO - 2020-02-03 13:26:14 --> Language Class Initialized
INFO - 2020-02-03 13:26:14 --> Language Class Initialized
INFO - 2020-02-03 13:26:14 --> Config Class Initialized
INFO - 2020-02-03 13:26:14 --> Loader Class Initialized
INFO - 2020-02-03 13:26:14 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:14 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:14 --> Controller Class Initialized
DEBUG - 2020-02-03 13:26:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:26:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:26:14 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:14 --> Total execution time: 0.6106
INFO - 2020-02-03 13:26:18 --> Config Class Initialized
INFO - 2020-02-03 13:26:18 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:18 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:18 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:18 --> URI Class Initialized
INFO - 2020-02-03 13:26:18 --> Router Class Initialized
INFO - 2020-02-03 13:26:18 --> Output Class Initialized
INFO - 2020-02-03 13:26:18 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:18 --> Input Class Initialized
INFO - 2020-02-03 13:26:19 --> Language Class Initialized
INFO - 2020-02-03 13:26:19 --> Language Class Initialized
INFO - 2020-02-03 13:26:19 --> Config Class Initialized
INFO - 2020-02-03 13:26:19 --> Loader Class Initialized
INFO - 2020-02-03 13:26:19 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:19 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:19 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:19 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:19 --> Controller Class Initialized
DEBUG - 2020-02-03 13:26:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:26:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:26:19 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:19 --> Total execution time: 0.5696
INFO - 2020-02-03 13:26:22 --> Config Class Initialized
INFO - 2020-02-03 13:26:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:23 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:23 --> URI Class Initialized
INFO - 2020-02-03 13:26:23 --> Router Class Initialized
INFO - 2020-02-03 13:26:23 --> Output Class Initialized
INFO - 2020-02-03 13:26:23 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:23 --> Input Class Initialized
INFO - 2020-02-03 13:26:23 --> Language Class Initialized
INFO - 2020-02-03 13:26:23 --> Language Class Initialized
INFO - 2020-02-03 13:26:23 --> Config Class Initialized
INFO - 2020-02-03 13:26:23 --> Loader Class Initialized
INFO - 2020-02-03 13:26:23 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:23 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:23 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:23 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:23 --> Controller Class Initialized
DEBUG - 2020-02-03 13:26:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:26:23 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:26:23 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:23 --> Total execution time: 0.6244
INFO - 2020-02-03 13:26:47 --> Config Class Initialized
INFO - 2020-02-03 13:26:47 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:26:47 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:26:47 --> Utf8 Class Initialized
INFO - 2020-02-03 13:26:47 --> URI Class Initialized
INFO - 2020-02-03 13:26:47 --> Router Class Initialized
INFO - 2020-02-03 13:26:47 --> Output Class Initialized
INFO - 2020-02-03 13:26:47 --> Security Class Initialized
DEBUG - 2020-02-03 13:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:26:48 --> Input Class Initialized
INFO - 2020-02-03 13:26:48 --> Language Class Initialized
INFO - 2020-02-03 13:26:48 --> Language Class Initialized
INFO - 2020-02-03 13:26:48 --> Config Class Initialized
INFO - 2020-02-03 13:26:48 --> Loader Class Initialized
INFO - 2020-02-03 13:26:48 --> Helper loaded: url_helper
INFO - 2020-02-03 13:26:48 --> Helper loaded: file_helper
INFO - 2020-02-03 13:26:48 --> Helper loaded: form_helper
INFO - 2020-02-03 13:26:48 --> Helper loaded: my_helper
INFO - 2020-02-03 13:26:48 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:26:48 --> Controller Class Initialized
DEBUG - 2020-02-03 13:26:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:26:48 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:26:48 --> Final output sent to browser
DEBUG - 2020-02-03 13:26:48 --> Total execution time: 0.5450
INFO - 2020-02-03 13:29:02 --> Config Class Initialized
INFO - 2020-02-03 13:29:02 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:02 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:02 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:02 --> URI Class Initialized
INFO - 2020-02-03 13:29:02 --> Router Class Initialized
INFO - 2020-02-03 13:29:02 --> Output Class Initialized
INFO - 2020-02-03 13:29:02 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:02 --> Input Class Initialized
INFO - 2020-02-03 13:29:02 --> Language Class Initialized
INFO - 2020-02-03 13:29:02 --> Language Class Initialized
INFO - 2020-02-03 13:29:02 --> Config Class Initialized
INFO - 2020-02-03 13:29:02 --> Loader Class Initialized
INFO - 2020-02-03 13:29:02 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:02 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:02 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:02 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:02 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:02 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:29:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:03 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:03 --> Total execution time: 0.6140
INFO - 2020-02-03 13:29:03 --> Config Class Initialized
INFO - 2020-02-03 13:29:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:03 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:03 --> URI Class Initialized
INFO - 2020-02-03 13:29:03 --> Router Class Initialized
INFO - 2020-02-03 13:29:03 --> Output Class Initialized
INFO - 2020-02-03 13:29:03 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:03 --> Input Class Initialized
INFO - 2020-02-03 13:29:03 --> Language Class Initialized
INFO - 2020-02-03 13:29:03 --> Language Class Initialized
INFO - 2020-02-03 13:29:03 --> Config Class Initialized
INFO - 2020-02-03 13:29:03 --> Loader Class Initialized
INFO - 2020-02-03 13:29:03 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:03 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:03 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:03 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:03 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:03 --> Controller Class Initialized
INFO - 2020-02-03 13:29:08 --> Config Class Initialized
INFO - 2020-02-03 13:29:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:08 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:08 --> URI Class Initialized
INFO - 2020-02-03 13:29:08 --> Router Class Initialized
INFO - 2020-02-03 13:29:08 --> Output Class Initialized
INFO - 2020-02-03 13:29:08 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:08 --> Input Class Initialized
INFO - 2020-02-03 13:29:08 --> Language Class Initialized
INFO - 2020-02-03 13:29:08 --> Language Class Initialized
INFO - 2020-02-03 13:29:08 --> Config Class Initialized
INFO - 2020-02-03 13:29:08 --> Loader Class Initialized
INFO - 2020-02-03 13:29:08 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:08 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:08 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:08 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:08 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:08 --> Controller Class Initialized
INFO - 2020-02-03 13:29:08 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:08 --> Total execution time: 0.4687
INFO - 2020-02-03 13:29:08 --> Config Class Initialized
INFO - 2020-02-03 13:29:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:08 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:08 --> URI Class Initialized
INFO - 2020-02-03 13:29:09 --> Router Class Initialized
INFO - 2020-02-03 13:29:09 --> Output Class Initialized
INFO - 2020-02-03 13:29:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:09 --> Input Class Initialized
INFO - 2020-02-03 13:29:09 --> Language Class Initialized
INFO - 2020-02-03 13:29:09 --> Language Class Initialized
INFO - 2020-02-03 13:29:09 --> Config Class Initialized
INFO - 2020-02-03 13:29:09 --> Loader Class Initialized
INFO - 2020-02-03 13:29:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:09 --> Controller Class Initialized
INFO - 2020-02-03 13:29:10 --> Config Class Initialized
INFO - 2020-02-03 13:29:10 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:10 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:10 --> URI Class Initialized
INFO - 2020-02-03 13:29:10 --> Router Class Initialized
INFO - 2020-02-03 13:29:10 --> Output Class Initialized
INFO - 2020-02-03 13:29:10 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:10 --> Input Class Initialized
INFO - 2020-02-03 13:29:10 --> Language Class Initialized
INFO - 2020-02-03 13:29:10 --> Language Class Initialized
INFO - 2020-02-03 13:29:10 --> Config Class Initialized
INFO - 2020-02-03 13:29:11 --> Loader Class Initialized
INFO - 2020-02-03 13:29:11 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:11 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:29:11 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:11 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:11 --> Total execution time: 0.6275
INFO - 2020-02-03 13:29:11 --> Config Class Initialized
INFO - 2020-02-03 13:29:11 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:11 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:11 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:11 --> URI Class Initialized
INFO - 2020-02-03 13:29:11 --> Router Class Initialized
INFO - 2020-02-03 13:29:11 --> Output Class Initialized
INFO - 2020-02-03 13:29:11 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:11 --> Input Class Initialized
INFO - 2020-02-03 13:29:11 --> Language Class Initialized
INFO - 2020-02-03 13:29:11 --> Language Class Initialized
INFO - 2020-02-03 13:29:11 --> Config Class Initialized
INFO - 2020-02-03 13:29:11 --> Loader Class Initialized
INFO - 2020-02-03 13:29:11 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:11 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:11 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:12 --> Controller Class Initialized
INFO - 2020-02-03 13:29:12 --> Config Class Initialized
INFO - 2020-02-03 13:29:12 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:12 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:12 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:12 --> URI Class Initialized
INFO - 2020-02-03 13:29:12 --> Router Class Initialized
INFO - 2020-02-03 13:29:12 --> Output Class Initialized
INFO - 2020-02-03 13:29:13 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:13 --> Input Class Initialized
INFO - 2020-02-03 13:29:13 --> Language Class Initialized
INFO - 2020-02-03 13:29:13 --> Language Class Initialized
INFO - 2020-02-03 13:29:13 --> Config Class Initialized
INFO - 2020-02-03 13:29:13 --> Loader Class Initialized
INFO - 2020-02-03 13:29:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:13 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:13 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:13 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:13 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:29:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:13 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:13 --> Total execution time: 0.6225
INFO - 2020-02-03 13:29:19 --> Config Class Initialized
INFO - 2020-02-03 13:29:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:19 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:19 --> URI Class Initialized
INFO - 2020-02-03 13:29:19 --> Router Class Initialized
INFO - 2020-02-03 13:29:19 --> Output Class Initialized
INFO - 2020-02-03 13:29:19 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:19 --> Input Class Initialized
INFO - 2020-02-03 13:29:19 --> Language Class Initialized
INFO - 2020-02-03 13:29:19 --> Language Class Initialized
INFO - 2020-02-03 13:29:19 --> Config Class Initialized
INFO - 2020-02-03 13:29:19 --> Loader Class Initialized
INFO - 2020-02-03 13:29:19 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:19 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:19 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:19 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:19 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:29:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:19 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:19 --> Total execution time: 0.5594
INFO - 2020-02-03 13:29:20 --> Config Class Initialized
INFO - 2020-02-03 13:29:20 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:20 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:20 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:20 --> URI Class Initialized
INFO - 2020-02-03 13:29:20 --> Router Class Initialized
INFO - 2020-02-03 13:29:20 --> Output Class Initialized
INFO - 2020-02-03 13:29:20 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:20 --> Input Class Initialized
INFO - 2020-02-03 13:29:20 --> Language Class Initialized
INFO - 2020-02-03 13:29:20 --> Language Class Initialized
INFO - 2020-02-03 13:29:20 --> Config Class Initialized
INFO - 2020-02-03 13:29:20 --> Loader Class Initialized
INFO - 2020-02-03 13:29:20 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:20 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:20 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:20 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:20 --> Controller Class Initialized
INFO - 2020-02-03 13:29:21 --> Config Class Initialized
INFO - 2020-02-03 13:29:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:22 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:22 --> URI Class Initialized
INFO - 2020-02-03 13:29:22 --> Router Class Initialized
INFO - 2020-02-03 13:29:22 --> Output Class Initialized
INFO - 2020-02-03 13:29:22 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:22 --> Input Class Initialized
INFO - 2020-02-03 13:29:22 --> Language Class Initialized
INFO - 2020-02-03 13:29:22 --> Language Class Initialized
INFO - 2020-02-03 13:29:22 --> Config Class Initialized
INFO - 2020-02-03 13:29:22 --> Loader Class Initialized
INFO - 2020-02-03 13:29:22 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:22 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:22 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:22 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:22 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:22 --> Controller Class Initialized
INFO - 2020-02-03 13:29:22 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:22 --> Total execution time: 0.5332
INFO - 2020-02-03 13:29:22 --> Config Class Initialized
INFO - 2020-02-03 13:29:22 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:22 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:22 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:22 --> URI Class Initialized
INFO - 2020-02-03 13:29:22 --> Router Class Initialized
INFO - 2020-02-03 13:29:22 --> Output Class Initialized
INFO - 2020-02-03 13:29:22 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:22 --> Input Class Initialized
INFO - 2020-02-03 13:29:22 --> Language Class Initialized
INFO - 2020-02-03 13:29:22 --> Language Class Initialized
INFO - 2020-02-03 13:29:22 --> Config Class Initialized
INFO - 2020-02-03 13:29:23 --> Loader Class Initialized
INFO - 2020-02-03 13:29:23 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:23 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:23 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:23 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:23 --> Controller Class Initialized
INFO - 2020-02-03 13:29:24 --> Config Class Initialized
INFO - 2020-02-03 13:29:24 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:24 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:24 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:24 --> URI Class Initialized
INFO - 2020-02-03 13:29:24 --> Router Class Initialized
INFO - 2020-02-03 13:29:24 --> Output Class Initialized
INFO - 2020-02-03 13:29:24 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:24 --> Input Class Initialized
INFO - 2020-02-03 13:29:24 --> Language Class Initialized
INFO - 2020-02-03 13:29:24 --> Language Class Initialized
INFO - 2020-02-03 13:29:24 --> Config Class Initialized
INFO - 2020-02-03 13:29:24 --> Loader Class Initialized
INFO - 2020-02-03 13:29:24 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:24 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:24 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:24 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:24 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:24 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:29:24 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:24 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:24 --> Total execution time: 0.5674
INFO - 2020-02-03 13:29:24 --> Config Class Initialized
INFO - 2020-02-03 13:29:24 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:24 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:24 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:24 --> URI Class Initialized
INFO - 2020-02-03 13:29:24 --> Router Class Initialized
INFO - 2020-02-03 13:29:24 --> Output Class Initialized
INFO - 2020-02-03 13:29:24 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:25 --> Input Class Initialized
INFO - 2020-02-03 13:29:25 --> Language Class Initialized
INFO - 2020-02-03 13:29:25 --> Language Class Initialized
INFO - 2020-02-03 13:29:25 --> Config Class Initialized
INFO - 2020-02-03 13:29:25 --> Loader Class Initialized
INFO - 2020-02-03 13:29:25 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:25 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:25 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:25 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:25 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:25 --> Controller Class Initialized
INFO - 2020-02-03 13:29:30 --> Config Class Initialized
INFO - 2020-02-03 13:29:30 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:30 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:30 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:30 --> URI Class Initialized
INFO - 2020-02-03 13:29:30 --> Router Class Initialized
INFO - 2020-02-03 13:29:30 --> Output Class Initialized
INFO - 2020-02-03 13:29:30 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:30 --> Input Class Initialized
INFO - 2020-02-03 13:29:30 --> Language Class Initialized
INFO - 2020-02-03 13:29:30 --> Language Class Initialized
INFO - 2020-02-03 13:29:30 --> Config Class Initialized
INFO - 2020-02-03 13:29:30 --> Loader Class Initialized
INFO - 2020-02-03 13:29:30 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:30 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:30 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:30 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:30 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:30 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:29:30 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:30 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:30 --> Total execution time: 0.5347
INFO - 2020-02-03 13:29:32 --> Config Class Initialized
INFO - 2020-02-03 13:29:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:29:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:29:32 --> Utf8 Class Initialized
INFO - 2020-02-03 13:29:32 --> URI Class Initialized
INFO - 2020-02-03 13:29:32 --> Router Class Initialized
INFO - 2020-02-03 13:29:32 --> Output Class Initialized
INFO - 2020-02-03 13:29:32 --> Security Class Initialized
DEBUG - 2020-02-03 13:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:29:32 --> Input Class Initialized
INFO - 2020-02-03 13:29:32 --> Language Class Initialized
INFO - 2020-02-03 13:29:32 --> Language Class Initialized
INFO - 2020-02-03 13:29:32 --> Config Class Initialized
INFO - 2020-02-03 13:29:32 --> Loader Class Initialized
INFO - 2020-02-03 13:29:32 --> Helper loaded: url_helper
INFO - 2020-02-03 13:29:32 --> Helper loaded: file_helper
INFO - 2020-02-03 13:29:32 --> Helper loaded: form_helper
INFO - 2020-02-03 13:29:32 --> Helper loaded: my_helper
INFO - 2020-02-03 13:29:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:29:32 --> Controller Class Initialized
DEBUG - 2020-02-03 13:29:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:29:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:29:32 --> Final output sent to browser
DEBUG - 2020-02-03 13:29:32 --> Total execution time: 0.5893
INFO - 2020-02-03 13:35:37 --> Config Class Initialized
INFO - 2020-02-03 13:35:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:35:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:35:37 --> Utf8 Class Initialized
INFO - 2020-02-03 13:35:37 --> URI Class Initialized
INFO - 2020-02-03 13:35:37 --> Router Class Initialized
INFO - 2020-02-03 13:35:37 --> Output Class Initialized
INFO - 2020-02-03 13:35:37 --> Security Class Initialized
DEBUG - 2020-02-03 13:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:35:37 --> Input Class Initialized
INFO - 2020-02-03 13:35:37 --> Language Class Initialized
INFO - 2020-02-03 13:35:37 --> Language Class Initialized
INFO - 2020-02-03 13:35:37 --> Config Class Initialized
INFO - 2020-02-03 13:35:37 --> Loader Class Initialized
INFO - 2020-02-03 13:35:37 --> Helper loaded: url_helper
INFO - 2020-02-03 13:35:37 --> Helper loaded: file_helper
INFO - 2020-02-03 13:35:37 --> Helper loaded: form_helper
INFO - 2020-02-03 13:35:37 --> Helper loaded: my_helper
INFO - 2020-02-03 13:35:37 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:35:37 --> Controller Class Initialized
DEBUG - 2020-02-03 13:35:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:35:37 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:35:37 --> Final output sent to browser
DEBUG - 2020-02-03 13:35:37 --> Total execution time: 0.5735
INFO - 2020-02-03 13:40:13 --> Config Class Initialized
INFO - 2020-02-03 13:40:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:40:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:40:13 --> Utf8 Class Initialized
INFO - 2020-02-03 13:40:13 --> URI Class Initialized
INFO - 2020-02-03 13:40:13 --> Router Class Initialized
INFO - 2020-02-03 13:40:13 --> Output Class Initialized
INFO - 2020-02-03 13:40:13 --> Security Class Initialized
DEBUG - 2020-02-03 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:40:13 --> Input Class Initialized
INFO - 2020-02-03 13:40:13 --> Language Class Initialized
INFO - 2020-02-03 13:40:13 --> Language Class Initialized
INFO - 2020-02-03 13:40:13 --> Config Class Initialized
INFO - 2020-02-03 13:40:13 --> Loader Class Initialized
INFO - 2020-02-03 13:40:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:40:13 --> Helper loaded: file_helper
INFO - 2020-02-03 13:40:14 --> Helper loaded: form_helper
INFO - 2020-02-03 13:40:14 --> Helper loaded: my_helper
INFO - 2020-02-03 13:40:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:40:14 --> Controller Class Initialized
DEBUG - 2020-02-03 13:40:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:40:14 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:40:14 --> Final output sent to browser
DEBUG - 2020-02-03 13:40:14 --> Total execution time: 0.6479
INFO - 2020-02-03 13:45:19 --> Config Class Initialized
INFO - 2020-02-03 13:45:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:45:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:45:19 --> Utf8 Class Initialized
INFO - 2020-02-03 13:45:19 --> URI Class Initialized
INFO - 2020-02-03 13:45:19 --> Router Class Initialized
INFO - 2020-02-03 13:45:19 --> Output Class Initialized
INFO - 2020-02-03 13:45:19 --> Security Class Initialized
DEBUG - 2020-02-03 13:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:45:19 --> Input Class Initialized
INFO - 2020-02-03 13:45:19 --> Language Class Initialized
INFO - 2020-02-03 13:45:19 --> Language Class Initialized
INFO - 2020-02-03 13:45:19 --> Config Class Initialized
INFO - 2020-02-03 13:45:19 --> Loader Class Initialized
INFO - 2020-02-03 13:45:19 --> Helper loaded: url_helper
INFO - 2020-02-03 13:45:19 --> Helper loaded: file_helper
INFO - 2020-02-03 13:45:19 --> Helper loaded: form_helper
INFO - 2020-02-03 13:45:19 --> Helper loaded: my_helper
INFO - 2020-02-03 13:45:19 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:45:20 --> Controller Class Initialized
DEBUG - 2020-02-03 13:45:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:45:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:45:20 --> Final output sent to browser
DEBUG - 2020-02-03 13:45:20 --> Total execution time: 0.5697
INFO - 2020-02-03 13:45:37 --> Config Class Initialized
INFO - 2020-02-03 13:45:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:45:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:45:37 --> Utf8 Class Initialized
INFO - 2020-02-03 13:45:37 --> URI Class Initialized
INFO - 2020-02-03 13:45:37 --> Router Class Initialized
INFO - 2020-02-03 13:45:37 --> Output Class Initialized
INFO - 2020-02-03 13:45:37 --> Security Class Initialized
DEBUG - 2020-02-03 13:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:45:37 --> Input Class Initialized
INFO - 2020-02-03 13:45:37 --> Language Class Initialized
INFO - 2020-02-03 13:45:37 --> Language Class Initialized
INFO - 2020-02-03 13:45:37 --> Config Class Initialized
INFO - 2020-02-03 13:45:37 --> Loader Class Initialized
INFO - 2020-02-03 13:45:37 --> Helper loaded: url_helper
INFO - 2020-02-03 13:45:37 --> Helper loaded: file_helper
INFO - 2020-02-03 13:45:38 --> Helper loaded: form_helper
INFO - 2020-02-03 13:45:38 --> Helper loaded: my_helper
INFO - 2020-02-03 13:45:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:45:38 --> Controller Class Initialized
DEBUG - 2020-02-03 13:45:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:45:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:45:38 --> Final output sent to browser
DEBUG - 2020-02-03 13:45:38 --> Total execution time: 0.6105
INFO - 2020-02-03 13:57:23 --> Config Class Initialized
INFO - 2020-02-03 13:57:23 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:57:23 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:57:23 --> Utf8 Class Initialized
INFO - 2020-02-03 13:57:23 --> URI Class Initialized
INFO - 2020-02-03 13:57:23 --> Router Class Initialized
INFO - 2020-02-03 13:57:23 --> Output Class Initialized
INFO - 2020-02-03 13:57:23 --> Security Class Initialized
DEBUG - 2020-02-03 13:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:57:23 --> Input Class Initialized
INFO - 2020-02-03 13:57:23 --> Language Class Initialized
INFO - 2020-02-03 13:57:23 --> Language Class Initialized
INFO - 2020-02-03 13:57:23 --> Config Class Initialized
INFO - 2020-02-03 13:57:23 --> Loader Class Initialized
INFO - 2020-02-03 13:57:23 --> Helper loaded: url_helper
INFO - 2020-02-03 13:57:23 --> Helper loaded: file_helper
INFO - 2020-02-03 13:57:23 --> Helper loaded: form_helper
INFO - 2020-02-03 13:57:23 --> Helper loaded: my_helper
INFO - 2020-02-03 13:57:23 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:57:23 --> Controller Class Initialized
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:23 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:24 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:57:25 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
DEBUG - 2020-02-03 13:57:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:57:25 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:57:25 --> Final output sent to browser
DEBUG - 2020-02-03 13:57:25 --> Total execution time: 2.5587
INFO - 2020-02-03 13:58:01 --> Config Class Initialized
INFO - 2020-02-03 13:58:01 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:01 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:01 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:01 --> URI Class Initialized
INFO - 2020-02-03 13:58:01 --> Router Class Initialized
INFO - 2020-02-03 13:58:01 --> Output Class Initialized
INFO - 2020-02-03 13:58:01 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:01 --> Input Class Initialized
INFO - 2020-02-03 13:58:01 --> Language Class Initialized
INFO - 2020-02-03 13:58:01 --> Language Class Initialized
INFO - 2020-02-03 13:58:01 --> Config Class Initialized
INFO - 2020-02-03 13:58:01 --> Loader Class Initialized
INFO - 2020-02-03 13:58:01 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:01 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:01 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:01 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:01 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:01 --> Controller Class Initialized
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:01 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:02 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:03 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
DEBUG - 2020-02-03 13:58:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:58:03 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:58:03 --> Final output sent to browser
DEBUG - 2020-02-03 13:58:03 --> Total execution time: 2.8054
INFO - 2020-02-03 13:58:08 --> Config Class Initialized
INFO - 2020-02-03 13:58:08 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:08 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:08 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:08 --> URI Class Initialized
INFO - 2020-02-03 13:58:08 --> Router Class Initialized
INFO - 2020-02-03 13:58:08 --> Output Class Initialized
INFO - 2020-02-03 13:58:08 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:09 --> Input Class Initialized
INFO - 2020-02-03 13:58:09 --> Language Class Initialized
INFO - 2020-02-03 13:58:09 --> Language Class Initialized
INFO - 2020-02-03 13:58:09 --> Config Class Initialized
INFO - 2020-02-03 13:58:09 --> Loader Class Initialized
INFO - 2020-02-03 13:58:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:09 --> Controller Class Initialized
DEBUG - 2020-02-03 13:58:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:58:09 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:58:09 --> Final output sent to browser
DEBUG - 2020-02-03 13:58:09 --> Total execution time: 0.5807
INFO - 2020-02-03 13:58:09 --> Config Class Initialized
INFO - 2020-02-03 13:58:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:09 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:09 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:09 --> URI Class Initialized
INFO - 2020-02-03 13:58:09 --> Router Class Initialized
INFO - 2020-02-03 13:58:09 --> Output Class Initialized
INFO - 2020-02-03 13:58:09 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:09 --> Input Class Initialized
INFO - 2020-02-03 13:58:09 --> Language Class Initialized
INFO - 2020-02-03 13:58:09 --> Language Class Initialized
INFO - 2020-02-03 13:58:09 --> Config Class Initialized
INFO - 2020-02-03 13:58:09 --> Loader Class Initialized
INFO - 2020-02-03 13:58:09 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:09 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:09 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:10 --> Controller Class Initialized
INFO - 2020-02-03 13:58:13 --> Config Class Initialized
INFO - 2020-02-03 13:58:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:13 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:13 --> URI Class Initialized
INFO - 2020-02-03 13:58:13 --> Router Class Initialized
INFO - 2020-02-03 13:58:13 --> Output Class Initialized
INFO - 2020-02-03 13:58:13 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:13 --> Input Class Initialized
INFO - 2020-02-03 13:58:13 --> Language Class Initialized
INFO - 2020-02-03 13:58:13 --> Language Class Initialized
INFO - 2020-02-03 13:58:13 --> Config Class Initialized
INFO - 2020-02-03 13:58:13 --> Loader Class Initialized
INFO - 2020-02-03 13:58:13 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:13 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:13 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:13 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:13 --> Controller Class Initialized
DEBUG - 2020-02-03 13:58:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/tahun/views/list.php
DEBUG - 2020-02-03 13:58:13 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:58:13 --> Final output sent to browser
DEBUG - 2020-02-03 13:58:13 --> Total execution time: 0.5657
INFO - 2020-02-03 13:58:13 --> Config Class Initialized
INFO - 2020-02-03 13:58:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:14 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:14 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:14 --> URI Class Initialized
INFO - 2020-02-03 13:58:14 --> Router Class Initialized
INFO - 2020-02-03 13:58:14 --> Output Class Initialized
INFO - 2020-02-03 13:58:14 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:14 --> Input Class Initialized
INFO - 2020-02-03 13:58:14 --> Language Class Initialized
INFO - 2020-02-03 13:58:14 --> Language Class Initialized
INFO - 2020-02-03 13:58:14 --> Config Class Initialized
INFO - 2020-02-03 13:58:14 --> Loader Class Initialized
INFO - 2020-02-03 13:58:14 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:14 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:14 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:14 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:14 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:14 --> Controller Class Initialized
INFO - 2020-02-03 13:58:15 --> Config Class Initialized
INFO - 2020-02-03 13:58:15 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:15 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:15 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:15 --> URI Class Initialized
INFO - 2020-02-03 13:58:15 --> Router Class Initialized
INFO - 2020-02-03 13:58:15 --> Output Class Initialized
INFO - 2020-02-03 13:58:15 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:15 --> Input Class Initialized
INFO - 2020-02-03 13:58:15 --> Language Class Initialized
INFO - 2020-02-03 13:58:15 --> Language Class Initialized
INFO - 2020-02-03 13:58:15 --> Config Class Initialized
INFO - 2020-02-03 13:58:15 --> Loader Class Initialized
INFO - 2020-02-03 13:58:15 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:15 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:15 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:15 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:15 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:15 --> Controller Class Initialized
DEBUG - 2020-02-03 13:58:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/list.php
DEBUG - 2020-02-03 13:58:15 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:58:15 --> Final output sent to browser
DEBUG - 2020-02-03 13:58:15 --> Total execution time: 0.6346
INFO - 2020-02-03 13:58:17 --> Config Class Initialized
INFO - 2020-02-03 13:58:17 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:58:17 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:58:17 --> Utf8 Class Initialized
INFO - 2020-02-03 13:58:17 --> URI Class Initialized
INFO - 2020-02-03 13:58:17 --> Router Class Initialized
INFO - 2020-02-03 13:58:17 --> Output Class Initialized
INFO - 2020-02-03 13:58:17 --> Security Class Initialized
DEBUG - 2020-02-03 13:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:58:17 --> Input Class Initialized
INFO - 2020-02-03 13:58:17 --> Language Class Initialized
INFO - 2020-02-03 13:58:17 --> Language Class Initialized
INFO - 2020-02-03 13:58:17 --> Config Class Initialized
INFO - 2020-02-03 13:58:17 --> Loader Class Initialized
INFO - 2020-02-03 13:58:17 --> Helper loaded: url_helper
INFO - 2020-02-03 13:58:17 --> Helper loaded: file_helper
INFO - 2020-02-03 13:58:17 --> Helper loaded: form_helper
INFO - 2020-02-03 13:58:17 --> Helper loaded: my_helper
INFO - 2020-02-03 13:58:17 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:58:17 --> Controller Class Initialized
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:17 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:18 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:58:19 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
DEBUG - 2020-02-03 13:58:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:58:19 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:58:19 --> Final output sent to browser
DEBUG - 2020-02-03 13:58:19 --> Total execution time: 2.5275
INFO - 2020-02-03 13:59:09 --> Config Class Initialized
INFO - 2020-02-03 13:59:09 --> Hooks Class Initialized
DEBUG - 2020-02-03 13:59:10 --> UTF-8 Support Enabled
INFO - 2020-02-03 13:59:10 --> Utf8 Class Initialized
INFO - 2020-02-03 13:59:10 --> URI Class Initialized
INFO - 2020-02-03 13:59:10 --> Router Class Initialized
INFO - 2020-02-03 13:59:10 --> Output Class Initialized
INFO - 2020-02-03 13:59:10 --> Security Class Initialized
DEBUG - 2020-02-03 13:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 13:59:10 --> Input Class Initialized
INFO - 2020-02-03 13:59:10 --> Language Class Initialized
INFO - 2020-02-03 13:59:10 --> Language Class Initialized
INFO - 2020-02-03 13:59:10 --> Config Class Initialized
INFO - 2020-02-03 13:59:10 --> Loader Class Initialized
INFO - 2020-02-03 13:59:10 --> Helper loaded: url_helper
INFO - 2020-02-03 13:59:10 --> Helper loaded: file_helper
INFO - 2020-02-03 13:59:10 --> Helper loaded: form_helper
INFO - 2020-02-03 13:59:10 --> Helper loaded: my_helper
INFO - 2020-02-03 13:59:10 --> Database Driver Class Initialized
DEBUG - 2020-02-03 13:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 13:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 13:59:10 --> Controller Class Initialized
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:10 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:11 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: id E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
ERROR - 2020-02-03 13:59:12 --> Severity: Notice --> Undefined index: nama E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
DEBUG - 2020-02-03 13:59:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 13:59:12 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 13:59:12 --> Final output sent to browser
DEBUG - 2020-02-03 13:59:12 --> Total execution time: 2.6347
INFO - 2020-02-03 14:00:32 --> Config Class Initialized
INFO - 2020-02-03 14:00:32 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:00:32 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:00:32 --> Utf8 Class Initialized
INFO - 2020-02-03 14:00:32 --> URI Class Initialized
INFO - 2020-02-03 14:00:32 --> Router Class Initialized
INFO - 2020-02-03 14:00:32 --> Output Class Initialized
INFO - 2020-02-03 14:00:32 --> Security Class Initialized
DEBUG - 2020-02-03 14:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:00:32 --> Input Class Initialized
INFO - 2020-02-03 14:00:32 --> Language Class Initialized
INFO - 2020-02-03 14:00:32 --> Language Class Initialized
INFO - 2020-02-03 14:00:32 --> Config Class Initialized
INFO - 2020-02-03 14:00:32 --> Loader Class Initialized
INFO - 2020-02-03 14:00:32 --> Helper loaded: url_helper
INFO - 2020-02-03 14:00:32 --> Helper loaded: file_helper
INFO - 2020-02-03 14:00:32 --> Helper loaded: form_helper
INFO - 2020-02-03 14:00:32 --> Helper loaded: my_helper
INFO - 2020-02-03 14:00:32 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:00:32 --> Controller Class Initialized
DEBUG - 2020-02-03 14:00:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:00:32 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:00:32 --> Final output sent to browser
DEBUG - 2020-02-03 14:00:32 --> Total execution time: 0.6105
INFO - 2020-02-03 14:00:38 --> Config Class Initialized
INFO - 2020-02-03 14:00:38 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:00:38 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:00:38 --> Utf8 Class Initialized
INFO - 2020-02-03 14:00:38 --> URI Class Initialized
INFO - 2020-02-03 14:00:38 --> Router Class Initialized
INFO - 2020-02-03 14:00:38 --> Output Class Initialized
INFO - 2020-02-03 14:00:38 --> Security Class Initialized
DEBUG - 2020-02-03 14:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:00:38 --> Input Class Initialized
INFO - 2020-02-03 14:00:38 --> Language Class Initialized
INFO - 2020-02-03 14:00:38 --> Language Class Initialized
INFO - 2020-02-03 14:00:38 --> Config Class Initialized
INFO - 2020-02-03 14:00:38 --> Loader Class Initialized
INFO - 2020-02-03 14:00:38 --> Helper loaded: url_helper
INFO - 2020-02-03 14:00:38 --> Helper loaded: file_helper
INFO - 2020-02-03 14:00:38 --> Helper loaded: form_helper
INFO - 2020-02-03 14:00:38 --> Helper loaded: my_helper
INFO - 2020-02-03 14:00:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:00:38 --> Controller Class Initialized
DEBUG - 2020-02-03 14:00:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:00:39 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:00:39 --> Final output sent to browser
DEBUG - 2020-02-03 14:00:39 --> Total execution time: 0.6581
INFO - 2020-02-03 14:02:13 --> Config Class Initialized
INFO - 2020-02-03 14:02:13 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:02:13 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:02:13 --> Utf8 Class Initialized
INFO - 2020-02-03 14:02:13 --> URI Class Initialized
INFO - 2020-02-03 14:02:13 --> Router Class Initialized
INFO - 2020-02-03 14:02:13 --> Output Class Initialized
INFO - 2020-02-03 14:02:13 --> Security Class Initialized
DEBUG - 2020-02-03 14:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:02:13 --> Input Class Initialized
INFO - 2020-02-03 14:02:13 --> Language Class Initialized
INFO - 2020-02-03 14:02:13 --> Language Class Initialized
INFO - 2020-02-03 14:02:13 --> Config Class Initialized
INFO - 2020-02-03 14:02:13 --> Loader Class Initialized
INFO - 2020-02-03 14:02:13 --> Helper loaded: url_helper
INFO - 2020-02-03 14:02:13 --> Helper loaded: file_helper
INFO - 2020-02-03 14:02:13 --> Helper loaded: form_helper
INFO - 2020-02-03 14:02:13 --> Helper loaded: my_helper
INFO - 2020-02-03 14:02:13 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:02:13 --> Controller Class Initialized
ERROR - 2020-02-03 14:02:13 --> Severity: Parsing Error --> syntax error, unexpected ''</option>'' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' E:\xampp\htdocs\_2020\myraport\application\modules\set_kelas\views\form.php 38
INFO - 2020-02-03 14:02:21 --> Config Class Initialized
INFO - 2020-02-03 14:02:21 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:02:21 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:02:21 --> Utf8 Class Initialized
INFO - 2020-02-03 14:02:21 --> URI Class Initialized
INFO - 2020-02-03 14:02:21 --> Router Class Initialized
INFO - 2020-02-03 14:02:21 --> Output Class Initialized
INFO - 2020-02-03 14:02:21 --> Security Class Initialized
DEBUG - 2020-02-03 14:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:02:21 --> Input Class Initialized
INFO - 2020-02-03 14:02:21 --> Language Class Initialized
INFO - 2020-02-03 14:02:21 --> Language Class Initialized
INFO - 2020-02-03 14:02:21 --> Config Class Initialized
INFO - 2020-02-03 14:02:21 --> Loader Class Initialized
INFO - 2020-02-03 14:02:21 --> Helper loaded: url_helper
INFO - 2020-02-03 14:02:21 --> Helper loaded: file_helper
INFO - 2020-02-03 14:02:21 --> Helper loaded: form_helper
INFO - 2020-02-03 14:02:21 --> Helper loaded: my_helper
INFO - 2020-02-03 14:02:21 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:02:22 --> Controller Class Initialized
DEBUG - 2020-02-03 14:02:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:02:22 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:02:22 --> Final output sent to browser
DEBUG - 2020-02-03 14:02:22 --> Total execution time: 0.6354
INFO - 2020-02-03 14:03:03 --> Config Class Initialized
INFO - 2020-02-03 14:03:03 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:03:03 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:03:03 --> Utf8 Class Initialized
INFO - 2020-02-03 14:03:03 --> URI Class Initialized
INFO - 2020-02-03 14:03:03 --> Router Class Initialized
INFO - 2020-02-03 14:03:03 --> Output Class Initialized
INFO - 2020-02-03 14:03:03 --> Security Class Initialized
DEBUG - 2020-02-03 14:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:03:03 --> Input Class Initialized
INFO - 2020-02-03 14:03:03 --> Language Class Initialized
INFO - 2020-02-03 14:03:03 --> Language Class Initialized
INFO - 2020-02-03 14:03:03 --> Config Class Initialized
INFO - 2020-02-03 14:03:03 --> Loader Class Initialized
INFO - 2020-02-03 14:03:04 --> Helper loaded: url_helper
INFO - 2020-02-03 14:03:04 --> Helper loaded: file_helper
INFO - 2020-02-03 14:03:04 --> Helper loaded: form_helper
INFO - 2020-02-03 14:03:04 --> Helper loaded: my_helper
INFO - 2020-02-03 14:03:04 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:03:04 --> Controller Class Initialized
DEBUG - 2020-02-03 14:03:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:03:04 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:03:04 --> Final output sent to browser
DEBUG - 2020-02-03 14:03:04 --> Total execution time: 0.6591
INFO - 2020-02-03 14:04:04 --> Config Class Initialized
INFO - 2020-02-03 14:04:04 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:04:04 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:04:04 --> Utf8 Class Initialized
INFO - 2020-02-03 14:04:04 --> URI Class Initialized
INFO - 2020-02-03 14:04:04 --> Router Class Initialized
INFO - 2020-02-03 14:04:04 --> Output Class Initialized
INFO - 2020-02-03 14:04:04 --> Security Class Initialized
DEBUG - 2020-02-03 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:04:04 --> Input Class Initialized
INFO - 2020-02-03 14:04:05 --> Language Class Initialized
INFO - 2020-02-03 14:04:05 --> Language Class Initialized
INFO - 2020-02-03 14:04:05 --> Config Class Initialized
INFO - 2020-02-03 14:04:05 --> Loader Class Initialized
INFO - 2020-02-03 14:04:05 --> Helper loaded: url_helper
INFO - 2020-02-03 14:04:05 --> Helper loaded: file_helper
INFO - 2020-02-03 14:04:05 --> Helper loaded: form_helper
INFO - 2020-02-03 14:04:05 --> Helper loaded: my_helper
INFO - 2020-02-03 14:04:05 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:04:05 --> Controller Class Initialized
DEBUG - 2020-02-03 14:04:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:04:05 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:04:05 --> Final output sent to browser
DEBUG - 2020-02-03 14:04:05 --> Total execution time: 0.6030
INFO - 2020-02-03 14:06:37 --> Config Class Initialized
INFO - 2020-02-03 14:06:37 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:06:37 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:06:37 --> Utf8 Class Initialized
INFO - 2020-02-03 14:06:37 --> URI Class Initialized
INFO - 2020-02-03 14:06:37 --> Router Class Initialized
INFO - 2020-02-03 14:06:37 --> Output Class Initialized
INFO - 2020-02-03 14:06:37 --> Security Class Initialized
DEBUG - 2020-02-03 14:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:06:37 --> Input Class Initialized
INFO - 2020-02-03 14:06:37 --> Language Class Initialized
INFO - 2020-02-03 14:06:37 --> Language Class Initialized
INFO - 2020-02-03 14:06:37 --> Config Class Initialized
INFO - 2020-02-03 14:06:37 --> Loader Class Initialized
INFO - 2020-02-03 14:06:37 --> Helper loaded: url_helper
INFO - 2020-02-03 14:06:37 --> Helper loaded: file_helper
INFO - 2020-02-03 14:06:37 --> Helper loaded: form_helper
INFO - 2020-02-03 14:06:37 --> Helper loaded: my_helper
INFO - 2020-02-03 14:06:38 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:06:38 --> Controller Class Initialized
DEBUG - 2020-02-03 14:06:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:06:38 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:06:38 --> Final output sent to browser
DEBUG - 2020-02-03 14:06:38 --> Total execution time: 0.6530
INFO - 2020-02-03 14:06:48 --> Config Class Initialized
INFO - 2020-02-03 14:06:48 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:06:48 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:06:48 --> Utf8 Class Initialized
INFO - 2020-02-03 14:06:48 --> URI Class Initialized
INFO - 2020-02-03 14:06:48 --> Router Class Initialized
INFO - 2020-02-03 14:06:48 --> Output Class Initialized
INFO - 2020-02-03 14:06:48 --> Security Class Initialized
DEBUG - 2020-02-03 14:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:06:48 --> Input Class Initialized
INFO - 2020-02-03 14:06:48 --> Language Class Initialized
INFO - 2020-02-03 14:06:48 --> Language Class Initialized
INFO - 2020-02-03 14:06:48 --> Config Class Initialized
INFO - 2020-02-03 14:06:49 --> Loader Class Initialized
INFO - 2020-02-03 14:06:49 --> Helper loaded: url_helper
INFO - 2020-02-03 14:06:49 --> Helper loaded: file_helper
INFO - 2020-02-03 14:06:49 --> Helper loaded: form_helper
INFO - 2020-02-03 14:06:49 --> Helper loaded: my_helper
INFO - 2020-02-03 14:06:49 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:06:49 --> Controller Class Initialized
DEBUG - 2020-02-03 14:06:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:06:49 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:06:49 --> Final output sent to browser
DEBUG - 2020-02-03 14:06:49 --> Total execution time: 0.6881
INFO - 2020-02-03 14:07:19 --> Config Class Initialized
INFO - 2020-02-03 14:07:19 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:07:19 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:07:19 --> Utf8 Class Initialized
INFO - 2020-02-03 14:07:19 --> URI Class Initialized
INFO - 2020-02-03 14:07:19 --> Router Class Initialized
INFO - 2020-02-03 14:07:19 --> Output Class Initialized
INFO - 2020-02-03 14:07:19 --> Security Class Initialized
DEBUG - 2020-02-03 14:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:07:19 --> Input Class Initialized
INFO - 2020-02-03 14:07:19 --> Language Class Initialized
INFO - 2020-02-03 14:07:19 --> Language Class Initialized
INFO - 2020-02-03 14:07:19 --> Config Class Initialized
INFO - 2020-02-03 14:07:19 --> Loader Class Initialized
INFO - 2020-02-03 14:07:19 --> Helper loaded: url_helper
INFO - 2020-02-03 14:07:19 --> Helper loaded: file_helper
INFO - 2020-02-03 14:07:19 --> Helper loaded: form_helper
INFO - 2020-02-03 14:07:19 --> Helper loaded: my_helper
INFO - 2020-02-03 14:07:20 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:07:20 --> Controller Class Initialized
DEBUG - 2020-02-03 14:07:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:07:20 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:07:20 --> Final output sent to browser
DEBUG - 2020-02-03 14:07:20 --> Total execution time: 0.6812
INFO - 2020-02-03 14:08:01 --> Config Class Initialized
INFO - 2020-02-03 14:08:01 --> Hooks Class Initialized
DEBUG - 2020-02-03 14:08:01 --> UTF-8 Support Enabled
INFO - 2020-02-03 14:08:01 --> Utf8 Class Initialized
INFO - 2020-02-03 14:08:01 --> URI Class Initialized
INFO - 2020-02-03 14:08:01 --> Router Class Initialized
INFO - 2020-02-03 14:08:01 --> Output Class Initialized
INFO - 2020-02-03 14:08:01 --> Security Class Initialized
DEBUG - 2020-02-03 14:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-02-03 14:08:01 --> Input Class Initialized
INFO - 2020-02-03 14:08:01 --> Language Class Initialized
INFO - 2020-02-03 14:08:01 --> Language Class Initialized
INFO - 2020-02-03 14:08:01 --> Config Class Initialized
INFO - 2020-02-03 14:08:01 --> Loader Class Initialized
INFO - 2020-02-03 14:08:01 --> Helper loaded: url_helper
INFO - 2020-02-03 14:08:01 --> Helper loaded: file_helper
INFO - 2020-02-03 14:08:01 --> Helper loaded: form_helper
INFO - 2020-02-03 14:08:01 --> Helper loaded: my_helper
INFO - 2020-02-03 14:08:01 --> Database Driver Class Initialized
DEBUG - 2020-02-03 14:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-02-03 14:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-02-03 14:08:02 --> Controller Class Initialized
DEBUG - 2020-02-03 14:08:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\modules/set_kelas/views/form.php
DEBUG - 2020-02-03 14:08:02 --> File loaded: E:\xampp\htdocs\_2020\myraport\application\views\template_utama.php
INFO - 2020-02-03 14:08:02 --> Final output sent to browser
DEBUG - 2020-02-03 14:08:02 --> Total execution time: 0.7981
