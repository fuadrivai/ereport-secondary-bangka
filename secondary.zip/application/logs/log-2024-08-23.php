<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Hooks Class Initialized
DEBUG - 2024-08-23 07:39:17 --> UTF-8 Support Enabled
INFO - 2024-08-23 07:39:17 --> Utf8 Class Initialized
INFO - 2024-08-23 07:39:17 --> URI Class Initialized
INFO - 2024-08-23 07:39:17 --> Router Class Initialized
INFO - 2024-08-23 07:39:17 --> Output Class Initialized
INFO - 2024-08-23 07:39:17 --> Security Class Initialized
DEBUG - 2024-08-23 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 07:39:17 --> Input Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Loader Class Initialized
INFO - 2024-08-23 07:39:17 --> Helper loaded: url_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: file_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: form_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: my_helper
INFO - 2024-08-23 07:39:17 --> Database Driver Class Initialized
INFO - 2024-08-23 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 07:39:17 --> Controller Class Initialized
INFO - 2024-08-23 07:39:17 --> Helper loaded: cookie_helper
INFO - 2024-08-23 07:39:17 --> Final output sent to browser
DEBUG - 2024-08-23 07:39:17 --> Total execution time: 0.2902
INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Hooks Class Initialized
DEBUG - 2024-08-23 07:39:17 --> UTF-8 Support Enabled
INFO - 2024-08-23 07:39:17 --> Utf8 Class Initialized
INFO - 2024-08-23 07:39:17 --> URI Class Initialized
INFO - 2024-08-23 07:39:17 --> Router Class Initialized
INFO - 2024-08-23 07:39:17 --> Output Class Initialized
INFO - 2024-08-23 07:39:17 --> Security Class Initialized
DEBUG - 2024-08-23 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 07:39:17 --> Input Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Loader Class Initialized
INFO - 2024-08-23 07:39:17 --> Helper loaded: url_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: file_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: form_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: my_helper
INFO - 2024-08-23 07:39:17 --> Database Driver Class Initialized
INFO - 2024-08-23 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 07:39:17 --> Controller Class Initialized
INFO - 2024-08-23 07:39:17 --> Helper loaded: cookie_helper
INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Hooks Class Initialized
DEBUG - 2024-08-23 07:39:17 --> UTF-8 Support Enabled
INFO - 2024-08-23 07:39:17 --> Utf8 Class Initialized
INFO - 2024-08-23 07:39:17 --> URI Class Initialized
INFO - 2024-08-23 07:39:17 --> Router Class Initialized
INFO - 2024-08-23 07:39:17 --> Output Class Initialized
INFO - 2024-08-23 07:39:17 --> Security Class Initialized
DEBUG - 2024-08-23 07:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 07:39:17 --> Input Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Language Class Initialized
INFO - 2024-08-23 07:39:17 --> Config Class Initialized
INFO - 2024-08-23 07:39:17 --> Loader Class Initialized
INFO - 2024-08-23 07:39:17 --> Helper loaded: url_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: file_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: form_helper
INFO - 2024-08-23 07:39:17 --> Helper loaded: my_helper
INFO - 2024-08-23 07:39:17 --> Database Driver Class Initialized
INFO - 2024-08-23 07:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 07:39:17 --> Controller Class Initialized
DEBUG - 2024-08-23 07:39:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 07:39:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 07:39:17 --> Final output sent to browser
DEBUG - 2024-08-23 07:39:17 --> Total execution time: 0.1540
INFO - 2024-08-23 08:50:18 --> Config Class Initialized
INFO - 2024-08-23 08:50:18 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:50:18 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:50:18 --> Utf8 Class Initialized
INFO - 2024-08-23 08:50:18 --> URI Class Initialized
INFO - 2024-08-23 08:50:18 --> Router Class Initialized
INFO - 2024-08-23 08:50:18 --> Output Class Initialized
INFO - 2024-08-23 08:50:18 --> Security Class Initialized
DEBUG - 2024-08-23 08:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:50:18 --> Input Class Initialized
INFO - 2024-08-23 08:50:18 --> Language Class Initialized
INFO - 2024-08-23 08:50:18 --> Language Class Initialized
INFO - 2024-08-23 08:50:18 --> Config Class Initialized
INFO - 2024-08-23 08:50:18 --> Loader Class Initialized
INFO - 2024-08-23 08:50:18 --> Helper loaded: url_helper
INFO - 2024-08-23 08:50:18 --> Helper loaded: file_helper
INFO - 2024-08-23 08:50:18 --> Helper loaded: form_helper
INFO - 2024-08-23 08:50:18 --> Helper loaded: my_helper
INFO - 2024-08-23 08:50:18 --> Database Driver Class Initialized
INFO - 2024-08-23 08:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:50:18 --> Controller Class Initialized
INFO - 2024-08-23 08:50:18 --> Helper loaded: cookie_helper
INFO - 2024-08-23 08:50:18 --> Final output sent to browser
DEBUG - 2024-08-23 08:50:18 --> Total execution time: 0.0878
INFO - 2024-08-23 08:50:19 --> Config Class Initialized
INFO - 2024-08-23 08:50:19 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:50:19 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:50:19 --> Utf8 Class Initialized
INFO - 2024-08-23 08:50:19 --> URI Class Initialized
INFO - 2024-08-23 08:50:19 --> Router Class Initialized
INFO - 2024-08-23 08:50:19 --> Output Class Initialized
INFO - 2024-08-23 08:50:19 --> Security Class Initialized
DEBUG - 2024-08-23 08:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:50:19 --> Input Class Initialized
INFO - 2024-08-23 08:50:19 --> Language Class Initialized
INFO - 2024-08-23 08:50:19 --> Language Class Initialized
INFO - 2024-08-23 08:50:19 --> Config Class Initialized
INFO - 2024-08-23 08:50:19 --> Loader Class Initialized
INFO - 2024-08-23 08:50:19 --> Helper loaded: url_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: file_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: form_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: my_helper
INFO - 2024-08-23 08:50:19 --> Database Driver Class Initialized
INFO - 2024-08-23 08:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:50:19 --> Controller Class Initialized
INFO - 2024-08-23 08:50:19 --> Helper loaded: cookie_helper
INFO - 2024-08-23 08:50:19 --> Config Class Initialized
INFO - 2024-08-23 08:50:19 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:50:19 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:50:19 --> Utf8 Class Initialized
INFO - 2024-08-23 08:50:19 --> URI Class Initialized
INFO - 2024-08-23 08:50:19 --> Router Class Initialized
INFO - 2024-08-23 08:50:19 --> Output Class Initialized
INFO - 2024-08-23 08:50:19 --> Security Class Initialized
DEBUG - 2024-08-23 08:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:50:19 --> Input Class Initialized
INFO - 2024-08-23 08:50:19 --> Language Class Initialized
INFO - 2024-08-23 08:50:19 --> Language Class Initialized
INFO - 2024-08-23 08:50:19 --> Config Class Initialized
INFO - 2024-08-23 08:50:19 --> Loader Class Initialized
INFO - 2024-08-23 08:50:19 --> Helper loaded: url_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: file_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: form_helper
INFO - 2024-08-23 08:50:19 --> Helper loaded: my_helper
INFO - 2024-08-23 08:50:19 --> Database Driver Class Initialized
INFO - 2024-08-23 08:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:50:19 --> Controller Class Initialized
DEBUG - 2024-08-23 08:50:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 08:50:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 08:50:19 --> Final output sent to browser
DEBUG - 2024-08-23 08:50:19 --> Total execution time: 0.0422
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:51:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:51:14 --> Utf8 Class Initialized
INFO - 2024-08-23 08:51:14 --> URI Class Initialized
INFO - 2024-08-23 08:51:14 --> Router Class Initialized
INFO - 2024-08-23 08:51:14 --> Output Class Initialized
INFO - 2024-08-23 08:51:14 --> Security Class Initialized
DEBUG - 2024-08-23 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:51:14 --> Input Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Loader Class Initialized
INFO - 2024-08-23 08:51:14 --> Helper loaded: url_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: file_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: form_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: my_helper
INFO - 2024-08-23 08:51:14 --> Database Driver Class Initialized
INFO - 2024-08-23 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:51:14 --> Controller Class Initialized
INFO - 2024-08-23 08:51:14 --> Helper loaded: cookie_helper
INFO - 2024-08-23 08:51:14 --> Final output sent to browser
DEBUG - 2024-08-23 08:51:14 --> Total execution time: 0.2683
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:51:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:51:14 --> Utf8 Class Initialized
INFO - 2024-08-23 08:51:14 --> URI Class Initialized
INFO - 2024-08-23 08:51:14 --> Router Class Initialized
INFO - 2024-08-23 08:51:14 --> Output Class Initialized
INFO - 2024-08-23 08:51:14 --> Security Class Initialized
DEBUG - 2024-08-23 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:51:14 --> Input Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Loader Class Initialized
INFO - 2024-08-23 08:51:14 --> Helper loaded: url_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: file_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: form_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: my_helper
INFO - 2024-08-23 08:51:14 --> Database Driver Class Initialized
INFO - 2024-08-23 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:51:14 --> Controller Class Initialized
INFO - 2024-08-23 08:51:14 --> Helper loaded: cookie_helper
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 08:51:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 08:51:14 --> Utf8 Class Initialized
INFO - 2024-08-23 08:51:14 --> URI Class Initialized
INFO - 2024-08-23 08:51:14 --> Router Class Initialized
INFO - 2024-08-23 08:51:14 --> Output Class Initialized
INFO - 2024-08-23 08:51:14 --> Security Class Initialized
DEBUG - 2024-08-23 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 08:51:14 --> Input Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Language Class Initialized
INFO - 2024-08-23 08:51:14 --> Config Class Initialized
INFO - 2024-08-23 08:51:14 --> Loader Class Initialized
INFO - 2024-08-23 08:51:14 --> Helper loaded: url_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: file_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: form_helper
INFO - 2024-08-23 08:51:14 --> Helper loaded: my_helper
INFO - 2024-08-23 08:51:14 --> Database Driver Class Initialized
INFO - 2024-08-23 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 08:51:14 --> Controller Class Initialized
DEBUG - 2024-08-23 08:51:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 08:51:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 08:51:14 --> Final output sent to browser
DEBUG - 2024-08-23 08:51:14 --> Total execution time: 0.0417
INFO - 2024-08-23 10:08:13 --> Config Class Initialized
INFO - 2024-08-23 10:08:13 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:08:13 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:08:13 --> Utf8 Class Initialized
INFO - 2024-08-23 10:08:13 --> URI Class Initialized
INFO - 2024-08-23 10:08:13 --> Router Class Initialized
INFO - 2024-08-23 10:08:13 --> Output Class Initialized
INFO - 2024-08-23 10:08:13 --> Security Class Initialized
DEBUG - 2024-08-23 10:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:08:13 --> Input Class Initialized
INFO - 2024-08-23 10:08:13 --> Language Class Initialized
INFO - 2024-08-23 10:08:13 --> Language Class Initialized
INFO - 2024-08-23 10:08:13 --> Config Class Initialized
INFO - 2024-08-23 10:08:13 --> Loader Class Initialized
INFO - 2024-08-23 10:08:13 --> Helper loaded: url_helper
INFO - 2024-08-23 10:08:13 --> Helper loaded: file_helper
INFO - 2024-08-23 10:08:13 --> Helper loaded: form_helper
INFO - 2024-08-23 10:08:13 --> Helper loaded: my_helper
INFO - 2024-08-23 10:08:13 --> Database Driver Class Initialized
INFO - 2024-08-23 10:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:08:13 --> Controller Class Initialized
INFO - 2024-08-23 10:08:13 --> Helper loaded: cookie_helper
INFO - 2024-08-23 10:08:13 --> Final output sent to browser
DEBUG - 2024-08-23 10:08:13 --> Total execution time: 0.0532
INFO - 2024-08-23 10:08:14 --> Config Class Initialized
INFO - 2024-08-23 10:08:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:08:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:08:14 --> Utf8 Class Initialized
INFO - 2024-08-23 10:08:14 --> URI Class Initialized
INFO - 2024-08-23 10:08:14 --> Router Class Initialized
INFO - 2024-08-23 10:08:14 --> Output Class Initialized
INFO - 2024-08-23 10:08:14 --> Security Class Initialized
DEBUG - 2024-08-23 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:08:14 --> Input Class Initialized
INFO - 2024-08-23 10:08:14 --> Language Class Initialized
INFO - 2024-08-23 10:08:14 --> Language Class Initialized
INFO - 2024-08-23 10:08:14 --> Config Class Initialized
INFO - 2024-08-23 10:08:14 --> Loader Class Initialized
INFO - 2024-08-23 10:08:14 --> Helper loaded: url_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: file_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: form_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: my_helper
INFO - 2024-08-23 10:08:14 --> Database Driver Class Initialized
INFO - 2024-08-23 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:08:14 --> Controller Class Initialized
INFO - 2024-08-23 10:08:14 --> Helper loaded: cookie_helper
INFO - 2024-08-23 10:08:14 --> Config Class Initialized
INFO - 2024-08-23 10:08:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:08:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:08:14 --> Utf8 Class Initialized
INFO - 2024-08-23 10:08:14 --> URI Class Initialized
INFO - 2024-08-23 10:08:14 --> Router Class Initialized
INFO - 2024-08-23 10:08:14 --> Output Class Initialized
INFO - 2024-08-23 10:08:14 --> Security Class Initialized
DEBUG - 2024-08-23 10:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:08:14 --> Input Class Initialized
INFO - 2024-08-23 10:08:14 --> Language Class Initialized
INFO - 2024-08-23 10:08:14 --> Language Class Initialized
INFO - 2024-08-23 10:08:14 --> Config Class Initialized
INFO - 2024-08-23 10:08:14 --> Loader Class Initialized
INFO - 2024-08-23 10:08:14 --> Helper loaded: url_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: file_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: form_helper
INFO - 2024-08-23 10:08:14 --> Helper loaded: my_helper
INFO - 2024-08-23 10:08:14 --> Database Driver Class Initialized
INFO - 2024-08-23 10:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:08:14 --> Controller Class Initialized
DEBUG - 2024-08-23 10:08:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 10:08:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 10:08:14 --> Final output sent to browser
DEBUG - 2024-08-23 10:08:14 --> Total execution time: 0.0382
INFO - 2024-08-23 10:48:15 --> Config Class Initialized
INFO - 2024-08-23 10:48:15 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:15 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:15 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:15 --> URI Class Initialized
INFO - 2024-08-23 10:48:15 --> Router Class Initialized
INFO - 2024-08-23 10:48:15 --> Output Class Initialized
INFO - 2024-08-23 10:48:15 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:15 --> Input Class Initialized
INFO - 2024-08-23 10:48:15 --> Language Class Initialized
INFO - 2024-08-23 10:48:15 --> Language Class Initialized
INFO - 2024-08-23 10:48:15 --> Config Class Initialized
INFO - 2024-08-23 10:48:15 --> Loader Class Initialized
INFO - 2024-08-23 10:48:15 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:15 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:15 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:15 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:15 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:15 --> Controller Class Initialized
INFO - 2024-08-23 10:48:15 --> Helper loaded: cookie_helper
INFO - 2024-08-23 10:48:15 --> Final output sent to browser
DEBUG - 2024-08-23 10:48:15 --> Total execution time: 0.0552
INFO - 2024-08-23 10:48:16 --> Config Class Initialized
INFO - 2024-08-23 10:48:16 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:16 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:16 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:16 --> URI Class Initialized
INFO - 2024-08-23 10:48:16 --> Router Class Initialized
INFO - 2024-08-23 10:48:16 --> Output Class Initialized
INFO - 2024-08-23 10:48:16 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:16 --> Input Class Initialized
INFO - 2024-08-23 10:48:16 --> Language Class Initialized
INFO - 2024-08-23 10:48:16 --> Language Class Initialized
INFO - 2024-08-23 10:48:16 --> Config Class Initialized
INFO - 2024-08-23 10:48:16 --> Loader Class Initialized
INFO - 2024-08-23 10:48:16 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:16 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:16 --> Controller Class Initialized
INFO - 2024-08-23 10:48:16 --> Helper loaded: cookie_helper
INFO - 2024-08-23 10:48:16 --> Config Class Initialized
INFO - 2024-08-23 10:48:16 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:16 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:16 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:16 --> URI Class Initialized
INFO - 2024-08-23 10:48:16 --> Router Class Initialized
INFO - 2024-08-23 10:48:16 --> Output Class Initialized
INFO - 2024-08-23 10:48:16 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:16 --> Input Class Initialized
INFO - 2024-08-23 10:48:16 --> Language Class Initialized
INFO - 2024-08-23 10:48:16 --> Language Class Initialized
INFO - 2024-08-23 10:48:16 --> Config Class Initialized
INFO - 2024-08-23 10:48:16 --> Loader Class Initialized
INFO - 2024-08-23 10:48:16 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:16 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:16 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:16 --> Controller Class Initialized
DEBUG - 2024-08-23 10:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 10:48:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 10:48:16 --> Final output sent to browser
DEBUG - 2024-08-23 10:48:16 --> Total execution time: 0.0355
INFO - 2024-08-23 10:48:28 --> Config Class Initialized
INFO - 2024-08-23 10:48:28 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:28 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:28 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:28 --> URI Class Initialized
INFO - 2024-08-23 10:48:28 --> Router Class Initialized
INFO - 2024-08-23 10:48:28 --> Output Class Initialized
INFO - 2024-08-23 10:48:28 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:28 --> Input Class Initialized
INFO - 2024-08-23 10:48:28 --> Language Class Initialized
INFO - 2024-08-23 10:48:28 --> Language Class Initialized
INFO - 2024-08-23 10:48:28 --> Config Class Initialized
INFO - 2024-08-23 10:48:28 --> Loader Class Initialized
INFO - 2024-08-23 10:48:28 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:28 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:28 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:28 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:28 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:28 --> Controller Class Initialized
DEBUG - 2024-08-23 10:48:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-23 10:48:32 --> Final output sent to browser
DEBUG - 2024-08-23 10:48:32 --> Total execution time: 4.2091
INFO - 2024-08-23 10:48:33 --> Config Class Initialized
INFO - 2024-08-23 10:48:33 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:33 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:33 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:33 --> URI Class Initialized
INFO - 2024-08-23 10:48:33 --> Router Class Initialized
INFO - 2024-08-23 10:48:33 --> Output Class Initialized
INFO - 2024-08-23 10:48:33 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:33 --> Input Class Initialized
INFO - 2024-08-23 10:48:33 --> Language Class Initialized
INFO - 2024-08-23 10:48:33 --> Language Class Initialized
INFO - 2024-08-23 10:48:33 --> Config Class Initialized
INFO - 2024-08-23 10:48:33 --> Loader Class Initialized
INFO - 2024-08-23 10:48:33 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:33 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:33 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:33 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:33 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:33 --> Controller Class Initialized
DEBUG - 2024-08-23 10:48:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-23 10:48:35 --> Config Class Initialized
INFO - 2024-08-23 10:48:35 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:35 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:35 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:35 --> URI Class Initialized
INFO - 2024-08-23 10:48:35 --> Router Class Initialized
INFO - 2024-08-23 10:48:35 --> Output Class Initialized
INFO - 2024-08-23 10:48:35 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:35 --> Input Class Initialized
INFO - 2024-08-23 10:48:35 --> Language Class Initialized
INFO - 2024-08-23 10:48:36 --> Language Class Initialized
INFO - 2024-08-23 10:48:36 --> Config Class Initialized
INFO - 2024-08-23 10:48:36 --> Loader Class Initialized
INFO - 2024-08-23 10:48:36 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:36 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:36 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:36 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:36 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:37 --> Controller Class Initialized
DEBUG - 2024-08-23 10:48:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-23 10:48:41 --> Final output sent to browser
DEBUG - 2024-08-23 10:48:41 --> Total execution time: 5.4179
INFO - 2024-08-23 10:48:41 --> Config Class Initialized
INFO - 2024-08-23 10:48:41 --> Hooks Class Initialized
DEBUG - 2024-08-23 10:48:41 --> UTF-8 Support Enabled
INFO - 2024-08-23 10:48:41 --> Utf8 Class Initialized
INFO - 2024-08-23 10:48:41 --> URI Class Initialized
INFO - 2024-08-23 10:48:41 --> Router Class Initialized
INFO - 2024-08-23 10:48:41 --> Output Class Initialized
INFO - 2024-08-23 10:48:41 --> Security Class Initialized
DEBUG - 2024-08-23 10:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 10:48:41 --> Input Class Initialized
INFO - 2024-08-23 10:48:41 --> Language Class Initialized
INFO - 2024-08-23 10:48:41 --> Language Class Initialized
INFO - 2024-08-23 10:48:41 --> Config Class Initialized
INFO - 2024-08-23 10:48:41 --> Loader Class Initialized
INFO - 2024-08-23 10:48:41 --> Helper loaded: url_helper
INFO - 2024-08-23 10:48:41 --> Helper loaded: file_helper
INFO - 2024-08-23 10:48:41 --> Helper loaded: form_helper
INFO - 2024-08-23 10:48:41 --> Helper loaded: my_helper
INFO - 2024-08-23 10:48:41 --> Database Driver Class Initialized
INFO - 2024-08-23 10:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 10:48:41 --> Controller Class Initialized
DEBUG - 2024-08-23 10:48:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-23 12:33:21 --> Config Class Initialized
INFO - 2024-08-23 12:33:21 --> Hooks Class Initialized
DEBUG - 2024-08-23 12:33:21 --> UTF-8 Support Enabled
INFO - 2024-08-23 12:33:21 --> Utf8 Class Initialized
INFO - 2024-08-23 12:33:21 --> URI Class Initialized
INFO - 2024-08-23 12:33:21 --> Router Class Initialized
INFO - 2024-08-23 12:33:21 --> Output Class Initialized
INFO - 2024-08-23 12:33:21 --> Security Class Initialized
DEBUG - 2024-08-23 12:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 12:33:21 --> Input Class Initialized
INFO - 2024-08-23 12:33:21 --> Language Class Initialized
INFO - 2024-08-23 12:33:21 --> Language Class Initialized
INFO - 2024-08-23 12:33:21 --> Config Class Initialized
INFO - 2024-08-23 12:33:21 --> Loader Class Initialized
INFO - 2024-08-23 12:33:21 --> Helper loaded: url_helper
INFO - 2024-08-23 12:33:21 --> Helper loaded: file_helper
INFO - 2024-08-23 12:33:21 --> Helper loaded: form_helper
INFO - 2024-08-23 12:33:21 --> Helper loaded: my_helper
INFO - 2024-08-23 12:33:21 --> Database Driver Class Initialized
INFO - 2024-08-23 12:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 12:33:21 --> Controller Class Initialized
INFO - 2024-08-23 12:33:21 --> Helper loaded: cookie_helper
INFO - 2024-08-23 12:33:21 --> Final output sent to browser
DEBUG - 2024-08-23 12:33:21 --> Total execution time: 0.0479
INFO - 2024-08-23 12:33:22 --> Config Class Initialized
INFO - 2024-08-23 12:33:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 12:33:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 12:33:22 --> Utf8 Class Initialized
INFO - 2024-08-23 12:33:22 --> URI Class Initialized
INFO - 2024-08-23 12:33:22 --> Router Class Initialized
INFO - 2024-08-23 12:33:22 --> Output Class Initialized
INFO - 2024-08-23 12:33:22 --> Security Class Initialized
DEBUG - 2024-08-23 12:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 12:33:22 --> Input Class Initialized
INFO - 2024-08-23 12:33:22 --> Language Class Initialized
INFO - 2024-08-23 12:33:22 --> Language Class Initialized
INFO - 2024-08-23 12:33:22 --> Config Class Initialized
INFO - 2024-08-23 12:33:22 --> Loader Class Initialized
INFO - 2024-08-23 12:33:22 --> Helper loaded: url_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: file_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: form_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: my_helper
INFO - 2024-08-23 12:33:22 --> Database Driver Class Initialized
INFO - 2024-08-23 12:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 12:33:22 --> Controller Class Initialized
INFO - 2024-08-23 12:33:22 --> Helper loaded: cookie_helper
INFO - 2024-08-23 12:33:22 --> Config Class Initialized
INFO - 2024-08-23 12:33:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 12:33:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 12:33:22 --> Utf8 Class Initialized
INFO - 2024-08-23 12:33:22 --> URI Class Initialized
INFO - 2024-08-23 12:33:22 --> Router Class Initialized
INFO - 2024-08-23 12:33:22 --> Output Class Initialized
INFO - 2024-08-23 12:33:22 --> Security Class Initialized
DEBUG - 2024-08-23 12:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 12:33:22 --> Input Class Initialized
INFO - 2024-08-23 12:33:22 --> Language Class Initialized
INFO - 2024-08-23 12:33:22 --> Language Class Initialized
INFO - 2024-08-23 12:33:22 --> Config Class Initialized
INFO - 2024-08-23 12:33:22 --> Loader Class Initialized
INFO - 2024-08-23 12:33:22 --> Helper loaded: url_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: file_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: form_helper
INFO - 2024-08-23 12:33:22 --> Helper loaded: my_helper
INFO - 2024-08-23 12:33:22 --> Database Driver Class Initialized
INFO - 2024-08-23 12:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 12:33:22 --> Controller Class Initialized
DEBUG - 2024-08-23 12:33:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 12:33:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 12:33:22 --> Final output sent to browser
DEBUG - 2024-08-23 12:33:22 --> Total execution time: 0.0340
INFO - 2024-08-23 16:09:27 --> Config Class Initialized
INFO - 2024-08-23 16:09:27 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:27 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:27 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:27 --> URI Class Initialized
INFO - 2024-08-23 16:09:27 --> Router Class Initialized
INFO - 2024-08-23 16:09:27 --> Output Class Initialized
INFO - 2024-08-23 16:09:27 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:27 --> Input Class Initialized
INFO - 2024-08-23 16:09:27 --> Language Class Initialized
INFO - 2024-08-23 16:09:27 --> Language Class Initialized
INFO - 2024-08-23 16:09:27 --> Config Class Initialized
INFO - 2024-08-23 16:09:27 --> Loader Class Initialized
INFO - 2024-08-23 16:09:27 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:27 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:27 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:27 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:28 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:28 --> Controller Class Initialized
DEBUG - 2024-08-23 16:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-23 16:09:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:09:28 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:28 --> Total execution time: 0.0571
INFO - 2024-08-23 16:09:31 --> Config Class Initialized
INFO - 2024-08-23 16:09:31 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:31 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:31 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:31 --> URI Class Initialized
INFO - 2024-08-23 16:09:31 --> Router Class Initialized
INFO - 2024-08-23 16:09:31 --> Output Class Initialized
INFO - 2024-08-23 16:09:31 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:31 --> Input Class Initialized
INFO - 2024-08-23 16:09:31 --> Language Class Initialized
INFO - 2024-08-23 16:09:31 --> Language Class Initialized
INFO - 2024-08-23 16:09:31 --> Config Class Initialized
INFO - 2024-08-23 16:09:31 --> Loader Class Initialized
INFO - 2024-08-23 16:09:31 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:31 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:31 --> Controller Class Initialized
INFO - 2024-08-23 16:09:31 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:09:31 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:31 --> Total execution time: 0.0779
INFO - 2024-08-23 16:09:31 --> Config Class Initialized
INFO - 2024-08-23 16:09:31 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:31 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:31 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:31 --> URI Class Initialized
INFO - 2024-08-23 16:09:31 --> Router Class Initialized
INFO - 2024-08-23 16:09:31 --> Output Class Initialized
INFO - 2024-08-23 16:09:31 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:31 --> Input Class Initialized
INFO - 2024-08-23 16:09:31 --> Language Class Initialized
INFO - 2024-08-23 16:09:31 --> Language Class Initialized
INFO - 2024-08-23 16:09:31 --> Config Class Initialized
INFO - 2024-08-23 16:09:31 --> Loader Class Initialized
INFO - 2024-08-23 16:09:31 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:31 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:31 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:31 --> Controller Class Initialized
DEBUG - 2024-08-23 16:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-23 16:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:09:31 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:31 --> Total execution time: 0.0665
INFO - 2024-08-23 16:09:48 --> Config Class Initialized
INFO - 2024-08-23 16:09:48 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:48 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:48 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:48 --> URI Class Initialized
INFO - 2024-08-23 16:09:48 --> Router Class Initialized
INFO - 2024-08-23 16:09:48 --> Output Class Initialized
INFO - 2024-08-23 16:09:48 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:48 --> Input Class Initialized
INFO - 2024-08-23 16:09:48 --> Language Class Initialized
INFO - 2024-08-23 16:09:48 --> Language Class Initialized
INFO - 2024-08-23 16:09:48 --> Config Class Initialized
INFO - 2024-08-23 16:09:48 --> Loader Class Initialized
INFO - 2024-08-23 16:09:48 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:48 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:48 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:48 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:48 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:48 --> Controller Class Initialized
INFO - 2024-08-23 16:09:48 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:09:50 --> Config Class Initialized
INFO - 2024-08-23 16:09:50 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:50 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:50 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:50 --> URI Class Initialized
INFO - 2024-08-23 16:09:50 --> Router Class Initialized
INFO - 2024-08-23 16:09:50 --> Output Class Initialized
INFO - 2024-08-23 16:09:50 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:50 --> Input Class Initialized
INFO - 2024-08-23 16:09:50 --> Language Class Initialized
INFO - 2024-08-23 16:09:50 --> Language Class Initialized
INFO - 2024-08-23 16:09:50 --> Config Class Initialized
INFO - 2024-08-23 16:09:50 --> Loader Class Initialized
INFO - 2024-08-23 16:09:50 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:50 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:50 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:50 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:50 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:50 --> Controller Class Initialized
INFO - 2024-08-23 16:09:51 --> Config Class Initialized
INFO - 2024-08-23 16:09:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:51 --> URI Class Initialized
INFO - 2024-08-23 16:09:51 --> Router Class Initialized
INFO - 2024-08-23 16:09:51 --> Output Class Initialized
INFO - 2024-08-23 16:09:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:51 --> Input Class Initialized
INFO - 2024-08-23 16:09:51 --> Language Class Initialized
INFO - 2024-08-23 16:09:51 --> Language Class Initialized
INFO - 2024-08-23 16:09:51 --> Config Class Initialized
INFO - 2024-08-23 16:09:51 --> Loader Class Initialized
INFO - 2024-08-23 16:09:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:51 --> Controller Class Initialized
DEBUG - 2024-08-23 16:09:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-23 16:09:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:09:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:51 --> Total execution time: 0.0430
INFO - 2024-08-23 16:09:59 --> Config Class Initialized
INFO - 2024-08-23 16:09:59 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:59 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:59 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:59 --> URI Class Initialized
INFO - 2024-08-23 16:09:59 --> Router Class Initialized
INFO - 2024-08-23 16:09:59 --> Output Class Initialized
INFO - 2024-08-23 16:09:59 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:59 --> Input Class Initialized
INFO - 2024-08-23 16:09:59 --> Language Class Initialized
INFO - 2024-08-23 16:09:59 --> Language Class Initialized
INFO - 2024-08-23 16:09:59 --> Config Class Initialized
INFO - 2024-08-23 16:09:59 --> Loader Class Initialized
INFO - 2024-08-23 16:09:59 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:59 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:59 --> Controller Class Initialized
INFO - 2024-08-23 16:09:59 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:09:59 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:59 --> Total execution time: 0.0585
INFO - 2024-08-23 16:09:59 --> Config Class Initialized
INFO - 2024-08-23 16:09:59 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:09:59 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:09:59 --> Utf8 Class Initialized
INFO - 2024-08-23 16:09:59 --> URI Class Initialized
INFO - 2024-08-23 16:09:59 --> Router Class Initialized
INFO - 2024-08-23 16:09:59 --> Output Class Initialized
INFO - 2024-08-23 16:09:59 --> Security Class Initialized
DEBUG - 2024-08-23 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:09:59 --> Input Class Initialized
INFO - 2024-08-23 16:09:59 --> Language Class Initialized
INFO - 2024-08-23 16:09:59 --> Language Class Initialized
INFO - 2024-08-23 16:09:59 --> Config Class Initialized
INFO - 2024-08-23 16:09:59 --> Loader Class Initialized
INFO - 2024-08-23 16:09:59 --> Helper loaded: url_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: file_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: form_helper
INFO - 2024-08-23 16:09:59 --> Helper loaded: my_helper
INFO - 2024-08-23 16:09:59 --> Database Driver Class Initialized
INFO - 2024-08-23 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:09:59 --> Controller Class Initialized
DEBUG - 2024-08-23 16:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-08-23 16:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:09:59 --> Final output sent to browser
DEBUG - 2024-08-23 16:09:59 --> Total execution time: 0.0507
INFO - 2024-08-23 16:10:09 --> Config Class Initialized
INFO - 2024-08-23 16:10:09 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:09 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:09 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:09 --> URI Class Initialized
INFO - 2024-08-23 16:10:09 --> Router Class Initialized
INFO - 2024-08-23 16:10:09 --> Output Class Initialized
INFO - 2024-08-23 16:10:09 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:09 --> Input Class Initialized
INFO - 2024-08-23 16:10:09 --> Language Class Initialized
INFO - 2024-08-23 16:10:09 --> Language Class Initialized
INFO - 2024-08-23 16:10:09 --> Config Class Initialized
INFO - 2024-08-23 16:10:09 --> Loader Class Initialized
INFO - 2024-08-23 16:10:09 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:09 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:09 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:09 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:09 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:09 --> Controller Class Initialized
DEBUG - 2024-08-23 16:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-08-23 16:10:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:10:09 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:09 --> Total execution time: 0.0386
INFO - 2024-08-23 16:10:11 --> Config Class Initialized
INFO - 2024-08-23 16:10:11 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:11 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:11 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:11 --> URI Class Initialized
INFO - 2024-08-23 16:10:11 --> Router Class Initialized
INFO - 2024-08-23 16:10:11 --> Output Class Initialized
INFO - 2024-08-23 16:10:11 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:11 --> Input Class Initialized
INFO - 2024-08-23 16:10:11 --> Language Class Initialized
INFO - 2024-08-23 16:10:11 --> Language Class Initialized
INFO - 2024-08-23 16:10:11 --> Config Class Initialized
INFO - 2024-08-23 16:10:11 --> Loader Class Initialized
INFO - 2024-08-23 16:10:11 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:11 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:11 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:11 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:11 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:11 --> Controller Class Initialized
DEBUG - 2024-08-23 16:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-08-23 16:10:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:10:11 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:11 --> Total execution time: 0.0951
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:14 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:14 --> URI Class Initialized
INFO - 2024-08-23 16:10:14 --> Router Class Initialized
INFO - 2024-08-23 16:10:14 --> Output Class Initialized
INFO - 2024-08-23 16:10:14 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:14 --> Input Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Loader Class Initialized
INFO - 2024-08-23 16:10:14 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:14 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:14 --> Controller Class Initialized
INFO - 2024-08-23 16:10:14 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:14 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:14 --> URI Class Initialized
INFO - 2024-08-23 16:10:14 --> Router Class Initialized
INFO - 2024-08-23 16:10:14 --> Output Class Initialized
INFO - 2024-08-23 16:10:14 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:14 --> Input Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Loader Class Initialized
INFO - 2024-08-23 16:10:14 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:14 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:14 --> Controller Class Initialized
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:14 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:14 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:14 --> URI Class Initialized
INFO - 2024-08-23 16:10:14 --> Router Class Initialized
INFO - 2024-08-23 16:10:14 --> Output Class Initialized
INFO - 2024-08-23 16:10:14 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:14 --> Input Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Language Class Initialized
INFO - 2024-08-23 16:10:14 --> Config Class Initialized
INFO - 2024-08-23 16:10:14 --> Loader Class Initialized
INFO - 2024-08-23 16:10:14 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:14 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:14 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:15 --> Controller Class Initialized
DEBUG - 2024-08-23 16:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-23 16:10:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:10:15 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:15 --> Total execution time: 0.0356
INFO - 2024-08-23 16:10:22 --> Config Class Initialized
INFO - 2024-08-23 16:10:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:22 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:22 --> URI Class Initialized
INFO - 2024-08-23 16:10:22 --> Router Class Initialized
INFO - 2024-08-23 16:10:22 --> Output Class Initialized
INFO - 2024-08-23 16:10:22 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:22 --> Input Class Initialized
INFO - 2024-08-23 16:10:22 --> Language Class Initialized
INFO - 2024-08-23 16:10:22 --> Language Class Initialized
INFO - 2024-08-23 16:10:22 --> Config Class Initialized
INFO - 2024-08-23 16:10:22 --> Loader Class Initialized
INFO - 2024-08-23 16:10:22 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:22 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:22 --> Controller Class Initialized
INFO - 2024-08-23 16:10:22 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:10:22 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:22 --> Total execution time: 0.0347
INFO - 2024-08-23 16:10:22 --> Config Class Initialized
INFO - 2024-08-23 16:10:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:22 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:22 --> URI Class Initialized
INFO - 2024-08-23 16:10:22 --> Router Class Initialized
INFO - 2024-08-23 16:10:22 --> Output Class Initialized
INFO - 2024-08-23 16:10:22 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:22 --> Input Class Initialized
INFO - 2024-08-23 16:10:22 --> Language Class Initialized
INFO - 2024-08-23 16:10:22 --> Language Class Initialized
INFO - 2024-08-23 16:10:22 --> Config Class Initialized
INFO - 2024-08-23 16:10:22 --> Loader Class Initialized
INFO - 2024-08-23 16:10:22 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:22 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:22 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:22 --> Controller Class Initialized
DEBUG - 2024-08-23 16:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-23 16:10:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:10:22 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:22 --> Total execution time: 0.0525
INFO - 2024-08-23 16:10:29 --> Config Class Initialized
INFO - 2024-08-23 16:10:29 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:29 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:29 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:29 --> URI Class Initialized
INFO - 2024-08-23 16:10:29 --> Router Class Initialized
INFO - 2024-08-23 16:10:29 --> Output Class Initialized
INFO - 2024-08-23 16:10:29 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:29 --> Input Class Initialized
INFO - 2024-08-23 16:10:29 --> Language Class Initialized
INFO - 2024-08-23 16:10:29 --> Language Class Initialized
INFO - 2024-08-23 16:10:29 --> Config Class Initialized
INFO - 2024-08-23 16:10:29 --> Loader Class Initialized
INFO - 2024-08-23 16:10:29 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:29 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:29 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:29 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:29 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:29 --> Controller Class Initialized
INFO - 2024-08-23 16:10:29 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:10:30 --> Config Class Initialized
INFO - 2024-08-23 16:10:30 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:30 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:30 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:30 --> URI Class Initialized
INFO - 2024-08-23 16:10:30 --> Router Class Initialized
INFO - 2024-08-23 16:10:30 --> Output Class Initialized
INFO - 2024-08-23 16:10:30 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:30 --> Input Class Initialized
INFO - 2024-08-23 16:10:30 --> Language Class Initialized
INFO - 2024-08-23 16:10:30 --> Language Class Initialized
INFO - 2024-08-23 16:10:30 --> Config Class Initialized
INFO - 2024-08-23 16:10:30 --> Loader Class Initialized
INFO - 2024-08-23 16:10:30 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:30 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:30 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:30 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:30 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:30 --> Controller Class Initialized
INFO - 2024-08-23 16:10:34 --> Config Class Initialized
INFO - 2024-08-23 16:10:34 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:10:34 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:10:34 --> Utf8 Class Initialized
INFO - 2024-08-23 16:10:34 --> URI Class Initialized
INFO - 2024-08-23 16:10:34 --> Router Class Initialized
INFO - 2024-08-23 16:10:34 --> Output Class Initialized
INFO - 2024-08-23 16:10:34 --> Security Class Initialized
DEBUG - 2024-08-23 16:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:10:34 --> Input Class Initialized
INFO - 2024-08-23 16:10:34 --> Language Class Initialized
INFO - 2024-08-23 16:10:34 --> Language Class Initialized
INFO - 2024-08-23 16:10:34 --> Config Class Initialized
INFO - 2024-08-23 16:10:34 --> Loader Class Initialized
INFO - 2024-08-23 16:10:34 --> Helper loaded: url_helper
INFO - 2024-08-23 16:10:34 --> Helper loaded: file_helper
INFO - 2024-08-23 16:10:34 --> Helper loaded: form_helper
INFO - 2024-08-23 16:10:34 --> Helper loaded: my_helper
INFO - 2024-08-23 16:10:34 --> Database Driver Class Initialized
INFO - 2024-08-23 16:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:10:34 --> Controller Class Initialized
DEBUG - 2024-08-23 16:10:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-23 16:10:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:10:34 --> Final output sent to browser
DEBUG - 2024-08-23 16:10:34 --> Total execution time: 0.0341
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:13:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:13:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:13:51 --> URI Class Initialized
INFO - 2024-08-23 16:13:51 --> Router Class Initialized
INFO - 2024-08-23 16:13:51 --> Output Class Initialized
INFO - 2024-08-23 16:13:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:13:51 --> Input Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Loader Class Initialized
INFO - 2024-08-23 16:13:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:13:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:13:51 --> Controller Class Initialized
INFO - 2024-08-23 16:13:51 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:13:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:13:51 --> Total execution time: 0.0429
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:13:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:13:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:13:51 --> URI Class Initialized
INFO - 2024-08-23 16:13:51 --> Router Class Initialized
INFO - 2024-08-23 16:13:51 --> Output Class Initialized
INFO - 2024-08-23 16:13:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:13:51 --> Input Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Loader Class Initialized
INFO - 2024-08-23 16:13:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:13:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:13:51 --> Controller Class Initialized
INFO - 2024-08-23 16:13:51 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:13:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:13:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:13:51 --> URI Class Initialized
INFO - 2024-08-23 16:13:51 --> Router Class Initialized
INFO - 2024-08-23 16:13:51 --> Output Class Initialized
INFO - 2024-08-23 16:13:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:13:51 --> Input Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Language Class Initialized
INFO - 2024-08-23 16:13:51 --> Config Class Initialized
INFO - 2024-08-23 16:13:51 --> Loader Class Initialized
INFO - 2024-08-23 16:13:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:13:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:13:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:13:51 --> Controller Class Initialized
DEBUG - 2024-08-23 16:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:13:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:13:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:13:51 --> Total execution time: 0.0377
INFO - 2024-08-23 16:14:01 --> Config Class Initialized
INFO - 2024-08-23 16:14:01 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:01 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:01 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:01 --> URI Class Initialized
INFO - 2024-08-23 16:14:01 --> Router Class Initialized
INFO - 2024-08-23 16:14:01 --> Output Class Initialized
INFO - 2024-08-23 16:14:01 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:01 --> Input Class Initialized
INFO - 2024-08-23 16:14:01 --> Language Class Initialized
INFO - 2024-08-23 16:14:01 --> Language Class Initialized
INFO - 2024-08-23 16:14:01 --> Config Class Initialized
INFO - 2024-08-23 16:14:01 --> Loader Class Initialized
INFO - 2024-08-23 16:14:01 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:01 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:01 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:01 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:01 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:01 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:06 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:06 --> Total execution time: 5.2410
INFO - 2024-08-23 16:14:06 --> Config Class Initialized
INFO - 2024-08-23 16:14:06 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:06 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:06 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:06 --> URI Class Initialized
INFO - 2024-08-23 16:14:06 --> Router Class Initialized
INFO - 2024-08-23 16:14:06 --> Output Class Initialized
INFO - 2024-08-23 16:14:06 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:06 --> Input Class Initialized
INFO - 2024-08-23 16:14:06 --> Language Class Initialized
INFO - 2024-08-23 16:14:06 --> Language Class Initialized
INFO - 2024-08-23 16:14:06 --> Config Class Initialized
INFO - 2024-08-23 16:14:06 --> Loader Class Initialized
INFO - 2024-08-23 16:14:06 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:06 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:06 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:06 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:06 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:06 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:08 --> Config Class Initialized
INFO - 2024-08-23 16:14:08 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:08 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:08 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:08 --> URI Class Initialized
INFO - 2024-08-23 16:14:08 --> Router Class Initialized
INFO - 2024-08-23 16:14:08 --> Output Class Initialized
INFO - 2024-08-23 16:14:08 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:08 --> Input Class Initialized
INFO - 2024-08-23 16:14:08 --> Language Class Initialized
INFO - 2024-08-23 16:14:08 --> Language Class Initialized
INFO - 2024-08-23 16:14:08 --> Config Class Initialized
INFO - 2024-08-23 16:14:08 --> Loader Class Initialized
INFO - 2024-08-23 16:14:08 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:08 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:08 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:08 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:08 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:11 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:11 --> Total execution time: 4.6646
INFO - 2024-08-23 16:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:11 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:12 --> Config Class Initialized
INFO - 2024-08-23 16:14:12 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:12 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:12 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:12 --> URI Class Initialized
INFO - 2024-08-23 16:14:12 --> Router Class Initialized
INFO - 2024-08-23 16:14:12 --> Output Class Initialized
INFO - 2024-08-23 16:14:12 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:12 --> Input Class Initialized
INFO - 2024-08-23 16:14:12 --> Language Class Initialized
INFO - 2024-08-23 16:14:12 --> Language Class Initialized
INFO - 2024-08-23 16:14:12 --> Config Class Initialized
INFO - 2024-08-23 16:14:12 --> Loader Class Initialized
INFO - 2024-08-23 16:14:12 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:12 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:12 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:12 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:12 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:13 --> Config Class Initialized
INFO - 2024-08-23 16:14:13 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:13 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:13 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:13 --> URI Class Initialized
INFO - 2024-08-23 16:14:13 --> Router Class Initialized
INFO - 2024-08-23 16:14:13 --> Output Class Initialized
INFO - 2024-08-23 16:14:13 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:13 --> Input Class Initialized
INFO - 2024-08-23 16:14:13 --> Language Class Initialized
INFO - 2024-08-23 16:14:13 --> Language Class Initialized
INFO - 2024-08-23 16:14:13 --> Config Class Initialized
INFO - 2024-08-23 16:14:13 --> Loader Class Initialized
INFO - 2024-08-23 16:14:13 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:13 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:13 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:13 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:13 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:15 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:15 --> Total execution time: 7.0980
INFO - 2024-08-23 16:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:15 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:21 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:21 --> Total execution time: 9.1692
INFO - 2024-08-23 16:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:21 --> Controller Class Initialized
INFO - 2024-08-23 16:14:21 --> Config Class Initialized
INFO - 2024-08-23 16:14:21 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:21 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:21 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:21 --> URI Class Initialized
INFO - 2024-08-23 16:14:21 --> Router Class Initialized
INFO - 2024-08-23 16:14:21 --> Output Class Initialized
ERROR - 2024-08-23 16:14:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:21 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:21 --> Input Class Initialized
INFO - 2024-08-23 16:14:21 --> Language Class Initialized
INFO - 2024-08-23 16:14:21 --> Language Class Initialized
INFO - 2024-08-23 16:14:21 --> Config Class Initialized
INFO - 2024-08-23 16:14:21 --> Loader Class Initialized
INFO - 2024-08-23 16:14:21 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:21 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:21 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:21 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:21 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:26 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:26 --> Total execution time: 12.9694
INFO - 2024-08-23 16:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:26 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:31 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:31 --> Total execution time: 10.2648
INFO - 2024-08-23 16:14:32 --> Config Class Initialized
INFO - 2024-08-23 16:14:32 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:32 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:32 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:32 --> URI Class Initialized
INFO - 2024-08-23 16:14:32 --> Router Class Initialized
INFO - 2024-08-23 16:14:32 --> Output Class Initialized
INFO - 2024-08-23 16:14:32 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:32 --> Input Class Initialized
INFO - 2024-08-23 16:14:32 --> Language Class Initialized
INFO - 2024-08-23 16:14:32 --> Language Class Initialized
INFO - 2024-08-23 16:14:32 --> Config Class Initialized
INFO - 2024-08-23 16:14:32 --> Loader Class Initialized
INFO - 2024-08-23 16:14:32 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:32 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:32 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:32 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:32 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:32 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:32 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:36 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:36 --> Total execution time: 4.6701
INFO - 2024-08-23 16:14:36 --> Config Class Initialized
INFO - 2024-08-23 16:14:36 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:36 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:36 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:36 --> URI Class Initialized
INFO - 2024-08-23 16:14:36 --> Router Class Initialized
INFO - 2024-08-23 16:14:36 --> Output Class Initialized
INFO - 2024-08-23 16:14:36 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:36 --> Input Class Initialized
INFO - 2024-08-23 16:14:36 --> Language Class Initialized
INFO - 2024-08-23 16:14:36 --> Language Class Initialized
INFO - 2024-08-23 16:14:36 --> Config Class Initialized
INFO - 2024-08-23 16:14:36 --> Loader Class Initialized
INFO - 2024-08-23 16:14:36 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:36 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:36 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:36 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:36 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:36 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:42 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:42 --> Total execution time: 5.3704
INFO - 2024-08-23 16:14:42 --> Config Class Initialized
INFO - 2024-08-23 16:14:42 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:42 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:42 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:42 --> URI Class Initialized
INFO - 2024-08-23 16:14:42 --> Router Class Initialized
INFO - 2024-08-23 16:14:42 --> Output Class Initialized
INFO - 2024-08-23 16:14:42 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:42 --> Input Class Initialized
INFO - 2024-08-23 16:14:42 --> Language Class Initialized
INFO - 2024-08-23 16:14:42 --> Language Class Initialized
INFO - 2024-08-23 16:14:42 --> Config Class Initialized
INFO - 2024-08-23 16:14:42 --> Loader Class Initialized
INFO - 2024-08-23 16:14:42 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:42 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:42 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:42 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:42 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:42 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:43 --> Config Class Initialized
INFO - 2024-08-23 16:14:43 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:43 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:43 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:43 --> URI Class Initialized
INFO - 2024-08-23 16:14:43 --> Router Class Initialized
INFO - 2024-08-23 16:14:43 --> Output Class Initialized
INFO - 2024-08-23 16:14:43 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:43 --> Input Class Initialized
INFO - 2024-08-23 16:14:43 --> Language Class Initialized
INFO - 2024-08-23 16:14:43 --> Language Class Initialized
INFO - 2024-08-23 16:14:43 --> Config Class Initialized
INFO - 2024-08-23 16:14:43 --> Loader Class Initialized
INFO - 2024-08-23 16:14:43 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:43 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:43 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:43 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:43 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:46 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:46 --> Total execution time: 4.4713
INFO - 2024-08-23 16:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:46 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:51 --> Total execution time: 8.0548
INFO - 2024-08-23 16:14:51 --> Config Class Initialized
INFO - 2024-08-23 16:14:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:51 --> URI Class Initialized
INFO - 2024-08-23 16:14:51 --> Router Class Initialized
INFO - 2024-08-23 16:14:51 --> Output Class Initialized
INFO - 2024-08-23 16:14:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:51 --> Input Class Initialized
INFO - 2024-08-23 16:14:51 --> Language Class Initialized
INFO - 2024-08-23 16:14:51 --> Language Class Initialized
INFO - 2024-08-23 16:14:51 --> Config Class Initialized
INFO - 2024-08-23 16:14:51 --> Loader Class Initialized
INFO - 2024-08-23 16:14:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:51 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:14:56 --> Final output sent to browser
DEBUG - 2024-08-23 16:14:56 --> Total execution time: 5.1155
INFO - 2024-08-23 16:14:56 --> Config Class Initialized
INFO - 2024-08-23 16:14:56 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:14:56 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:14:56 --> Utf8 Class Initialized
INFO - 2024-08-23 16:14:56 --> URI Class Initialized
INFO - 2024-08-23 16:14:56 --> Router Class Initialized
INFO - 2024-08-23 16:14:56 --> Output Class Initialized
INFO - 2024-08-23 16:14:56 --> Security Class Initialized
DEBUG - 2024-08-23 16:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:14:56 --> Input Class Initialized
INFO - 2024-08-23 16:14:56 --> Language Class Initialized
INFO - 2024-08-23 16:14:56 --> Language Class Initialized
INFO - 2024-08-23 16:14:56 --> Config Class Initialized
INFO - 2024-08-23 16:14:56 --> Loader Class Initialized
INFO - 2024-08-23 16:14:56 --> Helper loaded: url_helper
INFO - 2024-08-23 16:14:56 --> Helper loaded: file_helper
INFO - 2024-08-23 16:14:56 --> Helper loaded: form_helper
INFO - 2024-08-23 16:14:56 --> Helper loaded: my_helper
INFO - 2024-08-23 16:14:56 --> Database Driver Class Initialized
INFO - 2024-08-23 16:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:14:56 --> Controller Class Initialized
ERROR - 2024-08-23 16:14:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:14:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:14:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:01 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:01 --> Total execution time: 4.5137
INFO - 2024-08-23 16:15:01 --> Config Class Initialized
INFO - 2024-08-23 16:15:01 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:01 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:01 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:01 --> URI Class Initialized
INFO - 2024-08-23 16:15:01 --> Router Class Initialized
INFO - 2024-08-23 16:15:01 --> Output Class Initialized
INFO - 2024-08-23 16:15:01 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:01 --> Input Class Initialized
INFO - 2024-08-23 16:15:01 --> Language Class Initialized
INFO - 2024-08-23 16:15:01 --> Language Class Initialized
INFO - 2024-08-23 16:15:01 --> Config Class Initialized
INFO - 2024-08-23 16:15:01 --> Loader Class Initialized
INFO - 2024-08-23 16:15:01 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:01 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:01 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:01 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:01 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:01 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:06 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:06 --> Total execution time: 5.5163
INFO - 2024-08-23 16:15:07 --> Config Class Initialized
INFO - 2024-08-23 16:15:07 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:07 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:07 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:07 --> URI Class Initialized
INFO - 2024-08-23 16:15:07 --> Router Class Initialized
INFO - 2024-08-23 16:15:07 --> Output Class Initialized
INFO - 2024-08-23 16:15:07 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:07 --> Input Class Initialized
INFO - 2024-08-23 16:15:07 --> Language Class Initialized
INFO - 2024-08-23 16:15:07 --> Language Class Initialized
INFO - 2024-08-23 16:15:07 --> Config Class Initialized
INFO - 2024-08-23 16:15:07 --> Loader Class Initialized
INFO - 2024-08-23 16:15:07 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:07 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:07 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:07 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:07 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:07 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:11 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:11 --> Total execution time: 4.4683
INFO - 2024-08-23 16:15:11 --> Config Class Initialized
INFO - 2024-08-23 16:15:11 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:11 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:11 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:11 --> URI Class Initialized
INFO - 2024-08-23 16:15:11 --> Router Class Initialized
INFO - 2024-08-23 16:15:11 --> Output Class Initialized
INFO - 2024-08-23 16:15:11 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:11 --> Input Class Initialized
INFO - 2024-08-23 16:15:11 --> Language Class Initialized
INFO - 2024-08-23 16:15:11 --> Language Class Initialized
INFO - 2024-08-23 16:15:11 --> Config Class Initialized
INFO - 2024-08-23 16:15:11 --> Loader Class Initialized
INFO - 2024-08-23 16:15:11 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:11 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:11 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:11 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:11 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:11 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:11 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:15 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:15 --> Total execution time: 4.2864
INFO - 2024-08-23 16:15:47 --> Config Class Initialized
INFO - 2024-08-23 16:15:47 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:47 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:47 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:47 --> URI Class Initialized
INFO - 2024-08-23 16:15:47 --> Router Class Initialized
INFO - 2024-08-23 16:15:47 --> Output Class Initialized
INFO - 2024-08-23 16:15:47 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:47 --> Input Class Initialized
INFO - 2024-08-23 16:15:47 --> Language Class Initialized
INFO - 2024-08-23 16:15:47 --> Language Class Initialized
INFO - 2024-08-23 16:15:47 --> Config Class Initialized
INFO - 2024-08-23 16:15:47 --> Loader Class Initialized
INFO - 2024-08-23 16:15:47 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:47 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:47 --> Config Class Initialized
INFO - 2024-08-23 16:15:47 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:47 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:47 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:47 --> URI Class Initialized
INFO - 2024-08-23 16:15:47 --> Router Class Initialized
INFO - 2024-08-23 16:15:47 --> Output Class Initialized
INFO - 2024-08-23 16:15:47 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:47 --> Input Class Initialized
INFO - 2024-08-23 16:15:47 --> Language Class Initialized
INFO - 2024-08-23 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:47 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:47 --> Language Class Initialized
INFO - 2024-08-23 16:15:47 --> Config Class Initialized
INFO - 2024-08-23 16:15:47 --> Loader Class Initialized
INFO - 2024-08-23 16:15:47 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:47 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:47 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:51 --> Total execution time: 4.3300
INFO - 2024-08-23 16:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:51 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:15:56 --> Final output sent to browser
DEBUG - 2024-08-23 16:15:56 --> Total execution time: 8.9302
INFO - 2024-08-23 16:15:56 --> Config Class Initialized
INFO - 2024-08-23 16:15:56 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:15:56 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:15:56 --> Utf8 Class Initialized
INFO - 2024-08-23 16:15:56 --> URI Class Initialized
INFO - 2024-08-23 16:15:56 --> Router Class Initialized
INFO - 2024-08-23 16:15:56 --> Output Class Initialized
INFO - 2024-08-23 16:15:56 --> Security Class Initialized
DEBUG - 2024-08-23 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:15:56 --> Input Class Initialized
INFO - 2024-08-23 16:15:56 --> Language Class Initialized
INFO - 2024-08-23 16:15:56 --> Language Class Initialized
INFO - 2024-08-23 16:15:56 --> Config Class Initialized
INFO - 2024-08-23 16:15:56 --> Loader Class Initialized
INFO - 2024-08-23 16:15:56 --> Helper loaded: url_helper
INFO - 2024-08-23 16:15:56 --> Helper loaded: file_helper
INFO - 2024-08-23 16:15:56 --> Helper loaded: form_helper
INFO - 2024-08-23 16:15:56 --> Helper loaded: my_helper
INFO - 2024-08-23 16:15:56 --> Database Driver Class Initialized
INFO - 2024-08-23 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:15:56 --> Controller Class Initialized
ERROR - 2024-08-23 16:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:15:56 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:15:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:04 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:04 --> Total execution time: 7.6458
INFO - 2024-08-23 16:16:04 --> Config Class Initialized
INFO - 2024-08-23 16:16:04 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:04 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:04 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:04 --> URI Class Initialized
INFO - 2024-08-23 16:16:04 --> Router Class Initialized
INFO - 2024-08-23 16:16:04 --> Output Class Initialized
INFO - 2024-08-23 16:16:04 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:04 --> Input Class Initialized
INFO - 2024-08-23 16:16:04 --> Language Class Initialized
INFO - 2024-08-23 16:16:04 --> Language Class Initialized
INFO - 2024-08-23 16:16:04 --> Config Class Initialized
INFO - 2024-08-23 16:16:04 --> Loader Class Initialized
INFO - 2024-08-23 16:16:04 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:04 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:04 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:04 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:04 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:04 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:06 --> Config Class Initialized
INFO - 2024-08-23 16:16:06 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:06 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:06 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:06 --> URI Class Initialized
INFO - 2024-08-23 16:16:06 --> Router Class Initialized
INFO - 2024-08-23 16:16:06 --> Output Class Initialized
INFO - 2024-08-23 16:16:06 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:06 --> Input Class Initialized
INFO - 2024-08-23 16:16:06 --> Language Class Initialized
INFO - 2024-08-23 16:16:06 --> Language Class Initialized
INFO - 2024-08-23 16:16:06 --> Config Class Initialized
INFO - 2024-08-23 16:16:06 --> Loader Class Initialized
INFO - 2024-08-23 16:16:06 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:06 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:06 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:06 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:06 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:08 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:08 --> Total execution time: 4.3102
INFO - 2024-08-23 16:16:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:08 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:12 --> Config Class Initialized
INFO - 2024-08-23 16:16:12 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:12 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:12 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:12 --> URI Class Initialized
INFO - 2024-08-23 16:16:12 --> Router Class Initialized
INFO - 2024-08-23 16:16:12 --> Output Class Initialized
INFO - 2024-08-23 16:16:12 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:12 --> Input Class Initialized
INFO - 2024-08-23 16:16:12 --> Language Class Initialized
INFO - 2024-08-23 16:16:12 --> Language Class Initialized
INFO - 2024-08-23 16:16:12 --> Config Class Initialized
INFO - 2024-08-23 16:16:12 --> Loader Class Initialized
INFO - 2024-08-23 16:16:12 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:12 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:12 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:12 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:12 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:13 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:13 --> Total execution time: 7.7674
INFO - 2024-08-23 16:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:13 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:18 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:18 --> Total execution time: 5.7042
INFO - 2024-08-23 16:16:18 --> Config Class Initialized
INFO - 2024-08-23 16:16:18 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:18 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:18 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:18 --> URI Class Initialized
INFO - 2024-08-23 16:16:18 --> Router Class Initialized
INFO - 2024-08-23 16:16:18 --> Output Class Initialized
INFO - 2024-08-23 16:16:18 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:18 --> Input Class Initialized
INFO - 2024-08-23 16:16:18 --> Language Class Initialized
INFO - 2024-08-23 16:16:18 --> Language Class Initialized
INFO - 2024-08-23 16:16:18 --> Config Class Initialized
INFO - 2024-08-23 16:16:18 --> Loader Class Initialized
INFO - 2024-08-23 16:16:18 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:18 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:18 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:18 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:18 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:18 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:18 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:23 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:23 --> Total execution time: 4.3917
INFO - 2024-08-23 16:16:23 --> Config Class Initialized
INFO - 2024-08-23 16:16:23 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:23 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:23 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:23 --> URI Class Initialized
INFO - 2024-08-23 16:16:23 --> Router Class Initialized
INFO - 2024-08-23 16:16:23 --> Output Class Initialized
INFO - 2024-08-23 16:16:23 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:23 --> Input Class Initialized
INFO - 2024-08-23 16:16:23 --> Language Class Initialized
INFO - 2024-08-23 16:16:23 --> Language Class Initialized
INFO - 2024-08-23 16:16:23 --> Config Class Initialized
INFO - 2024-08-23 16:16:23 --> Loader Class Initialized
INFO - 2024-08-23 16:16:23 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:23 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:23 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:23 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:23 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:23 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:27 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:27 --> Total execution time: 4.1461
INFO - 2024-08-23 16:16:27 --> Config Class Initialized
INFO - 2024-08-23 16:16:27 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:27 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:27 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:27 --> URI Class Initialized
INFO - 2024-08-23 16:16:27 --> Router Class Initialized
INFO - 2024-08-23 16:16:27 --> Output Class Initialized
INFO - 2024-08-23 16:16:27 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:27 --> Input Class Initialized
INFO - 2024-08-23 16:16:27 --> Language Class Initialized
INFO - 2024-08-23 16:16:27 --> Language Class Initialized
INFO - 2024-08-23 16:16:27 --> Config Class Initialized
INFO - 2024-08-23 16:16:27 --> Loader Class Initialized
INFO - 2024-08-23 16:16:27 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:27 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:27 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:27 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:27 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:27 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:31 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:31 --> Total execution time: 4.1584
INFO - 2024-08-23 16:16:31 --> Config Class Initialized
INFO - 2024-08-23 16:16:31 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:31 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:31 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:31 --> URI Class Initialized
INFO - 2024-08-23 16:16:31 --> Router Class Initialized
INFO - 2024-08-23 16:16:31 --> Output Class Initialized
INFO - 2024-08-23 16:16:31 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:31 --> Input Class Initialized
INFO - 2024-08-23 16:16:31 --> Language Class Initialized
INFO - 2024-08-23 16:16:31 --> Language Class Initialized
INFO - 2024-08-23 16:16:31 --> Config Class Initialized
INFO - 2024-08-23 16:16:31 --> Loader Class Initialized
INFO - 2024-08-23 16:16:31 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:31 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:31 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:31 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:31 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:31 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:34 --> Config Class Initialized
INFO - 2024-08-23 16:16:34 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:34 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:34 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:34 --> URI Class Initialized
INFO - 2024-08-23 16:16:34 --> Router Class Initialized
INFO - 2024-08-23 16:16:34 --> Output Class Initialized
INFO - 2024-08-23 16:16:34 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:34 --> Input Class Initialized
INFO - 2024-08-23 16:16:34 --> Language Class Initialized
INFO - 2024-08-23 16:16:34 --> Language Class Initialized
INFO - 2024-08-23 16:16:34 --> Config Class Initialized
INFO - 2024-08-23 16:16:34 --> Loader Class Initialized
INFO - 2024-08-23 16:16:34 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:34 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:34 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:34 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:34 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:36 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:36 --> Total execution time: 4.7171
INFO - 2024-08-23 16:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:36 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:36 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:36 --> Config Class Initialized
INFO - 2024-08-23 16:16:36 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:36 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:36 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:36 --> URI Class Initialized
INFO - 2024-08-23 16:16:36 --> Router Class Initialized
INFO - 2024-08-23 16:16:36 --> Output Class Initialized
INFO - 2024-08-23 16:16:36 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:36 --> Input Class Initialized
INFO - 2024-08-23 16:16:36 --> Language Class Initialized
INFO - 2024-08-23 16:16:36 --> Language Class Initialized
INFO - 2024-08-23 16:16:36 --> Config Class Initialized
INFO - 2024-08-23 16:16:36 --> Loader Class Initialized
INFO - 2024-08-23 16:16:36 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:36 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:36 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:36 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:36 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:40 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:40 --> Total execution time: 5.7641
INFO - 2024-08-23 16:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:40 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:41 --> Config Class Initialized
INFO - 2024-08-23 16:16:41 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:41 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:41 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:41 --> URI Class Initialized
INFO - 2024-08-23 16:16:41 --> Router Class Initialized
INFO - 2024-08-23 16:16:41 --> Output Class Initialized
INFO - 2024-08-23 16:16:41 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:41 --> Input Class Initialized
INFO - 2024-08-23 16:16:41 --> Language Class Initialized
INFO - 2024-08-23 16:16:41 --> Language Class Initialized
INFO - 2024-08-23 16:16:41 --> Config Class Initialized
INFO - 2024-08-23 16:16:41 --> Loader Class Initialized
INFO - 2024-08-23 16:16:41 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:41 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:41 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:41 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:41 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:45 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:45 --> Total execution time: 9.2238
INFO - 2024-08-23 16:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:45 --> Controller Class Initialized
INFO - 2024-08-23 16:16:45 --> Config Class Initialized
INFO - 2024-08-23 16:16:45 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:45 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:45 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:45 --> URI Class Initialized
INFO - 2024-08-23 16:16:45 --> Router Class Initialized
ERROR - 2024-08-23 16:16:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:45 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:46 --> Output Class Initialized
INFO - 2024-08-23 16:16:46 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:46 --> Input Class Initialized
INFO - 2024-08-23 16:16:46 --> Language Class Initialized
INFO - 2024-08-23 16:16:46 --> Language Class Initialized
INFO - 2024-08-23 16:16:46 --> Config Class Initialized
INFO - 2024-08-23 16:16:46 --> Loader Class Initialized
INFO - 2024-08-23 16:16:46 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:46 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:46 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:46 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:46 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:50 --> Config Class Initialized
INFO - 2024-08-23 16:16:50 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:50 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:50 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:50 --> URI Class Initialized
INFO - 2024-08-23 16:16:50 --> Router Class Initialized
INFO - 2024-08-23 16:16:50 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:50 --> Total execution time: 9.7364
INFO - 2024-08-23 16:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:50 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:51 --> Output Class Initialized
INFO - 2024-08-23 16:16:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:51 --> Input Class Initialized
INFO - 2024-08-23 16:16:51 --> Language Class Initialized
INFO - 2024-08-23 16:16:51 --> Language Class Initialized
INFO - 2024-08-23 16:16:51 --> Config Class Initialized
INFO - 2024-08-23 16:16:51 --> Loader Class Initialized
INFO - 2024-08-23 16:16:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:55 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:55 --> Total execution time: 9.5695
INFO - 2024-08-23 16:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:55 --> Controller Class Initialized
INFO - 2024-08-23 16:16:55 --> Config Class Initialized
INFO - 2024-08-23 16:16:55 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:16:55 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:16:55 --> Utf8 Class Initialized
INFO - 2024-08-23 16:16:55 --> URI Class Initialized
ERROR - 2024-08-23 16:16:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:16:55 --> Router Class Initialized
INFO - 2024-08-23 16:16:55 --> Output Class Initialized
INFO - 2024-08-23 16:16:55 --> Security Class Initialized
DEBUG - 2024-08-23 16:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:16:55 --> Input Class Initialized
INFO - 2024-08-23 16:16:55 --> Language Class Initialized
INFO - 2024-08-23 16:16:55 --> Language Class Initialized
INFO - 2024-08-23 16:16:55 --> Config Class Initialized
INFO - 2024-08-23 16:16:55 --> Loader Class Initialized
INFO - 2024-08-23 16:16:55 --> Helper loaded: url_helper
INFO - 2024-08-23 16:16:55 --> Helper loaded: file_helper
INFO - 2024-08-23 16:16:55 --> Helper loaded: form_helper
INFO - 2024-08-23 16:16:55 --> Helper loaded: my_helper
INFO - 2024-08-23 16:16:55 --> Database Driver Class Initialized
INFO - 2024-08-23 16:16:59 --> Final output sent to browser
DEBUG - 2024-08-23 16:16:59 --> Total execution time: 8.2626
INFO - 2024-08-23 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:16:59 --> Controller Class Initialized
ERROR - 2024-08-23 16:16:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:16:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:16:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:17:03 --> Final output sent to browser
DEBUG - 2024-08-23 16:17:03 --> Total execution time: 8.3441
INFO - 2024-08-23 16:17:04 --> Config Class Initialized
INFO - 2024-08-23 16:17:04 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:17:04 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:17:04 --> Utf8 Class Initialized
INFO - 2024-08-23 16:17:04 --> URI Class Initialized
INFO - 2024-08-23 16:17:04 --> Router Class Initialized
INFO - 2024-08-23 16:17:04 --> Output Class Initialized
INFO - 2024-08-23 16:17:04 --> Security Class Initialized
DEBUG - 2024-08-23 16:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:17:04 --> Input Class Initialized
INFO - 2024-08-23 16:17:04 --> Language Class Initialized
INFO - 2024-08-23 16:17:04 --> Language Class Initialized
INFO - 2024-08-23 16:17:04 --> Config Class Initialized
INFO - 2024-08-23 16:17:04 --> Loader Class Initialized
INFO - 2024-08-23 16:17:04 --> Helper loaded: url_helper
INFO - 2024-08-23 16:17:04 --> Helper loaded: file_helper
INFO - 2024-08-23 16:17:04 --> Helper loaded: form_helper
INFO - 2024-08-23 16:17:04 --> Helper loaded: my_helper
INFO - 2024-08-23 16:17:04 --> Database Driver Class Initialized
INFO - 2024-08-23 16:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:17:04 --> Controller Class Initialized
ERROR - 2024-08-23 16:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:17:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:17:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:17:08 --> Final output sent to browser
DEBUG - 2024-08-23 16:17:08 --> Total execution time: 4.3161
INFO - 2024-08-23 16:17:08 --> Config Class Initialized
INFO - 2024-08-23 16:17:08 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:17:08 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:17:08 --> Utf8 Class Initialized
INFO - 2024-08-23 16:17:08 --> URI Class Initialized
INFO - 2024-08-23 16:17:08 --> Router Class Initialized
INFO - 2024-08-23 16:17:08 --> Output Class Initialized
INFO - 2024-08-23 16:17:08 --> Security Class Initialized
DEBUG - 2024-08-23 16:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:17:08 --> Input Class Initialized
INFO - 2024-08-23 16:17:08 --> Language Class Initialized
INFO - 2024-08-23 16:17:08 --> Language Class Initialized
INFO - 2024-08-23 16:17:08 --> Config Class Initialized
INFO - 2024-08-23 16:17:08 --> Loader Class Initialized
INFO - 2024-08-23 16:17:08 --> Helper loaded: url_helper
INFO - 2024-08-23 16:17:08 --> Helper loaded: file_helper
INFO - 2024-08-23 16:17:08 --> Helper loaded: form_helper
INFO - 2024-08-23 16:17:08 --> Helper loaded: my_helper
INFO - 2024-08-23 16:17:08 --> Database Driver Class Initialized
INFO - 2024-08-23 16:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:17:08 --> Controller Class Initialized
ERROR - 2024-08-23 16:17:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:17:08 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:17:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:17:13 --> Final output sent to browser
DEBUG - 2024-08-23 16:17:13 --> Total execution time: 4.5471
INFO - 2024-08-23 16:19:00 --> Config Class Initialized
INFO - 2024-08-23 16:19:00 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:19:00 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:19:00 --> Utf8 Class Initialized
INFO - 2024-08-23 16:19:00 --> URI Class Initialized
INFO - 2024-08-23 16:19:00 --> Router Class Initialized
INFO - 2024-08-23 16:19:00 --> Output Class Initialized
INFO - 2024-08-23 16:19:00 --> Security Class Initialized
DEBUG - 2024-08-23 16:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:19:00 --> Input Class Initialized
INFO - 2024-08-23 16:19:00 --> Language Class Initialized
INFO - 2024-08-23 16:19:00 --> Language Class Initialized
INFO - 2024-08-23 16:19:00 --> Config Class Initialized
INFO - 2024-08-23 16:19:00 --> Loader Class Initialized
INFO - 2024-08-23 16:19:00 --> Helper loaded: url_helper
INFO - 2024-08-23 16:19:00 --> Helper loaded: file_helper
INFO - 2024-08-23 16:19:00 --> Helper loaded: form_helper
INFO - 2024-08-23 16:19:00 --> Helper loaded: my_helper
INFO - 2024-08-23 16:19:00 --> Database Driver Class Initialized
INFO - 2024-08-23 16:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:19:00 --> Controller Class Initialized
INFO - 2024-08-23 16:19:01 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:19:01 --> Final output sent to browser
DEBUG - 2024-08-23 16:19:01 --> Total execution time: 0.2442
INFO - 2024-08-23 16:20:04 --> Config Class Initialized
INFO - 2024-08-23 16:20:04 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:20:04 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:20:04 --> Utf8 Class Initialized
INFO - 2024-08-23 16:20:04 --> URI Class Initialized
INFO - 2024-08-23 16:20:04 --> Router Class Initialized
INFO - 2024-08-23 16:20:04 --> Output Class Initialized
INFO - 2024-08-23 16:20:04 --> Security Class Initialized
DEBUG - 2024-08-23 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:20:04 --> Input Class Initialized
INFO - 2024-08-23 16:20:04 --> Language Class Initialized
INFO - 2024-08-23 16:20:04 --> Language Class Initialized
INFO - 2024-08-23 16:20:04 --> Config Class Initialized
INFO - 2024-08-23 16:20:04 --> Loader Class Initialized
INFO - 2024-08-23 16:20:04 --> Helper loaded: url_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: file_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: form_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: my_helper
INFO - 2024-08-23 16:20:04 --> Database Driver Class Initialized
INFO - 2024-08-23 16:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:20:04 --> Controller Class Initialized
INFO - 2024-08-23 16:20:04 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:20:04 --> Final output sent to browser
DEBUG - 2024-08-23 16:20:04 --> Total execution time: 0.1790
INFO - 2024-08-23 16:20:04 --> Config Class Initialized
INFO - 2024-08-23 16:20:04 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:20:04 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:20:04 --> Utf8 Class Initialized
INFO - 2024-08-23 16:20:04 --> URI Class Initialized
INFO - 2024-08-23 16:20:04 --> Router Class Initialized
INFO - 2024-08-23 16:20:04 --> Output Class Initialized
INFO - 2024-08-23 16:20:04 --> Security Class Initialized
DEBUG - 2024-08-23 16:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:20:04 --> Input Class Initialized
INFO - 2024-08-23 16:20:04 --> Language Class Initialized
INFO - 2024-08-23 16:20:04 --> Language Class Initialized
INFO - 2024-08-23 16:20:04 --> Config Class Initialized
INFO - 2024-08-23 16:20:04 --> Loader Class Initialized
INFO - 2024-08-23 16:20:04 --> Helper loaded: url_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: file_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: form_helper
INFO - 2024-08-23 16:20:04 --> Helper loaded: my_helper
INFO - 2024-08-23 16:20:04 --> Database Driver Class Initialized
INFO - 2024-08-23 16:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:20:04 --> Controller Class Initialized
INFO - 2024-08-23 16:20:04 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:20:05 --> Config Class Initialized
INFO - 2024-08-23 16:20:05 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:20:05 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:20:05 --> Utf8 Class Initialized
INFO - 2024-08-23 16:20:05 --> URI Class Initialized
INFO - 2024-08-23 16:20:05 --> Router Class Initialized
INFO - 2024-08-23 16:20:05 --> Output Class Initialized
INFO - 2024-08-23 16:20:05 --> Security Class Initialized
DEBUG - 2024-08-23 16:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:20:05 --> Input Class Initialized
INFO - 2024-08-23 16:20:05 --> Language Class Initialized
INFO - 2024-08-23 16:20:05 --> Language Class Initialized
INFO - 2024-08-23 16:20:05 --> Config Class Initialized
INFO - 2024-08-23 16:20:05 --> Loader Class Initialized
INFO - 2024-08-23 16:20:05 --> Helper loaded: url_helper
INFO - 2024-08-23 16:20:05 --> Helper loaded: file_helper
INFO - 2024-08-23 16:20:05 --> Helper loaded: form_helper
INFO - 2024-08-23 16:20:05 --> Helper loaded: my_helper
INFO - 2024-08-23 16:20:05 --> Database Driver Class Initialized
INFO - 2024-08-23 16:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:20:05 --> Controller Class Initialized
DEBUG - 2024-08-23 16:20:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:20:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:20:05 --> Final output sent to browser
DEBUG - 2024-08-23 16:20:05 --> Total execution time: 0.1029
INFO - 2024-08-23 16:20:12 --> Config Class Initialized
INFO - 2024-08-23 16:20:12 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:20:12 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:20:12 --> Utf8 Class Initialized
INFO - 2024-08-23 16:20:12 --> URI Class Initialized
INFO - 2024-08-23 16:20:12 --> Router Class Initialized
INFO - 2024-08-23 16:20:12 --> Output Class Initialized
INFO - 2024-08-23 16:20:12 --> Security Class Initialized
DEBUG - 2024-08-23 16:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:20:12 --> Input Class Initialized
INFO - 2024-08-23 16:20:12 --> Language Class Initialized
INFO - 2024-08-23 16:20:12 --> Language Class Initialized
INFO - 2024-08-23 16:20:12 --> Config Class Initialized
INFO - 2024-08-23 16:20:12 --> Loader Class Initialized
INFO - 2024-08-23 16:20:12 --> Helper loaded: url_helper
INFO - 2024-08-23 16:20:12 --> Helper loaded: file_helper
INFO - 2024-08-23 16:20:12 --> Helper loaded: form_helper
INFO - 2024-08-23 16:20:12 --> Helper loaded: my_helper
INFO - 2024-08-23 16:20:12 --> Database Driver Class Initialized
INFO - 2024-08-23 16:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:20:12 --> Controller Class Initialized
ERROR - 2024-08-23 16:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:20:17 --> Final output sent to browser
DEBUG - 2024-08-23 16:20:17 --> Total execution time: 4.9760
INFO - 2024-08-23 16:21:46 --> Config Class Initialized
INFO - 2024-08-23 16:21:46 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:46 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:46 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:46 --> URI Class Initialized
INFO - 2024-08-23 16:21:46 --> Router Class Initialized
INFO - 2024-08-23 16:21:46 --> Output Class Initialized
INFO - 2024-08-23 16:21:46 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:46 --> Input Class Initialized
INFO - 2024-08-23 16:21:46 --> Language Class Initialized
INFO - 2024-08-23 16:21:46 --> Language Class Initialized
INFO - 2024-08-23 16:21:46 --> Config Class Initialized
INFO - 2024-08-23 16:21:46 --> Loader Class Initialized
INFO - 2024-08-23 16:21:46 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:46 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:46 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:46 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:46 --> Database Driver Class Initialized
INFO - 2024-08-23 16:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:21:46 --> Controller Class Initialized
ERROR - 2024-08-23 16:21:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:21:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:21:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:21:50 --> Final output sent to browser
DEBUG - 2024-08-23 16:21:50 --> Total execution time: 3.8806
INFO - 2024-08-23 16:21:50 --> Config Class Initialized
INFO - 2024-08-23 16:21:50 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:50 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:50 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:50 --> URI Class Initialized
INFO - 2024-08-23 16:21:50 --> Router Class Initialized
INFO - 2024-08-23 16:21:50 --> Output Class Initialized
INFO - 2024-08-23 16:21:50 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:50 --> Input Class Initialized
INFO - 2024-08-23 16:21:50 --> Language Class Initialized
INFO - 2024-08-23 16:21:50 --> Language Class Initialized
INFO - 2024-08-23 16:21:50 --> Config Class Initialized
INFO - 2024-08-23 16:21:50 --> Loader Class Initialized
INFO - 2024-08-23 16:21:50 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:50 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:50 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:50 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:50 --> Database Driver Class Initialized
INFO - 2024-08-23 16:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:21:50 --> Controller Class Initialized
ERROR - 2024-08-23 16:21:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:21:50 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:21:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:21:53 --> Config Class Initialized
INFO - 2024-08-23 16:21:53 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:53 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:53 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:53 --> URI Class Initialized
INFO - 2024-08-23 16:21:53 --> Router Class Initialized
INFO - 2024-08-23 16:21:53 --> Output Class Initialized
INFO - 2024-08-23 16:21:53 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:53 --> Input Class Initialized
INFO - 2024-08-23 16:21:53 --> Language Class Initialized
INFO - 2024-08-23 16:21:53 --> Language Class Initialized
INFO - 2024-08-23 16:21:53 --> Config Class Initialized
INFO - 2024-08-23 16:21:53 --> Loader Class Initialized
INFO - 2024-08-23 16:21:53 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:53 --> Database Driver Class Initialized
INFO - 2024-08-23 16:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:21:53 --> Controller Class Initialized
INFO - 2024-08-23 16:21:53 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:21:53 --> Final output sent to browser
DEBUG - 2024-08-23 16:21:53 --> Total execution time: 0.0916
INFO - 2024-08-23 16:21:53 --> Config Class Initialized
INFO - 2024-08-23 16:21:53 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:53 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:53 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:53 --> URI Class Initialized
INFO - 2024-08-23 16:21:53 --> Router Class Initialized
INFO - 2024-08-23 16:21:53 --> Output Class Initialized
INFO - 2024-08-23 16:21:53 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:53 --> Input Class Initialized
INFO - 2024-08-23 16:21:53 --> Language Class Initialized
INFO - 2024-08-23 16:21:53 --> Language Class Initialized
INFO - 2024-08-23 16:21:53 --> Config Class Initialized
INFO - 2024-08-23 16:21:53 --> Loader Class Initialized
INFO - 2024-08-23 16:21:53 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:53 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:53 --> Database Driver Class Initialized
INFO - 2024-08-23 16:21:54 --> Final output sent to browser
DEBUG - 2024-08-23 16:21:54 --> Total execution time: 4.0234
INFO - 2024-08-23 16:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:21:54 --> Controller Class Initialized
INFO - 2024-08-23 16:21:54 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:21:54 --> Config Class Initialized
INFO - 2024-08-23 16:21:54 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:54 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:54 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:54 --> URI Class Initialized
INFO - 2024-08-23 16:21:54 --> Router Class Initialized
INFO - 2024-08-23 16:21:54 --> Output Class Initialized
INFO - 2024-08-23 16:21:54 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:54 --> Input Class Initialized
INFO - 2024-08-23 16:21:54 --> Language Class Initialized
INFO - 2024-08-23 16:21:54 --> Language Class Initialized
INFO - 2024-08-23 16:21:54 --> Config Class Initialized
INFO - 2024-08-23 16:21:54 --> Loader Class Initialized
INFO - 2024-08-23 16:21:54 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:54 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:54 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:54 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:54 --> Database Driver Class Initialized
INFO - 2024-08-23 16:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:21:54 --> Controller Class Initialized
ERROR - 2024-08-23 16:21:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:21:55 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:21:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:21:55 --> Config Class Initialized
INFO - 2024-08-23 16:21:55 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:21:55 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:21:55 --> Utf8 Class Initialized
INFO - 2024-08-23 16:21:55 --> URI Class Initialized
INFO - 2024-08-23 16:21:55 --> Router Class Initialized
INFO - 2024-08-23 16:21:55 --> Output Class Initialized
INFO - 2024-08-23 16:21:55 --> Security Class Initialized
DEBUG - 2024-08-23 16:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:21:55 --> Input Class Initialized
INFO - 2024-08-23 16:21:55 --> Language Class Initialized
INFO - 2024-08-23 16:21:55 --> Language Class Initialized
INFO - 2024-08-23 16:21:55 --> Config Class Initialized
INFO - 2024-08-23 16:21:55 --> Loader Class Initialized
INFO - 2024-08-23 16:21:55 --> Helper loaded: url_helper
INFO - 2024-08-23 16:21:55 --> Helper loaded: file_helper
INFO - 2024-08-23 16:21:55 --> Helper loaded: form_helper
INFO - 2024-08-23 16:21:55 --> Helper loaded: my_helper
INFO - 2024-08-23 16:21:55 --> Database Driver Class Initialized
INFO - 2024-08-23 16:22:01 --> Final output sent to browser
DEBUG - 2024-08-23 16:22:01 --> Total execution time: 6.6074
INFO - 2024-08-23 16:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:22:01 --> Controller Class Initialized
DEBUG - 2024-08-23 16:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:22:01 --> Final output sent to browser
DEBUG - 2024-08-23 16:22:01 --> Total execution time: 6.3900
INFO - 2024-08-23 16:22:01 --> Config Class Initialized
INFO - 2024-08-23 16:22:01 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:22:01 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:22:01 --> Utf8 Class Initialized
INFO - 2024-08-23 16:22:01 --> URI Class Initialized
INFO - 2024-08-23 16:22:01 --> Router Class Initialized
INFO - 2024-08-23 16:22:01 --> Output Class Initialized
INFO - 2024-08-23 16:22:01 --> Security Class Initialized
DEBUG - 2024-08-23 16:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:22:01 --> Input Class Initialized
INFO - 2024-08-23 16:22:01 --> Language Class Initialized
INFO - 2024-08-23 16:22:01 --> Language Class Initialized
INFO - 2024-08-23 16:22:01 --> Config Class Initialized
INFO - 2024-08-23 16:22:01 --> Loader Class Initialized
INFO - 2024-08-23 16:22:01 --> Helper loaded: url_helper
INFO - 2024-08-23 16:22:01 --> Helper loaded: file_helper
INFO - 2024-08-23 16:22:01 --> Helper loaded: form_helper
INFO - 2024-08-23 16:22:01 --> Helper loaded: my_helper
INFO - 2024-08-23 16:22:01 --> Database Driver Class Initialized
INFO - 2024-08-23 16:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:22:01 --> Controller Class Initialized
ERROR - 2024-08-23 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:22:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:22:06 --> Final output sent to browser
DEBUG - 2024-08-23 16:22:06 --> Total execution time: 4.6495
INFO - 2024-08-23 16:22:06 --> Config Class Initialized
INFO - 2024-08-23 16:22:06 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:22:06 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:22:06 --> Utf8 Class Initialized
INFO - 2024-08-23 16:22:06 --> URI Class Initialized
INFO - 2024-08-23 16:22:06 --> Router Class Initialized
INFO - 2024-08-23 16:22:06 --> Output Class Initialized
INFO - 2024-08-23 16:22:06 --> Security Class Initialized
DEBUG - 2024-08-23 16:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:22:06 --> Input Class Initialized
INFO - 2024-08-23 16:22:06 --> Language Class Initialized
INFO - 2024-08-23 16:22:06 --> Language Class Initialized
INFO - 2024-08-23 16:22:06 --> Config Class Initialized
INFO - 2024-08-23 16:22:06 --> Loader Class Initialized
INFO - 2024-08-23 16:22:06 --> Helper loaded: url_helper
INFO - 2024-08-23 16:22:06 --> Helper loaded: file_helper
INFO - 2024-08-23 16:22:06 --> Helper loaded: form_helper
INFO - 2024-08-23 16:22:06 --> Helper loaded: my_helper
INFO - 2024-08-23 16:22:06 --> Database Driver Class Initialized
INFO - 2024-08-23 16:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:22:06 --> Controller Class Initialized
ERROR - 2024-08-23 16:22:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 474
ERROR - 2024-08-23 16:22:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 475
DEBUG - 2024-08-23 16:22:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-23 16:22:10 --> Final output sent to browser
DEBUG - 2024-08-23 16:22:10 --> Total execution time: 4.0181
INFO - 2024-08-23 16:35:05 --> Config Class Initialized
INFO - 2024-08-23 16:35:05 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:05 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:05 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:05 --> URI Class Initialized
INFO - 2024-08-23 16:35:05 --> Router Class Initialized
INFO - 2024-08-23 16:35:05 --> Output Class Initialized
INFO - 2024-08-23 16:35:05 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:05 --> Input Class Initialized
INFO - 2024-08-23 16:35:05 --> Language Class Initialized
INFO - 2024-08-23 16:35:05 --> Language Class Initialized
INFO - 2024-08-23 16:35:05 --> Config Class Initialized
INFO - 2024-08-23 16:35:05 --> Loader Class Initialized
INFO - 2024-08-23 16:35:05 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:05 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:05 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:05 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:05 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:05 --> Controller Class Initialized
INFO - 2024-08-23 16:35:05 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:35:05 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:05 --> Total execution time: 0.0819
INFO - 2024-08-23 16:35:06 --> Config Class Initialized
INFO - 2024-08-23 16:35:06 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:06 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:06 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:06 --> URI Class Initialized
INFO - 2024-08-23 16:35:06 --> Router Class Initialized
INFO - 2024-08-23 16:35:06 --> Output Class Initialized
INFO - 2024-08-23 16:35:06 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:06 --> Input Class Initialized
INFO - 2024-08-23 16:35:06 --> Language Class Initialized
INFO - 2024-08-23 16:35:06 --> Language Class Initialized
INFO - 2024-08-23 16:35:06 --> Config Class Initialized
INFO - 2024-08-23 16:35:06 --> Loader Class Initialized
INFO - 2024-08-23 16:35:06 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:06 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:06 --> Controller Class Initialized
INFO - 2024-08-23 16:35:06 --> Helper loaded: cookie_helper
INFO - 2024-08-23 16:35:06 --> Config Class Initialized
INFO - 2024-08-23 16:35:06 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:06 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:06 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:06 --> URI Class Initialized
INFO - 2024-08-23 16:35:06 --> Router Class Initialized
INFO - 2024-08-23 16:35:06 --> Output Class Initialized
INFO - 2024-08-23 16:35:06 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:06 --> Input Class Initialized
INFO - 2024-08-23 16:35:06 --> Language Class Initialized
INFO - 2024-08-23 16:35:06 --> Language Class Initialized
INFO - 2024-08-23 16:35:06 --> Config Class Initialized
INFO - 2024-08-23 16:35:06 --> Loader Class Initialized
INFO - 2024-08-23 16:35:06 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:06 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:06 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:06 --> Controller Class Initialized
DEBUG - 2024-08-23 16:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:35:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:35:06 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:06 --> Total execution time: 0.1867
INFO - 2024-08-23 16:35:22 --> Config Class Initialized
INFO - 2024-08-23 16:35:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:22 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:22 --> URI Class Initialized
INFO - 2024-08-23 16:35:22 --> Router Class Initialized
INFO - 2024-08-23 16:35:22 --> Output Class Initialized
INFO - 2024-08-23 16:35:22 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:22 --> Input Class Initialized
INFO - 2024-08-23 16:35:22 --> Language Class Initialized
INFO - 2024-08-23 16:35:22 --> Language Class Initialized
INFO - 2024-08-23 16:35:22 --> Config Class Initialized
INFO - 2024-08-23 16:35:22 --> Loader Class Initialized
INFO - 2024-08-23 16:35:22 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:22 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:22 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:22 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:22 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:22 --> Controller Class Initialized
DEBUG - 2024-08-23 16:35:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:35:27 --> Config Class Initialized
INFO - 2024-08-23 16:35:27 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:27 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:27 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:27 --> URI Class Initialized
INFO - 2024-08-23 16:35:27 --> Router Class Initialized
INFO - 2024-08-23 16:35:27 --> Output Class Initialized
INFO - 2024-08-23 16:35:27 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:27 --> Input Class Initialized
INFO - 2024-08-23 16:35:27 --> Language Class Initialized
INFO - 2024-08-23 16:35:27 --> Language Class Initialized
INFO - 2024-08-23 16:35:27 --> Config Class Initialized
INFO - 2024-08-23 16:35:27 --> Loader Class Initialized
INFO - 2024-08-23 16:35:27 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:27 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:27 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:27 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:27 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:28 --> Config Class Initialized
INFO - 2024-08-23 16:35:28 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:28 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:28 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:28 --> URI Class Initialized
INFO - 2024-08-23 16:35:28 --> Router Class Initialized
INFO - 2024-08-23 16:35:28 --> Output Class Initialized
INFO - 2024-08-23 16:35:28 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:28 --> Input Class Initialized
INFO - 2024-08-23 16:35:28 --> Language Class Initialized
INFO - 2024-08-23 16:35:28 --> Language Class Initialized
INFO - 2024-08-23 16:35:28 --> Config Class Initialized
INFO - 2024-08-23 16:35:28 --> Loader Class Initialized
INFO - 2024-08-23 16:35:28 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:28 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:28 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:28 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:28 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:33 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:33 --> Total execution time: 11.0429
INFO - 2024-08-23 16:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:33 --> Controller Class Initialized
DEBUG - 2024-08-23 16:35:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:35:38 --> Config Class Initialized
INFO - 2024-08-23 16:35:38 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:38 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:38 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:38 --> URI Class Initialized
INFO - 2024-08-23 16:35:38 --> Router Class Initialized
INFO - 2024-08-23 16:35:38 --> Output Class Initialized
INFO - 2024-08-23 16:35:38 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:38 --> Input Class Initialized
INFO - 2024-08-23 16:35:38 --> Language Class Initialized
INFO - 2024-08-23 16:35:38 --> Language Class Initialized
INFO - 2024-08-23 16:35:38 --> Config Class Initialized
INFO - 2024-08-23 16:35:38 --> Loader Class Initialized
INFO - 2024-08-23 16:35:38 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:38 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:38 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:38 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:38 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:42 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:42 --> Total execution time: 15.3282
INFO - 2024-08-23 16:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:42 --> Controller Class Initialized
DEBUG - 2024-08-23 16:35:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:35:51 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:51 --> Total execution time: 22.5010
INFO - 2024-08-23 16:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:51 --> Controller Class Initialized
INFO - 2024-08-23 16:35:51 --> Config Class Initialized
INFO - 2024-08-23 16:35:51 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
DEBUG - 2024-08-23 16:35:51 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:51 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:51 --> URI Class Initialized
INFO - 2024-08-23 16:35:51 --> Router Class Initialized
INFO - 2024-08-23 16:35:51 --> Output Class Initialized
INFO - 2024-08-23 16:35:51 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:51 --> Input Class Initialized
INFO - 2024-08-23 16:35:51 --> Language Class Initialized
INFO - 2024-08-23 16:35:51 --> Language Class Initialized
INFO - 2024-08-23 16:35:51 --> Config Class Initialized
INFO - 2024-08-23 16:35:51 --> Loader Class Initialized
INFO - 2024-08-23 16:35:51 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:51 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:51 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:51 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:51 --> Database Driver Class Initialized
INFO - 2024-08-23 16:35:57 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:57 --> Total execution time: 19.6659
INFO - 2024-08-23 16:35:57 --> Config Class Initialized
INFO - 2024-08-23 16:35:57 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:35:57 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:35:57 --> Utf8 Class Initialized
INFO - 2024-08-23 16:35:57 --> URI Class Initialized
INFO - 2024-08-23 16:35:57 --> Router Class Initialized
INFO - 2024-08-23 16:35:57 --> Output Class Initialized
INFO - 2024-08-23 16:35:57 --> Security Class Initialized
DEBUG - 2024-08-23 16:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:35:57 --> Input Class Initialized
INFO - 2024-08-23 16:35:57 --> Language Class Initialized
INFO - 2024-08-23 16:35:57 --> Language Class Initialized
INFO - 2024-08-23 16:35:57 --> Config Class Initialized
INFO - 2024-08-23 16:35:57 --> Loader Class Initialized
INFO - 2024-08-23 16:35:57 --> Helper loaded: url_helper
INFO - 2024-08-23 16:35:57 --> Helper loaded: file_helper
INFO - 2024-08-23 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:57 --> Controller Class Initialized
INFO - 2024-08-23 16:35:57 --> Helper loaded: form_helper
INFO - 2024-08-23 16:35:57 --> Helper loaded: my_helper
INFO - 2024-08-23 16:35:57 --> Database Driver Class Initialized
DEBUG - 2024-08-23 16:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:35:57 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:57 --> Total execution time: 6.7155
INFO - 2024-08-23 16:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:35:57 --> Controller Class Initialized
DEBUG - 2024-08-23 16:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 16:35:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 16:35:57 --> Final output sent to browser
DEBUG - 2024-08-23 16:35:57 --> Total execution time: 0.0422
INFO - 2024-08-23 16:36:01 --> Config Class Initialized
INFO - 2024-08-23 16:36:01 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:36:01 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:36:01 --> Utf8 Class Initialized
INFO - 2024-08-23 16:36:01 --> URI Class Initialized
INFO - 2024-08-23 16:36:01 --> Router Class Initialized
INFO - 2024-08-23 16:36:01 --> Output Class Initialized
INFO - 2024-08-23 16:36:01 --> Security Class Initialized
DEBUG - 2024-08-23 16:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:36:01 --> Input Class Initialized
INFO - 2024-08-23 16:36:01 --> Language Class Initialized
INFO - 2024-08-23 16:36:02 --> Language Class Initialized
INFO - 2024-08-23 16:36:02 --> Config Class Initialized
INFO - 2024-08-23 16:36:02 --> Loader Class Initialized
INFO - 2024-08-23 16:36:02 --> Helper loaded: url_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: file_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: form_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: my_helper
INFO - 2024-08-23 16:36:02 --> Database Driver Class Initialized
INFO - 2024-08-23 16:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:36:02 --> Controller Class Initialized
INFO - 2024-08-23 16:36:02 --> Config Class Initialized
INFO - 2024-08-23 16:36:02 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:36:02 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:36:02 --> Utf8 Class Initialized
INFO - 2024-08-23 16:36:02 --> URI Class Initialized
INFO - 2024-08-23 16:36:02 --> Router Class Initialized
INFO - 2024-08-23 16:36:02 --> Output Class Initialized
INFO - 2024-08-23 16:36:02 --> Security Class Initialized
DEBUG - 2024-08-23 16:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:36:02 --> Input Class Initialized
INFO - 2024-08-23 16:36:02 --> Language Class Initialized
INFO - 2024-08-23 16:36:02 --> Language Class Initialized
INFO - 2024-08-23 16:36:02 --> Config Class Initialized
INFO - 2024-08-23 16:36:02 --> Loader Class Initialized
INFO - 2024-08-23 16:36:02 --> Helper loaded: url_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: file_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: form_helper
INFO - 2024-08-23 16:36:02 --> Helper loaded: my_helper
INFO - 2024-08-23 16:36:02 --> Database Driver Class Initialized
DEBUG - 2024-08-23 16:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:36:13 --> Final output sent to browser
DEBUG - 2024-08-23 16:36:13 --> Total execution time: 11.2056
INFO - 2024-08-23 16:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:36:13 --> Controller Class Initialized
DEBUG - 2024-08-23 16:36:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:36:22 --> Final output sent to browser
DEBUG - 2024-08-23 16:36:22 --> Total execution time: 19.5400
INFO - 2024-08-23 16:36:22 --> Config Class Initialized
INFO - 2024-08-23 16:36:22 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:36:22 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:36:22 --> Utf8 Class Initialized
INFO - 2024-08-23 16:36:22 --> URI Class Initialized
INFO - 2024-08-23 16:36:22 --> Router Class Initialized
INFO - 2024-08-23 16:36:22 --> Output Class Initialized
INFO - 2024-08-23 16:36:22 --> Security Class Initialized
DEBUG - 2024-08-23 16:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:36:22 --> Input Class Initialized
INFO - 2024-08-23 16:36:22 --> Language Class Initialized
INFO - 2024-08-23 16:36:22 --> Language Class Initialized
INFO - 2024-08-23 16:36:22 --> Config Class Initialized
INFO - 2024-08-23 16:36:22 --> Loader Class Initialized
INFO - 2024-08-23 16:36:22 --> Helper loaded: url_helper
INFO - 2024-08-23 16:36:22 --> Helper loaded: file_helper
INFO - 2024-08-23 16:36:22 --> Helper loaded: form_helper
INFO - 2024-08-23 16:36:22 --> Helper loaded: my_helper
INFO - 2024-08-23 16:36:22 --> Database Driver Class Initialized
INFO - 2024-08-23 16:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:36:22 --> Controller Class Initialized
DEBUG - 2024-08-23 16:36:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:36:33 --> Final output sent to browser
DEBUG - 2024-08-23 16:36:33 --> Total execution time: 11.0785
INFO - 2024-08-23 16:36:33 --> Config Class Initialized
INFO - 2024-08-23 16:36:33 --> Hooks Class Initialized
DEBUG - 2024-08-23 16:36:33 --> UTF-8 Support Enabled
INFO - 2024-08-23 16:36:33 --> Utf8 Class Initialized
INFO - 2024-08-23 16:36:33 --> URI Class Initialized
INFO - 2024-08-23 16:36:33 --> Router Class Initialized
INFO - 2024-08-23 16:36:33 --> Output Class Initialized
INFO - 2024-08-23 16:36:33 --> Security Class Initialized
DEBUG - 2024-08-23 16:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 16:36:33 --> Input Class Initialized
INFO - 2024-08-23 16:36:33 --> Language Class Initialized
INFO - 2024-08-23 16:36:33 --> Language Class Initialized
INFO - 2024-08-23 16:36:33 --> Config Class Initialized
INFO - 2024-08-23 16:36:33 --> Loader Class Initialized
INFO - 2024-08-23 16:36:33 --> Helper loaded: url_helper
INFO - 2024-08-23 16:36:33 --> Helper loaded: file_helper
INFO - 2024-08-23 16:36:33 --> Helper loaded: form_helper
INFO - 2024-08-23 16:36:33 --> Helper loaded: my_helper
INFO - 2024-08-23 16:36:33 --> Database Driver Class Initialized
INFO - 2024-08-23 16:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 16:36:33 --> Controller Class Initialized
DEBUG - 2024-08-23 16:36:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-08-23 16:36:42 --> Final output sent to browser
DEBUG - 2024-08-23 16:36:42 --> Total execution time: 8.6766
INFO - 2024-08-23 21:39:32 --> Config Class Initialized
INFO - 2024-08-23 21:39:32 --> Hooks Class Initialized
DEBUG - 2024-08-23 21:39:32 --> UTF-8 Support Enabled
INFO - 2024-08-23 21:39:32 --> Utf8 Class Initialized
INFO - 2024-08-23 21:39:32 --> URI Class Initialized
INFO - 2024-08-23 21:39:32 --> Router Class Initialized
INFO - 2024-08-23 21:39:32 --> Output Class Initialized
INFO - 2024-08-23 21:39:32 --> Security Class Initialized
DEBUG - 2024-08-23 21:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 21:39:32 --> Input Class Initialized
INFO - 2024-08-23 21:39:32 --> Language Class Initialized
INFO - 2024-08-23 21:39:32 --> Language Class Initialized
INFO - 2024-08-23 21:39:32 --> Config Class Initialized
INFO - 2024-08-23 21:39:32 --> Loader Class Initialized
INFO - 2024-08-23 21:39:32 --> Helper loaded: url_helper
INFO - 2024-08-23 21:39:32 --> Helper loaded: file_helper
INFO - 2024-08-23 21:39:32 --> Helper loaded: form_helper
INFO - 2024-08-23 21:39:32 --> Helper loaded: my_helper
INFO - 2024-08-23 21:39:32 --> Database Driver Class Initialized
INFO - 2024-08-23 21:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 21:39:32 --> Controller Class Initialized
INFO - 2024-08-23 21:39:33 --> Helper loaded: cookie_helper
INFO - 2024-08-23 21:39:33 --> Final output sent to browser
DEBUG - 2024-08-23 21:39:33 --> Total execution time: 0.4541
INFO - 2024-08-23 21:39:33 --> Config Class Initialized
INFO - 2024-08-23 21:39:33 --> Hooks Class Initialized
DEBUG - 2024-08-23 21:39:33 --> UTF-8 Support Enabled
INFO - 2024-08-23 21:39:33 --> Utf8 Class Initialized
INFO - 2024-08-23 21:39:33 --> URI Class Initialized
INFO - 2024-08-23 21:39:33 --> Router Class Initialized
INFO - 2024-08-23 21:39:33 --> Output Class Initialized
INFO - 2024-08-23 21:39:33 --> Security Class Initialized
DEBUG - 2024-08-23 21:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 21:39:33 --> Input Class Initialized
INFO - 2024-08-23 21:39:33 --> Language Class Initialized
INFO - 2024-08-23 21:39:33 --> Language Class Initialized
INFO - 2024-08-23 21:39:33 --> Config Class Initialized
INFO - 2024-08-23 21:39:33 --> Loader Class Initialized
INFO - 2024-08-23 21:39:33 --> Helper loaded: url_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: file_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: form_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: my_helper
INFO - 2024-08-23 21:39:33 --> Database Driver Class Initialized
INFO - 2024-08-23 21:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 21:39:33 --> Controller Class Initialized
INFO - 2024-08-23 21:39:33 --> Helper loaded: cookie_helper
INFO - 2024-08-23 21:39:33 --> Config Class Initialized
INFO - 2024-08-23 21:39:33 --> Hooks Class Initialized
DEBUG - 2024-08-23 21:39:33 --> UTF-8 Support Enabled
INFO - 2024-08-23 21:39:33 --> Utf8 Class Initialized
INFO - 2024-08-23 21:39:33 --> URI Class Initialized
INFO - 2024-08-23 21:39:33 --> Router Class Initialized
INFO - 2024-08-23 21:39:33 --> Output Class Initialized
INFO - 2024-08-23 21:39:33 --> Security Class Initialized
DEBUG - 2024-08-23 21:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-23 21:39:33 --> Input Class Initialized
INFO - 2024-08-23 21:39:33 --> Language Class Initialized
INFO - 2024-08-23 21:39:33 --> Language Class Initialized
INFO - 2024-08-23 21:39:33 --> Config Class Initialized
INFO - 2024-08-23 21:39:33 --> Loader Class Initialized
INFO - 2024-08-23 21:39:33 --> Helper loaded: url_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: file_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: form_helper
INFO - 2024-08-23 21:39:33 --> Helper loaded: my_helper
INFO - 2024-08-23 21:39:33 --> Database Driver Class Initialized
INFO - 2024-08-23 21:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-23 21:39:33 --> Controller Class Initialized
DEBUG - 2024-08-23 21:39:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-23 21:39:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-23 21:39:33 --> Final output sent to browser
DEBUG - 2024-08-23 21:39:33 --> Total execution time: 0.0357
