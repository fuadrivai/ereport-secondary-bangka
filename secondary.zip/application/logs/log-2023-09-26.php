<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-26 07:59:56 --> Config Class Initialized
INFO - 2023-09-26 07:59:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 07:59:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 07:59:56 --> Utf8 Class Initialized
INFO - 2023-09-26 07:59:56 --> URI Class Initialized
INFO - 2023-09-26 07:59:56 --> Router Class Initialized
INFO - 2023-09-26 07:59:57 --> Output Class Initialized
INFO - 2023-09-26 07:59:57 --> Security Class Initialized
DEBUG - 2023-09-26 07:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 07:59:57 --> Input Class Initialized
INFO - 2023-09-26 07:59:57 --> Language Class Initialized
INFO - 2023-09-26 07:59:57 --> Language Class Initialized
INFO - 2023-09-26 07:59:57 --> Config Class Initialized
INFO - 2023-09-26 07:59:57 --> Loader Class Initialized
INFO - 2023-09-26 07:59:57 --> Helper loaded: url_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: file_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: form_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: my_helper
INFO - 2023-09-26 07:59:57 --> Database Driver Class Initialized
INFO - 2023-09-26 07:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 07:59:57 --> Controller Class Initialized
INFO - 2023-09-26 07:59:57 --> Config Class Initialized
INFO - 2023-09-26 07:59:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 07:59:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 07:59:57 --> Utf8 Class Initialized
INFO - 2023-09-26 07:59:57 --> URI Class Initialized
INFO - 2023-09-26 07:59:57 --> Router Class Initialized
INFO - 2023-09-26 07:59:57 --> Output Class Initialized
INFO - 2023-09-26 07:59:57 --> Security Class Initialized
DEBUG - 2023-09-26 07:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 07:59:57 --> Input Class Initialized
INFO - 2023-09-26 07:59:57 --> Language Class Initialized
INFO - 2023-09-26 07:59:57 --> Language Class Initialized
INFO - 2023-09-26 07:59:57 --> Config Class Initialized
INFO - 2023-09-26 07:59:57 --> Loader Class Initialized
INFO - 2023-09-26 07:59:57 --> Helper loaded: url_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: file_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: form_helper
INFO - 2023-09-26 07:59:57 --> Helper loaded: my_helper
INFO - 2023-09-26 07:59:57 --> Database Driver Class Initialized
INFO - 2023-09-26 07:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 07:59:57 --> Controller Class Initialized
DEBUG - 2023-09-26 07:59:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 07:59:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 07:59:57 --> Final output sent to browser
DEBUG - 2023-09-26 07:59:57 --> Total execution time: 0.0368
INFO - 2023-09-26 08:00:01 --> Config Class Initialized
INFO - 2023-09-26 08:00:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:01 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:01 --> URI Class Initialized
INFO - 2023-09-26 08:00:01 --> Router Class Initialized
INFO - 2023-09-26 08:00:01 --> Output Class Initialized
INFO - 2023-09-26 08:00:01 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:01 --> Input Class Initialized
INFO - 2023-09-26 08:00:01 --> Language Class Initialized
INFO - 2023-09-26 08:00:01 --> Language Class Initialized
INFO - 2023-09-26 08:00:01 --> Config Class Initialized
INFO - 2023-09-26 08:00:01 --> Loader Class Initialized
INFO - 2023-09-26 08:00:01 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:01 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:01 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:01 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:01 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:01 --> Controller Class Initialized
INFO - 2023-09-26 08:00:02 --> Helper loaded: cookie_helper
INFO - 2023-09-26 08:00:02 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:02 --> Total execution time: 0.2926
INFO - 2023-09-26 08:00:02 --> Config Class Initialized
INFO - 2023-09-26 08:00:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:02 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:02 --> URI Class Initialized
INFO - 2023-09-26 08:00:02 --> Router Class Initialized
INFO - 2023-09-26 08:00:02 --> Output Class Initialized
INFO - 2023-09-26 08:00:02 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:02 --> Input Class Initialized
INFO - 2023-09-26 08:00:02 --> Language Class Initialized
INFO - 2023-09-26 08:00:02 --> Language Class Initialized
INFO - 2023-09-26 08:00:02 --> Config Class Initialized
INFO - 2023-09-26 08:00:02 --> Loader Class Initialized
INFO - 2023-09-26 08:00:02 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:02 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:02 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:02 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:02 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:02 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 08:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:02 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:02 --> Total execution time: 0.1255
INFO - 2023-09-26 08:00:06 --> Config Class Initialized
INFO - 2023-09-26 08:00:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:06 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:06 --> URI Class Initialized
INFO - 2023-09-26 08:00:06 --> Router Class Initialized
INFO - 2023-09-26 08:00:06 --> Output Class Initialized
INFO - 2023-09-26 08:00:06 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:06 --> Input Class Initialized
INFO - 2023-09-26 08:00:06 --> Language Class Initialized
INFO - 2023-09-26 08:00:06 --> Language Class Initialized
INFO - 2023-09-26 08:00:06 --> Config Class Initialized
INFO - 2023-09-26 08:00:06 --> Loader Class Initialized
INFO - 2023-09-26 08:00:06 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:06 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:06 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:06 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:06 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:06 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 08:00:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:06 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:06 --> Total execution time: 0.0768
INFO - 2023-09-26 08:00:08 --> Config Class Initialized
INFO - 2023-09-26 08:00:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:08 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:08 --> URI Class Initialized
INFO - 2023-09-26 08:00:08 --> Router Class Initialized
INFO - 2023-09-26 08:00:08 --> Output Class Initialized
INFO - 2023-09-26 08:00:08 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:08 --> Input Class Initialized
INFO - 2023-09-26 08:00:08 --> Language Class Initialized
INFO - 2023-09-26 08:00:08 --> Language Class Initialized
INFO - 2023-09-26 08:00:08 --> Config Class Initialized
INFO - 2023-09-26 08:00:08 --> Loader Class Initialized
INFO - 2023-09-26 08:00:08 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:08 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:08 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:08 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:08 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:08 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:08 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:08 --> Total execution time: 0.2135
INFO - 2023-09-26 08:00:08 --> Config Class Initialized
INFO - 2023-09-26 08:00:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:08 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:08 --> URI Class Initialized
INFO - 2023-09-26 08:00:08 --> Router Class Initialized
INFO - 2023-09-26 08:00:08 --> Output Class Initialized
INFO - 2023-09-26 08:00:08 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:08 --> Input Class Initialized
INFO - 2023-09-26 08:00:08 --> Language Class Initialized
INFO - 2023-09-26 08:00:08 --> Language Class Initialized
INFO - 2023-09-26 08:00:08 --> Config Class Initialized
INFO - 2023-09-26 08:00:08 --> Loader Class Initialized
INFO - 2023-09-26 08:00:09 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:09 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:09 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:09 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:09 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:09 --> Controller Class Initialized
INFO - 2023-09-26 08:00:11 --> Config Class Initialized
INFO - 2023-09-26 08:00:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:11 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:11 --> URI Class Initialized
INFO - 2023-09-26 08:00:11 --> Router Class Initialized
INFO - 2023-09-26 08:00:11 --> Output Class Initialized
INFO - 2023-09-26 08:00:11 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:11 --> Input Class Initialized
INFO - 2023-09-26 08:00:11 --> Language Class Initialized
INFO - 2023-09-26 08:00:11 --> Language Class Initialized
INFO - 2023-09-26 08:00:11 --> Config Class Initialized
INFO - 2023-09-26 08:00:11 --> Loader Class Initialized
INFO - 2023-09-26 08:00:11 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:11 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:11 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:11 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:11 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:11 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:11 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:11 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:00:15 --> Config Class Initialized
INFO - 2023-09-26 08:00:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:15 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:15 --> URI Class Initialized
INFO - 2023-09-26 08:00:15 --> Router Class Initialized
INFO - 2023-09-26 08:00:15 --> Output Class Initialized
INFO - 2023-09-26 08:00:15 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:15 --> Input Class Initialized
INFO - 2023-09-26 08:00:15 --> Language Class Initialized
INFO - 2023-09-26 08:00:15 --> Language Class Initialized
INFO - 2023-09-26 08:00:15 --> Config Class Initialized
INFO - 2023-09-26 08:00:15 --> Loader Class Initialized
INFO - 2023-09-26 08:00:15 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:15 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:15 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:15 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:15 --> Total execution time: 0.0500
INFO - 2023-09-26 08:00:15 --> Config Class Initialized
INFO - 2023-09-26 08:00:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:15 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:15 --> URI Class Initialized
INFO - 2023-09-26 08:00:15 --> Router Class Initialized
INFO - 2023-09-26 08:00:15 --> Output Class Initialized
INFO - 2023-09-26 08:00:15 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:15 --> Input Class Initialized
INFO - 2023-09-26 08:00:15 --> Language Class Initialized
INFO - 2023-09-26 08:00:15 --> Language Class Initialized
INFO - 2023-09-26 08:00:15 --> Config Class Initialized
INFO - 2023-09-26 08:00:15 --> Loader Class Initialized
INFO - 2023-09-26 08:00:15 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:15 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:15 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:15 --> Controller Class Initialized
INFO - 2023-09-26 08:00:16 --> Config Class Initialized
INFO - 2023-09-26 08:00:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:16 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:16 --> URI Class Initialized
INFO - 2023-09-26 08:00:16 --> Router Class Initialized
INFO - 2023-09-26 08:00:16 --> Output Class Initialized
INFO - 2023-09-26 08:00:16 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:16 --> Input Class Initialized
INFO - 2023-09-26 08:00:16 --> Language Class Initialized
INFO - 2023-09-26 08:00:16 --> Language Class Initialized
INFO - 2023-09-26 08:00:16 --> Config Class Initialized
INFO - 2023-09-26 08:00:16 --> Loader Class Initialized
INFO - 2023-09-26 08:00:16 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:16 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:16 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:16 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:16 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:16 --> Controller Class Initialized
INFO - 2023-09-26 08:00:16 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:16 --> Total execution time: 0.0478
INFO - 2023-09-26 08:00:18 --> Config Class Initialized
INFO - 2023-09-26 08:00:18 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:18 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:18 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:18 --> URI Class Initialized
INFO - 2023-09-26 08:00:18 --> Router Class Initialized
INFO - 2023-09-26 08:00:18 --> Output Class Initialized
INFO - 2023-09-26 08:00:18 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:18 --> Input Class Initialized
INFO - 2023-09-26 08:00:18 --> Language Class Initialized
INFO - 2023-09-26 08:00:18 --> Language Class Initialized
INFO - 2023-09-26 08:00:18 --> Config Class Initialized
INFO - 2023-09-26 08:00:18 --> Loader Class Initialized
INFO - 2023-09-26 08:00:18 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:18 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:18 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:18 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:18 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:18 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:00:20 --> Config Class Initialized
INFO - 2023-09-26 08:00:20 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:20 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:20 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:20 --> URI Class Initialized
INFO - 2023-09-26 08:00:20 --> Router Class Initialized
INFO - 2023-09-26 08:00:20 --> Output Class Initialized
INFO - 2023-09-26 08:00:20 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:20 --> Input Class Initialized
INFO - 2023-09-26 08:00:20 --> Language Class Initialized
INFO - 2023-09-26 08:00:20 --> Language Class Initialized
INFO - 2023-09-26 08:00:20 --> Config Class Initialized
INFO - 2023-09-26 08:00:20 --> Loader Class Initialized
INFO - 2023-09-26 08:00:20 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:21 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:21 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:21 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:21 --> Total execution time: 0.1957
INFO - 2023-09-26 08:00:21 --> Config Class Initialized
INFO - 2023-09-26 08:00:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:21 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:21 --> URI Class Initialized
INFO - 2023-09-26 08:00:21 --> Router Class Initialized
INFO - 2023-09-26 08:00:21 --> Output Class Initialized
INFO - 2023-09-26 08:00:21 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:21 --> Input Class Initialized
INFO - 2023-09-26 08:00:21 --> Language Class Initialized
INFO - 2023-09-26 08:00:21 --> Language Class Initialized
INFO - 2023-09-26 08:00:21 --> Config Class Initialized
INFO - 2023-09-26 08:00:21 --> Loader Class Initialized
INFO - 2023-09-26 08:00:21 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:21 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:21 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:21 --> Controller Class Initialized
INFO - 2023-09-26 08:00:22 --> Config Class Initialized
INFO - 2023-09-26 08:00:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:22 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:22 --> URI Class Initialized
INFO - 2023-09-26 08:00:22 --> Router Class Initialized
INFO - 2023-09-26 08:00:22 --> Output Class Initialized
INFO - 2023-09-26 08:00:22 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:22 --> Input Class Initialized
INFO - 2023-09-26 08:00:22 --> Language Class Initialized
INFO - 2023-09-26 08:00:22 --> Language Class Initialized
INFO - 2023-09-26 08:00:22 --> Config Class Initialized
INFO - 2023-09-26 08:00:22 --> Loader Class Initialized
INFO - 2023-09-26 08:00:22 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:22 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:22 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:22 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:22 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:22 --> Controller Class Initialized
INFO - 2023-09-26 08:00:22 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:22 --> Total execution time: 0.0460
INFO - 2023-09-26 08:00:24 --> Config Class Initialized
INFO - 2023-09-26 08:00:24 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:24 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:24 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:24 --> URI Class Initialized
INFO - 2023-09-26 08:00:24 --> Router Class Initialized
INFO - 2023-09-26 08:00:24 --> Output Class Initialized
INFO - 2023-09-26 08:00:24 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:24 --> Input Class Initialized
INFO - 2023-09-26 08:00:24 --> Language Class Initialized
INFO - 2023-09-26 08:00:24 --> Language Class Initialized
INFO - 2023-09-26 08:00:24 --> Config Class Initialized
INFO - 2023-09-26 08:00:24 --> Loader Class Initialized
INFO - 2023-09-26 08:00:24 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:24 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:24 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:24 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:24 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:24 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:24 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:00:26 --> Config Class Initialized
INFO - 2023-09-26 08:00:26 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:26 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:26 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:26 --> URI Class Initialized
INFO - 2023-09-26 08:00:26 --> Router Class Initialized
INFO - 2023-09-26 08:00:26 --> Output Class Initialized
INFO - 2023-09-26 08:00:26 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:26 --> Input Class Initialized
INFO - 2023-09-26 08:00:26 --> Language Class Initialized
INFO - 2023-09-26 08:00:26 --> Language Class Initialized
INFO - 2023-09-26 08:00:26 --> Config Class Initialized
INFO - 2023-09-26 08:00:26 --> Loader Class Initialized
INFO - 2023-09-26 08:00:26 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:26 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:26 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:26 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:26 --> Total execution time: 0.0474
INFO - 2023-09-26 08:00:26 --> Config Class Initialized
INFO - 2023-09-26 08:00:26 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:26 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:26 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:26 --> URI Class Initialized
INFO - 2023-09-26 08:00:26 --> Router Class Initialized
INFO - 2023-09-26 08:00:26 --> Output Class Initialized
INFO - 2023-09-26 08:00:26 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:26 --> Input Class Initialized
INFO - 2023-09-26 08:00:26 --> Language Class Initialized
INFO - 2023-09-26 08:00:26 --> Language Class Initialized
INFO - 2023-09-26 08:00:26 --> Config Class Initialized
INFO - 2023-09-26 08:00:26 --> Loader Class Initialized
INFO - 2023-09-26 08:00:26 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:26 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:26 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:26 --> Controller Class Initialized
INFO - 2023-09-26 08:00:28 --> Config Class Initialized
INFO - 2023-09-26 08:00:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:28 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:28 --> URI Class Initialized
INFO - 2023-09-26 08:00:28 --> Router Class Initialized
INFO - 2023-09-26 08:00:28 --> Output Class Initialized
INFO - 2023-09-26 08:00:28 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:28 --> Input Class Initialized
INFO - 2023-09-26 08:00:28 --> Language Class Initialized
INFO - 2023-09-26 08:00:28 --> Language Class Initialized
INFO - 2023-09-26 08:00:28 --> Config Class Initialized
INFO - 2023-09-26 08:00:28 --> Loader Class Initialized
INFO - 2023-09-26 08:00:28 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:28 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:28 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:28 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:28 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:28 --> Controller Class Initialized
INFO - 2023-09-26 08:00:28 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:28 --> Total execution time: 0.0751
INFO - 2023-09-26 08:00:29 --> Config Class Initialized
INFO - 2023-09-26 08:00:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:29 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:29 --> URI Class Initialized
INFO - 2023-09-26 08:00:29 --> Router Class Initialized
INFO - 2023-09-26 08:00:29 --> Output Class Initialized
INFO - 2023-09-26 08:00:29 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:29 --> Input Class Initialized
INFO - 2023-09-26 08:00:29 --> Language Class Initialized
INFO - 2023-09-26 08:00:29 --> Language Class Initialized
INFO - 2023-09-26 08:00:29 --> Config Class Initialized
INFO - 2023-09-26 08:00:29 --> Loader Class Initialized
INFO - 2023-09-26 08:00:29 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:29 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:29 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:29 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:29 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:29 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:30 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:00:31 --> Config Class Initialized
INFO - 2023-09-26 08:00:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:31 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:31 --> URI Class Initialized
INFO - 2023-09-26 08:00:31 --> Router Class Initialized
INFO - 2023-09-26 08:00:31 --> Output Class Initialized
INFO - 2023-09-26 08:00:31 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:31 --> Input Class Initialized
INFO - 2023-09-26 08:00:31 --> Language Class Initialized
INFO - 2023-09-26 08:00:31 --> Language Class Initialized
INFO - 2023-09-26 08:00:31 --> Config Class Initialized
INFO - 2023-09-26 08:00:31 --> Loader Class Initialized
INFO - 2023-09-26 08:00:31 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:31 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:31 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:31 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:31 --> Total execution time: 0.0757
INFO - 2023-09-26 08:00:31 --> Config Class Initialized
INFO - 2023-09-26 08:00:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:31 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:31 --> URI Class Initialized
INFO - 2023-09-26 08:00:31 --> Router Class Initialized
INFO - 2023-09-26 08:00:31 --> Output Class Initialized
INFO - 2023-09-26 08:00:31 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:31 --> Input Class Initialized
INFO - 2023-09-26 08:00:31 --> Language Class Initialized
INFO - 2023-09-26 08:00:31 --> Language Class Initialized
INFO - 2023-09-26 08:00:31 --> Config Class Initialized
INFO - 2023-09-26 08:00:31 --> Loader Class Initialized
INFO - 2023-09-26 08:00:31 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:31 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:32 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:32 --> Controller Class Initialized
INFO - 2023-09-26 08:00:48 --> Config Class Initialized
INFO - 2023-09-26 08:00:48 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:48 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:48 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:48 --> URI Class Initialized
INFO - 2023-09-26 08:00:48 --> Router Class Initialized
INFO - 2023-09-26 08:00:48 --> Output Class Initialized
INFO - 2023-09-26 08:00:48 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:48 --> Input Class Initialized
INFO - 2023-09-26 08:00:48 --> Language Class Initialized
INFO - 2023-09-26 08:00:48 --> Language Class Initialized
INFO - 2023-09-26 08:00:48 --> Config Class Initialized
INFO - 2023-09-26 08:00:48 --> Loader Class Initialized
INFO - 2023-09-26 08:00:48 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:48 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:48 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:48 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:48 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:48 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:48 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:48 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:00:51 --> Config Class Initialized
INFO - 2023-09-26 08:00:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:51 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:51 --> URI Class Initialized
INFO - 2023-09-26 08:00:51 --> Router Class Initialized
INFO - 2023-09-26 08:00:51 --> Output Class Initialized
INFO - 2023-09-26 08:00:51 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:51 --> Input Class Initialized
INFO - 2023-09-26 08:00:51 --> Language Class Initialized
INFO - 2023-09-26 08:00:51 --> Language Class Initialized
INFO - 2023-09-26 08:00:51 --> Config Class Initialized
INFO - 2023-09-26 08:00:51 --> Loader Class Initialized
INFO - 2023-09-26 08:00:51 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:51 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:51 --> Controller Class Initialized
DEBUG - 2023-09-26 08:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:00:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:00:51 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:51 --> Total execution time: 0.0433
INFO - 2023-09-26 08:00:51 --> Config Class Initialized
INFO - 2023-09-26 08:00:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:51 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:51 --> URI Class Initialized
INFO - 2023-09-26 08:00:51 --> Router Class Initialized
INFO - 2023-09-26 08:00:51 --> Output Class Initialized
INFO - 2023-09-26 08:00:51 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:51 --> Input Class Initialized
INFO - 2023-09-26 08:00:51 --> Language Class Initialized
INFO - 2023-09-26 08:00:51 --> Language Class Initialized
INFO - 2023-09-26 08:00:51 --> Config Class Initialized
INFO - 2023-09-26 08:00:51 --> Loader Class Initialized
INFO - 2023-09-26 08:00:51 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:51 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:51 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:51 --> Controller Class Initialized
INFO - 2023-09-26 08:00:57 --> Config Class Initialized
INFO - 2023-09-26 08:00:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:57 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:57 --> URI Class Initialized
INFO - 2023-09-26 08:00:57 --> Router Class Initialized
INFO - 2023-09-26 08:00:57 --> Output Class Initialized
INFO - 2023-09-26 08:00:57 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:57 --> Input Class Initialized
INFO - 2023-09-26 08:00:57 --> Language Class Initialized
INFO - 2023-09-26 08:00:57 --> Language Class Initialized
INFO - 2023-09-26 08:00:57 --> Config Class Initialized
INFO - 2023-09-26 08:00:57 --> Loader Class Initialized
INFO - 2023-09-26 08:00:57 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:57 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:57 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:57 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:57 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:57 --> Controller Class Initialized
INFO - 2023-09-26 08:00:57 --> Final output sent to browser
DEBUG - 2023-09-26 08:00:57 --> Total execution time: 0.0455
INFO - 2023-09-26 08:00:59 --> Config Class Initialized
INFO - 2023-09-26 08:00:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:00:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:00:59 --> Utf8 Class Initialized
INFO - 2023-09-26 08:00:59 --> URI Class Initialized
INFO - 2023-09-26 08:00:59 --> Router Class Initialized
INFO - 2023-09-26 08:00:59 --> Output Class Initialized
INFO - 2023-09-26 08:00:59 --> Security Class Initialized
DEBUG - 2023-09-26 08:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:00:59 --> Input Class Initialized
INFO - 2023-09-26 08:00:59 --> Language Class Initialized
INFO - 2023-09-26 08:00:59 --> Language Class Initialized
INFO - 2023-09-26 08:00:59 --> Config Class Initialized
INFO - 2023-09-26 08:00:59 --> Loader Class Initialized
INFO - 2023-09-26 08:00:59 --> Helper loaded: url_helper
INFO - 2023-09-26 08:00:59 --> Helper loaded: file_helper
INFO - 2023-09-26 08:00:59 --> Helper loaded: form_helper
INFO - 2023-09-26 08:00:59 --> Helper loaded: my_helper
INFO - 2023-09-26 08:00:59 --> Database Driver Class Initialized
INFO - 2023-09-26 08:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:00:59 --> Controller Class Initialized
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 08:00:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 08:00:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 08:01:01 --> Config Class Initialized
INFO - 2023-09-26 08:01:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:01:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:01:01 --> Utf8 Class Initialized
INFO - 2023-09-26 08:01:01 --> URI Class Initialized
INFO - 2023-09-26 08:01:01 --> Router Class Initialized
INFO - 2023-09-26 08:01:01 --> Output Class Initialized
INFO - 2023-09-26 08:01:01 --> Security Class Initialized
DEBUG - 2023-09-26 08:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:01:01 --> Input Class Initialized
INFO - 2023-09-26 08:01:01 --> Language Class Initialized
INFO - 2023-09-26 08:01:01 --> Language Class Initialized
INFO - 2023-09-26 08:01:01 --> Config Class Initialized
INFO - 2023-09-26 08:01:01 --> Loader Class Initialized
INFO - 2023-09-26 08:01:01 --> Helper loaded: url_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: file_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: form_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: my_helper
INFO - 2023-09-26 08:01:01 --> Database Driver Class Initialized
INFO - 2023-09-26 08:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:01:01 --> Controller Class Initialized
DEBUG - 2023-09-26 08:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 08:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 08:01:01 --> Final output sent to browser
DEBUG - 2023-09-26 08:01:01 --> Total execution time: 0.0985
INFO - 2023-09-26 08:01:01 --> Config Class Initialized
INFO - 2023-09-26 08:01:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 08:01:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 08:01:01 --> Utf8 Class Initialized
INFO - 2023-09-26 08:01:01 --> URI Class Initialized
INFO - 2023-09-26 08:01:01 --> Router Class Initialized
INFO - 2023-09-26 08:01:01 --> Output Class Initialized
INFO - 2023-09-26 08:01:01 --> Security Class Initialized
DEBUG - 2023-09-26 08:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 08:01:01 --> Input Class Initialized
INFO - 2023-09-26 08:01:01 --> Language Class Initialized
INFO - 2023-09-26 08:01:01 --> Language Class Initialized
INFO - 2023-09-26 08:01:01 --> Config Class Initialized
INFO - 2023-09-26 08:01:01 --> Loader Class Initialized
INFO - 2023-09-26 08:01:01 --> Helper loaded: url_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: file_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: form_helper
INFO - 2023-09-26 08:01:01 --> Helper loaded: my_helper
INFO - 2023-09-26 08:01:01 --> Database Driver Class Initialized
INFO - 2023-09-26 08:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 08:01:01 --> Controller Class Initialized
INFO - 2023-09-26 09:29:03 --> Config Class Initialized
INFO - 2023-09-26 09:29:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:29:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:29:03 --> Utf8 Class Initialized
INFO - 2023-09-26 09:29:03 --> URI Class Initialized
INFO - 2023-09-26 09:29:03 --> Router Class Initialized
INFO - 2023-09-26 09:29:03 --> Output Class Initialized
INFO - 2023-09-26 09:29:03 --> Security Class Initialized
DEBUG - 2023-09-26 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:29:03 --> Input Class Initialized
INFO - 2023-09-26 09:29:03 --> Language Class Initialized
INFO - 2023-09-26 09:29:03 --> Language Class Initialized
INFO - 2023-09-26 09:29:03 --> Config Class Initialized
INFO - 2023-09-26 09:29:03 --> Loader Class Initialized
INFO - 2023-09-26 09:29:03 --> Helper loaded: url_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: file_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: form_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: my_helper
INFO - 2023-09-26 09:29:03 --> Database Driver Class Initialized
INFO - 2023-09-26 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:29:03 --> Controller Class Initialized
DEBUG - 2023-09-26 09:29:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 09:29:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 09:29:03 --> Final output sent to browser
DEBUG - 2023-09-26 09:29:03 --> Total execution time: 0.1579
INFO - 2023-09-26 09:29:03 --> Config Class Initialized
INFO - 2023-09-26 09:29:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:29:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:29:03 --> Utf8 Class Initialized
INFO - 2023-09-26 09:29:03 --> URI Class Initialized
INFO - 2023-09-26 09:29:03 --> Router Class Initialized
INFO - 2023-09-26 09:29:03 --> Output Class Initialized
INFO - 2023-09-26 09:29:03 --> Security Class Initialized
DEBUG - 2023-09-26 09:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:29:03 --> Input Class Initialized
INFO - 2023-09-26 09:29:03 --> Language Class Initialized
INFO - 2023-09-26 09:29:03 --> Language Class Initialized
INFO - 2023-09-26 09:29:03 --> Config Class Initialized
INFO - 2023-09-26 09:29:03 --> Loader Class Initialized
INFO - 2023-09-26 09:29:03 --> Helper loaded: url_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: file_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: form_helper
INFO - 2023-09-26 09:29:03 --> Helper loaded: my_helper
INFO - 2023-09-26 09:29:03 --> Database Driver Class Initialized
INFO - 2023-09-26 09:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:29:03 --> Controller Class Initialized
INFO - 2023-09-26 09:56:22 --> Config Class Initialized
INFO - 2023-09-26 09:56:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:22 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:22 --> URI Class Initialized
INFO - 2023-09-26 09:56:22 --> Router Class Initialized
INFO - 2023-09-26 09:56:22 --> Output Class Initialized
INFO - 2023-09-26 09:56:22 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:22 --> Input Class Initialized
INFO - 2023-09-26 09:56:22 --> Language Class Initialized
INFO - 2023-09-26 09:56:22 --> Language Class Initialized
INFO - 2023-09-26 09:56:22 --> Config Class Initialized
INFO - 2023-09-26 09:56:22 --> Loader Class Initialized
INFO - 2023-09-26 09:56:22 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:22 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:22 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:22 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:22 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:22 --> Controller Class Initialized
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 09:56:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 09:56:25 --> Config Class Initialized
INFO - 2023-09-26 09:56:25 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:25 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:25 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:25 --> URI Class Initialized
INFO - 2023-09-26 09:56:25 --> Router Class Initialized
INFO - 2023-09-26 09:56:25 --> Output Class Initialized
INFO - 2023-09-26 09:56:25 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:25 --> Input Class Initialized
INFO - 2023-09-26 09:56:25 --> Language Class Initialized
INFO - 2023-09-26 09:56:25 --> Language Class Initialized
INFO - 2023-09-26 09:56:25 --> Config Class Initialized
INFO - 2023-09-26 09:56:25 --> Loader Class Initialized
INFO - 2023-09-26 09:56:25 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:25 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:25 --> Controller Class Initialized
DEBUG - 2023-09-26 09:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 09:56:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 09:56:25 --> Final output sent to browser
DEBUG - 2023-09-26 09:56:25 --> Total execution time: 0.0347
INFO - 2023-09-26 09:56:25 --> Config Class Initialized
INFO - 2023-09-26 09:56:25 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:25 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:25 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:25 --> URI Class Initialized
INFO - 2023-09-26 09:56:25 --> Router Class Initialized
INFO - 2023-09-26 09:56:25 --> Output Class Initialized
INFO - 2023-09-26 09:56:25 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:25 --> Input Class Initialized
INFO - 2023-09-26 09:56:25 --> Language Class Initialized
INFO - 2023-09-26 09:56:25 --> Language Class Initialized
INFO - 2023-09-26 09:56:25 --> Config Class Initialized
INFO - 2023-09-26 09:56:25 --> Loader Class Initialized
INFO - 2023-09-26 09:56:25 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:25 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:25 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:25 --> Controller Class Initialized
INFO - 2023-09-26 09:56:27 --> Config Class Initialized
INFO - 2023-09-26 09:56:27 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:27 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:27 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:27 --> URI Class Initialized
INFO - 2023-09-26 09:56:27 --> Router Class Initialized
INFO - 2023-09-26 09:56:27 --> Output Class Initialized
INFO - 2023-09-26 09:56:27 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:27 --> Input Class Initialized
INFO - 2023-09-26 09:56:27 --> Language Class Initialized
INFO - 2023-09-26 09:56:27 --> Language Class Initialized
INFO - 2023-09-26 09:56:27 --> Config Class Initialized
INFO - 2023-09-26 09:56:27 --> Loader Class Initialized
INFO - 2023-09-26 09:56:27 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:27 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:27 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:27 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:27 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:27 --> Controller Class Initialized
INFO - 2023-09-26 09:56:27 --> Final output sent to browser
DEBUG - 2023-09-26 09:56:27 --> Total execution time: 0.0364
INFO - 2023-09-26 09:56:29 --> Config Class Initialized
INFO - 2023-09-26 09:56:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:29 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:29 --> URI Class Initialized
INFO - 2023-09-26 09:56:29 --> Router Class Initialized
INFO - 2023-09-26 09:56:29 --> Output Class Initialized
INFO - 2023-09-26 09:56:29 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:29 --> Input Class Initialized
INFO - 2023-09-26 09:56:29 --> Language Class Initialized
INFO - 2023-09-26 09:56:29 --> Language Class Initialized
INFO - 2023-09-26 09:56:29 --> Config Class Initialized
INFO - 2023-09-26 09:56:29 --> Loader Class Initialized
INFO - 2023-09-26 09:56:29 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:29 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:29 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:29 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:29 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:29 --> Controller Class Initialized
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 09:56:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 09:56:31 --> Config Class Initialized
INFO - 2023-09-26 09:56:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:31 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:31 --> URI Class Initialized
INFO - 2023-09-26 09:56:31 --> Router Class Initialized
INFO - 2023-09-26 09:56:31 --> Output Class Initialized
INFO - 2023-09-26 09:56:31 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:31 --> Input Class Initialized
INFO - 2023-09-26 09:56:31 --> Language Class Initialized
INFO - 2023-09-26 09:56:31 --> Language Class Initialized
INFO - 2023-09-26 09:56:31 --> Config Class Initialized
INFO - 2023-09-26 09:56:31 --> Loader Class Initialized
INFO - 2023-09-26 09:56:31 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:31 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:31 --> Controller Class Initialized
DEBUG - 2023-09-26 09:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 09:56:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 09:56:31 --> Final output sent to browser
DEBUG - 2023-09-26 09:56:31 --> Total execution time: 0.0397
INFO - 2023-09-26 09:56:31 --> Config Class Initialized
INFO - 2023-09-26 09:56:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:31 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:31 --> URI Class Initialized
INFO - 2023-09-26 09:56:31 --> Router Class Initialized
INFO - 2023-09-26 09:56:31 --> Output Class Initialized
INFO - 2023-09-26 09:56:31 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:31 --> Input Class Initialized
INFO - 2023-09-26 09:56:31 --> Language Class Initialized
INFO - 2023-09-26 09:56:31 --> Language Class Initialized
INFO - 2023-09-26 09:56:31 --> Config Class Initialized
INFO - 2023-09-26 09:56:31 --> Loader Class Initialized
INFO - 2023-09-26 09:56:31 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:31 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:31 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:31 --> Controller Class Initialized
INFO - 2023-09-26 09:56:34 --> Config Class Initialized
INFO - 2023-09-26 09:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:34 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:34 --> URI Class Initialized
INFO - 2023-09-26 09:56:34 --> Router Class Initialized
INFO - 2023-09-26 09:56:34 --> Output Class Initialized
INFO - 2023-09-26 09:56:34 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:34 --> Input Class Initialized
INFO - 2023-09-26 09:56:34 --> Language Class Initialized
INFO - 2023-09-26 09:56:34 --> Language Class Initialized
INFO - 2023-09-26 09:56:34 --> Config Class Initialized
INFO - 2023-09-26 09:56:34 --> Loader Class Initialized
INFO - 2023-09-26 09:56:34 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:34 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:34 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:34 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:34 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:34 --> Controller Class Initialized
INFO - 2023-09-26 09:56:34 --> Final output sent to browser
DEBUG - 2023-09-26 09:56:34 --> Total execution time: 0.0307
INFO - 2023-09-26 09:56:38 --> Config Class Initialized
INFO - 2023-09-26 09:56:38 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:38 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:38 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:38 --> URI Class Initialized
INFO - 2023-09-26 09:56:38 --> Router Class Initialized
INFO - 2023-09-26 09:56:38 --> Output Class Initialized
INFO - 2023-09-26 09:56:38 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:38 --> Input Class Initialized
INFO - 2023-09-26 09:56:38 --> Language Class Initialized
INFO - 2023-09-26 09:56:38 --> Language Class Initialized
INFO - 2023-09-26 09:56:38 --> Config Class Initialized
INFO - 2023-09-26 09:56:38 --> Loader Class Initialized
INFO - 2023-09-26 09:56:38 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:38 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:38 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:38 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:38 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:38 --> Controller Class Initialized
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 09:56:38 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 09:56:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 09:56:40 --> Config Class Initialized
INFO - 2023-09-26 09:56:40 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:40 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:40 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:40 --> URI Class Initialized
INFO - 2023-09-26 09:56:40 --> Router Class Initialized
INFO - 2023-09-26 09:56:40 --> Output Class Initialized
INFO - 2023-09-26 09:56:40 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:40 --> Input Class Initialized
INFO - 2023-09-26 09:56:40 --> Language Class Initialized
INFO - 2023-09-26 09:56:40 --> Language Class Initialized
INFO - 2023-09-26 09:56:40 --> Config Class Initialized
INFO - 2023-09-26 09:56:40 --> Loader Class Initialized
INFO - 2023-09-26 09:56:40 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:40 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:40 --> Controller Class Initialized
DEBUG - 2023-09-26 09:56:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 09:56:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 09:56:40 --> Final output sent to browser
DEBUG - 2023-09-26 09:56:40 --> Total execution time: 0.0335
INFO - 2023-09-26 09:56:40 --> Config Class Initialized
INFO - 2023-09-26 09:56:40 --> Hooks Class Initialized
DEBUG - 2023-09-26 09:56:40 --> UTF-8 Support Enabled
INFO - 2023-09-26 09:56:40 --> Utf8 Class Initialized
INFO - 2023-09-26 09:56:40 --> URI Class Initialized
INFO - 2023-09-26 09:56:40 --> Router Class Initialized
INFO - 2023-09-26 09:56:40 --> Output Class Initialized
INFO - 2023-09-26 09:56:40 --> Security Class Initialized
DEBUG - 2023-09-26 09:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 09:56:40 --> Input Class Initialized
INFO - 2023-09-26 09:56:40 --> Language Class Initialized
INFO - 2023-09-26 09:56:40 --> Language Class Initialized
INFO - 2023-09-26 09:56:40 --> Config Class Initialized
INFO - 2023-09-26 09:56:40 --> Loader Class Initialized
INFO - 2023-09-26 09:56:40 --> Helper loaded: url_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: file_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: form_helper
INFO - 2023-09-26 09:56:40 --> Helper loaded: my_helper
INFO - 2023-09-26 09:56:40 --> Database Driver Class Initialized
INFO - 2023-09-26 09:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 09:56:40 --> Controller Class Initialized
INFO - 2023-09-26 11:11:19 --> Config Class Initialized
INFO - 2023-09-26 11:11:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:11:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:11:19 --> Utf8 Class Initialized
INFO - 2023-09-26 11:11:19 --> URI Class Initialized
INFO - 2023-09-26 11:11:19 --> Router Class Initialized
INFO - 2023-09-26 11:11:19 --> Output Class Initialized
INFO - 2023-09-26 11:11:19 --> Security Class Initialized
DEBUG - 2023-09-26 11:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:11:19 --> Input Class Initialized
INFO - 2023-09-26 11:11:19 --> Language Class Initialized
INFO - 2023-09-26 11:11:20 --> Language Class Initialized
INFO - 2023-09-26 11:11:20 --> Config Class Initialized
INFO - 2023-09-26 11:11:20 --> Loader Class Initialized
INFO - 2023-09-26 11:11:20 --> Helper loaded: url_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: file_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: form_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: my_helper
INFO - 2023-09-26 11:11:20 --> Database Driver Class Initialized
INFO - 2023-09-26 11:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 11:11:20 --> Controller Class Initialized
DEBUG - 2023-09-26 11:11:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 11:11:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 11:11:20 --> Final output sent to browser
DEBUG - 2023-09-26 11:11:20 --> Total execution time: 0.0717
INFO - 2023-09-26 11:11:20 --> Config Class Initialized
INFO - 2023-09-26 11:11:20 --> Hooks Class Initialized
DEBUG - 2023-09-26 11:11:20 --> UTF-8 Support Enabled
INFO - 2023-09-26 11:11:20 --> Utf8 Class Initialized
INFO - 2023-09-26 11:11:20 --> URI Class Initialized
INFO - 2023-09-26 11:11:20 --> Router Class Initialized
INFO - 2023-09-26 11:11:20 --> Output Class Initialized
INFO - 2023-09-26 11:11:20 --> Security Class Initialized
DEBUG - 2023-09-26 11:11:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 11:11:20 --> Input Class Initialized
INFO - 2023-09-26 11:11:20 --> Language Class Initialized
INFO - 2023-09-26 11:11:20 --> Language Class Initialized
INFO - 2023-09-26 11:11:20 --> Config Class Initialized
INFO - 2023-09-26 11:11:20 --> Loader Class Initialized
INFO - 2023-09-26 11:11:20 --> Helper loaded: url_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: file_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: form_helper
INFO - 2023-09-26 11:11:20 --> Helper loaded: my_helper
INFO - 2023-09-26 11:11:20 --> Database Driver Class Initialized
INFO - 2023-09-26 11:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 11:11:20 --> Controller Class Initialized
INFO - 2023-09-26 14:12:06 --> Config Class Initialized
INFO - 2023-09-26 14:12:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:07 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:07 --> URI Class Initialized
INFO - 2023-09-26 14:12:07 --> Router Class Initialized
INFO - 2023-09-26 14:12:07 --> Output Class Initialized
INFO - 2023-09-26 14:12:07 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:07 --> Input Class Initialized
INFO - 2023-09-26 14:12:07 --> Language Class Initialized
INFO - 2023-09-26 14:12:07 --> Language Class Initialized
INFO - 2023-09-26 14:12:07 --> Config Class Initialized
INFO - 2023-09-26 14:12:07 --> Loader Class Initialized
INFO - 2023-09-26 14:12:07 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:07 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:07 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:07 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:07 --> Total execution time: 0.4097
INFO - 2023-09-26 14:12:07 --> Config Class Initialized
INFO - 2023-09-26 14:12:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:07 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:07 --> URI Class Initialized
INFO - 2023-09-26 14:12:07 --> Router Class Initialized
INFO - 2023-09-26 14:12:07 --> Output Class Initialized
INFO - 2023-09-26 14:12:07 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:07 --> Input Class Initialized
INFO - 2023-09-26 14:12:07 --> Language Class Initialized
INFO - 2023-09-26 14:12:07 --> Language Class Initialized
INFO - 2023-09-26 14:12:07 --> Config Class Initialized
INFO - 2023-09-26 14:12:07 --> Loader Class Initialized
INFO - 2023-09-26 14:12:07 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:07 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:07 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:07 --> Controller Class Initialized
INFO - 2023-09-26 14:12:12 --> Config Class Initialized
INFO - 2023-09-26 14:12:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:12 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:12 --> URI Class Initialized
INFO - 2023-09-26 14:12:12 --> Router Class Initialized
INFO - 2023-09-26 14:12:12 --> Output Class Initialized
INFO - 2023-09-26 14:12:12 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:12 --> Input Class Initialized
INFO - 2023-09-26 14:12:12 --> Language Class Initialized
INFO - 2023-09-26 14:12:12 --> Language Class Initialized
INFO - 2023-09-26 14:12:12 --> Config Class Initialized
INFO - 2023-09-26 14:12:12 --> Loader Class Initialized
INFO - 2023-09-26 14:12:12 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:12 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:12 --> Controller Class Initialized
INFO - 2023-09-26 14:12:12 --> Config Class Initialized
INFO - 2023-09-26 14:12:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:12 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:12 --> URI Class Initialized
INFO - 2023-09-26 14:12:12 --> Router Class Initialized
INFO - 2023-09-26 14:12:12 --> Output Class Initialized
INFO - 2023-09-26 14:12:12 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:12 --> Input Class Initialized
INFO - 2023-09-26 14:12:12 --> Language Class Initialized
INFO - 2023-09-26 14:12:12 --> Language Class Initialized
INFO - 2023-09-26 14:12:12 --> Config Class Initialized
INFO - 2023-09-26 14:12:12 --> Loader Class Initialized
INFO - 2023-09-26 14:12:12 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:12 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:12 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:12 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 14:12:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:12 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:12 --> Total execution time: 0.0435
INFO - 2023-09-26 14:12:14 --> Config Class Initialized
INFO - 2023-09-26 14:12:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:14 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:14 --> URI Class Initialized
INFO - 2023-09-26 14:12:14 --> Router Class Initialized
INFO - 2023-09-26 14:12:14 --> Output Class Initialized
INFO - 2023-09-26 14:12:14 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:14 --> Input Class Initialized
INFO - 2023-09-26 14:12:14 --> Language Class Initialized
INFO - 2023-09-26 14:12:14 --> Language Class Initialized
INFO - 2023-09-26 14:12:14 --> Config Class Initialized
INFO - 2023-09-26 14:12:14 --> Loader Class Initialized
INFO - 2023-09-26 14:12:14 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:14 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:14 --> Controller Class Initialized
INFO - 2023-09-26 14:12:14 --> Helper loaded: cookie_helper
INFO - 2023-09-26 14:12:14 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:14 --> Total execution time: 0.0607
INFO - 2023-09-26 14:12:14 --> Config Class Initialized
INFO - 2023-09-26 14:12:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:14 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:14 --> URI Class Initialized
INFO - 2023-09-26 14:12:14 --> Router Class Initialized
INFO - 2023-09-26 14:12:14 --> Output Class Initialized
INFO - 2023-09-26 14:12:14 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:14 --> Input Class Initialized
INFO - 2023-09-26 14:12:14 --> Language Class Initialized
INFO - 2023-09-26 14:12:14 --> Language Class Initialized
INFO - 2023-09-26 14:12:14 --> Config Class Initialized
INFO - 2023-09-26 14:12:14 --> Loader Class Initialized
INFO - 2023-09-26 14:12:14 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:14 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:14 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:14 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 14:12:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:14 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:14 --> Total execution time: 0.0444
INFO - 2023-09-26 14:12:17 --> Config Class Initialized
INFO - 2023-09-26 14:12:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:17 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:17 --> URI Class Initialized
INFO - 2023-09-26 14:12:17 --> Router Class Initialized
INFO - 2023-09-26 14:12:17 --> Output Class Initialized
INFO - 2023-09-26 14:12:17 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:17 --> Input Class Initialized
INFO - 2023-09-26 14:12:17 --> Language Class Initialized
INFO - 2023-09-26 14:12:17 --> Language Class Initialized
INFO - 2023-09-26 14:12:17 --> Config Class Initialized
INFO - 2023-09-26 14:12:17 --> Loader Class Initialized
INFO - 2023-09-26 14:12:17 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:17 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:17 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:17 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:17 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:17 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:12:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:17 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:17 --> Total execution time: 0.0386
INFO - 2023-09-26 14:12:19 --> Config Class Initialized
INFO - 2023-09-26 14:12:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:19 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:19 --> URI Class Initialized
INFO - 2023-09-26 14:12:19 --> Router Class Initialized
INFO - 2023-09-26 14:12:19 --> Output Class Initialized
INFO - 2023-09-26 14:12:19 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:19 --> Input Class Initialized
INFO - 2023-09-26 14:12:19 --> Language Class Initialized
INFO - 2023-09-26 14:12:19 --> Language Class Initialized
INFO - 2023-09-26 14:12:19 --> Config Class Initialized
INFO - 2023-09-26 14:12:19 --> Loader Class Initialized
INFO - 2023-09-26 14:12:19 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:19 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:19 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:19 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:19 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:19 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:19 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:19 --> Total execution time: 0.0786
INFO - 2023-09-26 14:12:19 --> Config Class Initialized
INFO - 2023-09-26 14:12:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:19 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:19 --> URI Class Initialized
INFO - 2023-09-26 14:12:19 --> Router Class Initialized
INFO - 2023-09-26 14:12:19 --> Output Class Initialized
INFO - 2023-09-26 14:12:19 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:19 --> Input Class Initialized
INFO - 2023-09-26 14:12:19 --> Language Class Initialized
INFO - 2023-09-26 14:12:19 --> Language Class Initialized
INFO - 2023-09-26 14:12:19 --> Config Class Initialized
INFO - 2023-09-26 14:12:19 --> Loader Class Initialized
INFO - 2023-09-26 14:12:19 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:19 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:20 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:20 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:20 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:20 --> Controller Class Initialized
INFO - 2023-09-26 14:12:23 --> Config Class Initialized
INFO - 2023-09-26 14:12:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:23 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:23 --> URI Class Initialized
INFO - 2023-09-26 14:12:23 --> Router Class Initialized
INFO - 2023-09-26 14:12:23 --> Output Class Initialized
INFO - 2023-09-26 14:12:23 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:23 --> Input Class Initialized
INFO - 2023-09-26 14:12:23 --> Language Class Initialized
INFO - 2023-09-26 14:12:23 --> Language Class Initialized
INFO - 2023-09-26 14:12:23 --> Config Class Initialized
INFO - 2023-09-26 14:12:23 --> Loader Class Initialized
INFO - 2023-09-26 14:12:23 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:23 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:23 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:23 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:23 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:23 --> Controller Class Initialized
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:23 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:12:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:12:28 --> Config Class Initialized
INFO - 2023-09-26 14:12:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:28 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:28 --> URI Class Initialized
INFO - 2023-09-26 14:12:28 --> Router Class Initialized
INFO - 2023-09-26 14:12:28 --> Output Class Initialized
INFO - 2023-09-26 14:12:28 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:28 --> Input Class Initialized
INFO - 2023-09-26 14:12:28 --> Language Class Initialized
INFO - 2023-09-26 14:12:28 --> Language Class Initialized
INFO - 2023-09-26 14:12:28 --> Config Class Initialized
INFO - 2023-09-26 14:12:28 --> Loader Class Initialized
INFO - 2023-09-26 14:12:28 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:28 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:28 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:28 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:28 --> Total execution time: 0.0383
INFO - 2023-09-26 14:12:28 --> Config Class Initialized
INFO - 2023-09-26 14:12:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:28 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:28 --> URI Class Initialized
INFO - 2023-09-26 14:12:28 --> Router Class Initialized
INFO - 2023-09-26 14:12:28 --> Output Class Initialized
INFO - 2023-09-26 14:12:28 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:28 --> Input Class Initialized
INFO - 2023-09-26 14:12:28 --> Language Class Initialized
INFO - 2023-09-26 14:12:28 --> Language Class Initialized
INFO - 2023-09-26 14:12:28 --> Config Class Initialized
INFO - 2023-09-26 14:12:28 --> Loader Class Initialized
INFO - 2023-09-26 14:12:28 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:28 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:28 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:28 --> Controller Class Initialized
INFO - 2023-09-26 14:12:31 --> Config Class Initialized
INFO - 2023-09-26 14:12:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:31 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:31 --> URI Class Initialized
INFO - 2023-09-26 14:12:31 --> Router Class Initialized
INFO - 2023-09-26 14:12:31 --> Output Class Initialized
INFO - 2023-09-26 14:12:31 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:31 --> Input Class Initialized
INFO - 2023-09-26 14:12:31 --> Language Class Initialized
INFO - 2023-09-26 14:12:31 --> Language Class Initialized
INFO - 2023-09-26 14:12:31 --> Config Class Initialized
INFO - 2023-09-26 14:12:31 --> Loader Class Initialized
INFO - 2023-09-26 14:12:31 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:31 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:31 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:31 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:31 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:31 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:12:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:31 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:31 --> Total execution time: 0.0789
INFO - 2023-09-26 14:12:33 --> Config Class Initialized
INFO - 2023-09-26 14:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:33 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:33 --> URI Class Initialized
INFO - 2023-09-26 14:12:33 --> Router Class Initialized
INFO - 2023-09-26 14:12:33 --> Output Class Initialized
INFO - 2023-09-26 14:12:33 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:33 --> Input Class Initialized
INFO - 2023-09-26 14:12:33 --> Language Class Initialized
INFO - 2023-09-26 14:12:33 --> Language Class Initialized
INFO - 2023-09-26 14:12:33 --> Config Class Initialized
INFO - 2023-09-26 14:12:33 --> Loader Class Initialized
INFO - 2023-09-26 14:12:33 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:33 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:33 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:33 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:33 --> Total execution time: 0.0458
INFO - 2023-09-26 14:12:33 --> Config Class Initialized
INFO - 2023-09-26 14:12:33 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:33 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:33 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:33 --> URI Class Initialized
INFO - 2023-09-26 14:12:33 --> Router Class Initialized
INFO - 2023-09-26 14:12:33 --> Output Class Initialized
INFO - 2023-09-26 14:12:33 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:33 --> Input Class Initialized
INFO - 2023-09-26 14:12:33 --> Language Class Initialized
INFO - 2023-09-26 14:12:33 --> Language Class Initialized
INFO - 2023-09-26 14:12:33 --> Config Class Initialized
INFO - 2023-09-26 14:12:33 --> Loader Class Initialized
INFO - 2023-09-26 14:12:33 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:33 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:33 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:33 --> Controller Class Initialized
INFO - 2023-09-26 14:12:35 --> Config Class Initialized
INFO - 2023-09-26 14:12:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:35 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:35 --> URI Class Initialized
INFO - 2023-09-26 14:12:35 --> Router Class Initialized
INFO - 2023-09-26 14:12:35 --> Output Class Initialized
INFO - 2023-09-26 14:12:35 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:35 --> Input Class Initialized
INFO - 2023-09-26 14:12:35 --> Language Class Initialized
INFO - 2023-09-26 14:12:35 --> Language Class Initialized
INFO - 2023-09-26 14:12:35 --> Config Class Initialized
INFO - 2023-09-26 14:12:35 --> Loader Class Initialized
INFO - 2023-09-26 14:12:35 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:35 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:35 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:35 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:35 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:35 --> Controller Class Initialized
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:35 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:12:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:12:37 --> Config Class Initialized
INFO - 2023-09-26 14:12:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:37 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:37 --> URI Class Initialized
INFO - 2023-09-26 14:12:37 --> Router Class Initialized
INFO - 2023-09-26 14:12:37 --> Output Class Initialized
INFO - 2023-09-26 14:12:37 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:37 --> Input Class Initialized
INFO - 2023-09-26 14:12:37 --> Language Class Initialized
INFO - 2023-09-26 14:12:37 --> Language Class Initialized
INFO - 2023-09-26 14:12:37 --> Config Class Initialized
INFO - 2023-09-26 14:12:37 --> Loader Class Initialized
INFO - 2023-09-26 14:12:37 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:37 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:37 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:37 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:37 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:38 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:38 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:38 --> Total execution time: 0.0374
INFO - 2023-09-26 14:12:38 --> Config Class Initialized
INFO - 2023-09-26 14:12:38 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:38 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:38 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:38 --> URI Class Initialized
INFO - 2023-09-26 14:12:38 --> Router Class Initialized
INFO - 2023-09-26 14:12:38 --> Output Class Initialized
INFO - 2023-09-26 14:12:38 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:38 --> Input Class Initialized
INFO - 2023-09-26 14:12:38 --> Language Class Initialized
INFO - 2023-09-26 14:12:38 --> Language Class Initialized
INFO - 2023-09-26 14:12:38 --> Config Class Initialized
INFO - 2023-09-26 14:12:38 --> Loader Class Initialized
INFO - 2023-09-26 14:12:38 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:38 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:38 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:38 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:38 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:38 --> Controller Class Initialized
INFO - 2023-09-26 14:12:40 --> Config Class Initialized
INFO - 2023-09-26 14:12:40 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:40 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:40 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:40 --> URI Class Initialized
INFO - 2023-09-26 14:12:40 --> Router Class Initialized
INFO - 2023-09-26 14:12:40 --> Output Class Initialized
INFO - 2023-09-26 14:12:40 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:40 --> Input Class Initialized
INFO - 2023-09-26 14:12:40 --> Language Class Initialized
INFO - 2023-09-26 14:12:40 --> Language Class Initialized
INFO - 2023-09-26 14:12:40 --> Config Class Initialized
INFO - 2023-09-26 14:12:40 --> Loader Class Initialized
INFO - 2023-09-26 14:12:40 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:40 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:40 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:40 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:40 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:40 --> Controller Class Initialized
INFO - 2023-09-26 14:12:40 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:40 --> Total execution time: 0.0865
INFO - 2023-09-26 14:12:41 --> Config Class Initialized
INFO - 2023-09-26 14:12:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:41 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:41 --> URI Class Initialized
INFO - 2023-09-26 14:12:41 --> Router Class Initialized
INFO - 2023-09-26 14:12:41 --> Output Class Initialized
INFO - 2023-09-26 14:12:41 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:41 --> Input Class Initialized
INFO - 2023-09-26 14:12:41 --> Language Class Initialized
INFO - 2023-09-26 14:12:41 --> Language Class Initialized
INFO - 2023-09-26 14:12:41 --> Config Class Initialized
INFO - 2023-09-26 14:12:41 --> Loader Class Initialized
INFO - 2023-09-26 14:12:41 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:41 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:41 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:41 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:41 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:41 --> Controller Class Initialized
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:12:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:12:44 --> Config Class Initialized
INFO - 2023-09-26 14:12:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:44 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:44 --> URI Class Initialized
INFO - 2023-09-26 14:12:44 --> Router Class Initialized
INFO - 2023-09-26 14:12:44 --> Output Class Initialized
INFO - 2023-09-26 14:12:44 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:44 --> Input Class Initialized
INFO - 2023-09-26 14:12:44 --> Language Class Initialized
INFO - 2023-09-26 14:12:44 --> Language Class Initialized
INFO - 2023-09-26 14:12:44 --> Config Class Initialized
INFO - 2023-09-26 14:12:44 --> Loader Class Initialized
INFO - 2023-09-26 14:12:44 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:44 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:44 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:44 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:44 --> Total execution time: 0.0478
INFO - 2023-09-26 14:12:44 --> Config Class Initialized
INFO - 2023-09-26 14:12:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:44 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:44 --> URI Class Initialized
INFO - 2023-09-26 14:12:44 --> Router Class Initialized
INFO - 2023-09-26 14:12:44 --> Output Class Initialized
INFO - 2023-09-26 14:12:44 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:44 --> Input Class Initialized
INFO - 2023-09-26 14:12:44 --> Language Class Initialized
INFO - 2023-09-26 14:12:44 --> Language Class Initialized
INFO - 2023-09-26 14:12:44 --> Config Class Initialized
INFO - 2023-09-26 14:12:44 --> Loader Class Initialized
INFO - 2023-09-26 14:12:44 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:44 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:44 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:44 --> Controller Class Initialized
INFO - 2023-09-26 14:12:45 --> Config Class Initialized
INFO - 2023-09-26 14:12:45 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:45 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:45 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:45 --> URI Class Initialized
INFO - 2023-09-26 14:12:45 --> Router Class Initialized
INFO - 2023-09-26 14:12:45 --> Output Class Initialized
INFO - 2023-09-26 14:12:45 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:45 --> Input Class Initialized
INFO - 2023-09-26 14:12:45 --> Language Class Initialized
INFO - 2023-09-26 14:12:45 --> Language Class Initialized
INFO - 2023-09-26 14:12:45 --> Config Class Initialized
INFO - 2023-09-26 14:12:45 --> Loader Class Initialized
INFO - 2023-09-26 14:12:45 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:45 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:45 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:45 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:45 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:45 --> Controller Class Initialized
INFO - 2023-09-26 14:12:45 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:45 --> Total execution time: 0.0444
INFO - 2023-09-26 14:12:46 --> Config Class Initialized
INFO - 2023-09-26 14:12:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:46 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:46 --> URI Class Initialized
INFO - 2023-09-26 14:12:46 --> Router Class Initialized
INFO - 2023-09-26 14:12:46 --> Output Class Initialized
INFO - 2023-09-26 14:12:46 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:46 --> Input Class Initialized
INFO - 2023-09-26 14:12:46 --> Language Class Initialized
INFO - 2023-09-26 14:12:46 --> Language Class Initialized
INFO - 2023-09-26 14:12:46 --> Config Class Initialized
INFO - 2023-09-26 14:12:46 --> Loader Class Initialized
INFO - 2023-09-26 14:12:46 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:46 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:46 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:46 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:46 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:46 --> Controller Class Initialized
INFO - 2023-09-26 14:12:46 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:46 --> Total execution time: 0.0594
INFO - 2023-09-26 14:12:48 --> Config Class Initialized
INFO - 2023-09-26 14:12:48 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:48 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:48 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:48 --> URI Class Initialized
INFO - 2023-09-26 14:12:48 --> Router Class Initialized
INFO - 2023-09-26 14:12:48 --> Output Class Initialized
INFO - 2023-09-26 14:12:48 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:48 --> Input Class Initialized
INFO - 2023-09-26 14:12:48 --> Language Class Initialized
INFO - 2023-09-26 14:12:48 --> Language Class Initialized
INFO - 2023-09-26 14:12:48 --> Config Class Initialized
INFO - 2023-09-26 14:12:48 --> Loader Class Initialized
INFO - 2023-09-26 14:12:48 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:48 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:48 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:48 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:48 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:48 --> Controller Class Initialized
INFO - 2023-09-26 14:12:48 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:48 --> Total execution time: 0.0371
INFO - 2023-09-26 14:12:51 --> Config Class Initialized
INFO - 2023-09-26 14:12:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:51 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:51 --> URI Class Initialized
INFO - 2023-09-26 14:12:51 --> Router Class Initialized
INFO - 2023-09-26 14:12:52 --> Output Class Initialized
INFO - 2023-09-26 14:12:52 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:52 --> Input Class Initialized
INFO - 2023-09-26 14:12:52 --> Language Class Initialized
INFO - 2023-09-26 14:12:52 --> Language Class Initialized
INFO - 2023-09-26 14:12:52 --> Config Class Initialized
INFO - 2023-09-26 14:12:52 --> Loader Class Initialized
INFO - 2023-09-26 14:12:52 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:52 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:52 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:52 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:52 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:52 --> Controller Class Initialized
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:12:52 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:12:52 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:12:54 --> Config Class Initialized
INFO - 2023-09-26 14:12:54 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:54 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:54 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:54 --> URI Class Initialized
INFO - 2023-09-26 14:12:54 --> Router Class Initialized
INFO - 2023-09-26 14:12:54 --> Output Class Initialized
INFO - 2023-09-26 14:12:54 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:54 --> Input Class Initialized
INFO - 2023-09-26 14:12:54 --> Language Class Initialized
INFO - 2023-09-26 14:12:54 --> Language Class Initialized
INFO - 2023-09-26 14:12:54 --> Config Class Initialized
INFO - 2023-09-26 14:12:54 --> Loader Class Initialized
INFO - 2023-09-26 14:12:54 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:54 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:54 --> Controller Class Initialized
DEBUG - 2023-09-26 14:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:12:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:12:54 --> Final output sent to browser
DEBUG - 2023-09-26 14:12:54 --> Total execution time: 0.1154
INFO - 2023-09-26 14:12:54 --> Config Class Initialized
INFO - 2023-09-26 14:12:54 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:12:54 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:12:54 --> Utf8 Class Initialized
INFO - 2023-09-26 14:12:54 --> URI Class Initialized
INFO - 2023-09-26 14:12:54 --> Router Class Initialized
INFO - 2023-09-26 14:12:54 --> Output Class Initialized
INFO - 2023-09-26 14:12:54 --> Security Class Initialized
DEBUG - 2023-09-26 14:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:12:54 --> Input Class Initialized
INFO - 2023-09-26 14:12:54 --> Language Class Initialized
INFO - 2023-09-26 14:12:54 --> Language Class Initialized
INFO - 2023-09-26 14:12:54 --> Config Class Initialized
INFO - 2023-09-26 14:12:54 --> Loader Class Initialized
INFO - 2023-09-26 14:12:54 --> Helper loaded: url_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: file_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: form_helper
INFO - 2023-09-26 14:12:54 --> Helper loaded: my_helper
INFO - 2023-09-26 14:12:54 --> Database Driver Class Initialized
INFO - 2023-09-26 14:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:12:54 --> Controller Class Initialized
INFO - 2023-09-26 14:13:01 --> Config Class Initialized
INFO - 2023-09-26 14:13:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:01 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:01 --> URI Class Initialized
INFO - 2023-09-26 14:13:01 --> Router Class Initialized
INFO - 2023-09-26 14:13:01 --> Output Class Initialized
INFO - 2023-09-26 14:13:01 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:01 --> Input Class Initialized
INFO - 2023-09-26 14:13:01 --> Language Class Initialized
INFO - 2023-09-26 14:13:01 --> Language Class Initialized
INFO - 2023-09-26 14:13:01 --> Config Class Initialized
INFO - 2023-09-26 14:13:01 --> Loader Class Initialized
INFO - 2023-09-26 14:13:01 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:01 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:01 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:01 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:01 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:01 --> Controller Class Initialized
INFO - 2023-09-26 14:13:01 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:01 --> Total execution time: 0.1870
INFO - 2023-09-26 14:13:07 --> Config Class Initialized
INFO - 2023-09-26 14:13:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:07 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:07 --> URI Class Initialized
INFO - 2023-09-26 14:13:07 --> Router Class Initialized
INFO - 2023-09-26 14:13:07 --> Output Class Initialized
INFO - 2023-09-26 14:13:07 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:07 --> Input Class Initialized
INFO - 2023-09-26 14:13:07 --> Language Class Initialized
INFO - 2023-09-26 14:13:07 --> Language Class Initialized
INFO - 2023-09-26 14:13:07 --> Config Class Initialized
INFO - 2023-09-26 14:13:07 --> Loader Class Initialized
INFO - 2023-09-26 14:13:07 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:07 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:07 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:07 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:07 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:07 --> Controller Class Initialized
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:07 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:13:07 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:13:09 --> Config Class Initialized
INFO - 2023-09-26 14:13:09 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:09 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:09 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:09 --> URI Class Initialized
INFO - 2023-09-26 14:13:09 --> Router Class Initialized
INFO - 2023-09-26 14:13:09 --> Output Class Initialized
INFO - 2023-09-26 14:13:09 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:09 --> Input Class Initialized
INFO - 2023-09-26 14:13:09 --> Language Class Initialized
INFO - 2023-09-26 14:13:09 --> Language Class Initialized
INFO - 2023-09-26 14:13:09 --> Config Class Initialized
INFO - 2023-09-26 14:13:09 --> Loader Class Initialized
INFO - 2023-09-26 14:13:09 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:09 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:09 --> Controller Class Initialized
DEBUG - 2023-09-26 14:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:13:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:13:09 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:09 --> Total execution time: 0.0444
INFO - 2023-09-26 14:13:09 --> Config Class Initialized
INFO - 2023-09-26 14:13:09 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:09 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:09 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:09 --> URI Class Initialized
INFO - 2023-09-26 14:13:09 --> Router Class Initialized
INFO - 2023-09-26 14:13:09 --> Output Class Initialized
INFO - 2023-09-26 14:13:09 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:09 --> Input Class Initialized
INFO - 2023-09-26 14:13:09 --> Language Class Initialized
INFO - 2023-09-26 14:13:09 --> Language Class Initialized
INFO - 2023-09-26 14:13:09 --> Config Class Initialized
INFO - 2023-09-26 14:13:09 --> Loader Class Initialized
INFO - 2023-09-26 14:13:09 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:09 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:09 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:09 --> Controller Class Initialized
INFO - 2023-09-26 14:13:18 --> Config Class Initialized
INFO - 2023-09-26 14:13:18 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:18 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:18 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:18 --> URI Class Initialized
INFO - 2023-09-26 14:13:18 --> Router Class Initialized
INFO - 2023-09-26 14:13:18 --> Output Class Initialized
INFO - 2023-09-26 14:13:18 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:18 --> Input Class Initialized
INFO - 2023-09-26 14:13:18 --> Language Class Initialized
INFO - 2023-09-26 14:13:18 --> Language Class Initialized
INFO - 2023-09-26 14:13:18 --> Config Class Initialized
INFO - 2023-09-26 14:13:18 --> Loader Class Initialized
INFO - 2023-09-26 14:13:18 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:18 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:18 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:18 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:18 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:18 --> Controller Class Initialized
INFO - 2023-09-26 14:13:18 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:18 --> Total execution time: 0.0497
INFO - 2023-09-26 14:13:27 --> Config Class Initialized
INFO - 2023-09-26 14:13:27 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:27 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:27 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:27 --> URI Class Initialized
INFO - 2023-09-26 14:13:27 --> Router Class Initialized
INFO - 2023-09-26 14:13:27 --> Output Class Initialized
INFO - 2023-09-26 14:13:27 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:27 --> Input Class Initialized
INFO - 2023-09-26 14:13:27 --> Language Class Initialized
INFO - 2023-09-26 14:13:27 --> Language Class Initialized
INFO - 2023-09-26 14:13:27 --> Config Class Initialized
INFO - 2023-09-26 14:13:27 --> Loader Class Initialized
INFO - 2023-09-26 14:13:27 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:27 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:27 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:27 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:27 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:27 --> Controller Class Initialized
INFO - 2023-09-26 14:13:27 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:27 --> Total execution time: 0.0422
INFO - 2023-09-26 14:13:29 --> Config Class Initialized
INFO - 2023-09-26 14:13:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:29 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:29 --> URI Class Initialized
INFO - 2023-09-26 14:13:29 --> Router Class Initialized
INFO - 2023-09-26 14:13:29 --> Output Class Initialized
INFO - 2023-09-26 14:13:29 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:29 --> Input Class Initialized
INFO - 2023-09-26 14:13:29 --> Language Class Initialized
INFO - 2023-09-26 14:13:29 --> Language Class Initialized
INFO - 2023-09-26 14:13:29 --> Config Class Initialized
INFO - 2023-09-26 14:13:29 --> Loader Class Initialized
INFO - 2023-09-26 14:13:29 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:29 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:29 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:29 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:29 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:29 --> Controller Class Initialized
INFO - 2023-09-26 14:13:29 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:29 --> Total execution time: 0.0443
INFO - 2023-09-26 14:13:31 --> Config Class Initialized
INFO - 2023-09-26 14:13:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:31 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:31 --> URI Class Initialized
INFO - 2023-09-26 14:13:31 --> Router Class Initialized
INFO - 2023-09-26 14:13:31 --> Output Class Initialized
INFO - 2023-09-26 14:13:31 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:31 --> Input Class Initialized
INFO - 2023-09-26 14:13:31 --> Language Class Initialized
INFO - 2023-09-26 14:13:31 --> Language Class Initialized
INFO - 2023-09-26 14:13:31 --> Config Class Initialized
INFO - 2023-09-26 14:13:31 --> Loader Class Initialized
INFO - 2023-09-26 14:13:31 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:31 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:31 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:31 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:31 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:31 --> Controller Class Initialized
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:31 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:13:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:13:34 --> Config Class Initialized
INFO - 2023-09-26 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:34 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:34 --> URI Class Initialized
INFO - 2023-09-26 14:13:34 --> Router Class Initialized
INFO - 2023-09-26 14:13:34 --> Output Class Initialized
INFO - 2023-09-26 14:13:34 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:34 --> Input Class Initialized
INFO - 2023-09-26 14:13:34 --> Language Class Initialized
INFO - 2023-09-26 14:13:34 --> Language Class Initialized
INFO - 2023-09-26 14:13:34 --> Config Class Initialized
INFO - 2023-09-26 14:13:34 --> Loader Class Initialized
INFO - 2023-09-26 14:13:34 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:34 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:34 --> Controller Class Initialized
DEBUG - 2023-09-26 14:13:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:13:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:13:34 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:34 --> Total execution time: 0.0530
INFO - 2023-09-26 14:13:34 --> Config Class Initialized
INFO - 2023-09-26 14:13:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:34 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:34 --> URI Class Initialized
INFO - 2023-09-26 14:13:34 --> Router Class Initialized
INFO - 2023-09-26 14:13:34 --> Output Class Initialized
INFO - 2023-09-26 14:13:34 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:34 --> Input Class Initialized
INFO - 2023-09-26 14:13:34 --> Language Class Initialized
INFO - 2023-09-26 14:13:34 --> Language Class Initialized
INFO - 2023-09-26 14:13:34 --> Config Class Initialized
INFO - 2023-09-26 14:13:34 --> Loader Class Initialized
INFO - 2023-09-26 14:13:34 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:34 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:34 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:34 --> Controller Class Initialized
INFO - 2023-09-26 14:13:39 --> Config Class Initialized
INFO - 2023-09-26 14:13:39 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:39 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:39 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:39 --> URI Class Initialized
INFO - 2023-09-26 14:13:39 --> Router Class Initialized
INFO - 2023-09-26 14:13:39 --> Output Class Initialized
INFO - 2023-09-26 14:13:39 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:39 --> Input Class Initialized
INFO - 2023-09-26 14:13:39 --> Language Class Initialized
INFO - 2023-09-26 14:13:39 --> Language Class Initialized
INFO - 2023-09-26 14:13:39 --> Config Class Initialized
INFO - 2023-09-26 14:13:39 --> Loader Class Initialized
INFO - 2023-09-26 14:13:39 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:39 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:39 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:39 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:39 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:39 --> Controller Class Initialized
INFO - 2023-09-26 14:13:39 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:39 --> Total execution time: 0.0457
INFO - 2023-09-26 14:13:40 --> Config Class Initialized
INFO - 2023-09-26 14:13:40 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:40 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:40 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:40 --> URI Class Initialized
INFO - 2023-09-26 14:13:40 --> Router Class Initialized
INFO - 2023-09-26 14:13:40 --> Output Class Initialized
INFO - 2023-09-26 14:13:40 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:40 --> Input Class Initialized
INFO - 2023-09-26 14:13:40 --> Language Class Initialized
INFO - 2023-09-26 14:13:40 --> Language Class Initialized
INFO - 2023-09-26 14:13:40 --> Config Class Initialized
INFO - 2023-09-26 14:13:40 --> Loader Class Initialized
INFO - 2023-09-26 14:13:40 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:40 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:40 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:40 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:40 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:40 --> Controller Class Initialized
INFO - 2023-09-26 14:13:40 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:40 --> Total execution time: 0.0897
INFO - 2023-09-26 14:13:42 --> Config Class Initialized
INFO - 2023-09-26 14:13:42 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:42 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:42 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:42 --> URI Class Initialized
INFO - 2023-09-26 14:13:42 --> Router Class Initialized
INFO - 2023-09-26 14:13:42 --> Output Class Initialized
INFO - 2023-09-26 14:13:42 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:42 --> Input Class Initialized
INFO - 2023-09-26 14:13:42 --> Language Class Initialized
INFO - 2023-09-26 14:13:42 --> Language Class Initialized
INFO - 2023-09-26 14:13:42 --> Config Class Initialized
INFO - 2023-09-26 14:13:42 --> Loader Class Initialized
INFO - 2023-09-26 14:13:42 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:42 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:42 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:42 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:42 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:42 --> Controller Class Initialized
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:42 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:13:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:13:46 --> Config Class Initialized
INFO - 2023-09-26 14:13:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:46 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:46 --> URI Class Initialized
INFO - 2023-09-26 14:13:46 --> Router Class Initialized
INFO - 2023-09-26 14:13:46 --> Output Class Initialized
INFO - 2023-09-26 14:13:46 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:46 --> Input Class Initialized
INFO - 2023-09-26 14:13:46 --> Language Class Initialized
INFO - 2023-09-26 14:13:46 --> Language Class Initialized
INFO - 2023-09-26 14:13:46 --> Config Class Initialized
INFO - 2023-09-26 14:13:46 --> Loader Class Initialized
INFO - 2023-09-26 14:13:46 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:46 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:46 --> Controller Class Initialized
DEBUG - 2023-09-26 14:13:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:13:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:13:46 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:46 --> Total execution time: 0.0738
INFO - 2023-09-26 14:13:46 --> Config Class Initialized
INFO - 2023-09-26 14:13:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:46 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:46 --> URI Class Initialized
INFO - 2023-09-26 14:13:46 --> Router Class Initialized
INFO - 2023-09-26 14:13:46 --> Output Class Initialized
INFO - 2023-09-26 14:13:46 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:46 --> Input Class Initialized
INFO - 2023-09-26 14:13:46 --> Language Class Initialized
INFO - 2023-09-26 14:13:46 --> Language Class Initialized
INFO - 2023-09-26 14:13:46 --> Config Class Initialized
INFO - 2023-09-26 14:13:46 --> Loader Class Initialized
INFO - 2023-09-26 14:13:46 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:46 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:46 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:46 --> Controller Class Initialized
INFO - 2023-09-26 14:13:52 --> Config Class Initialized
INFO - 2023-09-26 14:13:52 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:52 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:52 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:52 --> URI Class Initialized
INFO - 2023-09-26 14:13:52 --> Router Class Initialized
INFO - 2023-09-26 14:13:52 --> Output Class Initialized
INFO - 2023-09-26 14:13:52 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:52 --> Input Class Initialized
INFO - 2023-09-26 14:13:52 --> Language Class Initialized
INFO - 2023-09-26 14:13:52 --> Language Class Initialized
INFO - 2023-09-26 14:13:52 --> Config Class Initialized
INFO - 2023-09-26 14:13:52 --> Loader Class Initialized
INFO - 2023-09-26 14:13:52 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:52 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:52 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:52 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:52 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:52 --> Controller Class Initialized
INFO - 2023-09-26 14:13:52 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:52 --> Total execution time: 0.0707
INFO - 2023-09-26 14:13:53 --> Config Class Initialized
INFO - 2023-09-26 14:13:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:53 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:53 --> URI Class Initialized
INFO - 2023-09-26 14:13:53 --> Router Class Initialized
INFO - 2023-09-26 14:13:53 --> Output Class Initialized
INFO - 2023-09-26 14:13:53 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:53 --> Input Class Initialized
INFO - 2023-09-26 14:13:53 --> Language Class Initialized
INFO - 2023-09-26 14:13:53 --> Language Class Initialized
INFO - 2023-09-26 14:13:53 --> Config Class Initialized
INFO - 2023-09-26 14:13:53 --> Loader Class Initialized
INFO - 2023-09-26 14:13:53 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:53 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:53 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:53 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:53 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:53 --> Controller Class Initialized
INFO - 2023-09-26 14:13:53 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:53 --> Total execution time: 0.0403
INFO - 2023-09-26 14:13:55 --> Config Class Initialized
INFO - 2023-09-26 14:13:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:55 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:55 --> URI Class Initialized
INFO - 2023-09-26 14:13:55 --> Router Class Initialized
INFO - 2023-09-26 14:13:55 --> Output Class Initialized
INFO - 2023-09-26 14:13:55 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:55 --> Input Class Initialized
INFO - 2023-09-26 14:13:55 --> Language Class Initialized
INFO - 2023-09-26 14:13:55 --> Language Class Initialized
INFO - 2023-09-26 14:13:55 --> Config Class Initialized
INFO - 2023-09-26 14:13:55 --> Loader Class Initialized
INFO - 2023-09-26 14:13:55 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:55 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:55 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:55 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:55 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:55 --> Controller Class Initialized
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:13:55 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:13:55 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:13:58 --> Config Class Initialized
INFO - 2023-09-26 14:13:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:58 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:58 --> URI Class Initialized
INFO - 2023-09-26 14:13:58 --> Router Class Initialized
INFO - 2023-09-26 14:13:58 --> Output Class Initialized
INFO - 2023-09-26 14:13:58 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:58 --> Input Class Initialized
INFO - 2023-09-26 14:13:58 --> Language Class Initialized
INFO - 2023-09-26 14:13:58 --> Language Class Initialized
INFO - 2023-09-26 14:13:58 --> Config Class Initialized
INFO - 2023-09-26 14:13:58 --> Loader Class Initialized
INFO - 2023-09-26 14:13:58 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:58 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:58 --> Controller Class Initialized
DEBUG - 2023-09-26 14:13:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:13:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:13:58 --> Final output sent to browser
DEBUG - 2023-09-26 14:13:58 --> Total execution time: 0.0419
INFO - 2023-09-26 14:13:58 --> Config Class Initialized
INFO - 2023-09-26 14:13:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:13:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:13:58 --> Utf8 Class Initialized
INFO - 2023-09-26 14:13:58 --> URI Class Initialized
INFO - 2023-09-26 14:13:58 --> Router Class Initialized
INFO - 2023-09-26 14:13:58 --> Output Class Initialized
INFO - 2023-09-26 14:13:58 --> Security Class Initialized
DEBUG - 2023-09-26 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:13:58 --> Input Class Initialized
INFO - 2023-09-26 14:13:58 --> Language Class Initialized
INFO - 2023-09-26 14:13:58 --> Language Class Initialized
INFO - 2023-09-26 14:13:58 --> Config Class Initialized
INFO - 2023-09-26 14:13:58 --> Loader Class Initialized
INFO - 2023-09-26 14:13:58 --> Helper loaded: url_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: file_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: form_helper
INFO - 2023-09-26 14:13:58 --> Helper loaded: my_helper
INFO - 2023-09-26 14:13:58 --> Database Driver Class Initialized
INFO - 2023-09-26 14:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:13:58 --> Controller Class Initialized
INFO - 2023-09-26 14:14:00 --> Config Class Initialized
INFO - 2023-09-26 14:14:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:00 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:00 --> URI Class Initialized
INFO - 2023-09-26 14:14:00 --> Router Class Initialized
INFO - 2023-09-26 14:14:00 --> Output Class Initialized
INFO - 2023-09-26 14:14:00 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:00 --> Input Class Initialized
INFO - 2023-09-26 14:14:00 --> Language Class Initialized
INFO - 2023-09-26 14:14:00 --> Language Class Initialized
INFO - 2023-09-26 14:14:00 --> Config Class Initialized
INFO - 2023-09-26 14:14:00 --> Loader Class Initialized
INFO - 2023-09-26 14:14:00 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:00 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:00 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:00 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:00 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:00 --> Controller Class Initialized
INFO - 2023-09-26 14:14:00 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:00 --> Total execution time: 0.0545
INFO - 2023-09-26 14:14:01 --> Config Class Initialized
INFO - 2023-09-26 14:14:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:01 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:01 --> URI Class Initialized
INFO - 2023-09-26 14:14:01 --> Router Class Initialized
INFO - 2023-09-26 14:14:01 --> Output Class Initialized
INFO - 2023-09-26 14:14:01 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:01 --> Input Class Initialized
INFO - 2023-09-26 14:14:01 --> Language Class Initialized
INFO - 2023-09-26 14:14:01 --> Language Class Initialized
INFO - 2023-09-26 14:14:01 --> Config Class Initialized
INFO - 2023-09-26 14:14:01 --> Loader Class Initialized
INFO - 2023-09-26 14:14:01 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:01 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:01 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:01 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:01 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:02 --> Controller Class Initialized
INFO - 2023-09-26 14:14:02 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:02 --> Total execution time: 0.2419
INFO - 2023-09-26 14:14:02 --> Config Class Initialized
INFO - 2023-09-26 14:14:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:02 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:02 --> URI Class Initialized
INFO - 2023-09-26 14:14:02 --> Router Class Initialized
INFO - 2023-09-26 14:14:02 --> Output Class Initialized
INFO - 2023-09-26 14:14:02 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:02 --> Input Class Initialized
INFO - 2023-09-26 14:14:02 --> Language Class Initialized
INFO - 2023-09-26 14:14:03 --> Language Class Initialized
INFO - 2023-09-26 14:14:03 --> Config Class Initialized
INFO - 2023-09-26 14:14:03 --> Loader Class Initialized
INFO - 2023-09-26 14:14:03 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:03 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:03 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:03 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:03 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:03 --> Controller Class Initialized
INFO - 2023-09-26 14:14:03 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:03 --> Total execution time: 0.1463
INFO - 2023-09-26 14:14:04 --> Config Class Initialized
INFO - 2023-09-26 14:14:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:04 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:04 --> URI Class Initialized
INFO - 2023-09-26 14:14:04 --> Router Class Initialized
INFO - 2023-09-26 14:14:04 --> Output Class Initialized
INFO - 2023-09-26 14:14:04 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:04 --> Input Class Initialized
INFO - 2023-09-26 14:14:04 --> Language Class Initialized
INFO - 2023-09-26 14:14:04 --> Language Class Initialized
INFO - 2023-09-26 14:14:04 --> Config Class Initialized
INFO - 2023-09-26 14:14:04 --> Loader Class Initialized
INFO - 2023-09-26 14:14:04 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:04 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:04 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:04 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:04 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:04 --> Controller Class Initialized
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2023-09-26 14:14:04 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 202
ERROR - 2023-09-26 14:14:04 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 203
DEBUG - 2023-09-26 14:14:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2023-09-26 14:14:04 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:04 --> Total execution time: 0.0754
INFO - 2023-09-26 14:14:18 --> Config Class Initialized
INFO - 2023-09-26 14:14:18 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:18 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:18 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:18 --> URI Class Initialized
INFO - 2023-09-26 14:14:18 --> Router Class Initialized
INFO - 2023-09-26 14:14:18 --> Output Class Initialized
INFO - 2023-09-26 14:14:18 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:18 --> Input Class Initialized
INFO - 2023-09-26 14:14:18 --> Language Class Initialized
INFO - 2023-09-26 14:14:18 --> Language Class Initialized
INFO - 2023-09-26 14:14:18 --> Config Class Initialized
INFO - 2023-09-26 14:14:18 --> Loader Class Initialized
INFO - 2023-09-26 14:14:18 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:18 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:18 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:18 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:18 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:18 --> Controller Class Initialized
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:14:18 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:14:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:14:23 --> Config Class Initialized
INFO - 2023-09-26 14:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:23 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:23 --> URI Class Initialized
INFO - 2023-09-26 14:14:23 --> Router Class Initialized
INFO - 2023-09-26 14:14:23 --> Output Class Initialized
INFO - 2023-09-26 14:14:23 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:23 --> Input Class Initialized
INFO - 2023-09-26 14:14:23 --> Language Class Initialized
INFO - 2023-09-26 14:14:23 --> Language Class Initialized
INFO - 2023-09-26 14:14:23 --> Config Class Initialized
INFO - 2023-09-26 14:14:23 --> Loader Class Initialized
INFO - 2023-09-26 14:14:23 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:23 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:23 --> Controller Class Initialized
DEBUG - 2023-09-26 14:14:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:14:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:14:23 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:23 --> Total execution time: 0.0445
INFO - 2023-09-26 14:14:23 --> Config Class Initialized
INFO - 2023-09-26 14:14:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:23 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:23 --> URI Class Initialized
INFO - 2023-09-26 14:14:23 --> Router Class Initialized
INFO - 2023-09-26 14:14:23 --> Output Class Initialized
INFO - 2023-09-26 14:14:23 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:23 --> Input Class Initialized
INFO - 2023-09-26 14:14:23 --> Language Class Initialized
INFO - 2023-09-26 14:14:23 --> Language Class Initialized
INFO - 2023-09-26 14:14:23 --> Config Class Initialized
INFO - 2023-09-26 14:14:23 --> Loader Class Initialized
INFO - 2023-09-26 14:14:23 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:23 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:23 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:23 --> Controller Class Initialized
INFO - 2023-09-26 14:14:27 --> Config Class Initialized
INFO - 2023-09-26 14:14:27 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:27 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:27 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:27 --> URI Class Initialized
INFO - 2023-09-26 14:14:27 --> Router Class Initialized
INFO - 2023-09-26 14:14:27 --> Output Class Initialized
INFO - 2023-09-26 14:14:27 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:27 --> Input Class Initialized
INFO - 2023-09-26 14:14:27 --> Language Class Initialized
INFO - 2023-09-26 14:14:27 --> Language Class Initialized
INFO - 2023-09-26 14:14:27 --> Config Class Initialized
INFO - 2023-09-26 14:14:27 --> Loader Class Initialized
INFO - 2023-09-26 14:14:27 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:27 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:27 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:27 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:27 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:27 --> Controller Class Initialized
INFO - 2023-09-26 14:14:27 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:27 --> Total execution time: 0.0399
INFO - 2023-09-26 14:14:29 --> Config Class Initialized
INFO - 2023-09-26 14:14:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:29 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:29 --> URI Class Initialized
INFO - 2023-09-26 14:14:29 --> Router Class Initialized
INFO - 2023-09-26 14:14:29 --> Output Class Initialized
INFO - 2023-09-26 14:14:29 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:29 --> Input Class Initialized
INFO - 2023-09-26 14:14:29 --> Language Class Initialized
INFO - 2023-09-26 14:14:29 --> Language Class Initialized
INFO - 2023-09-26 14:14:29 --> Config Class Initialized
INFO - 2023-09-26 14:14:29 --> Loader Class Initialized
INFO - 2023-09-26 14:14:29 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:29 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:29 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:29 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:29 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:29 --> Controller Class Initialized
INFO - 2023-09-26 14:14:29 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:29 --> Total execution time: 0.0396
INFO - 2023-09-26 14:14:51 --> Config Class Initialized
INFO - 2023-09-26 14:14:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:14:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:14:51 --> Utf8 Class Initialized
INFO - 2023-09-26 14:14:51 --> URI Class Initialized
INFO - 2023-09-26 14:14:51 --> Router Class Initialized
INFO - 2023-09-26 14:14:51 --> Output Class Initialized
INFO - 2023-09-26 14:14:51 --> Security Class Initialized
DEBUG - 2023-09-26 14:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:14:51 --> Input Class Initialized
INFO - 2023-09-26 14:14:51 --> Language Class Initialized
INFO - 2023-09-26 14:14:51 --> Language Class Initialized
INFO - 2023-09-26 14:14:51 --> Config Class Initialized
INFO - 2023-09-26 14:14:51 --> Loader Class Initialized
INFO - 2023-09-26 14:14:51 --> Helper loaded: url_helper
INFO - 2023-09-26 14:14:51 --> Helper loaded: file_helper
INFO - 2023-09-26 14:14:51 --> Helper loaded: form_helper
INFO - 2023-09-26 14:14:51 --> Helper loaded: my_helper
INFO - 2023-09-26 14:14:51 --> Database Driver Class Initialized
INFO - 2023-09-26 14:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:14:51 --> Controller Class Initialized
INFO - 2023-09-26 14:14:51 --> Final output sent to browser
DEBUG - 2023-09-26 14:14:51 --> Total execution time: 0.0381
INFO - 2023-09-26 14:31:59 --> Config Class Initialized
INFO - 2023-09-26 14:31:59 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:31:59 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:31:59 --> Utf8 Class Initialized
INFO - 2023-09-26 14:31:59 --> URI Class Initialized
INFO - 2023-09-26 14:31:59 --> Router Class Initialized
INFO - 2023-09-26 14:31:59 --> Output Class Initialized
INFO - 2023-09-26 14:31:59 --> Security Class Initialized
DEBUG - 2023-09-26 14:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:31:59 --> Input Class Initialized
INFO - 2023-09-26 14:31:59 --> Language Class Initialized
INFO - 2023-09-26 14:31:59 --> Language Class Initialized
INFO - 2023-09-26 14:31:59 --> Config Class Initialized
INFO - 2023-09-26 14:31:59 --> Loader Class Initialized
INFO - 2023-09-26 14:31:59 --> Helper loaded: url_helper
INFO - 2023-09-26 14:31:59 --> Helper loaded: file_helper
INFO - 2023-09-26 14:31:59 --> Helper loaded: form_helper
INFO - 2023-09-26 14:31:59 --> Helper loaded: my_helper
INFO - 2023-09-26 14:31:59 --> Database Driver Class Initialized
INFO - 2023-09-26 14:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:31:59 --> Controller Class Initialized
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:31:59 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:31:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:32:16 --> Config Class Initialized
INFO - 2023-09-26 14:32:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:16 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:16 --> URI Class Initialized
INFO - 2023-09-26 14:32:16 --> Router Class Initialized
INFO - 2023-09-26 14:32:16 --> Output Class Initialized
INFO - 2023-09-26 14:32:16 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:16 --> Input Class Initialized
INFO - 2023-09-26 14:32:16 --> Language Class Initialized
INFO - 2023-09-26 14:32:16 --> Language Class Initialized
INFO - 2023-09-26 14:32:16 --> Config Class Initialized
INFO - 2023-09-26 14:32:16 --> Loader Class Initialized
INFO - 2023-09-26 14:32:16 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:16 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:16 --> Controller Class Initialized
DEBUG - 2023-09-26 14:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:32:16 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:16 --> Total execution time: 0.1268
INFO - 2023-09-26 14:32:16 --> Config Class Initialized
INFO - 2023-09-26 14:32:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:16 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:16 --> URI Class Initialized
INFO - 2023-09-26 14:32:16 --> Router Class Initialized
INFO - 2023-09-26 14:32:16 --> Output Class Initialized
INFO - 2023-09-26 14:32:16 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:16 --> Input Class Initialized
INFO - 2023-09-26 14:32:16 --> Language Class Initialized
INFO - 2023-09-26 14:32:16 --> Language Class Initialized
INFO - 2023-09-26 14:32:16 --> Config Class Initialized
INFO - 2023-09-26 14:32:16 --> Loader Class Initialized
INFO - 2023-09-26 14:32:16 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:16 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:16 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:16 --> Controller Class Initialized
INFO - 2023-09-26 14:32:19 --> Config Class Initialized
INFO - 2023-09-26 14:32:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:19 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:19 --> URI Class Initialized
INFO - 2023-09-26 14:32:19 --> Router Class Initialized
INFO - 2023-09-26 14:32:19 --> Output Class Initialized
INFO - 2023-09-26 14:32:19 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:19 --> Input Class Initialized
INFO - 2023-09-26 14:32:19 --> Language Class Initialized
INFO - 2023-09-26 14:32:19 --> Language Class Initialized
INFO - 2023-09-26 14:32:19 --> Config Class Initialized
INFO - 2023-09-26 14:32:19 --> Loader Class Initialized
INFO - 2023-09-26 14:32:19 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:19 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:19 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:19 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:19 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:19 --> Controller Class Initialized
INFO - 2023-09-26 14:32:19 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:19 --> Total execution time: 0.2155
INFO - 2023-09-26 14:32:22 --> Config Class Initialized
INFO - 2023-09-26 14:32:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:22 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:22 --> URI Class Initialized
INFO - 2023-09-26 14:32:22 --> Router Class Initialized
INFO - 2023-09-26 14:32:22 --> Output Class Initialized
INFO - 2023-09-26 14:32:22 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:22 --> Input Class Initialized
INFO - 2023-09-26 14:32:22 --> Language Class Initialized
INFO - 2023-09-26 14:32:22 --> Language Class Initialized
INFO - 2023-09-26 14:32:22 --> Config Class Initialized
INFO - 2023-09-26 14:32:22 --> Loader Class Initialized
INFO - 2023-09-26 14:32:22 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:22 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:22 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:22 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:22 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:22 --> Controller Class Initialized
INFO - 2023-09-26 14:32:22 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:22 --> Total execution time: 0.0715
INFO - 2023-09-26 14:32:27 --> Config Class Initialized
INFO - 2023-09-26 14:32:27 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:27 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:27 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:27 --> URI Class Initialized
INFO - 2023-09-26 14:32:27 --> Router Class Initialized
INFO - 2023-09-26 14:32:27 --> Output Class Initialized
INFO - 2023-09-26 14:32:27 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:27 --> Input Class Initialized
INFO - 2023-09-26 14:32:27 --> Language Class Initialized
INFO - 2023-09-26 14:32:27 --> Language Class Initialized
INFO - 2023-09-26 14:32:27 --> Config Class Initialized
INFO - 2023-09-26 14:32:27 --> Loader Class Initialized
INFO - 2023-09-26 14:32:27 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:27 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:27 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:27 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:27 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:27 --> Controller Class Initialized
INFO - 2023-09-26 14:32:27 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:27 --> Total execution time: 0.1629
INFO - 2023-09-26 14:32:30 --> Config Class Initialized
INFO - 2023-09-26 14:32:30 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:30 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:30 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:30 --> URI Class Initialized
INFO - 2023-09-26 14:32:30 --> Router Class Initialized
INFO - 2023-09-26 14:32:30 --> Output Class Initialized
INFO - 2023-09-26 14:32:30 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:30 --> Input Class Initialized
INFO - 2023-09-26 14:32:30 --> Language Class Initialized
INFO - 2023-09-26 14:32:30 --> Language Class Initialized
INFO - 2023-09-26 14:32:30 --> Config Class Initialized
INFO - 2023-09-26 14:32:30 --> Loader Class Initialized
INFO - 2023-09-26 14:32:30 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:30 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:30 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:30 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:30 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:30 --> Controller Class Initialized
DEBUG - 2023-09-26 14:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 14:32:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:32:30 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:30 --> Total execution time: 0.1611
INFO - 2023-09-26 14:32:33 --> Config Class Initialized
INFO - 2023-09-26 14:32:33 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:33 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:33 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:33 --> URI Class Initialized
INFO - 2023-09-26 14:32:33 --> Router Class Initialized
INFO - 2023-09-26 14:32:33 --> Output Class Initialized
INFO - 2023-09-26 14:32:33 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:33 --> Input Class Initialized
INFO - 2023-09-26 14:32:33 --> Language Class Initialized
INFO - 2023-09-26 14:32:33 --> Language Class Initialized
INFO - 2023-09-26 14:32:33 --> Config Class Initialized
INFO - 2023-09-26 14:32:33 --> Loader Class Initialized
INFO - 2023-09-26 14:32:33 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:33 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:33 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:33 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:33 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:33 --> Controller Class Initialized
INFO - 2023-09-26 14:32:34 --> Helper loaded: cookie_helper
INFO - 2023-09-26 14:32:34 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:34 --> Total execution time: 1.0152
INFO - 2023-09-26 14:32:34 --> Config Class Initialized
INFO - 2023-09-26 14:32:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:34 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:34 --> URI Class Initialized
INFO - 2023-09-26 14:32:34 --> Router Class Initialized
INFO - 2023-09-26 14:32:34 --> Output Class Initialized
INFO - 2023-09-26 14:32:34 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:34 --> Input Class Initialized
INFO - 2023-09-26 14:32:34 --> Language Class Initialized
INFO - 2023-09-26 14:32:34 --> Language Class Initialized
INFO - 2023-09-26 14:32:34 --> Config Class Initialized
INFO - 2023-09-26 14:32:34 --> Loader Class Initialized
INFO - 2023-09-26 14:32:34 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:34 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:34 --> Config Class Initialized
INFO - 2023-09-26 14:32:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:34 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:34 --> Controller Class Initialized
INFO - 2023-09-26 14:32:34 --> URI Class Initialized
INFO - 2023-09-26 14:32:34 --> Router Class Initialized
INFO - 2023-09-26 14:32:34 --> Output Class Initialized
INFO - 2023-09-26 14:32:34 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:34 --> Input Class Initialized
INFO - 2023-09-26 14:32:34 --> Language Class Initialized
INFO - 2023-09-26 14:32:34 --> Language Class Initialized
INFO - 2023-09-26 14:32:34 --> Config Class Initialized
INFO - 2023-09-26 14:32:34 --> Loader Class Initialized
INFO - 2023-09-26 14:32:34 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:34 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:34 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:34 --> Controller Class Initialized
INFO - 2023-09-26 14:32:34 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:34 --> Total execution time: 0.1068
DEBUG - 2023-09-26 14:32:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-26 14:32:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:32:34 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:34 --> Total execution time: 0.3457
INFO - 2023-09-26 14:32:37 --> Config Class Initialized
INFO - 2023-09-26 14:32:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:37 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:37 --> URI Class Initialized
INFO - 2023-09-26 14:32:37 --> Router Class Initialized
INFO - 2023-09-26 14:32:37 --> Output Class Initialized
INFO - 2023-09-26 14:32:37 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:37 --> Input Class Initialized
INFO - 2023-09-26 14:32:37 --> Language Class Initialized
INFO - 2023-09-26 14:32:37 --> Language Class Initialized
INFO - 2023-09-26 14:32:37 --> Config Class Initialized
INFO - 2023-09-26 14:32:37 --> Loader Class Initialized
INFO - 2023-09-26 14:32:37 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:37 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:37 --> Controller Class Initialized
INFO - 2023-09-26 14:32:37 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:37 --> Total execution time: 0.1943
INFO - 2023-09-26 14:32:37 --> Config Class Initialized
INFO - 2023-09-26 14:32:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:37 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:37 --> URI Class Initialized
INFO - 2023-09-26 14:32:37 --> Router Class Initialized
INFO - 2023-09-26 14:32:37 --> Output Class Initialized
INFO - 2023-09-26 14:32:37 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:37 --> Input Class Initialized
INFO - 2023-09-26 14:32:37 --> Language Class Initialized
INFO - 2023-09-26 14:32:37 --> Language Class Initialized
INFO - 2023-09-26 14:32:37 --> Config Class Initialized
INFO - 2023-09-26 14:32:37 --> Loader Class Initialized
INFO - 2023-09-26 14:32:37 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:37 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:37 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:37 --> Controller Class Initialized
DEBUG - 2023-09-26 14:32:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-26 14:32:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:32:37 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:37 --> Total execution time: 0.3001
INFO - 2023-09-26 14:32:37 --> Config Class Initialized
INFO - 2023-09-26 14:32:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:37 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:37 --> URI Class Initialized
INFO - 2023-09-26 14:32:38 --> Router Class Initialized
INFO - 2023-09-26 14:32:38 --> Output Class Initialized
INFO - 2023-09-26 14:32:38 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:38 --> Input Class Initialized
INFO - 2023-09-26 14:32:38 --> Language Class Initialized
ERROR - 2023-09-26 14:32:38 --> 404 Page Not Found: /index
INFO - 2023-09-26 14:32:38 --> Config Class Initialized
INFO - 2023-09-26 14:32:38 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:38 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:38 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:38 --> URI Class Initialized
INFO - 2023-09-26 14:32:38 --> Router Class Initialized
INFO - 2023-09-26 14:32:38 --> Output Class Initialized
INFO - 2023-09-26 14:32:38 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:38 --> Input Class Initialized
INFO - 2023-09-26 14:32:38 --> Language Class Initialized
INFO - 2023-09-26 14:32:38 --> Language Class Initialized
INFO - 2023-09-26 14:32:38 --> Config Class Initialized
INFO - 2023-09-26 14:32:38 --> Loader Class Initialized
INFO - 2023-09-26 14:32:38 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:38 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:38 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:38 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:38 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:38 --> Controller Class Initialized
INFO - 2023-09-26 14:32:49 --> Config Class Initialized
INFO - 2023-09-26 14:32:49 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:49 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:49 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:49 --> URI Class Initialized
INFO - 2023-09-26 14:32:49 --> Router Class Initialized
INFO - 2023-09-26 14:32:49 --> Output Class Initialized
INFO - 2023-09-26 14:32:49 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:49 --> Input Class Initialized
INFO - 2023-09-26 14:32:49 --> Language Class Initialized
INFO - 2023-09-26 14:32:49 --> Language Class Initialized
INFO - 2023-09-26 14:32:49 --> Config Class Initialized
INFO - 2023-09-26 14:32:49 --> Loader Class Initialized
INFO - 2023-09-26 14:32:49 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:49 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:49 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:49 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:49 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:49 --> Controller Class Initialized
INFO - 2023-09-26 14:32:49 --> Final output sent to browser
DEBUG - 2023-09-26 14:32:49 --> Total execution time: 0.0652
INFO - 2023-09-26 14:32:50 --> Config Class Initialized
INFO - 2023-09-26 14:32:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:32:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:32:50 --> Utf8 Class Initialized
INFO - 2023-09-26 14:32:50 --> URI Class Initialized
INFO - 2023-09-26 14:32:50 --> Router Class Initialized
INFO - 2023-09-26 14:32:50 --> Output Class Initialized
INFO - 2023-09-26 14:32:50 --> Security Class Initialized
DEBUG - 2023-09-26 14:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:32:50 --> Input Class Initialized
INFO - 2023-09-26 14:32:50 --> Language Class Initialized
INFO - 2023-09-26 14:32:50 --> Language Class Initialized
INFO - 2023-09-26 14:32:50 --> Config Class Initialized
INFO - 2023-09-26 14:32:50 --> Loader Class Initialized
INFO - 2023-09-26 14:32:50 --> Helper loaded: url_helper
INFO - 2023-09-26 14:32:50 --> Helper loaded: file_helper
INFO - 2023-09-26 14:32:50 --> Helper loaded: form_helper
INFO - 2023-09-26 14:32:50 --> Helper loaded: my_helper
INFO - 2023-09-26 14:32:50 --> Database Driver Class Initialized
INFO - 2023-09-26 14:32:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:32:50 --> Controller Class Initialized
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:32:51 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:32:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:33:08 --> Config Class Initialized
INFO - 2023-09-26 14:33:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:33:08 --> Utf8 Class Initialized
INFO - 2023-09-26 14:33:08 --> URI Class Initialized
INFO - 2023-09-26 14:33:08 --> Router Class Initialized
INFO - 2023-09-26 14:33:08 --> Output Class Initialized
INFO - 2023-09-26 14:33:08 --> Security Class Initialized
DEBUG - 2023-09-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:33:08 --> Input Class Initialized
INFO - 2023-09-26 14:33:08 --> Language Class Initialized
INFO - 2023-09-26 14:33:08 --> Language Class Initialized
INFO - 2023-09-26 14:33:08 --> Config Class Initialized
INFO - 2023-09-26 14:33:08 --> Loader Class Initialized
INFO - 2023-09-26 14:33:08 --> Helper loaded: url_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: file_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: form_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: my_helper
INFO - 2023-09-26 14:33:08 --> Database Driver Class Initialized
INFO - 2023-09-26 14:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:33:08 --> Controller Class Initialized
INFO - 2023-09-26 14:33:08 --> Final output sent to browser
DEBUG - 2023-09-26 14:33:08 --> Total execution time: 0.0451
INFO - 2023-09-26 14:33:08 --> Config Class Initialized
INFO - 2023-09-26 14:33:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:33:08 --> Utf8 Class Initialized
INFO - 2023-09-26 14:33:08 --> URI Class Initialized
INFO - 2023-09-26 14:33:08 --> Router Class Initialized
INFO - 2023-09-26 14:33:08 --> Output Class Initialized
INFO - 2023-09-26 14:33:08 --> Security Class Initialized
DEBUG - 2023-09-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:33:08 --> Input Class Initialized
INFO - 2023-09-26 14:33:08 --> Language Class Initialized
ERROR - 2023-09-26 14:33:08 --> 404 Page Not Found: /index
INFO - 2023-09-26 14:33:08 --> Config Class Initialized
INFO - 2023-09-26 14:33:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:33:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:33:08 --> Utf8 Class Initialized
INFO - 2023-09-26 14:33:08 --> URI Class Initialized
INFO - 2023-09-26 14:33:08 --> Router Class Initialized
INFO - 2023-09-26 14:33:08 --> Output Class Initialized
INFO - 2023-09-26 14:33:08 --> Security Class Initialized
DEBUG - 2023-09-26 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:33:08 --> Input Class Initialized
INFO - 2023-09-26 14:33:08 --> Language Class Initialized
INFO - 2023-09-26 14:33:08 --> Language Class Initialized
INFO - 2023-09-26 14:33:08 --> Config Class Initialized
INFO - 2023-09-26 14:33:08 --> Loader Class Initialized
INFO - 2023-09-26 14:33:08 --> Helper loaded: url_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: file_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: form_helper
INFO - 2023-09-26 14:33:08 --> Helper loaded: my_helper
INFO - 2023-09-26 14:33:08 --> Database Driver Class Initialized
INFO - 2023-09-26 14:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:33:09 --> Controller Class Initialized
INFO - 2023-09-26 14:53:56 --> Config Class Initialized
INFO - 2023-09-26 14:53:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:53:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:53:56 --> Utf8 Class Initialized
INFO - 2023-09-26 14:53:56 --> URI Class Initialized
DEBUG - 2023-09-26 14:53:56 --> No URI present. Default controller set.
INFO - 2023-09-26 14:53:56 --> Router Class Initialized
INFO - 2023-09-26 14:53:56 --> Output Class Initialized
INFO - 2023-09-26 14:53:56 --> Security Class Initialized
DEBUG - 2023-09-26 14:53:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:53:56 --> Input Class Initialized
INFO - 2023-09-26 14:53:56 --> Language Class Initialized
INFO - 2023-09-26 14:53:56 --> Language Class Initialized
INFO - 2023-09-26 14:53:56 --> Config Class Initialized
INFO - 2023-09-26 14:53:56 --> Loader Class Initialized
INFO - 2023-09-26 14:53:56 --> Helper loaded: url_helper
INFO - 2023-09-26 14:53:56 --> Helper loaded: file_helper
INFO - 2023-09-26 14:53:56 --> Helper loaded: form_helper
INFO - 2023-09-26 14:53:56 --> Helper loaded: my_helper
INFO - 2023-09-26 14:53:56 --> Database Driver Class Initialized
INFO - 2023-09-26 14:53:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:53:56 --> Controller Class Initialized
INFO - 2023-09-26 14:53:57 --> Config Class Initialized
INFO - 2023-09-26 14:53:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:53:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:53:57 --> Utf8 Class Initialized
INFO - 2023-09-26 14:53:57 --> URI Class Initialized
INFO - 2023-09-26 14:53:57 --> Router Class Initialized
INFO - 2023-09-26 14:53:57 --> Output Class Initialized
INFO - 2023-09-26 14:53:57 --> Security Class Initialized
DEBUG - 2023-09-26 14:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:53:57 --> Input Class Initialized
INFO - 2023-09-26 14:53:57 --> Language Class Initialized
INFO - 2023-09-26 14:53:57 --> Language Class Initialized
INFO - 2023-09-26 14:53:57 --> Config Class Initialized
INFO - 2023-09-26 14:53:57 --> Loader Class Initialized
INFO - 2023-09-26 14:53:57 --> Helper loaded: url_helper
INFO - 2023-09-26 14:53:57 --> Helper loaded: file_helper
INFO - 2023-09-26 14:53:57 --> Helper loaded: form_helper
INFO - 2023-09-26 14:53:57 --> Helper loaded: my_helper
INFO - 2023-09-26 14:53:57 --> Database Driver Class Initialized
INFO - 2023-09-26 14:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:53:57 --> Controller Class Initialized
DEBUG - 2023-09-26 14:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 14:53:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:53:57 --> Final output sent to browser
DEBUG - 2023-09-26 14:53:57 --> Total execution time: 0.1484
INFO - 2023-09-26 14:54:00 --> Config Class Initialized
INFO - 2023-09-26 14:54:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:00 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:00 --> URI Class Initialized
INFO - 2023-09-26 14:54:00 --> Router Class Initialized
INFO - 2023-09-26 14:54:00 --> Output Class Initialized
INFO - 2023-09-26 14:54:00 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:00 --> Input Class Initialized
INFO - 2023-09-26 14:54:00 --> Language Class Initialized
INFO - 2023-09-26 14:54:00 --> Language Class Initialized
INFO - 2023-09-26 14:54:00 --> Config Class Initialized
INFO - 2023-09-26 14:54:00 --> Loader Class Initialized
INFO - 2023-09-26 14:54:00 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:00 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:00 --> Controller Class Initialized
INFO - 2023-09-26 14:54:00 --> Helper loaded: cookie_helper
INFO - 2023-09-26 14:54:00 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:00 --> Total execution time: 0.0920
INFO - 2023-09-26 14:54:00 --> Config Class Initialized
INFO - 2023-09-26 14:54:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:00 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:00 --> URI Class Initialized
INFO - 2023-09-26 14:54:00 --> Router Class Initialized
INFO - 2023-09-26 14:54:00 --> Output Class Initialized
INFO - 2023-09-26 14:54:00 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:00 --> Input Class Initialized
INFO - 2023-09-26 14:54:00 --> Language Class Initialized
INFO - 2023-09-26 14:54:00 --> Language Class Initialized
INFO - 2023-09-26 14:54:00 --> Config Class Initialized
INFO - 2023-09-26 14:54:00 --> Loader Class Initialized
INFO - 2023-09-26 14:54:00 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:00 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:00 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:00 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 14:54:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:00 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:00 --> Total execution time: 0.0952
INFO - 2023-09-26 14:54:02 --> Config Class Initialized
INFO - 2023-09-26 14:54:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:02 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:02 --> URI Class Initialized
INFO - 2023-09-26 14:54:02 --> Router Class Initialized
INFO - 2023-09-26 14:54:02 --> Output Class Initialized
INFO - 2023-09-26 14:54:02 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:02 --> Input Class Initialized
INFO - 2023-09-26 14:54:02 --> Language Class Initialized
INFO - 2023-09-26 14:54:02 --> Language Class Initialized
INFO - 2023-09-26 14:54:02 --> Config Class Initialized
INFO - 2023-09-26 14:54:02 --> Loader Class Initialized
INFO - 2023-09-26 14:54:02 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:02 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:02 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:02 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:02 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:02 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:54:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:02 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:02 --> Total execution time: 0.2350
INFO - 2023-09-26 14:54:03 --> Config Class Initialized
INFO - 2023-09-26 14:54:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:03 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:03 --> URI Class Initialized
INFO - 2023-09-26 14:54:03 --> Router Class Initialized
INFO - 2023-09-26 14:54:03 --> Output Class Initialized
INFO - 2023-09-26 14:54:03 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:03 --> Input Class Initialized
INFO - 2023-09-26 14:54:03 --> Language Class Initialized
INFO - 2023-09-26 14:54:03 --> Language Class Initialized
INFO - 2023-09-26 14:54:03 --> Config Class Initialized
INFO - 2023-09-26 14:54:03 --> Loader Class Initialized
INFO - 2023-09-26 14:54:03 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:03 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:03 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:03 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:03 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:04 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:54:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:04 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:04 --> Total execution time: 0.1534
INFO - 2023-09-26 14:54:04 --> Config Class Initialized
INFO - 2023-09-26 14:54:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:04 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:04 --> URI Class Initialized
INFO - 2023-09-26 14:54:04 --> Router Class Initialized
INFO - 2023-09-26 14:54:04 --> Output Class Initialized
INFO - 2023-09-26 14:54:04 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:04 --> Input Class Initialized
INFO - 2023-09-26 14:54:04 --> Language Class Initialized
INFO - 2023-09-26 14:54:04 --> Language Class Initialized
INFO - 2023-09-26 14:54:04 --> Config Class Initialized
INFO - 2023-09-26 14:54:04 --> Loader Class Initialized
INFO - 2023-09-26 14:54:04 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:04 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:04 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:04 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:04 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:04 --> Controller Class Initialized
INFO - 2023-09-26 14:54:06 --> Config Class Initialized
INFO - 2023-09-26 14:54:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:06 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:06 --> URI Class Initialized
INFO - 2023-09-26 14:54:06 --> Router Class Initialized
INFO - 2023-09-26 14:54:06 --> Output Class Initialized
INFO - 2023-09-26 14:54:06 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:06 --> Input Class Initialized
INFO - 2023-09-26 14:54:06 --> Language Class Initialized
INFO - 2023-09-26 14:54:06 --> Language Class Initialized
INFO - 2023-09-26 14:54:06 --> Config Class Initialized
INFO - 2023-09-26 14:54:06 --> Loader Class Initialized
INFO - 2023-09-26 14:54:06 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:06 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:06 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:06 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:06 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:07 --> Controller Class Initialized
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:08 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:54:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:54:15 --> Config Class Initialized
INFO - 2023-09-26 14:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:15 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:15 --> URI Class Initialized
INFO - 2023-09-26 14:54:15 --> Router Class Initialized
INFO - 2023-09-26 14:54:15 --> Output Class Initialized
INFO - 2023-09-26 14:54:15 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:15 --> Input Class Initialized
INFO - 2023-09-26 14:54:15 --> Language Class Initialized
INFO - 2023-09-26 14:54:15 --> Language Class Initialized
INFO - 2023-09-26 14:54:15 --> Config Class Initialized
INFO - 2023-09-26 14:54:15 --> Loader Class Initialized
INFO - 2023-09-26 14:54:15 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:15 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:15 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:54:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:15 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:15 --> Total execution time: 0.3616
INFO - 2023-09-26 14:54:15 --> Config Class Initialized
INFO - 2023-09-26 14:54:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:15 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:15 --> URI Class Initialized
INFO - 2023-09-26 14:54:15 --> Router Class Initialized
INFO - 2023-09-26 14:54:15 --> Output Class Initialized
INFO - 2023-09-26 14:54:15 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:15 --> Input Class Initialized
INFO - 2023-09-26 14:54:15 --> Language Class Initialized
INFO - 2023-09-26 14:54:15 --> Language Class Initialized
INFO - 2023-09-26 14:54:15 --> Config Class Initialized
INFO - 2023-09-26 14:54:15 --> Loader Class Initialized
INFO - 2023-09-26 14:54:15 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:15 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:15 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:15 --> Controller Class Initialized
INFO - 2023-09-26 14:54:16 --> Config Class Initialized
INFO - 2023-09-26 14:54:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:16 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:16 --> URI Class Initialized
INFO - 2023-09-26 14:54:16 --> Router Class Initialized
INFO - 2023-09-26 14:54:16 --> Output Class Initialized
INFO - 2023-09-26 14:54:16 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:16 --> Input Class Initialized
INFO - 2023-09-26 14:54:16 --> Language Class Initialized
INFO - 2023-09-26 14:54:16 --> Language Class Initialized
INFO - 2023-09-26 14:54:16 --> Config Class Initialized
INFO - 2023-09-26 14:54:16 --> Loader Class Initialized
INFO - 2023-09-26 14:54:16 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:16 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:16 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:16 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:16 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:16 --> Controller Class Initialized
INFO - 2023-09-26 14:54:17 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:17 --> Total execution time: 0.3346
INFO - 2023-09-26 14:54:18 --> Config Class Initialized
INFO - 2023-09-26 14:54:18 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:18 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:18 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:18 --> URI Class Initialized
INFO - 2023-09-26 14:54:18 --> Router Class Initialized
INFO - 2023-09-26 14:54:18 --> Output Class Initialized
INFO - 2023-09-26 14:54:18 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:18 --> Input Class Initialized
INFO - 2023-09-26 14:54:18 --> Language Class Initialized
INFO - 2023-09-26 14:54:18 --> Language Class Initialized
INFO - 2023-09-26 14:54:18 --> Config Class Initialized
INFO - 2023-09-26 14:54:18 --> Loader Class Initialized
INFO - 2023-09-26 14:54:18 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:18 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:18 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:18 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:18 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:18 --> Controller Class Initialized
INFO - 2023-09-26 14:54:18 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:18 --> Total execution time: 0.0798
INFO - 2023-09-26 14:54:19 --> Config Class Initialized
INFO - 2023-09-26 14:54:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:19 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:19 --> URI Class Initialized
INFO - 2023-09-26 14:54:19 --> Router Class Initialized
INFO - 2023-09-26 14:54:19 --> Output Class Initialized
INFO - 2023-09-26 14:54:19 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:19 --> Input Class Initialized
INFO - 2023-09-26 14:54:19 --> Language Class Initialized
INFO - 2023-09-26 14:54:19 --> Language Class Initialized
INFO - 2023-09-26 14:54:19 --> Config Class Initialized
INFO - 2023-09-26 14:54:19 --> Loader Class Initialized
INFO - 2023-09-26 14:54:19 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:19 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:19 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:19 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:19 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:19 --> Controller Class Initialized
INFO - 2023-09-26 14:54:20 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:20 --> Total execution time: 0.4426
INFO - 2023-09-26 14:54:24 --> Config Class Initialized
INFO - 2023-09-26 14:54:24 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:24 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:24 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:24 --> URI Class Initialized
INFO - 2023-09-26 14:54:24 --> Router Class Initialized
INFO - 2023-09-26 14:54:24 --> Output Class Initialized
INFO - 2023-09-26 14:54:24 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:24 --> Input Class Initialized
INFO - 2023-09-26 14:54:24 --> Language Class Initialized
INFO - 2023-09-26 14:54:24 --> Language Class Initialized
INFO - 2023-09-26 14:54:24 --> Config Class Initialized
INFO - 2023-09-26 14:54:24 --> Loader Class Initialized
INFO - 2023-09-26 14:54:24 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:24 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:24 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:24 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:24 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:24 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:54:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:24 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:24 --> Total execution time: 0.0358
INFO - 2023-09-26 14:54:26 --> Config Class Initialized
INFO - 2023-09-26 14:54:26 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:26 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:26 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:26 --> URI Class Initialized
INFO - 2023-09-26 14:54:26 --> Router Class Initialized
INFO - 2023-09-26 14:54:26 --> Output Class Initialized
INFO - 2023-09-26 14:54:26 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:26 --> Input Class Initialized
INFO - 2023-09-26 14:54:26 --> Language Class Initialized
INFO - 2023-09-26 14:54:26 --> Language Class Initialized
INFO - 2023-09-26 14:54:26 --> Config Class Initialized
INFO - 2023-09-26 14:54:26 --> Loader Class Initialized
INFO - 2023-09-26 14:54:26 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:26 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:26 --> Controller Class Initialized
DEBUG - 2023-09-26 14:54:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:54:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:54:26 --> Final output sent to browser
DEBUG - 2023-09-26 14:54:26 --> Total execution time: 0.2842
INFO - 2023-09-26 14:54:26 --> Config Class Initialized
INFO - 2023-09-26 14:54:26 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:26 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:26 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:26 --> URI Class Initialized
INFO - 2023-09-26 14:54:26 --> Router Class Initialized
INFO - 2023-09-26 14:54:26 --> Output Class Initialized
INFO - 2023-09-26 14:54:26 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:26 --> Input Class Initialized
INFO - 2023-09-26 14:54:26 --> Language Class Initialized
INFO - 2023-09-26 14:54:26 --> Language Class Initialized
INFO - 2023-09-26 14:54:26 --> Config Class Initialized
INFO - 2023-09-26 14:54:26 --> Loader Class Initialized
INFO - 2023-09-26 14:54:26 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:26 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:26 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:26 --> Controller Class Initialized
INFO - 2023-09-26 14:54:28 --> Config Class Initialized
INFO - 2023-09-26 14:54:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:54:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:54:28 --> Utf8 Class Initialized
INFO - 2023-09-26 14:54:28 --> URI Class Initialized
INFO - 2023-09-26 14:54:28 --> Router Class Initialized
INFO - 2023-09-26 14:54:28 --> Output Class Initialized
INFO - 2023-09-26 14:54:28 --> Security Class Initialized
DEBUG - 2023-09-26 14:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:54:28 --> Input Class Initialized
INFO - 2023-09-26 14:54:28 --> Language Class Initialized
INFO - 2023-09-26 14:54:28 --> Language Class Initialized
INFO - 2023-09-26 14:54:28 --> Config Class Initialized
INFO - 2023-09-26 14:54:28 --> Loader Class Initialized
INFO - 2023-09-26 14:54:28 --> Helper loaded: url_helper
INFO - 2023-09-26 14:54:28 --> Helper loaded: file_helper
INFO - 2023-09-26 14:54:28 --> Helper loaded: form_helper
INFO - 2023-09-26 14:54:28 --> Helper loaded: my_helper
INFO - 2023-09-26 14:54:28 --> Database Driver Class Initialized
INFO - 2023-09-26 14:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:54:28 --> Controller Class Initialized
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:54:29 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 462
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:54:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:55:56 --> Config Class Initialized
INFO - 2023-09-26 14:55:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:55:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:55:56 --> Utf8 Class Initialized
INFO - 2023-09-26 14:55:56 --> URI Class Initialized
INFO - 2023-09-26 14:55:56 --> Router Class Initialized
INFO - 2023-09-26 14:55:56 --> Output Class Initialized
INFO - 2023-09-26 14:55:56 --> Security Class Initialized
DEBUG - 2023-09-26 14:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:55:56 --> Input Class Initialized
INFO - 2023-09-26 14:55:56 --> Language Class Initialized
INFO - 2023-09-26 14:55:56 --> Language Class Initialized
INFO - 2023-09-26 14:55:56 --> Config Class Initialized
INFO - 2023-09-26 14:55:56 --> Loader Class Initialized
INFO - 2023-09-26 14:55:56 --> Helper loaded: url_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: file_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: form_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: my_helper
INFO - 2023-09-26 14:55:56 --> Database Driver Class Initialized
INFO - 2023-09-26 14:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:55:56 --> Controller Class Initialized
DEBUG - 2023-09-26 14:55:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:55:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:55:56 --> Final output sent to browser
DEBUG - 2023-09-26 14:55:56 --> Total execution time: 0.1280
INFO - 2023-09-26 14:55:56 --> Config Class Initialized
INFO - 2023-09-26 14:55:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:55:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:55:56 --> Utf8 Class Initialized
INFO - 2023-09-26 14:55:56 --> URI Class Initialized
INFO - 2023-09-26 14:55:56 --> Router Class Initialized
INFO - 2023-09-26 14:55:56 --> Output Class Initialized
INFO - 2023-09-26 14:55:56 --> Security Class Initialized
DEBUG - 2023-09-26 14:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:55:56 --> Input Class Initialized
INFO - 2023-09-26 14:55:56 --> Language Class Initialized
INFO - 2023-09-26 14:55:56 --> Language Class Initialized
INFO - 2023-09-26 14:55:56 --> Config Class Initialized
INFO - 2023-09-26 14:55:56 --> Loader Class Initialized
INFO - 2023-09-26 14:55:56 --> Helper loaded: url_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: file_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: form_helper
INFO - 2023-09-26 14:55:56 --> Helper loaded: my_helper
INFO - 2023-09-26 14:55:56 --> Database Driver Class Initialized
INFO - 2023-09-26 14:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:55:56 --> Controller Class Initialized
INFO - 2023-09-26 14:55:57 --> Config Class Initialized
INFO - 2023-09-26 14:55:57 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:55:57 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:55:57 --> Utf8 Class Initialized
INFO - 2023-09-26 14:55:57 --> URI Class Initialized
INFO - 2023-09-26 14:55:57 --> Router Class Initialized
INFO - 2023-09-26 14:55:57 --> Output Class Initialized
INFO - 2023-09-26 14:55:57 --> Security Class Initialized
DEBUG - 2023-09-26 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:55:57 --> Input Class Initialized
INFO - 2023-09-26 14:55:57 --> Language Class Initialized
INFO - 2023-09-26 14:55:57 --> Language Class Initialized
INFO - 2023-09-26 14:55:57 --> Config Class Initialized
INFO - 2023-09-26 14:55:57 --> Loader Class Initialized
INFO - 2023-09-26 14:55:57 --> Helper loaded: url_helper
INFO - 2023-09-26 14:55:57 --> Helper loaded: file_helper
INFO - 2023-09-26 14:55:57 --> Helper loaded: form_helper
INFO - 2023-09-26 14:55:57 --> Helper loaded: my_helper
INFO - 2023-09-26 14:55:57 --> Database Driver Class Initialized
INFO - 2023-09-26 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:55:57 --> Controller Class Initialized
INFO - 2023-09-26 14:55:58 --> Final output sent to browser
DEBUG - 2023-09-26 14:55:58 --> Total execution time: 0.8474
INFO - 2023-09-26 14:56:00 --> Config Class Initialized
INFO - 2023-09-26 14:56:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:00 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:00 --> URI Class Initialized
INFO - 2023-09-26 14:56:00 --> Router Class Initialized
INFO - 2023-09-26 14:56:00 --> Output Class Initialized
INFO - 2023-09-26 14:56:00 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:00 --> Input Class Initialized
INFO - 2023-09-26 14:56:00 --> Language Class Initialized
INFO - 2023-09-26 14:56:00 --> Language Class Initialized
INFO - 2023-09-26 14:56:00 --> Config Class Initialized
INFO - 2023-09-26 14:56:00 --> Loader Class Initialized
INFO - 2023-09-26 14:56:00 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:00 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:00 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:00 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:00 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:00 --> Controller Class Initialized
INFO - 2023-09-26 14:56:00 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:00 --> Total execution time: 0.1577
INFO - 2023-09-26 14:56:02 --> Config Class Initialized
INFO - 2023-09-26 14:56:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:02 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:02 --> URI Class Initialized
INFO - 2023-09-26 14:56:02 --> Router Class Initialized
INFO - 2023-09-26 14:56:02 --> Output Class Initialized
INFO - 2023-09-26 14:56:02 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:02 --> Input Class Initialized
INFO - 2023-09-26 14:56:02 --> Language Class Initialized
INFO - 2023-09-26 14:56:02 --> Language Class Initialized
INFO - 2023-09-26 14:56:02 --> Config Class Initialized
INFO - 2023-09-26 14:56:02 --> Loader Class Initialized
INFO - 2023-09-26 14:56:02 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:02 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:02 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:02 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:02 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:02 --> Controller Class Initialized
INFO - 2023-09-26 14:56:02 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:02 --> Total execution time: 0.1122
INFO - 2023-09-26 14:56:04 --> Config Class Initialized
INFO - 2023-09-26 14:56:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:04 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:04 --> URI Class Initialized
INFO - 2023-09-26 14:56:04 --> Router Class Initialized
INFO - 2023-09-26 14:56:04 --> Output Class Initialized
INFO - 2023-09-26 14:56:04 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:04 --> Input Class Initialized
INFO - 2023-09-26 14:56:04 --> Language Class Initialized
INFO - 2023-09-26 14:56:04 --> Language Class Initialized
INFO - 2023-09-26 14:56:04 --> Config Class Initialized
INFO - 2023-09-26 14:56:04 --> Loader Class Initialized
INFO - 2023-09-26 14:56:04 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:04 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:04 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:04 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:04 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:04 --> Controller Class Initialized
INFO - 2023-09-26 14:56:04 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:04 --> Total execution time: 0.0962
INFO - 2023-09-26 14:56:06 --> Config Class Initialized
INFO - 2023-09-26 14:56:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:06 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:06 --> URI Class Initialized
INFO - 2023-09-26 14:56:06 --> Router Class Initialized
INFO - 2023-09-26 14:56:06 --> Output Class Initialized
INFO - 2023-09-26 14:56:06 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:06 --> Input Class Initialized
INFO - 2023-09-26 14:56:06 --> Language Class Initialized
INFO - 2023-09-26 14:56:06 --> Language Class Initialized
INFO - 2023-09-26 14:56:06 --> Config Class Initialized
INFO - 2023-09-26 14:56:06 --> Loader Class Initialized
INFO - 2023-09-26 14:56:06 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:06 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:06 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:06 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:06 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:06 --> Controller Class Initialized
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:56:06 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 14:56:30 --> Config Class Initialized
INFO - 2023-09-26 14:56:30 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:30 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:30 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:30 --> URI Class Initialized
INFO - 2023-09-26 14:56:30 --> Router Class Initialized
INFO - 2023-09-26 14:56:30 --> Output Class Initialized
INFO - 2023-09-26 14:56:30 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:30 --> Input Class Initialized
INFO - 2023-09-26 14:56:30 --> Language Class Initialized
INFO - 2023-09-26 14:56:30 --> Language Class Initialized
INFO - 2023-09-26 14:56:30 --> Config Class Initialized
INFO - 2023-09-26 14:56:30 --> Loader Class Initialized
INFO - 2023-09-26 14:56:30 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:30 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:30 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:30 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:30 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:30 --> Controller Class Initialized
DEBUG - 2023-09-26 14:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:56:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:56:30 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:30 --> Total execution time: 0.0739
INFO - 2023-09-26 14:56:31 --> Config Class Initialized
INFO - 2023-09-26 14:56:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:31 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:31 --> URI Class Initialized
INFO - 2023-09-26 14:56:31 --> Router Class Initialized
INFO - 2023-09-26 14:56:31 --> Output Class Initialized
INFO - 2023-09-26 14:56:31 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:31 --> Input Class Initialized
INFO - 2023-09-26 14:56:31 --> Language Class Initialized
INFO - 2023-09-26 14:56:31 --> Language Class Initialized
INFO - 2023-09-26 14:56:31 --> Config Class Initialized
INFO - 2023-09-26 14:56:31 --> Loader Class Initialized
INFO - 2023-09-26 14:56:31 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:31 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:31 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:31 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:31 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:31 --> Controller Class Initialized
INFO - 2023-09-26 14:56:32 --> Config Class Initialized
INFO - 2023-09-26 14:56:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:32 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:32 --> URI Class Initialized
INFO - 2023-09-26 14:56:32 --> Router Class Initialized
INFO - 2023-09-26 14:56:32 --> Output Class Initialized
INFO - 2023-09-26 14:56:32 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:32 --> Input Class Initialized
INFO - 2023-09-26 14:56:32 --> Language Class Initialized
INFO - 2023-09-26 14:56:32 --> Language Class Initialized
INFO - 2023-09-26 14:56:32 --> Config Class Initialized
INFO - 2023-09-26 14:56:32 --> Loader Class Initialized
INFO - 2023-09-26 14:56:32 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:32 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:32 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:32 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:32 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:32 --> Controller Class Initialized
DEBUG - 2023-09-26 14:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:56:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:56:32 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:32 --> Total execution time: 0.0475
INFO - 2023-09-26 14:56:34 --> Config Class Initialized
INFO - 2023-09-26 14:56:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:34 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:34 --> URI Class Initialized
INFO - 2023-09-26 14:56:34 --> Router Class Initialized
INFO - 2023-09-26 14:56:34 --> Output Class Initialized
INFO - 2023-09-26 14:56:34 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:34 --> Input Class Initialized
INFO - 2023-09-26 14:56:34 --> Language Class Initialized
INFO - 2023-09-26 14:56:34 --> Language Class Initialized
INFO - 2023-09-26 14:56:34 --> Config Class Initialized
INFO - 2023-09-26 14:56:34 --> Loader Class Initialized
INFO - 2023-09-26 14:56:34 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:34 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:34 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:34 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:34 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:34 --> Controller Class Initialized
DEBUG - 2023-09-26 14:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-09-26 14:56:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:56:34 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:34 --> Total execution time: 0.0605
INFO - 2023-09-26 14:56:35 --> Config Class Initialized
INFO - 2023-09-26 14:56:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:35 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:35 --> URI Class Initialized
INFO - 2023-09-26 14:56:35 --> Router Class Initialized
INFO - 2023-09-26 14:56:35 --> Output Class Initialized
INFO - 2023-09-26 14:56:35 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:35 --> Input Class Initialized
INFO - 2023-09-26 14:56:35 --> Language Class Initialized
INFO - 2023-09-26 14:56:35 --> Language Class Initialized
INFO - 2023-09-26 14:56:35 --> Config Class Initialized
INFO - 2023-09-26 14:56:35 --> Loader Class Initialized
INFO - 2023-09-26 14:56:35 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:35 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:35 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:35 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:35 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:35 --> Controller Class Initialized
DEBUG - 2023-09-26 14:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 14:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:56:35 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:35 --> Total execution time: 0.0397
INFO - 2023-09-26 14:56:36 --> Config Class Initialized
INFO - 2023-09-26 14:56:36 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:36 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:36 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:36 --> URI Class Initialized
INFO - 2023-09-26 14:56:36 --> Router Class Initialized
INFO - 2023-09-26 14:56:36 --> Output Class Initialized
INFO - 2023-09-26 14:56:36 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:36 --> Input Class Initialized
INFO - 2023-09-26 14:56:36 --> Language Class Initialized
INFO - 2023-09-26 14:56:36 --> Language Class Initialized
INFO - 2023-09-26 14:56:36 --> Config Class Initialized
INFO - 2023-09-26 14:56:36 --> Loader Class Initialized
INFO - 2023-09-26 14:56:36 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:36 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:36 --> Controller Class Initialized
DEBUG - 2023-09-26 14:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 14:56:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 14:56:36 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:36 --> Total execution time: 0.2666
INFO - 2023-09-26 14:56:36 --> Config Class Initialized
INFO - 2023-09-26 14:56:36 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:36 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:36 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:36 --> URI Class Initialized
INFO - 2023-09-26 14:56:36 --> Router Class Initialized
INFO - 2023-09-26 14:56:36 --> Output Class Initialized
INFO - 2023-09-26 14:56:36 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:36 --> Input Class Initialized
INFO - 2023-09-26 14:56:36 --> Language Class Initialized
INFO - 2023-09-26 14:56:36 --> Language Class Initialized
INFO - 2023-09-26 14:56:36 --> Config Class Initialized
INFO - 2023-09-26 14:56:36 --> Loader Class Initialized
INFO - 2023-09-26 14:56:36 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:36 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:36 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:36 --> Controller Class Initialized
INFO - 2023-09-26 14:56:37 --> Config Class Initialized
INFO - 2023-09-26 14:56:37 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:37 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:37 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:37 --> URI Class Initialized
INFO - 2023-09-26 14:56:37 --> Router Class Initialized
INFO - 2023-09-26 14:56:37 --> Output Class Initialized
INFO - 2023-09-26 14:56:37 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:37 --> Input Class Initialized
INFO - 2023-09-26 14:56:37 --> Language Class Initialized
INFO - 2023-09-26 14:56:37 --> Language Class Initialized
INFO - 2023-09-26 14:56:37 --> Config Class Initialized
INFO - 2023-09-26 14:56:37 --> Loader Class Initialized
INFO - 2023-09-26 14:56:37 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:37 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:37 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:37 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:37 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:37 --> Controller Class Initialized
INFO - 2023-09-26 14:56:37 --> Final output sent to browser
DEBUG - 2023-09-26 14:56:37 --> Total execution time: 0.0605
INFO - 2023-09-26 14:56:41 --> Config Class Initialized
INFO - 2023-09-26 14:56:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 14:56:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 14:56:41 --> Utf8 Class Initialized
INFO - 2023-09-26 14:56:41 --> URI Class Initialized
INFO - 2023-09-26 14:56:41 --> Router Class Initialized
INFO - 2023-09-26 14:56:41 --> Output Class Initialized
INFO - 2023-09-26 14:56:41 --> Security Class Initialized
DEBUG - 2023-09-26 14:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 14:56:41 --> Input Class Initialized
INFO - 2023-09-26 14:56:41 --> Language Class Initialized
INFO - 2023-09-26 14:56:41 --> Language Class Initialized
INFO - 2023-09-26 14:56:41 --> Config Class Initialized
INFO - 2023-09-26 14:56:41 --> Loader Class Initialized
INFO - 2023-09-26 14:56:41 --> Helper loaded: url_helper
INFO - 2023-09-26 14:56:41 --> Helper loaded: file_helper
INFO - 2023-09-26 14:56:41 --> Helper loaded: form_helper
INFO - 2023-09-26 14:56:41 --> Helper loaded: my_helper
INFO - 2023-09-26 14:56:41 --> Database Driver Class Initialized
INFO - 2023-09-26 14:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 14:56:41 --> Controller Class Initialized
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 571
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 573
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
ERROR - 2023-09-26 14:56:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 579
INFO - 2023-09-26 15:04:00 --> Config Class Initialized
INFO - 2023-09-26 15:04:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:04:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:04:00 --> Utf8 Class Initialized
INFO - 2023-09-26 15:04:00 --> URI Class Initialized
DEBUG - 2023-09-26 15:04:00 --> No URI present. Default controller set.
INFO - 2023-09-26 15:04:00 --> Router Class Initialized
INFO - 2023-09-26 15:04:00 --> Output Class Initialized
INFO - 2023-09-26 15:04:00 --> Security Class Initialized
DEBUG - 2023-09-26 15:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:04:00 --> Input Class Initialized
INFO - 2023-09-26 15:04:00 --> Language Class Initialized
INFO - 2023-09-26 15:04:00 --> Language Class Initialized
INFO - 2023-09-26 15:04:00 --> Config Class Initialized
INFO - 2023-09-26 15:04:00 --> Loader Class Initialized
INFO - 2023-09-26 15:04:00 --> Helper loaded: url_helper
INFO - 2023-09-26 15:04:00 --> Helper loaded: file_helper
INFO - 2023-09-26 15:04:00 --> Helper loaded: form_helper
INFO - 2023-09-26 15:04:00 --> Helper loaded: my_helper
INFO - 2023-09-26 15:04:00 --> Database Driver Class Initialized
INFO - 2023-09-26 15:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:04:00 --> Controller Class Initialized
DEBUG - 2023-09-26 15:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:04:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:04:00 --> Final output sent to browser
DEBUG - 2023-09-26 15:04:00 --> Total execution time: 0.0633
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:04:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:04:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:04:01 --> URI Class Initialized
INFO - 2023-09-26 15:04:01 --> Router Class Initialized
INFO - 2023-09-26 15:04:01 --> Output Class Initialized
INFO - 2023-09-26 15:04:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:04:01 --> Input Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Loader Class Initialized
INFO - 2023-09-26 15:04:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:04:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:04:01 --> Controller Class Initialized
INFO - 2023-09-26 15:04:01 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:04:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:04:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:04:01 --> URI Class Initialized
INFO - 2023-09-26 15:04:01 --> Router Class Initialized
INFO - 2023-09-26 15:04:01 --> Output Class Initialized
INFO - 2023-09-26 15:04:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:04:01 --> Input Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Loader Class Initialized
INFO - 2023-09-26 15:04:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:04:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:04:01 --> Controller Class Initialized
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:04:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:04:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:04:01 --> URI Class Initialized
INFO - 2023-09-26 15:04:01 --> Router Class Initialized
INFO - 2023-09-26 15:04:01 --> Output Class Initialized
INFO - 2023-09-26 15:04:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:04:01 --> Input Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Language Class Initialized
INFO - 2023-09-26 15:04:01 --> Config Class Initialized
INFO - 2023-09-26 15:04:01 --> Loader Class Initialized
INFO - 2023-09-26 15:04:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:04:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:04:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:04:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:04:01 --> Controller Class Initialized
DEBUG - 2023-09-26 15:04:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:04:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:04:01 --> Final output sent to browser
DEBUG - 2023-09-26 15:04:01 --> Total execution time: 0.0491
INFO - 2023-09-26 15:26:07 --> Config Class Initialized
INFO - 2023-09-26 15:26:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:07 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:07 --> URI Class Initialized
DEBUG - 2023-09-26 15:26:07 --> No URI present. Default controller set.
INFO - 2023-09-26 15:26:07 --> Router Class Initialized
INFO - 2023-09-26 15:26:07 --> Output Class Initialized
INFO - 2023-09-26 15:26:07 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:07 --> Input Class Initialized
INFO - 2023-09-26 15:26:07 --> Language Class Initialized
INFO - 2023-09-26 15:26:07 --> Language Class Initialized
INFO - 2023-09-26 15:26:07 --> Config Class Initialized
INFO - 2023-09-26 15:26:07 --> Loader Class Initialized
INFO - 2023-09-26 15:26:07 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:07 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:07 --> Controller Class Initialized
INFO - 2023-09-26 15:26:07 --> Config Class Initialized
INFO - 2023-09-26 15:26:07 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:07 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:07 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:07 --> URI Class Initialized
INFO - 2023-09-26 15:26:07 --> Router Class Initialized
INFO - 2023-09-26 15:26:07 --> Output Class Initialized
INFO - 2023-09-26 15:26:07 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:07 --> Input Class Initialized
INFO - 2023-09-26 15:26:07 --> Language Class Initialized
INFO - 2023-09-26 15:26:07 --> Language Class Initialized
INFO - 2023-09-26 15:26:07 --> Config Class Initialized
INFO - 2023-09-26 15:26:07 --> Loader Class Initialized
INFO - 2023-09-26 15:26:07 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:07 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:07 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:07 --> Controller Class Initialized
DEBUG - 2023-09-26 15:26:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:26:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:26:07 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:07 --> Total execution time: 0.0519
INFO - 2023-09-26 15:26:20 --> Config Class Initialized
INFO - 2023-09-26 15:26:20 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:20 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:20 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:20 --> URI Class Initialized
INFO - 2023-09-26 15:26:20 --> Router Class Initialized
INFO - 2023-09-26 15:26:20 --> Output Class Initialized
INFO - 2023-09-26 15:26:20 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:20 --> Input Class Initialized
INFO - 2023-09-26 15:26:20 --> Language Class Initialized
INFO - 2023-09-26 15:26:20 --> Language Class Initialized
INFO - 2023-09-26 15:26:20 --> Config Class Initialized
INFO - 2023-09-26 15:26:20 --> Loader Class Initialized
INFO - 2023-09-26 15:26:20 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:20 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:20 --> Controller Class Initialized
INFO - 2023-09-26 15:26:20 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:26:20 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:20 --> Total execution time: 0.0512
INFO - 2023-09-26 15:26:20 --> Config Class Initialized
INFO - 2023-09-26 15:26:20 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:20 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:20 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:20 --> URI Class Initialized
INFO - 2023-09-26 15:26:20 --> Router Class Initialized
INFO - 2023-09-26 15:26:20 --> Output Class Initialized
INFO - 2023-09-26 15:26:20 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:20 --> Input Class Initialized
INFO - 2023-09-26 15:26:20 --> Language Class Initialized
INFO - 2023-09-26 15:26:20 --> Language Class Initialized
INFO - 2023-09-26 15:26:20 --> Config Class Initialized
INFO - 2023-09-26 15:26:20 --> Loader Class Initialized
INFO - 2023-09-26 15:26:20 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:20 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:20 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:20 --> Controller Class Initialized
DEBUG - 2023-09-26 15:26:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:26:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:26:20 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:20 --> Total execution time: 0.0818
INFO - 2023-09-26 15:26:23 --> Config Class Initialized
INFO - 2023-09-26 15:26:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:23 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:23 --> URI Class Initialized
INFO - 2023-09-26 15:26:23 --> Router Class Initialized
INFO - 2023-09-26 15:26:23 --> Output Class Initialized
INFO - 2023-09-26 15:26:23 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:23 --> Input Class Initialized
INFO - 2023-09-26 15:26:23 --> Language Class Initialized
INFO - 2023-09-26 15:26:24 --> Language Class Initialized
INFO - 2023-09-26 15:26:24 --> Config Class Initialized
INFO - 2023-09-26 15:26:24 --> Loader Class Initialized
INFO - 2023-09-26 15:26:24 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:24 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:24 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:24 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:24 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:24 --> Controller Class Initialized
DEBUG - 2023-09-26 15:26:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:26:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:26:24 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:24 --> Total execution time: 0.0737
INFO - 2023-09-26 15:26:25 --> Config Class Initialized
INFO - 2023-09-26 15:26:25 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:25 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:25 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:25 --> URI Class Initialized
INFO - 2023-09-26 15:26:25 --> Router Class Initialized
INFO - 2023-09-26 15:26:25 --> Output Class Initialized
INFO - 2023-09-26 15:26:25 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:25 --> Input Class Initialized
INFO - 2023-09-26 15:26:25 --> Language Class Initialized
INFO - 2023-09-26 15:26:25 --> Language Class Initialized
INFO - 2023-09-26 15:26:25 --> Config Class Initialized
INFO - 2023-09-26 15:26:25 --> Loader Class Initialized
INFO - 2023-09-26 15:26:25 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:25 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:25 --> Controller Class Initialized
DEBUG - 2023-09-26 15:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:26:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:26:25 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:25 --> Total execution time: 0.0388
INFO - 2023-09-26 15:26:25 --> Config Class Initialized
INFO - 2023-09-26 15:26:25 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:25 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:25 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:25 --> URI Class Initialized
INFO - 2023-09-26 15:26:25 --> Router Class Initialized
INFO - 2023-09-26 15:26:25 --> Output Class Initialized
INFO - 2023-09-26 15:26:25 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:25 --> Input Class Initialized
INFO - 2023-09-26 15:26:25 --> Language Class Initialized
INFO - 2023-09-26 15:26:25 --> Language Class Initialized
INFO - 2023-09-26 15:26:25 --> Config Class Initialized
INFO - 2023-09-26 15:26:25 --> Loader Class Initialized
INFO - 2023-09-26 15:26:25 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:25 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:25 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:25 --> Controller Class Initialized
INFO - 2023-09-26 15:26:26 --> Config Class Initialized
INFO - 2023-09-26 15:26:26 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:26 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:26 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:26 --> URI Class Initialized
INFO - 2023-09-26 15:26:26 --> Router Class Initialized
INFO - 2023-09-26 15:26:26 --> Output Class Initialized
INFO - 2023-09-26 15:26:26 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:26 --> Input Class Initialized
INFO - 2023-09-26 15:26:26 --> Language Class Initialized
INFO - 2023-09-26 15:26:26 --> Language Class Initialized
INFO - 2023-09-26 15:26:26 --> Config Class Initialized
INFO - 2023-09-26 15:26:26 --> Loader Class Initialized
INFO - 2023-09-26 15:26:26 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:26 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:26 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:26 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:26 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:26 --> Controller Class Initialized
INFO - 2023-09-26 15:26:26 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:26 --> Total execution time: 0.0376
INFO - 2023-09-26 15:26:43 --> Config Class Initialized
INFO - 2023-09-26 15:26:43 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:43 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:43 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:43 --> URI Class Initialized
INFO - 2023-09-26 15:26:43 --> Router Class Initialized
INFO - 2023-09-26 15:26:43 --> Output Class Initialized
INFO - 2023-09-26 15:26:43 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:43 --> Input Class Initialized
INFO - 2023-09-26 15:26:43 --> Language Class Initialized
INFO - 2023-09-26 15:26:43 --> Language Class Initialized
INFO - 2023-09-26 15:26:43 --> Config Class Initialized
INFO - 2023-09-26 15:26:43 --> Loader Class Initialized
INFO - 2023-09-26 15:26:43 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:43 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:43 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:43 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:43 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:43 --> Controller Class Initialized
INFO - 2023-09-26 15:26:43 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:43 --> Total execution time: 0.0917
INFO - 2023-09-26 15:26:56 --> Config Class Initialized
INFO - 2023-09-26 15:26:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:26:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:26:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:26:56 --> URI Class Initialized
INFO - 2023-09-26 15:26:56 --> Router Class Initialized
INFO - 2023-09-26 15:26:56 --> Output Class Initialized
INFO - 2023-09-26 15:26:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:26:56 --> Input Class Initialized
INFO - 2023-09-26 15:26:56 --> Language Class Initialized
INFO - 2023-09-26 15:26:56 --> Language Class Initialized
INFO - 2023-09-26 15:26:56 --> Config Class Initialized
INFO - 2023-09-26 15:26:56 --> Loader Class Initialized
INFO - 2023-09-26 15:26:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:26:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:26:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:26:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:26:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:26:56 --> Controller Class Initialized
INFO - 2023-09-26 15:26:56 --> Final output sent to browser
DEBUG - 2023-09-26 15:26:56 --> Total execution time: 0.0932
INFO - 2023-09-26 15:27:29 --> Config Class Initialized
INFO - 2023-09-26 15:27:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:29 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:29 --> URI Class Initialized
INFO - 2023-09-26 15:27:29 --> Router Class Initialized
INFO - 2023-09-26 15:27:29 --> Output Class Initialized
INFO - 2023-09-26 15:27:29 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:29 --> Input Class Initialized
INFO - 2023-09-26 15:27:29 --> Language Class Initialized
INFO - 2023-09-26 15:27:29 --> Language Class Initialized
INFO - 2023-09-26 15:27:29 --> Config Class Initialized
INFO - 2023-09-26 15:27:29 --> Loader Class Initialized
INFO - 2023-09-26 15:27:29 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:29 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:29 --> Controller Class Initialized
INFO - 2023-09-26 15:27:29 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:29 --> Total execution time: 0.0463
INFO - 2023-09-26 15:27:29 --> Config Class Initialized
INFO - 2023-09-26 15:27:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:29 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:29 --> URI Class Initialized
INFO - 2023-09-26 15:27:29 --> Router Class Initialized
INFO - 2023-09-26 15:27:29 --> Output Class Initialized
INFO - 2023-09-26 15:27:29 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:29 --> Input Class Initialized
INFO - 2023-09-26 15:27:29 --> Language Class Initialized
INFO - 2023-09-26 15:27:29 --> Language Class Initialized
INFO - 2023-09-26 15:27:29 --> Config Class Initialized
INFO - 2023-09-26 15:27:29 --> Loader Class Initialized
INFO - 2023-09-26 15:27:29 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:29 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:29 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:29 --> Controller Class Initialized
INFO - 2023-09-26 15:27:29 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:29 --> Total execution time: 0.0989
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:41 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:41 --> URI Class Initialized
INFO - 2023-09-26 15:27:41 --> Router Class Initialized
INFO - 2023-09-26 15:27:41 --> Output Class Initialized
INFO - 2023-09-26 15:27:41 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:41 --> Input Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Loader Class Initialized
INFO - 2023-09-26 15:27:41 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:41 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:41 --> Controller Class Initialized
INFO - 2023-09-26 15:27:41 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:41 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:41 --> URI Class Initialized
INFO - 2023-09-26 15:27:41 --> Router Class Initialized
INFO - 2023-09-26 15:27:41 --> Output Class Initialized
INFO - 2023-09-26 15:27:41 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:41 --> Input Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Loader Class Initialized
INFO - 2023-09-26 15:27:41 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:41 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:41 --> Controller Class Initialized
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:41 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:41 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:41 --> URI Class Initialized
INFO - 2023-09-26 15:27:41 --> Router Class Initialized
INFO - 2023-09-26 15:27:41 --> Output Class Initialized
INFO - 2023-09-26 15:27:41 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:41 --> Input Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Language Class Initialized
INFO - 2023-09-26 15:27:41 --> Config Class Initialized
INFO - 2023-09-26 15:27:41 --> Loader Class Initialized
INFO - 2023-09-26 15:27:41 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:41 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:41 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:41 --> Controller Class Initialized
DEBUG - 2023-09-26 15:27:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:27:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:27:41 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:41 --> Total execution time: 0.0551
INFO - 2023-09-26 15:27:53 --> Config Class Initialized
INFO - 2023-09-26 15:27:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:53 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:53 --> URI Class Initialized
INFO - 2023-09-26 15:27:53 --> Router Class Initialized
INFO - 2023-09-26 15:27:53 --> Output Class Initialized
INFO - 2023-09-26 15:27:53 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:53 --> Input Class Initialized
INFO - 2023-09-26 15:27:53 --> Language Class Initialized
INFO - 2023-09-26 15:27:53 --> Language Class Initialized
INFO - 2023-09-26 15:27:53 --> Config Class Initialized
INFO - 2023-09-26 15:27:53 --> Loader Class Initialized
INFO - 2023-09-26 15:27:53 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:53 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:53 --> Controller Class Initialized
INFO - 2023-09-26 15:27:53 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:27:53 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:53 --> Total execution time: 0.0365
INFO - 2023-09-26 15:27:53 --> Config Class Initialized
INFO - 2023-09-26 15:27:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:53 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:53 --> URI Class Initialized
INFO - 2023-09-26 15:27:53 --> Router Class Initialized
INFO - 2023-09-26 15:27:53 --> Output Class Initialized
INFO - 2023-09-26 15:27:53 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:53 --> Input Class Initialized
INFO - 2023-09-26 15:27:53 --> Language Class Initialized
INFO - 2023-09-26 15:27:53 --> Language Class Initialized
INFO - 2023-09-26 15:27:53 --> Config Class Initialized
INFO - 2023-09-26 15:27:53 --> Loader Class Initialized
INFO - 2023-09-26 15:27:53 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:53 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:53 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:53 --> Controller Class Initialized
DEBUG - 2023-09-26 15:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-26 15:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:27:53 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:53 --> Total execution time: 0.0421
INFO - 2023-09-26 15:27:55 --> Config Class Initialized
INFO - 2023-09-26 15:27:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:55 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:55 --> URI Class Initialized
INFO - 2023-09-26 15:27:55 --> Router Class Initialized
INFO - 2023-09-26 15:27:55 --> Output Class Initialized
INFO - 2023-09-26 15:27:55 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:55 --> Input Class Initialized
INFO - 2023-09-26 15:27:55 --> Language Class Initialized
INFO - 2023-09-26 15:27:55 --> Language Class Initialized
INFO - 2023-09-26 15:27:55 --> Config Class Initialized
INFO - 2023-09-26 15:27:55 --> Loader Class Initialized
INFO - 2023-09-26 15:27:55 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:56 --> Controller Class Initialized
DEBUG - 2023-09-26 15:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-26 15:27:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:27:56 --> Final output sent to browser
DEBUG - 2023-09-26 15:27:56 --> Total execution time: 0.0364
INFO - 2023-09-26 15:27:56 --> Config Class Initialized
INFO - 2023-09-26 15:27:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:56 --> URI Class Initialized
INFO - 2023-09-26 15:27:56 --> Router Class Initialized
INFO - 2023-09-26 15:27:56 --> Output Class Initialized
INFO - 2023-09-26 15:27:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:56 --> Input Class Initialized
INFO - 2023-09-26 15:27:56 --> Language Class Initialized
ERROR - 2023-09-26 15:27:56 --> 404 Page Not Found: /index
INFO - 2023-09-26 15:27:56 --> Config Class Initialized
INFO - 2023-09-26 15:27:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:27:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:27:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:27:56 --> URI Class Initialized
INFO - 2023-09-26 15:27:56 --> Router Class Initialized
INFO - 2023-09-26 15:27:56 --> Output Class Initialized
INFO - 2023-09-26 15:27:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:27:56 --> Input Class Initialized
INFO - 2023-09-26 15:27:56 --> Language Class Initialized
INFO - 2023-09-26 15:27:56 --> Language Class Initialized
INFO - 2023-09-26 15:27:56 --> Config Class Initialized
INFO - 2023-09-26 15:27:56 --> Loader Class Initialized
INFO - 2023-09-26 15:27:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:27:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:27:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:27:56 --> Controller Class Initialized
INFO - 2023-09-26 15:28:00 --> Config Class Initialized
INFO - 2023-09-26 15:28:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:00 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:00 --> URI Class Initialized
INFO - 2023-09-26 15:28:00 --> Router Class Initialized
INFO - 2023-09-26 15:28:00 --> Output Class Initialized
INFO - 2023-09-26 15:28:00 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:00 --> Input Class Initialized
INFO - 2023-09-26 15:28:00 --> Language Class Initialized
INFO - 2023-09-26 15:28:00 --> Language Class Initialized
INFO - 2023-09-26 15:28:00 --> Config Class Initialized
INFO - 2023-09-26 15:28:00 --> Loader Class Initialized
INFO - 2023-09-26 15:28:00 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:00 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:00 --> Controller Class Initialized
INFO - 2023-09-26 15:28:00 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:28:00 --> Config Class Initialized
INFO - 2023-09-26 15:28:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:00 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:00 --> URI Class Initialized
INFO - 2023-09-26 15:28:00 --> Router Class Initialized
INFO - 2023-09-26 15:28:00 --> Output Class Initialized
INFO - 2023-09-26 15:28:00 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:00 --> Input Class Initialized
INFO - 2023-09-26 15:28:00 --> Language Class Initialized
INFO - 2023-09-26 15:28:00 --> Language Class Initialized
INFO - 2023-09-26 15:28:00 --> Config Class Initialized
INFO - 2023-09-26 15:28:00 --> Loader Class Initialized
INFO - 2023-09-26 15:28:00 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:00 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:00 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:01 --> Controller Class Initialized
INFO - 2023-09-26 15:28:01 --> Config Class Initialized
INFO - 2023-09-26 15:28:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:01 --> URI Class Initialized
INFO - 2023-09-26 15:28:01 --> Router Class Initialized
INFO - 2023-09-26 15:28:01 --> Output Class Initialized
INFO - 2023-09-26 15:28:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:01 --> Input Class Initialized
INFO - 2023-09-26 15:28:01 --> Language Class Initialized
INFO - 2023-09-26 15:28:01 --> Language Class Initialized
INFO - 2023-09-26 15:28:01 --> Config Class Initialized
INFO - 2023-09-26 15:28:01 --> Loader Class Initialized
INFO - 2023-09-26 15:28:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:01 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:28:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:01 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:01 --> Total execution time: 0.0379
INFO - 2023-09-26 15:28:03 --> Config Class Initialized
INFO - 2023-09-26 15:28:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:03 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:03 --> URI Class Initialized
INFO - 2023-09-26 15:28:03 --> Router Class Initialized
INFO - 2023-09-26 15:28:03 --> Output Class Initialized
INFO - 2023-09-26 15:28:03 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:03 --> Input Class Initialized
INFO - 2023-09-26 15:28:03 --> Language Class Initialized
INFO - 2023-09-26 15:28:03 --> Language Class Initialized
INFO - 2023-09-26 15:28:03 --> Config Class Initialized
INFO - 2023-09-26 15:28:03 --> Loader Class Initialized
INFO - 2023-09-26 15:28:03 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:03 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:03 --> Controller Class Initialized
INFO - 2023-09-26 15:28:03 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:28:03 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:03 --> Total execution time: 0.0435
INFO - 2023-09-26 15:28:03 --> Config Class Initialized
INFO - 2023-09-26 15:28:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:03 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:03 --> URI Class Initialized
INFO - 2023-09-26 15:28:03 --> Router Class Initialized
INFO - 2023-09-26 15:28:03 --> Output Class Initialized
INFO - 2023-09-26 15:28:03 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:03 --> Input Class Initialized
INFO - 2023-09-26 15:28:03 --> Language Class Initialized
INFO - 2023-09-26 15:28:03 --> Language Class Initialized
INFO - 2023-09-26 15:28:03 --> Config Class Initialized
INFO - 2023-09-26 15:28:03 --> Loader Class Initialized
INFO - 2023-09-26 15:28:03 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:03 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:03 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:03 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:03 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:03 --> Total execution time: 0.0420
INFO - 2023-09-26 15:28:05 --> Config Class Initialized
INFO - 2023-09-26 15:28:05 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:05 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:05 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:05 --> URI Class Initialized
INFO - 2023-09-26 15:28:05 --> Router Class Initialized
INFO - 2023-09-26 15:28:05 --> Output Class Initialized
INFO - 2023-09-26 15:28:05 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:05 --> Input Class Initialized
INFO - 2023-09-26 15:28:05 --> Language Class Initialized
INFO - 2023-09-26 15:28:05 --> Language Class Initialized
INFO - 2023-09-26 15:28:05 --> Config Class Initialized
INFO - 2023-09-26 15:28:05 --> Loader Class Initialized
INFO - 2023-09-26 15:28:05 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:05 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:05 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:05 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:05 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:05 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:05 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:05 --> Total execution time: 0.0848
INFO - 2023-09-26 15:28:06 --> Config Class Initialized
INFO - 2023-09-26 15:28:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:06 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:06 --> URI Class Initialized
INFO - 2023-09-26 15:28:06 --> Router Class Initialized
INFO - 2023-09-26 15:28:06 --> Output Class Initialized
INFO - 2023-09-26 15:28:06 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:06 --> Input Class Initialized
INFO - 2023-09-26 15:28:06 --> Language Class Initialized
INFO - 2023-09-26 15:28:06 --> Language Class Initialized
INFO - 2023-09-26 15:28:06 --> Config Class Initialized
INFO - 2023-09-26 15:28:06 --> Loader Class Initialized
INFO - 2023-09-26 15:28:06 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:06 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:06 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:28:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:06 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:06 --> Total execution time: 0.0452
INFO - 2023-09-26 15:28:06 --> Config Class Initialized
INFO - 2023-09-26 15:28:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:06 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:06 --> URI Class Initialized
INFO - 2023-09-26 15:28:06 --> Router Class Initialized
INFO - 2023-09-26 15:28:06 --> Output Class Initialized
INFO - 2023-09-26 15:28:06 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:06 --> Input Class Initialized
INFO - 2023-09-26 15:28:06 --> Language Class Initialized
INFO - 2023-09-26 15:28:06 --> Language Class Initialized
INFO - 2023-09-26 15:28:06 --> Config Class Initialized
INFO - 2023-09-26 15:28:06 --> Loader Class Initialized
INFO - 2023-09-26 15:28:06 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:06 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:06 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:06 --> Controller Class Initialized
INFO - 2023-09-26 15:28:08 --> Config Class Initialized
INFO - 2023-09-26 15:28:08 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:08 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:08 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:08 --> URI Class Initialized
INFO - 2023-09-26 15:28:08 --> Router Class Initialized
INFO - 2023-09-26 15:28:08 --> Output Class Initialized
INFO - 2023-09-26 15:28:08 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:08 --> Input Class Initialized
INFO - 2023-09-26 15:28:08 --> Language Class Initialized
INFO - 2023-09-26 15:28:08 --> Language Class Initialized
INFO - 2023-09-26 15:28:08 --> Config Class Initialized
INFO - 2023-09-26 15:28:08 --> Loader Class Initialized
INFO - 2023-09-26 15:28:08 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:08 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:08 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:08 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:08 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:08 --> Controller Class Initialized
INFO - 2023-09-26 15:28:12 --> Config Class Initialized
INFO - 2023-09-26 15:28:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:12 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:12 --> URI Class Initialized
INFO - 2023-09-26 15:28:12 --> Router Class Initialized
INFO - 2023-09-26 15:28:12 --> Output Class Initialized
INFO - 2023-09-26 15:28:12 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:12 --> Input Class Initialized
INFO - 2023-09-26 15:28:12 --> Language Class Initialized
INFO - 2023-09-26 15:28:12 --> Language Class Initialized
INFO - 2023-09-26 15:28:12 --> Config Class Initialized
INFO - 2023-09-26 15:28:12 --> Loader Class Initialized
INFO - 2023-09-26 15:28:12 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:12 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:12 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:28:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:12 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:12 --> Total execution time: 0.0759
INFO - 2023-09-26 15:28:12 --> Config Class Initialized
INFO - 2023-09-26 15:28:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:12 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:12 --> URI Class Initialized
INFO - 2023-09-26 15:28:12 --> Router Class Initialized
INFO - 2023-09-26 15:28:12 --> Output Class Initialized
INFO - 2023-09-26 15:28:12 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:12 --> Input Class Initialized
INFO - 2023-09-26 15:28:12 --> Language Class Initialized
INFO - 2023-09-26 15:28:12 --> Language Class Initialized
INFO - 2023-09-26 15:28:12 --> Config Class Initialized
INFO - 2023-09-26 15:28:12 --> Loader Class Initialized
INFO - 2023-09-26 15:28:12 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:12 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:12 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:12 --> Controller Class Initialized
INFO - 2023-09-26 15:28:18 --> Config Class Initialized
INFO - 2023-09-26 15:28:18 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:18 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:18 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:18 --> URI Class Initialized
INFO - 2023-09-26 15:28:18 --> Router Class Initialized
INFO - 2023-09-26 15:28:18 --> Output Class Initialized
INFO - 2023-09-26 15:28:18 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:18 --> Input Class Initialized
INFO - 2023-09-26 15:28:18 --> Language Class Initialized
INFO - 2023-09-26 15:28:18 --> Language Class Initialized
INFO - 2023-09-26 15:28:18 --> Config Class Initialized
INFO - 2023-09-26 15:28:18 --> Loader Class Initialized
INFO - 2023-09-26 15:28:18 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:18 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:18 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:18 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:18 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:18 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:28:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:18 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:18 --> Total execution time: 0.0568
INFO - 2023-09-26 15:28:19 --> Config Class Initialized
INFO - 2023-09-26 15:28:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:19 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:19 --> URI Class Initialized
INFO - 2023-09-26 15:28:19 --> Router Class Initialized
INFO - 2023-09-26 15:28:19 --> Output Class Initialized
INFO - 2023-09-26 15:28:19 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:19 --> Input Class Initialized
INFO - 2023-09-26 15:28:19 --> Language Class Initialized
INFO - 2023-09-26 15:28:19 --> Language Class Initialized
INFO - 2023-09-26 15:28:19 --> Config Class Initialized
INFO - 2023-09-26 15:28:19 --> Loader Class Initialized
INFO - 2023-09-26 15:28:19 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:19 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:19 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:19 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:19 --> Total execution time: 0.1291
INFO - 2023-09-26 15:28:19 --> Config Class Initialized
INFO - 2023-09-26 15:28:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:19 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:19 --> URI Class Initialized
INFO - 2023-09-26 15:28:19 --> Router Class Initialized
INFO - 2023-09-26 15:28:19 --> Output Class Initialized
INFO - 2023-09-26 15:28:19 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:19 --> Input Class Initialized
INFO - 2023-09-26 15:28:19 --> Language Class Initialized
INFO - 2023-09-26 15:28:19 --> Language Class Initialized
INFO - 2023-09-26 15:28:19 --> Config Class Initialized
INFO - 2023-09-26 15:28:19 --> Loader Class Initialized
INFO - 2023-09-26 15:28:19 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:19 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:19 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:19 --> Controller Class Initialized
INFO - 2023-09-26 15:28:24 --> Config Class Initialized
INFO - 2023-09-26 15:28:24 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:24 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:24 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:24 --> URI Class Initialized
INFO - 2023-09-26 15:28:24 --> Router Class Initialized
INFO - 2023-09-26 15:28:24 --> Output Class Initialized
INFO - 2023-09-26 15:28:24 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:24 --> Input Class Initialized
INFO - 2023-09-26 15:28:24 --> Language Class Initialized
INFO - 2023-09-26 15:28:24 --> Language Class Initialized
INFO - 2023-09-26 15:28:24 --> Config Class Initialized
INFO - 2023-09-26 15:28:24 --> Loader Class Initialized
INFO - 2023-09-26 15:28:24 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:24 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:24 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:24 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:24 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:24 --> Controller Class Initialized
ERROR - 2023-09-26 15:28:24 --> Severity: Notice --> Undefined offset: 26 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 393
ERROR - 2023-09-26 15:28:24 --> Severity: error --> Exception: Invalid cell coordinate 7 /www/wwwroot/report.mhis.link/bangka/secondary/application/third_party/PHP_Excel/PHPExcel/Cell.php 558
INFO - 2023-09-26 15:28:28 --> Config Class Initialized
INFO - 2023-09-26 15:28:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:28 --> URI Class Initialized
INFO - 2023-09-26 15:28:28 --> Router Class Initialized
INFO - 2023-09-26 15:28:28 --> Output Class Initialized
INFO - 2023-09-26 15:28:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:28 --> Input Class Initialized
INFO - 2023-09-26 15:28:28 --> Language Class Initialized
INFO - 2023-09-26 15:28:28 --> Language Class Initialized
INFO - 2023-09-26 15:28:28 --> Config Class Initialized
INFO - 2023-09-26 15:28:28 --> Loader Class Initialized
INFO - 2023-09-26 15:28:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:28 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:28 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:28 --> Total execution time: 0.0348
INFO - 2023-09-26 15:28:28 --> Config Class Initialized
INFO - 2023-09-26 15:28:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:28 --> URI Class Initialized
INFO - 2023-09-26 15:28:28 --> Router Class Initialized
INFO - 2023-09-26 15:28:28 --> Output Class Initialized
INFO - 2023-09-26 15:28:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:28 --> Input Class Initialized
INFO - 2023-09-26 15:28:28 --> Language Class Initialized
INFO - 2023-09-26 15:28:28 --> Language Class Initialized
INFO - 2023-09-26 15:28:28 --> Config Class Initialized
INFO - 2023-09-26 15:28:28 --> Loader Class Initialized
INFO - 2023-09-26 15:28:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:28 --> Controller Class Initialized
INFO - 2023-09-26 15:28:29 --> Config Class Initialized
INFO - 2023-09-26 15:28:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:29 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:29 --> URI Class Initialized
INFO - 2023-09-26 15:28:29 --> Router Class Initialized
INFO - 2023-09-26 15:28:29 --> Output Class Initialized
INFO - 2023-09-26 15:28:29 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:29 --> Input Class Initialized
INFO - 2023-09-26 15:28:29 --> Language Class Initialized
INFO - 2023-09-26 15:28:29 --> Language Class Initialized
INFO - 2023-09-26 15:28:29 --> Config Class Initialized
INFO - 2023-09-26 15:28:29 --> Loader Class Initialized
INFO - 2023-09-26 15:28:29 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:29 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:29 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:29 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:29 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:29 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:28:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:29 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:29 --> Total execution time: 0.0456
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:35 --> URI Class Initialized
INFO - 2023-09-26 15:28:35 --> Router Class Initialized
INFO - 2023-09-26 15:28:35 --> Output Class Initialized
INFO - 2023-09-26 15:28:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:35 --> Input Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Loader Class Initialized
INFO - 2023-09-26 15:28:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:35 --> Controller Class Initialized
INFO - 2023-09-26 15:28:35 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:35 --> URI Class Initialized
INFO - 2023-09-26 15:28:35 --> Router Class Initialized
INFO - 2023-09-26 15:28:35 --> Output Class Initialized
INFO - 2023-09-26 15:28:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:35 --> Input Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Loader Class Initialized
INFO - 2023-09-26 15:28:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:35 --> Controller Class Initialized
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:35 --> URI Class Initialized
INFO - 2023-09-26 15:28:35 --> Router Class Initialized
INFO - 2023-09-26 15:28:35 --> Output Class Initialized
INFO - 2023-09-26 15:28:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:35 --> Input Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Language Class Initialized
INFO - 2023-09-26 15:28:35 --> Config Class Initialized
INFO - 2023-09-26 15:28:35 --> Loader Class Initialized
INFO - 2023-09-26 15:28:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:35 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:28:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:35 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:35 --> Total execution time: 0.0635
INFO - 2023-09-26 15:28:42 --> Config Class Initialized
INFO - 2023-09-26 15:28:42 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:42 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:42 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:42 --> URI Class Initialized
INFO - 2023-09-26 15:28:42 --> Router Class Initialized
INFO - 2023-09-26 15:28:42 --> Output Class Initialized
INFO - 2023-09-26 15:28:42 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:42 --> Input Class Initialized
INFO - 2023-09-26 15:28:42 --> Language Class Initialized
INFO - 2023-09-26 15:28:42 --> Language Class Initialized
INFO - 2023-09-26 15:28:42 --> Config Class Initialized
INFO - 2023-09-26 15:28:42 --> Loader Class Initialized
INFO - 2023-09-26 15:28:42 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:42 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:42 --> Controller Class Initialized
INFO - 2023-09-26 15:28:42 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:28:42 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:42 --> Total execution time: 0.0357
INFO - 2023-09-26 15:28:42 --> Config Class Initialized
INFO - 2023-09-26 15:28:42 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:42 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:42 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:42 --> URI Class Initialized
INFO - 2023-09-26 15:28:42 --> Router Class Initialized
INFO - 2023-09-26 15:28:42 --> Output Class Initialized
INFO - 2023-09-26 15:28:42 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:42 --> Input Class Initialized
INFO - 2023-09-26 15:28:42 --> Language Class Initialized
INFO - 2023-09-26 15:28:42 --> Language Class Initialized
INFO - 2023-09-26 15:28:42 --> Config Class Initialized
INFO - 2023-09-26 15:28:42 --> Loader Class Initialized
INFO - 2023-09-26 15:28:42 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:42 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:42 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:42 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-26 15:28:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:42 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:42 --> Total execution time: 0.0390
INFO - 2023-09-26 15:28:44 --> Config Class Initialized
INFO - 2023-09-26 15:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:44 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:44 --> URI Class Initialized
INFO - 2023-09-26 15:28:44 --> Router Class Initialized
INFO - 2023-09-26 15:28:44 --> Output Class Initialized
INFO - 2023-09-26 15:28:44 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:44 --> Input Class Initialized
INFO - 2023-09-26 15:28:44 --> Language Class Initialized
INFO - 2023-09-26 15:28:44 --> Language Class Initialized
INFO - 2023-09-26 15:28:44 --> Config Class Initialized
INFO - 2023-09-26 15:28:44 --> Loader Class Initialized
INFO - 2023-09-26 15:28:44 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:44 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:44 --> Controller Class Initialized
DEBUG - 2023-09-26 15:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-09-26 15:28:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:28:44 --> Final output sent to browser
DEBUG - 2023-09-26 15:28:44 --> Total execution time: 0.0362
INFO - 2023-09-26 15:28:44 --> Config Class Initialized
INFO - 2023-09-26 15:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:44 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:44 --> URI Class Initialized
INFO - 2023-09-26 15:28:44 --> Router Class Initialized
INFO - 2023-09-26 15:28:44 --> Output Class Initialized
INFO - 2023-09-26 15:28:44 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:44 --> Input Class Initialized
INFO - 2023-09-26 15:28:44 --> Language Class Initialized
ERROR - 2023-09-26 15:28:44 --> 404 Page Not Found: /index
INFO - 2023-09-26 15:28:44 --> Config Class Initialized
INFO - 2023-09-26 15:28:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:44 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:44 --> URI Class Initialized
INFO - 2023-09-26 15:28:44 --> Router Class Initialized
INFO - 2023-09-26 15:28:44 --> Output Class Initialized
INFO - 2023-09-26 15:28:44 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:44 --> Input Class Initialized
INFO - 2023-09-26 15:28:44 --> Language Class Initialized
INFO - 2023-09-26 15:28:44 --> Language Class Initialized
INFO - 2023-09-26 15:28:44 --> Config Class Initialized
INFO - 2023-09-26 15:28:44 --> Loader Class Initialized
INFO - 2023-09-26 15:28:44 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:44 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:44 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:44 --> Controller Class Initialized
INFO - 2023-09-26 15:28:49 --> Config Class Initialized
INFO - 2023-09-26 15:28:49 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:28:49 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:28:49 --> Utf8 Class Initialized
INFO - 2023-09-26 15:28:49 --> URI Class Initialized
INFO - 2023-09-26 15:28:49 --> Router Class Initialized
INFO - 2023-09-26 15:28:50 --> Output Class Initialized
INFO - 2023-09-26 15:28:50 --> Security Class Initialized
DEBUG - 2023-09-26 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:28:50 --> Input Class Initialized
INFO - 2023-09-26 15:28:50 --> Language Class Initialized
INFO - 2023-09-26 15:28:50 --> Language Class Initialized
INFO - 2023-09-26 15:28:50 --> Config Class Initialized
INFO - 2023-09-26 15:28:50 --> Loader Class Initialized
INFO - 2023-09-26 15:28:50 --> Helper loaded: url_helper
INFO - 2023-09-26 15:28:50 --> Helper loaded: file_helper
INFO - 2023-09-26 15:28:50 --> Helper loaded: form_helper
INFO - 2023-09-26 15:28:50 --> Helper loaded: my_helper
INFO - 2023-09-26 15:28:50 --> Database Driver Class Initialized
INFO - 2023-09-26 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:28:50 --> Controller Class Initialized
INFO - 2023-09-26 15:29:04 --> Config Class Initialized
INFO - 2023-09-26 15:29:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:04 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:04 --> URI Class Initialized
INFO - 2023-09-26 15:29:04 --> Router Class Initialized
INFO - 2023-09-26 15:29:04 --> Output Class Initialized
INFO - 2023-09-26 15:29:04 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:04 --> Input Class Initialized
INFO - 2023-09-26 15:29:04 --> Language Class Initialized
INFO - 2023-09-26 15:29:04 --> Language Class Initialized
INFO - 2023-09-26 15:29:04 --> Config Class Initialized
INFO - 2023-09-26 15:29:04 --> Loader Class Initialized
INFO - 2023-09-26 15:29:04 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:04 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:04 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-09-26 15:29:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:04 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:04 --> Total execution time: 0.0462
INFO - 2023-09-26 15:29:04 --> Config Class Initialized
INFO - 2023-09-26 15:29:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:04 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:04 --> URI Class Initialized
INFO - 2023-09-26 15:29:04 --> Router Class Initialized
INFO - 2023-09-26 15:29:04 --> Output Class Initialized
INFO - 2023-09-26 15:29:04 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:04 --> Input Class Initialized
INFO - 2023-09-26 15:29:04 --> Language Class Initialized
ERROR - 2023-09-26 15:29:04 --> 404 Page Not Found: /index
INFO - 2023-09-26 15:29:04 --> Config Class Initialized
INFO - 2023-09-26 15:29:04 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:04 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:04 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:04 --> URI Class Initialized
INFO - 2023-09-26 15:29:04 --> Router Class Initialized
INFO - 2023-09-26 15:29:04 --> Output Class Initialized
INFO - 2023-09-26 15:29:04 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:04 --> Input Class Initialized
INFO - 2023-09-26 15:29:04 --> Language Class Initialized
INFO - 2023-09-26 15:29:04 --> Language Class Initialized
INFO - 2023-09-26 15:29:04 --> Config Class Initialized
INFO - 2023-09-26 15:29:04 --> Loader Class Initialized
INFO - 2023-09-26 15:29:04 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:04 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:04 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:04 --> Controller Class Initialized
INFO - 2023-09-26 15:29:06 --> Config Class Initialized
INFO - 2023-09-26 15:29:06 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:06 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:06 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:06 --> URI Class Initialized
INFO - 2023-09-26 15:29:06 --> Router Class Initialized
INFO - 2023-09-26 15:29:06 --> Output Class Initialized
INFO - 2023-09-26 15:29:06 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:06 --> Input Class Initialized
INFO - 2023-09-26 15:29:06 --> Language Class Initialized
INFO - 2023-09-26 15:29:06 --> Language Class Initialized
INFO - 2023-09-26 15:29:06 --> Config Class Initialized
INFO - 2023-09-26 15:29:06 --> Loader Class Initialized
INFO - 2023-09-26 15:29:06 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:06 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:06 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:06 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:06 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:06 --> Controller Class Initialized
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:10 --> URI Class Initialized
INFO - 2023-09-26 15:29:10 --> Router Class Initialized
INFO - 2023-09-26 15:29:10 --> Output Class Initialized
INFO - 2023-09-26 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:10 --> Input Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Loader Class Initialized
INFO - 2023-09-26 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:10 --> Controller Class Initialized
INFO - 2023-09-26 15:29:10 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:10 --> URI Class Initialized
INFO - 2023-09-26 15:29:10 --> Router Class Initialized
INFO - 2023-09-26 15:29:10 --> Output Class Initialized
INFO - 2023-09-26 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:10 --> Input Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Loader Class Initialized
INFO - 2023-09-26 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:10 --> Controller Class Initialized
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:10 --> URI Class Initialized
INFO - 2023-09-26 15:29:10 --> Router Class Initialized
INFO - 2023-09-26 15:29:10 --> Output Class Initialized
INFO - 2023-09-26 15:29:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:10 --> Input Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Language Class Initialized
INFO - 2023-09-26 15:29:10 --> Config Class Initialized
INFO - 2023-09-26 15:29:10 --> Loader Class Initialized
INFO - 2023-09-26 15:29:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:10 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:29:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:10 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:10 --> Total execution time: 0.0350
INFO - 2023-09-26 15:29:13 --> Config Class Initialized
INFO - 2023-09-26 15:29:13 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:13 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:13 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:13 --> URI Class Initialized
INFO - 2023-09-26 15:29:13 --> Router Class Initialized
INFO - 2023-09-26 15:29:13 --> Output Class Initialized
INFO - 2023-09-26 15:29:13 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:13 --> Input Class Initialized
INFO - 2023-09-26 15:29:13 --> Language Class Initialized
INFO - 2023-09-26 15:29:13 --> Language Class Initialized
INFO - 2023-09-26 15:29:13 --> Config Class Initialized
INFO - 2023-09-26 15:29:13 --> Loader Class Initialized
INFO - 2023-09-26 15:29:13 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:13 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:13 --> Controller Class Initialized
INFO - 2023-09-26 15:29:13 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:29:13 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:13 --> Total execution time: 0.0362
INFO - 2023-09-26 15:29:13 --> Config Class Initialized
INFO - 2023-09-26 15:29:13 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:13 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:13 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:13 --> URI Class Initialized
INFO - 2023-09-26 15:29:13 --> Router Class Initialized
INFO - 2023-09-26 15:29:13 --> Output Class Initialized
INFO - 2023-09-26 15:29:13 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:13 --> Input Class Initialized
INFO - 2023-09-26 15:29:13 --> Language Class Initialized
INFO - 2023-09-26 15:29:13 --> Language Class Initialized
INFO - 2023-09-26 15:29:13 --> Config Class Initialized
INFO - 2023-09-26 15:29:13 --> Loader Class Initialized
INFO - 2023-09-26 15:29:13 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:13 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:13 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:13 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:13 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:13 --> Total execution time: 0.0348
INFO - 2023-09-26 15:29:16 --> Config Class Initialized
INFO - 2023-09-26 15:29:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:16 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:16 --> URI Class Initialized
INFO - 2023-09-26 15:29:16 --> Router Class Initialized
INFO - 2023-09-26 15:29:16 --> Output Class Initialized
INFO - 2023-09-26 15:29:16 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:16 --> Input Class Initialized
INFO - 2023-09-26 15:29:16 --> Language Class Initialized
INFO - 2023-09-26 15:29:16 --> Language Class Initialized
INFO - 2023-09-26 15:29:16 --> Config Class Initialized
INFO - 2023-09-26 15:29:16 --> Loader Class Initialized
INFO - 2023-09-26 15:29:16 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:16 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:16 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:16 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:16 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:16 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:29:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:16 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:16 --> Total execution time: 0.0358
INFO - 2023-09-26 15:29:17 --> Config Class Initialized
INFO - 2023-09-26 15:29:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:17 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:17 --> URI Class Initialized
INFO - 2023-09-26 15:29:17 --> Router Class Initialized
INFO - 2023-09-26 15:29:17 --> Output Class Initialized
INFO - 2023-09-26 15:29:17 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:17 --> Input Class Initialized
INFO - 2023-09-26 15:29:17 --> Language Class Initialized
INFO - 2023-09-26 15:29:17 --> Language Class Initialized
INFO - 2023-09-26 15:29:17 --> Config Class Initialized
INFO - 2023-09-26 15:29:17 --> Loader Class Initialized
INFO - 2023-09-26 15:29:17 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:17 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:17 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:29:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:17 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:17 --> Total execution time: 0.0380
INFO - 2023-09-26 15:29:17 --> Config Class Initialized
INFO - 2023-09-26 15:29:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:17 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:17 --> URI Class Initialized
INFO - 2023-09-26 15:29:17 --> Router Class Initialized
INFO - 2023-09-26 15:29:17 --> Output Class Initialized
INFO - 2023-09-26 15:29:17 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:17 --> Input Class Initialized
INFO - 2023-09-26 15:29:17 --> Language Class Initialized
INFO - 2023-09-26 15:29:17 --> Language Class Initialized
INFO - 2023-09-26 15:29:17 --> Config Class Initialized
INFO - 2023-09-26 15:29:17 --> Loader Class Initialized
INFO - 2023-09-26 15:29:17 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:17 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:17 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:17 --> Controller Class Initialized
INFO - 2023-09-26 15:29:22 --> Config Class Initialized
INFO - 2023-09-26 15:29:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:22 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:22 --> URI Class Initialized
INFO - 2023-09-26 15:29:22 --> Router Class Initialized
INFO - 2023-09-26 15:29:22 --> Output Class Initialized
INFO - 2023-09-26 15:29:22 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:22 --> Input Class Initialized
INFO - 2023-09-26 15:29:22 --> Language Class Initialized
INFO - 2023-09-26 15:29:22 --> Language Class Initialized
INFO - 2023-09-26 15:29:22 --> Config Class Initialized
INFO - 2023-09-26 15:29:22 --> Loader Class Initialized
INFO - 2023-09-26 15:29:22 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:22 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:22 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:22 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:22 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:22 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:29:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:22 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:22 --> Total execution time: 0.0383
INFO - 2023-09-26 15:29:22 --> Config Class Initialized
INFO - 2023-09-26 15:29:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:22 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:22 --> URI Class Initialized
INFO - 2023-09-26 15:29:23 --> Router Class Initialized
INFO - 2023-09-26 15:29:23 --> Output Class Initialized
INFO - 2023-09-26 15:29:23 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:23 --> Input Class Initialized
INFO - 2023-09-26 15:29:23 --> Language Class Initialized
INFO - 2023-09-26 15:29:23 --> Language Class Initialized
INFO - 2023-09-26 15:29:23 --> Config Class Initialized
INFO - 2023-09-26 15:29:23 --> Loader Class Initialized
INFO - 2023-09-26 15:29:23 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:23 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:23 --> Controller Class Initialized
DEBUG - 2023-09-26 15:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:29:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:29:23 --> Final output sent to browser
DEBUG - 2023-09-26 15:29:23 --> Total execution time: 0.0513
INFO - 2023-09-26 15:29:23 --> Config Class Initialized
INFO - 2023-09-26 15:29:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:29:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:29:23 --> Utf8 Class Initialized
INFO - 2023-09-26 15:29:23 --> URI Class Initialized
INFO - 2023-09-26 15:29:23 --> Router Class Initialized
INFO - 2023-09-26 15:29:23 --> Output Class Initialized
INFO - 2023-09-26 15:29:23 --> Security Class Initialized
DEBUG - 2023-09-26 15:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:29:23 --> Input Class Initialized
INFO - 2023-09-26 15:29:23 --> Language Class Initialized
INFO - 2023-09-26 15:29:23 --> Language Class Initialized
INFO - 2023-09-26 15:29:23 --> Config Class Initialized
INFO - 2023-09-26 15:29:23 --> Loader Class Initialized
INFO - 2023-09-26 15:29:23 --> Helper loaded: url_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: file_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: form_helper
INFO - 2023-09-26 15:29:23 --> Helper loaded: my_helper
INFO - 2023-09-26 15:29:23 --> Database Driver Class Initialized
INFO - 2023-09-26 15:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:29:23 --> Controller Class Initialized
INFO - 2023-09-26 15:52:56 --> Config Class Initialized
INFO - 2023-09-26 15:52:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:52:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:52:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:52:56 --> URI Class Initialized
INFO - 2023-09-26 15:52:56 --> Router Class Initialized
INFO - 2023-09-26 15:52:56 --> Output Class Initialized
INFO - 2023-09-26 15:52:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:52:56 --> Input Class Initialized
INFO - 2023-09-26 15:52:56 --> Language Class Initialized
INFO - 2023-09-26 15:52:56 --> Language Class Initialized
INFO - 2023-09-26 15:52:56 --> Config Class Initialized
INFO - 2023-09-26 15:52:56 --> Loader Class Initialized
INFO - 2023-09-26 15:52:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:52:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:52:56 --> Controller Class Initialized
DEBUG - 2023-09-26 15:52:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:52:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:52:56 --> Final output sent to browser
DEBUG - 2023-09-26 15:52:56 --> Total execution time: 0.0429
INFO - 2023-09-26 15:52:56 --> Config Class Initialized
INFO - 2023-09-26 15:52:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:52:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:52:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:52:56 --> URI Class Initialized
INFO - 2023-09-26 15:52:56 --> Router Class Initialized
INFO - 2023-09-26 15:52:56 --> Output Class Initialized
INFO - 2023-09-26 15:52:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:52:56 --> Input Class Initialized
INFO - 2023-09-26 15:52:56 --> Language Class Initialized
INFO - 2023-09-26 15:52:56 --> Language Class Initialized
INFO - 2023-09-26 15:52:56 --> Config Class Initialized
INFO - 2023-09-26 15:52:56 --> Loader Class Initialized
INFO - 2023-09-26 15:52:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:52:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:52:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:52:56 --> Controller Class Initialized
INFO - 2023-09-26 15:52:58 --> Config Class Initialized
INFO - 2023-09-26 15:52:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:52:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:52:58 --> Utf8 Class Initialized
INFO - 2023-09-26 15:52:58 --> URI Class Initialized
INFO - 2023-09-26 15:52:58 --> Router Class Initialized
INFO - 2023-09-26 15:52:58 --> Output Class Initialized
INFO - 2023-09-26 15:52:58 --> Security Class Initialized
DEBUG - 2023-09-26 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:52:58 --> Input Class Initialized
INFO - 2023-09-26 15:52:58 --> Language Class Initialized
INFO - 2023-09-26 15:52:58 --> Language Class Initialized
INFO - 2023-09-26 15:52:58 --> Config Class Initialized
INFO - 2023-09-26 15:52:58 --> Loader Class Initialized
INFO - 2023-09-26 15:52:58 --> Helper loaded: url_helper
INFO - 2023-09-26 15:52:58 --> Helper loaded: file_helper
INFO - 2023-09-26 15:52:58 --> Helper loaded: form_helper
INFO - 2023-09-26 15:52:58 --> Helper loaded: my_helper
INFO - 2023-09-26 15:52:58 --> Database Driver Class Initialized
INFO - 2023-09-26 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:52:58 --> Controller Class Initialized
INFO - 2023-09-26 15:55:01 --> Config Class Initialized
INFO - 2023-09-26 15:55:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:01 --> URI Class Initialized
DEBUG - 2023-09-26 15:55:01 --> No URI present. Default controller set.
INFO - 2023-09-26 15:55:01 --> Router Class Initialized
INFO - 2023-09-26 15:55:01 --> Output Class Initialized
INFO - 2023-09-26 15:55:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:01 --> Input Class Initialized
INFO - 2023-09-26 15:55:01 --> Language Class Initialized
INFO - 2023-09-26 15:55:01 --> Language Class Initialized
INFO - 2023-09-26 15:55:01 --> Config Class Initialized
INFO - 2023-09-26 15:55:01 --> Loader Class Initialized
INFO - 2023-09-26 15:55:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:02 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:55:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:02 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:02 --> Total execution time: 0.1675
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:05 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:05 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:05 --> URI Class Initialized
INFO - 2023-09-26 15:55:05 --> Router Class Initialized
INFO - 2023-09-26 15:55:05 --> Output Class Initialized
INFO - 2023-09-26 15:55:05 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:05 --> Input Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Loader Class Initialized
INFO - 2023-09-26 15:55:05 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:05 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:05 --> Controller Class Initialized
INFO - 2023-09-26 15:55:05 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:05 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:05 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:05 --> URI Class Initialized
INFO - 2023-09-26 15:55:05 --> Router Class Initialized
INFO - 2023-09-26 15:55:05 --> Output Class Initialized
INFO - 2023-09-26 15:55:05 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:05 --> Input Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Loader Class Initialized
INFO - 2023-09-26 15:55:05 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:05 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:05 --> Controller Class Initialized
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:05 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:05 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:05 --> URI Class Initialized
INFO - 2023-09-26 15:55:05 --> Router Class Initialized
INFO - 2023-09-26 15:55:05 --> Output Class Initialized
INFO - 2023-09-26 15:55:05 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:05 --> Input Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Language Class Initialized
INFO - 2023-09-26 15:55:05 --> Config Class Initialized
INFO - 2023-09-26 15:55:05 --> Loader Class Initialized
INFO - 2023-09-26 15:55:05 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:05 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:05 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:05 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 15:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:05 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:05 --> Total execution time: 0.0895
INFO - 2023-09-26 15:55:10 --> Config Class Initialized
INFO - 2023-09-26 15:55:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:10 --> URI Class Initialized
INFO - 2023-09-26 15:55:10 --> Router Class Initialized
INFO - 2023-09-26 15:55:10 --> Output Class Initialized
INFO - 2023-09-26 15:55:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:10 --> Input Class Initialized
INFO - 2023-09-26 15:55:10 --> Language Class Initialized
INFO - 2023-09-26 15:55:10 --> Language Class Initialized
INFO - 2023-09-26 15:55:10 --> Config Class Initialized
INFO - 2023-09-26 15:55:10 --> Loader Class Initialized
INFO - 2023-09-26 15:55:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:10 --> Controller Class Initialized
INFO - 2023-09-26 15:55:10 --> Helper loaded: cookie_helper
INFO - 2023-09-26 15:55:10 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:10 --> Total execution time: 0.0396
INFO - 2023-09-26 15:55:11 --> Config Class Initialized
INFO - 2023-09-26 15:55:11 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:11 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:11 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:11 --> URI Class Initialized
INFO - 2023-09-26 15:55:11 --> Router Class Initialized
INFO - 2023-09-26 15:55:11 --> Output Class Initialized
INFO - 2023-09-26 15:55:11 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:11 --> Input Class Initialized
INFO - 2023-09-26 15:55:11 --> Language Class Initialized
INFO - 2023-09-26 15:55:11 --> Language Class Initialized
INFO - 2023-09-26 15:55:11 --> Config Class Initialized
INFO - 2023-09-26 15:55:11 --> Loader Class Initialized
INFO - 2023-09-26 15:55:11 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:11 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:11 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:11 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:11 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:11 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 15:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:11 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:11 --> Total execution time: 0.0426
INFO - 2023-09-26 15:55:12 --> Config Class Initialized
INFO - 2023-09-26 15:55:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:12 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:12 --> URI Class Initialized
INFO - 2023-09-26 15:55:12 --> Router Class Initialized
INFO - 2023-09-26 15:55:12 --> Output Class Initialized
INFO - 2023-09-26 15:55:12 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:12 --> Input Class Initialized
INFO - 2023-09-26 15:55:12 --> Language Class Initialized
INFO - 2023-09-26 15:55:12 --> Language Class Initialized
INFO - 2023-09-26 15:55:12 --> Config Class Initialized
INFO - 2023-09-26 15:55:12 --> Loader Class Initialized
INFO - 2023-09-26 15:55:12 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:12 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:12 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:12 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:12 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:12 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:55:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:12 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:12 --> Total execution time: 0.0813
INFO - 2023-09-26 15:55:14 --> Config Class Initialized
INFO - 2023-09-26 15:55:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:14 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:14 --> URI Class Initialized
INFO - 2023-09-26 15:55:14 --> Router Class Initialized
INFO - 2023-09-26 15:55:14 --> Output Class Initialized
INFO - 2023-09-26 15:55:14 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:14 --> Input Class Initialized
INFO - 2023-09-26 15:55:14 --> Language Class Initialized
INFO - 2023-09-26 15:55:14 --> Language Class Initialized
INFO - 2023-09-26 15:55:14 --> Config Class Initialized
INFO - 2023-09-26 15:55:14 --> Loader Class Initialized
INFO - 2023-09-26 15:55:14 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:14 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:14 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:14 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:14 --> Total execution time: 0.0718
INFO - 2023-09-26 15:55:14 --> Config Class Initialized
INFO - 2023-09-26 15:55:14 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:14 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:14 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:14 --> URI Class Initialized
INFO - 2023-09-26 15:55:14 --> Router Class Initialized
INFO - 2023-09-26 15:55:14 --> Output Class Initialized
INFO - 2023-09-26 15:55:14 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:14 --> Input Class Initialized
INFO - 2023-09-26 15:55:14 --> Language Class Initialized
INFO - 2023-09-26 15:55:14 --> Language Class Initialized
INFO - 2023-09-26 15:55:14 --> Config Class Initialized
INFO - 2023-09-26 15:55:14 --> Loader Class Initialized
INFO - 2023-09-26 15:55:14 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:14 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:14 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:14 --> Controller Class Initialized
INFO - 2023-09-26 15:55:15 --> Config Class Initialized
INFO - 2023-09-26 15:55:15 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:15 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:15 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:15 --> URI Class Initialized
INFO - 2023-09-26 15:55:15 --> Router Class Initialized
INFO - 2023-09-26 15:55:15 --> Output Class Initialized
INFO - 2023-09-26 15:55:15 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:15 --> Input Class Initialized
INFO - 2023-09-26 15:55:15 --> Language Class Initialized
INFO - 2023-09-26 15:55:15 --> Language Class Initialized
INFO - 2023-09-26 15:55:15 --> Config Class Initialized
INFO - 2023-09-26 15:55:15 --> Loader Class Initialized
INFO - 2023-09-26 15:55:15 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:15 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:15 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:15 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:15 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:15 --> Controller Class Initialized
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:15 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 568
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 572
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 575
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 15:55:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
INFO - 2023-09-26 15:55:19 --> Config Class Initialized
INFO - 2023-09-26 15:55:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:19 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:19 --> URI Class Initialized
INFO - 2023-09-26 15:55:19 --> Router Class Initialized
INFO - 2023-09-26 15:55:19 --> Output Class Initialized
INFO - 2023-09-26 15:55:19 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:19 --> Input Class Initialized
INFO - 2023-09-26 15:55:19 --> Language Class Initialized
INFO - 2023-09-26 15:55:19 --> Language Class Initialized
INFO - 2023-09-26 15:55:19 --> Config Class Initialized
INFO - 2023-09-26 15:55:19 --> Loader Class Initialized
INFO - 2023-09-26 15:55:19 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:19 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:19 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:19 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:19 --> Total execution time: 0.0504
INFO - 2023-09-26 15:55:19 --> Config Class Initialized
INFO - 2023-09-26 15:55:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:19 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:19 --> URI Class Initialized
INFO - 2023-09-26 15:55:19 --> Router Class Initialized
INFO - 2023-09-26 15:55:19 --> Output Class Initialized
INFO - 2023-09-26 15:55:19 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:19 --> Input Class Initialized
INFO - 2023-09-26 15:55:19 --> Language Class Initialized
INFO - 2023-09-26 15:55:19 --> Language Class Initialized
INFO - 2023-09-26 15:55:19 --> Config Class Initialized
INFO - 2023-09-26 15:55:19 --> Loader Class Initialized
INFO - 2023-09-26 15:55:19 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:19 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:19 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:19 --> Controller Class Initialized
INFO - 2023-09-26 15:55:20 --> Config Class Initialized
INFO - 2023-09-26 15:55:20 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:20 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:20 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:20 --> URI Class Initialized
INFO - 2023-09-26 15:55:20 --> Router Class Initialized
INFO - 2023-09-26 15:55:20 --> Output Class Initialized
INFO - 2023-09-26 15:55:20 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:20 --> Input Class Initialized
INFO - 2023-09-26 15:55:20 --> Language Class Initialized
INFO - 2023-09-26 15:55:20 --> Language Class Initialized
INFO - 2023-09-26 15:55:20 --> Config Class Initialized
INFO - 2023-09-26 15:55:20 --> Loader Class Initialized
INFO - 2023-09-26 15:55:20 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:20 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:20 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:20 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:20 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:20 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:55:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:20 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:20 --> Total execution time: 0.0944
INFO - 2023-09-26 15:55:21 --> Config Class Initialized
INFO - 2023-09-26 15:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:21 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:21 --> URI Class Initialized
INFO - 2023-09-26 15:55:21 --> Router Class Initialized
INFO - 2023-09-26 15:55:21 --> Output Class Initialized
INFO - 2023-09-26 15:55:21 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:21 --> Input Class Initialized
INFO - 2023-09-26 15:55:21 --> Language Class Initialized
INFO - 2023-09-26 15:55:21 --> Language Class Initialized
INFO - 2023-09-26 15:55:21 --> Config Class Initialized
INFO - 2023-09-26 15:55:21 --> Loader Class Initialized
INFO - 2023-09-26 15:55:21 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:21 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:21 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:21 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:21 --> Total execution time: 0.0584
INFO - 2023-09-26 15:55:21 --> Config Class Initialized
INFO - 2023-09-26 15:55:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:21 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:21 --> URI Class Initialized
INFO - 2023-09-26 15:55:21 --> Router Class Initialized
INFO - 2023-09-26 15:55:21 --> Output Class Initialized
INFO - 2023-09-26 15:55:21 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:21 --> Input Class Initialized
INFO - 2023-09-26 15:55:21 --> Language Class Initialized
INFO - 2023-09-26 15:55:21 --> Language Class Initialized
INFO - 2023-09-26 15:55:21 --> Config Class Initialized
INFO - 2023-09-26 15:55:21 --> Loader Class Initialized
INFO - 2023-09-26 15:55:21 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:21 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:21 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:21 --> Controller Class Initialized
INFO - 2023-09-26 15:55:22 --> Config Class Initialized
INFO - 2023-09-26 15:55:22 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:22 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:22 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:22 --> URI Class Initialized
INFO - 2023-09-26 15:55:22 --> Router Class Initialized
INFO - 2023-09-26 15:55:22 --> Output Class Initialized
INFO - 2023-09-26 15:55:22 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:22 --> Input Class Initialized
INFO - 2023-09-26 15:55:22 --> Language Class Initialized
INFO - 2023-09-26 15:55:22 --> Language Class Initialized
INFO - 2023-09-26 15:55:22 --> Config Class Initialized
INFO - 2023-09-26 15:55:22 --> Loader Class Initialized
INFO - 2023-09-26 15:55:22 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:22 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:22 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:22 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:22 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:22 --> Controller Class Initialized
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 568
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 572
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 575
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 15:55:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
INFO - 2023-09-26 15:55:28 --> Config Class Initialized
INFO - 2023-09-26 15:55:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:28 --> URI Class Initialized
INFO - 2023-09-26 15:55:28 --> Router Class Initialized
INFO - 2023-09-26 15:55:28 --> Output Class Initialized
INFO - 2023-09-26 15:55:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:28 --> Input Class Initialized
INFO - 2023-09-26 15:55:28 --> Language Class Initialized
INFO - 2023-09-26 15:55:28 --> Language Class Initialized
INFO - 2023-09-26 15:55:28 --> Config Class Initialized
INFO - 2023-09-26 15:55:28 --> Loader Class Initialized
INFO - 2023-09-26 15:55:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:28 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:28 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:28 --> Total execution time: 0.0523
INFO - 2023-09-26 15:55:28 --> Config Class Initialized
INFO - 2023-09-26 15:55:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:28 --> URI Class Initialized
INFO - 2023-09-26 15:55:28 --> Router Class Initialized
INFO - 2023-09-26 15:55:28 --> Output Class Initialized
INFO - 2023-09-26 15:55:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:28 --> Input Class Initialized
INFO - 2023-09-26 15:55:28 --> Language Class Initialized
INFO - 2023-09-26 15:55:28 --> Language Class Initialized
INFO - 2023-09-26 15:55:28 --> Config Class Initialized
INFO - 2023-09-26 15:55:28 --> Loader Class Initialized
INFO - 2023-09-26 15:55:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:28 --> Controller Class Initialized
INFO - 2023-09-26 15:55:29 --> Config Class Initialized
INFO - 2023-09-26 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:29 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:29 --> URI Class Initialized
INFO - 2023-09-26 15:55:29 --> Router Class Initialized
INFO - 2023-09-26 15:55:29 --> Output Class Initialized
INFO - 2023-09-26 15:55:29 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:29 --> Input Class Initialized
INFO - 2023-09-26 15:55:29 --> Language Class Initialized
INFO - 2023-09-26 15:55:29 --> Language Class Initialized
INFO - 2023-09-26 15:55:29 --> Config Class Initialized
INFO - 2023-09-26 15:55:29 --> Loader Class Initialized
INFO - 2023-09-26 15:55:29 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:29 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:29 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:29 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:29 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:29 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:55:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:29 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:29 --> Total execution time: 0.0969
INFO - 2023-09-26 15:55:31 --> Config Class Initialized
INFO - 2023-09-26 15:55:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:31 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:31 --> URI Class Initialized
INFO - 2023-09-26 15:55:31 --> Router Class Initialized
INFO - 2023-09-26 15:55:31 --> Output Class Initialized
INFO - 2023-09-26 15:55:31 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:31 --> Input Class Initialized
INFO - 2023-09-26 15:55:31 --> Language Class Initialized
INFO - 2023-09-26 15:55:31 --> Language Class Initialized
INFO - 2023-09-26 15:55:31 --> Config Class Initialized
INFO - 2023-09-26 15:55:31 --> Loader Class Initialized
INFO - 2023-09-26 15:55:31 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:31 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:31 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:31 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:31 --> Total execution time: 0.0418
INFO - 2023-09-26 15:55:31 --> Config Class Initialized
INFO - 2023-09-26 15:55:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:31 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:31 --> URI Class Initialized
INFO - 2023-09-26 15:55:31 --> Router Class Initialized
INFO - 2023-09-26 15:55:31 --> Output Class Initialized
INFO - 2023-09-26 15:55:31 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:31 --> Input Class Initialized
INFO - 2023-09-26 15:55:31 --> Language Class Initialized
INFO - 2023-09-26 15:55:31 --> Language Class Initialized
INFO - 2023-09-26 15:55:31 --> Config Class Initialized
INFO - 2023-09-26 15:55:31 --> Loader Class Initialized
INFO - 2023-09-26 15:55:31 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:31 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:31 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:31 --> Controller Class Initialized
INFO - 2023-09-26 15:55:32 --> Config Class Initialized
INFO - 2023-09-26 15:55:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:32 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:32 --> URI Class Initialized
INFO - 2023-09-26 15:55:32 --> Router Class Initialized
INFO - 2023-09-26 15:55:32 --> Output Class Initialized
INFO - 2023-09-26 15:55:32 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:32 --> Input Class Initialized
INFO - 2023-09-26 15:55:32 --> Language Class Initialized
INFO - 2023-09-26 15:55:32 --> Language Class Initialized
INFO - 2023-09-26 15:55:32 --> Config Class Initialized
INFO - 2023-09-26 15:55:32 --> Loader Class Initialized
INFO - 2023-09-26 15:55:32 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:32 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:32 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:32 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:32 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:32 --> Controller Class Initialized
INFO - 2023-09-26 15:55:32 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:32 --> Total execution time: 0.0996
INFO - 2023-09-26 15:55:35 --> Config Class Initialized
INFO - 2023-09-26 15:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:35 --> URI Class Initialized
INFO - 2023-09-26 15:55:35 --> Router Class Initialized
INFO - 2023-09-26 15:55:35 --> Output Class Initialized
INFO - 2023-09-26 15:55:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:35 --> Input Class Initialized
INFO - 2023-09-26 15:55:35 --> Language Class Initialized
INFO - 2023-09-26 15:55:35 --> Language Class Initialized
INFO - 2023-09-26 15:55:35 --> Config Class Initialized
INFO - 2023-09-26 15:55:35 --> Loader Class Initialized
INFO - 2023-09-26 15:55:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:35 --> Controller Class Initialized
INFO - 2023-09-26 15:55:35 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:35 --> Total execution time: 0.0391
INFO - 2023-09-26 15:55:35 --> Config Class Initialized
INFO - 2023-09-26 15:55:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:35 --> URI Class Initialized
INFO - 2023-09-26 15:55:35 --> Router Class Initialized
INFO - 2023-09-26 15:55:35 --> Output Class Initialized
INFO - 2023-09-26 15:55:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:35 --> Input Class Initialized
INFO - 2023-09-26 15:55:35 --> Language Class Initialized
INFO - 2023-09-26 15:55:35 --> Language Class Initialized
INFO - 2023-09-26 15:55:35 --> Config Class Initialized
INFO - 2023-09-26 15:55:35 --> Loader Class Initialized
INFO - 2023-09-26 15:55:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:35 --> Controller Class Initialized
INFO - 2023-09-26 15:55:35 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:35 --> Total execution time: 0.0536
INFO - 2023-09-26 15:55:36 --> Config Class Initialized
INFO - 2023-09-26 15:55:36 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:36 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:36 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:36 --> URI Class Initialized
INFO - 2023-09-26 15:55:36 --> Router Class Initialized
INFO - 2023-09-26 15:55:36 --> Output Class Initialized
INFO - 2023-09-26 15:55:36 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:36 --> Input Class Initialized
INFO - 2023-09-26 15:55:36 --> Language Class Initialized
INFO - 2023-09-26 15:55:36 --> Language Class Initialized
INFO - 2023-09-26 15:55:36 --> Config Class Initialized
INFO - 2023-09-26 15:55:36 --> Loader Class Initialized
INFO - 2023-09-26 15:55:36 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:36 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:36 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:36 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:36 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:36 --> Controller Class Initialized
INFO - 2023-09-26 15:55:36 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:36 --> Total execution time: 0.0404
INFO - 2023-09-26 15:55:39 --> Config Class Initialized
INFO - 2023-09-26 15:55:39 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:39 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:39 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:39 --> URI Class Initialized
INFO - 2023-09-26 15:55:39 --> Router Class Initialized
INFO - 2023-09-26 15:55:39 --> Output Class Initialized
INFO - 2023-09-26 15:55:39 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:39 --> Input Class Initialized
INFO - 2023-09-26 15:55:39 --> Language Class Initialized
INFO - 2023-09-26 15:55:39 --> Language Class Initialized
INFO - 2023-09-26 15:55:39 --> Config Class Initialized
INFO - 2023-09-26 15:55:39 --> Loader Class Initialized
INFO - 2023-09-26 15:55:39 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:39 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:39 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:39 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:39 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:39 --> Controller Class Initialized
INFO - 2023-09-26 15:55:39 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:39 --> Total execution time: 0.1020
INFO - 2023-09-26 15:55:40 --> Config Class Initialized
INFO - 2023-09-26 15:55:40 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:40 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:40 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:40 --> URI Class Initialized
INFO - 2023-09-26 15:55:40 --> Router Class Initialized
INFO - 2023-09-26 15:55:40 --> Output Class Initialized
INFO - 2023-09-26 15:55:40 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:40 --> Input Class Initialized
INFO - 2023-09-26 15:55:40 --> Language Class Initialized
INFO - 2023-09-26 15:55:40 --> Language Class Initialized
INFO - 2023-09-26 15:55:40 --> Config Class Initialized
INFO - 2023-09-26 15:55:40 --> Loader Class Initialized
INFO - 2023-09-26 15:55:40 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:40 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:40 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:40 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:40 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:40 --> Controller Class Initialized
INFO - 2023-09-26 15:55:40 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:40 --> Total execution time: 0.0428
INFO - 2023-09-26 15:55:43 --> Config Class Initialized
INFO - 2023-09-26 15:55:43 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:43 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:43 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:43 --> URI Class Initialized
INFO - 2023-09-26 15:55:43 --> Router Class Initialized
INFO - 2023-09-26 15:55:43 --> Output Class Initialized
INFO - 2023-09-26 15:55:43 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:43 --> Input Class Initialized
INFO - 2023-09-26 15:55:43 --> Language Class Initialized
INFO - 2023-09-26 15:55:43 --> Language Class Initialized
INFO - 2023-09-26 15:55:43 --> Config Class Initialized
INFO - 2023-09-26 15:55:43 --> Loader Class Initialized
INFO - 2023-09-26 15:55:43 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:43 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:43 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:43 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:43 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:43 --> Controller Class Initialized
INFO - 2023-09-26 15:55:43 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:43 --> Total execution time: 0.0398
INFO - 2023-09-26 15:55:49 --> Config Class Initialized
INFO - 2023-09-26 15:55:49 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:49 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:49 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:49 --> URI Class Initialized
INFO - 2023-09-26 15:55:49 --> Router Class Initialized
INFO - 2023-09-26 15:55:49 --> Output Class Initialized
INFO - 2023-09-26 15:55:49 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:49 --> Input Class Initialized
INFO - 2023-09-26 15:55:49 --> Language Class Initialized
INFO - 2023-09-26 15:55:49 --> Language Class Initialized
INFO - 2023-09-26 15:55:49 --> Config Class Initialized
INFO - 2023-09-26 15:55:49 --> Loader Class Initialized
INFO - 2023-09-26 15:55:49 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:49 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:49 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:49 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:49 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:49 --> Controller Class Initialized
INFO - 2023-09-26 15:55:49 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:49 --> Total execution time: 0.0359
INFO - 2023-09-26 15:55:50 --> Config Class Initialized
INFO - 2023-09-26 15:55:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:50 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:50 --> URI Class Initialized
INFO - 2023-09-26 15:55:50 --> Router Class Initialized
INFO - 2023-09-26 15:55:50 --> Output Class Initialized
INFO - 2023-09-26 15:55:50 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:50 --> Input Class Initialized
INFO - 2023-09-26 15:55:50 --> Language Class Initialized
INFO - 2023-09-26 15:55:50 --> Language Class Initialized
INFO - 2023-09-26 15:55:50 --> Config Class Initialized
INFO - 2023-09-26 15:55:50 --> Loader Class Initialized
INFO - 2023-09-26 15:55:50 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:50 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:50 --> Controller Class Initialized
INFO - 2023-09-26 15:55:50 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:50 --> Total execution time: 0.0406
INFO - 2023-09-26 15:55:50 --> Config Class Initialized
INFO - 2023-09-26 15:55:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:50 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:50 --> URI Class Initialized
INFO - 2023-09-26 15:55:50 --> Router Class Initialized
INFO - 2023-09-26 15:55:50 --> Output Class Initialized
INFO - 2023-09-26 15:55:50 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:50 --> Input Class Initialized
INFO - 2023-09-26 15:55:50 --> Language Class Initialized
INFO - 2023-09-26 15:55:50 --> Language Class Initialized
INFO - 2023-09-26 15:55:50 --> Config Class Initialized
INFO - 2023-09-26 15:55:50 --> Loader Class Initialized
INFO - 2023-09-26 15:55:50 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:50 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:50 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:50 --> Controller Class Initialized
INFO - 2023-09-26 15:55:52 --> Config Class Initialized
INFO - 2023-09-26 15:55:52 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:52 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:52 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:52 --> URI Class Initialized
INFO - 2023-09-26 15:55:52 --> Router Class Initialized
INFO - 2023-09-26 15:55:52 --> Output Class Initialized
INFO - 2023-09-26 15:55:52 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:52 --> Input Class Initialized
INFO - 2023-09-26 15:55:52 --> Language Class Initialized
INFO - 2023-09-26 15:55:52 --> Language Class Initialized
INFO - 2023-09-26 15:55:52 --> Config Class Initialized
INFO - 2023-09-26 15:55:52 --> Loader Class Initialized
INFO - 2023-09-26 15:55:52 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:52 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:52 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:52 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:52 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:52 --> Controller Class Initialized
INFO - 2023-09-26 15:55:52 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:52 --> Total execution time: 0.0357
INFO - 2023-09-26 15:55:53 --> Config Class Initialized
INFO - 2023-09-26 15:55:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:53 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:53 --> URI Class Initialized
INFO - 2023-09-26 15:55:53 --> Router Class Initialized
INFO - 2023-09-26 15:55:53 --> Output Class Initialized
INFO - 2023-09-26 15:55:53 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:53 --> Input Class Initialized
INFO - 2023-09-26 15:55:53 --> Language Class Initialized
INFO - 2023-09-26 15:55:53 --> Language Class Initialized
INFO - 2023-09-26 15:55:53 --> Config Class Initialized
INFO - 2023-09-26 15:55:53 --> Loader Class Initialized
INFO - 2023-09-26 15:55:53 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:53 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:53 --> Controller Class Initialized
INFO - 2023-09-26 15:55:53 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:53 --> Total execution time: 0.0378
INFO - 2023-09-26 15:55:53 --> Config Class Initialized
INFO - 2023-09-26 15:55:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:53 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:53 --> URI Class Initialized
INFO - 2023-09-26 15:55:53 --> Router Class Initialized
INFO - 2023-09-26 15:55:53 --> Output Class Initialized
INFO - 2023-09-26 15:55:53 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:53 --> Input Class Initialized
INFO - 2023-09-26 15:55:53 --> Language Class Initialized
INFO - 2023-09-26 15:55:53 --> Language Class Initialized
INFO - 2023-09-26 15:55:53 --> Config Class Initialized
INFO - 2023-09-26 15:55:53 --> Loader Class Initialized
INFO - 2023-09-26 15:55:53 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:53 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:53 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:53 --> Controller Class Initialized
INFO - 2023-09-26 15:55:54 --> Config Class Initialized
INFO - 2023-09-26 15:55:54 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:54 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:54 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:54 --> URI Class Initialized
INFO - 2023-09-26 15:55:54 --> Router Class Initialized
INFO - 2023-09-26 15:55:54 --> Output Class Initialized
INFO - 2023-09-26 15:55:54 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:54 --> Input Class Initialized
INFO - 2023-09-26 15:55:54 --> Language Class Initialized
INFO - 2023-09-26 15:55:54 --> Language Class Initialized
INFO - 2023-09-26 15:55:54 --> Config Class Initialized
INFO - 2023-09-26 15:55:54 --> Loader Class Initialized
INFO - 2023-09-26 15:55:54 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:54 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:54 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:54 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:54 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:54 --> Controller Class Initialized
INFO - 2023-09-26 15:55:54 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:54 --> Total execution time: 0.0386
INFO - 2023-09-26 15:55:55 --> Config Class Initialized
INFO - 2023-09-26 15:55:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:55 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:55 --> URI Class Initialized
INFO - 2023-09-26 15:55:55 --> Router Class Initialized
INFO - 2023-09-26 15:55:55 --> Output Class Initialized
INFO - 2023-09-26 15:55:55 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:55 --> Input Class Initialized
INFO - 2023-09-26 15:55:55 --> Language Class Initialized
INFO - 2023-09-26 15:55:55 --> Language Class Initialized
INFO - 2023-09-26 15:55:55 --> Config Class Initialized
INFO - 2023-09-26 15:55:55 --> Loader Class Initialized
INFO - 2023-09-26 15:55:55 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:55 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:55 --> Controller Class Initialized
INFO - 2023-09-26 15:55:55 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:55 --> Total execution time: 0.1068
INFO - 2023-09-26 15:55:55 --> Config Class Initialized
INFO - 2023-09-26 15:55:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:55 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:55 --> URI Class Initialized
INFO - 2023-09-26 15:55:55 --> Router Class Initialized
INFO - 2023-09-26 15:55:55 --> Output Class Initialized
INFO - 2023-09-26 15:55:55 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:55 --> Input Class Initialized
INFO - 2023-09-26 15:55:55 --> Language Class Initialized
INFO - 2023-09-26 15:55:55 --> Language Class Initialized
INFO - 2023-09-26 15:55:55 --> Config Class Initialized
INFO - 2023-09-26 15:55:55 --> Loader Class Initialized
INFO - 2023-09-26 15:55:55 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:55 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:55 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:55 --> Controller Class Initialized
INFO - 2023-09-26 15:55:56 --> Config Class Initialized
INFO - 2023-09-26 15:55:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:56 --> URI Class Initialized
INFO - 2023-09-26 15:55:56 --> Router Class Initialized
INFO - 2023-09-26 15:55:56 --> Output Class Initialized
INFO - 2023-09-26 15:55:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:56 --> Input Class Initialized
INFO - 2023-09-26 15:55:56 --> Language Class Initialized
INFO - 2023-09-26 15:55:56 --> Language Class Initialized
INFO - 2023-09-26 15:55:56 --> Config Class Initialized
INFO - 2023-09-26 15:55:56 --> Loader Class Initialized
INFO - 2023-09-26 15:55:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:56 --> Controller Class Initialized
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:55:56 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 568
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 572
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 575
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 15:55:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
INFO - 2023-09-26 15:55:58 --> Config Class Initialized
INFO - 2023-09-26 15:55:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:58 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:58 --> URI Class Initialized
INFO - 2023-09-26 15:55:58 --> Router Class Initialized
INFO - 2023-09-26 15:55:58 --> Output Class Initialized
INFO - 2023-09-26 15:55:58 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:58 --> Input Class Initialized
INFO - 2023-09-26 15:55:58 --> Language Class Initialized
INFO - 2023-09-26 15:55:58 --> Language Class Initialized
INFO - 2023-09-26 15:55:58 --> Config Class Initialized
INFO - 2023-09-26 15:55:58 --> Loader Class Initialized
INFO - 2023-09-26 15:55:58 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:58 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:58 --> Controller Class Initialized
DEBUG - 2023-09-26 15:55:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:55:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:55:58 --> Final output sent to browser
DEBUG - 2023-09-26 15:55:58 --> Total execution time: 0.0734
INFO - 2023-09-26 15:55:58 --> Config Class Initialized
INFO - 2023-09-26 15:55:58 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:55:58 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:55:58 --> Utf8 Class Initialized
INFO - 2023-09-26 15:55:58 --> URI Class Initialized
INFO - 2023-09-26 15:55:58 --> Router Class Initialized
INFO - 2023-09-26 15:55:58 --> Output Class Initialized
INFO - 2023-09-26 15:55:58 --> Security Class Initialized
DEBUG - 2023-09-26 15:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:55:58 --> Input Class Initialized
INFO - 2023-09-26 15:55:58 --> Language Class Initialized
INFO - 2023-09-26 15:55:58 --> Language Class Initialized
INFO - 2023-09-26 15:55:58 --> Config Class Initialized
INFO - 2023-09-26 15:55:58 --> Loader Class Initialized
INFO - 2023-09-26 15:55:58 --> Helper loaded: url_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: file_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: form_helper
INFO - 2023-09-26 15:55:58 --> Helper loaded: my_helper
INFO - 2023-09-26 15:55:58 --> Database Driver Class Initialized
INFO - 2023-09-26 15:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:55:58 --> Controller Class Initialized
INFO - 2023-09-26 15:56:00 --> Config Class Initialized
INFO - 2023-09-26 15:56:00 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:00 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:00 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:00 --> URI Class Initialized
INFO - 2023-09-26 15:56:00 --> Router Class Initialized
INFO - 2023-09-26 15:56:00 --> Output Class Initialized
INFO - 2023-09-26 15:56:00 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:00 --> Input Class Initialized
INFO - 2023-09-26 15:56:00 --> Language Class Initialized
INFO - 2023-09-26 15:56:00 --> Language Class Initialized
INFO - 2023-09-26 15:56:00 --> Config Class Initialized
INFO - 2023-09-26 15:56:00 --> Loader Class Initialized
INFO - 2023-09-26 15:56:00 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:00 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:00 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:00 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:00 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:00 --> Controller Class Initialized
INFO - 2023-09-26 15:56:00 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:00 --> Total execution time: 0.0401
INFO - 2023-09-26 15:56:05 --> Config Class Initialized
INFO - 2023-09-26 15:56:05 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:05 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:05 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:05 --> URI Class Initialized
INFO - 2023-09-26 15:56:05 --> Router Class Initialized
INFO - 2023-09-26 15:56:05 --> Output Class Initialized
INFO - 2023-09-26 15:56:05 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:05 --> Input Class Initialized
INFO - 2023-09-26 15:56:05 --> Language Class Initialized
INFO - 2023-09-26 15:56:05 --> Language Class Initialized
INFO - 2023-09-26 15:56:05 --> Config Class Initialized
INFO - 2023-09-26 15:56:05 --> Loader Class Initialized
INFO - 2023-09-26 15:56:05 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:05 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:05 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:05 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:05 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:05 --> Controller Class Initialized
INFO - 2023-09-26 15:56:05 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:05 --> Total execution time: 0.0898
INFO - 2023-09-26 15:56:10 --> Config Class Initialized
INFO - 2023-09-26 15:56:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:10 --> URI Class Initialized
INFO - 2023-09-26 15:56:10 --> Router Class Initialized
INFO - 2023-09-26 15:56:10 --> Output Class Initialized
INFO - 2023-09-26 15:56:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:10 --> Input Class Initialized
INFO - 2023-09-26 15:56:10 --> Language Class Initialized
INFO - 2023-09-26 15:56:10 --> Language Class Initialized
INFO - 2023-09-26 15:56:10 --> Config Class Initialized
INFO - 2023-09-26 15:56:10 --> Loader Class Initialized
INFO - 2023-09-26 15:56:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:10 --> Controller Class Initialized
INFO - 2023-09-26 15:56:10 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:10 --> Total execution time: 0.0475
INFO - 2023-09-26 15:56:10 --> Config Class Initialized
INFO - 2023-09-26 15:56:10 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:10 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:10 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:10 --> URI Class Initialized
INFO - 2023-09-26 15:56:10 --> Router Class Initialized
INFO - 2023-09-26 15:56:10 --> Output Class Initialized
INFO - 2023-09-26 15:56:10 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:10 --> Input Class Initialized
INFO - 2023-09-26 15:56:10 --> Language Class Initialized
INFO - 2023-09-26 15:56:10 --> Language Class Initialized
INFO - 2023-09-26 15:56:10 --> Config Class Initialized
INFO - 2023-09-26 15:56:10 --> Loader Class Initialized
INFO - 2023-09-26 15:56:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:10 --> Controller Class Initialized
INFO - 2023-09-26 15:56:12 --> Config Class Initialized
INFO - 2023-09-26 15:56:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:12 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:12 --> URI Class Initialized
INFO - 2023-09-26 15:56:12 --> Router Class Initialized
INFO - 2023-09-26 15:56:12 --> Output Class Initialized
INFO - 2023-09-26 15:56:12 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:12 --> Input Class Initialized
INFO - 2023-09-26 15:56:12 --> Language Class Initialized
INFO - 2023-09-26 15:56:12 --> Language Class Initialized
INFO - 2023-09-26 15:56:12 --> Config Class Initialized
INFO - 2023-09-26 15:56:12 --> Loader Class Initialized
INFO - 2023-09-26 15:56:12 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:12 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:12 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:12 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:12 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:12 --> Controller Class Initialized
INFO - 2023-09-26 15:56:12 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:12 --> Total execution time: 0.0830
INFO - 2023-09-26 15:56:17 --> Config Class Initialized
INFO - 2023-09-26 15:56:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:17 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:17 --> URI Class Initialized
INFO - 2023-09-26 15:56:17 --> Router Class Initialized
INFO - 2023-09-26 15:56:17 --> Output Class Initialized
INFO - 2023-09-26 15:56:17 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:17 --> Input Class Initialized
INFO - 2023-09-26 15:56:17 --> Language Class Initialized
INFO - 2023-09-26 15:56:17 --> Language Class Initialized
INFO - 2023-09-26 15:56:17 --> Config Class Initialized
INFO - 2023-09-26 15:56:17 --> Loader Class Initialized
INFO - 2023-09-26 15:56:17 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:17 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:17 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:17 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:17 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:17 --> Controller Class Initialized
INFO - 2023-09-26 15:56:17 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:17 --> Total execution time: 0.0417
INFO - 2023-09-26 15:56:21 --> Config Class Initialized
INFO - 2023-09-26 15:56:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:21 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:21 --> URI Class Initialized
INFO - 2023-09-26 15:56:21 --> Router Class Initialized
INFO - 2023-09-26 15:56:21 --> Output Class Initialized
INFO - 2023-09-26 15:56:21 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:21 --> Input Class Initialized
INFO - 2023-09-26 15:56:21 --> Language Class Initialized
INFO - 2023-09-26 15:56:21 --> Language Class Initialized
INFO - 2023-09-26 15:56:21 --> Config Class Initialized
INFO - 2023-09-26 15:56:21 --> Loader Class Initialized
INFO - 2023-09-26 15:56:21 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:21 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:21 --> Controller Class Initialized
INFO - 2023-09-26 15:56:21 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:21 --> Total execution time: 0.1332
INFO - 2023-09-26 15:56:21 --> Config Class Initialized
INFO - 2023-09-26 15:56:21 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:21 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:21 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:21 --> URI Class Initialized
INFO - 2023-09-26 15:56:21 --> Router Class Initialized
INFO - 2023-09-26 15:56:21 --> Output Class Initialized
INFO - 2023-09-26 15:56:21 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:21 --> Input Class Initialized
INFO - 2023-09-26 15:56:21 --> Language Class Initialized
INFO - 2023-09-26 15:56:21 --> Language Class Initialized
INFO - 2023-09-26 15:56:21 --> Config Class Initialized
INFO - 2023-09-26 15:56:21 --> Loader Class Initialized
INFO - 2023-09-26 15:56:21 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:21 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:21 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:21 --> Controller Class Initialized
INFO - 2023-09-26 15:56:23 --> Config Class Initialized
INFO - 2023-09-26 15:56:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:23 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:23 --> URI Class Initialized
INFO - 2023-09-26 15:56:23 --> Router Class Initialized
INFO - 2023-09-26 15:56:23 --> Output Class Initialized
INFO - 2023-09-26 15:56:23 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:23 --> Input Class Initialized
INFO - 2023-09-26 15:56:23 --> Language Class Initialized
INFO - 2023-09-26 15:56:23 --> Language Class Initialized
INFO - 2023-09-26 15:56:23 --> Config Class Initialized
INFO - 2023-09-26 15:56:23 --> Loader Class Initialized
INFO - 2023-09-26 15:56:23 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:23 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:23 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:23 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:23 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:23 --> Controller Class Initialized
INFO - 2023-09-26 15:56:23 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:23 --> Total execution time: 0.0589
INFO - 2023-09-26 15:56:38 --> Config Class Initialized
INFO - 2023-09-26 15:56:38 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:38 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:38 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:38 --> URI Class Initialized
INFO - 2023-09-26 15:56:38 --> Router Class Initialized
INFO - 2023-09-26 15:56:38 --> Output Class Initialized
INFO - 2023-09-26 15:56:38 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:38 --> Input Class Initialized
INFO - 2023-09-26 15:56:38 --> Language Class Initialized
INFO - 2023-09-26 15:56:38 --> Language Class Initialized
INFO - 2023-09-26 15:56:38 --> Config Class Initialized
INFO - 2023-09-26 15:56:38 --> Loader Class Initialized
INFO - 2023-09-26 15:56:38 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:38 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:38 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:38 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:38 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:38 --> Controller Class Initialized
INFO - 2023-09-26 15:56:38 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:38 --> Total execution time: 0.0389
INFO - 2023-09-26 15:56:44 --> Config Class Initialized
INFO - 2023-09-26 15:56:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:44 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:44 --> URI Class Initialized
INFO - 2023-09-26 15:56:44 --> Router Class Initialized
INFO - 2023-09-26 15:56:44 --> Output Class Initialized
INFO - 2023-09-26 15:56:44 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:44 --> Input Class Initialized
INFO - 2023-09-26 15:56:44 --> Language Class Initialized
INFO - 2023-09-26 15:56:44 --> Language Class Initialized
INFO - 2023-09-26 15:56:44 --> Config Class Initialized
INFO - 2023-09-26 15:56:44 --> Loader Class Initialized
INFO - 2023-09-26 15:56:44 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:44 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:44 --> Controller Class Initialized
INFO - 2023-09-26 15:56:44 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:44 --> Total execution time: 0.0402
INFO - 2023-09-26 15:56:44 --> Config Class Initialized
INFO - 2023-09-26 15:56:44 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:44 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:44 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:44 --> URI Class Initialized
INFO - 2023-09-26 15:56:44 --> Router Class Initialized
INFO - 2023-09-26 15:56:44 --> Output Class Initialized
INFO - 2023-09-26 15:56:44 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:44 --> Input Class Initialized
INFO - 2023-09-26 15:56:44 --> Language Class Initialized
INFO - 2023-09-26 15:56:44 --> Language Class Initialized
INFO - 2023-09-26 15:56:44 --> Config Class Initialized
INFO - 2023-09-26 15:56:44 --> Loader Class Initialized
INFO - 2023-09-26 15:56:44 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:44 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:44 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:44 --> Controller Class Initialized
INFO - 2023-09-26 15:56:45 --> Config Class Initialized
INFO - 2023-09-26 15:56:45 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:45 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:45 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:45 --> URI Class Initialized
INFO - 2023-09-26 15:56:45 --> Router Class Initialized
INFO - 2023-09-26 15:56:45 --> Output Class Initialized
INFO - 2023-09-26 15:56:45 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:45 --> Input Class Initialized
INFO - 2023-09-26 15:56:45 --> Language Class Initialized
INFO - 2023-09-26 15:56:45 --> Language Class Initialized
INFO - 2023-09-26 15:56:45 --> Config Class Initialized
INFO - 2023-09-26 15:56:45 --> Loader Class Initialized
INFO - 2023-09-26 15:56:45 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:45 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:45 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:45 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:45 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:45 --> Controller Class Initialized
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 460
ERROR - 2023-09-26 15:56:45 --> Severity: Notice --> Undefined offset: 1 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 461
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 568
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 569
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 570
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 572
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 575
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 576
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 577
ERROR - 2023-09-26 15:56:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /www/wwwroot/report.mhis.link/bangka/secondary/system/core/Exceptions.php:271) /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 578
INFO - 2023-09-26 15:56:47 --> Config Class Initialized
INFO - 2023-09-26 15:56:47 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:47 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:47 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:47 --> URI Class Initialized
INFO - 2023-09-26 15:56:47 --> Router Class Initialized
INFO - 2023-09-26 15:56:47 --> Output Class Initialized
INFO - 2023-09-26 15:56:47 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:47 --> Input Class Initialized
INFO - 2023-09-26 15:56:47 --> Language Class Initialized
INFO - 2023-09-26 15:56:47 --> Language Class Initialized
INFO - 2023-09-26 15:56:47 --> Config Class Initialized
INFO - 2023-09-26 15:56:47 --> Loader Class Initialized
INFO - 2023-09-26 15:56:47 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:47 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:47 --> Controller Class Initialized
DEBUG - 2023-09-26 15:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:56:47 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:47 --> Total execution time: 0.0417
INFO - 2023-09-26 15:56:47 --> Config Class Initialized
INFO - 2023-09-26 15:56:47 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:47 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:47 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:47 --> URI Class Initialized
INFO - 2023-09-26 15:56:47 --> Router Class Initialized
INFO - 2023-09-26 15:56:47 --> Output Class Initialized
INFO - 2023-09-26 15:56:47 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:47 --> Input Class Initialized
INFO - 2023-09-26 15:56:47 --> Language Class Initialized
INFO - 2023-09-26 15:56:47 --> Language Class Initialized
INFO - 2023-09-26 15:56:47 --> Config Class Initialized
INFO - 2023-09-26 15:56:47 --> Loader Class Initialized
INFO - 2023-09-26 15:56:47 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:47 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:47 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:47 --> Controller Class Initialized
INFO - 2023-09-26 15:56:50 --> Config Class Initialized
INFO - 2023-09-26 15:56:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:50 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:50 --> URI Class Initialized
INFO - 2023-09-26 15:56:50 --> Router Class Initialized
INFO - 2023-09-26 15:56:50 --> Output Class Initialized
INFO - 2023-09-26 15:56:50 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:50 --> Input Class Initialized
INFO - 2023-09-26 15:56:50 --> Language Class Initialized
INFO - 2023-09-26 15:56:50 --> Language Class Initialized
INFO - 2023-09-26 15:56:50 --> Config Class Initialized
INFO - 2023-09-26 15:56:50 --> Loader Class Initialized
INFO - 2023-09-26 15:56:50 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:50 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:50 --> Controller Class Initialized
INFO - 2023-09-26 15:56:50 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:50 --> Total execution time: 0.0658
INFO - 2023-09-26 15:56:50 --> Config Class Initialized
INFO - 2023-09-26 15:56:50 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:50 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:50 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:50 --> URI Class Initialized
INFO - 2023-09-26 15:56:50 --> Router Class Initialized
INFO - 2023-09-26 15:56:50 --> Output Class Initialized
INFO - 2023-09-26 15:56:50 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:50 --> Input Class Initialized
INFO - 2023-09-26 15:56:50 --> Language Class Initialized
INFO - 2023-09-26 15:56:50 --> Language Class Initialized
INFO - 2023-09-26 15:56:50 --> Config Class Initialized
INFO - 2023-09-26 15:56:50 --> Loader Class Initialized
INFO - 2023-09-26 15:56:50 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:50 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:50 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:50 --> Controller Class Initialized
INFO - 2023-09-26 15:56:52 --> Config Class Initialized
INFO - 2023-09-26 15:56:52 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:52 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:52 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:52 --> URI Class Initialized
INFO - 2023-09-26 15:56:52 --> Router Class Initialized
INFO - 2023-09-26 15:56:52 --> Output Class Initialized
INFO - 2023-09-26 15:56:52 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:52 --> Input Class Initialized
INFO - 2023-09-26 15:56:52 --> Language Class Initialized
INFO - 2023-09-26 15:56:52 --> Language Class Initialized
INFO - 2023-09-26 15:56:52 --> Config Class Initialized
INFO - 2023-09-26 15:56:52 --> Loader Class Initialized
INFO - 2023-09-26 15:56:52 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:52 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:52 --> Controller Class Initialized
INFO - 2023-09-26 15:56:52 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:52 --> Total execution time: 0.0548
INFO - 2023-09-26 15:56:52 --> Config Class Initialized
INFO - 2023-09-26 15:56:52 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:52 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:52 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:52 --> URI Class Initialized
INFO - 2023-09-26 15:56:52 --> Router Class Initialized
INFO - 2023-09-26 15:56:52 --> Output Class Initialized
INFO - 2023-09-26 15:56:52 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:52 --> Input Class Initialized
INFO - 2023-09-26 15:56:52 --> Language Class Initialized
INFO - 2023-09-26 15:56:52 --> Language Class Initialized
INFO - 2023-09-26 15:56:52 --> Config Class Initialized
INFO - 2023-09-26 15:56:52 --> Loader Class Initialized
INFO - 2023-09-26 15:56:52 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:52 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:52 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:52 --> Controller Class Initialized
INFO - 2023-09-26 15:56:55 --> Config Class Initialized
INFO - 2023-09-26 15:56:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:55 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:55 --> URI Class Initialized
INFO - 2023-09-26 15:56:55 --> Router Class Initialized
INFO - 2023-09-26 15:56:55 --> Output Class Initialized
INFO - 2023-09-26 15:56:55 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:55 --> Input Class Initialized
INFO - 2023-09-26 15:56:55 --> Language Class Initialized
INFO - 2023-09-26 15:56:55 --> Language Class Initialized
INFO - 2023-09-26 15:56:55 --> Config Class Initialized
INFO - 2023-09-26 15:56:55 --> Loader Class Initialized
INFO - 2023-09-26 15:56:55 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:55 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:55 --> Controller Class Initialized
INFO - 2023-09-26 15:56:55 --> Final output sent to browser
DEBUG - 2023-09-26 15:56:55 --> Total execution time: 0.1016
INFO - 2023-09-26 15:56:55 --> Config Class Initialized
INFO - 2023-09-26 15:56:55 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:55 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:55 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:55 --> URI Class Initialized
INFO - 2023-09-26 15:56:55 --> Router Class Initialized
INFO - 2023-09-26 15:56:55 --> Output Class Initialized
INFO - 2023-09-26 15:56:55 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:55 --> Input Class Initialized
INFO - 2023-09-26 15:56:55 --> Language Class Initialized
INFO - 2023-09-26 15:56:55 --> Language Class Initialized
INFO - 2023-09-26 15:56:55 --> Config Class Initialized
INFO - 2023-09-26 15:56:55 --> Loader Class Initialized
INFO - 2023-09-26 15:56:55 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:55 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:55 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:55 --> Controller Class Initialized
INFO - 2023-09-26 15:56:56 --> Config Class Initialized
INFO - 2023-09-26 15:56:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:56:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:56:56 --> Utf8 Class Initialized
INFO - 2023-09-26 15:56:56 --> URI Class Initialized
INFO - 2023-09-26 15:56:56 --> Router Class Initialized
INFO - 2023-09-26 15:56:56 --> Output Class Initialized
INFO - 2023-09-26 15:56:56 --> Security Class Initialized
DEBUG - 2023-09-26 15:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:56:56 --> Input Class Initialized
INFO - 2023-09-26 15:56:56 --> Language Class Initialized
INFO - 2023-09-26 15:56:56 --> Language Class Initialized
INFO - 2023-09-26 15:56:56 --> Config Class Initialized
INFO - 2023-09-26 15:56:56 --> Loader Class Initialized
INFO - 2023-09-26 15:56:56 --> Helper loaded: url_helper
INFO - 2023-09-26 15:56:56 --> Helper loaded: file_helper
INFO - 2023-09-26 15:56:56 --> Helper loaded: form_helper
INFO - 2023-09-26 15:56:56 --> Helper loaded: my_helper
INFO - 2023-09-26 15:56:56 --> Database Driver Class Initialized
INFO - 2023-09-26 15:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:56:56 --> Controller Class Initialized
INFO - 2023-09-26 15:57:01 --> Config Class Initialized
INFO - 2023-09-26 15:57:01 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:01 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:01 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:01 --> URI Class Initialized
INFO - 2023-09-26 15:57:01 --> Router Class Initialized
INFO - 2023-09-26 15:57:01 --> Output Class Initialized
INFO - 2023-09-26 15:57:01 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:01 --> Input Class Initialized
INFO - 2023-09-26 15:57:01 --> Language Class Initialized
INFO - 2023-09-26 15:57:01 --> Language Class Initialized
INFO - 2023-09-26 15:57:01 --> Config Class Initialized
INFO - 2023-09-26 15:57:01 --> Loader Class Initialized
INFO - 2023-09-26 15:57:01 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:01 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:01 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:01 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:01 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:01 --> Controller Class Initialized
DEBUG - 2023-09-26 15:57:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 15:57:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:57:01 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:01 --> Total execution time: 0.1761
INFO - 2023-09-26 15:57:02 --> Config Class Initialized
INFO - 2023-09-26 15:57:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:02 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:02 --> URI Class Initialized
INFO - 2023-09-26 15:57:02 --> Router Class Initialized
INFO - 2023-09-26 15:57:02 --> Output Class Initialized
INFO - 2023-09-26 15:57:02 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:02 --> Input Class Initialized
INFO - 2023-09-26 15:57:02 --> Language Class Initialized
INFO - 2023-09-26 15:57:02 --> Language Class Initialized
INFO - 2023-09-26 15:57:02 --> Config Class Initialized
INFO - 2023-09-26 15:57:02 --> Loader Class Initialized
INFO - 2023-09-26 15:57:02 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:02 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:02 --> Controller Class Initialized
DEBUG - 2023-09-26 15:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 15:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 15:57:02 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:02 --> Total execution time: 0.1052
INFO - 2023-09-26 15:57:02 --> Config Class Initialized
INFO - 2023-09-26 15:57:02 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:02 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:02 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:02 --> URI Class Initialized
INFO - 2023-09-26 15:57:02 --> Router Class Initialized
INFO - 2023-09-26 15:57:02 --> Output Class Initialized
INFO - 2023-09-26 15:57:02 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:02 --> Input Class Initialized
INFO - 2023-09-26 15:57:02 --> Language Class Initialized
INFO - 2023-09-26 15:57:02 --> Language Class Initialized
INFO - 2023-09-26 15:57:02 --> Config Class Initialized
INFO - 2023-09-26 15:57:02 --> Loader Class Initialized
INFO - 2023-09-26 15:57:02 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:02 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:02 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:02 --> Controller Class Initialized
INFO - 2023-09-26 15:57:03 --> Config Class Initialized
INFO - 2023-09-26 15:57:03 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:03 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:03 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:03 --> URI Class Initialized
INFO - 2023-09-26 15:57:03 --> Router Class Initialized
INFO - 2023-09-26 15:57:03 --> Output Class Initialized
INFO - 2023-09-26 15:57:03 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:03 --> Input Class Initialized
INFO - 2023-09-26 15:57:03 --> Language Class Initialized
INFO - 2023-09-26 15:57:03 --> Language Class Initialized
INFO - 2023-09-26 15:57:03 --> Config Class Initialized
INFO - 2023-09-26 15:57:03 --> Loader Class Initialized
INFO - 2023-09-26 15:57:03 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:03 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:03 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:03 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:03 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:03 --> Controller Class Initialized
INFO - 2023-09-26 15:57:03 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:03 --> Total execution time: 0.0411
INFO - 2023-09-26 15:57:09 --> Config Class Initialized
INFO - 2023-09-26 15:57:09 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:09 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:09 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:09 --> URI Class Initialized
INFO - 2023-09-26 15:57:09 --> Router Class Initialized
INFO - 2023-09-26 15:57:09 --> Output Class Initialized
INFO - 2023-09-26 15:57:09 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:09 --> Input Class Initialized
INFO - 2023-09-26 15:57:09 --> Language Class Initialized
INFO - 2023-09-26 15:57:10 --> Language Class Initialized
INFO - 2023-09-26 15:57:10 --> Config Class Initialized
INFO - 2023-09-26 15:57:10 --> Loader Class Initialized
INFO - 2023-09-26 15:57:10 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:10 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:10 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:10 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:10 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:10 --> Controller Class Initialized
INFO - 2023-09-26 15:57:10 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:10 --> Total execution time: 0.0507
INFO - 2023-09-26 15:57:12 --> Config Class Initialized
INFO - 2023-09-26 15:57:12 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:12 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:12 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:12 --> URI Class Initialized
INFO - 2023-09-26 15:57:12 --> Router Class Initialized
INFO - 2023-09-26 15:57:12 --> Output Class Initialized
INFO - 2023-09-26 15:57:12 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:12 --> Input Class Initialized
INFO - 2023-09-26 15:57:12 --> Language Class Initialized
INFO - 2023-09-26 15:57:12 --> Language Class Initialized
INFO - 2023-09-26 15:57:12 --> Config Class Initialized
INFO - 2023-09-26 15:57:12 --> Loader Class Initialized
INFO - 2023-09-26 15:57:12 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:12 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:12 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:12 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:12 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:12 --> Controller Class Initialized
INFO - 2023-09-26 15:57:12 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:12 --> Total execution time: 0.0356
INFO - 2023-09-26 15:57:16 --> Config Class Initialized
INFO - 2023-09-26 15:57:16 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:16 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:16 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:16 --> URI Class Initialized
INFO - 2023-09-26 15:57:16 --> Router Class Initialized
INFO - 2023-09-26 15:57:16 --> Output Class Initialized
INFO - 2023-09-26 15:57:16 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:16 --> Input Class Initialized
INFO - 2023-09-26 15:57:16 --> Language Class Initialized
INFO - 2023-09-26 15:57:16 --> Language Class Initialized
INFO - 2023-09-26 15:57:16 --> Config Class Initialized
INFO - 2023-09-26 15:57:16 --> Loader Class Initialized
INFO - 2023-09-26 15:57:17 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:17 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:17 --> Controller Class Initialized
INFO - 2023-09-26 15:57:17 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:17 --> Total execution time: 0.0972
INFO - 2023-09-26 15:57:17 --> Config Class Initialized
INFO - 2023-09-26 15:57:17 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:17 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:17 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:17 --> URI Class Initialized
INFO - 2023-09-26 15:57:17 --> Router Class Initialized
INFO - 2023-09-26 15:57:17 --> Output Class Initialized
INFO - 2023-09-26 15:57:17 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:17 --> Input Class Initialized
INFO - 2023-09-26 15:57:17 --> Language Class Initialized
INFO - 2023-09-26 15:57:17 --> Language Class Initialized
INFO - 2023-09-26 15:57:17 --> Config Class Initialized
INFO - 2023-09-26 15:57:17 --> Loader Class Initialized
INFO - 2023-09-26 15:57:17 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:17 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:17 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:17 --> Controller Class Initialized
INFO - 2023-09-26 15:57:19 --> Config Class Initialized
INFO - 2023-09-26 15:57:19 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:19 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:19 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:19 --> URI Class Initialized
INFO - 2023-09-26 15:57:19 --> Router Class Initialized
INFO - 2023-09-26 15:57:19 --> Output Class Initialized
INFO - 2023-09-26 15:57:19 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:19 --> Input Class Initialized
INFO - 2023-09-26 15:57:19 --> Language Class Initialized
INFO - 2023-09-26 15:57:19 --> Language Class Initialized
INFO - 2023-09-26 15:57:19 --> Config Class Initialized
INFO - 2023-09-26 15:57:19 --> Loader Class Initialized
INFO - 2023-09-26 15:57:19 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:19 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:19 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:19 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:19 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:19 --> Controller Class Initialized
INFO - 2023-09-26 15:57:19 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:19 --> Total execution time: 0.0559
INFO - 2023-09-26 15:57:23 --> Config Class Initialized
INFO - 2023-09-26 15:57:23 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:23 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:23 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:23 --> URI Class Initialized
INFO - 2023-09-26 15:57:23 --> Router Class Initialized
INFO - 2023-09-26 15:57:23 --> Output Class Initialized
INFO - 2023-09-26 15:57:23 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:23 --> Input Class Initialized
INFO - 2023-09-26 15:57:23 --> Language Class Initialized
INFO - 2023-09-26 15:57:23 --> Language Class Initialized
INFO - 2023-09-26 15:57:23 --> Config Class Initialized
INFO - 2023-09-26 15:57:23 --> Loader Class Initialized
INFO - 2023-09-26 15:57:23 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:23 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:23 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:23 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:23 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:23 --> Controller Class Initialized
INFO - 2023-09-26 15:57:23 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:23 --> Total execution time: 0.0345
INFO - 2023-09-26 15:57:28 --> Config Class Initialized
INFO - 2023-09-26 15:57:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:28 --> URI Class Initialized
INFO - 2023-09-26 15:57:28 --> Router Class Initialized
INFO - 2023-09-26 15:57:28 --> Output Class Initialized
INFO - 2023-09-26 15:57:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:28 --> Input Class Initialized
INFO - 2023-09-26 15:57:28 --> Language Class Initialized
INFO - 2023-09-26 15:57:28 --> Language Class Initialized
INFO - 2023-09-26 15:57:28 --> Config Class Initialized
INFO - 2023-09-26 15:57:28 --> Loader Class Initialized
INFO - 2023-09-26 15:57:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:28 --> Controller Class Initialized
INFO - 2023-09-26 15:57:28 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:28 --> Total execution time: 0.0562
INFO - 2023-09-26 15:57:28 --> Config Class Initialized
INFO - 2023-09-26 15:57:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:28 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:28 --> URI Class Initialized
INFO - 2023-09-26 15:57:28 --> Router Class Initialized
INFO - 2023-09-26 15:57:28 --> Output Class Initialized
INFO - 2023-09-26 15:57:28 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:28 --> Input Class Initialized
INFO - 2023-09-26 15:57:28 --> Language Class Initialized
INFO - 2023-09-26 15:57:28 --> Language Class Initialized
INFO - 2023-09-26 15:57:28 --> Config Class Initialized
INFO - 2023-09-26 15:57:28 --> Loader Class Initialized
INFO - 2023-09-26 15:57:28 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:28 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:28 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:28 --> Controller Class Initialized
INFO - 2023-09-26 15:57:29 --> Config Class Initialized
INFO - 2023-09-26 15:57:29 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:29 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:29 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:29 --> URI Class Initialized
INFO - 2023-09-26 15:57:29 --> Router Class Initialized
INFO - 2023-09-26 15:57:29 --> Output Class Initialized
INFO - 2023-09-26 15:57:29 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:29 --> Input Class Initialized
INFO - 2023-09-26 15:57:29 --> Language Class Initialized
INFO - 2023-09-26 15:57:29 --> Language Class Initialized
INFO - 2023-09-26 15:57:29 --> Config Class Initialized
INFO - 2023-09-26 15:57:29 --> Loader Class Initialized
INFO - 2023-09-26 15:57:29 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:29 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:29 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:29 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:29 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:29 --> Controller Class Initialized
INFO - 2023-09-26 15:57:29 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:29 --> Total execution time: 0.0482
INFO - 2023-09-26 15:57:32 --> Config Class Initialized
INFO - 2023-09-26 15:57:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:32 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:32 --> URI Class Initialized
INFO - 2023-09-26 15:57:32 --> Router Class Initialized
INFO - 2023-09-26 15:57:32 --> Output Class Initialized
INFO - 2023-09-26 15:57:32 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:32 --> Input Class Initialized
INFO - 2023-09-26 15:57:32 --> Language Class Initialized
INFO - 2023-09-26 15:57:32 --> Language Class Initialized
INFO - 2023-09-26 15:57:32 --> Config Class Initialized
INFO - 2023-09-26 15:57:32 --> Loader Class Initialized
INFO - 2023-09-26 15:57:32 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:32 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:32 --> Controller Class Initialized
INFO - 2023-09-26 15:57:32 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:32 --> Total execution time: 0.0482
INFO - 2023-09-26 15:57:32 --> Config Class Initialized
INFO - 2023-09-26 15:57:32 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:32 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:32 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:32 --> URI Class Initialized
INFO - 2023-09-26 15:57:32 --> Router Class Initialized
INFO - 2023-09-26 15:57:32 --> Output Class Initialized
INFO - 2023-09-26 15:57:32 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:32 --> Input Class Initialized
INFO - 2023-09-26 15:57:32 --> Language Class Initialized
INFO - 2023-09-26 15:57:32 --> Language Class Initialized
INFO - 2023-09-26 15:57:32 --> Config Class Initialized
INFO - 2023-09-26 15:57:32 --> Loader Class Initialized
INFO - 2023-09-26 15:57:32 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:32 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:32 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:32 --> Controller Class Initialized
INFO - 2023-09-26 15:57:34 --> Config Class Initialized
INFO - 2023-09-26 15:57:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:34 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:34 --> URI Class Initialized
INFO - 2023-09-26 15:57:34 --> Router Class Initialized
INFO - 2023-09-26 15:57:34 --> Output Class Initialized
INFO - 2023-09-26 15:57:34 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:34 --> Input Class Initialized
INFO - 2023-09-26 15:57:34 --> Language Class Initialized
INFO - 2023-09-26 15:57:34 --> Language Class Initialized
INFO - 2023-09-26 15:57:34 --> Config Class Initialized
INFO - 2023-09-26 15:57:34 --> Loader Class Initialized
INFO - 2023-09-26 15:57:34 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:34 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:34 --> Controller Class Initialized
INFO - 2023-09-26 15:57:34 --> Final output sent to browser
DEBUG - 2023-09-26 15:57:34 --> Total execution time: 0.0674
INFO - 2023-09-26 15:57:34 --> Config Class Initialized
INFO - 2023-09-26 15:57:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:34 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:34 --> URI Class Initialized
INFO - 2023-09-26 15:57:34 --> Router Class Initialized
INFO - 2023-09-26 15:57:34 --> Output Class Initialized
INFO - 2023-09-26 15:57:34 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:34 --> Input Class Initialized
INFO - 2023-09-26 15:57:34 --> Language Class Initialized
INFO - 2023-09-26 15:57:34 --> Language Class Initialized
INFO - 2023-09-26 15:57:34 --> Config Class Initialized
INFO - 2023-09-26 15:57:34 --> Loader Class Initialized
INFO - 2023-09-26 15:57:34 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:34 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:34 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:34 --> Controller Class Initialized
INFO - 2023-09-26 15:57:35 --> Config Class Initialized
INFO - 2023-09-26 15:57:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 15:57:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 15:57:35 --> Utf8 Class Initialized
INFO - 2023-09-26 15:57:35 --> URI Class Initialized
INFO - 2023-09-26 15:57:35 --> Router Class Initialized
INFO - 2023-09-26 15:57:35 --> Output Class Initialized
INFO - 2023-09-26 15:57:35 --> Security Class Initialized
DEBUG - 2023-09-26 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 15:57:35 --> Input Class Initialized
INFO - 2023-09-26 15:57:35 --> Language Class Initialized
INFO - 2023-09-26 15:57:35 --> Language Class Initialized
INFO - 2023-09-26 15:57:35 --> Config Class Initialized
INFO - 2023-09-26 15:57:35 --> Loader Class Initialized
INFO - 2023-09-26 15:57:35 --> Helper loaded: url_helper
INFO - 2023-09-26 15:57:35 --> Helper loaded: file_helper
INFO - 2023-09-26 15:57:35 --> Helper loaded: form_helper
INFO - 2023-09-26 15:57:35 --> Helper loaded: my_helper
INFO - 2023-09-26 15:57:35 --> Database Driver Class Initialized
INFO - 2023-09-26 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 15:57:35 --> Controller Class Initialized
INFO - 2023-09-26 16:19:34 --> Config Class Initialized
INFO - 2023-09-26 16:19:34 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:19:34 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:19:34 --> Utf8 Class Initialized
INFO - 2023-09-26 16:19:34 --> URI Class Initialized
INFO - 2023-09-26 16:19:34 --> Router Class Initialized
INFO - 2023-09-26 16:19:34 --> Output Class Initialized
INFO - 2023-09-26 16:19:34 --> Security Class Initialized
DEBUG - 2023-09-26 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:19:34 --> Input Class Initialized
INFO - 2023-09-26 16:19:34 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Config Class Initialized
INFO - 2023-09-26 16:19:35 --> Loader Class Initialized
INFO - 2023-09-26 16:19:35 --> Helper loaded: url_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: file_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: form_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: my_helper
INFO - 2023-09-26 16:19:35 --> Database Driver Class Initialized
INFO - 2023-09-26 16:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:19:35 --> Controller Class Initialized
INFO - 2023-09-26 16:19:35 --> Helper loaded: cookie_helper
INFO - 2023-09-26 16:19:35 --> Config Class Initialized
INFO - 2023-09-26 16:19:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:19:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:19:35 --> Utf8 Class Initialized
INFO - 2023-09-26 16:19:35 --> URI Class Initialized
INFO - 2023-09-26 16:19:35 --> Router Class Initialized
INFO - 2023-09-26 16:19:35 --> Output Class Initialized
INFO - 2023-09-26 16:19:35 --> Security Class Initialized
DEBUG - 2023-09-26 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:19:35 --> Input Class Initialized
INFO - 2023-09-26 16:19:35 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Config Class Initialized
INFO - 2023-09-26 16:19:35 --> Loader Class Initialized
INFO - 2023-09-26 16:19:35 --> Helper loaded: url_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: file_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: form_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: my_helper
INFO - 2023-09-26 16:19:35 --> Database Driver Class Initialized
INFO - 2023-09-26 16:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:19:35 --> Controller Class Initialized
INFO - 2023-09-26 16:19:35 --> Config Class Initialized
INFO - 2023-09-26 16:19:35 --> Hooks Class Initialized
DEBUG - 2023-09-26 16:19:35 --> UTF-8 Support Enabled
INFO - 2023-09-26 16:19:35 --> Utf8 Class Initialized
INFO - 2023-09-26 16:19:35 --> URI Class Initialized
INFO - 2023-09-26 16:19:35 --> Router Class Initialized
INFO - 2023-09-26 16:19:35 --> Output Class Initialized
INFO - 2023-09-26 16:19:35 --> Security Class Initialized
DEBUG - 2023-09-26 16:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 16:19:35 --> Input Class Initialized
INFO - 2023-09-26 16:19:35 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Language Class Initialized
INFO - 2023-09-26 16:19:35 --> Config Class Initialized
INFO - 2023-09-26 16:19:35 --> Loader Class Initialized
INFO - 2023-09-26 16:19:35 --> Helper loaded: url_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: file_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: form_helper
INFO - 2023-09-26 16:19:35 --> Helper loaded: my_helper
INFO - 2023-09-26 16:19:35 --> Database Driver Class Initialized
INFO - 2023-09-26 16:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 16:19:35 --> Controller Class Initialized
DEBUG - 2023-09-26 16:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 16:19:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 16:19:35 --> Final output sent to browser
DEBUG - 2023-09-26 16:19:35 --> Total execution time: 0.0417
INFO - 2023-09-26 22:17:46 --> Config Class Initialized
INFO - 2023-09-26 22:17:46 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:46 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:46 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:46 --> URI Class Initialized
DEBUG - 2023-09-26 22:17:46 --> No URI present. Default controller set.
INFO - 2023-09-26 22:17:46 --> Router Class Initialized
INFO - 2023-09-26 22:17:46 --> Output Class Initialized
INFO - 2023-09-26 22:17:46 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:46 --> Input Class Initialized
INFO - 2023-09-26 22:17:46 --> Language Class Initialized
INFO - 2023-09-26 22:17:46 --> Language Class Initialized
INFO - 2023-09-26 22:17:46 --> Config Class Initialized
INFO - 2023-09-26 22:17:46 --> Loader Class Initialized
INFO - 2023-09-26 22:17:46 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:46 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:46 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:46 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:46 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:46 --> Controller Class Initialized
INFO - 2023-09-26 22:17:47 --> Config Class Initialized
INFO - 2023-09-26 22:17:47 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:47 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:47 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:47 --> URI Class Initialized
INFO - 2023-09-26 22:17:47 --> Router Class Initialized
INFO - 2023-09-26 22:17:47 --> Output Class Initialized
INFO - 2023-09-26 22:17:47 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:47 --> Input Class Initialized
INFO - 2023-09-26 22:17:47 --> Language Class Initialized
INFO - 2023-09-26 22:17:47 --> Language Class Initialized
INFO - 2023-09-26 22:17:47 --> Config Class Initialized
INFO - 2023-09-26 22:17:47 --> Loader Class Initialized
INFO - 2023-09-26 22:17:47 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:47 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:47 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:47 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:47 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:47 --> Controller Class Initialized
DEBUG - 2023-09-26 22:17:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-26 22:17:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:17:47 --> Final output sent to browser
DEBUG - 2023-09-26 22:17:47 --> Total execution time: 0.0372
INFO - 2023-09-26 22:17:51 --> Config Class Initialized
INFO - 2023-09-26 22:17:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:51 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:51 --> URI Class Initialized
INFO - 2023-09-26 22:17:51 --> Router Class Initialized
INFO - 2023-09-26 22:17:51 --> Output Class Initialized
INFO - 2023-09-26 22:17:51 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:51 --> Input Class Initialized
INFO - 2023-09-26 22:17:51 --> Language Class Initialized
INFO - 2023-09-26 22:17:51 --> Language Class Initialized
INFO - 2023-09-26 22:17:51 --> Config Class Initialized
INFO - 2023-09-26 22:17:51 --> Loader Class Initialized
INFO - 2023-09-26 22:17:51 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:51 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:51 --> Controller Class Initialized
INFO - 2023-09-26 22:17:51 --> Helper loaded: cookie_helper
INFO - 2023-09-26 22:17:51 --> Final output sent to browser
DEBUG - 2023-09-26 22:17:51 --> Total execution time: 0.0728
INFO - 2023-09-26 22:17:51 --> Config Class Initialized
INFO - 2023-09-26 22:17:51 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:51 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:51 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:51 --> URI Class Initialized
INFO - 2023-09-26 22:17:51 --> Router Class Initialized
INFO - 2023-09-26 22:17:51 --> Output Class Initialized
INFO - 2023-09-26 22:17:51 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:51 --> Input Class Initialized
INFO - 2023-09-26 22:17:51 --> Language Class Initialized
INFO - 2023-09-26 22:17:51 --> Language Class Initialized
INFO - 2023-09-26 22:17:51 --> Config Class Initialized
INFO - 2023-09-26 22:17:51 --> Loader Class Initialized
INFO - 2023-09-26 22:17:51 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:51 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:51 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:51 --> Controller Class Initialized
DEBUG - 2023-09-26 22:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 22:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:17:51 --> Final output sent to browser
DEBUG - 2023-09-26 22:17:51 --> Total execution time: 0.0608
INFO - 2023-09-26 22:17:53 --> Config Class Initialized
INFO - 2023-09-26 22:17:53 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:53 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:53 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:53 --> URI Class Initialized
INFO - 2023-09-26 22:17:53 --> Router Class Initialized
INFO - 2023-09-26 22:17:53 --> Output Class Initialized
INFO - 2023-09-26 22:17:53 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:53 --> Input Class Initialized
INFO - 2023-09-26 22:17:53 --> Language Class Initialized
INFO - 2023-09-26 22:17:53 --> Language Class Initialized
INFO - 2023-09-26 22:17:53 --> Config Class Initialized
INFO - 2023-09-26 22:17:53 --> Loader Class Initialized
INFO - 2023-09-26 22:17:53 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:53 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:53 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:53 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:53 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:53 --> Controller Class Initialized
DEBUG - 2023-09-26 22:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 22:17:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:17:53 --> Final output sent to browser
DEBUG - 2023-09-26 22:17:53 --> Total execution time: 0.0444
INFO - 2023-09-26 22:17:56 --> Config Class Initialized
INFO - 2023-09-26 22:17:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:56 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:56 --> URI Class Initialized
INFO - 2023-09-26 22:17:56 --> Router Class Initialized
INFO - 2023-09-26 22:17:56 --> Output Class Initialized
INFO - 2023-09-26 22:17:56 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:56 --> Input Class Initialized
INFO - 2023-09-26 22:17:56 --> Language Class Initialized
INFO - 2023-09-26 22:17:56 --> Language Class Initialized
INFO - 2023-09-26 22:17:56 --> Config Class Initialized
INFO - 2023-09-26 22:17:56 --> Loader Class Initialized
INFO - 2023-09-26 22:17:56 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:56 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:56 --> Controller Class Initialized
DEBUG - 2023-09-26 22:17:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 22:17:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:17:56 --> Final output sent to browser
DEBUG - 2023-09-26 22:17:56 --> Total execution time: 0.0582
INFO - 2023-09-26 22:17:56 --> Config Class Initialized
INFO - 2023-09-26 22:17:56 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:17:56 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:17:56 --> Utf8 Class Initialized
INFO - 2023-09-26 22:17:56 --> URI Class Initialized
INFO - 2023-09-26 22:17:56 --> Router Class Initialized
INFO - 2023-09-26 22:17:56 --> Output Class Initialized
INFO - 2023-09-26 22:17:56 --> Security Class Initialized
DEBUG - 2023-09-26 22:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:17:56 --> Input Class Initialized
INFO - 2023-09-26 22:17:56 --> Language Class Initialized
INFO - 2023-09-26 22:17:56 --> Language Class Initialized
INFO - 2023-09-26 22:17:56 --> Config Class Initialized
INFO - 2023-09-26 22:17:56 --> Loader Class Initialized
INFO - 2023-09-26 22:17:56 --> Helper loaded: url_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: file_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: form_helper
INFO - 2023-09-26 22:17:56 --> Helper loaded: my_helper
INFO - 2023-09-26 22:17:56 --> Database Driver Class Initialized
INFO - 2023-09-26 22:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:17:56 --> Controller Class Initialized
INFO - 2023-09-26 22:28:28 --> Config Class Initialized
INFO - 2023-09-26 22:28:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:28:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:28:28 --> Utf8 Class Initialized
INFO - 2023-09-26 22:28:28 --> URI Class Initialized
DEBUG - 2023-09-26 22:28:28 --> No URI present. Default controller set.
INFO - 2023-09-26 22:28:28 --> Router Class Initialized
INFO - 2023-09-26 22:28:28 --> Output Class Initialized
INFO - 2023-09-26 22:28:28 --> Security Class Initialized
DEBUG - 2023-09-26 22:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:28:28 --> Input Class Initialized
INFO - 2023-09-26 22:28:28 --> Language Class Initialized
INFO - 2023-09-26 22:28:28 --> Language Class Initialized
INFO - 2023-09-26 22:28:28 --> Config Class Initialized
INFO - 2023-09-26 22:28:28 --> Loader Class Initialized
INFO - 2023-09-26 22:28:28 --> Helper loaded: url_helper
INFO - 2023-09-26 22:28:28 --> Helper loaded: file_helper
INFO - 2023-09-26 22:28:28 --> Helper loaded: form_helper
INFO - 2023-09-26 22:28:28 --> Helper loaded: my_helper
INFO - 2023-09-26 22:28:28 --> Database Driver Class Initialized
INFO - 2023-09-26 22:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:28:28 --> Controller Class Initialized
DEBUG - 2023-09-26 22:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-09-26 22:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:28:28 --> Final output sent to browser
DEBUG - 2023-09-26 22:28:28 --> Total execution time: 0.0345
INFO - 2023-09-26 22:29:28 --> Config Class Initialized
INFO - 2023-09-26 22:29:28 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:29:28 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:29:28 --> Utf8 Class Initialized
INFO - 2023-09-26 22:29:28 --> URI Class Initialized
INFO - 2023-09-26 22:29:28 --> Router Class Initialized
INFO - 2023-09-26 22:29:28 --> Output Class Initialized
INFO - 2023-09-26 22:29:28 --> Security Class Initialized
DEBUG - 2023-09-26 22:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:29:28 --> Input Class Initialized
INFO - 2023-09-26 22:29:28 --> Language Class Initialized
INFO - 2023-09-26 22:29:28 --> Language Class Initialized
INFO - 2023-09-26 22:29:28 --> Config Class Initialized
INFO - 2023-09-26 22:29:28 --> Loader Class Initialized
INFO - 2023-09-26 22:29:28 --> Helper loaded: url_helper
INFO - 2023-09-26 22:29:28 --> Helper loaded: file_helper
INFO - 2023-09-26 22:29:28 --> Helper loaded: form_helper
INFO - 2023-09-26 22:29:28 --> Helper loaded: my_helper
INFO - 2023-09-26 22:29:28 --> Database Driver Class Initialized
INFO - 2023-09-26 22:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:29:28 --> Controller Class Initialized
DEBUG - 2023-09-26 22:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-09-26 22:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:29:28 --> Final output sent to browser
DEBUG - 2023-09-26 22:29:28 --> Total execution time: 0.0893
INFO - 2023-09-26 22:29:31 --> Config Class Initialized
INFO - 2023-09-26 22:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:29:31 --> Utf8 Class Initialized
INFO - 2023-09-26 22:29:31 --> URI Class Initialized
INFO - 2023-09-26 22:29:31 --> Router Class Initialized
INFO - 2023-09-26 22:29:31 --> Output Class Initialized
INFO - 2023-09-26 22:29:31 --> Security Class Initialized
DEBUG - 2023-09-26 22:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:29:31 --> Input Class Initialized
INFO - 2023-09-26 22:29:31 --> Language Class Initialized
INFO - 2023-09-26 22:29:31 --> Language Class Initialized
INFO - 2023-09-26 22:29:31 --> Config Class Initialized
INFO - 2023-09-26 22:29:31 --> Loader Class Initialized
INFO - 2023-09-26 22:29:31 --> Helper loaded: url_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: file_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: form_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: my_helper
INFO - 2023-09-26 22:29:31 --> Database Driver Class Initialized
INFO - 2023-09-26 22:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:29:31 --> Controller Class Initialized
DEBUG - 2023-09-26 22:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-26 22:29:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-26 22:29:31 --> Final output sent to browser
DEBUG - 2023-09-26 22:29:31 --> Total execution time: 0.1026
INFO - 2023-09-26 22:29:31 --> Config Class Initialized
INFO - 2023-09-26 22:29:31 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:29:31 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:29:31 --> Utf8 Class Initialized
INFO - 2023-09-26 22:29:31 --> URI Class Initialized
INFO - 2023-09-26 22:29:31 --> Router Class Initialized
INFO - 2023-09-26 22:29:31 --> Output Class Initialized
INFO - 2023-09-26 22:29:31 --> Security Class Initialized
DEBUG - 2023-09-26 22:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:29:31 --> Input Class Initialized
INFO - 2023-09-26 22:29:31 --> Language Class Initialized
INFO - 2023-09-26 22:29:31 --> Language Class Initialized
INFO - 2023-09-26 22:29:31 --> Config Class Initialized
INFO - 2023-09-26 22:29:31 --> Loader Class Initialized
INFO - 2023-09-26 22:29:31 --> Helper loaded: url_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: file_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: form_helper
INFO - 2023-09-26 22:29:31 --> Helper loaded: my_helper
INFO - 2023-09-26 22:29:31 --> Database Driver Class Initialized
INFO - 2023-09-26 22:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:29:31 --> Controller Class Initialized
INFO - 2023-09-26 22:40:33 --> Config Class Initialized
INFO - 2023-09-26 22:40:33 --> Hooks Class Initialized
DEBUG - 2023-09-26 22:40:33 --> UTF-8 Support Enabled
INFO - 2023-09-26 22:40:33 --> Utf8 Class Initialized
INFO - 2023-09-26 22:40:33 --> URI Class Initialized
INFO - 2023-09-26 22:40:33 --> Router Class Initialized
INFO - 2023-09-26 22:40:33 --> Output Class Initialized
INFO - 2023-09-26 22:40:33 --> Security Class Initialized
DEBUG - 2023-09-26 22:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-26 22:40:33 --> Input Class Initialized
INFO - 2023-09-26 22:40:33 --> Language Class Initialized
INFO - 2023-09-26 22:40:33 --> Language Class Initialized
INFO - 2023-09-26 22:40:33 --> Config Class Initialized
INFO - 2023-09-26 22:40:33 --> Loader Class Initialized
INFO - 2023-09-26 22:40:33 --> Helper loaded: url_helper
INFO - 2023-09-26 22:40:33 --> Helper loaded: file_helper
INFO - 2023-09-26 22:40:33 --> Helper loaded: form_helper
INFO - 2023-09-26 22:40:33 --> Helper loaded: my_helper
INFO - 2023-09-26 22:40:33 --> Database Driver Class Initialized
INFO - 2023-09-26 22:40:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-26 22:40:33 --> Controller Class Initialized
