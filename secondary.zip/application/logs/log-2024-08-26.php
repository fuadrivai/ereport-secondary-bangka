<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-26 06:34:20 --> Config Class Initialized
INFO - 2024-08-26 06:34:20 --> Hooks Class Initialized
DEBUG - 2024-08-26 06:34:20 --> UTF-8 Support Enabled
INFO - 2024-08-26 06:34:20 --> Utf8 Class Initialized
INFO - 2024-08-26 06:34:20 --> URI Class Initialized
INFO - 2024-08-26 06:34:20 --> Router Class Initialized
INFO - 2024-08-26 06:34:20 --> Output Class Initialized
INFO - 2024-08-26 06:34:20 --> Security Class Initialized
DEBUG - 2024-08-26 06:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 06:34:20 --> Input Class Initialized
INFO - 2024-08-26 06:34:20 --> Language Class Initialized
INFO - 2024-08-26 06:34:20 --> Language Class Initialized
INFO - 2024-08-26 06:34:20 --> Config Class Initialized
INFO - 2024-08-26 06:34:20 --> Loader Class Initialized
INFO - 2024-08-26 06:34:20 --> Helper loaded: url_helper
INFO - 2024-08-26 06:34:20 --> Helper loaded: file_helper
INFO - 2024-08-26 06:34:20 --> Helper loaded: form_helper
INFO - 2024-08-26 06:34:20 --> Helper loaded: my_helper
INFO - 2024-08-26 06:34:20 --> Database Driver Class Initialized
INFO - 2024-08-26 06:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 06:34:20 --> Controller Class Initialized
INFO - 2024-08-26 06:34:21 --> Helper loaded: cookie_helper
INFO - 2024-08-26 06:34:21 --> Final output sent to browser
DEBUG - 2024-08-26 06:34:21 --> Total execution time: 0.3284
INFO - 2024-08-26 06:34:22 --> Config Class Initialized
INFO - 2024-08-26 06:34:22 --> Hooks Class Initialized
DEBUG - 2024-08-26 06:34:22 --> UTF-8 Support Enabled
INFO - 2024-08-26 06:34:22 --> Utf8 Class Initialized
INFO - 2024-08-26 06:34:22 --> URI Class Initialized
INFO - 2024-08-26 06:34:22 --> Router Class Initialized
INFO - 2024-08-26 06:34:22 --> Output Class Initialized
INFO - 2024-08-26 06:34:22 --> Security Class Initialized
DEBUG - 2024-08-26 06:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 06:34:22 --> Input Class Initialized
INFO - 2024-08-26 06:34:22 --> Language Class Initialized
INFO - 2024-08-26 06:34:22 --> Language Class Initialized
INFO - 2024-08-26 06:34:22 --> Config Class Initialized
INFO - 2024-08-26 06:34:22 --> Loader Class Initialized
INFO - 2024-08-26 06:34:22 --> Helper loaded: url_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: file_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: form_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: my_helper
INFO - 2024-08-26 06:34:22 --> Database Driver Class Initialized
INFO - 2024-08-26 06:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 06:34:22 --> Controller Class Initialized
INFO - 2024-08-26 06:34:22 --> Helper loaded: cookie_helper
INFO - 2024-08-26 06:34:22 --> Config Class Initialized
INFO - 2024-08-26 06:34:22 --> Hooks Class Initialized
DEBUG - 2024-08-26 06:34:22 --> UTF-8 Support Enabled
INFO - 2024-08-26 06:34:22 --> Utf8 Class Initialized
INFO - 2024-08-26 06:34:22 --> URI Class Initialized
INFO - 2024-08-26 06:34:22 --> Router Class Initialized
INFO - 2024-08-26 06:34:22 --> Output Class Initialized
INFO - 2024-08-26 06:34:22 --> Security Class Initialized
DEBUG - 2024-08-26 06:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 06:34:22 --> Input Class Initialized
INFO - 2024-08-26 06:34:22 --> Language Class Initialized
INFO - 2024-08-26 06:34:22 --> Language Class Initialized
INFO - 2024-08-26 06:34:22 --> Config Class Initialized
INFO - 2024-08-26 06:34:22 --> Loader Class Initialized
INFO - 2024-08-26 06:34:22 --> Helper loaded: url_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: file_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: form_helper
INFO - 2024-08-26 06:34:22 --> Helper loaded: my_helper
INFO - 2024-08-26 06:34:22 --> Database Driver Class Initialized
INFO - 2024-08-26 06:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 06:34:22 --> Controller Class Initialized
DEBUG - 2024-08-26 06:34:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-26 06:34:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-26 06:34:22 --> Final output sent to browser
DEBUG - 2024-08-26 06:34:22 --> Total execution time: 0.0543
INFO - 2024-08-26 09:04:37 --> Config Class Initialized
INFO - 2024-08-26 09:04:37 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:04:37 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:04:37 --> Utf8 Class Initialized
INFO - 2024-08-26 09:04:37 --> URI Class Initialized
INFO - 2024-08-26 09:04:37 --> Router Class Initialized
INFO - 2024-08-26 09:04:37 --> Output Class Initialized
INFO - 2024-08-26 09:04:37 --> Security Class Initialized
DEBUG - 2024-08-26 09:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:04:37 --> Input Class Initialized
INFO - 2024-08-26 09:04:37 --> Language Class Initialized
INFO - 2024-08-26 09:04:37 --> Language Class Initialized
INFO - 2024-08-26 09:04:37 --> Config Class Initialized
INFO - 2024-08-26 09:04:37 --> Loader Class Initialized
INFO - 2024-08-26 09:04:37 --> Helper loaded: url_helper
INFO - 2024-08-26 09:04:37 --> Helper loaded: file_helper
INFO - 2024-08-26 09:04:37 --> Helper loaded: form_helper
INFO - 2024-08-26 09:04:37 --> Helper loaded: my_helper
INFO - 2024-08-26 09:04:37 --> Database Driver Class Initialized
INFO - 2024-08-26 09:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:04:37 --> Controller Class Initialized
INFO - 2024-08-26 09:04:37 --> Final output sent to browser
DEBUG - 2024-08-26 09:04:37 --> Total execution time: 0.0603
INFO - 2024-08-26 09:04:46 --> Config Class Initialized
INFO - 2024-08-26 09:04:46 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:04:46 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:04:46 --> Utf8 Class Initialized
INFO - 2024-08-26 09:04:46 --> URI Class Initialized
INFO - 2024-08-26 09:04:46 --> Router Class Initialized
INFO - 2024-08-26 09:04:46 --> Output Class Initialized
INFO - 2024-08-26 09:04:46 --> Security Class Initialized
DEBUG - 2024-08-26 09:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:04:46 --> Input Class Initialized
INFO - 2024-08-26 09:04:46 --> Language Class Initialized
INFO - 2024-08-26 09:04:46 --> Language Class Initialized
INFO - 2024-08-26 09:04:46 --> Config Class Initialized
INFO - 2024-08-26 09:04:46 --> Loader Class Initialized
INFO - 2024-08-26 09:04:46 --> Helper loaded: url_helper
INFO - 2024-08-26 09:04:46 --> Helper loaded: file_helper
INFO - 2024-08-26 09:04:46 --> Helper loaded: form_helper
INFO - 2024-08-26 09:04:46 --> Helper loaded: my_helper
INFO - 2024-08-26 09:04:46 --> Database Driver Class Initialized
INFO - 2024-08-26 09:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:04:46 --> Controller Class Initialized
INFO - 2024-08-26 09:04:46 --> Final output sent to browser
DEBUG - 2024-08-26 09:04:46 --> Total execution time: 0.0309
INFO - 2024-08-26 09:10:05 --> Config Class Initialized
INFO - 2024-08-26 09:10:05 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:10:05 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:10:05 --> Utf8 Class Initialized
INFO - 2024-08-26 09:10:05 --> URI Class Initialized
INFO - 2024-08-26 09:10:05 --> Router Class Initialized
INFO - 2024-08-26 09:10:05 --> Output Class Initialized
INFO - 2024-08-26 09:10:05 --> Security Class Initialized
DEBUG - 2024-08-26 09:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:10:05 --> Input Class Initialized
INFO - 2024-08-26 09:10:05 --> Language Class Initialized
INFO - 2024-08-26 09:10:05 --> Language Class Initialized
INFO - 2024-08-26 09:10:05 --> Config Class Initialized
INFO - 2024-08-26 09:10:05 --> Loader Class Initialized
INFO - 2024-08-26 09:10:06 --> Helper loaded: url_helper
INFO - 2024-08-26 09:10:06 --> Helper loaded: file_helper
INFO - 2024-08-26 09:10:06 --> Helper loaded: form_helper
INFO - 2024-08-26 09:10:06 --> Helper loaded: my_helper
INFO - 2024-08-26 09:10:06 --> Database Driver Class Initialized
INFO - 2024-08-26 09:10:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:10:06 --> Controller Class Initialized
INFO - 2024-08-26 09:10:06 --> Final output sent to browser
DEBUG - 2024-08-26 09:10:06 --> Total execution time: 0.0450
INFO - 2024-08-26 09:10:11 --> Config Class Initialized
INFO - 2024-08-26 09:10:11 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:10:11 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:10:11 --> Utf8 Class Initialized
INFO - 2024-08-26 09:10:11 --> URI Class Initialized
INFO - 2024-08-26 09:10:11 --> Router Class Initialized
INFO - 2024-08-26 09:10:11 --> Output Class Initialized
INFO - 2024-08-26 09:10:11 --> Security Class Initialized
DEBUG - 2024-08-26 09:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:10:11 --> Input Class Initialized
INFO - 2024-08-26 09:10:11 --> Language Class Initialized
INFO - 2024-08-26 09:10:11 --> Language Class Initialized
INFO - 2024-08-26 09:10:11 --> Config Class Initialized
INFO - 2024-08-26 09:10:11 --> Loader Class Initialized
INFO - 2024-08-26 09:10:11 --> Helper loaded: url_helper
INFO - 2024-08-26 09:10:11 --> Helper loaded: file_helper
INFO - 2024-08-26 09:10:11 --> Helper loaded: form_helper
INFO - 2024-08-26 09:10:11 --> Helper loaded: my_helper
INFO - 2024-08-26 09:10:11 --> Database Driver Class Initialized
INFO - 2024-08-26 09:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:10:11 --> Controller Class Initialized
INFO - 2024-08-26 09:10:11 --> Final output sent to browser
DEBUG - 2024-08-26 09:10:11 --> Total execution time: 0.0330
INFO - 2024-08-26 09:47:30 --> Config Class Initialized
INFO - 2024-08-26 09:47:30 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:47:30 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:47:30 --> Utf8 Class Initialized
INFO - 2024-08-26 09:47:30 --> URI Class Initialized
INFO - 2024-08-26 09:47:30 --> Router Class Initialized
INFO - 2024-08-26 09:47:30 --> Output Class Initialized
INFO - 2024-08-26 09:47:30 --> Security Class Initialized
DEBUG - 2024-08-26 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:47:30 --> Input Class Initialized
INFO - 2024-08-26 09:47:30 --> Language Class Initialized
INFO - 2024-08-26 09:47:31 --> Language Class Initialized
INFO - 2024-08-26 09:47:31 --> Config Class Initialized
INFO - 2024-08-26 09:47:31 --> Loader Class Initialized
INFO - 2024-08-26 09:47:31 --> Helper loaded: url_helper
INFO - 2024-08-26 09:47:31 --> Helper loaded: file_helper
INFO - 2024-08-26 09:47:31 --> Helper loaded: form_helper
INFO - 2024-08-26 09:47:31 --> Helper loaded: my_helper
INFO - 2024-08-26 09:47:31 --> Database Driver Class Initialized
INFO - 2024-08-26 09:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:47:31 --> Controller Class Initialized
INFO - 2024-08-26 09:47:31 --> Final output sent to browser
DEBUG - 2024-08-26 09:47:31 --> Total execution time: 0.0653
INFO - 2024-08-26 09:47:38 --> Config Class Initialized
INFO - 2024-08-26 09:47:38 --> Hooks Class Initialized
DEBUG - 2024-08-26 09:47:38 --> UTF-8 Support Enabled
INFO - 2024-08-26 09:47:38 --> Utf8 Class Initialized
INFO - 2024-08-26 09:47:38 --> URI Class Initialized
INFO - 2024-08-26 09:47:38 --> Router Class Initialized
INFO - 2024-08-26 09:47:38 --> Output Class Initialized
INFO - 2024-08-26 09:47:38 --> Security Class Initialized
DEBUG - 2024-08-26 09:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 09:47:38 --> Input Class Initialized
INFO - 2024-08-26 09:47:38 --> Language Class Initialized
INFO - 2024-08-26 09:47:38 --> Language Class Initialized
INFO - 2024-08-26 09:47:38 --> Config Class Initialized
INFO - 2024-08-26 09:47:38 --> Loader Class Initialized
INFO - 2024-08-26 09:47:38 --> Helper loaded: url_helper
INFO - 2024-08-26 09:47:38 --> Helper loaded: file_helper
INFO - 2024-08-26 09:47:38 --> Helper loaded: form_helper
INFO - 2024-08-26 09:47:38 --> Helper loaded: my_helper
INFO - 2024-08-26 09:47:38 --> Database Driver Class Initialized
INFO - 2024-08-26 09:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 09:47:38 --> Controller Class Initialized
INFO - 2024-08-26 09:47:38 --> Final output sent to browser
DEBUG - 2024-08-26 09:47:38 --> Total execution time: 0.0424
INFO - 2024-08-26 12:16:44 --> Config Class Initialized
INFO - 2024-08-26 12:16:44 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:16:44 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:16:44 --> Utf8 Class Initialized
INFO - 2024-08-26 12:16:44 --> URI Class Initialized
INFO - 2024-08-26 12:16:44 --> Router Class Initialized
INFO - 2024-08-26 12:16:44 --> Output Class Initialized
INFO - 2024-08-26 12:16:44 --> Security Class Initialized
DEBUG - 2024-08-26 12:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:16:44 --> Input Class Initialized
INFO - 2024-08-26 12:16:44 --> Language Class Initialized
INFO - 2024-08-26 12:16:44 --> Language Class Initialized
INFO - 2024-08-26 12:16:44 --> Config Class Initialized
INFO - 2024-08-26 12:16:44 --> Loader Class Initialized
INFO - 2024-08-26 12:16:44 --> Helper loaded: url_helper
INFO - 2024-08-26 12:16:44 --> Helper loaded: file_helper
INFO - 2024-08-26 12:16:44 --> Helper loaded: form_helper
INFO - 2024-08-26 12:16:44 --> Helper loaded: my_helper
INFO - 2024-08-26 12:16:44 --> Database Driver Class Initialized
INFO - 2024-08-26 12:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:16:44 --> Controller Class Initialized
INFO - 2024-08-26 12:16:44 --> Final output sent to browser
DEBUG - 2024-08-26 12:16:44 --> Total execution time: 0.0683
INFO - 2024-08-26 12:21:02 --> Config Class Initialized
INFO - 2024-08-26 12:21:02 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:21:02 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:21:02 --> Utf8 Class Initialized
INFO - 2024-08-26 12:21:02 --> URI Class Initialized
INFO - 2024-08-26 12:21:02 --> Router Class Initialized
INFO - 2024-08-26 12:21:02 --> Output Class Initialized
INFO - 2024-08-26 12:21:02 --> Security Class Initialized
DEBUG - 2024-08-26 12:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:21:02 --> Input Class Initialized
INFO - 2024-08-26 12:21:02 --> Language Class Initialized
INFO - 2024-08-26 12:21:02 --> Language Class Initialized
INFO - 2024-08-26 12:21:02 --> Config Class Initialized
INFO - 2024-08-26 12:21:02 --> Loader Class Initialized
INFO - 2024-08-26 12:21:02 --> Helper loaded: url_helper
INFO - 2024-08-26 12:21:02 --> Helper loaded: file_helper
INFO - 2024-08-26 12:21:02 --> Helper loaded: form_helper
INFO - 2024-08-26 12:21:02 --> Helper loaded: my_helper
INFO - 2024-08-26 12:21:02 --> Database Driver Class Initialized
INFO - 2024-08-26 12:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:21:02 --> Controller Class Initialized
INFO - 2024-08-26 12:21:02 --> Final output sent to browser
DEBUG - 2024-08-26 12:21:02 --> Total execution time: 0.0385
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:44:58 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:44:58 --> Utf8 Class Initialized
INFO - 2024-08-26 12:44:58 --> URI Class Initialized
INFO - 2024-08-26 12:44:58 --> Router Class Initialized
INFO - 2024-08-26 12:44:58 --> Output Class Initialized
INFO - 2024-08-26 12:44:58 --> Security Class Initialized
DEBUG - 2024-08-26 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:44:58 --> Input Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Loader Class Initialized
INFO - 2024-08-26 12:44:58 --> Helper loaded: url_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: file_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: form_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: my_helper
INFO - 2024-08-26 12:44:58 --> Database Driver Class Initialized
INFO - 2024-08-26 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:44:58 --> Controller Class Initialized
INFO - 2024-08-26 12:44:58 --> Helper loaded: cookie_helper
INFO - 2024-08-26 12:44:58 --> Final output sent to browser
DEBUG - 2024-08-26 12:44:58 --> Total execution time: 0.1305
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:44:58 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:44:58 --> Utf8 Class Initialized
INFO - 2024-08-26 12:44:58 --> URI Class Initialized
INFO - 2024-08-26 12:44:58 --> Router Class Initialized
INFO - 2024-08-26 12:44:58 --> Output Class Initialized
INFO - 2024-08-26 12:44:58 --> Security Class Initialized
DEBUG - 2024-08-26 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:44:58 --> Input Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Loader Class Initialized
INFO - 2024-08-26 12:44:58 --> Helper loaded: url_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: file_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: form_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: my_helper
INFO - 2024-08-26 12:44:58 --> Database Driver Class Initialized
INFO - 2024-08-26 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:44:58 --> Controller Class Initialized
INFO - 2024-08-26 12:44:58 --> Helper loaded: cookie_helper
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:44:58 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:44:58 --> Utf8 Class Initialized
INFO - 2024-08-26 12:44:58 --> URI Class Initialized
INFO - 2024-08-26 12:44:58 --> Router Class Initialized
INFO - 2024-08-26 12:44:58 --> Output Class Initialized
INFO - 2024-08-26 12:44:58 --> Security Class Initialized
DEBUG - 2024-08-26 12:44:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:44:58 --> Input Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Language Class Initialized
INFO - 2024-08-26 12:44:58 --> Config Class Initialized
INFO - 2024-08-26 12:44:58 --> Loader Class Initialized
INFO - 2024-08-26 12:44:58 --> Helper loaded: url_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: file_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: form_helper
INFO - 2024-08-26 12:44:58 --> Helper loaded: my_helper
INFO - 2024-08-26 12:44:58 --> Database Driver Class Initialized
INFO - 2024-08-26 12:44:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:44:58 --> Controller Class Initialized
DEBUG - 2024-08-26 12:44:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-26 12:44:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-26 12:44:58 --> Final output sent to browser
DEBUG - 2024-08-26 12:44:58 --> Total execution time: 0.0446
INFO - 2024-08-26 12:45:10 --> Config Class Initialized
INFO - 2024-08-26 12:45:10 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:45:10 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:45:10 --> Utf8 Class Initialized
INFO - 2024-08-26 12:45:10 --> URI Class Initialized
INFO - 2024-08-26 12:45:10 --> Router Class Initialized
INFO - 2024-08-26 12:45:10 --> Output Class Initialized
INFO - 2024-08-26 12:45:10 --> Security Class Initialized
DEBUG - 2024-08-26 12:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:45:10 --> Input Class Initialized
INFO - 2024-08-26 12:45:10 --> Language Class Initialized
INFO - 2024-08-26 12:45:10 --> Language Class Initialized
INFO - 2024-08-26 12:45:10 --> Config Class Initialized
INFO - 2024-08-26 12:45:10 --> Loader Class Initialized
INFO - 2024-08-26 12:45:10 --> Helper loaded: url_helper
INFO - 2024-08-26 12:45:10 --> Helper loaded: file_helper
INFO - 2024-08-26 12:45:10 --> Helper loaded: form_helper
INFO - 2024-08-26 12:45:10 --> Helper loaded: my_helper
INFO - 2024-08-26 12:45:10 --> Database Driver Class Initialized
INFO - 2024-08-26 12:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:45:10 --> Controller Class Initialized
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-26 12:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-26 12:45:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-26 12:45:12 --> Config Class Initialized
INFO - 2024-08-26 12:45:12 --> Hooks Class Initialized
DEBUG - 2024-08-26 12:45:12 --> UTF-8 Support Enabled
INFO - 2024-08-26 12:45:12 --> Utf8 Class Initialized
INFO - 2024-08-26 12:45:12 --> URI Class Initialized
INFO - 2024-08-26 12:45:12 --> Router Class Initialized
INFO - 2024-08-26 12:45:12 --> Output Class Initialized
INFO - 2024-08-26 12:45:12 --> Security Class Initialized
DEBUG - 2024-08-26 12:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 12:45:12 --> Input Class Initialized
INFO - 2024-08-26 12:45:12 --> Language Class Initialized
INFO - 2024-08-26 12:45:12 --> Language Class Initialized
INFO - 2024-08-26 12:45:12 --> Config Class Initialized
INFO - 2024-08-26 12:45:12 --> Loader Class Initialized
INFO - 2024-08-26 12:45:12 --> Helper loaded: url_helper
INFO - 2024-08-26 12:45:12 --> Helper loaded: file_helper
INFO - 2024-08-26 12:45:12 --> Helper loaded: form_helper
INFO - 2024-08-26 12:45:12 --> Helper loaded: my_helper
INFO - 2024-08-26 12:45:12 --> Database Driver Class Initialized
INFO - 2024-08-26 12:45:13 --> Final output sent to browser
DEBUG - 2024-08-26 12:45:13 --> Total execution time: 3.1054
INFO - 2024-08-26 12:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 12:45:13 --> Controller Class Initialized
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-26 12:45:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-26 12:45:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-26 12:45:15 --> Final output sent to browser
DEBUG - 2024-08-26 12:45:15 --> Total execution time: 3.7449
INFO - 2024-08-26 13:02:40 --> Config Class Initialized
INFO - 2024-08-26 13:02:40 --> Hooks Class Initialized
DEBUG - 2024-08-26 13:02:40 --> UTF-8 Support Enabled
INFO - 2024-08-26 13:02:40 --> Utf8 Class Initialized
INFO - 2024-08-26 13:02:40 --> URI Class Initialized
INFO - 2024-08-26 13:02:40 --> Router Class Initialized
INFO - 2024-08-26 13:02:40 --> Output Class Initialized
INFO - 2024-08-26 13:02:40 --> Security Class Initialized
DEBUG - 2024-08-26 13:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 13:02:40 --> Input Class Initialized
INFO - 2024-08-26 13:02:40 --> Language Class Initialized
INFO - 2024-08-26 13:02:40 --> Language Class Initialized
INFO - 2024-08-26 13:02:40 --> Config Class Initialized
INFO - 2024-08-26 13:02:40 --> Loader Class Initialized
INFO - 2024-08-26 13:02:40 --> Helper loaded: url_helper
INFO - 2024-08-26 13:02:40 --> Helper loaded: file_helper
INFO - 2024-08-26 13:02:40 --> Helper loaded: form_helper
INFO - 2024-08-26 13:02:40 --> Helper loaded: my_helper
INFO - 2024-08-26 13:02:40 --> Database Driver Class Initialized
INFO - 2024-08-26 13:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 13:02:40 --> Controller Class Initialized
INFO - 2024-08-26 13:02:40 --> Helper loaded: cookie_helper
INFO - 2024-08-26 13:02:40 --> Final output sent to browser
DEBUG - 2024-08-26 13:02:40 --> Total execution time: 0.0595
INFO - 2024-08-26 13:02:41 --> Config Class Initialized
INFO - 2024-08-26 13:02:41 --> Hooks Class Initialized
DEBUG - 2024-08-26 13:02:41 --> UTF-8 Support Enabled
INFO - 2024-08-26 13:02:41 --> Utf8 Class Initialized
INFO - 2024-08-26 13:02:41 --> URI Class Initialized
INFO - 2024-08-26 13:02:41 --> Router Class Initialized
INFO - 2024-08-26 13:02:41 --> Output Class Initialized
INFO - 2024-08-26 13:02:41 --> Security Class Initialized
DEBUG - 2024-08-26 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 13:02:41 --> Input Class Initialized
INFO - 2024-08-26 13:02:41 --> Language Class Initialized
INFO - 2024-08-26 13:02:41 --> Language Class Initialized
INFO - 2024-08-26 13:02:41 --> Config Class Initialized
INFO - 2024-08-26 13:02:41 --> Loader Class Initialized
INFO - 2024-08-26 13:02:41 --> Helper loaded: url_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: file_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: form_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: my_helper
INFO - 2024-08-26 13:02:41 --> Database Driver Class Initialized
INFO - 2024-08-26 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 13:02:41 --> Controller Class Initialized
INFO - 2024-08-26 13:02:41 --> Helper loaded: cookie_helper
INFO - 2024-08-26 13:02:41 --> Config Class Initialized
INFO - 2024-08-26 13:02:41 --> Hooks Class Initialized
DEBUG - 2024-08-26 13:02:41 --> UTF-8 Support Enabled
INFO - 2024-08-26 13:02:41 --> Utf8 Class Initialized
INFO - 2024-08-26 13:02:41 --> URI Class Initialized
INFO - 2024-08-26 13:02:41 --> Router Class Initialized
INFO - 2024-08-26 13:02:41 --> Output Class Initialized
INFO - 2024-08-26 13:02:41 --> Security Class Initialized
DEBUG - 2024-08-26 13:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-26 13:02:41 --> Input Class Initialized
INFO - 2024-08-26 13:02:41 --> Language Class Initialized
INFO - 2024-08-26 13:02:41 --> Language Class Initialized
INFO - 2024-08-26 13:02:41 --> Config Class Initialized
INFO - 2024-08-26 13:02:41 --> Loader Class Initialized
INFO - 2024-08-26 13:02:41 --> Helper loaded: url_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: file_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: form_helper
INFO - 2024-08-26 13:02:41 --> Helper loaded: my_helper
INFO - 2024-08-26 13:02:41 --> Database Driver Class Initialized
INFO - 2024-08-26 13:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-26 13:02:41 --> Controller Class Initialized
DEBUG - 2024-08-26 13:02:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-26 13:02:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-26 13:02:41 --> Final output sent to browser
DEBUG - 2024-08-26 13:02:41 --> Total execution time: 0.0963
