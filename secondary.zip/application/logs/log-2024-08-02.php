<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-02 09:01:22 --> Config Class Initialized
INFO - 2024-08-02 09:01:22 --> Hooks Class Initialized
DEBUG - 2024-08-02 09:01:22 --> UTF-8 Support Enabled
INFO - 2024-08-02 09:01:22 --> Utf8 Class Initialized
INFO - 2024-08-02 09:01:22 --> URI Class Initialized
INFO - 2024-08-02 09:01:22 --> Router Class Initialized
INFO - 2024-08-02 09:01:22 --> Output Class Initialized
INFO - 2024-08-02 09:01:22 --> Security Class Initialized
DEBUG - 2024-08-02 09:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 09:01:22 --> Input Class Initialized
INFO - 2024-08-02 09:01:22 --> Language Class Initialized
INFO - 2024-08-02 09:01:22 --> Language Class Initialized
INFO - 2024-08-02 09:01:22 --> Config Class Initialized
INFO - 2024-08-02 09:01:22 --> Loader Class Initialized
INFO - 2024-08-02 09:01:22 --> Helper loaded: url_helper
INFO - 2024-08-02 09:01:22 --> Helper loaded: file_helper
INFO - 2024-08-02 09:01:22 --> Helper loaded: form_helper
INFO - 2024-08-02 09:01:22 --> Helper loaded: my_helper
INFO - 2024-08-02 09:01:22 --> Database Driver Class Initialized
INFO - 2024-08-02 09:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 09:01:22 --> Controller Class Initialized
INFO - 2024-08-02 09:01:22 --> Config Class Initialized
INFO - 2024-08-02 09:01:22 --> Hooks Class Initialized
DEBUG - 2024-08-02 09:01:22 --> UTF-8 Support Enabled
INFO - 2024-08-02 09:01:22 --> Utf8 Class Initialized
INFO - 2024-08-02 09:01:23 --> URI Class Initialized
INFO - 2024-08-02 09:01:23 --> Router Class Initialized
INFO - 2024-08-02 09:01:23 --> Output Class Initialized
INFO - 2024-08-02 09:01:23 --> Security Class Initialized
DEBUG - 2024-08-02 09:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 09:01:23 --> Input Class Initialized
INFO - 2024-08-02 09:01:23 --> Language Class Initialized
INFO - 2024-08-02 09:01:23 --> Language Class Initialized
INFO - 2024-08-02 09:01:23 --> Config Class Initialized
INFO - 2024-08-02 09:01:23 --> Loader Class Initialized
INFO - 2024-08-02 09:01:23 --> Helper loaded: url_helper
INFO - 2024-08-02 09:01:23 --> Helper loaded: file_helper
INFO - 2024-08-02 09:01:23 --> Helper loaded: form_helper
INFO - 2024-08-02 09:01:23 --> Helper loaded: my_helper
INFO - 2024-08-02 09:01:23 --> Database Driver Class Initialized
INFO - 2024-08-02 09:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 09:01:23 --> Controller Class Initialized
DEBUG - 2024-08-02 09:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-02 09:01:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 09:01:23 --> Final output sent to browser
DEBUG - 2024-08-02 09:01:23 --> Total execution time: 0.1072
INFO - 2024-08-02 09:36:50 --> Config Class Initialized
INFO - 2024-08-02 09:36:50 --> Hooks Class Initialized
DEBUG - 2024-08-02 09:36:50 --> UTF-8 Support Enabled
INFO - 2024-08-02 09:36:50 --> Utf8 Class Initialized
INFO - 2024-08-02 09:36:50 --> URI Class Initialized
INFO - 2024-08-02 09:36:50 --> Router Class Initialized
INFO - 2024-08-02 09:36:50 --> Output Class Initialized
INFO - 2024-08-02 09:36:50 --> Security Class Initialized
DEBUG - 2024-08-02 09:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 09:36:50 --> Input Class Initialized
INFO - 2024-08-02 09:36:50 --> Language Class Initialized
INFO - 2024-08-02 09:36:50 --> Language Class Initialized
INFO - 2024-08-02 09:36:50 --> Config Class Initialized
INFO - 2024-08-02 09:36:50 --> Loader Class Initialized
INFO - 2024-08-02 09:36:50 --> Helper loaded: url_helper
INFO - 2024-08-02 09:36:50 --> Helper loaded: file_helper
INFO - 2024-08-02 09:36:50 --> Helper loaded: form_helper
INFO - 2024-08-02 09:36:50 --> Helper loaded: my_helper
INFO - 2024-08-02 09:36:50 --> Database Driver Class Initialized
INFO - 2024-08-02 09:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 09:36:50 --> Controller Class Initialized
DEBUG - 2024-08-02 09:36:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-02 09:36:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 09:36:50 --> Final output sent to browser
DEBUG - 2024-08-02 09:36:50 --> Total execution time: 0.0730
INFO - 2024-08-02 10:36:20 --> Config Class Initialized
INFO - 2024-08-02 10:36:20 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:36:20 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:36:20 --> Utf8 Class Initialized
INFO - 2024-08-02 10:36:20 --> URI Class Initialized
INFO - 2024-08-02 10:36:20 --> Router Class Initialized
INFO - 2024-08-02 10:36:20 --> Output Class Initialized
INFO - 2024-08-02 10:36:20 --> Security Class Initialized
DEBUG - 2024-08-02 10:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:36:20 --> Input Class Initialized
INFO - 2024-08-02 10:36:20 --> Language Class Initialized
INFO - 2024-08-02 10:36:20 --> Language Class Initialized
INFO - 2024-08-02 10:36:20 --> Config Class Initialized
INFO - 2024-08-02 10:36:20 --> Loader Class Initialized
INFO - 2024-08-02 10:36:20 --> Helper loaded: url_helper
INFO - 2024-08-02 10:36:20 --> Helper loaded: file_helper
INFO - 2024-08-02 10:36:20 --> Helper loaded: form_helper
INFO - 2024-08-02 10:36:20 --> Helper loaded: my_helper
INFO - 2024-08-02 10:36:20 --> Database Driver Class Initialized
INFO - 2024-08-02 10:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:36:20 --> Controller Class Initialized
INFO - 2024-08-02 10:36:20 --> Helper loaded: cookie_helper
INFO - 2024-08-02 10:36:20 --> Final output sent to browser
DEBUG - 2024-08-02 10:36:20 --> Total execution time: 0.1248
INFO - 2024-08-02 10:36:20 --> Config Class Initialized
INFO - 2024-08-02 10:36:20 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:36:20 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:36:20 --> Utf8 Class Initialized
INFO - 2024-08-02 10:36:20 --> URI Class Initialized
INFO - 2024-08-02 10:36:20 --> Router Class Initialized
INFO - 2024-08-02 10:36:20 --> Output Class Initialized
INFO - 2024-08-02 10:36:20 --> Security Class Initialized
DEBUG - 2024-08-02 10:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:36:21 --> Input Class Initialized
INFO - 2024-08-02 10:36:21 --> Language Class Initialized
INFO - 2024-08-02 10:36:21 --> Language Class Initialized
INFO - 2024-08-02 10:36:21 --> Config Class Initialized
INFO - 2024-08-02 10:36:21 --> Loader Class Initialized
INFO - 2024-08-02 10:36:21 --> Helper loaded: url_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: file_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: form_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: my_helper
INFO - 2024-08-02 10:36:21 --> Database Driver Class Initialized
INFO - 2024-08-02 10:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:36:21 --> Controller Class Initialized
INFO - 2024-08-02 10:36:21 --> Helper loaded: cookie_helper
INFO - 2024-08-02 10:36:21 --> Config Class Initialized
INFO - 2024-08-02 10:36:21 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:36:21 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:36:21 --> Utf8 Class Initialized
INFO - 2024-08-02 10:36:21 --> URI Class Initialized
INFO - 2024-08-02 10:36:21 --> Router Class Initialized
INFO - 2024-08-02 10:36:21 --> Output Class Initialized
INFO - 2024-08-02 10:36:21 --> Security Class Initialized
DEBUG - 2024-08-02 10:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:36:21 --> Input Class Initialized
INFO - 2024-08-02 10:36:21 --> Language Class Initialized
INFO - 2024-08-02 10:36:21 --> Language Class Initialized
INFO - 2024-08-02 10:36:21 --> Config Class Initialized
INFO - 2024-08-02 10:36:21 --> Loader Class Initialized
INFO - 2024-08-02 10:36:21 --> Helper loaded: url_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: file_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: form_helper
INFO - 2024-08-02 10:36:21 --> Helper loaded: my_helper
INFO - 2024-08-02 10:36:21 --> Database Driver Class Initialized
INFO - 2024-08-02 10:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:36:21 --> Controller Class Initialized
DEBUG - 2024-08-02 10:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-02 10:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 10:36:21 --> Final output sent to browser
DEBUG - 2024-08-02 10:36:21 --> Total execution time: 0.0514
INFO - 2024-08-02 10:36:25 --> Config Class Initialized
INFO - 2024-08-02 10:36:25 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:36:25 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:36:25 --> Utf8 Class Initialized
INFO - 2024-08-02 10:36:25 --> URI Class Initialized
INFO - 2024-08-02 10:36:25 --> Router Class Initialized
INFO - 2024-08-02 10:36:25 --> Output Class Initialized
INFO - 2024-08-02 10:36:25 --> Security Class Initialized
DEBUG - 2024-08-02 10:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:36:25 --> Input Class Initialized
INFO - 2024-08-02 10:36:25 --> Language Class Initialized
INFO - 2024-08-02 10:36:25 --> Language Class Initialized
INFO - 2024-08-02 10:36:25 --> Config Class Initialized
INFO - 2024-08-02 10:36:25 --> Loader Class Initialized
INFO - 2024-08-02 10:36:25 --> Helper loaded: url_helper
INFO - 2024-08-02 10:36:25 --> Helper loaded: file_helper
INFO - 2024-08-02 10:36:25 --> Helper loaded: form_helper
INFO - 2024-08-02 10:36:25 --> Helper loaded: my_helper
INFO - 2024-08-02 10:36:25 --> Database Driver Class Initialized
INFO - 2024-08-02 10:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:36:25 --> Controller Class Initialized
DEBUG - 2024-08-02 10:36:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-02 10:36:28 --> Config Class Initialized
INFO - 2024-08-02 10:36:28 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:36:28 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:36:28 --> Utf8 Class Initialized
INFO - 2024-08-02 10:36:28 --> URI Class Initialized
INFO - 2024-08-02 10:36:28 --> Router Class Initialized
INFO - 2024-08-02 10:36:28 --> Output Class Initialized
INFO - 2024-08-02 10:36:28 --> Security Class Initialized
DEBUG - 2024-08-02 10:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:36:28 --> Input Class Initialized
INFO - 2024-08-02 10:36:28 --> Language Class Initialized
INFO - 2024-08-02 10:36:28 --> Language Class Initialized
INFO - 2024-08-02 10:36:28 --> Config Class Initialized
INFO - 2024-08-02 10:36:28 --> Loader Class Initialized
INFO - 2024-08-02 10:36:28 --> Helper loaded: url_helper
INFO - 2024-08-02 10:36:28 --> Helper loaded: file_helper
INFO - 2024-08-02 10:36:28 --> Helper loaded: form_helper
INFO - 2024-08-02 10:36:28 --> Helper loaded: my_helper
INFO - 2024-08-02 10:36:28 --> Database Driver Class Initialized
INFO - 2024-08-02 10:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:36:31 --> Controller Class Initialized
DEBUG - 2024-08-02 10:36:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-02 10:46:28 --> Config Class Initialized
INFO - 2024-08-02 10:46:28 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:28 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:28 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:28 --> URI Class Initialized
INFO - 2024-08-02 10:46:28 --> Router Class Initialized
INFO - 2024-08-02 10:46:28 --> Output Class Initialized
INFO - 2024-08-02 10:46:28 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:28 --> Input Class Initialized
INFO - 2024-08-02 10:46:28 --> Language Class Initialized
INFO - 2024-08-02 10:46:28 --> Language Class Initialized
INFO - 2024-08-02 10:46:28 --> Config Class Initialized
INFO - 2024-08-02 10:46:28 --> Loader Class Initialized
INFO - 2024-08-02 10:46:28 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:28 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:28 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:28 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:28 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:28 --> Controller Class Initialized
INFO - 2024-08-02 10:46:28 --> Helper loaded: cookie_helper
INFO - 2024-08-02 10:46:28 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:28 --> Total execution time: 0.0500
INFO - 2024-08-02 10:46:29 --> Config Class Initialized
INFO - 2024-08-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:29 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:29 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:29 --> URI Class Initialized
INFO - 2024-08-02 10:46:29 --> Router Class Initialized
INFO - 2024-08-02 10:46:29 --> Output Class Initialized
INFO - 2024-08-02 10:46:29 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:29 --> Input Class Initialized
INFO - 2024-08-02 10:46:29 --> Language Class Initialized
INFO - 2024-08-02 10:46:29 --> Language Class Initialized
INFO - 2024-08-02 10:46:29 --> Config Class Initialized
INFO - 2024-08-02 10:46:29 --> Loader Class Initialized
INFO - 2024-08-02 10:46:29 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:29 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:29 --> Controller Class Initialized
INFO - 2024-08-02 10:46:29 --> Helper loaded: cookie_helper
INFO - 2024-08-02 10:46:29 --> Config Class Initialized
INFO - 2024-08-02 10:46:29 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:29 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:29 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:29 --> URI Class Initialized
INFO - 2024-08-02 10:46:29 --> Router Class Initialized
INFO - 2024-08-02 10:46:29 --> Output Class Initialized
INFO - 2024-08-02 10:46:29 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:29 --> Input Class Initialized
INFO - 2024-08-02 10:46:29 --> Language Class Initialized
INFO - 2024-08-02 10:46:29 --> Language Class Initialized
INFO - 2024-08-02 10:46:29 --> Config Class Initialized
INFO - 2024-08-02 10:46:29 --> Loader Class Initialized
INFO - 2024-08-02 10:46:29 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:29 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:29 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:29 --> Controller Class Initialized
DEBUG - 2024-08-02 10:46:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-02 10:46:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 10:46:29 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:29 --> Total execution time: 0.0388
INFO - 2024-08-02 10:46:38 --> Config Class Initialized
INFO - 2024-08-02 10:46:38 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:38 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:38 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:38 --> URI Class Initialized
INFO - 2024-08-02 10:46:38 --> Router Class Initialized
INFO - 2024-08-02 10:46:38 --> Output Class Initialized
INFO - 2024-08-02 10:46:38 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:38 --> Input Class Initialized
INFO - 2024-08-02 10:46:38 --> Language Class Initialized
INFO - 2024-08-02 10:46:38 --> Language Class Initialized
INFO - 2024-08-02 10:46:38 --> Config Class Initialized
INFO - 2024-08-02 10:46:38 --> Loader Class Initialized
INFO - 2024-08-02 10:46:38 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:38 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:38 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:38 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:38 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:38 --> Controller Class Initialized
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-02 10:46:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-02 10:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-02 10:46:41 --> Config Class Initialized
INFO - 2024-08-02 10:46:41 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:41 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:41 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:41 --> URI Class Initialized
INFO - 2024-08-02 10:46:41 --> Router Class Initialized
INFO - 2024-08-02 10:46:41 --> Output Class Initialized
INFO - 2024-08-02 10:46:41 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:41 --> Input Class Initialized
INFO - 2024-08-02 10:46:41 --> Language Class Initialized
INFO - 2024-08-02 10:46:41 --> Language Class Initialized
INFO - 2024-08-02 10:46:41 --> Config Class Initialized
INFO - 2024-08-02 10:46:41 --> Loader Class Initialized
INFO - 2024-08-02 10:46:41 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:41 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:41 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:41 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:41 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:42 --> Config Class Initialized
INFO - 2024-08-02 10:46:42 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:42 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:42 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:42 --> URI Class Initialized
INFO - 2024-08-02 10:46:42 --> Router Class Initialized
INFO - 2024-08-02 10:46:42 --> Output Class Initialized
INFO - 2024-08-02 10:46:42 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:42 --> Input Class Initialized
INFO - 2024-08-02 10:46:42 --> Language Class Initialized
INFO - 2024-08-02 10:46:42 --> Language Class Initialized
INFO - 2024-08-02 10:46:42 --> Config Class Initialized
INFO - 2024-08-02 10:46:42 --> Loader Class Initialized
INFO - 2024-08-02 10:46:42 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:42 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:42 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:42 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:42 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:43 --> Config Class Initialized
INFO - 2024-08-02 10:46:43 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:43 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:43 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:43 --> URI Class Initialized
INFO - 2024-08-02 10:46:43 --> Router Class Initialized
INFO - 2024-08-02 10:46:43 --> Output Class Initialized
INFO - 2024-08-02 10:46:43 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:43 --> Input Class Initialized
INFO - 2024-08-02 10:46:43 --> Language Class Initialized
INFO - 2024-08-02 10:46:43 --> Language Class Initialized
INFO - 2024-08-02 10:46:43 --> Config Class Initialized
INFO - 2024-08-02 10:46:43 --> Loader Class Initialized
INFO - 2024-08-02 10:46:43 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:43 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:43 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:43 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:43 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:44 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:44 --> Total execution time: 6.4183
INFO - 2024-08-02 10:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:44 --> Controller Class Initialized
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-02 10:46:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-02 10:46:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-02 10:46:47 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:47 --> Total execution time: 6.4984
INFO - 2024-08-02 10:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:47 --> Controller Class Initialized
ERROR - 2024-08-02 10:46:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 10:46:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-02 10:46:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 10:46:52 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:52 --> Total execution time: 10.4543
INFO - 2024-08-02 10:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:52 --> Controller Class Initialized
INFO - 2024-08-02 10:46:52 --> Config Class Initialized
INFO - 2024-08-02 10:46:52 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:52 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:52 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:52 --> URI Class Initialized
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 10:46:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-02 10:46:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 10:46:52 --> Router Class Initialized
INFO - 2024-08-02 10:46:52 --> Output Class Initialized
INFO - 2024-08-02 10:46:52 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:52 --> Input Class Initialized
INFO - 2024-08-02 10:46:52 --> Language Class Initialized
INFO - 2024-08-02 10:46:52 --> Language Class Initialized
INFO - 2024-08-02 10:46:52 --> Config Class Initialized
INFO - 2024-08-02 10:46:52 --> Loader Class Initialized
INFO - 2024-08-02 10:46:52 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:52 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:52 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:52 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:52 --> Database Driver Class Initialized
INFO - 2024-08-02 10:46:57 --> Final output sent to browser
DEBUG - 2024-08-02 10:46:57 --> Total execution time: 14.0220
INFO - 2024-08-02 10:46:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:46:57 --> Controller Class Initialized
INFO - 2024-08-02 10:46:57 --> Config Class Initialized
INFO - 2024-08-02 10:46:57 --> Hooks Class Initialized
DEBUG - 2024-08-02 10:46:57 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:46:57 --> Utf8 Class Initialized
INFO - 2024-08-02 10:46:57 --> URI Class Initialized
INFO - 2024-08-02 10:46:57 --> Router Class Initialized
INFO - 2024-08-02 10:46:57 --> Output Class Initialized
INFO - 2024-08-02 10:46:57 --> Security Class Initialized
DEBUG - 2024-08-02 10:46:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:46:57 --> Input Class Initialized
INFO - 2024-08-02 10:46:57 --> Language Class Initialized
INFO - 2024-08-02 10:46:57 --> Language Class Initialized
INFO - 2024-08-02 10:46:57 --> Config Class Initialized
INFO - 2024-08-02 10:46:57 --> Loader Class Initialized
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-02 10:46:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-02 10:46:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-02 10:46:57 --> Helper loaded: url_helper
INFO - 2024-08-02 10:46:57 --> Helper loaded: file_helper
INFO - 2024-08-02 10:46:57 --> Helper loaded: form_helper
INFO - 2024-08-02 10:46:57 --> Helper loaded: my_helper
INFO - 2024-08-02 10:46:57 --> Database Driver Class Initialized
INFO - 2024-08-02 10:47:00 --> Final output sent to browser
DEBUG - 2024-08-02 10:47:00 --> Total execution time: 8.0468
INFO - 2024-08-02 10:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:47:00 --> Controller Class Initialized
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
INFO - 2024-08-02 10:47:00 --> Config Class Initialized
INFO - 2024-08-02 10:47:00 --> Hooks Class Initialized
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
DEBUG - 2024-08-02 10:47:00 --> UTF-8 Support Enabled
INFO - 2024-08-02 10:47:00 --> Utf8 Class Initialized
INFO - 2024-08-02 10:47:00 --> URI Class Initialized
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-02 10:47:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-02 10:47:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-02 10:47:01 --> Router Class Initialized
INFO - 2024-08-02 10:47:01 --> Output Class Initialized
INFO - 2024-08-02 10:47:01 --> Security Class Initialized
DEBUG - 2024-08-02 10:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 10:47:01 --> Input Class Initialized
INFO - 2024-08-02 10:47:01 --> Language Class Initialized
INFO - 2024-08-02 10:47:01 --> Language Class Initialized
INFO - 2024-08-02 10:47:01 --> Config Class Initialized
INFO - 2024-08-02 10:47:01 --> Loader Class Initialized
INFO - 2024-08-02 10:47:01 --> Helper loaded: url_helper
INFO - 2024-08-02 10:47:01 --> Helper loaded: file_helper
INFO - 2024-08-02 10:47:01 --> Helper loaded: form_helper
INFO - 2024-08-02 10:47:01 --> Helper loaded: my_helper
INFO - 2024-08-02 10:47:01 --> Database Driver Class Initialized
INFO - 2024-08-02 10:47:06 --> Final output sent to browser
DEBUG - 2024-08-02 10:47:06 --> Total execution time: 9.5748
INFO - 2024-08-02 10:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 10:47:06 --> Controller Class Initialized
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-02 10:47:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-02 10:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-02 10:47:11 --> Final output sent to browser
DEBUG - 2024-08-02 10:47:11 --> Total execution time: 10.9129
INFO - 2024-08-02 12:41:36 --> Config Class Initialized
INFO - 2024-08-02 12:41:36 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:36 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:36 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:36 --> URI Class Initialized
DEBUG - 2024-08-02 12:41:36 --> No URI present. Default controller set.
INFO - 2024-08-02 12:41:36 --> Router Class Initialized
INFO - 2024-08-02 12:41:36 --> Output Class Initialized
INFO - 2024-08-02 12:41:36 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:36 --> Input Class Initialized
INFO - 2024-08-02 12:41:36 --> Language Class Initialized
INFO - 2024-08-02 12:41:36 --> Language Class Initialized
INFO - 2024-08-02 12:41:36 --> Config Class Initialized
INFO - 2024-08-02 12:41:36 --> Loader Class Initialized
INFO - 2024-08-02 12:41:36 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:36 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:36 --> Controller Class Initialized
INFO - 2024-08-02 12:41:36 --> Config Class Initialized
INFO - 2024-08-02 12:41:36 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:36 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:36 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:36 --> URI Class Initialized
INFO - 2024-08-02 12:41:36 --> Router Class Initialized
INFO - 2024-08-02 12:41:36 --> Output Class Initialized
INFO - 2024-08-02 12:41:36 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:36 --> Input Class Initialized
INFO - 2024-08-02 12:41:36 --> Language Class Initialized
INFO - 2024-08-02 12:41:36 --> Language Class Initialized
INFO - 2024-08-02 12:41:36 --> Config Class Initialized
INFO - 2024-08-02 12:41:36 --> Loader Class Initialized
INFO - 2024-08-02 12:41:36 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:36 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:36 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:36 --> Controller Class Initialized
DEBUG - 2024-08-02 12:41:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-08-02 12:41:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 12:41:36 --> Final output sent to browser
DEBUG - 2024-08-02 12:41:36 --> Total execution time: 0.0302
INFO - 2024-08-02 12:41:42 --> Config Class Initialized
INFO - 2024-08-02 12:41:42 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:42 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:42 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:42 --> URI Class Initialized
INFO - 2024-08-02 12:41:42 --> Router Class Initialized
INFO - 2024-08-02 12:41:42 --> Output Class Initialized
INFO - 2024-08-02 12:41:42 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:42 --> Input Class Initialized
INFO - 2024-08-02 12:41:42 --> Language Class Initialized
INFO - 2024-08-02 12:41:42 --> Language Class Initialized
INFO - 2024-08-02 12:41:42 --> Config Class Initialized
INFO - 2024-08-02 12:41:42 --> Loader Class Initialized
INFO - 2024-08-02 12:41:42 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:42 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:42 --> Controller Class Initialized
INFO - 2024-08-02 12:41:42 --> Helper loaded: cookie_helper
INFO - 2024-08-02 12:41:42 --> Final output sent to browser
DEBUG - 2024-08-02 12:41:42 --> Total execution time: 0.0399
INFO - 2024-08-02 12:41:42 --> Config Class Initialized
INFO - 2024-08-02 12:41:42 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:42 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:42 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:42 --> URI Class Initialized
INFO - 2024-08-02 12:41:42 --> Router Class Initialized
INFO - 2024-08-02 12:41:42 --> Output Class Initialized
INFO - 2024-08-02 12:41:42 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:42 --> Input Class Initialized
INFO - 2024-08-02 12:41:42 --> Language Class Initialized
INFO - 2024-08-02 12:41:42 --> Language Class Initialized
INFO - 2024-08-02 12:41:42 --> Config Class Initialized
INFO - 2024-08-02 12:41:42 --> Loader Class Initialized
INFO - 2024-08-02 12:41:42 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:42 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:42 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:42 --> Controller Class Initialized
DEBUG - 2024-08-02 12:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-08-02 12:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 12:41:42 --> Final output sent to browser
DEBUG - 2024-08-02 12:41:42 --> Total execution time: 0.0332
INFO - 2024-08-02 12:41:43 --> Config Class Initialized
INFO - 2024-08-02 12:41:43 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:43 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:43 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:43 --> URI Class Initialized
INFO - 2024-08-02 12:41:43 --> Router Class Initialized
INFO - 2024-08-02 12:41:43 --> Output Class Initialized
INFO - 2024-08-02 12:41:43 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:43 --> Input Class Initialized
INFO - 2024-08-02 12:41:43 --> Language Class Initialized
INFO - 2024-08-02 12:41:43 --> Language Class Initialized
INFO - 2024-08-02 12:41:43 --> Config Class Initialized
INFO - 2024-08-02 12:41:43 --> Loader Class Initialized
INFO - 2024-08-02 12:41:43 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:43 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:43 --> Controller Class Initialized
DEBUG - 2024-08-02 12:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-08-02 12:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 12:41:43 --> Final output sent to browser
DEBUG - 2024-08-02 12:41:43 --> Total execution time: 0.0289
INFO - 2024-08-02 12:41:43 --> Config Class Initialized
INFO - 2024-08-02 12:41:43 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:43 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:43 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:43 --> URI Class Initialized
INFO - 2024-08-02 12:41:43 --> Router Class Initialized
INFO - 2024-08-02 12:41:43 --> Output Class Initialized
INFO - 2024-08-02 12:41:43 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:43 --> Input Class Initialized
INFO - 2024-08-02 12:41:43 --> Language Class Initialized
ERROR - 2024-08-02 12:41:43 --> 404 Page Not Found: /index
INFO - 2024-08-02 12:41:43 --> Config Class Initialized
INFO - 2024-08-02 12:41:43 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:43 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:43 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:43 --> URI Class Initialized
INFO - 2024-08-02 12:41:43 --> Router Class Initialized
INFO - 2024-08-02 12:41:43 --> Output Class Initialized
INFO - 2024-08-02 12:41:43 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:43 --> Input Class Initialized
INFO - 2024-08-02 12:41:43 --> Language Class Initialized
INFO - 2024-08-02 12:41:43 --> Language Class Initialized
INFO - 2024-08-02 12:41:43 --> Config Class Initialized
INFO - 2024-08-02 12:41:43 --> Loader Class Initialized
INFO - 2024-08-02 12:41:43 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:43 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:43 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:43 --> Controller Class Initialized
INFO - 2024-08-02 12:41:50 --> Config Class Initialized
INFO - 2024-08-02 12:41:50 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:50 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:50 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:50 --> URI Class Initialized
INFO - 2024-08-02 12:41:50 --> Router Class Initialized
INFO - 2024-08-02 12:41:50 --> Output Class Initialized
INFO - 2024-08-02 12:41:50 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:50 --> Input Class Initialized
INFO - 2024-08-02 12:41:50 --> Language Class Initialized
INFO - 2024-08-02 12:41:50 --> Language Class Initialized
INFO - 2024-08-02 12:41:50 --> Config Class Initialized
INFO - 2024-08-02 12:41:50 --> Loader Class Initialized
INFO - 2024-08-02 12:41:50 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:50 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:50 --> Controller Class Initialized
INFO - 2024-08-02 12:41:50 --> Config Class Initialized
INFO - 2024-08-02 12:41:50 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:50 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:50 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:50 --> URI Class Initialized
INFO - 2024-08-02 12:41:50 --> Router Class Initialized
INFO - 2024-08-02 12:41:50 --> Output Class Initialized
INFO - 2024-08-02 12:41:50 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:50 --> Input Class Initialized
INFO - 2024-08-02 12:41:50 --> Language Class Initialized
INFO - 2024-08-02 12:41:50 --> Language Class Initialized
INFO - 2024-08-02 12:41:50 --> Config Class Initialized
INFO - 2024-08-02 12:41:50 --> Loader Class Initialized
INFO - 2024-08-02 12:41:50 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:50 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:51 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:51 --> Controller Class Initialized
INFO - 2024-08-02 12:41:51 --> Config Class Initialized
INFO - 2024-08-02 12:41:51 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:51 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:51 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:51 --> URI Class Initialized
INFO - 2024-08-02 12:41:51 --> Router Class Initialized
INFO - 2024-08-02 12:41:51 --> Output Class Initialized
INFO - 2024-08-02 12:41:51 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:51 --> Input Class Initialized
INFO - 2024-08-02 12:41:51 --> Language Class Initialized
INFO - 2024-08-02 12:41:51 --> Language Class Initialized
INFO - 2024-08-02 12:41:51 --> Config Class Initialized
INFO - 2024-08-02 12:41:51 --> Loader Class Initialized
INFO - 2024-08-02 12:41:51 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:51 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:51 --> Controller Class Initialized
INFO - 2024-08-02 12:41:51 --> Config Class Initialized
INFO - 2024-08-02 12:41:51 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:51 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:51 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:51 --> URI Class Initialized
INFO - 2024-08-02 12:41:51 --> Router Class Initialized
INFO - 2024-08-02 12:41:51 --> Output Class Initialized
INFO - 2024-08-02 12:41:51 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:51 --> Input Class Initialized
INFO - 2024-08-02 12:41:51 --> Language Class Initialized
INFO - 2024-08-02 12:41:51 --> Language Class Initialized
INFO - 2024-08-02 12:41:51 --> Config Class Initialized
INFO - 2024-08-02 12:41:51 --> Loader Class Initialized
INFO - 2024-08-02 12:41:51 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:51 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:51 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:51 --> Controller Class Initialized
INFO - 2024-08-02 12:41:53 --> Config Class Initialized
INFO - 2024-08-02 12:41:53 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:53 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:53 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:53 --> URI Class Initialized
INFO - 2024-08-02 12:41:53 --> Router Class Initialized
INFO - 2024-08-02 12:41:53 --> Output Class Initialized
INFO - 2024-08-02 12:41:53 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:53 --> Input Class Initialized
INFO - 2024-08-02 12:41:53 --> Language Class Initialized
INFO - 2024-08-02 12:41:53 --> Language Class Initialized
INFO - 2024-08-02 12:41:53 --> Config Class Initialized
INFO - 2024-08-02 12:41:53 --> Loader Class Initialized
INFO - 2024-08-02 12:41:53 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:53 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:53 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:53 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:53 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:53 --> Controller Class Initialized
INFO - 2024-08-02 12:41:54 --> Config Class Initialized
INFO - 2024-08-02 12:41:54 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:54 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:54 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:54 --> URI Class Initialized
INFO - 2024-08-02 12:41:54 --> Router Class Initialized
INFO - 2024-08-02 12:41:54 --> Output Class Initialized
INFO - 2024-08-02 12:41:54 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:54 --> Input Class Initialized
INFO - 2024-08-02 12:41:54 --> Language Class Initialized
INFO - 2024-08-02 12:41:54 --> Language Class Initialized
INFO - 2024-08-02 12:41:54 --> Config Class Initialized
INFO - 2024-08-02 12:41:54 --> Loader Class Initialized
INFO - 2024-08-02 12:41:54 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:54 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:54 --> Controller Class Initialized
INFO - 2024-08-02 12:41:54 --> Config Class Initialized
INFO - 2024-08-02 12:41:54 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:41:54 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:41:54 --> Utf8 Class Initialized
INFO - 2024-08-02 12:41:54 --> URI Class Initialized
INFO - 2024-08-02 12:41:54 --> Router Class Initialized
INFO - 2024-08-02 12:41:54 --> Output Class Initialized
INFO - 2024-08-02 12:41:54 --> Security Class Initialized
DEBUG - 2024-08-02 12:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:41:54 --> Input Class Initialized
INFO - 2024-08-02 12:41:54 --> Language Class Initialized
INFO - 2024-08-02 12:41:54 --> Language Class Initialized
INFO - 2024-08-02 12:41:54 --> Config Class Initialized
INFO - 2024-08-02 12:41:54 --> Loader Class Initialized
INFO - 2024-08-02 12:41:54 --> Helper loaded: url_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: file_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: form_helper
INFO - 2024-08-02 12:41:54 --> Helper loaded: my_helper
INFO - 2024-08-02 12:41:54 --> Database Driver Class Initialized
INFO - 2024-08-02 12:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:41:54 --> Controller Class Initialized
INFO - 2024-08-02 12:42:04 --> Config Class Initialized
INFO - 2024-08-02 12:42:04 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:04 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:04 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:04 --> URI Class Initialized
INFO - 2024-08-02 12:42:04 --> Router Class Initialized
INFO - 2024-08-02 12:42:04 --> Output Class Initialized
INFO - 2024-08-02 12:42:04 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:04 --> Input Class Initialized
INFO - 2024-08-02 12:42:04 --> Language Class Initialized
INFO - 2024-08-02 12:42:04 --> Language Class Initialized
INFO - 2024-08-02 12:42:04 --> Config Class Initialized
INFO - 2024-08-02 12:42:04 --> Loader Class Initialized
INFO - 2024-08-02 12:42:04 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:04 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:04 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:04 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:04 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:04 --> Controller Class Initialized
INFO - 2024-08-02 12:42:05 --> Config Class Initialized
INFO - 2024-08-02 12:42:05 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:05 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:05 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:05 --> URI Class Initialized
INFO - 2024-08-02 12:42:05 --> Router Class Initialized
INFO - 2024-08-02 12:42:05 --> Output Class Initialized
INFO - 2024-08-02 12:42:05 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:05 --> Input Class Initialized
INFO - 2024-08-02 12:42:05 --> Language Class Initialized
INFO - 2024-08-02 12:42:05 --> Language Class Initialized
INFO - 2024-08-02 12:42:05 --> Config Class Initialized
INFO - 2024-08-02 12:42:05 --> Loader Class Initialized
INFO - 2024-08-02 12:42:05 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:05 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:05 --> Controller Class Initialized
INFO - 2024-08-02 12:42:05 --> Config Class Initialized
INFO - 2024-08-02 12:42:05 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:05 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:05 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:05 --> URI Class Initialized
INFO - 2024-08-02 12:42:05 --> Router Class Initialized
INFO - 2024-08-02 12:42:05 --> Output Class Initialized
INFO - 2024-08-02 12:42:05 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:05 --> Input Class Initialized
INFO - 2024-08-02 12:42:05 --> Language Class Initialized
INFO - 2024-08-02 12:42:05 --> Language Class Initialized
INFO - 2024-08-02 12:42:05 --> Config Class Initialized
INFO - 2024-08-02 12:42:05 --> Loader Class Initialized
INFO - 2024-08-02 12:42:05 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:05 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:05 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:05 --> Controller Class Initialized
INFO - 2024-08-02 12:42:06 --> Config Class Initialized
INFO - 2024-08-02 12:42:06 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:06 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:06 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:06 --> URI Class Initialized
INFO - 2024-08-02 12:42:06 --> Router Class Initialized
INFO - 2024-08-02 12:42:06 --> Output Class Initialized
INFO - 2024-08-02 12:42:06 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:06 --> Input Class Initialized
INFO - 2024-08-02 12:42:06 --> Language Class Initialized
INFO - 2024-08-02 12:42:06 --> Language Class Initialized
INFO - 2024-08-02 12:42:06 --> Config Class Initialized
INFO - 2024-08-02 12:42:06 --> Loader Class Initialized
INFO - 2024-08-02 12:42:06 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:06 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:06 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:06 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:06 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:06 --> Controller Class Initialized
INFO - 2024-08-02 12:42:07 --> Config Class Initialized
INFO - 2024-08-02 12:42:07 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:07 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:07 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:07 --> URI Class Initialized
INFO - 2024-08-02 12:42:07 --> Router Class Initialized
INFO - 2024-08-02 12:42:07 --> Output Class Initialized
INFO - 2024-08-02 12:42:07 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:07 --> Input Class Initialized
INFO - 2024-08-02 12:42:07 --> Language Class Initialized
INFO - 2024-08-02 12:42:07 --> Language Class Initialized
INFO - 2024-08-02 12:42:07 --> Config Class Initialized
INFO - 2024-08-02 12:42:07 --> Loader Class Initialized
INFO - 2024-08-02 12:42:07 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:07 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:07 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:07 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:07 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:07 --> Controller Class Initialized
INFO - 2024-08-02 12:42:10 --> Config Class Initialized
INFO - 2024-08-02 12:42:10 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:10 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:10 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:10 --> URI Class Initialized
INFO - 2024-08-02 12:42:10 --> Router Class Initialized
INFO - 2024-08-02 12:42:10 --> Output Class Initialized
INFO - 2024-08-02 12:42:10 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:10 --> Input Class Initialized
INFO - 2024-08-02 12:42:10 --> Language Class Initialized
INFO - 2024-08-02 12:42:10 --> Language Class Initialized
INFO - 2024-08-02 12:42:10 --> Config Class Initialized
INFO - 2024-08-02 12:42:10 --> Loader Class Initialized
INFO - 2024-08-02 12:42:10 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:10 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:10 --> Controller Class Initialized
INFO - 2024-08-02 12:42:10 --> Config Class Initialized
INFO - 2024-08-02 12:42:10 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:10 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:10 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:10 --> URI Class Initialized
INFO - 2024-08-02 12:42:10 --> Router Class Initialized
INFO - 2024-08-02 12:42:10 --> Output Class Initialized
INFO - 2024-08-02 12:42:10 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:10 --> Input Class Initialized
INFO - 2024-08-02 12:42:10 --> Language Class Initialized
INFO - 2024-08-02 12:42:10 --> Language Class Initialized
INFO - 2024-08-02 12:42:10 --> Config Class Initialized
INFO - 2024-08-02 12:42:10 --> Loader Class Initialized
INFO - 2024-08-02 12:42:10 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:10 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:10 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:10 --> Controller Class Initialized
INFO - 2024-08-02 12:42:11 --> Config Class Initialized
INFO - 2024-08-02 12:42:11 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:11 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:11 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:11 --> URI Class Initialized
INFO - 2024-08-02 12:42:11 --> Router Class Initialized
INFO - 2024-08-02 12:42:11 --> Output Class Initialized
INFO - 2024-08-02 12:42:11 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:11 --> Input Class Initialized
INFO - 2024-08-02 12:42:11 --> Language Class Initialized
INFO - 2024-08-02 12:42:11 --> Language Class Initialized
INFO - 2024-08-02 12:42:11 --> Config Class Initialized
INFO - 2024-08-02 12:42:11 --> Loader Class Initialized
INFO - 2024-08-02 12:42:11 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:11 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:11 --> Controller Class Initialized
INFO - 2024-08-02 12:42:11 --> Config Class Initialized
INFO - 2024-08-02 12:42:11 --> Hooks Class Initialized
DEBUG - 2024-08-02 12:42:11 --> UTF-8 Support Enabled
INFO - 2024-08-02 12:42:11 --> Utf8 Class Initialized
INFO - 2024-08-02 12:42:11 --> URI Class Initialized
INFO - 2024-08-02 12:42:11 --> Router Class Initialized
INFO - 2024-08-02 12:42:11 --> Output Class Initialized
INFO - 2024-08-02 12:42:11 --> Security Class Initialized
DEBUG - 2024-08-02 12:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 12:42:11 --> Input Class Initialized
INFO - 2024-08-02 12:42:11 --> Language Class Initialized
INFO - 2024-08-02 12:42:11 --> Language Class Initialized
INFO - 2024-08-02 12:42:11 --> Config Class Initialized
INFO - 2024-08-02 12:42:11 --> Loader Class Initialized
INFO - 2024-08-02 12:42:11 --> Helper loaded: url_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: file_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: form_helper
INFO - 2024-08-02 12:42:11 --> Helper loaded: my_helper
INFO - 2024-08-02 12:42:11 --> Database Driver Class Initialized
INFO - 2024-08-02 12:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 12:42:11 --> Controller Class Initialized
INFO - 2024-08-02 21:08:52 --> Config Class Initialized
INFO - 2024-08-02 21:08:52 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:08:52 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:08:52 --> Utf8 Class Initialized
INFO - 2024-08-02 21:08:52 --> URI Class Initialized
INFO - 2024-08-02 21:08:52 --> Router Class Initialized
INFO - 2024-08-02 21:08:52 --> Output Class Initialized
INFO - 2024-08-02 21:08:52 --> Security Class Initialized
DEBUG - 2024-08-02 21:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:08:52 --> Input Class Initialized
INFO - 2024-08-02 21:08:52 --> Language Class Initialized
INFO - 2024-08-02 21:08:52 --> Language Class Initialized
INFO - 2024-08-02 21:08:52 --> Config Class Initialized
INFO - 2024-08-02 21:08:52 --> Loader Class Initialized
INFO - 2024-08-02 21:08:52 --> Helper loaded: url_helper
INFO - 2024-08-02 21:08:52 --> Helper loaded: file_helper
INFO - 2024-08-02 21:08:52 --> Helper loaded: form_helper
INFO - 2024-08-02 21:08:52 --> Helper loaded: my_helper
INFO - 2024-08-02 21:08:52 --> Database Driver Class Initialized
INFO - 2024-08-02 21:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:08:52 --> Controller Class Initialized
INFO - 2024-08-02 21:08:52 --> Helper loaded: cookie_helper
INFO - 2024-08-02 21:08:52 --> Final output sent to browser
DEBUG - 2024-08-02 21:08:52 --> Total execution time: 0.0583
INFO - 2024-08-02 21:08:53 --> Config Class Initialized
INFO - 2024-08-02 21:08:53 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:08:53 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:08:53 --> Utf8 Class Initialized
INFO - 2024-08-02 21:08:53 --> URI Class Initialized
INFO - 2024-08-02 21:08:53 --> Router Class Initialized
INFO - 2024-08-02 21:08:53 --> Output Class Initialized
INFO - 2024-08-02 21:08:53 --> Security Class Initialized
DEBUG - 2024-08-02 21:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:08:53 --> Input Class Initialized
INFO - 2024-08-02 21:08:53 --> Language Class Initialized
INFO - 2024-08-02 21:08:53 --> Language Class Initialized
INFO - 2024-08-02 21:08:53 --> Config Class Initialized
INFO - 2024-08-02 21:08:53 --> Loader Class Initialized
INFO - 2024-08-02 21:08:53 --> Helper loaded: url_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: file_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: form_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: my_helper
INFO - 2024-08-02 21:08:53 --> Database Driver Class Initialized
INFO - 2024-08-02 21:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:08:53 --> Controller Class Initialized
INFO - 2024-08-02 21:08:53 --> Helper loaded: cookie_helper
INFO - 2024-08-02 21:08:53 --> Config Class Initialized
INFO - 2024-08-02 21:08:53 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:08:53 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:08:53 --> Utf8 Class Initialized
INFO - 2024-08-02 21:08:53 --> URI Class Initialized
INFO - 2024-08-02 21:08:53 --> Router Class Initialized
INFO - 2024-08-02 21:08:53 --> Output Class Initialized
INFO - 2024-08-02 21:08:53 --> Security Class Initialized
DEBUG - 2024-08-02 21:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:08:53 --> Input Class Initialized
INFO - 2024-08-02 21:08:53 --> Language Class Initialized
INFO - 2024-08-02 21:08:53 --> Language Class Initialized
INFO - 2024-08-02 21:08:53 --> Config Class Initialized
INFO - 2024-08-02 21:08:53 --> Loader Class Initialized
INFO - 2024-08-02 21:08:53 --> Helper loaded: url_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: file_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: form_helper
INFO - 2024-08-02 21:08:53 --> Helper loaded: my_helper
INFO - 2024-08-02 21:08:53 --> Database Driver Class Initialized
INFO - 2024-08-02 21:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:08:53 --> Controller Class Initialized
DEBUG - 2024-08-02 21:08:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-02 21:08:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-02 21:08:53 --> Final output sent to browser
DEBUG - 2024-08-02 21:08:53 --> Total execution time: 0.0500
INFO - 2024-08-02 21:09:05 --> Config Class Initialized
INFO - 2024-08-02 21:09:05 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:05 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:05 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:05 --> URI Class Initialized
INFO - 2024-08-02 21:09:05 --> Router Class Initialized
INFO - 2024-08-02 21:09:05 --> Output Class Initialized
INFO - 2024-08-02 21:09:05 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:05 --> Input Class Initialized
INFO - 2024-08-02 21:09:05 --> Language Class Initialized
INFO - 2024-08-02 21:09:05 --> Language Class Initialized
INFO - 2024-08-02 21:09:05 --> Config Class Initialized
INFO - 2024-08-02 21:09:05 --> Loader Class Initialized
INFO - 2024-08-02 21:09:05 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:05 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:05 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:05 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:05 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:05 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-02 21:09:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-02 21:09:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 21:09:07 --> Config Class Initialized
INFO - 2024-08-02 21:09:07 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:07 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:07 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:07 --> URI Class Initialized
INFO - 2024-08-02 21:09:07 --> Router Class Initialized
INFO - 2024-08-02 21:09:07 --> Output Class Initialized
INFO - 2024-08-02 21:09:07 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:07 --> Input Class Initialized
INFO - 2024-08-02 21:09:07 --> Language Class Initialized
INFO - 2024-08-02 21:09:07 --> Language Class Initialized
INFO - 2024-08-02 21:09:07 --> Config Class Initialized
INFO - 2024-08-02 21:09:07 --> Loader Class Initialized
INFO - 2024-08-02 21:09:07 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:07 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:07 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:07 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:07 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:09 --> Final output sent to browser
DEBUG - 2024-08-02 21:09:09 --> Total execution time: 4.4790
INFO - 2024-08-02 21:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:09 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-02 21:09:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-02 21:09:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 21:09:12 --> Final output sent to browser
DEBUG - 2024-08-02 21:09:12 --> Total execution time: 4.6114
INFO - 2024-08-02 21:09:12 --> Config Class Initialized
INFO - 2024-08-02 21:09:12 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:12 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:12 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:12 --> URI Class Initialized
INFO - 2024-08-02 21:09:12 --> Router Class Initialized
INFO - 2024-08-02 21:09:12 --> Output Class Initialized
INFO - 2024-08-02 21:09:12 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:12 --> Input Class Initialized
INFO - 2024-08-02 21:09:12 --> Language Class Initialized
INFO - 2024-08-02 21:09:12 --> Language Class Initialized
INFO - 2024-08-02 21:09:12 --> Config Class Initialized
INFO - 2024-08-02 21:09:12 --> Loader Class Initialized
INFO - 2024-08-02 21:09:12 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:12 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:12 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:12 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:12 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:12 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-02 21:09:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-02 21:09:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 21:09:15 --> Final output sent to browser
DEBUG - 2024-08-02 21:09:15 --> Total execution time: 2.9826
INFO - 2024-08-02 21:09:15 --> Config Class Initialized
INFO - 2024-08-02 21:09:15 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:15 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:15 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:15 --> URI Class Initialized
INFO - 2024-08-02 21:09:15 --> Router Class Initialized
INFO - 2024-08-02 21:09:15 --> Output Class Initialized
INFO - 2024-08-02 21:09:15 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:15 --> Input Class Initialized
INFO - 2024-08-02 21:09:15 --> Language Class Initialized
INFO - 2024-08-02 21:09:15 --> Language Class Initialized
INFO - 2024-08-02 21:09:15 --> Config Class Initialized
INFO - 2024-08-02 21:09:15 --> Loader Class Initialized
INFO - 2024-08-02 21:09:15 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:15 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:15 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:15 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:15 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:15 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-02 21:09:15 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-02 21:09:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-02 21:09:18 --> Config Class Initialized
INFO - 2024-08-02 21:09:18 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:18 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:18 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:18 --> URI Class Initialized
INFO - 2024-08-02 21:09:18 --> Router Class Initialized
INFO - 2024-08-02 21:09:18 --> Output Class Initialized
INFO - 2024-08-02 21:09:18 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:18 --> Input Class Initialized
INFO - 2024-08-02 21:09:18 --> Language Class Initialized
INFO - 2024-08-02 21:09:18 --> Language Class Initialized
INFO - 2024-08-02 21:09:18 --> Config Class Initialized
INFO - 2024-08-02 21:09:18 --> Loader Class Initialized
INFO - 2024-08-02 21:09:18 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:18 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:18 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:18 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:18 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:18 --> Final output sent to browser
DEBUG - 2024-08-02 21:09:18 --> Total execution time: 2.9771
INFO - 2024-08-02 21:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:18 --> Controller Class Initialized
DEBUG - 2024-08-02 21:09:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-02 21:09:22 --> Final output sent to browser
DEBUG - 2024-08-02 21:09:22 --> Total execution time: 4.6792
INFO - 2024-08-02 21:09:22 --> Config Class Initialized
INFO - 2024-08-02 21:09:22 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:22 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:22 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:22 --> URI Class Initialized
INFO - 2024-08-02 21:09:22 --> Router Class Initialized
INFO - 2024-08-02 21:09:22 --> Output Class Initialized
INFO - 2024-08-02 21:09:22 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:22 --> Input Class Initialized
INFO - 2024-08-02 21:09:22 --> Language Class Initialized
INFO - 2024-08-02 21:09:22 --> Language Class Initialized
INFO - 2024-08-02 21:09:22 --> Config Class Initialized
INFO - 2024-08-02 21:09:22 --> Loader Class Initialized
INFO - 2024-08-02 21:09:22 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:22 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:22 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:22 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:22 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:22 --> Controller Class Initialized
DEBUG - 2024-08-02 21:09:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-02 21:09:23 --> Config Class Initialized
INFO - 2024-08-02 21:09:23 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:23 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:23 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:23 --> URI Class Initialized
INFO - 2024-08-02 21:09:23 --> Router Class Initialized
INFO - 2024-08-02 21:09:23 --> Output Class Initialized
INFO - 2024-08-02 21:09:23 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:23 --> Input Class Initialized
INFO - 2024-08-02 21:09:23 --> Language Class Initialized
INFO - 2024-08-02 21:09:23 --> Language Class Initialized
INFO - 2024-08-02 21:09:23 --> Config Class Initialized
INFO - 2024-08-02 21:09:23 --> Loader Class Initialized
INFO - 2024-08-02 21:09:23 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:23 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:23 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:23 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:23 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:23 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-02 21:09:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-02 21:09:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-02 21:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-02 21:09:24 --> Config Class Initialized
INFO - 2024-08-02 21:09:24 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:24 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:24 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:24 --> URI Class Initialized
INFO - 2024-08-02 21:09:24 --> Router Class Initialized
INFO - 2024-08-02 21:09:24 --> Output Class Initialized
INFO - 2024-08-02 21:09:24 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:24 --> Input Class Initialized
INFO - 2024-08-02 21:09:24 --> Language Class Initialized
INFO - 2024-08-02 21:09:24 --> Language Class Initialized
INFO - 2024-08-02 21:09:24 --> Config Class Initialized
INFO - 2024-08-02 21:09:24 --> Loader Class Initialized
INFO - 2024-08-02 21:09:24 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:24 --> Database Driver Class Initialized
INFO - 2024-08-02 21:09:24 --> Config Class Initialized
INFO - 2024-08-02 21:09:24 --> Hooks Class Initialized
DEBUG - 2024-08-02 21:09:24 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:24 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:24 --> URI Class Initialized
INFO - 2024-08-02 21:09:24 --> Router Class Initialized
INFO - 2024-08-02 21:09:24 --> Output Class Initialized
INFO - 2024-08-02 21:09:24 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:24 --> Input Class Initialized
INFO - 2024-08-02 21:09:24 --> Language Class Initialized
INFO - 2024-08-02 21:09:24 --> Language Class Initialized
INFO - 2024-08-02 21:09:24 --> Config Class Initialized
INFO - 2024-08-02 21:09:24 --> Loader Class Initialized
INFO - 2024-08-02 21:09:24 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:24 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:25 --> Database Driver Class Initialized
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-02 21:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:30 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-02 21:09:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-02 21:09:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-02 21:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:34 --> Controller Class Initialized
INFO - 2024-08-02 21:09:34 --> Config Class Initialized
INFO - 2024-08-02 21:09:34 --> Hooks Class Initialized
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-02 21:09:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-02 21:09:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
DEBUG - 2024-08-02 21:09:34 --> UTF-8 Support Enabled
INFO - 2024-08-02 21:09:34 --> Utf8 Class Initialized
INFO - 2024-08-02 21:09:34 --> URI Class Initialized
INFO - 2024-08-02 21:09:34 --> Router Class Initialized
INFO - 2024-08-02 21:09:34 --> Output Class Initialized
INFO - 2024-08-02 21:09:34 --> Security Class Initialized
DEBUG - 2024-08-02 21:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-02 21:09:34 --> Input Class Initialized
INFO - 2024-08-02 21:09:34 --> Language Class Initialized
INFO - 2024-08-02 21:09:34 --> Language Class Initialized
INFO - 2024-08-02 21:09:34 --> Config Class Initialized
INFO - 2024-08-02 21:09:34 --> Loader Class Initialized
INFO - 2024-08-02 21:09:34 --> Helper loaded: url_helper
INFO - 2024-08-02 21:09:34 --> Helper loaded: file_helper
INFO - 2024-08-02 21:09:34 --> Helper loaded: form_helper
INFO - 2024-08-02 21:09:34 --> Helper loaded: my_helper
INFO - 2024-08-02 21:09:34 --> Database Driver Class Initialized
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-02 21:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-02 21:09:38 --> Controller Class Initialized
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 230
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 231
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 235
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-02 21:09:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-02 21:09:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-08-02 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-02 21:09:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
