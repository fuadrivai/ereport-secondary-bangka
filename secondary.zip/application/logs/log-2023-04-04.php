<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-04-04 06:15:33 --> Config Class Initialized
INFO - 2023-04-04 06:15:33 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:33 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:33 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:33 --> URI Class Initialized
INFO - 2023-04-04 06:15:33 --> Router Class Initialized
INFO - 2023-04-04 06:15:33 --> Output Class Initialized
INFO - 2023-04-04 06:15:33 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:33 --> Input Class Initialized
INFO - 2023-04-04 06:15:33 --> Language Class Initialized
INFO - 2023-04-04 06:15:33 --> Language Class Initialized
INFO - 2023-04-04 06:15:33 --> Config Class Initialized
INFO - 2023-04-04 06:15:33 --> Loader Class Initialized
INFO - 2023-04-04 06:15:33 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:33 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:33 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:33 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:33 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:33 --> Controller Class Initialized
DEBUG - 2023-04-04 06:15:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-04 06:15:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:15:33 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:33 --> Total execution time: 0.7247
INFO - 2023-04-04 06:15:40 --> Config Class Initialized
INFO - 2023-04-04 06:15:40 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:40 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:40 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:40 --> URI Class Initialized
INFO - 2023-04-04 06:15:40 --> Router Class Initialized
INFO - 2023-04-04 06:15:40 --> Output Class Initialized
INFO - 2023-04-04 06:15:40 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:40 --> Input Class Initialized
INFO - 2023-04-04 06:15:40 --> Language Class Initialized
INFO - 2023-04-04 06:15:40 --> Language Class Initialized
INFO - 2023-04-04 06:15:40 --> Config Class Initialized
INFO - 2023-04-04 06:15:40 --> Loader Class Initialized
INFO - 2023-04-04 06:15:40 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:40 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:40 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:40 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:40 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:41 --> Controller Class Initialized
INFO - 2023-04-04 06:15:41 --> Helper loaded: cookie_helper
INFO - 2023-04-04 06:15:41 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:41 --> Total execution time: 0.0930
INFO - 2023-04-04 06:15:41 --> Config Class Initialized
INFO - 2023-04-04 06:15:41 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:41 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:41 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:41 --> URI Class Initialized
INFO - 2023-04-04 06:15:41 --> Router Class Initialized
INFO - 2023-04-04 06:15:41 --> Output Class Initialized
INFO - 2023-04-04 06:15:41 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:41 --> Input Class Initialized
INFO - 2023-04-04 06:15:41 --> Language Class Initialized
INFO - 2023-04-04 06:15:41 --> Language Class Initialized
INFO - 2023-04-04 06:15:41 --> Config Class Initialized
INFO - 2023-04-04 06:15:41 --> Loader Class Initialized
INFO - 2023-04-04 06:15:41 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:41 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:41 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:41 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:41 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:41 --> Controller Class Initialized
DEBUG - 2023-04-04 06:15:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-04 06:15:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:15:41 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:41 --> Total execution time: 0.1216
INFO - 2023-04-04 06:15:44 --> Config Class Initialized
INFO - 2023-04-04 06:15:44 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:44 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:44 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:44 --> URI Class Initialized
INFO - 2023-04-04 06:15:44 --> Router Class Initialized
INFO - 2023-04-04 06:15:44 --> Output Class Initialized
INFO - 2023-04-04 06:15:44 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:44 --> Input Class Initialized
INFO - 2023-04-04 06:15:44 --> Language Class Initialized
INFO - 2023-04-04 06:15:44 --> Language Class Initialized
INFO - 2023-04-04 06:15:44 --> Config Class Initialized
INFO - 2023-04-04 06:15:44 --> Loader Class Initialized
INFO - 2023-04-04 06:15:44 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:44 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:44 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:44 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:44 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:44 --> Controller Class Initialized
DEBUG - 2023-04-04 06:15:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-04 06:15:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:15:44 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:44 --> Total execution time: 0.0895
INFO - 2023-04-04 06:15:50 --> Config Class Initialized
INFO - 2023-04-04 06:15:50 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:50 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:50 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:50 --> URI Class Initialized
INFO - 2023-04-04 06:15:50 --> Router Class Initialized
INFO - 2023-04-04 06:15:50 --> Output Class Initialized
INFO - 2023-04-04 06:15:50 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:50 --> Input Class Initialized
INFO - 2023-04-04 06:15:50 --> Language Class Initialized
INFO - 2023-04-04 06:15:50 --> Language Class Initialized
INFO - 2023-04-04 06:15:50 --> Config Class Initialized
INFO - 2023-04-04 06:15:50 --> Loader Class Initialized
INFO - 2023-04-04 06:15:50 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:50 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:50 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:50 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:50 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:50 --> Controller Class Initialized
DEBUG - 2023-04-04 06:15:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-04 06:15:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:15:50 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:50 --> Total execution time: 0.0783
INFO - 2023-04-04 06:15:59 --> Config Class Initialized
INFO - 2023-04-04 06:15:59 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:15:59 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:15:59 --> Utf8 Class Initialized
INFO - 2023-04-04 06:15:59 --> URI Class Initialized
INFO - 2023-04-04 06:15:59 --> Router Class Initialized
INFO - 2023-04-04 06:15:59 --> Output Class Initialized
INFO - 2023-04-04 06:15:59 --> Security Class Initialized
DEBUG - 2023-04-04 06:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:15:59 --> Input Class Initialized
INFO - 2023-04-04 06:15:59 --> Language Class Initialized
INFO - 2023-04-04 06:15:59 --> Language Class Initialized
INFO - 2023-04-04 06:15:59 --> Config Class Initialized
INFO - 2023-04-04 06:15:59 --> Loader Class Initialized
INFO - 2023-04-04 06:15:59 --> Helper loaded: url_helper
INFO - 2023-04-04 06:15:59 --> Helper loaded: file_helper
INFO - 2023-04-04 06:15:59 --> Helper loaded: form_helper
INFO - 2023-04-04 06:15:59 --> Helper loaded: my_helper
INFO - 2023-04-04 06:15:59 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:15:59 --> Controller Class Initialized
DEBUG - 2023-04-04 06:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-04-04 06:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:15:59 --> Final output sent to browser
DEBUG - 2023-04-04 06:15:59 --> Total execution time: 0.0562
INFO - 2023-04-04 06:16:00 --> Config Class Initialized
INFO - 2023-04-04 06:16:00 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:16:00 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:16:00 --> Utf8 Class Initialized
INFO - 2023-04-04 06:16:00 --> URI Class Initialized
INFO - 2023-04-04 06:16:00 --> Router Class Initialized
INFO - 2023-04-04 06:16:00 --> Output Class Initialized
INFO - 2023-04-04 06:16:00 --> Security Class Initialized
DEBUG - 2023-04-04 06:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:16:00 --> Input Class Initialized
INFO - 2023-04-04 06:16:00 --> Language Class Initialized
INFO - 2023-04-04 06:16:00 --> Language Class Initialized
INFO - 2023-04-04 06:16:00 --> Config Class Initialized
INFO - 2023-04-04 06:16:00 --> Loader Class Initialized
INFO - 2023-04-04 06:16:00 --> Helper loaded: url_helper
INFO - 2023-04-04 06:16:00 --> Helper loaded: file_helper
INFO - 2023-04-04 06:16:00 --> Helper loaded: form_helper
INFO - 2023-04-04 06:16:00 --> Helper loaded: my_helper
INFO - 2023-04-04 06:16:00 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:16:00 --> Controller Class Initialized
DEBUG - 2023-04-04 06:16:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-04-04 06:16:02 --> Final output sent to browser
DEBUG - 2023-04-04 06:16:02 --> Total execution time: 2.0797
INFO - 2023-04-04 06:18:30 --> Config Class Initialized
INFO - 2023-04-04 06:18:30 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:18:30 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:18:30 --> Utf8 Class Initialized
INFO - 2023-04-04 06:18:30 --> URI Class Initialized
INFO - 2023-04-04 06:18:30 --> Router Class Initialized
INFO - 2023-04-04 06:18:30 --> Output Class Initialized
INFO - 2023-04-04 06:18:30 --> Security Class Initialized
DEBUG - 2023-04-04 06:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:18:30 --> Input Class Initialized
INFO - 2023-04-04 06:18:30 --> Language Class Initialized
INFO - 2023-04-04 06:18:30 --> Language Class Initialized
INFO - 2023-04-04 06:18:30 --> Config Class Initialized
INFO - 2023-04-04 06:18:30 --> Loader Class Initialized
INFO - 2023-04-04 06:18:30 --> Helper loaded: url_helper
INFO - 2023-04-04 06:18:30 --> Helper loaded: file_helper
INFO - 2023-04-04 06:18:30 --> Helper loaded: form_helper
INFO - 2023-04-04 06:18:30 --> Helper loaded: my_helper
INFO - 2023-04-04 06:18:30 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:18:30 --> Controller Class Initialized
DEBUG - 2023-04-04 06:18:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-04-04 06:18:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:18:30 --> Final output sent to browser
DEBUG - 2023-04-04 06:18:30 --> Total execution time: 0.0466
INFO - 2023-04-04 06:18:32 --> Config Class Initialized
INFO - 2023-04-04 06:18:32 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:18:32 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:18:32 --> Utf8 Class Initialized
INFO - 2023-04-04 06:18:32 --> URI Class Initialized
INFO - 2023-04-04 06:18:32 --> Router Class Initialized
INFO - 2023-04-04 06:18:32 --> Output Class Initialized
INFO - 2023-04-04 06:18:32 --> Security Class Initialized
DEBUG - 2023-04-04 06:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:18:32 --> Input Class Initialized
INFO - 2023-04-04 06:18:32 --> Language Class Initialized
INFO - 2023-04-04 06:18:32 --> Language Class Initialized
INFO - 2023-04-04 06:18:32 --> Config Class Initialized
INFO - 2023-04-04 06:18:32 --> Loader Class Initialized
INFO - 2023-04-04 06:18:32 --> Helper loaded: url_helper
INFO - 2023-04-04 06:18:32 --> Helper loaded: file_helper
INFO - 2023-04-04 06:18:32 --> Helper loaded: form_helper
INFO - 2023-04-04 06:18:32 --> Helper loaded: my_helper
INFO - 2023-04-04 06:18:32 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:18:32 --> Controller Class Initialized
DEBUG - 2023-04-04 06:18:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-04-04 06:18:33 --> Final output sent to browser
DEBUG - 2023-04-04 06:18:33 --> Total execution time: 1.2229
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:15 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:15 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:15 --> URI Class Initialized
INFO - 2023-04-04 06:27:15 --> Router Class Initialized
INFO - 2023-04-04 06:27:15 --> Output Class Initialized
INFO - 2023-04-04 06:27:15 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:15 --> Input Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Loader Class Initialized
INFO - 2023-04-04 06:27:15 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:15 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:15 --> Controller Class Initialized
INFO - 2023-04-04 06:27:15 --> Helper loaded: cookie_helper
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:15 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:15 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:15 --> URI Class Initialized
INFO - 2023-04-04 06:27:15 --> Router Class Initialized
INFO - 2023-04-04 06:27:15 --> Output Class Initialized
INFO - 2023-04-04 06:27:15 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:15 --> Input Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Loader Class Initialized
INFO - 2023-04-04 06:27:15 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:15 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:15 --> Controller Class Initialized
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:15 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:15 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:15 --> URI Class Initialized
INFO - 2023-04-04 06:27:15 --> Router Class Initialized
INFO - 2023-04-04 06:27:15 --> Output Class Initialized
INFO - 2023-04-04 06:27:15 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:15 --> Input Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Language Class Initialized
INFO - 2023-04-04 06:27:15 --> Config Class Initialized
INFO - 2023-04-04 06:27:15 --> Loader Class Initialized
INFO - 2023-04-04 06:27:15 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:15 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:15 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:15 --> Controller Class Initialized
DEBUG - 2023-04-04 06:27:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-04 06:27:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:27:15 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:15 --> Total execution time: 0.0244
INFO - 2023-04-04 06:27:20 --> Config Class Initialized
INFO - 2023-04-04 06:27:20 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:20 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:20 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:20 --> URI Class Initialized
INFO - 2023-04-04 06:27:20 --> Router Class Initialized
INFO - 2023-04-04 06:27:20 --> Output Class Initialized
INFO - 2023-04-04 06:27:20 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:20 --> Input Class Initialized
INFO - 2023-04-04 06:27:20 --> Language Class Initialized
INFO - 2023-04-04 06:27:20 --> Language Class Initialized
INFO - 2023-04-04 06:27:20 --> Config Class Initialized
INFO - 2023-04-04 06:27:20 --> Loader Class Initialized
INFO - 2023-04-04 06:27:20 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:20 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:20 --> Controller Class Initialized
INFO - 2023-04-04 06:27:20 --> Helper loaded: cookie_helper
INFO - 2023-04-04 06:27:20 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:20 --> Total execution time: 0.0374
INFO - 2023-04-04 06:27:20 --> Config Class Initialized
INFO - 2023-04-04 06:27:20 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:20 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:20 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:20 --> URI Class Initialized
INFO - 2023-04-04 06:27:20 --> Router Class Initialized
INFO - 2023-04-04 06:27:20 --> Output Class Initialized
INFO - 2023-04-04 06:27:20 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:20 --> Input Class Initialized
INFO - 2023-04-04 06:27:20 --> Language Class Initialized
INFO - 2023-04-04 06:27:20 --> Language Class Initialized
INFO - 2023-04-04 06:27:20 --> Config Class Initialized
INFO - 2023-04-04 06:27:20 --> Loader Class Initialized
INFO - 2023-04-04 06:27:20 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:20 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:20 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:20 --> Controller Class Initialized
DEBUG - 2023-04-04 06:27:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-04-04 06:27:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:27:20 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:20 --> Total execution time: 0.0292
INFO - 2023-04-04 06:27:21 --> Config Class Initialized
INFO - 2023-04-04 06:27:21 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:21 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:21 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:21 --> URI Class Initialized
INFO - 2023-04-04 06:27:21 --> Router Class Initialized
INFO - 2023-04-04 06:27:21 --> Output Class Initialized
INFO - 2023-04-04 06:27:21 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:21 --> Input Class Initialized
INFO - 2023-04-04 06:27:21 --> Language Class Initialized
INFO - 2023-04-04 06:27:21 --> Language Class Initialized
INFO - 2023-04-04 06:27:21 --> Config Class Initialized
INFO - 2023-04-04 06:27:21 --> Loader Class Initialized
INFO - 2023-04-04 06:27:21 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:21 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:21 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:21 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:21 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:21 --> Controller Class Initialized
DEBUG - 2023-04-04 06:27:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-04-04 06:27:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:27:21 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:21 --> Total execution time: 0.0449
INFO - 2023-04-04 06:27:25 --> Config Class Initialized
INFO - 2023-04-04 06:27:25 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:25 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:25 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:25 --> URI Class Initialized
INFO - 2023-04-04 06:27:25 --> Router Class Initialized
INFO - 2023-04-04 06:27:25 --> Output Class Initialized
INFO - 2023-04-04 06:27:25 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:25 --> Input Class Initialized
INFO - 2023-04-04 06:27:25 --> Language Class Initialized
INFO - 2023-04-04 06:27:25 --> Language Class Initialized
INFO - 2023-04-04 06:27:25 --> Config Class Initialized
INFO - 2023-04-04 06:27:25 --> Loader Class Initialized
INFO - 2023-04-04 06:27:25 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:25 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:25 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:25 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:25 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:26 --> Controller Class Initialized
DEBUG - 2023-04-04 06:27:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-04-04 06:27:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:27:26 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:26 --> Total execution time: 0.0904
INFO - 2023-04-04 06:27:26 --> Config Class Initialized
INFO - 2023-04-04 06:27:26 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:26 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:26 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:26 --> URI Class Initialized
INFO - 2023-04-04 06:27:26 --> Router Class Initialized
INFO - 2023-04-04 06:27:26 --> Output Class Initialized
INFO - 2023-04-04 06:27:26 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:26 --> Input Class Initialized
INFO - 2023-04-04 06:27:26 --> Language Class Initialized
INFO - 2023-04-04 06:27:26 --> Language Class Initialized
INFO - 2023-04-04 06:27:26 --> Config Class Initialized
INFO - 2023-04-04 06:27:26 --> Loader Class Initialized
INFO - 2023-04-04 06:27:26 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:26 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:26 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:26 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:26 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:26 --> Controller Class Initialized
INFO - 2023-04-04 06:27:55 --> Config Class Initialized
INFO - 2023-04-04 06:27:55 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:55 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:55 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:55 --> URI Class Initialized
INFO - 2023-04-04 06:27:55 --> Router Class Initialized
INFO - 2023-04-04 06:27:55 --> Output Class Initialized
INFO - 2023-04-04 06:27:55 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:55 --> Input Class Initialized
INFO - 2023-04-04 06:27:55 --> Language Class Initialized
INFO - 2023-04-04 06:27:55 --> Language Class Initialized
INFO - 2023-04-04 06:27:55 --> Config Class Initialized
INFO - 2023-04-04 06:27:55 --> Loader Class Initialized
INFO - 2023-04-04 06:27:55 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:55 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:55 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:55 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:55 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:55 --> Controller Class Initialized
INFO - 2023-04-04 06:27:55 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:55 --> Total execution time: 0.0406
INFO - 2023-04-04 06:27:57 --> Config Class Initialized
INFO - 2023-04-04 06:27:57 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:27:57 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:27:57 --> Utf8 Class Initialized
INFO - 2023-04-04 06:27:57 --> URI Class Initialized
INFO - 2023-04-04 06:27:57 --> Router Class Initialized
INFO - 2023-04-04 06:27:57 --> Output Class Initialized
INFO - 2023-04-04 06:27:57 --> Security Class Initialized
DEBUG - 2023-04-04 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:27:57 --> Input Class Initialized
INFO - 2023-04-04 06:27:57 --> Language Class Initialized
INFO - 2023-04-04 06:27:57 --> Language Class Initialized
INFO - 2023-04-04 06:27:57 --> Config Class Initialized
INFO - 2023-04-04 06:27:57 --> Loader Class Initialized
INFO - 2023-04-04 06:27:57 --> Helper loaded: url_helper
INFO - 2023-04-04 06:27:57 --> Helper loaded: file_helper
INFO - 2023-04-04 06:27:57 --> Helper loaded: form_helper
INFO - 2023-04-04 06:27:57 --> Helper loaded: my_helper
INFO - 2023-04-04 06:27:57 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:27:57 --> Controller Class Initialized
INFO - 2023-04-04 06:27:57 --> Final output sent to browser
DEBUG - 2023-04-04 06:27:57 --> Total execution time: 0.0241
INFO - 2023-04-04 06:28:19 --> Config Class Initialized
INFO - 2023-04-04 06:28:19 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:28:19 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:28:19 --> Utf8 Class Initialized
INFO - 2023-04-04 06:28:19 --> URI Class Initialized
INFO - 2023-04-04 06:28:19 --> Router Class Initialized
INFO - 2023-04-04 06:28:19 --> Output Class Initialized
INFO - 2023-04-04 06:28:19 --> Security Class Initialized
DEBUG - 2023-04-04 06:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:28:19 --> Input Class Initialized
INFO - 2023-04-04 06:28:19 --> Language Class Initialized
INFO - 2023-04-04 06:28:19 --> Language Class Initialized
INFO - 2023-04-04 06:28:19 --> Config Class Initialized
INFO - 2023-04-04 06:28:19 --> Loader Class Initialized
INFO - 2023-04-04 06:28:19 --> Helper loaded: url_helper
INFO - 2023-04-04 06:28:19 --> Helper loaded: file_helper
INFO - 2023-04-04 06:28:19 --> Helper loaded: form_helper
INFO - 2023-04-04 06:28:19 --> Helper loaded: my_helper
INFO - 2023-04-04 06:28:19 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:28:19 --> Controller Class Initialized
INFO - 2023-04-04 06:28:19 --> Final output sent to browser
DEBUG - 2023-04-04 06:28:19 --> Total execution time: 0.0250
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:40:37 --> Utf8 Class Initialized
INFO - 2023-04-04 06:40:37 --> URI Class Initialized
INFO - 2023-04-04 06:40:37 --> Router Class Initialized
INFO - 2023-04-04 06:40:37 --> Output Class Initialized
INFO - 2023-04-04 06:40:37 --> Security Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:40:37 --> Input Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Loader Class Initialized
INFO - 2023-04-04 06:40:37 --> Helper loaded: url_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: file_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: form_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: my_helper
INFO - 2023-04-04 06:40:37 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:40:37 --> Controller Class Initialized
INFO - 2023-04-04 06:40:37 --> Helper loaded: cookie_helper
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:40:37 --> Utf8 Class Initialized
INFO - 2023-04-04 06:40:37 --> URI Class Initialized
INFO - 2023-04-04 06:40:37 --> Router Class Initialized
INFO - 2023-04-04 06:40:37 --> Output Class Initialized
INFO - 2023-04-04 06:40:37 --> Security Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:40:37 --> Input Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Loader Class Initialized
INFO - 2023-04-04 06:40:37 --> Helper loaded: url_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: file_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: form_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: my_helper
INFO - 2023-04-04 06:40:37 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:40:37 --> Controller Class Initialized
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Hooks Class Initialized
DEBUG - 2023-04-04 06:40:37 --> UTF-8 Support Enabled
INFO - 2023-04-04 06:40:37 --> Utf8 Class Initialized
INFO - 2023-04-04 06:40:37 --> URI Class Initialized
INFO - 2023-04-04 06:40:37 --> Router Class Initialized
INFO - 2023-04-04 06:40:37 --> Output Class Initialized
INFO - 2023-04-04 06:40:37 --> Security Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 06:40:37 --> Input Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Language Class Initialized
INFO - 2023-04-04 06:40:37 --> Config Class Initialized
INFO - 2023-04-04 06:40:37 --> Loader Class Initialized
INFO - 2023-04-04 06:40:37 --> Helper loaded: url_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: file_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: form_helper
INFO - 2023-04-04 06:40:37 --> Helper loaded: my_helper
INFO - 2023-04-04 06:40:37 --> Database Driver Class Initialized
DEBUG - 2023-04-04 06:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 06:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 06:40:37 --> Controller Class Initialized
DEBUG - 2023-04-04 06:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-04-04 06:40:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 06:40:37 --> Final output sent to browser
DEBUG - 2023-04-04 06:40:37 --> Total execution time: 0.0266
INFO - 2023-04-04 08:04:00 --> Config Class Initialized
INFO - 2023-04-04 08:04:00 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:00 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:00 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:00 --> URI Class Initialized
INFO - 2023-04-04 08:04:00 --> Router Class Initialized
INFO - 2023-04-04 08:04:00 --> Output Class Initialized
INFO - 2023-04-04 08:04:00 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:00 --> Input Class Initialized
INFO - 2023-04-04 08:04:00 --> Language Class Initialized
INFO - 2023-04-04 08:04:00 --> Language Class Initialized
INFO - 2023-04-04 08:04:00 --> Config Class Initialized
INFO - 2023-04-04 08:04:00 --> Loader Class Initialized
INFO - 2023-04-04 08:04:00 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:00 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:00 --> Controller Class Initialized
INFO - 2023-04-04 08:04:00 --> Helper loaded: cookie_helper
INFO - 2023-04-04 08:04:00 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:00 --> Total execution time: 0.6886
INFO - 2023-04-04 08:04:00 --> Config Class Initialized
INFO - 2023-04-04 08:04:00 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:00 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:00 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:00 --> URI Class Initialized
INFO - 2023-04-04 08:04:00 --> Router Class Initialized
INFO - 2023-04-04 08:04:00 --> Output Class Initialized
INFO - 2023-04-04 08:04:00 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:00 --> Input Class Initialized
INFO - 2023-04-04 08:04:00 --> Language Class Initialized
INFO - 2023-04-04 08:04:00 --> Language Class Initialized
INFO - 2023-04-04 08:04:00 --> Config Class Initialized
INFO - 2023-04-04 08:04:00 --> Loader Class Initialized
INFO - 2023-04-04 08:04:00 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:00 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:00 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:00 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-04 08:04:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:00 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:00 --> Total execution time: 0.1385
INFO - 2023-04-04 08:04:03 --> Config Class Initialized
INFO - 2023-04-04 08:04:03 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:03 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:03 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:03 --> URI Class Initialized
INFO - 2023-04-04 08:04:03 --> Router Class Initialized
INFO - 2023-04-04 08:04:03 --> Output Class Initialized
INFO - 2023-04-04 08:04:03 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:03 --> Input Class Initialized
INFO - 2023-04-04 08:04:03 --> Language Class Initialized
INFO - 2023-04-04 08:04:03 --> Language Class Initialized
INFO - 2023-04-04 08:04:03 --> Config Class Initialized
INFO - 2023-04-04 08:04:03 --> Loader Class Initialized
INFO - 2023-04-04 08:04:03 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:03 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:03 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_guru/views/list.php
DEBUG - 2023-04-04 08:04:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:03 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:03 --> Total execution time: 0.0590
INFO - 2023-04-04 08:04:03 --> Config Class Initialized
INFO - 2023-04-04 08:04:03 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:03 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:03 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:03 --> URI Class Initialized
INFO - 2023-04-04 08:04:03 --> Router Class Initialized
INFO - 2023-04-04 08:04:03 --> Output Class Initialized
INFO - 2023-04-04 08:04:03 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:03 --> Input Class Initialized
INFO - 2023-04-04 08:04:03 --> Language Class Initialized
INFO - 2023-04-04 08:04:03 --> Language Class Initialized
INFO - 2023-04-04 08:04:03 --> Config Class Initialized
INFO - 2023-04-04 08:04:03 --> Loader Class Initialized
INFO - 2023-04-04 08:04:03 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:03 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:03 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:03 --> Controller Class Initialized
INFO - 2023-04-04 08:04:06 --> Config Class Initialized
INFO - 2023-04-04 08:04:06 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:06 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:06 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:06 --> URI Class Initialized
INFO - 2023-04-04 08:04:06 --> Router Class Initialized
INFO - 2023-04-04 08:04:06 --> Output Class Initialized
INFO - 2023-04-04 08:04:06 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:06 --> Input Class Initialized
INFO - 2023-04-04 08:04:06 --> Language Class Initialized
INFO - 2023-04-04 08:04:06 --> Language Class Initialized
INFO - 2023-04-04 08:04:06 --> Config Class Initialized
INFO - 2023-04-04 08:04:06 --> Loader Class Initialized
INFO - 2023-04-04 08:04:06 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:06 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:06 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/list.php
DEBUG - 2023-04-04 08:04:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:06 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:06 --> Total execution time: 0.0722
INFO - 2023-04-04 08:04:06 --> Config Class Initialized
INFO - 2023-04-04 08:04:06 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:06 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:06 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:06 --> URI Class Initialized
INFO - 2023-04-04 08:04:06 --> Router Class Initialized
INFO - 2023-04-04 08:04:06 --> Output Class Initialized
INFO - 2023-04-04 08:04:06 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:06 --> Input Class Initialized
INFO - 2023-04-04 08:04:06 --> Language Class Initialized
INFO - 2023-04-04 08:04:06 --> Language Class Initialized
INFO - 2023-04-04 08:04:06 --> Config Class Initialized
INFO - 2023-04-04 08:04:06 --> Loader Class Initialized
INFO - 2023-04-04 08:04:06 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:06 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:06 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:06 --> Controller Class Initialized
INFO - 2023-04-04 08:04:11 --> Config Class Initialized
INFO - 2023-04-04 08:04:11 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:11 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:11 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:11 --> URI Class Initialized
INFO - 2023-04-04 08:04:11 --> Router Class Initialized
INFO - 2023-04-04 08:04:11 --> Output Class Initialized
INFO - 2023-04-04 08:04:11 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:11 --> Input Class Initialized
INFO - 2023-04-04 08:04:11 --> Language Class Initialized
INFO - 2023-04-04 08:04:11 --> Language Class Initialized
INFO - 2023-04-04 08:04:11 --> Config Class Initialized
INFO - 2023-04-04 08:04:11 --> Loader Class Initialized
INFO - 2023-04-04 08:04:11 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:11 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:11 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:11 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:11 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:11 --> Controller Class Initialized
ERROR - 2023-04-04 08:04:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-04-04 08:04:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_siswa/views/form.php
DEBUG - 2023-04-04 08:04:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:11 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:11 --> Total execution time: 0.0880
INFO - 2023-04-04 08:04:32 --> Config Class Initialized
INFO - 2023-04-04 08:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:32 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:32 --> URI Class Initialized
INFO - 2023-04-04 08:04:32 --> Router Class Initialized
INFO - 2023-04-04 08:04:32 --> Output Class Initialized
INFO - 2023-04-04 08:04:32 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:32 --> Input Class Initialized
INFO - 2023-04-04 08:04:32 --> Language Class Initialized
INFO - 2023-04-04 08:04:32 --> Language Class Initialized
INFO - 2023-04-04 08:04:32 --> Config Class Initialized
INFO - 2023-04-04 08:04:32 --> Loader Class Initialized
INFO - 2023-04-04 08:04:32 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:32 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:32 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-04-04 08:04:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:32 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:32 --> Total execution time: 0.0851
INFO - 2023-04-04 08:04:32 --> Config Class Initialized
INFO - 2023-04-04 08:04:32 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:32 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:32 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:32 --> URI Class Initialized
INFO - 2023-04-04 08:04:32 --> Router Class Initialized
INFO - 2023-04-04 08:04:32 --> Output Class Initialized
INFO - 2023-04-04 08:04:32 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:32 --> Input Class Initialized
INFO - 2023-04-04 08:04:32 --> Language Class Initialized
INFO - 2023-04-04 08:04:32 --> Language Class Initialized
INFO - 2023-04-04 08:04:32 --> Config Class Initialized
INFO - 2023-04-04 08:04:32 --> Loader Class Initialized
INFO - 2023-04-04 08:04:32 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:32 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:32 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:32 --> Controller Class Initialized
INFO - 2023-04-04 08:04:41 --> Config Class Initialized
INFO - 2023-04-04 08:04:41 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:41 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:41 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:41 --> URI Class Initialized
INFO - 2023-04-04 08:04:41 --> Router Class Initialized
INFO - 2023-04-04 08:04:41 --> Output Class Initialized
INFO - 2023-04-04 08:04:41 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:41 --> Input Class Initialized
INFO - 2023-04-04 08:04:41 --> Language Class Initialized
INFO - 2023-04-04 08:04:41 --> Language Class Initialized
INFO - 2023-04-04 08:04:41 --> Config Class Initialized
INFO - 2023-04-04 08:04:41 --> Loader Class Initialized
INFO - 2023-04-04 08:04:41 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:41 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:41 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_kelas/views/list.php
DEBUG - 2023-04-04 08:04:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:41 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:41 --> Total execution time: 0.0549
INFO - 2023-04-04 08:04:41 --> Config Class Initialized
INFO - 2023-04-04 08:04:41 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:41 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:41 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:41 --> URI Class Initialized
INFO - 2023-04-04 08:04:41 --> Router Class Initialized
INFO - 2023-04-04 08:04:41 --> Output Class Initialized
INFO - 2023-04-04 08:04:41 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:41 --> Input Class Initialized
INFO - 2023-04-04 08:04:41 --> Language Class Initialized
INFO - 2023-04-04 08:04:41 --> Language Class Initialized
INFO - 2023-04-04 08:04:41 --> Config Class Initialized
INFO - 2023-04-04 08:04:41 --> Loader Class Initialized
INFO - 2023-04-04 08:04:41 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:41 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:41 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:41 --> Controller Class Initialized
INFO - 2023-04-04 08:04:42 --> Config Class Initialized
INFO - 2023-04-04 08:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:42 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:42 --> URI Class Initialized
INFO - 2023-04-04 08:04:42 --> Router Class Initialized
INFO - 2023-04-04 08:04:42 --> Output Class Initialized
INFO - 2023-04-04 08:04:42 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:42 --> Input Class Initialized
INFO - 2023-04-04 08:04:42 --> Language Class Initialized
INFO - 2023-04-04 08:04:42 --> Language Class Initialized
INFO - 2023-04-04 08:04:42 --> Config Class Initialized
INFO - 2023-04-04 08:04:42 --> Loader Class Initialized
INFO - 2023-04-04 08:04:42 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:42 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:42 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_ekstra/views/list.php
DEBUG - 2023-04-04 08:04:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:42 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:42 --> Total execution time: 0.0565
INFO - 2023-04-04 08:04:42 --> Config Class Initialized
INFO - 2023-04-04 08:04:42 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:42 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:42 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:42 --> URI Class Initialized
INFO - 2023-04-04 08:04:42 --> Router Class Initialized
INFO - 2023-04-04 08:04:42 --> Output Class Initialized
INFO - 2023-04-04 08:04:42 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:42 --> Input Class Initialized
INFO - 2023-04-04 08:04:42 --> Language Class Initialized
INFO - 2023-04-04 08:04:42 --> Language Class Initialized
INFO - 2023-04-04 08:04:42 --> Config Class Initialized
INFO - 2023-04-04 08:04:42 --> Loader Class Initialized
INFO - 2023-04-04 08:04:42 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:42 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:42 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:42 --> Controller Class Initialized
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:43 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:43 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:43 --> URI Class Initialized
INFO - 2023-04-04 08:04:43 --> Router Class Initialized
INFO - 2023-04-04 08:04:43 --> Output Class Initialized
INFO - 2023-04-04 08:04:43 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:43 --> Input Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Loader Class Initialized
INFO - 2023-04-04 08:04:43 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:43 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:43 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/tahun/views/list.php
DEBUG - 2023-04-04 08:04:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:43 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:43 --> Total execution time: 0.0502
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:43 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:43 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:43 --> URI Class Initialized
INFO - 2023-04-04 08:04:43 --> Router Class Initialized
INFO - 2023-04-04 08:04:43 --> Output Class Initialized
INFO - 2023-04-04 08:04:43 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:43 --> Input Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Loader Class Initialized
INFO - 2023-04-04 08:04:43 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:43 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:43 --> Controller Class Initialized
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:43 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:43 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:43 --> URI Class Initialized
INFO - 2023-04-04 08:04:43 --> Router Class Initialized
INFO - 2023-04-04 08:04:43 --> Output Class Initialized
INFO - 2023-04-04 08:04:43 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:43 --> Input Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Language Class Initialized
INFO - 2023-04-04 08:04:43 --> Config Class Initialized
INFO - 2023-04-04 08:04:43 --> Loader Class Initialized
INFO - 2023-04-04 08:04:43 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:43 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:43 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:43 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-04-04 08:04:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:43 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:43 --> Total execution time: 0.0624
INFO - 2023-04-04 08:04:56 --> Config Class Initialized
INFO - 2023-04-04 08:04:56 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:56 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:56 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:56 --> URI Class Initialized
INFO - 2023-04-04 08:04:56 --> Router Class Initialized
INFO - 2023-04-04 08:04:56 --> Output Class Initialized
INFO - 2023-04-04 08:04:56 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:56 --> Input Class Initialized
INFO - 2023-04-04 08:04:56 --> Language Class Initialized
INFO - 2023-04-04 08:04:56 --> Language Class Initialized
INFO - 2023-04-04 08:04:56 --> Config Class Initialized
INFO - 2023-04-04 08:04:56 --> Loader Class Initialized
INFO - 2023-04-04 08:04:56 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:56 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:56 --> Controller Class Initialized
DEBUG - 2023-04-04 08:04:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/tahun/views/list.php
DEBUG - 2023-04-04 08:04:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:04:56 --> Final output sent to browser
DEBUG - 2023-04-04 08:04:56 --> Total execution time: 0.0394
INFO - 2023-04-04 08:04:56 --> Config Class Initialized
INFO - 2023-04-04 08:04:56 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:04:56 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:04:56 --> Utf8 Class Initialized
INFO - 2023-04-04 08:04:56 --> URI Class Initialized
INFO - 2023-04-04 08:04:56 --> Router Class Initialized
INFO - 2023-04-04 08:04:56 --> Output Class Initialized
INFO - 2023-04-04 08:04:56 --> Security Class Initialized
DEBUG - 2023-04-04 08:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:04:56 --> Input Class Initialized
INFO - 2023-04-04 08:04:56 --> Language Class Initialized
INFO - 2023-04-04 08:04:56 --> Language Class Initialized
INFO - 2023-04-04 08:04:56 --> Config Class Initialized
INFO - 2023-04-04 08:04:56 --> Loader Class Initialized
INFO - 2023-04-04 08:04:56 --> Helper loaded: url_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: file_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: form_helper
INFO - 2023-04-04 08:04:56 --> Helper loaded: my_helper
INFO - 2023-04-04 08:04:56 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:04:56 --> Controller Class Initialized
INFO - 2023-04-04 08:05:05 --> Config Class Initialized
INFO - 2023-04-04 08:05:05 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:05:05 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:05:05 --> Utf8 Class Initialized
INFO - 2023-04-04 08:05:05 --> URI Class Initialized
INFO - 2023-04-04 08:05:05 --> Router Class Initialized
INFO - 2023-04-04 08:05:05 --> Output Class Initialized
INFO - 2023-04-04 08:05:05 --> Security Class Initialized
DEBUG - 2023-04-04 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:05:05 --> Input Class Initialized
INFO - 2023-04-04 08:05:05 --> Language Class Initialized
INFO - 2023-04-04 08:05:05 --> Language Class Initialized
INFO - 2023-04-04 08:05:05 --> Config Class Initialized
INFO - 2023-04-04 08:05:05 --> Loader Class Initialized
INFO - 2023-04-04 08:05:05 --> Helper loaded: url_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: file_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: form_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: my_helper
INFO - 2023-04-04 08:05:05 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:05:05 --> Controller Class Initialized
DEBUG - 2023-04-04 08:05:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_walikelas/views/list.php
DEBUG - 2023-04-04 08:05:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:05:05 --> Final output sent to browser
DEBUG - 2023-04-04 08:05:05 --> Total execution time: 0.0576
INFO - 2023-04-04 08:05:05 --> Config Class Initialized
INFO - 2023-04-04 08:05:05 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:05:05 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:05:05 --> Utf8 Class Initialized
INFO - 2023-04-04 08:05:05 --> URI Class Initialized
INFO - 2023-04-04 08:05:05 --> Router Class Initialized
INFO - 2023-04-04 08:05:05 --> Output Class Initialized
INFO - 2023-04-04 08:05:05 --> Security Class Initialized
DEBUG - 2023-04-04 08:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:05:05 --> Input Class Initialized
INFO - 2023-04-04 08:05:05 --> Language Class Initialized
INFO - 2023-04-04 08:05:05 --> Language Class Initialized
INFO - 2023-04-04 08:05:05 --> Config Class Initialized
INFO - 2023-04-04 08:05:05 --> Loader Class Initialized
INFO - 2023-04-04 08:05:05 --> Helper loaded: url_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: file_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: form_helper
INFO - 2023-04-04 08:05:05 --> Helper loaded: my_helper
INFO - 2023-04-04 08:05:05 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:05:05 --> Controller Class Initialized
INFO - 2023-04-04 08:05:08 --> Config Class Initialized
INFO - 2023-04-04 08:05:08 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:05:08 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:05:08 --> Utf8 Class Initialized
INFO - 2023-04-04 08:05:08 --> URI Class Initialized
INFO - 2023-04-04 08:05:08 --> Router Class Initialized
INFO - 2023-04-04 08:05:08 --> Output Class Initialized
INFO - 2023-04-04 08:05:08 --> Security Class Initialized
DEBUG - 2023-04-04 08:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:05:08 --> Input Class Initialized
INFO - 2023-04-04 08:05:08 --> Language Class Initialized
INFO - 2023-04-04 08:05:08 --> Language Class Initialized
INFO - 2023-04-04 08:05:08 --> Config Class Initialized
INFO - 2023-04-04 08:05:08 --> Loader Class Initialized
INFO - 2023-04-04 08:05:08 --> Helper loaded: url_helper
INFO - 2023-04-04 08:05:08 --> Helper loaded: file_helper
INFO - 2023-04-04 08:05:08 --> Helper loaded: form_helper
INFO - 2023-04-04 08:05:08 --> Helper loaded: my_helper
INFO - 2023-04-04 08:05:08 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:05:08 --> Controller Class Initialized
DEBUG - 2023-04-04 08:05:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-04-04 08:05:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:05:08 --> Final output sent to browser
DEBUG - 2023-04-04 08:05:08 --> Total execution time: 0.0326
INFO - 2023-04-04 08:05:09 --> Config Class Initialized
INFO - 2023-04-04 08:05:09 --> Hooks Class Initialized
DEBUG - 2023-04-04 08:05:09 --> UTF-8 Support Enabled
INFO - 2023-04-04 08:05:09 --> Utf8 Class Initialized
INFO - 2023-04-04 08:05:09 --> URI Class Initialized
DEBUG - 2023-04-04 08:05:09 --> No URI present. Default controller set.
INFO - 2023-04-04 08:05:09 --> Router Class Initialized
INFO - 2023-04-04 08:05:09 --> Output Class Initialized
INFO - 2023-04-04 08:05:09 --> Security Class Initialized
DEBUG - 2023-04-04 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-04-04 08:05:09 --> Input Class Initialized
INFO - 2023-04-04 08:05:09 --> Language Class Initialized
INFO - 2023-04-04 08:05:09 --> Language Class Initialized
INFO - 2023-04-04 08:05:09 --> Config Class Initialized
INFO - 2023-04-04 08:05:09 --> Loader Class Initialized
INFO - 2023-04-04 08:05:09 --> Helper loaded: url_helper
INFO - 2023-04-04 08:05:09 --> Helper loaded: file_helper
INFO - 2023-04-04 08:05:09 --> Helper loaded: form_helper
INFO - 2023-04-04 08:05:09 --> Helper loaded: my_helper
INFO - 2023-04-04 08:05:09 --> Database Driver Class Initialized
DEBUG - 2023-04-04 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-04-04 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-04-04 08:05:09 --> Controller Class Initialized
DEBUG - 2023-04-04 08:05:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-04-04 08:05:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-04-04 08:05:09 --> Final output sent to browser
DEBUG - 2023-04-04 08:05:09 --> Total execution time: 0.0376
