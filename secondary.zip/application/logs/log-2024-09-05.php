<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-05 09:30:33 --> Config Class Initialized
INFO - 2024-09-05 09:30:33 --> Hooks Class Initialized
DEBUG - 2024-09-05 09:30:33 --> UTF-8 Support Enabled
INFO - 2024-09-05 09:30:33 --> Utf8 Class Initialized
INFO - 2024-09-05 09:30:33 --> URI Class Initialized
INFO - 2024-09-05 09:30:33 --> Router Class Initialized
INFO - 2024-09-05 09:30:33 --> Output Class Initialized
INFO - 2024-09-05 09:30:33 --> Security Class Initialized
DEBUG - 2024-09-05 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 09:30:33 --> Input Class Initialized
INFO - 2024-09-05 09:30:33 --> Language Class Initialized
INFO - 2024-09-05 09:30:33 --> Language Class Initialized
INFO - 2024-09-05 09:30:33 --> Config Class Initialized
INFO - 2024-09-05 09:30:33 --> Loader Class Initialized
INFO - 2024-09-05 09:30:33 --> Helper loaded: url_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: file_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: form_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: my_helper
INFO - 2024-09-05 09:30:33 --> Database Driver Class Initialized
INFO - 2024-09-05 09:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 09:30:33 --> Controller Class Initialized
INFO - 2024-09-05 09:30:33 --> Helper loaded: cookie_helper
INFO - 2024-09-05 09:30:33 --> Final output sent to browser
DEBUG - 2024-09-05 09:30:33 --> Total execution time: 0.0637
INFO - 2024-09-05 09:30:33 --> Config Class Initialized
INFO - 2024-09-05 09:30:33 --> Hooks Class Initialized
DEBUG - 2024-09-05 09:30:33 --> UTF-8 Support Enabled
INFO - 2024-09-05 09:30:33 --> Utf8 Class Initialized
INFO - 2024-09-05 09:30:33 --> URI Class Initialized
INFO - 2024-09-05 09:30:33 --> Router Class Initialized
INFO - 2024-09-05 09:30:33 --> Output Class Initialized
INFO - 2024-09-05 09:30:33 --> Security Class Initialized
DEBUG - 2024-09-05 09:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 09:30:33 --> Input Class Initialized
INFO - 2024-09-05 09:30:33 --> Language Class Initialized
INFO - 2024-09-05 09:30:33 --> Language Class Initialized
INFO - 2024-09-05 09:30:33 --> Config Class Initialized
INFO - 2024-09-05 09:30:33 --> Loader Class Initialized
INFO - 2024-09-05 09:30:33 --> Helper loaded: url_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: file_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: form_helper
INFO - 2024-09-05 09:30:33 --> Helper loaded: my_helper
INFO - 2024-09-05 09:30:33 --> Database Driver Class Initialized
INFO - 2024-09-05 09:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 09:30:33 --> Controller Class Initialized
INFO - 2024-09-05 09:30:34 --> Helper loaded: cookie_helper
INFO - 2024-09-05 09:30:34 --> Config Class Initialized
INFO - 2024-09-05 09:30:34 --> Hooks Class Initialized
DEBUG - 2024-09-05 09:30:34 --> UTF-8 Support Enabled
INFO - 2024-09-05 09:30:34 --> Utf8 Class Initialized
INFO - 2024-09-05 09:30:34 --> URI Class Initialized
INFO - 2024-09-05 09:30:34 --> Router Class Initialized
INFO - 2024-09-05 09:30:34 --> Output Class Initialized
INFO - 2024-09-05 09:30:34 --> Security Class Initialized
DEBUG - 2024-09-05 09:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-05 09:30:34 --> Input Class Initialized
INFO - 2024-09-05 09:30:34 --> Language Class Initialized
INFO - 2024-09-05 09:30:34 --> Language Class Initialized
INFO - 2024-09-05 09:30:34 --> Config Class Initialized
INFO - 2024-09-05 09:30:34 --> Loader Class Initialized
INFO - 2024-09-05 09:30:34 --> Helper loaded: url_helper
INFO - 2024-09-05 09:30:34 --> Helper loaded: file_helper
INFO - 2024-09-05 09:30:34 --> Helper loaded: form_helper
INFO - 2024-09-05 09:30:34 --> Helper loaded: my_helper
INFO - 2024-09-05 09:30:34 --> Database Driver Class Initialized
INFO - 2024-09-05 09:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-05 09:30:34 --> Controller Class Initialized
DEBUG - 2024-09-05 09:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-05 09:30:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-05 09:30:34 --> Final output sent to browser
DEBUG - 2024-09-05 09:30:34 --> Total execution time: 0.0354
