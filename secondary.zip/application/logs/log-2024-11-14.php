<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-14 12:22:23 --> Config Class Initialized
INFO - 2024-11-14 12:22:23 --> Hooks Class Initialized
DEBUG - 2024-11-14 12:22:23 --> UTF-8 Support Enabled
INFO - 2024-11-14 12:22:23 --> Utf8 Class Initialized
INFO - 2024-11-14 12:22:23 --> URI Class Initialized
INFO - 2024-11-14 12:22:23 --> Router Class Initialized
INFO - 2024-11-14 12:22:23 --> Output Class Initialized
INFO - 2024-11-14 12:22:23 --> Security Class Initialized
DEBUG - 2024-11-14 12:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 12:22:23 --> Input Class Initialized
INFO - 2024-11-14 12:22:23 --> Language Class Initialized
INFO - 2024-11-14 12:22:23 --> Language Class Initialized
INFO - 2024-11-14 12:22:23 --> Config Class Initialized
INFO - 2024-11-14 12:22:23 --> Loader Class Initialized
INFO - 2024-11-14 12:22:23 --> Helper loaded: url_helper
INFO - 2024-11-14 12:22:23 --> Helper loaded: file_helper
INFO - 2024-11-14 12:22:23 --> Helper loaded: form_helper
INFO - 2024-11-14 12:22:23 --> Helper loaded: my_helper
INFO - 2024-11-14 12:22:23 --> Database Driver Class Initialized
INFO - 2024-11-14 12:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 12:22:23 --> Controller Class Initialized
INFO - 2024-11-14 12:22:23 --> Helper loaded: cookie_helper
INFO - 2024-11-14 12:22:23 --> Final output sent to browser
DEBUG - 2024-11-14 12:22:23 --> Total execution time: 0.0665
INFO - 2024-11-14 12:22:24 --> Config Class Initialized
INFO - 2024-11-14 12:22:24 --> Hooks Class Initialized
DEBUG - 2024-11-14 12:22:24 --> UTF-8 Support Enabled
INFO - 2024-11-14 12:22:24 --> Utf8 Class Initialized
INFO - 2024-11-14 12:22:24 --> URI Class Initialized
INFO - 2024-11-14 12:22:24 --> Router Class Initialized
INFO - 2024-11-14 12:22:24 --> Output Class Initialized
INFO - 2024-11-14 12:22:24 --> Security Class Initialized
DEBUG - 2024-11-14 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 12:22:24 --> Input Class Initialized
INFO - 2024-11-14 12:22:24 --> Language Class Initialized
INFO - 2024-11-14 12:22:24 --> Language Class Initialized
INFO - 2024-11-14 12:22:24 --> Config Class Initialized
INFO - 2024-11-14 12:22:24 --> Loader Class Initialized
INFO - 2024-11-14 12:22:24 --> Helper loaded: url_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: file_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: form_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: my_helper
INFO - 2024-11-14 12:22:24 --> Database Driver Class Initialized
INFO - 2024-11-14 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 12:22:24 --> Controller Class Initialized
INFO - 2024-11-14 12:22:24 --> Helper loaded: cookie_helper
INFO - 2024-11-14 12:22:24 --> Config Class Initialized
INFO - 2024-11-14 12:22:24 --> Hooks Class Initialized
DEBUG - 2024-11-14 12:22:24 --> UTF-8 Support Enabled
INFO - 2024-11-14 12:22:24 --> Utf8 Class Initialized
INFO - 2024-11-14 12:22:24 --> URI Class Initialized
INFO - 2024-11-14 12:22:24 --> Router Class Initialized
INFO - 2024-11-14 12:22:24 --> Output Class Initialized
INFO - 2024-11-14 12:22:24 --> Security Class Initialized
DEBUG - 2024-11-14 12:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 12:22:24 --> Input Class Initialized
INFO - 2024-11-14 12:22:24 --> Language Class Initialized
INFO - 2024-11-14 12:22:24 --> Language Class Initialized
INFO - 2024-11-14 12:22:24 --> Config Class Initialized
INFO - 2024-11-14 12:22:24 --> Loader Class Initialized
INFO - 2024-11-14 12:22:24 --> Helper loaded: url_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: file_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: form_helper
INFO - 2024-11-14 12:22:24 --> Helper loaded: my_helper
INFO - 2024-11-14 12:22:24 --> Database Driver Class Initialized
INFO - 2024-11-14 12:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 12:22:24 --> Controller Class Initialized
DEBUG - 2024-11-14 12:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-11-14 12:22:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-14 12:22:24 --> Final output sent to browser
DEBUG - 2024-11-14 12:22:24 --> Total execution time: 0.1914
INFO - 2024-11-14 12:22:27 --> Config Class Initialized
INFO - 2024-11-14 12:22:27 --> Hooks Class Initialized
DEBUG - 2024-11-14 12:22:27 --> UTF-8 Support Enabled
INFO - 2024-11-14 12:22:27 --> Utf8 Class Initialized
INFO - 2024-11-14 12:22:27 --> URI Class Initialized
INFO - 2024-11-14 12:22:27 --> Router Class Initialized
INFO - 2024-11-14 12:22:27 --> Output Class Initialized
INFO - 2024-11-14 12:22:27 --> Security Class Initialized
DEBUG - 2024-11-14 12:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-14 12:22:27 --> Input Class Initialized
INFO - 2024-11-14 12:22:27 --> Language Class Initialized
INFO - 2024-11-14 12:22:27 --> Language Class Initialized
INFO - 2024-11-14 12:22:27 --> Config Class Initialized
INFO - 2024-11-14 12:22:27 --> Loader Class Initialized
INFO - 2024-11-14 12:22:27 --> Helper loaded: url_helper
INFO - 2024-11-14 12:22:27 --> Helper loaded: file_helper
INFO - 2024-11-14 12:22:27 --> Helper loaded: form_helper
INFO - 2024-11-14 12:22:27 --> Helper loaded: my_helper
INFO - 2024-11-14 12:22:27 --> Database Driver Class Initialized
INFO - 2024-11-14 12:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-14 12:22:27 --> Controller Class Initialized
DEBUG - 2024-11-14 12:22:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-11-14 12:22:31 --> Final output sent to browser
DEBUG - 2024-11-14 12:22:31 --> Total execution time: 3.1442
