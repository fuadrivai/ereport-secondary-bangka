<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-22 10:49:20 --> Config Class Initialized
INFO - 2023-08-22 10:49:20 --> Hooks Class Initialized
DEBUG - 2023-08-22 10:49:20 --> UTF-8 Support Enabled
INFO - 2023-08-22 10:49:20 --> Utf8 Class Initialized
INFO - 2023-08-22 10:49:20 --> URI Class Initialized
INFO - 2023-08-22 10:49:20 --> Router Class Initialized
INFO - 2023-08-22 10:49:20 --> Output Class Initialized
INFO - 2023-08-22 10:49:20 --> Security Class Initialized
DEBUG - 2023-08-22 10:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 10:49:20 --> Input Class Initialized
INFO - 2023-08-22 10:49:20 --> Language Class Initialized
INFO - 2023-08-22 10:49:20 --> Language Class Initialized
INFO - 2023-08-22 10:49:20 --> Config Class Initialized
INFO - 2023-08-22 10:49:20 --> Loader Class Initialized
INFO - 2023-08-22 10:49:20 --> Helper loaded: url_helper
INFO - 2023-08-22 10:49:20 --> Helper loaded: file_helper
INFO - 2023-08-22 10:49:20 --> Helper loaded: form_helper
INFO - 2023-08-22 10:49:20 --> Helper loaded: my_helper
INFO - 2023-08-22 10:49:20 --> Database Driver Class Initialized
INFO - 2023-08-22 10:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 10:49:20 --> Controller Class Initialized
DEBUG - 2023-08-22 10:49:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-22 10:49:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-22 10:49:20 --> Final output sent to browser
DEBUG - 2023-08-22 10:49:20 --> Total execution time: 0.0727
INFO - 2023-08-22 20:07:42 --> Config Class Initialized
INFO - 2023-08-22 20:07:42 --> Hooks Class Initialized
DEBUG - 2023-08-22 20:07:42 --> UTF-8 Support Enabled
INFO - 2023-08-22 20:07:42 --> Utf8 Class Initialized
INFO - 2023-08-22 20:07:42 --> URI Class Initialized
INFO - 2023-08-22 20:07:42 --> Router Class Initialized
INFO - 2023-08-22 20:07:42 --> Output Class Initialized
INFO - 2023-08-22 20:07:42 --> Security Class Initialized
DEBUG - 2023-08-22 20:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-22 20:07:42 --> Input Class Initialized
INFO - 2023-08-22 20:07:42 --> Language Class Initialized
INFO - 2023-08-22 20:07:42 --> Language Class Initialized
INFO - 2023-08-22 20:07:42 --> Config Class Initialized
INFO - 2023-08-22 20:07:42 --> Loader Class Initialized
INFO - 2023-08-22 20:07:42 --> Helper loaded: url_helper
INFO - 2023-08-22 20:07:42 --> Helper loaded: file_helper
INFO - 2023-08-22 20:07:42 --> Helper loaded: form_helper
INFO - 2023-08-22 20:07:42 --> Helper loaded: my_helper
INFO - 2023-08-22 20:07:42 --> Database Driver Class Initialized
INFO - 2023-08-22 20:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-22 20:07:42 --> Controller Class Initialized
DEBUG - 2023-08-22 20:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-22 20:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-22 20:07:42 --> Final output sent to browser
DEBUG - 2023-08-22 20:07:42 --> Total execution time: 0.0670
