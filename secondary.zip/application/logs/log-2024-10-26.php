<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Hooks Class Initialized
DEBUG - 2024-10-26 11:04:07 --> UTF-8 Support Enabled
INFO - 2024-10-26 11:04:07 --> Utf8 Class Initialized
INFO - 2024-10-26 11:04:07 --> URI Class Initialized
INFO - 2024-10-26 11:04:07 --> Router Class Initialized
INFO - 2024-10-26 11:04:07 --> Output Class Initialized
INFO - 2024-10-26 11:04:07 --> Security Class Initialized
DEBUG - 2024-10-26 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 11:04:07 --> Input Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Loader Class Initialized
INFO - 2024-10-26 11:04:07 --> Helper loaded: url_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: file_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: form_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: my_helper
INFO - 2024-10-26 11:04:07 --> Database Driver Class Initialized
INFO - 2024-10-26 11:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 11:04:07 --> Controller Class Initialized
INFO - 2024-10-26 11:04:07 --> Helper loaded: cookie_helper
INFO - 2024-10-26 11:04:07 --> Final output sent to browser
DEBUG - 2024-10-26 11:04:07 --> Total execution time: 0.0759
INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Hooks Class Initialized
DEBUG - 2024-10-26 11:04:07 --> UTF-8 Support Enabled
INFO - 2024-10-26 11:04:07 --> Utf8 Class Initialized
INFO - 2024-10-26 11:04:07 --> URI Class Initialized
INFO - 2024-10-26 11:04:07 --> Router Class Initialized
INFO - 2024-10-26 11:04:07 --> Output Class Initialized
INFO - 2024-10-26 11:04:07 --> Security Class Initialized
DEBUG - 2024-10-26 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 11:04:07 --> Input Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Loader Class Initialized
INFO - 2024-10-26 11:04:07 --> Helper loaded: url_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: file_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: form_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: my_helper
INFO - 2024-10-26 11:04:07 --> Database Driver Class Initialized
INFO - 2024-10-26 11:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 11:04:07 --> Controller Class Initialized
INFO - 2024-10-26 11:04:07 --> Helper loaded: cookie_helper
INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Hooks Class Initialized
DEBUG - 2024-10-26 11:04:07 --> UTF-8 Support Enabled
INFO - 2024-10-26 11:04:07 --> Utf8 Class Initialized
INFO - 2024-10-26 11:04:07 --> URI Class Initialized
INFO - 2024-10-26 11:04:07 --> Router Class Initialized
INFO - 2024-10-26 11:04:07 --> Output Class Initialized
INFO - 2024-10-26 11:04:07 --> Security Class Initialized
DEBUG - 2024-10-26 11:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 11:04:07 --> Input Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Language Class Initialized
INFO - 2024-10-26 11:04:07 --> Config Class Initialized
INFO - 2024-10-26 11:04:07 --> Loader Class Initialized
INFO - 2024-10-26 11:04:07 --> Helper loaded: url_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: file_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: form_helper
INFO - 2024-10-26 11:04:07 --> Helper loaded: my_helper
INFO - 2024-10-26 11:04:07 --> Database Driver Class Initialized
INFO - 2024-10-26 11:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 11:04:07 --> Controller Class Initialized
DEBUG - 2024-10-26 11:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-26 11:04:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-26 11:04:07 --> Final output sent to browser
DEBUG - 2024-10-26 11:04:07 --> Total execution time: 0.0437
INFO - 2024-10-26 11:04:09 --> Config Class Initialized
INFO - 2024-10-26 11:04:09 --> Hooks Class Initialized
DEBUG - 2024-10-26 11:04:09 --> UTF-8 Support Enabled
INFO - 2024-10-26 11:04:09 --> Utf8 Class Initialized
INFO - 2024-10-26 11:04:09 --> URI Class Initialized
INFO - 2024-10-26 11:04:09 --> Router Class Initialized
INFO - 2024-10-26 11:04:09 --> Output Class Initialized
INFO - 2024-10-26 11:04:09 --> Security Class Initialized
DEBUG - 2024-10-26 11:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 11:04:09 --> Input Class Initialized
INFO - 2024-10-26 11:04:09 --> Language Class Initialized
INFO - 2024-10-26 11:04:09 --> Language Class Initialized
INFO - 2024-10-26 11:04:09 --> Config Class Initialized
INFO - 2024-10-26 11:04:09 --> Loader Class Initialized
INFO - 2024-10-26 11:04:09 --> Helper loaded: url_helper
INFO - 2024-10-26 11:04:09 --> Helper loaded: file_helper
INFO - 2024-10-26 11:04:09 --> Helper loaded: form_helper
INFO - 2024-10-26 11:04:09 --> Helper loaded: my_helper
INFO - 2024-10-26 11:04:09 --> Database Driver Class Initialized
INFO - 2024-10-26 11:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 11:04:09 --> Controller Class Initialized
DEBUG - 2024-10-26 11:04:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-26 11:04:12 --> Final output sent to browser
DEBUG - 2024-10-26 11:04:12 --> Total execution time: 2.5923
INFO - 2024-10-26 16:27:20 --> Config Class Initialized
INFO - 2024-10-26 16:27:20 --> Hooks Class Initialized
DEBUG - 2024-10-26 16:27:20 --> UTF-8 Support Enabled
INFO - 2024-10-26 16:27:20 --> Utf8 Class Initialized
INFO - 2024-10-26 16:27:20 --> URI Class Initialized
INFO - 2024-10-26 16:27:20 --> Router Class Initialized
INFO - 2024-10-26 16:27:20 --> Output Class Initialized
INFO - 2024-10-26 16:27:20 --> Security Class Initialized
DEBUG - 2024-10-26 16:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 16:27:20 --> Input Class Initialized
INFO - 2024-10-26 16:27:20 --> Language Class Initialized
INFO - 2024-10-26 16:27:20 --> Language Class Initialized
INFO - 2024-10-26 16:27:20 --> Config Class Initialized
INFO - 2024-10-26 16:27:20 --> Loader Class Initialized
INFO - 2024-10-26 16:27:20 --> Helper loaded: url_helper
INFO - 2024-10-26 16:27:20 --> Helper loaded: file_helper
INFO - 2024-10-26 16:27:20 --> Helper loaded: form_helper
INFO - 2024-10-26 16:27:20 --> Helper loaded: my_helper
INFO - 2024-10-26 16:27:20 --> Database Driver Class Initialized
INFO - 2024-10-26 16:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 16:27:20 --> Controller Class Initialized
INFO - 2024-10-26 16:27:20 --> Helper loaded: cookie_helper
INFO - 2024-10-26 16:27:20 --> Final output sent to browser
DEBUG - 2024-10-26 16:27:20 --> Total execution time: 0.0911
INFO - 2024-10-26 16:27:21 --> Config Class Initialized
INFO - 2024-10-26 16:27:21 --> Hooks Class Initialized
DEBUG - 2024-10-26 16:27:21 --> UTF-8 Support Enabled
INFO - 2024-10-26 16:27:21 --> Utf8 Class Initialized
INFO - 2024-10-26 16:27:21 --> URI Class Initialized
INFO - 2024-10-26 16:27:21 --> Router Class Initialized
INFO - 2024-10-26 16:27:21 --> Output Class Initialized
INFO - 2024-10-26 16:27:21 --> Security Class Initialized
DEBUG - 2024-10-26 16:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 16:27:21 --> Input Class Initialized
INFO - 2024-10-26 16:27:21 --> Language Class Initialized
INFO - 2024-10-26 16:27:21 --> Language Class Initialized
INFO - 2024-10-26 16:27:21 --> Config Class Initialized
INFO - 2024-10-26 16:27:21 --> Loader Class Initialized
INFO - 2024-10-26 16:27:21 --> Helper loaded: url_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: file_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: form_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: my_helper
INFO - 2024-10-26 16:27:21 --> Database Driver Class Initialized
INFO - 2024-10-26 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 16:27:21 --> Controller Class Initialized
INFO - 2024-10-26 16:27:21 --> Helper loaded: cookie_helper
INFO - 2024-10-26 16:27:21 --> Config Class Initialized
INFO - 2024-10-26 16:27:21 --> Hooks Class Initialized
DEBUG - 2024-10-26 16:27:21 --> UTF-8 Support Enabled
INFO - 2024-10-26 16:27:21 --> Utf8 Class Initialized
INFO - 2024-10-26 16:27:21 --> URI Class Initialized
INFO - 2024-10-26 16:27:21 --> Router Class Initialized
INFO - 2024-10-26 16:27:21 --> Output Class Initialized
INFO - 2024-10-26 16:27:21 --> Security Class Initialized
DEBUG - 2024-10-26 16:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 16:27:21 --> Input Class Initialized
INFO - 2024-10-26 16:27:21 --> Language Class Initialized
INFO - 2024-10-26 16:27:21 --> Language Class Initialized
INFO - 2024-10-26 16:27:21 --> Config Class Initialized
INFO - 2024-10-26 16:27:21 --> Loader Class Initialized
INFO - 2024-10-26 16:27:21 --> Helper loaded: url_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: file_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: form_helper
INFO - 2024-10-26 16:27:21 --> Helper loaded: my_helper
INFO - 2024-10-26 16:27:21 --> Database Driver Class Initialized
INFO - 2024-10-26 16:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 16:27:21 --> Controller Class Initialized
DEBUG - 2024-10-26 16:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-26 16:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-26 16:27:21 --> Final output sent to browser
DEBUG - 2024-10-26 16:27:21 --> Total execution time: 0.0458
INFO - 2024-10-26 16:27:24 --> Config Class Initialized
INFO - 2024-10-26 16:27:24 --> Hooks Class Initialized
DEBUG - 2024-10-26 16:27:24 --> UTF-8 Support Enabled
INFO - 2024-10-26 16:27:24 --> Utf8 Class Initialized
INFO - 2024-10-26 16:27:24 --> URI Class Initialized
INFO - 2024-10-26 16:27:24 --> Router Class Initialized
INFO - 2024-10-26 16:27:24 --> Output Class Initialized
INFO - 2024-10-26 16:27:24 --> Security Class Initialized
DEBUG - 2024-10-26 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 16:27:24 --> Input Class Initialized
INFO - 2024-10-26 16:27:24 --> Language Class Initialized
INFO - 2024-10-26 16:27:24 --> Language Class Initialized
INFO - 2024-10-26 16:27:24 --> Config Class Initialized
INFO - 2024-10-26 16:27:24 --> Loader Class Initialized
INFO - 2024-10-26 16:27:24 --> Helper loaded: url_helper
INFO - 2024-10-26 16:27:24 --> Helper loaded: file_helper
INFO - 2024-10-26 16:27:24 --> Helper loaded: form_helper
INFO - 2024-10-26 16:27:24 --> Helper loaded: my_helper
INFO - 2024-10-26 16:27:24 --> Database Driver Class Initialized
INFO - 2024-10-26 16:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 16:27:24 --> Controller Class Initialized
DEBUG - 2024-10-26 16:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-26 16:27:27 --> Final output sent to browser
DEBUG - 2024-10-26 16:27:27 --> Total execution time: 2.9093
