<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-02 08:45:05 --> Config Class Initialized
INFO - 2024-07-02 08:45:05 --> Hooks Class Initialized
DEBUG - 2024-07-02 08:45:05 --> UTF-8 Support Enabled
INFO - 2024-07-02 08:45:05 --> Utf8 Class Initialized
INFO - 2024-07-02 08:45:05 --> URI Class Initialized
DEBUG - 2024-07-02 08:45:05 --> No URI present. Default controller set.
INFO - 2024-07-02 08:45:05 --> Router Class Initialized
INFO - 2024-07-02 08:45:05 --> Output Class Initialized
INFO - 2024-07-02 08:45:05 --> Security Class Initialized
DEBUG - 2024-07-02 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 08:45:05 --> Input Class Initialized
INFO - 2024-07-02 08:45:05 --> Language Class Initialized
INFO - 2024-07-02 08:45:05 --> Language Class Initialized
INFO - 2024-07-02 08:45:05 --> Config Class Initialized
INFO - 2024-07-02 08:45:05 --> Loader Class Initialized
INFO - 2024-07-02 08:45:05 --> Helper loaded: url_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: file_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: form_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: my_helper
INFO - 2024-07-02 08:45:05 --> Database Driver Class Initialized
INFO - 2024-07-02 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 08:45:05 --> Controller Class Initialized
INFO - 2024-07-02 08:45:05 --> Config Class Initialized
INFO - 2024-07-02 08:45:05 --> Hooks Class Initialized
DEBUG - 2024-07-02 08:45:05 --> UTF-8 Support Enabled
INFO - 2024-07-02 08:45:05 --> Utf8 Class Initialized
INFO - 2024-07-02 08:45:05 --> URI Class Initialized
INFO - 2024-07-02 08:45:05 --> Router Class Initialized
INFO - 2024-07-02 08:45:05 --> Output Class Initialized
INFO - 2024-07-02 08:45:05 --> Security Class Initialized
DEBUG - 2024-07-02 08:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 08:45:05 --> Input Class Initialized
INFO - 2024-07-02 08:45:05 --> Language Class Initialized
INFO - 2024-07-02 08:45:05 --> Language Class Initialized
INFO - 2024-07-02 08:45:05 --> Config Class Initialized
INFO - 2024-07-02 08:45:05 --> Loader Class Initialized
INFO - 2024-07-02 08:45:05 --> Helper loaded: url_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: file_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: form_helper
INFO - 2024-07-02 08:45:05 --> Helper loaded: my_helper
INFO - 2024-07-02 08:45:05 --> Database Driver Class Initialized
INFO - 2024-07-02 08:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 08:45:05 --> Controller Class Initialized
DEBUG - 2024-07-02 08:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-02 08:45:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-02 08:45:05 --> Final output sent to browser
DEBUG - 2024-07-02 08:45:05 --> Total execution time: 0.0335
INFO - 2024-07-02 08:45:12 --> Config Class Initialized
INFO - 2024-07-02 08:45:12 --> Hooks Class Initialized
DEBUG - 2024-07-02 08:45:12 --> UTF-8 Support Enabled
INFO - 2024-07-02 08:45:12 --> Utf8 Class Initialized
INFO - 2024-07-02 08:45:12 --> URI Class Initialized
INFO - 2024-07-02 08:45:12 --> Router Class Initialized
INFO - 2024-07-02 08:45:12 --> Output Class Initialized
INFO - 2024-07-02 08:45:12 --> Security Class Initialized
DEBUG - 2024-07-02 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 08:45:12 --> Input Class Initialized
INFO - 2024-07-02 08:45:12 --> Language Class Initialized
INFO - 2024-07-02 08:45:12 --> Language Class Initialized
INFO - 2024-07-02 08:45:12 --> Config Class Initialized
INFO - 2024-07-02 08:45:12 --> Loader Class Initialized
INFO - 2024-07-02 08:45:12 --> Helper loaded: url_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: file_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: form_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: my_helper
INFO - 2024-07-02 08:45:12 --> Database Driver Class Initialized
INFO - 2024-07-02 08:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 08:45:12 --> Controller Class Initialized
INFO - 2024-07-02 08:45:12 --> Helper loaded: cookie_helper
INFO - 2024-07-02 08:45:12 --> Final output sent to browser
DEBUG - 2024-07-02 08:45:12 --> Total execution time: 0.0318
INFO - 2024-07-02 08:45:12 --> Config Class Initialized
INFO - 2024-07-02 08:45:12 --> Hooks Class Initialized
DEBUG - 2024-07-02 08:45:12 --> UTF-8 Support Enabled
INFO - 2024-07-02 08:45:12 --> Utf8 Class Initialized
INFO - 2024-07-02 08:45:12 --> URI Class Initialized
INFO - 2024-07-02 08:45:12 --> Router Class Initialized
INFO - 2024-07-02 08:45:12 --> Output Class Initialized
INFO - 2024-07-02 08:45:12 --> Security Class Initialized
DEBUG - 2024-07-02 08:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 08:45:12 --> Input Class Initialized
INFO - 2024-07-02 08:45:12 --> Language Class Initialized
INFO - 2024-07-02 08:45:12 --> Language Class Initialized
INFO - 2024-07-02 08:45:12 --> Config Class Initialized
INFO - 2024-07-02 08:45:12 --> Loader Class Initialized
INFO - 2024-07-02 08:45:12 --> Helper loaded: url_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: file_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: form_helper
INFO - 2024-07-02 08:45:12 --> Helper loaded: my_helper
INFO - 2024-07-02 08:45:12 --> Database Driver Class Initialized
INFO - 2024-07-02 08:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 08:45:12 --> Controller Class Initialized
DEBUG - 2024-07-02 08:45:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-02 08:45:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-02 08:45:12 --> Final output sent to browser
DEBUG - 2024-07-02 08:45:12 --> Total execution time: 0.0394
INFO - 2024-07-02 08:45:21 --> Config Class Initialized
INFO - 2024-07-02 08:45:21 --> Hooks Class Initialized
DEBUG - 2024-07-02 08:45:21 --> UTF-8 Support Enabled
INFO - 2024-07-02 08:45:21 --> Utf8 Class Initialized
INFO - 2024-07-02 08:45:21 --> URI Class Initialized
INFO - 2024-07-02 08:45:21 --> Router Class Initialized
INFO - 2024-07-02 08:45:21 --> Output Class Initialized
INFO - 2024-07-02 08:45:21 --> Security Class Initialized
DEBUG - 2024-07-02 08:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-02 08:45:21 --> Input Class Initialized
INFO - 2024-07-02 08:45:21 --> Language Class Initialized
INFO - 2024-07-02 08:45:21 --> Language Class Initialized
INFO - 2024-07-02 08:45:21 --> Config Class Initialized
INFO - 2024-07-02 08:45:21 --> Loader Class Initialized
INFO - 2024-07-02 08:45:21 --> Helper loaded: url_helper
INFO - 2024-07-02 08:45:21 --> Helper loaded: file_helper
INFO - 2024-07-02 08:45:21 --> Helper loaded: form_helper
INFO - 2024-07-02 08:45:21 --> Helper loaded: my_helper
INFO - 2024-07-02 08:45:21 --> Database Driver Class Initialized
INFO - 2024-07-02 08:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-02 08:45:21 --> Controller Class Initialized
DEBUG - 2024-07-02 08:45:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-02 08:45:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-02 08:45:21 --> Final output sent to browser
DEBUG - 2024-07-02 08:45:21 --> Total execution time: 0.0280
