<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-30 09:16:41 --> Config Class Initialized
INFO - 2023-10-30 09:16:41 --> Hooks Class Initialized
DEBUG - 2023-10-30 09:16:41 --> UTF-8 Support Enabled
INFO - 2023-10-30 09:16:41 --> Utf8 Class Initialized
INFO - 2023-10-30 09:16:41 --> URI Class Initialized
INFO - 2023-10-30 09:16:41 --> Router Class Initialized
INFO - 2023-10-30 09:16:41 --> Output Class Initialized
INFO - 2023-10-30 09:16:41 --> Security Class Initialized
DEBUG - 2023-10-30 09:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 09:16:41 --> Input Class Initialized
INFO - 2023-10-30 09:16:41 --> Language Class Initialized
INFO - 2023-10-30 09:16:41 --> Language Class Initialized
INFO - 2023-10-30 09:16:41 --> Config Class Initialized
INFO - 2023-10-30 09:16:41 --> Loader Class Initialized
INFO - 2023-10-30 09:16:41 --> Helper loaded: url_helper
INFO - 2023-10-30 09:16:41 --> Helper loaded: file_helper
INFO - 2023-10-30 09:16:41 --> Helper loaded: form_helper
INFO - 2023-10-30 09:16:41 --> Helper loaded: my_helper
INFO - 2023-10-30 09:16:41 --> Database Driver Class Initialized
INFO - 2023-10-30 09:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 09:16:41 --> Controller Class Initialized
DEBUG - 2023-10-30 09:16:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-30 09:16:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 09:16:41 --> Final output sent to browser
DEBUG - 2023-10-30 09:16:41 --> Total execution time: 0.1646
INFO - 2023-10-30 15:52:17 --> Config Class Initialized
INFO - 2023-10-30 15:52:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:52:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:52:17 --> Utf8 Class Initialized
INFO - 2023-10-30 15:52:17 --> URI Class Initialized
INFO - 2023-10-30 15:52:17 --> Router Class Initialized
INFO - 2023-10-30 15:52:17 --> Output Class Initialized
INFO - 2023-10-30 15:52:17 --> Security Class Initialized
DEBUG - 2023-10-30 15:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:52:17 --> Input Class Initialized
INFO - 2023-10-30 15:52:17 --> Language Class Initialized
INFO - 2023-10-30 15:52:17 --> Language Class Initialized
INFO - 2023-10-30 15:52:17 --> Config Class Initialized
INFO - 2023-10-30 15:52:17 --> Loader Class Initialized
INFO - 2023-10-30 15:52:17 --> Helper loaded: url_helper
INFO - 2023-10-30 15:52:17 --> Helper loaded: file_helper
INFO - 2023-10-30 15:52:17 --> Helper loaded: form_helper
INFO - 2023-10-30 15:52:17 --> Helper loaded: my_helper
INFO - 2023-10-30 15:52:17 --> Database Driver Class Initialized
INFO - 2023-10-30 15:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:52:18 --> Controller Class Initialized
DEBUG - 2023-10-30 15:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-30 15:52:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:52:18 --> Final output sent to browser
DEBUG - 2023-10-30 15:52:18 --> Total execution time: 1.0937
INFO - 2023-10-30 15:52:22 --> Config Class Initialized
INFO - 2023-10-30 15:52:22 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:52:22 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:52:22 --> Utf8 Class Initialized
INFO - 2023-10-30 15:52:22 --> URI Class Initialized
INFO - 2023-10-30 15:52:23 --> Router Class Initialized
INFO - 2023-10-30 15:52:23 --> Output Class Initialized
INFO - 2023-10-30 15:52:23 --> Security Class Initialized
DEBUG - 2023-10-30 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:52:23 --> Input Class Initialized
INFO - 2023-10-30 15:52:23 --> Language Class Initialized
INFO - 2023-10-30 15:52:23 --> Language Class Initialized
INFO - 2023-10-30 15:52:23 --> Config Class Initialized
INFO - 2023-10-30 15:52:23 --> Loader Class Initialized
INFO - 2023-10-30 15:52:23 --> Helper loaded: url_helper
INFO - 2023-10-30 15:52:23 --> Helper loaded: file_helper
INFO - 2023-10-30 15:52:23 --> Helper loaded: form_helper
INFO - 2023-10-30 15:52:23 --> Helper loaded: my_helper
INFO - 2023-10-30 15:52:23 --> Database Driver Class Initialized
INFO - 2023-10-30 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:52:23 --> Controller Class Initialized
INFO - 2023-10-30 15:52:23 --> Helper loaded: cookie_helper
INFO - 2023-10-30 15:52:23 --> Final output sent to browser
DEBUG - 2023-10-30 15:52:23 --> Total execution time: 1.2889
INFO - 2023-10-30 15:52:27 --> Config Class Initialized
INFO - 2023-10-30 15:52:27 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:52:28 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:52:28 --> Utf8 Class Initialized
INFO - 2023-10-30 15:52:28 --> URI Class Initialized
INFO - 2023-10-30 15:52:28 --> Router Class Initialized
INFO - 2023-10-30 15:52:28 --> Output Class Initialized
INFO - 2023-10-30 15:52:28 --> Security Class Initialized
DEBUG - 2023-10-30 15:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:52:28 --> Input Class Initialized
INFO - 2023-10-30 15:52:28 --> Language Class Initialized
INFO - 2023-10-30 15:52:28 --> Language Class Initialized
INFO - 2023-10-30 15:52:28 --> Config Class Initialized
INFO - 2023-10-30 15:52:28 --> Loader Class Initialized
INFO - 2023-10-30 15:52:28 --> Helper loaded: url_helper
INFO - 2023-10-30 15:52:28 --> Helper loaded: file_helper
INFO - 2023-10-30 15:52:28 --> Helper loaded: form_helper
INFO - 2023-10-30 15:52:28 --> Helper loaded: my_helper
INFO - 2023-10-30 15:52:28 --> Database Driver Class Initialized
INFO - 2023-10-30 15:52:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:52:28 --> Controller Class Initialized
DEBUG - 2023-10-30 15:52:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-30 15:52:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:52:29 --> Final output sent to browser
DEBUG - 2023-10-30 15:52:29 --> Total execution time: 1.1791
INFO - 2023-10-30 15:56:44 --> Config Class Initialized
INFO - 2023-10-30 15:56:44 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:56:44 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:56:44 --> Utf8 Class Initialized
INFO - 2023-10-30 15:56:44 --> URI Class Initialized
INFO - 2023-10-30 15:56:44 --> Router Class Initialized
INFO - 2023-10-30 15:56:44 --> Output Class Initialized
INFO - 2023-10-30 15:56:44 --> Security Class Initialized
DEBUG - 2023-10-30 15:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:56:44 --> Input Class Initialized
INFO - 2023-10-30 15:56:44 --> Language Class Initialized
INFO - 2023-10-30 15:56:44 --> Language Class Initialized
INFO - 2023-10-30 15:56:44 --> Config Class Initialized
INFO - 2023-10-30 15:56:44 --> Loader Class Initialized
INFO - 2023-10-30 15:56:44 --> Helper loaded: url_helper
INFO - 2023-10-30 15:56:44 --> Helper loaded: file_helper
INFO - 2023-10-30 15:56:44 --> Helper loaded: form_helper
INFO - 2023-10-30 15:56:44 --> Helper loaded: my_helper
INFO - 2023-10-30 15:56:44 --> Database Driver Class Initialized
INFO - 2023-10-30 15:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:56:44 --> Controller Class Initialized
DEBUG - 2023-10-30 15:56:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-30 15:56:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:56:44 --> Final output sent to browser
DEBUG - 2023-10-30 15:56:44 --> Total execution time: 0.1806
INFO - 2023-10-30 15:56:46 --> Config Class Initialized
INFO - 2023-10-30 15:56:46 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:56:46 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:56:46 --> Utf8 Class Initialized
INFO - 2023-10-30 15:56:46 --> URI Class Initialized
INFO - 2023-10-30 15:56:46 --> Router Class Initialized
INFO - 2023-10-30 15:56:46 --> Output Class Initialized
INFO - 2023-10-30 15:56:46 --> Security Class Initialized
DEBUG - 2023-10-30 15:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:56:46 --> Input Class Initialized
INFO - 2023-10-30 15:56:46 --> Language Class Initialized
INFO - 2023-10-30 15:56:46 --> Language Class Initialized
INFO - 2023-10-30 15:56:46 --> Config Class Initialized
INFO - 2023-10-30 15:56:46 --> Loader Class Initialized
INFO - 2023-10-30 15:56:46 --> Helper loaded: url_helper
INFO - 2023-10-30 15:56:46 --> Helper loaded: file_helper
INFO - 2023-10-30 15:56:46 --> Helper loaded: form_helper
INFO - 2023-10-30 15:56:46 --> Helper loaded: my_helper
INFO - 2023-10-30 15:56:46 --> Database Driver Class Initialized
INFO - 2023-10-30 15:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:56:47 --> Controller Class Initialized
DEBUG - 2023-10-30 15:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-30 15:57:02 --> Final output sent to browser
DEBUG - 2023-10-30 15:57:02 --> Total execution time: 15.8818
INFO - 2023-10-30 15:59:26 --> Config Class Initialized
INFO - 2023-10-30 15:59:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:26 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:26 --> URI Class Initialized
INFO - 2023-10-30 15:59:26 --> Router Class Initialized
INFO - 2023-10-30 15:59:26 --> Output Class Initialized
INFO - 2023-10-30 15:59:26 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:26 --> Input Class Initialized
INFO - 2023-10-30 15:59:26 --> Language Class Initialized
INFO - 2023-10-30 15:59:26 --> Language Class Initialized
INFO - 2023-10-30 15:59:26 --> Config Class Initialized
INFO - 2023-10-30 15:59:26 --> Loader Class Initialized
INFO - 2023-10-30 15:59:26 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:26 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:26 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:26 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:26 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:26 --> Controller Class Initialized
INFO - 2023-10-30 15:59:26 --> Helper loaded: cookie_helper
INFO - 2023-10-30 15:59:26 --> Config Class Initialized
INFO - 2023-10-30 15:59:26 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:26 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:26 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:27 --> URI Class Initialized
INFO - 2023-10-30 15:59:27 --> Router Class Initialized
INFO - 2023-10-30 15:59:27 --> Output Class Initialized
INFO - 2023-10-30 15:59:27 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:27 --> Input Class Initialized
INFO - 2023-10-30 15:59:27 --> Language Class Initialized
INFO - 2023-10-30 15:59:27 --> Language Class Initialized
INFO - 2023-10-30 15:59:27 --> Config Class Initialized
INFO - 2023-10-30 15:59:27 --> Loader Class Initialized
INFO - 2023-10-30 15:59:27 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:27 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:27 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:27 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:27 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:27 --> Controller Class Initialized
INFO - 2023-10-30 15:59:27 --> Config Class Initialized
INFO - 2023-10-30 15:59:27 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:27 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:27 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:27 --> URI Class Initialized
INFO - 2023-10-30 15:59:27 --> Router Class Initialized
INFO - 2023-10-30 15:59:27 --> Output Class Initialized
INFO - 2023-10-30 15:59:27 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:27 --> Input Class Initialized
INFO - 2023-10-30 15:59:27 --> Language Class Initialized
INFO - 2023-10-30 15:59:27 --> Language Class Initialized
INFO - 2023-10-30 15:59:27 --> Config Class Initialized
INFO - 2023-10-30 15:59:27 --> Loader Class Initialized
INFO - 2023-10-30 15:59:28 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:28 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:28 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:28 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:28 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:28 --> Controller Class Initialized
DEBUG - 2023-10-30 15:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-30 15:59:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:59:28 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:28 --> Total execution time: 0.5774
INFO - 2023-10-30 15:59:32 --> Config Class Initialized
INFO - 2023-10-30 15:59:32 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:32 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:32 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:32 --> URI Class Initialized
INFO - 2023-10-30 15:59:32 --> Router Class Initialized
INFO - 2023-10-30 15:59:32 --> Output Class Initialized
INFO - 2023-10-30 15:59:32 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:32 --> Input Class Initialized
INFO - 2023-10-30 15:59:32 --> Language Class Initialized
INFO - 2023-10-30 15:59:32 --> Language Class Initialized
INFO - 2023-10-30 15:59:32 --> Config Class Initialized
INFO - 2023-10-30 15:59:32 --> Loader Class Initialized
INFO - 2023-10-30 15:59:32 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:32 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:32 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:32 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:32 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:33 --> Controller Class Initialized
INFO - 2023-10-30 15:59:33 --> Helper loaded: cookie_helper
INFO - 2023-10-30 15:59:33 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:33 --> Total execution time: 0.7444
INFO - 2023-10-30 15:59:33 --> Config Class Initialized
INFO - 2023-10-30 15:59:33 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:33 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:33 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:33 --> URI Class Initialized
INFO - 2023-10-30 15:59:33 --> Router Class Initialized
INFO - 2023-10-30 15:59:33 --> Output Class Initialized
INFO - 2023-10-30 15:59:33 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:33 --> Input Class Initialized
INFO - 2023-10-30 15:59:33 --> Language Class Initialized
INFO - 2023-10-30 15:59:33 --> Language Class Initialized
INFO - 2023-10-30 15:59:33 --> Config Class Initialized
INFO - 2023-10-30 15:59:33 --> Loader Class Initialized
INFO - 2023-10-30 15:59:33 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:33 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:33 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:33 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:33 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:33 --> Controller Class Initialized
DEBUG - 2023-10-30 15:59:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-10-30 15:59:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:59:33 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:33 --> Total execution time: 0.7368
INFO - 2023-10-30 15:59:36 --> Config Class Initialized
INFO - 2023-10-30 15:59:36 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:36 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:36 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:36 --> URI Class Initialized
INFO - 2023-10-30 15:59:36 --> Router Class Initialized
INFO - 2023-10-30 15:59:36 --> Output Class Initialized
INFO - 2023-10-30 15:59:36 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:36 --> Input Class Initialized
INFO - 2023-10-30 15:59:36 --> Language Class Initialized
INFO - 2023-10-30 15:59:36 --> Language Class Initialized
INFO - 2023-10-30 15:59:36 --> Config Class Initialized
INFO - 2023-10-30 15:59:36 --> Loader Class Initialized
INFO - 2023-10-30 15:59:36 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:36 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:36 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:36 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:36 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:37 --> Controller Class Initialized
DEBUG - 2023-10-30 15:59:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-10-30 15:59:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 15:59:37 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:37 --> Total execution time: 0.6137
INFO - 2023-10-30 15:59:37 --> Config Class Initialized
INFO - 2023-10-30 15:59:37 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:38 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:38 --> URI Class Initialized
INFO - 2023-10-30 15:59:38 --> Router Class Initialized
INFO - 2023-10-30 15:59:38 --> Output Class Initialized
INFO - 2023-10-30 15:59:38 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:38 --> Input Class Initialized
INFO - 2023-10-30 15:59:38 --> Language Class Initialized
ERROR - 2023-10-30 15:59:38 --> 404 Page Not Found: /index
INFO - 2023-10-30 15:59:38 --> Config Class Initialized
INFO - 2023-10-30 15:59:38 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:38 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:38 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:38 --> URI Class Initialized
INFO - 2023-10-30 15:59:38 --> Router Class Initialized
INFO - 2023-10-30 15:59:38 --> Output Class Initialized
INFO - 2023-10-30 15:59:38 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:38 --> Input Class Initialized
INFO - 2023-10-30 15:59:38 --> Language Class Initialized
INFO - 2023-10-30 15:59:38 --> Language Class Initialized
INFO - 2023-10-30 15:59:38 --> Config Class Initialized
INFO - 2023-10-30 15:59:38 --> Loader Class Initialized
INFO - 2023-10-30 15:59:38 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:38 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:39 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:39 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:39 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:39 --> Controller Class Initialized
INFO - 2023-10-30 15:59:51 --> Config Class Initialized
INFO - 2023-10-30 15:59:51 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:51 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:51 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:51 --> URI Class Initialized
INFO - 2023-10-30 15:59:51 --> Router Class Initialized
INFO - 2023-10-30 15:59:51 --> Output Class Initialized
INFO - 2023-10-30 15:59:51 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:51 --> Input Class Initialized
INFO - 2023-10-30 15:59:51 --> Language Class Initialized
INFO - 2023-10-30 15:59:51 --> Language Class Initialized
INFO - 2023-10-30 15:59:51 --> Config Class Initialized
INFO - 2023-10-30 15:59:51 --> Loader Class Initialized
INFO - 2023-10-30 15:59:51 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:51 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:51 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:51 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:51 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:51 --> Controller Class Initialized
INFO - 2023-10-30 15:59:51 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:51 --> Total execution time: 0.3008
INFO - 2023-10-30 15:59:57 --> Config Class Initialized
INFO - 2023-10-30 15:59:57 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:57 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:57 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:57 --> URI Class Initialized
INFO - 2023-10-30 15:59:57 --> Router Class Initialized
INFO - 2023-10-30 15:59:57 --> Output Class Initialized
INFO - 2023-10-30 15:59:57 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:57 --> Input Class Initialized
INFO - 2023-10-30 15:59:57 --> Language Class Initialized
INFO - 2023-10-30 15:59:57 --> Language Class Initialized
INFO - 2023-10-30 15:59:57 --> Config Class Initialized
INFO - 2023-10-30 15:59:57 --> Loader Class Initialized
INFO - 2023-10-30 15:59:57 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:57 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:57 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:57 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:57 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:58 --> Controller Class Initialized
INFO - 2023-10-30 15:59:58 --> Final output sent to browser
DEBUG - 2023-10-30 15:59:58 --> Total execution time: 0.4827
INFO - 2023-10-30 15:59:58 --> Config Class Initialized
INFO - 2023-10-30 15:59:58 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:58 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:58 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:58 --> URI Class Initialized
INFO - 2023-10-30 15:59:58 --> Router Class Initialized
INFO - 2023-10-30 15:59:58 --> Output Class Initialized
INFO - 2023-10-30 15:59:58 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:58 --> Input Class Initialized
INFO - 2023-10-30 15:59:58 --> Language Class Initialized
ERROR - 2023-10-30 15:59:58 --> 404 Page Not Found: /index
INFO - 2023-10-30 15:59:58 --> Config Class Initialized
INFO - 2023-10-30 15:59:58 --> Hooks Class Initialized
DEBUG - 2023-10-30 15:59:58 --> UTF-8 Support Enabled
INFO - 2023-10-30 15:59:58 --> Utf8 Class Initialized
INFO - 2023-10-30 15:59:58 --> URI Class Initialized
INFO - 2023-10-30 15:59:58 --> Router Class Initialized
INFO - 2023-10-30 15:59:58 --> Output Class Initialized
INFO - 2023-10-30 15:59:58 --> Security Class Initialized
DEBUG - 2023-10-30 15:59:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 15:59:58 --> Input Class Initialized
INFO - 2023-10-30 15:59:58 --> Language Class Initialized
INFO - 2023-10-30 15:59:58 --> Language Class Initialized
INFO - 2023-10-30 15:59:58 --> Config Class Initialized
INFO - 2023-10-30 15:59:58 --> Loader Class Initialized
INFO - 2023-10-30 15:59:58 --> Helper loaded: url_helper
INFO - 2023-10-30 15:59:58 --> Helper loaded: file_helper
INFO - 2023-10-30 15:59:58 --> Helper loaded: form_helper
INFO - 2023-10-30 15:59:58 --> Helper loaded: my_helper
INFO - 2023-10-30 15:59:58 --> Database Driver Class Initialized
INFO - 2023-10-30 15:59:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 15:59:58 --> Controller Class Initialized
INFO - 2023-10-30 16:00:02 --> Config Class Initialized
INFO - 2023-10-30 16:00:02 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:02 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:02 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:02 --> URI Class Initialized
INFO - 2023-10-30 16:00:02 --> Router Class Initialized
INFO - 2023-10-30 16:00:02 --> Output Class Initialized
INFO - 2023-10-30 16:00:02 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:03 --> Input Class Initialized
INFO - 2023-10-30 16:00:03 --> Language Class Initialized
INFO - 2023-10-30 16:00:03 --> Language Class Initialized
INFO - 2023-10-30 16:00:03 --> Config Class Initialized
INFO - 2023-10-30 16:00:03 --> Loader Class Initialized
INFO - 2023-10-30 16:00:03 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:03 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:03 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:03 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-10-30 16:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:03 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:03 --> Total execution time: 0.7414
INFO - 2023-10-30 16:00:03 --> Config Class Initialized
INFO - 2023-10-30 16:00:03 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:03 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:03 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:03 --> URI Class Initialized
INFO - 2023-10-30 16:00:03 --> Router Class Initialized
INFO - 2023-10-30 16:00:03 --> Output Class Initialized
INFO - 2023-10-30 16:00:03 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:03 --> Input Class Initialized
INFO - 2023-10-30 16:00:03 --> Language Class Initialized
ERROR - 2023-10-30 16:00:03 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:04 --> Config Class Initialized
INFO - 2023-10-30 16:00:04 --> Hooks Class Initialized
INFO - 2023-10-30 16:00:04 --> Config Class Initialized
INFO - 2023-10-30 16:00:04 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:04 --> Utf8 Class Initialized
DEBUG - 2023-10-30 16:00:04 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:04 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:04 --> URI Class Initialized
INFO - 2023-10-30 16:00:04 --> URI Class Initialized
INFO - 2023-10-30 16:00:04 --> Router Class Initialized
INFO - 2023-10-30 16:00:04 --> Output Class Initialized
INFO - 2023-10-30 16:00:04 --> Router Class Initialized
INFO - 2023-10-30 16:00:04 --> Security Class Initialized
INFO - 2023-10-30 16:00:04 --> Output Class Initialized
DEBUG - 2023-10-30 16:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:04 --> Input Class Initialized
INFO - 2023-10-30 16:00:04 --> Language Class Initialized
INFO - 2023-10-30 16:00:04 --> Security Class Initialized
INFO - 2023-10-30 16:00:04 --> Language Class Initialized
INFO - 2023-10-30 16:00:04 --> Config Class Initialized
INFO - 2023-10-30 16:00:04 --> Loader Class Initialized
DEBUG - 2023-10-30 16:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:04 --> Input Class Initialized
INFO - 2023-10-30 16:00:04 --> Language Class Initialized
INFO - 2023-10-30 16:00:05 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:05 --> Language Class Initialized
INFO - 2023-10-30 16:00:05 --> Config Class Initialized
INFO - 2023-10-30 16:00:05 --> Loader Class Initialized
INFO - 2023-10-30 16:00:05 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:05 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:05 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:05 --> Controller Class Initialized
INFO - 2023-10-30 16:00:05 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:05 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-10-30 16:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:05 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:05 --> Total execution time: 1.1343
INFO - 2023-10-30 16:00:06 --> Config Class Initialized
INFO - 2023-10-30 16:00:06 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:06 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:06 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:06 --> URI Class Initialized
INFO - 2023-10-30 16:00:06 --> Router Class Initialized
INFO - 2023-10-30 16:00:06 --> Output Class Initialized
INFO - 2023-10-30 16:00:06 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:06 --> Input Class Initialized
INFO - 2023-10-30 16:00:06 --> Language Class Initialized
ERROR - 2023-10-30 16:00:06 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:06 --> Config Class Initialized
INFO - 2023-10-30 16:00:06 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:06 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:06 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:06 --> URI Class Initialized
INFO - 2023-10-30 16:00:06 --> Router Class Initialized
INFO - 2023-10-30 16:00:06 --> Output Class Initialized
INFO - 2023-10-30 16:00:06 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:06 --> Input Class Initialized
INFO - 2023-10-30 16:00:06 --> Language Class Initialized
INFO - 2023-10-30 16:00:07 --> Language Class Initialized
INFO - 2023-10-30 16:00:07 --> Config Class Initialized
INFO - 2023-10-30 16:00:07 --> Loader Class Initialized
INFO - 2023-10-30 16:00:07 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:07 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:07 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:07 --> Controller Class Initialized
INFO - 2023-10-30 16:00:08 --> Config Class Initialized
INFO - 2023-10-30 16:00:08 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:08 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:08 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:08 --> URI Class Initialized
INFO - 2023-10-30 16:00:08 --> Router Class Initialized
INFO - 2023-10-30 16:00:08 --> Output Class Initialized
INFO - 2023-10-30 16:00:08 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:08 --> Input Class Initialized
INFO - 2023-10-30 16:00:08 --> Language Class Initialized
INFO - 2023-10-30 16:00:08 --> Language Class Initialized
INFO - 2023-10-30 16:00:08 --> Config Class Initialized
INFO - 2023-10-30 16:00:08 --> Loader Class Initialized
INFO - 2023-10-30 16:00:08 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:08 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:08 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-10-30 16:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:08 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:08 --> Total execution time: 0.2280
INFO - 2023-10-30 16:00:08 --> Config Class Initialized
INFO - 2023-10-30 16:00:08 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:08 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:08 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:08 --> URI Class Initialized
INFO - 2023-10-30 16:00:08 --> Router Class Initialized
INFO - 2023-10-30 16:00:08 --> Output Class Initialized
INFO - 2023-10-30 16:00:08 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:08 --> Input Class Initialized
INFO - 2023-10-30 16:00:08 --> Language Class Initialized
ERROR - 2023-10-30 16:00:08 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:08 --> Config Class Initialized
INFO - 2023-10-30 16:00:08 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:08 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:08 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:08 --> URI Class Initialized
INFO - 2023-10-30 16:00:08 --> Router Class Initialized
INFO - 2023-10-30 16:00:08 --> Output Class Initialized
INFO - 2023-10-30 16:00:08 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:08 --> Input Class Initialized
INFO - 2023-10-30 16:00:08 --> Language Class Initialized
INFO - 2023-10-30 16:00:08 --> Language Class Initialized
INFO - 2023-10-30 16:00:08 --> Config Class Initialized
INFO - 2023-10-30 16:00:08 --> Loader Class Initialized
INFO - 2023-10-30 16:00:08 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:08 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:08 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:08 --> Controller Class Initialized
INFO - 2023-10-30 16:00:09 --> Config Class Initialized
INFO - 2023-10-30 16:00:09 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:09 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:09 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:09 --> URI Class Initialized
INFO - 2023-10-30 16:00:09 --> Router Class Initialized
INFO - 2023-10-30 16:00:09 --> Output Class Initialized
INFO - 2023-10-30 16:00:09 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:09 --> Input Class Initialized
INFO - 2023-10-30 16:00:09 --> Language Class Initialized
INFO - 2023-10-30 16:00:09 --> Language Class Initialized
INFO - 2023-10-30 16:00:09 --> Config Class Initialized
INFO - 2023-10-30 16:00:09 --> Loader Class Initialized
INFO - 2023-10-30 16:00:09 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:09 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:09 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:09 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:10 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:10 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-10-30 16:00:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:10 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:10 --> Total execution time: 0.3439
INFO - 2023-10-30 16:00:10 --> Config Class Initialized
INFO - 2023-10-30 16:00:10 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:10 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:10 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:10 --> URI Class Initialized
INFO - 2023-10-30 16:00:10 --> Router Class Initialized
INFO - 2023-10-30 16:00:10 --> Output Class Initialized
INFO - 2023-10-30 16:00:10 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:10 --> Input Class Initialized
INFO - 2023-10-30 16:00:10 --> Language Class Initialized
ERROR - 2023-10-30 16:00:10 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:11 --> Config Class Initialized
INFO - 2023-10-30 16:00:11 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:11 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:11 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:11 --> URI Class Initialized
INFO - 2023-10-30 16:00:11 --> Router Class Initialized
INFO - 2023-10-30 16:00:11 --> Output Class Initialized
INFO - 2023-10-30 16:00:11 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:11 --> Input Class Initialized
INFO - 2023-10-30 16:00:11 --> Language Class Initialized
INFO - 2023-10-30 16:00:11 --> Language Class Initialized
INFO - 2023-10-30 16:00:11 --> Config Class Initialized
INFO - 2023-10-30 16:00:11 --> Loader Class Initialized
INFO - 2023-10-30 16:00:11 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:11 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:11 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:11 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:11 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:11 --> Controller Class Initialized
INFO - 2023-10-30 16:00:13 --> Config Class Initialized
INFO - 2023-10-30 16:00:13 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:13 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:13 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:13 --> URI Class Initialized
INFO - 2023-10-30 16:00:13 --> Router Class Initialized
INFO - 2023-10-30 16:00:13 --> Output Class Initialized
INFO - 2023-10-30 16:00:13 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:13 --> Input Class Initialized
INFO - 2023-10-30 16:00:13 --> Language Class Initialized
INFO - 2023-10-30 16:00:13 --> Language Class Initialized
INFO - 2023-10-30 16:00:13 --> Config Class Initialized
INFO - 2023-10-30 16:00:13 --> Loader Class Initialized
INFO - 2023-10-30 16:00:13 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:13 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:13 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:13 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:14 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:14 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-10-30 16:00:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:14 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:14 --> Total execution time: 1.0913
INFO - 2023-10-30 16:00:14 --> Config Class Initialized
INFO - 2023-10-30 16:00:14 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:14 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:14 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:14 --> URI Class Initialized
INFO - 2023-10-30 16:00:14 --> Router Class Initialized
INFO - 2023-10-30 16:00:15 --> Output Class Initialized
INFO - 2023-10-30 16:00:15 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:15 --> Input Class Initialized
INFO - 2023-10-30 16:00:15 --> Language Class Initialized
ERROR - 2023-10-30 16:00:15 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:15 --> Config Class Initialized
INFO - 2023-10-30 16:00:15 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:15 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:15 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:15 --> URI Class Initialized
INFO - 2023-10-30 16:00:15 --> Router Class Initialized
INFO - 2023-10-30 16:00:15 --> Output Class Initialized
INFO - 2023-10-30 16:00:15 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:15 --> Input Class Initialized
INFO - 2023-10-30 16:00:15 --> Language Class Initialized
INFO - 2023-10-30 16:00:15 --> Language Class Initialized
INFO - 2023-10-30 16:00:15 --> Config Class Initialized
INFO - 2023-10-30 16:00:15 --> Loader Class Initialized
INFO - 2023-10-30 16:00:15 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:15 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:15 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:15 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:15 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:15 --> Controller Class Initialized
INFO - 2023-10-30 16:00:17 --> Config Class Initialized
INFO - 2023-10-30 16:00:17 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:17 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:17 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:17 --> URI Class Initialized
INFO - 2023-10-30 16:00:17 --> Router Class Initialized
INFO - 2023-10-30 16:00:17 --> Output Class Initialized
INFO - 2023-10-30 16:00:17 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:17 --> Input Class Initialized
INFO - 2023-10-30 16:00:17 --> Language Class Initialized
INFO - 2023-10-30 16:00:18 --> Language Class Initialized
INFO - 2023-10-30 16:00:18 --> Config Class Initialized
INFO - 2023-10-30 16:00:18 --> Loader Class Initialized
INFO - 2023-10-30 16:00:18 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:18 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:18 --> Controller Class Initialized
DEBUG - 2023-10-30 16:00:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-10-30 16:00:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-30 16:00:18 --> Final output sent to browser
DEBUG - 2023-10-30 16:00:18 --> Total execution time: 0.3329
INFO - 2023-10-30 16:00:18 --> Config Class Initialized
INFO - 2023-10-30 16:00:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:18 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:18 --> URI Class Initialized
INFO - 2023-10-30 16:00:18 --> Router Class Initialized
INFO - 2023-10-30 16:00:18 --> Output Class Initialized
INFO - 2023-10-30 16:00:18 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:18 --> Input Class Initialized
INFO - 2023-10-30 16:00:18 --> Language Class Initialized
ERROR - 2023-10-30 16:00:18 --> 404 Page Not Found: /index
INFO - 2023-10-30 16:00:18 --> Config Class Initialized
INFO - 2023-10-30 16:00:18 --> Hooks Class Initialized
DEBUG - 2023-10-30 16:00:18 --> UTF-8 Support Enabled
INFO - 2023-10-30 16:00:18 --> Utf8 Class Initialized
INFO - 2023-10-30 16:00:18 --> URI Class Initialized
INFO - 2023-10-30 16:00:18 --> Router Class Initialized
INFO - 2023-10-30 16:00:18 --> Output Class Initialized
INFO - 2023-10-30 16:00:18 --> Security Class Initialized
DEBUG - 2023-10-30 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-30 16:00:18 --> Input Class Initialized
INFO - 2023-10-30 16:00:18 --> Language Class Initialized
INFO - 2023-10-30 16:00:18 --> Language Class Initialized
INFO - 2023-10-30 16:00:18 --> Config Class Initialized
INFO - 2023-10-30 16:00:18 --> Loader Class Initialized
INFO - 2023-10-30 16:00:18 --> Helper loaded: url_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: file_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: form_helper
INFO - 2023-10-30 16:00:18 --> Helper loaded: my_helper
INFO - 2023-10-30 16:00:18 --> Database Driver Class Initialized
INFO - 2023-10-30 16:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-30 16:00:18 --> Controller Class Initialized
