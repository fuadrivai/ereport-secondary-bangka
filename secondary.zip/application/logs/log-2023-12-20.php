<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-20 08:18:24 --> Config Class Initialized
INFO - 2023-12-20 08:18:24 --> Hooks Class Initialized
DEBUG - 2023-12-20 08:18:24 --> UTF-8 Support Enabled
INFO - 2023-12-20 08:18:24 --> Utf8 Class Initialized
INFO - 2023-12-20 08:18:24 --> URI Class Initialized
INFO - 2023-12-20 08:18:24 --> Router Class Initialized
INFO - 2023-12-20 08:18:24 --> Output Class Initialized
INFO - 2023-12-20 08:18:24 --> Security Class Initialized
DEBUG - 2023-12-20 08:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 08:18:24 --> Input Class Initialized
INFO - 2023-12-20 08:18:24 --> Language Class Initialized
INFO - 2023-12-20 08:18:24 --> Language Class Initialized
INFO - 2023-12-20 08:18:24 --> Config Class Initialized
INFO - 2023-12-20 08:18:24 --> Loader Class Initialized
INFO - 2023-12-20 08:18:24 --> Helper loaded: url_helper
INFO - 2023-12-20 08:18:24 --> Helper loaded: file_helper
INFO - 2023-12-20 08:18:24 --> Helper loaded: form_helper
INFO - 2023-12-20 08:18:24 --> Helper loaded: my_helper
INFO - 2023-12-20 08:18:24 --> Database Driver Class Initialized
INFO - 2023-12-20 08:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 08:18:24 --> Controller Class Initialized
DEBUG - 2023-12-20 08:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-20 08:18:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 08:18:24 --> Final output sent to browser
DEBUG - 2023-12-20 08:18:24 --> Total execution time: 0.0589
INFO - 2023-12-20 08:19:24 --> Config Class Initialized
INFO - 2023-12-20 08:19:24 --> Hooks Class Initialized
DEBUG - 2023-12-20 08:19:24 --> UTF-8 Support Enabled
INFO - 2023-12-20 08:19:24 --> Utf8 Class Initialized
INFO - 2023-12-20 08:19:24 --> URI Class Initialized
INFO - 2023-12-20 08:19:24 --> Router Class Initialized
INFO - 2023-12-20 08:19:24 --> Output Class Initialized
INFO - 2023-12-20 08:19:24 --> Security Class Initialized
DEBUG - 2023-12-20 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 08:19:24 --> Input Class Initialized
INFO - 2023-12-20 08:19:24 --> Language Class Initialized
INFO - 2023-12-20 08:19:24 --> Language Class Initialized
INFO - 2023-12-20 08:19:24 --> Config Class Initialized
INFO - 2023-12-20 08:19:24 --> Loader Class Initialized
INFO - 2023-12-20 08:19:24 --> Helper loaded: url_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: file_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: form_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: my_helper
INFO - 2023-12-20 08:19:24 --> Database Driver Class Initialized
INFO - 2023-12-20 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 08:19:24 --> Controller Class Initialized
INFO - 2023-12-20 08:19:24 --> Helper loaded: cookie_helper
INFO - 2023-12-20 08:19:24 --> Final output sent to browser
DEBUG - 2023-12-20 08:19:24 --> Total execution time: 0.5042
INFO - 2023-12-20 08:19:24 --> Config Class Initialized
INFO - 2023-12-20 08:19:24 --> Hooks Class Initialized
DEBUG - 2023-12-20 08:19:24 --> UTF-8 Support Enabled
INFO - 2023-12-20 08:19:24 --> Utf8 Class Initialized
INFO - 2023-12-20 08:19:24 --> URI Class Initialized
INFO - 2023-12-20 08:19:24 --> Router Class Initialized
INFO - 2023-12-20 08:19:24 --> Output Class Initialized
INFO - 2023-12-20 08:19:24 --> Security Class Initialized
DEBUG - 2023-12-20 08:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 08:19:24 --> Input Class Initialized
INFO - 2023-12-20 08:19:24 --> Language Class Initialized
INFO - 2023-12-20 08:19:24 --> Language Class Initialized
INFO - 2023-12-20 08:19:24 --> Config Class Initialized
INFO - 2023-12-20 08:19:24 --> Loader Class Initialized
INFO - 2023-12-20 08:19:24 --> Helper loaded: url_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: file_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: form_helper
INFO - 2023-12-20 08:19:24 --> Helper loaded: my_helper
INFO - 2023-12-20 08:19:24 --> Database Driver Class Initialized
INFO - 2023-12-20 08:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 08:19:24 --> Controller Class Initialized
DEBUG - 2023-12-20 08:19:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-20 08:19:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 08:19:24 --> Final output sent to browser
DEBUG - 2023-12-20 08:19:24 --> Total execution time: 0.0989
INFO - 2023-12-20 08:24:15 --> Config Class Initialized
INFO - 2023-12-20 08:24:15 --> Hooks Class Initialized
DEBUG - 2023-12-20 08:24:15 --> UTF-8 Support Enabled
INFO - 2023-12-20 08:24:15 --> Utf8 Class Initialized
INFO - 2023-12-20 08:24:15 --> URI Class Initialized
INFO - 2023-12-20 08:24:15 --> Router Class Initialized
INFO - 2023-12-20 08:24:15 --> Output Class Initialized
INFO - 2023-12-20 08:24:15 --> Security Class Initialized
DEBUG - 2023-12-20 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 08:24:15 --> Input Class Initialized
INFO - 2023-12-20 08:24:15 --> Language Class Initialized
INFO - 2023-12-20 08:24:15 --> Language Class Initialized
INFO - 2023-12-20 08:24:15 --> Config Class Initialized
INFO - 2023-12-20 08:24:15 --> Loader Class Initialized
INFO - 2023-12-20 08:24:15 --> Helper loaded: url_helper
INFO - 2023-12-20 08:24:15 --> Helper loaded: file_helper
INFO - 2023-12-20 08:24:15 --> Helper loaded: form_helper
INFO - 2023-12-20 08:24:15 --> Helper loaded: my_helper
INFO - 2023-12-20 08:24:15 --> Database Driver Class Initialized
INFO - 2023-12-20 08:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 08:24:15 --> Controller Class Initialized
DEBUG - 2023-12-20 08:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-20 08:24:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 08:24:15 --> Final output sent to browser
DEBUG - 2023-12-20 08:24:15 --> Total execution time: 0.1241
INFO - 2023-12-20 14:40:42 --> Config Class Initialized
INFO - 2023-12-20 14:40:42 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:42 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:42 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:42 --> URI Class Initialized
INFO - 2023-12-20 14:40:42 --> Router Class Initialized
INFO - 2023-12-20 14:40:42 --> Output Class Initialized
INFO - 2023-12-20 14:40:42 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:42 --> Input Class Initialized
INFO - 2023-12-20 14:40:42 --> Language Class Initialized
INFO - 2023-12-20 14:40:42 --> Language Class Initialized
INFO - 2023-12-20 14:40:42 --> Config Class Initialized
INFO - 2023-12-20 14:40:42 --> Loader Class Initialized
INFO - 2023-12-20 14:40:42 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:42 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:42 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:42 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:42 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:42 --> Controller Class Initialized
INFO - 2023-12-20 14:40:42 --> Helper loaded: cookie_helper
INFO - 2023-12-20 14:40:42 --> Final output sent to browser
DEBUG - 2023-12-20 14:40:42 --> Total execution time: 0.0640
INFO - 2023-12-20 14:40:43 --> Config Class Initialized
INFO - 2023-12-20 14:40:43 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:43 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:43 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:43 --> URI Class Initialized
INFO - 2023-12-20 14:40:43 --> Router Class Initialized
INFO - 2023-12-20 14:40:43 --> Output Class Initialized
INFO - 2023-12-20 14:40:43 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:43 --> Input Class Initialized
INFO - 2023-12-20 14:40:43 --> Language Class Initialized
INFO - 2023-12-20 14:40:43 --> Language Class Initialized
INFO - 2023-12-20 14:40:43 --> Config Class Initialized
INFO - 2023-12-20 14:40:43 --> Loader Class Initialized
INFO - 2023-12-20 14:40:43 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:43 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:43 --> Controller Class Initialized
INFO - 2023-12-20 14:40:43 --> Helper loaded: cookie_helper
INFO - 2023-12-20 14:40:43 --> Config Class Initialized
INFO - 2023-12-20 14:40:43 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:43 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:43 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:43 --> URI Class Initialized
INFO - 2023-12-20 14:40:43 --> Router Class Initialized
INFO - 2023-12-20 14:40:43 --> Output Class Initialized
INFO - 2023-12-20 14:40:43 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:43 --> Input Class Initialized
INFO - 2023-12-20 14:40:43 --> Language Class Initialized
INFO - 2023-12-20 14:40:43 --> Language Class Initialized
INFO - 2023-12-20 14:40:43 --> Config Class Initialized
INFO - 2023-12-20 14:40:43 --> Loader Class Initialized
INFO - 2023-12-20 14:40:43 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:43 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:43 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:43 --> Controller Class Initialized
DEBUG - 2023-12-20 14:40:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 14:40:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 14:40:43 --> Final output sent to browser
DEBUG - 2023-12-20 14:40:43 --> Total execution time: 0.0623
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:44 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:44 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:44 --> URI Class Initialized
INFO - 2023-12-20 14:40:44 --> Router Class Initialized
INFO - 2023-12-20 14:40:44 --> Output Class Initialized
INFO - 2023-12-20 14:40:44 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:44 --> Input Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Loader Class Initialized
INFO - 2023-12-20 14:40:44 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:44 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:44 --> Controller Class Initialized
INFO - 2023-12-20 14:40:44 --> Helper loaded: cookie_helper
INFO - 2023-12-20 14:40:44 --> Final output sent to browser
DEBUG - 2023-12-20 14:40:44 --> Total execution time: 0.0602
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:44 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:44 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:44 --> URI Class Initialized
INFO - 2023-12-20 14:40:44 --> Router Class Initialized
INFO - 2023-12-20 14:40:44 --> Output Class Initialized
INFO - 2023-12-20 14:40:44 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:44 --> Input Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Loader Class Initialized
INFO - 2023-12-20 14:40:44 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:44 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:44 --> Controller Class Initialized
INFO - 2023-12-20 14:40:44 --> Helper loaded: cookie_helper
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:40:44 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:40:44 --> Utf8 Class Initialized
INFO - 2023-12-20 14:40:44 --> URI Class Initialized
INFO - 2023-12-20 14:40:44 --> Router Class Initialized
INFO - 2023-12-20 14:40:44 --> Output Class Initialized
INFO - 2023-12-20 14:40:44 --> Security Class Initialized
DEBUG - 2023-12-20 14:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:40:44 --> Input Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Language Class Initialized
INFO - 2023-12-20 14:40:44 --> Config Class Initialized
INFO - 2023-12-20 14:40:44 --> Loader Class Initialized
INFO - 2023-12-20 14:40:44 --> Helper loaded: url_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: file_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: form_helper
INFO - 2023-12-20 14:40:44 --> Helper loaded: my_helper
INFO - 2023-12-20 14:40:44 --> Database Driver Class Initialized
INFO - 2023-12-20 14:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:40:44 --> Controller Class Initialized
DEBUG - 2023-12-20 14:40:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 14:40:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 14:40:44 --> Final output sent to browser
DEBUG - 2023-12-20 14:40:44 --> Total execution time: 0.0664
INFO - 2023-12-20 14:41:11 --> Config Class Initialized
INFO - 2023-12-20 14:41:11 --> Hooks Class Initialized
DEBUG - 2023-12-20 14:41:11 --> UTF-8 Support Enabled
INFO - 2023-12-20 14:41:11 --> Utf8 Class Initialized
INFO - 2023-12-20 14:41:11 --> URI Class Initialized
INFO - 2023-12-20 14:41:11 --> Router Class Initialized
INFO - 2023-12-20 14:41:11 --> Output Class Initialized
INFO - 2023-12-20 14:41:11 --> Security Class Initialized
DEBUG - 2023-12-20 14:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 14:41:11 --> Input Class Initialized
INFO - 2023-12-20 14:41:11 --> Language Class Initialized
INFO - 2023-12-20 14:41:11 --> Language Class Initialized
INFO - 2023-12-20 14:41:11 --> Config Class Initialized
INFO - 2023-12-20 14:41:11 --> Loader Class Initialized
INFO - 2023-12-20 14:41:11 --> Helper loaded: url_helper
INFO - 2023-12-20 14:41:11 --> Helper loaded: file_helper
INFO - 2023-12-20 14:41:11 --> Helper loaded: form_helper
INFO - 2023-12-20 14:41:11 --> Helper loaded: my_helper
INFO - 2023-12-20 14:41:11 --> Database Driver Class Initialized
INFO - 2023-12-20 14:41:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 14:41:11 --> Controller Class Initialized
DEBUG - 2023-12-20 14:41:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-20 14:41:18 --> Final output sent to browser
DEBUG - 2023-12-20 14:41:18 --> Total execution time: 6.5840
INFO - 2023-12-20 17:09:44 --> Config Class Initialized
INFO - 2023-12-20 17:09:44 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:09:44 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:09:44 --> Utf8 Class Initialized
INFO - 2023-12-20 17:09:44 --> URI Class Initialized
INFO - 2023-12-20 17:09:44 --> Router Class Initialized
INFO - 2023-12-20 17:09:44 --> Output Class Initialized
INFO - 2023-12-20 17:09:44 --> Security Class Initialized
DEBUG - 2023-12-20 17:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:09:44 --> Input Class Initialized
INFO - 2023-12-20 17:09:44 --> Language Class Initialized
INFO - 2023-12-20 17:09:44 --> Language Class Initialized
INFO - 2023-12-20 17:09:44 --> Config Class Initialized
INFO - 2023-12-20 17:09:44 --> Loader Class Initialized
INFO - 2023-12-20 17:09:44 --> Helper loaded: url_helper
INFO - 2023-12-20 17:09:44 --> Helper loaded: file_helper
INFO - 2023-12-20 17:09:44 --> Helper loaded: form_helper
INFO - 2023-12-20 17:09:44 --> Helper loaded: my_helper
INFO - 2023-12-20 17:09:44 --> Database Driver Class Initialized
INFO - 2023-12-20 17:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:09:44 --> Controller Class Initialized
INFO - 2023-12-20 17:09:44 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:09:44 --> Final output sent to browser
DEBUG - 2023-12-20 17:09:44 --> Total execution time: 0.1670
INFO - 2023-12-20 17:09:45 --> Config Class Initialized
INFO - 2023-12-20 17:09:45 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:09:45 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:09:45 --> Utf8 Class Initialized
INFO - 2023-12-20 17:09:45 --> URI Class Initialized
INFO - 2023-12-20 17:09:45 --> Router Class Initialized
INFO - 2023-12-20 17:09:45 --> Output Class Initialized
INFO - 2023-12-20 17:09:45 --> Security Class Initialized
DEBUG - 2023-12-20 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:09:45 --> Input Class Initialized
INFO - 2023-12-20 17:09:45 --> Language Class Initialized
INFO - 2023-12-20 17:09:45 --> Language Class Initialized
INFO - 2023-12-20 17:09:45 --> Config Class Initialized
INFO - 2023-12-20 17:09:45 --> Loader Class Initialized
INFO - 2023-12-20 17:09:45 --> Helper loaded: url_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: file_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: form_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: my_helper
INFO - 2023-12-20 17:09:45 --> Database Driver Class Initialized
INFO - 2023-12-20 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:09:45 --> Controller Class Initialized
INFO - 2023-12-20 17:09:45 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:09:45 --> Config Class Initialized
INFO - 2023-12-20 17:09:45 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:09:45 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:09:45 --> Utf8 Class Initialized
INFO - 2023-12-20 17:09:45 --> URI Class Initialized
INFO - 2023-12-20 17:09:45 --> Router Class Initialized
INFO - 2023-12-20 17:09:45 --> Output Class Initialized
INFO - 2023-12-20 17:09:45 --> Security Class Initialized
DEBUG - 2023-12-20 17:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:09:45 --> Input Class Initialized
INFO - 2023-12-20 17:09:45 --> Language Class Initialized
INFO - 2023-12-20 17:09:45 --> Language Class Initialized
INFO - 2023-12-20 17:09:45 --> Config Class Initialized
INFO - 2023-12-20 17:09:45 --> Loader Class Initialized
INFO - 2023-12-20 17:09:45 --> Helper loaded: url_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: file_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: form_helper
INFO - 2023-12-20 17:09:45 --> Helper loaded: my_helper
INFO - 2023-12-20 17:09:45 --> Database Driver Class Initialized
INFO - 2023-12-20 17:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:09:45 --> Controller Class Initialized
DEBUG - 2023-12-20 17:09:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 17:09:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 17:09:45 --> Final output sent to browser
DEBUG - 2023-12-20 17:09:45 --> Total execution time: 0.0663
INFO - 2023-12-20 17:10:03 --> Config Class Initialized
INFO - 2023-12-20 17:10:03 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:03 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:03 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:03 --> URI Class Initialized
INFO - 2023-12-20 17:10:03 --> Router Class Initialized
INFO - 2023-12-20 17:10:03 --> Output Class Initialized
INFO - 2023-12-20 17:10:03 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:03 --> Input Class Initialized
INFO - 2023-12-20 17:10:03 --> Language Class Initialized
INFO - 2023-12-20 17:10:03 --> Language Class Initialized
INFO - 2023-12-20 17:10:03 --> Config Class Initialized
INFO - 2023-12-20 17:10:03 --> Loader Class Initialized
INFO - 2023-12-20 17:10:03 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:03 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:03 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:03 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:03 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:03 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:10:10 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:10 --> Total execution time: 7.1466
INFO - 2023-12-20 17:10:12 --> Config Class Initialized
INFO - 2023-12-20 17:10:12 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:12 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:12 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:12 --> URI Class Initialized
INFO - 2023-12-20 17:10:12 --> Router Class Initialized
INFO - 2023-12-20 17:10:12 --> Output Class Initialized
INFO - 2023-12-20 17:10:12 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:12 --> Input Class Initialized
INFO - 2023-12-20 17:10:12 --> Language Class Initialized
INFO - 2023-12-20 17:10:13 --> Language Class Initialized
INFO - 2023-12-20 17:10:13 --> Config Class Initialized
INFO - 2023-12-20 17:10:13 --> Loader Class Initialized
INFO - 2023-12-20 17:10:13 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:13 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:13 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:13 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:13 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:13 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:10:19 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:19 --> Total execution time: 6.9353
INFO - 2023-12-20 17:10:45 --> Config Class Initialized
INFO - 2023-12-20 17:10:45 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:45 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:45 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:45 --> URI Class Initialized
INFO - 2023-12-20 17:10:45 --> Router Class Initialized
INFO - 2023-12-20 17:10:45 --> Output Class Initialized
INFO - 2023-12-20 17:10:45 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:45 --> Input Class Initialized
INFO - 2023-12-20 17:10:45 --> Language Class Initialized
INFO - 2023-12-20 17:10:45 --> Language Class Initialized
INFO - 2023-12-20 17:10:45 --> Config Class Initialized
INFO - 2023-12-20 17:10:45 --> Loader Class Initialized
INFO - 2023-12-20 17:10:45 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:45 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:45 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:45 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:45 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:45 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 17:10:48 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:48 --> Total execution time: 3.0113
INFO - 2023-12-20 17:10:48 --> Config Class Initialized
INFO - 2023-12-20 17:10:48 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:48 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:48 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:48 --> URI Class Initialized
INFO - 2023-12-20 17:10:48 --> Router Class Initialized
INFO - 2023-12-20 17:10:48 --> Output Class Initialized
INFO - 2023-12-20 17:10:48 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:48 --> Input Class Initialized
INFO - 2023-12-20 17:10:48 --> Language Class Initialized
INFO - 2023-12-20 17:10:48 --> Language Class Initialized
INFO - 2023-12-20 17:10:48 --> Config Class Initialized
INFO - 2023-12-20 17:10:48 --> Loader Class Initialized
INFO - 2023-12-20 17:10:48 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:48 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:48 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:48 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:48 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:48 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 17:10:51 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:51 --> Total execution time: 2.9697
INFO - 2023-12-20 17:10:52 --> Config Class Initialized
INFO - 2023-12-20 17:10:52 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:52 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:52 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:52 --> URI Class Initialized
INFO - 2023-12-20 17:10:52 --> Router Class Initialized
INFO - 2023-12-20 17:10:52 --> Output Class Initialized
INFO - 2023-12-20 17:10:52 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:52 --> Input Class Initialized
INFO - 2023-12-20 17:10:52 --> Language Class Initialized
INFO - 2023-12-20 17:10:52 --> Language Class Initialized
INFO - 2023-12-20 17:10:52 --> Config Class Initialized
INFO - 2023-12-20 17:10:52 --> Loader Class Initialized
INFO - 2023-12-20 17:10:52 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:52 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:52 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:52 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:52 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:52 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 17:10:55 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:55 --> Total execution time: 3.0708
INFO - 2023-12-20 17:10:56 --> Config Class Initialized
INFO - 2023-12-20 17:10:56 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:10:56 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:10:56 --> Utf8 Class Initialized
INFO - 2023-12-20 17:10:56 --> URI Class Initialized
INFO - 2023-12-20 17:10:56 --> Router Class Initialized
INFO - 2023-12-20 17:10:56 --> Output Class Initialized
INFO - 2023-12-20 17:10:56 --> Security Class Initialized
DEBUG - 2023-12-20 17:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:10:56 --> Input Class Initialized
INFO - 2023-12-20 17:10:56 --> Language Class Initialized
INFO - 2023-12-20 17:10:56 --> Language Class Initialized
INFO - 2023-12-20 17:10:56 --> Config Class Initialized
INFO - 2023-12-20 17:10:56 --> Loader Class Initialized
INFO - 2023-12-20 17:10:56 --> Helper loaded: url_helper
INFO - 2023-12-20 17:10:56 --> Helper loaded: file_helper
INFO - 2023-12-20 17:10:56 --> Helper loaded: form_helper
INFO - 2023-12-20 17:10:56 --> Helper loaded: my_helper
INFO - 2023-12-20 17:10:56 --> Database Driver Class Initialized
INFO - 2023-12-20 17:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:10:56 --> Controller Class Initialized
DEBUG - 2023-12-20 17:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 17:10:59 --> Final output sent to browser
DEBUG - 2023-12-20 17:10:59 --> Total execution time: 2.9373
INFO - 2023-12-20 17:12:03 --> Config Class Initialized
INFO - 2023-12-20 17:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:12:03 --> Utf8 Class Initialized
INFO - 2023-12-20 17:12:03 --> URI Class Initialized
INFO - 2023-12-20 17:12:03 --> Router Class Initialized
INFO - 2023-12-20 17:12:03 --> Output Class Initialized
INFO - 2023-12-20 17:12:03 --> Security Class Initialized
DEBUG - 2023-12-20 17:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:12:03 --> Input Class Initialized
INFO - 2023-12-20 17:12:03 --> Language Class Initialized
INFO - 2023-12-20 17:12:03 --> Language Class Initialized
INFO - 2023-12-20 17:12:03 --> Config Class Initialized
INFO - 2023-12-20 17:12:03 --> Loader Class Initialized
INFO - 2023-12-20 17:12:03 --> Helper loaded: url_helper
INFO - 2023-12-20 17:12:03 --> Helper loaded: file_helper
INFO - 2023-12-20 17:12:03 --> Helper loaded: form_helper
INFO - 2023-12-20 17:12:03 --> Helper loaded: my_helper
INFO - 2023-12-20 17:12:03 --> Database Driver Class Initialized
INFO - 2023-12-20 17:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:12:03 --> Controller Class Initialized
DEBUG - 2023-12-20 17:12:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 17:12:12 --> Final output sent to browser
DEBUG - 2023-12-20 17:12:12 --> Total execution time: 8.6041
INFO - 2023-12-20 17:12:12 --> Config Class Initialized
INFO - 2023-12-20 17:12:12 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:12:12 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:12:12 --> Utf8 Class Initialized
INFO - 2023-12-20 17:12:12 --> URI Class Initialized
INFO - 2023-12-20 17:12:12 --> Router Class Initialized
INFO - 2023-12-20 17:12:12 --> Output Class Initialized
INFO - 2023-12-20 17:12:12 --> Security Class Initialized
DEBUG - 2023-12-20 17:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:12:12 --> Input Class Initialized
INFO - 2023-12-20 17:12:12 --> Language Class Initialized
INFO - 2023-12-20 17:12:12 --> Language Class Initialized
INFO - 2023-12-20 17:12:12 --> Config Class Initialized
INFO - 2023-12-20 17:12:12 --> Loader Class Initialized
INFO - 2023-12-20 17:12:12 --> Helper loaded: url_helper
INFO - 2023-12-20 17:12:12 --> Helper loaded: file_helper
INFO - 2023-12-20 17:12:12 --> Helper loaded: form_helper
INFO - 2023-12-20 17:12:12 --> Helper loaded: my_helper
INFO - 2023-12-20 17:12:12 --> Database Driver Class Initialized
INFO - 2023-12-20 17:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:12:12 --> Controller Class Initialized
DEBUG - 2023-12-20 17:12:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 17:12:21 --> Final output sent to browser
DEBUG - 2023-12-20 17:12:21 --> Total execution time: 8.8343
INFO - 2023-12-20 17:14:36 --> Config Class Initialized
INFO - 2023-12-20 17:14:36 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:14:36 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:14:36 --> Utf8 Class Initialized
INFO - 2023-12-20 17:14:36 --> URI Class Initialized
INFO - 2023-12-20 17:14:36 --> Router Class Initialized
INFO - 2023-12-20 17:14:36 --> Output Class Initialized
INFO - 2023-12-20 17:14:36 --> Security Class Initialized
DEBUG - 2023-12-20 17:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:14:36 --> Input Class Initialized
INFO - 2023-12-20 17:14:36 --> Language Class Initialized
INFO - 2023-12-20 17:14:36 --> Language Class Initialized
INFO - 2023-12-20 17:14:36 --> Config Class Initialized
INFO - 2023-12-20 17:14:36 --> Loader Class Initialized
INFO - 2023-12-20 17:14:36 --> Helper loaded: url_helper
INFO - 2023-12-20 17:14:36 --> Helper loaded: file_helper
INFO - 2023-12-20 17:14:36 --> Helper loaded: form_helper
INFO - 2023-12-20 17:14:36 --> Helper loaded: my_helper
INFO - 2023-12-20 17:14:36 --> Database Driver Class Initialized
INFO - 2023-12-20 17:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:14:36 --> Controller Class Initialized
DEBUG - 2023-12-20 17:14:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 17:14:45 --> Final output sent to browser
DEBUG - 2023-12-20 17:14:45 --> Total execution time: 9.2680
INFO - 2023-12-20 17:14:46 --> Config Class Initialized
INFO - 2023-12-20 17:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:14:46 --> Utf8 Class Initialized
INFO - 2023-12-20 17:14:46 --> URI Class Initialized
INFO - 2023-12-20 17:14:46 --> Router Class Initialized
INFO - 2023-12-20 17:14:46 --> Output Class Initialized
INFO - 2023-12-20 17:14:46 --> Security Class Initialized
DEBUG - 2023-12-20 17:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:14:46 --> Input Class Initialized
INFO - 2023-12-20 17:14:46 --> Language Class Initialized
INFO - 2023-12-20 17:14:46 --> Language Class Initialized
INFO - 2023-12-20 17:14:46 --> Config Class Initialized
INFO - 2023-12-20 17:14:46 --> Loader Class Initialized
INFO - 2023-12-20 17:14:46 --> Helper loaded: url_helper
INFO - 2023-12-20 17:14:46 --> Helper loaded: file_helper
INFO - 2023-12-20 17:14:46 --> Helper loaded: form_helper
INFO - 2023-12-20 17:14:46 --> Helper loaded: my_helper
INFO - 2023-12-20 17:14:46 --> Database Driver Class Initialized
INFO - 2023-12-20 17:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:14:46 --> Controller Class Initialized
DEBUG - 2023-12-20 17:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 17:14:55 --> Final output sent to browser
DEBUG - 2023-12-20 17:14:55 --> Total execution time: 8.8560
INFO - 2023-12-20 17:16:06 --> Config Class Initialized
INFO - 2023-12-20 17:16:06 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:06 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:06 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:06 --> URI Class Initialized
INFO - 2023-12-20 17:16:06 --> Router Class Initialized
INFO - 2023-12-20 17:16:06 --> Output Class Initialized
INFO - 2023-12-20 17:16:06 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:06 --> Input Class Initialized
INFO - 2023-12-20 17:16:06 --> Language Class Initialized
INFO - 2023-12-20 17:16:06 --> Language Class Initialized
INFO - 2023-12-20 17:16:06 --> Config Class Initialized
INFO - 2023-12-20 17:16:06 --> Loader Class Initialized
INFO - 2023-12-20 17:16:06 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:06 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:06 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:06 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:06 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:06 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:13 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:13 --> Total execution time: 6.7316
INFO - 2023-12-20 17:16:13 --> Config Class Initialized
INFO - 2023-12-20 17:16:13 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:13 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:13 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:13 --> URI Class Initialized
INFO - 2023-12-20 17:16:13 --> Router Class Initialized
INFO - 2023-12-20 17:16:13 --> Output Class Initialized
INFO - 2023-12-20 17:16:13 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:13 --> Input Class Initialized
INFO - 2023-12-20 17:16:13 --> Language Class Initialized
INFO - 2023-12-20 17:16:13 --> Language Class Initialized
INFO - 2023-12-20 17:16:13 --> Config Class Initialized
INFO - 2023-12-20 17:16:13 --> Loader Class Initialized
INFO - 2023-12-20 17:16:13 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:13 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:13 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:13 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:13 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:13 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:21 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:21 --> Total execution time: 7.7297
INFO - 2023-12-20 17:16:21 --> Config Class Initialized
INFO - 2023-12-20 17:16:21 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:21 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:21 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:21 --> URI Class Initialized
INFO - 2023-12-20 17:16:21 --> Router Class Initialized
INFO - 2023-12-20 17:16:21 --> Output Class Initialized
INFO - 2023-12-20 17:16:21 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:21 --> Input Class Initialized
INFO - 2023-12-20 17:16:21 --> Language Class Initialized
INFO - 2023-12-20 17:16:21 --> Language Class Initialized
INFO - 2023-12-20 17:16:21 --> Config Class Initialized
INFO - 2023-12-20 17:16:21 --> Loader Class Initialized
INFO - 2023-12-20 17:16:21 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:21 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:21 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:21 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:21 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:21 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:27 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:27 --> Total execution time: 5.8431
INFO - 2023-12-20 17:16:28 --> Config Class Initialized
INFO - 2023-12-20 17:16:28 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:28 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:28 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:28 --> URI Class Initialized
INFO - 2023-12-20 17:16:28 --> Router Class Initialized
INFO - 2023-12-20 17:16:28 --> Output Class Initialized
INFO - 2023-12-20 17:16:28 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:28 --> Input Class Initialized
INFO - 2023-12-20 17:16:28 --> Language Class Initialized
INFO - 2023-12-20 17:16:28 --> Language Class Initialized
INFO - 2023-12-20 17:16:28 --> Config Class Initialized
INFO - 2023-12-20 17:16:28 --> Loader Class Initialized
INFO - 2023-12-20 17:16:28 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:28 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:28 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:28 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:28 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:28 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:33 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:33 --> Total execution time: 4.8875
INFO - 2023-12-20 17:16:36 --> Config Class Initialized
INFO - 2023-12-20 17:16:36 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:36 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:36 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:36 --> URI Class Initialized
INFO - 2023-12-20 17:16:36 --> Router Class Initialized
INFO - 2023-12-20 17:16:36 --> Output Class Initialized
INFO - 2023-12-20 17:16:36 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:36 --> Input Class Initialized
INFO - 2023-12-20 17:16:36 --> Language Class Initialized
INFO - 2023-12-20 17:16:36 --> Language Class Initialized
INFO - 2023-12-20 17:16:36 --> Config Class Initialized
INFO - 2023-12-20 17:16:36 --> Loader Class Initialized
INFO - 2023-12-20 17:16:36 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:36 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:36 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:36 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:36 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:36 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:42 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:42 --> Total execution time: 5.4266
INFO - 2023-12-20 17:16:42 --> Config Class Initialized
INFO - 2023-12-20 17:16:42 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:16:42 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:16:42 --> Utf8 Class Initialized
INFO - 2023-12-20 17:16:42 --> URI Class Initialized
INFO - 2023-12-20 17:16:42 --> Router Class Initialized
INFO - 2023-12-20 17:16:42 --> Output Class Initialized
INFO - 2023-12-20 17:16:42 --> Security Class Initialized
DEBUG - 2023-12-20 17:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:16:42 --> Input Class Initialized
INFO - 2023-12-20 17:16:42 --> Language Class Initialized
INFO - 2023-12-20 17:16:42 --> Language Class Initialized
INFO - 2023-12-20 17:16:42 --> Config Class Initialized
INFO - 2023-12-20 17:16:42 --> Loader Class Initialized
INFO - 2023-12-20 17:16:42 --> Helper loaded: url_helper
INFO - 2023-12-20 17:16:42 --> Helper loaded: file_helper
INFO - 2023-12-20 17:16:42 --> Helper loaded: form_helper
INFO - 2023-12-20 17:16:42 --> Helper loaded: my_helper
INFO - 2023-12-20 17:16:42 --> Database Driver Class Initialized
INFO - 2023-12-20 17:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:16:42 --> Controller Class Initialized
DEBUG - 2023-12-20 17:16:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:16:48 --> Final output sent to browser
DEBUG - 2023-12-20 17:16:48 --> Total execution time: 5.9794
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:02 --> Controller Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:02 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:02 --> Total execution time: 0.1207
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:02 --> Controller Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:02 --> Controller Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:02 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:02 --> Total execution time: 0.0455
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:02 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 17:18:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 17:18:02 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:02 --> Total execution time: 0.0471
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:02 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:02 --> URI Class Initialized
INFO - 2023-12-20 17:18:02 --> Router Class Initialized
INFO - 2023-12-20 17:18:02 --> Output Class Initialized
INFO - 2023-12-20 17:18:02 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:02 --> Input Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Language Class Initialized
INFO - 2023-12-20 17:18:02 --> Config Class Initialized
INFO - 2023-12-20 17:18:02 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:02 --> Controller Class Initialized
INFO - 2023-12-20 17:18:02 --> Loader Class Initialized
INFO - 2023-12-20 17:18:02 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:03 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:03 --> Controller Class Initialized
INFO - 2023-12-20 17:18:03 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:03 --> Config Class Initialized
INFO - 2023-12-20 17:18:03 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:03 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:03 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:03 --> URI Class Initialized
INFO - 2023-12-20 17:18:03 --> Router Class Initialized
INFO - 2023-12-20 17:18:03 --> Output Class Initialized
INFO - 2023-12-20 17:18:03 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:03 --> Input Class Initialized
INFO - 2023-12-20 17:18:03 --> Language Class Initialized
INFO - 2023-12-20 17:18:03 --> Language Class Initialized
INFO - 2023-12-20 17:18:03 --> Config Class Initialized
INFO - 2023-12-20 17:18:03 --> Loader Class Initialized
INFO - 2023-12-20 17:18:03 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:03 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:03 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:03 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:03 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:03 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 17:18:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 17:18:03 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:03 --> Total execution time: 0.0409
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:05 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:05 --> URI Class Initialized
INFO - 2023-12-20 17:18:05 --> Router Class Initialized
INFO - 2023-12-20 17:18:05 --> Output Class Initialized
INFO - 2023-12-20 17:18:05 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:05 --> Input Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Loader Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:05 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:05 --> Controller Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:05 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:05 --> Total execution time: 0.0443
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:05 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:05 --> URI Class Initialized
INFO - 2023-12-20 17:18:05 --> Router Class Initialized
INFO - 2023-12-20 17:18:05 --> Output Class Initialized
INFO - 2023-12-20 17:18:05 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:05 --> Input Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:05 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:05 --> URI Class Initialized
INFO - 2023-12-20 17:18:05 --> Router Class Initialized
INFO - 2023-12-20 17:18:05 --> Output Class Initialized
INFO - 2023-12-20 17:18:05 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:05 --> Input Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Loader Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Loader Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:05 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:05 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:05 --> Controller Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:05 --> Controller Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: cookie_helper
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:05 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:05 --> URI Class Initialized
INFO - 2023-12-20 17:18:05 --> Router Class Initialized
INFO - 2023-12-20 17:18:05 --> Output Class Initialized
INFO - 2023-12-20 17:18:05 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:05 --> Input Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Language Class Initialized
INFO - 2023-12-20 17:18:05 --> Config Class Initialized
INFO - 2023-12-20 17:18:05 --> Loader Class Initialized
INFO - 2023-12-20 17:18:05 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:05 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:05 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:05 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 17:18:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 17:18:05 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:05 --> Total execution time: 0.0414
INFO - 2023-12-20 17:18:47 --> Config Class Initialized
INFO - 2023-12-20 17:18:47 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:47 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:47 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:47 --> URI Class Initialized
INFO - 2023-12-20 17:18:47 --> Router Class Initialized
INFO - 2023-12-20 17:18:47 --> Output Class Initialized
INFO - 2023-12-20 17:18:47 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:47 --> Input Class Initialized
INFO - 2023-12-20 17:18:47 --> Language Class Initialized
INFO - 2023-12-20 17:18:47 --> Language Class Initialized
INFO - 2023-12-20 17:18:47 --> Config Class Initialized
INFO - 2023-12-20 17:18:47 --> Loader Class Initialized
INFO - 2023-12-20 17:18:47 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:47 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:47 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:47 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:47 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:47 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:18:52 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:52 --> Total execution time: 5.5166
INFO - 2023-12-20 17:18:53 --> Config Class Initialized
INFO - 2023-12-20 17:18:53 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:53 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:53 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:53 --> URI Class Initialized
INFO - 2023-12-20 17:18:53 --> Router Class Initialized
INFO - 2023-12-20 17:18:53 --> Output Class Initialized
INFO - 2023-12-20 17:18:53 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:53 --> Input Class Initialized
INFO - 2023-12-20 17:18:53 --> Language Class Initialized
INFO - 2023-12-20 17:18:53 --> Language Class Initialized
INFO - 2023-12-20 17:18:53 --> Config Class Initialized
INFO - 2023-12-20 17:18:53 --> Loader Class Initialized
INFO - 2023-12-20 17:18:53 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:53 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:53 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:53 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:53 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:53 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:18:57 --> Final output sent to browser
DEBUG - 2023-12-20 17:18:57 --> Total execution time: 4.3739
INFO - 2023-12-20 17:18:58 --> Config Class Initialized
INFO - 2023-12-20 17:18:58 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:18:58 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:18:58 --> Utf8 Class Initialized
INFO - 2023-12-20 17:18:58 --> URI Class Initialized
INFO - 2023-12-20 17:18:58 --> Router Class Initialized
INFO - 2023-12-20 17:18:58 --> Output Class Initialized
INFO - 2023-12-20 17:18:58 --> Security Class Initialized
DEBUG - 2023-12-20 17:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:18:58 --> Input Class Initialized
INFO - 2023-12-20 17:18:58 --> Language Class Initialized
INFO - 2023-12-20 17:18:58 --> Language Class Initialized
INFO - 2023-12-20 17:18:58 --> Config Class Initialized
INFO - 2023-12-20 17:18:58 --> Loader Class Initialized
INFO - 2023-12-20 17:18:58 --> Helper loaded: url_helper
INFO - 2023-12-20 17:18:58 --> Helper loaded: file_helper
INFO - 2023-12-20 17:18:58 --> Helper loaded: form_helper
INFO - 2023-12-20 17:18:58 --> Helper loaded: my_helper
INFO - 2023-12-20 17:18:58 --> Database Driver Class Initialized
INFO - 2023-12-20 17:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:18:58 --> Controller Class Initialized
DEBUG - 2023-12-20 17:18:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:19:04 --> Final output sent to browser
DEBUG - 2023-12-20 17:19:04 --> Total execution time: 5.4797
INFO - 2023-12-20 17:19:04 --> Config Class Initialized
INFO - 2023-12-20 17:19:04 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:19:04 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:19:04 --> Utf8 Class Initialized
INFO - 2023-12-20 17:19:04 --> URI Class Initialized
INFO - 2023-12-20 17:19:04 --> Router Class Initialized
INFO - 2023-12-20 17:19:04 --> Output Class Initialized
INFO - 2023-12-20 17:19:04 --> Security Class Initialized
DEBUG - 2023-12-20 17:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:19:04 --> Input Class Initialized
INFO - 2023-12-20 17:19:04 --> Language Class Initialized
INFO - 2023-12-20 17:19:04 --> Language Class Initialized
INFO - 2023-12-20 17:19:04 --> Config Class Initialized
INFO - 2023-12-20 17:19:04 --> Loader Class Initialized
INFO - 2023-12-20 17:19:04 --> Helper loaded: url_helper
INFO - 2023-12-20 17:19:04 --> Helper loaded: file_helper
INFO - 2023-12-20 17:19:04 --> Helper loaded: form_helper
INFO - 2023-12-20 17:19:04 --> Helper loaded: my_helper
INFO - 2023-12-20 17:19:05 --> Database Driver Class Initialized
INFO - 2023-12-20 17:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:19:05 --> Controller Class Initialized
DEBUG - 2023-12-20 17:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:19:09 --> Final output sent to browser
DEBUG - 2023-12-20 17:19:09 --> Total execution time: 4.6567
INFO - 2023-12-20 17:20:06 --> Config Class Initialized
INFO - 2023-12-20 17:20:06 --> Hooks Class Initialized
DEBUG - 2023-12-20 17:20:06 --> UTF-8 Support Enabled
INFO - 2023-12-20 17:20:06 --> Utf8 Class Initialized
INFO - 2023-12-20 17:20:06 --> URI Class Initialized
INFO - 2023-12-20 17:20:06 --> Router Class Initialized
INFO - 2023-12-20 17:20:06 --> Output Class Initialized
INFO - 2023-12-20 17:20:06 --> Security Class Initialized
DEBUG - 2023-12-20 17:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 17:20:06 --> Input Class Initialized
INFO - 2023-12-20 17:20:06 --> Language Class Initialized
INFO - 2023-12-20 17:20:06 --> Language Class Initialized
INFO - 2023-12-20 17:20:06 --> Config Class Initialized
INFO - 2023-12-20 17:20:06 --> Loader Class Initialized
INFO - 2023-12-20 17:20:06 --> Helper loaded: url_helper
INFO - 2023-12-20 17:20:06 --> Helper loaded: file_helper
INFO - 2023-12-20 17:20:06 --> Helper loaded: form_helper
INFO - 2023-12-20 17:20:06 --> Helper loaded: my_helper
INFO - 2023-12-20 17:20:06 --> Database Driver Class Initialized
INFO - 2023-12-20 17:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 17:20:06 --> Controller Class Initialized
DEBUG - 2023-12-20 17:20:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 17:20:11 --> Final output sent to browser
DEBUG - 2023-12-20 17:20:11 --> Total execution time: 5.5684
INFO - 2023-12-20 20:00:00 --> Config Class Initialized
INFO - 2023-12-20 20:00:00 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:00 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:00 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:00 --> URI Class Initialized
INFO - 2023-12-20 20:00:00 --> Router Class Initialized
INFO - 2023-12-20 20:00:00 --> Output Class Initialized
INFO - 2023-12-20 20:00:00 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:00 --> Input Class Initialized
INFO - 2023-12-20 20:00:00 --> Language Class Initialized
INFO - 2023-12-20 20:00:00 --> Language Class Initialized
INFO - 2023-12-20 20:00:00 --> Config Class Initialized
INFO - 2023-12-20 20:00:00 --> Loader Class Initialized
INFO - 2023-12-20 20:00:01 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:01 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:01 --> Controller Class Initialized
INFO - 2023-12-20 20:00:01 --> Helper loaded: cookie_helper
INFO - 2023-12-20 20:00:01 --> Final output sent to browser
DEBUG - 2023-12-20 20:00:01 --> Total execution time: 0.5394
INFO - 2023-12-20 20:00:01 --> Config Class Initialized
INFO - 2023-12-20 20:00:01 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:01 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:01 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:01 --> URI Class Initialized
INFO - 2023-12-20 20:00:01 --> Router Class Initialized
INFO - 2023-12-20 20:00:01 --> Output Class Initialized
INFO - 2023-12-20 20:00:01 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:01 --> Input Class Initialized
INFO - 2023-12-20 20:00:01 --> Language Class Initialized
INFO - 2023-12-20 20:00:01 --> Config Class Initialized
INFO - 2023-12-20 20:00:01 --> Hooks Class Initialized
INFO - 2023-12-20 20:00:01 --> Language Class Initialized
INFO - 2023-12-20 20:00:01 --> Config Class Initialized
INFO - 2023-12-20 20:00:01 --> Loader Class Initialized
INFO - 2023-12-20 20:00:01 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:01 --> Helper loaded: my_helper
DEBUG - 2023-12-20 20:00:01 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:01 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:01 --> URI Class Initialized
INFO - 2023-12-20 20:00:01 --> Router Class Initialized
INFO - 2023-12-20 20:00:01 --> Output Class Initialized
INFO - 2023-12-20 20:00:01 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:01 --> Input Class Initialized
INFO - 2023-12-20 20:00:01 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Loader Class Initialized
INFO - 2023-12-20 20:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:02 --> Controller Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:02 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 20:00:02 --> Final output sent to browser
DEBUG - 2023-12-20 20:00:02 --> Total execution time: 0.6156
INFO - 2023-12-20 20:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:02 --> Controller Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:02 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:02 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:02 --> URI Class Initialized
INFO - 2023-12-20 20:00:02 --> URI Class Initialized
INFO - 2023-12-20 20:00:02 --> Router Class Initialized
INFO - 2023-12-20 20:00:02 --> Output Class Initialized
INFO - 2023-12-20 20:00:02 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:02 --> Input Class Initialized
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:02 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:02 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Loader Class Initialized
INFO - 2023-12-20 20:00:02 --> Router Class Initialized
INFO - 2023-12-20 20:00:02 --> Output Class Initialized
INFO - 2023-12-20 20:00:02 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:02 --> Input Class Initialized
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> URI Class Initialized
INFO - 2023-12-20 20:00:02 --> Router Class Initialized
INFO - 2023-12-20 20:00:02 --> Output Class Initialized
INFO - 2023-12-20 20:00:02 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:02 --> Input Class Initialized
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Loader Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:02 --> Language Class Initialized
INFO - 2023-12-20 20:00:02 --> Config Class Initialized
INFO - 2023-12-20 20:00:02 --> Loader Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:02 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:02 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:02 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:02 --> Controller Class Initialized
INFO - 2023-12-20 20:00:02 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:02 --> Helper loaded: cookie_helper
INFO - 2023-12-20 20:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:02 --> Controller Class Initialized
DEBUG - 2023-12-20 20:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 20:00:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 20:00:02 --> Final output sent to browser
DEBUG - 2023-12-20 20:00:02 --> Total execution time: 0.4704
INFO - 2023-12-20 20:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:02 --> Controller Class Initialized
INFO - 2023-12-20 20:00:03 --> Helper loaded: cookie_helper
INFO - 2023-12-20 20:00:03 --> Config Class Initialized
INFO - 2023-12-20 20:00:03 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:03 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:03 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:03 --> URI Class Initialized
INFO - 2023-12-20 20:00:03 --> Router Class Initialized
INFO - 2023-12-20 20:00:03 --> Output Class Initialized
INFO - 2023-12-20 20:00:03 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:03 --> Input Class Initialized
INFO - 2023-12-20 20:00:03 --> Language Class Initialized
INFO - 2023-12-20 20:00:03 --> Language Class Initialized
INFO - 2023-12-20 20:00:03 --> Config Class Initialized
INFO - 2023-12-20 20:00:03 --> Loader Class Initialized
INFO - 2023-12-20 20:00:03 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:03 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:03 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:03 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:03 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:03 --> Controller Class Initialized
DEBUG - 2023-12-20 20:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-20 20:00:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-20 20:00:03 --> Final output sent to browser
DEBUG - 2023-12-20 20:00:03 --> Total execution time: 0.1260
INFO - 2023-12-20 20:00:47 --> Config Class Initialized
INFO - 2023-12-20 20:00:47 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:00:47 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:00:47 --> Utf8 Class Initialized
INFO - 2023-12-20 20:00:47 --> URI Class Initialized
INFO - 2023-12-20 20:00:47 --> Router Class Initialized
INFO - 2023-12-20 20:00:47 --> Output Class Initialized
INFO - 2023-12-20 20:00:47 --> Security Class Initialized
DEBUG - 2023-12-20 20:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:00:47 --> Input Class Initialized
INFO - 2023-12-20 20:00:47 --> Language Class Initialized
INFO - 2023-12-20 20:00:47 --> Language Class Initialized
INFO - 2023-12-20 20:00:47 --> Config Class Initialized
INFO - 2023-12-20 20:00:47 --> Loader Class Initialized
INFO - 2023-12-20 20:00:47 --> Helper loaded: url_helper
INFO - 2023-12-20 20:00:47 --> Helper loaded: file_helper
INFO - 2023-12-20 20:00:47 --> Helper loaded: form_helper
INFO - 2023-12-20 20:00:47 --> Helper loaded: my_helper
INFO - 2023-12-20 20:00:47 --> Database Driver Class Initialized
INFO - 2023-12-20 20:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:00:47 --> Controller Class Initialized
DEBUG - 2023-12-20 20:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:01:07 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:07 --> Total execution time: 19.7347
INFO - 2023-12-20 20:01:07 --> Config Class Initialized
INFO - 2023-12-20 20:01:07 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:07 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:07 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:07 --> Config Class Initialized
INFO - 2023-12-20 20:01:07 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:07 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:07 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:07 --> URI Class Initialized
INFO - 2023-12-20 20:01:07 --> URI Class Initialized
INFO - 2023-12-20 20:01:07 --> Router Class Initialized
INFO - 2023-12-20 20:01:07 --> Router Class Initialized
INFO - 2023-12-20 20:01:07 --> Output Class Initialized
INFO - 2023-12-20 20:01:07 --> Output Class Initialized
INFO - 2023-12-20 20:01:07 --> Security Class Initialized
INFO - 2023-12-20 20:01:07 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:07 --> Input Class Initialized
INFO - 2023-12-20 20:01:07 --> Language Class Initialized
DEBUG - 2023-12-20 20:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:07 --> Input Class Initialized
INFO - 2023-12-20 20:01:07 --> Language Class Initialized
INFO - 2023-12-20 20:01:07 --> Language Class Initialized
INFO - 2023-12-20 20:01:07 --> Config Class Initialized
INFO - 2023-12-20 20:01:07 --> Loader Class Initialized
INFO - 2023-12-20 20:01:07 --> Language Class Initialized
INFO - 2023-12-20 20:01:07 --> Config Class Initialized
INFO - 2023-12-20 20:01:07 --> Loader Class Initialized
INFO - 2023-12-20 20:01:07 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:07 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:07 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:07 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:08 --> Controller Class Initialized
INFO - 2023-12-20 20:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:08 --> Controller Class Initialized
DEBUG - 2023-12-20 20:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
DEBUG - 2023-12-20 20:01:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:01:13 --> Config Class Initialized
INFO - 2023-12-20 20:01:13 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:13 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:13 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:13 --> URI Class Initialized
INFO - 2023-12-20 20:01:13 --> Router Class Initialized
INFO - 2023-12-20 20:01:13 --> Output Class Initialized
INFO - 2023-12-20 20:01:13 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:13 --> Input Class Initialized
INFO - 2023-12-20 20:01:13 --> Language Class Initialized
INFO - 2023-12-20 20:01:13 --> Language Class Initialized
INFO - 2023-12-20 20:01:13 --> Config Class Initialized
INFO - 2023-12-20 20:01:13 --> Loader Class Initialized
INFO - 2023-12-20 20:01:13 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:13 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:13 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:13 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:13 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:13 --> Controller Class Initialized
DEBUG - 2023-12-20 20:01:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:01:24 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:24 --> Total execution time: 17.4188
INFO - 2023-12-20 20:01:25 --> Config Class Initialized
INFO - 2023-12-20 20:01:25 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:25 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:25 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:25 --> URI Class Initialized
INFO - 2023-12-20 20:01:25 --> Router Class Initialized
INFO - 2023-12-20 20:01:25 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:25 --> Total execution time: 17.6837
INFO - 2023-12-20 20:01:25 --> Output Class Initialized
INFO - 2023-12-20 20:01:25 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:25 --> Input Class Initialized
INFO - 2023-12-20 20:01:25 --> Language Class Initialized
INFO - 2023-12-20 20:01:25 --> Language Class Initialized
INFO - 2023-12-20 20:01:25 --> Config Class Initialized
INFO - 2023-12-20 20:01:25 --> Loader Class Initialized
INFO - 2023-12-20 20:01:25 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:25 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:25 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:25 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:25 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:25 --> Controller Class Initialized
DEBUG - 2023-12-20 20:01:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:01:29 --> Config Class Initialized
INFO - 2023-12-20 20:01:29 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:29 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:29 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:29 --> URI Class Initialized
INFO - 2023-12-20 20:01:29 --> Router Class Initialized
INFO - 2023-12-20 20:01:29 --> Output Class Initialized
INFO - 2023-12-20 20:01:29 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:29 --> Input Class Initialized
INFO - 2023-12-20 20:01:29 --> Language Class Initialized
INFO - 2023-12-20 20:01:29 --> Language Class Initialized
INFO - 2023-12-20 20:01:29 --> Config Class Initialized
INFO - 2023-12-20 20:01:29 --> Loader Class Initialized
INFO - 2023-12-20 20:01:29 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:29 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:29 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:29 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:30 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:30 --> Controller Class Initialized
DEBUG - 2023-12-20 20:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:01:35 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:35 --> Total execution time: 22.6392
INFO - 2023-12-20 20:01:35 --> Config Class Initialized
INFO - 2023-12-20 20:01:35 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:35 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:35 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:35 --> URI Class Initialized
INFO - 2023-12-20 20:01:35 --> Router Class Initialized
INFO - 2023-12-20 20:01:36 --> Output Class Initialized
INFO - 2023-12-20 20:01:36 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:36 --> Input Class Initialized
INFO - 2023-12-20 20:01:36 --> Language Class Initialized
INFO - 2023-12-20 20:01:36 --> Language Class Initialized
INFO - 2023-12-20 20:01:36 --> Config Class Initialized
INFO - 2023-12-20 20:01:36 --> Loader Class Initialized
INFO - 2023-12-20 20:01:36 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:36 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:36 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:36 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:36 --> Database Driver Class Initialized
INFO - 2023-12-20 20:01:49 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:49 --> Total execution time: 24.7115
INFO - 2023-12-20 20:01:55 --> Final output sent to browser
DEBUG - 2023-12-20 20:01:55 --> Total execution time: 25.6937
INFO - 2023-12-20 20:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:01:55 --> Controller Class Initialized
INFO - 2023-12-20 20:01:55 --> Config Class Initialized
INFO - 2023-12-20 20:01:55 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:01:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
DEBUG - 2023-12-20 20:01:55 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:01:55 --> Utf8 Class Initialized
INFO - 2023-12-20 20:01:55 --> URI Class Initialized
INFO - 2023-12-20 20:01:55 --> Router Class Initialized
INFO - 2023-12-20 20:01:55 --> Output Class Initialized
INFO - 2023-12-20 20:01:55 --> Security Class Initialized
DEBUG - 2023-12-20 20:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:01:55 --> Input Class Initialized
INFO - 2023-12-20 20:01:55 --> Language Class Initialized
INFO - 2023-12-20 20:01:55 --> Language Class Initialized
INFO - 2023-12-20 20:01:55 --> Config Class Initialized
INFO - 2023-12-20 20:01:55 --> Loader Class Initialized
INFO - 2023-12-20 20:01:55 --> Helper loaded: url_helper
INFO - 2023-12-20 20:01:55 --> Helper loaded: file_helper
INFO - 2023-12-20 20:01:55 --> Helper loaded: form_helper
INFO - 2023-12-20 20:01:55 --> Helper loaded: my_helper
INFO - 2023-12-20 20:01:55 --> Database Driver Class Initialized
INFO - 2023-12-20 20:02:10 --> Final output sent to browser
DEBUG - 2023-12-20 20:02:10 --> Total execution time: 35.0419
INFO - 2023-12-20 20:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:02:11 --> Controller Class Initialized
DEBUG - 2023-12-20 20:02:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-20 20:02:22 --> Final output sent to browser
DEBUG - 2023-12-20 20:02:22 --> Total execution time: 26.6330
INFO - 2023-12-20 20:03:56 --> Config Class Initialized
INFO - 2023-12-20 20:03:56 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:03:56 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:03:56 --> Utf8 Class Initialized
INFO - 2023-12-20 20:03:56 --> URI Class Initialized
INFO - 2023-12-20 20:03:56 --> Router Class Initialized
INFO - 2023-12-20 20:03:56 --> Output Class Initialized
INFO - 2023-12-20 20:03:56 --> Security Class Initialized
DEBUG - 2023-12-20 20:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:03:56 --> Input Class Initialized
INFO - 2023-12-20 20:03:56 --> Language Class Initialized
INFO - 2023-12-20 20:03:56 --> Language Class Initialized
INFO - 2023-12-20 20:03:56 --> Config Class Initialized
INFO - 2023-12-20 20:03:56 --> Loader Class Initialized
INFO - 2023-12-20 20:03:56 --> Helper loaded: url_helper
INFO - 2023-12-20 20:03:56 --> Helper loaded: file_helper
INFO - 2023-12-20 20:03:56 --> Helper loaded: form_helper
INFO - 2023-12-20 20:03:56 --> Helper loaded: my_helper
INFO - 2023-12-20 20:03:56 --> Database Driver Class Initialized
INFO - 2023-12-20 20:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:03:56 --> Controller Class Initialized
DEBUG - 2023-12-20 20:03:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:04:21 --> Final output sent to browser
DEBUG - 2023-12-20 20:04:21 --> Total execution time: 25.0654
INFO - 2023-12-20 20:04:21 --> Config Class Initialized
INFO - 2023-12-20 20:04:21 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:04:21 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:04:21 --> Utf8 Class Initialized
INFO - 2023-12-20 20:04:21 --> URI Class Initialized
INFO - 2023-12-20 20:04:21 --> Router Class Initialized
INFO - 2023-12-20 20:04:21 --> Output Class Initialized
INFO - 2023-12-20 20:04:21 --> Security Class Initialized
DEBUG - 2023-12-20 20:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:04:21 --> Input Class Initialized
INFO - 2023-12-20 20:04:21 --> Language Class Initialized
INFO - 2023-12-20 20:04:21 --> Language Class Initialized
INFO - 2023-12-20 20:04:21 --> Config Class Initialized
INFO - 2023-12-20 20:04:21 --> Loader Class Initialized
INFO - 2023-12-20 20:04:21 --> Helper loaded: url_helper
INFO - 2023-12-20 20:04:21 --> Helper loaded: file_helper
INFO - 2023-12-20 20:04:21 --> Helper loaded: form_helper
INFO - 2023-12-20 20:04:21 --> Helper loaded: my_helper
INFO - 2023-12-20 20:04:21 --> Database Driver Class Initialized
INFO - 2023-12-20 20:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:04:22 --> Controller Class Initialized
DEBUG - 2023-12-20 20:04:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:04:31 --> Config Class Initialized
INFO - 2023-12-20 20:04:31 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:04:31 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:04:31 --> Utf8 Class Initialized
INFO - 2023-12-20 20:04:31 --> URI Class Initialized
INFO - 2023-12-20 20:04:31 --> Router Class Initialized
INFO - 2023-12-20 20:04:31 --> Output Class Initialized
INFO - 2023-12-20 20:04:31 --> Security Class Initialized
DEBUG - 2023-12-20 20:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:04:31 --> Input Class Initialized
INFO - 2023-12-20 20:04:31 --> Language Class Initialized
INFO - 2023-12-20 20:04:31 --> Language Class Initialized
INFO - 2023-12-20 20:04:31 --> Config Class Initialized
INFO - 2023-12-20 20:04:31 --> Loader Class Initialized
INFO - 2023-12-20 20:04:31 --> Helper loaded: url_helper
INFO - 2023-12-20 20:04:31 --> Helper loaded: file_helper
INFO - 2023-12-20 20:04:31 --> Helper loaded: form_helper
INFO - 2023-12-20 20:04:31 --> Helper loaded: my_helper
INFO - 2023-12-20 20:04:31 --> Database Driver Class Initialized
INFO - 2023-12-20 20:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:04:31 --> Controller Class Initialized
DEBUG - 2023-12-20 20:04:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:04:53 --> Final output sent to browser
DEBUG - 2023-12-20 20:04:53 --> Total execution time: 31.8587
INFO - 2023-12-20 20:05:03 --> Final output sent to browser
DEBUG - 2023-12-20 20:05:03 --> Total execution time: 32.9064
INFO - 2023-12-20 20:05:04 --> Config Class Initialized
INFO - 2023-12-20 20:05:04 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:05:04 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:05:04 --> Utf8 Class Initialized
INFO - 2023-12-20 20:05:04 --> URI Class Initialized
INFO - 2023-12-20 20:05:04 --> Router Class Initialized
INFO - 2023-12-20 20:05:04 --> Output Class Initialized
INFO - 2023-12-20 20:05:04 --> Security Class Initialized
DEBUG - 2023-12-20 20:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:05:04 --> Input Class Initialized
INFO - 2023-12-20 20:05:04 --> Language Class Initialized
INFO - 2023-12-20 20:05:04 --> Language Class Initialized
INFO - 2023-12-20 20:05:04 --> Config Class Initialized
INFO - 2023-12-20 20:05:04 --> Loader Class Initialized
INFO - 2023-12-20 20:05:04 --> Helper loaded: url_helper
INFO - 2023-12-20 20:05:04 --> Helper loaded: file_helper
INFO - 2023-12-20 20:05:04 --> Helper loaded: form_helper
INFO - 2023-12-20 20:05:04 --> Helper loaded: my_helper
INFO - 2023-12-20 20:05:05 --> Database Driver Class Initialized
INFO - 2023-12-20 20:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:05:05 --> Controller Class Initialized
DEBUG - 2023-12-20 20:05:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:05:24 --> Final output sent to browser
DEBUG - 2023-12-20 20:05:24 --> Total execution time: 19.5792
INFO - 2023-12-20 20:05:36 --> Config Class Initialized
INFO - 2023-12-20 20:05:36 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:05:36 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:05:36 --> Utf8 Class Initialized
INFO - 2023-12-20 20:05:36 --> URI Class Initialized
INFO - 2023-12-20 20:05:36 --> Router Class Initialized
INFO - 2023-12-20 20:05:36 --> Output Class Initialized
INFO - 2023-12-20 20:05:36 --> Security Class Initialized
DEBUG - 2023-12-20 20:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:05:36 --> Input Class Initialized
INFO - 2023-12-20 20:05:36 --> Language Class Initialized
INFO - 2023-12-20 20:05:36 --> Language Class Initialized
INFO - 2023-12-20 20:05:36 --> Config Class Initialized
INFO - 2023-12-20 20:05:36 --> Loader Class Initialized
INFO - 2023-12-20 20:05:36 --> Helper loaded: url_helper
INFO - 2023-12-20 20:05:36 --> Helper loaded: file_helper
INFO - 2023-12-20 20:05:36 --> Helper loaded: form_helper
INFO - 2023-12-20 20:05:36 --> Helper loaded: my_helper
INFO - 2023-12-20 20:05:36 --> Database Driver Class Initialized
INFO - 2023-12-20 20:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:05:36 --> Controller Class Initialized
DEBUG - 2023-12-20 20:05:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:05:47 --> Final output sent to browser
DEBUG - 2023-12-20 20:05:47 --> Total execution time: 12.0144
INFO - 2023-12-20 20:05:48 --> Config Class Initialized
INFO - 2023-12-20 20:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:05:48 --> Utf8 Class Initialized
INFO - 2023-12-20 20:05:48 --> URI Class Initialized
INFO - 2023-12-20 20:05:48 --> Router Class Initialized
INFO - 2023-12-20 20:05:48 --> Output Class Initialized
INFO - 2023-12-20 20:05:48 --> Security Class Initialized
DEBUG - 2023-12-20 20:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:05:48 --> Input Class Initialized
INFO - 2023-12-20 20:05:48 --> Language Class Initialized
INFO - 2023-12-20 20:05:48 --> Language Class Initialized
INFO - 2023-12-20 20:05:48 --> Config Class Initialized
INFO - 2023-12-20 20:05:48 --> Loader Class Initialized
INFO - 2023-12-20 20:05:48 --> Helper loaded: url_helper
INFO - 2023-12-20 20:05:48 --> Helper loaded: file_helper
INFO - 2023-12-20 20:05:48 --> Helper loaded: form_helper
INFO - 2023-12-20 20:05:48 --> Helper loaded: my_helper
INFO - 2023-12-20 20:05:48 --> Database Driver Class Initialized
INFO - 2023-12-20 20:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:05:48 --> Controller Class Initialized
DEBUG - 2023-12-20 20:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:05:51 --> Config Class Initialized
INFO - 2023-12-20 20:05:51 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:05:51 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:05:51 --> Utf8 Class Initialized
INFO - 2023-12-20 20:05:51 --> URI Class Initialized
INFO - 2023-12-20 20:05:51 --> Router Class Initialized
INFO - 2023-12-20 20:05:51 --> Output Class Initialized
INFO - 2023-12-20 20:05:51 --> Security Class Initialized
DEBUG - 2023-12-20 20:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:05:51 --> Input Class Initialized
INFO - 2023-12-20 20:05:51 --> Language Class Initialized
INFO - 2023-12-20 20:05:51 --> Language Class Initialized
INFO - 2023-12-20 20:05:51 --> Config Class Initialized
INFO - 2023-12-20 20:05:51 --> Loader Class Initialized
INFO - 2023-12-20 20:05:51 --> Helper loaded: url_helper
INFO - 2023-12-20 20:05:51 --> Helper loaded: file_helper
INFO - 2023-12-20 20:05:51 --> Helper loaded: form_helper
INFO - 2023-12-20 20:05:51 --> Helper loaded: my_helper
INFO - 2023-12-20 20:05:51 --> Database Driver Class Initialized
INFO - 2023-12-20 20:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:05:52 --> Controller Class Initialized
DEBUG - 2023-12-20 20:05:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:05:58 --> Final output sent to browser
DEBUG - 2023-12-20 20:05:58 --> Total execution time: 9.9835
INFO - 2023-12-20 20:06:09 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:09 --> Total execution time: 17.6408
INFO - 2023-12-20 20:06:09 --> Config Class Initialized
INFO - 2023-12-20 20:06:09 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:06:09 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:06:09 --> Utf8 Class Initialized
INFO - 2023-12-20 20:06:09 --> URI Class Initialized
INFO - 2023-12-20 20:06:09 --> Router Class Initialized
INFO - 2023-12-20 20:06:09 --> Output Class Initialized
INFO - 2023-12-20 20:06:09 --> Security Class Initialized
DEBUG - 2023-12-20 20:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:06:09 --> Input Class Initialized
INFO - 2023-12-20 20:06:09 --> Language Class Initialized
INFO - 2023-12-20 20:06:09 --> Language Class Initialized
INFO - 2023-12-20 20:06:09 --> Config Class Initialized
INFO - 2023-12-20 20:06:09 --> Loader Class Initialized
INFO - 2023-12-20 20:06:09 --> Helper loaded: url_helper
INFO - 2023-12-20 20:06:09 --> Helper loaded: file_helper
INFO - 2023-12-20 20:06:09 --> Helper loaded: form_helper
INFO - 2023-12-20 20:06:09 --> Helper loaded: my_helper
INFO - 2023-12-20 20:06:09 --> Database Driver Class Initialized
INFO - 2023-12-20 20:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:06:09 --> Controller Class Initialized
DEBUG - 2023-12-20 20:06:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:06:17 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:17 --> Total execution time: 7.8215
INFO - 2023-12-20 20:06:21 --> Config Class Initialized
INFO - 2023-12-20 20:06:21 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:06:21 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:06:21 --> Utf8 Class Initialized
INFO - 2023-12-20 20:06:21 --> URI Class Initialized
INFO - 2023-12-20 20:06:21 --> Router Class Initialized
INFO - 2023-12-20 20:06:21 --> Output Class Initialized
INFO - 2023-12-20 20:06:21 --> Security Class Initialized
DEBUG - 2023-12-20 20:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:06:21 --> Input Class Initialized
INFO - 2023-12-20 20:06:21 --> Language Class Initialized
INFO - 2023-12-20 20:06:21 --> Language Class Initialized
INFO - 2023-12-20 20:06:21 --> Config Class Initialized
INFO - 2023-12-20 20:06:21 --> Loader Class Initialized
INFO - 2023-12-20 20:06:21 --> Helper loaded: url_helper
INFO - 2023-12-20 20:06:21 --> Helper loaded: file_helper
INFO - 2023-12-20 20:06:21 --> Helper loaded: form_helper
INFO - 2023-12-20 20:06:21 --> Helper loaded: my_helper
INFO - 2023-12-20 20:06:21 --> Database Driver Class Initialized
INFO - 2023-12-20 20:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:06:21 --> Controller Class Initialized
DEBUG - 2023-12-20 20:06:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 20:06:25 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:25 --> Total execution time: 3.7830
INFO - 2023-12-20 20:06:26 --> Config Class Initialized
INFO - 2023-12-20 20:06:26 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:06:26 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:06:26 --> Utf8 Class Initialized
INFO - 2023-12-20 20:06:26 --> URI Class Initialized
INFO - 2023-12-20 20:06:26 --> Router Class Initialized
INFO - 2023-12-20 20:06:26 --> Output Class Initialized
INFO - 2023-12-20 20:06:26 --> Security Class Initialized
DEBUG - 2023-12-20 20:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:06:26 --> Input Class Initialized
INFO - 2023-12-20 20:06:26 --> Language Class Initialized
INFO - 2023-12-20 20:06:26 --> Language Class Initialized
INFO - 2023-12-20 20:06:26 --> Config Class Initialized
INFO - 2023-12-20 20:06:26 --> Loader Class Initialized
INFO - 2023-12-20 20:06:26 --> Helper loaded: url_helper
INFO - 2023-12-20 20:06:26 --> Helper loaded: file_helper
INFO - 2023-12-20 20:06:26 --> Helper loaded: form_helper
INFO - 2023-12-20 20:06:26 --> Helper loaded: my_helper
INFO - 2023-12-20 20:06:26 --> Database Driver Class Initialized
INFO - 2023-12-20 20:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:06:26 --> Controller Class Initialized
DEBUG - 2023-12-20 20:06:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 20:06:27 --> Config Class Initialized
INFO - 2023-12-20 20:06:27 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:06:27 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:06:27 --> Utf8 Class Initialized
INFO - 2023-12-20 20:06:27 --> URI Class Initialized
INFO - 2023-12-20 20:06:27 --> Router Class Initialized
INFO - 2023-12-20 20:06:27 --> Output Class Initialized
INFO - 2023-12-20 20:06:27 --> Security Class Initialized
DEBUG - 2023-12-20 20:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:06:27 --> Input Class Initialized
INFO - 2023-12-20 20:06:27 --> Language Class Initialized
INFO - 2023-12-20 20:06:27 --> Language Class Initialized
INFO - 2023-12-20 20:06:27 --> Config Class Initialized
INFO - 2023-12-20 20:06:27 --> Loader Class Initialized
INFO - 2023-12-20 20:06:27 --> Helper loaded: url_helper
INFO - 2023-12-20 20:06:27 --> Helper loaded: file_helper
INFO - 2023-12-20 20:06:27 --> Helper loaded: form_helper
INFO - 2023-12-20 20:06:27 --> Helper loaded: my_helper
INFO - 2023-12-20 20:06:27 --> Database Driver Class Initialized
INFO - 2023-12-20 20:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:06:28 --> Controller Class Initialized
DEBUG - 2023-12-20 20:06:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 20:06:31 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:31 --> Total execution time: 5.2608
INFO - 2023-12-20 20:06:34 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:34 --> Total execution time: 7.1623
INFO - 2023-12-20 20:06:35 --> Config Class Initialized
INFO - 2023-12-20 20:06:35 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:06:35 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:06:35 --> Utf8 Class Initialized
INFO - 2023-12-20 20:06:35 --> URI Class Initialized
INFO - 2023-12-20 20:06:35 --> Router Class Initialized
INFO - 2023-12-20 20:06:35 --> Output Class Initialized
INFO - 2023-12-20 20:06:35 --> Security Class Initialized
DEBUG - 2023-12-20 20:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:06:35 --> Input Class Initialized
INFO - 2023-12-20 20:06:35 --> Language Class Initialized
INFO - 2023-12-20 20:06:35 --> Language Class Initialized
INFO - 2023-12-20 20:06:35 --> Config Class Initialized
INFO - 2023-12-20 20:06:35 --> Loader Class Initialized
INFO - 2023-12-20 20:06:35 --> Helper loaded: url_helper
INFO - 2023-12-20 20:06:35 --> Helper loaded: file_helper
INFO - 2023-12-20 20:06:35 --> Helper loaded: form_helper
INFO - 2023-12-20 20:06:35 --> Helper loaded: my_helper
INFO - 2023-12-20 20:06:35 --> Database Driver Class Initialized
INFO - 2023-12-20 20:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:06:35 --> Controller Class Initialized
DEBUG - 2023-12-20 20:06:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-20 20:06:41 --> Final output sent to browser
DEBUG - 2023-12-20 20:06:41 --> Total execution time: 6.0653
INFO - 2023-12-20 20:09:38 --> Config Class Initialized
INFO - 2023-12-20 20:09:38 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:09:38 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:09:38 --> Utf8 Class Initialized
INFO - 2023-12-20 20:09:38 --> URI Class Initialized
INFO - 2023-12-20 20:09:38 --> Router Class Initialized
INFO - 2023-12-20 20:09:38 --> Output Class Initialized
INFO - 2023-12-20 20:09:38 --> Security Class Initialized
DEBUG - 2023-12-20 20:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:09:38 --> Input Class Initialized
INFO - 2023-12-20 20:09:38 --> Language Class Initialized
INFO - 2023-12-20 20:09:39 --> Language Class Initialized
INFO - 2023-12-20 20:09:39 --> Config Class Initialized
INFO - 2023-12-20 20:09:39 --> Loader Class Initialized
INFO - 2023-12-20 20:09:39 --> Helper loaded: url_helper
INFO - 2023-12-20 20:09:39 --> Helper loaded: file_helper
INFO - 2023-12-20 20:09:39 --> Helper loaded: form_helper
INFO - 2023-12-20 20:09:39 --> Helper loaded: my_helper
INFO - 2023-12-20 20:09:39 --> Database Driver Class Initialized
INFO - 2023-12-20 20:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:09:39 --> Controller Class Initialized
DEBUG - 2023-12-20 20:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:09:40 --> Config Class Initialized
INFO - 2023-12-20 20:09:40 --> Hooks Class Initialized
DEBUG - 2023-12-20 20:09:40 --> UTF-8 Support Enabled
INFO - 2023-12-20 20:09:40 --> Utf8 Class Initialized
INFO - 2023-12-20 20:09:40 --> URI Class Initialized
INFO - 2023-12-20 20:09:40 --> Router Class Initialized
INFO - 2023-12-20 20:09:40 --> Output Class Initialized
INFO - 2023-12-20 20:09:40 --> Security Class Initialized
DEBUG - 2023-12-20 20:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-20 20:09:40 --> Input Class Initialized
INFO - 2023-12-20 20:09:40 --> Language Class Initialized
INFO - 2023-12-20 20:09:40 --> Language Class Initialized
INFO - 2023-12-20 20:09:40 --> Config Class Initialized
INFO - 2023-12-20 20:09:40 --> Loader Class Initialized
INFO - 2023-12-20 20:09:40 --> Helper loaded: url_helper
INFO - 2023-12-20 20:09:40 --> Helper loaded: file_helper
INFO - 2023-12-20 20:09:40 --> Helper loaded: form_helper
INFO - 2023-12-20 20:09:40 --> Helper loaded: my_helper
INFO - 2023-12-20 20:09:40 --> Database Driver Class Initialized
INFO - 2023-12-20 20:09:52 --> Final output sent to browser
DEBUG - 2023-12-20 20:09:52 --> Total execution time: 13.2611
INFO - 2023-12-20 20:09:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-20 20:09:52 --> Controller Class Initialized
DEBUG - 2023-12-20 20:09:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-20 20:10:14 --> Final output sent to browser
DEBUG - 2023-12-20 20:10:14 --> Total execution time: 33.7469
