<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-08-21 08:11:07 --> Config Class Initialized
INFO - 2023-08-21 08:11:07 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:07 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:07 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:07 --> URI Class Initialized
DEBUG - 2023-08-21 08:11:07 --> No URI present. Default controller set.
INFO - 2023-08-21 08:11:07 --> Router Class Initialized
INFO - 2023-08-21 08:11:07 --> Output Class Initialized
INFO - 2023-08-21 08:11:07 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:07 --> Input Class Initialized
INFO - 2023-08-21 08:11:07 --> Language Class Initialized
INFO - 2023-08-21 08:11:07 --> Language Class Initialized
INFO - 2023-08-21 08:11:07 --> Config Class Initialized
INFO - 2023-08-21 08:11:07 --> Loader Class Initialized
INFO - 2023-08-21 08:11:07 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: my_helper
INFO - 2023-08-21 08:11:07 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:07 --> Controller Class Initialized
INFO - 2023-08-21 08:11:07 --> Config Class Initialized
INFO - 2023-08-21 08:11:07 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:07 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:07 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:07 --> URI Class Initialized
INFO - 2023-08-21 08:11:07 --> Router Class Initialized
INFO - 2023-08-21 08:11:07 --> Output Class Initialized
INFO - 2023-08-21 08:11:07 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:07 --> Input Class Initialized
INFO - 2023-08-21 08:11:07 --> Language Class Initialized
INFO - 2023-08-21 08:11:07 --> Language Class Initialized
INFO - 2023-08-21 08:11:07 --> Config Class Initialized
INFO - 2023-08-21 08:11:07 --> Loader Class Initialized
INFO - 2023-08-21 08:11:07 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:07 --> Helper loaded: my_helper
INFO - 2023-08-21 08:11:07 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:07 --> Controller Class Initialized
DEBUG - 2023-08-21 08:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-21 08:11:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-21 08:11:07 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:07 --> Total execution time: 0.0946
INFO - 2023-08-21 08:11:19 --> Config Class Initialized
INFO - 2023-08-21 08:11:19 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:19 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:19 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:19 --> URI Class Initialized
INFO - 2023-08-21 08:11:19 --> Router Class Initialized
INFO - 2023-08-21 08:11:19 --> Output Class Initialized
INFO - 2023-08-21 08:11:19 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:19 --> Input Class Initialized
INFO - 2023-08-21 08:11:19 --> Language Class Initialized
INFO - 2023-08-21 08:11:19 --> Language Class Initialized
INFO - 2023-08-21 08:11:19 --> Config Class Initialized
INFO - 2023-08-21 08:11:19 --> Loader Class Initialized
INFO - 2023-08-21 08:11:19 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:19 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:19 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:19 --> Helper loaded: my_helper
INFO - 2023-08-21 08:11:19 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:19 --> Controller Class Initialized
INFO - 2023-08-21 08:11:19 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:19 --> Total execution time: 0.0604
INFO - 2023-08-21 08:11:36 --> Config Class Initialized
INFO - 2023-08-21 08:11:36 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:36 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:36 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:36 --> URI Class Initialized
INFO - 2023-08-21 08:11:36 --> Router Class Initialized
INFO - 2023-08-21 08:11:36 --> Output Class Initialized
INFO - 2023-08-21 08:11:36 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:36 --> Input Class Initialized
INFO - 2023-08-21 08:11:36 --> Language Class Initialized
INFO - 2023-08-21 08:11:36 --> Language Class Initialized
INFO - 2023-08-21 08:11:36 --> Config Class Initialized
INFO - 2023-08-21 08:11:36 --> Loader Class Initialized
INFO - 2023-08-21 08:11:36 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:36 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:36 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:36 --> Helper loaded: my_helper
INFO - 2023-08-21 08:11:36 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:36 --> Controller Class Initialized
INFO - 2023-08-21 08:11:36 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:36 --> Total execution time: 0.0373
INFO - 2023-08-21 08:11:46 --> Config Class Initialized
INFO - 2023-08-21 08:11:46 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:11:46 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:11:46 --> Utf8 Class Initialized
INFO - 2023-08-21 08:11:46 --> URI Class Initialized
INFO - 2023-08-21 08:11:46 --> Router Class Initialized
INFO - 2023-08-21 08:11:46 --> Output Class Initialized
INFO - 2023-08-21 08:11:46 --> Security Class Initialized
DEBUG - 2023-08-21 08:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:11:46 --> Input Class Initialized
INFO - 2023-08-21 08:11:46 --> Language Class Initialized
INFO - 2023-08-21 08:11:46 --> Language Class Initialized
INFO - 2023-08-21 08:11:46 --> Config Class Initialized
INFO - 2023-08-21 08:11:46 --> Loader Class Initialized
INFO - 2023-08-21 08:11:46 --> Helper loaded: url_helper
INFO - 2023-08-21 08:11:46 --> Helper loaded: file_helper
INFO - 2023-08-21 08:11:46 --> Helper loaded: form_helper
INFO - 2023-08-21 08:11:46 --> Helper loaded: my_helper
INFO - 2023-08-21 08:11:46 --> Database Driver Class Initialized
INFO - 2023-08-21 08:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:11:46 --> Controller Class Initialized
INFO - 2023-08-21 08:11:46 --> Final output sent to browser
DEBUG - 2023-08-21 08:11:46 --> Total execution time: 0.0444
INFO - 2023-08-21 08:12:06 --> Config Class Initialized
INFO - 2023-08-21 08:12:06 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:06 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:06 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:06 --> URI Class Initialized
INFO - 2023-08-21 08:12:06 --> Router Class Initialized
INFO - 2023-08-21 08:12:06 --> Output Class Initialized
INFO - 2023-08-21 08:12:06 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:06 --> Input Class Initialized
INFO - 2023-08-21 08:12:06 --> Language Class Initialized
INFO - 2023-08-21 08:12:06 --> Language Class Initialized
INFO - 2023-08-21 08:12:06 --> Config Class Initialized
INFO - 2023-08-21 08:12:06 --> Loader Class Initialized
INFO - 2023-08-21 08:12:06 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:06 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:06 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:06 --> Helper loaded: my_helper
INFO - 2023-08-21 08:12:06 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:06 --> Controller Class Initialized
INFO - 2023-08-21 08:12:06 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:06 --> Total execution time: 0.0370
INFO - 2023-08-21 08:12:15 --> Config Class Initialized
INFO - 2023-08-21 08:12:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:15 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:15 --> URI Class Initialized
DEBUG - 2023-08-21 08:12:15 --> No URI present. Default controller set.
INFO - 2023-08-21 08:12:15 --> Router Class Initialized
INFO - 2023-08-21 08:12:15 --> Output Class Initialized
INFO - 2023-08-21 08:12:15 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:15 --> Input Class Initialized
INFO - 2023-08-21 08:12:15 --> Language Class Initialized
INFO - 2023-08-21 08:12:15 --> Language Class Initialized
INFO - 2023-08-21 08:12:15 --> Config Class Initialized
INFO - 2023-08-21 08:12:15 --> Loader Class Initialized
INFO - 2023-08-21 08:12:15 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: my_helper
INFO - 2023-08-21 08:12:15 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:15 --> Controller Class Initialized
INFO - 2023-08-21 08:12:15 --> Config Class Initialized
INFO - 2023-08-21 08:12:15 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:15 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:15 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:15 --> URI Class Initialized
INFO - 2023-08-21 08:12:15 --> Router Class Initialized
INFO - 2023-08-21 08:12:15 --> Output Class Initialized
INFO - 2023-08-21 08:12:15 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:15 --> Input Class Initialized
INFO - 2023-08-21 08:12:15 --> Language Class Initialized
INFO - 2023-08-21 08:12:15 --> Language Class Initialized
INFO - 2023-08-21 08:12:15 --> Config Class Initialized
INFO - 2023-08-21 08:12:15 --> Loader Class Initialized
INFO - 2023-08-21 08:12:15 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:15 --> Helper loaded: my_helper
INFO - 2023-08-21 08:12:15 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:15 --> Controller Class Initialized
DEBUG - 2023-08-21 08:12:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-21 08:12:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-21 08:12:15 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:15 --> Total execution time: 0.0368
INFO - 2023-08-21 08:12:28 --> Config Class Initialized
INFO - 2023-08-21 08:12:28 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:12:28 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:12:28 --> Utf8 Class Initialized
INFO - 2023-08-21 08:12:28 --> URI Class Initialized
INFO - 2023-08-21 08:12:28 --> Router Class Initialized
INFO - 2023-08-21 08:12:28 --> Output Class Initialized
INFO - 2023-08-21 08:12:28 --> Security Class Initialized
DEBUG - 2023-08-21 08:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:12:28 --> Input Class Initialized
INFO - 2023-08-21 08:12:28 --> Language Class Initialized
INFO - 2023-08-21 08:12:28 --> Language Class Initialized
INFO - 2023-08-21 08:12:28 --> Config Class Initialized
INFO - 2023-08-21 08:12:28 --> Loader Class Initialized
INFO - 2023-08-21 08:12:28 --> Helper loaded: url_helper
INFO - 2023-08-21 08:12:28 --> Helper loaded: file_helper
INFO - 2023-08-21 08:12:28 --> Helper loaded: form_helper
INFO - 2023-08-21 08:12:28 --> Helper loaded: my_helper
INFO - 2023-08-21 08:12:28 --> Database Driver Class Initialized
INFO - 2023-08-21 08:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:12:28 --> Controller Class Initialized
INFO - 2023-08-21 08:12:28 --> Final output sent to browser
DEBUG - 2023-08-21 08:12:28 --> Total execution time: 0.0408
INFO - 2023-08-21 08:46:41 --> Config Class Initialized
INFO - 2023-08-21 08:46:41 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:46:41 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:46:41 --> Utf8 Class Initialized
INFO - 2023-08-21 08:46:41 --> URI Class Initialized
INFO - 2023-08-21 08:46:41 --> Router Class Initialized
INFO - 2023-08-21 08:46:41 --> Output Class Initialized
INFO - 2023-08-21 08:46:41 --> Security Class Initialized
DEBUG - 2023-08-21 08:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:46:41 --> Input Class Initialized
INFO - 2023-08-21 08:46:41 --> Language Class Initialized
INFO - 2023-08-21 08:46:41 --> Language Class Initialized
INFO - 2023-08-21 08:46:41 --> Config Class Initialized
INFO - 2023-08-21 08:46:41 --> Loader Class Initialized
INFO - 2023-08-21 08:46:41 --> Helper loaded: url_helper
INFO - 2023-08-21 08:46:41 --> Helper loaded: file_helper
INFO - 2023-08-21 08:46:41 --> Helper loaded: form_helper
INFO - 2023-08-21 08:46:41 --> Helper loaded: my_helper
INFO - 2023-08-21 08:46:41 --> Database Driver Class Initialized
INFO - 2023-08-21 08:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:46:42 --> Controller Class Initialized
INFO - 2023-08-21 08:46:42 --> Config Class Initialized
INFO - 2023-08-21 08:46:42 --> Hooks Class Initialized
DEBUG - 2023-08-21 08:46:42 --> UTF-8 Support Enabled
INFO - 2023-08-21 08:46:42 --> Utf8 Class Initialized
INFO - 2023-08-21 08:46:42 --> URI Class Initialized
INFO - 2023-08-21 08:46:42 --> Router Class Initialized
INFO - 2023-08-21 08:46:42 --> Output Class Initialized
INFO - 2023-08-21 08:46:42 --> Security Class Initialized
DEBUG - 2023-08-21 08:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 08:46:42 --> Input Class Initialized
INFO - 2023-08-21 08:46:42 --> Language Class Initialized
INFO - 2023-08-21 08:46:42 --> Language Class Initialized
INFO - 2023-08-21 08:46:42 --> Config Class Initialized
INFO - 2023-08-21 08:46:42 --> Loader Class Initialized
INFO - 2023-08-21 08:46:42 --> Helper loaded: url_helper
INFO - 2023-08-21 08:46:42 --> Helper loaded: file_helper
INFO - 2023-08-21 08:46:42 --> Helper loaded: form_helper
INFO - 2023-08-21 08:46:42 --> Helper loaded: my_helper
INFO - 2023-08-21 08:46:42 --> Database Driver Class Initialized
INFO - 2023-08-21 08:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 08:46:42 --> Controller Class Initialized
DEBUG - 2023-08-21 08:46:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-21 08:46:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-21 08:46:42 --> Final output sent to browser
DEBUG - 2023-08-21 08:46:42 --> Total execution time: 0.0293
INFO - 2023-08-21 17:21:39 --> Config Class Initialized
INFO - 2023-08-21 17:21:39 --> Hooks Class Initialized
DEBUG - 2023-08-21 17:21:39 --> UTF-8 Support Enabled
INFO - 2023-08-21 17:21:39 --> Utf8 Class Initialized
INFO - 2023-08-21 17:21:39 --> URI Class Initialized
INFO - 2023-08-21 17:21:39 --> Router Class Initialized
INFO - 2023-08-21 17:21:39 --> Output Class Initialized
INFO - 2023-08-21 17:21:39 --> Security Class Initialized
DEBUG - 2023-08-21 17:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-08-21 17:21:39 --> Input Class Initialized
INFO - 2023-08-21 17:21:39 --> Language Class Initialized
INFO - 2023-08-21 17:21:39 --> Language Class Initialized
INFO - 2023-08-21 17:21:39 --> Config Class Initialized
INFO - 2023-08-21 17:21:39 --> Loader Class Initialized
INFO - 2023-08-21 17:21:39 --> Helper loaded: url_helper
INFO - 2023-08-21 17:21:39 --> Helper loaded: file_helper
INFO - 2023-08-21 17:21:39 --> Helper loaded: form_helper
INFO - 2023-08-21 17:21:39 --> Helper loaded: my_helper
INFO - 2023-08-21 17:21:39 --> Database Driver Class Initialized
INFO - 2023-08-21 17:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-08-21 17:21:39 --> Controller Class Initialized
DEBUG - 2023-08-21 17:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-08-21 17:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-08-21 17:21:39 --> Final output sent to browser
DEBUG - 2023-08-21 17:21:39 --> Total execution time: 0.0749
