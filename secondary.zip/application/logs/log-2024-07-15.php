<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-07-15 14:33:31 --> Config Class Initialized
INFO - 2024-07-15 14:33:31 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:31 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:31 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:31 --> URI Class Initialized
INFO - 2024-07-15 14:33:31 --> Router Class Initialized
INFO - 2024-07-15 14:33:31 --> Output Class Initialized
INFO - 2024-07-15 14:33:31 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:31 --> Input Class Initialized
INFO - 2024-07-15 14:33:31 --> Language Class Initialized
INFO - 2024-07-15 14:33:31 --> Language Class Initialized
INFO - 2024-07-15 14:33:31 --> Config Class Initialized
INFO - 2024-07-15 14:33:31 --> Loader Class Initialized
INFO - 2024-07-15 14:33:31 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:31 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:31 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:31 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:31 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:31 --> Controller Class Initialized
DEBUG - 2024-07-15 14:33:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-07-15 14:33:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:33:31 --> Final output sent to browser
DEBUG - 2024-07-15 14:33:31 --> Total execution time: 0.0625
INFO - 2024-07-15 14:33:34 --> Config Class Initialized
INFO - 2024-07-15 14:33:34 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:34 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:34 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:34 --> URI Class Initialized
INFO - 2024-07-15 14:33:34 --> Router Class Initialized
INFO - 2024-07-15 14:33:34 --> Output Class Initialized
INFO - 2024-07-15 14:33:34 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:34 --> Input Class Initialized
INFO - 2024-07-15 14:33:34 --> Language Class Initialized
INFO - 2024-07-15 14:33:34 --> Language Class Initialized
INFO - 2024-07-15 14:33:34 --> Config Class Initialized
INFO - 2024-07-15 14:33:34 --> Loader Class Initialized
INFO - 2024-07-15 14:33:34 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:34 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:34 --> Controller Class Initialized
INFO - 2024-07-15 14:33:34 --> Helper loaded: cookie_helper
INFO - 2024-07-15 14:33:34 --> Final output sent to browser
DEBUG - 2024-07-15 14:33:34 --> Total execution time: 0.0341
INFO - 2024-07-15 14:33:34 --> Config Class Initialized
INFO - 2024-07-15 14:33:34 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:34 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:34 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:34 --> URI Class Initialized
INFO - 2024-07-15 14:33:34 --> Router Class Initialized
INFO - 2024-07-15 14:33:34 --> Output Class Initialized
INFO - 2024-07-15 14:33:34 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:34 --> Input Class Initialized
INFO - 2024-07-15 14:33:34 --> Language Class Initialized
INFO - 2024-07-15 14:33:34 --> Language Class Initialized
INFO - 2024-07-15 14:33:34 --> Config Class Initialized
INFO - 2024-07-15 14:33:34 --> Loader Class Initialized
INFO - 2024-07-15 14:33:34 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:34 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:34 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:34 --> Controller Class Initialized
DEBUG - 2024-07-15 14:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-07-15 14:33:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:33:34 --> Final output sent to browser
DEBUG - 2024-07-15 14:33:34 --> Total execution time: 0.0359
INFO - 2024-07-15 14:33:41 --> Config Class Initialized
INFO - 2024-07-15 14:33:41 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:41 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:41 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:41 --> URI Class Initialized
INFO - 2024-07-15 14:33:41 --> Router Class Initialized
INFO - 2024-07-15 14:33:41 --> Output Class Initialized
INFO - 2024-07-15 14:33:41 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:41 --> Input Class Initialized
INFO - 2024-07-15 14:33:41 --> Language Class Initialized
INFO - 2024-07-15 14:33:41 --> Language Class Initialized
INFO - 2024-07-15 14:33:41 --> Config Class Initialized
INFO - 2024-07-15 14:33:41 --> Loader Class Initialized
INFO - 2024-07-15 14:33:41 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:41 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:41 --> Controller Class Initialized
DEBUG - 2024-07-15 14:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-07-15 14:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:33:41 --> Final output sent to browser
DEBUG - 2024-07-15 14:33:41 --> Total execution time: 0.0354
INFO - 2024-07-15 14:33:41 --> Config Class Initialized
INFO - 2024-07-15 14:33:41 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:41 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:41 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:41 --> URI Class Initialized
INFO - 2024-07-15 14:33:41 --> Router Class Initialized
INFO - 2024-07-15 14:33:41 --> Output Class Initialized
INFO - 2024-07-15 14:33:41 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:41 --> Input Class Initialized
INFO - 2024-07-15 14:33:41 --> Language Class Initialized
ERROR - 2024-07-15 14:33:41 --> 404 Page Not Found: /index
INFO - 2024-07-15 14:33:41 --> Config Class Initialized
INFO - 2024-07-15 14:33:41 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:41 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:41 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:41 --> URI Class Initialized
INFO - 2024-07-15 14:33:41 --> Router Class Initialized
INFO - 2024-07-15 14:33:41 --> Output Class Initialized
INFO - 2024-07-15 14:33:41 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:41 --> Input Class Initialized
INFO - 2024-07-15 14:33:41 --> Language Class Initialized
INFO - 2024-07-15 14:33:41 --> Language Class Initialized
INFO - 2024-07-15 14:33:41 --> Config Class Initialized
INFO - 2024-07-15 14:33:41 --> Loader Class Initialized
INFO - 2024-07-15 14:33:41 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:41 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:41 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:41 --> Controller Class Initialized
INFO - 2024-07-15 14:33:46 --> Config Class Initialized
INFO - 2024-07-15 14:33:46 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:33:46 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:33:46 --> Utf8 Class Initialized
INFO - 2024-07-15 14:33:46 --> URI Class Initialized
INFO - 2024-07-15 14:33:46 --> Router Class Initialized
INFO - 2024-07-15 14:33:46 --> Output Class Initialized
INFO - 2024-07-15 14:33:46 --> Security Class Initialized
DEBUG - 2024-07-15 14:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:33:46 --> Input Class Initialized
INFO - 2024-07-15 14:33:46 --> Language Class Initialized
INFO - 2024-07-15 14:33:46 --> Language Class Initialized
INFO - 2024-07-15 14:33:46 --> Config Class Initialized
INFO - 2024-07-15 14:33:46 --> Loader Class Initialized
INFO - 2024-07-15 14:33:46 --> Helper loaded: url_helper
INFO - 2024-07-15 14:33:46 --> Helper loaded: file_helper
INFO - 2024-07-15 14:33:46 --> Helper loaded: form_helper
INFO - 2024-07-15 14:33:46 --> Helper loaded: my_helper
INFO - 2024-07-15 14:33:46 --> Database Driver Class Initialized
INFO - 2024-07-15 14:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:33:46 --> Controller Class Initialized
DEBUG - 2024-07-15 14:33:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:33:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:33:46 --> Final output sent to browser
DEBUG - 2024-07-15 14:33:46 --> Total execution time: 0.0931
INFO - 2024-07-15 14:34:05 --> Config Class Initialized
INFO - 2024-07-15 14:34:05 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:34:05 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:34:05 --> Utf8 Class Initialized
INFO - 2024-07-15 14:34:05 --> URI Class Initialized
INFO - 2024-07-15 14:34:05 --> Router Class Initialized
INFO - 2024-07-15 14:34:05 --> Output Class Initialized
INFO - 2024-07-15 14:34:05 --> Security Class Initialized
DEBUG - 2024-07-15 14:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:34:05 --> Input Class Initialized
INFO - 2024-07-15 14:34:05 --> Language Class Initialized
INFO - 2024-07-15 14:34:05 --> Language Class Initialized
INFO - 2024-07-15 14:34:05 --> Config Class Initialized
INFO - 2024-07-15 14:34:05 --> Loader Class Initialized
INFO - 2024-07-15 14:34:05 --> Helper loaded: url_helper
INFO - 2024-07-15 14:34:05 --> Helper loaded: file_helper
INFO - 2024-07-15 14:34:05 --> Helper loaded: form_helper
INFO - 2024-07-15 14:34:05 --> Helper loaded: my_helper
INFO - 2024-07-15 14:34:05 --> Database Driver Class Initialized
INFO - 2024-07-15 14:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:34:05 --> Controller Class Initialized
INFO - 2024-07-15 14:34:05 --> Final output sent to browser
DEBUG - 2024-07-15 14:34:05 --> Total execution time: 0.0465
INFO - 2024-07-15 14:34:11 --> Config Class Initialized
INFO - 2024-07-15 14:34:11 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:34:11 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:34:11 --> Utf8 Class Initialized
INFO - 2024-07-15 14:34:11 --> URI Class Initialized
INFO - 2024-07-15 14:34:11 --> Router Class Initialized
INFO - 2024-07-15 14:34:11 --> Output Class Initialized
INFO - 2024-07-15 14:34:11 --> Security Class Initialized
DEBUG - 2024-07-15 14:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:34:11 --> Input Class Initialized
INFO - 2024-07-15 14:34:11 --> Language Class Initialized
INFO - 2024-07-15 14:34:11 --> Language Class Initialized
INFO - 2024-07-15 14:34:11 --> Config Class Initialized
INFO - 2024-07-15 14:34:11 --> Loader Class Initialized
INFO - 2024-07-15 14:34:11 --> Helper loaded: url_helper
INFO - 2024-07-15 14:34:11 --> Helper loaded: file_helper
INFO - 2024-07-15 14:34:11 --> Helper loaded: form_helper
INFO - 2024-07-15 14:34:11 --> Helper loaded: my_helper
INFO - 2024-07-15 14:34:11 --> Database Driver Class Initialized
INFO - 2024-07-15 14:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:34:11 --> Controller Class Initialized
DEBUG - 2024-07-15 14:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:34:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:34:11 --> Final output sent to browser
DEBUG - 2024-07-15 14:34:11 --> Total execution time: 0.0380
INFO - 2024-07-15 14:34:29 --> Config Class Initialized
INFO - 2024-07-15 14:34:29 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:34:29 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:34:29 --> Utf8 Class Initialized
INFO - 2024-07-15 14:34:29 --> URI Class Initialized
INFO - 2024-07-15 14:34:29 --> Router Class Initialized
INFO - 2024-07-15 14:34:29 --> Output Class Initialized
INFO - 2024-07-15 14:34:29 --> Security Class Initialized
DEBUG - 2024-07-15 14:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:34:29 --> Input Class Initialized
INFO - 2024-07-15 14:34:29 --> Language Class Initialized
INFO - 2024-07-15 14:34:29 --> Language Class Initialized
INFO - 2024-07-15 14:34:29 --> Config Class Initialized
INFO - 2024-07-15 14:34:29 --> Loader Class Initialized
INFO - 2024-07-15 14:34:29 --> Helper loaded: url_helper
INFO - 2024-07-15 14:34:29 --> Helper loaded: file_helper
INFO - 2024-07-15 14:34:29 --> Helper loaded: form_helper
INFO - 2024-07-15 14:34:29 --> Helper loaded: my_helper
INFO - 2024-07-15 14:34:29 --> Database Driver Class Initialized
INFO - 2024-07-15 14:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:34:29 --> Controller Class Initialized
INFO - 2024-07-15 14:34:29 --> Final output sent to browser
DEBUG - 2024-07-15 14:34:29 --> Total execution time: 0.0294
INFO - 2024-07-15 14:34:32 --> Config Class Initialized
INFO - 2024-07-15 14:34:32 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:34:32 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:34:32 --> Utf8 Class Initialized
INFO - 2024-07-15 14:34:32 --> URI Class Initialized
INFO - 2024-07-15 14:34:32 --> Router Class Initialized
INFO - 2024-07-15 14:34:32 --> Output Class Initialized
INFO - 2024-07-15 14:34:32 --> Security Class Initialized
DEBUG - 2024-07-15 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:34:32 --> Input Class Initialized
INFO - 2024-07-15 14:34:32 --> Language Class Initialized
INFO - 2024-07-15 14:34:32 --> Language Class Initialized
INFO - 2024-07-15 14:34:32 --> Config Class Initialized
INFO - 2024-07-15 14:34:32 --> Loader Class Initialized
INFO - 2024-07-15 14:34:32 --> Helper loaded: url_helper
INFO - 2024-07-15 14:34:32 --> Helper loaded: file_helper
INFO - 2024-07-15 14:34:32 --> Helper loaded: form_helper
INFO - 2024-07-15 14:34:32 --> Helper loaded: my_helper
INFO - 2024-07-15 14:34:32 --> Database Driver Class Initialized
INFO - 2024-07-15 14:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:34:32 --> Controller Class Initialized
DEBUG - 2024-07-15 14:34:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:34:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:34:32 --> Final output sent to browser
DEBUG - 2024-07-15 14:34:32 --> Total execution time: 0.0330
INFO - 2024-07-15 14:36:28 --> Config Class Initialized
INFO - 2024-07-15 14:36:28 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:36:28 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:36:28 --> Utf8 Class Initialized
INFO - 2024-07-15 14:36:28 --> URI Class Initialized
INFO - 2024-07-15 14:36:28 --> Router Class Initialized
INFO - 2024-07-15 14:36:28 --> Output Class Initialized
INFO - 2024-07-15 14:36:28 --> Security Class Initialized
DEBUG - 2024-07-15 14:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:36:28 --> Input Class Initialized
INFO - 2024-07-15 14:36:28 --> Language Class Initialized
INFO - 2024-07-15 14:36:28 --> Language Class Initialized
INFO - 2024-07-15 14:36:28 --> Config Class Initialized
INFO - 2024-07-15 14:36:28 --> Loader Class Initialized
INFO - 2024-07-15 14:36:28 --> Helper loaded: url_helper
INFO - 2024-07-15 14:36:28 --> Helper loaded: file_helper
INFO - 2024-07-15 14:36:28 --> Helper loaded: form_helper
INFO - 2024-07-15 14:36:28 --> Helper loaded: my_helper
INFO - 2024-07-15 14:36:28 --> Database Driver Class Initialized
INFO - 2024-07-15 14:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:36:28 --> Controller Class Initialized
ERROR - 2024-07-15 14:36:28 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:36:28 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-15 14:36:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:36:28 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-15 14:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-15 14:36:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:36:28 --> Final output sent to browser
DEBUG - 2024-07-15 14:36:28 --> Total execution time: 0.0410
INFO - 2024-07-15 14:37:10 --> Config Class Initialized
INFO - 2024-07-15 14:37:10 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:10 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:10 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:10 --> URI Class Initialized
INFO - 2024-07-15 14:37:10 --> Router Class Initialized
INFO - 2024-07-15 14:37:10 --> Output Class Initialized
INFO - 2024-07-15 14:37:10 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:10 --> Input Class Initialized
INFO - 2024-07-15 14:37:10 --> Language Class Initialized
INFO - 2024-07-15 14:37:10 --> Language Class Initialized
INFO - 2024-07-15 14:37:10 --> Config Class Initialized
INFO - 2024-07-15 14:37:10 --> Loader Class Initialized
INFO - 2024-07-15 14:37:10 --> Helper loaded: url_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: file_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: form_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: my_helper
INFO - 2024-07-15 14:37:10 --> Database Driver Class Initialized
INFO - 2024-07-15 14:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:37:10 --> Controller Class Initialized
INFO - 2024-07-15 14:37:10 --> Config Class Initialized
INFO - 2024-07-15 14:37:10 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:10 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:10 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:10 --> URI Class Initialized
INFO - 2024-07-15 14:37:10 --> Router Class Initialized
INFO - 2024-07-15 14:37:10 --> Output Class Initialized
INFO - 2024-07-15 14:37:10 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:10 --> Input Class Initialized
INFO - 2024-07-15 14:37:10 --> Language Class Initialized
INFO - 2024-07-15 14:37:10 --> Language Class Initialized
INFO - 2024-07-15 14:37:10 --> Config Class Initialized
INFO - 2024-07-15 14:37:10 --> Loader Class Initialized
INFO - 2024-07-15 14:37:10 --> Helper loaded: url_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: file_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: form_helper
INFO - 2024-07-15 14:37:10 --> Helper loaded: my_helper
INFO - 2024-07-15 14:37:10 --> Database Driver Class Initialized
INFO - 2024-07-15 14:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:37:10 --> Controller Class Initialized
DEBUG - 2024-07-15 14:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:37:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:37:10 --> Final output sent to browser
DEBUG - 2024-07-15 14:37:10 --> Total execution time: 0.0340
INFO - 2024-07-15 14:37:22 --> Config Class Initialized
INFO - 2024-07-15 14:37:22 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:22 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:22 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:22 --> URI Class Initialized
INFO - 2024-07-15 14:37:22 --> Router Class Initialized
INFO - 2024-07-15 14:37:22 --> Output Class Initialized
INFO - 2024-07-15 14:37:22 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:22 --> Input Class Initialized
INFO - 2024-07-15 14:37:22 --> Language Class Initialized
INFO - 2024-07-15 14:37:22 --> Language Class Initialized
INFO - 2024-07-15 14:37:22 --> Config Class Initialized
INFO - 2024-07-15 14:37:22 --> Loader Class Initialized
INFO - 2024-07-15 14:37:22 --> Helper loaded: url_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: file_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: form_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: my_helper
INFO - 2024-07-15 14:37:22 --> Database Driver Class Initialized
INFO - 2024-07-15 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:37:22 --> Controller Class Initialized
DEBUG - 2024-07-15 14:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-15 14:37:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:37:22 --> Final output sent to browser
DEBUG - 2024-07-15 14:37:22 --> Total execution time: 0.0268
INFO - 2024-07-15 14:37:22 --> Config Class Initialized
INFO - 2024-07-15 14:37:22 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:22 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:22 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:22 --> URI Class Initialized
INFO - 2024-07-15 14:37:22 --> Router Class Initialized
INFO - 2024-07-15 14:37:22 --> Output Class Initialized
INFO - 2024-07-15 14:37:22 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:22 --> Input Class Initialized
INFO - 2024-07-15 14:37:22 --> Language Class Initialized
ERROR - 2024-07-15 14:37:22 --> 404 Page Not Found: /index
INFO - 2024-07-15 14:37:22 --> Config Class Initialized
INFO - 2024-07-15 14:37:22 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:22 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:22 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:22 --> URI Class Initialized
INFO - 2024-07-15 14:37:22 --> Router Class Initialized
INFO - 2024-07-15 14:37:22 --> Output Class Initialized
INFO - 2024-07-15 14:37:22 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:22 --> Input Class Initialized
INFO - 2024-07-15 14:37:22 --> Language Class Initialized
INFO - 2024-07-15 14:37:22 --> Language Class Initialized
INFO - 2024-07-15 14:37:22 --> Config Class Initialized
INFO - 2024-07-15 14:37:22 --> Loader Class Initialized
INFO - 2024-07-15 14:37:22 --> Helper loaded: url_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: file_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: form_helper
INFO - 2024-07-15 14:37:22 --> Helper loaded: my_helper
INFO - 2024-07-15 14:37:22 --> Database Driver Class Initialized
INFO - 2024-07-15 14:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:37:22 --> Controller Class Initialized
INFO - 2024-07-15 14:37:23 --> Config Class Initialized
INFO - 2024-07-15 14:37:23 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:37:23 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:37:23 --> Utf8 Class Initialized
INFO - 2024-07-15 14:37:23 --> URI Class Initialized
INFO - 2024-07-15 14:37:23 --> Router Class Initialized
INFO - 2024-07-15 14:37:23 --> Output Class Initialized
INFO - 2024-07-15 14:37:23 --> Security Class Initialized
DEBUG - 2024-07-15 14:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:37:23 --> Input Class Initialized
INFO - 2024-07-15 14:37:23 --> Language Class Initialized
INFO - 2024-07-15 14:37:23 --> Language Class Initialized
INFO - 2024-07-15 14:37:23 --> Config Class Initialized
INFO - 2024-07-15 14:37:23 --> Loader Class Initialized
INFO - 2024-07-15 14:37:23 --> Helper loaded: url_helper
INFO - 2024-07-15 14:37:23 --> Helper loaded: file_helper
INFO - 2024-07-15 14:37:23 --> Helper loaded: form_helper
INFO - 2024-07-15 14:37:23 --> Helper loaded: my_helper
INFO - 2024-07-15 14:37:23 --> Database Driver Class Initialized
INFO - 2024-07-15 14:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:37:23 --> Controller Class Initialized
ERROR - 2024-07-15 14:37:23 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2024-07-15 14:37:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2024-07-15 14:37:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:37:23 --> Final output sent to browser
DEBUG - 2024-07-15 14:37:23 --> Total execution time: 0.0355
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:41:24 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:41:24 --> Utf8 Class Initialized
INFO - 2024-07-15 14:41:24 --> URI Class Initialized
INFO - 2024-07-15 14:41:24 --> Router Class Initialized
INFO - 2024-07-15 14:41:24 --> Output Class Initialized
INFO - 2024-07-15 14:41:24 --> Security Class Initialized
DEBUG - 2024-07-15 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:41:24 --> Input Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Loader Class Initialized
INFO - 2024-07-15 14:41:24 --> Helper loaded: url_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: file_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: form_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: my_helper
INFO - 2024-07-15 14:41:24 --> Database Driver Class Initialized
INFO - 2024-07-15 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:41:24 --> Controller Class Initialized
INFO - 2024-07-15 14:41:24 --> Upload Class Initialized
INFO - 2024-07-15 14:41:24 --> Language file loaded: language/english/upload_lang.php
ERROR - 2024-07-15 14:41:24 --> The upload path does not appear to be valid.
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:41:24 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:41:24 --> Utf8 Class Initialized
INFO - 2024-07-15 14:41:24 --> URI Class Initialized
INFO - 2024-07-15 14:41:24 --> Router Class Initialized
INFO - 2024-07-15 14:41:24 --> Output Class Initialized
INFO - 2024-07-15 14:41:24 --> Security Class Initialized
DEBUG - 2024-07-15 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:41:24 --> Input Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Loader Class Initialized
INFO - 2024-07-15 14:41:24 --> Helper loaded: url_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: file_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: form_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: my_helper
INFO - 2024-07-15 14:41:24 --> Database Driver Class Initialized
INFO - 2024-07-15 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:41:24 --> Controller Class Initialized
DEBUG - 2024-07-15 14:41:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-07-15 14:41:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:41:24 --> Final output sent to browser
DEBUG - 2024-07-15 14:41:24 --> Total execution time: 0.0577
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:41:24 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:41:24 --> Utf8 Class Initialized
INFO - 2024-07-15 14:41:24 --> URI Class Initialized
INFO - 2024-07-15 14:41:24 --> Router Class Initialized
INFO - 2024-07-15 14:41:24 --> Output Class Initialized
INFO - 2024-07-15 14:41:24 --> Security Class Initialized
DEBUG - 2024-07-15 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:41:24 --> Input Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
ERROR - 2024-07-15 14:41:24 --> 404 Page Not Found: /index
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:41:24 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:41:24 --> Utf8 Class Initialized
INFO - 2024-07-15 14:41:24 --> URI Class Initialized
INFO - 2024-07-15 14:41:24 --> Router Class Initialized
INFO - 2024-07-15 14:41:24 --> Output Class Initialized
INFO - 2024-07-15 14:41:24 --> Security Class Initialized
DEBUG - 2024-07-15 14:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:41:24 --> Input Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Language Class Initialized
INFO - 2024-07-15 14:41:24 --> Config Class Initialized
INFO - 2024-07-15 14:41:24 --> Loader Class Initialized
INFO - 2024-07-15 14:41:24 --> Helper loaded: url_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: file_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: form_helper
INFO - 2024-07-15 14:41:24 --> Helper loaded: my_helper
INFO - 2024-07-15 14:41:24 --> Database Driver Class Initialized
INFO - 2024-07-15 14:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:41:24 --> Controller Class Initialized
INFO - 2024-07-15 14:41:32 --> Config Class Initialized
INFO - 2024-07-15 14:41:32 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:41:32 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:41:32 --> Utf8 Class Initialized
INFO - 2024-07-15 14:41:32 --> URI Class Initialized
INFO - 2024-07-15 14:41:32 --> Router Class Initialized
INFO - 2024-07-15 14:41:32 --> Output Class Initialized
INFO - 2024-07-15 14:41:32 --> Security Class Initialized
DEBUG - 2024-07-15 14:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:41:32 --> Input Class Initialized
INFO - 2024-07-15 14:41:32 --> Language Class Initialized
INFO - 2024-07-15 14:41:32 --> Language Class Initialized
INFO - 2024-07-15 14:41:32 --> Config Class Initialized
INFO - 2024-07-15 14:41:32 --> Loader Class Initialized
INFO - 2024-07-15 14:41:32 --> Helper loaded: url_helper
INFO - 2024-07-15 14:41:32 --> Helper loaded: file_helper
INFO - 2024-07-15 14:41:32 --> Helper loaded: form_helper
INFO - 2024-07-15 14:41:32 --> Helper loaded: my_helper
INFO - 2024-07-15 14:41:32 --> Database Driver Class Initialized
INFO - 2024-07-15 14:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:41:32 --> Controller Class Initialized
DEBUG - 2024-07-15 14:41:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:41:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:41:32 --> Final output sent to browser
DEBUG - 2024-07-15 14:41:32 --> Total execution time: 0.0410
INFO - 2024-07-15 14:42:00 --> Config Class Initialized
INFO - 2024-07-15 14:42:00 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:00 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:00 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:00 --> URI Class Initialized
INFO - 2024-07-15 14:42:00 --> Router Class Initialized
INFO - 2024-07-15 14:42:00 --> Output Class Initialized
INFO - 2024-07-15 14:42:00 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:00 --> Input Class Initialized
INFO - 2024-07-15 14:42:00 --> Language Class Initialized
INFO - 2024-07-15 14:42:00 --> Language Class Initialized
INFO - 2024-07-15 14:42:00 --> Config Class Initialized
INFO - 2024-07-15 14:42:00 --> Loader Class Initialized
INFO - 2024-07-15 14:42:00 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:00 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:00 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:00 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:00 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:00 --> Controller Class Initialized
INFO - 2024-07-15 14:42:00 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:00 --> Total execution time: 0.0783
INFO - 2024-07-15 14:42:02 --> Config Class Initialized
INFO - 2024-07-15 14:42:02 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:02 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:02 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:02 --> URI Class Initialized
INFO - 2024-07-15 14:42:02 --> Router Class Initialized
INFO - 2024-07-15 14:42:02 --> Output Class Initialized
INFO - 2024-07-15 14:42:02 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:02 --> Input Class Initialized
INFO - 2024-07-15 14:42:02 --> Language Class Initialized
INFO - 2024-07-15 14:42:02 --> Language Class Initialized
INFO - 2024-07-15 14:42:02 --> Config Class Initialized
INFO - 2024-07-15 14:42:02 --> Loader Class Initialized
INFO - 2024-07-15 14:42:02 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:02 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:02 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:02 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:02 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:02 --> Controller Class Initialized
DEBUG - 2024-07-15 14:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:42:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:42:02 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:02 --> Total execution time: 0.0430
INFO - 2024-07-15 14:42:09 --> Config Class Initialized
INFO - 2024-07-15 14:42:09 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:09 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:09 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:09 --> URI Class Initialized
INFO - 2024-07-15 14:42:09 --> Router Class Initialized
INFO - 2024-07-15 14:42:09 --> Output Class Initialized
INFO - 2024-07-15 14:42:09 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:09 --> Input Class Initialized
INFO - 2024-07-15 14:42:09 --> Language Class Initialized
INFO - 2024-07-15 14:42:09 --> Language Class Initialized
INFO - 2024-07-15 14:42:09 --> Config Class Initialized
INFO - 2024-07-15 14:42:09 --> Loader Class Initialized
INFO - 2024-07-15 14:42:09 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:09 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:09 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:09 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:09 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:09 --> Controller Class Initialized
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:09 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-15 14:42:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-15 14:42:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:42:09 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:09 --> Total execution time: 0.0475
INFO - 2024-07-15 14:42:18 --> Config Class Initialized
INFO - 2024-07-15 14:42:18 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:18 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:18 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:18 --> URI Class Initialized
INFO - 2024-07-15 14:42:18 --> Router Class Initialized
INFO - 2024-07-15 14:42:18 --> Output Class Initialized
INFO - 2024-07-15 14:42:18 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:18 --> Input Class Initialized
INFO - 2024-07-15 14:42:18 --> Language Class Initialized
INFO - 2024-07-15 14:42:18 --> Language Class Initialized
INFO - 2024-07-15 14:42:18 --> Config Class Initialized
INFO - 2024-07-15 14:42:18 --> Loader Class Initialized
INFO - 2024-07-15 14:42:18 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:18 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:18 --> Controller Class Initialized
INFO - 2024-07-15 14:42:18 --> Config Class Initialized
INFO - 2024-07-15 14:42:18 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:18 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:18 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:18 --> URI Class Initialized
INFO - 2024-07-15 14:42:18 --> Router Class Initialized
INFO - 2024-07-15 14:42:18 --> Output Class Initialized
INFO - 2024-07-15 14:42:18 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:18 --> Input Class Initialized
INFO - 2024-07-15 14:42:18 --> Language Class Initialized
INFO - 2024-07-15 14:42:18 --> Language Class Initialized
INFO - 2024-07-15 14:42:18 --> Config Class Initialized
INFO - 2024-07-15 14:42:18 --> Loader Class Initialized
INFO - 2024-07-15 14:42:18 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:18 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:18 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:18 --> Controller Class Initialized
DEBUG - 2024-07-15 14:42:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:42:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:42:18 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:18 --> Total execution time: 0.0274
INFO - 2024-07-15 14:42:22 --> Config Class Initialized
INFO - 2024-07-15 14:42:22 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:22 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:22 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:22 --> URI Class Initialized
INFO - 2024-07-15 14:42:22 --> Router Class Initialized
INFO - 2024-07-15 14:42:22 --> Output Class Initialized
INFO - 2024-07-15 14:42:22 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:22 --> Input Class Initialized
INFO - 2024-07-15 14:42:22 --> Language Class Initialized
INFO - 2024-07-15 14:42:22 --> Language Class Initialized
INFO - 2024-07-15 14:42:22 --> Config Class Initialized
INFO - 2024-07-15 14:42:22 --> Loader Class Initialized
INFO - 2024-07-15 14:42:22 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:22 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:22 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:22 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:22 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:22 --> Controller Class Initialized
ERROR - 2024-07-15 14:42:22 --> Severity: Notice --> Undefined index: tingkat /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
ERROR - 2024-07-15 14:42:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 49
ERROR - 2024-07-15 14:42:22 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php 59
DEBUG - 2024-07-15 14:42:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/form.php
DEBUG - 2024-07-15 14:42:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:42:22 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:22 --> Total execution time: 0.0353
INFO - 2024-07-15 14:42:35 --> Config Class Initialized
INFO - 2024-07-15 14:42:35 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:35 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:35 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:35 --> URI Class Initialized
INFO - 2024-07-15 14:42:35 --> Router Class Initialized
INFO - 2024-07-15 14:42:35 --> Output Class Initialized
INFO - 2024-07-15 14:42:35 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:35 --> Input Class Initialized
INFO - 2024-07-15 14:42:35 --> Language Class Initialized
INFO - 2024-07-15 14:42:35 --> Language Class Initialized
INFO - 2024-07-15 14:42:35 --> Config Class Initialized
INFO - 2024-07-15 14:42:35 --> Loader Class Initialized
INFO - 2024-07-15 14:42:35 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:35 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:35 --> Controller Class Initialized
INFO - 2024-07-15 14:42:35 --> Config Class Initialized
INFO - 2024-07-15 14:42:35 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:42:35 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:42:35 --> Utf8 Class Initialized
INFO - 2024-07-15 14:42:35 --> URI Class Initialized
INFO - 2024-07-15 14:42:35 --> Router Class Initialized
INFO - 2024-07-15 14:42:35 --> Output Class Initialized
INFO - 2024-07-15 14:42:35 --> Security Class Initialized
DEBUG - 2024-07-15 14:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:42:35 --> Input Class Initialized
INFO - 2024-07-15 14:42:35 --> Language Class Initialized
INFO - 2024-07-15 14:42:35 --> Language Class Initialized
INFO - 2024-07-15 14:42:35 --> Config Class Initialized
INFO - 2024-07-15 14:42:35 --> Loader Class Initialized
INFO - 2024-07-15 14:42:35 --> Helper loaded: url_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: file_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: form_helper
INFO - 2024-07-15 14:42:35 --> Helper loaded: my_helper
INFO - 2024-07-15 14:42:35 --> Database Driver Class Initialized
INFO - 2024-07-15 14:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:42:35 --> Controller Class Initialized
DEBUG - 2024-07-15 14:42:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:42:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:42:35 --> Final output sent to browser
DEBUG - 2024-07-15 14:42:35 --> Total execution time: 0.0469
INFO - 2024-07-15 14:44:55 --> Config Class Initialized
INFO - 2024-07-15 14:44:55 --> Hooks Class Initialized
DEBUG - 2024-07-15 14:44:55 --> UTF-8 Support Enabled
INFO - 2024-07-15 14:44:55 --> Utf8 Class Initialized
INFO - 2024-07-15 14:44:55 --> URI Class Initialized
INFO - 2024-07-15 14:44:55 --> Router Class Initialized
INFO - 2024-07-15 14:44:55 --> Output Class Initialized
INFO - 2024-07-15 14:44:55 --> Security Class Initialized
DEBUG - 2024-07-15 14:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-07-15 14:44:55 --> Input Class Initialized
INFO - 2024-07-15 14:44:55 --> Language Class Initialized
INFO - 2024-07-15 14:44:55 --> Language Class Initialized
INFO - 2024-07-15 14:44:55 --> Config Class Initialized
INFO - 2024-07-15 14:44:55 --> Loader Class Initialized
INFO - 2024-07-15 14:44:55 --> Helper loaded: url_helper
INFO - 2024-07-15 14:44:55 --> Helper loaded: file_helper
INFO - 2024-07-15 14:44:55 --> Helper loaded: form_helper
INFO - 2024-07-15 14:44:55 --> Helper loaded: my_helper
INFO - 2024-07-15 14:44:55 --> Database Driver Class Initialized
INFO - 2024-07-15 14:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-07-15 14:44:55 --> Controller Class Initialized
DEBUG - 2024-07-15 14:44:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-07-15 14:44:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-07-15 14:44:55 --> Final output sent to browser
DEBUG - 2024-07-15 14:44:55 --> Total execution time: 0.0281
