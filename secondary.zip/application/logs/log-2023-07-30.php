<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-30 16:51:20 --> Config Class Initialized
INFO - 2023-07-30 16:51:20 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:20 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:20 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:20 --> URI Class Initialized
DEBUG - 2023-07-30 16:51:20 --> No URI present. Default controller set.
INFO - 2023-07-30 16:51:20 --> Router Class Initialized
INFO - 2023-07-30 16:51:20 --> Output Class Initialized
INFO - 2023-07-30 16:51:20 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:20 --> Input Class Initialized
INFO - 2023-07-30 16:51:20 --> Language Class Initialized
INFO - 2023-07-30 16:51:20 --> Language Class Initialized
INFO - 2023-07-30 16:51:20 --> Config Class Initialized
INFO - 2023-07-30 16:51:20 --> Loader Class Initialized
INFO - 2023-07-30 16:51:20 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:20 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:20 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:20 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:20 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:20 --> Controller Class Initialized
INFO - 2023-07-30 16:51:21 --> Config Class Initialized
INFO - 2023-07-30 16:51:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:21 --> URI Class Initialized
INFO - 2023-07-30 16:51:21 --> Router Class Initialized
INFO - 2023-07-30 16:51:21 --> Output Class Initialized
INFO - 2023-07-30 16:51:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:21 --> Input Class Initialized
INFO - 2023-07-30 16:51:21 --> Language Class Initialized
INFO - 2023-07-30 16:51:21 --> Language Class Initialized
INFO - 2023-07-30 16:51:21 --> Config Class Initialized
INFO - 2023-07-30 16:51:21 --> Loader Class Initialized
INFO - 2023-07-30 16:51:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:21 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:21 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-30 16:51:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:21 --> Total execution time: 0.0378
INFO - 2023-07-30 16:51:26 --> Config Class Initialized
INFO - 2023-07-30 16:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:26 --> URI Class Initialized
INFO - 2023-07-30 16:51:26 --> Router Class Initialized
INFO - 2023-07-30 16:51:26 --> Output Class Initialized
INFO - 2023-07-30 16:51:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:26 --> Input Class Initialized
INFO - 2023-07-30 16:51:26 --> Language Class Initialized
INFO - 2023-07-30 16:51:26 --> Language Class Initialized
INFO - 2023-07-30 16:51:26 --> Config Class Initialized
INFO - 2023-07-30 16:51:26 --> Loader Class Initialized
INFO - 2023-07-30 16:51:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:26 --> Controller Class Initialized
INFO - 2023-07-30 16:51:26 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:51:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:26 --> Total execution time: 0.0562
INFO - 2023-07-30 16:51:26 --> Config Class Initialized
INFO - 2023-07-30 16:51:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:26 --> URI Class Initialized
INFO - 2023-07-30 16:51:26 --> Router Class Initialized
INFO - 2023-07-30 16:51:26 --> Output Class Initialized
INFO - 2023-07-30 16:51:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:26 --> Input Class Initialized
INFO - 2023-07-30 16:51:26 --> Language Class Initialized
INFO - 2023-07-30 16:51:26 --> Language Class Initialized
INFO - 2023-07-30 16:51:26 --> Config Class Initialized
INFO - 2023-07-30 16:51:26 --> Loader Class Initialized
INFO - 2023-07-30 16:51:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:26 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:26 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-30 16:51:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:26 --> Total execution time: 0.0856
INFO - 2023-07-30 16:51:28 --> Config Class Initialized
INFO - 2023-07-30 16:51:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:28 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:28 --> URI Class Initialized
INFO - 2023-07-30 16:51:28 --> Router Class Initialized
INFO - 2023-07-30 16:51:28 --> Output Class Initialized
INFO - 2023-07-30 16:51:28 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:28 --> Input Class Initialized
INFO - 2023-07-30 16:51:28 --> Language Class Initialized
INFO - 2023-07-30 16:51:28 --> Language Class Initialized
INFO - 2023-07-30 16:51:28 --> Config Class Initialized
INFO - 2023-07-30 16:51:28 --> Loader Class Initialized
INFO - 2023-07-30 16:51:28 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:28 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:28 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-30 16:51:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:28 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:28 --> Total execution time: 0.0546
INFO - 2023-07-30 16:51:28 --> Config Class Initialized
INFO - 2023-07-30 16:51:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:28 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:28 --> URI Class Initialized
INFO - 2023-07-30 16:51:28 --> Router Class Initialized
INFO - 2023-07-30 16:51:28 --> Output Class Initialized
INFO - 2023-07-30 16:51:28 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:28 --> Input Class Initialized
INFO - 2023-07-30 16:51:28 --> Language Class Initialized
INFO - 2023-07-30 16:51:28 --> Language Class Initialized
INFO - 2023-07-30 16:51:28 --> Config Class Initialized
INFO - 2023-07-30 16:51:28 --> Loader Class Initialized
INFO - 2023-07-30 16:51:28 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:28 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:28 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:28 --> Controller Class Initialized
INFO - 2023-07-30 16:51:29 --> Config Class Initialized
INFO - 2023-07-30 16:51:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:29 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:29 --> URI Class Initialized
INFO - 2023-07-30 16:51:29 --> Router Class Initialized
INFO - 2023-07-30 16:51:29 --> Output Class Initialized
INFO - 2023-07-30 16:51:29 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:29 --> Input Class Initialized
INFO - 2023-07-30 16:51:29 --> Language Class Initialized
INFO - 2023-07-30 16:51:29 --> Language Class Initialized
INFO - 2023-07-30 16:51:29 --> Config Class Initialized
INFO - 2023-07-30 16:51:29 --> Loader Class Initialized
INFO - 2023-07-30 16:51:29 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:29 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:29 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-30 16:51:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:29 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:29 --> Total execution time: 0.0622
INFO - 2023-07-30 16:51:29 --> Config Class Initialized
INFO - 2023-07-30 16:51:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:29 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:29 --> URI Class Initialized
INFO - 2023-07-30 16:51:29 --> Router Class Initialized
INFO - 2023-07-30 16:51:29 --> Output Class Initialized
INFO - 2023-07-30 16:51:29 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:29 --> Input Class Initialized
INFO - 2023-07-30 16:51:29 --> Language Class Initialized
INFO - 2023-07-30 16:51:29 --> Language Class Initialized
INFO - 2023-07-30 16:51:29 --> Config Class Initialized
INFO - 2023-07-30 16:51:29 --> Loader Class Initialized
INFO - 2023-07-30 16:51:29 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:29 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:29 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:29 --> Controller Class Initialized
INFO - 2023-07-30 16:51:29 --> Config Class Initialized
INFO - 2023-07-30 16:51:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:29 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:29 --> URI Class Initialized
INFO - 2023-07-30 16:51:29 --> Router Class Initialized
INFO - 2023-07-30 16:51:29 --> Output Class Initialized
INFO - 2023-07-30 16:51:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:30 --> Input Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Config Class Initialized
INFO - 2023-07-30 16:51:30 --> Loader Class Initialized
INFO - 2023-07-30 16:51:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:30 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:30 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-30 16:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:30 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:30 --> Total execution time: 0.0605
INFO - 2023-07-30 16:51:30 --> Config Class Initialized
INFO - 2023-07-30 16:51:30 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:30 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:30 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:30 --> URI Class Initialized
INFO - 2023-07-30 16:51:30 --> Router Class Initialized
INFO - 2023-07-30 16:51:30 --> Output Class Initialized
INFO - 2023-07-30 16:51:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:30 --> Input Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Config Class Initialized
INFO - 2023-07-30 16:51:30 --> Loader Class Initialized
INFO - 2023-07-30 16:51:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:30 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:30 --> Controller Class Initialized
INFO - 2023-07-30 16:51:30 --> Config Class Initialized
INFO - 2023-07-30 16:51:30 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:30 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:30 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:30 --> URI Class Initialized
INFO - 2023-07-30 16:51:30 --> Router Class Initialized
INFO - 2023-07-30 16:51:30 --> Output Class Initialized
INFO - 2023-07-30 16:51:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:30 --> Input Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Language Class Initialized
INFO - 2023-07-30 16:51:30 --> Config Class Initialized
INFO - 2023-07-30 16:51:30 --> Loader Class Initialized
INFO - 2023-07-30 16:51:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:30 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:30 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:30 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-30 16:51:30 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:30 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:30 --> Total execution time: 0.0485
INFO - 2023-07-30 16:51:31 --> Config Class Initialized
INFO - 2023-07-30 16:51:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:31 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:31 --> URI Class Initialized
INFO - 2023-07-30 16:51:31 --> Router Class Initialized
INFO - 2023-07-30 16:51:31 --> Output Class Initialized
INFO - 2023-07-30 16:51:31 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:31 --> Input Class Initialized
INFO - 2023-07-30 16:51:31 --> Language Class Initialized
INFO - 2023-07-30 16:51:31 --> Language Class Initialized
INFO - 2023-07-30 16:51:31 --> Config Class Initialized
INFO - 2023-07-30 16:51:31 --> Loader Class Initialized
INFO - 2023-07-30 16:51:31 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:31 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:31 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:31 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:31 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:31 --> Controller Class Initialized
INFO - 2023-07-30 16:51:32 --> Config Class Initialized
INFO - 2023-07-30 16:51:32 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:32 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:32 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:32 --> URI Class Initialized
INFO - 2023-07-30 16:51:32 --> Router Class Initialized
INFO - 2023-07-30 16:51:32 --> Output Class Initialized
INFO - 2023-07-30 16:51:32 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:32 --> Input Class Initialized
INFO - 2023-07-30 16:51:32 --> Language Class Initialized
INFO - 2023-07-30 16:51:32 --> Language Class Initialized
INFO - 2023-07-30 16:51:32 --> Config Class Initialized
INFO - 2023-07-30 16:51:32 --> Loader Class Initialized
INFO - 2023-07-30 16:51:32 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:32 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:32 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/tahun/views/list.php
DEBUG - 2023-07-30 16:51:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:32 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:32 --> Total execution time: 0.0425
INFO - 2023-07-30 16:51:32 --> Config Class Initialized
INFO - 2023-07-30 16:51:32 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:32 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:32 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:32 --> URI Class Initialized
INFO - 2023-07-30 16:51:32 --> Router Class Initialized
INFO - 2023-07-30 16:51:32 --> Output Class Initialized
INFO - 2023-07-30 16:51:32 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:32 --> Input Class Initialized
INFO - 2023-07-30 16:51:32 --> Language Class Initialized
INFO - 2023-07-30 16:51:32 --> Language Class Initialized
INFO - 2023-07-30 16:51:32 --> Config Class Initialized
INFO - 2023-07-30 16:51:32 --> Loader Class Initialized
INFO - 2023-07-30 16:51:32 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:32 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:32 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:32 --> Controller Class Initialized
INFO - 2023-07-30 16:51:34 --> Config Class Initialized
INFO - 2023-07-30 16:51:34 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:34 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:34 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:34 --> URI Class Initialized
INFO - 2023-07-30 16:51:34 --> Router Class Initialized
INFO - 2023-07-30 16:51:34 --> Output Class Initialized
INFO - 2023-07-30 16:51:34 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:34 --> Input Class Initialized
INFO - 2023-07-30 16:51:34 --> Language Class Initialized
INFO - 2023-07-30 16:51:34 --> Language Class Initialized
INFO - 2023-07-30 16:51:34 --> Config Class Initialized
INFO - 2023-07-30 16:51:34 --> Loader Class Initialized
INFO - 2023-07-30 16:51:34 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:34 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:34 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:34 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:34 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:34 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-30 16:51:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:34 --> Total execution time: 0.0492
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:35 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:35 --> URI Class Initialized
INFO - 2023-07-30 16:51:35 --> Router Class Initialized
INFO - 2023-07-30 16:51:35 --> Output Class Initialized
INFO - 2023-07-30 16:51:35 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:35 --> Input Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Loader Class Initialized
INFO - 2023-07-30 16:51:35 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:35 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:35 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_mapel/views/list.php
DEBUG - 2023-07-30 16:51:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:35 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:35 --> Total execution time: 0.0851
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:35 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:35 --> URI Class Initialized
INFO - 2023-07-30 16:51:35 --> Router Class Initialized
INFO - 2023-07-30 16:51:35 --> Output Class Initialized
INFO - 2023-07-30 16:51:35 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:35 --> Input Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Loader Class Initialized
INFO - 2023-07-30 16:51:35 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:35 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:35 --> Controller Class Initialized
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:35 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:35 --> URI Class Initialized
INFO - 2023-07-30 16:51:35 --> Router Class Initialized
INFO - 2023-07-30 16:51:35 --> Output Class Initialized
INFO - 2023-07-30 16:51:35 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:35 --> Input Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Loader Class Initialized
INFO - 2023-07-30 16:51:35 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:35 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:35 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_walikelas/views/list.php
DEBUG - 2023-07-30 16:51:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:35 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:35 --> Total execution time: 0.0841
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:35 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:35 --> URI Class Initialized
INFO - 2023-07-30 16:51:35 --> Router Class Initialized
INFO - 2023-07-30 16:51:35 --> Output Class Initialized
INFO - 2023-07-30 16:51:35 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:35 --> Input Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Language Class Initialized
INFO - 2023-07-30 16:51:35 --> Config Class Initialized
INFO - 2023-07-30 16:51:35 --> Loader Class Initialized
INFO - 2023-07-30 16:51:35 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:35 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:36 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:36 --> Controller Class Initialized
INFO - 2023-07-30 16:51:36 --> Config Class Initialized
INFO - 2023-07-30 16:51:36 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:36 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:36 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:36 --> URI Class Initialized
INFO - 2023-07-30 16:51:36 --> Router Class Initialized
INFO - 2023-07-30 16:51:36 --> Output Class Initialized
INFO - 2023-07-30 16:51:36 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:36 --> Input Class Initialized
INFO - 2023-07-30 16:51:36 --> Language Class Initialized
INFO - 2023-07-30 16:51:36 --> Language Class Initialized
INFO - 2023-07-30 16:51:36 --> Config Class Initialized
INFO - 2023-07-30 16:51:36 --> Loader Class Initialized
INFO - 2023-07-30 16:51:36 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:36 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:36 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_mapel/views/list.php
DEBUG - 2023-07-30 16:51:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:36 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:36 --> Total execution time: 0.0397
INFO - 2023-07-30 16:51:36 --> Config Class Initialized
INFO - 2023-07-30 16:51:36 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:36 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:36 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:36 --> URI Class Initialized
INFO - 2023-07-30 16:51:36 --> Router Class Initialized
INFO - 2023-07-30 16:51:36 --> Output Class Initialized
INFO - 2023-07-30 16:51:36 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:36 --> Input Class Initialized
INFO - 2023-07-30 16:51:36 --> Language Class Initialized
INFO - 2023-07-30 16:51:36 --> Language Class Initialized
INFO - 2023-07-30 16:51:36 --> Config Class Initialized
INFO - 2023-07-30 16:51:36 --> Loader Class Initialized
INFO - 2023-07-30 16:51:36 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:36 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:36 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:36 --> Controller Class Initialized
INFO - 2023-07-30 16:51:40 --> Config Class Initialized
INFO - 2023-07-30 16:51:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:40 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:40 --> URI Class Initialized
DEBUG - 2023-07-30 16:51:40 --> No URI present. Default controller set.
INFO - 2023-07-30 16:51:40 --> Router Class Initialized
INFO - 2023-07-30 16:51:40 --> Output Class Initialized
INFO - 2023-07-30 16:51:40 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:40 --> Input Class Initialized
INFO - 2023-07-30 16:51:40 --> Language Class Initialized
INFO - 2023-07-30 16:51:40 --> Language Class Initialized
INFO - 2023-07-30 16:51:40 --> Config Class Initialized
INFO - 2023-07-30 16:51:40 --> Loader Class Initialized
INFO - 2023-07-30 16:51:40 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:40 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:40 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:40 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:40 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:40 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-30 16:51:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:40 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:40 --> Total execution time: 0.0405
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:47 --> URI Class Initialized
INFO - 2023-07-30 16:51:47 --> Router Class Initialized
INFO - 2023-07-30 16:51:47 --> Output Class Initialized
INFO - 2023-07-30 16:51:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:47 --> Input Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Loader Class Initialized
INFO - 2023-07-30 16:51:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:47 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:47 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-30 16:51:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:47 --> Total execution time: 0.0382
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:47 --> URI Class Initialized
INFO - 2023-07-30 16:51:47 --> Router Class Initialized
INFO - 2023-07-30 16:51:47 --> Output Class Initialized
INFO - 2023-07-30 16:51:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:47 --> Input Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Loader Class Initialized
INFO - 2023-07-30 16:51:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:47 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:47 --> Controller Class Initialized
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:47 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:47 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:47 --> URI Class Initialized
INFO - 2023-07-30 16:51:47 --> Router Class Initialized
INFO - 2023-07-30 16:51:47 --> Output Class Initialized
INFO - 2023-07-30 16:51:47 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:47 --> Input Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Language Class Initialized
INFO - 2023-07-30 16:51:47 --> Config Class Initialized
INFO - 2023-07-30 16:51:47 --> Loader Class Initialized
INFO - 2023-07-30 16:51:47 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:47 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:47 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:47 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-30 16:51:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:47 --> Total execution time: 0.0518
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:48 --> URI Class Initialized
INFO - 2023-07-30 16:51:48 --> Router Class Initialized
INFO - 2023-07-30 16:51:48 --> Output Class Initialized
INFO - 2023-07-30 16:51:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:48 --> Input Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Loader Class Initialized
INFO - 2023-07-30 16:51:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:48 --> Controller Class Initialized
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:48 --> URI Class Initialized
INFO - 2023-07-30 16:51:48 --> Router Class Initialized
INFO - 2023-07-30 16:51:48 --> Output Class Initialized
INFO - 2023-07-30 16:51:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:48 --> Input Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Loader Class Initialized
INFO - 2023-07-30 16:51:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:48 --> Controller Class Initialized
DEBUG - 2023-07-30 16:51:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-30 16:51:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:51:48 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:48 --> Total execution time: 0.0492
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:48 --> URI Class Initialized
INFO - 2023-07-30 16:51:48 --> Router Class Initialized
INFO - 2023-07-30 16:51:48 --> Output Class Initialized
INFO - 2023-07-30 16:51:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:48 --> Input Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Language Class Initialized
INFO - 2023-07-30 16:51:48 --> Config Class Initialized
INFO - 2023-07-30 16:51:48 --> Loader Class Initialized
INFO - 2023-07-30 16:51:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:48 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:48 --> Controller Class Initialized
INFO - 2023-07-30 16:51:50 --> Config Class Initialized
INFO - 2023-07-30 16:51:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:51:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:51:50 --> Utf8 Class Initialized
INFO - 2023-07-30 16:51:50 --> URI Class Initialized
INFO - 2023-07-30 16:51:50 --> Router Class Initialized
INFO - 2023-07-30 16:51:50 --> Output Class Initialized
INFO - 2023-07-30 16:51:50 --> Security Class Initialized
DEBUG - 2023-07-30 16:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:51:50 --> Input Class Initialized
INFO - 2023-07-30 16:51:50 --> Language Class Initialized
INFO - 2023-07-30 16:51:50 --> Language Class Initialized
INFO - 2023-07-30 16:51:50 --> Config Class Initialized
INFO - 2023-07-30 16:51:50 --> Loader Class Initialized
INFO - 2023-07-30 16:51:50 --> Helper loaded: url_helper
INFO - 2023-07-30 16:51:50 --> Helper loaded: file_helper
INFO - 2023-07-30 16:51:50 --> Helper loaded: form_helper
INFO - 2023-07-30 16:51:50 --> Helper loaded: my_helper
INFO - 2023-07-30 16:51:50 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:51:50 --> Controller Class Initialized
INFO - 2023-07-30 16:51:50 --> Final output sent to browser
DEBUG - 2023-07-30 16:51:50 --> Total execution time: 0.0378
INFO - 2023-07-30 16:52:06 --> Config Class Initialized
INFO - 2023-07-30 16:52:06 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:06 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:06 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:06 --> URI Class Initialized
INFO - 2023-07-30 16:52:06 --> Router Class Initialized
INFO - 2023-07-30 16:52:06 --> Output Class Initialized
INFO - 2023-07-30 16:52:06 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:06 --> Input Class Initialized
INFO - 2023-07-30 16:52:06 --> Language Class Initialized
INFO - 2023-07-30 16:52:06 --> Language Class Initialized
INFO - 2023-07-30 16:52:06 --> Config Class Initialized
INFO - 2023-07-30 16:52:06 --> Loader Class Initialized
INFO - 2023-07-30 16:52:06 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:06 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:06 --> Controller Class Initialized
INFO - 2023-07-30 16:52:06 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:06 --> Total execution time: 0.0390
INFO - 2023-07-30 16:52:06 --> Config Class Initialized
INFO - 2023-07-30 16:52:06 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:06 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:06 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:06 --> URI Class Initialized
INFO - 2023-07-30 16:52:06 --> Router Class Initialized
INFO - 2023-07-30 16:52:06 --> Output Class Initialized
INFO - 2023-07-30 16:52:06 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:06 --> Input Class Initialized
INFO - 2023-07-30 16:52:06 --> Language Class Initialized
INFO - 2023-07-30 16:52:06 --> Language Class Initialized
INFO - 2023-07-30 16:52:06 --> Config Class Initialized
INFO - 2023-07-30 16:52:06 --> Loader Class Initialized
INFO - 2023-07-30 16:52:06 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:06 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:06 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:06 --> Controller Class Initialized
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:08 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:08 --> URI Class Initialized
INFO - 2023-07-30 16:52:08 --> Router Class Initialized
INFO - 2023-07-30 16:52:08 --> Output Class Initialized
INFO - 2023-07-30 16:52:08 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:08 --> Input Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Loader Class Initialized
INFO - 2023-07-30 16:52:08 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:08 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:08 --> Controller Class Initialized
INFO - 2023-07-30 16:52:08 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:08 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:08 --> URI Class Initialized
INFO - 2023-07-30 16:52:08 --> Router Class Initialized
INFO - 2023-07-30 16:52:08 --> Output Class Initialized
INFO - 2023-07-30 16:52:08 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:08 --> Input Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Loader Class Initialized
INFO - 2023-07-30 16:52:08 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:08 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:08 --> Controller Class Initialized
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:08 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:08 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:08 --> URI Class Initialized
INFO - 2023-07-30 16:52:08 --> Router Class Initialized
INFO - 2023-07-30 16:52:08 --> Output Class Initialized
INFO - 2023-07-30 16:52:08 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:08 --> Input Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Language Class Initialized
INFO - 2023-07-30 16:52:08 --> Config Class Initialized
INFO - 2023-07-30 16:52:08 --> Loader Class Initialized
INFO - 2023-07-30 16:52:08 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:08 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:08 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:08 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-30 16:52:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:52:09 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:09 --> Total execution time: 0.0434
INFO - 2023-07-30 16:52:17 --> Config Class Initialized
INFO - 2023-07-30 16:52:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:17 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:17 --> URI Class Initialized
INFO - 2023-07-30 16:52:17 --> Router Class Initialized
INFO - 2023-07-30 16:52:17 --> Output Class Initialized
INFO - 2023-07-30 16:52:17 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:17 --> Input Class Initialized
INFO - 2023-07-30 16:52:17 --> Language Class Initialized
INFO - 2023-07-30 16:52:17 --> Language Class Initialized
INFO - 2023-07-30 16:52:17 --> Config Class Initialized
INFO - 2023-07-30 16:52:17 --> Loader Class Initialized
INFO - 2023-07-30 16:52:17 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:17 --> Controller Class Initialized
INFO - 2023-07-30 16:52:17 --> Helper loaded: cookie_helper
INFO - 2023-07-30 16:52:17 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:17 --> Total execution time: 0.0592
INFO - 2023-07-30 16:52:17 --> Config Class Initialized
INFO - 2023-07-30 16:52:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:17 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:17 --> URI Class Initialized
INFO - 2023-07-30 16:52:17 --> Router Class Initialized
INFO - 2023-07-30 16:52:17 --> Output Class Initialized
INFO - 2023-07-30 16:52:17 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:17 --> Input Class Initialized
INFO - 2023-07-30 16:52:17 --> Language Class Initialized
INFO - 2023-07-30 16:52:17 --> Language Class Initialized
INFO - 2023-07-30 16:52:17 --> Config Class Initialized
INFO - 2023-07-30 16:52:17 --> Loader Class Initialized
INFO - 2023-07-30 16:52:17 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:17 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:17 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-30 16:52:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:52:17 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:17 --> Total execution time: 0.0901
INFO - 2023-07-30 16:52:20 --> Config Class Initialized
INFO - 2023-07-30 16:52:20 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:20 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:20 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:20 --> URI Class Initialized
INFO - 2023-07-30 16:52:20 --> Router Class Initialized
INFO - 2023-07-30 16:52:20 --> Output Class Initialized
INFO - 2023-07-30 16:52:20 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:20 --> Input Class Initialized
INFO - 2023-07-30 16:52:20 --> Language Class Initialized
INFO - 2023-07-30 16:52:20 --> Language Class Initialized
INFO - 2023-07-30 16:52:20 --> Config Class Initialized
INFO - 2023-07-30 16:52:20 --> Loader Class Initialized
INFO - 2023-07-30 16:52:20 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:20 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:20 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:20 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:20 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:20 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-30 16:52:20 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:52:20 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:20 --> Total execution time: 0.1212
INFO - 2023-07-30 16:52:21 --> Config Class Initialized
INFO - 2023-07-30 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:21 --> URI Class Initialized
INFO - 2023-07-30 16:52:21 --> Router Class Initialized
INFO - 2023-07-30 16:52:21 --> Output Class Initialized
INFO - 2023-07-30 16:52:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:21 --> Input Class Initialized
INFO - 2023-07-30 16:52:21 --> Language Class Initialized
INFO - 2023-07-30 16:52:21 --> Language Class Initialized
INFO - 2023-07-30 16:52:21 --> Config Class Initialized
INFO - 2023-07-30 16:52:21 --> Loader Class Initialized
INFO - 2023-07-30 16:52:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:21 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:21 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:52:24 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:24 --> Total execution time: 3.0634
INFO - 2023-07-30 16:52:35 --> Config Class Initialized
INFO - 2023-07-30 16:52:35 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:35 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:35 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:35 --> URI Class Initialized
INFO - 2023-07-30 16:52:35 --> Router Class Initialized
INFO - 2023-07-30 16:52:35 --> Output Class Initialized
INFO - 2023-07-30 16:52:35 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:35 --> Input Class Initialized
INFO - 2023-07-30 16:52:35 --> Language Class Initialized
INFO - 2023-07-30 16:52:35 --> Language Class Initialized
INFO - 2023-07-30 16:52:35 --> Config Class Initialized
INFO - 2023-07-30 16:52:35 --> Loader Class Initialized
INFO - 2023-07-30 16:52:35 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:35 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:35 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:35 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:35 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:35 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-30 16:52:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:52:36 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:36 --> Total execution time: 0.1277
INFO - 2023-07-30 16:52:37 --> Config Class Initialized
INFO - 2023-07-30 16:52:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:37 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:37 --> URI Class Initialized
INFO - 2023-07-30 16:52:37 --> Router Class Initialized
INFO - 2023-07-30 16:52:37 --> Output Class Initialized
INFO - 2023-07-30 16:52:37 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:37 --> Input Class Initialized
INFO - 2023-07-30 16:52:37 --> Language Class Initialized
INFO - 2023-07-30 16:52:37 --> Language Class Initialized
INFO - 2023-07-30 16:52:37 --> Config Class Initialized
INFO - 2023-07-30 16:52:37 --> Loader Class Initialized
INFO - 2023-07-30 16:52:37 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:37 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:37 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:37 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:37 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:37 --> Controller Class Initialized
INFO - 2023-07-30 16:52:37 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:37 --> Total execution time: 0.0549
INFO - 2023-07-30 16:52:43 --> Config Class Initialized
INFO - 2023-07-30 16:52:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:43 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:43 --> URI Class Initialized
INFO - 2023-07-30 16:52:43 --> Router Class Initialized
INFO - 2023-07-30 16:52:43 --> Output Class Initialized
INFO - 2023-07-30 16:52:43 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:43 --> Input Class Initialized
INFO - 2023-07-30 16:52:43 --> Language Class Initialized
INFO - 2023-07-30 16:52:43 --> Language Class Initialized
INFO - 2023-07-30 16:52:43 --> Config Class Initialized
INFO - 2023-07-30 16:52:43 --> Loader Class Initialized
INFO - 2023-07-30 16:52:43 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:43 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:43 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:43 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:43 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:43 --> Controller Class Initialized
INFO - 2023-07-30 16:52:43 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:43 --> Total execution time: 0.0434
INFO - 2023-07-30 16:52:45 --> Config Class Initialized
INFO - 2023-07-30 16:52:45 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:52:45 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:52:45 --> Utf8 Class Initialized
INFO - 2023-07-30 16:52:45 --> URI Class Initialized
INFO - 2023-07-30 16:52:46 --> Router Class Initialized
INFO - 2023-07-30 16:52:46 --> Output Class Initialized
INFO - 2023-07-30 16:52:46 --> Security Class Initialized
DEBUG - 2023-07-30 16:52:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:52:46 --> Input Class Initialized
INFO - 2023-07-30 16:52:46 --> Language Class Initialized
INFO - 2023-07-30 16:52:46 --> Language Class Initialized
INFO - 2023-07-30 16:52:46 --> Config Class Initialized
INFO - 2023-07-30 16:52:46 --> Loader Class Initialized
INFO - 2023-07-30 16:52:46 --> Helper loaded: url_helper
INFO - 2023-07-30 16:52:46 --> Helper loaded: file_helper
INFO - 2023-07-30 16:52:46 --> Helper loaded: form_helper
INFO - 2023-07-30 16:52:46 --> Helper loaded: my_helper
INFO - 2023-07-30 16:52:46 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:52:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:52:46 --> Controller Class Initialized
DEBUG - 2023-07-30 16:52:46 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:52:47 --> Final output sent to browser
DEBUG - 2023-07-30 16:52:47 --> Total execution time: 1.6396
INFO - 2023-07-30 16:53:00 --> Config Class Initialized
INFO - 2023-07-30 16:53:00 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:00 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:00 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:00 --> URI Class Initialized
INFO - 2023-07-30 16:53:00 --> Router Class Initialized
INFO - 2023-07-30 16:53:00 --> Output Class Initialized
INFO - 2023-07-30 16:53:00 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:00 --> Input Class Initialized
INFO - 2023-07-30 16:53:00 --> Language Class Initialized
INFO - 2023-07-30 16:53:00 --> Language Class Initialized
INFO - 2023-07-30 16:53:00 --> Config Class Initialized
INFO - 2023-07-30 16:53:00 --> Loader Class Initialized
INFO - 2023-07-30 16:53:00 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:00 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:00 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:00 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:00 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:00 --> Controller Class Initialized
INFO - 2023-07-30 16:53:00 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:00 --> Total execution time: 0.0553
INFO - 2023-07-30 16:53:02 --> Config Class Initialized
INFO - 2023-07-30 16:53:02 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:02 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:02 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:02 --> URI Class Initialized
INFO - 2023-07-30 16:53:02 --> Router Class Initialized
INFO - 2023-07-30 16:53:02 --> Output Class Initialized
INFO - 2023-07-30 16:53:02 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:02 --> Input Class Initialized
INFO - 2023-07-30 16:53:02 --> Language Class Initialized
INFO - 2023-07-30 16:53:02 --> Language Class Initialized
INFO - 2023-07-30 16:53:02 --> Config Class Initialized
INFO - 2023-07-30 16:53:02 --> Loader Class Initialized
INFO - 2023-07-30 16:53:02 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:02 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:02 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:02 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:02 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:02 --> Controller Class Initialized
DEBUG - 2023-07-30 16:53:02 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:53:03 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:03 --> Total execution time: 1.4061
INFO - 2023-07-30 16:53:16 --> Config Class Initialized
INFO - 2023-07-30 16:53:16 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:16 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:16 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:16 --> URI Class Initialized
INFO - 2023-07-30 16:53:16 --> Router Class Initialized
INFO - 2023-07-30 16:53:16 --> Output Class Initialized
INFO - 2023-07-30 16:53:16 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:16 --> Input Class Initialized
INFO - 2023-07-30 16:53:16 --> Language Class Initialized
INFO - 2023-07-30 16:53:16 --> Language Class Initialized
INFO - 2023-07-30 16:53:16 --> Config Class Initialized
INFO - 2023-07-30 16:53:16 --> Loader Class Initialized
INFO - 2023-07-30 16:53:16 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:16 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:16 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:16 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:16 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:16 --> Controller Class Initialized
INFO - 2023-07-30 16:53:16 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:16 --> Total execution time: 0.0326
INFO - 2023-07-30 16:53:26 --> Config Class Initialized
INFO - 2023-07-30 16:53:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:26 --> URI Class Initialized
INFO - 2023-07-30 16:53:26 --> Router Class Initialized
INFO - 2023-07-30 16:53:26 --> Output Class Initialized
INFO - 2023-07-30 16:53:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:26 --> Input Class Initialized
INFO - 2023-07-30 16:53:26 --> Language Class Initialized
INFO - 2023-07-30 16:53:26 --> Language Class Initialized
INFO - 2023-07-30 16:53:26 --> Config Class Initialized
INFO - 2023-07-30 16:53:26 --> Loader Class Initialized
INFO - 2023-07-30 16:53:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:26 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:26 --> Controller Class Initialized
INFO - 2023-07-30 16:53:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:26 --> Total execution time: 0.0597
INFO - 2023-07-30 16:53:29 --> Config Class Initialized
INFO - 2023-07-30 16:53:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:29 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:29 --> URI Class Initialized
INFO - 2023-07-30 16:53:29 --> Router Class Initialized
INFO - 2023-07-30 16:53:29 --> Output Class Initialized
INFO - 2023-07-30 16:53:29 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:29 --> Input Class Initialized
INFO - 2023-07-30 16:53:29 --> Language Class Initialized
INFO - 2023-07-30 16:53:29 --> Language Class Initialized
INFO - 2023-07-30 16:53:29 --> Config Class Initialized
INFO - 2023-07-30 16:53:29 --> Loader Class Initialized
INFO - 2023-07-30 16:53:29 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:29 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:29 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:29 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:29 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:29 --> Controller Class Initialized
DEBUG - 2023-07-30 16:53:29 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:53:30 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:30 --> Total execution time: 1.5269
INFO - 2023-07-30 16:53:41 --> Config Class Initialized
INFO - 2023-07-30 16:53:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:41 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:41 --> URI Class Initialized
INFO - 2023-07-30 16:53:41 --> Router Class Initialized
INFO - 2023-07-30 16:53:41 --> Output Class Initialized
INFO - 2023-07-30 16:53:41 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:41 --> Input Class Initialized
INFO - 2023-07-30 16:53:41 --> Language Class Initialized
INFO - 2023-07-30 16:53:41 --> Language Class Initialized
INFO - 2023-07-30 16:53:41 --> Config Class Initialized
INFO - 2023-07-30 16:53:41 --> Loader Class Initialized
INFO - 2023-07-30 16:53:41 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:41 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:41 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:41 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:41 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:41 --> Controller Class Initialized
INFO - 2023-07-30 16:53:41 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:41 --> Total execution time: 0.0474
INFO - 2023-07-30 16:53:46 --> Config Class Initialized
INFO - 2023-07-30 16:53:46 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:46 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:46 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:46 --> URI Class Initialized
INFO - 2023-07-30 16:53:46 --> Router Class Initialized
INFO - 2023-07-30 16:53:46 --> Output Class Initialized
INFO - 2023-07-30 16:53:46 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:46 --> Input Class Initialized
INFO - 2023-07-30 16:53:46 --> Language Class Initialized
INFO - 2023-07-30 16:53:46 --> Language Class Initialized
INFO - 2023-07-30 16:53:46 --> Config Class Initialized
INFO - 2023-07-30 16:53:46 --> Loader Class Initialized
INFO - 2023-07-30 16:53:46 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:46 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:46 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:46 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:46 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:46 --> Controller Class Initialized
INFO - 2023-07-30 16:53:46 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:46 --> Total execution time: 0.0466
INFO - 2023-07-30 16:53:48 --> Config Class Initialized
INFO - 2023-07-30 16:53:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:53:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:53:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:53:48 --> URI Class Initialized
INFO - 2023-07-30 16:53:48 --> Router Class Initialized
INFO - 2023-07-30 16:53:48 --> Output Class Initialized
INFO - 2023-07-30 16:53:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:53:48 --> Input Class Initialized
INFO - 2023-07-30 16:53:48 --> Language Class Initialized
INFO - 2023-07-30 16:53:48 --> Language Class Initialized
INFO - 2023-07-30 16:53:48 --> Config Class Initialized
INFO - 2023-07-30 16:53:48 --> Loader Class Initialized
INFO - 2023-07-30 16:53:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:53:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:53:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:53:48 --> Helper loaded: my_helper
INFO - 2023-07-30 16:53:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:53:48 --> Controller Class Initialized
DEBUG - 2023-07-30 16:53:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:53:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:53:49 --> Total execution time: 1.4930
INFO - 2023-07-30 16:54:26 --> Config Class Initialized
INFO - 2023-07-30 16:54:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:26 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:26 --> URI Class Initialized
INFO - 2023-07-30 16:54:26 --> Router Class Initialized
INFO - 2023-07-30 16:54:26 --> Output Class Initialized
INFO - 2023-07-30 16:54:26 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:26 --> Input Class Initialized
INFO - 2023-07-30 16:54:26 --> Language Class Initialized
INFO - 2023-07-30 16:54:26 --> Language Class Initialized
INFO - 2023-07-30 16:54:26 --> Config Class Initialized
INFO - 2023-07-30 16:54:26 --> Loader Class Initialized
INFO - 2023-07-30 16:54:26 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:26 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:26 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:26 --> Helper loaded: my_helper
INFO - 2023-07-30 16:54:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:26 --> Controller Class Initialized
INFO - 2023-07-30 16:54:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:26 --> Total execution time: 0.0584
INFO - 2023-07-30 16:54:28 --> Config Class Initialized
INFO - 2023-07-30 16:54:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:28 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:28 --> URI Class Initialized
INFO - 2023-07-30 16:54:28 --> Router Class Initialized
INFO - 2023-07-30 16:54:28 --> Output Class Initialized
INFO - 2023-07-30 16:54:28 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:28 --> Input Class Initialized
INFO - 2023-07-30 16:54:28 --> Language Class Initialized
INFO - 2023-07-30 16:54:28 --> Language Class Initialized
INFO - 2023-07-30 16:54:28 --> Config Class Initialized
INFO - 2023-07-30 16:54:28 --> Loader Class Initialized
INFO - 2023-07-30 16:54:28 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:28 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:28 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:28 --> Helper loaded: my_helper
INFO - 2023-07-30 16:54:28 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:28 --> Controller Class Initialized
INFO - 2023-07-30 16:54:28 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:28 --> Total execution time: 0.0478
INFO - 2023-07-30 16:54:30 --> Config Class Initialized
INFO - 2023-07-30 16:54:30 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:30 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:30 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:30 --> URI Class Initialized
INFO - 2023-07-30 16:54:30 --> Router Class Initialized
INFO - 2023-07-30 16:54:30 --> Output Class Initialized
INFO - 2023-07-30 16:54:30 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:30 --> Input Class Initialized
INFO - 2023-07-30 16:54:30 --> Language Class Initialized
INFO - 2023-07-30 16:54:30 --> Language Class Initialized
INFO - 2023-07-30 16:54:30 --> Config Class Initialized
INFO - 2023-07-30 16:54:30 --> Loader Class Initialized
INFO - 2023-07-30 16:54:30 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:30 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:30 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:30 --> Helper loaded: my_helper
INFO - 2023-07-30 16:54:30 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:54:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:30 --> Controller Class Initialized
INFO - 2023-07-30 16:54:31 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:31 --> Total execution time: 0.0455
INFO - 2023-07-30 16:54:32 --> Config Class Initialized
INFO - 2023-07-30 16:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:54:32 --> Utf8 Class Initialized
INFO - 2023-07-30 16:54:32 --> URI Class Initialized
INFO - 2023-07-30 16:54:32 --> Router Class Initialized
INFO - 2023-07-30 16:54:32 --> Output Class Initialized
INFO - 2023-07-30 16:54:32 --> Security Class Initialized
DEBUG - 2023-07-30 16:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:54:32 --> Input Class Initialized
INFO - 2023-07-30 16:54:32 --> Language Class Initialized
INFO - 2023-07-30 16:54:32 --> Language Class Initialized
INFO - 2023-07-30 16:54:32 --> Config Class Initialized
INFO - 2023-07-30 16:54:32 --> Loader Class Initialized
INFO - 2023-07-30 16:54:32 --> Helper loaded: url_helper
INFO - 2023-07-30 16:54:32 --> Helper loaded: file_helper
INFO - 2023-07-30 16:54:32 --> Helper loaded: form_helper
INFO - 2023-07-30 16:54:32 --> Helper loaded: my_helper
INFO - 2023-07-30 16:54:32 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:54:32 --> Controller Class Initialized
DEBUG - 2023-07-30 16:54:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 16:54:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:54:34 --> Total execution time: 1.5282
INFO - 2023-07-30 16:55:21 --> Config Class Initialized
INFO - 2023-07-30 16:55:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:21 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:21 --> URI Class Initialized
INFO - 2023-07-30 16:55:21 --> Router Class Initialized
INFO - 2023-07-30 16:55:21 --> Output Class Initialized
INFO - 2023-07-30 16:55:21 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:21 --> Input Class Initialized
INFO - 2023-07-30 16:55:21 --> Language Class Initialized
INFO - 2023-07-30 16:55:21 --> Language Class Initialized
INFO - 2023-07-30 16:55:21 --> Config Class Initialized
INFO - 2023-07-30 16:55:21 --> Loader Class Initialized
INFO - 2023-07-30 16:55:21 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:21 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:21 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:21 --> Helper loaded: my_helper
INFO - 2023-07-30 16:55:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:21 --> Controller Class Initialized
DEBUG - 2023-07-30 16:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-07-30 16:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 16:55:21 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:21 --> Total execution time: 0.0731
INFO - 2023-07-30 16:55:24 --> Config Class Initialized
INFO - 2023-07-30 16:55:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:24 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:24 --> URI Class Initialized
INFO - 2023-07-30 16:55:24 --> Router Class Initialized
INFO - 2023-07-30 16:55:24 --> Output Class Initialized
INFO - 2023-07-30 16:55:24 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:24 --> Input Class Initialized
INFO - 2023-07-30 16:55:24 --> Language Class Initialized
INFO - 2023-07-30 16:55:24 --> Language Class Initialized
INFO - 2023-07-30 16:55:24 --> Config Class Initialized
INFO - 2023-07-30 16:55:24 --> Loader Class Initialized
INFO - 2023-07-30 16:55:24 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:24 --> Helper loaded: my_helper
INFO - 2023-07-30 16:55:24 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:24 --> Controller Class Initialized
DEBUG - 2023-07-30 16:55:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-30 16:55:26 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:26 --> Total execution time: 2.3788
INFO - 2023-07-30 16:55:33 --> Config Class Initialized
INFO - 2023-07-30 16:55:33 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:33 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:33 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:33 --> URI Class Initialized
INFO - 2023-07-30 16:55:33 --> Router Class Initialized
INFO - 2023-07-30 16:55:33 --> Output Class Initialized
INFO - 2023-07-30 16:55:33 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:33 --> Input Class Initialized
INFO - 2023-07-30 16:55:33 --> Language Class Initialized
INFO - 2023-07-30 16:55:33 --> Language Class Initialized
INFO - 2023-07-30 16:55:33 --> Config Class Initialized
INFO - 2023-07-30 16:55:33 --> Loader Class Initialized
INFO - 2023-07-30 16:55:33 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:33 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:33 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:33 --> Helper loaded: my_helper
INFO - 2023-07-30 16:55:33 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:33 --> Controller Class Initialized
DEBUG - 2023-07-30 16:55:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-07-30 16:55:34 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:34 --> Total execution time: 0.9122
INFO - 2023-07-30 16:55:45 --> Config Class Initialized
INFO - 2023-07-30 16:55:45 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:55:45 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:55:45 --> Utf8 Class Initialized
INFO - 2023-07-30 16:55:45 --> URI Class Initialized
INFO - 2023-07-30 16:55:45 --> Router Class Initialized
INFO - 2023-07-30 16:55:45 --> Output Class Initialized
INFO - 2023-07-30 16:55:45 --> Security Class Initialized
DEBUG - 2023-07-30 16:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:55:45 --> Input Class Initialized
INFO - 2023-07-30 16:55:45 --> Language Class Initialized
INFO - 2023-07-30 16:55:45 --> Language Class Initialized
INFO - 2023-07-30 16:55:45 --> Config Class Initialized
INFO - 2023-07-30 16:55:45 --> Loader Class Initialized
INFO - 2023-07-30 16:55:45 --> Helper loaded: url_helper
INFO - 2023-07-30 16:55:45 --> Helper loaded: file_helper
INFO - 2023-07-30 16:55:45 --> Helper loaded: form_helper
INFO - 2023-07-30 16:55:45 --> Helper loaded: my_helper
INFO - 2023-07-30 16:55:45 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:55:45 --> Controller Class Initialized
DEBUG - 2023-07-30 16:55:45 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/cetak_pts_preschool.php
INFO - 2023-07-30 16:55:46 --> Final output sent to browser
DEBUG - 2023-07-30 16:55:46 --> Total execution time: 1.5177
INFO - 2023-07-30 16:57:48 --> Config Class Initialized
INFO - 2023-07-30 16:57:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:57:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:57:48 --> Utf8 Class Initialized
INFO - 2023-07-30 16:57:48 --> URI Class Initialized
INFO - 2023-07-30 16:57:48 --> Router Class Initialized
INFO - 2023-07-30 16:57:48 --> Output Class Initialized
INFO - 2023-07-30 16:57:48 --> Security Class Initialized
DEBUG - 2023-07-30 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:57:48 --> Input Class Initialized
INFO - 2023-07-30 16:57:48 --> Language Class Initialized
INFO - 2023-07-30 16:57:48 --> Language Class Initialized
INFO - 2023-07-30 16:57:48 --> Config Class Initialized
INFO - 2023-07-30 16:57:48 --> Loader Class Initialized
INFO - 2023-07-30 16:57:48 --> Helper loaded: url_helper
INFO - 2023-07-30 16:57:48 --> Helper loaded: file_helper
INFO - 2023-07-30 16:57:48 --> Helper loaded: form_helper
INFO - 2023-07-30 16:57:48 --> Helper loaded: my_helper
INFO - 2023-07-30 16:57:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:57:48 --> Controller Class Initialized
DEBUG - 2023-07-30 16:57:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-07-30 16:57:49 --> Final output sent to browser
DEBUG - 2023-07-30 16:57:49 --> Total execution time: 1.2987
INFO - 2023-07-30 16:59:52 --> Config Class Initialized
INFO - 2023-07-30 16:59:52 --> Hooks Class Initialized
DEBUG - 2023-07-30 16:59:52 --> UTF-8 Support Enabled
INFO - 2023-07-30 16:59:52 --> Utf8 Class Initialized
INFO - 2023-07-30 16:59:52 --> URI Class Initialized
INFO - 2023-07-30 16:59:52 --> Router Class Initialized
INFO - 2023-07-30 16:59:52 --> Output Class Initialized
INFO - 2023-07-30 16:59:52 --> Security Class Initialized
DEBUG - 2023-07-30 16:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 16:59:52 --> Input Class Initialized
INFO - 2023-07-30 16:59:52 --> Language Class Initialized
INFO - 2023-07-30 16:59:52 --> Language Class Initialized
INFO - 2023-07-30 16:59:52 --> Config Class Initialized
INFO - 2023-07-30 16:59:52 --> Loader Class Initialized
INFO - 2023-07-30 16:59:52 --> Helper loaded: url_helper
INFO - 2023-07-30 16:59:52 --> Helper loaded: file_helper
INFO - 2023-07-30 16:59:52 --> Helper loaded: form_helper
INFO - 2023-07-30 16:59:52 --> Helper loaded: my_helper
INFO - 2023-07-30 16:59:52 --> Database Driver Class Initialized
DEBUG - 2023-07-30 16:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 16:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 16:59:52 --> Controller Class Initialized
DEBUG - 2023-07-30 16:59:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-07-30 16:59:54 --> Final output sent to browser
DEBUG - 2023-07-30 16:59:54 --> Total execution time: 1.4488
INFO - 2023-07-30 17:00:04 --> Config Class Initialized
INFO - 2023-07-30 17:00:04 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:00:04 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:00:04 --> Utf8 Class Initialized
INFO - 2023-07-30 17:00:04 --> URI Class Initialized
INFO - 2023-07-30 17:00:04 --> Router Class Initialized
INFO - 2023-07-30 17:00:04 --> Output Class Initialized
INFO - 2023-07-30 17:00:04 --> Security Class Initialized
DEBUG - 2023-07-30 17:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:00:04 --> Input Class Initialized
INFO - 2023-07-30 17:00:04 --> Language Class Initialized
INFO - 2023-07-30 17:00:04 --> Language Class Initialized
INFO - 2023-07-30 17:00:04 --> Config Class Initialized
INFO - 2023-07-30 17:00:04 --> Loader Class Initialized
INFO - 2023-07-30 17:00:04 --> Helper loaded: url_helper
INFO - 2023-07-30 17:00:04 --> Helper loaded: file_helper
INFO - 2023-07-30 17:00:04 --> Helper loaded: form_helper
INFO - 2023-07-30 17:00:04 --> Helper loaded: my_helper
INFO - 2023-07-30 17:00:04 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:00:04 --> Controller Class Initialized
DEBUG - 2023-07-30 17:00:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 17:00:06 --> Final output sent to browser
DEBUG - 2023-07-30 17:00:06 --> Total execution time: 1.3701
INFO - 2023-07-30 17:00:24 --> Config Class Initialized
INFO - 2023-07-30 17:00:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:00:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:00:24 --> Utf8 Class Initialized
INFO - 2023-07-30 17:00:24 --> URI Class Initialized
INFO - 2023-07-30 17:00:24 --> Router Class Initialized
INFO - 2023-07-30 17:00:24 --> Output Class Initialized
INFO - 2023-07-30 17:00:24 --> Security Class Initialized
DEBUG - 2023-07-30 17:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:00:24 --> Input Class Initialized
INFO - 2023-07-30 17:00:24 --> Language Class Initialized
INFO - 2023-07-30 17:00:24 --> Language Class Initialized
INFO - 2023-07-30 17:00:24 --> Config Class Initialized
INFO - 2023-07-30 17:00:24 --> Loader Class Initialized
INFO - 2023-07-30 17:00:24 --> Helper loaded: url_helper
INFO - 2023-07-30 17:00:24 --> Helper loaded: file_helper
INFO - 2023-07-30 17:00:24 --> Helper loaded: form_helper
INFO - 2023-07-30 17:00:24 --> Helper loaded: my_helper
INFO - 2023-07-30 17:00:24 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:00:24 --> Controller Class Initialized
DEBUG - 2023-07-30 17:00:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-30 17:00:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:00:24 --> Final output sent to browser
DEBUG - 2023-07-30 17:00:24 --> Total execution time: 0.0647
INFO - 2023-07-30 17:00:25 --> Config Class Initialized
INFO - 2023-07-30 17:00:25 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:00:25 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:00:25 --> Utf8 Class Initialized
INFO - 2023-07-30 17:00:25 --> URI Class Initialized
INFO - 2023-07-30 17:00:25 --> Router Class Initialized
INFO - 2023-07-30 17:00:25 --> Output Class Initialized
INFO - 2023-07-30 17:00:25 --> Security Class Initialized
DEBUG - 2023-07-30 17:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:00:25 --> Input Class Initialized
INFO - 2023-07-30 17:00:25 --> Language Class Initialized
INFO - 2023-07-30 17:00:25 --> Language Class Initialized
INFO - 2023-07-30 17:00:25 --> Config Class Initialized
INFO - 2023-07-30 17:00:25 --> Loader Class Initialized
INFO - 2023-07-30 17:00:25 --> Helper loaded: url_helper
INFO - 2023-07-30 17:00:25 --> Helper loaded: file_helper
INFO - 2023-07-30 17:00:25 --> Helper loaded: form_helper
INFO - 2023-07-30 17:00:25 --> Helper loaded: my_helper
INFO - 2023-07-30 17:00:25 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:00:25 --> Controller Class Initialized
INFO - 2023-07-30 17:00:25 --> Final output sent to browser
DEBUG - 2023-07-30 17:00:25 --> Total execution time: 0.0382
INFO - 2023-07-30 17:00:28 --> Config Class Initialized
INFO - 2023-07-30 17:00:28 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:00:28 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:00:28 --> Utf8 Class Initialized
INFO - 2023-07-30 17:00:28 --> URI Class Initialized
INFO - 2023-07-30 17:00:28 --> Router Class Initialized
INFO - 2023-07-30 17:00:28 --> Output Class Initialized
INFO - 2023-07-30 17:00:28 --> Security Class Initialized
DEBUG - 2023-07-30 17:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:00:28 --> Input Class Initialized
INFO - 2023-07-30 17:00:28 --> Language Class Initialized
INFO - 2023-07-30 17:00:28 --> Language Class Initialized
INFO - 2023-07-30 17:00:28 --> Config Class Initialized
INFO - 2023-07-30 17:00:28 --> Loader Class Initialized
INFO - 2023-07-30 17:00:28 --> Helper loaded: url_helper
INFO - 2023-07-30 17:00:28 --> Helper loaded: file_helper
INFO - 2023-07-30 17:00:28 --> Helper loaded: form_helper
INFO - 2023-07-30 17:00:28 --> Helper loaded: my_helper
INFO - 2023-07-30 17:00:28 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:00:28 --> Controller Class Initialized
INFO - 2023-07-30 17:00:28 --> Final output sent to browser
DEBUG - 2023-07-30 17:00:28 --> Total execution time: 0.0445
INFO - 2023-07-30 17:00:31 --> Config Class Initialized
INFO - 2023-07-30 17:00:31 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:00:31 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:00:31 --> Utf8 Class Initialized
INFO - 2023-07-30 17:00:31 --> URI Class Initialized
INFO - 2023-07-30 17:00:31 --> Router Class Initialized
INFO - 2023-07-30 17:00:31 --> Output Class Initialized
INFO - 2023-07-30 17:00:31 --> Security Class Initialized
DEBUG - 2023-07-30 17:00:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:00:31 --> Input Class Initialized
INFO - 2023-07-30 17:00:31 --> Language Class Initialized
INFO - 2023-07-30 17:00:31 --> Language Class Initialized
INFO - 2023-07-30 17:00:31 --> Config Class Initialized
INFO - 2023-07-30 17:00:31 --> Loader Class Initialized
INFO - 2023-07-30 17:00:31 --> Helper loaded: url_helper
INFO - 2023-07-30 17:00:31 --> Helper loaded: file_helper
INFO - 2023-07-30 17:00:31 --> Helper loaded: form_helper
INFO - 2023-07-30 17:00:31 --> Helper loaded: my_helper
INFO - 2023-07-30 17:00:32 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:00:32 --> Controller Class Initialized
DEBUG - 2023-07-30 17:00:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 17:00:33 --> Final output sent to browser
DEBUG - 2023-07-30 17:00:33 --> Total execution time: 1.3993
INFO - 2023-07-30 17:02:56 --> Config Class Initialized
INFO - 2023-07-30 17:02:56 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:02:56 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:02:56 --> Utf8 Class Initialized
INFO - 2023-07-30 17:02:56 --> URI Class Initialized
INFO - 2023-07-30 17:02:56 --> Router Class Initialized
INFO - 2023-07-30 17:02:56 --> Output Class Initialized
INFO - 2023-07-30 17:02:56 --> Security Class Initialized
DEBUG - 2023-07-30 17:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:02:56 --> Input Class Initialized
INFO - 2023-07-30 17:02:56 --> Language Class Initialized
INFO - 2023-07-30 17:02:56 --> Language Class Initialized
INFO - 2023-07-30 17:02:56 --> Config Class Initialized
INFO - 2023-07-30 17:02:56 --> Loader Class Initialized
INFO - 2023-07-30 17:02:56 --> Helper loaded: url_helper
INFO - 2023-07-30 17:02:56 --> Helper loaded: file_helper
INFO - 2023-07-30 17:02:56 --> Helper loaded: form_helper
INFO - 2023-07-30 17:02:56 --> Helper loaded: my_helper
INFO - 2023-07-30 17:02:56 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:02:56 --> Controller Class Initialized
DEBUG - 2023-07-30 17:02:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 17:02:58 --> Final output sent to browser
DEBUG - 2023-07-30 17:02:58 --> Total execution time: 1.7093
INFO - 2023-07-30 17:04:19 --> Config Class Initialized
INFO - 2023-07-30 17:04:19 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:04:19 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:04:19 --> Utf8 Class Initialized
INFO - 2023-07-30 17:04:19 --> URI Class Initialized
INFO - 2023-07-30 17:04:19 --> Router Class Initialized
INFO - 2023-07-30 17:04:19 --> Output Class Initialized
INFO - 2023-07-30 17:04:19 --> Security Class Initialized
DEBUG - 2023-07-30 17:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:04:19 --> Input Class Initialized
INFO - 2023-07-30 17:04:19 --> Language Class Initialized
INFO - 2023-07-30 17:04:19 --> Language Class Initialized
INFO - 2023-07-30 17:04:19 --> Config Class Initialized
INFO - 2023-07-30 17:04:19 --> Loader Class Initialized
INFO - 2023-07-30 17:04:19 --> Helper loaded: url_helper
INFO - 2023-07-30 17:04:19 --> Helper loaded: file_helper
INFO - 2023-07-30 17:04:19 --> Helper loaded: form_helper
INFO - 2023-07-30 17:04:19 --> Helper loaded: my_helper
INFO - 2023-07-30 17:04:19 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:04:19 --> Controller Class Initialized
DEBUG - 2023-07-30 17:04:19 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 17:04:21 --> Final output sent to browser
DEBUG - 2023-07-30 17:04:21 --> Total execution time: 1.6566
INFO - 2023-07-30 17:05:21 --> Config Class Initialized
INFO - 2023-07-30 17:05:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:05:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:05:21 --> Utf8 Class Initialized
INFO - 2023-07-30 17:05:21 --> URI Class Initialized
INFO - 2023-07-30 17:05:21 --> Router Class Initialized
INFO - 2023-07-30 17:05:21 --> Output Class Initialized
INFO - 2023-07-30 17:05:21 --> Security Class Initialized
DEBUG - 2023-07-30 17:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:05:21 --> Input Class Initialized
INFO - 2023-07-30 17:05:21 --> Language Class Initialized
INFO - 2023-07-30 17:05:21 --> Language Class Initialized
INFO - 2023-07-30 17:05:21 --> Config Class Initialized
INFO - 2023-07-30 17:05:21 --> Loader Class Initialized
INFO - 2023-07-30 17:05:21 --> Helper loaded: url_helper
INFO - 2023-07-30 17:05:21 --> Helper loaded: file_helper
INFO - 2023-07-30 17:05:21 --> Helper loaded: form_helper
INFO - 2023-07-30 17:05:21 --> Helper loaded: my_helper
INFO - 2023-07-30 17:05:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:05:21 --> Controller Class Initialized
DEBUG - 2023-07-30 17:05:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-30 17:05:23 --> Final output sent to browser
DEBUG - 2023-07-30 17:05:23 --> Total execution time: 1.5257
INFO - 2023-07-30 17:05:26 --> Config Class Initialized
INFO - 2023-07-30 17:05:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:05:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:05:26 --> Utf8 Class Initialized
INFO - 2023-07-30 17:05:26 --> URI Class Initialized
INFO - 2023-07-30 17:05:26 --> Router Class Initialized
INFO - 2023-07-30 17:05:26 --> Output Class Initialized
INFO - 2023-07-30 17:05:26 --> Security Class Initialized
DEBUG - 2023-07-30 17:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:05:26 --> Input Class Initialized
INFO - 2023-07-30 17:05:26 --> Language Class Initialized
INFO - 2023-07-30 17:05:26 --> Language Class Initialized
INFO - 2023-07-30 17:05:26 --> Config Class Initialized
INFO - 2023-07-30 17:05:26 --> Loader Class Initialized
INFO - 2023-07-30 17:05:26 --> Helper loaded: url_helper
INFO - 2023-07-30 17:05:26 --> Helper loaded: file_helper
INFO - 2023-07-30 17:05:26 --> Helper loaded: form_helper
INFO - 2023-07-30 17:05:26 --> Helper loaded: my_helper
INFO - 2023-07-30 17:05:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:05:26 --> Controller Class Initialized
DEBUG - 2023-07-30 17:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot_sd.php
INFO - 2023-07-30 17:05:27 --> Final output sent to browser
DEBUG - 2023-07-30 17:05:27 --> Total execution time: 1.3826
INFO - 2023-07-30 17:08:09 --> Config Class Initialized
INFO - 2023-07-30 17:08:09 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:09 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:09 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:09 --> URI Class Initialized
INFO - 2023-07-30 17:08:09 --> Router Class Initialized
INFO - 2023-07-30 17:08:09 --> Output Class Initialized
INFO - 2023-07-30 17:08:09 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:09 --> Input Class Initialized
INFO - 2023-07-30 17:08:09 --> Language Class Initialized
INFO - 2023-07-30 17:08:09 --> Language Class Initialized
INFO - 2023-07-30 17:08:09 --> Config Class Initialized
INFO - 2023-07-30 17:08:09 --> Loader Class Initialized
INFO - 2023-07-30 17:08:09 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:09 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:09 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:09 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:09 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:09 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-30 17:08:09 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:09 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:09 --> Total execution time: 0.0468
INFO - 2023-07-30 17:08:10 --> Config Class Initialized
INFO - 2023-07-30 17:08:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:10 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:10 --> URI Class Initialized
INFO - 2023-07-30 17:08:10 --> Router Class Initialized
INFO - 2023-07-30 17:08:10 --> Output Class Initialized
INFO - 2023-07-30 17:08:10 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:10 --> Input Class Initialized
INFO - 2023-07-30 17:08:10 --> Language Class Initialized
INFO - 2023-07-30 17:08:10 --> Language Class Initialized
INFO - 2023-07-30 17:08:10 --> Config Class Initialized
INFO - 2023-07-30 17:08:10 --> Loader Class Initialized
INFO - 2023-07-30 17:08:10 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:10 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:10 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_icb/views/list.php
DEBUG - 2023-07-30 17:08:10 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:10 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:10 --> Total execution time: 0.0537
INFO - 2023-07-30 17:08:10 --> Config Class Initialized
INFO - 2023-07-30 17:08:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:10 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:10 --> URI Class Initialized
INFO - 2023-07-30 17:08:10 --> Router Class Initialized
INFO - 2023-07-30 17:08:10 --> Output Class Initialized
INFO - 2023-07-30 17:08:10 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:10 --> Input Class Initialized
INFO - 2023-07-30 17:08:10 --> Language Class Initialized
INFO - 2023-07-30 17:08:10 --> Language Class Initialized
INFO - 2023-07-30 17:08:10 --> Config Class Initialized
INFO - 2023-07-30 17:08:10 --> Loader Class Initialized
INFO - 2023-07-30 17:08:10 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:10 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:10 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:10 --> Controller Class Initialized
INFO - 2023-07-30 17:08:11 --> Config Class Initialized
INFO - 2023-07-30 17:08:11 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:11 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:11 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:11 --> URI Class Initialized
INFO - 2023-07-30 17:08:11 --> Router Class Initialized
INFO - 2023-07-30 17:08:11 --> Output Class Initialized
INFO - 2023-07-30 17:08:11 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:11 --> Input Class Initialized
INFO - 2023-07-30 17:08:11 --> Language Class Initialized
INFO - 2023-07-30 17:08:11 --> Language Class Initialized
INFO - 2023-07-30 17:08:11 --> Config Class Initialized
INFO - 2023-07-30 17:08:11 --> Loader Class Initialized
INFO - 2023-07-30 17:08:11 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:11 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:11 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:11 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:11 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:11 --> Controller Class Initialized
INFO - 2023-07-30 17:08:11 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:11 --> Total execution time: 0.0556
INFO - 2023-07-30 17:08:15 --> Config Class Initialized
INFO - 2023-07-30 17:08:15 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:15 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:15 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:15 --> URI Class Initialized
INFO - 2023-07-30 17:08:15 --> Router Class Initialized
INFO - 2023-07-30 17:08:15 --> Output Class Initialized
INFO - 2023-07-30 17:08:15 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:15 --> Input Class Initialized
INFO - 2023-07-30 17:08:15 --> Language Class Initialized
INFO - 2023-07-30 17:08:15 --> Language Class Initialized
INFO - 2023-07-30 17:08:15 --> Config Class Initialized
INFO - 2023-07-30 17:08:15 --> Loader Class Initialized
INFO - 2023-07-30 17:08:15 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:15 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:15 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:15 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:15 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:15 --> Controller Class Initialized
INFO - 2023-07-30 17:08:15 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:15 --> Total execution time: 0.0607
INFO - 2023-07-30 17:08:16 --> Config Class Initialized
INFO - 2023-07-30 17:08:16 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:16 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:16 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:16 --> URI Class Initialized
INFO - 2023-07-30 17:08:16 --> Router Class Initialized
INFO - 2023-07-30 17:08:16 --> Output Class Initialized
INFO - 2023-07-30 17:08:16 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:16 --> Input Class Initialized
INFO - 2023-07-30 17:08:16 --> Language Class Initialized
INFO - 2023-07-30 17:08:16 --> Language Class Initialized
INFO - 2023-07-30 17:08:16 --> Config Class Initialized
INFO - 2023-07-30 17:08:16 --> Loader Class Initialized
INFO - 2023-07-30 17:08:16 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:16 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:16 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:16 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:16 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:16 --> Controller Class Initialized
INFO - 2023-07-30 17:08:16 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:16 --> Total execution time: 0.0457
INFO - 2023-07-30 17:08:21 --> Config Class Initialized
INFO - 2023-07-30 17:08:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:21 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:21 --> URI Class Initialized
INFO - 2023-07-30 17:08:21 --> Router Class Initialized
INFO - 2023-07-30 17:08:21 --> Output Class Initialized
INFO - 2023-07-30 17:08:21 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:21 --> Input Class Initialized
INFO - 2023-07-30 17:08:21 --> Language Class Initialized
INFO - 2023-07-30 17:08:21 --> Language Class Initialized
INFO - 2023-07-30 17:08:21 --> Config Class Initialized
INFO - 2023-07-30 17:08:21 --> Loader Class Initialized
INFO - 2023-07-30 17:08:21 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:21 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:21 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:21 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:21 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-30 17:08:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:21 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:21 --> Total execution time: 0.0663
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:24 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:24 --> URI Class Initialized
INFO - 2023-07-30 17:08:24 --> Router Class Initialized
INFO - 2023-07-30 17:08:24 --> Output Class Initialized
INFO - 2023-07-30 17:08:24 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:24 --> Input Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Loader Class Initialized
INFO - 2023-07-30 17:08:24 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:24 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:24 --> Controller Class Initialized
INFO - 2023-07-30 17:08:24 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:24 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:24 --> URI Class Initialized
INFO - 2023-07-30 17:08:24 --> Router Class Initialized
INFO - 2023-07-30 17:08:24 --> Output Class Initialized
INFO - 2023-07-30 17:08:24 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:24 --> Input Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Loader Class Initialized
INFO - 2023-07-30 17:08:24 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:24 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:24 --> Controller Class Initialized
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:24 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:24 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:24 --> URI Class Initialized
INFO - 2023-07-30 17:08:24 --> Router Class Initialized
INFO - 2023-07-30 17:08:24 --> Output Class Initialized
INFO - 2023-07-30 17:08:24 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:24 --> Input Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Language Class Initialized
INFO - 2023-07-30 17:08:24 --> Config Class Initialized
INFO - 2023-07-30 17:08:24 --> Loader Class Initialized
INFO - 2023-07-30 17:08:24 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:24 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:24 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:24 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-30 17:08:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:24 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:24 --> Total execution time: 0.0387
INFO - 2023-07-30 17:08:40 --> Config Class Initialized
INFO - 2023-07-30 17:08:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:40 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:40 --> URI Class Initialized
INFO - 2023-07-30 17:08:40 --> Router Class Initialized
INFO - 2023-07-30 17:08:40 --> Output Class Initialized
INFO - 2023-07-30 17:08:40 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:40 --> Input Class Initialized
INFO - 2023-07-30 17:08:40 --> Language Class Initialized
INFO - 2023-07-30 17:08:40 --> Language Class Initialized
INFO - 2023-07-30 17:08:40 --> Config Class Initialized
INFO - 2023-07-30 17:08:40 --> Loader Class Initialized
INFO - 2023-07-30 17:08:40 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:40 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:40 --> Controller Class Initialized
INFO - 2023-07-30 17:08:40 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:08:40 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:40 --> Total execution time: 0.0525
INFO - 2023-07-30 17:08:40 --> Config Class Initialized
INFO - 2023-07-30 17:08:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:40 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:40 --> URI Class Initialized
INFO - 2023-07-30 17:08:40 --> Router Class Initialized
INFO - 2023-07-30 17:08:40 --> Output Class Initialized
INFO - 2023-07-30 17:08:40 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:40 --> Input Class Initialized
INFO - 2023-07-30 17:08:40 --> Language Class Initialized
INFO - 2023-07-30 17:08:40 --> Language Class Initialized
INFO - 2023-07-30 17:08:40 --> Config Class Initialized
INFO - 2023-07-30 17:08:40 --> Loader Class Initialized
INFO - 2023-07-30 17:08:40 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:40 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:40 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:40 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-30 17:08:40 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:40 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:40 --> Total execution time: 0.0615
INFO - 2023-07-30 17:08:41 --> Config Class Initialized
INFO - 2023-07-30 17:08:41 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:41 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:41 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:41 --> URI Class Initialized
INFO - 2023-07-30 17:08:41 --> Router Class Initialized
INFO - 2023-07-30 17:08:41 --> Output Class Initialized
INFO - 2023-07-30 17:08:41 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:41 --> Input Class Initialized
INFO - 2023-07-30 17:08:41 --> Language Class Initialized
INFO - 2023-07-30 17:08:41 --> Language Class Initialized
INFO - 2023-07-30 17:08:41 --> Config Class Initialized
INFO - 2023-07-30 17:08:41 --> Loader Class Initialized
INFO - 2023-07-30 17:08:41 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:41 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:41 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:41 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:41 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:41 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-30 17:08:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:42 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:42 --> Total execution time: 0.0574
INFO - 2023-07-30 17:08:43 --> Config Class Initialized
INFO - 2023-07-30 17:08:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:43 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:43 --> URI Class Initialized
INFO - 2023-07-30 17:08:43 --> Router Class Initialized
INFO - 2023-07-30 17:08:43 --> Output Class Initialized
INFO - 2023-07-30 17:08:43 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:43 --> Input Class Initialized
INFO - 2023-07-30 17:08:43 --> Language Class Initialized
INFO - 2023-07-30 17:08:43 --> Language Class Initialized
INFO - 2023-07-30 17:08:43 --> Config Class Initialized
INFO - 2023-07-30 17:08:43 --> Loader Class Initialized
INFO - 2023-07-30 17:08:43 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:43 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:43 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-30 17:08:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:43 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:43 --> Total execution time: 0.0553
INFO - 2023-07-30 17:08:43 --> Config Class Initialized
INFO - 2023-07-30 17:08:43 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:43 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:43 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:43 --> URI Class Initialized
INFO - 2023-07-30 17:08:43 --> Router Class Initialized
INFO - 2023-07-30 17:08:43 --> Output Class Initialized
INFO - 2023-07-30 17:08:43 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:43 --> Input Class Initialized
INFO - 2023-07-30 17:08:43 --> Language Class Initialized
INFO - 2023-07-30 17:08:43 --> Language Class Initialized
INFO - 2023-07-30 17:08:43 --> Config Class Initialized
INFO - 2023-07-30 17:08:43 --> Loader Class Initialized
INFO - 2023-07-30 17:08:43 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:43 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:43 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:43 --> Controller Class Initialized
INFO - 2023-07-30 17:08:45 --> Config Class Initialized
INFO - 2023-07-30 17:08:45 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:45 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:45 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:45 --> URI Class Initialized
INFO - 2023-07-30 17:08:45 --> Router Class Initialized
INFO - 2023-07-30 17:08:45 --> Output Class Initialized
INFO - 2023-07-30 17:08:45 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:45 --> Input Class Initialized
INFO - 2023-07-30 17:08:45 --> Language Class Initialized
INFO - 2023-07-30 17:08:45 --> Language Class Initialized
INFO - 2023-07-30 17:08:45 --> Config Class Initialized
INFO - 2023-07-30 17:08:45 --> Loader Class Initialized
INFO - 2023-07-30 17:08:45 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:45 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:45 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:45 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:45 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:45 --> Controller Class Initialized
INFO - 2023-07-30 17:08:45 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:45 --> Total execution time: 0.0554
INFO - 2023-07-30 17:08:46 --> Config Class Initialized
INFO - 2023-07-30 17:08:46 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:46 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:46 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:46 --> URI Class Initialized
INFO - 2023-07-30 17:08:46 --> Router Class Initialized
INFO - 2023-07-30 17:08:46 --> Output Class Initialized
INFO - 2023-07-30 17:08:46 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:46 --> Input Class Initialized
INFO - 2023-07-30 17:08:46 --> Language Class Initialized
INFO - 2023-07-30 17:08:46 --> Language Class Initialized
INFO - 2023-07-30 17:08:46 --> Config Class Initialized
INFO - 2023-07-30 17:08:46 --> Loader Class Initialized
INFO - 2023-07-30 17:08:46 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:46 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:46 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:46 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:46 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:46 --> Controller Class Initialized
INFO - 2023-07-30 17:08:46 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:46 --> Total execution time: 0.0526
INFO - 2023-07-30 17:08:48 --> Config Class Initialized
INFO - 2023-07-30 17:08:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:48 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:48 --> URI Class Initialized
INFO - 2023-07-30 17:08:48 --> Router Class Initialized
INFO - 2023-07-30 17:08:48 --> Output Class Initialized
INFO - 2023-07-30 17:08:48 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:48 --> Input Class Initialized
INFO - 2023-07-30 17:08:48 --> Language Class Initialized
INFO - 2023-07-30 17:08:48 --> Language Class Initialized
INFO - 2023-07-30 17:08:48 --> Config Class Initialized
INFO - 2023-07-30 17:08:48 --> Loader Class Initialized
INFO - 2023-07-30 17:08:48 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:48 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:48 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:48 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:48 --> Controller Class Initialized
INFO - 2023-07-30 17:08:48 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:48 --> Total execution time: 0.0453
INFO - 2023-07-30 17:08:50 --> Config Class Initialized
INFO - 2023-07-30 17:08:50 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:50 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:50 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:50 --> URI Class Initialized
INFO - 2023-07-30 17:08:50 --> Router Class Initialized
INFO - 2023-07-30 17:08:50 --> Output Class Initialized
INFO - 2023-07-30 17:08:50 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:50 --> Input Class Initialized
INFO - 2023-07-30 17:08:50 --> Language Class Initialized
INFO - 2023-07-30 17:08:50 --> Language Class Initialized
INFO - 2023-07-30 17:08:50 --> Config Class Initialized
INFO - 2023-07-30 17:08:50 --> Loader Class Initialized
INFO - 2023-07-30 17:08:50 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:50 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:50 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:50 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:50 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:50 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-30 17:08:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:50 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:50 --> Total execution time: 0.0616
INFO - 2023-07-30 17:08:51 --> Config Class Initialized
INFO - 2023-07-30 17:08:51 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:51 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:51 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:51 --> URI Class Initialized
INFO - 2023-07-30 17:08:51 --> Router Class Initialized
INFO - 2023-07-30 17:08:51 --> Output Class Initialized
INFO - 2023-07-30 17:08:51 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:51 --> Input Class Initialized
INFO - 2023-07-30 17:08:51 --> Language Class Initialized
INFO - 2023-07-30 17:08:51 --> Language Class Initialized
INFO - 2023-07-30 17:08:51 --> Config Class Initialized
INFO - 2023-07-30 17:08:51 --> Loader Class Initialized
INFO - 2023-07-30 17:08:51 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:51 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:51 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:51 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:51 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:51 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-07-30 17:08:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:51 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:51 --> Total execution time: 0.0571
INFO - 2023-07-30 17:08:52 --> Config Class Initialized
INFO - 2023-07-30 17:08:52 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:52 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:52 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:52 --> URI Class Initialized
INFO - 2023-07-30 17:08:52 --> Router Class Initialized
INFO - 2023-07-30 17:08:52 --> Output Class Initialized
INFO - 2023-07-30 17:08:52 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:52 --> Input Class Initialized
INFO - 2023-07-30 17:08:52 --> Language Class Initialized
INFO - 2023-07-30 17:08:52 --> Language Class Initialized
INFO - 2023-07-30 17:08:52 --> Config Class Initialized
INFO - 2023-07-30 17:08:52 --> Loader Class Initialized
INFO - 2023-07-30 17:08:52 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:52 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:52 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:52 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:53 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:53 --> Controller Class Initialized
INFO - 2023-07-30 17:08:53 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:53 --> Total execution time: 0.0548
INFO - 2023-07-30 17:08:54 --> Config Class Initialized
INFO - 2023-07-30 17:08:54 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:54 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:54 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:54 --> URI Class Initialized
INFO - 2023-07-30 17:08:54 --> Router Class Initialized
INFO - 2023-07-30 17:08:54 --> Output Class Initialized
INFO - 2023-07-30 17:08:54 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:54 --> Input Class Initialized
INFO - 2023-07-30 17:08:54 --> Language Class Initialized
INFO - 2023-07-30 17:08:54 --> Language Class Initialized
INFO - 2023-07-30 17:08:54 --> Config Class Initialized
INFO - 2023-07-30 17:08:54 --> Loader Class Initialized
INFO - 2023-07-30 17:08:54 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:54 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:54 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:54 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:54 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:54 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-30 17:08:54 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:54 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:54 --> Total execution time: 0.0602
INFO - 2023-07-30 17:08:55 --> Config Class Initialized
INFO - 2023-07-30 17:08:55 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:55 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:55 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:55 --> URI Class Initialized
INFO - 2023-07-30 17:08:55 --> Router Class Initialized
INFO - 2023-07-30 17:08:55 --> Output Class Initialized
INFO - 2023-07-30 17:08:55 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:55 --> Input Class Initialized
INFO - 2023-07-30 17:08:55 --> Language Class Initialized
INFO - 2023-07-30 17:08:55 --> Language Class Initialized
INFO - 2023-07-30 17:08:55 --> Config Class Initialized
INFO - 2023-07-30 17:08:55 --> Loader Class Initialized
INFO - 2023-07-30 17:08:55 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:55 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:55 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:55 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:55 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:56 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-07-30 17:08:56 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:56 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:56 --> Total execution time: 0.0555
INFO - 2023-07-30 17:08:57 --> Config Class Initialized
INFO - 2023-07-30 17:08:57 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:57 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:57 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:57 --> URI Class Initialized
INFO - 2023-07-30 17:08:57 --> Router Class Initialized
INFO - 2023-07-30 17:08:57 --> Output Class Initialized
INFO - 2023-07-30 17:08:57 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:57 --> Input Class Initialized
INFO - 2023-07-30 17:08:57 --> Language Class Initialized
INFO - 2023-07-30 17:08:57 --> Language Class Initialized
INFO - 2023-07-30 17:08:57 --> Config Class Initialized
INFO - 2023-07-30 17:08:57 --> Loader Class Initialized
INFO - 2023-07-30 17:08:57 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:57 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:57 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:57 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:57 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:57 --> Controller Class Initialized
INFO - 2023-07-30 17:08:57 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:57 --> Total execution time: 0.0585
INFO - 2023-07-30 17:08:59 --> Config Class Initialized
INFO - 2023-07-30 17:08:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:08:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:08:59 --> Utf8 Class Initialized
INFO - 2023-07-30 17:08:59 --> URI Class Initialized
DEBUG - 2023-07-30 17:08:59 --> No URI present. Default controller set.
INFO - 2023-07-30 17:08:59 --> Router Class Initialized
INFO - 2023-07-30 17:08:59 --> Output Class Initialized
INFO - 2023-07-30 17:08:59 --> Security Class Initialized
DEBUG - 2023-07-30 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:08:59 --> Input Class Initialized
INFO - 2023-07-30 17:08:59 --> Language Class Initialized
INFO - 2023-07-30 17:08:59 --> Language Class Initialized
INFO - 2023-07-30 17:08:59 --> Config Class Initialized
INFO - 2023-07-30 17:08:59 --> Loader Class Initialized
INFO - 2023-07-30 17:08:59 --> Helper loaded: url_helper
INFO - 2023-07-30 17:08:59 --> Helper loaded: file_helper
INFO - 2023-07-30 17:08:59 --> Helper loaded: form_helper
INFO - 2023-07-30 17:08:59 --> Helper loaded: my_helper
INFO - 2023-07-30 17:08:59 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:08:59 --> Controller Class Initialized
DEBUG - 2023-07-30 17:08:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-30 17:08:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:08:59 --> Final output sent to browser
DEBUG - 2023-07-30 17:08:59 --> Total execution time: 0.0645
INFO - 2023-07-30 17:36:59 --> Config Class Initialized
INFO - 2023-07-30 17:36:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:36:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:36:59 --> Utf8 Class Initialized
INFO - 2023-07-30 17:36:59 --> URI Class Initialized
DEBUG - 2023-07-30 17:36:59 --> No URI present. Default controller set.
INFO - 2023-07-30 17:36:59 --> Router Class Initialized
INFO - 2023-07-30 17:36:59 --> Output Class Initialized
INFO - 2023-07-30 17:36:59 --> Security Class Initialized
DEBUG - 2023-07-30 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:36:59 --> Input Class Initialized
INFO - 2023-07-30 17:36:59 --> Language Class Initialized
INFO - 2023-07-30 17:36:59 --> Language Class Initialized
INFO - 2023-07-30 17:36:59 --> Config Class Initialized
INFO - 2023-07-30 17:36:59 --> Loader Class Initialized
INFO - 2023-07-30 17:36:59 --> Helper loaded: url_helper
INFO - 2023-07-30 17:36:59 --> Helper loaded: file_helper
INFO - 2023-07-30 17:36:59 --> Helper loaded: form_helper
INFO - 2023-07-30 17:36:59 --> Helper loaded: my_helper
INFO - 2023-07-30 17:36:59 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:36:59 --> Controller Class Initialized
DEBUG - 2023-07-30 17:36:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-30 17:36:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:36:59 --> Final output sent to browser
DEBUG - 2023-07-30 17:36:59 --> Total execution time: 0.0680
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:11 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:11 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:11 --> URI Class Initialized
INFO - 2023-07-30 17:37:11 --> Router Class Initialized
INFO - 2023-07-30 17:37:11 --> Output Class Initialized
INFO - 2023-07-30 17:37:11 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:11 --> Input Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Loader Class Initialized
INFO - 2023-07-30 17:37:11 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:11 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:11 --> Controller Class Initialized
INFO - 2023-07-30 17:37:11 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:11 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:11 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:11 --> URI Class Initialized
INFO - 2023-07-30 17:37:11 --> Router Class Initialized
INFO - 2023-07-30 17:37:11 --> Output Class Initialized
INFO - 2023-07-30 17:37:11 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:11 --> Input Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Loader Class Initialized
INFO - 2023-07-30 17:37:11 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:11 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:11 --> Controller Class Initialized
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:11 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:11 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:11 --> URI Class Initialized
INFO - 2023-07-30 17:37:11 --> Router Class Initialized
INFO - 2023-07-30 17:37:11 --> Output Class Initialized
INFO - 2023-07-30 17:37:11 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:11 --> Input Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Language Class Initialized
INFO - 2023-07-30 17:37:11 --> Config Class Initialized
INFO - 2023-07-30 17:37:11 --> Loader Class Initialized
INFO - 2023-07-30 17:37:11 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:11 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:11 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:12 --> Controller Class Initialized
DEBUG - 2023-07-30 17:37:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-30 17:37:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:37:12 --> Final output sent to browser
DEBUG - 2023-07-30 17:37:12 --> Total execution time: 0.0350
INFO - 2023-07-30 17:37:17 --> Config Class Initialized
INFO - 2023-07-30 17:37:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:17 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:17 --> URI Class Initialized
INFO - 2023-07-30 17:37:17 --> Router Class Initialized
INFO - 2023-07-30 17:37:17 --> Output Class Initialized
INFO - 2023-07-30 17:37:17 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:17 --> Input Class Initialized
INFO - 2023-07-30 17:37:17 --> Language Class Initialized
INFO - 2023-07-30 17:37:17 --> Language Class Initialized
INFO - 2023-07-30 17:37:17 --> Config Class Initialized
INFO - 2023-07-30 17:37:17 --> Loader Class Initialized
INFO - 2023-07-30 17:37:17 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:17 --> Controller Class Initialized
INFO - 2023-07-30 17:37:17 --> Helper loaded: cookie_helper
INFO - 2023-07-30 17:37:17 --> Final output sent to browser
DEBUG - 2023-07-30 17:37:17 --> Total execution time: 0.0442
INFO - 2023-07-30 17:37:17 --> Config Class Initialized
INFO - 2023-07-30 17:37:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:17 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:17 --> URI Class Initialized
INFO - 2023-07-30 17:37:17 --> Router Class Initialized
INFO - 2023-07-30 17:37:17 --> Output Class Initialized
INFO - 2023-07-30 17:37:17 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:17 --> Input Class Initialized
INFO - 2023-07-30 17:37:17 --> Language Class Initialized
INFO - 2023-07-30 17:37:17 --> Language Class Initialized
INFO - 2023-07-30 17:37:17 --> Config Class Initialized
INFO - 2023-07-30 17:37:17 --> Loader Class Initialized
INFO - 2023-07-30 17:37:17 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:17 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:17 --> Controller Class Initialized
DEBUG - 2023-07-30 17:37:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-30 17:37:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:37:17 --> Final output sent to browser
DEBUG - 2023-07-30 17:37:17 --> Total execution time: 0.0553
INFO - 2023-07-30 17:37:26 --> Config Class Initialized
INFO - 2023-07-30 17:37:26 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:26 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:26 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:26 --> URI Class Initialized
INFO - 2023-07-30 17:37:26 --> Router Class Initialized
INFO - 2023-07-30 17:37:26 --> Output Class Initialized
INFO - 2023-07-30 17:37:26 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:26 --> Input Class Initialized
INFO - 2023-07-30 17:37:26 --> Language Class Initialized
INFO - 2023-07-30 17:37:26 --> Language Class Initialized
INFO - 2023-07-30 17:37:26 --> Config Class Initialized
INFO - 2023-07-30 17:37:26 --> Loader Class Initialized
INFO - 2023-07-30 17:37:26 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:26 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:26 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:26 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:26 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:26 --> Controller Class Initialized
DEBUG - 2023-07-30 17:37:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-30 17:37:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:37:26 --> Final output sent to browser
DEBUG - 2023-07-30 17:37:26 --> Total execution time: 0.0558
INFO - 2023-07-30 17:37:29 --> Config Class Initialized
INFO - 2023-07-30 17:37:29 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:29 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:29 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:29 --> URI Class Initialized
INFO - 2023-07-30 17:37:29 --> Router Class Initialized
INFO - 2023-07-30 17:37:29 --> Output Class Initialized
INFO - 2023-07-30 17:37:29 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:29 --> Input Class Initialized
INFO - 2023-07-30 17:37:29 --> Language Class Initialized
INFO - 2023-07-30 17:37:29 --> Language Class Initialized
INFO - 2023-07-30 17:37:29 --> Config Class Initialized
INFO - 2023-07-30 17:37:29 --> Loader Class Initialized
INFO - 2023-07-30 17:37:29 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:29 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:29 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:29 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:29 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:29 --> Controller Class Initialized
ERROR - 2023-07-30 17:37:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila&rsquo;s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du&rsquo;a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher&rsquo;s guidance. ', catatan_final = 'Akila needs encouragement in
participating daily dua in the
classroom also for murojaah time.
She still needs to be more focused
on reading iqra when btq. She also
need more practice in memorizing
doa masuk kamar mandi, doa keluar
kamar mandi, doa bangun tidur. Akila
needs practice to memorize hijaiyah
letters. She needs more practice to
recognize halal and haram food.
Akila also needs more practice to tidy
up her prayer set. ' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-07-30 17:37:29 --> Language file loaded: language/english/db_lang.php
INFO - 2023-07-30 17:37:36 --> Config Class Initialized
INFO - 2023-07-30 17:37:36 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:36 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:36 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:36 --> URI Class Initialized
INFO - 2023-07-30 17:37:36 --> Router Class Initialized
INFO - 2023-07-30 17:37:36 --> Output Class Initialized
INFO - 2023-07-30 17:37:36 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:36 --> Input Class Initialized
INFO - 2023-07-30 17:37:36 --> Language Class Initialized
INFO - 2023-07-30 17:37:36 --> Language Class Initialized
INFO - 2023-07-30 17:37:36 --> Config Class Initialized
INFO - 2023-07-30 17:37:36 --> Loader Class Initialized
INFO - 2023-07-30 17:37:36 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:36 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:36 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:36 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:36 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:36 --> Controller Class Initialized
DEBUG - 2023-07-30 17:37:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-30 17:37:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:37:36 --> Final output sent to browser
DEBUG - 2023-07-30 17:37:36 --> Total execution time: 0.0414
INFO - 2023-07-30 17:37:40 --> Config Class Initialized
INFO - 2023-07-30 17:37:40 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:40 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:40 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:40 --> URI Class Initialized
INFO - 2023-07-30 17:37:40 --> Router Class Initialized
INFO - 2023-07-30 17:37:40 --> Output Class Initialized
INFO - 2023-07-30 17:37:40 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:40 --> Input Class Initialized
INFO - 2023-07-30 17:37:40 --> Language Class Initialized
ERROR - 2023-07-30 17:37:40 --> 404 Page Not Found: /index
INFO - 2023-07-30 17:37:44 --> Config Class Initialized
INFO - 2023-07-30 17:37:44 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:37:44 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:37:44 --> Utf8 Class Initialized
INFO - 2023-07-30 17:37:44 --> URI Class Initialized
INFO - 2023-07-30 17:37:44 --> Router Class Initialized
INFO - 2023-07-30 17:37:44 --> Output Class Initialized
INFO - 2023-07-30 17:37:44 --> Security Class Initialized
DEBUG - 2023-07-30 17:37:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:37:44 --> Input Class Initialized
INFO - 2023-07-30 17:37:44 --> Language Class Initialized
INFO - 2023-07-30 17:37:44 --> Language Class Initialized
INFO - 2023-07-30 17:37:44 --> Config Class Initialized
INFO - 2023-07-30 17:37:44 --> Loader Class Initialized
INFO - 2023-07-30 17:37:44 --> Helper loaded: url_helper
INFO - 2023-07-30 17:37:44 --> Helper loaded: file_helper
INFO - 2023-07-30 17:37:44 --> Helper loaded: form_helper
INFO - 2023-07-30 17:37:44 --> Helper loaded: my_helper
INFO - 2023-07-30 17:37:44 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:37:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:37:44 --> Controller Class Initialized
ERROR - 2023-07-30 17:37:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near ') . She is also
able to recite ta'awwuz before reading iqra and recite shoda...' at line 1 - Invalid query: UPDATE t_catatan_nna SET  catatan_mid = 'Alhamdulillah Akila&rsquo;s Islamic values have improved as expected She is now in iqra 1
page 9 . Akila is able to recognize hijaiyah letters ا until ج) jim), ح) ha') . She is also
able to recite ta'awwuz before reading iqra and recite shodaqallahul adzim after
ending. She is able to follow kalimat thayyibah such as : alhamdulillah, astaghfirullah
, subhanallah, allahu akbar. Akila is also able to recite some du&rsquo;a, they are : doa
kedua orang tua, doa pembuka hati, doa before study and doa sebelum makan. She
is also able to recite hadith kasih sayang, hadith adab makan, and hadith sholat
adalah cahaya, hadith saling memberi hadiah independently. From Imtaq Center, she
is able to mention the name of the god of Muslims, namely Allah SWT and the name
of the Prophet, namely Prophet Muhammad SAW. She is also able to mention the
sequence of wudhu while playing games. She has learned of some names of Nabi
and malaikat Allah from the stories like Nabi Muhammad SAW, Nabi Sulaiman AS
and Nabi Ibrahim AS. Akila also learned about Asmaul Husna which are ar-rahman
until al-qahhar by singing and started to be able to memorize it until al- qahhar with
teacher&rsquo;s guidance. ', catatan_final = 'Akila needs encouragement in
participating daily dua in the
classroom also for murojaah time.
She still needs to be more focused
on reading iqra when btq. She also
need more practice in memorizing
doa masuk kamar mandi, doa keluar
kamar mandi, doa bangun tidur. Akila
needs practice to memorize hijaiyah
letters. She needs more practice to
recognize halal and haram food.
Akila also needs more practice to tidy
up her prayer set. ' WHERE ta = '20232' AND id_siswa = '531'
INFO - 2023-07-30 17:37:44 --> Language file loaded: language/english/db_lang.php
INFO - 2023-07-30 17:39:59 --> Config Class Initialized
INFO - 2023-07-30 17:39:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:39:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:39:59 --> Utf8 Class Initialized
INFO - 2023-07-30 17:39:59 --> URI Class Initialized
INFO - 2023-07-30 17:39:59 --> Router Class Initialized
INFO - 2023-07-30 17:39:59 --> Output Class Initialized
INFO - 2023-07-30 17:39:59 --> Security Class Initialized
DEBUG - 2023-07-30 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:39:59 --> Input Class Initialized
INFO - 2023-07-30 17:39:59 --> Language Class Initialized
INFO - 2023-07-30 17:39:59 --> Language Class Initialized
INFO - 2023-07-30 17:39:59 --> Config Class Initialized
INFO - 2023-07-30 17:39:59 --> Loader Class Initialized
INFO - 2023-07-30 17:39:59 --> Helper loaded: url_helper
INFO - 2023-07-30 17:39:59 --> Helper loaded: file_helper
INFO - 2023-07-30 17:39:59 --> Helper loaded: form_helper
INFO - 2023-07-30 17:39:59 --> Helper loaded: my_helper
INFO - 2023-07-30 17:39:59 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:39:59 --> Controller Class Initialized
DEBUG - 2023-07-30 17:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-30 17:39:59 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:39:59 --> Final output sent to browser
DEBUG - 2023-07-30 17:39:59 --> Total execution time: 0.1175
INFO - 2023-07-30 17:39:59 --> Config Class Initialized
INFO - 2023-07-30 17:39:59 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:39:59 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:39:59 --> Utf8 Class Initialized
INFO - 2023-07-30 17:39:59 --> URI Class Initialized
INFO - 2023-07-30 17:39:59 --> Router Class Initialized
INFO - 2023-07-30 17:39:59 --> Output Class Initialized
INFO - 2023-07-30 17:39:59 --> Security Class Initialized
DEBUG - 2023-07-30 17:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:39:59 --> Input Class Initialized
INFO - 2023-07-30 17:39:59 --> Language Class Initialized
ERROR - 2023-07-30 17:39:59 --> 404 Page Not Found: /index
INFO - 2023-07-30 17:40:04 --> Config Class Initialized
INFO - 2023-07-30 17:40:04 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:40:04 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:40:04 --> Utf8 Class Initialized
INFO - 2023-07-30 17:40:04 --> URI Class Initialized
INFO - 2023-07-30 17:40:04 --> Router Class Initialized
INFO - 2023-07-30 17:40:04 --> Output Class Initialized
INFO - 2023-07-30 17:40:04 --> Security Class Initialized
DEBUG - 2023-07-30 17:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:40:04 --> Input Class Initialized
INFO - 2023-07-30 17:40:04 --> Language Class Initialized
INFO - 2023-07-30 17:40:04 --> Language Class Initialized
INFO - 2023-07-30 17:40:04 --> Config Class Initialized
INFO - 2023-07-30 17:40:04 --> Loader Class Initialized
INFO - 2023-07-30 17:40:04 --> Helper loaded: url_helper
INFO - 2023-07-30 17:40:04 --> Helper loaded: file_helper
INFO - 2023-07-30 17:40:04 --> Helper loaded: form_helper
INFO - 2023-07-30 17:40:04 --> Helper loaded: my_helper
INFO - 2023-07-30 17:40:04 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:40:05 --> Controller Class Initialized
INFO - 2023-07-30 17:40:05 --> Final output sent to browser
DEBUG - 2023-07-30 17:40:05 --> Total execution time: 0.0731
INFO - 2023-07-30 17:42:10 --> Config Class Initialized
INFO - 2023-07-30 17:42:10 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:10 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:10 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:10 --> URI Class Initialized
INFO - 2023-07-30 17:42:10 --> Router Class Initialized
INFO - 2023-07-30 17:42:10 --> Output Class Initialized
INFO - 2023-07-30 17:42:10 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:10 --> Input Class Initialized
INFO - 2023-07-30 17:42:10 --> Language Class Initialized
INFO - 2023-07-30 17:42:10 --> Language Class Initialized
INFO - 2023-07-30 17:42:10 --> Config Class Initialized
INFO - 2023-07-30 17:42:10 --> Loader Class Initialized
INFO - 2023-07-30 17:42:10 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:10 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:10 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:10 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:10 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:10 --> Controller Class Initialized
INFO - 2023-07-30 17:42:12 --> Config Class Initialized
INFO - 2023-07-30 17:42:12 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:12 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:12 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:12 --> URI Class Initialized
INFO - 2023-07-30 17:42:12 --> Router Class Initialized
INFO - 2023-07-30 17:42:12 --> Output Class Initialized
INFO - 2023-07-30 17:42:12 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:12 --> Input Class Initialized
INFO - 2023-07-30 17:42:12 --> Language Class Initialized
INFO - 2023-07-30 17:42:12 --> Language Class Initialized
INFO - 2023-07-30 17:42:12 --> Config Class Initialized
INFO - 2023-07-30 17:42:12 --> Loader Class Initialized
INFO - 2023-07-30 17:42:12 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:12 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:12 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:12 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:12 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:12 --> Controller Class Initialized
DEBUG - 2023-07-30 17:42:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/form.php
DEBUG - 2023-07-30 17:42:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:42:12 --> Final output sent to browser
DEBUG - 2023-07-30 17:42:12 --> Total execution time: 0.0576
INFO - 2023-07-30 17:42:17 --> Config Class Initialized
INFO - 2023-07-30 17:42:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:17 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:17 --> URI Class Initialized
INFO - 2023-07-30 17:42:17 --> Router Class Initialized
INFO - 2023-07-30 17:42:17 --> Output Class Initialized
INFO - 2023-07-30 17:42:17 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:17 --> Input Class Initialized
INFO - 2023-07-30 17:42:17 --> Language Class Initialized
INFO - 2023-07-30 17:42:17 --> Language Class Initialized
INFO - 2023-07-30 17:42:17 --> Config Class Initialized
INFO - 2023-07-30 17:42:17 --> Loader Class Initialized
INFO - 2023-07-30 17:42:17 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:17 --> Controller Class Initialized
INFO - 2023-07-30 17:42:17 --> Config Class Initialized
INFO - 2023-07-30 17:42:17 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:17 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:17 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:17 --> URI Class Initialized
INFO - 2023-07-30 17:42:17 --> Router Class Initialized
INFO - 2023-07-30 17:42:17 --> Output Class Initialized
INFO - 2023-07-30 17:42:17 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:17 --> Input Class Initialized
INFO - 2023-07-30 17:42:17 --> Language Class Initialized
INFO - 2023-07-30 17:42:17 --> Language Class Initialized
INFO - 2023-07-30 17:42:17 --> Config Class Initialized
INFO - 2023-07-30 17:42:17 --> Loader Class Initialized
INFO - 2023-07-30 17:42:17 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:17 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:17 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:17 --> Controller Class Initialized
DEBUG - 2023-07-30 17:42:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-30 17:42:17 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:42:17 --> Final output sent to browser
DEBUG - 2023-07-30 17:42:17 --> Total execution time: 0.0567
INFO - 2023-07-30 17:42:21 --> Config Class Initialized
INFO - 2023-07-30 17:42:21 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:21 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:21 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:21 --> URI Class Initialized
INFO - 2023-07-30 17:42:21 --> Router Class Initialized
INFO - 2023-07-30 17:42:21 --> Output Class Initialized
INFO - 2023-07-30 17:42:21 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:21 --> Input Class Initialized
INFO - 2023-07-30 17:42:21 --> Language Class Initialized
INFO - 2023-07-30 17:42:21 --> Language Class Initialized
INFO - 2023-07-30 17:42:21 --> Config Class Initialized
INFO - 2023-07-30 17:42:21 --> Loader Class Initialized
INFO - 2023-07-30 17:42:21 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:21 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:21 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:21 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:21 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:21 --> Controller Class Initialized
DEBUG - 2023-07-30 17:42:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_nna/views/list.php
DEBUG - 2023-07-30 17:42:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:42:21 --> Final output sent to browser
DEBUG - 2023-07-30 17:42:21 --> Total execution time: 0.0561
INFO - 2023-07-30 17:42:37 --> Config Class Initialized
INFO - 2023-07-30 17:42:37 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:42:37 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:42:37 --> Utf8 Class Initialized
INFO - 2023-07-30 17:42:37 --> URI Class Initialized
INFO - 2023-07-30 17:42:37 --> Router Class Initialized
INFO - 2023-07-30 17:42:37 --> Output Class Initialized
INFO - 2023-07-30 17:42:37 --> Security Class Initialized
DEBUG - 2023-07-30 17:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:42:37 --> Input Class Initialized
INFO - 2023-07-30 17:42:37 --> Language Class Initialized
INFO - 2023-07-30 17:42:37 --> Language Class Initialized
INFO - 2023-07-30 17:42:37 --> Config Class Initialized
INFO - 2023-07-30 17:42:37 --> Loader Class Initialized
INFO - 2023-07-30 17:42:37 --> Helper loaded: url_helper
INFO - 2023-07-30 17:42:37 --> Helper loaded: file_helper
INFO - 2023-07-30 17:42:37 --> Helper loaded: form_helper
INFO - 2023-07-30 17:42:37 --> Helper loaded: my_helper
INFO - 2023-07-30 17:42:37 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:42:37 --> Controller Class Initialized
DEBUG - 2023-07-30 17:42:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_bi/views/list.php
DEBUG - 2023-07-30 17:42:37 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:42:37 --> Final output sent to browser
DEBUG - 2023-07-30 17:42:37 --> Total execution time: 0.0438
INFO - 2023-07-30 17:44:48 --> Config Class Initialized
INFO - 2023-07-30 17:44:48 --> Hooks Class Initialized
DEBUG - 2023-07-30 17:44:48 --> UTF-8 Support Enabled
INFO - 2023-07-30 17:44:48 --> Utf8 Class Initialized
INFO - 2023-07-30 17:44:48 --> URI Class Initialized
INFO - 2023-07-30 17:44:48 --> Router Class Initialized
INFO - 2023-07-30 17:44:48 --> Output Class Initialized
INFO - 2023-07-30 17:44:48 --> Security Class Initialized
DEBUG - 2023-07-30 17:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-30 17:44:48 --> Input Class Initialized
INFO - 2023-07-30 17:44:48 --> Language Class Initialized
INFO - 2023-07-30 17:44:48 --> Language Class Initialized
INFO - 2023-07-30 17:44:48 --> Config Class Initialized
INFO - 2023-07-30 17:44:48 --> Loader Class Initialized
INFO - 2023-07-30 17:44:48 --> Helper loaded: url_helper
INFO - 2023-07-30 17:44:48 --> Helper loaded: file_helper
INFO - 2023-07-30 17:44:48 --> Helper loaded: form_helper
INFO - 2023-07-30 17:44:48 --> Helper loaded: my_helper
INFO - 2023-07-30 17:44:48 --> Database Driver Class Initialized
DEBUG - 2023-07-30 17:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-30 17:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-30 17:44:48 --> Controller Class Initialized
DEBUG - 2023-07-30 17:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_kog/views/list.php
DEBUG - 2023-07-30 17:44:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-30 17:44:48 --> Final output sent to browser
DEBUG - 2023-07-30 17:44:48 --> Total execution time: 0.0554
