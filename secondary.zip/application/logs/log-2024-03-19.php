<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:32 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:32 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:32 --> URI Class Initialized
INFO - 2024-03-19 04:48:32 --> Router Class Initialized
INFO - 2024-03-19 04:48:32 --> Output Class Initialized
INFO - 2024-03-19 04:48:32 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:32 --> Input Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Loader Class Initialized
INFO - 2024-03-19 04:48:32 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:32 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:32 --> Controller Class Initialized
INFO - 2024-03-19 04:48:32 --> Helper loaded: cookie_helper
INFO - 2024-03-19 04:48:32 --> Final output sent to browser
DEBUG - 2024-03-19 04:48:32 --> Total execution time: 0.0439
INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:32 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:32 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:32 --> URI Class Initialized
INFO - 2024-03-19 04:48:32 --> Router Class Initialized
INFO - 2024-03-19 04:48:32 --> Output Class Initialized
INFO - 2024-03-19 04:48:32 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:32 --> Input Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Loader Class Initialized
INFO - 2024-03-19 04:48:32 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:32 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:32 --> Controller Class Initialized
INFO - 2024-03-19 04:48:32 --> Helper loaded: cookie_helper
INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:32 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:32 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:32 --> URI Class Initialized
INFO - 2024-03-19 04:48:32 --> Router Class Initialized
INFO - 2024-03-19 04:48:32 --> Output Class Initialized
INFO - 2024-03-19 04:48:32 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:32 --> Input Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Language Class Initialized
INFO - 2024-03-19 04:48:32 --> Config Class Initialized
INFO - 2024-03-19 04:48:32 --> Loader Class Initialized
INFO - 2024-03-19 04:48:32 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:32 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:32 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:32 --> Controller Class Initialized
DEBUG - 2024-03-19 04:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-19 04:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-19 04:48:32 --> Final output sent to browser
DEBUG - 2024-03-19 04:48:32 --> Total execution time: 0.0283
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:33 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:33 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:33 --> URI Class Initialized
INFO - 2024-03-19 04:48:33 --> Router Class Initialized
INFO - 2024-03-19 04:48:33 --> Output Class Initialized
INFO - 2024-03-19 04:48:33 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:33 --> Input Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Loader Class Initialized
INFO - 2024-03-19 04:48:33 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:33 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:33 --> Controller Class Initialized
INFO - 2024-03-19 04:48:33 --> Helper loaded: cookie_helper
INFO - 2024-03-19 04:48:33 --> Final output sent to browser
DEBUG - 2024-03-19 04:48:33 --> Total execution time: 0.0291
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:33 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:33 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:33 --> URI Class Initialized
INFO - 2024-03-19 04:48:33 --> Router Class Initialized
INFO - 2024-03-19 04:48:33 --> Output Class Initialized
INFO - 2024-03-19 04:48:33 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:33 --> Input Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Loader Class Initialized
INFO - 2024-03-19 04:48:33 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:33 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:33 --> Controller Class Initialized
INFO - 2024-03-19 04:48:33 --> Helper loaded: cookie_helper
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Hooks Class Initialized
DEBUG - 2024-03-19 04:48:33 --> UTF-8 Support Enabled
INFO - 2024-03-19 04:48:33 --> Utf8 Class Initialized
INFO - 2024-03-19 04:48:33 --> URI Class Initialized
INFO - 2024-03-19 04:48:33 --> Router Class Initialized
INFO - 2024-03-19 04:48:33 --> Output Class Initialized
INFO - 2024-03-19 04:48:33 --> Security Class Initialized
DEBUG - 2024-03-19 04:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 04:48:33 --> Input Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Language Class Initialized
INFO - 2024-03-19 04:48:33 --> Config Class Initialized
INFO - 2024-03-19 04:48:33 --> Loader Class Initialized
INFO - 2024-03-19 04:48:33 --> Helper loaded: url_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: file_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: form_helper
INFO - 2024-03-19 04:48:33 --> Helper loaded: my_helper
INFO - 2024-03-19 04:48:33 --> Database Driver Class Initialized
INFO - 2024-03-19 04:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 04:48:33 --> Controller Class Initialized
DEBUG - 2024-03-19 04:48:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-03-19 04:48:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-19 04:48:33 --> Final output sent to browser
DEBUG - 2024-03-19 04:48:33 --> Total execution time: 0.0593
INFO - 2024-03-19 10:02:11 --> Config Class Initialized
INFO - 2024-03-19 10:02:11 --> Hooks Class Initialized
DEBUG - 2024-03-19 10:02:11 --> UTF-8 Support Enabled
INFO - 2024-03-19 10:02:11 --> Utf8 Class Initialized
INFO - 2024-03-19 10:02:11 --> URI Class Initialized
INFO - 2024-03-19 10:02:11 --> Router Class Initialized
INFO - 2024-03-19 10:02:11 --> Output Class Initialized
INFO - 2024-03-19 10:02:11 --> Security Class Initialized
DEBUG - 2024-03-19 10:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 10:02:11 --> Input Class Initialized
INFO - 2024-03-19 10:02:11 --> Language Class Initialized
INFO - 2024-03-19 10:02:11 --> Language Class Initialized
INFO - 2024-03-19 10:02:11 --> Config Class Initialized
INFO - 2024-03-19 10:02:11 --> Loader Class Initialized
INFO - 2024-03-19 10:02:11 --> Helper loaded: url_helper
INFO - 2024-03-19 10:02:11 --> Helper loaded: file_helper
INFO - 2024-03-19 10:02:11 --> Helper loaded: form_helper
INFO - 2024-03-19 10:02:11 --> Helper loaded: my_helper
INFO - 2024-03-19 10:02:11 --> Database Driver Class Initialized
INFO - 2024-03-19 10:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 10:02:11 --> Controller Class Initialized
DEBUG - 2024-03-19 10:02:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-19 10:02:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-19 10:02:11 --> Final output sent to browser
DEBUG - 2024-03-19 10:02:11 --> Total execution time: 0.0656
INFO - 2024-03-19 10:02:13 --> Config Class Initialized
INFO - 2024-03-19 10:02:13 --> Hooks Class Initialized
DEBUG - 2024-03-19 10:02:13 --> UTF-8 Support Enabled
INFO - 2024-03-19 10:02:13 --> Utf8 Class Initialized
INFO - 2024-03-19 10:02:13 --> URI Class Initialized
INFO - 2024-03-19 10:02:13 --> Router Class Initialized
INFO - 2024-03-19 10:02:13 --> Output Class Initialized
INFO - 2024-03-19 10:02:13 --> Security Class Initialized
DEBUG - 2024-03-19 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 10:02:13 --> Input Class Initialized
INFO - 2024-03-19 10:02:13 --> Language Class Initialized
INFO - 2024-03-19 10:02:13 --> Language Class Initialized
INFO - 2024-03-19 10:02:13 --> Config Class Initialized
INFO - 2024-03-19 10:02:13 --> Loader Class Initialized
INFO - 2024-03-19 10:02:13 --> Helper loaded: url_helper
INFO - 2024-03-19 10:02:13 --> Helper loaded: file_helper
INFO - 2024-03-19 10:02:13 --> Helper loaded: form_helper
INFO - 2024-03-19 10:02:13 --> Helper loaded: my_helper
INFO - 2024-03-19 10:02:13 --> Database Driver Class Initialized
INFO - 2024-03-19 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 10:02:13 --> Controller Class Initialized
DEBUG - 2024-03-19 10:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-19 10:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-19 10:02:13 --> Final output sent to browser
DEBUG - 2024-03-19 10:02:13 --> Total execution time: 0.0322
INFO - 2024-03-19 15:03:59 --> Config Class Initialized
INFO - 2024-03-19 15:03:59 --> Hooks Class Initialized
DEBUG - 2024-03-19 15:03:59 --> UTF-8 Support Enabled
INFO - 2024-03-19 15:03:59 --> Utf8 Class Initialized
INFO - 2024-03-19 15:03:59 --> URI Class Initialized
INFO - 2024-03-19 15:03:59 --> Router Class Initialized
INFO - 2024-03-19 15:03:59 --> Output Class Initialized
INFO - 2024-03-19 15:03:59 --> Security Class Initialized
DEBUG - 2024-03-19 15:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 15:03:59 --> Input Class Initialized
INFO - 2024-03-19 15:03:59 --> Language Class Initialized
INFO - 2024-03-19 15:03:59 --> Language Class Initialized
INFO - 2024-03-19 15:03:59 --> Config Class Initialized
INFO - 2024-03-19 15:03:59 --> Loader Class Initialized
INFO - 2024-03-19 15:03:59 --> Helper loaded: url_helper
INFO - 2024-03-19 15:03:59 --> Helper loaded: file_helper
INFO - 2024-03-19 15:03:59 --> Helper loaded: form_helper
INFO - 2024-03-19 15:03:59 --> Helper loaded: my_helper
INFO - 2024-03-19 15:03:59 --> Database Driver Class Initialized
INFO - 2024-03-19 15:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 15:03:59 --> Controller Class Initialized
DEBUG - 2024-03-19 15:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-19 15:03:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-19 15:03:59 --> Final output sent to browser
DEBUG - 2024-03-19 15:03:59 --> Total execution time: 0.0474
INFO - 2024-03-19 22:42:06 --> Config Class Initialized
INFO - 2024-03-19 22:42:06 --> Hooks Class Initialized
DEBUG - 2024-03-19 22:42:06 --> UTF-8 Support Enabled
INFO - 2024-03-19 22:42:06 --> Utf8 Class Initialized
INFO - 2024-03-19 22:42:06 --> URI Class Initialized
INFO - 2024-03-19 22:42:06 --> Router Class Initialized
INFO - 2024-03-19 22:42:06 --> Output Class Initialized
INFO - 2024-03-19 22:42:06 --> Security Class Initialized
DEBUG - 2024-03-19 22:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-19 22:42:06 --> Input Class Initialized
INFO - 2024-03-19 22:42:06 --> Language Class Initialized
INFO - 2024-03-19 22:42:06 --> Language Class Initialized
INFO - 2024-03-19 22:42:06 --> Config Class Initialized
INFO - 2024-03-19 22:42:06 --> Loader Class Initialized
INFO - 2024-03-19 22:42:06 --> Helper loaded: url_helper
INFO - 2024-03-19 22:42:06 --> Helper loaded: file_helper
INFO - 2024-03-19 22:42:06 --> Helper loaded: form_helper
INFO - 2024-03-19 22:42:06 --> Helper loaded: my_helper
INFO - 2024-03-19 22:42:06 --> Database Driver Class Initialized
INFO - 2024-03-19 22:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-19 22:42:06 --> Controller Class Initialized
DEBUG - 2024-03-19 22:42:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-19 22:42:10 --> Final output sent to browser
DEBUG - 2024-03-19 22:42:10 --> Total execution time: 3.8772
