<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-02 20:55:47 --> Config Class Initialized
INFO - 2024-06-02 20:55:47 --> Hooks Class Initialized
DEBUG - 2024-06-02 20:55:47 --> UTF-8 Support Enabled
INFO - 2024-06-02 20:55:47 --> Utf8 Class Initialized
INFO - 2024-06-02 20:55:47 --> URI Class Initialized
INFO - 2024-06-02 20:55:47 --> Router Class Initialized
INFO - 2024-06-02 20:55:47 --> Output Class Initialized
INFO - 2024-06-02 20:55:47 --> Security Class Initialized
DEBUG - 2024-06-02 20:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 20:55:47 --> Input Class Initialized
INFO - 2024-06-02 20:55:47 --> Language Class Initialized
INFO - 2024-06-02 20:55:47 --> Language Class Initialized
INFO - 2024-06-02 20:55:47 --> Config Class Initialized
INFO - 2024-06-02 20:55:47 --> Loader Class Initialized
INFO - 2024-06-02 20:55:47 --> Helper loaded: url_helper
INFO - 2024-06-02 20:55:47 --> Helper loaded: file_helper
INFO - 2024-06-02 20:55:47 --> Helper loaded: form_helper
INFO - 2024-06-02 20:55:47 --> Helper loaded: my_helper
INFO - 2024-06-02 20:55:47 --> Database Driver Class Initialized
INFO - 2024-06-02 20:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 20:55:47 --> Controller Class Initialized
DEBUG - 2024-06-02 20:55:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-02 20:55:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-02 20:55:47 --> Final output sent to browser
DEBUG - 2024-06-02 20:55:47 --> Total execution time: 0.1286
INFO - 2024-06-02 20:56:04 --> Config Class Initialized
INFO - 2024-06-02 20:56:04 --> Hooks Class Initialized
DEBUG - 2024-06-02 20:56:04 --> UTF-8 Support Enabled
INFO - 2024-06-02 20:56:04 --> Utf8 Class Initialized
INFO - 2024-06-02 20:56:04 --> URI Class Initialized
INFO - 2024-06-02 20:56:04 --> Router Class Initialized
INFO - 2024-06-02 20:56:04 --> Output Class Initialized
INFO - 2024-06-02 20:56:04 --> Security Class Initialized
DEBUG - 2024-06-02 20:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-02 20:56:04 --> Input Class Initialized
INFO - 2024-06-02 20:56:04 --> Language Class Initialized
INFO - 2024-06-02 20:56:04 --> Language Class Initialized
INFO - 2024-06-02 20:56:04 --> Config Class Initialized
INFO - 2024-06-02 20:56:04 --> Loader Class Initialized
INFO - 2024-06-02 20:56:04 --> Helper loaded: url_helper
INFO - 2024-06-02 20:56:04 --> Helper loaded: file_helper
INFO - 2024-06-02 20:56:04 --> Helper loaded: form_helper
INFO - 2024-06-02 20:56:04 --> Helper loaded: my_helper
INFO - 2024-06-02 20:56:04 --> Database Driver Class Initialized
INFO - 2024-06-02 20:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-02 20:56:04 --> Controller Class Initialized
