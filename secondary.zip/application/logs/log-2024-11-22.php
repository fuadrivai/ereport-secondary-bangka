<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-11-22 13:43:14 --> Config Class Initialized
INFO - 2024-11-22 13:43:14 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:43:14 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:43:14 --> Utf8 Class Initialized
INFO - 2024-11-22 13:43:14 --> URI Class Initialized
INFO - 2024-11-22 13:43:14 --> Router Class Initialized
INFO - 2024-11-22 13:43:14 --> Output Class Initialized
INFO - 2024-11-22 13:43:14 --> Security Class Initialized
DEBUG - 2024-11-22 13:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:43:14 --> Input Class Initialized
INFO - 2024-11-22 13:43:14 --> Language Class Initialized
INFO - 2024-11-22 13:43:14 --> Language Class Initialized
INFO - 2024-11-22 13:43:14 --> Config Class Initialized
INFO - 2024-11-22 13:43:14 --> Loader Class Initialized
INFO - 2024-11-22 13:43:14 --> Helper loaded: url_helper
INFO - 2024-11-22 13:43:14 --> Helper loaded: file_helper
INFO - 2024-11-22 13:43:14 --> Helper loaded: form_helper
INFO - 2024-11-22 13:43:14 --> Helper loaded: my_helper
INFO - 2024-11-22 13:43:14 --> Database Driver Class Initialized
INFO - 2024-11-22 13:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:43:14 --> Controller Class Initialized
DEBUG - 2024-11-22 13:43:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-22 13:43:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:43:14 --> Final output sent to browser
DEBUG - 2024-11-22 13:43:14 --> Total execution time: 0.0616
INFO - 2024-11-22 13:48:24 --> Config Class Initialized
INFO - 2024-11-22 13:48:24 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:24 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:24 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:24 --> URI Class Initialized
DEBUG - 2024-11-22 13:48:24 --> No URI present. Default controller set.
INFO - 2024-11-22 13:48:24 --> Router Class Initialized
INFO - 2024-11-22 13:48:24 --> Output Class Initialized
INFO - 2024-11-22 13:48:24 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:24 --> Input Class Initialized
INFO - 2024-11-22 13:48:24 --> Language Class Initialized
INFO - 2024-11-22 13:48:24 --> Language Class Initialized
INFO - 2024-11-22 13:48:24 --> Config Class Initialized
INFO - 2024-11-22 13:48:24 --> Loader Class Initialized
INFO - 2024-11-22 13:48:24 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:24 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:24 --> Controller Class Initialized
INFO - 2024-11-22 13:48:24 --> Config Class Initialized
INFO - 2024-11-22 13:48:24 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:24 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:24 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:24 --> URI Class Initialized
INFO - 2024-11-22 13:48:24 --> Router Class Initialized
INFO - 2024-11-22 13:48:24 --> Output Class Initialized
INFO - 2024-11-22 13:48:24 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:24 --> Input Class Initialized
INFO - 2024-11-22 13:48:24 --> Language Class Initialized
INFO - 2024-11-22 13:48:24 --> Language Class Initialized
INFO - 2024-11-22 13:48:24 --> Config Class Initialized
INFO - 2024-11-22 13:48:24 --> Loader Class Initialized
INFO - 2024-11-22 13:48:24 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:24 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:24 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:24 --> Controller Class Initialized
DEBUG - 2024-11-22 13:48:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-22 13:48:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:48:24 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:24 --> Total execution time: 0.0309
INFO - 2024-11-22 13:48:28 --> Config Class Initialized
INFO - 2024-11-22 13:48:28 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:28 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:28 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:28 --> URI Class Initialized
INFO - 2024-11-22 13:48:28 --> Router Class Initialized
INFO - 2024-11-22 13:48:28 --> Output Class Initialized
INFO - 2024-11-22 13:48:28 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:28 --> Input Class Initialized
INFO - 2024-11-22 13:48:28 --> Language Class Initialized
INFO - 2024-11-22 13:48:28 --> Language Class Initialized
INFO - 2024-11-22 13:48:28 --> Config Class Initialized
INFO - 2024-11-22 13:48:28 --> Loader Class Initialized
INFO - 2024-11-22 13:48:28 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:28 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:28 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:28 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:28 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:28 --> Controller Class Initialized
INFO - 2024-11-22 13:48:28 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:28 --> Total execution time: 0.0308
INFO - 2024-11-22 13:48:32 --> Config Class Initialized
INFO - 2024-11-22 13:48:32 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:32 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:32 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:32 --> URI Class Initialized
INFO - 2024-11-22 13:48:32 --> Router Class Initialized
INFO - 2024-11-22 13:48:32 --> Output Class Initialized
INFO - 2024-11-22 13:48:32 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:32 --> Input Class Initialized
INFO - 2024-11-22 13:48:32 --> Language Class Initialized
INFO - 2024-11-22 13:48:32 --> Language Class Initialized
INFO - 2024-11-22 13:48:32 --> Config Class Initialized
INFO - 2024-11-22 13:48:32 --> Loader Class Initialized
INFO - 2024-11-22 13:48:32 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:32 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:32 --> Controller Class Initialized
INFO - 2024-11-22 13:48:32 --> Helper loaded: cookie_helper
INFO - 2024-11-22 13:48:32 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:32 --> Total execution time: 0.0267
INFO - 2024-11-22 13:48:32 --> Config Class Initialized
INFO - 2024-11-22 13:48:32 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:32 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:32 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:32 --> URI Class Initialized
INFO - 2024-11-22 13:48:32 --> Router Class Initialized
INFO - 2024-11-22 13:48:32 --> Output Class Initialized
INFO - 2024-11-22 13:48:32 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:32 --> Input Class Initialized
INFO - 2024-11-22 13:48:32 --> Language Class Initialized
INFO - 2024-11-22 13:48:32 --> Language Class Initialized
INFO - 2024-11-22 13:48:32 --> Config Class Initialized
INFO - 2024-11-22 13:48:32 --> Loader Class Initialized
INFO - 2024-11-22 13:48:32 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:32 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:32 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:32 --> Controller Class Initialized
DEBUG - 2024-11-22 13:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-11-22 13:48:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:48:32 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:32 --> Total execution time: 0.0509
INFO - 2024-11-22 13:48:39 --> Config Class Initialized
INFO - 2024-11-22 13:48:39 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:39 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:39 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:39 --> URI Class Initialized
INFO - 2024-11-22 13:48:39 --> Router Class Initialized
INFO - 2024-11-22 13:48:39 --> Output Class Initialized
INFO - 2024-11-22 13:48:39 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:39 --> Input Class Initialized
INFO - 2024-11-22 13:48:39 --> Language Class Initialized
INFO - 2024-11-22 13:48:39 --> Language Class Initialized
INFO - 2024-11-22 13:48:39 --> Config Class Initialized
INFO - 2024-11-22 13:48:39 --> Loader Class Initialized
INFO - 2024-11-22 13:48:39 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:39 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:39 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:39 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:39 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:39 --> Controller Class Initialized
DEBUG - 2024-11-22 13:48:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-11-22 13:48:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:48:39 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:39 --> Total execution time: 0.0418
INFO - 2024-11-22 13:48:41 --> Config Class Initialized
INFO - 2024-11-22 13:48:41 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:41 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:41 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:41 --> URI Class Initialized
INFO - 2024-11-22 13:48:41 --> Router Class Initialized
INFO - 2024-11-22 13:48:41 --> Output Class Initialized
INFO - 2024-11-22 13:48:41 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:41 --> Input Class Initialized
INFO - 2024-11-22 13:48:41 --> Language Class Initialized
INFO - 2024-11-22 13:48:41 --> Language Class Initialized
INFO - 2024-11-22 13:48:41 --> Config Class Initialized
INFO - 2024-11-22 13:48:41 --> Loader Class Initialized
INFO - 2024-11-22 13:48:41 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:41 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:41 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:41 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:41 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:41 --> Controller Class Initialized
INFO - 2024-11-22 13:48:41 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:42 --> Config Class Initialized
INFO - 2024-11-22 13:48:42 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:48:42 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:48:42 --> Utf8 Class Initialized
INFO - 2024-11-22 13:48:42 --> URI Class Initialized
INFO - 2024-11-22 13:48:42 --> Router Class Initialized
INFO - 2024-11-22 13:48:42 --> Output Class Initialized
INFO - 2024-11-22 13:48:42 --> Security Class Initialized
DEBUG - 2024-11-22 13:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:48:42 --> Input Class Initialized
INFO - 2024-11-22 13:48:42 --> Language Class Initialized
INFO - 2024-11-22 13:48:42 --> Language Class Initialized
INFO - 2024-11-22 13:48:42 --> Config Class Initialized
INFO - 2024-11-22 13:48:42 --> Loader Class Initialized
INFO - 2024-11-22 13:48:42 --> Helper loaded: url_helper
INFO - 2024-11-22 13:48:42 --> Helper loaded: file_helper
INFO - 2024-11-22 13:48:42 --> Helper loaded: form_helper
INFO - 2024-11-22 13:48:42 --> Helper loaded: my_helper
INFO - 2024-11-22 13:48:42 --> Database Driver Class Initialized
INFO - 2024-11-22 13:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:48:42 --> Controller Class Initialized
DEBUG - 2024-11-22 13:48:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-11-22 13:48:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:48:42 --> Final output sent to browser
DEBUG - 2024-11-22 13:48:42 --> Total execution time: 0.0277
INFO - 2024-11-22 13:49:22 --> Config Class Initialized
INFO - 2024-11-22 13:49:22 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:22 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:22 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:22 --> URI Class Initialized
INFO - 2024-11-22 13:49:22 --> Router Class Initialized
INFO - 2024-11-22 13:49:22 --> Output Class Initialized
INFO - 2024-11-22 13:49:22 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:22 --> Input Class Initialized
INFO - 2024-11-22 13:49:22 --> Language Class Initialized
INFO - 2024-11-22 13:49:22 --> Language Class Initialized
INFO - 2024-11-22 13:49:22 --> Config Class Initialized
INFO - 2024-11-22 13:49:22 --> Loader Class Initialized
INFO - 2024-11-22 13:49:22 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:22 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:22 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:22 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:22 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:22 --> Controller Class Initialized
DEBUG - 2024-11-22 13:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-11-22 13:49:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 13:49:22 --> Final output sent to browser
DEBUG - 2024-11-22 13:49:22 --> Total execution time: 0.0270
INFO - 2024-11-22 13:49:22 --> Config Class Initialized
INFO - 2024-11-22 13:49:22 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:22 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:22 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:22 --> URI Class Initialized
INFO - 2024-11-22 13:49:22 --> Router Class Initialized
INFO - 2024-11-22 13:49:22 --> Output Class Initialized
INFO - 2024-11-22 13:49:22 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:22 --> Input Class Initialized
INFO - 2024-11-22 13:49:22 --> Language Class Initialized
ERROR - 2024-11-22 13:49:22 --> 404 Page Not Found: /index
INFO - 2024-11-22 13:49:23 --> Config Class Initialized
INFO - 2024-11-22 13:49:23 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:23 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:23 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:23 --> URI Class Initialized
INFO - 2024-11-22 13:49:23 --> Router Class Initialized
INFO - 2024-11-22 13:49:23 --> Output Class Initialized
INFO - 2024-11-22 13:49:23 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:23 --> Input Class Initialized
INFO - 2024-11-22 13:49:23 --> Language Class Initialized
INFO - 2024-11-22 13:49:23 --> Language Class Initialized
INFO - 2024-11-22 13:49:23 --> Config Class Initialized
INFO - 2024-11-22 13:49:23 --> Loader Class Initialized
INFO - 2024-11-22 13:49:23 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:23 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:23 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:23 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:23 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:23 --> Controller Class Initialized
INFO - 2024-11-22 13:49:24 --> Config Class Initialized
INFO - 2024-11-22 13:49:24 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:24 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:24 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:24 --> URI Class Initialized
INFO - 2024-11-22 13:49:24 --> Router Class Initialized
INFO - 2024-11-22 13:49:24 --> Output Class Initialized
INFO - 2024-11-22 13:49:24 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:24 --> Input Class Initialized
INFO - 2024-11-22 13:49:24 --> Language Class Initialized
INFO - 2024-11-22 13:49:24 --> Language Class Initialized
INFO - 2024-11-22 13:49:24 --> Config Class Initialized
INFO - 2024-11-22 13:49:24 --> Loader Class Initialized
INFO - 2024-11-22 13:49:24 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:24 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:24 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:24 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:24 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:24 --> Controller Class Initialized
INFO - 2024-11-22 13:49:27 --> Config Class Initialized
INFO - 2024-11-22 13:49:27 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:27 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:27 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:27 --> URI Class Initialized
INFO - 2024-11-22 13:49:27 --> Router Class Initialized
INFO - 2024-11-22 13:49:27 --> Output Class Initialized
INFO - 2024-11-22 13:49:27 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:27 --> Input Class Initialized
INFO - 2024-11-22 13:49:27 --> Language Class Initialized
INFO - 2024-11-22 13:49:27 --> Language Class Initialized
INFO - 2024-11-22 13:49:27 --> Config Class Initialized
INFO - 2024-11-22 13:49:27 --> Loader Class Initialized
INFO - 2024-11-22 13:49:27 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:27 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:27 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:27 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:27 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:27 --> Controller Class Initialized
INFO - 2024-11-22 13:49:29 --> Config Class Initialized
INFO - 2024-11-22 13:49:29 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:29 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:29 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:29 --> URI Class Initialized
INFO - 2024-11-22 13:49:29 --> Router Class Initialized
INFO - 2024-11-22 13:49:29 --> Output Class Initialized
INFO - 2024-11-22 13:49:29 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:29 --> Input Class Initialized
INFO - 2024-11-22 13:49:29 --> Language Class Initialized
INFO - 2024-11-22 13:49:29 --> Language Class Initialized
INFO - 2024-11-22 13:49:29 --> Config Class Initialized
INFO - 2024-11-22 13:49:29 --> Loader Class Initialized
INFO - 2024-11-22 13:49:29 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:29 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:29 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:29 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:29 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:29 --> Controller Class Initialized
INFO - 2024-11-22 13:49:30 --> Config Class Initialized
INFO - 2024-11-22 13:49:30 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:30 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:30 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:30 --> URI Class Initialized
INFO - 2024-11-22 13:49:30 --> Router Class Initialized
INFO - 2024-11-22 13:49:30 --> Output Class Initialized
INFO - 2024-11-22 13:49:30 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:30 --> Input Class Initialized
INFO - 2024-11-22 13:49:30 --> Language Class Initialized
INFO - 2024-11-22 13:49:30 --> Language Class Initialized
INFO - 2024-11-22 13:49:30 --> Config Class Initialized
INFO - 2024-11-22 13:49:30 --> Loader Class Initialized
INFO - 2024-11-22 13:49:30 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:30 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:30 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:30 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:30 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:30 --> Controller Class Initialized
INFO - 2024-11-22 13:49:31 --> Config Class Initialized
INFO - 2024-11-22 13:49:31 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:31 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:31 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:31 --> URI Class Initialized
INFO - 2024-11-22 13:49:31 --> Router Class Initialized
INFO - 2024-11-22 13:49:31 --> Output Class Initialized
INFO - 2024-11-22 13:49:31 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:31 --> Input Class Initialized
INFO - 2024-11-22 13:49:31 --> Language Class Initialized
INFO - 2024-11-22 13:49:31 --> Language Class Initialized
INFO - 2024-11-22 13:49:31 --> Config Class Initialized
INFO - 2024-11-22 13:49:31 --> Loader Class Initialized
INFO - 2024-11-22 13:49:31 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:31 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:31 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:31 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:31 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:31 --> Controller Class Initialized
INFO - 2024-11-22 13:49:32 --> Config Class Initialized
INFO - 2024-11-22 13:49:32 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:32 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:32 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:32 --> URI Class Initialized
INFO - 2024-11-22 13:49:32 --> Router Class Initialized
INFO - 2024-11-22 13:49:32 --> Output Class Initialized
INFO - 2024-11-22 13:49:32 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:32 --> Input Class Initialized
INFO - 2024-11-22 13:49:32 --> Language Class Initialized
INFO - 2024-11-22 13:49:32 --> Language Class Initialized
INFO - 2024-11-22 13:49:32 --> Config Class Initialized
INFO - 2024-11-22 13:49:32 --> Loader Class Initialized
INFO - 2024-11-22 13:49:32 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:32 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:32 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:32 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:32 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:32 --> Controller Class Initialized
INFO - 2024-11-22 13:49:33 --> Config Class Initialized
INFO - 2024-11-22 13:49:33 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:33 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:33 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:33 --> URI Class Initialized
INFO - 2024-11-22 13:49:33 --> Router Class Initialized
INFO - 2024-11-22 13:49:33 --> Output Class Initialized
INFO - 2024-11-22 13:49:33 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:33 --> Input Class Initialized
INFO - 2024-11-22 13:49:33 --> Language Class Initialized
INFO - 2024-11-22 13:49:33 --> Language Class Initialized
INFO - 2024-11-22 13:49:33 --> Config Class Initialized
INFO - 2024-11-22 13:49:33 --> Loader Class Initialized
INFO - 2024-11-22 13:49:33 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:33 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:33 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:33 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:33 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:33 --> Controller Class Initialized
INFO - 2024-11-22 13:49:34 --> Config Class Initialized
INFO - 2024-11-22 13:49:34 --> Hooks Class Initialized
DEBUG - 2024-11-22 13:49:34 --> UTF-8 Support Enabled
INFO - 2024-11-22 13:49:34 --> Utf8 Class Initialized
INFO - 2024-11-22 13:49:34 --> URI Class Initialized
INFO - 2024-11-22 13:49:34 --> Router Class Initialized
INFO - 2024-11-22 13:49:34 --> Output Class Initialized
INFO - 2024-11-22 13:49:34 --> Security Class Initialized
DEBUG - 2024-11-22 13:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 13:49:34 --> Input Class Initialized
INFO - 2024-11-22 13:49:34 --> Language Class Initialized
INFO - 2024-11-22 13:49:34 --> Language Class Initialized
INFO - 2024-11-22 13:49:34 --> Config Class Initialized
INFO - 2024-11-22 13:49:34 --> Loader Class Initialized
INFO - 2024-11-22 13:49:34 --> Helper loaded: url_helper
INFO - 2024-11-22 13:49:34 --> Helper loaded: file_helper
INFO - 2024-11-22 13:49:34 --> Helper loaded: form_helper
INFO - 2024-11-22 13:49:34 --> Helper loaded: my_helper
INFO - 2024-11-22 13:49:34 --> Database Driver Class Initialized
INFO - 2024-11-22 13:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 13:49:34 --> Controller Class Initialized
INFO - 2024-11-22 15:07:49 --> Config Class Initialized
INFO - 2024-11-22 15:07:49 --> Hooks Class Initialized
DEBUG - 2024-11-22 15:07:49 --> UTF-8 Support Enabled
INFO - 2024-11-22 15:07:49 --> Utf8 Class Initialized
INFO - 2024-11-22 15:07:49 --> URI Class Initialized
INFO - 2024-11-22 15:07:49 --> Router Class Initialized
INFO - 2024-11-22 15:07:49 --> Output Class Initialized
INFO - 2024-11-22 15:07:49 --> Security Class Initialized
DEBUG - 2024-11-22 15:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 15:07:49 --> Input Class Initialized
INFO - 2024-11-22 15:07:49 --> Language Class Initialized
INFO - 2024-11-22 15:07:49 --> Language Class Initialized
INFO - 2024-11-22 15:07:49 --> Config Class Initialized
INFO - 2024-11-22 15:07:49 --> Loader Class Initialized
INFO - 2024-11-22 15:07:49 --> Helper loaded: url_helper
INFO - 2024-11-22 15:07:49 --> Helper loaded: file_helper
INFO - 2024-11-22 15:07:49 --> Helper loaded: form_helper
INFO - 2024-11-22 15:07:49 --> Helper loaded: my_helper
INFO - 2024-11-22 15:07:49 --> Database Driver Class Initialized
INFO - 2024-11-22 15:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 15:07:49 --> Controller Class Initialized
INFO - 2024-11-22 15:07:49 --> Final output sent to browser
DEBUG - 2024-11-22 15:07:49 --> Total execution time: 0.0715
INFO - 2024-11-22 15:53:55 --> Config Class Initialized
INFO - 2024-11-22 15:53:55 --> Hooks Class Initialized
DEBUG - 2024-11-22 15:53:55 --> UTF-8 Support Enabled
INFO - 2024-11-22 15:53:55 --> Utf8 Class Initialized
INFO - 2024-11-22 15:53:55 --> URI Class Initialized
INFO - 2024-11-22 15:53:55 --> Router Class Initialized
INFO - 2024-11-22 15:53:55 --> Output Class Initialized
INFO - 2024-11-22 15:53:55 --> Security Class Initialized
DEBUG - 2024-11-22 15:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 15:53:55 --> Input Class Initialized
INFO - 2024-11-22 15:53:55 --> Language Class Initialized
INFO - 2024-11-22 15:53:55 --> Language Class Initialized
INFO - 2024-11-22 15:53:55 --> Config Class Initialized
INFO - 2024-11-22 15:53:55 --> Loader Class Initialized
INFO - 2024-11-22 15:53:55 --> Helper loaded: url_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: file_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: form_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: my_helper
INFO - 2024-11-22 15:53:55 --> Database Driver Class Initialized
INFO - 2024-11-22 15:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 15:53:55 --> Controller Class Initialized
INFO - 2024-11-22 15:53:55 --> Config Class Initialized
INFO - 2024-11-22 15:53:55 --> Hooks Class Initialized
DEBUG - 2024-11-22 15:53:55 --> UTF-8 Support Enabled
INFO - 2024-11-22 15:53:55 --> Utf8 Class Initialized
INFO - 2024-11-22 15:53:55 --> URI Class Initialized
INFO - 2024-11-22 15:53:55 --> Router Class Initialized
INFO - 2024-11-22 15:53:55 --> Output Class Initialized
INFO - 2024-11-22 15:53:55 --> Security Class Initialized
DEBUG - 2024-11-22 15:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-11-22 15:53:55 --> Input Class Initialized
INFO - 2024-11-22 15:53:55 --> Language Class Initialized
INFO - 2024-11-22 15:53:55 --> Language Class Initialized
INFO - 2024-11-22 15:53:55 --> Config Class Initialized
INFO - 2024-11-22 15:53:55 --> Loader Class Initialized
INFO - 2024-11-22 15:53:55 --> Helper loaded: url_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: file_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: form_helper
INFO - 2024-11-22 15:53:55 --> Helper loaded: my_helper
INFO - 2024-11-22 15:53:55 --> Database Driver Class Initialized
INFO - 2024-11-22 15:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-11-22 15:53:55 --> Controller Class Initialized
DEBUG - 2024-11-22 15:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-11-22 15:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-11-22 15:53:55 --> Final output sent to browser
DEBUG - 2024-11-22 15:53:55 --> Total execution time: 0.0432
