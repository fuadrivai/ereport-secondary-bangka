<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-07 03:10:59 --> Config Class Initialized
INFO - 2023-07-07 03:10:59 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:10:59 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:10:59 --> Utf8 Class Initialized
INFO - 2023-07-07 03:10:59 --> URI Class Initialized
DEBUG - 2023-07-07 03:10:59 --> No URI present. Default controller set.
INFO - 2023-07-07 03:10:59 --> Router Class Initialized
INFO - 2023-07-07 03:10:59 --> Output Class Initialized
INFO - 2023-07-07 03:10:59 --> Security Class Initialized
DEBUG - 2023-07-07 03:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:10:59 --> Input Class Initialized
INFO - 2023-07-07 03:10:59 --> Language Class Initialized
INFO - 2023-07-07 03:10:59 --> Language Class Initialized
INFO - 2023-07-07 03:10:59 --> Config Class Initialized
INFO - 2023-07-07 03:10:59 --> Loader Class Initialized
INFO - 2023-07-07 03:10:59 --> Helper loaded: url_helper
INFO - 2023-07-07 03:10:59 --> Helper loaded: file_helper
INFO - 2023-07-07 03:10:59 --> Helper loaded: form_helper
INFO - 2023-07-07 03:10:59 --> Helper loaded: my_helper
INFO - 2023-07-07 03:11:00 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:11:00 --> Controller Class Initialized
INFO - 2023-07-07 03:11:00 --> Config Class Initialized
INFO - 2023-07-07 03:11:00 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:11:00 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:11:00 --> Utf8 Class Initialized
INFO - 2023-07-07 03:11:00 --> URI Class Initialized
INFO - 2023-07-07 03:11:00 --> Router Class Initialized
INFO - 2023-07-07 03:11:00 --> Output Class Initialized
INFO - 2023-07-07 03:11:00 --> Security Class Initialized
DEBUG - 2023-07-07 03:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:11:00 --> Input Class Initialized
INFO - 2023-07-07 03:11:00 --> Language Class Initialized
INFO - 2023-07-07 03:11:00 --> Language Class Initialized
INFO - 2023-07-07 03:11:00 --> Config Class Initialized
INFO - 2023-07-07 03:11:00 --> Loader Class Initialized
INFO - 2023-07-07 03:11:00 --> Helper loaded: url_helper
INFO - 2023-07-07 03:11:00 --> Helper loaded: file_helper
INFO - 2023-07-07 03:11:00 --> Helper loaded: form_helper
INFO - 2023-07-07 03:11:00 --> Helper loaded: my_helper
INFO - 2023-07-07 03:11:00 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:11:00 --> Controller Class Initialized
DEBUG - 2023-07-07 03:11:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-07 03:11:00 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:11:00 --> Final output sent to browser
DEBUG - 2023-07-07 03:11:00 --> Total execution time: 0.1393
INFO - 2023-07-07 03:11:04 --> Config Class Initialized
INFO - 2023-07-07 03:11:04 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:11:04 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:11:04 --> Utf8 Class Initialized
INFO - 2023-07-07 03:11:04 --> URI Class Initialized
DEBUG - 2023-07-07 03:11:04 --> No URI present. Default controller set.
INFO - 2023-07-07 03:11:04 --> Router Class Initialized
INFO - 2023-07-07 03:11:04 --> Output Class Initialized
INFO - 2023-07-07 03:11:04 --> Security Class Initialized
DEBUG - 2023-07-07 03:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:11:04 --> Input Class Initialized
INFO - 2023-07-07 03:11:04 --> Language Class Initialized
INFO - 2023-07-07 03:11:04 --> Language Class Initialized
INFO - 2023-07-07 03:11:04 --> Config Class Initialized
INFO - 2023-07-07 03:11:04 --> Loader Class Initialized
INFO - 2023-07-07 03:11:04 --> Helper loaded: url_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: file_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: form_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: my_helper
INFO - 2023-07-07 03:11:04 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:11:04 --> Controller Class Initialized
INFO - 2023-07-07 03:11:04 --> Config Class Initialized
INFO - 2023-07-07 03:11:04 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:11:04 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:11:04 --> Utf8 Class Initialized
INFO - 2023-07-07 03:11:04 --> URI Class Initialized
INFO - 2023-07-07 03:11:04 --> Router Class Initialized
INFO - 2023-07-07 03:11:04 --> Output Class Initialized
INFO - 2023-07-07 03:11:04 --> Security Class Initialized
DEBUG - 2023-07-07 03:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:11:04 --> Input Class Initialized
INFO - 2023-07-07 03:11:04 --> Language Class Initialized
INFO - 2023-07-07 03:11:04 --> Language Class Initialized
INFO - 2023-07-07 03:11:04 --> Config Class Initialized
INFO - 2023-07-07 03:11:04 --> Loader Class Initialized
INFO - 2023-07-07 03:11:04 --> Helper loaded: url_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: file_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: form_helper
INFO - 2023-07-07 03:11:04 --> Helper loaded: my_helper
INFO - 2023-07-07 03:11:04 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:11:04 --> Controller Class Initialized
DEBUG - 2023-07-07 03:11:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-07 03:11:04 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:11:04 --> Final output sent to browser
DEBUG - 2023-07-07 03:11:04 --> Total execution time: 0.0295
INFO - 2023-07-07 03:15:32 --> Config Class Initialized
INFO - 2023-07-07 03:15:32 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:15:32 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:15:32 --> Utf8 Class Initialized
INFO - 2023-07-07 03:15:32 --> URI Class Initialized
INFO - 2023-07-07 03:15:32 --> Router Class Initialized
INFO - 2023-07-07 03:15:32 --> Output Class Initialized
INFO - 2023-07-07 03:15:32 --> Security Class Initialized
DEBUG - 2023-07-07 03:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:15:32 --> Input Class Initialized
INFO - 2023-07-07 03:15:32 --> Language Class Initialized
INFO - 2023-07-07 03:15:32 --> Language Class Initialized
INFO - 2023-07-07 03:15:32 --> Config Class Initialized
INFO - 2023-07-07 03:15:32 --> Loader Class Initialized
INFO - 2023-07-07 03:15:32 --> Helper loaded: url_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: file_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: form_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: my_helper
INFO - 2023-07-07 03:15:32 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:15:32 --> Controller Class Initialized
INFO - 2023-07-07 03:15:32 --> Helper loaded: cookie_helper
INFO - 2023-07-07 03:15:32 --> Final output sent to browser
DEBUG - 2023-07-07 03:15:32 --> Total execution time: 0.1095
INFO - 2023-07-07 03:15:32 --> Config Class Initialized
INFO - 2023-07-07 03:15:32 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:15:32 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:15:32 --> Utf8 Class Initialized
INFO - 2023-07-07 03:15:32 --> URI Class Initialized
INFO - 2023-07-07 03:15:32 --> Router Class Initialized
INFO - 2023-07-07 03:15:32 --> Output Class Initialized
INFO - 2023-07-07 03:15:32 --> Security Class Initialized
DEBUG - 2023-07-07 03:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:15:32 --> Input Class Initialized
INFO - 2023-07-07 03:15:32 --> Language Class Initialized
INFO - 2023-07-07 03:15:32 --> Language Class Initialized
INFO - 2023-07-07 03:15:32 --> Config Class Initialized
INFO - 2023-07-07 03:15:32 --> Loader Class Initialized
INFO - 2023-07-07 03:15:32 --> Helper loaded: url_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: file_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: form_helper
INFO - 2023-07-07 03:15:32 --> Helper loaded: my_helper
INFO - 2023-07-07 03:15:32 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:15:32 --> Controller Class Initialized
DEBUG - 2023-07-07 03:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-07 03:15:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:15:32 --> Final output sent to browser
DEBUG - 2023-07-07 03:15:32 --> Total execution time: 0.0890
INFO - 2023-07-07 03:16:21 --> Config Class Initialized
INFO - 2023-07-07 03:16:21 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:16:21 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:16:21 --> Utf8 Class Initialized
INFO - 2023-07-07 03:16:21 --> URI Class Initialized
INFO - 2023-07-07 03:16:21 --> Router Class Initialized
INFO - 2023-07-07 03:16:21 --> Output Class Initialized
INFO - 2023-07-07 03:16:21 --> Security Class Initialized
DEBUG - 2023-07-07 03:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:16:21 --> Input Class Initialized
INFO - 2023-07-07 03:16:21 --> Language Class Initialized
INFO - 2023-07-07 03:16:21 --> Language Class Initialized
INFO - 2023-07-07 03:16:21 --> Config Class Initialized
INFO - 2023-07-07 03:16:21 --> Loader Class Initialized
INFO - 2023-07-07 03:16:21 --> Helper loaded: url_helper
INFO - 2023-07-07 03:16:21 --> Helper loaded: file_helper
INFO - 2023-07-07 03:16:21 --> Helper loaded: form_helper
INFO - 2023-07-07 03:16:21 --> Helper loaded: my_helper
INFO - 2023-07-07 03:16:21 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:16:21 --> Controller Class Initialized
DEBUG - 2023-07-07 03:16:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-07-07 03:16:21 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:16:21 --> Final output sent to browser
DEBUG - 2023-07-07 03:16:21 --> Total execution time: 0.1671
INFO - 2023-07-07 03:17:33 --> Config Class Initialized
INFO - 2023-07-07 03:17:33 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:17:33 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:17:33 --> Utf8 Class Initialized
INFO - 2023-07-07 03:17:33 --> URI Class Initialized
INFO - 2023-07-07 03:17:33 --> Router Class Initialized
INFO - 2023-07-07 03:17:33 --> Output Class Initialized
INFO - 2023-07-07 03:17:33 --> Security Class Initialized
DEBUG - 2023-07-07 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:17:33 --> Input Class Initialized
INFO - 2023-07-07 03:17:33 --> Language Class Initialized
INFO - 2023-07-07 03:17:33 --> Language Class Initialized
INFO - 2023-07-07 03:17:33 --> Config Class Initialized
INFO - 2023-07-07 03:17:33 --> Loader Class Initialized
INFO - 2023-07-07 03:17:33 --> Helper loaded: url_helper
INFO - 2023-07-07 03:17:33 --> Helper loaded: file_helper
INFO - 2023-07-07 03:17:33 --> Helper loaded: form_helper
INFO - 2023-07-07 03:17:33 --> Helper loaded: my_helper
INFO - 2023-07-07 03:17:34 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:17:34 --> Controller Class Initialized
DEBUG - 2023-07-07 03:17:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-07 03:17:34 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:17:34 --> Final output sent to browser
DEBUG - 2023-07-07 03:17:34 --> Total execution time: 0.1453
INFO - 2023-07-07 03:17:34 --> Config Class Initialized
INFO - 2023-07-07 03:17:34 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:17:34 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:17:34 --> Utf8 Class Initialized
INFO - 2023-07-07 03:17:34 --> URI Class Initialized
INFO - 2023-07-07 03:17:34 --> Router Class Initialized
INFO - 2023-07-07 03:17:34 --> Output Class Initialized
INFO - 2023-07-07 03:17:34 --> Security Class Initialized
DEBUG - 2023-07-07 03:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:17:34 --> Input Class Initialized
INFO - 2023-07-07 03:17:34 --> Language Class Initialized
INFO - 2023-07-07 03:17:34 --> Language Class Initialized
INFO - 2023-07-07 03:17:34 --> Config Class Initialized
INFO - 2023-07-07 03:17:34 --> Loader Class Initialized
INFO - 2023-07-07 03:17:34 --> Helper loaded: url_helper
INFO - 2023-07-07 03:17:34 --> Helper loaded: file_helper
INFO - 2023-07-07 03:17:34 --> Helper loaded: form_helper
INFO - 2023-07-07 03:17:34 --> Helper loaded: my_helper
INFO - 2023-07-07 03:17:34 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:17:34 --> Controller Class Initialized
INFO - 2023-07-07 03:18:30 --> Config Class Initialized
INFO - 2023-07-07 03:18:30 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:18:30 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:18:30 --> Utf8 Class Initialized
INFO - 2023-07-07 03:18:30 --> URI Class Initialized
INFO - 2023-07-07 03:18:30 --> Router Class Initialized
INFO - 2023-07-07 03:18:30 --> Output Class Initialized
INFO - 2023-07-07 03:18:30 --> Security Class Initialized
DEBUG - 2023-07-07 03:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:18:30 --> Input Class Initialized
INFO - 2023-07-07 03:18:30 --> Language Class Initialized
INFO - 2023-07-07 03:18:30 --> Language Class Initialized
INFO - 2023-07-07 03:18:30 --> Config Class Initialized
INFO - 2023-07-07 03:18:30 --> Loader Class Initialized
INFO - 2023-07-07 03:18:30 --> Helper loaded: url_helper
INFO - 2023-07-07 03:18:30 --> Helper loaded: file_helper
INFO - 2023-07-07 03:18:30 --> Helper loaded: form_helper
INFO - 2023-07-07 03:18:30 --> Helper loaded: my_helper
INFO - 2023-07-07 03:18:30 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:18:30 --> Controller Class Initialized
INFO - 2023-07-07 03:18:30 --> Final output sent to browser
DEBUG - 2023-07-07 03:18:30 --> Total execution time: 0.0808
INFO - 2023-07-07 03:19:17 --> Config Class Initialized
INFO - 2023-07-07 03:19:17 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:19:17 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:19:17 --> Utf8 Class Initialized
INFO - 2023-07-07 03:19:17 --> URI Class Initialized
INFO - 2023-07-07 03:19:17 --> Router Class Initialized
INFO - 2023-07-07 03:19:17 --> Output Class Initialized
INFO - 2023-07-07 03:19:17 --> Security Class Initialized
DEBUG - 2023-07-07 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:19:17 --> Input Class Initialized
INFO - 2023-07-07 03:19:17 --> Language Class Initialized
INFO - 2023-07-07 03:19:17 --> Language Class Initialized
INFO - 2023-07-07 03:19:17 --> Config Class Initialized
INFO - 2023-07-07 03:19:17 --> Loader Class Initialized
INFO - 2023-07-07 03:19:17 --> Helper loaded: url_helper
INFO - 2023-07-07 03:19:17 --> Helper loaded: file_helper
INFO - 2023-07-07 03:19:17 --> Helper loaded: form_helper
INFO - 2023-07-07 03:19:17 --> Helper loaded: my_helper
INFO - 2023-07-07 03:19:17 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:19:17 --> Controller Class Initialized
INFO - 2023-07-07 03:19:17 --> Final output sent to browser
DEBUG - 2023-07-07 03:19:17 --> Total execution time: 0.0539
INFO - 2023-07-07 03:20:14 --> Config Class Initialized
INFO - 2023-07-07 03:20:14 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:20:14 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:20:14 --> Utf8 Class Initialized
INFO - 2023-07-07 03:20:14 --> URI Class Initialized
INFO - 2023-07-07 03:20:14 --> Router Class Initialized
INFO - 2023-07-07 03:20:14 --> Output Class Initialized
INFO - 2023-07-07 03:20:14 --> Security Class Initialized
DEBUG - 2023-07-07 03:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:20:14 --> Input Class Initialized
INFO - 2023-07-07 03:20:14 --> Language Class Initialized
INFO - 2023-07-07 03:20:14 --> Language Class Initialized
INFO - 2023-07-07 03:20:14 --> Config Class Initialized
INFO - 2023-07-07 03:20:14 --> Loader Class Initialized
INFO - 2023-07-07 03:20:14 --> Helper loaded: url_helper
INFO - 2023-07-07 03:20:14 --> Helper loaded: file_helper
INFO - 2023-07-07 03:20:14 --> Helper loaded: form_helper
INFO - 2023-07-07 03:20:14 --> Helper loaded: my_helper
INFO - 2023-07-07 03:20:14 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:20:14 --> Controller Class Initialized
INFO - 2023-07-07 03:20:14 --> Final output sent to browser
DEBUG - 2023-07-07 03:20:14 --> Total execution time: 0.0563
INFO - 2023-07-07 03:21:45 --> Config Class Initialized
INFO - 2023-07-07 03:21:45 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:21:45 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:21:45 --> Utf8 Class Initialized
INFO - 2023-07-07 03:21:45 --> URI Class Initialized
INFO - 2023-07-07 03:21:45 --> Router Class Initialized
INFO - 2023-07-07 03:21:45 --> Output Class Initialized
INFO - 2023-07-07 03:21:45 --> Security Class Initialized
DEBUG - 2023-07-07 03:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:21:45 --> Input Class Initialized
INFO - 2023-07-07 03:21:45 --> Language Class Initialized
INFO - 2023-07-07 03:21:45 --> Language Class Initialized
INFO - 2023-07-07 03:21:45 --> Config Class Initialized
INFO - 2023-07-07 03:21:45 --> Loader Class Initialized
INFO - 2023-07-07 03:21:45 --> Helper loaded: url_helper
INFO - 2023-07-07 03:21:45 --> Helper loaded: file_helper
INFO - 2023-07-07 03:21:45 --> Helper loaded: form_helper
INFO - 2023-07-07 03:21:45 --> Helper loaded: my_helper
INFO - 2023-07-07 03:21:45 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:21:45 --> Controller Class Initialized
INFO - 2023-07-07 03:21:45 --> Final output sent to browser
DEBUG - 2023-07-07 03:21:45 --> Total execution time: 0.0654
INFO - 2023-07-07 03:22:16 --> Config Class Initialized
INFO - 2023-07-07 03:22:16 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:22:16 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:22:16 --> Utf8 Class Initialized
INFO - 2023-07-07 03:22:16 --> URI Class Initialized
INFO - 2023-07-07 03:22:16 --> Router Class Initialized
INFO - 2023-07-07 03:22:16 --> Output Class Initialized
INFO - 2023-07-07 03:22:16 --> Security Class Initialized
DEBUG - 2023-07-07 03:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:22:16 --> Input Class Initialized
INFO - 2023-07-07 03:22:16 --> Language Class Initialized
INFO - 2023-07-07 03:22:16 --> Language Class Initialized
INFO - 2023-07-07 03:22:16 --> Config Class Initialized
INFO - 2023-07-07 03:22:16 --> Loader Class Initialized
INFO - 2023-07-07 03:22:16 --> Helper loaded: url_helper
INFO - 2023-07-07 03:22:16 --> Helper loaded: file_helper
INFO - 2023-07-07 03:22:16 --> Helper loaded: form_helper
INFO - 2023-07-07 03:22:16 --> Helper loaded: my_helper
INFO - 2023-07-07 03:22:16 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:22:16 --> Controller Class Initialized
INFO - 2023-07-07 03:22:16 --> Final output sent to browser
DEBUG - 2023-07-07 03:22:16 --> Total execution time: 0.0589
INFO - 2023-07-07 03:22:29 --> Config Class Initialized
INFO - 2023-07-07 03:22:29 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:22:29 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:22:29 --> Utf8 Class Initialized
INFO - 2023-07-07 03:22:29 --> URI Class Initialized
INFO - 2023-07-07 03:22:29 --> Router Class Initialized
INFO - 2023-07-07 03:22:29 --> Output Class Initialized
INFO - 2023-07-07 03:22:29 --> Security Class Initialized
DEBUG - 2023-07-07 03:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:22:29 --> Input Class Initialized
INFO - 2023-07-07 03:22:29 --> Language Class Initialized
INFO - 2023-07-07 03:22:29 --> Language Class Initialized
INFO - 2023-07-07 03:22:29 --> Config Class Initialized
INFO - 2023-07-07 03:22:29 --> Loader Class Initialized
INFO - 2023-07-07 03:22:29 --> Helper loaded: url_helper
INFO - 2023-07-07 03:22:29 --> Helper loaded: file_helper
INFO - 2023-07-07 03:22:29 --> Helper loaded: form_helper
INFO - 2023-07-07 03:22:29 --> Helper loaded: my_helper
INFO - 2023-07-07 03:22:29 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:22:29 --> Controller Class Initialized
INFO - 2023-07-07 03:22:29 --> Final output sent to browser
DEBUG - 2023-07-07 03:22:29 --> Total execution time: 0.0406
INFO - 2023-07-07 03:22:36 --> Config Class Initialized
INFO - 2023-07-07 03:22:36 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:22:36 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:22:36 --> Utf8 Class Initialized
INFO - 2023-07-07 03:22:36 --> URI Class Initialized
INFO - 2023-07-07 03:22:36 --> Router Class Initialized
INFO - 2023-07-07 03:22:36 --> Output Class Initialized
INFO - 2023-07-07 03:22:36 --> Security Class Initialized
DEBUG - 2023-07-07 03:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:22:36 --> Input Class Initialized
INFO - 2023-07-07 03:22:36 --> Language Class Initialized
INFO - 2023-07-07 03:22:36 --> Language Class Initialized
INFO - 2023-07-07 03:22:36 --> Config Class Initialized
INFO - 2023-07-07 03:22:36 --> Loader Class Initialized
INFO - 2023-07-07 03:22:36 --> Helper loaded: url_helper
INFO - 2023-07-07 03:22:36 --> Helper loaded: file_helper
INFO - 2023-07-07 03:22:36 --> Helper loaded: form_helper
INFO - 2023-07-07 03:22:36 --> Helper loaded: my_helper
INFO - 2023-07-07 03:22:36 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:22:36 --> Controller Class Initialized
INFO - 2023-07-07 03:22:36 --> Final output sent to browser
DEBUG - 2023-07-07 03:22:36 --> Total execution time: 0.0714
INFO - 2023-07-07 03:23:18 --> Config Class Initialized
INFO - 2023-07-07 03:23:18 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:23:18 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:23:18 --> Utf8 Class Initialized
INFO - 2023-07-07 03:23:18 --> URI Class Initialized
INFO - 2023-07-07 03:23:18 --> Router Class Initialized
INFO - 2023-07-07 03:23:18 --> Output Class Initialized
INFO - 2023-07-07 03:23:18 --> Security Class Initialized
DEBUG - 2023-07-07 03:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:23:18 --> Input Class Initialized
INFO - 2023-07-07 03:23:18 --> Language Class Initialized
INFO - 2023-07-07 03:23:18 --> Language Class Initialized
INFO - 2023-07-07 03:23:18 --> Config Class Initialized
INFO - 2023-07-07 03:23:18 --> Loader Class Initialized
INFO - 2023-07-07 03:23:18 --> Helper loaded: url_helper
INFO - 2023-07-07 03:23:18 --> Helper loaded: file_helper
INFO - 2023-07-07 03:23:18 --> Helper loaded: form_helper
INFO - 2023-07-07 03:23:18 --> Helper loaded: my_helper
INFO - 2023-07-07 03:23:18 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:23:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:23:18 --> Controller Class Initialized
INFO - 2023-07-07 03:26:52 --> Config Class Initialized
INFO - 2023-07-07 03:26:52 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:26:52 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:26:52 --> Utf8 Class Initialized
INFO - 2023-07-07 03:26:52 --> URI Class Initialized
INFO - 2023-07-07 03:26:52 --> Router Class Initialized
INFO - 2023-07-07 03:26:52 --> Output Class Initialized
INFO - 2023-07-07 03:26:52 --> Security Class Initialized
DEBUG - 2023-07-07 03:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:26:52 --> Input Class Initialized
INFO - 2023-07-07 03:26:52 --> Language Class Initialized
INFO - 2023-07-07 03:26:52 --> Language Class Initialized
INFO - 2023-07-07 03:26:52 --> Config Class Initialized
INFO - 2023-07-07 03:26:52 --> Loader Class Initialized
INFO - 2023-07-07 03:26:52 --> Helper loaded: url_helper
INFO - 2023-07-07 03:26:52 --> Helper loaded: file_helper
INFO - 2023-07-07 03:26:52 --> Helper loaded: form_helper
INFO - 2023-07-07 03:26:52 --> Helper loaded: my_helper
INFO - 2023-07-07 03:26:52 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:26:52 --> Controller Class Initialized
DEBUG - 2023-07-07 03:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-07-07 03:26:52 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:26:52 --> Final output sent to browser
DEBUG - 2023-07-07 03:26:52 --> Total execution time: 0.1093
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:27:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:27:07 --> Utf8 Class Initialized
INFO - 2023-07-07 03:27:07 --> URI Class Initialized
INFO - 2023-07-07 03:27:07 --> Router Class Initialized
INFO - 2023-07-07 03:27:07 --> Output Class Initialized
INFO - 2023-07-07 03:27:07 --> Security Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:27:07 --> Input Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Loader Class Initialized
INFO - 2023-07-07 03:27:07 --> Helper loaded: url_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: file_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: form_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: my_helper
INFO - 2023-07-07 03:27:07 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:27:07 --> Controller Class Initialized
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:27:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:27:07 --> Utf8 Class Initialized
INFO - 2023-07-07 03:27:07 --> URI Class Initialized
INFO - 2023-07-07 03:27:07 --> Router Class Initialized
INFO - 2023-07-07 03:27:07 --> Output Class Initialized
INFO - 2023-07-07 03:27:07 --> Security Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:27:07 --> Input Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Loader Class Initialized
INFO - 2023-07-07 03:27:07 --> Helper loaded: url_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: file_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: form_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: my_helper
INFO - 2023-07-07 03:27:07 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:27:07 --> Controller Class Initialized
DEBUG - 2023-07-07 03:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-07-07 03:27:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:27:07 --> Final output sent to browser
DEBUG - 2023-07-07 03:27:07 --> Total execution time: 0.0481
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:27:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:27:07 --> Utf8 Class Initialized
INFO - 2023-07-07 03:27:07 --> URI Class Initialized
INFO - 2023-07-07 03:27:07 --> Router Class Initialized
INFO - 2023-07-07 03:27:07 --> Output Class Initialized
INFO - 2023-07-07 03:27:07 --> Security Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:27:07 --> Input Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Language Class Initialized
INFO - 2023-07-07 03:27:07 --> Config Class Initialized
INFO - 2023-07-07 03:27:07 --> Loader Class Initialized
INFO - 2023-07-07 03:27:07 --> Helper loaded: url_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: file_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: form_helper
INFO - 2023-07-07 03:27:07 --> Helper loaded: my_helper
INFO - 2023-07-07 03:27:07 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:27:07 --> Controller Class Initialized
INFO - 2023-07-07 03:27:12 --> Config Class Initialized
INFO - 2023-07-07 03:27:12 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:27:12 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:27:12 --> Utf8 Class Initialized
INFO - 2023-07-07 03:27:12 --> URI Class Initialized
INFO - 2023-07-07 03:27:12 --> Router Class Initialized
INFO - 2023-07-07 03:27:12 --> Output Class Initialized
INFO - 2023-07-07 03:27:12 --> Security Class Initialized
DEBUG - 2023-07-07 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:27:12 --> Input Class Initialized
INFO - 2023-07-07 03:27:12 --> Language Class Initialized
INFO - 2023-07-07 03:27:12 --> Language Class Initialized
INFO - 2023-07-07 03:27:12 --> Config Class Initialized
INFO - 2023-07-07 03:27:12 --> Loader Class Initialized
INFO - 2023-07-07 03:27:12 --> Helper loaded: url_helper
INFO - 2023-07-07 03:27:12 --> Helper loaded: file_helper
INFO - 2023-07-07 03:27:12 --> Helper loaded: form_helper
INFO - 2023-07-07 03:27:12 --> Helper loaded: my_helper
INFO - 2023-07-07 03:27:12 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:27:12 --> Controller Class Initialized
INFO - 2023-07-07 03:27:12 --> Final output sent to browser
DEBUG - 2023-07-07 03:27:12 --> Total execution time: 0.0484
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:35:23 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:35:23 --> Utf8 Class Initialized
INFO - 2023-07-07 03:35:23 --> URI Class Initialized
INFO - 2023-07-07 03:35:23 --> Router Class Initialized
INFO - 2023-07-07 03:35:23 --> Output Class Initialized
INFO - 2023-07-07 03:35:23 --> Security Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:35:23 --> Input Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Loader Class Initialized
INFO - 2023-07-07 03:35:23 --> Helper loaded: url_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: file_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: form_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: my_helper
INFO - 2023-07-07 03:35:23 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:35:23 --> Controller Class Initialized
INFO - 2023-07-07 03:35:23 --> Helper loaded: cookie_helper
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:35:23 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:35:23 --> Utf8 Class Initialized
INFO - 2023-07-07 03:35:23 --> URI Class Initialized
INFO - 2023-07-07 03:35:23 --> Router Class Initialized
INFO - 2023-07-07 03:35:23 --> Output Class Initialized
INFO - 2023-07-07 03:35:23 --> Security Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:35:23 --> Input Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Loader Class Initialized
INFO - 2023-07-07 03:35:23 --> Helper loaded: url_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: file_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: form_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: my_helper
INFO - 2023-07-07 03:35:23 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:35:23 --> Controller Class Initialized
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:35:23 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:35:23 --> Utf8 Class Initialized
INFO - 2023-07-07 03:35:23 --> URI Class Initialized
INFO - 2023-07-07 03:35:23 --> Router Class Initialized
INFO - 2023-07-07 03:35:23 --> Output Class Initialized
INFO - 2023-07-07 03:35:23 --> Security Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:35:23 --> Input Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Language Class Initialized
INFO - 2023-07-07 03:35:23 --> Config Class Initialized
INFO - 2023-07-07 03:35:23 --> Loader Class Initialized
INFO - 2023-07-07 03:35:23 --> Helper loaded: url_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: file_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: form_helper
INFO - 2023-07-07 03:35:23 --> Helper loaded: my_helper
INFO - 2023-07-07 03:35:23 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:35:23 --> Controller Class Initialized
DEBUG - 2023-07-07 03:35:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-07 03:35:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:35:23 --> Final output sent to browser
DEBUG - 2023-07-07 03:35:23 --> Total execution time: 0.0372
INFO - 2023-07-07 03:35:36 --> Config Class Initialized
INFO - 2023-07-07 03:35:36 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:35:36 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:35:36 --> Utf8 Class Initialized
INFO - 2023-07-07 03:35:36 --> URI Class Initialized
INFO - 2023-07-07 03:35:36 --> Router Class Initialized
INFO - 2023-07-07 03:35:36 --> Output Class Initialized
INFO - 2023-07-07 03:35:36 --> Security Class Initialized
DEBUG - 2023-07-07 03:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:35:36 --> Input Class Initialized
INFO - 2023-07-07 03:35:36 --> Language Class Initialized
INFO - 2023-07-07 03:35:36 --> Language Class Initialized
INFO - 2023-07-07 03:35:36 --> Config Class Initialized
INFO - 2023-07-07 03:35:36 --> Loader Class Initialized
INFO - 2023-07-07 03:35:36 --> Helper loaded: url_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: file_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: form_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: my_helper
INFO - 2023-07-07 03:35:36 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:35:36 --> Controller Class Initialized
INFO - 2023-07-07 03:35:36 --> Helper loaded: cookie_helper
INFO - 2023-07-07 03:35:36 --> Final output sent to browser
DEBUG - 2023-07-07 03:35:36 --> Total execution time: 0.0697
INFO - 2023-07-07 03:35:36 --> Config Class Initialized
INFO - 2023-07-07 03:35:36 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:35:36 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:35:36 --> Utf8 Class Initialized
INFO - 2023-07-07 03:35:36 --> URI Class Initialized
INFO - 2023-07-07 03:35:36 --> Router Class Initialized
INFO - 2023-07-07 03:35:36 --> Output Class Initialized
INFO - 2023-07-07 03:35:36 --> Security Class Initialized
DEBUG - 2023-07-07 03:35:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:35:36 --> Input Class Initialized
INFO - 2023-07-07 03:35:36 --> Language Class Initialized
INFO - 2023-07-07 03:35:36 --> Language Class Initialized
INFO - 2023-07-07 03:35:36 --> Config Class Initialized
INFO - 2023-07-07 03:35:36 --> Loader Class Initialized
INFO - 2023-07-07 03:35:36 --> Helper loaded: url_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: file_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: form_helper
INFO - 2023-07-07 03:35:36 --> Helper loaded: my_helper
INFO - 2023-07-07 03:35:36 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:35:36 --> Controller Class Initialized
DEBUG - 2023-07-07 03:35:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home_guru.php
DEBUG - 2023-07-07 03:35:36 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:35:36 --> Final output sent to browser
DEBUG - 2023-07-07 03:35:36 --> Total execution time: 0.0646
INFO - 2023-07-07 03:36:07 --> Config Class Initialized
INFO - 2023-07-07 03:36:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:36:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:36:07 --> Utf8 Class Initialized
INFO - 2023-07-07 03:36:07 --> URI Class Initialized
INFO - 2023-07-07 03:36:07 --> Router Class Initialized
INFO - 2023-07-07 03:36:07 --> Output Class Initialized
INFO - 2023-07-07 03:36:07 --> Security Class Initialized
DEBUG - 2023-07-07 03:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:36:07 --> Input Class Initialized
INFO - 2023-07-07 03:36:07 --> Language Class Initialized
INFO - 2023-07-07 03:36:07 --> Language Class Initialized
INFO - 2023-07-07 03:36:07 --> Config Class Initialized
INFO - 2023-07-07 03:36:07 --> Loader Class Initialized
INFO - 2023-07-07 03:36:07 --> Helper loaded: url_helper
INFO - 2023-07-07 03:36:07 --> Helper loaded: file_helper
INFO - 2023-07-07 03:36:07 --> Helper loaded: form_helper
INFO - 2023-07-07 03:36:07 --> Helper loaded: my_helper
INFO - 2023-07-07 03:36:07 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:36:07 --> Controller Class Initialized
DEBUG - 2023-07-07 03:36:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_absensi/views/list.php
DEBUG - 2023-07-07 03:36:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:36:07 --> Final output sent to browser
DEBUG - 2023-07-07 03:36:07 --> Total execution time: 0.1418
INFO - 2023-07-07 03:36:55 --> Config Class Initialized
INFO - 2023-07-07 03:36:55 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:36:55 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:36:55 --> Utf8 Class Initialized
INFO - 2023-07-07 03:36:55 --> URI Class Initialized
INFO - 2023-07-07 03:36:55 --> Router Class Initialized
INFO - 2023-07-07 03:36:55 --> Output Class Initialized
INFO - 2023-07-07 03:36:55 --> Security Class Initialized
DEBUG - 2023-07-07 03:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:36:55 --> Input Class Initialized
INFO - 2023-07-07 03:36:55 --> Language Class Initialized
INFO - 2023-07-07 03:36:55 --> Language Class Initialized
INFO - 2023-07-07 03:36:55 --> Config Class Initialized
INFO - 2023-07-07 03:36:55 --> Loader Class Initialized
INFO - 2023-07-07 03:36:55 --> Helper loaded: url_helper
INFO - 2023-07-07 03:36:55 --> Helper loaded: file_helper
INFO - 2023-07-07 03:36:55 --> Helper loaded: form_helper
INFO - 2023-07-07 03:36:55 --> Helper loaded: my_helper
INFO - 2023-07-07 03:36:55 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:36:55 --> Controller Class Initialized
DEBUG - 2023-07-07 03:36:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_ekstra/views/list.php
DEBUG - 2023-07-07 03:36:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:36:55 --> Final output sent to browser
DEBUG - 2023-07-07 03:36:55 --> Total execution time: 0.1868
INFO - 2023-07-07 03:38:25 --> Config Class Initialized
INFO - 2023-07-07 03:38:25 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:38:25 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:38:25 --> Utf8 Class Initialized
INFO - 2023-07-07 03:38:25 --> URI Class Initialized
INFO - 2023-07-07 03:38:25 --> Router Class Initialized
INFO - 2023-07-07 03:38:25 --> Output Class Initialized
INFO - 2023-07-07 03:38:25 --> Security Class Initialized
DEBUG - 2023-07-07 03:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:38:25 --> Input Class Initialized
INFO - 2023-07-07 03:38:25 --> Language Class Initialized
INFO - 2023-07-07 03:38:25 --> Language Class Initialized
INFO - 2023-07-07 03:38:25 --> Config Class Initialized
INFO - 2023-07-07 03:38:25 --> Loader Class Initialized
INFO - 2023-07-07 03:38:25 --> Helper loaded: url_helper
INFO - 2023-07-07 03:38:25 --> Helper loaded: file_helper
INFO - 2023-07-07 03:38:25 --> Helper loaded: form_helper
INFO - 2023-07-07 03:38:25 --> Helper loaded: my_helper
INFO - 2023-07-07 03:38:25 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:38:25 --> Controller Class Initialized
INFO - 2023-07-07 03:38:25 --> Final output sent to browser
DEBUG - 2023-07-07 03:38:25 --> Total execution time: 0.0620
INFO - 2023-07-07 03:38:42 --> Config Class Initialized
INFO - 2023-07-07 03:38:42 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:38:42 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:38:42 --> Utf8 Class Initialized
INFO - 2023-07-07 03:38:42 --> URI Class Initialized
INFO - 2023-07-07 03:38:42 --> Router Class Initialized
INFO - 2023-07-07 03:38:42 --> Output Class Initialized
INFO - 2023-07-07 03:38:42 --> Security Class Initialized
DEBUG - 2023-07-07 03:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:38:42 --> Input Class Initialized
INFO - 2023-07-07 03:38:42 --> Language Class Initialized
INFO - 2023-07-07 03:38:42 --> Language Class Initialized
INFO - 2023-07-07 03:38:42 --> Config Class Initialized
INFO - 2023-07-07 03:38:42 --> Loader Class Initialized
INFO - 2023-07-07 03:38:42 --> Helper loaded: url_helper
INFO - 2023-07-07 03:38:42 --> Helper loaded: file_helper
INFO - 2023-07-07 03:38:42 --> Helper loaded: form_helper
INFO - 2023-07-07 03:38:42 --> Helper loaded: my_helper
INFO - 2023-07-07 03:38:42 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:38:42 --> Controller Class Initialized
DEBUG - 2023-07-07 03:38:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_prestasi/views/list.php
DEBUG - 2023-07-07 03:38:42 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:38:42 --> Final output sent to browser
DEBUG - 2023-07-07 03:38:42 --> Total execution time: 0.0996
INFO - 2023-07-07 03:38:43 --> Config Class Initialized
INFO - 2023-07-07 03:38:43 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:38:43 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:38:43 --> Utf8 Class Initialized
INFO - 2023-07-07 03:38:43 --> URI Class Initialized
INFO - 2023-07-07 03:38:43 --> Router Class Initialized
INFO - 2023-07-07 03:38:43 --> Output Class Initialized
INFO - 2023-07-07 03:38:43 --> Security Class Initialized
DEBUG - 2023-07-07 03:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:38:43 --> Input Class Initialized
INFO - 2023-07-07 03:38:43 --> Language Class Initialized
INFO - 2023-07-07 03:38:43 --> Language Class Initialized
INFO - 2023-07-07 03:38:43 --> Config Class Initialized
INFO - 2023-07-07 03:38:43 --> Loader Class Initialized
INFO - 2023-07-07 03:38:43 --> Helper loaded: url_helper
INFO - 2023-07-07 03:38:43 --> Helper loaded: file_helper
INFO - 2023-07-07 03:38:43 --> Helper loaded: form_helper
INFO - 2023-07-07 03:38:43 --> Helper loaded: my_helper
INFO - 2023-07-07 03:38:43 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:38:43 --> Controller Class Initialized
INFO - 2023-07-07 03:39:26 --> Config Class Initialized
INFO - 2023-07-07 03:39:26 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:39:26 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:39:26 --> Utf8 Class Initialized
INFO - 2023-07-07 03:39:26 --> URI Class Initialized
INFO - 2023-07-07 03:39:26 --> Router Class Initialized
INFO - 2023-07-07 03:39:26 --> Output Class Initialized
INFO - 2023-07-07 03:39:26 --> Security Class Initialized
DEBUG - 2023-07-07 03:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:39:26 --> Input Class Initialized
INFO - 2023-07-07 03:39:26 --> Language Class Initialized
INFO - 2023-07-07 03:39:26 --> Language Class Initialized
INFO - 2023-07-07 03:39:26 --> Config Class Initialized
INFO - 2023-07-07 03:39:26 --> Loader Class Initialized
INFO - 2023-07-07 03:39:26 --> Helper loaded: url_helper
INFO - 2023-07-07 03:39:26 --> Helper loaded: file_helper
INFO - 2023-07-07 03:39:26 --> Helper loaded: form_helper
INFO - 2023-07-07 03:39:26 --> Helper loaded: my_helper
INFO - 2023-07-07 03:39:26 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:39:26 --> Controller Class Initialized
DEBUG - 2023-07-07 03:39:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-07-07 03:39:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:39:26 --> Final output sent to browser
DEBUG - 2023-07-07 03:39:26 --> Total execution time: 0.1434
INFO - 2023-07-07 03:39:38 --> Config Class Initialized
INFO - 2023-07-07 03:39:38 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:39:38 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:39:38 --> Utf8 Class Initialized
INFO - 2023-07-07 03:39:38 --> URI Class Initialized
INFO - 2023-07-07 03:39:38 --> Router Class Initialized
INFO - 2023-07-07 03:39:38 --> Output Class Initialized
INFO - 2023-07-07 03:39:38 --> Security Class Initialized
DEBUG - 2023-07-07 03:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:39:38 --> Input Class Initialized
INFO - 2023-07-07 03:39:38 --> Language Class Initialized
INFO - 2023-07-07 03:39:38 --> Language Class Initialized
INFO - 2023-07-07 03:39:38 --> Config Class Initialized
INFO - 2023-07-07 03:39:38 --> Loader Class Initialized
INFO - 2023-07-07 03:39:38 --> Helper loaded: url_helper
INFO - 2023-07-07 03:39:38 --> Helper loaded: file_helper
INFO - 2023-07-07 03:39:38 --> Helper loaded: form_helper
INFO - 2023-07-07 03:39:38 --> Helper loaded: my_helper
INFO - 2023-07-07 03:39:38 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:39:38 --> Controller Class Initialized
DEBUG - 2023-07-07 03:39:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-07 03:39:39 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:39:39 --> Final output sent to browser
DEBUG - 2023-07-07 03:39:39 --> Total execution time: 0.1236
INFO - 2023-07-07 03:39:54 --> Config Class Initialized
INFO - 2023-07-07 03:39:54 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:39:55 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:39:55 --> Utf8 Class Initialized
INFO - 2023-07-07 03:39:55 --> URI Class Initialized
INFO - 2023-07-07 03:39:55 --> Router Class Initialized
INFO - 2023-07-07 03:39:55 --> Output Class Initialized
INFO - 2023-07-07 03:39:55 --> Security Class Initialized
DEBUG - 2023-07-07 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:39:55 --> Input Class Initialized
INFO - 2023-07-07 03:39:55 --> Language Class Initialized
INFO - 2023-07-07 03:39:55 --> Language Class Initialized
INFO - 2023-07-07 03:39:55 --> Config Class Initialized
INFO - 2023-07-07 03:39:55 --> Loader Class Initialized
INFO - 2023-07-07 03:39:55 --> Helper loaded: url_helper
INFO - 2023-07-07 03:39:55 --> Helper loaded: file_helper
INFO - 2023-07-07 03:39:55 --> Helper loaded: form_helper
INFO - 2023-07-07 03:39:55 --> Helper loaded: my_helper
INFO - 2023-07-07 03:39:55 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:39:55 --> Controller Class Initialized
DEBUG - 2023-07-07 03:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan_kl1/views/list.php
DEBUG - 2023-07-07 03:39:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:39:55 --> Final output sent to browser
DEBUG - 2023-07-07 03:39:55 --> Total execution time: 0.1636
INFO - 2023-07-07 03:41:27 --> Config Class Initialized
INFO - 2023-07-07 03:41:27 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:41:27 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:41:27 --> Utf8 Class Initialized
INFO - 2023-07-07 03:41:27 --> URI Class Initialized
INFO - 2023-07-07 03:41:27 --> Router Class Initialized
INFO - 2023-07-07 03:41:27 --> Output Class Initialized
INFO - 2023-07-07 03:41:27 --> Security Class Initialized
DEBUG - 2023-07-07 03:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:41:27 --> Input Class Initialized
INFO - 2023-07-07 03:41:27 --> Language Class Initialized
INFO - 2023-07-07 03:41:27 --> Language Class Initialized
INFO - 2023-07-07 03:41:27 --> Config Class Initialized
INFO - 2023-07-07 03:41:27 --> Loader Class Initialized
INFO - 2023-07-07 03:41:27 --> Helper loaded: url_helper
INFO - 2023-07-07 03:41:27 --> Helper loaded: file_helper
INFO - 2023-07-07 03:41:27 --> Helper loaded: form_helper
INFO - 2023-07-07 03:41:27 --> Helper loaded: my_helper
INFO - 2023-07-07 03:41:27 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:41:27 --> Controller Class Initialized
DEBUG - 2023-07-07 03:41:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-07-07 03:41:27 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:41:27 --> Final output sent to browser
DEBUG - 2023-07-07 03:41:27 --> Total execution time: 0.1154
INFO - 2023-07-07 03:41:49 --> Config Class Initialized
INFO - 2023-07-07 03:41:49 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:41:49 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:41:49 --> Utf8 Class Initialized
INFO - 2023-07-07 03:41:49 --> URI Class Initialized
INFO - 2023-07-07 03:41:49 --> Router Class Initialized
INFO - 2023-07-07 03:41:50 --> Output Class Initialized
INFO - 2023-07-07 03:41:50 --> Security Class Initialized
DEBUG - 2023-07-07 03:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:41:50 --> Input Class Initialized
INFO - 2023-07-07 03:41:50 --> Language Class Initialized
INFO - 2023-07-07 03:41:50 --> Language Class Initialized
INFO - 2023-07-07 03:41:50 --> Config Class Initialized
INFO - 2023-07-07 03:41:50 --> Loader Class Initialized
INFO - 2023-07-07 03:41:50 --> Helper loaded: url_helper
INFO - 2023-07-07 03:41:50 --> Helper loaded: file_helper
INFO - 2023-07-07 03:41:50 --> Helper loaded: form_helper
INFO - 2023-07-07 03:41:50 --> Helper loaded: my_helper
INFO - 2023-07-07 03:41:50 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:41:50 --> Controller Class Initialized
DEBUG - 2023-07-07 03:41:50 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-07-07 03:41:52 --> Final output sent to browser
DEBUG - 2023-07-07 03:41:52 --> Total execution time: 2.5260
INFO - 2023-07-07 03:41:58 --> Config Class Initialized
INFO - 2023-07-07 03:41:58 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:41:58 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:41:58 --> Utf8 Class Initialized
INFO - 2023-07-07 03:41:58 --> URI Class Initialized
INFO - 2023-07-07 03:41:58 --> Router Class Initialized
INFO - 2023-07-07 03:41:58 --> Output Class Initialized
INFO - 2023-07-07 03:41:58 --> Security Class Initialized
DEBUG - 2023-07-07 03:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:41:58 --> Input Class Initialized
INFO - 2023-07-07 03:41:58 --> Language Class Initialized
INFO - 2023-07-07 03:41:58 --> Language Class Initialized
INFO - 2023-07-07 03:41:58 --> Config Class Initialized
INFO - 2023-07-07 03:41:58 --> Loader Class Initialized
INFO - 2023-07-07 03:41:58 --> Helper loaded: url_helper
INFO - 2023-07-07 03:41:58 --> Helper loaded: file_helper
INFO - 2023-07-07 03:41:58 --> Helper loaded: form_helper
INFO - 2023-07-07 03:41:58 --> Helper loaded: my_helper
INFO - 2023-07-07 03:41:58 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:41:58 --> Controller Class Initialized
DEBUG - 2023-07-07 03:41:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/cetak_pts_sd.php
INFO - 2023-07-07 03:41:59 --> Final output sent to browser
DEBUG - 2023-07-07 03:41:59 --> Total execution time: 0.7258
INFO - 2023-07-07 03:43:22 --> Config Class Initialized
INFO - 2023-07-07 03:43:22 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:43:22 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:43:22 --> Utf8 Class Initialized
INFO - 2023-07-07 03:43:22 --> URI Class Initialized
INFO - 2023-07-07 03:43:23 --> Router Class Initialized
INFO - 2023-07-07 03:43:23 --> Output Class Initialized
INFO - 2023-07-07 03:43:23 --> Security Class Initialized
DEBUG - 2023-07-07 03:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:43:23 --> Input Class Initialized
INFO - 2023-07-07 03:43:23 --> Language Class Initialized
INFO - 2023-07-07 03:43:23 --> Language Class Initialized
INFO - 2023-07-07 03:43:23 --> Config Class Initialized
INFO - 2023-07-07 03:43:23 --> Loader Class Initialized
INFO - 2023-07-07 03:43:23 --> Helper loaded: url_helper
INFO - 2023-07-07 03:43:23 --> Helper loaded: file_helper
INFO - 2023-07-07 03:43:23 --> Helper loaded: form_helper
INFO - 2023-07-07 03:43:23 --> Helper loaded: my_helper
INFO - 2023-07-07 03:43:23 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:43:23 --> Controller Class Initialized
DEBUG - 2023-07-07 03:43:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-07 03:43:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:43:23 --> Final output sent to browser
DEBUG - 2023-07-07 03:43:23 --> Total execution time: 0.0437
INFO - 2023-07-07 03:44:07 --> Config Class Initialized
INFO - 2023-07-07 03:44:07 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:44:07 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:44:07 --> Utf8 Class Initialized
INFO - 2023-07-07 03:44:07 --> URI Class Initialized
INFO - 2023-07-07 03:44:07 --> Router Class Initialized
INFO - 2023-07-07 03:44:07 --> Output Class Initialized
INFO - 2023-07-07 03:44:07 --> Security Class Initialized
DEBUG - 2023-07-07 03:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:44:07 --> Input Class Initialized
INFO - 2023-07-07 03:44:07 --> Language Class Initialized
INFO - 2023-07-07 03:44:07 --> Language Class Initialized
INFO - 2023-07-07 03:44:07 --> Config Class Initialized
INFO - 2023-07-07 03:44:07 --> Loader Class Initialized
INFO - 2023-07-07 03:44:07 --> Helper loaded: url_helper
INFO - 2023-07-07 03:44:07 --> Helper loaded: file_helper
INFO - 2023-07-07 03:44:07 --> Helper loaded: form_helper
INFO - 2023-07-07 03:44:07 --> Helper loaded: my_helper
INFO - 2023-07-07 03:44:07 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:44:07 --> Controller Class Initialized
DEBUG - 2023-07-07 03:44:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-07-07 03:44:07 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:44:07 --> Final output sent to browser
DEBUG - 2023-07-07 03:44:07 --> Total execution time: 0.0748
INFO - 2023-07-07 03:44:24 --> Config Class Initialized
INFO - 2023-07-07 03:44:24 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:44:24 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:44:24 --> Utf8 Class Initialized
INFO - 2023-07-07 03:44:24 --> URI Class Initialized
INFO - 2023-07-07 03:44:24 --> Router Class Initialized
INFO - 2023-07-07 03:44:24 --> Output Class Initialized
INFO - 2023-07-07 03:44:24 --> Security Class Initialized
DEBUG - 2023-07-07 03:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:44:24 --> Input Class Initialized
INFO - 2023-07-07 03:44:24 --> Language Class Initialized
INFO - 2023-07-07 03:44:24 --> Language Class Initialized
INFO - 2023-07-07 03:44:24 --> Config Class Initialized
INFO - 2023-07-07 03:44:24 --> Loader Class Initialized
INFO - 2023-07-07 03:44:24 --> Helper loaded: url_helper
INFO - 2023-07-07 03:44:24 --> Helper loaded: file_helper
INFO - 2023-07-07 03:44:24 --> Helper loaded: form_helper
INFO - 2023-07-07 03:44:24 --> Helper loaded: my_helper
INFO - 2023-07-07 03:44:24 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:44:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:44:24 --> Controller Class Initialized
DEBUG - 2023-07-07 03:44:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/list.php
DEBUG - 2023-07-07 03:44:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:44:25 --> Final output sent to browser
DEBUG - 2023-07-07 03:44:25 --> Total execution time: 0.1678
INFO - 2023-07-07 03:44:52 --> Config Class Initialized
INFO - 2023-07-07 03:44:52 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:44:52 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:44:52 --> Utf8 Class Initialized
INFO - 2023-07-07 03:44:52 --> URI Class Initialized
INFO - 2023-07-07 03:44:52 --> Router Class Initialized
INFO - 2023-07-07 03:44:52 --> Output Class Initialized
INFO - 2023-07-07 03:44:52 --> Security Class Initialized
DEBUG - 2023-07-07 03:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:44:52 --> Input Class Initialized
INFO - 2023-07-07 03:44:52 --> Language Class Initialized
INFO - 2023-07-07 03:44:53 --> Language Class Initialized
INFO - 2023-07-07 03:44:53 --> Config Class Initialized
INFO - 2023-07-07 03:44:53 --> Loader Class Initialized
INFO - 2023-07-07 03:44:53 --> Helper loaded: url_helper
INFO - 2023-07-07 03:44:53 --> Helper loaded: file_helper
INFO - 2023-07-07 03:44:53 --> Helper loaded: form_helper
INFO - 2023-07-07 03:44:53 --> Helper loaded: my_helper
INFO - 2023-07-07 03:44:53 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:44:53 --> Controller Class Initialized
DEBUG - 2023-07-07 03:44:53 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-07-07 03:44:54 --> Final output sent to browser
DEBUG - 2023-07-07 03:44:54 --> Total execution time: 1.5741
INFO - 2023-07-07 03:47:48 --> Config Class Initialized
INFO - 2023-07-07 03:47:48 --> Hooks Class Initialized
DEBUG - 2023-07-07 03:47:48 --> UTF-8 Support Enabled
INFO - 2023-07-07 03:47:48 --> Utf8 Class Initialized
INFO - 2023-07-07 03:47:48 --> URI Class Initialized
INFO - 2023-07-07 03:47:48 --> Router Class Initialized
INFO - 2023-07-07 03:47:48 --> Output Class Initialized
INFO - 2023-07-07 03:47:48 --> Security Class Initialized
DEBUG - 2023-07-07 03:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-07 03:47:48 --> Input Class Initialized
INFO - 2023-07-07 03:47:48 --> Language Class Initialized
INFO - 2023-07-07 03:47:48 --> Language Class Initialized
INFO - 2023-07-07 03:47:48 --> Config Class Initialized
INFO - 2023-07-07 03:47:48 --> Loader Class Initialized
INFO - 2023-07-07 03:47:48 --> Helper loaded: url_helper
INFO - 2023-07-07 03:47:48 --> Helper loaded: file_helper
INFO - 2023-07-07 03:47:48 --> Helper loaded: form_helper
INFO - 2023-07-07 03:47:48 --> Helper loaded: my_helper
INFO - 2023-07-07 03:47:48 --> Database Driver Class Initialized
DEBUG - 2023-07-07 03:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-07 03:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-07 03:47:48 --> Controller Class Initialized
DEBUG - 2023-07-07 03:47:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/n_catatan/views/list.php
DEBUG - 2023-07-07 03:47:48 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-07 03:47:48 --> Final output sent to browser
DEBUG - 2023-07-07 03:47:48 --> Total execution time: 0.0455
