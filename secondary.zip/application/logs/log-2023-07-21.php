<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-07-21 08:28:25 --> Config Class Initialized
INFO - 2023-07-21 08:28:25 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:28:25 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:28:25 --> Utf8 Class Initialized
INFO - 2023-07-21 08:28:25 --> URI Class Initialized
DEBUG - 2023-07-21 08:28:25 --> No URI present. Default controller set.
INFO - 2023-07-21 08:28:25 --> Router Class Initialized
INFO - 2023-07-21 08:28:25 --> Output Class Initialized
INFO - 2023-07-21 08:28:25 --> Security Class Initialized
DEBUG - 2023-07-21 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:28:25 --> Input Class Initialized
INFO - 2023-07-21 08:28:25 --> Language Class Initialized
INFO - 2023-07-21 08:28:25 --> Language Class Initialized
INFO - 2023-07-21 08:28:25 --> Config Class Initialized
INFO - 2023-07-21 08:28:25 --> Loader Class Initialized
INFO - 2023-07-21 08:28:25 --> Helper loaded: url_helper
INFO - 2023-07-21 08:28:25 --> Helper loaded: file_helper
INFO - 2023-07-21 08:28:25 --> Helper loaded: form_helper
INFO - 2023-07-21 08:28:25 --> Helper loaded: my_helper
INFO - 2023-07-21 08:28:26 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:28:26 --> Controller Class Initialized
INFO - 2023-07-21 08:28:26 --> Config Class Initialized
INFO - 2023-07-21 08:28:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:28:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:28:26 --> Utf8 Class Initialized
INFO - 2023-07-21 08:28:26 --> URI Class Initialized
DEBUG - 2023-07-21 08:28:26 --> No URI present. Default controller set.
INFO - 2023-07-21 08:28:26 --> Router Class Initialized
INFO - 2023-07-21 08:28:26 --> Output Class Initialized
INFO - 2023-07-21 08:28:26 --> Security Class Initialized
DEBUG - 2023-07-21 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:28:26 --> Input Class Initialized
INFO - 2023-07-21 08:28:26 --> Language Class Initialized
INFO - 2023-07-21 08:28:26 --> Language Class Initialized
INFO - 2023-07-21 08:28:26 --> Config Class Initialized
INFO - 2023-07-21 08:28:26 --> Loader Class Initialized
INFO - 2023-07-21 08:28:26 --> Helper loaded: url_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: file_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: form_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: my_helper
INFO - 2023-07-21 08:28:26 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:28:26 --> Controller Class Initialized
INFO - 2023-07-21 08:28:26 --> Config Class Initialized
INFO - 2023-07-21 08:28:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:28:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:28:26 --> Utf8 Class Initialized
INFO - 2023-07-21 08:28:26 --> URI Class Initialized
INFO - 2023-07-21 08:28:26 --> Router Class Initialized
INFO - 2023-07-21 08:28:26 --> Output Class Initialized
INFO - 2023-07-21 08:28:26 --> Security Class Initialized
DEBUG - 2023-07-21 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:28:26 --> Input Class Initialized
INFO - 2023-07-21 08:28:26 --> Language Class Initialized
INFO - 2023-07-21 08:28:26 --> Language Class Initialized
INFO - 2023-07-21 08:28:26 --> Config Class Initialized
INFO - 2023-07-21 08:28:26 --> Loader Class Initialized
INFO - 2023-07-21 08:28:26 --> Helper loaded: url_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: file_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: form_helper
INFO - 2023-07-21 08:28:26 --> Helper loaded: my_helper
INFO - 2023-07-21 08:28:26 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:28:26 --> Controller Class Initialized
DEBUG - 2023-07-21 08:28:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/login/views/login.php
DEBUG - 2023-07-21 08:28:26 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:28:26 --> Final output sent to browser
DEBUG - 2023-07-21 08:28:26 --> Total execution time: 0.1348
INFO - 2023-07-21 08:28:44 --> Config Class Initialized
INFO - 2023-07-21 08:28:44 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:28:44 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:28:44 --> Utf8 Class Initialized
INFO - 2023-07-21 08:28:44 --> URI Class Initialized
INFO - 2023-07-21 08:28:44 --> Router Class Initialized
INFO - 2023-07-21 08:28:44 --> Output Class Initialized
INFO - 2023-07-21 08:28:44 --> Security Class Initialized
DEBUG - 2023-07-21 08:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:28:44 --> Input Class Initialized
INFO - 2023-07-21 08:28:44 --> Language Class Initialized
INFO - 2023-07-21 08:28:44 --> Language Class Initialized
INFO - 2023-07-21 08:28:44 --> Config Class Initialized
INFO - 2023-07-21 08:28:44 --> Loader Class Initialized
INFO - 2023-07-21 08:28:44 --> Helper loaded: url_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: file_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: form_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: my_helper
INFO - 2023-07-21 08:28:44 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:28:44 --> Controller Class Initialized
INFO - 2023-07-21 08:28:44 --> Helper loaded: cookie_helper
INFO - 2023-07-21 08:28:44 --> Final output sent to browser
DEBUG - 2023-07-21 08:28:44 --> Total execution time: 0.1149
INFO - 2023-07-21 08:28:44 --> Config Class Initialized
INFO - 2023-07-21 08:28:44 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:28:44 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:28:44 --> Utf8 Class Initialized
INFO - 2023-07-21 08:28:44 --> URI Class Initialized
INFO - 2023-07-21 08:28:44 --> Router Class Initialized
INFO - 2023-07-21 08:28:44 --> Output Class Initialized
INFO - 2023-07-21 08:28:44 --> Security Class Initialized
DEBUG - 2023-07-21 08:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:28:44 --> Input Class Initialized
INFO - 2023-07-21 08:28:44 --> Language Class Initialized
INFO - 2023-07-21 08:28:44 --> Language Class Initialized
INFO - 2023-07-21 08:28:44 --> Config Class Initialized
INFO - 2023-07-21 08:28:44 --> Loader Class Initialized
INFO - 2023-07-21 08:28:44 --> Helper loaded: url_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: file_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: form_helper
INFO - 2023-07-21 08:28:44 --> Helper loaded: my_helper
INFO - 2023-07-21 08:28:44 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:28:44 --> Controller Class Initialized
DEBUG - 2023-07-21 08:28:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/home/views/v_home.php
DEBUG - 2023-07-21 08:28:44 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:28:44 --> Final output sent to browser
DEBUG - 2023-07-21 08:28:44 --> Total execution time: 0.2169
INFO - 2023-07-21 08:29:58 --> Config Class Initialized
INFO - 2023-07-21 08:29:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:29:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:29:58 --> Utf8 Class Initialized
INFO - 2023-07-21 08:29:58 --> URI Class Initialized
INFO - 2023-07-21 08:29:58 --> Router Class Initialized
INFO - 2023-07-21 08:29:58 --> Output Class Initialized
INFO - 2023-07-21 08:29:58 --> Security Class Initialized
DEBUG - 2023-07-21 08:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:29:58 --> Input Class Initialized
INFO - 2023-07-21 08:29:58 --> Language Class Initialized
INFO - 2023-07-21 08:29:58 --> Language Class Initialized
INFO - 2023-07-21 08:29:58 --> Config Class Initialized
INFO - 2023-07-21 08:29:58 --> Loader Class Initialized
INFO - 2023-07-21 08:29:58 --> Helper loaded: url_helper
INFO - 2023-07-21 08:29:58 --> Helper loaded: file_helper
INFO - 2023-07-21 08:29:58 --> Helper loaded: form_helper
INFO - 2023-07-21 08:29:58 --> Helper loaded: my_helper
INFO - 2023-07-21 08:29:58 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:29:58 --> Controller Class Initialized
DEBUG - 2023-07-21 08:29:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_guru/views/list.php
DEBUG - 2023-07-21 08:29:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:29:58 --> Final output sent to browser
DEBUG - 2023-07-21 08:29:58 --> Total execution time: 0.1266
INFO - 2023-07-21 08:29:58 --> Config Class Initialized
INFO - 2023-07-21 08:29:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:29:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:29:58 --> Utf8 Class Initialized
INFO - 2023-07-21 08:29:58 --> URI Class Initialized
INFO - 2023-07-21 08:29:58 --> Router Class Initialized
INFO - 2023-07-21 08:29:59 --> Output Class Initialized
INFO - 2023-07-21 08:29:59 --> Security Class Initialized
DEBUG - 2023-07-21 08:29:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:29:59 --> Input Class Initialized
INFO - 2023-07-21 08:29:59 --> Language Class Initialized
INFO - 2023-07-21 08:29:59 --> Language Class Initialized
INFO - 2023-07-21 08:29:59 --> Config Class Initialized
INFO - 2023-07-21 08:29:59 --> Loader Class Initialized
INFO - 2023-07-21 08:29:59 --> Helper loaded: url_helper
INFO - 2023-07-21 08:29:59 --> Helper loaded: file_helper
INFO - 2023-07-21 08:29:59 --> Helper loaded: form_helper
INFO - 2023-07-21 08:29:59 --> Helper loaded: my_helper
INFO - 2023-07-21 08:29:59 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:29:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:29:59 --> Controller Class Initialized
INFO - 2023-07-21 08:30:05 --> Config Class Initialized
INFO - 2023-07-21 08:30:05 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:05 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:05 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:05 --> URI Class Initialized
INFO - 2023-07-21 08:30:05 --> Router Class Initialized
INFO - 2023-07-21 08:30:05 --> Output Class Initialized
INFO - 2023-07-21 08:30:05 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:05 --> Input Class Initialized
INFO - 2023-07-21 08:30:05 --> Language Class Initialized
INFO - 2023-07-21 08:30:05 --> Language Class Initialized
INFO - 2023-07-21 08:30:05 --> Config Class Initialized
INFO - 2023-07-21 08:30:05 --> Loader Class Initialized
INFO - 2023-07-21 08:30:05 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:05 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:05 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:05 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:05 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:05 --> Controller Class Initialized
INFO - 2023-07-21 08:30:05 --> Final output sent to browser
DEBUG - 2023-07-21 08:30:05 --> Total execution time: 0.0553
INFO - 2023-07-21 08:30:17 --> Config Class Initialized
INFO - 2023-07-21 08:30:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:17 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:17 --> URI Class Initialized
INFO - 2023-07-21 08:30:17 --> Router Class Initialized
INFO - 2023-07-21 08:30:17 --> Output Class Initialized
INFO - 2023-07-21 08:30:17 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:17 --> Input Class Initialized
INFO - 2023-07-21 08:30:17 --> Language Class Initialized
INFO - 2023-07-21 08:30:17 --> Language Class Initialized
INFO - 2023-07-21 08:30:17 --> Config Class Initialized
INFO - 2023-07-21 08:30:17 --> Loader Class Initialized
INFO - 2023-07-21 08:30:17 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:17 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:17 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:17 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:17 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:17 --> Controller Class Initialized
INFO - 2023-07-21 08:30:17 --> Final output sent to browser
DEBUG - 2023-07-21 08:30:17 --> Total execution time: 0.0578
INFO - 2023-07-21 08:30:26 --> Config Class Initialized
INFO - 2023-07-21 08:30:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:26 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:26 --> URI Class Initialized
INFO - 2023-07-21 08:30:26 --> Router Class Initialized
INFO - 2023-07-21 08:30:26 --> Output Class Initialized
INFO - 2023-07-21 08:30:26 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:26 --> Input Class Initialized
INFO - 2023-07-21 08:30:26 --> Language Class Initialized
INFO - 2023-07-21 08:30:26 --> Language Class Initialized
INFO - 2023-07-21 08:30:26 --> Config Class Initialized
INFO - 2023-07-21 08:30:26 --> Loader Class Initialized
INFO - 2023-07-21 08:30:26 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:26 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:26 --> Controller Class Initialized
INFO - 2023-07-21 08:30:26 --> Final output sent to browser
DEBUG - 2023-07-21 08:30:26 --> Total execution time: 0.0682
INFO - 2023-07-21 08:30:26 --> Config Class Initialized
INFO - 2023-07-21 08:30:26 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:26 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:26 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:26 --> URI Class Initialized
INFO - 2023-07-21 08:30:26 --> Router Class Initialized
INFO - 2023-07-21 08:30:26 --> Output Class Initialized
INFO - 2023-07-21 08:30:26 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:26 --> Input Class Initialized
INFO - 2023-07-21 08:30:26 --> Language Class Initialized
INFO - 2023-07-21 08:30:26 --> Language Class Initialized
INFO - 2023-07-21 08:30:26 --> Config Class Initialized
INFO - 2023-07-21 08:30:26 --> Loader Class Initialized
INFO - 2023-07-21 08:30:26 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:26 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:26 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:26 --> Controller Class Initialized
INFO - 2023-07-21 08:30:37 --> Config Class Initialized
INFO - 2023-07-21 08:30:37 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:37 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:37 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:37 --> URI Class Initialized
INFO - 2023-07-21 08:30:37 --> Router Class Initialized
INFO - 2023-07-21 08:30:37 --> Output Class Initialized
INFO - 2023-07-21 08:30:37 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:37 --> Input Class Initialized
INFO - 2023-07-21 08:30:37 --> Language Class Initialized
INFO - 2023-07-21 08:30:37 --> Language Class Initialized
INFO - 2023-07-21 08:30:37 --> Config Class Initialized
INFO - 2023-07-21 08:30:37 --> Loader Class Initialized
INFO - 2023-07-21 08:30:37 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:37 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:37 --> Controller Class Initialized
INFO - 2023-07-21 08:30:37 --> Final output sent to browser
DEBUG - 2023-07-21 08:30:37 --> Total execution time: 0.0693
INFO - 2023-07-21 08:30:37 --> Config Class Initialized
INFO - 2023-07-21 08:30:37 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:30:37 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:30:37 --> Utf8 Class Initialized
INFO - 2023-07-21 08:30:37 --> URI Class Initialized
INFO - 2023-07-21 08:30:37 --> Router Class Initialized
INFO - 2023-07-21 08:30:37 --> Output Class Initialized
INFO - 2023-07-21 08:30:37 --> Security Class Initialized
DEBUG - 2023-07-21 08:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:30:37 --> Input Class Initialized
INFO - 2023-07-21 08:30:37 --> Language Class Initialized
INFO - 2023-07-21 08:30:37 --> Language Class Initialized
INFO - 2023-07-21 08:30:37 --> Config Class Initialized
INFO - 2023-07-21 08:30:37 --> Loader Class Initialized
INFO - 2023-07-21 08:30:37 --> Helper loaded: url_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: file_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: form_helper
INFO - 2023-07-21 08:30:37 --> Helper loaded: my_helper
INFO - 2023-07-21 08:30:37 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:30:37 --> Controller Class Initialized
INFO - 2023-07-21 08:31:21 --> Config Class Initialized
INFO - 2023-07-21 08:31:21 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:31:21 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:31:21 --> Utf8 Class Initialized
INFO - 2023-07-21 08:31:21 --> URI Class Initialized
INFO - 2023-07-21 08:31:21 --> Router Class Initialized
INFO - 2023-07-21 08:31:21 --> Output Class Initialized
INFO - 2023-07-21 08:31:21 --> Security Class Initialized
DEBUG - 2023-07-21 08:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:31:21 --> Input Class Initialized
INFO - 2023-07-21 08:31:21 --> Language Class Initialized
INFO - 2023-07-21 08:31:21 --> Language Class Initialized
INFO - 2023-07-21 08:31:21 --> Config Class Initialized
INFO - 2023-07-21 08:31:21 --> Loader Class Initialized
INFO - 2023-07-21 08:31:21 --> Helper loaded: url_helper
INFO - 2023-07-21 08:31:21 --> Helper loaded: file_helper
INFO - 2023-07-21 08:31:21 --> Helper loaded: form_helper
INFO - 2023-07-21 08:31:21 --> Helper loaded: my_helper
INFO - 2023-07-21 08:31:21 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:31:21 --> Controller Class Initialized
INFO - 2023-07-21 08:31:21 --> Final output sent to browser
DEBUG - 2023-07-21 08:31:21 --> Total execution time: 0.0573
INFO - 2023-07-21 08:32:02 --> Config Class Initialized
INFO - 2023-07-21 08:32:02 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:32:02 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:32:02 --> Utf8 Class Initialized
INFO - 2023-07-21 08:32:02 --> URI Class Initialized
INFO - 2023-07-21 08:32:02 --> Router Class Initialized
INFO - 2023-07-21 08:32:02 --> Output Class Initialized
INFO - 2023-07-21 08:32:02 --> Security Class Initialized
DEBUG - 2023-07-21 08:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:32:02 --> Input Class Initialized
INFO - 2023-07-21 08:32:02 --> Language Class Initialized
INFO - 2023-07-21 08:32:02 --> Language Class Initialized
INFO - 2023-07-21 08:32:02 --> Config Class Initialized
INFO - 2023-07-21 08:32:02 --> Loader Class Initialized
INFO - 2023-07-21 08:32:02 --> Helper loaded: url_helper
INFO - 2023-07-21 08:32:02 --> Helper loaded: file_helper
INFO - 2023-07-21 08:32:02 --> Helper loaded: form_helper
INFO - 2023-07-21 08:32:02 --> Helper loaded: my_helper
INFO - 2023-07-21 08:32:02 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:32:02 --> Controller Class Initialized
INFO - 2023-07-21 08:32:02 --> Final output sent to browser
DEBUG - 2023-07-21 08:32:02 --> Total execution time: 0.0477
INFO - 2023-07-21 08:32:14 --> Config Class Initialized
INFO - 2023-07-21 08:32:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:32:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:32:14 --> URI Class Initialized
INFO - 2023-07-21 08:32:14 --> Router Class Initialized
INFO - 2023-07-21 08:32:14 --> Output Class Initialized
INFO - 2023-07-21 08:32:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:32:14 --> Input Class Initialized
INFO - 2023-07-21 08:32:14 --> Language Class Initialized
INFO - 2023-07-21 08:32:14 --> Language Class Initialized
INFO - 2023-07-21 08:32:14 --> Config Class Initialized
INFO - 2023-07-21 08:32:14 --> Loader Class Initialized
INFO - 2023-07-21 08:32:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:32:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:32:14 --> Controller Class Initialized
DEBUG - 2023-07-21 08:32:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-21 08:32:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:32:14 --> Final output sent to browser
DEBUG - 2023-07-21 08:32:14 --> Total execution time: 0.1248
INFO - 2023-07-21 08:32:14 --> Config Class Initialized
INFO - 2023-07-21 08:32:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:32:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:32:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:32:14 --> URI Class Initialized
INFO - 2023-07-21 08:32:14 --> Router Class Initialized
INFO - 2023-07-21 08:32:14 --> Output Class Initialized
INFO - 2023-07-21 08:32:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:32:14 --> Input Class Initialized
INFO - 2023-07-21 08:32:14 --> Language Class Initialized
INFO - 2023-07-21 08:32:14 --> Language Class Initialized
INFO - 2023-07-21 08:32:14 --> Config Class Initialized
INFO - 2023-07-21 08:32:14 --> Loader Class Initialized
INFO - 2023-07-21 08:32:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:32:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:32:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:32:14 --> Controller Class Initialized
INFO - 2023-07-21 08:32:24 --> Config Class Initialized
INFO - 2023-07-21 08:32:24 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:32:24 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:32:24 --> Utf8 Class Initialized
INFO - 2023-07-21 08:32:24 --> URI Class Initialized
INFO - 2023-07-21 08:32:24 --> Router Class Initialized
INFO - 2023-07-21 08:32:24 --> Output Class Initialized
INFO - 2023-07-21 08:32:24 --> Security Class Initialized
DEBUG - 2023-07-21 08:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:32:24 --> Input Class Initialized
INFO - 2023-07-21 08:32:24 --> Language Class Initialized
INFO - 2023-07-21 08:32:24 --> Language Class Initialized
INFO - 2023-07-21 08:32:24 --> Config Class Initialized
INFO - 2023-07-21 08:32:24 --> Loader Class Initialized
INFO - 2023-07-21 08:32:24 --> Helper loaded: url_helper
INFO - 2023-07-21 08:32:24 --> Helper loaded: file_helper
INFO - 2023-07-21 08:32:24 --> Helper loaded: form_helper
INFO - 2023-07-21 08:32:24 --> Helper loaded: my_helper
INFO - 2023-07-21 08:32:24 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:32:24 --> Controller Class Initialized
ERROR - 2023-07-21 08:32:25 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-21 08:32:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-21 08:32:25 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:32:25 --> Final output sent to browser
DEBUG - 2023-07-21 08:32:25 --> Total execution time: 0.1944
INFO - 2023-07-21 08:34:42 --> Config Class Initialized
INFO - 2023-07-21 08:34:42 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:34:42 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:34:42 --> Utf8 Class Initialized
INFO - 2023-07-21 08:34:42 --> URI Class Initialized
INFO - 2023-07-21 08:34:42 --> Router Class Initialized
INFO - 2023-07-21 08:34:42 --> Output Class Initialized
INFO - 2023-07-21 08:34:42 --> Security Class Initialized
DEBUG - 2023-07-21 08:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:34:42 --> Input Class Initialized
INFO - 2023-07-21 08:34:42 --> Language Class Initialized
INFO - 2023-07-21 08:34:42 --> Language Class Initialized
INFO - 2023-07-21 08:34:42 --> Config Class Initialized
INFO - 2023-07-21 08:34:42 --> Loader Class Initialized
INFO - 2023-07-21 08:34:42 --> Helper loaded: url_helper
INFO - 2023-07-21 08:34:42 --> Helper loaded: file_helper
INFO - 2023-07-21 08:34:42 --> Helper loaded: form_helper
INFO - 2023-07-21 08:34:42 --> Helper loaded: my_helper
INFO - 2023-07-21 08:34:42 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:34:42 --> Controller Class Initialized
INFO - 2023-07-21 08:34:42 --> Upload Class Initialized
INFO - 2023-07-21 08:34:43 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-07-21 08:34:43 --> The upload path does not appear to be valid.
INFO - 2023-07-21 08:34:43 --> Config Class Initialized
INFO - 2023-07-21 08:34:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:34:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:34:43 --> Utf8 Class Initialized
INFO - 2023-07-21 08:34:43 --> URI Class Initialized
INFO - 2023-07-21 08:34:43 --> Router Class Initialized
INFO - 2023-07-21 08:34:43 --> Output Class Initialized
INFO - 2023-07-21 08:34:43 --> Security Class Initialized
DEBUG - 2023-07-21 08:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:34:43 --> Input Class Initialized
INFO - 2023-07-21 08:34:43 --> Language Class Initialized
INFO - 2023-07-21 08:34:43 --> Language Class Initialized
INFO - 2023-07-21 08:34:43 --> Config Class Initialized
INFO - 2023-07-21 08:34:43 --> Loader Class Initialized
INFO - 2023-07-21 08:34:43 --> Helper loaded: url_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: file_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: form_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: my_helper
INFO - 2023-07-21 08:34:43 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:34:43 --> Controller Class Initialized
DEBUG - 2023-07-21 08:34:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-21 08:34:43 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:34:43 --> Final output sent to browser
DEBUG - 2023-07-21 08:34:43 --> Total execution time: 0.0311
INFO - 2023-07-21 08:34:43 --> Config Class Initialized
INFO - 2023-07-21 08:34:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:34:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:34:43 --> Utf8 Class Initialized
INFO - 2023-07-21 08:34:43 --> URI Class Initialized
INFO - 2023-07-21 08:34:43 --> Router Class Initialized
INFO - 2023-07-21 08:34:43 --> Output Class Initialized
INFO - 2023-07-21 08:34:43 --> Security Class Initialized
DEBUG - 2023-07-21 08:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:34:43 --> Input Class Initialized
INFO - 2023-07-21 08:34:43 --> Language Class Initialized
INFO - 2023-07-21 08:34:43 --> Language Class Initialized
INFO - 2023-07-21 08:34:43 --> Config Class Initialized
INFO - 2023-07-21 08:34:43 --> Loader Class Initialized
INFO - 2023-07-21 08:34:43 --> Helper loaded: url_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: file_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: form_helper
INFO - 2023-07-21 08:34:43 --> Helper loaded: my_helper
INFO - 2023-07-21 08:34:43 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:34:43 --> Controller Class Initialized
INFO - 2023-07-21 08:34:51 --> Config Class Initialized
INFO - 2023-07-21 08:34:51 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:34:51 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:34:51 --> Utf8 Class Initialized
INFO - 2023-07-21 08:34:51 --> URI Class Initialized
INFO - 2023-07-21 08:34:51 --> Router Class Initialized
INFO - 2023-07-21 08:34:51 --> Output Class Initialized
INFO - 2023-07-21 08:34:51 --> Security Class Initialized
DEBUG - 2023-07-21 08:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:34:51 --> Input Class Initialized
INFO - 2023-07-21 08:34:51 --> Language Class Initialized
INFO - 2023-07-21 08:34:51 --> Language Class Initialized
INFO - 2023-07-21 08:34:51 --> Config Class Initialized
INFO - 2023-07-21 08:34:51 --> Loader Class Initialized
INFO - 2023-07-21 08:34:51 --> Helper loaded: url_helper
INFO - 2023-07-21 08:34:51 --> Helper loaded: file_helper
INFO - 2023-07-21 08:34:51 --> Helper loaded: form_helper
INFO - 2023-07-21 08:34:51 --> Helper loaded: my_helper
INFO - 2023-07-21 08:34:51 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:34:51 --> Controller Class Initialized
ERROR - 2023-07-21 08:34:51 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-21 08:34:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-21 08:34:51 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:34:51 --> Final output sent to browser
DEBUG - 2023-07-21 08:34:51 --> Total execution time: 0.0657
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:35:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:35:35 --> Utf8 Class Initialized
INFO - 2023-07-21 08:35:35 --> URI Class Initialized
INFO - 2023-07-21 08:35:35 --> Router Class Initialized
INFO - 2023-07-21 08:35:35 --> Output Class Initialized
INFO - 2023-07-21 08:35:35 --> Security Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:35:35 --> Input Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Loader Class Initialized
INFO - 2023-07-21 08:35:35 --> Helper loaded: url_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: file_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: form_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: my_helper
INFO - 2023-07-21 08:35:35 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:35:35 --> Controller Class Initialized
INFO - 2023-07-21 08:35:35 --> Upload Class Initialized
INFO - 2023-07-21 08:35:35 --> Language file loaded: language/english/upload_lang.php
ERROR - 2023-07-21 08:35:35 --> The upload path does not appear to be valid.
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:35:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:35:35 --> Utf8 Class Initialized
INFO - 2023-07-21 08:35:35 --> URI Class Initialized
INFO - 2023-07-21 08:35:35 --> Router Class Initialized
INFO - 2023-07-21 08:35:35 --> Output Class Initialized
INFO - 2023-07-21 08:35:35 --> Security Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:35:35 --> Input Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Loader Class Initialized
INFO - 2023-07-21 08:35:35 --> Helper loaded: url_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: file_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: form_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: my_helper
INFO - 2023-07-21 08:35:35 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:35:35 --> Controller Class Initialized
DEBUG - 2023-07-21 08:35:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-21 08:35:35 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:35:35 --> Final output sent to browser
DEBUG - 2023-07-21 08:35:35 --> Total execution time: 0.0458
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:35:35 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:35:35 --> Utf8 Class Initialized
INFO - 2023-07-21 08:35:35 --> URI Class Initialized
INFO - 2023-07-21 08:35:35 --> Router Class Initialized
INFO - 2023-07-21 08:35:35 --> Output Class Initialized
INFO - 2023-07-21 08:35:35 --> Security Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:35:35 --> Input Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Language Class Initialized
INFO - 2023-07-21 08:35:35 --> Config Class Initialized
INFO - 2023-07-21 08:35:35 --> Loader Class Initialized
INFO - 2023-07-21 08:35:35 --> Helper loaded: url_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: file_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: form_helper
INFO - 2023-07-21 08:35:35 --> Helper loaded: my_helper
INFO - 2023-07-21 08:35:35 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:35:35 --> Controller Class Initialized
INFO - 2023-07-21 08:39:57 --> Config Class Initialized
INFO - 2023-07-21 08:39:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:39:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:39:57 --> Utf8 Class Initialized
INFO - 2023-07-21 08:39:57 --> URI Class Initialized
INFO - 2023-07-21 08:39:57 --> Router Class Initialized
INFO - 2023-07-21 08:39:57 --> Output Class Initialized
INFO - 2023-07-21 08:39:57 --> Security Class Initialized
DEBUG - 2023-07-21 08:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:39:57 --> Input Class Initialized
INFO - 2023-07-21 08:39:57 --> Language Class Initialized
INFO - 2023-07-21 08:39:57 --> Language Class Initialized
INFO - 2023-07-21 08:39:57 --> Config Class Initialized
INFO - 2023-07-21 08:39:57 --> Loader Class Initialized
INFO - 2023-07-21 08:39:57 --> Helper loaded: url_helper
INFO - 2023-07-21 08:39:57 --> Helper loaded: file_helper
INFO - 2023-07-21 08:39:57 --> Helper loaded: form_helper
INFO - 2023-07-21 08:39:57 --> Helper loaded: my_helper
INFO - 2023-07-21 08:39:57 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:39:57 --> Controller Class Initialized
DEBUG - 2023-07-21 08:39:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form_import.php
DEBUG - 2023-07-21 08:39:57 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:39:57 --> Final output sent to browser
DEBUG - 2023-07-21 08:39:57 --> Total execution time: 0.1180
INFO - 2023-07-21 08:40:14 --> Config Class Initialized
INFO - 2023-07-21 08:40:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:14 --> URI Class Initialized
INFO - 2023-07-21 08:40:14 --> Router Class Initialized
INFO - 2023-07-21 08:40:14 --> Output Class Initialized
INFO - 2023-07-21 08:40:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:14 --> Input Class Initialized
INFO - 2023-07-21 08:40:14 --> Language Class Initialized
INFO - 2023-07-21 08:40:14 --> Language Class Initialized
INFO - 2023-07-21 08:40:14 --> Config Class Initialized
INFO - 2023-07-21 08:40:14 --> Loader Class Initialized
INFO - 2023-07-21 08:40:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:14 --> Controller Class Initialized
DEBUG - 2023-07-21 08:40:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-21 08:40:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:40:14 --> Final output sent to browser
DEBUG - 2023-07-21 08:40:14 --> Total execution time: 0.0826
INFO - 2023-07-21 08:40:14 --> Config Class Initialized
INFO - 2023-07-21 08:40:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:14 --> URI Class Initialized
INFO - 2023-07-21 08:40:14 --> Router Class Initialized
INFO - 2023-07-21 08:40:14 --> Output Class Initialized
INFO - 2023-07-21 08:40:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:14 --> Input Class Initialized
INFO - 2023-07-21 08:40:14 --> Language Class Initialized
INFO - 2023-07-21 08:40:14 --> Language Class Initialized
INFO - 2023-07-21 08:40:14 --> Config Class Initialized
INFO - 2023-07-21 08:40:14 --> Loader Class Initialized
INFO - 2023-07-21 08:40:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:14 --> Controller Class Initialized
INFO - 2023-07-21 08:40:15 --> Config Class Initialized
INFO - 2023-07-21 08:40:15 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:15 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:15 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:15 --> URI Class Initialized
INFO - 2023-07-21 08:40:15 --> Router Class Initialized
INFO - 2023-07-21 08:40:15 --> Output Class Initialized
INFO - 2023-07-21 08:40:15 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:15 --> Input Class Initialized
INFO - 2023-07-21 08:40:15 --> Language Class Initialized
INFO - 2023-07-21 08:40:15 --> Language Class Initialized
INFO - 2023-07-21 08:40:15 --> Config Class Initialized
INFO - 2023-07-21 08:40:15 --> Loader Class Initialized
INFO - 2023-07-21 08:40:15 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:15 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:15 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:15 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:15 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:15 --> Controller Class Initialized
ERROR - 2023-07-21 08:40:15 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\data_siswa\views\form.php 231
DEBUG - 2023-07-21 08:40:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/form.php
DEBUG - 2023-07-21 08:40:15 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:40:15 --> Final output sent to browser
DEBUG - 2023-07-21 08:40:15 --> Total execution time: 0.0551
INFO - 2023-07-21 08:40:24 --> Config Class Initialized
INFO - 2023-07-21 08:40:24 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:24 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:24 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:24 --> URI Class Initialized
INFO - 2023-07-21 08:40:24 --> Router Class Initialized
INFO - 2023-07-21 08:40:24 --> Output Class Initialized
INFO - 2023-07-21 08:40:24 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:24 --> Input Class Initialized
INFO - 2023-07-21 08:40:24 --> Language Class Initialized
INFO - 2023-07-21 08:40:24 --> Language Class Initialized
INFO - 2023-07-21 08:40:24 --> Config Class Initialized
INFO - 2023-07-21 08:40:24 --> Loader Class Initialized
INFO - 2023-07-21 08:40:24 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:24 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:24 --> Controller Class Initialized
DEBUG - 2023-07-21 08:40:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_kelas/views/list.php
DEBUG - 2023-07-21 08:40:24 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:40:24 --> Final output sent to browser
DEBUG - 2023-07-21 08:40:24 --> Total execution time: 0.1424
INFO - 2023-07-21 08:40:24 --> Config Class Initialized
INFO - 2023-07-21 08:40:24 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:24 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:24 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:24 --> URI Class Initialized
INFO - 2023-07-21 08:40:24 --> Router Class Initialized
INFO - 2023-07-21 08:40:24 --> Output Class Initialized
INFO - 2023-07-21 08:40:24 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:24 --> Input Class Initialized
INFO - 2023-07-21 08:40:24 --> Language Class Initialized
INFO - 2023-07-21 08:40:24 --> Language Class Initialized
INFO - 2023-07-21 08:40:24 --> Config Class Initialized
INFO - 2023-07-21 08:40:24 --> Loader Class Initialized
INFO - 2023-07-21 08:40:24 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:24 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:24 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:24 --> Controller Class Initialized
INFO - 2023-07-21 08:40:43 --> Config Class Initialized
INFO - 2023-07-21 08:40:43 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:40:43 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:40:43 --> Utf8 Class Initialized
INFO - 2023-07-21 08:40:43 --> URI Class Initialized
INFO - 2023-07-21 08:40:43 --> Router Class Initialized
INFO - 2023-07-21 08:40:43 --> Output Class Initialized
INFO - 2023-07-21 08:40:43 --> Security Class Initialized
DEBUG - 2023-07-21 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:40:43 --> Input Class Initialized
INFO - 2023-07-21 08:40:43 --> Language Class Initialized
INFO - 2023-07-21 08:40:43 --> Language Class Initialized
INFO - 2023-07-21 08:40:43 --> Config Class Initialized
INFO - 2023-07-21 08:40:43 --> Loader Class Initialized
INFO - 2023-07-21 08:40:43 --> Helper loaded: url_helper
INFO - 2023-07-21 08:40:43 --> Helper loaded: file_helper
INFO - 2023-07-21 08:40:43 --> Helper loaded: form_helper
INFO - 2023-07-21 08:40:43 --> Helper loaded: my_helper
INFO - 2023-07-21 08:40:43 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:40:43 --> Controller Class Initialized
INFO - 2023-07-21 08:40:43 --> Final output sent to browser
DEBUG - 2023-07-21 08:40:43 --> Total execution time: 0.0587
INFO - 2023-07-21 08:41:41 --> Config Class Initialized
INFO - 2023-07-21 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:41:41 --> Utf8 Class Initialized
INFO - 2023-07-21 08:41:41 --> URI Class Initialized
INFO - 2023-07-21 08:41:41 --> Router Class Initialized
INFO - 2023-07-21 08:41:41 --> Output Class Initialized
INFO - 2023-07-21 08:41:41 --> Security Class Initialized
DEBUG - 2023-07-21 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:41:41 --> Input Class Initialized
INFO - 2023-07-21 08:41:41 --> Language Class Initialized
INFO - 2023-07-21 08:41:41 --> Language Class Initialized
INFO - 2023-07-21 08:41:41 --> Config Class Initialized
INFO - 2023-07-21 08:41:41 --> Loader Class Initialized
INFO - 2023-07-21 08:41:41 --> Helper loaded: url_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: file_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: form_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: my_helper
INFO - 2023-07-21 08:41:41 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:41:41 --> Controller Class Initialized
INFO - 2023-07-21 08:41:41 --> Final output sent to browser
DEBUG - 2023-07-21 08:41:41 --> Total execution time: 0.0561
INFO - 2023-07-21 08:41:41 --> Config Class Initialized
INFO - 2023-07-21 08:41:41 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:41:41 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:41:41 --> Utf8 Class Initialized
INFO - 2023-07-21 08:41:41 --> URI Class Initialized
INFO - 2023-07-21 08:41:41 --> Router Class Initialized
INFO - 2023-07-21 08:41:41 --> Output Class Initialized
INFO - 2023-07-21 08:41:41 --> Security Class Initialized
DEBUG - 2023-07-21 08:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:41:41 --> Input Class Initialized
INFO - 2023-07-21 08:41:41 --> Language Class Initialized
INFO - 2023-07-21 08:41:41 --> Language Class Initialized
INFO - 2023-07-21 08:41:41 --> Config Class Initialized
INFO - 2023-07-21 08:41:41 --> Loader Class Initialized
INFO - 2023-07-21 08:41:41 --> Helper loaded: url_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: file_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: form_helper
INFO - 2023-07-21 08:41:41 --> Helper loaded: my_helper
INFO - 2023-07-21 08:41:41 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:41:41 --> Controller Class Initialized
INFO - 2023-07-21 08:43:46 --> Config Class Initialized
INFO - 2023-07-21 08:43:46 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:43:46 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:43:46 --> Utf8 Class Initialized
INFO - 2023-07-21 08:43:46 --> URI Class Initialized
INFO - 2023-07-21 08:43:46 --> Router Class Initialized
INFO - 2023-07-21 08:43:46 --> Output Class Initialized
INFO - 2023-07-21 08:43:46 --> Security Class Initialized
DEBUG - 2023-07-21 08:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:43:46 --> Input Class Initialized
INFO - 2023-07-21 08:43:46 --> Language Class Initialized
INFO - 2023-07-21 08:43:46 --> Language Class Initialized
INFO - 2023-07-21 08:43:46 --> Config Class Initialized
INFO - 2023-07-21 08:43:46 --> Loader Class Initialized
INFO - 2023-07-21 08:43:46 --> Helper loaded: url_helper
INFO - 2023-07-21 08:43:46 --> Helper loaded: file_helper
INFO - 2023-07-21 08:43:46 --> Helper loaded: form_helper
INFO - 2023-07-21 08:43:46 --> Helper loaded: my_helper
INFO - 2023-07-21 08:43:46 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:43:46 --> Controller Class Initialized
INFO - 2023-07-21 08:43:46 --> Final output sent to browser
DEBUG - 2023-07-21 08:43:46 --> Total execution time: 0.0464
INFO - 2023-07-21 08:43:57 --> Config Class Initialized
INFO - 2023-07-21 08:43:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:43:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:43:57 --> Utf8 Class Initialized
INFO - 2023-07-21 08:43:57 --> URI Class Initialized
INFO - 2023-07-21 08:43:57 --> Router Class Initialized
INFO - 2023-07-21 08:43:57 --> Output Class Initialized
INFO - 2023-07-21 08:43:57 --> Security Class Initialized
DEBUG - 2023-07-21 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:43:57 --> Input Class Initialized
INFO - 2023-07-21 08:43:57 --> Language Class Initialized
INFO - 2023-07-21 08:43:57 --> Language Class Initialized
INFO - 2023-07-21 08:43:57 --> Config Class Initialized
INFO - 2023-07-21 08:43:57 --> Loader Class Initialized
INFO - 2023-07-21 08:43:57 --> Helper loaded: url_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: file_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: form_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: my_helper
INFO - 2023-07-21 08:43:57 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:43:57 --> Controller Class Initialized
INFO - 2023-07-21 08:43:57 --> Final output sent to browser
DEBUG - 2023-07-21 08:43:57 --> Total execution time: 0.0714
INFO - 2023-07-21 08:43:57 --> Config Class Initialized
INFO - 2023-07-21 08:43:57 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:43:57 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:43:57 --> Utf8 Class Initialized
INFO - 2023-07-21 08:43:57 --> URI Class Initialized
INFO - 2023-07-21 08:43:57 --> Router Class Initialized
INFO - 2023-07-21 08:43:57 --> Output Class Initialized
INFO - 2023-07-21 08:43:57 --> Security Class Initialized
DEBUG - 2023-07-21 08:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:43:57 --> Input Class Initialized
INFO - 2023-07-21 08:43:57 --> Language Class Initialized
INFO - 2023-07-21 08:43:57 --> Language Class Initialized
INFO - 2023-07-21 08:43:57 --> Config Class Initialized
INFO - 2023-07-21 08:43:57 --> Loader Class Initialized
INFO - 2023-07-21 08:43:57 --> Helper loaded: url_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: file_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: form_helper
INFO - 2023-07-21 08:43:57 --> Helper loaded: my_helper
INFO - 2023-07-21 08:43:57 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:43:57 --> Controller Class Initialized
INFO - 2023-07-21 08:43:58 --> Config Class Initialized
INFO - 2023-07-21 08:43:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:43:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:43:58 --> Utf8 Class Initialized
INFO - 2023-07-21 08:43:58 --> URI Class Initialized
INFO - 2023-07-21 08:43:58 --> Router Class Initialized
INFO - 2023-07-21 08:43:58 --> Output Class Initialized
INFO - 2023-07-21 08:43:58 --> Security Class Initialized
DEBUG - 2023-07-21 08:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:43:58 --> Input Class Initialized
INFO - 2023-07-21 08:43:58 --> Language Class Initialized
INFO - 2023-07-21 08:43:58 --> Language Class Initialized
INFO - 2023-07-21 08:43:58 --> Config Class Initialized
INFO - 2023-07-21 08:43:58 --> Loader Class Initialized
INFO - 2023-07-21 08:43:58 --> Helper loaded: url_helper
INFO - 2023-07-21 08:43:58 --> Helper loaded: file_helper
INFO - 2023-07-21 08:43:58 --> Helper loaded: form_helper
INFO - 2023-07-21 08:43:58 --> Helper loaded: my_helper
INFO - 2023-07-21 08:43:58 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:43:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:43:58 --> Controller Class Initialized
INFO - 2023-07-21 08:43:58 --> Final output sent to browser
DEBUG - 2023-07-21 08:43:58 --> Total execution time: 0.0661
INFO - 2023-07-21 08:44:04 --> Config Class Initialized
INFO - 2023-07-21 08:44:04 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:04 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:04 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:04 --> URI Class Initialized
INFO - 2023-07-21 08:44:04 --> Router Class Initialized
INFO - 2023-07-21 08:44:04 --> Output Class Initialized
INFO - 2023-07-21 08:44:04 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:04 --> Input Class Initialized
INFO - 2023-07-21 08:44:04 --> Language Class Initialized
INFO - 2023-07-21 08:44:04 --> Language Class Initialized
INFO - 2023-07-21 08:44:04 --> Config Class Initialized
INFO - 2023-07-21 08:44:04 --> Loader Class Initialized
INFO - 2023-07-21 08:44:04 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:04 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:04 --> Controller Class Initialized
INFO - 2023-07-21 08:44:04 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:04 --> Total execution time: 0.0523
INFO - 2023-07-21 08:44:04 --> Config Class Initialized
INFO - 2023-07-21 08:44:04 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:04 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:04 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:04 --> URI Class Initialized
INFO - 2023-07-21 08:44:04 --> Router Class Initialized
INFO - 2023-07-21 08:44:04 --> Output Class Initialized
INFO - 2023-07-21 08:44:04 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:04 --> Input Class Initialized
INFO - 2023-07-21 08:44:04 --> Language Class Initialized
INFO - 2023-07-21 08:44:04 --> Language Class Initialized
INFO - 2023-07-21 08:44:04 --> Config Class Initialized
INFO - 2023-07-21 08:44:04 --> Loader Class Initialized
INFO - 2023-07-21 08:44:04 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:04 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:04 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:04 --> Controller Class Initialized
INFO - 2023-07-21 08:44:06 --> Config Class Initialized
INFO - 2023-07-21 08:44:06 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:06 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:06 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:06 --> URI Class Initialized
INFO - 2023-07-21 08:44:06 --> Router Class Initialized
INFO - 2023-07-21 08:44:06 --> Output Class Initialized
INFO - 2023-07-21 08:44:06 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:06 --> Input Class Initialized
INFO - 2023-07-21 08:44:06 --> Language Class Initialized
INFO - 2023-07-21 08:44:06 --> Language Class Initialized
INFO - 2023-07-21 08:44:06 --> Config Class Initialized
INFO - 2023-07-21 08:44:06 --> Loader Class Initialized
INFO - 2023-07-21 08:44:06 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:06 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:06 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:06 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:06 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:06 --> Controller Class Initialized
INFO - 2023-07-21 08:44:06 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:06 --> Total execution time: 0.0599
INFO - 2023-07-21 08:44:12 --> Config Class Initialized
INFO - 2023-07-21 08:44:12 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:12 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:12 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:12 --> URI Class Initialized
INFO - 2023-07-21 08:44:12 --> Router Class Initialized
INFO - 2023-07-21 08:44:12 --> Output Class Initialized
INFO - 2023-07-21 08:44:12 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:12 --> Input Class Initialized
INFO - 2023-07-21 08:44:12 --> Language Class Initialized
INFO - 2023-07-21 08:44:12 --> Language Class Initialized
INFO - 2023-07-21 08:44:12 --> Config Class Initialized
INFO - 2023-07-21 08:44:12 --> Loader Class Initialized
INFO - 2023-07-21 08:44:12 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:12 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:12 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:12 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:12 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:12 --> Controller Class Initialized
INFO - 2023-07-21 08:44:12 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:12 --> Total execution time: 0.0558
INFO - 2023-07-21 08:44:13 --> Config Class Initialized
INFO - 2023-07-21 08:44:13 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:13 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:13 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:13 --> URI Class Initialized
INFO - 2023-07-21 08:44:13 --> Router Class Initialized
INFO - 2023-07-21 08:44:13 --> Output Class Initialized
INFO - 2023-07-21 08:44:13 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:13 --> Input Class Initialized
INFO - 2023-07-21 08:44:13 --> Language Class Initialized
INFO - 2023-07-21 08:44:13 --> Language Class Initialized
INFO - 2023-07-21 08:44:13 --> Config Class Initialized
INFO - 2023-07-21 08:44:13 --> Loader Class Initialized
INFO - 2023-07-21 08:44:13 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:13 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:13 --> Controller Class Initialized
INFO - 2023-07-21 08:44:13 --> Config Class Initialized
INFO - 2023-07-21 08:44:13 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:13 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:13 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:13 --> URI Class Initialized
INFO - 2023-07-21 08:44:13 --> Router Class Initialized
INFO - 2023-07-21 08:44:13 --> Output Class Initialized
INFO - 2023-07-21 08:44:13 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:13 --> Input Class Initialized
INFO - 2023-07-21 08:44:13 --> Language Class Initialized
INFO - 2023-07-21 08:44:13 --> Language Class Initialized
INFO - 2023-07-21 08:44:13 --> Config Class Initialized
INFO - 2023-07-21 08:44:13 --> Loader Class Initialized
INFO - 2023-07-21 08:44:13 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:13 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:13 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:13 --> Controller Class Initialized
INFO - 2023-07-21 08:44:13 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:13 --> Total execution time: 0.0647
INFO - 2023-07-21 08:44:17 --> Config Class Initialized
INFO - 2023-07-21 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:17 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:17 --> URI Class Initialized
INFO - 2023-07-21 08:44:17 --> Router Class Initialized
INFO - 2023-07-21 08:44:17 --> Output Class Initialized
INFO - 2023-07-21 08:44:17 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:17 --> Input Class Initialized
INFO - 2023-07-21 08:44:17 --> Language Class Initialized
INFO - 2023-07-21 08:44:17 --> Language Class Initialized
INFO - 2023-07-21 08:44:17 --> Config Class Initialized
INFO - 2023-07-21 08:44:17 --> Loader Class Initialized
INFO - 2023-07-21 08:44:17 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:17 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:17 --> Controller Class Initialized
INFO - 2023-07-21 08:44:17 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:17 --> Total execution time: 0.0642
INFO - 2023-07-21 08:44:17 --> Config Class Initialized
INFO - 2023-07-21 08:44:17 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:17 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:17 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:17 --> URI Class Initialized
INFO - 2023-07-21 08:44:17 --> Router Class Initialized
INFO - 2023-07-21 08:44:17 --> Output Class Initialized
INFO - 2023-07-21 08:44:17 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:17 --> Input Class Initialized
INFO - 2023-07-21 08:44:17 --> Language Class Initialized
INFO - 2023-07-21 08:44:17 --> Language Class Initialized
INFO - 2023-07-21 08:44:17 --> Config Class Initialized
INFO - 2023-07-21 08:44:17 --> Loader Class Initialized
INFO - 2023-07-21 08:44:17 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:17 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:17 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:17 --> Controller Class Initialized
INFO - 2023-07-21 08:44:33 --> Config Class Initialized
INFO - 2023-07-21 08:44:33 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:33 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:33 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:33 --> URI Class Initialized
INFO - 2023-07-21 08:44:33 --> Router Class Initialized
INFO - 2023-07-21 08:44:33 --> Output Class Initialized
INFO - 2023-07-21 08:44:33 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:33 --> Input Class Initialized
INFO - 2023-07-21 08:44:33 --> Language Class Initialized
INFO - 2023-07-21 08:44:33 --> Language Class Initialized
INFO - 2023-07-21 08:44:33 --> Config Class Initialized
INFO - 2023-07-21 08:44:33 --> Loader Class Initialized
INFO - 2023-07-21 08:44:33 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:33 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:33 --> Controller Class Initialized
DEBUG - 2023-07-21 08:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-21 08:44:33 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:44:33 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:33 --> Total execution time: 0.1339
INFO - 2023-07-21 08:44:33 --> Config Class Initialized
INFO - 2023-07-21 08:44:33 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:33 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:33 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:33 --> URI Class Initialized
INFO - 2023-07-21 08:44:33 --> Router Class Initialized
INFO - 2023-07-21 08:44:33 --> Output Class Initialized
INFO - 2023-07-21 08:44:33 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:33 --> Input Class Initialized
INFO - 2023-07-21 08:44:33 --> Language Class Initialized
INFO - 2023-07-21 08:44:33 --> Language Class Initialized
INFO - 2023-07-21 08:44:33 --> Config Class Initialized
INFO - 2023-07-21 08:44:33 --> Loader Class Initialized
INFO - 2023-07-21 08:44:33 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:33 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:33 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:33 --> Controller Class Initialized
INFO - 2023-07-21 08:44:38 --> Config Class Initialized
INFO - 2023-07-21 08:44:38 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:44:38 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:44:38 --> Utf8 Class Initialized
INFO - 2023-07-21 08:44:38 --> URI Class Initialized
INFO - 2023-07-21 08:44:38 --> Router Class Initialized
INFO - 2023-07-21 08:44:38 --> Output Class Initialized
INFO - 2023-07-21 08:44:38 --> Security Class Initialized
DEBUG - 2023-07-21 08:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:44:38 --> Input Class Initialized
INFO - 2023-07-21 08:44:38 --> Language Class Initialized
INFO - 2023-07-21 08:44:38 --> Language Class Initialized
INFO - 2023-07-21 08:44:38 --> Config Class Initialized
INFO - 2023-07-21 08:44:38 --> Loader Class Initialized
INFO - 2023-07-21 08:44:38 --> Helper loaded: url_helper
INFO - 2023-07-21 08:44:38 --> Helper loaded: file_helper
INFO - 2023-07-21 08:44:38 --> Helper loaded: form_helper
INFO - 2023-07-21 08:44:38 --> Helper loaded: my_helper
INFO - 2023-07-21 08:44:38 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:44:38 --> Controller Class Initialized
INFO - 2023-07-21 08:44:38 --> Final output sent to browser
DEBUG - 2023-07-21 08:44:38 --> Total execution time: 0.0458
INFO - 2023-07-21 08:47:56 --> Config Class Initialized
INFO - 2023-07-21 08:47:56 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:47:56 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:47:56 --> Utf8 Class Initialized
INFO - 2023-07-21 08:47:56 --> URI Class Initialized
INFO - 2023-07-21 08:47:56 --> Router Class Initialized
INFO - 2023-07-21 08:47:56 --> Output Class Initialized
INFO - 2023-07-21 08:47:56 --> Security Class Initialized
DEBUG - 2023-07-21 08:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:47:56 --> Input Class Initialized
INFO - 2023-07-21 08:47:56 --> Language Class Initialized
INFO - 2023-07-21 08:47:56 --> Language Class Initialized
INFO - 2023-07-21 08:47:56 --> Config Class Initialized
INFO - 2023-07-21 08:47:56 --> Loader Class Initialized
INFO - 2023-07-21 08:47:56 --> Helper loaded: url_helper
INFO - 2023-07-21 08:47:56 --> Helper loaded: file_helper
INFO - 2023-07-21 08:47:56 --> Helper loaded: form_helper
INFO - 2023-07-21 08:47:56 --> Helper loaded: my_helper
INFO - 2023-07-21 08:47:56 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:47:56 --> Controller Class Initialized
INFO - 2023-07-21 08:48:47 --> Config Class Initialized
INFO - 2023-07-21 08:48:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:48:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:48:47 --> Utf8 Class Initialized
INFO - 2023-07-21 08:48:47 --> URI Class Initialized
INFO - 2023-07-21 08:48:47 --> Router Class Initialized
INFO - 2023-07-21 08:48:47 --> Output Class Initialized
INFO - 2023-07-21 08:48:47 --> Security Class Initialized
DEBUG - 2023-07-21 08:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:48:47 --> Input Class Initialized
INFO - 2023-07-21 08:48:47 --> Language Class Initialized
INFO - 2023-07-21 08:48:47 --> Language Class Initialized
INFO - 2023-07-21 08:48:47 --> Config Class Initialized
INFO - 2023-07-21 08:48:47 --> Loader Class Initialized
INFO - 2023-07-21 08:48:47 --> Helper loaded: url_helper
INFO - 2023-07-21 08:48:47 --> Helper loaded: file_helper
INFO - 2023-07-21 08:48:47 --> Helper loaded: form_helper
INFO - 2023-07-21 08:48:47 --> Helper loaded: my_helper
INFO - 2023-07-21 08:48:47 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:48:47 --> Controller Class Initialized
INFO - 2023-07-21 08:48:47 --> Final output sent to browser
DEBUG - 2023-07-21 08:48:47 --> Total execution time: 0.0437
INFO - 2023-07-21 08:51:14 --> Config Class Initialized
INFO - 2023-07-21 08:51:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:51:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:51:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:51:14 --> URI Class Initialized
INFO - 2023-07-21 08:51:14 --> Router Class Initialized
INFO - 2023-07-21 08:51:14 --> Output Class Initialized
INFO - 2023-07-21 08:51:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:51:14 --> Input Class Initialized
INFO - 2023-07-21 08:51:14 --> Language Class Initialized
INFO - 2023-07-21 08:51:14 --> Language Class Initialized
INFO - 2023-07-21 08:51:14 --> Config Class Initialized
INFO - 2023-07-21 08:51:14 --> Loader Class Initialized
INFO - 2023-07-21 08:51:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:51:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:51:14 --> Controller Class Initialized
DEBUG - 2023-07-21 08:51:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_ekstra/views/list.php
DEBUG - 2023-07-21 08:51:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:51:14 --> Final output sent to browser
DEBUG - 2023-07-21 08:51:14 --> Total execution time: 0.1421
INFO - 2023-07-21 08:51:14 --> Config Class Initialized
INFO - 2023-07-21 08:51:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:51:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:51:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:51:14 --> URI Class Initialized
INFO - 2023-07-21 08:51:14 --> Router Class Initialized
INFO - 2023-07-21 08:51:14 --> Output Class Initialized
INFO - 2023-07-21 08:51:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:51:14 --> Input Class Initialized
INFO - 2023-07-21 08:51:14 --> Language Class Initialized
INFO - 2023-07-21 08:51:14 --> Language Class Initialized
INFO - 2023-07-21 08:51:14 --> Config Class Initialized
INFO - 2023-07-21 08:51:14 --> Loader Class Initialized
INFO - 2023-07-21 08:51:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:51:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:51:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:51:14 --> Controller Class Initialized
INFO - 2023-07-21 08:51:16 --> Config Class Initialized
INFO - 2023-07-21 08:51:16 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:51:16 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:51:16 --> Utf8 Class Initialized
INFO - 2023-07-21 08:51:16 --> URI Class Initialized
INFO - 2023-07-21 08:51:16 --> Router Class Initialized
INFO - 2023-07-21 08:51:16 --> Output Class Initialized
INFO - 2023-07-21 08:51:16 --> Security Class Initialized
DEBUG - 2023-07-21 08:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:51:16 --> Input Class Initialized
INFO - 2023-07-21 08:51:16 --> Language Class Initialized
INFO - 2023-07-21 08:51:16 --> Language Class Initialized
INFO - 2023-07-21 08:51:16 --> Config Class Initialized
INFO - 2023-07-21 08:51:16 --> Loader Class Initialized
INFO - 2023-07-21 08:51:16 --> Helper loaded: url_helper
INFO - 2023-07-21 08:51:16 --> Helper loaded: file_helper
INFO - 2023-07-21 08:51:16 --> Helper loaded: form_helper
INFO - 2023-07-21 08:51:16 --> Helper loaded: my_helper
INFO - 2023-07-21 08:51:16 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:51:16 --> Controller Class Initialized
INFO - 2023-07-21 08:51:16 --> Final output sent to browser
DEBUG - 2023-07-21 08:51:16 --> Total execution time: 0.0498
INFO - 2023-07-21 08:52:11 --> Config Class Initialized
INFO - 2023-07-21 08:52:11 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:52:11 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:52:11 --> Utf8 Class Initialized
INFO - 2023-07-21 08:52:11 --> URI Class Initialized
INFO - 2023-07-21 08:52:11 --> Router Class Initialized
INFO - 2023-07-21 08:52:11 --> Output Class Initialized
INFO - 2023-07-21 08:52:11 --> Security Class Initialized
DEBUG - 2023-07-21 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:52:11 --> Input Class Initialized
INFO - 2023-07-21 08:52:11 --> Language Class Initialized
INFO - 2023-07-21 08:52:11 --> Language Class Initialized
INFO - 2023-07-21 08:52:11 --> Config Class Initialized
INFO - 2023-07-21 08:52:11 --> Loader Class Initialized
INFO - 2023-07-21 08:52:11 --> Helper loaded: url_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: file_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: form_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: my_helper
INFO - 2023-07-21 08:52:11 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:52:11 --> Controller Class Initialized
DEBUG - 2023-07-21 08:52:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/tahun/views/list.php
DEBUG - 2023-07-21 08:52:11 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:52:11 --> Final output sent to browser
DEBUG - 2023-07-21 08:52:11 --> Total execution time: 0.1372
INFO - 2023-07-21 08:52:11 --> Config Class Initialized
INFO - 2023-07-21 08:52:11 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:52:11 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:52:11 --> Utf8 Class Initialized
INFO - 2023-07-21 08:52:11 --> URI Class Initialized
INFO - 2023-07-21 08:52:11 --> Router Class Initialized
INFO - 2023-07-21 08:52:11 --> Output Class Initialized
INFO - 2023-07-21 08:52:11 --> Security Class Initialized
DEBUG - 2023-07-21 08:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:52:11 --> Input Class Initialized
INFO - 2023-07-21 08:52:11 --> Language Class Initialized
INFO - 2023-07-21 08:52:11 --> Language Class Initialized
INFO - 2023-07-21 08:52:11 --> Config Class Initialized
INFO - 2023-07-21 08:52:11 --> Loader Class Initialized
INFO - 2023-07-21 08:52:11 --> Helper loaded: url_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: file_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: form_helper
INFO - 2023-07-21 08:52:11 --> Helper loaded: my_helper
INFO - 2023-07-21 08:52:11 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:52:11 --> Controller Class Initialized
INFO - 2023-07-21 08:52:27 --> Config Class Initialized
INFO - 2023-07-21 08:52:27 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:52:27 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:52:27 --> Utf8 Class Initialized
INFO - 2023-07-21 08:52:27 --> URI Class Initialized
INFO - 2023-07-21 08:52:27 --> Router Class Initialized
INFO - 2023-07-21 08:52:27 --> Output Class Initialized
INFO - 2023-07-21 08:52:27 --> Security Class Initialized
DEBUG - 2023-07-21 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:52:27 --> Input Class Initialized
INFO - 2023-07-21 08:52:27 --> Language Class Initialized
INFO - 2023-07-21 08:52:27 --> Language Class Initialized
INFO - 2023-07-21 08:52:27 --> Config Class Initialized
INFO - 2023-07-21 08:52:27 --> Loader Class Initialized
INFO - 2023-07-21 08:52:27 --> Helper loaded: url_helper
INFO - 2023-07-21 08:52:27 --> Helper loaded: file_helper
INFO - 2023-07-21 08:52:27 --> Helper loaded: form_helper
INFO - 2023-07-21 08:52:27 --> Helper loaded: my_helper
INFO - 2023-07-21 08:52:27 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:52:27 --> Controller Class Initialized
INFO - 2023-07-21 08:52:27 --> Final output sent to browser
DEBUG - 2023-07-21 08:52:27 --> Total execution time: 0.0574
INFO - 2023-07-21 08:54:32 --> Config Class Initialized
INFO - 2023-07-21 08:54:32 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:54:32 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:54:32 --> Utf8 Class Initialized
INFO - 2023-07-21 08:54:32 --> URI Class Initialized
INFO - 2023-07-21 08:54:32 --> Router Class Initialized
INFO - 2023-07-21 08:54:32 --> Output Class Initialized
INFO - 2023-07-21 08:54:32 --> Security Class Initialized
DEBUG - 2023-07-21 08:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:54:32 --> Input Class Initialized
INFO - 2023-07-21 08:54:32 --> Language Class Initialized
INFO - 2023-07-21 08:54:32 --> Language Class Initialized
INFO - 2023-07-21 08:54:32 --> Config Class Initialized
INFO - 2023-07-21 08:54:32 --> Loader Class Initialized
INFO - 2023-07-21 08:54:32 --> Helper loaded: url_helper
INFO - 2023-07-21 08:54:32 --> Helper loaded: file_helper
INFO - 2023-07-21 08:54:32 --> Helper loaded: form_helper
INFO - 2023-07-21 08:54:32 --> Helper loaded: my_helper
INFO - 2023-07-21 08:54:32 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:54:32 --> Controller Class Initialized
DEBUG - 2023-07-21 08:54:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-21 08:54:32 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:54:32 --> Final output sent to browser
DEBUG - 2023-07-21 08:54:32 --> Total execution time: 0.1603
INFO - 2023-07-21 08:54:58 --> Config Class Initialized
INFO - 2023-07-21 08:54:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:54:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:54:58 --> Utf8 Class Initialized
INFO - 2023-07-21 08:54:58 --> URI Class Initialized
INFO - 2023-07-21 08:54:58 --> Router Class Initialized
INFO - 2023-07-21 08:54:58 --> Output Class Initialized
INFO - 2023-07-21 08:54:58 --> Security Class Initialized
DEBUG - 2023-07-21 08:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:54:58 --> Input Class Initialized
INFO - 2023-07-21 08:54:58 --> Language Class Initialized
INFO - 2023-07-21 08:54:58 --> Language Class Initialized
INFO - 2023-07-21 08:54:58 --> Config Class Initialized
INFO - 2023-07-21 08:54:58 --> Loader Class Initialized
INFO - 2023-07-21 08:54:58 --> Helper loaded: url_helper
INFO - 2023-07-21 08:54:58 --> Helper loaded: file_helper
INFO - 2023-07-21 08:54:58 --> Helper loaded: form_helper
INFO - 2023-07-21 08:54:58 --> Helper loaded: my_helper
INFO - 2023-07-21 08:54:58 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:54:58 --> Controller Class Initialized
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 59
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 47
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 49
ERROR - 2023-07-21 08:54:58 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-07-21 08:54:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/form.php
DEBUG - 2023-07-21 08:54:58 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:54:58 --> Final output sent to browser
DEBUG - 2023-07-21 08:54:58 --> Total execution time: 0.1151
INFO - 2023-07-21 08:56:31 --> Config Class Initialized
INFO - 2023-07-21 08:56:31 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:56:31 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:56:31 --> Utf8 Class Initialized
INFO - 2023-07-21 08:56:31 --> URI Class Initialized
INFO - 2023-07-21 08:56:31 --> Router Class Initialized
INFO - 2023-07-21 08:56:31 --> Output Class Initialized
INFO - 2023-07-21 08:56:31 --> Security Class Initialized
DEBUG - 2023-07-21 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:56:31 --> Input Class Initialized
INFO - 2023-07-21 08:56:31 --> Language Class Initialized
INFO - 2023-07-21 08:56:31 --> Language Class Initialized
INFO - 2023-07-21 08:56:31 --> Config Class Initialized
INFO - 2023-07-21 08:56:31 --> Loader Class Initialized
INFO - 2023-07-21 08:56:31 --> Helper loaded: url_helper
INFO - 2023-07-21 08:56:31 --> Helper loaded: file_helper
INFO - 2023-07-21 08:56:31 --> Helper loaded: form_helper
INFO - 2023-07-21 08:56:31 --> Helper loaded: my_helper
INFO - 2023-07-21 08:56:31 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:56:31 --> Controller Class Initialized
DEBUG - 2023-07-21 08:56:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_kelas/views/list.php
DEBUG - 2023-07-21 08:56:31 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:56:31 --> Final output sent to browser
DEBUG - 2023-07-21 08:56:31 --> Total execution time: 0.0702
INFO - 2023-07-21 08:57:12 --> Config Class Initialized
INFO - 2023-07-21 08:57:12 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:12 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:12 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:12 --> URI Class Initialized
INFO - 2023-07-21 08:57:12 --> Router Class Initialized
INFO - 2023-07-21 08:57:12 --> Output Class Initialized
INFO - 2023-07-21 08:57:12 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:12 --> Input Class Initialized
INFO - 2023-07-21 08:57:12 --> Language Class Initialized
INFO - 2023-07-21 08:57:12 --> Language Class Initialized
INFO - 2023-07-21 08:57:12 --> Config Class Initialized
INFO - 2023-07-21 08:57:12 --> Loader Class Initialized
INFO - 2023-07-21 08:57:12 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:12 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:12 --> Controller Class Initialized
DEBUG - 2023-07-21 08:57:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_mapel/views/list.php
DEBUG - 2023-07-21 08:57:12 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:57:12 --> Final output sent to browser
DEBUG - 2023-07-21 08:57:12 --> Total execution time: 0.0695
INFO - 2023-07-21 08:57:12 --> Config Class Initialized
INFO - 2023-07-21 08:57:12 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:12 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:12 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:12 --> URI Class Initialized
INFO - 2023-07-21 08:57:12 --> Router Class Initialized
INFO - 2023-07-21 08:57:12 --> Output Class Initialized
INFO - 2023-07-21 08:57:12 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:12 --> Input Class Initialized
INFO - 2023-07-21 08:57:12 --> Language Class Initialized
INFO - 2023-07-21 08:57:12 --> Language Class Initialized
INFO - 2023-07-21 08:57:12 --> Config Class Initialized
INFO - 2023-07-21 08:57:12 --> Loader Class Initialized
INFO - 2023-07-21 08:57:12 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:12 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:12 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:12 --> Controller Class Initialized
INFO - 2023-07-21 08:57:15 --> Config Class Initialized
INFO - 2023-07-21 08:57:15 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:15 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:15 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:15 --> URI Class Initialized
INFO - 2023-07-21 08:57:15 --> Router Class Initialized
INFO - 2023-07-21 08:57:15 --> Output Class Initialized
INFO - 2023-07-21 08:57:15 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:15 --> Input Class Initialized
INFO - 2023-07-21 08:57:15 --> Language Class Initialized
INFO - 2023-07-21 08:57:15 --> Language Class Initialized
INFO - 2023-07-21 08:57:15 --> Config Class Initialized
INFO - 2023-07-21 08:57:15 --> Loader Class Initialized
INFO - 2023-07-21 08:57:15 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:15 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:15 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:15 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:15 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:15 --> Controller Class Initialized
INFO - 2023-07-21 08:57:15 --> Final output sent to browser
DEBUG - 2023-07-21 08:57:15 --> Total execution time: 0.0682
INFO - 2023-07-21 08:57:23 --> Config Class Initialized
INFO - 2023-07-21 08:57:23 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:23 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:23 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:23 --> URI Class Initialized
INFO - 2023-07-21 08:57:23 --> Router Class Initialized
INFO - 2023-07-21 08:57:23 --> Output Class Initialized
INFO - 2023-07-21 08:57:23 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:23 --> Input Class Initialized
INFO - 2023-07-21 08:57:23 --> Language Class Initialized
INFO - 2023-07-21 08:57:23 --> Language Class Initialized
INFO - 2023-07-21 08:57:23 --> Config Class Initialized
INFO - 2023-07-21 08:57:23 --> Loader Class Initialized
INFO - 2023-07-21 08:57:23 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:23 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:23 --> Controller Class Initialized
DEBUG - 2023-07-21 08:57:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_mapel/views/list.php
DEBUG - 2023-07-21 08:57:23 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:57:23 --> Final output sent to browser
DEBUG - 2023-07-21 08:57:23 --> Total execution time: 0.1357
INFO - 2023-07-21 08:57:23 --> Config Class Initialized
INFO - 2023-07-21 08:57:23 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:23 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:23 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:23 --> URI Class Initialized
INFO - 2023-07-21 08:57:23 --> Router Class Initialized
INFO - 2023-07-21 08:57:23 --> Output Class Initialized
INFO - 2023-07-21 08:57:23 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:23 --> Input Class Initialized
INFO - 2023-07-21 08:57:23 --> Language Class Initialized
INFO - 2023-07-21 08:57:23 --> Language Class Initialized
INFO - 2023-07-21 08:57:23 --> Config Class Initialized
INFO - 2023-07-21 08:57:23 --> Loader Class Initialized
INFO - 2023-07-21 08:57:23 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:23 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:23 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:23 --> Controller Class Initialized
INFO - 2023-07-21 08:57:28 --> Config Class Initialized
INFO - 2023-07-21 08:57:28 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:57:28 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:57:28 --> Utf8 Class Initialized
INFO - 2023-07-21 08:57:28 --> URI Class Initialized
INFO - 2023-07-21 08:57:28 --> Router Class Initialized
INFO - 2023-07-21 08:57:28 --> Output Class Initialized
INFO - 2023-07-21 08:57:28 --> Security Class Initialized
DEBUG - 2023-07-21 08:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:57:28 --> Input Class Initialized
INFO - 2023-07-21 08:57:28 --> Language Class Initialized
INFO - 2023-07-21 08:57:28 --> Language Class Initialized
INFO - 2023-07-21 08:57:28 --> Config Class Initialized
INFO - 2023-07-21 08:57:28 --> Loader Class Initialized
INFO - 2023-07-21 08:57:28 --> Helper loaded: url_helper
INFO - 2023-07-21 08:57:28 --> Helper loaded: file_helper
INFO - 2023-07-21 08:57:28 --> Helper loaded: form_helper
INFO - 2023-07-21 08:57:28 --> Helper loaded: my_helper
INFO - 2023-07-21 08:57:28 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:57:28 --> Controller Class Initialized
DEBUG - 2023-07-21 08:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_mapel/views/form.php
DEBUG - 2023-07-21 08:57:28 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:57:28 --> Final output sent to browser
DEBUG - 2023-07-21 08:57:28 --> Total execution time: 0.1088
INFO - 2023-07-21 08:58:14 --> Config Class Initialized
INFO - 2023-07-21 08:58:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:58:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:58:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:58:14 --> URI Class Initialized
INFO - 2023-07-21 08:58:14 --> Router Class Initialized
INFO - 2023-07-21 08:58:14 --> Output Class Initialized
INFO - 2023-07-21 08:58:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:58:14 --> Input Class Initialized
INFO - 2023-07-21 08:58:14 --> Language Class Initialized
INFO - 2023-07-21 08:58:14 --> Language Class Initialized
INFO - 2023-07-21 08:58:14 --> Config Class Initialized
INFO - 2023-07-21 08:58:14 --> Loader Class Initialized
INFO - 2023-07-21 08:58:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:58:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:58:14 --> Controller Class Initialized
DEBUG - 2023-07-21 08:58:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_mapel/views/list.php
DEBUG - 2023-07-21 08:58:14 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:58:14 --> Final output sent to browser
DEBUG - 2023-07-21 08:58:14 --> Total execution time: 0.0776
INFO - 2023-07-21 08:58:14 --> Config Class Initialized
INFO - 2023-07-21 08:58:14 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:58:14 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:58:14 --> Utf8 Class Initialized
INFO - 2023-07-21 08:58:14 --> URI Class Initialized
INFO - 2023-07-21 08:58:14 --> Router Class Initialized
INFO - 2023-07-21 08:58:14 --> Output Class Initialized
INFO - 2023-07-21 08:58:14 --> Security Class Initialized
DEBUG - 2023-07-21 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:58:14 --> Input Class Initialized
INFO - 2023-07-21 08:58:14 --> Language Class Initialized
INFO - 2023-07-21 08:58:14 --> Language Class Initialized
INFO - 2023-07-21 08:58:14 --> Config Class Initialized
INFO - 2023-07-21 08:58:14 --> Loader Class Initialized
INFO - 2023-07-21 08:58:14 --> Helper loaded: url_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: file_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: form_helper
INFO - 2023-07-21 08:58:14 --> Helper loaded: my_helper
INFO - 2023-07-21 08:58:14 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:58:14 --> Controller Class Initialized
INFO - 2023-07-21 08:58:55 --> Config Class Initialized
INFO - 2023-07-21 08:58:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:58:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:58:55 --> Utf8 Class Initialized
INFO - 2023-07-21 08:58:55 --> URI Class Initialized
INFO - 2023-07-21 08:58:55 --> Router Class Initialized
INFO - 2023-07-21 08:58:55 --> Output Class Initialized
INFO - 2023-07-21 08:58:55 --> Security Class Initialized
DEBUG - 2023-07-21 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:58:55 --> Input Class Initialized
INFO - 2023-07-21 08:58:55 --> Language Class Initialized
INFO - 2023-07-21 08:58:55 --> Language Class Initialized
INFO - 2023-07-21 08:58:55 --> Config Class Initialized
INFO - 2023-07-21 08:58:55 --> Loader Class Initialized
INFO - 2023-07-21 08:58:55 --> Helper loaded: url_helper
INFO - 2023-07-21 08:58:55 --> Helper loaded: file_helper
INFO - 2023-07-21 08:58:55 --> Helper loaded: form_helper
INFO - 2023-07-21 08:58:55 --> Helper loaded: my_helper
INFO - 2023-07-21 08:58:55 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:58:55 --> Controller Class Initialized
DEBUG - 2023-07-21 08:58:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/set_walikelas/views/list.php
DEBUG - 2023-07-21 08:58:55 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:58:55 --> Final output sent to browser
DEBUG - 2023-07-21 08:58:55 --> Total execution time: 0.1351
INFO - 2023-07-21 08:58:55 --> Config Class Initialized
INFO - 2023-07-21 08:58:55 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:58:55 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:58:55 --> Utf8 Class Initialized
INFO - 2023-07-21 08:58:55 --> URI Class Initialized
INFO - 2023-07-21 08:58:55 --> Router Class Initialized
INFO - 2023-07-21 08:58:55 --> Output Class Initialized
INFO - 2023-07-21 08:58:55 --> Security Class Initialized
DEBUG - 2023-07-21 08:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:58:55 --> Input Class Initialized
INFO - 2023-07-21 08:58:55 --> Language Class Initialized
INFO - 2023-07-21 08:58:56 --> Language Class Initialized
INFO - 2023-07-21 08:58:56 --> Config Class Initialized
INFO - 2023-07-21 08:58:56 --> Loader Class Initialized
INFO - 2023-07-21 08:58:56 --> Helper loaded: url_helper
INFO - 2023-07-21 08:58:56 --> Helper loaded: file_helper
INFO - 2023-07-21 08:58:56 --> Helper loaded: form_helper
INFO - 2023-07-21 08:58:56 --> Helper loaded: my_helper
INFO - 2023-07-21 08:58:56 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:58:56 --> Controller Class Initialized
INFO - 2023-07-21 08:58:58 --> Config Class Initialized
INFO - 2023-07-21 08:58:58 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:58:58 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:58:58 --> Utf8 Class Initialized
INFO - 2023-07-21 08:58:58 --> URI Class Initialized
INFO - 2023-07-21 08:58:58 --> Router Class Initialized
INFO - 2023-07-21 08:58:58 --> Output Class Initialized
INFO - 2023-07-21 08:58:58 --> Security Class Initialized
DEBUG - 2023-07-21 08:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:58:58 --> Input Class Initialized
INFO - 2023-07-21 08:58:58 --> Language Class Initialized
INFO - 2023-07-21 08:58:58 --> Language Class Initialized
INFO - 2023-07-21 08:58:58 --> Config Class Initialized
INFO - 2023-07-21 08:58:58 --> Loader Class Initialized
INFO - 2023-07-21 08:58:58 --> Helper loaded: url_helper
INFO - 2023-07-21 08:58:58 --> Helper loaded: file_helper
INFO - 2023-07-21 08:58:58 --> Helper loaded: form_helper
INFO - 2023-07-21 08:58:58 --> Helper loaded: my_helper
INFO - 2023-07-21 08:58:58 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:58:58 --> Controller Class Initialized
INFO - 2023-07-21 08:58:58 --> Final output sent to browser
DEBUG - 2023-07-21 08:58:58 --> Total execution time: 0.0533
INFO - 2023-07-21 08:59:47 --> Config Class Initialized
INFO - 2023-07-21 08:59:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:59:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:59:47 --> Utf8 Class Initialized
INFO - 2023-07-21 08:59:47 --> URI Class Initialized
INFO - 2023-07-21 08:59:47 --> Router Class Initialized
INFO - 2023-07-21 08:59:47 --> Output Class Initialized
INFO - 2023-07-21 08:59:47 --> Security Class Initialized
DEBUG - 2023-07-21 08:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:59:47 --> Input Class Initialized
INFO - 2023-07-21 08:59:47 --> Language Class Initialized
INFO - 2023-07-21 08:59:47 --> Language Class Initialized
INFO - 2023-07-21 08:59:47 --> Config Class Initialized
INFO - 2023-07-21 08:59:47 --> Loader Class Initialized
INFO - 2023-07-21 08:59:47 --> Helper loaded: url_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: file_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: form_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: my_helper
INFO - 2023-07-21 08:59:47 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:59:47 --> Controller Class Initialized
DEBUG - 2023-07-21 08:59:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\modules/data_siswa/views/list.php
DEBUG - 2023-07-21 08:59:47 --> File loaded: C:\xampp\htdocs\myraportk13\bintaro\primary\application\views\template_utama.php
INFO - 2023-07-21 08:59:47 --> Final output sent to browser
DEBUG - 2023-07-21 08:59:47 --> Total execution time: 0.0554
INFO - 2023-07-21 08:59:47 --> Config Class Initialized
INFO - 2023-07-21 08:59:47 --> Hooks Class Initialized
DEBUG - 2023-07-21 08:59:47 --> UTF-8 Support Enabled
INFO - 2023-07-21 08:59:47 --> Utf8 Class Initialized
INFO - 2023-07-21 08:59:47 --> URI Class Initialized
INFO - 2023-07-21 08:59:47 --> Router Class Initialized
INFO - 2023-07-21 08:59:47 --> Output Class Initialized
INFO - 2023-07-21 08:59:47 --> Security Class Initialized
DEBUG - 2023-07-21 08:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-07-21 08:59:47 --> Input Class Initialized
INFO - 2023-07-21 08:59:47 --> Language Class Initialized
INFO - 2023-07-21 08:59:47 --> Language Class Initialized
INFO - 2023-07-21 08:59:47 --> Config Class Initialized
INFO - 2023-07-21 08:59:47 --> Loader Class Initialized
INFO - 2023-07-21 08:59:47 --> Helper loaded: url_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: file_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: form_helper
INFO - 2023-07-21 08:59:47 --> Helper loaded: my_helper
INFO - 2023-07-21 08:59:47 --> Database Driver Class Initialized
DEBUG - 2023-07-21 08:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-07-21 08:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-07-21 08:59:47 --> Controller Class Initialized
