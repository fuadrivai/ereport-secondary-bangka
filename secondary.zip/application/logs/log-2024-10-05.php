<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-05 13:47:36 --> Config Class Initialized
INFO - 2024-10-05 13:47:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 13:47:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 13:47:36 --> Utf8 Class Initialized
INFO - 2024-10-05 13:47:36 --> URI Class Initialized
INFO - 2024-10-05 13:47:36 --> Router Class Initialized
INFO - 2024-10-05 13:47:36 --> Output Class Initialized
INFO - 2024-10-05 13:47:36 --> Security Class Initialized
DEBUG - 2024-10-05 13:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 13:47:36 --> Input Class Initialized
INFO - 2024-10-05 13:47:36 --> Language Class Initialized
INFO - 2024-10-05 13:47:36 --> Language Class Initialized
INFO - 2024-10-05 13:47:36 --> Config Class Initialized
INFO - 2024-10-05 13:47:36 --> Loader Class Initialized
INFO - 2024-10-05 13:47:36 --> Helper loaded: url_helper
INFO - 2024-10-05 13:47:36 --> Helper loaded: file_helper
INFO - 2024-10-05 13:47:36 --> Helper loaded: form_helper
INFO - 2024-10-05 13:47:36 --> Helper loaded: my_helper
INFO - 2024-10-05 13:47:36 --> Database Driver Class Initialized
INFO - 2024-10-05 13:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 13:47:36 --> Controller Class Initialized
DEBUG - 2024-10-05 13:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-05 13:47:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 13:47:36 --> Final output sent to browser
DEBUG - 2024-10-05 13:47:36 --> Total execution time: 0.0662
INFO - 2024-10-05 14:04:25 --> Config Class Initialized
INFO - 2024-10-05 14:04:25 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:04:25 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:04:25 --> Utf8 Class Initialized
INFO - 2024-10-05 14:04:25 --> URI Class Initialized
INFO - 2024-10-05 14:04:25 --> Router Class Initialized
INFO - 2024-10-05 14:04:25 --> Output Class Initialized
INFO - 2024-10-05 14:04:25 --> Security Class Initialized
DEBUG - 2024-10-05 14:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:04:25 --> Input Class Initialized
INFO - 2024-10-05 14:04:25 --> Language Class Initialized
INFO - 2024-10-05 14:04:25 --> Language Class Initialized
INFO - 2024-10-05 14:04:25 --> Config Class Initialized
INFO - 2024-10-05 14:04:25 --> Loader Class Initialized
INFO - 2024-10-05 14:04:25 --> Helper loaded: url_helper
INFO - 2024-10-05 14:04:25 --> Helper loaded: file_helper
INFO - 2024-10-05 14:04:25 --> Helper loaded: form_helper
INFO - 2024-10-05 14:04:25 --> Helper loaded: my_helper
INFO - 2024-10-05 14:04:26 --> Database Driver Class Initialized
INFO - 2024-10-05 14:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:04:26 --> Controller Class Initialized
DEBUG - 2024-10-05 14:04:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-05 14:04:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 14:04:26 --> Final output sent to browser
DEBUG - 2024-10-05 14:04:26 --> Total execution time: 0.0300
INFO - 2024-10-05 14:04:53 --> Config Class Initialized
INFO - 2024-10-05 14:04:53 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:04:53 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:04:53 --> Utf8 Class Initialized
INFO - 2024-10-05 14:04:53 --> URI Class Initialized
INFO - 2024-10-05 14:04:53 --> Router Class Initialized
INFO - 2024-10-05 14:04:53 --> Output Class Initialized
INFO - 2024-10-05 14:04:53 --> Security Class Initialized
DEBUG - 2024-10-05 14:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:04:53 --> Input Class Initialized
INFO - 2024-10-05 14:04:53 --> Language Class Initialized
INFO - 2024-10-05 14:04:53 --> Language Class Initialized
INFO - 2024-10-05 14:04:53 --> Config Class Initialized
INFO - 2024-10-05 14:04:53 --> Loader Class Initialized
INFO - 2024-10-05 14:04:53 --> Helper loaded: url_helper
INFO - 2024-10-05 14:04:53 --> Helper loaded: file_helper
INFO - 2024-10-05 14:04:53 --> Helper loaded: form_helper
INFO - 2024-10-05 14:04:53 --> Helper loaded: my_helper
INFO - 2024-10-05 14:04:53 --> Database Driver Class Initialized
INFO - 2024-10-05 14:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:04:53 --> Controller Class Initialized
INFO - 2024-10-05 14:04:53 --> Helper loaded: cookie_helper
INFO - 2024-10-05 14:04:53 --> Final output sent to browser
DEBUG - 2024-10-05 14:04:53 --> Total execution time: 0.0447
INFO - 2024-10-05 14:04:54 --> Config Class Initialized
INFO - 2024-10-05 14:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:04:54 --> Utf8 Class Initialized
INFO - 2024-10-05 14:04:54 --> URI Class Initialized
INFO - 2024-10-05 14:04:54 --> Router Class Initialized
INFO - 2024-10-05 14:04:54 --> Output Class Initialized
INFO - 2024-10-05 14:04:54 --> Security Class Initialized
DEBUG - 2024-10-05 14:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:04:54 --> Input Class Initialized
INFO - 2024-10-05 14:04:54 --> Language Class Initialized
INFO - 2024-10-05 14:04:54 --> Language Class Initialized
INFO - 2024-10-05 14:04:54 --> Config Class Initialized
INFO - 2024-10-05 14:04:54 --> Loader Class Initialized
INFO - 2024-10-05 14:04:54 --> Helper loaded: url_helper
INFO - 2024-10-05 14:04:54 --> Helper loaded: file_helper
INFO - 2024-10-05 14:04:54 --> Helper loaded: form_helper
INFO - 2024-10-05 14:04:54 --> Helper loaded: my_helper
INFO - 2024-10-05 14:04:54 --> Database Driver Class Initialized
INFO - 2024-10-05 14:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:04:54 --> Controller Class Initialized
DEBUG - 2024-10-05 14:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 14:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 14:04:54 --> Final output sent to browser
DEBUG - 2024-10-05 14:04:54 --> Total execution time: 0.0523
INFO - 2024-10-05 14:05:05 --> Config Class Initialized
INFO - 2024-10-05 14:05:05 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:05:05 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:05:05 --> Utf8 Class Initialized
INFO - 2024-10-05 14:05:05 --> URI Class Initialized
INFO - 2024-10-05 14:05:05 --> Router Class Initialized
INFO - 2024-10-05 14:05:05 --> Output Class Initialized
INFO - 2024-10-05 14:05:05 --> Security Class Initialized
DEBUG - 2024-10-05 14:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:05:05 --> Input Class Initialized
INFO - 2024-10-05 14:05:05 --> Language Class Initialized
INFO - 2024-10-05 14:05:05 --> Language Class Initialized
INFO - 2024-10-05 14:05:05 --> Config Class Initialized
INFO - 2024-10-05 14:05:05 --> Loader Class Initialized
INFO - 2024-10-05 14:05:05 --> Helper loaded: url_helper
INFO - 2024-10-05 14:05:05 --> Helper loaded: file_helper
INFO - 2024-10-05 14:05:05 --> Helper loaded: form_helper
INFO - 2024-10-05 14:05:05 --> Helper loaded: my_helper
INFO - 2024-10-05 14:05:05 --> Database Driver Class Initialized
INFO - 2024-10-05 14:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:05:05 --> Controller Class Initialized
DEBUG - 2024-10-05 14:05:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 14:05:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 14:05:05 --> Final output sent to browser
DEBUG - 2024-10-05 14:05:05 --> Total execution time: 0.0360
INFO - 2024-10-05 14:05:12 --> Config Class Initialized
INFO - 2024-10-05 14:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:05:12 --> Utf8 Class Initialized
INFO - 2024-10-05 14:05:12 --> URI Class Initialized
INFO - 2024-10-05 14:05:12 --> Router Class Initialized
INFO - 2024-10-05 14:05:12 --> Output Class Initialized
INFO - 2024-10-05 14:05:12 --> Security Class Initialized
DEBUG - 2024-10-05 14:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:05:12 --> Input Class Initialized
INFO - 2024-10-05 14:05:12 --> Language Class Initialized
INFO - 2024-10-05 14:05:12 --> Language Class Initialized
INFO - 2024-10-05 14:05:12 --> Config Class Initialized
INFO - 2024-10-05 14:05:12 --> Loader Class Initialized
INFO - 2024-10-05 14:05:12 --> Helper loaded: url_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: file_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: form_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: my_helper
INFO - 2024-10-05 14:05:12 --> Database Driver Class Initialized
INFO - 2024-10-05 14:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:05:12 --> Controller Class Initialized
DEBUG - 2024-10-05 14:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 14:05:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 14:05:12 --> Final output sent to browser
DEBUG - 2024-10-05 14:05:12 --> Total execution time: 0.0408
INFO - 2024-10-05 14:05:12 --> Config Class Initialized
INFO - 2024-10-05 14:05:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:05:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:05:12 --> Utf8 Class Initialized
INFO - 2024-10-05 14:05:12 --> URI Class Initialized
INFO - 2024-10-05 14:05:12 --> Router Class Initialized
INFO - 2024-10-05 14:05:12 --> Output Class Initialized
INFO - 2024-10-05 14:05:12 --> Security Class Initialized
DEBUG - 2024-10-05 14:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:05:12 --> Input Class Initialized
INFO - 2024-10-05 14:05:12 --> Language Class Initialized
INFO - 2024-10-05 14:05:12 --> Language Class Initialized
INFO - 2024-10-05 14:05:12 --> Config Class Initialized
INFO - 2024-10-05 14:05:12 --> Loader Class Initialized
INFO - 2024-10-05 14:05:12 --> Helper loaded: url_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: file_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: form_helper
INFO - 2024-10-05 14:05:12 --> Helper loaded: my_helper
INFO - 2024-10-05 14:05:12 --> Database Driver Class Initialized
INFO - 2024-10-05 14:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:05:12 --> Controller Class Initialized
INFO - 2024-10-05 14:05:17 --> Config Class Initialized
INFO - 2024-10-05 14:05:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:05:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:05:17 --> Utf8 Class Initialized
INFO - 2024-10-05 14:05:17 --> URI Class Initialized
INFO - 2024-10-05 14:05:17 --> Router Class Initialized
INFO - 2024-10-05 14:05:17 --> Output Class Initialized
INFO - 2024-10-05 14:05:17 --> Security Class Initialized
DEBUG - 2024-10-05 14:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:05:17 --> Input Class Initialized
INFO - 2024-10-05 14:05:17 --> Language Class Initialized
INFO - 2024-10-05 14:05:17 --> Language Class Initialized
INFO - 2024-10-05 14:05:17 --> Config Class Initialized
INFO - 2024-10-05 14:05:17 --> Loader Class Initialized
INFO - 2024-10-05 14:05:17 --> Helper loaded: url_helper
INFO - 2024-10-05 14:05:17 --> Helper loaded: file_helper
INFO - 2024-10-05 14:05:17 --> Helper loaded: form_helper
INFO - 2024-10-05 14:05:17 --> Helper loaded: my_helper
INFO - 2024-10-05 14:05:17 --> Database Driver Class Initialized
INFO - 2024-10-05 14:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:05:17 --> Controller Class Initialized
INFO - 2024-10-05 14:05:17 --> Final output sent to browser
DEBUG - 2024-10-05 14:05:17 --> Total execution time: 0.0426
INFO - 2024-10-05 14:05:28 --> Config Class Initialized
INFO - 2024-10-05 14:05:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 14:05:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 14:05:28 --> Utf8 Class Initialized
INFO - 2024-10-05 14:05:28 --> URI Class Initialized
INFO - 2024-10-05 14:05:28 --> Router Class Initialized
INFO - 2024-10-05 14:05:28 --> Output Class Initialized
INFO - 2024-10-05 14:05:28 --> Security Class Initialized
DEBUG - 2024-10-05 14:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 14:05:28 --> Input Class Initialized
INFO - 2024-10-05 14:05:28 --> Language Class Initialized
INFO - 2024-10-05 14:05:28 --> Language Class Initialized
INFO - 2024-10-05 14:05:28 --> Config Class Initialized
INFO - 2024-10-05 14:05:28 --> Loader Class Initialized
INFO - 2024-10-05 14:05:28 --> Helper loaded: url_helper
INFO - 2024-10-05 14:05:28 --> Helper loaded: file_helper
INFO - 2024-10-05 14:05:28 --> Helper loaded: form_helper
INFO - 2024-10-05 14:05:28 --> Helper loaded: my_helper
INFO - 2024-10-05 14:05:28 --> Database Driver Class Initialized
INFO - 2024-10-05 14:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 14:05:28 --> Controller Class Initialized
INFO - 2024-10-05 14:05:28 --> Final output sent to browser
DEBUG - 2024-10-05 14:05:28 --> Total execution time: 0.1937
INFO - 2024-10-05 18:46:47 --> Config Class Initialized
INFO - 2024-10-05 18:46:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:46:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:46:47 --> Utf8 Class Initialized
INFO - 2024-10-05 18:46:47 --> URI Class Initialized
DEBUG - 2024-10-05 18:46:47 --> No URI present. Default controller set.
INFO - 2024-10-05 18:46:47 --> Router Class Initialized
INFO - 2024-10-05 18:46:47 --> Output Class Initialized
INFO - 2024-10-05 18:46:47 --> Security Class Initialized
DEBUG - 2024-10-05 18:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:46:47 --> Input Class Initialized
INFO - 2024-10-05 18:46:47 --> Language Class Initialized
INFO - 2024-10-05 18:46:47 --> Language Class Initialized
INFO - 2024-10-05 18:46:47 --> Config Class Initialized
INFO - 2024-10-05 18:46:47 --> Loader Class Initialized
INFO - 2024-10-05 18:46:47 --> Helper loaded: url_helper
INFO - 2024-10-05 18:46:47 --> Helper loaded: file_helper
INFO - 2024-10-05 18:46:47 --> Helper loaded: form_helper
INFO - 2024-10-05 18:46:47 --> Helper loaded: my_helper
INFO - 2024-10-05 18:46:47 --> Database Driver Class Initialized
INFO - 2024-10-05 18:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:46:48 --> Controller Class Initialized
DEBUG - 2024-10-05 18:46:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 18:46:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:46:48 --> Final output sent to browser
DEBUG - 2024-10-05 18:46:48 --> Total execution time: 0.0545
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:46:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:46:58 --> Utf8 Class Initialized
INFO - 2024-10-05 18:46:58 --> URI Class Initialized
INFO - 2024-10-05 18:46:58 --> Router Class Initialized
INFO - 2024-10-05 18:46:58 --> Output Class Initialized
INFO - 2024-10-05 18:46:58 --> Security Class Initialized
DEBUG - 2024-10-05 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:46:58 --> Input Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Loader Class Initialized
INFO - 2024-10-05 18:46:58 --> Helper loaded: url_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: file_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: form_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: my_helper
INFO - 2024-10-05 18:46:58 --> Database Driver Class Initialized
INFO - 2024-10-05 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:46:58 --> Controller Class Initialized
INFO - 2024-10-05 18:46:58 --> Helper loaded: cookie_helper
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:46:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:46:58 --> Utf8 Class Initialized
INFO - 2024-10-05 18:46:58 --> URI Class Initialized
INFO - 2024-10-05 18:46:58 --> Router Class Initialized
INFO - 2024-10-05 18:46:58 --> Output Class Initialized
INFO - 2024-10-05 18:46:58 --> Security Class Initialized
DEBUG - 2024-10-05 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:46:58 --> Input Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Loader Class Initialized
INFO - 2024-10-05 18:46:58 --> Helper loaded: url_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: file_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: form_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: my_helper
INFO - 2024-10-05 18:46:58 --> Database Driver Class Initialized
INFO - 2024-10-05 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:46:58 --> Controller Class Initialized
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:46:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:46:58 --> Utf8 Class Initialized
INFO - 2024-10-05 18:46:58 --> URI Class Initialized
INFO - 2024-10-05 18:46:58 --> Router Class Initialized
INFO - 2024-10-05 18:46:58 --> Output Class Initialized
INFO - 2024-10-05 18:46:58 --> Security Class Initialized
DEBUG - 2024-10-05 18:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:46:58 --> Input Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Language Class Initialized
INFO - 2024-10-05 18:46:58 --> Config Class Initialized
INFO - 2024-10-05 18:46:58 --> Loader Class Initialized
INFO - 2024-10-05 18:46:58 --> Helper loaded: url_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: file_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: form_helper
INFO - 2024-10-05 18:46:58 --> Helper loaded: my_helper
INFO - 2024-10-05 18:46:58 --> Database Driver Class Initialized
INFO - 2024-10-05 18:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:46:58 --> Controller Class Initialized
DEBUG - 2024-10-05 18:46:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-05 18:46:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:46:58 --> Final output sent to browser
DEBUG - 2024-10-05 18:46:58 --> Total execution time: 0.0321
INFO - 2024-10-05 18:47:05 --> Config Class Initialized
INFO - 2024-10-05 18:47:05 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:05 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:05 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:05 --> URI Class Initialized
INFO - 2024-10-05 18:47:05 --> Router Class Initialized
INFO - 2024-10-05 18:47:05 --> Output Class Initialized
INFO - 2024-10-05 18:47:05 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:05 --> Input Class Initialized
INFO - 2024-10-05 18:47:05 --> Language Class Initialized
INFO - 2024-10-05 18:47:05 --> Language Class Initialized
INFO - 2024-10-05 18:47:05 --> Config Class Initialized
INFO - 2024-10-05 18:47:05 --> Loader Class Initialized
INFO - 2024-10-05 18:47:05 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:05 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:05 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:05 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:05 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:05 --> Controller Class Initialized
INFO - 2024-10-05 18:47:06 --> Helper loaded: cookie_helper
INFO - 2024-10-05 18:47:06 --> Final output sent to browser
DEBUG - 2024-10-05 18:47:06 --> Total execution time: 0.0436
INFO - 2024-10-05 18:47:06 --> Config Class Initialized
INFO - 2024-10-05 18:47:06 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:06 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:06 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:06 --> URI Class Initialized
INFO - 2024-10-05 18:47:06 --> Router Class Initialized
INFO - 2024-10-05 18:47:06 --> Output Class Initialized
INFO - 2024-10-05 18:47:06 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:06 --> Input Class Initialized
INFO - 2024-10-05 18:47:06 --> Language Class Initialized
INFO - 2024-10-05 18:47:06 --> Language Class Initialized
INFO - 2024-10-05 18:47:06 --> Config Class Initialized
INFO - 2024-10-05 18:47:06 --> Loader Class Initialized
INFO - 2024-10-05 18:47:06 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:06 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:06 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:06 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:06 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:06 --> Controller Class Initialized
DEBUG - 2024-10-05 18:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 18:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:47:06 --> Final output sent to browser
DEBUG - 2024-10-05 18:47:06 --> Total execution time: 0.0336
INFO - 2024-10-05 18:47:12 --> Config Class Initialized
INFO - 2024-10-05 18:47:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:12 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:12 --> URI Class Initialized
INFO - 2024-10-05 18:47:12 --> Router Class Initialized
INFO - 2024-10-05 18:47:12 --> Output Class Initialized
INFO - 2024-10-05 18:47:12 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:12 --> Input Class Initialized
INFO - 2024-10-05 18:47:12 --> Language Class Initialized
INFO - 2024-10-05 18:47:12 --> Language Class Initialized
INFO - 2024-10-05 18:47:12 --> Config Class Initialized
INFO - 2024-10-05 18:47:12 --> Loader Class Initialized
INFO - 2024-10-05 18:47:12 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:12 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:12 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:12 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:12 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:12 --> Controller Class Initialized
DEBUG - 2024-10-05 18:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 18:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:47:12 --> Final output sent to browser
DEBUG - 2024-10-05 18:47:12 --> Total execution time: 0.0320
INFO - 2024-10-05 18:47:16 --> Config Class Initialized
INFO - 2024-10-05 18:47:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:16 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:16 --> URI Class Initialized
INFO - 2024-10-05 18:47:16 --> Router Class Initialized
INFO - 2024-10-05 18:47:16 --> Output Class Initialized
INFO - 2024-10-05 18:47:16 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:16 --> Input Class Initialized
INFO - 2024-10-05 18:47:16 --> Language Class Initialized
INFO - 2024-10-05 18:47:16 --> Language Class Initialized
INFO - 2024-10-05 18:47:16 --> Config Class Initialized
INFO - 2024-10-05 18:47:16 --> Loader Class Initialized
INFO - 2024-10-05 18:47:16 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:16 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:16 --> Controller Class Initialized
DEBUG - 2024-10-05 18:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 18:47:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:47:16 --> Final output sent to browser
DEBUG - 2024-10-05 18:47:16 --> Total execution time: 0.0404
INFO - 2024-10-05 18:47:16 --> Config Class Initialized
INFO - 2024-10-05 18:47:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:16 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:16 --> URI Class Initialized
INFO - 2024-10-05 18:47:16 --> Router Class Initialized
INFO - 2024-10-05 18:47:16 --> Output Class Initialized
INFO - 2024-10-05 18:47:16 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:16 --> Input Class Initialized
INFO - 2024-10-05 18:47:16 --> Language Class Initialized
INFO - 2024-10-05 18:47:16 --> Language Class Initialized
INFO - 2024-10-05 18:47:16 --> Config Class Initialized
INFO - 2024-10-05 18:47:16 --> Loader Class Initialized
INFO - 2024-10-05 18:47:16 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:16 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:16 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:16 --> Controller Class Initialized
INFO - 2024-10-05 18:47:43 --> Config Class Initialized
INFO - 2024-10-05 18:47:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:47:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:47:43 --> Utf8 Class Initialized
INFO - 2024-10-05 18:47:43 --> URI Class Initialized
INFO - 2024-10-05 18:47:43 --> Router Class Initialized
INFO - 2024-10-05 18:47:43 --> Output Class Initialized
INFO - 2024-10-05 18:47:43 --> Security Class Initialized
DEBUG - 2024-10-05 18:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:47:43 --> Input Class Initialized
INFO - 2024-10-05 18:47:43 --> Language Class Initialized
INFO - 2024-10-05 18:47:43 --> Language Class Initialized
INFO - 2024-10-05 18:47:43 --> Config Class Initialized
INFO - 2024-10-05 18:47:43 --> Loader Class Initialized
INFO - 2024-10-05 18:47:43 --> Helper loaded: url_helper
INFO - 2024-10-05 18:47:43 --> Helper loaded: file_helper
INFO - 2024-10-05 18:47:43 --> Helper loaded: form_helper
INFO - 2024-10-05 18:47:43 --> Helper loaded: my_helper
INFO - 2024-10-05 18:47:43 --> Database Driver Class Initialized
INFO - 2024-10-05 18:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:47:43 --> Controller Class Initialized
INFO - 2024-10-05 18:47:43 --> Final output sent to browser
DEBUG - 2024-10-05 18:47:43 --> Total execution time: 0.0409
INFO - 2024-10-05 18:54:19 --> Config Class Initialized
INFO - 2024-10-05 18:54:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:54:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:54:19 --> Utf8 Class Initialized
INFO - 2024-10-05 18:54:19 --> URI Class Initialized
INFO - 2024-10-05 18:54:19 --> Router Class Initialized
INFO - 2024-10-05 18:54:19 --> Output Class Initialized
INFO - 2024-10-05 18:54:19 --> Security Class Initialized
DEBUG - 2024-10-05 18:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:54:19 --> Input Class Initialized
INFO - 2024-10-05 18:54:19 --> Language Class Initialized
INFO - 2024-10-05 18:54:19 --> Language Class Initialized
INFO - 2024-10-05 18:54:19 --> Config Class Initialized
INFO - 2024-10-05 18:54:19 --> Loader Class Initialized
INFO - 2024-10-05 18:54:19 --> Helper loaded: url_helper
INFO - 2024-10-05 18:54:19 --> Helper loaded: file_helper
INFO - 2024-10-05 18:54:19 --> Helper loaded: form_helper
INFO - 2024-10-05 18:54:19 --> Helper loaded: my_helper
INFO - 2024-10-05 18:54:19 --> Database Driver Class Initialized
INFO - 2024-10-05 18:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:54:19 --> Controller Class Initialized
INFO - 2024-10-05 18:54:19 --> Final output sent to browser
DEBUG - 2024-10-05 18:54:19 --> Total execution time: 0.0534
INFO - 2024-10-05 18:54:22 --> Config Class Initialized
INFO - 2024-10-05 18:54:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:54:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:54:22 --> Utf8 Class Initialized
INFO - 2024-10-05 18:54:22 --> URI Class Initialized
INFO - 2024-10-05 18:54:22 --> Router Class Initialized
INFO - 2024-10-05 18:54:22 --> Output Class Initialized
INFO - 2024-10-05 18:54:22 --> Security Class Initialized
DEBUG - 2024-10-05 18:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:54:22 --> Input Class Initialized
INFO - 2024-10-05 18:54:22 --> Language Class Initialized
INFO - 2024-10-05 18:54:22 --> Language Class Initialized
INFO - 2024-10-05 18:54:22 --> Config Class Initialized
INFO - 2024-10-05 18:54:22 --> Loader Class Initialized
INFO - 2024-10-05 18:54:22 --> Helper loaded: url_helper
INFO - 2024-10-05 18:54:22 --> Helper loaded: file_helper
INFO - 2024-10-05 18:54:22 --> Helper loaded: form_helper
INFO - 2024-10-05 18:54:22 --> Helper loaded: my_helper
INFO - 2024-10-05 18:54:22 --> Database Driver Class Initialized
INFO - 2024-10-05 18:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:54:22 --> Controller Class Initialized
DEBUG - 2024-10-05 18:54:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 18:54:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:54:22 --> Final output sent to browser
DEBUG - 2024-10-05 18:54:22 --> Total execution time: 0.0300
INFO - 2024-10-05 18:54:24 --> Config Class Initialized
INFO - 2024-10-05 18:54:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:54:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:54:24 --> Utf8 Class Initialized
INFO - 2024-10-05 18:54:24 --> URI Class Initialized
INFO - 2024-10-05 18:54:24 --> Router Class Initialized
INFO - 2024-10-05 18:54:24 --> Output Class Initialized
INFO - 2024-10-05 18:54:24 --> Security Class Initialized
DEBUG - 2024-10-05 18:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:54:24 --> Input Class Initialized
INFO - 2024-10-05 18:54:24 --> Language Class Initialized
INFO - 2024-10-05 18:54:24 --> Language Class Initialized
INFO - 2024-10-05 18:54:24 --> Config Class Initialized
INFO - 2024-10-05 18:54:24 --> Loader Class Initialized
INFO - 2024-10-05 18:54:24 --> Helper loaded: url_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: file_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: form_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: my_helper
INFO - 2024-10-05 18:54:24 --> Database Driver Class Initialized
INFO - 2024-10-05 18:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:54:24 --> Controller Class Initialized
DEBUG - 2024-10-05 18:54:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 18:54:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:54:24 --> Final output sent to browser
DEBUG - 2024-10-05 18:54:24 --> Total execution time: 0.0355
INFO - 2024-10-05 18:54:24 --> Config Class Initialized
INFO - 2024-10-05 18:54:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:54:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:54:24 --> Utf8 Class Initialized
INFO - 2024-10-05 18:54:24 --> URI Class Initialized
INFO - 2024-10-05 18:54:24 --> Router Class Initialized
INFO - 2024-10-05 18:54:24 --> Output Class Initialized
INFO - 2024-10-05 18:54:24 --> Security Class Initialized
DEBUG - 2024-10-05 18:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:54:24 --> Input Class Initialized
INFO - 2024-10-05 18:54:24 --> Language Class Initialized
INFO - 2024-10-05 18:54:24 --> Language Class Initialized
INFO - 2024-10-05 18:54:24 --> Config Class Initialized
INFO - 2024-10-05 18:54:24 --> Loader Class Initialized
INFO - 2024-10-05 18:54:24 --> Helper loaded: url_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: file_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: form_helper
INFO - 2024-10-05 18:54:24 --> Helper loaded: my_helper
INFO - 2024-10-05 18:54:24 --> Database Driver Class Initialized
INFO - 2024-10-05 18:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:54:24 --> Controller Class Initialized
INFO - 2024-10-05 18:54:28 --> Config Class Initialized
INFO - 2024-10-05 18:54:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:54:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:54:28 --> Utf8 Class Initialized
INFO - 2024-10-05 18:54:28 --> URI Class Initialized
INFO - 2024-10-05 18:54:28 --> Router Class Initialized
INFO - 2024-10-05 18:54:28 --> Output Class Initialized
INFO - 2024-10-05 18:54:28 --> Security Class Initialized
DEBUG - 2024-10-05 18:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:54:28 --> Input Class Initialized
INFO - 2024-10-05 18:54:28 --> Language Class Initialized
INFO - 2024-10-05 18:54:28 --> Language Class Initialized
INFO - 2024-10-05 18:54:28 --> Config Class Initialized
INFO - 2024-10-05 18:54:28 --> Loader Class Initialized
INFO - 2024-10-05 18:54:28 --> Helper loaded: url_helper
INFO - 2024-10-05 18:54:28 --> Helper loaded: file_helper
INFO - 2024-10-05 18:54:28 --> Helper loaded: form_helper
INFO - 2024-10-05 18:54:28 --> Helper loaded: my_helper
INFO - 2024-10-05 18:54:28 --> Database Driver Class Initialized
INFO - 2024-10-05 18:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:54:28 --> Controller Class Initialized
INFO - 2024-10-05 18:54:28 --> Final output sent to browser
DEBUG - 2024-10-05 18:54:28 --> Total execution time: 0.0344
INFO - 2024-10-05 18:59:08 --> Config Class Initialized
INFO - 2024-10-05 18:59:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:59:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:59:08 --> Utf8 Class Initialized
INFO - 2024-10-05 18:59:08 --> URI Class Initialized
INFO - 2024-10-05 18:59:08 --> Router Class Initialized
INFO - 2024-10-05 18:59:08 --> Output Class Initialized
INFO - 2024-10-05 18:59:08 --> Security Class Initialized
DEBUG - 2024-10-05 18:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:59:08 --> Input Class Initialized
INFO - 2024-10-05 18:59:08 --> Language Class Initialized
INFO - 2024-10-05 18:59:08 --> Language Class Initialized
INFO - 2024-10-05 18:59:08 --> Config Class Initialized
INFO - 2024-10-05 18:59:08 --> Loader Class Initialized
INFO - 2024-10-05 18:59:08 --> Helper loaded: url_helper
INFO - 2024-10-05 18:59:08 --> Helper loaded: file_helper
INFO - 2024-10-05 18:59:08 --> Helper loaded: form_helper
INFO - 2024-10-05 18:59:08 --> Helper loaded: my_helper
INFO - 2024-10-05 18:59:08 --> Database Driver Class Initialized
INFO - 2024-10-05 18:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:59:08 --> Controller Class Initialized
INFO - 2024-10-05 18:59:08 --> Final output sent to browser
DEBUG - 2024-10-05 18:59:08 --> Total execution time: 0.0578
INFO - 2024-10-05 18:59:17 --> Config Class Initialized
INFO - 2024-10-05 18:59:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:59:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:59:17 --> Utf8 Class Initialized
INFO - 2024-10-05 18:59:17 --> URI Class Initialized
INFO - 2024-10-05 18:59:17 --> Router Class Initialized
INFO - 2024-10-05 18:59:17 --> Output Class Initialized
INFO - 2024-10-05 18:59:17 --> Security Class Initialized
DEBUG - 2024-10-05 18:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:59:17 --> Input Class Initialized
INFO - 2024-10-05 18:59:17 --> Language Class Initialized
INFO - 2024-10-05 18:59:17 --> Language Class Initialized
INFO - 2024-10-05 18:59:17 --> Config Class Initialized
INFO - 2024-10-05 18:59:17 --> Loader Class Initialized
INFO - 2024-10-05 18:59:17 --> Helper loaded: url_helper
INFO - 2024-10-05 18:59:17 --> Helper loaded: file_helper
INFO - 2024-10-05 18:59:17 --> Helper loaded: form_helper
INFO - 2024-10-05 18:59:17 --> Helper loaded: my_helper
INFO - 2024-10-05 18:59:17 --> Database Driver Class Initialized
INFO - 2024-10-05 18:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:59:17 --> Controller Class Initialized
DEBUG - 2024-10-05 18:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 18:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:59:17 --> Final output sent to browser
DEBUG - 2024-10-05 18:59:17 --> Total execution time: 0.0303
INFO - 2024-10-05 18:59:19 --> Config Class Initialized
INFO - 2024-10-05 18:59:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:59:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:59:19 --> Utf8 Class Initialized
INFO - 2024-10-05 18:59:19 --> URI Class Initialized
INFO - 2024-10-05 18:59:19 --> Router Class Initialized
INFO - 2024-10-05 18:59:19 --> Output Class Initialized
INFO - 2024-10-05 18:59:19 --> Security Class Initialized
DEBUG - 2024-10-05 18:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:59:19 --> Input Class Initialized
INFO - 2024-10-05 18:59:19 --> Language Class Initialized
INFO - 2024-10-05 18:59:19 --> Language Class Initialized
INFO - 2024-10-05 18:59:19 --> Config Class Initialized
INFO - 2024-10-05 18:59:19 --> Loader Class Initialized
INFO - 2024-10-05 18:59:19 --> Helper loaded: url_helper
INFO - 2024-10-05 18:59:19 --> Helper loaded: file_helper
INFO - 2024-10-05 18:59:19 --> Helper loaded: form_helper
INFO - 2024-10-05 18:59:19 --> Helper loaded: my_helper
INFO - 2024-10-05 18:59:19 --> Database Driver Class Initialized
INFO - 2024-10-05 18:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:59:19 --> Controller Class Initialized
DEBUG - 2024-10-05 18:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 18:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 18:59:19 --> Final output sent to browser
DEBUG - 2024-10-05 18:59:19 --> Total execution time: 0.0335
INFO - 2024-10-05 18:59:20 --> Config Class Initialized
INFO - 2024-10-05 18:59:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:59:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:59:20 --> Utf8 Class Initialized
INFO - 2024-10-05 18:59:20 --> URI Class Initialized
INFO - 2024-10-05 18:59:20 --> Router Class Initialized
INFO - 2024-10-05 18:59:20 --> Output Class Initialized
INFO - 2024-10-05 18:59:20 --> Security Class Initialized
DEBUG - 2024-10-05 18:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:59:20 --> Input Class Initialized
INFO - 2024-10-05 18:59:20 --> Language Class Initialized
INFO - 2024-10-05 18:59:20 --> Language Class Initialized
INFO - 2024-10-05 18:59:20 --> Config Class Initialized
INFO - 2024-10-05 18:59:20 --> Loader Class Initialized
INFO - 2024-10-05 18:59:20 --> Helper loaded: url_helper
INFO - 2024-10-05 18:59:20 --> Helper loaded: file_helper
INFO - 2024-10-05 18:59:20 --> Helper loaded: form_helper
INFO - 2024-10-05 18:59:20 --> Helper loaded: my_helper
INFO - 2024-10-05 18:59:20 --> Database Driver Class Initialized
INFO - 2024-10-05 18:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:59:20 --> Controller Class Initialized
INFO - 2024-10-05 18:59:23 --> Config Class Initialized
INFO - 2024-10-05 18:59:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 18:59:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 18:59:23 --> Utf8 Class Initialized
INFO - 2024-10-05 18:59:23 --> URI Class Initialized
INFO - 2024-10-05 18:59:23 --> Router Class Initialized
INFO - 2024-10-05 18:59:23 --> Output Class Initialized
INFO - 2024-10-05 18:59:23 --> Security Class Initialized
DEBUG - 2024-10-05 18:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 18:59:23 --> Input Class Initialized
INFO - 2024-10-05 18:59:23 --> Language Class Initialized
INFO - 2024-10-05 18:59:23 --> Language Class Initialized
INFO - 2024-10-05 18:59:23 --> Config Class Initialized
INFO - 2024-10-05 18:59:23 --> Loader Class Initialized
INFO - 2024-10-05 18:59:23 --> Helper loaded: url_helper
INFO - 2024-10-05 18:59:23 --> Helper loaded: file_helper
INFO - 2024-10-05 18:59:23 --> Helper loaded: form_helper
INFO - 2024-10-05 18:59:23 --> Helper loaded: my_helper
INFO - 2024-10-05 18:59:23 --> Database Driver Class Initialized
INFO - 2024-10-05 18:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 18:59:23 --> Controller Class Initialized
INFO - 2024-10-05 18:59:23 --> Final output sent to browser
DEBUG - 2024-10-05 18:59:23 --> Total execution time: 0.0365
INFO - 2024-10-05 19:03:45 --> Config Class Initialized
INFO - 2024-10-05 19:03:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:03:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:03:45 --> Utf8 Class Initialized
INFO - 2024-10-05 19:03:45 --> URI Class Initialized
INFO - 2024-10-05 19:03:45 --> Router Class Initialized
INFO - 2024-10-05 19:03:45 --> Output Class Initialized
INFO - 2024-10-05 19:03:45 --> Security Class Initialized
DEBUG - 2024-10-05 19:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:03:45 --> Input Class Initialized
INFO - 2024-10-05 19:03:45 --> Language Class Initialized
INFO - 2024-10-05 19:03:45 --> Language Class Initialized
INFO - 2024-10-05 19:03:45 --> Config Class Initialized
INFO - 2024-10-05 19:03:45 --> Loader Class Initialized
INFO - 2024-10-05 19:03:45 --> Helper loaded: url_helper
INFO - 2024-10-05 19:03:45 --> Helper loaded: file_helper
INFO - 2024-10-05 19:03:45 --> Helper loaded: form_helper
INFO - 2024-10-05 19:03:45 --> Helper loaded: my_helper
INFO - 2024-10-05 19:03:45 --> Database Driver Class Initialized
INFO - 2024-10-05 19:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:03:45 --> Controller Class Initialized
INFO - 2024-10-05 19:03:45 --> Final output sent to browser
DEBUG - 2024-10-05 19:03:45 --> Total execution time: 0.0596
INFO - 2024-10-05 19:30:57 --> Config Class Initialized
INFO - 2024-10-05 19:30:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:30:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:30:57 --> Utf8 Class Initialized
INFO - 2024-10-05 19:30:57 --> URI Class Initialized
INFO - 2024-10-05 19:30:57 --> Router Class Initialized
INFO - 2024-10-05 19:30:57 --> Output Class Initialized
INFO - 2024-10-05 19:30:57 --> Security Class Initialized
DEBUG - 2024-10-05 19:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:30:57 --> Input Class Initialized
INFO - 2024-10-05 19:30:57 --> Language Class Initialized
INFO - 2024-10-05 19:30:57 --> Language Class Initialized
INFO - 2024-10-05 19:30:57 --> Config Class Initialized
INFO - 2024-10-05 19:30:57 --> Loader Class Initialized
INFO - 2024-10-05 19:30:57 --> Helper loaded: url_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: file_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: form_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: my_helper
INFO - 2024-10-05 19:30:57 --> Database Driver Class Initialized
INFO - 2024-10-05 19:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:30:57 --> Controller Class Initialized
INFO - 2024-10-05 19:30:57 --> Config Class Initialized
INFO - 2024-10-05 19:30:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:30:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:30:57 --> Utf8 Class Initialized
INFO - 2024-10-05 19:30:57 --> URI Class Initialized
INFO - 2024-10-05 19:30:57 --> Router Class Initialized
INFO - 2024-10-05 19:30:57 --> Output Class Initialized
INFO - 2024-10-05 19:30:57 --> Security Class Initialized
DEBUG - 2024-10-05 19:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:30:57 --> Input Class Initialized
INFO - 2024-10-05 19:30:57 --> Language Class Initialized
INFO - 2024-10-05 19:30:57 --> Language Class Initialized
INFO - 2024-10-05 19:30:57 --> Config Class Initialized
INFO - 2024-10-05 19:30:57 --> Loader Class Initialized
INFO - 2024-10-05 19:30:57 --> Helper loaded: url_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: file_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: form_helper
INFO - 2024-10-05 19:30:57 --> Helper loaded: my_helper
INFO - 2024-10-05 19:30:57 --> Database Driver Class Initialized
INFO - 2024-10-05 19:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:30:57 --> Controller Class Initialized
DEBUG - 2024-10-05 19:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-05 19:30:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:30:57 --> Final output sent to browser
DEBUG - 2024-10-05 19:30:57 --> Total execution time: 0.0287
INFO - 2024-10-05 19:33:07 --> Config Class Initialized
INFO - 2024-10-05 19:33:07 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:33:07 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:33:07 --> Utf8 Class Initialized
INFO - 2024-10-05 19:33:07 --> URI Class Initialized
INFO - 2024-10-05 19:33:07 --> Router Class Initialized
INFO - 2024-10-05 19:33:07 --> Output Class Initialized
INFO - 2024-10-05 19:33:07 --> Security Class Initialized
DEBUG - 2024-10-05 19:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:33:07 --> Input Class Initialized
INFO - 2024-10-05 19:33:07 --> Language Class Initialized
INFO - 2024-10-05 19:33:07 --> Language Class Initialized
INFO - 2024-10-05 19:33:07 --> Config Class Initialized
INFO - 2024-10-05 19:33:07 --> Loader Class Initialized
INFO - 2024-10-05 19:33:07 --> Helper loaded: url_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: file_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: form_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: my_helper
INFO - 2024-10-05 19:33:07 --> Database Driver Class Initialized
INFO - 2024-10-05 19:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:33:07 --> Controller Class Initialized
INFO - 2024-10-05 19:33:07 --> Helper loaded: cookie_helper
INFO - 2024-10-05 19:33:07 --> Final output sent to browser
DEBUG - 2024-10-05 19:33:07 --> Total execution time: 0.0370
INFO - 2024-10-05 19:33:07 --> Config Class Initialized
INFO - 2024-10-05 19:33:07 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:33:07 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:33:07 --> Utf8 Class Initialized
INFO - 2024-10-05 19:33:07 --> URI Class Initialized
INFO - 2024-10-05 19:33:07 --> Router Class Initialized
INFO - 2024-10-05 19:33:07 --> Output Class Initialized
INFO - 2024-10-05 19:33:07 --> Security Class Initialized
DEBUG - 2024-10-05 19:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:33:07 --> Input Class Initialized
INFO - 2024-10-05 19:33:07 --> Language Class Initialized
INFO - 2024-10-05 19:33:07 --> Language Class Initialized
INFO - 2024-10-05 19:33:07 --> Config Class Initialized
INFO - 2024-10-05 19:33:07 --> Loader Class Initialized
INFO - 2024-10-05 19:33:07 --> Helper loaded: url_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: file_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: form_helper
INFO - 2024-10-05 19:33:07 --> Helper loaded: my_helper
INFO - 2024-10-05 19:33:07 --> Database Driver Class Initialized
INFO - 2024-10-05 19:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:33:07 --> Controller Class Initialized
DEBUG - 2024-10-05 19:33:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 19:33:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:33:07 --> Final output sent to browser
DEBUG - 2024-10-05 19:33:07 --> Total execution time: 0.0309
INFO - 2024-10-05 19:33:10 --> Config Class Initialized
INFO - 2024-10-05 19:33:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:33:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:33:10 --> Utf8 Class Initialized
INFO - 2024-10-05 19:33:10 --> URI Class Initialized
INFO - 2024-10-05 19:33:10 --> Router Class Initialized
INFO - 2024-10-05 19:33:10 --> Output Class Initialized
INFO - 2024-10-05 19:33:10 --> Security Class Initialized
DEBUG - 2024-10-05 19:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:33:10 --> Input Class Initialized
INFO - 2024-10-05 19:33:10 --> Language Class Initialized
INFO - 2024-10-05 19:33:10 --> Language Class Initialized
INFO - 2024-10-05 19:33:10 --> Config Class Initialized
INFO - 2024-10-05 19:33:10 --> Loader Class Initialized
INFO - 2024-10-05 19:33:10 --> Helper loaded: url_helper
INFO - 2024-10-05 19:33:10 --> Helper loaded: file_helper
INFO - 2024-10-05 19:33:10 --> Helper loaded: form_helper
INFO - 2024-10-05 19:33:10 --> Helper loaded: my_helper
INFO - 2024-10-05 19:33:10 --> Database Driver Class Initialized
INFO - 2024-10-05 19:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:33:10 --> Controller Class Initialized
DEBUG - 2024-10-05 19:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:33:10 --> Final output sent to browser
DEBUG - 2024-10-05 19:33:10 --> Total execution time: 0.0307
INFO - 2024-10-05 19:34:10 --> Config Class Initialized
INFO - 2024-10-05 19:34:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:34:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:34:10 --> Utf8 Class Initialized
INFO - 2024-10-05 19:34:10 --> URI Class Initialized
INFO - 2024-10-05 19:34:10 --> Router Class Initialized
INFO - 2024-10-05 19:34:10 --> Output Class Initialized
INFO - 2024-10-05 19:34:10 --> Security Class Initialized
DEBUG - 2024-10-05 19:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:34:10 --> Input Class Initialized
INFO - 2024-10-05 19:34:10 --> Language Class Initialized
INFO - 2024-10-05 19:34:10 --> Language Class Initialized
INFO - 2024-10-05 19:34:10 --> Config Class Initialized
INFO - 2024-10-05 19:34:10 --> Loader Class Initialized
INFO - 2024-10-05 19:34:10 --> Helper loaded: url_helper
INFO - 2024-10-05 19:34:10 --> Helper loaded: file_helper
INFO - 2024-10-05 19:34:10 --> Helper loaded: form_helper
INFO - 2024-10-05 19:34:10 --> Helper loaded: my_helper
INFO - 2024-10-05 19:34:10 --> Database Driver Class Initialized
INFO - 2024-10-05 19:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:34:10 --> Controller Class Initialized
INFO - 2024-10-05 19:35:02 --> Config Class Initialized
INFO - 2024-10-05 19:35:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:02 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:02 --> URI Class Initialized
INFO - 2024-10-05 19:35:02 --> Router Class Initialized
INFO - 2024-10-05 19:35:02 --> Output Class Initialized
INFO - 2024-10-05 19:35:02 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:02 --> Input Class Initialized
INFO - 2024-10-05 19:35:02 --> Language Class Initialized
INFO - 2024-10-05 19:35:02 --> Language Class Initialized
INFO - 2024-10-05 19:35:02 --> Config Class Initialized
INFO - 2024-10-05 19:35:02 --> Loader Class Initialized
INFO - 2024-10-05 19:35:02 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:02 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:02 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:02 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:02 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:02 --> Controller Class Initialized
DEBUG - 2024-10-05 19:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:35:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:35:02 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:02 --> Total execution time: 0.0478
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:11 --> URI Class Initialized
INFO - 2024-10-05 19:35:11 --> Router Class Initialized
INFO - 2024-10-05 19:35:11 --> Output Class Initialized
INFO - 2024-10-05 19:35:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:11 --> Input Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Loader Class Initialized
INFO - 2024-10-05 19:35:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:11 --> Controller Class Initialized
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:11 --> URI Class Initialized
INFO - 2024-10-05 19:35:11 --> Router Class Initialized
INFO - 2024-10-05 19:35:11 --> Output Class Initialized
INFO - 2024-10-05 19:35:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:11 --> Input Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Loader Class Initialized
INFO - 2024-10-05 19:35:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:11 --> Controller Class Initialized
DEBUG - 2024-10-05 19:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:35:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:35:11 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:11 --> Total execution time: 0.0370
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:11 --> URI Class Initialized
INFO - 2024-10-05 19:35:11 --> Router Class Initialized
INFO - 2024-10-05 19:35:11 --> Output Class Initialized
INFO - 2024-10-05 19:35:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:11 --> Input Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Language Class Initialized
INFO - 2024-10-05 19:35:11 --> Config Class Initialized
INFO - 2024-10-05 19:35:11 --> Loader Class Initialized
INFO - 2024-10-05 19:35:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:11 --> Controller Class Initialized
INFO - 2024-10-05 19:35:16 --> Config Class Initialized
INFO - 2024-10-05 19:35:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:16 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:16 --> URI Class Initialized
INFO - 2024-10-05 19:35:16 --> Router Class Initialized
INFO - 2024-10-05 19:35:16 --> Output Class Initialized
INFO - 2024-10-05 19:35:16 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:16 --> Input Class Initialized
INFO - 2024-10-05 19:35:16 --> Language Class Initialized
INFO - 2024-10-05 19:35:16 --> Language Class Initialized
INFO - 2024-10-05 19:35:16 --> Config Class Initialized
INFO - 2024-10-05 19:35:16 --> Loader Class Initialized
INFO - 2024-10-05 19:35:16 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:16 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:16 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:16 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:16 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:16 --> Controller Class Initialized
INFO - 2024-10-05 19:35:16 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:16 --> Total execution time: 0.0359
INFO - 2024-10-05 19:35:19 --> Config Class Initialized
INFO - 2024-10-05 19:35:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:19 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:19 --> URI Class Initialized
INFO - 2024-10-05 19:35:19 --> Router Class Initialized
INFO - 2024-10-05 19:35:19 --> Output Class Initialized
INFO - 2024-10-05 19:35:19 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:19 --> Input Class Initialized
INFO - 2024-10-05 19:35:19 --> Language Class Initialized
INFO - 2024-10-05 19:35:19 --> Language Class Initialized
INFO - 2024-10-05 19:35:19 --> Config Class Initialized
INFO - 2024-10-05 19:35:19 --> Loader Class Initialized
INFO - 2024-10-05 19:35:19 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:19 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:19 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:19 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:19 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:19 --> Controller Class Initialized
INFO - 2024-10-05 19:35:19 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:19 --> Total execution time: 0.0340
INFO - 2024-10-05 19:35:21 --> Config Class Initialized
INFO - 2024-10-05 19:35:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:21 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:21 --> URI Class Initialized
INFO - 2024-10-05 19:35:21 --> Router Class Initialized
INFO - 2024-10-05 19:35:21 --> Output Class Initialized
INFO - 2024-10-05 19:35:21 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:21 --> Input Class Initialized
INFO - 2024-10-05 19:35:21 --> Language Class Initialized
INFO - 2024-10-05 19:35:21 --> Language Class Initialized
INFO - 2024-10-05 19:35:21 --> Config Class Initialized
INFO - 2024-10-05 19:35:21 --> Loader Class Initialized
INFO - 2024-10-05 19:35:21 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:21 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:21 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:21 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:21 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:21 --> Controller Class Initialized
DEBUG - 2024-10-05 19:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:35:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:35:21 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:21 --> Total execution time: 0.0278
INFO - 2024-10-05 19:35:27 --> Config Class Initialized
INFO - 2024-10-05 19:35:27 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:27 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:27 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:27 --> URI Class Initialized
INFO - 2024-10-05 19:35:27 --> Router Class Initialized
INFO - 2024-10-05 19:35:27 --> Output Class Initialized
INFO - 2024-10-05 19:35:27 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:27 --> Input Class Initialized
INFO - 2024-10-05 19:35:27 --> Language Class Initialized
INFO - 2024-10-05 19:35:27 --> Language Class Initialized
INFO - 2024-10-05 19:35:27 --> Config Class Initialized
INFO - 2024-10-05 19:35:27 --> Loader Class Initialized
INFO - 2024-10-05 19:35:27 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:27 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:27 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:27 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:27 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:27 --> Controller Class Initialized
DEBUG - 2024-10-05 19:35:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:35:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:35:27 --> Final output sent to browser
DEBUG - 2024-10-05 19:35:27 --> Total execution time: 0.0291
INFO - 2024-10-05 19:35:28 --> Config Class Initialized
INFO - 2024-10-05 19:35:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:28 --> URI Class Initialized
INFO - 2024-10-05 19:35:28 --> Router Class Initialized
INFO - 2024-10-05 19:35:28 --> Output Class Initialized
INFO - 2024-10-05 19:35:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:28 --> Input Class Initialized
INFO - 2024-10-05 19:35:28 --> Language Class Initialized
INFO - 2024-10-05 19:35:28 --> Language Class Initialized
INFO - 2024-10-05 19:35:28 --> Config Class Initialized
INFO - 2024-10-05 19:35:28 --> Loader Class Initialized
INFO - 2024-10-05 19:35:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:28 --> Controller Class Initialized
INFO - 2024-10-05 19:35:29 --> Config Class Initialized
INFO - 2024-10-05 19:35:29 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:35:29 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:35:29 --> Utf8 Class Initialized
INFO - 2024-10-05 19:35:29 --> URI Class Initialized
INFO - 2024-10-05 19:35:29 --> Router Class Initialized
INFO - 2024-10-05 19:35:29 --> Output Class Initialized
INFO - 2024-10-05 19:35:29 --> Security Class Initialized
DEBUG - 2024-10-05 19:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:35:29 --> Input Class Initialized
INFO - 2024-10-05 19:35:29 --> Language Class Initialized
INFO - 2024-10-05 19:35:29 --> Language Class Initialized
INFO - 2024-10-05 19:35:29 --> Config Class Initialized
INFO - 2024-10-05 19:35:29 --> Loader Class Initialized
INFO - 2024-10-05 19:35:29 --> Helper loaded: url_helper
INFO - 2024-10-05 19:35:29 --> Helper loaded: file_helper
INFO - 2024-10-05 19:35:29 --> Helper loaded: form_helper
INFO - 2024-10-05 19:35:29 --> Helper loaded: my_helper
INFO - 2024-10-05 19:35:29 --> Database Driver Class Initialized
INFO - 2024-10-05 19:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:35:29 --> Controller Class Initialized
INFO - 2024-10-05 19:36:02 --> Config Class Initialized
INFO - 2024-10-05 19:36:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:02 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:02 --> URI Class Initialized
INFO - 2024-10-05 19:36:02 --> Router Class Initialized
INFO - 2024-10-05 19:36:02 --> Output Class Initialized
INFO - 2024-10-05 19:36:02 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:02 --> Input Class Initialized
INFO - 2024-10-05 19:36:02 --> Language Class Initialized
INFO - 2024-10-05 19:36:02 --> Language Class Initialized
INFO - 2024-10-05 19:36:02 --> Config Class Initialized
INFO - 2024-10-05 19:36:02 --> Loader Class Initialized
INFO - 2024-10-05 19:36:02 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:02 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:02 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:02 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:02 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:02 --> Controller Class Initialized
DEBUG - 2024-10-05 19:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:36:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:36:02 --> Final output sent to browser
DEBUG - 2024-10-05 19:36:02 --> Total execution time: 0.0435
INFO - 2024-10-05 19:36:14 --> Config Class Initialized
INFO - 2024-10-05 19:36:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:14 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:14 --> URI Class Initialized
INFO - 2024-10-05 19:36:14 --> Router Class Initialized
INFO - 2024-10-05 19:36:14 --> Output Class Initialized
INFO - 2024-10-05 19:36:14 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:14 --> Input Class Initialized
INFO - 2024-10-05 19:36:14 --> Language Class Initialized
INFO - 2024-10-05 19:36:14 --> Language Class Initialized
INFO - 2024-10-05 19:36:14 --> Config Class Initialized
INFO - 2024-10-05 19:36:14 --> Loader Class Initialized
INFO - 2024-10-05 19:36:14 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:14 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:14 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:14 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:14 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:14 --> Controller Class Initialized
INFO - 2024-10-05 19:36:15 --> Config Class Initialized
INFO - 2024-10-05 19:36:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:15 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:15 --> URI Class Initialized
INFO - 2024-10-05 19:36:15 --> Router Class Initialized
INFO - 2024-10-05 19:36:15 --> Output Class Initialized
INFO - 2024-10-05 19:36:15 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:15 --> Input Class Initialized
INFO - 2024-10-05 19:36:15 --> Language Class Initialized
INFO - 2024-10-05 19:36:15 --> Language Class Initialized
INFO - 2024-10-05 19:36:15 --> Config Class Initialized
INFO - 2024-10-05 19:36:15 --> Loader Class Initialized
INFO - 2024-10-05 19:36:15 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:15 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:15 --> Controller Class Initialized
DEBUG - 2024-10-05 19:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:36:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:36:15 --> Final output sent to browser
DEBUG - 2024-10-05 19:36:15 --> Total execution time: 0.0414
INFO - 2024-10-05 19:36:15 --> Config Class Initialized
INFO - 2024-10-05 19:36:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:15 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:15 --> URI Class Initialized
INFO - 2024-10-05 19:36:15 --> Router Class Initialized
INFO - 2024-10-05 19:36:15 --> Output Class Initialized
INFO - 2024-10-05 19:36:15 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:15 --> Input Class Initialized
INFO - 2024-10-05 19:36:15 --> Language Class Initialized
INFO - 2024-10-05 19:36:15 --> Language Class Initialized
INFO - 2024-10-05 19:36:15 --> Config Class Initialized
INFO - 2024-10-05 19:36:15 --> Loader Class Initialized
INFO - 2024-10-05 19:36:15 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:15 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:15 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:15 --> Controller Class Initialized
INFO - 2024-10-05 19:36:24 --> Config Class Initialized
INFO - 2024-10-05 19:36:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:24 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:24 --> URI Class Initialized
INFO - 2024-10-05 19:36:24 --> Router Class Initialized
INFO - 2024-10-05 19:36:24 --> Output Class Initialized
INFO - 2024-10-05 19:36:24 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:24 --> Input Class Initialized
INFO - 2024-10-05 19:36:24 --> Language Class Initialized
INFO - 2024-10-05 19:36:24 --> Language Class Initialized
INFO - 2024-10-05 19:36:24 --> Config Class Initialized
INFO - 2024-10-05 19:36:24 --> Loader Class Initialized
INFO - 2024-10-05 19:36:24 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:24 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:24 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:24 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:24 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:24 --> Controller Class Initialized
DEBUG - 2024-10-05 19:36:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:36:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:36:24 --> Final output sent to browser
DEBUG - 2024-10-05 19:36:24 --> Total execution time: 0.0378
INFO - 2024-10-05 19:36:26 --> Config Class Initialized
INFO - 2024-10-05 19:36:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:26 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:26 --> URI Class Initialized
INFO - 2024-10-05 19:36:26 --> Router Class Initialized
INFO - 2024-10-05 19:36:26 --> Output Class Initialized
INFO - 2024-10-05 19:36:26 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:26 --> Input Class Initialized
INFO - 2024-10-05 19:36:26 --> Language Class Initialized
INFO - 2024-10-05 19:36:26 --> Language Class Initialized
INFO - 2024-10-05 19:36:26 --> Config Class Initialized
INFO - 2024-10-05 19:36:26 --> Loader Class Initialized
INFO - 2024-10-05 19:36:26 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:26 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:26 --> Controller Class Initialized
DEBUG - 2024-10-05 19:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:36:26 --> Final output sent to browser
DEBUG - 2024-10-05 19:36:26 --> Total execution time: 0.0305
INFO - 2024-10-05 19:36:26 --> Config Class Initialized
INFO - 2024-10-05 19:36:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:26 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:26 --> URI Class Initialized
INFO - 2024-10-05 19:36:26 --> Router Class Initialized
INFO - 2024-10-05 19:36:26 --> Output Class Initialized
INFO - 2024-10-05 19:36:26 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:26 --> Input Class Initialized
INFO - 2024-10-05 19:36:26 --> Language Class Initialized
INFO - 2024-10-05 19:36:26 --> Language Class Initialized
INFO - 2024-10-05 19:36:26 --> Config Class Initialized
INFO - 2024-10-05 19:36:26 --> Loader Class Initialized
INFO - 2024-10-05 19:36:26 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:26 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:26 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:26 --> Controller Class Initialized
INFO - 2024-10-05 19:36:28 --> Config Class Initialized
INFO - 2024-10-05 19:36:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:36:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:36:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:36:28 --> URI Class Initialized
INFO - 2024-10-05 19:36:28 --> Router Class Initialized
INFO - 2024-10-05 19:36:28 --> Output Class Initialized
INFO - 2024-10-05 19:36:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:36:28 --> Input Class Initialized
INFO - 2024-10-05 19:36:28 --> Language Class Initialized
INFO - 2024-10-05 19:36:28 --> Language Class Initialized
INFO - 2024-10-05 19:36:28 --> Config Class Initialized
INFO - 2024-10-05 19:36:28 --> Loader Class Initialized
INFO - 2024-10-05 19:36:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:36:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:36:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:36:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:36:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:36:28 --> Controller Class Initialized
INFO - 2024-10-05 19:37:03 --> Config Class Initialized
INFO - 2024-10-05 19:37:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:03 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:03 --> URI Class Initialized
INFO - 2024-10-05 19:37:03 --> Router Class Initialized
INFO - 2024-10-05 19:37:03 --> Output Class Initialized
INFO - 2024-10-05 19:37:03 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:03 --> Input Class Initialized
INFO - 2024-10-05 19:37:03 --> Language Class Initialized
INFO - 2024-10-05 19:37:03 --> Language Class Initialized
INFO - 2024-10-05 19:37:03 --> Config Class Initialized
INFO - 2024-10-05 19:37:03 --> Loader Class Initialized
INFO - 2024-10-05 19:37:03 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:03 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:03 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:03 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:03 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:03 --> Controller Class Initialized
DEBUG - 2024-10-05 19:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:37:03 --> Final output sent to browser
DEBUG - 2024-10-05 19:37:03 --> Total execution time: 0.0303
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:11 --> URI Class Initialized
INFO - 2024-10-05 19:37:11 --> Router Class Initialized
INFO - 2024-10-05 19:37:11 --> Output Class Initialized
INFO - 2024-10-05 19:37:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:11 --> Input Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Loader Class Initialized
INFO - 2024-10-05 19:37:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:11 --> Controller Class Initialized
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:11 --> URI Class Initialized
INFO - 2024-10-05 19:37:11 --> Router Class Initialized
INFO - 2024-10-05 19:37:11 --> Output Class Initialized
INFO - 2024-10-05 19:37:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:11 --> Input Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Loader Class Initialized
INFO - 2024-10-05 19:37:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:11 --> Controller Class Initialized
DEBUG - 2024-10-05 19:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:37:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:37:11 --> Final output sent to browser
DEBUG - 2024-10-05 19:37:11 --> Total execution time: 0.0328
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:11 --> URI Class Initialized
INFO - 2024-10-05 19:37:11 --> Router Class Initialized
INFO - 2024-10-05 19:37:11 --> Output Class Initialized
INFO - 2024-10-05 19:37:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:11 --> Input Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Language Class Initialized
INFO - 2024-10-05 19:37:11 --> Config Class Initialized
INFO - 2024-10-05 19:37:11 --> Loader Class Initialized
INFO - 2024-10-05 19:37:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:11 --> Controller Class Initialized
INFO - 2024-10-05 19:37:15 --> Config Class Initialized
INFO - 2024-10-05 19:37:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:15 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:15 --> URI Class Initialized
INFO - 2024-10-05 19:37:15 --> Router Class Initialized
INFO - 2024-10-05 19:37:15 --> Output Class Initialized
INFO - 2024-10-05 19:37:15 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:15 --> Input Class Initialized
INFO - 2024-10-05 19:37:15 --> Language Class Initialized
INFO - 2024-10-05 19:37:15 --> Language Class Initialized
INFO - 2024-10-05 19:37:15 --> Config Class Initialized
INFO - 2024-10-05 19:37:15 --> Loader Class Initialized
INFO - 2024-10-05 19:37:15 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:15 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:15 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:15 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:15 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:15 --> Controller Class Initialized
INFO - 2024-10-05 19:37:15 --> Final output sent to browser
DEBUG - 2024-10-05 19:37:15 --> Total execution time: 0.0328
INFO - 2024-10-05 19:37:21 --> Config Class Initialized
INFO - 2024-10-05 19:37:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:37:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:37:21 --> Utf8 Class Initialized
INFO - 2024-10-05 19:37:21 --> URI Class Initialized
INFO - 2024-10-05 19:37:21 --> Router Class Initialized
INFO - 2024-10-05 19:37:21 --> Output Class Initialized
INFO - 2024-10-05 19:37:21 --> Security Class Initialized
DEBUG - 2024-10-05 19:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:37:21 --> Input Class Initialized
INFO - 2024-10-05 19:37:21 --> Language Class Initialized
INFO - 2024-10-05 19:37:21 --> Language Class Initialized
INFO - 2024-10-05 19:37:21 --> Config Class Initialized
INFO - 2024-10-05 19:37:21 --> Loader Class Initialized
INFO - 2024-10-05 19:37:21 --> Helper loaded: url_helper
INFO - 2024-10-05 19:37:21 --> Helper loaded: file_helper
INFO - 2024-10-05 19:37:21 --> Helper loaded: form_helper
INFO - 2024-10-05 19:37:21 --> Helper loaded: my_helper
INFO - 2024-10-05 19:37:21 --> Database Driver Class Initialized
INFO - 2024-10-05 19:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:37:21 --> Controller Class Initialized
DEBUG - 2024-10-05 19:37:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:37:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:37:21 --> Final output sent to browser
DEBUG - 2024-10-05 19:37:21 --> Total execution time: 0.0371
INFO - 2024-10-05 19:39:33 --> Config Class Initialized
INFO - 2024-10-05 19:39:33 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:39:33 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:39:33 --> Utf8 Class Initialized
INFO - 2024-10-05 19:39:33 --> URI Class Initialized
INFO - 2024-10-05 19:39:33 --> Router Class Initialized
INFO - 2024-10-05 19:39:33 --> Output Class Initialized
INFO - 2024-10-05 19:39:33 --> Security Class Initialized
DEBUG - 2024-10-05 19:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:39:33 --> Input Class Initialized
INFO - 2024-10-05 19:39:33 --> Language Class Initialized
INFO - 2024-10-05 19:39:33 --> Language Class Initialized
INFO - 2024-10-05 19:39:33 --> Config Class Initialized
INFO - 2024-10-05 19:39:33 --> Loader Class Initialized
INFO - 2024-10-05 19:39:33 --> Helper loaded: url_helper
INFO - 2024-10-05 19:39:33 --> Helper loaded: file_helper
INFO - 2024-10-05 19:39:33 --> Helper loaded: form_helper
INFO - 2024-10-05 19:39:33 --> Helper loaded: my_helper
INFO - 2024-10-05 19:39:33 --> Database Driver Class Initialized
INFO - 2024-10-05 19:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:39:33 --> Controller Class Initialized
DEBUG - 2024-10-05 19:39:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:39:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:39:33 --> Final output sent to browser
DEBUG - 2024-10-05 19:39:33 --> Total execution time: 0.0458
INFO - 2024-10-05 19:39:43 --> Config Class Initialized
INFO - 2024-10-05 19:39:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:39:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:39:43 --> Utf8 Class Initialized
INFO - 2024-10-05 19:39:43 --> URI Class Initialized
INFO - 2024-10-05 19:39:43 --> Router Class Initialized
INFO - 2024-10-05 19:39:43 --> Output Class Initialized
INFO - 2024-10-05 19:39:43 --> Security Class Initialized
DEBUG - 2024-10-05 19:39:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:39:43 --> Input Class Initialized
INFO - 2024-10-05 19:39:43 --> Language Class Initialized
INFO - 2024-10-05 19:39:43 --> Language Class Initialized
INFO - 2024-10-05 19:39:43 --> Config Class Initialized
INFO - 2024-10-05 19:39:43 --> Loader Class Initialized
INFO - 2024-10-05 19:39:43 --> Helper loaded: url_helper
INFO - 2024-10-05 19:39:43 --> Helper loaded: file_helper
INFO - 2024-10-05 19:39:43 --> Helper loaded: form_helper
INFO - 2024-10-05 19:39:43 --> Helper loaded: my_helper
INFO - 2024-10-05 19:39:43 --> Database Driver Class Initialized
INFO - 2024-10-05 19:39:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:39:43 --> Controller Class Initialized
INFO - 2024-10-05 19:39:43 --> Final output sent to browser
DEBUG - 2024-10-05 19:39:43 --> Total execution time: 0.0441
INFO - 2024-10-05 19:39:50 --> Config Class Initialized
INFO - 2024-10-05 19:39:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:39:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:39:50 --> Utf8 Class Initialized
INFO - 2024-10-05 19:39:50 --> URI Class Initialized
INFO - 2024-10-05 19:39:50 --> Router Class Initialized
INFO - 2024-10-05 19:39:50 --> Output Class Initialized
INFO - 2024-10-05 19:39:50 --> Security Class Initialized
DEBUG - 2024-10-05 19:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:39:50 --> Input Class Initialized
INFO - 2024-10-05 19:39:50 --> Language Class Initialized
INFO - 2024-10-05 19:39:50 --> Language Class Initialized
INFO - 2024-10-05 19:39:50 --> Config Class Initialized
INFO - 2024-10-05 19:39:50 --> Loader Class Initialized
INFO - 2024-10-05 19:39:50 --> Helper loaded: url_helper
INFO - 2024-10-05 19:39:50 --> Helper loaded: file_helper
INFO - 2024-10-05 19:39:50 --> Helper loaded: form_helper
INFO - 2024-10-05 19:39:50 --> Helper loaded: my_helper
INFO - 2024-10-05 19:39:50 --> Database Driver Class Initialized
INFO - 2024-10-05 19:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:39:50 --> Controller Class Initialized
DEBUG - 2024-10-05 19:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:39:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:39:50 --> Final output sent to browser
DEBUG - 2024-10-05 19:39:50 --> Total execution time: 0.0288
INFO - 2024-10-05 19:39:53 --> Config Class Initialized
INFO - 2024-10-05 19:39:53 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:39:53 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:39:53 --> Utf8 Class Initialized
INFO - 2024-10-05 19:39:53 --> URI Class Initialized
INFO - 2024-10-05 19:39:53 --> Router Class Initialized
INFO - 2024-10-05 19:39:53 --> Output Class Initialized
INFO - 2024-10-05 19:39:53 --> Security Class Initialized
DEBUG - 2024-10-05 19:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:39:53 --> Input Class Initialized
INFO - 2024-10-05 19:39:53 --> Language Class Initialized
INFO - 2024-10-05 19:39:53 --> Language Class Initialized
INFO - 2024-10-05 19:39:53 --> Config Class Initialized
INFO - 2024-10-05 19:39:53 --> Loader Class Initialized
INFO - 2024-10-05 19:39:53 --> Helper loaded: url_helper
INFO - 2024-10-05 19:39:53 --> Helper loaded: file_helper
INFO - 2024-10-05 19:39:53 --> Helper loaded: form_helper
INFO - 2024-10-05 19:39:53 --> Helper loaded: my_helper
INFO - 2024-10-05 19:39:53 --> Database Driver Class Initialized
INFO - 2024-10-05 19:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:39:53 --> Controller Class Initialized
DEBUG - 2024-10-05 19:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:39:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:39:53 --> Final output sent to browser
DEBUG - 2024-10-05 19:39:53 --> Total execution time: 0.0315
INFO - 2024-10-05 19:39:55 --> Config Class Initialized
INFO - 2024-10-05 19:39:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:39:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:39:55 --> Utf8 Class Initialized
INFO - 2024-10-05 19:39:55 --> URI Class Initialized
INFO - 2024-10-05 19:39:55 --> Router Class Initialized
INFO - 2024-10-05 19:39:55 --> Output Class Initialized
INFO - 2024-10-05 19:39:55 --> Security Class Initialized
DEBUG - 2024-10-05 19:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:39:55 --> Input Class Initialized
INFO - 2024-10-05 19:39:55 --> Language Class Initialized
INFO - 2024-10-05 19:39:55 --> Language Class Initialized
INFO - 2024-10-05 19:39:55 --> Config Class Initialized
INFO - 2024-10-05 19:39:55 --> Loader Class Initialized
INFO - 2024-10-05 19:39:55 --> Helper loaded: url_helper
INFO - 2024-10-05 19:39:55 --> Helper loaded: file_helper
INFO - 2024-10-05 19:39:55 --> Helper loaded: form_helper
INFO - 2024-10-05 19:39:55 --> Helper loaded: my_helper
INFO - 2024-10-05 19:39:55 --> Database Driver Class Initialized
INFO - 2024-10-05 19:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:39:55 --> Controller Class Initialized
INFO - 2024-10-05 19:39:55 --> Final output sent to browser
DEBUG - 2024-10-05 19:39:55 --> Total execution time: 0.0297
INFO - 2024-10-05 19:41:26 --> Config Class Initialized
INFO - 2024-10-05 19:41:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:26 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:26 --> URI Class Initialized
INFO - 2024-10-05 19:41:26 --> Router Class Initialized
INFO - 2024-10-05 19:41:26 --> Output Class Initialized
INFO - 2024-10-05 19:41:26 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:26 --> Input Class Initialized
INFO - 2024-10-05 19:41:26 --> Language Class Initialized
INFO - 2024-10-05 19:41:26 --> Language Class Initialized
INFO - 2024-10-05 19:41:26 --> Config Class Initialized
INFO - 2024-10-05 19:41:26 --> Loader Class Initialized
INFO - 2024-10-05 19:41:26 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:26 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:26 --> Controller Class Initialized
DEBUG - 2024-10-05 19:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:41:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:41:26 --> Final output sent to browser
DEBUG - 2024-10-05 19:41:26 --> Total execution time: 0.0328
INFO - 2024-10-05 19:41:26 --> Config Class Initialized
INFO - 2024-10-05 19:41:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:26 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:26 --> URI Class Initialized
INFO - 2024-10-05 19:41:26 --> Router Class Initialized
INFO - 2024-10-05 19:41:26 --> Output Class Initialized
INFO - 2024-10-05 19:41:26 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:26 --> Input Class Initialized
INFO - 2024-10-05 19:41:26 --> Language Class Initialized
INFO - 2024-10-05 19:41:26 --> Language Class Initialized
INFO - 2024-10-05 19:41:26 --> Config Class Initialized
INFO - 2024-10-05 19:41:26 --> Loader Class Initialized
INFO - 2024-10-05 19:41:26 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:26 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:26 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:26 --> Controller Class Initialized
INFO - 2024-10-05 19:41:29 --> Config Class Initialized
INFO - 2024-10-05 19:41:29 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:29 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:29 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:29 --> URI Class Initialized
INFO - 2024-10-05 19:41:29 --> Router Class Initialized
INFO - 2024-10-05 19:41:29 --> Output Class Initialized
INFO - 2024-10-05 19:41:29 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:29 --> Input Class Initialized
INFO - 2024-10-05 19:41:29 --> Language Class Initialized
INFO - 2024-10-05 19:41:29 --> Language Class Initialized
INFO - 2024-10-05 19:41:29 --> Config Class Initialized
INFO - 2024-10-05 19:41:29 --> Loader Class Initialized
INFO - 2024-10-05 19:41:29 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:29 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:29 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:29 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:29 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:29 --> Controller Class Initialized
DEBUG - 2024-10-05 19:41:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:41:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:41:29 --> Final output sent to browser
DEBUG - 2024-10-05 19:41:29 --> Total execution time: 0.0336
INFO - 2024-10-05 19:41:47 --> Config Class Initialized
INFO - 2024-10-05 19:41:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:47 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:47 --> URI Class Initialized
INFO - 2024-10-05 19:41:47 --> Router Class Initialized
INFO - 2024-10-05 19:41:47 --> Output Class Initialized
INFO - 2024-10-05 19:41:47 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:47 --> Input Class Initialized
INFO - 2024-10-05 19:41:47 --> Language Class Initialized
INFO - 2024-10-05 19:41:47 --> Language Class Initialized
INFO - 2024-10-05 19:41:47 --> Config Class Initialized
INFO - 2024-10-05 19:41:47 --> Loader Class Initialized
INFO - 2024-10-05 19:41:47 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:47 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:47 --> Controller Class Initialized
INFO - 2024-10-05 19:41:47 --> Config Class Initialized
INFO - 2024-10-05 19:41:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:47 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:47 --> URI Class Initialized
INFO - 2024-10-05 19:41:47 --> Router Class Initialized
INFO - 2024-10-05 19:41:47 --> Output Class Initialized
INFO - 2024-10-05 19:41:47 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:47 --> Input Class Initialized
INFO - 2024-10-05 19:41:47 --> Language Class Initialized
INFO - 2024-10-05 19:41:47 --> Language Class Initialized
INFO - 2024-10-05 19:41:47 --> Config Class Initialized
INFO - 2024-10-05 19:41:47 --> Loader Class Initialized
INFO - 2024-10-05 19:41:47 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:47 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:47 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:47 --> Controller Class Initialized
DEBUG - 2024-10-05 19:41:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:41:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:41:47 --> Final output sent to browser
DEBUG - 2024-10-05 19:41:47 --> Total execution time: 0.0325
INFO - 2024-10-05 19:41:48 --> Config Class Initialized
INFO - 2024-10-05 19:41:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:48 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:48 --> URI Class Initialized
INFO - 2024-10-05 19:41:48 --> Router Class Initialized
INFO - 2024-10-05 19:41:48 --> Output Class Initialized
INFO - 2024-10-05 19:41:48 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:48 --> Input Class Initialized
INFO - 2024-10-05 19:41:48 --> Language Class Initialized
INFO - 2024-10-05 19:41:48 --> Language Class Initialized
INFO - 2024-10-05 19:41:48 --> Config Class Initialized
INFO - 2024-10-05 19:41:48 --> Loader Class Initialized
INFO - 2024-10-05 19:41:48 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:48 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:48 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:48 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:48 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:48 --> Controller Class Initialized
INFO - 2024-10-05 19:41:51 --> Config Class Initialized
INFO - 2024-10-05 19:41:51 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:51 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:51 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:51 --> URI Class Initialized
INFO - 2024-10-05 19:41:51 --> Router Class Initialized
INFO - 2024-10-05 19:41:51 --> Output Class Initialized
INFO - 2024-10-05 19:41:51 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:51 --> Input Class Initialized
INFO - 2024-10-05 19:41:51 --> Language Class Initialized
INFO - 2024-10-05 19:41:51 --> Language Class Initialized
INFO - 2024-10-05 19:41:51 --> Config Class Initialized
INFO - 2024-10-05 19:41:51 --> Loader Class Initialized
INFO - 2024-10-05 19:41:51 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:51 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:51 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:51 --> Helper loaded: my_helper
INFO - 2024-10-05 19:41:51 --> Database Driver Class Initialized
INFO - 2024-10-05 19:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:41:51 --> Controller Class Initialized
INFO - 2024-10-05 19:41:51 --> Final output sent to browser
DEBUG - 2024-10-05 19:41:51 --> Total execution time: 0.0299
INFO - 2024-10-05 19:41:59 --> Config Class Initialized
INFO - 2024-10-05 19:41:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:41:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:41:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:41:59 --> URI Class Initialized
INFO - 2024-10-05 19:41:59 --> Router Class Initialized
INFO - 2024-10-05 19:41:59 --> Output Class Initialized
INFO - 2024-10-05 19:41:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:41:59 --> Input Class Initialized
INFO - 2024-10-05 19:41:59 --> Language Class Initialized
INFO - 2024-10-05 19:41:59 --> Language Class Initialized
INFO - 2024-10-05 19:41:59 --> Config Class Initialized
INFO - 2024-10-05 19:41:59 --> Loader Class Initialized
INFO - 2024-10-05 19:41:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:41:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:41:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:41:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:00 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:00 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:42:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:00 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:00 --> Total execution time: 0.0304
INFO - 2024-10-05 19:42:01 --> Config Class Initialized
INFO - 2024-10-05 19:42:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:01 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:01 --> URI Class Initialized
INFO - 2024-10-05 19:42:01 --> Router Class Initialized
INFO - 2024-10-05 19:42:01 --> Output Class Initialized
INFO - 2024-10-05 19:42:01 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:01 --> Input Class Initialized
INFO - 2024-10-05 19:42:01 --> Language Class Initialized
INFO - 2024-10-05 19:42:01 --> Language Class Initialized
INFO - 2024-10-05 19:42:01 --> Config Class Initialized
INFO - 2024-10-05 19:42:01 --> Loader Class Initialized
INFO - 2024-10-05 19:42:01 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:01 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:01 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:01 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:01 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:01 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:42:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:01 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:01 --> Total execution time: 0.0746
INFO - 2024-10-05 19:42:04 --> Config Class Initialized
INFO - 2024-10-05 19:42:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:04 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:04 --> URI Class Initialized
INFO - 2024-10-05 19:42:04 --> Router Class Initialized
INFO - 2024-10-05 19:42:04 --> Output Class Initialized
INFO - 2024-10-05 19:42:04 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:04 --> Input Class Initialized
INFO - 2024-10-05 19:42:04 --> Language Class Initialized
INFO - 2024-10-05 19:42:04 --> Language Class Initialized
INFO - 2024-10-05 19:42:04 --> Config Class Initialized
INFO - 2024-10-05 19:42:04 --> Loader Class Initialized
INFO - 2024-10-05 19:42:04 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:04 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:04 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:04 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:04 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:04 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 19:42:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:04 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:04 --> Total execution time: 0.0333
INFO - 2024-10-05 19:42:17 --> Config Class Initialized
INFO - 2024-10-05 19:42:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:17 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:17 --> URI Class Initialized
INFO - 2024-10-05 19:42:17 --> Router Class Initialized
INFO - 2024-10-05 19:42:17 --> Output Class Initialized
INFO - 2024-10-05 19:42:17 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:17 --> Input Class Initialized
INFO - 2024-10-05 19:42:17 --> Language Class Initialized
INFO - 2024-10-05 19:42:17 --> Language Class Initialized
INFO - 2024-10-05 19:42:17 --> Config Class Initialized
INFO - 2024-10-05 19:42:17 --> Loader Class Initialized
INFO - 2024-10-05 19:42:17 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:17 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:17 --> Controller Class Initialized
INFO - 2024-10-05 19:42:17 --> Config Class Initialized
INFO - 2024-10-05 19:42:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:17 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:17 --> URI Class Initialized
INFO - 2024-10-05 19:42:17 --> Router Class Initialized
INFO - 2024-10-05 19:42:17 --> Output Class Initialized
INFO - 2024-10-05 19:42:17 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:17 --> Input Class Initialized
INFO - 2024-10-05 19:42:17 --> Language Class Initialized
INFO - 2024-10-05 19:42:17 --> Language Class Initialized
INFO - 2024-10-05 19:42:17 --> Config Class Initialized
INFO - 2024-10-05 19:42:17 --> Loader Class Initialized
INFO - 2024-10-05 19:42:17 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:17 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:17 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:17 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:42:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:17 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:17 --> Total execution time: 0.0377
INFO - 2024-10-05 19:42:20 --> Config Class Initialized
INFO - 2024-10-05 19:42:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:20 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:20 --> URI Class Initialized
INFO - 2024-10-05 19:42:20 --> Router Class Initialized
INFO - 2024-10-05 19:42:20 --> Output Class Initialized
INFO - 2024-10-05 19:42:20 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:20 --> Input Class Initialized
INFO - 2024-10-05 19:42:20 --> Language Class Initialized
INFO - 2024-10-05 19:42:20 --> Language Class Initialized
INFO - 2024-10-05 19:42:20 --> Config Class Initialized
INFO - 2024-10-05 19:42:20 --> Loader Class Initialized
INFO - 2024-10-05 19:42:20 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:20 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:20 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:20 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:20 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:20 --> Controller Class Initialized
INFO - 2024-10-05 19:42:20 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:20 --> Total execution time: 0.0334
INFO - 2024-10-05 19:42:25 --> Config Class Initialized
INFO - 2024-10-05 19:42:25 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:25 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:25 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:25 --> URI Class Initialized
INFO - 2024-10-05 19:42:25 --> Router Class Initialized
INFO - 2024-10-05 19:42:25 --> Output Class Initialized
INFO - 2024-10-05 19:42:25 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:25 --> Input Class Initialized
INFO - 2024-10-05 19:42:25 --> Language Class Initialized
INFO - 2024-10-05 19:42:25 --> Language Class Initialized
INFO - 2024-10-05 19:42:25 --> Config Class Initialized
INFO - 2024-10-05 19:42:25 --> Loader Class Initialized
INFO - 2024-10-05 19:42:25 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:25 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:25 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:25 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:25 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:25 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:42:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:25 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:25 --> Total execution time: 0.0300
INFO - 2024-10-05 19:42:28 --> Config Class Initialized
INFO - 2024-10-05 19:42:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:28 --> URI Class Initialized
INFO - 2024-10-05 19:42:28 --> Router Class Initialized
INFO - 2024-10-05 19:42:28 --> Output Class Initialized
INFO - 2024-10-05 19:42:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:28 --> Input Class Initialized
INFO - 2024-10-05 19:42:28 --> Language Class Initialized
INFO - 2024-10-05 19:42:28 --> Language Class Initialized
INFO - 2024-10-05 19:42:28 --> Config Class Initialized
INFO - 2024-10-05 19:42:28 --> Loader Class Initialized
INFO - 2024-10-05 19:42:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:28 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:28 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:28 --> Total execution time: 0.0309
INFO - 2024-10-05 19:42:30 --> Config Class Initialized
INFO - 2024-10-05 19:42:30 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:30 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:30 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:30 --> URI Class Initialized
INFO - 2024-10-05 19:42:30 --> Router Class Initialized
INFO - 2024-10-05 19:42:30 --> Output Class Initialized
INFO - 2024-10-05 19:42:30 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:30 --> Input Class Initialized
INFO - 2024-10-05 19:42:30 --> Language Class Initialized
INFO - 2024-10-05 19:42:30 --> Language Class Initialized
INFO - 2024-10-05 19:42:30 --> Config Class Initialized
INFO - 2024-10-05 19:42:30 --> Loader Class Initialized
INFO - 2024-10-05 19:42:30 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:30 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:30 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:30 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:31 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:31 --> Controller Class Initialized
INFO - 2024-10-05 19:42:33 --> Config Class Initialized
INFO - 2024-10-05 19:42:33 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:33 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:33 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:33 --> URI Class Initialized
INFO - 2024-10-05 19:42:33 --> Router Class Initialized
INFO - 2024-10-05 19:42:33 --> Output Class Initialized
INFO - 2024-10-05 19:42:33 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:33 --> Input Class Initialized
INFO - 2024-10-05 19:42:33 --> Language Class Initialized
INFO - 2024-10-05 19:42:33 --> Language Class Initialized
INFO - 2024-10-05 19:42:33 --> Config Class Initialized
INFO - 2024-10-05 19:42:33 --> Loader Class Initialized
INFO - 2024-10-05 19:42:33 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:33 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:33 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:33 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:33 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:33 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:42:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:33 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:33 --> Total execution time: 0.0413
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:41 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:41 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:41 --> URI Class Initialized
INFO - 2024-10-05 19:42:41 --> Router Class Initialized
INFO - 2024-10-05 19:42:41 --> Output Class Initialized
INFO - 2024-10-05 19:42:41 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:41 --> Input Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Loader Class Initialized
INFO - 2024-10-05 19:42:41 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:41 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:41 --> Controller Class Initialized
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:41 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:41 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:41 --> URI Class Initialized
INFO - 2024-10-05 19:42:41 --> Router Class Initialized
INFO - 2024-10-05 19:42:41 --> Output Class Initialized
INFO - 2024-10-05 19:42:41 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:41 --> Input Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Loader Class Initialized
INFO - 2024-10-05 19:42:41 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:41 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:41 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:42:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:41 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:41 --> Total execution time: 0.0394
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:41 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:41 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:41 --> URI Class Initialized
INFO - 2024-10-05 19:42:41 --> Router Class Initialized
INFO - 2024-10-05 19:42:41 --> Output Class Initialized
INFO - 2024-10-05 19:42:41 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:41 --> Input Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Language Class Initialized
INFO - 2024-10-05 19:42:41 --> Config Class Initialized
INFO - 2024-10-05 19:42:41 --> Loader Class Initialized
INFO - 2024-10-05 19:42:41 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:41 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:41 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:41 --> Controller Class Initialized
INFO - 2024-10-05 19:42:45 --> Config Class Initialized
INFO - 2024-10-05 19:42:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:45 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:45 --> URI Class Initialized
INFO - 2024-10-05 19:42:45 --> Router Class Initialized
INFO - 2024-10-05 19:42:45 --> Output Class Initialized
INFO - 2024-10-05 19:42:45 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:45 --> Input Class Initialized
INFO - 2024-10-05 19:42:45 --> Language Class Initialized
INFO - 2024-10-05 19:42:45 --> Language Class Initialized
INFO - 2024-10-05 19:42:45 --> Config Class Initialized
INFO - 2024-10-05 19:42:45 --> Loader Class Initialized
INFO - 2024-10-05 19:42:45 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:45 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:45 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:45 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:45 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:45 --> Controller Class Initialized
INFO - 2024-10-05 19:42:45 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:45 --> Total execution time: 0.0307
INFO - 2024-10-05 19:42:50 --> Config Class Initialized
INFO - 2024-10-05 19:42:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:50 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:50 --> URI Class Initialized
INFO - 2024-10-05 19:42:50 --> Router Class Initialized
INFO - 2024-10-05 19:42:50 --> Output Class Initialized
INFO - 2024-10-05 19:42:50 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:50 --> Input Class Initialized
INFO - 2024-10-05 19:42:50 --> Language Class Initialized
INFO - 2024-10-05 19:42:50 --> Language Class Initialized
INFO - 2024-10-05 19:42:50 --> Config Class Initialized
INFO - 2024-10-05 19:42:50 --> Loader Class Initialized
INFO - 2024-10-05 19:42:50 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:50 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:50 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:50 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:50 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:50 --> Controller Class Initialized
INFO - 2024-10-05 19:42:50 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:50 --> Total execution time: 0.1774
INFO - 2024-10-05 19:42:53 --> Config Class Initialized
INFO - 2024-10-05 19:42:53 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:53 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:53 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:53 --> URI Class Initialized
INFO - 2024-10-05 19:42:53 --> Router Class Initialized
INFO - 2024-10-05 19:42:53 --> Output Class Initialized
INFO - 2024-10-05 19:42:53 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:53 --> Input Class Initialized
INFO - 2024-10-05 19:42:53 --> Language Class Initialized
INFO - 2024-10-05 19:42:53 --> Language Class Initialized
INFO - 2024-10-05 19:42:53 --> Config Class Initialized
INFO - 2024-10-05 19:42:53 --> Loader Class Initialized
INFO - 2024-10-05 19:42:53 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:53 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:53 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:53 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:53 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:53 --> Controller Class Initialized
INFO - 2024-10-05 19:42:53 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:53 --> Total execution time: 0.1653
INFO - 2024-10-05 19:42:56 --> Config Class Initialized
INFO - 2024-10-05 19:42:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:56 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:56 --> URI Class Initialized
INFO - 2024-10-05 19:42:56 --> Router Class Initialized
INFO - 2024-10-05 19:42:56 --> Output Class Initialized
INFO - 2024-10-05 19:42:56 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:56 --> Input Class Initialized
INFO - 2024-10-05 19:42:56 --> Language Class Initialized
INFO - 2024-10-05 19:42:56 --> Language Class Initialized
INFO - 2024-10-05 19:42:56 --> Config Class Initialized
INFO - 2024-10-05 19:42:56 --> Loader Class Initialized
INFO - 2024-10-05 19:42:56 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:56 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:56 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:56 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:56 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:56 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:42:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:56 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:56 --> Total execution time: 0.0302
INFO - 2024-10-05 19:42:59 --> Config Class Initialized
INFO - 2024-10-05 19:42:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:42:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:42:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:42:59 --> URI Class Initialized
INFO - 2024-10-05 19:42:59 --> Router Class Initialized
INFO - 2024-10-05 19:42:59 --> Output Class Initialized
INFO - 2024-10-05 19:42:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:42:59 --> Input Class Initialized
INFO - 2024-10-05 19:42:59 --> Language Class Initialized
INFO - 2024-10-05 19:42:59 --> Language Class Initialized
INFO - 2024-10-05 19:42:59 --> Config Class Initialized
INFO - 2024-10-05 19:42:59 --> Loader Class Initialized
INFO - 2024-10-05 19:42:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:42:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:42:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:42:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:42:59 --> Database Driver Class Initialized
INFO - 2024-10-05 19:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:42:59 --> Controller Class Initialized
DEBUG - 2024-10-05 19:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:42:59 --> Final output sent to browser
DEBUG - 2024-10-05 19:42:59 --> Total execution time: 0.0317
INFO - 2024-10-05 19:43:01 --> Config Class Initialized
INFO - 2024-10-05 19:43:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:43:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:43:01 --> Utf8 Class Initialized
INFO - 2024-10-05 19:43:01 --> URI Class Initialized
INFO - 2024-10-05 19:43:01 --> Router Class Initialized
INFO - 2024-10-05 19:43:01 --> Output Class Initialized
INFO - 2024-10-05 19:43:01 --> Security Class Initialized
DEBUG - 2024-10-05 19:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:43:01 --> Input Class Initialized
INFO - 2024-10-05 19:43:01 --> Language Class Initialized
INFO - 2024-10-05 19:43:01 --> Language Class Initialized
INFO - 2024-10-05 19:43:01 --> Config Class Initialized
INFO - 2024-10-05 19:43:01 --> Loader Class Initialized
INFO - 2024-10-05 19:43:01 --> Helper loaded: url_helper
INFO - 2024-10-05 19:43:01 --> Helper loaded: file_helper
INFO - 2024-10-05 19:43:01 --> Helper loaded: form_helper
INFO - 2024-10-05 19:43:01 --> Helper loaded: my_helper
INFO - 2024-10-05 19:43:01 --> Database Driver Class Initialized
INFO - 2024-10-05 19:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:43:01 --> Controller Class Initialized
DEBUG - 2024-10-05 19:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 19:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:43:01 --> Final output sent to browser
DEBUG - 2024-10-05 19:43:01 --> Total execution time: 0.0412
INFO - 2024-10-05 19:43:08 --> Config Class Initialized
INFO - 2024-10-05 19:43:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:43:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:43:08 --> Utf8 Class Initialized
INFO - 2024-10-05 19:43:08 --> URI Class Initialized
INFO - 2024-10-05 19:43:08 --> Router Class Initialized
INFO - 2024-10-05 19:43:09 --> Output Class Initialized
INFO - 2024-10-05 19:43:09 --> Security Class Initialized
DEBUG - 2024-10-05 19:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:43:09 --> Input Class Initialized
INFO - 2024-10-05 19:43:09 --> Language Class Initialized
INFO - 2024-10-05 19:43:09 --> Language Class Initialized
INFO - 2024-10-05 19:43:09 --> Config Class Initialized
INFO - 2024-10-05 19:43:09 --> Loader Class Initialized
INFO - 2024-10-05 19:43:09 --> Helper loaded: url_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: file_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: form_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: my_helper
INFO - 2024-10-05 19:43:09 --> Database Driver Class Initialized
INFO - 2024-10-05 19:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:43:09 --> Controller Class Initialized
INFO - 2024-10-05 19:43:09 --> Config Class Initialized
INFO - 2024-10-05 19:43:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:43:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:43:09 --> Utf8 Class Initialized
INFO - 2024-10-05 19:43:09 --> URI Class Initialized
INFO - 2024-10-05 19:43:09 --> Router Class Initialized
INFO - 2024-10-05 19:43:09 --> Output Class Initialized
INFO - 2024-10-05 19:43:09 --> Security Class Initialized
DEBUG - 2024-10-05 19:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:43:09 --> Input Class Initialized
INFO - 2024-10-05 19:43:09 --> Language Class Initialized
INFO - 2024-10-05 19:43:09 --> Language Class Initialized
INFO - 2024-10-05 19:43:09 --> Config Class Initialized
INFO - 2024-10-05 19:43:09 --> Loader Class Initialized
INFO - 2024-10-05 19:43:09 --> Helper loaded: url_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: file_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: form_helper
INFO - 2024-10-05 19:43:09 --> Helper loaded: my_helper
INFO - 2024-10-05 19:43:09 --> Database Driver Class Initialized
INFO - 2024-10-05 19:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:43:09 --> Controller Class Initialized
DEBUG - 2024-10-05 19:43:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:43:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:43:09 --> Final output sent to browser
DEBUG - 2024-10-05 19:43:09 --> Total execution time: 0.0314
INFO - 2024-10-05 19:43:11 --> Config Class Initialized
INFO - 2024-10-05 19:43:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:43:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:43:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:43:11 --> URI Class Initialized
INFO - 2024-10-05 19:43:11 --> Router Class Initialized
INFO - 2024-10-05 19:43:11 --> Output Class Initialized
INFO - 2024-10-05 19:43:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:43:11 --> Input Class Initialized
INFO - 2024-10-05 19:43:11 --> Language Class Initialized
INFO - 2024-10-05 19:43:11 --> Language Class Initialized
INFO - 2024-10-05 19:43:11 --> Config Class Initialized
INFO - 2024-10-05 19:43:11 --> Loader Class Initialized
INFO - 2024-10-05 19:43:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:43:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:43:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:43:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:43:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:43:11 --> Controller Class Initialized
INFO - 2024-10-05 19:43:11 --> Final output sent to browser
DEBUG - 2024-10-05 19:43:11 --> Total execution time: 0.0314
INFO - 2024-10-05 19:43:57 --> Config Class Initialized
INFO - 2024-10-05 19:43:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:43:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:43:57 --> Utf8 Class Initialized
INFO - 2024-10-05 19:43:57 --> URI Class Initialized
INFO - 2024-10-05 19:43:57 --> Router Class Initialized
INFO - 2024-10-05 19:43:57 --> Output Class Initialized
INFO - 2024-10-05 19:43:57 --> Security Class Initialized
DEBUG - 2024-10-05 19:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:43:57 --> Input Class Initialized
INFO - 2024-10-05 19:43:57 --> Language Class Initialized
INFO - 2024-10-05 19:43:57 --> Language Class Initialized
INFO - 2024-10-05 19:43:57 --> Config Class Initialized
INFO - 2024-10-05 19:43:57 --> Loader Class Initialized
INFO - 2024-10-05 19:43:57 --> Helper loaded: url_helper
INFO - 2024-10-05 19:43:57 --> Helper loaded: file_helper
INFO - 2024-10-05 19:43:57 --> Helper loaded: form_helper
INFO - 2024-10-05 19:43:57 --> Helper loaded: my_helper
INFO - 2024-10-05 19:43:57 --> Database Driver Class Initialized
INFO - 2024-10-05 19:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:43:57 --> Controller Class Initialized
INFO - 2024-10-05 19:43:57 --> Final output sent to browser
DEBUG - 2024-10-05 19:43:57 --> Total execution time: 0.0779
INFO - 2024-10-05 19:44:00 --> Config Class Initialized
INFO - 2024-10-05 19:44:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:00 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:00 --> URI Class Initialized
INFO - 2024-10-05 19:44:00 --> Router Class Initialized
INFO - 2024-10-05 19:44:00 --> Output Class Initialized
INFO - 2024-10-05 19:44:00 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:00 --> Input Class Initialized
INFO - 2024-10-05 19:44:00 --> Language Class Initialized
INFO - 2024-10-05 19:44:00 --> Language Class Initialized
INFO - 2024-10-05 19:44:00 --> Config Class Initialized
INFO - 2024-10-05 19:44:00 --> Loader Class Initialized
INFO - 2024-10-05 19:44:00 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:00 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:00 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:00 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:00 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:00 --> Controller Class Initialized
DEBUG - 2024-10-05 19:44:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:44:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:44:00 --> Final output sent to browser
DEBUG - 2024-10-05 19:44:00 --> Total execution time: 0.0354
INFO - 2024-10-05 19:44:01 --> Config Class Initialized
INFO - 2024-10-05 19:44:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:01 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:01 --> URI Class Initialized
INFO - 2024-10-05 19:44:01 --> Router Class Initialized
INFO - 2024-10-05 19:44:01 --> Output Class Initialized
INFO - 2024-10-05 19:44:01 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:01 --> Input Class Initialized
INFO - 2024-10-05 19:44:01 --> Language Class Initialized
INFO - 2024-10-05 19:44:01 --> Language Class Initialized
INFO - 2024-10-05 19:44:01 --> Config Class Initialized
INFO - 2024-10-05 19:44:01 --> Loader Class Initialized
INFO - 2024-10-05 19:44:01 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:01 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:01 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:01 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:01 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:01 --> Controller Class Initialized
INFO - 2024-10-05 19:44:01 --> Final output sent to browser
DEBUG - 2024-10-05 19:44:01 --> Total execution time: 0.4655
INFO - 2024-10-05 19:44:03 --> Config Class Initialized
INFO - 2024-10-05 19:44:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:03 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:03 --> URI Class Initialized
INFO - 2024-10-05 19:44:03 --> Router Class Initialized
INFO - 2024-10-05 19:44:03 --> Output Class Initialized
INFO - 2024-10-05 19:44:03 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:03 --> Input Class Initialized
INFO - 2024-10-05 19:44:03 --> Language Class Initialized
INFO - 2024-10-05 19:44:03 --> Language Class Initialized
INFO - 2024-10-05 19:44:03 --> Config Class Initialized
INFO - 2024-10-05 19:44:03 --> Loader Class Initialized
INFO - 2024-10-05 19:44:03 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:03 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:03 --> Controller Class Initialized
DEBUG - 2024-10-05 19:44:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:44:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:44:03 --> Final output sent to browser
DEBUG - 2024-10-05 19:44:03 --> Total execution time: 0.0382
INFO - 2024-10-05 19:44:03 --> Config Class Initialized
INFO - 2024-10-05 19:44:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:03 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:03 --> URI Class Initialized
INFO - 2024-10-05 19:44:03 --> Router Class Initialized
INFO - 2024-10-05 19:44:03 --> Output Class Initialized
INFO - 2024-10-05 19:44:03 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:03 --> Input Class Initialized
INFO - 2024-10-05 19:44:03 --> Language Class Initialized
INFO - 2024-10-05 19:44:03 --> Language Class Initialized
INFO - 2024-10-05 19:44:03 --> Config Class Initialized
INFO - 2024-10-05 19:44:03 --> Loader Class Initialized
INFO - 2024-10-05 19:44:03 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:03 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:03 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:03 --> Controller Class Initialized
INFO - 2024-10-05 19:44:10 --> Config Class Initialized
INFO - 2024-10-05 19:44:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:10 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:10 --> URI Class Initialized
INFO - 2024-10-05 19:44:10 --> Router Class Initialized
INFO - 2024-10-05 19:44:10 --> Output Class Initialized
INFO - 2024-10-05 19:44:10 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:10 --> Input Class Initialized
INFO - 2024-10-05 19:44:10 --> Language Class Initialized
INFO - 2024-10-05 19:44:10 --> Language Class Initialized
INFO - 2024-10-05 19:44:10 --> Config Class Initialized
INFO - 2024-10-05 19:44:10 --> Loader Class Initialized
INFO - 2024-10-05 19:44:10 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:10 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:10 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:10 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:10 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:10 --> Controller Class Initialized
DEBUG - 2024-10-05 19:44:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:44:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:44:10 --> Final output sent to browser
DEBUG - 2024-10-05 19:44:10 --> Total execution time: 0.0318
INFO - 2024-10-05 19:44:12 --> Config Class Initialized
INFO - 2024-10-05 19:44:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:44:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:44:12 --> Utf8 Class Initialized
INFO - 2024-10-05 19:44:12 --> URI Class Initialized
INFO - 2024-10-05 19:44:12 --> Router Class Initialized
INFO - 2024-10-05 19:44:12 --> Output Class Initialized
INFO - 2024-10-05 19:44:12 --> Security Class Initialized
DEBUG - 2024-10-05 19:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:44:12 --> Input Class Initialized
INFO - 2024-10-05 19:44:12 --> Language Class Initialized
INFO - 2024-10-05 19:44:12 --> Language Class Initialized
INFO - 2024-10-05 19:44:12 --> Config Class Initialized
INFO - 2024-10-05 19:44:12 --> Loader Class Initialized
INFO - 2024-10-05 19:44:12 --> Helper loaded: url_helper
INFO - 2024-10-05 19:44:12 --> Helper loaded: file_helper
INFO - 2024-10-05 19:44:12 --> Helper loaded: form_helper
INFO - 2024-10-05 19:44:12 --> Helper loaded: my_helper
INFO - 2024-10-05 19:44:12 --> Database Driver Class Initialized
INFO - 2024-10-05 19:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:44:12 --> Controller Class Initialized
DEBUG - 2024-10-05 19:44:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:44:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:44:12 --> Final output sent to browser
DEBUG - 2024-10-05 19:44:12 --> Total execution time: 0.0309
INFO - 2024-10-05 19:45:10 --> Config Class Initialized
INFO - 2024-10-05 19:45:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:10 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:10 --> URI Class Initialized
INFO - 2024-10-05 19:45:10 --> Router Class Initialized
INFO - 2024-10-05 19:45:10 --> Output Class Initialized
INFO - 2024-10-05 19:45:10 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:10 --> Input Class Initialized
INFO - 2024-10-05 19:45:10 --> Language Class Initialized
INFO - 2024-10-05 19:45:10 --> Language Class Initialized
INFO - 2024-10-05 19:45:10 --> Config Class Initialized
INFO - 2024-10-05 19:45:10 --> Loader Class Initialized
INFO - 2024-10-05 19:45:10 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:10 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:10 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:10 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:10 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:10 --> Controller Class Initialized
INFO - 2024-10-05 19:45:10 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:10 --> Total execution time: 0.0414
INFO - 2024-10-05 19:45:28 --> Config Class Initialized
INFO - 2024-10-05 19:45:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:28 --> URI Class Initialized
INFO - 2024-10-05 19:45:28 --> Router Class Initialized
INFO - 2024-10-05 19:45:28 --> Output Class Initialized
INFO - 2024-10-05 19:45:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:28 --> Input Class Initialized
INFO - 2024-10-05 19:45:28 --> Language Class Initialized
INFO - 2024-10-05 19:45:28 --> Language Class Initialized
INFO - 2024-10-05 19:45:28 --> Config Class Initialized
INFO - 2024-10-05 19:45:28 --> Loader Class Initialized
INFO - 2024-10-05 19:45:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:28 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:28 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:28 --> Total execution time: 0.0426
INFO - 2024-10-05 19:45:43 --> Config Class Initialized
INFO - 2024-10-05 19:45:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:43 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:43 --> URI Class Initialized
INFO - 2024-10-05 19:45:44 --> Router Class Initialized
INFO - 2024-10-05 19:45:44 --> Output Class Initialized
INFO - 2024-10-05 19:45:44 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:44 --> Input Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Config Class Initialized
INFO - 2024-10-05 19:45:44 --> Loader Class Initialized
INFO - 2024-10-05 19:45:44 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:44 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:44 --> Controller Class Initialized
INFO - 2024-10-05 19:45:44 --> Config Class Initialized
INFO - 2024-10-05 19:45:44 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:44 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:44 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:44 --> URI Class Initialized
INFO - 2024-10-05 19:45:44 --> Router Class Initialized
INFO - 2024-10-05 19:45:44 --> Output Class Initialized
INFO - 2024-10-05 19:45:44 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:44 --> Input Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Config Class Initialized
INFO - 2024-10-05 19:45:44 --> Loader Class Initialized
INFO - 2024-10-05 19:45:44 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:44 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:44 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:44 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:44 --> Total execution time: 0.0349
INFO - 2024-10-05 19:45:44 --> Config Class Initialized
INFO - 2024-10-05 19:45:44 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:44 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:44 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:44 --> URI Class Initialized
INFO - 2024-10-05 19:45:44 --> Router Class Initialized
INFO - 2024-10-05 19:45:44 --> Output Class Initialized
INFO - 2024-10-05 19:45:44 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:44 --> Input Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Language Class Initialized
INFO - 2024-10-05 19:45:44 --> Config Class Initialized
INFO - 2024-10-05 19:45:44 --> Loader Class Initialized
INFO - 2024-10-05 19:45:44 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:44 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:44 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:44 --> Controller Class Initialized
INFO - 2024-10-05 19:45:46 --> Config Class Initialized
INFO - 2024-10-05 19:45:46 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:46 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:46 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:46 --> URI Class Initialized
INFO - 2024-10-05 19:45:46 --> Router Class Initialized
INFO - 2024-10-05 19:45:46 --> Output Class Initialized
INFO - 2024-10-05 19:45:46 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:46 --> Input Class Initialized
INFO - 2024-10-05 19:45:46 --> Language Class Initialized
INFO - 2024-10-05 19:45:46 --> Language Class Initialized
INFO - 2024-10-05 19:45:46 --> Config Class Initialized
INFO - 2024-10-05 19:45:46 --> Loader Class Initialized
INFO - 2024-10-05 19:45:46 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:46 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:46 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:46 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:46 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:46 --> Controller Class Initialized
INFO - 2024-10-05 19:45:46 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:46 --> Total execution time: 0.0352
INFO - 2024-10-05 19:45:50 --> Config Class Initialized
INFO - 2024-10-05 19:45:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:50 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:50 --> URI Class Initialized
INFO - 2024-10-05 19:45:50 --> Router Class Initialized
INFO - 2024-10-05 19:45:50 --> Output Class Initialized
INFO - 2024-10-05 19:45:50 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:50 --> Input Class Initialized
INFO - 2024-10-05 19:45:50 --> Language Class Initialized
INFO - 2024-10-05 19:45:51 --> Language Class Initialized
INFO - 2024-10-05 19:45:51 --> Config Class Initialized
INFO - 2024-10-05 19:45:51 --> Loader Class Initialized
INFO - 2024-10-05 19:45:51 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:51 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:51 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:51 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:51 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:51 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:45:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:51 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:51 --> Total execution time: 0.0287
INFO - 2024-10-05 19:45:54 --> Config Class Initialized
INFO - 2024-10-05 19:45:54 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:54 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:54 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:54 --> URI Class Initialized
INFO - 2024-10-05 19:45:54 --> Router Class Initialized
INFO - 2024-10-05 19:45:54 --> Output Class Initialized
INFO - 2024-10-05 19:45:54 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:54 --> Input Class Initialized
INFO - 2024-10-05 19:45:54 --> Language Class Initialized
INFO - 2024-10-05 19:45:54 --> Language Class Initialized
INFO - 2024-10-05 19:45:54 --> Config Class Initialized
INFO - 2024-10-05 19:45:54 --> Loader Class Initialized
INFO - 2024-10-05 19:45:54 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:54 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:54 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:54 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:54 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:54 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:54 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:54 --> Total execution time: 0.0295
INFO - 2024-10-05 19:45:56 --> Config Class Initialized
INFO - 2024-10-05 19:45:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:56 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:56 --> URI Class Initialized
INFO - 2024-10-05 19:45:56 --> Router Class Initialized
INFO - 2024-10-05 19:45:56 --> Output Class Initialized
INFO - 2024-10-05 19:45:56 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:56 --> Input Class Initialized
INFO - 2024-10-05 19:45:56 --> Language Class Initialized
INFO - 2024-10-05 19:45:56 --> Language Class Initialized
INFO - 2024-10-05 19:45:56 --> Config Class Initialized
INFO - 2024-10-05 19:45:56 --> Loader Class Initialized
INFO - 2024-10-05 19:45:56 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:56 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:56 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:56 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:56 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:56 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:56 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:56 --> Total execution time: 0.0340
INFO - 2024-10-05 19:45:59 --> Config Class Initialized
INFO - 2024-10-05 19:45:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:59 --> URI Class Initialized
INFO - 2024-10-05 19:45:59 --> Router Class Initialized
INFO - 2024-10-05 19:45:59 --> Output Class Initialized
INFO - 2024-10-05 19:45:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:59 --> Input Class Initialized
INFO - 2024-10-05 19:45:59 --> Language Class Initialized
INFO - 2024-10-05 19:45:59 --> Language Class Initialized
INFO - 2024-10-05 19:45:59 --> Config Class Initialized
INFO - 2024-10-05 19:45:59 --> Loader Class Initialized
INFO - 2024-10-05 19:45:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:59 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:59 --> Controller Class Initialized
DEBUG - 2024-10-05 19:45:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:45:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:45:59 --> Final output sent to browser
DEBUG - 2024-10-05 19:45:59 --> Total execution time: 0.0610
INFO - 2024-10-05 19:45:59 --> Config Class Initialized
INFO - 2024-10-05 19:45:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:45:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:45:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:45:59 --> URI Class Initialized
INFO - 2024-10-05 19:45:59 --> Router Class Initialized
INFO - 2024-10-05 19:45:59 --> Output Class Initialized
INFO - 2024-10-05 19:45:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:45:59 --> Input Class Initialized
INFO - 2024-10-05 19:45:59 --> Language Class Initialized
INFO - 2024-10-05 19:45:59 --> Language Class Initialized
INFO - 2024-10-05 19:45:59 --> Config Class Initialized
INFO - 2024-10-05 19:45:59 --> Loader Class Initialized
INFO - 2024-10-05 19:45:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:45:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:45:59 --> Database Driver Class Initialized
INFO - 2024-10-05 19:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:45:59 --> Controller Class Initialized
INFO - 2024-10-05 19:46:01 --> Config Class Initialized
INFO - 2024-10-05 19:46:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:01 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:01 --> URI Class Initialized
INFO - 2024-10-05 19:46:01 --> Router Class Initialized
INFO - 2024-10-05 19:46:01 --> Output Class Initialized
INFO - 2024-10-05 19:46:01 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:01 --> Input Class Initialized
INFO - 2024-10-05 19:46:01 --> Language Class Initialized
INFO - 2024-10-05 19:46:01 --> Language Class Initialized
INFO - 2024-10-05 19:46:01 --> Config Class Initialized
INFO - 2024-10-05 19:46:01 --> Loader Class Initialized
INFO - 2024-10-05 19:46:01 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:01 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:01 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:01 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:01 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:01 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:46:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:01 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:01 --> Total execution time: 0.0445
INFO - 2024-10-05 19:46:08 --> Config Class Initialized
INFO - 2024-10-05 19:46:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:08 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:08 --> URI Class Initialized
INFO - 2024-10-05 19:46:08 --> Router Class Initialized
INFO - 2024-10-05 19:46:08 --> Output Class Initialized
INFO - 2024-10-05 19:46:08 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:08 --> Input Class Initialized
INFO - 2024-10-05 19:46:08 --> Language Class Initialized
INFO - 2024-10-05 19:46:08 --> Language Class Initialized
INFO - 2024-10-05 19:46:08 --> Config Class Initialized
INFO - 2024-10-05 19:46:08 --> Loader Class Initialized
INFO - 2024-10-05 19:46:08 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:08 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:08 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:08 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:08 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:08 --> Controller Class Initialized
INFO - 2024-10-05 19:46:11 --> Config Class Initialized
INFO - 2024-10-05 19:46:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:11 --> URI Class Initialized
INFO - 2024-10-05 19:46:11 --> Router Class Initialized
INFO - 2024-10-05 19:46:11 --> Output Class Initialized
INFO - 2024-10-05 19:46:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:11 --> Input Class Initialized
INFO - 2024-10-05 19:46:11 --> Language Class Initialized
INFO - 2024-10-05 19:46:11 --> Language Class Initialized
INFO - 2024-10-05 19:46:11 --> Config Class Initialized
INFO - 2024-10-05 19:46:11 --> Loader Class Initialized
INFO - 2024-10-05 19:46:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:11 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:11 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:11 --> Total execution time: 0.0288
INFO - 2024-10-05 19:46:23 --> Config Class Initialized
INFO - 2024-10-05 19:46:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:23 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:23 --> URI Class Initialized
INFO - 2024-10-05 19:46:23 --> Router Class Initialized
INFO - 2024-10-05 19:46:23 --> Output Class Initialized
INFO - 2024-10-05 19:46:23 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:23 --> Input Class Initialized
INFO - 2024-10-05 19:46:23 --> Language Class Initialized
INFO - 2024-10-05 19:46:23 --> Language Class Initialized
INFO - 2024-10-05 19:46:23 --> Config Class Initialized
INFO - 2024-10-05 19:46:23 --> Loader Class Initialized
INFO - 2024-10-05 19:46:23 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:23 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:23 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:23 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:23 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:23 --> Controller Class Initialized
INFO - 2024-10-05 19:46:25 --> Config Class Initialized
INFO - 2024-10-05 19:46:25 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:25 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:25 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:25 --> URI Class Initialized
INFO - 2024-10-05 19:46:25 --> Router Class Initialized
INFO - 2024-10-05 19:46:25 --> Output Class Initialized
INFO - 2024-10-05 19:46:25 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:25 --> Input Class Initialized
INFO - 2024-10-05 19:46:25 --> Language Class Initialized
INFO - 2024-10-05 19:46:25 --> Language Class Initialized
INFO - 2024-10-05 19:46:25 --> Config Class Initialized
INFO - 2024-10-05 19:46:25 --> Loader Class Initialized
INFO - 2024-10-05 19:46:25 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:25 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:25 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:25 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:25 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:25 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:46:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:25 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:25 --> Total execution time: 0.0294
INFO - 2024-10-05 19:46:28 --> Config Class Initialized
INFO - 2024-10-05 19:46:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:28 --> URI Class Initialized
INFO - 2024-10-05 19:46:28 --> Router Class Initialized
INFO - 2024-10-05 19:46:28 --> Output Class Initialized
INFO - 2024-10-05 19:46:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:28 --> Input Class Initialized
INFO - 2024-10-05 19:46:28 --> Language Class Initialized
INFO - 2024-10-05 19:46:28 --> Language Class Initialized
INFO - 2024-10-05 19:46:28 --> Config Class Initialized
INFO - 2024-10-05 19:46:28 --> Loader Class Initialized
INFO - 2024-10-05 19:46:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:28 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:46:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:28 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:28 --> Total execution time: 0.0307
INFO - 2024-10-05 19:46:28 --> Config Class Initialized
INFO - 2024-10-05 19:46:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:28 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:28 --> URI Class Initialized
INFO - 2024-10-05 19:46:28 --> Router Class Initialized
INFO - 2024-10-05 19:46:28 --> Output Class Initialized
INFO - 2024-10-05 19:46:28 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:28 --> Input Class Initialized
INFO - 2024-10-05 19:46:28 --> Language Class Initialized
INFO - 2024-10-05 19:46:28 --> Language Class Initialized
INFO - 2024-10-05 19:46:28 --> Config Class Initialized
INFO - 2024-10-05 19:46:28 --> Loader Class Initialized
INFO - 2024-10-05 19:46:28 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:28 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:28 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:28 --> Controller Class Initialized
INFO - 2024-10-05 19:46:31 --> Config Class Initialized
INFO - 2024-10-05 19:46:31 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:31 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:31 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:31 --> URI Class Initialized
INFO - 2024-10-05 19:46:31 --> Router Class Initialized
INFO - 2024-10-05 19:46:31 --> Output Class Initialized
INFO - 2024-10-05 19:46:31 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:31 --> Input Class Initialized
INFO - 2024-10-05 19:46:31 --> Language Class Initialized
INFO - 2024-10-05 19:46:31 --> Language Class Initialized
INFO - 2024-10-05 19:46:31 --> Config Class Initialized
INFO - 2024-10-05 19:46:31 --> Loader Class Initialized
INFO - 2024-10-05 19:46:31 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:31 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:31 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:31 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:31 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:31 --> Controller Class Initialized
INFO - 2024-10-05 19:46:36 --> Config Class Initialized
INFO - 2024-10-05 19:46:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:36 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:36 --> URI Class Initialized
INFO - 2024-10-05 19:46:36 --> Router Class Initialized
INFO - 2024-10-05 19:46:36 --> Output Class Initialized
INFO - 2024-10-05 19:46:36 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:36 --> Input Class Initialized
INFO - 2024-10-05 19:46:36 --> Language Class Initialized
INFO - 2024-10-05 19:46:36 --> Language Class Initialized
INFO - 2024-10-05 19:46:36 --> Config Class Initialized
INFO - 2024-10-05 19:46:36 --> Loader Class Initialized
INFO - 2024-10-05 19:46:36 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:36 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:36 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:36 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:36 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:36 --> Controller Class Initialized
INFO - 2024-10-05 19:46:36 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:36 --> Total execution time: 0.0305
INFO - 2024-10-05 19:46:43 --> Config Class Initialized
INFO - 2024-10-05 19:46:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:43 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:43 --> URI Class Initialized
INFO - 2024-10-05 19:46:43 --> Router Class Initialized
INFO - 2024-10-05 19:46:43 --> Output Class Initialized
INFO - 2024-10-05 19:46:43 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:43 --> Input Class Initialized
INFO - 2024-10-05 19:46:43 --> Language Class Initialized
INFO - 2024-10-05 19:46:43 --> Language Class Initialized
INFO - 2024-10-05 19:46:43 --> Config Class Initialized
INFO - 2024-10-05 19:46:43 --> Loader Class Initialized
INFO - 2024-10-05 19:46:43 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:43 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:43 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:43 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:43 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:43 --> Controller Class Initialized
INFO - 2024-10-05 19:46:43 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:43 --> Total execution time: 0.0295
INFO - 2024-10-05 19:46:50 --> Config Class Initialized
INFO - 2024-10-05 19:46:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:50 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:50 --> URI Class Initialized
INFO - 2024-10-05 19:46:50 --> Router Class Initialized
INFO - 2024-10-05 19:46:50 --> Output Class Initialized
INFO - 2024-10-05 19:46:50 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:50 --> Input Class Initialized
INFO - 2024-10-05 19:46:50 --> Language Class Initialized
INFO - 2024-10-05 19:46:50 --> Language Class Initialized
INFO - 2024-10-05 19:46:50 --> Config Class Initialized
INFO - 2024-10-05 19:46:50 --> Loader Class Initialized
INFO - 2024-10-05 19:46:50 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:50 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:50 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:50 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:50 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:50 --> Controller Class Initialized
INFO - 2024-10-05 19:46:50 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:50 --> Total execution time: 0.1793
INFO - 2024-10-05 19:46:52 --> Config Class Initialized
INFO - 2024-10-05 19:46:52 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:52 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:52 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:52 --> URI Class Initialized
INFO - 2024-10-05 19:46:52 --> Router Class Initialized
INFO - 2024-10-05 19:46:52 --> Output Class Initialized
INFO - 2024-10-05 19:46:52 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:52 --> Input Class Initialized
INFO - 2024-10-05 19:46:52 --> Language Class Initialized
INFO - 2024-10-05 19:46:52 --> Language Class Initialized
INFO - 2024-10-05 19:46:52 --> Config Class Initialized
INFO - 2024-10-05 19:46:52 --> Loader Class Initialized
INFO - 2024-10-05 19:46:52 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:52 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:52 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:52 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:52 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:52 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:46:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:52 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:52 --> Total execution time: 0.0254
INFO - 2024-10-05 19:46:54 --> Config Class Initialized
INFO - 2024-10-05 19:46:54 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:54 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:54 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:54 --> URI Class Initialized
INFO - 2024-10-05 19:46:54 --> Router Class Initialized
INFO - 2024-10-05 19:46:54 --> Output Class Initialized
INFO - 2024-10-05 19:46:54 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:54 --> Input Class Initialized
INFO - 2024-10-05 19:46:54 --> Language Class Initialized
INFO - 2024-10-05 19:46:54 --> Language Class Initialized
INFO - 2024-10-05 19:46:54 --> Config Class Initialized
INFO - 2024-10-05 19:46:54 --> Loader Class Initialized
INFO - 2024-10-05 19:46:54 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:54 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:54 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:54 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:54 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:54 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:46:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:54 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:54 --> Total execution time: 0.0315
INFO - 2024-10-05 19:46:56 --> Config Class Initialized
INFO - 2024-10-05 19:46:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:56 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:56 --> URI Class Initialized
INFO - 2024-10-05 19:46:56 --> Router Class Initialized
INFO - 2024-10-05 19:46:56 --> Output Class Initialized
INFO - 2024-10-05 19:46:56 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:56 --> Input Class Initialized
INFO - 2024-10-05 19:46:56 --> Language Class Initialized
INFO - 2024-10-05 19:46:56 --> Language Class Initialized
INFO - 2024-10-05 19:46:56 --> Config Class Initialized
INFO - 2024-10-05 19:46:56 --> Loader Class Initialized
INFO - 2024-10-05 19:46:56 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:56 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:56 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:56 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:56 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:56 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:56 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:56 --> Total execution time: 0.0310
INFO - 2024-10-05 19:46:59 --> Config Class Initialized
INFO - 2024-10-05 19:46:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:59 --> URI Class Initialized
INFO - 2024-10-05 19:46:59 --> Router Class Initialized
INFO - 2024-10-05 19:46:59 --> Output Class Initialized
INFO - 2024-10-05 19:46:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:59 --> Input Class Initialized
INFO - 2024-10-05 19:46:59 --> Language Class Initialized
INFO - 2024-10-05 19:46:59 --> Language Class Initialized
INFO - 2024-10-05 19:46:59 --> Config Class Initialized
INFO - 2024-10-05 19:46:59 --> Loader Class Initialized
INFO - 2024-10-05 19:46:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:59 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:59 --> Controller Class Initialized
DEBUG - 2024-10-05 19:46:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:46:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:46:59 --> Final output sent to browser
DEBUG - 2024-10-05 19:46:59 --> Total execution time: 0.0304
INFO - 2024-10-05 19:46:59 --> Config Class Initialized
INFO - 2024-10-05 19:46:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:46:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:46:59 --> Utf8 Class Initialized
INFO - 2024-10-05 19:46:59 --> URI Class Initialized
INFO - 2024-10-05 19:46:59 --> Router Class Initialized
INFO - 2024-10-05 19:46:59 --> Output Class Initialized
INFO - 2024-10-05 19:46:59 --> Security Class Initialized
DEBUG - 2024-10-05 19:46:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:46:59 --> Input Class Initialized
INFO - 2024-10-05 19:46:59 --> Language Class Initialized
INFO - 2024-10-05 19:46:59 --> Language Class Initialized
INFO - 2024-10-05 19:46:59 --> Config Class Initialized
INFO - 2024-10-05 19:46:59 --> Loader Class Initialized
INFO - 2024-10-05 19:46:59 --> Helper loaded: url_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: file_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: form_helper
INFO - 2024-10-05 19:46:59 --> Helper loaded: my_helper
INFO - 2024-10-05 19:46:59 --> Database Driver Class Initialized
INFO - 2024-10-05 19:46:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:46:59 --> Controller Class Initialized
INFO - 2024-10-05 19:47:01 --> Config Class Initialized
INFO - 2024-10-05 19:47:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:01 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:01 --> URI Class Initialized
INFO - 2024-10-05 19:47:01 --> Router Class Initialized
INFO - 2024-10-05 19:47:01 --> Output Class Initialized
INFO - 2024-10-05 19:47:01 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:01 --> Input Class Initialized
INFO - 2024-10-05 19:47:01 --> Language Class Initialized
INFO - 2024-10-05 19:47:01 --> Language Class Initialized
INFO - 2024-10-05 19:47:01 --> Config Class Initialized
INFO - 2024-10-05 19:47:01 --> Loader Class Initialized
INFO - 2024-10-05 19:47:01 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:01 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:01 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:01 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:01 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:01 --> Controller Class Initialized
INFO - 2024-10-05 19:47:01 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:01 --> Total execution time: 0.0360
INFO - 2024-10-05 19:47:03 --> Config Class Initialized
INFO - 2024-10-05 19:47:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:03 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:03 --> URI Class Initialized
INFO - 2024-10-05 19:47:03 --> Router Class Initialized
INFO - 2024-10-05 19:47:03 --> Output Class Initialized
INFO - 2024-10-05 19:47:03 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:03 --> Input Class Initialized
INFO - 2024-10-05 19:47:03 --> Language Class Initialized
INFO - 2024-10-05 19:47:03 --> Language Class Initialized
INFO - 2024-10-05 19:47:03 --> Config Class Initialized
INFO - 2024-10-05 19:47:03 --> Loader Class Initialized
INFO - 2024-10-05 19:47:03 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:03 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:03 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:03 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:03 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:03 --> Controller Class Initialized
DEBUG - 2024-10-05 19:47:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 19:47:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:47:03 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:03 --> Total execution time: 0.0313
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:08 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:08 --> URI Class Initialized
INFO - 2024-10-05 19:47:08 --> Router Class Initialized
INFO - 2024-10-05 19:47:08 --> Output Class Initialized
INFO - 2024-10-05 19:47:08 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:08 --> Input Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Loader Class Initialized
INFO - 2024-10-05 19:47:08 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:08 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:08 --> Controller Class Initialized
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:08 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:08 --> URI Class Initialized
INFO - 2024-10-05 19:47:08 --> Router Class Initialized
INFO - 2024-10-05 19:47:08 --> Output Class Initialized
INFO - 2024-10-05 19:47:08 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:08 --> Input Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Loader Class Initialized
INFO - 2024-10-05 19:47:08 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:08 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:08 --> Controller Class Initialized
DEBUG - 2024-10-05 19:47:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 19:47:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:47:08 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:08 --> Total execution time: 0.0316
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:08 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:08 --> URI Class Initialized
INFO - 2024-10-05 19:47:08 --> Router Class Initialized
INFO - 2024-10-05 19:47:08 --> Output Class Initialized
INFO - 2024-10-05 19:47:08 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:08 --> Input Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Language Class Initialized
INFO - 2024-10-05 19:47:08 --> Config Class Initialized
INFO - 2024-10-05 19:47:08 --> Loader Class Initialized
INFO - 2024-10-05 19:47:08 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:08 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:08 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:08 --> Controller Class Initialized
INFO - 2024-10-05 19:47:10 --> Config Class Initialized
INFO - 2024-10-05 19:47:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:10 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:10 --> URI Class Initialized
INFO - 2024-10-05 19:47:10 --> Router Class Initialized
INFO - 2024-10-05 19:47:10 --> Output Class Initialized
INFO - 2024-10-05 19:47:10 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:10 --> Input Class Initialized
INFO - 2024-10-05 19:47:10 --> Language Class Initialized
INFO - 2024-10-05 19:47:10 --> Language Class Initialized
INFO - 2024-10-05 19:47:10 --> Config Class Initialized
INFO - 2024-10-05 19:47:10 --> Loader Class Initialized
INFO - 2024-10-05 19:47:10 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:10 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:10 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:10 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:10 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:10 --> Controller Class Initialized
INFO - 2024-10-05 19:47:10 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:10 --> Total execution time: 0.0381
INFO - 2024-10-05 19:47:12 --> Config Class Initialized
INFO - 2024-10-05 19:47:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:12 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:12 --> URI Class Initialized
INFO - 2024-10-05 19:47:12 --> Router Class Initialized
INFO - 2024-10-05 19:47:12 --> Output Class Initialized
INFO - 2024-10-05 19:47:12 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:12 --> Input Class Initialized
INFO - 2024-10-05 19:47:12 --> Language Class Initialized
INFO - 2024-10-05 19:47:12 --> Language Class Initialized
INFO - 2024-10-05 19:47:12 --> Config Class Initialized
INFO - 2024-10-05 19:47:12 --> Loader Class Initialized
INFO - 2024-10-05 19:47:12 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:12 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:12 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:12 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:12 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:12 --> Controller Class Initialized
INFO - 2024-10-05 19:47:12 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:12 --> Total execution time: 0.0314
INFO - 2024-10-05 19:47:17 --> Config Class Initialized
INFO - 2024-10-05 19:47:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:17 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:17 --> URI Class Initialized
INFO - 2024-10-05 19:47:17 --> Router Class Initialized
INFO - 2024-10-05 19:47:17 --> Output Class Initialized
INFO - 2024-10-05 19:47:17 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:17 --> Input Class Initialized
INFO - 2024-10-05 19:47:17 --> Language Class Initialized
INFO - 2024-10-05 19:47:17 --> Language Class Initialized
INFO - 2024-10-05 19:47:17 --> Config Class Initialized
INFO - 2024-10-05 19:47:17 --> Loader Class Initialized
INFO - 2024-10-05 19:47:17 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:17 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:17 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:17 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:17 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:17 --> Controller Class Initialized
DEBUG - 2024-10-05 19:47:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:47:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:47:17 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:17 --> Total execution time: 0.0305
INFO - 2024-10-05 19:47:20 --> Config Class Initialized
INFO - 2024-10-05 19:47:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:20 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:20 --> URI Class Initialized
INFO - 2024-10-05 19:47:20 --> Router Class Initialized
INFO - 2024-10-05 19:47:20 --> Output Class Initialized
INFO - 2024-10-05 19:47:20 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:20 --> Input Class Initialized
INFO - 2024-10-05 19:47:20 --> Language Class Initialized
INFO - 2024-10-05 19:47:20 --> Language Class Initialized
INFO - 2024-10-05 19:47:20 --> Config Class Initialized
INFO - 2024-10-05 19:47:20 --> Loader Class Initialized
INFO - 2024-10-05 19:47:20 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:20 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:20 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:20 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:20 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:20 --> Controller Class Initialized
DEBUG - 2024-10-05 19:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:47:20 --> Final output sent to browser
DEBUG - 2024-10-05 19:47:20 --> Total execution time: 0.0284
INFO - 2024-10-05 19:47:22 --> Config Class Initialized
INFO - 2024-10-05 19:47:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:47:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:47:22 --> Utf8 Class Initialized
INFO - 2024-10-05 19:47:22 --> URI Class Initialized
INFO - 2024-10-05 19:47:22 --> Router Class Initialized
INFO - 2024-10-05 19:47:22 --> Output Class Initialized
INFO - 2024-10-05 19:47:22 --> Security Class Initialized
DEBUG - 2024-10-05 19:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:47:22 --> Input Class Initialized
INFO - 2024-10-05 19:47:22 --> Language Class Initialized
INFO - 2024-10-05 19:47:22 --> Language Class Initialized
INFO - 2024-10-05 19:47:22 --> Config Class Initialized
INFO - 2024-10-05 19:47:22 --> Loader Class Initialized
INFO - 2024-10-05 19:47:22 --> Helper loaded: url_helper
INFO - 2024-10-05 19:47:22 --> Helper loaded: file_helper
INFO - 2024-10-05 19:47:22 --> Helper loaded: form_helper
INFO - 2024-10-05 19:47:22 --> Helper loaded: my_helper
INFO - 2024-10-05 19:47:22 --> Database Driver Class Initialized
INFO - 2024-10-05 19:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:47:22 --> Controller Class Initialized
INFO - 2024-10-05 19:52:09 --> Config Class Initialized
INFO - 2024-10-05 19:52:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:52:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:52:09 --> Utf8 Class Initialized
INFO - 2024-10-05 19:52:09 --> URI Class Initialized
INFO - 2024-10-05 19:52:09 --> Router Class Initialized
INFO - 2024-10-05 19:52:09 --> Output Class Initialized
INFO - 2024-10-05 19:52:09 --> Security Class Initialized
DEBUG - 2024-10-05 19:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:52:09 --> Input Class Initialized
INFO - 2024-10-05 19:52:09 --> Language Class Initialized
INFO - 2024-10-05 19:52:09 --> Language Class Initialized
INFO - 2024-10-05 19:52:09 --> Config Class Initialized
INFO - 2024-10-05 19:52:09 --> Loader Class Initialized
INFO - 2024-10-05 19:52:09 --> Helper loaded: url_helper
INFO - 2024-10-05 19:52:09 --> Helper loaded: file_helper
INFO - 2024-10-05 19:52:09 --> Helper loaded: form_helper
INFO - 2024-10-05 19:52:09 --> Helper loaded: my_helper
INFO - 2024-10-05 19:52:09 --> Database Driver Class Initialized
INFO - 2024-10-05 19:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:52:09 --> Controller Class Initialized
INFO - 2024-10-05 19:52:09 --> Final output sent to browser
DEBUG - 2024-10-05 19:52:09 --> Total execution time: 0.0762
INFO - 2024-10-05 19:52:14 --> Config Class Initialized
INFO - 2024-10-05 19:52:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:52:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:52:14 --> Utf8 Class Initialized
INFO - 2024-10-05 19:52:14 --> URI Class Initialized
INFO - 2024-10-05 19:52:14 --> Router Class Initialized
INFO - 2024-10-05 19:52:14 --> Output Class Initialized
INFO - 2024-10-05 19:52:14 --> Security Class Initialized
DEBUG - 2024-10-05 19:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:52:14 --> Input Class Initialized
INFO - 2024-10-05 19:52:14 --> Language Class Initialized
INFO - 2024-10-05 19:52:14 --> Language Class Initialized
INFO - 2024-10-05 19:52:14 --> Config Class Initialized
INFO - 2024-10-05 19:52:14 --> Loader Class Initialized
INFO - 2024-10-05 19:52:14 --> Helper loaded: url_helper
INFO - 2024-10-05 19:52:14 --> Helper loaded: file_helper
INFO - 2024-10-05 19:52:14 --> Helper loaded: form_helper
INFO - 2024-10-05 19:52:14 --> Helper loaded: my_helper
INFO - 2024-10-05 19:52:14 --> Database Driver Class Initialized
INFO - 2024-10-05 19:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:52:14 --> Controller Class Initialized
DEBUG - 2024-10-05 19:52:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:52:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:52:14 --> Final output sent to browser
DEBUG - 2024-10-05 19:52:14 --> Total execution time: 0.0332
INFO - 2024-10-05 19:52:16 --> Config Class Initialized
INFO - 2024-10-05 19:52:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:52:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:52:16 --> Utf8 Class Initialized
INFO - 2024-10-05 19:52:16 --> URI Class Initialized
INFO - 2024-10-05 19:52:16 --> Router Class Initialized
INFO - 2024-10-05 19:52:16 --> Output Class Initialized
INFO - 2024-10-05 19:52:16 --> Security Class Initialized
DEBUG - 2024-10-05 19:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:52:16 --> Input Class Initialized
INFO - 2024-10-05 19:52:16 --> Language Class Initialized
INFO - 2024-10-05 19:52:16 --> Language Class Initialized
INFO - 2024-10-05 19:52:16 --> Config Class Initialized
INFO - 2024-10-05 19:52:16 --> Loader Class Initialized
INFO - 2024-10-05 19:52:16 --> Helper loaded: url_helper
INFO - 2024-10-05 19:52:16 --> Helper loaded: file_helper
INFO - 2024-10-05 19:52:16 --> Helper loaded: form_helper
INFO - 2024-10-05 19:52:16 --> Helper loaded: my_helper
INFO - 2024-10-05 19:52:16 --> Database Driver Class Initialized
INFO - 2024-10-05 19:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:52:16 --> Controller Class Initialized
DEBUG - 2024-10-05 19:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 19:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:52:16 --> Final output sent to browser
DEBUG - 2024-10-05 19:52:16 --> Total execution time: 0.0321
INFO - 2024-10-05 19:53:11 --> Config Class Initialized
INFO - 2024-10-05 19:53:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:53:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:53:11 --> Utf8 Class Initialized
INFO - 2024-10-05 19:53:11 --> URI Class Initialized
INFO - 2024-10-05 19:53:11 --> Router Class Initialized
INFO - 2024-10-05 19:53:11 --> Output Class Initialized
INFO - 2024-10-05 19:53:11 --> Security Class Initialized
DEBUG - 2024-10-05 19:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:53:11 --> Input Class Initialized
INFO - 2024-10-05 19:53:11 --> Language Class Initialized
INFO - 2024-10-05 19:53:11 --> Language Class Initialized
INFO - 2024-10-05 19:53:11 --> Config Class Initialized
INFO - 2024-10-05 19:53:11 --> Loader Class Initialized
INFO - 2024-10-05 19:53:11 --> Helper loaded: url_helper
INFO - 2024-10-05 19:53:11 --> Helper loaded: file_helper
INFO - 2024-10-05 19:53:11 --> Helper loaded: form_helper
INFO - 2024-10-05 19:53:11 --> Helper loaded: my_helper
INFO - 2024-10-05 19:53:11 --> Database Driver Class Initialized
INFO - 2024-10-05 19:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:53:11 --> Controller Class Initialized
INFO - 2024-10-05 19:53:11 --> Final output sent to browser
DEBUG - 2024-10-05 19:53:11 --> Total execution time: 0.0353
INFO - 2024-10-05 19:57:15 --> Config Class Initialized
INFO - 2024-10-05 19:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:57:15 --> Utf8 Class Initialized
INFO - 2024-10-05 19:57:15 --> URI Class Initialized
INFO - 2024-10-05 19:57:15 --> Router Class Initialized
INFO - 2024-10-05 19:57:15 --> Output Class Initialized
INFO - 2024-10-05 19:57:15 --> Security Class Initialized
DEBUG - 2024-10-05 19:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:57:15 --> Input Class Initialized
INFO - 2024-10-05 19:57:15 --> Language Class Initialized
INFO - 2024-10-05 19:57:15 --> Language Class Initialized
INFO - 2024-10-05 19:57:15 --> Config Class Initialized
INFO - 2024-10-05 19:57:15 --> Loader Class Initialized
INFO - 2024-10-05 19:57:15 --> Helper loaded: url_helper
INFO - 2024-10-05 19:57:15 --> Helper loaded: file_helper
INFO - 2024-10-05 19:57:15 --> Helper loaded: form_helper
INFO - 2024-10-05 19:57:15 --> Helper loaded: my_helper
INFO - 2024-10-05 19:57:15 --> Database Driver Class Initialized
INFO - 2024-10-05 19:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:57:15 --> Controller Class Initialized
INFO - 2024-10-05 19:57:15 --> Final output sent to browser
DEBUG - 2024-10-05 19:57:15 --> Total execution time: 0.0623
INFO - 2024-10-05 19:58:23 --> Config Class Initialized
INFO - 2024-10-05 19:58:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:23 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:23 --> URI Class Initialized
INFO - 2024-10-05 19:58:23 --> Router Class Initialized
INFO - 2024-10-05 19:58:23 --> Output Class Initialized
INFO - 2024-10-05 19:58:23 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:23 --> Input Class Initialized
INFO - 2024-10-05 19:58:23 --> Language Class Initialized
INFO - 2024-10-05 19:58:23 --> Language Class Initialized
INFO - 2024-10-05 19:58:23 --> Config Class Initialized
INFO - 2024-10-05 19:58:23 --> Loader Class Initialized
INFO - 2024-10-05 19:58:23 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:23 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:23 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:23 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:23 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:23 --> Controller Class Initialized
INFO - 2024-10-05 19:58:23 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:23 --> Total execution time: 0.0512
INFO - 2024-10-05 19:58:29 --> Config Class Initialized
INFO - 2024-10-05 19:58:29 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:29 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:29 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:29 --> URI Class Initialized
INFO - 2024-10-05 19:58:29 --> Router Class Initialized
INFO - 2024-10-05 19:58:29 --> Output Class Initialized
INFO - 2024-10-05 19:58:29 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:29 --> Input Class Initialized
INFO - 2024-10-05 19:58:29 --> Language Class Initialized
INFO - 2024-10-05 19:58:29 --> Language Class Initialized
INFO - 2024-10-05 19:58:29 --> Config Class Initialized
INFO - 2024-10-05 19:58:29 --> Loader Class Initialized
INFO - 2024-10-05 19:58:29 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:29 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:29 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:29 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:29 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:29 --> Controller Class Initialized
INFO - 2024-10-05 19:58:30 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:30 --> Total execution time: 0.0839
INFO - 2024-10-05 19:58:32 --> Config Class Initialized
INFO - 2024-10-05 19:58:32 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:32 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:32 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:32 --> URI Class Initialized
DEBUG - 2024-10-05 19:58:32 --> No URI present. Default controller set.
INFO - 2024-10-05 19:58:32 --> Router Class Initialized
INFO - 2024-10-05 19:58:32 --> Output Class Initialized
INFO - 2024-10-05 19:58:32 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:32 --> Input Class Initialized
INFO - 2024-10-05 19:58:32 --> Language Class Initialized
INFO - 2024-10-05 19:58:32 --> Language Class Initialized
INFO - 2024-10-05 19:58:32 --> Config Class Initialized
INFO - 2024-10-05 19:58:32 --> Loader Class Initialized
INFO - 2024-10-05 19:58:32 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:32 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:32 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:32 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:32 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:32 --> Controller Class Initialized
DEBUG - 2024-10-05 19:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 19:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:58:32 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:32 --> Total execution time: 0.0286
INFO - 2024-10-05 19:58:35 --> Config Class Initialized
INFO - 2024-10-05 19:58:35 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:35 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:35 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:35 --> URI Class Initialized
INFO - 2024-10-05 19:58:35 --> Router Class Initialized
INFO - 2024-10-05 19:58:35 --> Output Class Initialized
INFO - 2024-10-05 19:58:35 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:35 --> Input Class Initialized
INFO - 2024-10-05 19:58:35 --> Language Class Initialized
INFO - 2024-10-05 19:58:35 --> Language Class Initialized
INFO - 2024-10-05 19:58:35 --> Config Class Initialized
INFO - 2024-10-05 19:58:35 --> Loader Class Initialized
INFO - 2024-10-05 19:58:35 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:35 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:35 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:35 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:35 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:35 --> Controller Class Initialized
DEBUG - 2024-10-05 19:58:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:58:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:58:35 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:35 --> Total execution time: 0.0253
INFO - 2024-10-05 19:58:38 --> Config Class Initialized
INFO - 2024-10-05 19:58:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:38 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:38 --> URI Class Initialized
INFO - 2024-10-05 19:58:38 --> Router Class Initialized
INFO - 2024-10-05 19:58:38 --> Output Class Initialized
INFO - 2024-10-05 19:58:38 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:38 --> Input Class Initialized
INFO - 2024-10-05 19:58:38 --> Language Class Initialized
INFO - 2024-10-05 19:58:38 --> Language Class Initialized
INFO - 2024-10-05 19:58:38 --> Config Class Initialized
INFO - 2024-10-05 19:58:38 --> Loader Class Initialized
INFO - 2024-10-05 19:58:38 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:38 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:38 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:38 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:38 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:38 --> Controller Class Initialized
DEBUG - 2024-10-05 19:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-10-05 19:58:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:58:38 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:38 --> Total execution time: 0.0288
INFO - 2024-10-05 19:58:48 --> Config Class Initialized
INFO - 2024-10-05 19:58:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:58:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:58:48 --> Utf8 Class Initialized
INFO - 2024-10-05 19:58:48 --> URI Class Initialized
INFO - 2024-10-05 19:58:48 --> Router Class Initialized
INFO - 2024-10-05 19:58:48 --> Output Class Initialized
INFO - 2024-10-05 19:58:48 --> Security Class Initialized
DEBUG - 2024-10-05 19:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:58:48 --> Input Class Initialized
INFO - 2024-10-05 19:58:48 --> Language Class Initialized
INFO - 2024-10-05 19:58:48 --> Language Class Initialized
INFO - 2024-10-05 19:58:48 --> Config Class Initialized
INFO - 2024-10-05 19:58:48 --> Loader Class Initialized
INFO - 2024-10-05 19:58:48 --> Helper loaded: url_helper
INFO - 2024-10-05 19:58:48 --> Helper loaded: file_helper
INFO - 2024-10-05 19:58:48 --> Helper loaded: form_helper
INFO - 2024-10-05 19:58:48 --> Helper loaded: my_helper
INFO - 2024-10-05 19:58:48 --> Database Driver Class Initialized
INFO - 2024-10-05 19:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:58:48 --> Controller Class Initialized
DEBUG - 2024-10-05 19:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-10-05 19:58:48 --> Final output sent to browser
DEBUG - 2024-10-05 19:58:48 --> Total execution time: 0.1499
INFO - 2024-10-05 19:59:00 --> Config Class Initialized
INFO - 2024-10-05 19:59:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:59:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:59:00 --> Utf8 Class Initialized
INFO - 2024-10-05 19:59:00 --> URI Class Initialized
INFO - 2024-10-05 19:59:00 --> Router Class Initialized
INFO - 2024-10-05 19:59:00 --> Output Class Initialized
INFO - 2024-10-05 19:59:00 --> Security Class Initialized
DEBUG - 2024-10-05 19:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:59:00 --> Input Class Initialized
INFO - 2024-10-05 19:59:00 --> Language Class Initialized
INFO - 2024-10-05 19:59:00 --> Language Class Initialized
INFO - 2024-10-05 19:59:00 --> Config Class Initialized
INFO - 2024-10-05 19:59:00 --> Loader Class Initialized
INFO - 2024-10-05 19:59:00 --> Helper loaded: url_helper
INFO - 2024-10-05 19:59:00 --> Helper loaded: file_helper
INFO - 2024-10-05 19:59:00 --> Helper loaded: form_helper
INFO - 2024-10-05 19:59:00 --> Helper loaded: my_helper
INFO - 2024-10-05 19:59:00 --> Database Driver Class Initialized
INFO - 2024-10-05 19:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:59:00 --> Controller Class Initialized
DEBUG - 2024-10-05 19:59:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_keterampilan/views/cetak.php
INFO - 2024-10-05 19:59:00 --> Final output sent to browser
DEBUG - 2024-10-05 19:59:00 --> Total execution time: 0.0395
INFO - 2024-10-05 19:59:07 --> Config Class Initialized
INFO - 2024-10-05 19:59:07 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:59:07 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:59:07 --> Utf8 Class Initialized
INFO - 2024-10-05 19:59:07 --> URI Class Initialized
INFO - 2024-10-05 19:59:07 --> Router Class Initialized
INFO - 2024-10-05 19:59:07 --> Output Class Initialized
INFO - 2024-10-05 19:59:07 --> Security Class Initialized
DEBUG - 2024-10-05 19:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:59:07 --> Input Class Initialized
INFO - 2024-10-05 19:59:07 --> Language Class Initialized
INFO - 2024-10-05 19:59:07 --> Language Class Initialized
INFO - 2024-10-05 19:59:07 --> Config Class Initialized
INFO - 2024-10-05 19:59:07 --> Loader Class Initialized
INFO - 2024-10-05 19:59:07 --> Helper loaded: url_helper
INFO - 2024-10-05 19:59:07 --> Helper loaded: file_helper
INFO - 2024-10-05 19:59:07 --> Helper loaded: form_helper
INFO - 2024-10-05 19:59:07 --> Helper loaded: my_helper
INFO - 2024-10-05 19:59:07 --> Database Driver Class Initialized
INFO - 2024-10-05 19:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:59:07 --> Controller Class Initialized
DEBUG - 2024-10-05 19:59:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-10-05 19:59:07 --> Final output sent to browser
DEBUG - 2024-10-05 19:59:07 --> Total execution time: 0.0888
INFO - 2024-10-05 19:59:43 --> Config Class Initialized
INFO - 2024-10-05 19:59:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 19:59:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 19:59:43 --> Utf8 Class Initialized
INFO - 2024-10-05 19:59:43 --> URI Class Initialized
INFO - 2024-10-05 19:59:43 --> Router Class Initialized
INFO - 2024-10-05 19:59:43 --> Output Class Initialized
INFO - 2024-10-05 19:59:43 --> Security Class Initialized
DEBUG - 2024-10-05 19:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 19:59:43 --> Input Class Initialized
INFO - 2024-10-05 19:59:43 --> Language Class Initialized
INFO - 2024-10-05 19:59:43 --> Language Class Initialized
INFO - 2024-10-05 19:59:43 --> Config Class Initialized
INFO - 2024-10-05 19:59:43 --> Loader Class Initialized
INFO - 2024-10-05 19:59:43 --> Helper loaded: url_helper
INFO - 2024-10-05 19:59:43 --> Helper loaded: file_helper
INFO - 2024-10-05 19:59:43 --> Helper loaded: form_helper
INFO - 2024-10-05 19:59:43 --> Helper loaded: my_helper
INFO - 2024-10-05 19:59:43 --> Database Driver Class Initialized
INFO - 2024-10-05 19:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 19:59:43 --> Controller Class Initialized
DEBUG - 2024-10-05 19:59:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 19:59:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 19:59:43 --> Final output sent to browser
DEBUG - 2024-10-05 19:59:43 --> Total execution time: 0.0338
INFO - 2024-10-05 20:00:38 --> Config Class Initialized
INFO - 2024-10-05 20:00:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:00:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:00:38 --> Utf8 Class Initialized
INFO - 2024-10-05 20:00:38 --> URI Class Initialized
INFO - 2024-10-05 20:00:38 --> Router Class Initialized
INFO - 2024-10-05 20:00:38 --> Output Class Initialized
INFO - 2024-10-05 20:00:38 --> Security Class Initialized
DEBUG - 2024-10-05 20:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:00:38 --> Input Class Initialized
INFO - 2024-10-05 20:00:38 --> Language Class Initialized
INFO - 2024-10-05 20:00:38 --> Language Class Initialized
INFO - 2024-10-05 20:00:38 --> Config Class Initialized
INFO - 2024-10-05 20:00:38 --> Loader Class Initialized
INFO - 2024-10-05 20:00:38 --> Helper loaded: url_helper
INFO - 2024-10-05 20:00:38 --> Helper loaded: file_helper
INFO - 2024-10-05 20:00:38 --> Helper loaded: form_helper
INFO - 2024-10-05 20:00:38 --> Helper loaded: my_helper
INFO - 2024-10-05 20:00:38 --> Database Driver Class Initialized
INFO - 2024-10-05 20:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:00:38 --> Controller Class Initialized
DEBUG - 2024-10-05 20:00:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 20:00:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:00:38 --> Final output sent to browser
DEBUG - 2024-10-05 20:00:38 --> Total execution time: 0.0410
INFO - 2024-10-05 20:00:48 --> Config Class Initialized
INFO - 2024-10-05 20:00:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:00:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:00:48 --> Utf8 Class Initialized
INFO - 2024-10-05 20:00:48 --> URI Class Initialized
INFO - 2024-10-05 20:00:48 --> Router Class Initialized
INFO - 2024-10-05 20:00:48 --> Output Class Initialized
INFO - 2024-10-05 20:00:48 --> Security Class Initialized
DEBUG - 2024-10-05 20:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:00:48 --> Input Class Initialized
INFO - 2024-10-05 20:00:48 --> Language Class Initialized
INFO - 2024-10-05 20:00:48 --> Language Class Initialized
INFO - 2024-10-05 20:00:48 --> Config Class Initialized
INFO - 2024-10-05 20:00:48 --> Loader Class Initialized
INFO - 2024-10-05 20:00:48 --> Helper loaded: url_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: file_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: form_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: my_helper
INFO - 2024-10-05 20:00:48 --> Database Driver Class Initialized
INFO - 2024-10-05 20:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:00:48 --> Controller Class Initialized
INFO - 2024-10-05 20:00:48 --> Config Class Initialized
INFO - 2024-10-05 20:00:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:00:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:00:48 --> Utf8 Class Initialized
INFO - 2024-10-05 20:00:48 --> URI Class Initialized
INFO - 2024-10-05 20:00:48 --> Router Class Initialized
INFO - 2024-10-05 20:00:48 --> Output Class Initialized
INFO - 2024-10-05 20:00:48 --> Security Class Initialized
DEBUG - 2024-10-05 20:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:00:48 --> Input Class Initialized
INFO - 2024-10-05 20:00:48 --> Language Class Initialized
INFO - 2024-10-05 20:00:48 --> Language Class Initialized
INFO - 2024-10-05 20:00:48 --> Config Class Initialized
INFO - 2024-10-05 20:00:48 --> Loader Class Initialized
INFO - 2024-10-05 20:00:48 --> Helper loaded: url_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: file_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: form_helper
INFO - 2024-10-05 20:00:48 --> Helper loaded: my_helper
INFO - 2024-10-05 20:00:48 --> Database Driver Class Initialized
INFO - 2024-10-05 20:00:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:00:48 --> Controller Class Initialized
DEBUG - 2024-10-05 20:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:00:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:00:48 --> Final output sent to browser
DEBUG - 2024-10-05 20:00:48 --> Total execution time: 0.0288
INFO - 2024-10-05 20:00:51 --> Config Class Initialized
INFO - 2024-10-05 20:00:51 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:00:51 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:00:51 --> Utf8 Class Initialized
INFO - 2024-10-05 20:00:51 --> URI Class Initialized
INFO - 2024-10-05 20:00:51 --> Router Class Initialized
INFO - 2024-10-05 20:00:51 --> Output Class Initialized
INFO - 2024-10-05 20:00:51 --> Security Class Initialized
DEBUG - 2024-10-05 20:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:00:51 --> Input Class Initialized
INFO - 2024-10-05 20:00:51 --> Language Class Initialized
INFO - 2024-10-05 20:00:51 --> Language Class Initialized
INFO - 2024-10-05 20:00:51 --> Config Class Initialized
INFO - 2024-10-05 20:00:51 --> Loader Class Initialized
INFO - 2024-10-05 20:00:51 --> Helper loaded: url_helper
INFO - 2024-10-05 20:00:51 --> Helper loaded: file_helper
INFO - 2024-10-05 20:00:51 --> Helper loaded: form_helper
INFO - 2024-10-05 20:00:51 --> Helper loaded: my_helper
INFO - 2024-10-05 20:00:51 --> Database Driver Class Initialized
INFO - 2024-10-05 20:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:00:51 --> Controller Class Initialized
INFO - 2024-10-05 20:00:51 --> Final output sent to browser
DEBUG - 2024-10-05 20:00:51 --> Total execution time: 0.0307
INFO - 2024-10-05 20:00:57 --> Config Class Initialized
INFO - 2024-10-05 20:00:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:00:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:00:57 --> Utf8 Class Initialized
INFO - 2024-10-05 20:00:57 --> URI Class Initialized
INFO - 2024-10-05 20:00:57 --> Router Class Initialized
INFO - 2024-10-05 20:00:57 --> Output Class Initialized
INFO - 2024-10-05 20:00:57 --> Security Class Initialized
DEBUG - 2024-10-05 20:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:00:57 --> Input Class Initialized
INFO - 2024-10-05 20:00:57 --> Language Class Initialized
INFO - 2024-10-05 20:00:57 --> Language Class Initialized
INFO - 2024-10-05 20:00:57 --> Config Class Initialized
INFO - 2024-10-05 20:00:57 --> Loader Class Initialized
INFO - 2024-10-05 20:00:57 --> Helper loaded: url_helper
INFO - 2024-10-05 20:00:57 --> Helper loaded: file_helper
INFO - 2024-10-05 20:00:57 --> Helper loaded: form_helper
INFO - 2024-10-05 20:00:57 --> Helper loaded: my_helper
INFO - 2024-10-05 20:00:57 --> Database Driver Class Initialized
INFO - 2024-10-05 20:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:00:57 --> Controller Class Initialized
DEBUG - 2024-10-05 20:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:00:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:00:57 --> Final output sent to browser
DEBUG - 2024-10-05 20:00:57 --> Total execution time: 0.0300
INFO - 2024-10-05 20:01:01 --> Config Class Initialized
INFO - 2024-10-05 20:01:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:01:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:01:01 --> Utf8 Class Initialized
INFO - 2024-10-05 20:01:01 --> URI Class Initialized
INFO - 2024-10-05 20:01:01 --> Router Class Initialized
INFO - 2024-10-05 20:01:01 --> Output Class Initialized
INFO - 2024-10-05 20:01:01 --> Security Class Initialized
DEBUG - 2024-10-05 20:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:01:01 --> Input Class Initialized
INFO - 2024-10-05 20:01:01 --> Language Class Initialized
INFO - 2024-10-05 20:01:01 --> Language Class Initialized
INFO - 2024-10-05 20:01:01 --> Config Class Initialized
INFO - 2024-10-05 20:01:01 --> Loader Class Initialized
INFO - 2024-10-05 20:01:01 --> Helper loaded: url_helper
INFO - 2024-10-05 20:01:01 --> Helper loaded: file_helper
INFO - 2024-10-05 20:01:01 --> Helper loaded: form_helper
INFO - 2024-10-05 20:01:01 --> Helper loaded: my_helper
INFO - 2024-10-05 20:01:01 --> Database Driver Class Initialized
INFO - 2024-10-05 20:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:01:01 --> Controller Class Initialized
DEBUG - 2024-10-05 20:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:01:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:01:01 --> Final output sent to browser
DEBUG - 2024-10-05 20:01:01 --> Total execution time: 0.0356
INFO - 2024-10-05 20:01:03 --> Config Class Initialized
INFO - 2024-10-05 20:01:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:01:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:01:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:01:03 --> URI Class Initialized
INFO - 2024-10-05 20:01:03 --> Router Class Initialized
INFO - 2024-10-05 20:01:03 --> Output Class Initialized
INFO - 2024-10-05 20:01:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:01:03 --> Input Class Initialized
INFO - 2024-10-05 20:01:03 --> Language Class Initialized
INFO - 2024-10-05 20:01:03 --> Language Class Initialized
INFO - 2024-10-05 20:01:03 --> Config Class Initialized
INFO - 2024-10-05 20:01:03 --> Loader Class Initialized
INFO - 2024-10-05 20:01:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:01:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:01:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:01:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:01:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:01:03 --> Controller Class Initialized
INFO - 2024-10-05 20:01:03 --> Final output sent to browser
DEBUG - 2024-10-05 20:01:03 --> Total execution time: 0.0345
INFO - 2024-10-05 20:04:21 --> Config Class Initialized
INFO - 2024-10-05 20:04:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:21 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:21 --> URI Class Initialized
INFO - 2024-10-05 20:04:21 --> Router Class Initialized
INFO - 2024-10-05 20:04:21 --> Output Class Initialized
INFO - 2024-10-05 20:04:21 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:21 --> Input Class Initialized
INFO - 2024-10-05 20:04:21 --> Language Class Initialized
INFO - 2024-10-05 20:04:21 --> Language Class Initialized
INFO - 2024-10-05 20:04:21 --> Config Class Initialized
INFO - 2024-10-05 20:04:21 --> Loader Class Initialized
INFO - 2024-10-05 20:04:21 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:21 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:21 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:21 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:21 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:21 --> Controller Class Initialized
INFO - 2024-10-05 20:04:21 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:21 --> Total execution time: 0.0617
INFO - 2024-10-05 20:04:27 --> Config Class Initialized
INFO - 2024-10-05 20:04:27 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:27 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:27 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:27 --> URI Class Initialized
INFO - 2024-10-05 20:04:27 --> Router Class Initialized
INFO - 2024-10-05 20:04:27 --> Output Class Initialized
INFO - 2024-10-05 20:04:27 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:27 --> Input Class Initialized
INFO - 2024-10-05 20:04:27 --> Language Class Initialized
INFO - 2024-10-05 20:04:27 --> Language Class Initialized
INFO - 2024-10-05 20:04:27 --> Config Class Initialized
INFO - 2024-10-05 20:04:27 --> Loader Class Initialized
INFO - 2024-10-05 20:04:27 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:27 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:27 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:27 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:27 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:28 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:04:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:28 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:28 --> Total execution time: 0.0362
INFO - 2024-10-05 20:04:32 --> Config Class Initialized
INFO - 2024-10-05 20:04:32 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:32 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:32 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:32 --> URI Class Initialized
INFO - 2024-10-05 20:04:32 --> Router Class Initialized
INFO - 2024-10-05 20:04:32 --> Output Class Initialized
INFO - 2024-10-05 20:04:32 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:32 --> Input Class Initialized
INFO - 2024-10-05 20:04:32 --> Language Class Initialized
INFO - 2024-10-05 20:04:32 --> Language Class Initialized
INFO - 2024-10-05 20:04:32 --> Config Class Initialized
INFO - 2024-10-05 20:04:32 --> Loader Class Initialized
INFO - 2024-10-05 20:04:32 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:32 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:32 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:32 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:32 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:32 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:32 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:32 --> Total execution time: 0.0345
INFO - 2024-10-05 20:04:34 --> Config Class Initialized
INFO - 2024-10-05 20:04:34 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:34 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:34 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:34 --> URI Class Initialized
INFO - 2024-10-05 20:04:34 --> Router Class Initialized
INFO - 2024-10-05 20:04:34 --> Output Class Initialized
INFO - 2024-10-05 20:04:34 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:34 --> Input Class Initialized
INFO - 2024-10-05 20:04:34 --> Language Class Initialized
INFO - 2024-10-05 20:04:34 --> Language Class Initialized
INFO - 2024-10-05 20:04:34 --> Config Class Initialized
INFO - 2024-10-05 20:04:34 --> Loader Class Initialized
INFO - 2024-10-05 20:04:34 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:34 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:34 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:34 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:34 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:34 --> Controller Class Initialized
INFO - 2024-10-05 20:04:34 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:34 --> Total execution time: 0.0342
INFO - 2024-10-05 20:04:36 --> Config Class Initialized
INFO - 2024-10-05 20:04:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:36 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:36 --> URI Class Initialized
INFO - 2024-10-05 20:04:36 --> Router Class Initialized
INFO - 2024-10-05 20:04:36 --> Output Class Initialized
INFO - 2024-10-05 20:04:36 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:36 --> Input Class Initialized
INFO - 2024-10-05 20:04:36 --> Language Class Initialized
INFO - 2024-10-05 20:04:36 --> Language Class Initialized
INFO - 2024-10-05 20:04:36 --> Config Class Initialized
INFO - 2024-10-05 20:04:36 --> Loader Class Initialized
INFO - 2024-10-05 20:04:36 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:36 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:36 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:36 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:36 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:36 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:04:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:36 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:36 --> Total execution time: 0.0383
INFO - 2024-10-05 20:04:38 --> Config Class Initialized
INFO - 2024-10-05 20:04:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:38 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:38 --> URI Class Initialized
INFO - 2024-10-05 20:04:38 --> Router Class Initialized
INFO - 2024-10-05 20:04:38 --> Output Class Initialized
INFO - 2024-10-05 20:04:38 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:38 --> Input Class Initialized
INFO - 2024-10-05 20:04:38 --> Language Class Initialized
INFO - 2024-10-05 20:04:38 --> Language Class Initialized
INFO - 2024-10-05 20:04:38 --> Config Class Initialized
INFO - 2024-10-05 20:04:38 --> Loader Class Initialized
INFO - 2024-10-05 20:04:38 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:38 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:38 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:38 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:38 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:38 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:04:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:38 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:38 --> Total execution time: 0.1062
INFO - 2024-10-05 20:04:39 --> Config Class Initialized
INFO - 2024-10-05 20:04:39 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:39 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:39 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:39 --> URI Class Initialized
INFO - 2024-10-05 20:04:39 --> Router Class Initialized
INFO - 2024-10-05 20:04:39 --> Output Class Initialized
INFO - 2024-10-05 20:04:39 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:39 --> Input Class Initialized
INFO - 2024-10-05 20:04:39 --> Language Class Initialized
INFO - 2024-10-05 20:04:39 --> Language Class Initialized
INFO - 2024-10-05 20:04:39 --> Config Class Initialized
INFO - 2024-10-05 20:04:39 --> Loader Class Initialized
INFO - 2024-10-05 20:04:39 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:39 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:39 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:39 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:39 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:39 --> Controller Class Initialized
INFO - 2024-10-05 20:04:39 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:39 --> Total execution time: 0.0401
INFO - 2024-10-05 20:04:42 --> Config Class Initialized
INFO - 2024-10-05 20:04:42 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:42 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:42 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:42 --> URI Class Initialized
INFO - 2024-10-05 20:04:42 --> Router Class Initialized
INFO - 2024-10-05 20:04:42 --> Output Class Initialized
INFO - 2024-10-05 20:04:42 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:42 --> Input Class Initialized
INFO - 2024-10-05 20:04:42 --> Language Class Initialized
INFO - 2024-10-05 20:04:42 --> Language Class Initialized
INFO - 2024-10-05 20:04:42 --> Config Class Initialized
INFO - 2024-10-05 20:04:42 --> Loader Class Initialized
INFO - 2024-10-05 20:04:42 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:42 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:42 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:42 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:42 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:42 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:04:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:42 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:42 --> Total execution time: 0.0276
INFO - 2024-10-05 20:04:47 --> Config Class Initialized
INFO - 2024-10-05 20:04:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:47 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:47 --> URI Class Initialized
INFO - 2024-10-05 20:04:47 --> Router Class Initialized
INFO - 2024-10-05 20:04:47 --> Output Class Initialized
INFO - 2024-10-05 20:04:47 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:47 --> Input Class Initialized
INFO - 2024-10-05 20:04:47 --> Language Class Initialized
INFO - 2024-10-05 20:04:47 --> Language Class Initialized
INFO - 2024-10-05 20:04:47 --> Config Class Initialized
INFO - 2024-10-05 20:04:47 --> Loader Class Initialized
INFO - 2024-10-05 20:04:47 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:47 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:47 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:47 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:47 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:47 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:47 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:47 --> Total execution time: 0.0297
INFO - 2024-10-05 20:04:48 --> Config Class Initialized
INFO - 2024-10-05 20:04:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:48 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:48 --> URI Class Initialized
INFO - 2024-10-05 20:04:48 --> Router Class Initialized
INFO - 2024-10-05 20:04:48 --> Output Class Initialized
INFO - 2024-10-05 20:04:48 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:48 --> Input Class Initialized
INFO - 2024-10-05 20:04:48 --> Language Class Initialized
INFO - 2024-10-05 20:04:48 --> Language Class Initialized
INFO - 2024-10-05 20:04:48 --> Config Class Initialized
INFO - 2024-10-05 20:04:48 --> Loader Class Initialized
INFO - 2024-10-05 20:04:48 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:48 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:48 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:48 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:48 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:48 --> Controller Class Initialized
INFO - 2024-10-05 20:04:49 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:49 --> Total execution time: 0.0361
INFO - 2024-10-05 20:04:50 --> Config Class Initialized
INFO - 2024-10-05 20:04:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:50 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:50 --> URI Class Initialized
INFO - 2024-10-05 20:04:50 --> Router Class Initialized
INFO - 2024-10-05 20:04:50 --> Output Class Initialized
INFO - 2024-10-05 20:04:50 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:50 --> Input Class Initialized
INFO - 2024-10-05 20:04:50 --> Language Class Initialized
INFO - 2024-10-05 20:04:50 --> Language Class Initialized
INFO - 2024-10-05 20:04:50 --> Config Class Initialized
INFO - 2024-10-05 20:04:50 --> Loader Class Initialized
INFO - 2024-10-05 20:04:50 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:50 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:50 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:50 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:50 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:50 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:04:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:50 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:50 --> Total execution time: 0.0290
INFO - 2024-10-05 20:04:54 --> Config Class Initialized
INFO - 2024-10-05 20:04:54 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:54 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:54 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:54 --> URI Class Initialized
INFO - 2024-10-05 20:04:54 --> Router Class Initialized
INFO - 2024-10-05 20:04:54 --> Output Class Initialized
INFO - 2024-10-05 20:04:54 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:54 --> Input Class Initialized
INFO - 2024-10-05 20:04:54 --> Language Class Initialized
INFO - 2024-10-05 20:04:54 --> Language Class Initialized
INFO - 2024-10-05 20:04:54 --> Config Class Initialized
INFO - 2024-10-05 20:04:54 --> Loader Class Initialized
INFO - 2024-10-05 20:04:54 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:54 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:54 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:54 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:54 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:54 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:04:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:54 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:54 --> Total execution time: 0.0313
INFO - 2024-10-05 20:04:55 --> Config Class Initialized
INFO - 2024-10-05 20:04:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:55 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:55 --> URI Class Initialized
INFO - 2024-10-05 20:04:55 --> Router Class Initialized
INFO - 2024-10-05 20:04:55 --> Output Class Initialized
INFO - 2024-10-05 20:04:55 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:55 --> Input Class Initialized
INFO - 2024-10-05 20:04:55 --> Language Class Initialized
INFO - 2024-10-05 20:04:55 --> Language Class Initialized
INFO - 2024-10-05 20:04:55 --> Config Class Initialized
INFO - 2024-10-05 20:04:55 --> Loader Class Initialized
INFO - 2024-10-05 20:04:55 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:55 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:55 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:55 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:55 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:55 --> Controller Class Initialized
INFO - 2024-10-05 20:04:55 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:55 --> Total execution time: 0.0344
INFO - 2024-10-05 20:04:56 --> Config Class Initialized
INFO - 2024-10-05 20:04:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:56 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:56 --> URI Class Initialized
INFO - 2024-10-05 20:04:56 --> Router Class Initialized
INFO - 2024-10-05 20:04:56 --> Output Class Initialized
INFO - 2024-10-05 20:04:56 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:56 --> Input Class Initialized
INFO - 2024-10-05 20:04:56 --> Language Class Initialized
INFO - 2024-10-05 20:04:56 --> Language Class Initialized
INFO - 2024-10-05 20:04:56 --> Config Class Initialized
INFO - 2024-10-05 20:04:56 --> Loader Class Initialized
INFO - 2024-10-05 20:04:56 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:56 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:56 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:56 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:56 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:56 --> Controller Class Initialized
INFO - 2024-10-05 20:04:56 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:56 --> Total execution time: 0.0311
INFO - 2024-10-05 20:04:58 --> Config Class Initialized
INFO - 2024-10-05 20:04:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:04:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:04:58 --> Utf8 Class Initialized
INFO - 2024-10-05 20:04:58 --> URI Class Initialized
INFO - 2024-10-05 20:04:58 --> Router Class Initialized
INFO - 2024-10-05 20:04:58 --> Output Class Initialized
INFO - 2024-10-05 20:04:58 --> Security Class Initialized
DEBUG - 2024-10-05 20:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:04:58 --> Input Class Initialized
INFO - 2024-10-05 20:04:58 --> Language Class Initialized
INFO - 2024-10-05 20:04:58 --> Language Class Initialized
INFO - 2024-10-05 20:04:58 --> Config Class Initialized
INFO - 2024-10-05 20:04:58 --> Loader Class Initialized
INFO - 2024-10-05 20:04:58 --> Helper loaded: url_helper
INFO - 2024-10-05 20:04:58 --> Helper loaded: file_helper
INFO - 2024-10-05 20:04:58 --> Helper loaded: form_helper
INFO - 2024-10-05 20:04:58 --> Helper loaded: my_helper
INFO - 2024-10-05 20:04:58 --> Database Driver Class Initialized
INFO - 2024-10-05 20:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:04:58 --> Controller Class Initialized
DEBUG - 2024-10-05 20:04:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:04:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:04:58 --> Final output sent to browser
DEBUG - 2024-10-05 20:04:58 --> Total execution time: 0.0323
INFO - 2024-10-05 20:05:02 --> Config Class Initialized
INFO - 2024-10-05 20:05:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:02 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:02 --> URI Class Initialized
INFO - 2024-10-05 20:05:02 --> Router Class Initialized
INFO - 2024-10-05 20:05:02 --> Output Class Initialized
INFO - 2024-10-05 20:05:02 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:02 --> Input Class Initialized
INFO - 2024-10-05 20:05:02 --> Language Class Initialized
INFO - 2024-10-05 20:05:02 --> Language Class Initialized
INFO - 2024-10-05 20:05:02 --> Config Class Initialized
INFO - 2024-10-05 20:05:02 --> Loader Class Initialized
INFO - 2024-10-05 20:05:02 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:02 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:02 --> Controller Class Initialized
DEBUG - 2024-10-05 20:05:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 20:05:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:05:02 --> Final output sent to browser
DEBUG - 2024-10-05 20:05:02 --> Total execution time: 0.0391
INFO - 2024-10-05 20:05:02 --> Config Class Initialized
INFO - 2024-10-05 20:05:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:02 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:02 --> URI Class Initialized
INFO - 2024-10-05 20:05:02 --> Router Class Initialized
INFO - 2024-10-05 20:05:02 --> Output Class Initialized
INFO - 2024-10-05 20:05:02 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:02 --> Input Class Initialized
INFO - 2024-10-05 20:05:02 --> Language Class Initialized
INFO - 2024-10-05 20:05:02 --> Language Class Initialized
INFO - 2024-10-05 20:05:02 --> Config Class Initialized
INFO - 2024-10-05 20:05:02 --> Loader Class Initialized
INFO - 2024-10-05 20:05:02 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:02 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:02 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:02 --> Controller Class Initialized
INFO - 2024-10-05 20:05:09 --> Config Class Initialized
INFO - 2024-10-05 20:05:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:09 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:09 --> URI Class Initialized
INFO - 2024-10-05 20:05:09 --> Router Class Initialized
INFO - 2024-10-05 20:05:09 --> Output Class Initialized
INFO - 2024-10-05 20:05:09 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:09 --> Input Class Initialized
INFO - 2024-10-05 20:05:09 --> Language Class Initialized
INFO - 2024-10-05 20:05:09 --> Language Class Initialized
INFO - 2024-10-05 20:05:09 --> Config Class Initialized
INFO - 2024-10-05 20:05:09 --> Loader Class Initialized
INFO - 2024-10-05 20:05:09 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:09 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:09 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:09 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:09 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:09 --> Controller Class Initialized
INFO - 2024-10-05 20:05:09 --> Final output sent to browser
DEBUG - 2024-10-05 20:05:09 --> Total execution time: 0.0354
INFO - 2024-10-05 20:05:43 --> Config Class Initialized
INFO - 2024-10-05 20:05:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:43 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:43 --> URI Class Initialized
INFO - 2024-10-05 20:05:43 --> Router Class Initialized
INFO - 2024-10-05 20:05:43 --> Output Class Initialized
INFO - 2024-10-05 20:05:43 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:43 --> Input Class Initialized
INFO - 2024-10-05 20:05:43 --> Language Class Initialized
INFO - 2024-10-05 20:05:43 --> Language Class Initialized
INFO - 2024-10-05 20:05:43 --> Config Class Initialized
INFO - 2024-10-05 20:05:43 --> Loader Class Initialized
INFO - 2024-10-05 20:05:43 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:43 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:43 --> Controller Class Initialized
INFO - 2024-10-05 20:05:43 --> Final output sent to browser
DEBUG - 2024-10-05 20:05:43 --> Total execution time: 0.0314
INFO - 2024-10-05 20:05:43 --> Config Class Initialized
INFO - 2024-10-05 20:05:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:43 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:43 --> URI Class Initialized
INFO - 2024-10-05 20:05:43 --> Router Class Initialized
INFO - 2024-10-05 20:05:43 --> Output Class Initialized
INFO - 2024-10-05 20:05:43 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:43 --> Input Class Initialized
INFO - 2024-10-05 20:05:43 --> Language Class Initialized
INFO - 2024-10-05 20:05:43 --> Language Class Initialized
INFO - 2024-10-05 20:05:43 --> Config Class Initialized
INFO - 2024-10-05 20:05:43 --> Loader Class Initialized
INFO - 2024-10-05 20:05:43 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:43 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:43 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:43 --> Controller Class Initialized
INFO - 2024-10-05 20:05:45 --> Config Class Initialized
INFO - 2024-10-05 20:05:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:05:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:05:45 --> Utf8 Class Initialized
INFO - 2024-10-05 20:05:45 --> URI Class Initialized
INFO - 2024-10-05 20:05:45 --> Router Class Initialized
INFO - 2024-10-05 20:05:45 --> Output Class Initialized
INFO - 2024-10-05 20:05:45 --> Security Class Initialized
DEBUG - 2024-10-05 20:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:05:45 --> Input Class Initialized
INFO - 2024-10-05 20:05:45 --> Language Class Initialized
INFO - 2024-10-05 20:05:45 --> Language Class Initialized
INFO - 2024-10-05 20:05:45 --> Config Class Initialized
INFO - 2024-10-05 20:05:45 --> Loader Class Initialized
INFO - 2024-10-05 20:05:45 --> Helper loaded: url_helper
INFO - 2024-10-05 20:05:45 --> Helper loaded: file_helper
INFO - 2024-10-05 20:05:45 --> Helper loaded: form_helper
INFO - 2024-10-05 20:05:45 --> Helper loaded: my_helper
INFO - 2024-10-05 20:05:45 --> Database Driver Class Initialized
INFO - 2024-10-05 20:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:05:45 --> Controller Class Initialized
INFO - 2024-10-05 20:05:45 --> Final output sent to browser
DEBUG - 2024-10-05 20:05:45 --> Total execution time: 0.0355
INFO - 2024-10-05 20:06:03 --> Config Class Initialized
INFO - 2024-10-05 20:06:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:03 --> URI Class Initialized
INFO - 2024-10-05 20:06:03 --> Router Class Initialized
INFO - 2024-10-05 20:06:03 --> Output Class Initialized
INFO - 2024-10-05 20:06:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:03 --> Input Class Initialized
INFO - 2024-10-05 20:06:03 --> Language Class Initialized
INFO - 2024-10-05 20:06:03 --> Language Class Initialized
INFO - 2024-10-05 20:06:03 --> Config Class Initialized
INFO - 2024-10-05 20:06:03 --> Loader Class Initialized
INFO - 2024-10-05 20:06:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:03 --> Controller Class Initialized
INFO - 2024-10-05 20:06:03 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:03 --> Total execution time: 0.0329
INFO - 2024-10-05 20:06:03 --> Config Class Initialized
INFO - 2024-10-05 20:06:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:03 --> URI Class Initialized
INFO - 2024-10-05 20:06:03 --> Router Class Initialized
INFO - 2024-10-05 20:06:03 --> Output Class Initialized
INFO - 2024-10-05 20:06:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:03 --> Input Class Initialized
INFO - 2024-10-05 20:06:03 --> Language Class Initialized
INFO - 2024-10-05 20:06:03 --> Language Class Initialized
INFO - 2024-10-05 20:06:03 --> Config Class Initialized
INFO - 2024-10-05 20:06:03 --> Loader Class Initialized
INFO - 2024-10-05 20:06:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:03 --> Controller Class Initialized
INFO - 2024-10-05 20:06:09 --> Config Class Initialized
INFO - 2024-10-05 20:06:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:09 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:09 --> URI Class Initialized
INFO - 2024-10-05 20:06:09 --> Router Class Initialized
INFO - 2024-10-05 20:06:09 --> Output Class Initialized
INFO - 2024-10-05 20:06:09 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:09 --> Input Class Initialized
INFO - 2024-10-05 20:06:09 --> Language Class Initialized
INFO - 2024-10-05 20:06:09 --> Language Class Initialized
INFO - 2024-10-05 20:06:09 --> Config Class Initialized
INFO - 2024-10-05 20:06:09 --> Loader Class Initialized
INFO - 2024-10-05 20:06:09 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:09 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:09 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:09 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:09 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:09 --> Controller Class Initialized
INFO - 2024-10-05 20:06:09 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:09 --> Total execution time: 0.0759
INFO - 2024-10-05 20:06:19 --> Config Class Initialized
INFO - 2024-10-05 20:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:19 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:19 --> URI Class Initialized
INFO - 2024-10-05 20:06:19 --> Router Class Initialized
INFO - 2024-10-05 20:06:19 --> Output Class Initialized
INFO - 2024-10-05 20:06:19 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:19 --> Input Class Initialized
INFO - 2024-10-05 20:06:19 --> Language Class Initialized
INFO - 2024-10-05 20:06:19 --> Language Class Initialized
INFO - 2024-10-05 20:06:19 --> Config Class Initialized
INFO - 2024-10-05 20:06:19 --> Loader Class Initialized
INFO - 2024-10-05 20:06:19 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:19 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:19 --> Controller Class Initialized
INFO - 2024-10-05 20:06:19 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:19 --> Total execution time: 0.0302
INFO - 2024-10-05 20:06:19 --> Config Class Initialized
INFO - 2024-10-05 20:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:19 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:19 --> URI Class Initialized
INFO - 2024-10-05 20:06:19 --> Router Class Initialized
INFO - 2024-10-05 20:06:19 --> Output Class Initialized
INFO - 2024-10-05 20:06:19 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:19 --> Input Class Initialized
INFO - 2024-10-05 20:06:19 --> Language Class Initialized
INFO - 2024-10-05 20:06:19 --> Language Class Initialized
INFO - 2024-10-05 20:06:19 --> Config Class Initialized
INFO - 2024-10-05 20:06:19 --> Loader Class Initialized
INFO - 2024-10-05 20:06:19 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:19 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:19 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:19 --> Controller Class Initialized
INFO - 2024-10-05 20:06:26 --> Config Class Initialized
INFO - 2024-10-05 20:06:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:26 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:26 --> URI Class Initialized
INFO - 2024-10-05 20:06:26 --> Router Class Initialized
INFO - 2024-10-05 20:06:26 --> Output Class Initialized
INFO - 2024-10-05 20:06:26 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:26 --> Input Class Initialized
INFO - 2024-10-05 20:06:26 --> Language Class Initialized
INFO - 2024-10-05 20:06:26 --> Language Class Initialized
INFO - 2024-10-05 20:06:26 --> Config Class Initialized
INFO - 2024-10-05 20:06:26 --> Loader Class Initialized
INFO - 2024-10-05 20:06:26 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:26 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:26 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:26 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:26 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:26 --> Controller Class Initialized
INFO - 2024-10-05 20:06:26 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:26 --> Total execution time: 0.0375
INFO - 2024-10-05 20:06:43 --> Config Class Initialized
INFO - 2024-10-05 20:06:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:43 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:43 --> URI Class Initialized
INFO - 2024-10-05 20:06:43 --> Router Class Initialized
INFO - 2024-10-05 20:06:43 --> Output Class Initialized
INFO - 2024-10-05 20:06:43 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:43 --> Input Class Initialized
INFO - 2024-10-05 20:06:43 --> Language Class Initialized
INFO - 2024-10-05 20:06:43 --> Language Class Initialized
INFO - 2024-10-05 20:06:43 --> Config Class Initialized
INFO - 2024-10-05 20:06:43 --> Loader Class Initialized
INFO - 2024-10-05 20:06:43 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:43 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:43 --> Controller Class Initialized
INFO - 2024-10-05 20:06:43 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:43 --> Total execution time: 0.0312
INFO - 2024-10-05 20:06:43 --> Config Class Initialized
INFO - 2024-10-05 20:06:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:43 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:43 --> URI Class Initialized
INFO - 2024-10-05 20:06:43 --> Router Class Initialized
INFO - 2024-10-05 20:06:43 --> Output Class Initialized
INFO - 2024-10-05 20:06:43 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:43 --> Input Class Initialized
INFO - 2024-10-05 20:06:43 --> Language Class Initialized
INFO - 2024-10-05 20:06:43 --> Language Class Initialized
INFO - 2024-10-05 20:06:43 --> Config Class Initialized
INFO - 2024-10-05 20:06:43 --> Loader Class Initialized
INFO - 2024-10-05 20:06:43 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:43 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:43 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:43 --> Controller Class Initialized
INFO - 2024-10-05 20:06:55 --> Config Class Initialized
INFO - 2024-10-05 20:06:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:06:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:06:55 --> Utf8 Class Initialized
INFO - 2024-10-05 20:06:55 --> URI Class Initialized
INFO - 2024-10-05 20:06:55 --> Router Class Initialized
INFO - 2024-10-05 20:06:55 --> Output Class Initialized
INFO - 2024-10-05 20:06:55 --> Security Class Initialized
DEBUG - 2024-10-05 20:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:06:55 --> Input Class Initialized
INFO - 2024-10-05 20:06:55 --> Language Class Initialized
INFO - 2024-10-05 20:06:55 --> Language Class Initialized
INFO - 2024-10-05 20:06:55 --> Config Class Initialized
INFO - 2024-10-05 20:06:55 --> Loader Class Initialized
INFO - 2024-10-05 20:06:55 --> Helper loaded: url_helper
INFO - 2024-10-05 20:06:55 --> Helper loaded: file_helper
INFO - 2024-10-05 20:06:55 --> Helper loaded: form_helper
INFO - 2024-10-05 20:06:55 --> Helper loaded: my_helper
INFO - 2024-10-05 20:06:55 --> Database Driver Class Initialized
INFO - 2024-10-05 20:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:06:55 --> Controller Class Initialized
INFO - 2024-10-05 20:06:55 --> Final output sent to browser
DEBUG - 2024-10-05 20:06:55 --> Total execution time: 0.0363
INFO - 2024-10-05 20:07:14 --> Config Class Initialized
INFO - 2024-10-05 20:07:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:07:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:07:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:07:14 --> URI Class Initialized
INFO - 2024-10-05 20:07:14 --> Router Class Initialized
INFO - 2024-10-05 20:07:14 --> Output Class Initialized
INFO - 2024-10-05 20:07:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:07:14 --> Input Class Initialized
INFO - 2024-10-05 20:07:14 --> Language Class Initialized
INFO - 2024-10-05 20:07:14 --> Language Class Initialized
INFO - 2024-10-05 20:07:14 --> Config Class Initialized
INFO - 2024-10-05 20:07:14 --> Loader Class Initialized
INFO - 2024-10-05 20:07:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:07:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:07:14 --> Controller Class Initialized
INFO - 2024-10-05 20:07:14 --> Final output sent to browser
DEBUG - 2024-10-05 20:07:14 --> Total execution time: 0.0384
INFO - 2024-10-05 20:07:14 --> Config Class Initialized
INFO - 2024-10-05 20:07:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:07:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:07:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:07:14 --> URI Class Initialized
INFO - 2024-10-05 20:07:14 --> Router Class Initialized
INFO - 2024-10-05 20:07:14 --> Output Class Initialized
INFO - 2024-10-05 20:07:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:07:14 --> Input Class Initialized
INFO - 2024-10-05 20:07:14 --> Language Class Initialized
INFO - 2024-10-05 20:07:14 --> Language Class Initialized
INFO - 2024-10-05 20:07:14 --> Config Class Initialized
INFO - 2024-10-05 20:07:14 --> Loader Class Initialized
INFO - 2024-10-05 20:07:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:07:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:07:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:07:14 --> Controller Class Initialized
INFO - 2024-10-05 20:07:36 --> Config Class Initialized
INFO - 2024-10-05 20:07:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:07:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:07:36 --> Utf8 Class Initialized
INFO - 2024-10-05 20:07:36 --> URI Class Initialized
INFO - 2024-10-05 20:07:36 --> Router Class Initialized
INFO - 2024-10-05 20:07:36 --> Output Class Initialized
INFO - 2024-10-05 20:07:36 --> Security Class Initialized
DEBUG - 2024-10-05 20:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:07:36 --> Input Class Initialized
INFO - 2024-10-05 20:07:36 --> Language Class Initialized
INFO - 2024-10-05 20:07:36 --> Language Class Initialized
INFO - 2024-10-05 20:07:36 --> Config Class Initialized
INFO - 2024-10-05 20:07:36 --> Loader Class Initialized
INFO - 2024-10-05 20:07:36 --> Helper loaded: url_helper
INFO - 2024-10-05 20:07:36 --> Helper loaded: file_helper
INFO - 2024-10-05 20:07:36 --> Helper loaded: form_helper
INFO - 2024-10-05 20:07:36 --> Helper loaded: my_helper
INFO - 2024-10-05 20:07:36 --> Database Driver Class Initialized
INFO - 2024-10-05 20:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:07:36 --> Controller Class Initialized
INFO - 2024-10-05 20:07:36 --> Final output sent to browser
DEBUG - 2024-10-05 20:07:36 --> Total execution time: 0.0331
INFO - 2024-10-05 20:07:46 --> Config Class Initialized
INFO - 2024-10-05 20:07:46 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:07:46 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:07:46 --> Utf8 Class Initialized
INFO - 2024-10-05 20:07:46 --> URI Class Initialized
INFO - 2024-10-05 20:07:46 --> Router Class Initialized
INFO - 2024-10-05 20:07:46 --> Output Class Initialized
INFO - 2024-10-05 20:07:46 --> Security Class Initialized
DEBUG - 2024-10-05 20:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:07:46 --> Input Class Initialized
INFO - 2024-10-05 20:07:46 --> Language Class Initialized
INFO - 2024-10-05 20:07:46 --> Language Class Initialized
INFO - 2024-10-05 20:07:46 --> Config Class Initialized
INFO - 2024-10-05 20:07:46 --> Loader Class Initialized
INFO - 2024-10-05 20:07:46 --> Helper loaded: url_helper
INFO - 2024-10-05 20:07:46 --> Helper loaded: file_helper
INFO - 2024-10-05 20:07:46 --> Helper loaded: form_helper
INFO - 2024-10-05 20:07:46 --> Helper loaded: my_helper
INFO - 2024-10-05 20:07:46 --> Database Driver Class Initialized
INFO - 2024-10-05 20:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:07:46 --> Controller Class Initialized
INFO - 2024-10-05 20:07:46 --> Final output sent to browser
DEBUG - 2024-10-05 20:07:46 --> Total execution time: 0.0323
INFO - 2024-10-05 20:07:47 --> Config Class Initialized
INFO - 2024-10-05 20:07:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:07:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:07:47 --> Utf8 Class Initialized
INFO - 2024-10-05 20:07:47 --> URI Class Initialized
INFO - 2024-10-05 20:07:47 --> Router Class Initialized
INFO - 2024-10-05 20:07:47 --> Output Class Initialized
INFO - 2024-10-05 20:07:47 --> Security Class Initialized
DEBUG - 2024-10-05 20:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:07:47 --> Input Class Initialized
INFO - 2024-10-05 20:07:47 --> Language Class Initialized
INFO - 2024-10-05 20:07:47 --> Language Class Initialized
INFO - 2024-10-05 20:07:47 --> Config Class Initialized
INFO - 2024-10-05 20:07:47 --> Loader Class Initialized
INFO - 2024-10-05 20:07:47 --> Helper loaded: url_helper
INFO - 2024-10-05 20:07:47 --> Helper loaded: file_helper
INFO - 2024-10-05 20:07:47 --> Helper loaded: form_helper
INFO - 2024-10-05 20:07:47 --> Helper loaded: my_helper
INFO - 2024-10-05 20:07:47 --> Database Driver Class Initialized
INFO - 2024-10-05 20:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:07:47 --> Controller Class Initialized
INFO - 2024-10-05 20:08:09 --> Config Class Initialized
INFO - 2024-10-05 20:08:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:09 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:09 --> URI Class Initialized
INFO - 2024-10-05 20:08:09 --> Router Class Initialized
INFO - 2024-10-05 20:08:09 --> Output Class Initialized
INFO - 2024-10-05 20:08:09 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:09 --> Input Class Initialized
INFO - 2024-10-05 20:08:09 --> Language Class Initialized
INFO - 2024-10-05 20:08:09 --> Language Class Initialized
INFO - 2024-10-05 20:08:09 --> Config Class Initialized
INFO - 2024-10-05 20:08:09 --> Loader Class Initialized
INFO - 2024-10-05 20:08:09 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:09 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:09 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:09 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:09 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:09 --> Controller Class Initialized
INFO - 2024-10-05 20:08:09 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:09 --> Total execution time: 0.0285
INFO - 2024-10-05 20:08:18 --> Config Class Initialized
INFO - 2024-10-05 20:08:18 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:18 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:18 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:18 --> URI Class Initialized
INFO - 2024-10-05 20:08:18 --> Router Class Initialized
INFO - 2024-10-05 20:08:18 --> Output Class Initialized
INFO - 2024-10-05 20:08:18 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:18 --> Input Class Initialized
INFO - 2024-10-05 20:08:18 --> Language Class Initialized
INFO - 2024-10-05 20:08:18 --> Language Class Initialized
INFO - 2024-10-05 20:08:18 --> Config Class Initialized
INFO - 2024-10-05 20:08:18 --> Loader Class Initialized
INFO - 2024-10-05 20:08:18 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:18 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:18 --> Controller Class Initialized
INFO - 2024-10-05 20:08:18 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:18 --> Total execution time: 0.0455
INFO - 2024-10-05 20:08:18 --> Config Class Initialized
INFO - 2024-10-05 20:08:18 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:18 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:18 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:18 --> URI Class Initialized
INFO - 2024-10-05 20:08:18 --> Router Class Initialized
INFO - 2024-10-05 20:08:18 --> Output Class Initialized
INFO - 2024-10-05 20:08:18 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:18 --> Input Class Initialized
INFO - 2024-10-05 20:08:18 --> Language Class Initialized
INFO - 2024-10-05 20:08:18 --> Language Class Initialized
INFO - 2024-10-05 20:08:18 --> Config Class Initialized
INFO - 2024-10-05 20:08:18 --> Loader Class Initialized
INFO - 2024-10-05 20:08:18 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:18 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:18 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:18 --> Controller Class Initialized
INFO - 2024-10-05 20:08:22 --> Config Class Initialized
INFO - 2024-10-05 20:08:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:22 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:22 --> URI Class Initialized
INFO - 2024-10-05 20:08:22 --> Router Class Initialized
INFO - 2024-10-05 20:08:22 --> Output Class Initialized
INFO - 2024-10-05 20:08:22 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:22 --> Input Class Initialized
INFO - 2024-10-05 20:08:22 --> Language Class Initialized
INFO - 2024-10-05 20:08:22 --> Language Class Initialized
INFO - 2024-10-05 20:08:22 --> Config Class Initialized
INFO - 2024-10-05 20:08:22 --> Loader Class Initialized
INFO - 2024-10-05 20:08:22 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:22 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:22 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:22 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:22 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:22 --> Controller Class Initialized
INFO - 2024-10-05 20:08:22 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:22 --> Total execution time: 0.0369
INFO - 2024-10-05 20:08:32 --> Config Class Initialized
INFO - 2024-10-05 20:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:32 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:32 --> URI Class Initialized
INFO - 2024-10-05 20:08:32 --> Router Class Initialized
INFO - 2024-10-05 20:08:32 --> Output Class Initialized
INFO - 2024-10-05 20:08:32 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:32 --> Input Class Initialized
INFO - 2024-10-05 20:08:32 --> Language Class Initialized
INFO - 2024-10-05 20:08:32 --> Language Class Initialized
INFO - 2024-10-05 20:08:32 --> Config Class Initialized
INFO - 2024-10-05 20:08:32 --> Loader Class Initialized
INFO - 2024-10-05 20:08:32 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:32 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:32 --> Controller Class Initialized
INFO - 2024-10-05 20:08:32 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:32 --> Total execution time: 0.0349
INFO - 2024-10-05 20:08:32 --> Config Class Initialized
INFO - 2024-10-05 20:08:32 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:32 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:32 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:32 --> URI Class Initialized
INFO - 2024-10-05 20:08:32 --> Router Class Initialized
INFO - 2024-10-05 20:08:32 --> Output Class Initialized
INFO - 2024-10-05 20:08:32 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:32 --> Input Class Initialized
INFO - 2024-10-05 20:08:32 --> Language Class Initialized
INFO - 2024-10-05 20:08:32 --> Language Class Initialized
INFO - 2024-10-05 20:08:32 --> Config Class Initialized
INFO - 2024-10-05 20:08:32 --> Loader Class Initialized
INFO - 2024-10-05 20:08:32 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:32 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:32 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:32 --> Controller Class Initialized
INFO - 2024-10-05 20:08:37 --> Config Class Initialized
INFO - 2024-10-05 20:08:37 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:37 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:37 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:37 --> URI Class Initialized
INFO - 2024-10-05 20:08:37 --> Router Class Initialized
INFO - 2024-10-05 20:08:37 --> Output Class Initialized
INFO - 2024-10-05 20:08:37 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:37 --> Input Class Initialized
INFO - 2024-10-05 20:08:37 --> Language Class Initialized
INFO - 2024-10-05 20:08:37 --> Language Class Initialized
INFO - 2024-10-05 20:08:37 --> Config Class Initialized
INFO - 2024-10-05 20:08:37 --> Loader Class Initialized
INFO - 2024-10-05 20:08:37 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:37 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:37 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:37 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:37 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:37 --> Controller Class Initialized
INFO - 2024-10-05 20:08:42 --> Config Class Initialized
INFO - 2024-10-05 20:08:42 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:42 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:42 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:42 --> URI Class Initialized
INFO - 2024-10-05 20:08:42 --> Router Class Initialized
INFO - 2024-10-05 20:08:42 --> Output Class Initialized
INFO - 2024-10-05 20:08:42 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:42 --> Input Class Initialized
INFO - 2024-10-05 20:08:42 --> Language Class Initialized
INFO - 2024-10-05 20:08:42 --> Language Class Initialized
INFO - 2024-10-05 20:08:42 --> Config Class Initialized
INFO - 2024-10-05 20:08:42 --> Loader Class Initialized
INFO - 2024-10-05 20:08:42 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:42 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:42 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:42 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:42 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:42 --> Controller Class Initialized
DEBUG - 2024-10-05 20:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:08:42 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:42 --> Total execution time: 0.0299
INFO - 2024-10-05 20:08:45 --> Config Class Initialized
INFO - 2024-10-05 20:08:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:45 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:45 --> URI Class Initialized
INFO - 2024-10-05 20:08:45 --> Router Class Initialized
INFO - 2024-10-05 20:08:45 --> Output Class Initialized
INFO - 2024-10-05 20:08:45 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:45 --> Input Class Initialized
INFO - 2024-10-05 20:08:45 --> Language Class Initialized
INFO - 2024-10-05 20:08:45 --> Language Class Initialized
INFO - 2024-10-05 20:08:45 --> Config Class Initialized
INFO - 2024-10-05 20:08:45 --> Loader Class Initialized
INFO - 2024-10-05 20:08:45 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:45 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:45 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:45 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:45 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:45 --> Controller Class Initialized
DEBUG - 2024-10-05 20:08:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:08:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:08:45 --> Final output sent to browser
DEBUG - 2024-10-05 20:08:45 --> Total execution time: 0.0420
INFO - 2024-10-05 20:08:48 --> Config Class Initialized
INFO - 2024-10-05 20:08:48 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:08:48 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:08:48 --> Utf8 Class Initialized
INFO - 2024-10-05 20:08:48 --> URI Class Initialized
INFO - 2024-10-05 20:08:48 --> Router Class Initialized
INFO - 2024-10-05 20:08:48 --> Output Class Initialized
INFO - 2024-10-05 20:08:48 --> Security Class Initialized
DEBUG - 2024-10-05 20:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:08:48 --> Input Class Initialized
INFO - 2024-10-05 20:08:48 --> Language Class Initialized
INFO - 2024-10-05 20:08:48 --> Language Class Initialized
INFO - 2024-10-05 20:08:48 --> Config Class Initialized
INFO - 2024-10-05 20:08:48 --> Loader Class Initialized
INFO - 2024-10-05 20:08:48 --> Helper loaded: url_helper
INFO - 2024-10-05 20:08:48 --> Helper loaded: file_helper
INFO - 2024-10-05 20:08:48 --> Helper loaded: form_helper
INFO - 2024-10-05 20:08:48 --> Helper loaded: my_helper
INFO - 2024-10-05 20:08:48 --> Database Driver Class Initialized
INFO - 2024-10-05 20:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:08:48 --> Controller Class Initialized
INFO - 2024-10-05 20:13:18 --> Config Class Initialized
INFO - 2024-10-05 20:13:18 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:18 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:18 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:18 --> URI Class Initialized
INFO - 2024-10-05 20:13:18 --> Router Class Initialized
INFO - 2024-10-05 20:13:18 --> Output Class Initialized
INFO - 2024-10-05 20:13:18 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:18 --> Input Class Initialized
INFO - 2024-10-05 20:13:18 --> Language Class Initialized
INFO - 2024-10-05 20:13:18 --> Language Class Initialized
INFO - 2024-10-05 20:13:18 --> Config Class Initialized
INFO - 2024-10-05 20:13:18 --> Loader Class Initialized
INFO - 2024-10-05 20:13:18 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:18 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:18 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:18 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:18 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:18 --> Controller Class Initialized
DEBUG - 2024-10-05 20:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 20:13:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:13:18 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:18 --> Total execution time: 0.0317
INFO - 2024-10-05 20:13:40 --> Config Class Initialized
INFO - 2024-10-05 20:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:40 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:40 --> URI Class Initialized
INFO - 2024-10-05 20:13:40 --> Router Class Initialized
INFO - 2024-10-05 20:13:40 --> Output Class Initialized
INFO - 2024-10-05 20:13:40 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:40 --> Input Class Initialized
INFO - 2024-10-05 20:13:40 --> Language Class Initialized
INFO - 2024-10-05 20:13:40 --> Language Class Initialized
INFO - 2024-10-05 20:13:40 --> Config Class Initialized
INFO - 2024-10-05 20:13:40 --> Loader Class Initialized
INFO - 2024-10-05 20:13:40 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:40 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:40 --> Controller Class Initialized
INFO - 2024-10-05 20:13:40 --> Config Class Initialized
INFO - 2024-10-05 20:13:40 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:40 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:40 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:40 --> URI Class Initialized
INFO - 2024-10-05 20:13:40 --> Router Class Initialized
INFO - 2024-10-05 20:13:40 --> Output Class Initialized
INFO - 2024-10-05 20:13:40 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:40 --> Input Class Initialized
INFO - 2024-10-05 20:13:40 --> Language Class Initialized
INFO - 2024-10-05 20:13:40 --> Language Class Initialized
INFO - 2024-10-05 20:13:40 --> Config Class Initialized
INFO - 2024-10-05 20:13:40 --> Loader Class Initialized
INFO - 2024-10-05 20:13:40 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:40 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:40 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:40 --> Controller Class Initialized
DEBUG - 2024-10-05 20:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:13:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:13:40 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:40 --> Total execution time: 0.0319
INFO - 2024-10-05 20:13:42 --> Config Class Initialized
INFO - 2024-10-05 20:13:42 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:42 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:42 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:42 --> URI Class Initialized
INFO - 2024-10-05 20:13:42 --> Router Class Initialized
INFO - 2024-10-05 20:13:42 --> Output Class Initialized
INFO - 2024-10-05 20:13:42 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:42 --> Input Class Initialized
INFO - 2024-10-05 20:13:42 --> Language Class Initialized
INFO - 2024-10-05 20:13:42 --> Language Class Initialized
INFO - 2024-10-05 20:13:42 --> Config Class Initialized
INFO - 2024-10-05 20:13:42 --> Loader Class Initialized
INFO - 2024-10-05 20:13:42 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:42 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:42 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:42 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:42 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:42 --> Controller Class Initialized
INFO - 2024-10-05 20:13:42 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:42 --> Total execution time: 0.0394
INFO - 2024-10-05 20:13:45 --> Config Class Initialized
INFO - 2024-10-05 20:13:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:45 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:45 --> URI Class Initialized
INFO - 2024-10-05 20:13:45 --> Router Class Initialized
INFO - 2024-10-05 20:13:45 --> Output Class Initialized
INFO - 2024-10-05 20:13:45 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:45 --> Input Class Initialized
INFO - 2024-10-05 20:13:45 --> Language Class Initialized
INFO - 2024-10-05 20:13:45 --> Language Class Initialized
INFO - 2024-10-05 20:13:45 --> Config Class Initialized
INFO - 2024-10-05 20:13:45 --> Loader Class Initialized
INFO - 2024-10-05 20:13:45 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:45 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:45 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:45 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:45 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:45 --> Controller Class Initialized
DEBUG - 2024-10-05 20:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 20:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:13:45 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:45 --> Total execution time: 0.0314
INFO - 2024-10-05 20:13:52 --> Config Class Initialized
INFO - 2024-10-05 20:13:52 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:52 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:52 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:52 --> URI Class Initialized
INFO - 2024-10-05 20:13:52 --> Router Class Initialized
INFO - 2024-10-05 20:13:52 --> Output Class Initialized
INFO - 2024-10-05 20:13:52 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:52 --> Input Class Initialized
INFO - 2024-10-05 20:13:52 --> Language Class Initialized
INFO - 2024-10-05 20:13:52 --> Language Class Initialized
INFO - 2024-10-05 20:13:52 --> Config Class Initialized
INFO - 2024-10-05 20:13:52 --> Loader Class Initialized
INFO - 2024-10-05 20:13:52 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:52 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:52 --> Controller Class Initialized
INFO - 2024-10-05 20:13:52 --> Config Class Initialized
INFO - 2024-10-05 20:13:52 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:52 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:52 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:52 --> URI Class Initialized
INFO - 2024-10-05 20:13:52 --> Router Class Initialized
INFO - 2024-10-05 20:13:52 --> Output Class Initialized
INFO - 2024-10-05 20:13:52 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:52 --> Input Class Initialized
INFO - 2024-10-05 20:13:52 --> Language Class Initialized
INFO - 2024-10-05 20:13:52 --> Language Class Initialized
INFO - 2024-10-05 20:13:52 --> Config Class Initialized
INFO - 2024-10-05 20:13:52 --> Loader Class Initialized
INFO - 2024-10-05 20:13:52 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:52 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:52 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:52 --> Controller Class Initialized
DEBUG - 2024-10-05 20:13:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:13:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:13:52 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:52 --> Total execution time: 0.0314
INFO - 2024-10-05 20:13:53 --> Config Class Initialized
INFO - 2024-10-05 20:13:53 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:53 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:53 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:53 --> URI Class Initialized
INFO - 2024-10-05 20:13:53 --> Router Class Initialized
INFO - 2024-10-05 20:13:53 --> Output Class Initialized
INFO - 2024-10-05 20:13:53 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:53 --> Input Class Initialized
INFO - 2024-10-05 20:13:53 --> Language Class Initialized
INFO - 2024-10-05 20:13:53 --> Language Class Initialized
INFO - 2024-10-05 20:13:53 --> Config Class Initialized
INFO - 2024-10-05 20:13:53 --> Loader Class Initialized
INFO - 2024-10-05 20:13:53 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:53 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:53 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:53 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:53 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:53 --> Controller Class Initialized
INFO - 2024-10-05 20:13:53 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:53 --> Total execution time: 0.0314
INFO - 2024-10-05 20:13:56 --> Config Class Initialized
INFO - 2024-10-05 20:13:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:13:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:13:56 --> Utf8 Class Initialized
INFO - 2024-10-05 20:13:56 --> URI Class Initialized
INFO - 2024-10-05 20:13:56 --> Router Class Initialized
INFO - 2024-10-05 20:13:56 --> Output Class Initialized
INFO - 2024-10-05 20:13:56 --> Security Class Initialized
DEBUG - 2024-10-05 20:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:13:56 --> Input Class Initialized
INFO - 2024-10-05 20:13:56 --> Language Class Initialized
INFO - 2024-10-05 20:13:56 --> Language Class Initialized
INFO - 2024-10-05 20:13:56 --> Config Class Initialized
INFO - 2024-10-05 20:13:56 --> Loader Class Initialized
INFO - 2024-10-05 20:13:56 --> Helper loaded: url_helper
INFO - 2024-10-05 20:13:56 --> Helper loaded: file_helper
INFO - 2024-10-05 20:13:56 --> Helper loaded: form_helper
INFO - 2024-10-05 20:13:56 --> Helper loaded: my_helper
INFO - 2024-10-05 20:13:56 --> Database Driver Class Initialized
INFO - 2024-10-05 20:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:13:56 --> Controller Class Initialized
DEBUG - 2024-10-05 20:13:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:13:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:13:56 --> Final output sent to browser
DEBUG - 2024-10-05 20:13:56 --> Total execution time: 0.0365
INFO - 2024-10-05 20:14:00 --> Config Class Initialized
INFO - 2024-10-05 20:14:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:00 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:00 --> URI Class Initialized
INFO - 2024-10-05 20:14:01 --> Router Class Initialized
INFO - 2024-10-05 20:14:01 --> Output Class Initialized
INFO - 2024-10-05 20:14:01 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:01 --> Input Class Initialized
INFO - 2024-10-05 20:14:01 --> Language Class Initialized
INFO - 2024-10-05 20:14:01 --> Language Class Initialized
INFO - 2024-10-05 20:14:01 --> Config Class Initialized
INFO - 2024-10-05 20:14:01 --> Loader Class Initialized
INFO - 2024-10-05 20:14:01 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:01 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:01 --> Controller Class Initialized
DEBUG - 2024-10-05 20:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 20:14:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:14:01 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:01 --> Total execution time: 0.0362
INFO - 2024-10-05 20:14:01 --> Config Class Initialized
INFO - 2024-10-05 20:14:01 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:01 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:01 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:01 --> URI Class Initialized
INFO - 2024-10-05 20:14:01 --> Router Class Initialized
INFO - 2024-10-05 20:14:01 --> Output Class Initialized
INFO - 2024-10-05 20:14:01 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:01 --> Input Class Initialized
INFO - 2024-10-05 20:14:01 --> Language Class Initialized
INFO - 2024-10-05 20:14:01 --> Language Class Initialized
INFO - 2024-10-05 20:14:01 --> Config Class Initialized
INFO - 2024-10-05 20:14:01 --> Loader Class Initialized
INFO - 2024-10-05 20:14:01 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:01 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:01 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:01 --> Controller Class Initialized
INFO - 2024-10-05 20:14:03 --> Config Class Initialized
INFO - 2024-10-05 20:14:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:03 --> URI Class Initialized
INFO - 2024-10-05 20:14:03 --> Router Class Initialized
INFO - 2024-10-05 20:14:03 --> Output Class Initialized
INFO - 2024-10-05 20:14:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:03 --> Input Class Initialized
INFO - 2024-10-05 20:14:03 --> Language Class Initialized
INFO - 2024-10-05 20:14:03 --> Language Class Initialized
INFO - 2024-10-05 20:14:03 --> Config Class Initialized
INFO - 2024-10-05 20:14:03 --> Loader Class Initialized
INFO - 2024-10-05 20:14:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:03 --> Controller Class Initialized
DEBUG - 2024-10-05 20:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 20:14:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:14:03 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:03 --> Total execution time: 0.0446
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:10 --> URI Class Initialized
INFO - 2024-10-05 20:14:10 --> Router Class Initialized
INFO - 2024-10-05 20:14:10 --> Output Class Initialized
INFO - 2024-10-05 20:14:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:10 --> Input Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Loader Class Initialized
INFO - 2024-10-05 20:14:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:10 --> Controller Class Initialized
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:10 --> URI Class Initialized
INFO - 2024-10-05 20:14:10 --> Router Class Initialized
INFO - 2024-10-05 20:14:10 --> Output Class Initialized
INFO - 2024-10-05 20:14:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:10 --> Input Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Loader Class Initialized
INFO - 2024-10-05 20:14:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:10 --> Controller Class Initialized
DEBUG - 2024-10-05 20:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 20:14:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:14:10 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:10 --> Total execution time: 0.0303
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:10 --> URI Class Initialized
INFO - 2024-10-05 20:14:10 --> Router Class Initialized
INFO - 2024-10-05 20:14:10 --> Output Class Initialized
INFO - 2024-10-05 20:14:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:10 --> Input Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Language Class Initialized
INFO - 2024-10-05 20:14:10 --> Config Class Initialized
INFO - 2024-10-05 20:14:10 --> Loader Class Initialized
INFO - 2024-10-05 20:14:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:10 --> Controller Class Initialized
INFO - 2024-10-05 20:14:12 --> Config Class Initialized
INFO - 2024-10-05 20:14:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:12 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:12 --> URI Class Initialized
INFO - 2024-10-05 20:14:12 --> Router Class Initialized
INFO - 2024-10-05 20:14:12 --> Output Class Initialized
INFO - 2024-10-05 20:14:12 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:12 --> Input Class Initialized
INFO - 2024-10-05 20:14:12 --> Language Class Initialized
INFO - 2024-10-05 20:14:12 --> Language Class Initialized
INFO - 2024-10-05 20:14:12 --> Config Class Initialized
INFO - 2024-10-05 20:14:12 --> Loader Class Initialized
INFO - 2024-10-05 20:14:12 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:12 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:12 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:12 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:12 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:12 --> Controller Class Initialized
INFO - 2024-10-05 20:14:12 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:12 --> Total execution time: 0.0341
INFO - 2024-10-05 20:14:17 --> Config Class Initialized
INFO - 2024-10-05 20:14:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:17 --> URI Class Initialized
INFO - 2024-10-05 20:14:17 --> Router Class Initialized
INFO - 2024-10-05 20:14:17 --> Output Class Initialized
INFO - 2024-10-05 20:14:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:17 --> Input Class Initialized
INFO - 2024-10-05 20:14:17 --> Language Class Initialized
INFO - 2024-10-05 20:14:17 --> Language Class Initialized
INFO - 2024-10-05 20:14:17 --> Config Class Initialized
INFO - 2024-10-05 20:14:17 --> Loader Class Initialized
INFO - 2024-10-05 20:14:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:17 --> Controller Class Initialized
INFO - 2024-10-05 20:14:17 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:17 --> Total execution time: 0.0509
INFO - 2024-10-05 20:14:19 --> Config Class Initialized
INFO - 2024-10-05 20:14:19 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:19 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:19 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:19 --> URI Class Initialized
INFO - 2024-10-05 20:14:19 --> Router Class Initialized
INFO - 2024-10-05 20:14:19 --> Output Class Initialized
INFO - 2024-10-05 20:14:19 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:19 --> Input Class Initialized
INFO - 2024-10-05 20:14:19 --> Language Class Initialized
INFO - 2024-10-05 20:14:19 --> Language Class Initialized
INFO - 2024-10-05 20:14:19 --> Config Class Initialized
INFO - 2024-10-05 20:14:19 --> Loader Class Initialized
INFO - 2024-10-05 20:14:19 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:19 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:19 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:19 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:19 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:19 --> Controller Class Initialized
INFO - 2024-10-05 20:14:19 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:19 --> Total execution time: 0.1646
INFO - 2024-10-05 20:14:21 --> Config Class Initialized
INFO - 2024-10-05 20:14:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:21 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:21 --> URI Class Initialized
INFO - 2024-10-05 20:14:21 --> Router Class Initialized
INFO - 2024-10-05 20:14:21 --> Output Class Initialized
INFO - 2024-10-05 20:14:21 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:21 --> Input Class Initialized
INFO - 2024-10-05 20:14:21 --> Language Class Initialized
INFO - 2024-10-05 20:14:21 --> Language Class Initialized
INFO - 2024-10-05 20:14:21 --> Config Class Initialized
INFO - 2024-10-05 20:14:21 --> Loader Class Initialized
INFO - 2024-10-05 20:14:21 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:21 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:21 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:21 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:21 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:21 --> Controller Class Initialized
DEBUG - 2024-10-05 20:14:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:14:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:14:21 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:21 --> Total execution time: 0.0298
INFO - 2024-10-05 20:14:23 --> Config Class Initialized
INFO - 2024-10-05 20:14:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:23 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:23 --> URI Class Initialized
INFO - 2024-10-05 20:14:23 --> Router Class Initialized
INFO - 2024-10-05 20:14:23 --> Output Class Initialized
INFO - 2024-10-05 20:14:23 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:23 --> Input Class Initialized
INFO - 2024-10-05 20:14:23 --> Language Class Initialized
INFO - 2024-10-05 20:14:23 --> Language Class Initialized
INFO - 2024-10-05 20:14:23 --> Config Class Initialized
INFO - 2024-10-05 20:14:23 --> Loader Class Initialized
INFO - 2024-10-05 20:14:23 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:23 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:23 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:23 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:23 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:23 --> Controller Class Initialized
DEBUG - 2024-10-05 20:14:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 20:14:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:14:23 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:23 --> Total execution time: 0.0404
INFO - 2024-10-05 20:14:24 --> Config Class Initialized
INFO - 2024-10-05 20:14:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:24 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:24 --> URI Class Initialized
INFO - 2024-10-05 20:14:24 --> Router Class Initialized
INFO - 2024-10-05 20:14:24 --> Output Class Initialized
INFO - 2024-10-05 20:14:24 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:24 --> Input Class Initialized
INFO - 2024-10-05 20:14:24 --> Language Class Initialized
INFO - 2024-10-05 20:14:24 --> Language Class Initialized
INFO - 2024-10-05 20:14:24 --> Config Class Initialized
INFO - 2024-10-05 20:14:24 --> Loader Class Initialized
INFO - 2024-10-05 20:14:24 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:24 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:24 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:24 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:24 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:24 --> Controller Class Initialized
INFO - 2024-10-05 20:14:26 --> Config Class Initialized
INFO - 2024-10-05 20:14:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:26 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:26 --> URI Class Initialized
INFO - 2024-10-05 20:14:26 --> Router Class Initialized
INFO - 2024-10-05 20:14:26 --> Output Class Initialized
INFO - 2024-10-05 20:14:26 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:26 --> Input Class Initialized
INFO - 2024-10-05 20:14:26 --> Language Class Initialized
INFO - 2024-10-05 20:14:26 --> Language Class Initialized
INFO - 2024-10-05 20:14:26 --> Config Class Initialized
INFO - 2024-10-05 20:14:26 --> Loader Class Initialized
INFO - 2024-10-05 20:14:26 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:26 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:26 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:26 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:26 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:26 --> Controller Class Initialized
INFO - 2024-10-05 20:14:26 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:26 --> Total execution time: 0.0312
INFO - 2024-10-05 20:14:49 --> Config Class Initialized
INFO - 2024-10-05 20:14:49 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:49 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:49 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:49 --> URI Class Initialized
INFO - 2024-10-05 20:14:49 --> Router Class Initialized
INFO - 2024-10-05 20:14:49 --> Output Class Initialized
INFO - 2024-10-05 20:14:49 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:49 --> Input Class Initialized
INFO - 2024-10-05 20:14:49 --> Language Class Initialized
INFO - 2024-10-05 20:14:49 --> Language Class Initialized
INFO - 2024-10-05 20:14:49 --> Config Class Initialized
INFO - 2024-10-05 20:14:49 --> Loader Class Initialized
INFO - 2024-10-05 20:14:49 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:49 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:49 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:49 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:49 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:49 --> Controller Class Initialized
INFO - 2024-10-05 20:14:49 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:49 --> Total execution time: 0.0357
INFO - 2024-10-05 20:14:50 --> Config Class Initialized
INFO - 2024-10-05 20:14:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:50 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:50 --> URI Class Initialized
INFO - 2024-10-05 20:14:50 --> Router Class Initialized
INFO - 2024-10-05 20:14:50 --> Output Class Initialized
INFO - 2024-10-05 20:14:50 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:50 --> Input Class Initialized
INFO - 2024-10-05 20:14:50 --> Language Class Initialized
INFO - 2024-10-05 20:14:50 --> Language Class Initialized
INFO - 2024-10-05 20:14:50 --> Config Class Initialized
INFO - 2024-10-05 20:14:50 --> Loader Class Initialized
INFO - 2024-10-05 20:14:50 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:50 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:50 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:50 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:50 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:50 --> Controller Class Initialized
INFO - 2024-10-05 20:14:56 --> Config Class Initialized
INFO - 2024-10-05 20:14:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:14:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:14:56 --> Utf8 Class Initialized
INFO - 2024-10-05 20:14:56 --> URI Class Initialized
INFO - 2024-10-05 20:14:56 --> Router Class Initialized
INFO - 2024-10-05 20:14:56 --> Output Class Initialized
INFO - 2024-10-05 20:14:56 --> Security Class Initialized
DEBUG - 2024-10-05 20:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:14:56 --> Input Class Initialized
INFO - 2024-10-05 20:14:56 --> Language Class Initialized
INFO - 2024-10-05 20:14:56 --> Language Class Initialized
INFO - 2024-10-05 20:14:56 --> Config Class Initialized
INFO - 2024-10-05 20:14:56 --> Loader Class Initialized
INFO - 2024-10-05 20:14:56 --> Helper loaded: url_helper
INFO - 2024-10-05 20:14:56 --> Helper loaded: file_helper
INFO - 2024-10-05 20:14:56 --> Helper loaded: form_helper
INFO - 2024-10-05 20:14:56 --> Helper loaded: my_helper
INFO - 2024-10-05 20:14:56 --> Database Driver Class Initialized
INFO - 2024-10-05 20:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:14:56 --> Controller Class Initialized
INFO - 2024-10-05 20:14:56 --> Final output sent to browser
DEBUG - 2024-10-05 20:14:56 --> Total execution time: 0.0338
INFO - 2024-10-05 20:15:06 --> Config Class Initialized
INFO - 2024-10-05 20:15:06 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:06 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:06 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:06 --> URI Class Initialized
INFO - 2024-10-05 20:15:06 --> Router Class Initialized
INFO - 2024-10-05 20:15:06 --> Output Class Initialized
INFO - 2024-10-05 20:15:06 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:06 --> Input Class Initialized
INFO - 2024-10-05 20:15:06 --> Language Class Initialized
INFO - 2024-10-05 20:15:06 --> Language Class Initialized
INFO - 2024-10-05 20:15:06 --> Config Class Initialized
INFO - 2024-10-05 20:15:06 --> Loader Class Initialized
INFO - 2024-10-05 20:15:06 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:06 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:06 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:06 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:06 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:07 --> Controller Class Initialized
INFO - 2024-10-05 20:15:07 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:07 --> Total execution time: 0.0398
INFO - 2024-10-05 20:15:07 --> Config Class Initialized
INFO - 2024-10-05 20:15:07 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:07 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:07 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:07 --> URI Class Initialized
INFO - 2024-10-05 20:15:07 --> Router Class Initialized
INFO - 2024-10-05 20:15:07 --> Output Class Initialized
INFO - 2024-10-05 20:15:07 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:07 --> Input Class Initialized
INFO - 2024-10-05 20:15:07 --> Language Class Initialized
INFO - 2024-10-05 20:15:07 --> Language Class Initialized
INFO - 2024-10-05 20:15:07 --> Config Class Initialized
INFO - 2024-10-05 20:15:07 --> Loader Class Initialized
INFO - 2024-10-05 20:15:07 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:07 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:07 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:07 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:07 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:07 --> Controller Class Initialized
INFO - 2024-10-05 20:15:10 --> Config Class Initialized
INFO - 2024-10-05 20:15:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:10 --> URI Class Initialized
INFO - 2024-10-05 20:15:10 --> Router Class Initialized
INFO - 2024-10-05 20:15:10 --> Output Class Initialized
INFO - 2024-10-05 20:15:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:10 --> Input Class Initialized
INFO - 2024-10-05 20:15:10 --> Language Class Initialized
INFO - 2024-10-05 20:15:10 --> Language Class Initialized
INFO - 2024-10-05 20:15:10 --> Config Class Initialized
INFO - 2024-10-05 20:15:10 --> Loader Class Initialized
INFO - 2024-10-05 20:15:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:10 --> Controller Class Initialized
INFO - 2024-10-05 20:15:10 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:10 --> Total execution time: 0.0280
INFO - 2024-10-05 20:15:20 --> Config Class Initialized
INFO - 2024-10-05 20:15:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:20 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:20 --> URI Class Initialized
INFO - 2024-10-05 20:15:20 --> Router Class Initialized
INFO - 2024-10-05 20:15:20 --> Output Class Initialized
INFO - 2024-10-05 20:15:20 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:20 --> Input Class Initialized
INFO - 2024-10-05 20:15:20 --> Language Class Initialized
INFO - 2024-10-05 20:15:20 --> Language Class Initialized
INFO - 2024-10-05 20:15:20 --> Config Class Initialized
INFO - 2024-10-05 20:15:20 --> Loader Class Initialized
INFO - 2024-10-05 20:15:20 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:20 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:20 --> Controller Class Initialized
INFO - 2024-10-05 20:15:20 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:20 --> Total execution time: 0.0359
INFO - 2024-10-05 20:15:20 --> Config Class Initialized
INFO - 2024-10-05 20:15:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:20 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:20 --> URI Class Initialized
INFO - 2024-10-05 20:15:20 --> Router Class Initialized
INFO - 2024-10-05 20:15:20 --> Output Class Initialized
INFO - 2024-10-05 20:15:20 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:20 --> Input Class Initialized
INFO - 2024-10-05 20:15:20 --> Language Class Initialized
INFO - 2024-10-05 20:15:20 --> Language Class Initialized
INFO - 2024-10-05 20:15:20 --> Config Class Initialized
INFO - 2024-10-05 20:15:20 --> Loader Class Initialized
INFO - 2024-10-05 20:15:20 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:20 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:20 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:20 --> Controller Class Initialized
INFO - 2024-10-05 20:15:27 --> Config Class Initialized
INFO - 2024-10-05 20:15:27 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:27 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:27 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:27 --> URI Class Initialized
INFO - 2024-10-05 20:15:27 --> Router Class Initialized
INFO - 2024-10-05 20:15:27 --> Output Class Initialized
INFO - 2024-10-05 20:15:27 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:27 --> Input Class Initialized
INFO - 2024-10-05 20:15:27 --> Language Class Initialized
INFO - 2024-10-05 20:15:27 --> Language Class Initialized
INFO - 2024-10-05 20:15:27 --> Config Class Initialized
INFO - 2024-10-05 20:15:27 --> Loader Class Initialized
INFO - 2024-10-05 20:15:27 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:27 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:27 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:27 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:27 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:27 --> Controller Class Initialized
INFO - 2024-10-05 20:15:27 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:27 --> Total execution time: 0.0423
INFO - 2024-10-05 20:15:36 --> Config Class Initialized
INFO - 2024-10-05 20:15:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:36 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:36 --> URI Class Initialized
INFO - 2024-10-05 20:15:36 --> Router Class Initialized
INFO - 2024-10-05 20:15:36 --> Output Class Initialized
INFO - 2024-10-05 20:15:36 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:36 --> Input Class Initialized
INFO - 2024-10-05 20:15:36 --> Language Class Initialized
INFO - 2024-10-05 20:15:36 --> Language Class Initialized
INFO - 2024-10-05 20:15:36 --> Config Class Initialized
INFO - 2024-10-05 20:15:36 --> Loader Class Initialized
INFO - 2024-10-05 20:15:36 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:36 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:36 --> Controller Class Initialized
INFO - 2024-10-05 20:15:36 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:36 --> Total execution time: 0.0313
INFO - 2024-10-05 20:15:36 --> Config Class Initialized
INFO - 2024-10-05 20:15:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:36 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:36 --> URI Class Initialized
INFO - 2024-10-05 20:15:36 --> Router Class Initialized
INFO - 2024-10-05 20:15:36 --> Output Class Initialized
INFO - 2024-10-05 20:15:36 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:36 --> Input Class Initialized
INFO - 2024-10-05 20:15:36 --> Language Class Initialized
INFO - 2024-10-05 20:15:36 --> Language Class Initialized
INFO - 2024-10-05 20:15:36 --> Config Class Initialized
INFO - 2024-10-05 20:15:36 --> Loader Class Initialized
INFO - 2024-10-05 20:15:36 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:36 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:36 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:36 --> Controller Class Initialized
INFO - 2024-10-05 20:15:57 --> Config Class Initialized
INFO - 2024-10-05 20:15:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:15:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:15:57 --> Utf8 Class Initialized
INFO - 2024-10-05 20:15:57 --> URI Class Initialized
INFO - 2024-10-05 20:15:57 --> Router Class Initialized
INFO - 2024-10-05 20:15:57 --> Output Class Initialized
INFO - 2024-10-05 20:15:57 --> Security Class Initialized
DEBUG - 2024-10-05 20:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:15:57 --> Input Class Initialized
INFO - 2024-10-05 20:15:57 --> Language Class Initialized
INFO - 2024-10-05 20:15:57 --> Language Class Initialized
INFO - 2024-10-05 20:15:57 --> Config Class Initialized
INFO - 2024-10-05 20:15:57 --> Loader Class Initialized
INFO - 2024-10-05 20:15:57 --> Helper loaded: url_helper
INFO - 2024-10-05 20:15:57 --> Helper loaded: file_helper
INFO - 2024-10-05 20:15:57 --> Helper loaded: form_helper
INFO - 2024-10-05 20:15:57 --> Helper loaded: my_helper
INFO - 2024-10-05 20:15:57 --> Database Driver Class Initialized
INFO - 2024-10-05 20:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:15:57 --> Controller Class Initialized
INFO - 2024-10-05 20:15:57 --> Final output sent to browser
DEBUG - 2024-10-05 20:15:57 --> Total execution time: 0.0278
INFO - 2024-10-05 20:16:02 --> Config Class Initialized
INFO - 2024-10-05 20:16:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:02 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:02 --> URI Class Initialized
INFO - 2024-10-05 20:16:02 --> Router Class Initialized
INFO - 2024-10-05 20:16:02 --> Output Class Initialized
INFO - 2024-10-05 20:16:02 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:02 --> Input Class Initialized
INFO - 2024-10-05 20:16:02 --> Language Class Initialized
INFO - 2024-10-05 20:16:02 --> Language Class Initialized
INFO - 2024-10-05 20:16:02 --> Config Class Initialized
INFO - 2024-10-05 20:16:02 --> Loader Class Initialized
INFO - 2024-10-05 20:16:02 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:02 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:02 --> Controller Class Initialized
INFO - 2024-10-05 20:16:02 --> Final output sent to browser
DEBUG - 2024-10-05 20:16:02 --> Total execution time: 0.0336
INFO - 2024-10-05 20:16:02 --> Config Class Initialized
INFO - 2024-10-05 20:16:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:02 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:02 --> URI Class Initialized
INFO - 2024-10-05 20:16:02 --> Router Class Initialized
INFO - 2024-10-05 20:16:02 --> Output Class Initialized
INFO - 2024-10-05 20:16:02 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:02 --> Input Class Initialized
INFO - 2024-10-05 20:16:02 --> Language Class Initialized
INFO - 2024-10-05 20:16:02 --> Language Class Initialized
INFO - 2024-10-05 20:16:02 --> Config Class Initialized
INFO - 2024-10-05 20:16:02 --> Loader Class Initialized
INFO - 2024-10-05 20:16:02 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:02 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:02 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:02 --> Controller Class Initialized
INFO - 2024-10-05 20:16:07 --> Config Class Initialized
INFO - 2024-10-05 20:16:07 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:07 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:07 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:07 --> URI Class Initialized
INFO - 2024-10-05 20:16:07 --> Router Class Initialized
INFO - 2024-10-05 20:16:07 --> Output Class Initialized
INFO - 2024-10-05 20:16:07 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:07 --> Input Class Initialized
INFO - 2024-10-05 20:16:07 --> Language Class Initialized
INFO - 2024-10-05 20:16:07 --> Language Class Initialized
INFO - 2024-10-05 20:16:07 --> Config Class Initialized
INFO - 2024-10-05 20:16:07 --> Loader Class Initialized
INFO - 2024-10-05 20:16:07 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:07 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:07 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:07 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:07 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:07 --> Controller Class Initialized
INFO - 2024-10-05 20:16:07 --> Final output sent to browser
DEBUG - 2024-10-05 20:16:07 --> Total execution time: 0.0291
INFO - 2024-10-05 20:16:17 --> Config Class Initialized
INFO - 2024-10-05 20:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:17 --> URI Class Initialized
INFO - 2024-10-05 20:16:17 --> Router Class Initialized
INFO - 2024-10-05 20:16:17 --> Output Class Initialized
INFO - 2024-10-05 20:16:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:17 --> Input Class Initialized
INFO - 2024-10-05 20:16:17 --> Language Class Initialized
INFO - 2024-10-05 20:16:17 --> Language Class Initialized
INFO - 2024-10-05 20:16:17 --> Config Class Initialized
INFO - 2024-10-05 20:16:17 --> Loader Class Initialized
INFO - 2024-10-05 20:16:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:17 --> Controller Class Initialized
INFO - 2024-10-05 20:16:17 --> Final output sent to browser
DEBUG - 2024-10-05 20:16:17 --> Total execution time: 0.0318
INFO - 2024-10-05 20:16:17 --> Config Class Initialized
INFO - 2024-10-05 20:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:17 --> URI Class Initialized
INFO - 2024-10-05 20:16:17 --> Router Class Initialized
INFO - 2024-10-05 20:16:17 --> Output Class Initialized
INFO - 2024-10-05 20:16:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:17 --> Input Class Initialized
INFO - 2024-10-05 20:16:17 --> Language Class Initialized
INFO - 2024-10-05 20:16:17 --> Language Class Initialized
INFO - 2024-10-05 20:16:17 --> Config Class Initialized
INFO - 2024-10-05 20:16:17 --> Loader Class Initialized
INFO - 2024-10-05 20:16:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:17 --> Controller Class Initialized
INFO - 2024-10-05 20:16:21 --> Config Class Initialized
INFO - 2024-10-05 20:16:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:16:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:16:21 --> Utf8 Class Initialized
INFO - 2024-10-05 20:16:21 --> URI Class Initialized
INFO - 2024-10-05 20:16:21 --> Router Class Initialized
INFO - 2024-10-05 20:16:21 --> Output Class Initialized
INFO - 2024-10-05 20:16:21 --> Security Class Initialized
DEBUG - 2024-10-05 20:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:16:21 --> Input Class Initialized
INFO - 2024-10-05 20:16:21 --> Language Class Initialized
INFO - 2024-10-05 20:16:21 --> Language Class Initialized
INFO - 2024-10-05 20:16:21 --> Config Class Initialized
INFO - 2024-10-05 20:16:21 --> Loader Class Initialized
INFO - 2024-10-05 20:16:21 --> Helper loaded: url_helper
INFO - 2024-10-05 20:16:21 --> Helper loaded: file_helper
INFO - 2024-10-05 20:16:21 --> Helper loaded: form_helper
INFO - 2024-10-05 20:16:21 --> Helper loaded: my_helper
INFO - 2024-10-05 20:16:21 --> Database Driver Class Initialized
INFO - 2024-10-05 20:16:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:16:21 --> Controller Class Initialized
INFO - 2024-10-05 20:17:51 --> Config Class Initialized
INFO - 2024-10-05 20:17:51 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:17:51 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:17:51 --> Utf8 Class Initialized
INFO - 2024-10-05 20:17:51 --> URI Class Initialized
INFO - 2024-10-05 20:17:51 --> Router Class Initialized
INFO - 2024-10-05 20:17:51 --> Output Class Initialized
INFO - 2024-10-05 20:17:51 --> Security Class Initialized
DEBUG - 2024-10-05 20:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:17:51 --> Input Class Initialized
INFO - 2024-10-05 20:17:51 --> Language Class Initialized
INFO - 2024-10-05 20:17:51 --> Language Class Initialized
INFO - 2024-10-05 20:17:51 --> Config Class Initialized
INFO - 2024-10-05 20:17:51 --> Loader Class Initialized
INFO - 2024-10-05 20:17:51 --> Helper loaded: url_helper
INFO - 2024-10-05 20:17:51 --> Helper loaded: file_helper
INFO - 2024-10-05 20:17:51 --> Helper loaded: form_helper
INFO - 2024-10-05 20:17:51 --> Helper loaded: my_helper
INFO - 2024-10-05 20:17:51 --> Database Driver Class Initialized
INFO - 2024-10-05 20:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:17:51 --> Controller Class Initialized
DEBUG - 2024-10-05 20:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2024-10-05 20:17:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:17:51 --> Final output sent to browser
DEBUG - 2024-10-05 20:17:51 --> Total execution time: 0.0414
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:00 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:00 --> URI Class Initialized
INFO - 2024-10-05 20:18:00 --> Router Class Initialized
INFO - 2024-10-05 20:18:00 --> Output Class Initialized
INFO - 2024-10-05 20:18:00 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:00 --> Input Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Loader Class Initialized
INFO - 2024-10-05 20:18:00 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:00 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:00 --> Controller Class Initialized
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:00 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:00 --> URI Class Initialized
INFO - 2024-10-05 20:18:00 --> Router Class Initialized
INFO - 2024-10-05 20:18:00 --> Output Class Initialized
INFO - 2024-10-05 20:18:00 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:00 --> Input Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Loader Class Initialized
INFO - 2024-10-05 20:18:00 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:00 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:00 --> Controller Class Initialized
DEBUG - 2024-10-05 20:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-10-05 20:18:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:18:00 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:00 --> Total execution time: 0.0355
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:00 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:00 --> URI Class Initialized
INFO - 2024-10-05 20:18:00 --> Router Class Initialized
INFO - 2024-10-05 20:18:00 --> Output Class Initialized
INFO - 2024-10-05 20:18:00 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:00 --> Input Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Language Class Initialized
INFO - 2024-10-05 20:18:00 --> Config Class Initialized
INFO - 2024-10-05 20:18:00 --> Loader Class Initialized
INFO - 2024-10-05 20:18:00 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:00 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:00 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:00 --> Controller Class Initialized
INFO - 2024-10-05 20:18:02 --> Config Class Initialized
INFO - 2024-10-05 20:18:02 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:02 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:02 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:02 --> URI Class Initialized
INFO - 2024-10-05 20:18:02 --> Router Class Initialized
INFO - 2024-10-05 20:18:02 --> Output Class Initialized
INFO - 2024-10-05 20:18:02 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:02 --> Input Class Initialized
INFO - 2024-10-05 20:18:02 --> Language Class Initialized
INFO - 2024-10-05 20:18:02 --> Language Class Initialized
INFO - 2024-10-05 20:18:02 --> Config Class Initialized
INFO - 2024-10-05 20:18:02 --> Loader Class Initialized
INFO - 2024-10-05 20:18:02 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:02 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:02 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:02 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:02 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:02 --> Controller Class Initialized
INFO - 2024-10-05 20:18:02 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:02 --> Total execution time: 0.0375
INFO - 2024-10-05 20:18:05 --> Config Class Initialized
INFO - 2024-10-05 20:18:05 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:05 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:05 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:05 --> URI Class Initialized
INFO - 2024-10-05 20:18:05 --> Router Class Initialized
INFO - 2024-10-05 20:18:05 --> Output Class Initialized
INFO - 2024-10-05 20:18:05 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:05 --> Input Class Initialized
INFO - 2024-10-05 20:18:05 --> Language Class Initialized
INFO - 2024-10-05 20:18:05 --> Language Class Initialized
INFO - 2024-10-05 20:18:05 --> Config Class Initialized
INFO - 2024-10-05 20:18:05 --> Loader Class Initialized
INFO - 2024-10-05 20:18:05 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:05 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:05 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:05 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:05 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:05 --> Controller Class Initialized
INFO - 2024-10-05 20:18:05 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:05 --> Total execution time: 0.0321
INFO - 2024-10-05 20:18:08 --> Config Class Initialized
INFO - 2024-10-05 20:18:08 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:08 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:08 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:08 --> URI Class Initialized
INFO - 2024-10-05 20:18:08 --> Router Class Initialized
INFO - 2024-10-05 20:18:08 --> Output Class Initialized
INFO - 2024-10-05 20:18:08 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:08 --> Input Class Initialized
INFO - 2024-10-05 20:18:08 --> Language Class Initialized
INFO - 2024-10-05 20:18:08 --> Language Class Initialized
INFO - 2024-10-05 20:18:08 --> Config Class Initialized
INFO - 2024-10-05 20:18:08 --> Loader Class Initialized
INFO - 2024-10-05 20:18:08 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:08 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:08 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:08 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:08 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:08 --> Controller Class Initialized
DEBUG - 2024-10-05 20:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:18:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:18:08 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:08 --> Total execution time: 0.0434
INFO - 2024-10-05 20:18:13 --> Config Class Initialized
INFO - 2024-10-05 20:18:13 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:13 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:13 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:13 --> URI Class Initialized
INFO - 2024-10-05 20:18:13 --> Router Class Initialized
INFO - 2024-10-05 20:18:13 --> Output Class Initialized
INFO - 2024-10-05 20:18:13 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:13 --> Input Class Initialized
INFO - 2024-10-05 20:18:13 --> Language Class Initialized
INFO - 2024-10-05 20:18:13 --> Language Class Initialized
INFO - 2024-10-05 20:18:13 --> Config Class Initialized
INFO - 2024-10-05 20:18:13 --> Loader Class Initialized
INFO - 2024-10-05 20:18:13 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:13 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:13 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:13 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:13 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:13 --> Controller Class Initialized
DEBUG - 2024-10-05 20:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:18:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:18:13 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:13 --> Total execution time: 0.0339
INFO - 2024-10-05 20:18:15 --> Config Class Initialized
INFO - 2024-10-05 20:18:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:15 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:15 --> URI Class Initialized
INFO - 2024-10-05 20:18:15 --> Router Class Initialized
INFO - 2024-10-05 20:18:15 --> Output Class Initialized
INFO - 2024-10-05 20:18:15 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:15 --> Input Class Initialized
INFO - 2024-10-05 20:18:15 --> Language Class Initialized
INFO - 2024-10-05 20:18:15 --> Language Class Initialized
INFO - 2024-10-05 20:18:15 --> Config Class Initialized
INFO - 2024-10-05 20:18:15 --> Loader Class Initialized
INFO - 2024-10-05 20:18:15 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:15 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:15 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:15 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:15 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:15 --> Controller Class Initialized
INFO - 2024-10-05 20:18:31 --> Config Class Initialized
INFO - 2024-10-05 20:18:31 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:18:31 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:18:31 --> Utf8 Class Initialized
INFO - 2024-10-05 20:18:31 --> URI Class Initialized
INFO - 2024-10-05 20:18:31 --> Router Class Initialized
INFO - 2024-10-05 20:18:31 --> Output Class Initialized
INFO - 2024-10-05 20:18:31 --> Security Class Initialized
DEBUG - 2024-10-05 20:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:18:31 --> Input Class Initialized
INFO - 2024-10-05 20:18:31 --> Language Class Initialized
INFO - 2024-10-05 20:18:31 --> Language Class Initialized
INFO - 2024-10-05 20:18:31 --> Config Class Initialized
INFO - 2024-10-05 20:18:31 --> Loader Class Initialized
INFO - 2024-10-05 20:18:31 --> Helper loaded: url_helper
INFO - 2024-10-05 20:18:31 --> Helper loaded: file_helper
INFO - 2024-10-05 20:18:31 --> Helper loaded: form_helper
INFO - 2024-10-05 20:18:31 --> Helper loaded: my_helper
INFO - 2024-10-05 20:18:31 --> Database Driver Class Initialized
INFO - 2024-10-05 20:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:18:31 --> Controller Class Initialized
INFO - 2024-10-05 20:18:31 --> Final output sent to browser
DEBUG - 2024-10-05 20:18:31 --> Total execution time: 0.0349
INFO - 2024-10-05 20:20:14 --> Config Class Initialized
INFO - 2024-10-05 20:20:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:14 --> URI Class Initialized
INFO - 2024-10-05 20:20:14 --> Router Class Initialized
INFO - 2024-10-05 20:20:14 --> Output Class Initialized
INFO - 2024-10-05 20:20:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:14 --> Input Class Initialized
INFO - 2024-10-05 20:20:14 --> Language Class Initialized
INFO - 2024-10-05 20:20:14 --> Language Class Initialized
INFO - 2024-10-05 20:20:14 --> Config Class Initialized
INFO - 2024-10-05 20:20:14 --> Loader Class Initialized
INFO - 2024-10-05 20:20:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:14 --> Controller Class Initialized
DEBUG - 2024-10-05 20:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-10-05 20:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:20:14 --> Final output sent to browser
DEBUG - 2024-10-05 20:20:14 --> Total execution time: 0.0408
INFO - 2024-10-05 20:20:20 --> Config Class Initialized
INFO - 2024-10-05 20:20:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:20 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:20 --> URI Class Initialized
INFO - 2024-10-05 20:20:20 --> Router Class Initialized
INFO - 2024-10-05 20:20:20 --> Output Class Initialized
INFO - 2024-10-05 20:20:20 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:20 --> Input Class Initialized
INFO - 2024-10-05 20:20:20 --> Language Class Initialized
INFO - 2024-10-05 20:20:20 --> Language Class Initialized
INFO - 2024-10-05 20:20:20 --> Config Class Initialized
INFO - 2024-10-05 20:20:20 --> Loader Class Initialized
INFO - 2024-10-05 20:20:20 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:20 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:20 --> Controller Class Initialized
INFO - 2024-10-05 20:20:20 --> Config Class Initialized
INFO - 2024-10-05 20:20:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:20 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:20 --> URI Class Initialized
INFO - 2024-10-05 20:20:20 --> Router Class Initialized
INFO - 2024-10-05 20:20:20 --> Output Class Initialized
INFO - 2024-10-05 20:20:20 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:20 --> Input Class Initialized
INFO - 2024-10-05 20:20:20 --> Language Class Initialized
INFO - 2024-10-05 20:20:20 --> Language Class Initialized
INFO - 2024-10-05 20:20:20 --> Config Class Initialized
INFO - 2024-10-05 20:20:20 --> Loader Class Initialized
INFO - 2024-10-05 20:20:20 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:20 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:20 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:20 --> Controller Class Initialized
DEBUG - 2024-10-05 20:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:20:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:20:20 --> Final output sent to browser
DEBUG - 2024-10-05 20:20:20 --> Total execution time: 0.0338
INFO - 2024-10-05 20:20:22 --> Config Class Initialized
INFO - 2024-10-05 20:20:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:22 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:22 --> URI Class Initialized
INFO - 2024-10-05 20:20:22 --> Router Class Initialized
INFO - 2024-10-05 20:20:22 --> Output Class Initialized
INFO - 2024-10-05 20:20:22 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:22 --> Input Class Initialized
INFO - 2024-10-05 20:20:22 --> Language Class Initialized
INFO - 2024-10-05 20:20:22 --> Language Class Initialized
INFO - 2024-10-05 20:20:22 --> Config Class Initialized
INFO - 2024-10-05 20:20:22 --> Loader Class Initialized
INFO - 2024-10-05 20:20:22 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:22 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:22 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:22 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:22 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:22 --> Controller Class Initialized
INFO - 2024-10-05 20:20:22 --> Final output sent to browser
DEBUG - 2024-10-05 20:20:22 --> Total execution time: 0.0374
INFO - 2024-10-05 20:20:25 --> Config Class Initialized
INFO - 2024-10-05 20:20:25 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:25 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:25 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:25 --> URI Class Initialized
INFO - 2024-10-05 20:20:25 --> Router Class Initialized
INFO - 2024-10-05 20:20:25 --> Output Class Initialized
INFO - 2024-10-05 20:20:25 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:25 --> Input Class Initialized
INFO - 2024-10-05 20:20:25 --> Language Class Initialized
INFO - 2024-10-05 20:20:25 --> Language Class Initialized
INFO - 2024-10-05 20:20:25 --> Config Class Initialized
INFO - 2024-10-05 20:20:25 --> Loader Class Initialized
INFO - 2024-10-05 20:20:25 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:25 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:25 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:25 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:25 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:25 --> Controller Class Initialized
DEBUG - 2024-10-05 20:20:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:20:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:20:25 --> Final output sent to browser
DEBUG - 2024-10-05 20:20:25 --> Total execution time: 0.0477
INFO - 2024-10-05 20:20:57 --> Config Class Initialized
INFO - 2024-10-05 20:20:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:57 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:57 --> URI Class Initialized
INFO - 2024-10-05 20:20:57 --> Router Class Initialized
INFO - 2024-10-05 20:20:57 --> Output Class Initialized
INFO - 2024-10-05 20:20:57 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:57 --> Input Class Initialized
INFO - 2024-10-05 20:20:57 --> Language Class Initialized
INFO - 2024-10-05 20:20:57 --> Language Class Initialized
INFO - 2024-10-05 20:20:57 --> Config Class Initialized
INFO - 2024-10-05 20:20:57 --> Loader Class Initialized
INFO - 2024-10-05 20:20:57 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:57 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:57 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:57 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:57 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:57 --> Controller Class Initialized
DEBUG - 2024-10-05 20:20:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-10-05 20:20:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:20:57 --> Final output sent to browser
DEBUG - 2024-10-05 20:20:57 --> Total execution time: 0.0407
INFO - 2024-10-05 20:20:58 --> Config Class Initialized
INFO - 2024-10-05 20:20:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:20:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:20:58 --> Utf8 Class Initialized
INFO - 2024-10-05 20:20:58 --> URI Class Initialized
INFO - 2024-10-05 20:20:58 --> Router Class Initialized
INFO - 2024-10-05 20:20:58 --> Output Class Initialized
INFO - 2024-10-05 20:20:58 --> Security Class Initialized
DEBUG - 2024-10-05 20:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:20:58 --> Input Class Initialized
INFO - 2024-10-05 20:20:58 --> Language Class Initialized
INFO - 2024-10-05 20:20:58 --> Language Class Initialized
INFO - 2024-10-05 20:20:58 --> Config Class Initialized
INFO - 2024-10-05 20:20:58 --> Loader Class Initialized
INFO - 2024-10-05 20:20:58 --> Helper loaded: url_helper
INFO - 2024-10-05 20:20:58 --> Helper loaded: file_helper
INFO - 2024-10-05 20:20:58 --> Helper loaded: form_helper
INFO - 2024-10-05 20:20:58 --> Helper loaded: my_helper
INFO - 2024-10-05 20:20:58 --> Database Driver Class Initialized
INFO - 2024-10-05 20:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:20:58 --> Controller Class Initialized
INFO - 2024-10-05 20:29:55 --> Config Class Initialized
INFO - 2024-10-05 20:29:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:29:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:29:55 --> Utf8 Class Initialized
INFO - 2024-10-05 20:29:55 --> URI Class Initialized
INFO - 2024-10-05 20:29:55 --> Router Class Initialized
INFO - 2024-10-05 20:29:55 --> Output Class Initialized
INFO - 2024-10-05 20:29:55 --> Security Class Initialized
DEBUG - 2024-10-05 20:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:29:55 --> Input Class Initialized
INFO - 2024-10-05 20:29:55 --> Language Class Initialized
INFO - 2024-10-05 20:29:55 --> Language Class Initialized
INFO - 2024-10-05 20:29:55 --> Config Class Initialized
INFO - 2024-10-05 20:29:55 --> Loader Class Initialized
INFO - 2024-10-05 20:29:55 --> Helper loaded: url_helper
INFO - 2024-10-05 20:29:55 --> Helper loaded: file_helper
INFO - 2024-10-05 20:29:55 --> Helper loaded: form_helper
INFO - 2024-10-05 20:29:55 --> Helper loaded: my_helper
INFO - 2024-10-05 20:29:55 --> Database Driver Class Initialized
INFO - 2024-10-05 20:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:29:55 --> Controller Class Initialized
DEBUG - 2024-10-05 20:29:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:29:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:29:55 --> Final output sent to browser
DEBUG - 2024-10-05 20:29:55 --> Total execution time: 0.0297
INFO - 2024-10-05 20:29:58 --> Config Class Initialized
INFO - 2024-10-05 20:29:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:29:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:29:58 --> Utf8 Class Initialized
INFO - 2024-10-05 20:29:58 --> URI Class Initialized
INFO - 2024-10-05 20:29:58 --> Router Class Initialized
INFO - 2024-10-05 20:29:58 --> Output Class Initialized
INFO - 2024-10-05 20:29:58 --> Security Class Initialized
DEBUG - 2024-10-05 20:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:29:58 --> Input Class Initialized
INFO - 2024-10-05 20:29:58 --> Language Class Initialized
INFO - 2024-10-05 20:29:58 --> Language Class Initialized
INFO - 2024-10-05 20:29:58 --> Config Class Initialized
INFO - 2024-10-05 20:29:58 --> Loader Class Initialized
INFO - 2024-10-05 20:29:58 --> Helper loaded: url_helper
INFO - 2024-10-05 20:29:58 --> Helper loaded: file_helper
INFO - 2024-10-05 20:29:58 --> Helper loaded: form_helper
INFO - 2024-10-05 20:29:58 --> Helper loaded: my_helper
INFO - 2024-10-05 20:29:58 --> Database Driver Class Initialized
INFO - 2024-10-05 20:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:29:58 --> Controller Class Initialized
DEBUG - 2024-10-05 20:29:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:29:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:29:58 --> Final output sent to browser
DEBUG - 2024-10-05 20:29:58 --> Total execution time: 0.0329
INFO - 2024-10-05 20:30:10 --> Config Class Initialized
INFO - 2024-10-05 20:30:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:10 --> URI Class Initialized
INFO - 2024-10-05 20:30:10 --> Router Class Initialized
INFO - 2024-10-05 20:30:10 --> Output Class Initialized
INFO - 2024-10-05 20:30:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:10 --> Input Class Initialized
INFO - 2024-10-05 20:30:10 --> Language Class Initialized
INFO - 2024-10-05 20:30:10 --> Language Class Initialized
INFO - 2024-10-05 20:30:10 --> Config Class Initialized
INFO - 2024-10-05 20:30:10 --> Loader Class Initialized
INFO - 2024-10-05 20:30:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:10 --> Controller Class Initialized
DEBUG - 2024-10-05 20:30:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 20:30:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:30:10 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:10 --> Total execution time: 0.0386
INFO - 2024-10-05 20:30:11 --> Config Class Initialized
INFO - 2024-10-05 20:30:11 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:11 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:11 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:11 --> URI Class Initialized
INFO - 2024-10-05 20:30:11 --> Router Class Initialized
INFO - 2024-10-05 20:30:11 --> Output Class Initialized
INFO - 2024-10-05 20:30:11 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:11 --> Input Class Initialized
INFO - 2024-10-05 20:30:11 --> Language Class Initialized
INFO - 2024-10-05 20:30:11 --> Language Class Initialized
INFO - 2024-10-05 20:30:11 --> Config Class Initialized
INFO - 2024-10-05 20:30:11 --> Loader Class Initialized
INFO - 2024-10-05 20:30:11 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:11 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:11 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:11 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:11 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:11 --> Controller Class Initialized
DEBUG - 2024-10-05 20:30:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 20:30:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:30:11 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:11 --> Total execution time: 0.0299
INFO - 2024-10-05 20:30:13 --> Config Class Initialized
INFO - 2024-10-05 20:30:13 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:13 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:13 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:13 --> URI Class Initialized
INFO - 2024-10-05 20:30:13 --> Router Class Initialized
INFO - 2024-10-05 20:30:13 --> Output Class Initialized
INFO - 2024-10-05 20:30:13 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:13 --> Input Class Initialized
INFO - 2024-10-05 20:30:13 --> Language Class Initialized
INFO - 2024-10-05 20:30:13 --> Language Class Initialized
INFO - 2024-10-05 20:30:13 --> Config Class Initialized
INFO - 2024-10-05 20:30:13 --> Loader Class Initialized
INFO - 2024-10-05 20:30:13 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:13 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:13 --> Controller Class Initialized
INFO - 2024-10-05 20:30:13 --> Helper loaded: cookie_helper
INFO - 2024-10-05 20:30:13 --> Config Class Initialized
INFO - 2024-10-05 20:30:13 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:13 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:13 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:13 --> URI Class Initialized
INFO - 2024-10-05 20:30:13 --> Router Class Initialized
INFO - 2024-10-05 20:30:13 --> Output Class Initialized
INFO - 2024-10-05 20:30:13 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:13 --> Input Class Initialized
INFO - 2024-10-05 20:30:13 --> Language Class Initialized
INFO - 2024-10-05 20:30:13 --> Language Class Initialized
INFO - 2024-10-05 20:30:13 --> Config Class Initialized
INFO - 2024-10-05 20:30:13 --> Loader Class Initialized
INFO - 2024-10-05 20:30:13 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:13 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:13 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:13 --> Controller Class Initialized
INFO - 2024-10-05 20:30:14 --> Config Class Initialized
INFO - 2024-10-05 20:30:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:14 --> URI Class Initialized
INFO - 2024-10-05 20:30:14 --> Router Class Initialized
INFO - 2024-10-05 20:30:14 --> Output Class Initialized
INFO - 2024-10-05 20:30:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:14 --> Input Class Initialized
INFO - 2024-10-05 20:30:14 --> Language Class Initialized
INFO - 2024-10-05 20:30:14 --> Language Class Initialized
INFO - 2024-10-05 20:30:14 --> Config Class Initialized
INFO - 2024-10-05 20:30:14 --> Loader Class Initialized
INFO - 2024-10-05 20:30:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:14 --> Controller Class Initialized
DEBUG - 2024-10-05 20:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-10-05 20:30:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:30:14 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:14 --> Total execution time: 0.0330
INFO - 2024-10-05 20:30:15 --> Config Class Initialized
INFO - 2024-10-05 20:30:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:15 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:15 --> URI Class Initialized
INFO - 2024-10-05 20:30:15 --> Router Class Initialized
INFO - 2024-10-05 20:30:15 --> Output Class Initialized
INFO - 2024-10-05 20:30:15 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:15 --> Input Class Initialized
INFO - 2024-10-05 20:30:15 --> Language Class Initialized
INFO - 2024-10-05 20:30:15 --> Language Class Initialized
INFO - 2024-10-05 20:30:15 --> Config Class Initialized
INFO - 2024-10-05 20:30:15 --> Loader Class Initialized
INFO - 2024-10-05 20:30:15 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:15 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:15 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:15 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:15 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:15 --> Controller Class Initialized
INFO - 2024-10-05 20:30:15 --> Helper loaded: cookie_helper
INFO - 2024-10-05 20:30:15 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:15 --> Total execution time: 0.0376
INFO - 2024-10-05 20:30:16 --> Config Class Initialized
INFO - 2024-10-05 20:30:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:16 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:16 --> URI Class Initialized
INFO - 2024-10-05 20:30:16 --> Router Class Initialized
INFO - 2024-10-05 20:30:16 --> Output Class Initialized
INFO - 2024-10-05 20:30:16 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:16 --> Input Class Initialized
INFO - 2024-10-05 20:30:16 --> Language Class Initialized
INFO - 2024-10-05 20:30:16 --> Language Class Initialized
INFO - 2024-10-05 20:30:16 --> Config Class Initialized
INFO - 2024-10-05 20:30:16 --> Loader Class Initialized
INFO - 2024-10-05 20:30:16 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:16 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:16 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:16 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:16 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:16 --> Controller Class Initialized
DEBUG - 2024-10-05 20:30:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-10-05 20:30:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:30:16 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:16 --> Total execution time: 0.0303
INFO - 2024-10-05 20:30:17 --> Config Class Initialized
INFO - 2024-10-05 20:30:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:30:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:30:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:30:17 --> URI Class Initialized
INFO - 2024-10-05 20:30:17 --> Router Class Initialized
INFO - 2024-10-05 20:30:17 --> Output Class Initialized
INFO - 2024-10-05 20:30:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:30:17 --> Input Class Initialized
INFO - 2024-10-05 20:30:17 --> Language Class Initialized
INFO - 2024-10-05 20:30:17 --> Language Class Initialized
INFO - 2024-10-05 20:30:17 --> Config Class Initialized
INFO - 2024-10-05 20:30:17 --> Loader Class Initialized
INFO - 2024-10-05 20:30:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:30:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:30:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:30:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:30:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:30:17 --> Controller Class Initialized
DEBUG - 2024-10-05 20:30:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-10-05 20:30:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:30:17 --> Final output sent to browser
DEBUG - 2024-10-05 20:30:17 --> Total execution time: 0.0358
INFO - 2024-10-05 20:34:03 --> Config Class Initialized
INFO - 2024-10-05 20:34:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:03 --> URI Class Initialized
INFO - 2024-10-05 20:34:03 --> Router Class Initialized
INFO - 2024-10-05 20:34:03 --> Output Class Initialized
INFO - 2024-10-05 20:34:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:03 --> Input Class Initialized
INFO - 2024-10-05 20:34:03 --> Language Class Initialized
INFO - 2024-10-05 20:34:03 --> Language Class Initialized
INFO - 2024-10-05 20:34:03 --> Config Class Initialized
INFO - 2024-10-05 20:34:03 --> Loader Class Initialized
INFO - 2024-10-05 20:34:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:03 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/pengumuman/views/list.php
DEBUG - 2024-10-05 20:34:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:03 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:03 --> Total execution time: 0.0347
INFO - 2024-10-05 20:34:03 --> Config Class Initialized
INFO - 2024-10-05 20:34:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:03 --> URI Class Initialized
INFO - 2024-10-05 20:34:03 --> Router Class Initialized
INFO - 2024-10-05 20:34:03 --> Output Class Initialized
INFO - 2024-10-05 20:34:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:03 --> Input Class Initialized
INFO - 2024-10-05 20:34:03 --> Language Class Initialized
ERROR - 2024-10-05 20:34:03 --> 404 Page Not Found: /index
INFO - 2024-10-05 20:34:03 --> Config Class Initialized
INFO - 2024-10-05 20:34:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:03 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:03 --> URI Class Initialized
INFO - 2024-10-05 20:34:03 --> Router Class Initialized
INFO - 2024-10-05 20:34:03 --> Output Class Initialized
INFO - 2024-10-05 20:34:03 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:03 --> Input Class Initialized
INFO - 2024-10-05 20:34:03 --> Language Class Initialized
INFO - 2024-10-05 20:34:03 --> Language Class Initialized
INFO - 2024-10-05 20:34:03 --> Config Class Initialized
INFO - 2024-10-05 20:34:03 --> Loader Class Initialized
INFO - 2024-10-05 20:34:03 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:03 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:03 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:03 --> Controller Class Initialized
INFO - 2024-10-05 20:34:06 --> Config Class Initialized
INFO - 2024-10-05 20:34:06 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:06 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:06 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:06 --> URI Class Initialized
INFO - 2024-10-05 20:34:06 --> Router Class Initialized
INFO - 2024-10-05 20:34:06 --> Output Class Initialized
INFO - 2024-10-05 20:34:06 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:06 --> Input Class Initialized
INFO - 2024-10-05 20:34:06 --> Language Class Initialized
INFO - 2024-10-05 20:34:06 --> Language Class Initialized
INFO - 2024-10-05 20:34:06 --> Config Class Initialized
INFO - 2024-10-05 20:34:06 --> Loader Class Initialized
INFO - 2024-10-05 20:34:06 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:06 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:06 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:06 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:06 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:06 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-10-05 20:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:06 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:06 --> Total execution time: 0.0456
INFO - 2024-10-05 20:34:09 --> Config Class Initialized
INFO - 2024-10-05 20:34:09 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:09 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:09 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:09 --> URI Class Initialized
INFO - 2024-10-05 20:34:09 --> Router Class Initialized
INFO - 2024-10-05 20:34:09 --> Output Class Initialized
INFO - 2024-10-05 20:34:09 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:09 --> Input Class Initialized
INFO - 2024-10-05 20:34:09 --> Language Class Initialized
INFO - 2024-10-05 20:34:09 --> Language Class Initialized
INFO - 2024-10-05 20:34:09 --> Config Class Initialized
INFO - 2024-10-05 20:34:09 --> Loader Class Initialized
INFO - 2024-10-05 20:34:09 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:09 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:09 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:09 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:09 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:09 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-05 20:34:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:09 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:09 --> Total execution time: 0.0379
INFO - 2024-10-05 20:34:17 --> Config Class Initialized
INFO - 2024-10-05 20:34:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:17 --> URI Class Initialized
INFO - 2024-10-05 20:34:17 --> Router Class Initialized
INFO - 2024-10-05 20:34:17 --> Output Class Initialized
INFO - 2024-10-05 20:34:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:17 --> Input Class Initialized
INFO - 2024-10-05 20:34:17 --> Language Class Initialized
INFO - 2024-10-05 20:34:17 --> Language Class Initialized
INFO - 2024-10-05 20:34:17 --> Config Class Initialized
INFO - 2024-10-05 20:34:17 --> Loader Class Initialized
INFO - 2024-10-05 20:34:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:17 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-10-05 20:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:17 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:17 --> Total execution time: 0.0323
INFO - 2024-10-05 20:34:21 --> Config Class Initialized
INFO - 2024-10-05 20:34:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:21 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:21 --> URI Class Initialized
INFO - 2024-10-05 20:34:21 --> Router Class Initialized
INFO - 2024-10-05 20:34:21 --> Output Class Initialized
INFO - 2024-10-05 20:34:21 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:21 --> Input Class Initialized
INFO - 2024-10-05 20:34:21 --> Language Class Initialized
INFO - 2024-10-05 20:34:21 --> Language Class Initialized
INFO - 2024-10-05 20:34:21 --> Config Class Initialized
INFO - 2024-10-05 20:34:21 --> Loader Class Initialized
INFO - 2024-10-05 20:34:21 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:21 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:21 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:21 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:21 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:21 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 20:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:21 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:21 --> Total execution time: 0.0276
INFO - 2024-10-05 20:34:24 --> Config Class Initialized
INFO - 2024-10-05 20:34:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:24 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:24 --> URI Class Initialized
INFO - 2024-10-05 20:34:24 --> Router Class Initialized
INFO - 2024-10-05 20:34:24 --> Output Class Initialized
INFO - 2024-10-05 20:34:24 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:24 --> Input Class Initialized
INFO - 2024-10-05 20:34:24 --> Language Class Initialized
INFO - 2024-10-05 20:34:24 --> Language Class Initialized
INFO - 2024-10-05 20:34:24 --> Config Class Initialized
INFO - 2024-10-05 20:34:24 --> Loader Class Initialized
INFO - 2024-10-05 20:34:24 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:24 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:24 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:24 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:24 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:24 --> Controller Class Initialized
DEBUG - 2024-10-05 20:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-10-05 20:34:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 20:34:24 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:24 --> Total execution time: 0.0347
INFO - 2024-10-05 20:34:24 --> Config Class Initialized
INFO - 2024-10-05 20:34:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:24 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:24 --> URI Class Initialized
INFO - 2024-10-05 20:34:24 --> Router Class Initialized
INFO - 2024-10-05 20:34:25 --> Output Class Initialized
INFO - 2024-10-05 20:34:25 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:25 --> Input Class Initialized
INFO - 2024-10-05 20:34:25 --> Language Class Initialized
INFO - 2024-10-05 20:34:25 --> Language Class Initialized
INFO - 2024-10-05 20:34:25 --> Config Class Initialized
INFO - 2024-10-05 20:34:25 --> Loader Class Initialized
INFO - 2024-10-05 20:34:25 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:25 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:25 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:25 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:25 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:25 --> Controller Class Initialized
INFO - 2024-10-05 20:34:27 --> Config Class Initialized
INFO - 2024-10-05 20:34:27 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:34:27 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:34:27 --> Utf8 Class Initialized
INFO - 2024-10-05 20:34:27 --> URI Class Initialized
INFO - 2024-10-05 20:34:27 --> Router Class Initialized
INFO - 2024-10-05 20:34:27 --> Output Class Initialized
INFO - 2024-10-05 20:34:27 --> Security Class Initialized
DEBUG - 2024-10-05 20:34:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:34:27 --> Input Class Initialized
INFO - 2024-10-05 20:34:27 --> Language Class Initialized
INFO - 2024-10-05 20:34:27 --> Language Class Initialized
INFO - 2024-10-05 20:34:27 --> Config Class Initialized
INFO - 2024-10-05 20:34:27 --> Loader Class Initialized
INFO - 2024-10-05 20:34:27 --> Helper loaded: url_helper
INFO - 2024-10-05 20:34:27 --> Helper loaded: file_helper
INFO - 2024-10-05 20:34:27 --> Helper loaded: form_helper
INFO - 2024-10-05 20:34:27 --> Helper loaded: my_helper
INFO - 2024-10-05 20:34:27 --> Database Driver Class Initialized
INFO - 2024-10-05 20:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:34:27 --> Controller Class Initialized
INFO - 2024-10-05 20:34:27 --> Final output sent to browser
DEBUG - 2024-10-05 20:34:27 --> Total execution time: 0.0419
INFO - 2024-10-05 20:35:14 --> Config Class Initialized
INFO - 2024-10-05 20:35:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:35:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:35:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:35:14 --> URI Class Initialized
INFO - 2024-10-05 20:35:14 --> Router Class Initialized
INFO - 2024-10-05 20:35:14 --> Output Class Initialized
INFO - 2024-10-05 20:35:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:35:14 --> Input Class Initialized
INFO - 2024-10-05 20:35:14 --> Language Class Initialized
INFO - 2024-10-05 20:35:14 --> Language Class Initialized
INFO - 2024-10-05 20:35:14 --> Config Class Initialized
INFO - 2024-10-05 20:35:14 --> Loader Class Initialized
INFO - 2024-10-05 20:35:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:35:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:35:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:35:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:35:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:35:14 --> Controller Class Initialized
INFO - 2024-10-05 20:35:14 --> Final output sent to browser
DEBUG - 2024-10-05 20:35:14 --> Total execution time: 0.0463
INFO - 2024-10-05 20:35:17 --> Config Class Initialized
INFO - 2024-10-05 20:35:17 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:35:17 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:35:17 --> Utf8 Class Initialized
INFO - 2024-10-05 20:35:17 --> URI Class Initialized
INFO - 2024-10-05 20:35:17 --> Router Class Initialized
INFO - 2024-10-05 20:35:17 --> Output Class Initialized
INFO - 2024-10-05 20:35:17 --> Security Class Initialized
DEBUG - 2024-10-05 20:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:35:17 --> Input Class Initialized
INFO - 2024-10-05 20:35:17 --> Language Class Initialized
INFO - 2024-10-05 20:35:17 --> Language Class Initialized
INFO - 2024-10-05 20:35:17 --> Config Class Initialized
INFO - 2024-10-05 20:35:17 --> Loader Class Initialized
INFO - 2024-10-05 20:35:17 --> Helper loaded: url_helper
INFO - 2024-10-05 20:35:17 --> Helper loaded: file_helper
INFO - 2024-10-05 20:35:17 --> Helper loaded: form_helper
INFO - 2024-10-05 20:35:17 --> Helper loaded: my_helper
INFO - 2024-10-05 20:35:17 --> Database Driver Class Initialized
INFO - 2024-10-05 20:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:35:17 --> Controller Class Initialized
INFO - 2024-10-05 20:35:17 --> Final output sent to browser
DEBUG - 2024-10-05 20:35:17 --> Total execution time: 0.0328
INFO - 2024-10-05 20:40:44 --> Config Class Initialized
INFO - 2024-10-05 20:40:44 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:40:44 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:40:44 --> Utf8 Class Initialized
INFO - 2024-10-05 20:40:44 --> URI Class Initialized
INFO - 2024-10-05 20:40:44 --> Router Class Initialized
INFO - 2024-10-05 20:40:44 --> Output Class Initialized
INFO - 2024-10-05 20:40:44 --> Security Class Initialized
DEBUG - 2024-10-05 20:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:40:44 --> Input Class Initialized
INFO - 2024-10-05 20:40:44 --> Language Class Initialized
INFO - 2024-10-05 20:40:44 --> Language Class Initialized
INFO - 2024-10-05 20:40:44 --> Config Class Initialized
INFO - 2024-10-05 20:40:44 --> Loader Class Initialized
INFO - 2024-10-05 20:40:44 --> Helper loaded: url_helper
INFO - 2024-10-05 20:40:44 --> Helper loaded: file_helper
INFO - 2024-10-05 20:40:44 --> Helper loaded: form_helper
INFO - 2024-10-05 20:40:44 --> Helper loaded: my_helper
INFO - 2024-10-05 20:40:44 --> Database Driver Class Initialized
INFO - 2024-10-05 20:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:40:44 --> Controller Class Initialized
INFO - 2024-10-05 20:40:44 --> Final output sent to browser
DEBUG - 2024-10-05 20:40:44 --> Total execution time: 0.0399
INFO - 2024-10-05 20:41:16 --> Config Class Initialized
INFO - 2024-10-05 20:41:16 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:41:16 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:41:16 --> Utf8 Class Initialized
INFO - 2024-10-05 20:41:16 --> URI Class Initialized
INFO - 2024-10-05 20:41:16 --> Router Class Initialized
INFO - 2024-10-05 20:41:16 --> Output Class Initialized
INFO - 2024-10-05 20:41:16 --> Security Class Initialized
DEBUG - 2024-10-05 20:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:41:16 --> Input Class Initialized
INFO - 2024-10-05 20:41:16 --> Language Class Initialized
INFO - 2024-10-05 20:41:16 --> Language Class Initialized
INFO - 2024-10-05 20:41:16 --> Config Class Initialized
INFO - 2024-10-05 20:41:16 --> Loader Class Initialized
INFO - 2024-10-05 20:41:16 --> Helper loaded: url_helper
INFO - 2024-10-05 20:41:16 --> Helper loaded: file_helper
INFO - 2024-10-05 20:41:16 --> Helper loaded: form_helper
INFO - 2024-10-05 20:41:16 --> Helper loaded: my_helper
INFO - 2024-10-05 20:41:16 --> Database Driver Class Initialized
INFO - 2024-10-05 20:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:41:16 --> Controller Class Initialized
INFO - 2024-10-05 20:41:16 --> Final output sent to browser
DEBUG - 2024-10-05 20:41:16 --> Total execution time: 0.0471
INFO - 2024-10-05 20:41:22 --> Config Class Initialized
INFO - 2024-10-05 20:41:22 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:41:22 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:41:22 --> Utf8 Class Initialized
INFO - 2024-10-05 20:41:22 --> URI Class Initialized
INFO - 2024-10-05 20:41:22 --> Router Class Initialized
INFO - 2024-10-05 20:41:22 --> Output Class Initialized
INFO - 2024-10-05 20:41:22 --> Security Class Initialized
DEBUG - 2024-10-05 20:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:41:22 --> Input Class Initialized
INFO - 2024-10-05 20:41:22 --> Language Class Initialized
INFO - 2024-10-05 20:41:22 --> Language Class Initialized
INFO - 2024-10-05 20:41:22 --> Config Class Initialized
INFO - 2024-10-05 20:41:22 --> Loader Class Initialized
INFO - 2024-10-05 20:41:22 --> Helper loaded: url_helper
INFO - 2024-10-05 20:41:22 --> Helper loaded: file_helper
INFO - 2024-10-05 20:41:22 --> Helper loaded: form_helper
INFO - 2024-10-05 20:41:22 --> Helper loaded: my_helper
INFO - 2024-10-05 20:41:22 --> Database Driver Class Initialized
INFO - 2024-10-05 20:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:41:22 --> Controller Class Initialized
INFO - 2024-10-05 20:41:22 --> Final output sent to browser
DEBUG - 2024-10-05 20:41:22 --> Total execution time: 0.0316
INFO - 2024-10-05 20:46:05 --> Config Class Initialized
INFO - 2024-10-05 20:46:05 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:46:05 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:46:05 --> Utf8 Class Initialized
INFO - 2024-10-05 20:46:05 --> URI Class Initialized
INFO - 2024-10-05 20:46:05 --> Router Class Initialized
INFO - 2024-10-05 20:46:05 --> Output Class Initialized
INFO - 2024-10-05 20:46:05 --> Security Class Initialized
DEBUG - 2024-10-05 20:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:46:05 --> Input Class Initialized
INFO - 2024-10-05 20:46:05 --> Language Class Initialized
INFO - 2024-10-05 20:46:05 --> Language Class Initialized
INFO - 2024-10-05 20:46:05 --> Config Class Initialized
INFO - 2024-10-05 20:46:05 --> Loader Class Initialized
INFO - 2024-10-05 20:46:05 --> Helper loaded: url_helper
INFO - 2024-10-05 20:46:05 --> Helper loaded: file_helper
INFO - 2024-10-05 20:46:05 --> Helper loaded: form_helper
INFO - 2024-10-05 20:46:05 --> Helper loaded: my_helper
INFO - 2024-10-05 20:46:05 --> Database Driver Class Initialized
INFO - 2024-10-05 20:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:46:06 --> Controller Class Initialized
INFO - 2024-10-05 20:46:06 --> Final output sent to browser
DEBUG - 2024-10-05 20:46:06 --> Total execution time: 0.0465
INFO - 2024-10-05 20:46:10 --> Config Class Initialized
INFO - 2024-10-05 20:46:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:46:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:46:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:46:10 --> URI Class Initialized
INFO - 2024-10-05 20:46:10 --> Router Class Initialized
INFO - 2024-10-05 20:46:10 --> Output Class Initialized
INFO - 2024-10-05 20:46:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:46:10 --> Input Class Initialized
INFO - 2024-10-05 20:46:10 --> Language Class Initialized
INFO - 2024-10-05 20:46:10 --> Language Class Initialized
INFO - 2024-10-05 20:46:10 --> Config Class Initialized
INFO - 2024-10-05 20:46:10 --> Loader Class Initialized
INFO - 2024-10-05 20:46:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:46:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:46:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:46:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:46:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:46:10 --> Controller Class Initialized
INFO - 2024-10-05 20:46:10 --> Final output sent to browser
DEBUG - 2024-10-05 20:46:10 --> Total execution time: 0.0433
INFO - 2024-10-05 20:48:38 --> Config Class Initialized
INFO - 2024-10-05 20:48:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:48:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:48:38 --> Utf8 Class Initialized
INFO - 2024-10-05 20:48:38 --> URI Class Initialized
INFO - 2024-10-05 20:48:38 --> Router Class Initialized
INFO - 2024-10-05 20:48:38 --> Output Class Initialized
INFO - 2024-10-05 20:48:38 --> Security Class Initialized
DEBUG - 2024-10-05 20:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:48:38 --> Input Class Initialized
INFO - 2024-10-05 20:48:38 --> Language Class Initialized
INFO - 2024-10-05 20:48:38 --> Language Class Initialized
INFO - 2024-10-05 20:48:38 --> Config Class Initialized
INFO - 2024-10-05 20:48:38 --> Loader Class Initialized
INFO - 2024-10-05 20:48:38 --> Helper loaded: url_helper
INFO - 2024-10-05 20:48:38 --> Helper loaded: file_helper
INFO - 2024-10-05 20:48:38 --> Helper loaded: form_helper
INFO - 2024-10-05 20:48:38 --> Helper loaded: my_helper
INFO - 2024-10-05 20:48:38 --> Database Driver Class Initialized
INFO - 2024-10-05 20:48:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:48:38 --> Controller Class Initialized
INFO - 2024-10-05 20:48:38 --> Final output sent to browser
DEBUG - 2024-10-05 20:48:38 --> Total execution time: 0.0461
INFO - 2024-10-05 20:48:46 --> Config Class Initialized
INFO - 2024-10-05 20:48:46 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:48:46 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:48:46 --> Utf8 Class Initialized
INFO - 2024-10-05 20:48:46 --> URI Class Initialized
INFO - 2024-10-05 20:48:46 --> Router Class Initialized
INFO - 2024-10-05 20:48:46 --> Output Class Initialized
INFO - 2024-10-05 20:48:46 --> Security Class Initialized
DEBUG - 2024-10-05 20:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:48:46 --> Input Class Initialized
INFO - 2024-10-05 20:48:46 --> Language Class Initialized
INFO - 2024-10-05 20:48:46 --> Language Class Initialized
INFO - 2024-10-05 20:48:46 --> Config Class Initialized
INFO - 2024-10-05 20:48:46 --> Loader Class Initialized
INFO - 2024-10-05 20:48:46 --> Helper loaded: url_helper
INFO - 2024-10-05 20:48:46 --> Helper loaded: file_helper
INFO - 2024-10-05 20:48:46 --> Helper loaded: form_helper
INFO - 2024-10-05 20:48:46 --> Helper loaded: my_helper
INFO - 2024-10-05 20:48:46 --> Database Driver Class Initialized
INFO - 2024-10-05 20:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:48:46 --> Controller Class Initialized
INFO - 2024-10-05 20:48:46 --> Final output sent to browser
DEBUG - 2024-10-05 20:48:46 --> Total execution time: 0.0322
INFO - 2024-10-05 20:49:37 --> Config Class Initialized
INFO - 2024-10-05 20:49:37 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:49:37 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:49:37 --> Utf8 Class Initialized
INFO - 2024-10-05 20:49:37 --> URI Class Initialized
INFO - 2024-10-05 20:49:37 --> Router Class Initialized
INFO - 2024-10-05 20:49:37 --> Output Class Initialized
INFO - 2024-10-05 20:49:37 --> Security Class Initialized
DEBUG - 2024-10-05 20:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:49:37 --> Input Class Initialized
INFO - 2024-10-05 20:49:37 --> Language Class Initialized
INFO - 2024-10-05 20:49:37 --> Language Class Initialized
INFO - 2024-10-05 20:49:37 --> Config Class Initialized
INFO - 2024-10-05 20:49:37 --> Loader Class Initialized
INFO - 2024-10-05 20:49:37 --> Helper loaded: url_helper
INFO - 2024-10-05 20:49:37 --> Helper loaded: file_helper
INFO - 2024-10-05 20:49:37 --> Helper loaded: form_helper
INFO - 2024-10-05 20:49:37 --> Helper loaded: my_helper
INFO - 2024-10-05 20:49:37 --> Database Driver Class Initialized
INFO - 2024-10-05 20:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:49:37 --> Controller Class Initialized
INFO - 2024-10-05 20:49:37 --> Final output sent to browser
DEBUG - 2024-10-05 20:49:37 --> Total execution time: 0.0449
INFO - 2024-10-05 20:49:42 --> Config Class Initialized
INFO - 2024-10-05 20:49:42 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:49:42 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:49:42 --> Utf8 Class Initialized
INFO - 2024-10-05 20:49:42 --> URI Class Initialized
INFO - 2024-10-05 20:49:42 --> Router Class Initialized
INFO - 2024-10-05 20:49:42 --> Output Class Initialized
INFO - 2024-10-05 20:49:42 --> Security Class Initialized
DEBUG - 2024-10-05 20:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:49:42 --> Input Class Initialized
INFO - 2024-10-05 20:49:42 --> Language Class Initialized
INFO - 2024-10-05 20:49:42 --> Language Class Initialized
INFO - 2024-10-05 20:49:42 --> Config Class Initialized
INFO - 2024-10-05 20:49:42 --> Loader Class Initialized
INFO - 2024-10-05 20:49:42 --> Helper loaded: url_helper
INFO - 2024-10-05 20:49:42 --> Helper loaded: file_helper
INFO - 2024-10-05 20:49:42 --> Helper loaded: form_helper
INFO - 2024-10-05 20:49:42 --> Helper loaded: my_helper
INFO - 2024-10-05 20:49:42 --> Database Driver Class Initialized
INFO - 2024-10-05 20:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:49:42 --> Controller Class Initialized
INFO - 2024-10-05 20:49:42 --> Final output sent to browser
DEBUG - 2024-10-05 20:49:42 --> Total execution time: 0.0349
INFO - 2024-10-05 20:49:45 --> Config Class Initialized
INFO - 2024-10-05 20:49:45 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:49:45 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:49:45 --> Utf8 Class Initialized
INFO - 2024-10-05 20:49:45 --> URI Class Initialized
INFO - 2024-10-05 20:49:45 --> Router Class Initialized
INFO - 2024-10-05 20:49:45 --> Output Class Initialized
INFO - 2024-10-05 20:49:45 --> Security Class Initialized
DEBUG - 2024-10-05 20:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:49:45 --> Input Class Initialized
INFO - 2024-10-05 20:49:45 --> Language Class Initialized
INFO - 2024-10-05 20:49:45 --> Language Class Initialized
INFO - 2024-10-05 20:49:45 --> Config Class Initialized
INFO - 2024-10-05 20:49:45 --> Loader Class Initialized
INFO - 2024-10-05 20:49:45 --> Helper loaded: url_helper
INFO - 2024-10-05 20:49:45 --> Helper loaded: file_helper
INFO - 2024-10-05 20:49:45 --> Helper loaded: form_helper
INFO - 2024-10-05 20:49:45 --> Helper loaded: my_helper
INFO - 2024-10-05 20:49:45 --> Database Driver Class Initialized
INFO - 2024-10-05 20:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:49:45 --> Controller Class Initialized
INFO - 2024-10-05 20:49:45 --> Final output sent to browser
DEBUG - 2024-10-05 20:49:45 --> Total execution time: 0.0956
INFO - 2024-10-05 20:49:47 --> Config Class Initialized
INFO - 2024-10-05 20:49:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:49:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:49:47 --> Utf8 Class Initialized
INFO - 2024-10-05 20:49:47 --> URI Class Initialized
INFO - 2024-10-05 20:49:47 --> Router Class Initialized
INFO - 2024-10-05 20:49:47 --> Output Class Initialized
INFO - 2024-10-05 20:49:47 --> Security Class Initialized
DEBUG - 2024-10-05 20:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:49:47 --> Input Class Initialized
INFO - 2024-10-05 20:49:47 --> Language Class Initialized
INFO - 2024-10-05 20:49:47 --> Language Class Initialized
INFO - 2024-10-05 20:49:47 --> Config Class Initialized
INFO - 2024-10-05 20:49:47 --> Loader Class Initialized
INFO - 2024-10-05 20:49:47 --> Helper loaded: url_helper
INFO - 2024-10-05 20:49:47 --> Helper loaded: file_helper
INFO - 2024-10-05 20:49:47 --> Helper loaded: form_helper
INFO - 2024-10-05 20:49:47 --> Helper loaded: my_helper
INFO - 2024-10-05 20:49:47 --> Database Driver Class Initialized
INFO - 2024-10-05 20:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:49:47 --> Controller Class Initialized
INFO - 2024-10-05 20:49:47 --> Final output sent to browser
DEBUG - 2024-10-05 20:49:47 --> Total execution time: 0.0324
INFO - 2024-10-05 20:51:38 --> Config Class Initialized
INFO - 2024-10-05 20:51:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:51:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:51:38 --> Utf8 Class Initialized
INFO - 2024-10-05 20:51:38 --> URI Class Initialized
INFO - 2024-10-05 20:51:38 --> Router Class Initialized
INFO - 2024-10-05 20:51:38 --> Output Class Initialized
INFO - 2024-10-05 20:51:38 --> Security Class Initialized
DEBUG - 2024-10-05 20:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:51:38 --> Input Class Initialized
INFO - 2024-10-05 20:51:38 --> Language Class Initialized
INFO - 2024-10-05 20:51:38 --> Language Class Initialized
INFO - 2024-10-05 20:51:38 --> Config Class Initialized
INFO - 2024-10-05 20:51:38 --> Loader Class Initialized
INFO - 2024-10-05 20:51:38 --> Helper loaded: url_helper
INFO - 2024-10-05 20:51:38 --> Helper loaded: file_helper
INFO - 2024-10-05 20:51:38 --> Helper loaded: form_helper
INFO - 2024-10-05 20:51:38 --> Helper loaded: my_helper
INFO - 2024-10-05 20:51:38 --> Database Driver Class Initialized
INFO - 2024-10-05 20:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:51:38 --> Controller Class Initialized
INFO - 2024-10-05 20:51:38 --> Final output sent to browser
DEBUG - 2024-10-05 20:51:38 --> Total execution time: 0.0725
INFO - 2024-10-05 20:51:42 --> Config Class Initialized
INFO - 2024-10-05 20:51:42 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:51:42 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:51:42 --> Utf8 Class Initialized
INFO - 2024-10-05 20:51:42 --> URI Class Initialized
INFO - 2024-10-05 20:51:42 --> Router Class Initialized
INFO - 2024-10-05 20:51:42 --> Output Class Initialized
INFO - 2024-10-05 20:51:42 --> Security Class Initialized
DEBUG - 2024-10-05 20:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:51:42 --> Input Class Initialized
INFO - 2024-10-05 20:51:42 --> Language Class Initialized
INFO - 2024-10-05 20:51:42 --> Language Class Initialized
INFO - 2024-10-05 20:51:42 --> Config Class Initialized
INFO - 2024-10-05 20:51:42 --> Loader Class Initialized
INFO - 2024-10-05 20:51:42 --> Helper loaded: url_helper
INFO - 2024-10-05 20:51:42 --> Helper loaded: file_helper
INFO - 2024-10-05 20:51:42 --> Helper loaded: form_helper
INFO - 2024-10-05 20:51:42 --> Helper loaded: my_helper
INFO - 2024-10-05 20:51:42 --> Database Driver Class Initialized
INFO - 2024-10-05 20:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:51:42 --> Controller Class Initialized
INFO - 2024-10-05 20:51:42 --> Final output sent to browser
DEBUG - 2024-10-05 20:51:42 --> Total execution time: 0.0345
INFO - 2024-10-05 20:52:18 --> Config Class Initialized
INFO - 2024-10-05 20:52:18 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:52:18 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:52:18 --> Utf8 Class Initialized
INFO - 2024-10-05 20:52:18 --> URI Class Initialized
INFO - 2024-10-05 20:52:18 --> Router Class Initialized
INFO - 2024-10-05 20:52:18 --> Output Class Initialized
INFO - 2024-10-05 20:52:18 --> Security Class Initialized
DEBUG - 2024-10-05 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:52:18 --> Input Class Initialized
INFO - 2024-10-05 20:52:18 --> Language Class Initialized
INFO - 2024-10-05 20:52:18 --> Language Class Initialized
INFO - 2024-10-05 20:52:18 --> Config Class Initialized
INFO - 2024-10-05 20:52:18 --> Loader Class Initialized
INFO - 2024-10-05 20:52:18 --> Helper loaded: url_helper
INFO - 2024-10-05 20:52:18 --> Helper loaded: file_helper
INFO - 2024-10-05 20:52:18 --> Helper loaded: form_helper
INFO - 2024-10-05 20:52:18 --> Helper loaded: my_helper
INFO - 2024-10-05 20:52:18 --> Database Driver Class Initialized
INFO - 2024-10-05 20:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:52:18 --> Controller Class Initialized
INFO - 2024-10-05 20:52:18 --> Final output sent to browser
DEBUG - 2024-10-05 20:52:18 --> Total execution time: 0.3685
INFO - 2024-10-05 20:52:29 --> Config Class Initialized
INFO - 2024-10-05 20:52:29 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:52:29 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:52:29 --> Utf8 Class Initialized
INFO - 2024-10-05 20:52:29 --> URI Class Initialized
INFO - 2024-10-05 20:52:29 --> Router Class Initialized
INFO - 2024-10-05 20:52:29 --> Output Class Initialized
INFO - 2024-10-05 20:52:29 --> Security Class Initialized
DEBUG - 2024-10-05 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:52:29 --> Input Class Initialized
INFO - 2024-10-05 20:52:29 --> Language Class Initialized
INFO - 2024-10-05 20:52:29 --> Language Class Initialized
INFO - 2024-10-05 20:52:29 --> Config Class Initialized
INFO - 2024-10-05 20:52:29 --> Loader Class Initialized
INFO - 2024-10-05 20:52:29 --> Helper loaded: url_helper
INFO - 2024-10-05 20:52:29 --> Helper loaded: file_helper
INFO - 2024-10-05 20:52:29 --> Helper loaded: form_helper
INFO - 2024-10-05 20:52:29 --> Helper loaded: my_helper
INFO - 2024-10-05 20:52:29 --> Database Driver Class Initialized
INFO - 2024-10-05 20:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:52:29 --> Controller Class Initialized
INFO - 2024-10-05 20:52:29 --> Final output sent to browser
DEBUG - 2024-10-05 20:52:29 --> Total execution time: 0.0835
INFO - 2024-10-05 20:52:33 --> Config Class Initialized
INFO - 2024-10-05 20:52:33 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:52:33 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:52:33 --> Utf8 Class Initialized
INFO - 2024-10-05 20:52:33 --> URI Class Initialized
INFO - 2024-10-05 20:52:33 --> Router Class Initialized
INFO - 2024-10-05 20:52:33 --> Output Class Initialized
INFO - 2024-10-05 20:52:33 --> Security Class Initialized
DEBUG - 2024-10-05 20:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:52:33 --> Input Class Initialized
INFO - 2024-10-05 20:52:33 --> Language Class Initialized
INFO - 2024-10-05 20:52:33 --> Language Class Initialized
INFO - 2024-10-05 20:52:33 --> Config Class Initialized
INFO - 2024-10-05 20:52:33 --> Loader Class Initialized
INFO - 2024-10-05 20:52:33 --> Helper loaded: url_helper
INFO - 2024-10-05 20:52:33 --> Helper loaded: file_helper
INFO - 2024-10-05 20:52:33 --> Helper loaded: form_helper
INFO - 2024-10-05 20:52:33 --> Helper loaded: my_helper
INFO - 2024-10-05 20:52:33 --> Database Driver Class Initialized
INFO - 2024-10-05 20:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:52:33 --> Controller Class Initialized
INFO - 2024-10-05 20:52:33 --> Final output sent to browser
DEBUG - 2024-10-05 20:52:33 --> Total execution time: 0.0286
INFO - 2024-10-05 20:54:10 --> Config Class Initialized
INFO - 2024-10-05 20:54:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:54:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:54:10 --> Utf8 Class Initialized
INFO - 2024-10-05 20:54:10 --> URI Class Initialized
INFO - 2024-10-05 20:54:10 --> Router Class Initialized
INFO - 2024-10-05 20:54:10 --> Output Class Initialized
INFO - 2024-10-05 20:54:10 --> Security Class Initialized
DEBUG - 2024-10-05 20:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:54:10 --> Input Class Initialized
INFO - 2024-10-05 20:54:10 --> Language Class Initialized
INFO - 2024-10-05 20:54:10 --> Language Class Initialized
INFO - 2024-10-05 20:54:10 --> Config Class Initialized
INFO - 2024-10-05 20:54:10 --> Loader Class Initialized
INFO - 2024-10-05 20:54:10 --> Helper loaded: url_helper
INFO - 2024-10-05 20:54:10 --> Helper loaded: file_helper
INFO - 2024-10-05 20:54:10 --> Helper loaded: form_helper
INFO - 2024-10-05 20:54:10 --> Helper loaded: my_helper
INFO - 2024-10-05 20:54:10 --> Database Driver Class Initialized
INFO - 2024-10-05 20:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:54:10 --> Controller Class Initialized
INFO - 2024-10-05 20:54:10 --> Final output sent to browser
DEBUG - 2024-10-05 20:54:10 --> Total execution time: 0.1138
INFO - 2024-10-05 20:54:14 --> Config Class Initialized
INFO - 2024-10-05 20:54:14 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:54:14 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:54:14 --> Utf8 Class Initialized
INFO - 2024-10-05 20:54:14 --> URI Class Initialized
INFO - 2024-10-05 20:54:14 --> Router Class Initialized
INFO - 2024-10-05 20:54:14 --> Output Class Initialized
INFO - 2024-10-05 20:54:14 --> Security Class Initialized
DEBUG - 2024-10-05 20:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:54:14 --> Input Class Initialized
INFO - 2024-10-05 20:54:14 --> Language Class Initialized
INFO - 2024-10-05 20:54:14 --> Language Class Initialized
INFO - 2024-10-05 20:54:14 --> Config Class Initialized
INFO - 2024-10-05 20:54:14 --> Loader Class Initialized
INFO - 2024-10-05 20:54:14 --> Helper loaded: url_helper
INFO - 2024-10-05 20:54:14 --> Helper loaded: file_helper
INFO - 2024-10-05 20:54:14 --> Helper loaded: form_helper
INFO - 2024-10-05 20:54:14 --> Helper loaded: my_helper
INFO - 2024-10-05 20:54:14 --> Database Driver Class Initialized
INFO - 2024-10-05 20:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:54:14 --> Controller Class Initialized
INFO - 2024-10-05 20:54:14 --> Final output sent to browser
DEBUG - 2024-10-05 20:54:14 --> Total execution time: 0.0573
INFO - 2024-10-05 20:55:49 --> Config Class Initialized
INFO - 2024-10-05 20:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-05 20:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-05 20:55:49 --> Utf8 Class Initialized
INFO - 2024-10-05 20:55:49 --> URI Class Initialized
INFO - 2024-10-05 20:55:49 --> Router Class Initialized
INFO - 2024-10-05 20:55:49 --> Output Class Initialized
INFO - 2024-10-05 20:55:49 --> Security Class Initialized
DEBUG - 2024-10-05 20:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 20:55:49 --> Input Class Initialized
INFO - 2024-10-05 20:55:49 --> Language Class Initialized
INFO - 2024-10-05 20:55:49 --> Language Class Initialized
INFO - 2024-10-05 20:55:49 --> Config Class Initialized
INFO - 2024-10-05 20:55:49 --> Loader Class Initialized
INFO - 2024-10-05 20:55:49 --> Helper loaded: url_helper
INFO - 2024-10-05 20:55:49 --> Helper loaded: file_helper
INFO - 2024-10-05 20:55:49 --> Helper loaded: form_helper
INFO - 2024-10-05 20:55:49 --> Helper loaded: my_helper
INFO - 2024-10-05 20:55:49 --> Database Driver Class Initialized
INFO - 2024-10-05 20:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 20:55:49 --> Controller Class Initialized
INFO - 2024-10-05 20:55:49 --> Final output sent to browser
DEBUG - 2024-10-05 20:55:49 --> Total execution time: 0.0652
INFO - 2024-10-05 21:08:57 --> Config Class Initialized
INFO - 2024-10-05 21:08:57 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:08:57 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:08:57 --> Utf8 Class Initialized
INFO - 2024-10-05 21:08:57 --> URI Class Initialized
INFO - 2024-10-05 21:08:57 --> Router Class Initialized
INFO - 2024-10-05 21:08:57 --> Output Class Initialized
INFO - 2024-10-05 21:08:57 --> Security Class Initialized
DEBUG - 2024-10-05 21:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:08:57 --> Input Class Initialized
INFO - 2024-10-05 21:08:57 --> Language Class Initialized
INFO - 2024-10-05 21:08:57 --> Language Class Initialized
INFO - 2024-10-05 21:08:57 --> Config Class Initialized
INFO - 2024-10-05 21:08:57 --> Loader Class Initialized
INFO - 2024-10-05 21:08:57 --> Helper loaded: url_helper
INFO - 2024-10-05 21:08:57 --> Helper loaded: file_helper
INFO - 2024-10-05 21:08:57 --> Helper loaded: form_helper
INFO - 2024-10-05 21:08:57 --> Helper loaded: my_helper
INFO - 2024-10-05 21:08:57 --> Database Driver Class Initialized
INFO - 2024-10-05 21:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:08:57 --> Controller Class Initialized
INFO - 2024-10-05 21:08:57 --> Final output sent to browser
DEBUG - 2024-10-05 21:08:57 --> Total execution time: 0.0845
INFO - 2024-10-05 21:09:26 --> Config Class Initialized
INFO - 2024-10-05 21:09:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:09:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:09:26 --> Utf8 Class Initialized
INFO - 2024-10-05 21:09:26 --> URI Class Initialized
INFO - 2024-10-05 21:09:26 --> Router Class Initialized
INFO - 2024-10-05 21:09:26 --> Output Class Initialized
INFO - 2024-10-05 21:09:26 --> Security Class Initialized
DEBUG - 2024-10-05 21:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:09:26 --> Input Class Initialized
INFO - 2024-10-05 21:09:26 --> Language Class Initialized
INFO - 2024-10-05 21:09:26 --> Language Class Initialized
INFO - 2024-10-05 21:09:26 --> Config Class Initialized
INFO - 2024-10-05 21:09:26 --> Loader Class Initialized
INFO - 2024-10-05 21:09:26 --> Helper loaded: url_helper
INFO - 2024-10-05 21:09:26 --> Helper loaded: file_helper
INFO - 2024-10-05 21:09:26 --> Helper loaded: form_helper
INFO - 2024-10-05 21:09:26 --> Helper loaded: my_helper
INFO - 2024-10-05 21:09:26 --> Database Driver Class Initialized
INFO - 2024-10-05 21:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:09:26 --> Controller Class Initialized
INFO - 2024-10-05 21:09:26 --> Final output sent to browser
DEBUG - 2024-10-05 21:09:26 --> Total execution time: 0.0825
INFO - 2024-10-05 21:09:31 --> Config Class Initialized
INFO - 2024-10-05 21:09:31 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:09:31 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:09:31 --> Utf8 Class Initialized
INFO - 2024-10-05 21:09:31 --> URI Class Initialized
INFO - 2024-10-05 21:09:31 --> Router Class Initialized
INFO - 2024-10-05 21:09:31 --> Output Class Initialized
INFO - 2024-10-05 21:09:31 --> Security Class Initialized
DEBUG - 2024-10-05 21:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:09:31 --> Input Class Initialized
INFO - 2024-10-05 21:09:31 --> Language Class Initialized
INFO - 2024-10-05 21:09:31 --> Language Class Initialized
INFO - 2024-10-05 21:09:31 --> Config Class Initialized
INFO - 2024-10-05 21:09:31 --> Loader Class Initialized
INFO - 2024-10-05 21:09:31 --> Helper loaded: url_helper
INFO - 2024-10-05 21:09:31 --> Helper loaded: file_helper
INFO - 2024-10-05 21:09:31 --> Helper loaded: form_helper
INFO - 2024-10-05 21:09:31 --> Helper loaded: my_helper
INFO - 2024-10-05 21:09:31 --> Database Driver Class Initialized
INFO - 2024-10-05 21:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:09:31 --> Controller Class Initialized
DEBUG - 2024-10-05 21:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 21:09:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:09:31 --> Final output sent to browser
DEBUG - 2024-10-05 21:09:31 --> Total execution time: 0.0358
INFO - 2024-10-05 21:09:35 --> Config Class Initialized
INFO - 2024-10-05 21:09:35 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:09:35 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:09:35 --> Utf8 Class Initialized
INFO - 2024-10-05 21:09:35 --> URI Class Initialized
INFO - 2024-10-05 21:09:35 --> Router Class Initialized
INFO - 2024-10-05 21:09:35 --> Output Class Initialized
INFO - 2024-10-05 21:09:35 --> Security Class Initialized
DEBUG - 2024-10-05 21:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:09:35 --> Input Class Initialized
INFO - 2024-10-05 21:09:35 --> Language Class Initialized
INFO - 2024-10-05 21:09:35 --> Language Class Initialized
INFO - 2024-10-05 21:09:35 --> Config Class Initialized
INFO - 2024-10-05 21:09:35 --> Loader Class Initialized
INFO - 2024-10-05 21:09:35 --> Helper loaded: url_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: file_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: form_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: my_helper
INFO - 2024-10-05 21:09:35 --> Database Driver Class Initialized
INFO - 2024-10-05 21:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:09:35 --> Controller Class Initialized
DEBUG - 2024-10-05 21:09:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-05 21:09:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:09:35 --> Final output sent to browser
DEBUG - 2024-10-05 21:09:35 --> Total execution time: 0.0521
INFO - 2024-10-05 21:09:35 --> Config Class Initialized
INFO - 2024-10-05 21:09:35 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:09:35 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:09:35 --> Utf8 Class Initialized
INFO - 2024-10-05 21:09:35 --> URI Class Initialized
INFO - 2024-10-05 21:09:35 --> Router Class Initialized
INFO - 2024-10-05 21:09:35 --> Output Class Initialized
INFO - 2024-10-05 21:09:35 --> Security Class Initialized
DEBUG - 2024-10-05 21:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:09:35 --> Input Class Initialized
INFO - 2024-10-05 21:09:35 --> Language Class Initialized
INFO - 2024-10-05 21:09:35 --> Language Class Initialized
INFO - 2024-10-05 21:09:35 --> Config Class Initialized
INFO - 2024-10-05 21:09:35 --> Loader Class Initialized
INFO - 2024-10-05 21:09:35 --> Helper loaded: url_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: file_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: form_helper
INFO - 2024-10-05 21:09:35 --> Helper loaded: my_helper
INFO - 2024-10-05 21:09:35 --> Database Driver Class Initialized
INFO - 2024-10-05 21:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:09:35 --> Controller Class Initialized
INFO - 2024-10-05 21:09:55 --> Config Class Initialized
INFO - 2024-10-05 21:09:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:09:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:09:55 --> Utf8 Class Initialized
INFO - 2024-10-05 21:09:55 --> URI Class Initialized
INFO - 2024-10-05 21:09:55 --> Router Class Initialized
INFO - 2024-10-05 21:09:55 --> Output Class Initialized
INFO - 2024-10-05 21:09:55 --> Security Class Initialized
DEBUG - 2024-10-05 21:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:09:55 --> Input Class Initialized
INFO - 2024-10-05 21:09:55 --> Language Class Initialized
INFO - 2024-10-05 21:09:55 --> Language Class Initialized
INFO - 2024-10-05 21:09:55 --> Config Class Initialized
INFO - 2024-10-05 21:09:55 --> Loader Class Initialized
INFO - 2024-10-05 21:09:55 --> Helper loaded: url_helper
INFO - 2024-10-05 21:09:55 --> Helper loaded: file_helper
INFO - 2024-10-05 21:09:55 --> Helper loaded: form_helper
INFO - 2024-10-05 21:09:55 --> Helper loaded: my_helper
INFO - 2024-10-05 21:09:55 --> Database Driver Class Initialized
INFO - 2024-10-05 21:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:09:55 --> Controller Class Initialized
INFO - 2024-10-05 21:09:55 --> Final output sent to browser
DEBUG - 2024-10-05 21:09:55 --> Total execution time: 0.0407
INFO - 2024-10-05 21:10:35 --> Config Class Initialized
INFO - 2024-10-05 21:10:35 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:10:35 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:10:35 --> Utf8 Class Initialized
INFO - 2024-10-05 21:10:35 --> URI Class Initialized
INFO - 2024-10-05 21:10:35 --> Router Class Initialized
INFO - 2024-10-05 21:10:35 --> Output Class Initialized
INFO - 2024-10-05 21:10:35 --> Security Class Initialized
DEBUG - 2024-10-05 21:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:10:35 --> Input Class Initialized
INFO - 2024-10-05 21:10:35 --> Language Class Initialized
INFO - 2024-10-05 21:10:35 --> Language Class Initialized
INFO - 2024-10-05 21:10:35 --> Config Class Initialized
INFO - 2024-10-05 21:10:35 --> Loader Class Initialized
INFO - 2024-10-05 21:10:35 --> Helper loaded: url_helper
INFO - 2024-10-05 21:10:35 --> Helper loaded: file_helper
INFO - 2024-10-05 21:10:35 --> Helper loaded: form_helper
INFO - 2024-10-05 21:10:35 --> Helper loaded: my_helper
INFO - 2024-10-05 21:10:35 --> Database Driver Class Initialized
INFO - 2024-10-05 21:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:10:35 --> Controller Class Initialized
INFO - 2024-10-05 21:10:35 --> Final output sent to browser
DEBUG - 2024-10-05 21:10:35 --> Total execution time: 0.0479
INFO - 2024-10-05 21:10:39 --> Config Class Initialized
INFO - 2024-10-05 21:10:39 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:10:39 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:10:39 --> Utf8 Class Initialized
INFO - 2024-10-05 21:10:39 --> URI Class Initialized
INFO - 2024-10-05 21:10:39 --> Router Class Initialized
INFO - 2024-10-05 21:10:39 --> Output Class Initialized
INFO - 2024-10-05 21:10:39 --> Security Class Initialized
DEBUG - 2024-10-05 21:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:10:39 --> Input Class Initialized
INFO - 2024-10-05 21:10:39 --> Language Class Initialized
INFO - 2024-10-05 21:10:39 --> Language Class Initialized
INFO - 2024-10-05 21:10:39 --> Config Class Initialized
INFO - 2024-10-05 21:10:39 --> Loader Class Initialized
INFO - 2024-10-05 21:10:39 --> Helper loaded: url_helper
INFO - 2024-10-05 21:10:39 --> Helper loaded: file_helper
INFO - 2024-10-05 21:10:39 --> Helper loaded: form_helper
INFO - 2024-10-05 21:10:39 --> Helper loaded: my_helper
INFO - 2024-10-05 21:10:39 --> Database Driver Class Initialized
INFO - 2024-10-05 21:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:10:39 --> Controller Class Initialized
INFO - 2024-10-05 21:10:39 --> Final output sent to browser
DEBUG - 2024-10-05 21:10:39 --> Total execution time: 0.0330
INFO - 2024-10-05 21:11:30 --> Config Class Initialized
INFO - 2024-10-05 21:11:30 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:11:30 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:11:30 --> Utf8 Class Initialized
INFO - 2024-10-05 21:11:30 --> URI Class Initialized
INFO - 2024-10-05 21:11:30 --> Router Class Initialized
INFO - 2024-10-05 21:11:30 --> Output Class Initialized
INFO - 2024-10-05 21:11:30 --> Security Class Initialized
DEBUG - 2024-10-05 21:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:11:30 --> Input Class Initialized
INFO - 2024-10-05 21:11:30 --> Language Class Initialized
INFO - 2024-10-05 21:11:30 --> Language Class Initialized
INFO - 2024-10-05 21:11:30 --> Config Class Initialized
INFO - 2024-10-05 21:11:30 --> Loader Class Initialized
INFO - 2024-10-05 21:11:30 --> Helper loaded: url_helper
INFO - 2024-10-05 21:11:30 --> Helper loaded: file_helper
INFO - 2024-10-05 21:11:30 --> Helper loaded: form_helper
INFO - 2024-10-05 21:11:30 --> Helper loaded: my_helper
INFO - 2024-10-05 21:11:30 --> Database Driver Class Initialized
INFO - 2024-10-05 21:11:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:11:30 --> Controller Class Initialized
INFO - 2024-10-05 21:11:30 --> Final output sent to browser
DEBUG - 2024-10-05 21:11:30 --> Total execution time: 0.0527
INFO - 2024-10-05 21:11:36 --> Config Class Initialized
INFO - 2024-10-05 21:11:36 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:11:36 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:11:36 --> Utf8 Class Initialized
INFO - 2024-10-05 21:11:36 --> URI Class Initialized
INFO - 2024-10-05 21:11:36 --> Router Class Initialized
INFO - 2024-10-05 21:11:36 --> Output Class Initialized
INFO - 2024-10-05 21:11:36 --> Security Class Initialized
DEBUG - 2024-10-05 21:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:11:36 --> Input Class Initialized
INFO - 2024-10-05 21:11:36 --> Language Class Initialized
INFO - 2024-10-05 21:11:36 --> Language Class Initialized
INFO - 2024-10-05 21:11:36 --> Config Class Initialized
INFO - 2024-10-05 21:11:36 --> Loader Class Initialized
INFO - 2024-10-05 21:11:36 --> Helper loaded: url_helper
INFO - 2024-10-05 21:11:36 --> Helper loaded: file_helper
INFO - 2024-10-05 21:11:36 --> Helper loaded: form_helper
INFO - 2024-10-05 21:11:36 --> Helper loaded: my_helper
INFO - 2024-10-05 21:11:36 --> Database Driver Class Initialized
INFO - 2024-10-05 21:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:11:36 --> Controller Class Initialized
INFO - 2024-10-05 21:11:36 --> Final output sent to browser
DEBUG - 2024-10-05 21:11:36 --> Total execution time: 0.0700
INFO - 2024-10-05 21:11:40 --> Config Class Initialized
INFO - 2024-10-05 21:11:40 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:11:40 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:11:40 --> Utf8 Class Initialized
INFO - 2024-10-05 21:11:40 --> URI Class Initialized
INFO - 2024-10-05 21:11:40 --> Router Class Initialized
INFO - 2024-10-05 21:11:40 --> Output Class Initialized
INFO - 2024-10-05 21:11:40 --> Security Class Initialized
DEBUG - 2024-10-05 21:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:11:40 --> Input Class Initialized
INFO - 2024-10-05 21:11:40 --> Language Class Initialized
INFO - 2024-10-05 21:11:40 --> Language Class Initialized
INFO - 2024-10-05 21:11:40 --> Config Class Initialized
INFO - 2024-10-05 21:11:40 --> Loader Class Initialized
INFO - 2024-10-05 21:11:40 --> Helper loaded: url_helper
INFO - 2024-10-05 21:11:40 --> Helper loaded: file_helper
INFO - 2024-10-05 21:11:40 --> Helper loaded: form_helper
INFO - 2024-10-05 21:11:40 --> Helper loaded: my_helper
INFO - 2024-10-05 21:11:40 --> Database Driver Class Initialized
INFO - 2024-10-05 21:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:11:40 --> Controller Class Initialized
INFO - 2024-10-05 21:11:40 --> Final output sent to browser
DEBUG - 2024-10-05 21:11:40 --> Total execution time: 0.0388
INFO - 2024-10-05 21:11:52 --> Config Class Initialized
INFO - 2024-10-05 21:11:52 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:11:52 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:11:52 --> Utf8 Class Initialized
INFO - 2024-10-05 21:11:52 --> URI Class Initialized
INFO - 2024-10-05 21:11:52 --> Router Class Initialized
INFO - 2024-10-05 21:11:52 --> Output Class Initialized
INFO - 2024-10-05 21:11:52 --> Security Class Initialized
DEBUG - 2024-10-05 21:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:11:52 --> Input Class Initialized
INFO - 2024-10-05 21:11:52 --> Language Class Initialized
INFO - 2024-10-05 21:11:52 --> Language Class Initialized
INFO - 2024-10-05 21:11:52 --> Config Class Initialized
INFO - 2024-10-05 21:11:52 --> Loader Class Initialized
INFO - 2024-10-05 21:11:52 --> Helper loaded: url_helper
INFO - 2024-10-05 21:11:52 --> Helper loaded: file_helper
INFO - 2024-10-05 21:11:52 --> Helper loaded: form_helper
INFO - 2024-10-05 21:11:52 --> Helper loaded: my_helper
INFO - 2024-10-05 21:11:52 --> Database Driver Class Initialized
INFO - 2024-10-05 21:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:11:52 --> Controller Class Initialized
INFO - 2024-10-05 21:11:52 --> Final output sent to browser
DEBUG - 2024-10-05 21:11:52 --> Total execution time: 0.4265
INFO - 2024-10-05 21:11:55 --> Config Class Initialized
INFO - 2024-10-05 21:11:55 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:11:55 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:11:55 --> Utf8 Class Initialized
INFO - 2024-10-05 21:11:55 --> URI Class Initialized
INFO - 2024-10-05 21:11:55 --> Router Class Initialized
INFO - 2024-10-05 21:11:55 --> Output Class Initialized
INFO - 2024-10-05 21:11:55 --> Security Class Initialized
DEBUG - 2024-10-05 21:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:11:55 --> Input Class Initialized
INFO - 2024-10-05 21:11:55 --> Language Class Initialized
INFO - 2024-10-05 21:11:55 --> Language Class Initialized
INFO - 2024-10-05 21:11:55 --> Config Class Initialized
INFO - 2024-10-05 21:11:55 --> Loader Class Initialized
INFO - 2024-10-05 21:11:55 --> Helper loaded: url_helper
INFO - 2024-10-05 21:11:55 --> Helper loaded: file_helper
INFO - 2024-10-05 21:11:55 --> Helper loaded: form_helper
INFO - 2024-10-05 21:11:55 --> Helper loaded: my_helper
INFO - 2024-10-05 21:11:55 --> Database Driver Class Initialized
INFO - 2024-10-05 21:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:11:55 --> Controller Class Initialized
INFO - 2024-10-05 21:11:55 --> Final output sent to browser
DEBUG - 2024-10-05 21:11:55 --> Total execution time: 0.0352
INFO - 2024-10-05 21:14:12 --> Config Class Initialized
INFO - 2024-10-05 21:14:12 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:14:12 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:14:12 --> Utf8 Class Initialized
INFO - 2024-10-05 21:14:12 --> URI Class Initialized
INFO - 2024-10-05 21:14:12 --> Router Class Initialized
INFO - 2024-10-05 21:14:12 --> Output Class Initialized
INFO - 2024-10-05 21:14:12 --> Security Class Initialized
DEBUG - 2024-10-05 21:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:14:12 --> Input Class Initialized
INFO - 2024-10-05 21:14:12 --> Language Class Initialized
INFO - 2024-10-05 21:14:12 --> Language Class Initialized
INFO - 2024-10-05 21:14:12 --> Config Class Initialized
INFO - 2024-10-05 21:14:12 --> Loader Class Initialized
INFO - 2024-10-05 21:14:12 --> Helper loaded: url_helper
INFO - 2024-10-05 21:14:12 --> Helper loaded: file_helper
INFO - 2024-10-05 21:14:12 --> Helper loaded: form_helper
INFO - 2024-10-05 21:14:12 --> Helper loaded: my_helper
INFO - 2024-10-05 21:14:12 --> Database Driver Class Initialized
INFO - 2024-10-05 21:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:14:12 --> Controller Class Initialized
INFO - 2024-10-05 21:14:12 --> Final output sent to browser
DEBUG - 2024-10-05 21:14:12 --> Total execution time: 0.0613
INFO - 2024-10-05 21:14:26 --> Config Class Initialized
INFO - 2024-10-05 21:14:26 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:14:26 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:14:26 --> Utf8 Class Initialized
INFO - 2024-10-05 21:14:26 --> URI Class Initialized
INFO - 2024-10-05 21:14:26 --> Router Class Initialized
INFO - 2024-10-05 21:14:26 --> Output Class Initialized
INFO - 2024-10-05 21:14:26 --> Security Class Initialized
DEBUG - 2024-10-05 21:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:14:26 --> Input Class Initialized
INFO - 2024-10-05 21:14:26 --> Language Class Initialized
INFO - 2024-10-05 21:14:26 --> Language Class Initialized
INFO - 2024-10-05 21:14:26 --> Config Class Initialized
INFO - 2024-10-05 21:14:26 --> Loader Class Initialized
INFO - 2024-10-05 21:14:26 --> Helper loaded: url_helper
INFO - 2024-10-05 21:14:26 --> Helper loaded: file_helper
INFO - 2024-10-05 21:14:26 --> Helper loaded: form_helper
INFO - 2024-10-05 21:14:26 --> Helper loaded: my_helper
INFO - 2024-10-05 21:14:26 --> Database Driver Class Initialized
INFO - 2024-10-05 21:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:14:26 --> Controller Class Initialized
INFO - 2024-10-05 21:14:26 --> Final output sent to browser
DEBUG - 2024-10-05 21:14:26 --> Total execution time: 0.0430
INFO - 2024-10-05 21:17:37 --> Config Class Initialized
INFO - 2024-10-05 21:17:37 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:17:37 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:17:37 --> Utf8 Class Initialized
INFO - 2024-10-05 21:17:37 --> URI Class Initialized
INFO - 2024-10-05 21:17:37 --> Router Class Initialized
INFO - 2024-10-05 21:17:37 --> Output Class Initialized
INFO - 2024-10-05 21:17:37 --> Security Class Initialized
DEBUG - 2024-10-05 21:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:17:37 --> Input Class Initialized
INFO - 2024-10-05 21:17:37 --> Language Class Initialized
INFO - 2024-10-05 21:17:37 --> Language Class Initialized
INFO - 2024-10-05 21:17:37 --> Config Class Initialized
INFO - 2024-10-05 21:17:37 --> Loader Class Initialized
INFO - 2024-10-05 21:17:37 --> Helper loaded: url_helper
INFO - 2024-10-05 21:17:37 --> Helper loaded: file_helper
INFO - 2024-10-05 21:17:37 --> Helper loaded: form_helper
INFO - 2024-10-05 21:17:37 --> Helper loaded: my_helper
INFO - 2024-10-05 21:17:37 --> Database Driver Class Initialized
INFO - 2024-10-05 21:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:17:37 --> Controller Class Initialized
INFO - 2024-10-05 21:17:37 --> Final output sent to browser
DEBUG - 2024-10-05 21:17:37 --> Total execution time: 0.0491
INFO - 2024-10-05 21:17:50 --> Config Class Initialized
INFO - 2024-10-05 21:17:50 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:17:50 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:17:50 --> Utf8 Class Initialized
INFO - 2024-10-05 21:17:50 --> URI Class Initialized
INFO - 2024-10-05 21:17:50 --> Router Class Initialized
INFO - 2024-10-05 21:17:50 --> Output Class Initialized
INFO - 2024-10-05 21:17:50 --> Security Class Initialized
DEBUG - 2024-10-05 21:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:17:50 --> Input Class Initialized
INFO - 2024-10-05 21:17:50 --> Language Class Initialized
INFO - 2024-10-05 21:17:50 --> Language Class Initialized
INFO - 2024-10-05 21:17:50 --> Config Class Initialized
INFO - 2024-10-05 21:17:50 --> Loader Class Initialized
INFO - 2024-10-05 21:17:50 --> Helper loaded: url_helper
INFO - 2024-10-05 21:17:50 --> Helper loaded: file_helper
INFO - 2024-10-05 21:17:50 --> Helper loaded: form_helper
INFO - 2024-10-05 21:17:50 --> Helper loaded: my_helper
INFO - 2024-10-05 21:17:50 --> Database Driver Class Initialized
INFO - 2024-10-05 21:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:17:50 --> Controller Class Initialized
INFO - 2024-10-05 21:17:50 --> Final output sent to browser
DEBUG - 2024-10-05 21:17:50 --> Total execution time: 0.0328
INFO - 2024-10-05 21:19:03 --> Config Class Initialized
INFO - 2024-10-05 21:19:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:19:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:19:03 --> Utf8 Class Initialized
INFO - 2024-10-05 21:19:03 --> URI Class Initialized
INFO - 2024-10-05 21:19:03 --> Router Class Initialized
INFO - 2024-10-05 21:19:03 --> Output Class Initialized
INFO - 2024-10-05 21:19:03 --> Security Class Initialized
DEBUG - 2024-10-05 21:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:19:03 --> Input Class Initialized
INFO - 2024-10-05 21:19:03 --> Language Class Initialized
INFO - 2024-10-05 21:19:03 --> Language Class Initialized
INFO - 2024-10-05 21:19:03 --> Config Class Initialized
INFO - 2024-10-05 21:19:03 --> Loader Class Initialized
INFO - 2024-10-05 21:19:03 --> Helper loaded: url_helper
INFO - 2024-10-05 21:19:03 --> Helper loaded: file_helper
INFO - 2024-10-05 21:19:03 --> Helper loaded: form_helper
INFO - 2024-10-05 21:19:03 --> Helper loaded: my_helper
INFO - 2024-10-05 21:19:03 --> Database Driver Class Initialized
INFO - 2024-10-05 21:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:19:03 --> Controller Class Initialized
INFO - 2024-10-05 21:19:03 --> Final output sent to browser
DEBUG - 2024-10-05 21:19:03 --> Total execution time: 0.0368
INFO - 2024-10-05 21:19:04 --> Config Class Initialized
INFO - 2024-10-05 21:19:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:19:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:19:04 --> Utf8 Class Initialized
INFO - 2024-10-05 21:19:04 --> URI Class Initialized
INFO - 2024-10-05 21:19:04 --> Router Class Initialized
INFO - 2024-10-05 21:19:04 --> Output Class Initialized
INFO - 2024-10-05 21:19:04 --> Security Class Initialized
DEBUG - 2024-10-05 21:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:19:04 --> Input Class Initialized
INFO - 2024-10-05 21:19:04 --> Language Class Initialized
INFO - 2024-10-05 21:19:04 --> Language Class Initialized
INFO - 2024-10-05 21:19:04 --> Config Class Initialized
INFO - 2024-10-05 21:19:04 --> Loader Class Initialized
INFO - 2024-10-05 21:19:04 --> Helper loaded: url_helper
INFO - 2024-10-05 21:19:04 --> Helper loaded: file_helper
INFO - 2024-10-05 21:19:04 --> Helper loaded: form_helper
INFO - 2024-10-05 21:19:04 --> Helper loaded: my_helper
INFO - 2024-10-05 21:19:04 --> Database Driver Class Initialized
INFO - 2024-10-05 21:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:19:04 --> Controller Class Initialized
INFO - 2024-10-05 21:19:04 --> Final output sent to browser
DEBUG - 2024-10-05 21:19:04 --> Total execution time: 0.0430
INFO - 2024-10-05 21:19:06 --> Config Class Initialized
INFO - 2024-10-05 21:19:06 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:19:06 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:19:06 --> Utf8 Class Initialized
INFO - 2024-10-05 21:19:06 --> URI Class Initialized
INFO - 2024-10-05 21:19:06 --> Router Class Initialized
INFO - 2024-10-05 21:19:06 --> Output Class Initialized
INFO - 2024-10-05 21:19:06 --> Security Class Initialized
DEBUG - 2024-10-05 21:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:19:06 --> Input Class Initialized
INFO - 2024-10-05 21:19:06 --> Language Class Initialized
INFO - 2024-10-05 21:19:06 --> Language Class Initialized
INFO - 2024-10-05 21:19:06 --> Config Class Initialized
INFO - 2024-10-05 21:19:06 --> Loader Class Initialized
INFO - 2024-10-05 21:19:06 --> Helper loaded: url_helper
INFO - 2024-10-05 21:19:06 --> Helper loaded: file_helper
INFO - 2024-10-05 21:19:06 --> Helper loaded: form_helper
INFO - 2024-10-05 21:19:06 --> Helper loaded: my_helper
INFO - 2024-10-05 21:19:06 --> Database Driver Class Initialized
INFO - 2024-10-05 21:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:19:06 --> Controller Class Initialized
INFO - 2024-10-05 21:19:06 --> Final output sent to browser
DEBUG - 2024-10-05 21:19:06 --> Total execution time: 0.0362
INFO - 2024-10-05 21:22:58 --> Config Class Initialized
INFO - 2024-10-05 21:22:58 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:22:58 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:22:58 --> Utf8 Class Initialized
INFO - 2024-10-05 21:22:58 --> URI Class Initialized
INFO - 2024-10-05 21:22:58 --> Router Class Initialized
INFO - 2024-10-05 21:22:58 --> Output Class Initialized
INFO - 2024-10-05 21:22:58 --> Security Class Initialized
DEBUG - 2024-10-05 21:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:22:58 --> Input Class Initialized
INFO - 2024-10-05 21:22:58 --> Language Class Initialized
INFO - 2024-10-05 21:22:58 --> Language Class Initialized
INFO - 2024-10-05 21:22:58 --> Config Class Initialized
INFO - 2024-10-05 21:22:58 --> Loader Class Initialized
INFO - 2024-10-05 21:22:58 --> Helper loaded: url_helper
INFO - 2024-10-05 21:22:58 --> Helper loaded: file_helper
INFO - 2024-10-05 21:22:58 --> Helper loaded: form_helper
INFO - 2024-10-05 21:22:58 --> Helper loaded: my_helper
INFO - 2024-10-05 21:22:58 --> Database Driver Class Initialized
INFO - 2024-10-05 21:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:22:58 --> Controller Class Initialized
INFO - 2024-10-05 21:22:58 --> Final output sent to browser
DEBUG - 2024-10-05 21:22:58 --> Total execution time: 0.0495
INFO - 2024-10-05 21:23:03 --> Config Class Initialized
INFO - 2024-10-05 21:23:03 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:03 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:03 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:03 --> URI Class Initialized
INFO - 2024-10-05 21:23:03 --> Router Class Initialized
INFO - 2024-10-05 21:23:03 --> Output Class Initialized
INFO - 2024-10-05 21:23:03 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:03 --> Input Class Initialized
INFO - 2024-10-05 21:23:03 --> Language Class Initialized
INFO - 2024-10-05 21:23:03 --> Language Class Initialized
INFO - 2024-10-05 21:23:03 --> Config Class Initialized
INFO - 2024-10-05 21:23:03 --> Loader Class Initialized
INFO - 2024-10-05 21:23:03 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:03 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:03 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:03 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:03 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:03 --> Controller Class Initialized
INFO - 2024-10-05 21:23:03 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:03 --> Total execution time: 0.0349
INFO - 2024-10-05 21:23:05 --> Config Class Initialized
INFO - 2024-10-05 21:23:05 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:05 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:05 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:05 --> URI Class Initialized
INFO - 2024-10-05 21:23:05 --> Router Class Initialized
INFO - 2024-10-05 21:23:05 --> Output Class Initialized
INFO - 2024-10-05 21:23:05 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:05 --> Input Class Initialized
INFO - 2024-10-05 21:23:05 --> Language Class Initialized
INFO - 2024-10-05 21:23:05 --> Language Class Initialized
INFO - 2024-10-05 21:23:05 --> Config Class Initialized
INFO - 2024-10-05 21:23:05 --> Loader Class Initialized
INFO - 2024-10-05 21:23:05 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:05 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:05 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:05 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:05 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:05 --> Controller Class Initialized
DEBUG - 2024-10-05 21:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 21:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:23:05 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:05 --> Total execution time: 0.0306
INFO - 2024-10-05 21:23:10 --> Config Class Initialized
INFO - 2024-10-05 21:23:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:10 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:10 --> URI Class Initialized
INFO - 2024-10-05 21:23:10 --> Router Class Initialized
INFO - 2024-10-05 21:23:10 --> Output Class Initialized
INFO - 2024-10-05 21:23:10 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:10 --> Input Class Initialized
INFO - 2024-10-05 21:23:10 --> Language Class Initialized
INFO - 2024-10-05 21:23:10 --> Language Class Initialized
INFO - 2024-10-05 21:23:10 --> Config Class Initialized
INFO - 2024-10-05 21:23:10 --> Loader Class Initialized
INFO - 2024-10-05 21:23:10 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:10 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:10 --> Controller Class Initialized
DEBUG - 2024-10-05 21:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-10-05 21:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:23:10 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:10 --> Total execution time: 0.0335
INFO - 2024-10-05 21:23:10 --> Config Class Initialized
INFO - 2024-10-05 21:23:10 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:10 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:10 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:10 --> URI Class Initialized
INFO - 2024-10-05 21:23:10 --> Router Class Initialized
INFO - 2024-10-05 21:23:10 --> Output Class Initialized
INFO - 2024-10-05 21:23:10 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:10 --> Input Class Initialized
INFO - 2024-10-05 21:23:10 --> Language Class Initialized
INFO - 2024-10-05 21:23:10 --> Language Class Initialized
INFO - 2024-10-05 21:23:10 --> Config Class Initialized
INFO - 2024-10-05 21:23:10 --> Loader Class Initialized
INFO - 2024-10-05 21:23:10 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:10 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:10 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:10 --> Controller Class Initialized
INFO - 2024-10-05 21:23:15 --> Config Class Initialized
INFO - 2024-10-05 21:23:15 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:15 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:15 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:15 --> URI Class Initialized
INFO - 2024-10-05 21:23:15 --> Router Class Initialized
INFO - 2024-10-05 21:23:15 --> Output Class Initialized
INFO - 2024-10-05 21:23:15 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:15 --> Input Class Initialized
INFO - 2024-10-05 21:23:15 --> Language Class Initialized
INFO - 2024-10-05 21:23:15 --> Language Class Initialized
INFO - 2024-10-05 21:23:15 --> Config Class Initialized
INFO - 2024-10-05 21:23:15 --> Loader Class Initialized
INFO - 2024-10-05 21:23:15 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:15 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:15 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:15 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:15 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:15 --> Controller Class Initialized
DEBUG - 2024-10-05 21:23:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 21:23:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:23:15 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:15 --> Total execution time: 0.0321
INFO - 2024-10-05 21:23:20 --> Config Class Initialized
INFO - 2024-10-05 21:23:20 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:20 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:20 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:20 --> URI Class Initialized
INFO - 2024-10-05 21:23:20 --> Router Class Initialized
INFO - 2024-10-05 21:23:20 --> Output Class Initialized
INFO - 2024-10-05 21:23:20 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:20 --> Input Class Initialized
INFO - 2024-10-05 21:23:20 --> Language Class Initialized
INFO - 2024-10-05 21:23:20 --> Language Class Initialized
INFO - 2024-10-05 21:23:20 --> Config Class Initialized
INFO - 2024-10-05 21:23:20 --> Loader Class Initialized
INFO - 2024-10-05 21:23:20 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:20 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:20 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:20 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:20 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:20 --> Controller Class Initialized
DEBUG - 2024-10-05 21:23:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-10-05 21:23:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:23:20 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:20 --> Total execution time: 0.0363
INFO - 2024-10-05 21:23:21 --> Config Class Initialized
INFO - 2024-10-05 21:23:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:21 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:21 --> URI Class Initialized
INFO - 2024-10-05 21:23:21 --> Router Class Initialized
INFO - 2024-10-05 21:23:21 --> Output Class Initialized
INFO - 2024-10-05 21:23:21 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:21 --> Input Class Initialized
INFO - 2024-10-05 21:23:21 --> Language Class Initialized
INFO - 2024-10-05 21:23:21 --> Language Class Initialized
INFO - 2024-10-05 21:23:21 --> Config Class Initialized
INFO - 2024-10-05 21:23:21 --> Loader Class Initialized
INFO - 2024-10-05 21:23:21 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:21 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:21 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:21 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:21 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:21 --> Controller Class Initialized
INFO - 2024-10-05 21:23:23 --> Config Class Initialized
INFO - 2024-10-05 21:23:23 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:23 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:23 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:23 --> URI Class Initialized
INFO - 2024-10-05 21:23:23 --> Router Class Initialized
INFO - 2024-10-05 21:23:23 --> Output Class Initialized
INFO - 2024-10-05 21:23:23 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:23 --> Input Class Initialized
INFO - 2024-10-05 21:23:23 --> Language Class Initialized
INFO - 2024-10-05 21:23:23 --> Language Class Initialized
INFO - 2024-10-05 21:23:23 --> Config Class Initialized
INFO - 2024-10-05 21:23:23 --> Loader Class Initialized
INFO - 2024-10-05 21:23:23 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:23 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:23 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:23 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:23 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:23 --> Controller Class Initialized
INFO - 2024-10-05 21:23:23 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:23 --> Total execution time: 0.0440
INFO - 2024-10-05 21:23:56 --> Config Class Initialized
INFO - 2024-10-05 21:23:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:23:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:23:56 --> Utf8 Class Initialized
INFO - 2024-10-05 21:23:56 --> URI Class Initialized
INFO - 2024-10-05 21:23:56 --> Router Class Initialized
INFO - 2024-10-05 21:23:56 --> Output Class Initialized
INFO - 2024-10-05 21:23:56 --> Security Class Initialized
DEBUG - 2024-10-05 21:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:23:56 --> Input Class Initialized
INFO - 2024-10-05 21:23:56 --> Language Class Initialized
INFO - 2024-10-05 21:23:56 --> Language Class Initialized
INFO - 2024-10-05 21:23:56 --> Config Class Initialized
INFO - 2024-10-05 21:23:56 --> Loader Class Initialized
INFO - 2024-10-05 21:23:56 --> Helper loaded: url_helper
INFO - 2024-10-05 21:23:56 --> Helper loaded: file_helper
INFO - 2024-10-05 21:23:56 --> Helper loaded: form_helper
INFO - 2024-10-05 21:23:56 --> Helper loaded: my_helper
INFO - 2024-10-05 21:23:56 --> Database Driver Class Initialized
INFO - 2024-10-05 21:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:23:56 --> Controller Class Initialized
INFO - 2024-10-05 21:23:56 --> Final output sent to browser
DEBUG - 2024-10-05 21:23:56 --> Total execution time: 0.0487
INFO - 2024-10-05 21:24:00 --> Config Class Initialized
INFO - 2024-10-05 21:24:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:24:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:24:00 --> Utf8 Class Initialized
INFO - 2024-10-05 21:24:00 --> URI Class Initialized
INFO - 2024-10-05 21:24:00 --> Router Class Initialized
INFO - 2024-10-05 21:24:00 --> Output Class Initialized
INFO - 2024-10-05 21:24:00 --> Security Class Initialized
DEBUG - 2024-10-05 21:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:24:00 --> Input Class Initialized
INFO - 2024-10-05 21:24:00 --> Language Class Initialized
INFO - 2024-10-05 21:24:00 --> Language Class Initialized
INFO - 2024-10-05 21:24:00 --> Config Class Initialized
INFO - 2024-10-05 21:24:00 --> Loader Class Initialized
INFO - 2024-10-05 21:24:00 --> Helper loaded: url_helper
INFO - 2024-10-05 21:24:00 --> Helper loaded: file_helper
INFO - 2024-10-05 21:24:00 --> Helper loaded: form_helper
INFO - 2024-10-05 21:24:00 --> Helper loaded: my_helper
INFO - 2024-10-05 21:24:00 --> Database Driver Class Initialized
INFO - 2024-10-05 21:24:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:24:00 --> Controller Class Initialized
INFO - 2024-10-05 21:24:00 --> Final output sent to browser
DEBUG - 2024-10-05 21:24:00 --> Total execution time: 0.0334
INFO - 2024-10-05 21:24:33 --> Config Class Initialized
INFO - 2024-10-05 21:24:33 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:24:33 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:24:33 --> Utf8 Class Initialized
INFO - 2024-10-05 21:24:33 --> URI Class Initialized
INFO - 2024-10-05 21:24:33 --> Router Class Initialized
INFO - 2024-10-05 21:24:33 --> Output Class Initialized
INFO - 2024-10-05 21:24:33 --> Security Class Initialized
DEBUG - 2024-10-05 21:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:24:33 --> Input Class Initialized
INFO - 2024-10-05 21:24:33 --> Language Class Initialized
INFO - 2024-10-05 21:24:33 --> Language Class Initialized
INFO - 2024-10-05 21:24:33 --> Config Class Initialized
INFO - 2024-10-05 21:24:33 --> Loader Class Initialized
INFO - 2024-10-05 21:24:33 --> Helper loaded: url_helper
INFO - 2024-10-05 21:24:33 --> Helper loaded: file_helper
INFO - 2024-10-05 21:24:33 --> Helper loaded: form_helper
INFO - 2024-10-05 21:24:33 --> Helper loaded: my_helper
INFO - 2024-10-05 21:24:33 --> Database Driver Class Initialized
INFO - 2024-10-05 21:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:24:33 --> Controller Class Initialized
INFO - 2024-10-05 21:24:33 --> Final output sent to browser
DEBUG - 2024-10-05 21:24:33 --> Total execution time: 0.0613
INFO - 2024-10-05 21:24:47 --> Config Class Initialized
INFO - 2024-10-05 21:24:47 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:24:47 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:24:47 --> Utf8 Class Initialized
INFO - 2024-10-05 21:24:47 --> URI Class Initialized
INFO - 2024-10-05 21:24:47 --> Router Class Initialized
INFO - 2024-10-05 21:24:47 --> Output Class Initialized
INFO - 2024-10-05 21:24:47 --> Security Class Initialized
DEBUG - 2024-10-05 21:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:24:47 --> Input Class Initialized
INFO - 2024-10-05 21:24:47 --> Language Class Initialized
INFO - 2024-10-05 21:24:47 --> Language Class Initialized
INFO - 2024-10-05 21:24:47 --> Config Class Initialized
INFO - 2024-10-05 21:24:47 --> Loader Class Initialized
INFO - 2024-10-05 21:24:47 --> Helper loaded: url_helper
INFO - 2024-10-05 21:24:47 --> Helper loaded: file_helper
INFO - 2024-10-05 21:24:47 --> Helper loaded: form_helper
INFO - 2024-10-05 21:24:47 --> Helper loaded: my_helper
INFO - 2024-10-05 21:24:47 --> Database Driver Class Initialized
INFO - 2024-10-05 21:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:24:47 --> Controller Class Initialized
INFO - 2024-10-05 21:24:47 --> Final output sent to browser
DEBUG - 2024-10-05 21:24:47 --> Total execution time: 0.0371
INFO - 2024-10-05 21:26:34 --> Config Class Initialized
INFO - 2024-10-05 21:26:34 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:26:34 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:26:34 --> Utf8 Class Initialized
INFO - 2024-10-05 21:26:34 --> URI Class Initialized
INFO - 2024-10-05 21:26:34 --> Router Class Initialized
INFO - 2024-10-05 21:26:34 --> Output Class Initialized
INFO - 2024-10-05 21:26:34 --> Security Class Initialized
DEBUG - 2024-10-05 21:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:26:34 --> Input Class Initialized
INFO - 2024-10-05 21:26:34 --> Language Class Initialized
INFO - 2024-10-05 21:26:34 --> Language Class Initialized
INFO - 2024-10-05 21:26:34 --> Config Class Initialized
INFO - 2024-10-05 21:26:34 --> Loader Class Initialized
INFO - 2024-10-05 21:26:34 --> Helper loaded: url_helper
INFO - 2024-10-05 21:26:34 --> Helper loaded: file_helper
INFO - 2024-10-05 21:26:34 --> Helper loaded: form_helper
INFO - 2024-10-05 21:26:34 --> Helper loaded: my_helper
INFO - 2024-10-05 21:26:34 --> Database Driver Class Initialized
INFO - 2024-10-05 21:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:26:34 --> Controller Class Initialized
INFO - 2024-10-05 21:26:34 --> Final output sent to browser
DEBUG - 2024-10-05 21:26:34 --> Total execution time: 0.0525
INFO - 2024-10-05 21:26:38 --> Config Class Initialized
INFO - 2024-10-05 21:26:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:26:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:26:38 --> Utf8 Class Initialized
INFO - 2024-10-05 21:26:38 --> URI Class Initialized
INFO - 2024-10-05 21:26:38 --> Router Class Initialized
INFO - 2024-10-05 21:26:38 --> Output Class Initialized
INFO - 2024-10-05 21:26:38 --> Security Class Initialized
DEBUG - 2024-10-05 21:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:26:38 --> Input Class Initialized
INFO - 2024-10-05 21:26:38 --> Language Class Initialized
INFO - 2024-10-05 21:26:38 --> Language Class Initialized
INFO - 2024-10-05 21:26:38 --> Config Class Initialized
INFO - 2024-10-05 21:26:38 --> Loader Class Initialized
INFO - 2024-10-05 21:26:38 --> Helper loaded: url_helper
INFO - 2024-10-05 21:26:38 --> Helper loaded: file_helper
INFO - 2024-10-05 21:26:38 --> Helper loaded: form_helper
INFO - 2024-10-05 21:26:38 --> Helper loaded: my_helper
INFO - 2024-10-05 21:26:38 --> Database Driver Class Initialized
INFO - 2024-10-05 21:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:26:38 --> Controller Class Initialized
INFO - 2024-10-05 21:26:38 --> Final output sent to browser
DEBUG - 2024-10-05 21:26:38 --> Total execution time: 0.0541
INFO - 2024-10-05 21:26:43 --> Config Class Initialized
INFO - 2024-10-05 21:26:43 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:26:43 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:26:43 --> Utf8 Class Initialized
INFO - 2024-10-05 21:26:43 --> URI Class Initialized
INFO - 2024-10-05 21:26:43 --> Router Class Initialized
INFO - 2024-10-05 21:26:43 --> Output Class Initialized
INFO - 2024-10-05 21:26:43 --> Security Class Initialized
DEBUG - 2024-10-05 21:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:26:43 --> Input Class Initialized
INFO - 2024-10-05 21:26:43 --> Language Class Initialized
INFO - 2024-10-05 21:26:43 --> Language Class Initialized
INFO - 2024-10-05 21:26:43 --> Config Class Initialized
INFO - 2024-10-05 21:26:43 --> Loader Class Initialized
INFO - 2024-10-05 21:26:43 --> Helper loaded: url_helper
INFO - 2024-10-05 21:26:43 --> Helper loaded: file_helper
INFO - 2024-10-05 21:26:43 --> Helper loaded: form_helper
INFO - 2024-10-05 21:26:43 --> Helper loaded: my_helper
INFO - 2024-10-05 21:26:43 --> Database Driver Class Initialized
INFO - 2024-10-05 21:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:26:43 --> Controller Class Initialized
INFO - 2024-10-05 21:26:43 --> Final output sent to browser
DEBUG - 2024-10-05 21:26:43 --> Total execution time: 0.0331
INFO - 2024-10-05 21:27:59 --> Config Class Initialized
INFO - 2024-10-05 21:27:59 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:27:59 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:27:59 --> Utf8 Class Initialized
INFO - 2024-10-05 21:27:59 --> URI Class Initialized
INFO - 2024-10-05 21:27:59 --> Router Class Initialized
INFO - 2024-10-05 21:27:59 --> Output Class Initialized
INFO - 2024-10-05 21:27:59 --> Security Class Initialized
DEBUG - 2024-10-05 21:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:27:59 --> Input Class Initialized
INFO - 2024-10-05 21:27:59 --> Language Class Initialized
INFO - 2024-10-05 21:27:59 --> Language Class Initialized
INFO - 2024-10-05 21:27:59 --> Config Class Initialized
INFO - 2024-10-05 21:27:59 --> Loader Class Initialized
INFO - 2024-10-05 21:27:59 --> Helper loaded: url_helper
INFO - 2024-10-05 21:27:59 --> Helper loaded: file_helper
INFO - 2024-10-05 21:27:59 --> Helper loaded: form_helper
INFO - 2024-10-05 21:27:59 --> Helper loaded: my_helper
INFO - 2024-10-05 21:27:59 --> Database Driver Class Initialized
INFO - 2024-10-05 21:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:27:59 --> Controller Class Initialized
INFO - 2024-10-05 21:27:59 --> Final output sent to browser
DEBUG - 2024-10-05 21:27:59 --> Total execution time: 0.0509
INFO - 2024-10-05 21:28:04 --> Config Class Initialized
INFO - 2024-10-05 21:28:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:28:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:28:04 --> Utf8 Class Initialized
INFO - 2024-10-05 21:28:04 --> URI Class Initialized
INFO - 2024-10-05 21:28:04 --> Router Class Initialized
INFO - 2024-10-05 21:28:04 --> Output Class Initialized
INFO - 2024-10-05 21:28:04 --> Security Class Initialized
DEBUG - 2024-10-05 21:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:28:04 --> Input Class Initialized
INFO - 2024-10-05 21:28:04 --> Language Class Initialized
INFO - 2024-10-05 21:28:04 --> Language Class Initialized
INFO - 2024-10-05 21:28:04 --> Config Class Initialized
INFO - 2024-10-05 21:28:04 --> Loader Class Initialized
INFO - 2024-10-05 21:28:04 --> Helper loaded: url_helper
INFO - 2024-10-05 21:28:04 --> Helper loaded: file_helper
INFO - 2024-10-05 21:28:04 --> Helper loaded: form_helper
INFO - 2024-10-05 21:28:04 --> Helper loaded: my_helper
INFO - 2024-10-05 21:28:04 --> Database Driver Class Initialized
INFO - 2024-10-05 21:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:28:04 --> Controller Class Initialized
INFO - 2024-10-05 21:28:04 --> Final output sent to browser
DEBUG - 2024-10-05 21:28:04 --> Total execution time: 0.0409
INFO - 2024-10-05 21:28:24 --> Config Class Initialized
INFO - 2024-10-05 21:28:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:28:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:28:24 --> Utf8 Class Initialized
INFO - 2024-10-05 21:28:24 --> URI Class Initialized
INFO - 2024-10-05 21:28:24 --> Router Class Initialized
INFO - 2024-10-05 21:28:24 --> Output Class Initialized
INFO - 2024-10-05 21:28:24 --> Security Class Initialized
DEBUG - 2024-10-05 21:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:28:24 --> Input Class Initialized
INFO - 2024-10-05 21:28:24 --> Language Class Initialized
INFO - 2024-10-05 21:28:24 --> Language Class Initialized
INFO - 2024-10-05 21:28:24 --> Config Class Initialized
INFO - 2024-10-05 21:28:24 --> Loader Class Initialized
INFO - 2024-10-05 21:28:24 --> Helper loaded: url_helper
INFO - 2024-10-05 21:28:24 --> Helper loaded: file_helper
INFO - 2024-10-05 21:28:24 --> Helper loaded: form_helper
INFO - 2024-10-05 21:28:24 --> Helper loaded: my_helper
INFO - 2024-10-05 21:28:24 --> Database Driver Class Initialized
INFO - 2024-10-05 21:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:28:24 --> Controller Class Initialized
INFO - 2024-10-05 21:28:24 --> Final output sent to browser
DEBUG - 2024-10-05 21:28:24 --> Total execution time: 0.0510
INFO - 2024-10-05 21:28:28 --> Config Class Initialized
INFO - 2024-10-05 21:28:28 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:28:28 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:28:28 --> Utf8 Class Initialized
INFO - 2024-10-05 21:28:28 --> URI Class Initialized
INFO - 2024-10-05 21:28:28 --> Router Class Initialized
INFO - 2024-10-05 21:28:28 --> Output Class Initialized
INFO - 2024-10-05 21:28:28 --> Security Class Initialized
DEBUG - 2024-10-05 21:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:28:28 --> Input Class Initialized
INFO - 2024-10-05 21:28:28 --> Language Class Initialized
INFO - 2024-10-05 21:28:28 --> Language Class Initialized
INFO - 2024-10-05 21:28:28 --> Config Class Initialized
INFO - 2024-10-05 21:28:28 --> Loader Class Initialized
INFO - 2024-10-05 21:28:28 --> Helper loaded: url_helper
INFO - 2024-10-05 21:28:28 --> Helper loaded: file_helper
INFO - 2024-10-05 21:28:28 --> Helper loaded: form_helper
INFO - 2024-10-05 21:28:28 --> Helper loaded: my_helper
INFO - 2024-10-05 21:28:28 --> Database Driver Class Initialized
INFO - 2024-10-05 21:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:28:28 --> Controller Class Initialized
DEBUG - 2024-10-05 21:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-10-05 21:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:28:28 --> Final output sent to browser
DEBUG - 2024-10-05 21:28:28 --> Total execution time: 0.0401
INFO - 2024-10-05 21:29:13 --> Config Class Initialized
INFO - 2024-10-05 21:29:13 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:29:13 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:29:13 --> Utf8 Class Initialized
INFO - 2024-10-05 21:29:13 --> URI Class Initialized
INFO - 2024-10-05 21:29:13 --> Router Class Initialized
INFO - 2024-10-05 21:29:13 --> Output Class Initialized
INFO - 2024-10-05 21:29:13 --> Security Class Initialized
DEBUG - 2024-10-05 21:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:29:13 --> Input Class Initialized
INFO - 2024-10-05 21:29:13 --> Language Class Initialized
INFO - 2024-10-05 21:29:13 --> Language Class Initialized
INFO - 2024-10-05 21:29:13 --> Config Class Initialized
INFO - 2024-10-05 21:29:13 --> Loader Class Initialized
INFO - 2024-10-05 21:29:13 --> Helper loaded: url_helper
INFO - 2024-10-05 21:29:13 --> Helper loaded: file_helper
INFO - 2024-10-05 21:29:13 --> Helper loaded: form_helper
INFO - 2024-10-05 21:29:13 --> Helper loaded: my_helper
INFO - 2024-10-05 21:29:13 --> Database Driver Class Initialized
INFO - 2024-10-05 21:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:29:13 --> Controller Class Initialized
DEBUG - 2024-10-05 21:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-05 21:29:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:29:13 --> Final output sent to browser
DEBUG - 2024-10-05 21:29:13 --> Total execution time: 0.0358
INFO - 2024-10-05 21:45:38 --> Config Class Initialized
INFO - 2024-10-05 21:45:38 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:45:38 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:45:38 --> Utf8 Class Initialized
INFO - 2024-10-05 21:45:38 --> URI Class Initialized
INFO - 2024-10-05 21:45:38 --> Router Class Initialized
INFO - 2024-10-05 21:45:38 --> Output Class Initialized
INFO - 2024-10-05 21:45:38 --> Security Class Initialized
DEBUG - 2024-10-05 21:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:45:38 --> Input Class Initialized
INFO - 2024-10-05 21:45:38 --> Language Class Initialized
INFO - 2024-10-05 21:45:38 --> Language Class Initialized
INFO - 2024-10-05 21:45:38 --> Config Class Initialized
INFO - 2024-10-05 21:45:38 --> Loader Class Initialized
INFO - 2024-10-05 21:45:38 --> Helper loaded: url_helper
INFO - 2024-10-05 21:45:38 --> Helper loaded: file_helper
INFO - 2024-10-05 21:45:38 --> Helper loaded: form_helper
INFO - 2024-10-05 21:45:38 --> Helper loaded: my_helper
INFO - 2024-10-05 21:45:38 --> Database Driver Class Initialized
INFO - 2024-10-05 21:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:45:38 --> Controller Class Initialized
INFO - 2024-10-05 21:45:38 --> Final output sent to browser
DEBUG - 2024-10-05 21:45:38 --> Total execution time: 0.0651
INFO - 2024-10-05 21:45:54 --> Config Class Initialized
INFO - 2024-10-05 21:45:54 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:45:54 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:45:54 --> Utf8 Class Initialized
INFO - 2024-10-05 21:45:54 --> URI Class Initialized
INFO - 2024-10-05 21:45:54 --> Router Class Initialized
INFO - 2024-10-05 21:45:54 --> Output Class Initialized
INFO - 2024-10-05 21:45:54 --> Security Class Initialized
DEBUG - 2024-10-05 21:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:45:54 --> Input Class Initialized
INFO - 2024-10-05 21:45:54 --> Language Class Initialized
INFO - 2024-10-05 21:45:54 --> Language Class Initialized
INFO - 2024-10-05 21:45:54 --> Config Class Initialized
INFO - 2024-10-05 21:45:54 --> Loader Class Initialized
INFO - 2024-10-05 21:45:54 --> Helper loaded: url_helper
INFO - 2024-10-05 21:45:54 --> Helper loaded: file_helper
INFO - 2024-10-05 21:45:54 --> Helper loaded: form_helper
INFO - 2024-10-05 21:45:54 --> Helper loaded: my_helper
INFO - 2024-10-05 21:45:54 --> Database Driver Class Initialized
INFO - 2024-10-05 21:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:45:54 --> Controller Class Initialized
DEBUG - 2024-10-05 21:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-10-05 21:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:45:54 --> Final output sent to browser
DEBUG - 2024-10-05 21:45:54 --> Total execution time: 0.0334
INFO - 2024-10-05 21:45:56 --> Config Class Initialized
INFO - 2024-10-05 21:45:56 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:45:56 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:45:56 --> Utf8 Class Initialized
INFO - 2024-10-05 21:45:56 --> URI Class Initialized
INFO - 2024-10-05 21:45:56 --> Router Class Initialized
INFO - 2024-10-05 21:45:56 --> Output Class Initialized
INFO - 2024-10-05 21:45:56 --> Security Class Initialized
DEBUG - 2024-10-05 21:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:45:56 --> Input Class Initialized
INFO - 2024-10-05 21:45:56 --> Language Class Initialized
INFO - 2024-10-05 21:45:56 --> Language Class Initialized
INFO - 2024-10-05 21:45:56 --> Config Class Initialized
INFO - 2024-10-05 21:45:56 --> Loader Class Initialized
INFO - 2024-10-05 21:45:56 --> Helper loaded: url_helper
INFO - 2024-10-05 21:45:56 --> Helper loaded: file_helper
INFO - 2024-10-05 21:45:56 --> Helper loaded: form_helper
INFO - 2024-10-05 21:45:56 --> Helper loaded: my_helper
INFO - 2024-10-05 21:45:56 --> Database Driver Class Initialized
INFO - 2024-10-05 21:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:45:56 --> Controller Class Initialized
DEBUG - 2024-10-05 21:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-10-05 21:45:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:45:56 --> Final output sent to browser
DEBUG - 2024-10-05 21:45:56 --> Total execution time: 0.0304
INFO - 2024-10-05 21:46:04 --> Config Class Initialized
INFO - 2024-10-05 21:46:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:46:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:46:04 --> Utf8 Class Initialized
INFO - 2024-10-05 21:46:04 --> URI Class Initialized
INFO - 2024-10-05 21:46:04 --> Router Class Initialized
INFO - 2024-10-05 21:46:04 --> Output Class Initialized
INFO - 2024-10-05 21:46:04 --> Security Class Initialized
DEBUG - 2024-10-05 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:46:04 --> Input Class Initialized
INFO - 2024-10-05 21:46:04 --> Language Class Initialized
INFO - 2024-10-05 21:46:04 --> Language Class Initialized
INFO - 2024-10-05 21:46:04 --> Config Class Initialized
INFO - 2024-10-05 21:46:04 --> Loader Class Initialized
INFO - 2024-10-05 21:46:04 --> Helper loaded: url_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: file_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: form_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: my_helper
INFO - 2024-10-05 21:46:04 --> Database Driver Class Initialized
INFO - 2024-10-05 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:46:04 --> Controller Class Initialized
DEBUG - 2024-10-05 21:46:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-10-05 21:46:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:46:04 --> Final output sent to browser
DEBUG - 2024-10-05 21:46:04 --> Total execution time: 0.0405
INFO - 2024-10-05 21:46:04 --> Config Class Initialized
INFO - 2024-10-05 21:46:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:46:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:46:04 --> Utf8 Class Initialized
INFO - 2024-10-05 21:46:04 --> URI Class Initialized
INFO - 2024-10-05 21:46:04 --> Router Class Initialized
INFO - 2024-10-05 21:46:04 --> Output Class Initialized
INFO - 2024-10-05 21:46:04 --> Security Class Initialized
DEBUG - 2024-10-05 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:46:04 --> Input Class Initialized
INFO - 2024-10-05 21:46:04 --> Language Class Initialized
ERROR - 2024-10-05 21:46:04 --> 404 Page Not Found: /index
INFO - 2024-10-05 21:46:04 --> Config Class Initialized
INFO - 2024-10-05 21:46:04 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:46:04 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:46:04 --> Utf8 Class Initialized
INFO - 2024-10-05 21:46:04 --> URI Class Initialized
INFO - 2024-10-05 21:46:04 --> Router Class Initialized
INFO - 2024-10-05 21:46:04 --> Output Class Initialized
INFO - 2024-10-05 21:46:04 --> Security Class Initialized
DEBUG - 2024-10-05 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:46:04 --> Input Class Initialized
INFO - 2024-10-05 21:46:04 --> Language Class Initialized
INFO - 2024-10-05 21:46:04 --> Language Class Initialized
INFO - 2024-10-05 21:46:04 --> Config Class Initialized
INFO - 2024-10-05 21:46:04 --> Loader Class Initialized
INFO - 2024-10-05 21:46:04 --> Helper loaded: url_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: file_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: form_helper
INFO - 2024-10-05 21:46:04 --> Helper loaded: my_helper
INFO - 2024-10-05 21:46:04 --> Database Driver Class Initialized
INFO - 2024-10-05 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:46:04 --> Controller Class Initialized
INFO - 2024-10-05 21:46:21 --> Config Class Initialized
INFO - 2024-10-05 21:46:21 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:46:21 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:46:21 --> Utf8 Class Initialized
INFO - 2024-10-05 21:46:21 --> URI Class Initialized
INFO - 2024-10-05 21:46:21 --> Router Class Initialized
INFO - 2024-10-05 21:46:21 --> Output Class Initialized
INFO - 2024-10-05 21:46:21 --> Security Class Initialized
DEBUG - 2024-10-05 21:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:46:21 --> Input Class Initialized
INFO - 2024-10-05 21:46:21 --> Language Class Initialized
INFO - 2024-10-05 21:46:21 --> Language Class Initialized
INFO - 2024-10-05 21:46:21 --> Config Class Initialized
INFO - 2024-10-05 21:46:21 --> Loader Class Initialized
INFO - 2024-10-05 21:46:21 --> Helper loaded: url_helper
INFO - 2024-10-05 21:46:21 --> Helper loaded: file_helper
INFO - 2024-10-05 21:46:21 --> Helper loaded: form_helper
INFO - 2024-10-05 21:46:21 --> Helper loaded: my_helper
INFO - 2024-10-05 21:46:21 --> Database Driver Class Initialized
INFO - 2024-10-05 21:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:46:21 --> Controller Class Initialized
DEBUG - 2024-10-05 21:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-10-05 21:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-05 21:46:21 --> Final output sent to browser
DEBUG - 2024-10-05 21:46:21 --> Total execution time: 0.0373
INFO - 2024-10-05 21:46:24 --> Config Class Initialized
INFO - 2024-10-05 21:46:24 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:46:24 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:46:24 --> Utf8 Class Initialized
INFO - 2024-10-05 21:46:24 --> URI Class Initialized
INFO - 2024-10-05 21:46:24 --> Router Class Initialized
INFO - 2024-10-05 21:46:24 --> Output Class Initialized
INFO - 2024-10-05 21:46:24 --> Security Class Initialized
DEBUG - 2024-10-05 21:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:46:24 --> Input Class Initialized
INFO - 2024-10-05 21:46:24 --> Language Class Initialized
INFO - 2024-10-05 21:46:24 --> Language Class Initialized
INFO - 2024-10-05 21:46:24 --> Config Class Initialized
INFO - 2024-10-05 21:46:24 --> Loader Class Initialized
INFO - 2024-10-05 21:46:24 --> Helper loaded: url_helper
INFO - 2024-10-05 21:46:24 --> Helper loaded: file_helper
INFO - 2024-10-05 21:46:24 --> Helper loaded: form_helper
INFO - 2024-10-05 21:46:24 --> Helper loaded: my_helper
INFO - 2024-10-05 21:46:24 --> Database Driver Class Initialized
INFO - 2024-10-05 21:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:46:24 --> Controller Class Initialized
DEBUG - 2024-10-05 21:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-05 21:46:32 --> Final output sent to browser
DEBUG - 2024-10-05 21:46:32 --> Total execution time: 7.3533
INFO - 2024-10-05 21:48:00 --> Config Class Initialized
INFO - 2024-10-05 21:48:00 --> Hooks Class Initialized
DEBUG - 2024-10-05 21:48:00 --> UTF-8 Support Enabled
INFO - 2024-10-05 21:48:00 --> Utf8 Class Initialized
INFO - 2024-10-05 21:48:00 --> URI Class Initialized
INFO - 2024-10-05 21:48:00 --> Router Class Initialized
INFO - 2024-10-05 21:48:00 --> Output Class Initialized
INFO - 2024-10-05 21:48:00 --> Security Class Initialized
DEBUG - 2024-10-05 21:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-05 21:48:00 --> Input Class Initialized
INFO - 2024-10-05 21:48:00 --> Language Class Initialized
INFO - 2024-10-05 21:48:00 --> Language Class Initialized
INFO - 2024-10-05 21:48:00 --> Config Class Initialized
INFO - 2024-10-05 21:48:00 --> Loader Class Initialized
INFO - 2024-10-05 21:48:00 --> Helper loaded: url_helper
INFO - 2024-10-05 21:48:00 --> Helper loaded: file_helper
INFO - 2024-10-05 21:48:00 --> Helper loaded: form_helper
INFO - 2024-10-05 21:48:00 --> Helper loaded: my_helper
INFO - 2024-10-05 21:48:00 --> Database Driver Class Initialized
INFO - 2024-10-05 21:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-05 21:48:00 --> Controller Class Initialized
DEBUG - 2024-10-05 21:48:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-05 21:48:11 --> Final output sent to browser
DEBUG - 2024-10-05 21:48:11 --> Total execution time: 10.9833
