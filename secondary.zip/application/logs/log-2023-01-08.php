<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-01-08 04:26:43 --> Config Class Initialized
INFO - 2023-01-08 04:26:43 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:26:43 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:26:43 --> Utf8 Class Initialized
INFO - 2023-01-08 04:26:43 --> URI Class Initialized
DEBUG - 2023-01-08 04:26:43 --> No URI present. Default controller set.
INFO - 2023-01-08 04:26:43 --> Router Class Initialized
INFO - 2023-01-08 04:26:43 --> Output Class Initialized
INFO - 2023-01-08 04:26:43 --> Security Class Initialized
DEBUG - 2023-01-08 04:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:26:43 --> Input Class Initialized
INFO - 2023-01-08 04:26:44 --> Language Class Initialized
INFO - 2023-01-08 04:26:44 --> Language Class Initialized
INFO - 2023-01-08 04:26:44 --> Config Class Initialized
INFO - 2023-01-08 04:26:44 --> Loader Class Initialized
INFO - 2023-01-08 04:26:44 --> Helper loaded: url_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: file_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: form_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: my_helper
INFO - 2023-01-08 04:26:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:26:44 --> Controller Class Initialized
INFO - 2023-01-08 04:26:44 --> Config Class Initialized
INFO - 2023-01-08 04:26:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:26:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:26:44 --> Utf8 Class Initialized
INFO - 2023-01-08 04:26:44 --> URI Class Initialized
INFO - 2023-01-08 04:26:44 --> Router Class Initialized
INFO - 2023-01-08 04:26:44 --> Output Class Initialized
INFO - 2023-01-08 04:26:44 --> Security Class Initialized
DEBUG - 2023-01-08 04:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:26:44 --> Input Class Initialized
INFO - 2023-01-08 04:26:44 --> Language Class Initialized
INFO - 2023-01-08 04:26:44 --> Language Class Initialized
INFO - 2023-01-08 04:26:44 --> Config Class Initialized
INFO - 2023-01-08 04:26:44 --> Loader Class Initialized
INFO - 2023-01-08 04:26:44 --> Helper loaded: url_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: file_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: form_helper
INFO - 2023-01-08 04:26:44 --> Helper loaded: my_helper
INFO - 2023-01-08 04:26:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:26:44 --> Controller Class Initialized
DEBUG - 2023-01-08 04:26:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 04:26:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:26:44 --> Final output sent to browser
DEBUG - 2023-01-08 04:26:44 --> Total execution time: 0.1186
INFO - 2023-01-08 04:26:51 --> Config Class Initialized
INFO - 2023-01-08 04:26:51 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:26:51 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:26:51 --> Utf8 Class Initialized
INFO - 2023-01-08 04:26:51 --> URI Class Initialized
INFO - 2023-01-08 04:26:51 --> Router Class Initialized
INFO - 2023-01-08 04:26:51 --> Output Class Initialized
INFO - 2023-01-08 04:26:51 --> Security Class Initialized
DEBUG - 2023-01-08 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:26:51 --> Input Class Initialized
INFO - 2023-01-08 04:26:51 --> Language Class Initialized
INFO - 2023-01-08 04:26:51 --> Language Class Initialized
INFO - 2023-01-08 04:26:51 --> Config Class Initialized
INFO - 2023-01-08 04:26:51 --> Loader Class Initialized
INFO - 2023-01-08 04:26:51 --> Helper loaded: url_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: file_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: form_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: my_helper
INFO - 2023-01-08 04:26:51 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:26:51 --> Controller Class Initialized
INFO - 2023-01-08 04:26:51 --> Helper loaded: cookie_helper
INFO - 2023-01-08 04:26:51 --> Final output sent to browser
DEBUG - 2023-01-08 04:26:51 --> Total execution time: 0.1004
INFO - 2023-01-08 04:26:51 --> Config Class Initialized
INFO - 2023-01-08 04:26:51 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:26:51 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:26:51 --> Utf8 Class Initialized
INFO - 2023-01-08 04:26:51 --> URI Class Initialized
INFO - 2023-01-08 04:26:51 --> Router Class Initialized
INFO - 2023-01-08 04:26:51 --> Output Class Initialized
INFO - 2023-01-08 04:26:51 --> Security Class Initialized
DEBUG - 2023-01-08 04:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:26:51 --> Input Class Initialized
INFO - 2023-01-08 04:26:51 --> Language Class Initialized
INFO - 2023-01-08 04:26:51 --> Language Class Initialized
INFO - 2023-01-08 04:26:51 --> Config Class Initialized
INFO - 2023-01-08 04:26:51 --> Loader Class Initialized
INFO - 2023-01-08 04:26:51 --> Helper loaded: url_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: file_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: form_helper
INFO - 2023-01-08 04:26:51 --> Helper loaded: my_helper
INFO - 2023-01-08 04:26:51 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:26:51 --> Controller Class Initialized
DEBUG - 2023-01-08 04:26:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 04:26:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:26:51 --> Final output sent to browser
DEBUG - 2023-01-08 04:26:51 --> Total execution time: 0.0997
INFO - 2023-01-08 04:27:00 --> Config Class Initialized
INFO - 2023-01-08 04:27:00 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:27:00 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:27:00 --> Utf8 Class Initialized
INFO - 2023-01-08 04:27:00 --> URI Class Initialized
INFO - 2023-01-08 04:27:00 --> Router Class Initialized
INFO - 2023-01-08 04:27:00 --> Output Class Initialized
INFO - 2023-01-08 04:27:00 --> Security Class Initialized
DEBUG - 2023-01-08 04:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:27:00 --> Input Class Initialized
INFO - 2023-01-08 04:27:00 --> Language Class Initialized
INFO - 2023-01-08 04:27:00 --> Language Class Initialized
INFO - 2023-01-08 04:27:00 --> Config Class Initialized
INFO - 2023-01-08 04:27:00 --> Loader Class Initialized
INFO - 2023-01-08 04:27:00 --> Helper loaded: url_helper
INFO - 2023-01-08 04:27:00 --> Helper loaded: file_helper
INFO - 2023-01-08 04:27:00 --> Helper loaded: form_helper
INFO - 2023-01-08 04:27:00 --> Helper loaded: my_helper
INFO - 2023-01-08 04:27:00 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:27:00 --> Controller Class Initialized
DEBUG - 2023-01-08 04:27:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-08 04:27:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:27:00 --> Final output sent to browser
DEBUG - 2023-01-08 04:27:00 --> Total execution time: 0.0981
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:18 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:18 --> URI Class Initialized
INFO - 2023-01-08 04:40:18 --> Router Class Initialized
INFO - 2023-01-08 04:40:18 --> Output Class Initialized
INFO - 2023-01-08 04:40:18 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:18 --> Input Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Loader Class Initialized
INFO - 2023-01-08 04:40:18 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:18 --> Controller Class Initialized
INFO - 2023-01-08 04:40:18 --> Helper loaded: cookie_helper
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:18 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:18 --> URI Class Initialized
INFO - 2023-01-08 04:40:18 --> Router Class Initialized
INFO - 2023-01-08 04:40:18 --> Output Class Initialized
INFO - 2023-01-08 04:40:18 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:18 --> Input Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Loader Class Initialized
INFO - 2023-01-08 04:40:18 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:18 --> Controller Class Initialized
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:18 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:18 --> URI Class Initialized
INFO - 2023-01-08 04:40:18 --> Router Class Initialized
INFO - 2023-01-08 04:40:18 --> Output Class Initialized
INFO - 2023-01-08 04:40:18 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:18 --> Input Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Language Class Initialized
INFO - 2023-01-08 04:40:18 --> Config Class Initialized
INFO - 2023-01-08 04:40:18 --> Loader Class Initialized
INFO - 2023-01-08 04:40:18 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:18 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:18 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 04:40:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:18 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:18 --> Total execution time: 0.0378
INFO - 2023-01-08 04:40:25 --> Config Class Initialized
INFO - 2023-01-08 04:40:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:25 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:25 --> URI Class Initialized
INFO - 2023-01-08 04:40:25 --> Router Class Initialized
INFO - 2023-01-08 04:40:25 --> Output Class Initialized
INFO - 2023-01-08 04:40:25 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:25 --> Input Class Initialized
INFO - 2023-01-08 04:40:25 --> Language Class Initialized
INFO - 2023-01-08 04:40:25 --> Language Class Initialized
INFO - 2023-01-08 04:40:25 --> Config Class Initialized
INFO - 2023-01-08 04:40:25 --> Loader Class Initialized
INFO - 2023-01-08 04:40:25 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:25 --> Controller Class Initialized
INFO - 2023-01-08 04:40:25 --> Helper loaded: cookie_helper
INFO - 2023-01-08 04:40:25 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:25 --> Total execution time: 0.0664
INFO - 2023-01-08 04:40:25 --> Config Class Initialized
INFO - 2023-01-08 04:40:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:25 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:25 --> URI Class Initialized
INFO - 2023-01-08 04:40:25 --> Router Class Initialized
INFO - 2023-01-08 04:40:25 --> Output Class Initialized
INFO - 2023-01-08 04:40:25 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:25 --> Input Class Initialized
INFO - 2023-01-08 04:40:25 --> Language Class Initialized
INFO - 2023-01-08 04:40:25 --> Language Class Initialized
INFO - 2023-01-08 04:40:25 --> Config Class Initialized
INFO - 2023-01-08 04:40:25 --> Loader Class Initialized
INFO - 2023-01-08 04:40:25 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:25 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:25 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-01-08 04:40:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:25 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:25 --> Total execution time: 0.0885
INFO - 2023-01-08 04:40:31 --> Config Class Initialized
INFO - 2023-01-08 04:40:31 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:31 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:31 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:31 --> URI Class Initialized
INFO - 2023-01-08 04:40:31 --> Router Class Initialized
INFO - 2023-01-08 04:40:31 --> Output Class Initialized
INFO - 2023-01-08 04:40:31 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:31 --> Input Class Initialized
INFO - 2023-01-08 04:40:31 --> Language Class Initialized
INFO - 2023-01-08 04:40:31 --> Language Class Initialized
INFO - 2023-01-08 04:40:31 --> Config Class Initialized
INFO - 2023-01-08 04:40:31 --> Loader Class Initialized
INFO - 2023-01-08 04:40:31 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:31 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:31 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:31 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:31 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:31 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-08 04:40:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:31 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:31 --> Total execution time: 0.0796
INFO - 2023-01-08 04:40:35 --> Config Class Initialized
INFO - 2023-01-08 04:40:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:35 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:35 --> URI Class Initialized
INFO - 2023-01-08 04:40:35 --> Router Class Initialized
INFO - 2023-01-08 04:40:35 --> Output Class Initialized
INFO - 2023-01-08 04:40:35 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:35 --> Input Class Initialized
INFO - 2023-01-08 04:40:35 --> Language Class Initialized
INFO - 2023-01-08 04:40:35 --> Language Class Initialized
INFO - 2023-01-08 04:40:35 --> Config Class Initialized
INFO - 2023-01-08 04:40:35 --> Loader Class Initialized
INFO - 2023-01-08 04:40:35 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:35 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:35 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:35 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:35 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:35 --> Controller Class Initialized
INFO - 2023-01-08 04:40:35 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:35 --> Total execution time: 0.0715
INFO - 2023-01-08 04:40:39 --> Config Class Initialized
INFO - 2023-01-08 04:40:39 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:39 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:39 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:39 --> URI Class Initialized
INFO - 2023-01-08 04:40:39 --> Router Class Initialized
INFO - 2023-01-08 04:40:39 --> Output Class Initialized
INFO - 2023-01-08 04:40:39 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:39 --> Input Class Initialized
INFO - 2023-01-08 04:40:39 --> Language Class Initialized
INFO - 2023-01-08 04:40:39 --> Language Class Initialized
INFO - 2023-01-08 04:40:39 --> Config Class Initialized
INFO - 2023-01-08 04:40:39 --> Loader Class Initialized
INFO - 2023-01-08 04:40:39 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:39 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:39 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:39 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:39 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:39 --> Controller Class Initialized
ERROR - 2023-01-08 04:40:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 47
ERROR - 2023-01-08 04:40:39 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 49
ERROR - 2023-01-08 04:40:39 --> Severity: Notice --> Undefined index: kelas C:\xampp\htdocs\myraportk13\application\modules\set_kelas\views\form.php 59
DEBUG - 2023-01-08 04:40:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/form.php
DEBUG - 2023-01-08 04:40:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:39 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:39 --> Total execution time: 0.1187
INFO - 2023-01-08 04:40:49 --> Config Class Initialized
INFO - 2023-01-08 04:40:49 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:49 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:49 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:49 --> URI Class Initialized
INFO - 2023-01-08 04:40:49 --> Router Class Initialized
INFO - 2023-01-08 04:40:49 --> Output Class Initialized
INFO - 2023-01-08 04:40:49 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:49 --> Input Class Initialized
INFO - 2023-01-08 04:40:49 --> Language Class Initialized
INFO - 2023-01-08 04:40:49 --> Language Class Initialized
INFO - 2023-01-08 04:40:49 --> Config Class Initialized
INFO - 2023-01-08 04:40:49 --> Loader Class Initialized
INFO - 2023-01-08 04:40:49 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:49 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:49 --> Controller Class Initialized
INFO - 2023-01-08 04:40:49 --> Config Class Initialized
INFO - 2023-01-08 04:40:49 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:49 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:49 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:49 --> URI Class Initialized
INFO - 2023-01-08 04:40:49 --> Router Class Initialized
INFO - 2023-01-08 04:40:49 --> Output Class Initialized
INFO - 2023-01-08 04:40:49 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:49 --> Input Class Initialized
INFO - 2023-01-08 04:40:49 --> Language Class Initialized
INFO - 2023-01-08 04:40:49 --> Language Class Initialized
INFO - 2023-01-08 04:40:49 --> Config Class Initialized
INFO - 2023-01-08 04:40:49 --> Loader Class Initialized
INFO - 2023-01-08 04:40:49 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:49 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:49 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:49 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_kelas/views/list.php
DEBUG - 2023-01-08 04:40:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:49 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:49 --> Total execution time: 0.0464
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:52 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:52 --> URI Class Initialized
INFO - 2023-01-08 04:40:52 --> Router Class Initialized
INFO - 2023-01-08 04:40:52 --> Output Class Initialized
INFO - 2023-01-08 04:40:52 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:52 --> Input Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Loader Class Initialized
INFO - 2023-01-08 04:40:52 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:52 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:52 --> Controller Class Initialized
INFO - 2023-01-08 04:40:52 --> Helper loaded: cookie_helper
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:52 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:52 --> URI Class Initialized
INFO - 2023-01-08 04:40:52 --> Router Class Initialized
INFO - 2023-01-08 04:40:52 --> Output Class Initialized
INFO - 2023-01-08 04:40:52 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:52 --> Input Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Loader Class Initialized
INFO - 2023-01-08 04:40:52 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:52 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:52 --> Controller Class Initialized
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:52 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:52 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:52 --> URI Class Initialized
INFO - 2023-01-08 04:40:52 --> Router Class Initialized
INFO - 2023-01-08 04:40:52 --> Output Class Initialized
INFO - 2023-01-08 04:40:52 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:52 --> Input Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Language Class Initialized
INFO - 2023-01-08 04:40:52 --> Config Class Initialized
INFO - 2023-01-08 04:40:52 --> Loader Class Initialized
INFO - 2023-01-08 04:40:52 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:52 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:52 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:52 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 04:40:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:52 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:52 --> Total execution time: 0.0357
INFO - 2023-01-08 04:40:59 --> Config Class Initialized
INFO - 2023-01-08 04:40:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:59 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:59 --> URI Class Initialized
INFO - 2023-01-08 04:40:59 --> Router Class Initialized
INFO - 2023-01-08 04:40:59 --> Output Class Initialized
INFO - 2023-01-08 04:40:59 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:59 --> Input Class Initialized
INFO - 2023-01-08 04:40:59 --> Language Class Initialized
INFO - 2023-01-08 04:40:59 --> Language Class Initialized
INFO - 2023-01-08 04:40:59 --> Config Class Initialized
INFO - 2023-01-08 04:40:59 --> Loader Class Initialized
INFO - 2023-01-08 04:40:59 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:59 --> Controller Class Initialized
INFO - 2023-01-08 04:40:59 --> Helper loaded: cookie_helper
INFO - 2023-01-08 04:40:59 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:59 --> Total execution time: 0.0558
INFO - 2023-01-08 04:40:59 --> Config Class Initialized
INFO - 2023-01-08 04:40:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:40:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:40:59 --> Utf8 Class Initialized
INFO - 2023-01-08 04:40:59 --> URI Class Initialized
INFO - 2023-01-08 04:40:59 --> Router Class Initialized
INFO - 2023-01-08 04:40:59 --> Output Class Initialized
INFO - 2023-01-08 04:40:59 --> Security Class Initialized
DEBUG - 2023-01-08 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:40:59 --> Input Class Initialized
INFO - 2023-01-08 04:40:59 --> Language Class Initialized
INFO - 2023-01-08 04:40:59 --> Language Class Initialized
INFO - 2023-01-08 04:40:59 --> Config Class Initialized
INFO - 2023-01-08 04:40:59 --> Loader Class Initialized
INFO - 2023-01-08 04:40:59 --> Helper loaded: url_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: file_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: form_helper
INFO - 2023-01-08 04:40:59 --> Helper loaded: my_helper
INFO - 2023-01-08 04:40:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:40:59 --> Controller Class Initialized
DEBUG - 2023-01-08 04:40:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 04:40:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:40:59 --> Final output sent to browser
DEBUG - 2023-01-08 04:40:59 --> Total execution time: 0.0634
INFO - 2023-01-08 04:41:03 --> Config Class Initialized
INFO - 2023-01-08 04:41:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:03 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:03 --> URI Class Initialized
INFO - 2023-01-08 04:41:03 --> Router Class Initialized
INFO - 2023-01-08 04:41:03 --> Output Class Initialized
INFO - 2023-01-08 04:41:03 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:03 --> Input Class Initialized
INFO - 2023-01-08 04:41:03 --> Language Class Initialized
INFO - 2023-01-08 04:41:03 --> Language Class Initialized
INFO - 2023-01-08 04:41:03 --> Config Class Initialized
INFO - 2023-01-08 04:41:03 --> Loader Class Initialized
INFO - 2023-01-08 04:41:03 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:03 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:03 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:03 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:03 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:03 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-08 04:41:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:03 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:03 --> Total execution time: 0.0377
INFO - 2023-01-08 04:41:05 --> Config Class Initialized
INFO - 2023-01-08 04:41:05 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:05 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:05 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:05 --> URI Class Initialized
INFO - 2023-01-08 04:41:05 --> Router Class Initialized
INFO - 2023-01-08 04:41:05 --> Output Class Initialized
INFO - 2023-01-08 04:41:05 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:05 --> Input Class Initialized
INFO - 2023-01-08 04:41:05 --> Language Class Initialized
INFO - 2023-01-08 04:41:05 --> Language Class Initialized
INFO - 2023-01-08 04:41:05 --> Config Class Initialized
INFO - 2023-01-08 04:41:05 --> Loader Class Initialized
INFO - 2023-01-08 04:41:05 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:05 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:05 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_prestasi/views/list.php
DEBUG - 2023-01-08 04:41:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:05 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:05 --> Total execution time: 0.0910
INFO - 2023-01-08 04:41:05 --> Config Class Initialized
INFO - 2023-01-08 04:41:05 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:05 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:05 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:05 --> URI Class Initialized
INFO - 2023-01-08 04:41:05 --> Router Class Initialized
INFO - 2023-01-08 04:41:05 --> Output Class Initialized
INFO - 2023-01-08 04:41:05 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:05 --> Input Class Initialized
INFO - 2023-01-08 04:41:05 --> Language Class Initialized
INFO - 2023-01-08 04:41:05 --> Language Class Initialized
INFO - 2023-01-08 04:41:05 --> Config Class Initialized
INFO - 2023-01-08 04:41:05 --> Loader Class Initialized
INFO - 2023-01-08 04:41:05 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:05 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:05 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:05 --> Controller Class Initialized
INFO - 2023-01-08 04:41:14 --> Config Class Initialized
INFO - 2023-01-08 04:41:14 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:14 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:14 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:14 --> URI Class Initialized
INFO - 2023-01-08 04:41:14 --> Router Class Initialized
INFO - 2023-01-08 04:41:14 --> Output Class Initialized
INFO - 2023-01-08 04:41:14 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:14 --> Input Class Initialized
INFO - 2023-01-08 04:41:14 --> Language Class Initialized
INFO - 2023-01-08 04:41:14 --> Language Class Initialized
INFO - 2023-01-08 04:41:14 --> Config Class Initialized
INFO - 2023-01-08 04:41:14 --> Loader Class Initialized
INFO - 2023-01-08 04:41:14 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:14 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:14 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:14 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:14 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:14 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-08 04:41:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:14 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:14 --> Total execution time: 0.0892
INFO - 2023-01-08 04:41:16 --> Config Class Initialized
INFO - 2023-01-08 04:41:16 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:16 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:16 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:16 --> URI Class Initialized
INFO - 2023-01-08 04:41:16 --> Router Class Initialized
INFO - 2023-01-08 04:41:16 --> Output Class Initialized
INFO - 2023-01-08 04:41:16 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:16 --> Input Class Initialized
INFO - 2023-01-08 04:41:16 --> Language Class Initialized
INFO - 2023-01-08 04:41:16 --> Language Class Initialized
INFO - 2023-01-08 04:41:16 --> Config Class Initialized
INFO - 2023-01-08 04:41:16 --> Loader Class Initialized
INFO - 2023-01-08 04:41:16 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:16 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:16 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:16 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:17 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:17 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-08 04:41:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:17 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:17 --> Total execution time: 0.0953
INFO - 2023-01-08 04:41:18 --> Config Class Initialized
INFO - 2023-01-08 04:41:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:18 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:18 --> URI Class Initialized
INFO - 2023-01-08 04:41:18 --> Router Class Initialized
INFO - 2023-01-08 04:41:18 --> Output Class Initialized
INFO - 2023-01-08 04:41:18 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:18 --> Input Class Initialized
INFO - 2023-01-08 04:41:18 --> Language Class Initialized
INFO - 2023-01-08 04:41:18 --> Language Class Initialized
INFO - 2023-01-08 04:41:18 --> Config Class Initialized
INFO - 2023-01-08 04:41:18 --> Loader Class Initialized
INFO - 2023-01-08 04:41:18 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:18 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:18 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:18 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:18 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-08 04:41:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:18 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:18 --> Total execution time: 0.0935
INFO - 2023-01-08 04:41:20 --> Config Class Initialized
INFO - 2023-01-08 04:41:20 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:20 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:20 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:20 --> URI Class Initialized
INFO - 2023-01-08 04:41:20 --> Router Class Initialized
INFO - 2023-01-08 04:41:20 --> Output Class Initialized
INFO - 2023-01-08 04:41:20 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:20 --> Input Class Initialized
INFO - 2023-01-08 04:41:20 --> Language Class Initialized
INFO - 2023-01-08 04:41:20 --> Language Class Initialized
INFO - 2023-01-08 04:41:20 --> Config Class Initialized
INFO - 2023-01-08 04:41:20 --> Loader Class Initialized
INFO - 2023-01-08 04:41:20 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:20 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:20 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:20 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:20 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:20 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-08 04:41:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:20 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:20 --> Total execution time: 0.0959
INFO - 2023-01-08 04:41:21 --> Config Class Initialized
INFO - 2023-01-08 04:41:21 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:21 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:21 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:21 --> URI Class Initialized
INFO - 2023-01-08 04:41:21 --> Router Class Initialized
INFO - 2023-01-08 04:41:21 --> Output Class Initialized
INFO - 2023-01-08 04:41:21 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:21 --> Input Class Initialized
INFO - 2023-01-08 04:41:21 --> Language Class Initialized
INFO - 2023-01-08 04:41:21 --> Language Class Initialized
INFO - 2023-01-08 04:41:21 --> Config Class Initialized
INFO - 2023-01-08 04:41:21 --> Loader Class Initialized
INFO - 2023-01-08 04:41:21 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:21 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:21 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:21 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:21 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:21 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 04:41:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:21 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:21 --> Total execution time: 0.0719
INFO - 2023-01-08 04:41:22 --> Config Class Initialized
INFO - 2023-01-08 04:41:22 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:22 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:22 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:22 --> URI Class Initialized
DEBUG - 2023-01-08 04:41:22 --> No URI present. Default controller set.
INFO - 2023-01-08 04:41:22 --> Router Class Initialized
INFO - 2023-01-08 04:41:22 --> Output Class Initialized
INFO - 2023-01-08 04:41:22 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:22 --> Input Class Initialized
INFO - 2023-01-08 04:41:22 --> Language Class Initialized
INFO - 2023-01-08 04:41:22 --> Language Class Initialized
INFO - 2023-01-08 04:41:22 --> Config Class Initialized
INFO - 2023-01-08 04:41:22 --> Loader Class Initialized
INFO - 2023-01-08 04:41:22 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:22 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:22 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:22 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:22 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:22 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 04:41:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:22 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:22 --> Total execution time: 0.0354
INFO - 2023-01-08 04:41:24 --> Config Class Initialized
INFO - 2023-01-08 04:41:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:24 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:24 --> URI Class Initialized
INFO - 2023-01-08 04:41:24 --> Router Class Initialized
INFO - 2023-01-08 04:41:24 --> Output Class Initialized
INFO - 2023-01-08 04:41:24 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:24 --> Input Class Initialized
INFO - 2023-01-08 04:41:24 --> Language Class Initialized
INFO - 2023-01-08 04:41:24 --> Language Class Initialized
INFO - 2023-01-08 04:41:24 --> Config Class Initialized
INFO - 2023-01-08 04:41:24 --> Loader Class Initialized
INFO - 2023-01-08 04:41:24 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:24 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:24 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:24 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:24 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-08 04:41:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:24 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:24 --> Total execution time: 0.0490
INFO - 2023-01-08 04:41:25 --> Config Class Initialized
INFO - 2023-01-08 04:41:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:25 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:25 --> URI Class Initialized
INFO - 2023-01-08 04:41:25 --> Router Class Initialized
INFO - 2023-01-08 04:41:25 --> Output Class Initialized
INFO - 2023-01-08 04:41:25 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:25 --> Input Class Initialized
INFO - 2023-01-08 04:41:25 --> Language Class Initialized
INFO - 2023-01-08 04:41:25 --> Language Class Initialized
INFO - 2023-01-08 04:41:25 --> Config Class Initialized
INFO - 2023-01-08 04:41:25 --> Loader Class Initialized
INFO - 2023-01-08 04:41:25 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:25 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:25 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:25 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:26 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-01-08 04:41:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:26 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:26 --> Total execution time: 0.0832
INFO - 2023-01-08 04:41:29 --> Config Class Initialized
INFO - 2023-01-08 04:41:29 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:29 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:29 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:29 --> URI Class Initialized
INFO - 2023-01-08 04:41:29 --> Router Class Initialized
INFO - 2023-01-08 04:41:29 --> Output Class Initialized
INFO - 2023-01-08 04:41:29 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:29 --> Input Class Initialized
INFO - 2023-01-08 04:41:29 --> Language Class Initialized
INFO - 2023-01-08 04:41:29 --> Language Class Initialized
INFO - 2023-01-08 04:41:29 --> Config Class Initialized
INFO - 2023-01-08 04:41:29 --> Loader Class Initialized
INFO - 2023-01-08 04:41:29 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:29 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:29 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:29 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:29 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:29 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_rapot_pts.php
INFO - 2023-01-08 04:41:29 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:29 --> Total execution time: 0.1086
INFO - 2023-01-08 04:41:57 --> Config Class Initialized
INFO - 2023-01-08 04:41:57 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:41:57 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:41:57 --> Utf8 Class Initialized
INFO - 2023-01-08 04:41:57 --> URI Class Initialized
INFO - 2023-01-08 04:41:57 --> Router Class Initialized
INFO - 2023-01-08 04:41:57 --> Output Class Initialized
INFO - 2023-01-08 04:41:57 --> Security Class Initialized
DEBUG - 2023-01-08 04:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:41:57 --> Input Class Initialized
INFO - 2023-01-08 04:41:57 --> Language Class Initialized
INFO - 2023-01-08 04:41:57 --> Language Class Initialized
INFO - 2023-01-08 04:41:57 --> Config Class Initialized
INFO - 2023-01-08 04:41:57 --> Loader Class Initialized
INFO - 2023-01-08 04:41:57 --> Helper loaded: url_helper
INFO - 2023-01-08 04:41:57 --> Helper loaded: file_helper
INFO - 2023-01-08 04:41:57 --> Helper loaded: form_helper
INFO - 2023-01-08 04:41:57 --> Helper loaded: my_helper
INFO - 2023-01-08 04:41:57 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:41:57 --> Controller Class Initialized
DEBUG - 2023-01-08 04:41:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-01-08 04:41:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:41:57 --> Final output sent to browser
DEBUG - 2023-01-08 04:41:57 --> Total execution time: 0.0660
INFO - 2023-01-08 04:42:02 --> Config Class Initialized
INFO - 2023-01-08 04:42:02 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:42:02 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:42:02 --> Utf8 Class Initialized
INFO - 2023-01-08 04:42:02 --> URI Class Initialized
INFO - 2023-01-08 04:42:02 --> Router Class Initialized
INFO - 2023-01-08 04:42:02 --> Output Class Initialized
INFO - 2023-01-08 04:42:02 --> Security Class Initialized
DEBUG - 2023-01-08 04:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:42:02 --> Input Class Initialized
INFO - 2023-01-08 04:42:02 --> Language Class Initialized
INFO - 2023-01-08 04:42:02 --> Language Class Initialized
INFO - 2023-01-08 04:42:02 --> Config Class Initialized
INFO - 2023-01-08 04:42:02 --> Loader Class Initialized
INFO - 2023-01-08 04:42:02 --> Helper loaded: url_helper
INFO - 2023-01-08 04:42:02 --> Helper loaded: file_helper
INFO - 2023-01-08 04:42:02 --> Helper loaded: form_helper
INFO - 2023-01-08 04:42:02 --> Helper loaded: my_helper
INFO - 2023-01-08 04:42:02 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:42:02 --> Controller Class Initialized
DEBUG - 2023-01-08 04:42:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_ubah_password.php
DEBUG - 2023-01-08 04:42:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:42:02 --> Final output sent to browser
DEBUG - 2023-01-08 04:42:02 --> Total execution time: 0.0630
INFO - 2023-01-08 04:42:05 --> Config Class Initialized
INFO - 2023-01-08 04:42:05 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:42:05 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:42:05 --> Utf8 Class Initialized
INFO - 2023-01-08 04:42:05 --> URI Class Initialized
INFO - 2023-01-08 04:42:05 --> Router Class Initialized
INFO - 2023-01-08 04:42:05 --> Output Class Initialized
INFO - 2023-01-08 04:42:05 --> Security Class Initialized
DEBUG - 2023-01-08 04:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:42:05 --> Input Class Initialized
INFO - 2023-01-08 04:42:05 --> Language Class Initialized
INFO - 2023-01-08 04:42:05 --> Language Class Initialized
INFO - 2023-01-08 04:42:05 --> Config Class Initialized
INFO - 2023-01-08 04:42:05 --> Loader Class Initialized
INFO - 2023-01-08 04:42:05 --> Helper loaded: url_helper
INFO - 2023-01-08 04:42:05 --> Helper loaded: file_helper
INFO - 2023-01-08 04:42:05 --> Helper loaded: form_helper
INFO - 2023-01-08 04:42:05 --> Helper loaded: my_helper
INFO - 2023-01-08 04:42:05 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:42:05 --> Controller Class Initialized
DEBUG - 2023-01-08 04:42:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_ubah_password.php
DEBUG - 2023-01-08 04:42:05 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:42:05 --> Final output sent to browser
DEBUG - 2023-01-08 04:42:05 --> Total execution time: 0.0384
INFO - 2023-01-08 04:42:09 --> Config Class Initialized
INFO - 2023-01-08 04:42:09 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:42:09 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:42:09 --> Utf8 Class Initialized
INFO - 2023-01-08 04:42:09 --> URI Class Initialized
INFO - 2023-01-08 04:42:09 --> Router Class Initialized
INFO - 2023-01-08 04:42:09 --> Output Class Initialized
INFO - 2023-01-08 04:42:09 --> Security Class Initialized
DEBUG - 2023-01-08 04:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:42:09 --> Input Class Initialized
INFO - 2023-01-08 04:42:09 --> Language Class Initialized
INFO - 2023-01-08 04:42:09 --> Language Class Initialized
INFO - 2023-01-08 04:42:09 --> Config Class Initialized
INFO - 2023-01-08 04:42:09 --> Loader Class Initialized
INFO - 2023-01-08 04:42:09 --> Helper loaded: url_helper
INFO - 2023-01-08 04:42:09 --> Helper loaded: file_helper
INFO - 2023-01-08 04:42:09 --> Helper loaded: form_helper
INFO - 2023-01-08 04:42:09 --> Helper loaded: my_helper
INFO - 2023-01-08 04:42:09 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:42:09 --> Controller Class Initialized
DEBUG - 2023-01-08 04:42:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-08 04:42:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:42:09 --> Final output sent to browser
DEBUG - 2023-01-08 04:42:09 --> Total execution time: 0.0395
INFO - 2023-01-08 04:42:42 --> Config Class Initialized
INFO - 2023-01-08 04:42:42 --> Hooks Class Initialized
DEBUG - 2023-01-08 04:42:42 --> UTF-8 Support Enabled
INFO - 2023-01-08 04:42:42 --> Utf8 Class Initialized
INFO - 2023-01-08 04:42:42 --> URI Class Initialized
INFO - 2023-01-08 04:42:42 --> Router Class Initialized
INFO - 2023-01-08 04:42:42 --> Output Class Initialized
INFO - 2023-01-08 04:42:42 --> Security Class Initialized
DEBUG - 2023-01-08 04:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 04:42:42 --> Input Class Initialized
INFO - 2023-01-08 04:42:42 --> Language Class Initialized
INFO - 2023-01-08 04:42:42 --> Language Class Initialized
INFO - 2023-01-08 04:42:42 --> Config Class Initialized
INFO - 2023-01-08 04:42:42 --> Loader Class Initialized
INFO - 2023-01-08 04:42:42 --> Helper loaded: url_helper
INFO - 2023-01-08 04:42:42 --> Helper loaded: file_helper
INFO - 2023-01-08 04:42:42 --> Helper loaded: form_helper
INFO - 2023-01-08 04:42:42 --> Helper loaded: my_helper
INFO - 2023-01-08 04:42:42 --> Database Driver Class Initialized
DEBUG - 2023-01-08 04:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 04:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 04:42:42 --> Controller Class Initialized
DEBUG - 2023-01-08 04:42:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-01-08 04:42:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 04:42:42 --> Final output sent to browser
DEBUG - 2023-01-08 04:42:42 --> Total execution time: 0.0549
INFO - 2023-01-08 05:29:10 --> Config Class Initialized
INFO - 2023-01-08 05:29:10 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:29:10 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:29:10 --> Utf8 Class Initialized
INFO - 2023-01-08 05:29:10 --> URI Class Initialized
INFO - 2023-01-08 05:29:10 --> Router Class Initialized
INFO - 2023-01-08 05:29:10 --> Output Class Initialized
INFO - 2023-01-08 05:29:10 --> Security Class Initialized
DEBUG - 2023-01-08 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:29:10 --> Input Class Initialized
INFO - 2023-01-08 05:29:10 --> Language Class Initialized
INFO - 2023-01-08 05:29:10 --> Language Class Initialized
INFO - 2023-01-08 05:29:10 --> Config Class Initialized
INFO - 2023-01-08 05:29:10 --> Loader Class Initialized
INFO - 2023-01-08 05:29:10 --> Helper loaded: url_helper
INFO - 2023-01-08 05:29:10 --> Helper loaded: file_helper
INFO - 2023-01-08 05:29:10 --> Helper loaded: form_helper
INFO - 2023-01-08 05:29:10 --> Helper loaded: my_helper
INFO - 2023-01-08 05:29:10 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:29:10 --> Controller Class Initialized
DEBUG - 2023-01-08 05:29:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-08 05:29:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:29:10 --> Final output sent to browser
DEBUG - 2023-01-08 05:29:10 --> Total execution time: 0.0583
INFO - 2023-01-08 05:29:12 --> Config Class Initialized
INFO - 2023-01-08 05:29:12 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:29:12 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:29:12 --> Utf8 Class Initialized
INFO - 2023-01-08 05:29:12 --> URI Class Initialized
INFO - 2023-01-08 05:29:12 --> Router Class Initialized
INFO - 2023-01-08 05:29:12 --> Output Class Initialized
INFO - 2023-01-08 05:29:12 --> Security Class Initialized
DEBUG - 2023-01-08 05:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:29:12 --> Input Class Initialized
INFO - 2023-01-08 05:29:12 --> Language Class Initialized
INFO - 2023-01-08 05:29:12 --> Language Class Initialized
INFO - 2023-01-08 05:29:12 --> Config Class Initialized
INFO - 2023-01-08 05:29:12 --> Loader Class Initialized
INFO - 2023-01-08 05:29:12 --> Helper loaded: url_helper
INFO - 2023-01-08 05:29:12 --> Helper loaded: file_helper
INFO - 2023-01-08 05:29:12 --> Helper loaded: form_helper
INFO - 2023-01-08 05:29:12 --> Helper loaded: my_helper
INFO - 2023-01-08 05:29:12 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:29:12 --> Controller Class Initialized
DEBUG - 2023-01-08 05:29:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:29:13 --> Final output sent to browser
DEBUG - 2023-01-08 05:29:13 --> Total execution time: 0.3441
INFO - 2023-01-08 05:29:22 --> Config Class Initialized
INFO - 2023-01-08 05:29:22 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:29:22 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:29:22 --> Utf8 Class Initialized
INFO - 2023-01-08 05:29:22 --> URI Class Initialized
INFO - 2023-01-08 05:29:22 --> Router Class Initialized
INFO - 2023-01-08 05:29:22 --> Output Class Initialized
INFO - 2023-01-08 05:29:22 --> Security Class Initialized
DEBUG - 2023-01-08 05:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:29:22 --> Input Class Initialized
INFO - 2023-01-08 05:29:22 --> Language Class Initialized
INFO - 2023-01-08 05:29:22 --> Language Class Initialized
INFO - 2023-01-08 05:29:22 --> Config Class Initialized
INFO - 2023-01-08 05:29:22 --> Loader Class Initialized
INFO - 2023-01-08 05:29:22 --> Helper loaded: url_helper
INFO - 2023-01-08 05:29:22 --> Helper loaded: file_helper
INFO - 2023-01-08 05:29:22 --> Helper loaded: form_helper
INFO - 2023-01-08 05:29:22 --> Helper loaded: my_helper
INFO - 2023-01-08 05:29:22 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:29:22 --> Controller Class Initialized
DEBUG - 2023-01-08 05:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-08 05:29:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:29:22 --> Final output sent to browser
DEBUG - 2023-01-08 05:29:22 --> Total execution time: 0.0412
INFO - 2023-01-08 05:42:32 --> Config Class Initialized
INFO - 2023-01-08 05:42:32 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:42:32 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:42:32 --> Utf8 Class Initialized
INFO - 2023-01-08 05:42:32 --> URI Class Initialized
INFO - 2023-01-08 05:42:32 --> Router Class Initialized
INFO - 2023-01-08 05:42:32 --> Output Class Initialized
INFO - 2023-01-08 05:42:32 --> Security Class Initialized
DEBUG - 2023-01-08 05:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:42:32 --> Input Class Initialized
INFO - 2023-01-08 05:42:32 --> Language Class Initialized
INFO - 2023-01-08 05:42:32 --> Language Class Initialized
INFO - 2023-01-08 05:42:32 --> Config Class Initialized
INFO - 2023-01-08 05:42:32 --> Loader Class Initialized
INFO - 2023-01-08 05:42:32 --> Helper loaded: url_helper
INFO - 2023-01-08 05:42:32 --> Helper loaded: file_helper
INFO - 2023-01-08 05:42:32 --> Helper loaded: form_helper
INFO - 2023-01-08 05:42:32 --> Helper loaded: my_helper
INFO - 2023-01-08 05:42:32 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:42:32 --> Controller Class Initialized
DEBUG - 2023-01-08 05:42:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:42:32 --> Final output sent to browser
DEBUG - 2023-01-08 05:42:32 --> Total execution time: 0.2060
INFO - 2023-01-08 05:51:48 --> Config Class Initialized
INFO - 2023-01-08 05:51:48 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:51:48 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:51:48 --> Utf8 Class Initialized
INFO - 2023-01-08 05:51:48 --> URI Class Initialized
INFO - 2023-01-08 05:51:48 --> Router Class Initialized
INFO - 2023-01-08 05:51:48 --> Output Class Initialized
INFO - 2023-01-08 05:51:48 --> Security Class Initialized
DEBUG - 2023-01-08 05:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:51:48 --> Input Class Initialized
INFO - 2023-01-08 05:51:48 --> Language Class Initialized
INFO - 2023-01-08 05:51:48 --> Language Class Initialized
INFO - 2023-01-08 05:51:48 --> Config Class Initialized
INFO - 2023-01-08 05:51:48 --> Loader Class Initialized
INFO - 2023-01-08 05:51:48 --> Helper loaded: url_helper
INFO - 2023-01-08 05:51:48 --> Helper loaded: file_helper
INFO - 2023-01-08 05:51:48 --> Helper loaded: form_helper
INFO - 2023-01-08 05:51:48 --> Helper loaded: my_helper
INFO - 2023-01-08 05:51:48 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:51:48 --> Controller Class Initialized
DEBUG - 2023-01-08 05:51:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:51:48 --> Final output sent to browser
DEBUG - 2023-01-08 05:51:48 --> Total execution time: 0.2217
INFO - 2023-01-08 05:53:17 --> Config Class Initialized
INFO - 2023-01-08 05:53:17 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:53:17 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:53:17 --> Utf8 Class Initialized
INFO - 2023-01-08 05:53:17 --> URI Class Initialized
INFO - 2023-01-08 05:53:17 --> Router Class Initialized
INFO - 2023-01-08 05:53:17 --> Output Class Initialized
INFO - 2023-01-08 05:53:17 --> Security Class Initialized
DEBUG - 2023-01-08 05:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:53:17 --> Input Class Initialized
INFO - 2023-01-08 05:53:17 --> Language Class Initialized
INFO - 2023-01-08 05:53:17 --> Language Class Initialized
INFO - 2023-01-08 05:53:17 --> Config Class Initialized
INFO - 2023-01-08 05:53:17 --> Loader Class Initialized
INFO - 2023-01-08 05:53:17 --> Helper loaded: url_helper
INFO - 2023-01-08 05:53:17 --> Helper loaded: file_helper
INFO - 2023-01-08 05:53:17 --> Helper loaded: form_helper
INFO - 2023-01-08 05:53:17 --> Helper loaded: my_helper
INFO - 2023-01-08 05:53:17 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:53:17 --> Controller Class Initialized
ERROR - 2023-01-08 05:53:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 05:53:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 05:53:17 --> Severity: Warning --> max(): When only one parameter is given, it must be an array C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
DEBUG - 2023-01-08 05:53:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:53:17 --> Final output sent to browser
DEBUG - 2023-01-08 05:53:17 --> Total execution time: 0.2478
INFO - 2023-01-08 05:54:08 --> Config Class Initialized
INFO - 2023-01-08 05:54:08 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:54:08 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:54:08 --> Utf8 Class Initialized
INFO - 2023-01-08 05:54:08 --> URI Class Initialized
INFO - 2023-01-08 05:54:08 --> Router Class Initialized
INFO - 2023-01-08 05:54:08 --> Output Class Initialized
INFO - 2023-01-08 05:54:08 --> Security Class Initialized
DEBUG - 2023-01-08 05:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:54:08 --> Input Class Initialized
INFO - 2023-01-08 05:54:08 --> Language Class Initialized
INFO - 2023-01-08 05:54:08 --> Language Class Initialized
INFO - 2023-01-08 05:54:08 --> Config Class Initialized
INFO - 2023-01-08 05:54:08 --> Loader Class Initialized
INFO - 2023-01-08 05:54:08 --> Helper loaded: url_helper
INFO - 2023-01-08 05:54:08 --> Helper loaded: file_helper
INFO - 2023-01-08 05:54:08 --> Helper loaded: form_helper
INFO - 2023-01-08 05:54:08 --> Helper loaded: my_helper
INFO - 2023-01-08 05:54:08 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:54:08 --> Controller Class Initialized
ERROR - 2023-01-08 05:54:08 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 187
DEBUG - 2023-01-08 05:54:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:54:08 --> Final output sent to browser
DEBUG - 2023-01-08 05:54:08 --> Total execution time: 0.1911
INFO - 2023-01-08 05:55:21 --> Config Class Initialized
INFO - 2023-01-08 05:55:21 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:55:21 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:55:21 --> Utf8 Class Initialized
INFO - 2023-01-08 05:55:21 --> URI Class Initialized
INFO - 2023-01-08 05:55:21 --> Router Class Initialized
INFO - 2023-01-08 05:55:21 --> Output Class Initialized
INFO - 2023-01-08 05:55:21 --> Security Class Initialized
DEBUG - 2023-01-08 05:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:55:21 --> Input Class Initialized
INFO - 2023-01-08 05:55:21 --> Language Class Initialized
INFO - 2023-01-08 05:55:21 --> Language Class Initialized
INFO - 2023-01-08 05:55:21 --> Config Class Initialized
INFO - 2023-01-08 05:55:21 --> Loader Class Initialized
INFO - 2023-01-08 05:55:21 --> Helper loaded: url_helper
INFO - 2023-01-08 05:55:21 --> Helper loaded: file_helper
INFO - 2023-01-08 05:55:21 --> Helper loaded: form_helper
INFO - 2023-01-08 05:55:21 --> Helper loaded: my_helper
INFO - 2023-01-08 05:55:21 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:55:21 --> Controller Class Initialized
ERROR - 2023-01-08 05:55:21 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 187
DEBUG - 2023-01-08 05:55:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:55:21 --> Final output sent to browser
DEBUG - 2023-01-08 05:55:21 --> Total execution time: 0.2237
INFO - 2023-01-08 05:55:49 --> Config Class Initialized
INFO - 2023-01-08 05:55:49 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:55:49 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:55:49 --> Utf8 Class Initialized
INFO - 2023-01-08 05:55:49 --> URI Class Initialized
INFO - 2023-01-08 05:55:49 --> Router Class Initialized
INFO - 2023-01-08 05:55:49 --> Output Class Initialized
INFO - 2023-01-08 05:55:49 --> Security Class Initialized
DEBUG - 2023-01-08 05:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:55:49 --> Input Class Initialized
INFO - 2023-01-08 05:55:49 --> Language Class Initialized
INFO - 2023-01-08 05:55:49 --> Language Class Initialized
INFO - 2023-01-08 05:55:49 --> Config Class Initialized
INFO - 2023-01-08 05:55:49 --> Loader Class Initialized
INFO - 2023-01-08 05:55:49 --> Helper loaded: url_helper
INFO - 2023-01-08 05:55:49 --> Helper loaded: file_helper
INFO - 2023-01-08 05:55:49 --> Helper loaded: form_helper
INFO - 2023-01-08 05:55:49 --> Helper loaded: my_helper
INFO - 2023-01-08 05:55:49 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:55:49 --> Controller Class Initialized
DEBUG - 2023-01-08 05:55:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:55:49 --> Final output sent to browser
DEBUG - 2023-01-08 05:55:49 --> Total execution time: 0.2052
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:24 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:24 --> URI Class Initialized
INFO - 2023-01-08 05:56:24 --> Router Class Initialized
INFO - 2023-01-08 05:56:24 --> Output Class Initialized
INFO - 2023-01-08 05:56:24 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:24 --> Input Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Loader Class Initialized
INFO - 2023-01-08 05:56:24 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:24 --> Controller Class Initialized
INFO - 2023-01-08 05:56:24 --> Helper loaded: cookie_helper
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:24 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:24 --> URI Class Initialized
INFO - 2023-01-08 05:56:24 --> Router Class Initialized
INFO - 2023-01-08 05:56:24 --> Output Class Initialized
INFO - 2023-01-08 05:56:24 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:24 --> Input Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Loader Class Initialized
INFO - 2023-01-08 05:56:24 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:24 --> Controller Class Initialized
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:24 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:24 --> URI Class Initialized
INFO - 2023-01-08 05:56:24 --> Router Class Initialized
INFO - 2023-01-08 05:56:24 --> Output Class Initialized
INFO - 2023-01-08 05:56:24 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:24 --> Input Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Language Class Initialized
INFO - 2023-01-08 05:56:24 --> Config Class Initialized
INFO - 2023-01-08 05:56:24 --> Loader Class Initialized
INFO - 2023-01-08 05:56:24 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:24 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:24 --> Controller Class Initialized
DEBUG - 2023-01-08 05:56:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 05:56:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:56:24 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:24 --> Total execution time: 0.0546
INFO - 2023-01-08 05:56:28 --> Config Class Initialized
INFO - 2023-01-08 05:56:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:28 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:28 --> URI Class Initialized
INFO - 2023-01-08 05:56:28 --> Router Class Initialized
INFO - 2023-01-08 05:56:28 --> Output Class Initialized
INFO - 2023-01-08 05:56:28 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:28 --> Input Class Initialized
INFO - 2023-01-08 05:56:28 --> Language Class Initialized
INFO - 2023-01-08 05:56:28 --> Language Class Initialized
INFO - 2023-01-08 05:56:28 --> Config Class Initialized
INFO - 2023-01-08 05:56:28 --> Loader Class Initialized
INFO - 2023-01-08 05:56:28 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:28 --> Controller Class Initialized
INFO - 2023-01-08 05:56:28 --> Helper loaded: cookie_helper
INFO - 2023-01-08 05:56:28 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:28 --> Total execution time: 0.0420
INFO - 2023-01-08 05:56:28 --> Config Class Initialized
INFO - 2023-01-08 05:56:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:28 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:28 --> URI Class Initialized
INFO - 2023-01-08 05:56:28 --> Router Class Initialized
INFO - 2023-01-08 05:56:28 --> Output Class Initialized
INFO - 2023-01-08 05:56:28 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:28 --> Input Class Initialized
INFO - 2023-01-08 05:56:28 --> Language Class Initialized
INFO - 2023-01-08 05:56:28 --> Language Class Initialized
INFO - 2023-01-08 05:56:28 --> Config Class Initialized
INFO - 2023-01-08 05:56:28 --> Loader Class Initialized
INFO - 2023-01-08 05:56:28 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:28 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:28 --> Controller Class Initialized
DEBUG - 2023-01-08 05:56:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 05:56:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:56:28 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:28 --> Total execution time: 0.0623
INFO - 2023-01-08 05:56:30 --> Config Class Initialized
INFO - 2023-01-08 05:56:30 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:30 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:30 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:30 --> URI Class Initialized
INFO - 2023-01-08 05:56:30 --> Router Class Initialized
INFO - 2023-01-08 05:56:30 --> Output Class Initialized
INFO - 2023-01-08 05:56:30 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:30 --> Input Class Initialized
INFO - 2023-01-08 05:56:30 --> Language Class Initialized
INFO - 2023-01-08 05:56:30 --> Language Class Initialized
INFO - 2023-01-08 05:56:30 --> Config Class Initialized
INFO - 2023-01-08 05:56:30 --> Loader Class Initialized
INFO - 2023-01-08 05:56:30 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:30 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:30 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:30 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:30 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:30 --> Controller Class Initialized
DEBUG - 2023-01-08 05:56:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 05:56:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:56:30 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:30 --> Total execution time: 0.0523
INFO - 2023-01-08 05:56:33 --> Config Class Initialized
INFO - 2023-01-08 05:56:33 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:33 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:33 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:33 --> URI Class Initialized
INFO - 2023-01-08 05:56:33 --> Router Class Initialized
INFO - 2023-01-08 05:56:33 --> Output Class Initialized
INFO - 2023-01-08 05:56:33 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:33 --> Input Class Initialized
INFO - 2023-01-08 05:56:33 --> Language Class Initialized
INFO - 2023-01-08 05:56:33 --> Language Class Initialized
INFO - 2023-01-08 05:56:33 --> Config Class Initialized
INFO - 2023-01-08 05:56:33 --> Loader Class Initialized
INFO - 2023-01-08 05:56:33 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:33 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:33 --> Controller Class Initialized
DEBUG - 2023-01-08 05:56:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 05:56:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 05:56:33 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:33 --> Total execution time: 0.0457
INFO - 2023-01-08 05:56:33 --> Config Class Initialized
INFO - 2023-01-08 05:56:33 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:33 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:33 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:33 --> URI Class Initialized
INFO - 2023-01-08 05:56:33 --> Router Class Initialized
INFO - 2023-01-08 05:56:33 --> Output Class Initialized
INFO - 2023-01-08 05:56:33 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:33 --> Input Class Initialized
INFO - 2023-01-08 05:56:33 --> Language Class Initialized
INFO - 2023-01-08 05:56:33 --> Language Class Initialized
INFO - 2023-01-08 05:56:33 --> Config Class Initialized
INFO - 2023-01-08 05:56:33 --> Loader Class Initialized
INFO - 2023-01-08 05:56:33 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:33 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:33 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:33 --> Controller Class Initialized
INFO - 2023-01-08 05:56:49 --> Config Class Initialized
INFO - 2023-01-08 05:56:49 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:56:49 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:56:49 --> Utf8 Class Initialized
INFO - 2023-01-08 05:56:49 --> URI Class Initialized
INFO - 2023-01-08 05:56:49 --> Router Class Initialized
INFO - 2023-01-08 05:56:49 --> Output Class Initialized
INFO - 2023-01-08 05:56:49 --> Security Class Initialized
DEBUG - 2023-01-08 05:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:56:49 --> Input Class Initialized
INFO - 2023-01-08 05:56:49 --> Language Class Initialized
INFO - 2023-01-08 05:56:49 --> Language Class Initialized
INFO - 2023-01-08 05:56:49 --> Config Class Initialized
INFO - 2023-01-08 05:56:49 --> Loader Class Initialized
INFO - 2023-01-08 05:56:49 --> Helper loaded: url_helper
INFO - 2023-01-08 05:56:49 --> Helper loaded: file_helper
INFO - 2023-01-08 05:56:49 --> Helper loaded: form_helper
INFO - 2023-01-08 05:56:49 --> Helper loaded: my_helper
INFO - 2023-01-08 05:56:49 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:56:49 --> Controller Class Initialized
INFO - 2023-01-08 05:56:49 --> Final output sent to browser
DEBUG - 2023-01-08 05:56:49 --> Total execution time: 0.0457
INFO - 2023-01-08 05:57:21 --> Config Class Initialized
INFO - 2023-01-08 05:57:21 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:57:21 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:57:21 --> Utf8 Class Initialized
INFO - 2023-01-08 05:57:21 --> URI Class Initialized
INFO - 2023-01-08 05:57:21 --> Router Class Initialized
INFO - 2023-01-08 05:57:21 --> Output Class Initialized
INFO - 2023-01-08 05:57:21 --> Security Class Initialized
DEBUG - 2023-01-08 05:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:57:21 --> Input Class Initialized
INFO - 2023-01-08 05:57:21 --> Language Class Initialized
INFO - 2023-01-08 05:57:21 --> Language Class Initialized
INFO - 2023-01-08 05:57:21 --> Config Class Initialized
INFO - 2023-01-08 05:57:21 --> Loader Class Initialized
INFO - 2023-01-08 05:57:21 --> Helper loaded: url_helper
INFO - 2023-01-08 05:57:21 --> Helper loaded: file_helper
INFO - 2023-01-08 05:57:21 --> Helper loaded: form_helper
INFO - 2023-01-08 05:57:21 --> Helper loaded: my_helper
INFO - 2023-01-08 05:57:21 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:57:21 --> Controller Class Initialized
INFO - 2023-01-08 05:57:21 --> Final output sent to browser
DEBUG - 2023-01-08 05:57:21 --> Total execution time: 0.0535
INFO - 2023-01-08 05:57:31 --> Config Class Initialized
INFO - 2023-01-08 05:57:31 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:57:31 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:57:31 --> Utf8 Class Initialized
INFO - 2023-01-08 05:57:31 --> URI Class Initialized
INFO - 2023-01-08 05:57:31 --> Router Class Initialized
INFO - 2023-01-08 05:57:31 --> Output Class Initialized
INFO - 2023-01-08 05:57:31 --> Security Class Initialized
DEBUG - 2023-01-08 05:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:57:31 --> Input Class Initialized
INFO - 2023-01-08 05:57:31 --> Language Class Initialized
INFO - 2023-01-08 05:57:31 --> Language Class Initialized
INFO - 2023-01-08 05:57:31 --> Config Class Initialized
INFO - 2023-01-08 05:57:31 --> Loader Class Initialized
INFO - 2023-01-08 05:57:31 --> Helper loaded: url_helper
INFO - 2023-01-08 05:57:31 --> Helper loaded: file_helper
INFO - 2023-01-08 05:57:31 --> Helper loaded: form_helper
INFO - 2023-01-08 05:57:31 --> Helper loaded: my_helper
INFO - 2023-01-08 05:57:31 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:57:32 --> Controller Class Initialized
INFO - 2023-01-08 05:57:32 --> Final output sent to browser
DEBUG - 2023-01-08 05:57:32 --> Total execution time: 0.0564
INFO - 2023-01-08 05:57:44 --> Config Class Initialized
INFO - 2023-01-08 05:57:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:57:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:57:44 --> Utf8 Class Initialized
INFO - 2023-01-08 05:57:44 --> URI Class Initialized
INFO - 2023-01-08 05:57:44 --> Router Class Initialized
INFO - 2023-01-08 05:57:44 --> Output Class Initialized
INFO - 2023-01-08 05:57:44 --> Security Class Initialized
DEBUG - 2023-01-08 05:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:57:44 --> Input Class Initialized
INFO - 2023-01-08 05:57:44 --> Language Class Initialized
INFO - 2023-01-08 05:57:44 --> Language Class Initialized
INFO - 2023-01-08 05:57:44 --> Config Class Initialized
INFO - 2023-01-08 05:57:44 --> Loader Class Initialized
INFO - 2023-01-08 05:57:44 --> Helper loaded: url_helper
INFO - 2023-01-08 05:57:44 --> Helper loaded: file_helper
INFO - 2023-01-08 05:57:44 --> Helper loaded: form_helper
INFO - 2023-01-08 05:57:44 --> Helper loaded: my_helper
INFO - 2023-01-08 05:57:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:57:44 --> Controller Class Initialized
INFO - 2023-01-08 05:57:44 --> Final output sent to browser
DEBUG - 2023-01-08 05:57:44 --> Total execution time: 0.0405
INFO - 2023-01-08 05:58:39 --> Config Class Initialized
INFO - 2023-01-08 05:58:39 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:58:39 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:58:39 --> Utf8 Class Initialized
INFO - 2023-01-08 05:58:39 --> URI Class Initialized
INFO - 2023-01-08 05:58:39 --> Router Class Initialized
INFO - 2023-01-08 05:58:39 --> Output Class Initialized
INFO - 2023-01-08 05:58:39 --> Security Class Initialized
DEBUG - 2023-01-08 05:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:58:39 --> Input Class Initialized
INFO - 2023-01-08 05:58:39 --> Language Class Initialized
INFO - 2023-01-08 05:58:39 --> Language Class Initialized
INFO - 2023-01-08 05:58:39 --> Config Class Initialized
INFO - 2023-01-08 05:58:39 --> Loader Class Initialized
INFO - 2023-01-08 05:58:39 --> Helper loaded: url_helper
INFO - 2023-01-08 05:58:39 --> Helper loaded: file_helper
INFO - 2023-01-08 05:58:39 --> Helper loaded: form_helper
INFO - 2023-01-08 05:58:39 --> Helper loaded: my_helper
INFO - 2023-01-08 05:58:39 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:58:39 --> Controller Class Initialized
ERROR - 2023-01-08 05:58:39 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 187
DEBUG - 2023-01-08 05:58:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:58:39 --> Final output sent to browser
DEBUG - 2023-01-08 05:58:39 --> Total execution time: 0.2106
INFO - 2023-01-08 05:58:50 --> Config Class Initialized
INFO - 2023-01-08 05:58:50 --> Hooks Class Initialized
DEBUG - 2023-01-08 05:58:50 --> UTF-8 Support Enabled
INFO - 2023-01-08 05:58:50 --> Utf8 Class Initialized
INFO - 2023-01-08 05:58:50 --> URI Class Initialized
INFO - 2023-01-08 05:58:50 --> Router Class Initialized
INFO - 2023-01-08 05:58:50 --> Output Class Initialized
INFO - 2023-01-08 05:58:50 --> Security Class Initialized
DEBUG - 2023-01-08 05:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 05:58:50 --> Input Class Initialized
INFO - 2023-01-08 05:58:50 --> Language Class Initialized
INFO - 2023-01-08 05:58:50 --> Language Class Initialized
INFO - 2023-01-08 05:58:50 --> Config Class Initialized
INFO - 2023-01-08 05:58:50 --> Loader Class Initialized
INFO - 2023-01-08 05:58:50 --> Helper loaded: url_helper
INFO - 2023-01-08 05:58:50 --> Helper loaded: file_helper
INFO - 2023-01-08 05:58:50 --> Helper loaded: form_helper
INFO - 2023-01-08 05:58:50 --> Helper loaded: my_helper
INFO - 2023-01-08 05:58:50 --> Database Driver Class Initialized
DEBUG - 2023-01-08 05:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 05:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 05:58:50 --> Controller Class Initialized
DEBUG - 2023-01-08 05:58:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 05:58:50 --> Final output sent to browser
DEBUG - 2023-01-08 05:58:50 --> Total execution time: 0.2303
INFO - 2023-01-08 06:01:33 --> Config Class Initialized
INFO - 2023-01-08 06:01:33 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:01:33 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:01:33 --> Utf8 Class Initialized
INFO - 2023-01-08 06:01:33 --> URI Class Initialized
INFO - 2023-01-08 06:01:33 --> Router Class Initialized
INFO - 2023-01-08 06:01:33 --> Output Class Initialized
INFO - 2023-01-08 06:01:33 --> Security Class Initialized
DEBUG - 2023-01-08 06:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:01:33 --> Input Class Initialized
INFO - 2023-01-08 06:01:33 --> Language Class Initialized
INFO - 2023-01-08 06:01:33 --> Language Class Initialized
INFO - 2023-01-08 06:01:33 --> Config Class Initialized
INFO - 2023-01-08 06:01:33 --> Loader Class Initialized
INFO - 2023-01-08 06:01:33 --> Helper loaded: url_helper
INFO - 2023-01-08 06:01:33 --> Helper loaded: file_helper
INFO - 2023-01-08 06:01:33 --> Helper loaded: form_helper
INFO - 2023-01-08 06:01:33 --> Helper loaded: my_helper
INFO - 2023-01-08 06:01:33 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:01:33 --> Controller Class Initialized
ERROR - 2023-01-08 06:01:33 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:01:33 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:01:33 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
DEBUG - 2023-01-08 06:01:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:01:33 --> Final output sent to browser
DEBUG - 2023-01-08 06:01:33 --> Total execution time: 0.2742
INFO - 2023-01-08 06:02:06 --> Config Class Initialized
INFO - 2023-01-08 06:02:06 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:02:06 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:02:06 --> Utf8 Class Initialized
INFO - 2023-01-08 06:02:06 --> URI Class Initialized
INFO - 2023-01-08 06:02:06 --> Router Class Initialized
INFO - 2023-01-08 06:02:06 --> Output Class Initialized
INFO - 2023-01-08 06:02:06 --> Security Class Initialized
DEBUG - 2023-01-08 06:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:02:06 --> Input Class Initialized
INFO - 2023-01-08 06:02:06 --> Language Class Initialized
INFO - 2023-01-08 06:02:06 --> Language Class Initialized
INFO - 2023-01-08 06:02:06 --> Config Class Initialized
INFO - 2023-01-08 06:02:06 --> Loader Class Initialized
INFO - 2023-01-08 06:02:06 --> Helper loaded: url_helper
INFO - 2023-01-08 06:02:06 --> Helper loaded: file_helper
INFO - 2023-01-08 06:02:06 --> Helper loaded: form_helper
INFO - 2023-01-08 06:02:06 --> Helper loaded: my_helper
INFO - 2023-01-08 06:02:06 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:02:06 --> Controller Class Initialized
DEBUG - 2023-01-08 06:02:06 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:02:06 --> Final output sent to browser
DEBUG - 2023-01-08 06:02:06 --> Total execution time: 0.2120
INFO - 2023-01-08 06:03:28 --> Config Class Initialized
INFO - 2023-01-08 06:03:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:03:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:03:28 --> Utf8 Class Initialized
INFO - 2023-01-08 06:03:28 --> URI Class Initialized
INFO - 2023-01-08 06:03:28 --> Router Class Initialized
INFO - 2023-01-08 06:03:28 --> Output Class Initialized
INFO - 2023-01-08 06:03:28 --> Security Class Initialized
DEBUG - 2023-01-08 06:03:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:03:28 --> Input Class Initialized
INFO - 2023-01-08 06:03:28 --> Language Class Initialized
INFO - 2023-01-08 06:03:28 --> Language Class Initialized
INFO - 2023-01-08 06:03:28 --> Config Class Initialized
INFO - 2023-01-08 06:03:28 --> Loader Class Initialized
INFO - 2023-01-08 06:03:28 --> Helper loaded: url_helper
INFO - 2023-01-08 06:03:28 --> Helper loaded: file_helper
INFO - 2023-01-08 06:03:28 --> Helper loaded: form_helper
INFO - 2023-01-08 06:03:28 --> Helper loaded: my_helper
INFO - 2023-01-08 06:03:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:03:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:03:28 --> Controller Class Initialized
DEBUG - 2023-01-08 06:03:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:03:28 --> Final output sent to browser
DEBUG - 2023-01-08 06:03:28 --> Total execution time: 0.2211
INFO - 2023-01-08 06:04:33 --> Config Class Initialized
INFO - 2023-01-08 06:04:33 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:04:33 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:04:33 --> Utf8 Class Initialized
INFO - 2023-01-08 06:04:33 --> URI Class Initialized
INFO - 2023-01-08 06:04:33 --> Router Class Initialized
INFO - 2023-01-08 06:04:33 --> Output Class Initialized
INFO - 2023-01-08 06:04:33 --> Security Class Initialized
DEBUG - 2023-01-08 06:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:04:33 --> Input Class Initialized
INFO - 2023-01-08 06:04:33 --> Language Class Initialized
INFO - 2023-01-08 06:04:33 --> Language Class Initialized
INFO - 2023-01-08 06:04:33 --> Config Class Initialized
INFO - 2023-01-08 06:04:33 --> Loader Class Initialized
INFO - 2023-01-08 06:04:33 --> Helper loaded: url_helper
INFO - 2023-01-08 06:04:33 --> Helper loaded: file_helper
INFO - 2023-01-08 06:04:33 --> Helper loaded: form_helper
INFO - 2023-01-08 06:04:33 --> Helper loaded: my_helper
INFO - 2023-01-08 06:04:33 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:04:33 --> Controller Class Initialized
DEBUG - 2023-01-08 06:04:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:04:33 --> Final output sent to browser
DEBUG - 2023-01-08 06:04:33 --> Total execution time: 0.2014
INFO - 2023-01-08 06:05:39 --> Config Class Initialized
INFO - 2023-01-08 06:05:39 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:05:39 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:05:39 --> Utf8 Class Initialized
INFO - 2023-01-08 06:05:39 --> URI Class Initialized
INFO - 2023-01-08 06:05:39 --> Router Class Initialized
INFO - 2023-01-08 06:05:39 --> Output Class Initialized
INFO - 2023-01-08 06:05:39 --> Security Class Initialized
DEBUG - 2023-01-08 06:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:05:39 --> Input Class Initialized
INFO - 2023-01-08 06:05:39 --> Language Class Initialized
INFO - 2023-01-08 06:05:39 --> Language Class Initialized
INFO - 2023-01-08 06:05:39 --> Config Class Initialized
INFO - 2023-01-08 06:05:39 --> Loader Class Initialized
INFO - 2023-01-08 06:05:39 --> Helper loaded: url_helper
INFO - 2023-01-08 06:05:39 --> Helper loaded: file_helper
INFO - 2023-01-08 06:05:39 --> Helper loaded: form_helper
INFO - 2023-01-08 06:05:39 --> Helper loaded: my_helper
INFO - 2023-01-08 06:05:39 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:05:39 --> Controller Class Initialized
DEBUG - 2023-01-08 06:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:05:39 --> Final output sent to browser
DEBUG - 2023-01-08 06:05:39 --> Total execution time: 0.2058
INFO - 2023-01-08 06:06:31 --> Config Class Initialized
INFO - 2023-01-08 06:06:31 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:06:31 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:06:31 --> Utf8 Class Initialized
INFO - 2023-01-08 06:06:31 --> URI Class Initialized
INFO - 2023-01-08 06:06:31 --> Router Class Initialized
INFO - 2023-01-08 06:06:31 --> Output Class Initialized
INFO - 2023-01-08 06:06:31 --> Security Class Initialized
DEBUG - 2023-01-08 06:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:06:31 --> Input Class Initialized
INFO - 2023-01-08 06:06:31 --> Language Class Initialized
INFO - 2023-01-08 06:06:31 --> Language Class Initialized
INFO - 2023-01-08 06:06:31 --> Config Class Initialized
INFO - 2023-01-08 06:06:31 --> Loader Class Initialized
INFO - 2023-01-08 06:06:31 --> Helper loaded: url_helper
INFO - 2023-01-08 06:06:31 --> Helper loaded: file_helper
INFO - 2023-01-08 06:06:31 --> Helper loaded: form_helper
INFO - 2023-01-08 06:06:31 --> Helper loaded: my_helper
INFO - 2023-01-08 06:06:31 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:06:31 --> Controller Class Initialized
DEBUG - 2023-01-08 06:06:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:06:31 --> Final output sent to browser
DEBUG - 2023-01-08 06:06:31 --> Total execution time: 0.2211
INFO - 2023-01-08 06:09:56 --> Config Class Initialized
INFO - 2023-01-08 06:09:56 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:09:56 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:09:56 --> Utf8 Class Initialized
INFO - 2023-01-08 06:09:56 --> URI Class Initialized
INFO - 2023-01-08 06:09:56 --> Router Class Initialized
INFO - 2023-01-08 06:09:56 --> Output Class Initialized
INFO - 2023-01-08 06:09:56 --> Security Class Initialized
DEBUG - 2023-01-08 06:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:09:56 --> Input Class Initialized
INFO - 2023-01-08 06:09:56 --> Language Class Initialized
INFO - 2023-01-08 06:09:56 --> Language Class Initialized
INFO - 2023-01-08 06:09:56 --> Config Class Initialized
INFO - 2023-01-08 06:09:56 --> Loader Class Initialized
INFO - 2023-01-08 06:09:56 --> Helper loaded: url_helper
INFO - 2023-01-08 06:09:56 --> Helper loaded: file_helper
INFO - 2023-01-08 06:09:56 --> Helper loaded: form_helper
INFO - 2023-01-08 06:09:56 --> Helper loaded: my_helper
INFO - 2023-01-08 06:09:56 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:09:56 --> Controller Class Initialized
DEBUG - 2023-01-08 06:09:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:09:56 --> Final output sent to browser
DEBUG - 2023-01-08 06:09:56 --> Total execution time: 0.2140
INFO - 2023-01-08 06:10:16 --> Config Class Initialized
INFO - 2023-01-08 06:10:16 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:10:16 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:10:16 --> Utf8 Class Initialized
INFO - 2023-01-08 06:10:16 --> URI Class Initialized
INFO - 2023-01-08 06:10:16 --> Router Class Initialized
INFO - 2023-01-08 06:10:16 --> Output Class Initialized
INFO - 2023-01-08 06:10:16 --> Security Class Initialized
DEBUG - 2023-01-08 06:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:10:16 --> Input Class Initialized
INFO - 2023-01-08 06:10:16 --> Language Class Initialized
INFO - 2023-01-08 06:10:16 --> Language Class Initialized
INFO - 2023-01-08 06:10:16 --> Config Class Initialized
INFO - 2023-01-08 06:10:16 --> Loader Class Initialized
INFO - 2023-01-08 06:10:16 --> Helper loaded: url_helper
INFO - 2023-01-08 06:10:16 --> Helper loaded: file_helper
INFO - 2023-01-08 06:10:16 --> Helper loaded: form_helper
INFO - 2023-01-08 06:10:16 --> Helper loaded: my_helper
INFO - 2023-01-08 06:10:16 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:10:16 --> Controller Class Initialized
ERROR - 2023-01-08 06:10:16 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:10:16 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:10:16 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
DEBUG - 2023-01-08 06:10:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:10:16 --> Final output sent to browser
DEBUG - 2023-01-08 06:10:16 --> Total execution time: 0.2464
INFO - 2023-01-08 06:10:28 --> Config Class Initialized
INFO - 2023-01-08 06:10:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:10:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:10:28 --> Utf8 Class Initialized
INFO - 2023-01-08 06:10:28 --> URI Class Initialized
INFO - 2023-01-08 06:10:28 --> Router Class Initialized
INFO - 2023-01-08 06:10:28 --> Output Class Initialized
INFO - 2023-01-08 06:10:28 --> Security Class Initialized
DEBUG - 2023-01-08 06:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:10:28 --> Input Class Initialized
INFO - 2023-01-08 06:10:28 --> Language Class Initialized
INFO - 2023-01-08 06:10:28 --> Language Class Initialized
INFO - 2023-01-08 06:10:28 --> Config Class Initialized
INFO - 2023-01-08 06:10:28 --> Loader Class Initialized
INFO - 2023-01-08 06:10:28 --> Helper loaded: url_helper
INFO - 2023-01-08 06:10:28 --> Helper loaded: file_helper
INFO - 2023-01-08 06:10:28 --> Helper loaded: form_helper
INFO - 2023-01-08 06:10:28 --> Helper loaded: my_helper
INFO - 2023-01-08 06:10:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:10:28 --> Controller Class Initialized
DEBUG - 2023-01-08 06:10:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:10:28 --> Final output sent to browser
DEBUG - 2023-01-08 06:10:28 --> Total execution time: 0.1996
INFO - 2023-01-08 06:11:35 --> Config Class Initialized
INFO - 2023-01-08 06:11:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:11:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:11:35 --> Utf8 Class Initialized
INFO - 2023-01-08 06:11:35 --> URI Class Initialized
INFO - 2023-01-08 06:11:35 --> Router Class Initialized
INFO - 2023-01-08 06:11:35 --> Output Class Initialized
INFO - 2023-01-08 06:11:35 --> Security Class Initialized
DEBUG - 2023-01-08 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:11:35 --> Input Class Initialized
INFO - 2023-01-08 06:11:35 --> Language Class Initialized
INFO - 2023-01-08 06:11:35 --> Language Class Initialized
INFO - 2023-01-08 06:11:35 --> Config Class Initialized
INFO - 2023-01-08 06:11:35 --> Loader Class Initialized
INFO - 2023-01-08 06:11:35 --> Helper loaded: url_helper
INFO - 2023-01-08 06:11:35 --> Helper loaded: file_helper
INFO - 2023-01-08 06:11:35 --> Helper loaded: form_helper
INFO - 2023-01-08 06:11:35 --> Helper loaded: my_helper
INFO - 2023-01-08 06:11:35 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:11:35 --> Controller Class Initialized
ERROR - 2023-01-08 06:11:35 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:11:35 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
ERROR - 2023-01-08 06:11:35 --> Severity: Warning --> implode(): Invalid arguments passed C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 174
DEBUG - 2023-01-08 06:11:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:11:35 --> Final output sent to browser
DEBUG - 2023-01-08 06:11:35 --> Total execution time: 0.2437
INFO - 2023-01-08 06:13:00 --> Config Class Initialized
INFO - 2023-01-08 06:13:00 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:13:00 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:13:00 --> Utf8 Class Initialized
INFO - 2023-01-08 06:13:00 --> URI Class Initialized
INFO - 2023-01-08 06:13:00 --> Router Class Initialized
INFO - 2023-01-08 06:13:00 --> Output Class Initialized
INFO - 2023-01-08 06:13:00 --> Security Class Initialized
DEBUG - 2023-01-08 06:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:13:00 --> Input Class Initialized
INFO - 2023-01-08 06:13:00 --> Language Class Initialized
INFO - 2023-01-08 06:13:00 --> Language Class Initialized
INFO - 2023-01-08 06:13:00 --> Config Class Initialized
INFO - 2023-01-08 06:13:00 --> Loader Class Initialized
INFO - 2023-01-08 06:13:00 --> Helper loaded: url_helper
INFO - 2023-01-08 06:13:00 --> Helper loaded: file_helper
INFO - 2023-01-08 06:13:00 --> Helper loaded: form_helper
INFO - 2023-01-08 06:13:00 --> Helper loaded: my_helper
INFO - 2023-01-08 06:13:00 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:13:00 --> Controller Class Initialized
DEBUG - 2023-01-08 06:13:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:13:00 --> Final output sent to browser
DEBUG - 2023-01-08 06:13:00 --> Total execution time: 0.2196
INFO - 2023-01-08 06:14:35 --> Config Class Initialized
INFO - 2023-01-08 06:14:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:14:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:14:35 --> Utf8 Class Initialized
INFO - 2023-01-08 06:14:35 --> URI Class Initialized
INFO - 2023-01-08 06:14:35 --> Router Class Initialized
INFO - 2023-01-08 06:14:35 --> Output Class Initialized
INFO - 2023-01-08 06:14:35 --> Security Class Initialized
DEBUG - 2023-01-08 06:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:14:35 --> Input Class Initialized
INFO - 2023-01-08 06:14:35 --> Language Class Initialized
INFO - 2023-01-08 06:14:35 --> Language Class Initialized
INFO - 2023-01-08 06:14:35 --> Config Class Initialized
INFO - 2023-01-08 06:14:35 --> Loader Class Initialized
INFO - 2023-01-08 06:14:35 --> Helper loaded: url_helper
INFO - 2023-01-08 06:14:35 --> Helper loaded: file_helper
INFO - 2023-01-08 06:14:35 --> Helper loaded: form_helper
INFO - 2023-01-08 06:14:35 --> Helper loaded: my_helper
INFO - 2023-01-08 06:14:35 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:14:35 --> Controller Class Initialized
DEBUG - 2023-01-08 06:14:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:14:36 --> Final output sent to browser
DEBUG - 2023-01-08 06:14:36 --> Total execution time: 0.2247
INFO - 2023-01-08 06:16:09 --> Config Class Initialized
INFO - 2023-01-08 06:16:09 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:16:09 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:16:09 --> Utf8 Class Initialized
INFO - 2023-01-08 06:16:09 --> URI Class Initialized
INFO - 2023-01-08 06:16:09 --> Router Class Initialized
INFO - 2023-01-08 06:16:09 --> Output Class Initialized
INFO - 2023-01-08 06:16:09 --> Security Class Initialized
DEBUG - 2023-01-08 06:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:16:09 --> Input Class Initialized
INFO - 2023-01-08 06:16:09 --> Language Class Initialized
INFO - 2023-01-08 06:16:09 --> Language Class Initialized
INFO - 2023-01-08 06:16:09 --> Config Class Initialized
INFO - 2023-01-08 06:16:09 --> Loader Class Initialized
INFO - 2023-01-08 06:16:09 --> Helper loaded: url_helper
INFO - 2023-01-08 06:16:09 --> Helper loaded: file_helper
INFO - 2023-01-08 06:16:09 --> Helper loaded: form_helper
INFO - 2023-01-08 06:16:09 --> Helper loaded: my_helper
INFO - 2023-01-08 06:16:09 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:16:09 --> Controller Class Initialized
DEBUG - 2023-01-08 06:16:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:16:09 --> Final output sent to browser
DEBUG - 2023-01-08 06:16:09 --> Total execution time: 0.2337
INFO - 2023-01-08 06:17:01 --> Config Class Initialized
INFO - 2023-01-08 06:17:01 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:17:01 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:17:01 --> Utf8 Class Initialized
INFO - 2023-01-08 06:17:01 --> URI Class Initialized
INFO - 2023-01-08 06:17:01 --> Router Class Initialized
INFO - 2023-01-08 06:17:01 --> Output Class Initialized
INFO - 2023-01-08 06:17:01 --> Security Class Initialized
DEBUG - 2023-01-08 06:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:17:01 --> Input Class Initialized
INFO - 2023-01-08 06:17:01 --> Language Class Initialized
INFO - 2023-01-08 06:17:01 --> Language Class Initialized
INFO - 2023-01-08 06:17:01 --> Config Class Initialized
INFO - 2023-01-08 06:17:01 --> Loader Class Initialized
INFO - 2023-01-08 06:17:01 --> Helper loaded: url_helper
INFO - 2023-01-08 06:17:01 --> Helper loaded: file_helper
INFO - 2023-01-08 06:17:01 --> Helper loaded: form_helper
INFO - 2023-01-08 06:17:01 --> Helper loaded: my_helper
INFO - 2023-01-08 06:17:01 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:17:01 --> Controller Class Initialized
DEBUG - 2023-01-08 06:17:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:17:01 --> Final output sent to browser
DEBUG - 2023-01-08 06:17:01 --> Total execution time: 0.2290
INFO - 2023-01-08 06:21:55 --> Config Class Initialized
INFO - 2023-01-08 06:21:55 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:21:55 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:21:55 --> Utf8 Class Initialized
INFO - 2023-01-08 06:21:55 --> URI Class Initialized
INFO - 2023-01-08 06:21:55 --> Router Class Initialized
INFO - 2023-01-08 06:21:55 --> Output Class Initialized
INFO - 2023-01-08 06:21:55 --> Security Class Initialized
DEBUG - 2023-01-08 06:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:21:55 --> Input Class Initialized
INFO - 2023-01-08 06:21:55 --> Language Class Initialized
INFO - 2023-01-08 06:21:56 --> Language Class Initialized
INFO - 2023-01-08 06:21:56 --> Config Class Initialized
INFO - 2023-01-08 06:21:56 --> Loader Class Initialized
INFO - 2023-01-08 06:21:56 --> Helper loaded: url_helper
INFO - 2023-01-08 06:21:56 --> Helper loaded: file_helper
INFO - 2023-01-08 06:21:56 --> Helper loaded: form_helper
INFO - 2023-01-08 06:21:56 --> Helper loaded: my_helper
INFO - 2023-01-08 06:21:56 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:21:56 --> Controller Class Initialized
DEBUG - 2023-01-08 06:21:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:21:56 --> Final output sent to browser
DEBUG - 2023-01-08 06:21:56 --> Total execution time: 0.1974
INFO - 2023-01-08 06:23:23 --> Config Class Initialized
INFO - 2023-01-08 06:23:23 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:23:23 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:23:23 --> Utf8 Class Initialized
INFO - 2023-01-08 06:23:23 --> URI Class Initialized
INFO - 2023-01-08 06:23:23 --> Router Class Initialized
INFO - 2023-01-08 06:23:23 --> Output Class Initialized
INFO - 2023-01-08 06:23:23 --> Security Class Initialized
DEBUG - 2023-01-08 06:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:23:23 --> Input Class Initialized
INFO - 2023-01-08 06:23:23 --> Language Class Initialized
INFO - 2023-01-08 06:23:23 --> Language Class Initialized
INFO - 2023-01-08 06:23:23 --> Config Class Initialized
INFO - 2023-01-08 06:23:23 --> Loader Class Initialized
INFO - 2023-01-08 06:23:23 --> Helper loaded: url_helper
INFO - 2023-01-08 06:23:23 --> Helper loaded: file_helper
INFO - 2023-01-08 06:23:23 --> Helper loaded: form_helper
INFO - 2023-01-08 06:23:23 --> Helper loaded: my_helper
INFO - 2023-01-08 06:23:23 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:23:23 --> Controller Class Initialized
DEBUG - 2023-01-08 06:23:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:23:23 --> Final output sent to browser
DEBUG - 2023-01-08 06:23:23 --> Total execution time: 0.2252
INFO - 2023-01-08 06:25:26 --> Config Class Initialized
INFO - 2023-01-08 06:25:26 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:25:26 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:25:26 --> Utf8 Class Initialized
INFO - 2023-01-08 06:25:26 --> URI Class Initialized
INFO - 2023-01-08 06:25:26 --> Router Class Initialized
INFO - 2023-01-08 06:25:26 --> Output Class Initialized
INFO - 2023-01-08 06:25:26 --> Security Class Initialized
DEBUG - 2023-01-08 06:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:25:26 --> Input Class Initialized
INFO - 2023-01-08 06:25:26 --> Language Class Initialized
INFO - 2023-01-08 06:25:26 --> Language Class Initialized
INFO - 2023-01-08 06:25:26 --> Config Class Initialized
INFO - 2023-01-08 06:25:26 --> Loader Class Initialized
INFO - 2023-01-08 06:25:26 --> Helper loaded: url_helper
INFO - 2023-01-08 06:25:26 --> Helper loaded: file_helper
INFO - 2023-01-08 06:25:26 --> Helper loaded: form_helper
INFO - 2023-01-08 06:25:26 --> Helper loaded: my_helper
INFO - 2023-01-08 06:25:26 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:25:26 --> Controller Class Initialized
DEBUG - 2023-01-08 06:25:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:25:26 --> Final output sent to browser
DEBUG - 2023-01-08 06:25:26 --> Total execution time: 0.2256
INFO - 2023-01-08 06:28:36 --> Config Class Initialized
INFO - 2023-01-08 06:28:36 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:28:36 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:28:36 --> Utf8 Class Initialized
INFO - 2023-01-08 06:28:36 --> URI Class Initialized
INFO - 2023-01-08 06:28:36 --> Router Class Initialized
INFO - 2023-01-08 06:28:36 --> Output Class Initialized
INFO - 2023-01-08 06:28:36 --> Security Class Initialized
DEBUG - 2023-01-08 06:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:28:36 --> Input Class Initialized
INFO - 2023-01-08 06:28:36 --> Language Class Initialized
INFO - 2023-01-08 06:28:36 --> Language Class Initialized
INFO - 2023-01-08 06:28:36 --> Config Class Initialized
INFO - 2023-01-08 06:28:36 --> Loader Class Initialized
INFO - 2023-01-08 06:28:36 --> Helper loaded: url_helper
INFO - 2023-01-08 06:28:36 --> Helper loaded: file_helper
INFO - 2023-01-08 06:28:36 --> Helper loaded: form_helper
INFO - 2023-01-08 06:28:36 --> Helper loaded: my_helper
INFO - 2023-01-08 06:28:36 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:28:36 --> Controller Class Initialized
DEBUG - 2023-01-08 06:28:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:28:36 --> Final output sent to browser
DEBUG - 2023-01-08 06:28:36 --> Total execution time: 0.1934
INFO - 2023-01-08 06:30:29 --> Config Class Initialized
INFO - 2023-01-08 06:30:29 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:30:29 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:30:29 --> Utf8 Class Initialized
INFO - 2023-01-08 06:30:29 --> URI Class Initialized
INFO - 2023-01-08 06:30:29 --> Router Class Initialized
INFO - 2023-01-08 06:30:29 --> Output Class Initialized
INFO - 2023-01-08 06:30:29 --> Security Class Initialized
DEBUG - 2023-01-08 06:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:30:29 --> Input Class Initialized
INFO - 2023-01-08 06:30:29 --> Language Class Initialized
INFO - 2023-01-08 06:30:29 --> Language Class Initialized
INFO - 2023-01-08 06:30:29 --> Config Class Initialized
INFO - 2023-01-08 06:30:29 --> Loader Class Initialized
INFO - 2023-01-08 06:30:29 --> Helper loaded: url_helper
INFO - 2023-01-08 06:30:29 --> Helper loaded: file_helper
INFO - 2023-01-08 06:30:29 --> Helper loaded: form_helper
INFO - 2023-01-08 06:30:29 --> Helper loaded: my_helper
INFO - 2023-01-08 06:30:29 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:30:29 --> Controller Class Initialized
DEBUG - 2023-01-08 06:30:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:30:30 --> Final output sent to browser
DEBUG - 2023-01-08 06:30:30 --> Total execution time: 0.1968
INFO - 2023-01-08 06:34:03 --> Config Class Initialized
INFO - 2023-01-08 06:34:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:34:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:34:03 --> Utf8 Class Initialized
INFO - 2023-01-08 06:34:03 --> URI Class Initialized
INFO - 2023-01-08 06:34:03 --> Router Class Initialized
INFO - 2023-01-08 06:34:03 --> Output Class Initialized
INFO - 2023-01-08 06:34:03 --> Security Class Initialized
DEBUG - 2023-01-08 06:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:34:03 --> Input Class Initialized
INFO - 2023-01-08 06:34:03 --> Language Class Initialized
INFO - 2023-01-08 06:34:03 --> Language Class Initialized
INFO - 2023-01-08 06:34:03 --> Config Class Initialized
INFO - 2023-01-08 06:34:03 --> Loader Class Initialized
INFO - 2023-01-08 06:34:03 --> Helper loaded: url_helper
INFO - 2023-01-08 06:34:03 --> Helper loaded: file_helper
INFO - 2023-01-08 06:34:03 --> Helper loaded: form_helper
INFO - 2023-01-08 06:34:03 --> Helper loaded: my_helper
INFO - 2023-01-08 06:34:03 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:34:03 --> Controller Class Initialized
DEBUG - 2023-01-08 06:34:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:34:03 --> Final output sent to browser
DEBUG - 2023-01-08 06:34:03 --> Total execution time: 0.2148
INFO - 2023-01-08 06:36:58 --> Config Class Initialized
INFO - 2023-01-08 06:36:58 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:36:58 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:36:58 --> Utf8 Class Initialized
INFO - 2023-01-08 06:36:58 --> URI Class Initialized
INFO - 2023-01-08 06:36:58 --> Router Class Initialized
INFO - 2023-01-08 06:36:58 --> Output Class Initialized
INFO - 2023-01-08 06:36:58 --> Security Class Initialized
DEBUG - 2023-01-08 06:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:36:58 --> Input Class Initialized
INFO - 2023-01-08 06:36:58 --> Language Class Initialized
INFO - 2023-01-08 06:36:58 --> Language Class Initialized
INFO - 2023-01-08 06:36:58 --> Config Class Initialized
INFO - 2023-01-08 06:36:58 --> Loader Class Initialized
INFO - 2023-01-08 06:36:58 --> Helper loaded: url_helper
INFO - 2023-01-08 06:36:58 --> Helper loaded: file_helper
INFO - 2023-01-08 06:36:58 --> Helper loaded: form_helper
INFO - 2023-01-08 06:36:58 --> Helper loaded: my_helper
INFO - 2023-01-08 06:36:58 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:36:58 --> Controller Class Initialized
ERROR - 2023-01-08 06:36:58 --> Severity: Warning --> array_push() expects parameter 1 to be array, null given C:\xampp\htdocs\myraportk13\application\modules\cetak_raport\controllers\Cetak_raport.php 166
DEBUG - 2023-01-08 06:36:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:36:58 --> Final output sent to browser
DEBUG - 2023-01-08 06:36:58 --> Total execution time: 0.2275
INFO - 2023-01-08 06:43:08 --> Config Class Initialized
INFO - 2023-01-08 06:43:08 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:43:08 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:43:08 --> Utf8 Class Initialized
INFO - 2023-01-08 06:43:08 --> URI Class Initialized
INFO - 2023-01-08 06:43:08 --> Router Class Initialized
INFO - 2023-01-08 06:43:08 --> Output Class Initialized
INFO - 2023-01-08 06:43:08 --> Security Class Initialized
DEBUG - 2023-01-08 06:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:43:08 --> Input Class Initialized
INFO - 2023-01-08 06:43:08 --> Language Class Initialized
INFO - 2023-01-08 06:43:08 --> Language Class Initialized
INFO - 2023-01-08 06:43:08 --> Config Class Initialized
INFO - 2023-01-08 06:43:08 --> Loader Class Initialized
INFO - 2023-01-08 06:43:08 --> Helper loaded: url_helper
INFO - 2023-01-08 06:43:08 --> Helper loaded: file_helper
INFO - 2023-01-08 06:43:08 --> Helper loaded: form_helper
INFO - 2023-01-08 06:43:08 --> Helper loaded: my_helper
INFO - 2023-01-08 06:43:08 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:43:08 --> Controller Class Initialized
DEBUG - 2023-01-08 06:43:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:43:08 --> Final output sent to browser
DEBUG - 2023-01-08 06:43:08 --> Total execution time: 0.1890
INFO - 2023-01-08 06:44:16 --> Config Class Initialized
INFO - 2023-01-08 06:44:16 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:44:16 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:44:16 --> Utf8 Class Initialized
INFO - 2023-01-08 06:44:16 --> URI Class Initialized
INFO - 2023-01-08 06:44:16 --> Router Class Initialized
INFO - 2023-01-08 06:44:16 --> Output Class Initialized
INFO - 2023-01-08 06:44:16 --> Security Class Initialized
DEBUG - 2023-01-08 06:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:44:16 --> Input Class Initialized
INFO - 2023-01-08 06:44:16 --> Language Class Initialized
INFO - 2023-01-08 06:44:16 --> Language Class Initialized
INFO - 2023-01-08 06:44:16 --> Config Class Initialized
INFO - 2023-01-08 06:44:16 --> Loader Class Initialized
INFO - 2023-01-08 06:44:16 --> Helper loaded: url_helper
INFO - 2023-01-08 06:44:16 --> Helper loaded: file_helper
INFO - 2023-01-08 06:44:16 --> Helper loaded: form_helper
INFO - 2023-01-08 06:44:16 --> Helper loaded: my_helper
INFO - 2023-01-08 06:44:16 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:44:16 --> Controller Class Initialized
DEBUG - 2023-01-08 06:44:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:44:16 --> Final output sent to browser
DEBUG - 2023-01-08 06:44:16 --> Total execution time: 0.1640
INFO - 2023-01-08 06:45:47 --> Config Class Initialized
INFO - 2023-01-08 06:45:47 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:45:47 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:45:47 --> Utf8 Class Initialized
INFO - 2023-01-08 06:45:47 --> URI Class Initialized
INFO - 2023-01-08 06:45:47 --> Router Class Initialized
INFO - 2023-01-08 06:45:47 --> Output Class Initialized
INFO - 2023-01-08 06:45:47 --> Security Class Initialized
DEBUG - 2023-01-08 06:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:45:47 --> Input Class Initialized
INFO - 2023-01-08 06:45:47 --> Language Class Initialized
INFO - 2023-01-08 06:45:47 --> Language Class Initialized
INFO - 2023-01-08 06:45:47 --> Config Class Initialized
INFO - 2023-01-08 06:45:47 --> Loader Class Initialized
INFO - 2023-01-08 06:45:47 --> Helper loaded: url_helper
INFO - 2023-01-08 06:45:47 --> Helper loaded: file_helper
INFO - 2023-01-08 06:45:47 --> Helper loaded: form_helper
INFO - 2023-01-08 06:45:47 --> Helper loaded: my_helper
INFO - 2023-01-08 06:45:47 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:45:47 --> Controller Class Initialized
DEBUG - 2023-01-08 06:45:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:45:47 --> Final output sent to browser
DEBUG - 2023-01-08 06:45:47 --> Total execution time: 0.1527
INFO - 2023-01-08 06:46:20 --> Config Class Initialized
INFO - 2023-01-08 06:46:20 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:46:20 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:46:20 --> Utf8 Class Initialized
INFO - 2023-01-08 06:46:20 --> URI Class Initialized
INFO - 2023-01-08 06:46:20 --> Router Class Initialized
INFO - 2023-01-08 06:46:20 --> Output Class Initialized
INFO - 2023-01-08 06:46:20 --> Security Class Initialized
DEBUG - 2023-01-08 06:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:46:20 --> Input Class Initialized
INFO - 2023-01-08 06:46:20 --> Language Class Initialized
INFO - 2023-01-08 06:46:20 --> Language Class Initialized
INFO - 2023-01-08 06:46:20 --> Config Class Initialized
INFO - 2023-01-08 06:46:20 --> Loader Class Initialized
INFO - 2023-01-08 06:46:20 --> Helper loaded: url_helper
INFO - 2023-01-08 06:46:20 --> Helper loaded: file_helper
INFO - 2023-01-08 06:46:20 --> Helper loaded: form_helper
INFO - 2023-01-08 06:46:20 --> Helper loaded: my_helper
INFO - 2023-01-08 06:46:20 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:46:20 --> Controller Class Initialized
DEBUG - 2023-01-08 06:46:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:46:20 --> Final output sent to browser
DEBUG - 2023-01-08 06:46:20 --> Total execution time: 0.1620
INFO - 2023-01-08 06:47:04 --> Config Class Initialized
INFO - 2023-01-08 06:47:04 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:47:04 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:47:04 --> Utf8 Class Initialized
INFO - 2023-01-08 06:47:04 --> URI Class Initialized
INFO - 2023-01-08 06:47:04 --> Router Class Initialized
INFO - 2023-01-08 06:47:04 --> Output Class Initialized
INFO - 2023-01-08 06:47:04 --> Security Class Initialized
DEBUG - 2023-01-08 06:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:47:04 --> Input Class Initialized
INFO - 2023-01-08 06:47:04 --> Language Class Initialized
INFO - 2023-01-08 06:47:04 --> Language Class Initialized
INFO - 2023-01-08 06:47:04 --> Config Class Initialized
INFO - 2023-01-08 06:47:04 --> Loader Class Initialized
INFO - 2023-01-08 06:47:04 --> Helper loaded: url_helper
INFO - 2023-01-08 06:47:04 --> Helper loaded: file_helper
INFO - 2023-01-08 06:47:04 --> Helper loaded: form_helper
INFO - 2023-01-08 06:47:04 --> Helper loaded: my_helper
INFO - 2023-01-08 06:47:04 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:47:04 --> Controller Class Initialized
DEBUG - 2023-01-08 06:47:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:47:04 --> Final output sent to browser
DEBUG - 2023-01-08 06:47:04 --> Total execution time: 0.1488
INFO - 2023-01-08 06:49:16 --> Config Class Initialized
INFO - 2023-01-08 06:49:16 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:49:16 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:49:16 --> Utf8 Class Initialized
INFO - 2023-01-08 06:49:16 --> URI Class Initialized
INFO - 2023-01-08 06:49:16 --> Router Class Initialized
INFO - 2023-01-08 06:49:16 --> Output Class Initialized
INFO - 2023-01-08 06:49:16 --> Security Class Initialized
DEBUG - 2023-01-08 06:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:49:16 --> Input Class Initialized
INFO - 2023-01-08 06:49:16 --> Language Class Initialized
INFO - 2023-01-08 06:49:16 --> Language Class Initialized
INFO - 2023-01-08 06:49:16 --> Config Class Initialized
INFO - 2023-01-08 06:49:16 --> Loader Class Initialized
INFO - 2023-01-08 06:49:16 --> Helper loaded: url_helper
INFO - 2023-01-08 06:49:16 --> Helper loaded: file_helper
INFO - 2023-01-08 06:49:16 --> Helper loaded: form_helper
INFO - 2023-01-08 06:49:16 --> Helper loaded: my_helper
INFO - 2023-01-08 06:49:16 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:49:16 --> Controller Class Initialized
DEBUG - 2023-01-08 06:49:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:49:16 --> Final output sent to browser
DEBUG - 2023-01-08 06:49:16 --> Total execution time: 0.1845
INFO - 2023-01-08 06:50:04 --> Config Class Initialized
INFO - 2023-01-08 06:50:04 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:50:04 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:50:04 --> Utf8 Class Initialized
INFO - 2023-01-08 06:50:04 --> URI Class Initialized
INFO - 2023-01-08 06:50:04 --> Router Class Initialized
INFO - 2023-01-08 06:50:04 --> Output Class Initialized
INFO - 2023-01-08 06:50:04 --> Security Class Initialized
DEBUG - 2023-01-08 06:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:50:04 --> Input Class Initialized
INFO - 2023-01-08 06:50:04 --> Language Class Initialized
INFO - 2023-01-08 06:50:04 --> Language Class Initialized
INFO - 2023-01-08 06:50:04 --> Config Class Initialized
INFO - 2023-01-08 06:50:04 --> Loader Class Initialized
INFO - 2023-01-08 06:50:04 --> Helper loaded: url_helper
INFO - 2023-01-08 06:50:04 --> Helper loaded: file_helper
INFO - 2023-01-08 06:50:04 --> Helper loaded: form_helper
INFO - 2023-01-08 06:50:04 --> Helper loaded: my_helper
INFO - 2023-01-08 06:50:04 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:50:04 --> Controller Class Initialized
DEBUG - 2023-01-08 06:50:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:50:04 --> Final output sent to browser
DEBUG - 2023-01-08 06:50:04 --> Total execution time: 0.1600
INFO - 2023-01-08 06:51:08 --> Config Class Initialized
INFO - 2023-01-08 06:51:08 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:51:08 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:51:08 --> Utf8 Class Initialized
INFO - 2023-01-08 06:51:08 --> URI Class Initialized
INFO - 2023-01-08 06:51:08 --> Router Class Initialized
INFO - 2023-01-08 06:51:08 --> Output Class Initialized
INFO - 2023-01-08 06:51:08 --> Security Class Initialized
DEBUG - 2023-01-08 06:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:51:08 --> Input Class Initialized
INFO - 2023-01-08 06:51:08 --> Language Class Initialized
INFO - 2023-01-08 06:51:08 --> Language Class Initialized
INFO - 2023-01-08 06:51:08 --> Config Class Initialized
INFO - 2023-01-08 06:51:08 --> Loader Class Initialized
INFO - 2023-01-08 06:51:08 --> Helper loaded: url_helper
INFO - 2023-01-08 06:51:08 --> Helper loaded: file_helper
INFO - 2023-01-08 06:51:08 --> Helper loaded: form_helper
INFO - 2023-01-08 06:51:08 --> Helper loaded: my_helper
INFO - 2023-01-08 06:51:08 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:51:08 --> Controller Class Initialized
DEBUG - 2023-01-08 06:51:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:51:09 --> Final output sent to browser
DEBUG - 2023-01-08 06:51:09 --> Total execution time: 1.2400
INFO - 2023-01-08 06:52:02 --> Config Class Initialized
INFO - 2023-01-08 06:52:02 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:52:02 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:52:02 --> Utf8 Class Initialized
INFO - 2023-01-08 06:52:02 --> URI Class Initialized
INFO - 2023-01-08 06:52:02 --> Router Class Initialized
INFO - 2023-01-08 06:52:02 --> Output Class Initialized
INFO - 2023-01-08 06:52:02 --> Security Class Initialized
DEBUG - 2023-01-08 06:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:52:02 --> Input Class Initialized
INFO - 2023-01-08 06:52:02 --> Language Class Initialized
INFO - 2023-01-08 06:52:02 --> Language Class Initialized
INFO - 2023-01-08 06:52:02 --> Config Class Initialized
INFO - 2023-01-08 06:52:02 --> Loader Class Initialized
INFO - 2023-01-08 06:52:02 --> Helper loaded: url_helper
INFO - 2023-01-08 06:52:02 --> Helper loaded: file_helper
INFO - 2023-01-08 06:52:02 --> Helper loaded: form_helper
INFO - 2023-01-08 06:52:02 --> Helper loaded: my_helper
INFO - 2023-01-08 06:52:02 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:52:02 --> Controller Class Initialized
DEBUG - 2023-01-08 06:52:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:52:02 --> Final output sent to browser
DEBUG - 2023-01-08 06:52:02 --> Total execution time: 0.1465
INFO - 2023-01-08 06:53:21 --> Config Class Initialized
INFO - 2023-01-08 06:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:53:21 --> Utf8 Class Initialized
INFO - 2023-01-08 06:53:21 --> URI Class Initialized
INFO - 2023-01-08 06:53:21 --> Router Class Initialized
INFO - 2023-01-08 06:53:21 --> Output Class Initialized
INFO - 2023-01-08 06:53:21 --> Security Class Initialized
DEBUG - 2023-01-08 06:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:53:21 --> Input Class Initialized
INFO - 2023-01-08 06:53:21 --> Language Class Initialized
INFO - 2023-01-08 06:53:21 --> Language Class Initialized
INFO - 2023-01-08 06:53:21 --> Config Class Initialized
INFO - 2023-01-08 06:53:21 --> Loader Class Initialized
INFO - 2023-01-08 06:53:21 --> Helper loaded: url_helper
INFO - 2023-01-08 06:53:21 --> Helper loaded: file_helper
INFO - 2023-01-08 06:53:21 --> Helper loaded: form_helper
INFO - 2023-01-08 06:53:21 --> Helper loaded: my_helper
INFO - 2023-01-08 06:53:21 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:53:21 --> Controller Class Initialized
DEBUG - 2023-01-08 06:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:53:21 --> Final output sent to browser
DEBUG - 2023-01-08 06:53:21 --> Total execution time: 0.1686
INFO - 2023-01-08 06:53:38 --> Config Class Initialized
INFO - 2023-01-08 06:53:38 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:53:38 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:53:38 --> Utf8 Class Initialized
INFO - 2023-01-08 06:53:38 --> URI Class Initialized
INFO - 2023-01-08 06:53:38 --> Router Class Initialized
INFO - 2023-01-08 06:53:38 --> Output Class Initialized
INFO - 2023-01-08 06:53:38 --> Security Class Initialized
DEBUG - 2023-01-08 06:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:53:38 --> Input Class Initialized
INFO - 2023-01-08 06:53:38 --> Language Class Initialized
INFO - 2023-01-08 06:53:38 --> Language Class Initialized
INFO - 2023-01-08 06:53:38 --> Config Class Initialized
INFO - 2023-01-08 06:53:38 --> Loader Class Initialized
INFO - 2023-01-08 06:53:38 --> Helper loaded: url_helper
INFO - 2023-01-08 06:53:38 --> Helper loaded: file_helper
INFO - 2023-01-08 06:53:38 --> Helper loaded: form_helper
INFO - 2023-01-08 06:53:38 --> Helper loaded: my_helper
INFO - 2023-01-08 06:53:38 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:53:38 --> Controller Class Initialized
DEBUG - 2023-01-08 06:53:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:53:38 --> Final output sent to browser
DEBUG - 2023-01-08 06:53:38 --> Total execution time: 0.1504
INFO - 2023-01-08 06:55:22 --> Config Class Initialized
INFO - 2023-01-08 06:55:22 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:55:22 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:55:22 --> Utf8 Class Initialized
INFO - 2023-01-08 06:55:22 --> URI Class Initialized
INFO - 2023-01-08 06:55:22 --> Router Class Initialized
INFO - 2023-01-08 06:55:22 --> Output Class Initialized
INFO - 2023-01-08 06:55:22 --> Security Class Initialized
DEBUG - 2023-01-08 06:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:55:22 --> Input Class Initialized
INFO - 2023-01-08 06:55:22 --> Language Class Initialized
INFO - 2023-01-08 06:55:22 --> Language Class Initialized
INFO - 2023-01-08 06:55:22 --> Config Class Initialized
INFO - 2023-01-08 06:55:22 --> Loader Class Initialized
INFO - 2023-01-08 06:55:22 --> Helper loaded: url_helper
INFO - 2023-01-08 06:55:22 --> Helper loaded: file_helper
INFO - 2023-01-08 06:55:22 --> Helper loaded: form_helper
INFO - 2023-01-08 06:55:22 --> Helper loaded: my_helper
INFO - 2023-01-08 06:55:22 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:55:22 --> Controller Class Initialized
DEBUG - 2023-01-08 06:55:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:55:22 --> Final output sent to browser
DEBUG - 2023-01-08 06:55:22 --> Total execution time: 0.1711
INFO - 2023-01-08 06:56:33 --> Config Class Initialized
INFO - 2023-01-08 06:56:33 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:56:33 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:56:33 --> Utf8 Class Initialized
INFO - 2023-01-08 06:56:33 --> URI Class Initialized
INFO - 2023-01-08 06:56:33 --> Router Class Initialized
INFO - 2023-01-08 06:56:33 --> Output Class Initialized
INFO - 2023-01-08 06:56:33 --> Security Class Initialized
DEBUG - 2023-01-08 06:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:56:33 --> Input Class Initialized
INFO - 2023-01-08 06:56:33 --> Language Class Initialized
INFO - 2023-01-08 06:56:33 --> Language Class Initialized
INFO - 2023-01-08 06:56:33 --> Config Class Initialized
INFO - 2023-01-08 06:56:33 --> Loader Class Initialized
INFO - 2023-01-08 06:56:33 --> Helper loaded: url_helper
INFO - 2023-01-08 06:56:33 --> Helper loaded: file_helper
INFO - 2023-01-08 06:56:33 --> Helper loaded: form_helper
INFO - 2023-01-08 06:56:33 --> Helper loaded: my_helper
INFO - 2023-01-08 06:56:33 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:56:33 --> Controller Class Initialized
DEBUG - 2023-01-08 06:56:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:56:33 --> Final output sent to browser
DEBUG - 2023-01-08 06:56:33 --> Total execution time: 0.1652
INFO - 2023-01-08 06:58:03 --> Config Class Initialized
INFO - 2023-01-08 06:58:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:58:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:58:03 --> Utf8 Class Initialized
INFO - 2023-01-08 06:58:03 --> URI Class Initialized
INFO - 2023-01-08 06:58:03 --> Router Class Initialized
INFO - 2023-01-08 06:58:03 --> Output Class Initialized
INFO - 2023-01-08 06:58:03 --> Security Class Initialized
DEBUG - 2023-01-08 06:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:58:03 --> Input Class Initialized
INFO - 2023-01-08 06:58:03 --> Language Class Initialized
INFO - 2023-01-08 06:58:03 --> Language Class Initialized
INFO - 2023-01-08 06:58:03 --> Config Class Initialized
INFO - 2023-01-08 06:58:03 --> Loader Class Initialized
INFO - 2023-01-08 06:58:03 --> Helper loaded: url_helper
INFO - 2023-01-08 06:58:03 --> Helper loaded: file_helper
INFO - 2023-01-08 06:58:03 --> Helper loaded: form_helper
INFO - 2023-01-08 06:58:03 --> Helper loaded: my_helper
INFO - 2023-01-08 06:58:03 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:58:03 --> Controller Class Initialized
DEBUG - 2023-01-08 06:58:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:58:03 --> Final output sent to browser
DEBUG - 2023-01-08 06:58:03 --> Total execution time: 0.1428
INFO - 2023-01-08 06:58:57 --> Config Class Initialized
INFO - 2023-01-08 06:58:57 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:58:57 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:58:57 --> Utf8 Class Initialized
INFO - 2023-01-08 06:58:57 --> URI Class Initialized
INFO - 2023-01-08 06:58:57 --> Router Class Initialized
INFO - 2023-01-08 06:58:57 --> Output Class Initialized
INFO - 2023-01-08 06:58:57 --> Security Class Initialized
DEBUG - 2023-01-08 06:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:58:57 --> Input Class Initialized
INFO - 2023-01-08 06:58:57 --> Language Class Initialized
INFO - 2023-01-08 06:58:57 --> Language Class Initialized
INFO - 2023-01-08 06:58:57 --> Config Class Initialized
INFO - 2023-01-08 06:58:57 --> Loader Class Initialized
INFO - 2023-01-08 06:58:57 --> Helper loaded: url_helper
INFO - 2023-01-08 06:58:57 --> Helper loaded: file_helper
INFO - 2023-01-08 06:58:57 --> Helper loaded: form_helper
INFO - 2023-01-08 06:58:57 --> Helper loaded: my_helper
INFO - 2023-01-08 06:58:57 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:58:57 --> Controller Class Initialized
DEBUG - 2023-01-08 06:58:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 06:58:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 06:58:57 --> Final output sent to browser
DEBUG - 2023-01-08 06:58:57 --> Total execution time: 0.1068
INFO - 2023-01-08 06:59:01 --> Config Class Initialized
INFO - 2023-01-08 06:59:01 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:59:01 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:59:01 --> Utf8 Class Initialized
INFO - 2023-01-08 06:59:01 --> URI Class Initialized
INFO - 2023-01-08 06:59:01 --> Router Class Initialized
INFO - 2023-01-08 06:59:01 --> Output Class Initialized
INFO - 2023-01-08 06:59:01 --> Security Class Initialized
DEBUG - 2023-01-08 06:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:59:01 --> Input Class Initialized
INFO - 2023-01-08 06:59:01 --> Language Class Initialized
INFO - 2023-01-08 06:59:01 --> Language Class Initialized
INFO - 2023-01-08 06:59:01 --> Config Class Initialized
INFO - 2023-01-08 06:59:01 --> Loader Class Initialized
INFO - 2023-01-08 06:59:01 --> Helper loaded: url_helper
INFO - 2023-01-08 06:59:01 --> Helper loaded: file_helper
INFO - 2023-01-08 06:59:01 --> Helper loaded: form_helper
INFO - 2023-01-08 06:59:01 --> Helper loaded: my_helper
INFO - 2023-01-08 06:59:01 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:59:01 --> Controller Class Initialized
INFO - 2023-01-08 06:59:02 --> Config Class Initialized
INFO - 2023-01-08 06:59:02 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:59:02 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:59:02 --> Utf8 Class Initialized
INFO - 2023-01-08 06:59:02 --> URI Class Initialized
INFO - 2023-01-08 06:59:02 --> Router Class Initialized
INFO - 2023-01-08 06:59:02 --> Output Class Initialized
INFO - 2023-01-08 06:59:02 --> Security Class Initialized
DEBUG - 2023-01-08 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:59:02 --> Input Class Initialized
INFO - 2023-01-08 06:59:02 --> Language Class Initialized
INFO - 2023-01-08 06:59:02 --> Language Class Initialized
INFO - 2023-01-08 06:59:02 --> Config Class Initialized
INFO - 2023-01-08 06:59:02 --> Loader Class Initialized
INFO - 2023-01-08 06:59:02 --> Helper loaded: url_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: file_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: form_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: my_helper
INFO - 2023-01-08 06:59:02 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:59:02 --> Controller Class Initialized
DEBUG - 2023-01-08 06:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 06:59:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 06:59:02 --> Final output sent to browser
DEBUG - 2023-01-08 06:59:02 --> Total execution time: 0.0541
INFO - 2023-01-08 06:59:02 --> Config Class Initialized
INFO - 2023-01-08 06:59:02 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:59:02 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:59:02 --> Utf8 Class Initialized
INFO - 2023-01-08 06:59:02 --> URI Class Initialized
INFO - 2023-01-08 06:59:02 --> Router Class Initialized
INFO - 2023-01-08 06:59:02 --> Output Class Initialized
INFO - 2023-01-08 06:59:02 --> Security Class Initialized
DEBUG - 2023-01-08 06:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:59:02 --> Input Class Initialized
INFO - 2023-01-08 06:59:02 --> Language Class Initialized
INFO - 2023-01-08 06:59:02 --> Language Class Initialized
INFO - 2023-01-08 06:59:02 --> Config Class Initialized
INFO - 2023-01-08 06:59:02 --> Loader Class Initialized
INFO - 2023-01-08 06:59:02 --> Helper loaded: url_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: file_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: form_helper
INFO - 2023-01-08 06:59:02 --> Helper loaded: my_helper
INFO - 2023-01-08 06:59:02 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:59:02 --> Controller Class Initialized
INFO - 2023-01-08 06:59:04 --> Config Class Initialized
INFO - 2023-01-08 06:59:04 --> Hooks Class Initialized
DEBUG - 2023-01-08 06:59:04 --> UTF-8 Support Enabled
INFO - 2023-01-08 06:59:04 --> Utf8 Class Initialized
INFO - 2023-01-08 06:59:04 --> URI Class Initialized
INFO - 2023-01-08 06:59:04 --> Router Class Initialized
INFO - 2023-01-08 06:59:04 --> Output Class Initialized
INFO - 2023-01-08 06:59:04 --> Security Class Initialized
DEBUG - 2023-01-08 06:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 06:59:04 --> Input Class Initialized
INFO - 2023-01-08 06:59:04 --> Language Class Initialized
INFO - 2023-01-08 06:59:04 --> Language Class Initialized
INFO - 2023-01-08 06:59:04 --> Config Class Initialized
INFO - 2023-01-08 06:59:04 --> Loader Class Initialized
INFO - 2023-01-08 06:59:04 --> Helper loaded: url_helper
INFO - 2023-01-08 06:59:04 --> Helper loaded: file_helper
INFO - 2023-01-08 06:59:04 --> Helper loaded: form_helper
INFO - 2023-01-08 06:59:04 --> Helper loaded: my_helper
INFO - 2023-01-08 06:59:04 --> Database Driver Class Initialized
DEBUG - 2023-01-08 06:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 06:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 06:59:04 --> Controller Class Initialized
DEBUG - 2023-01-08 06:59:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 06:59:04 --> Final output sent to browser
DEBUG - 2023-01-08 06:59:04 --> Total execution time: 0.1506
INFO - 2023-01-08 07:01:18 --> Config Class Initialized
INFO - 2023-01-08 07:01:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:01:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:01:18 --> Utf8 Class Initialized
INFO - 2023-01-08 07:01:18 --> URI Class Initialized
INFO - 2023-01-08 07:01:18 --> Router Class Initialized
INFO - 2023-01-08 07:01:18 --> Output Class Initialized
INFO - 2023-01-08 07:01:18 --> Security Class Initialized
DEBUG - 2023-01-08 07:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:01:18 --> Input Class Initialized
INFO - 2023-01-08 07:01:18 --> Language Class Initialized
INFO - 2023-01-08 07:01:18 --> Language Class Initialized
INFO - 2023-01-08 07:01:18 --> Config Class Initialized
INFO - 2023-01-08 07:01:18 --> Loader Class Initialized
INFO - 2023-01-08 07:01:18 --> Helper loaded: url_helper
INFO - 2023-01-08 07:01:18 --> Helper loaded: file_helper
INFO - 2023-01-08 07:01:18 --> Helper loaded: form_helper
INFO - 2023-01-08 07:01:18 --> Helper loaded: my_helper
INFO - 2023-01-08 07:01:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:01:18 --> Controller Class Initialized
DEBUG - 2023-01-08 07:01:18 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 07:01:18 --> Final output sent to browser
DEBUG - 2023-01-08 07:01:18 --> Total execution time: 0.1728
INFO - 2023-01-08 07:03:43 --> Config Class Initialized
INFO - 2023-01-08 07:03:43 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:03:43 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:03:43 --> Utf8 Class Initialized
INFO - 2023-01-08 07:03:43 --> URI Class Initialized
INFO - 2023-01-08 07:03:43 --> Router Class Initialized
INFO - 2023-01-08 07:03:43 --> Output Class Initialized
INFO - 2023-01-08 07:03:43 --> Security Class Initialized
DEBUG - 2023-01-08 07:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:03:43 --> Input Class Initialized
INFO - 2023-01-08 07:03:43 --> Language Class Initialized
INFO - 2023-01-08 07:03:43 --> Language Class Initialized
INFO - 2023-01-08 07:03:43 --> Config Class Initialized
INFO - 2023-01-08 07:03:43 --> Loader Class Initialized
INFO - 2023-01-08 07:03:43 --> Helper loaded: url_helper
INFO - 2023-01-08 07:03:43 --> Helper loaded: file_helper
INFO - 2023-01-08 07:03:43 --> Helper loaded: form_helper
INFO - 2023-01-08 07:03:43 --> Helper loaded: my_helper
INFO - 2023-01-08 07:03:43 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:03:43 --> Controller Class Initialized
DEBUG - 2023-01-08 07:03:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 07:03:43 --> Final output sent to browser
DEBUG - 2023-01-08 07:03:43 --> Total execution time: 0.1464
INFO - 2023-01-08 07:04:13 --> Config Class Initialized
INFO - 2023-01-08 07:04:13 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:04:13 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:04:13 --> Utf8 Class Initialized
INFO - 2023-01-08 07:04:13 --> URI Class Initialized
INFO - 2023-01-08 07:04:13 --> Router Class Initialized
INFO - 2023-01-08 07:04:13 --> Output Class Initialized
INFO - 2023-01-08 07:04:13 --> Security Class Initialized
DEBUG - 2023-01-08 07:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:04:13 --> Input Class Initialized
INFO - 2023-01-08 07:04:13 --> Language Class Initialized
INFO - 2023-01-08 07:04:13 --> Language Class Initialized
INFO - 2023-01-08 07:04:13 --> Config Class Initialized
INFO - 2023-01-08 07:04:13 --> Loader Class Initialized
INFO - 2023-01-08 07:04:13 --> Helper loaded: url_helper
INFO - 2023-01-08 07:04:13 --> Helper loaded: file_helper
INFO - 2023-01-08 07:04:13 --> Helper loaded: form_helper
INFO - 2023-01-08 07:04:13 --> Helper loaded: my_helper
INFO - 2023-01-08 07:04:13 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:04:13 --> Controller Class Initialized
DEBUG - 2023-01-08 07:04:13 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 07:04:14 --> Final output sent to browser
DEBUG - 2023-01-08 07:04:14 --> Total execution time: 0.1473
INFO - 2023-01-08 07:07:12 --> Config Class Initialized
INFO - 2023-01-08 07:07:12 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:07:12 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:07:12 --> Utf8 Class Initialized
INFO - 2023-01-08 07:07:12 --> URI Class Initialized
INFO - 2023-01-08 07:07:12 --> Router Class Initialized
INFO - 2023-01-08 07:07:12 --> Output Class Initialized
INFO - 2023-01-08 07:07:12 --> Security Class Initialized
DEBUG - 2023-01-08 07:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:07:12 --> Input Class Initialized
INFO - 2023-01-08 07:07:12 --> Language Class Initialized
INFO - 2023-01-08 07:07:12 --> Language Class Initialized
INFO - 2023-01-08 07:07:12 --> Config Class Initialized
INFO - 2023-01-08 07:07:12 --> Loader Class Initialized
INFO - 2023-01-08 07:07:12 --> Helper loaded: url_helper
INFO - 2023-01-08 07:07:12 --> Helper loaded: file_helper
INFO - 2023-01-08 07:07:12 --> Helper loaded: form_helper
INFO - 2023-01-08 07:07:12 --> Helper loaded: my_helper
INFO - 2023-01-08 07:07:12 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:07:12 --> Controller Class Initialized
DEBUG - 2023-01-08 07:07:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-01-08 07:07:12 --> Final output sent to browser
DEBUG - 2023-01-08 07:07:12 --> Total execution time: 0.1468
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:15 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:15 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:15 --> URI Class Initialized
INFO - 2023-01-08 07:33:15 --> Router Class Initialized
INFO - 2023-01-08 07:33:15 --> Output Class Initialized
INFO - 2023-01-08 07:33:15 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:15 --> Input Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Loader Class Initialized
INFO - 2023-01-08 07:33:15 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:15 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:15 --> Controller Class Initialized
INFO - 2023-01-08 07:33:15 --> Helper loaded: cookie_helper
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:15 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:15 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:15 --> URI Class Initialized
INFO - 2023-01-08 07:33:15 --> Router Class Initialized
INFO - 2023-01-08 07:33:15 --> Output Class Initialized
INFO - 2023-01-08 07:33:15 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:15 --> Input Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Loader Class Initialized
INFO - 2023-01-08 07:33:15 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:15 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:15 --> Controller Class Initialized
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:15 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:15 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:15 --> URI Class Initialized
INFO - 2023-01-08 07:33:15 --> Router Class Initialized
INFO - 2023-01-08 07:33:15 --> Output Class Initialized
INFO - 2023-01-08 07:33:15 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:15 --> Input Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Language Class Initialized
INFO - 2023-01-08 07:33:15 --> Config Class Initialized
INFO - 2023-01-08 07:33:15 --> Loader Class Initialized
INFO - 2023-01-08 07:33:15 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:15 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:15 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:15 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 07:33:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:15 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:15 --> Total execution time: 0.0463
INFO - 2023-01-08 07:33:20 --> Config Class Initialized
INFO - 2023-01-08 07:33:20 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:20 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:20 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:20 --> URI Class Initialized
INFO - 2023-01-08 07:33:20 --> Router Class Initialized
INFO - 2023-01-08 07:33:20 --> Output Class Initialized
INFO - 2023-01-08 07:33:20 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:20 --> Input Class Initialized
INFO - 2023-01-08 07:33:20 --> Language Class Initialized
INFO - 2023-01-08 07:33:20 --> Language Class Initialized
INFO - 2023-01-08 07:33:20 --> Config Class Initialized
INFO - 2023-01-08 07:33:20 --> Loader Class Initialized
INFO - 2023-01-08 07:33:20 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:20 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:20 --> Controller Class Initialized
INFO - 2023-01-08 07:33:20 --> Helper loaded: cookie_helper
INFO - 2023-01-08 07:33:20 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:20 --> Total execution time: 0.0326
INFO - 2023-01-08 07:33:20 --> Config Class Initialized
INFO - 2023-01-08 07:33:20 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:20 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:20 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:20 --> URI Class Initialized
INFO - 2023-01-08 07:33:20 --> Router Class Initialized
INFO - 2023-01-08 07:33:20 --> Output Class Initialized
INFO - 2023-01-08 07:33:20 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:20 --> Input Class Initialized
INFO - 2023-01-08 07:33:20 --> Language Class Initialized
INFO - 2023-01-08 07:33:20 --> Language Class Initialized
INFO - 2023-01-08 07:33:20 --> Config Class Initialized
INFO - 2023-01-08 07:33:20 --> Loader Class Initialized
INFO - 2023-01-08 07:33:20 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:20 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:20 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:20 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 07:33:20 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:20 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:20 --> Total execution time: 0.0436
INFO - 2023-01-08 07:33:25 --> Config Class Initialized
INFO - 2023-01-08 07:33:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:25 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:25 --> URI Class Initialized
INFO - 2023-01-08 07:33:25 --> Router Class Initialized
INFO - 2023-01-08 07:33:25 --> Output Class Initialized
INFO - 2023-01-08 07:33:25 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:25 --> Input Class Initialized
INFO - 2023-01-08 07:33:25 --> Language Class Initialized
INFO - 2023-01-08 07:33:25 --> Language Class Initialized
INFO - 2023-01-08 07:33:25 --> Config Class Initialized
INFO - 2023-01-08 07:33:25 --> Loader Class Initialized
INFO - 2023-01-08 07:33:25 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:25 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:25 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:25 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:25 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-01-08 07:33:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:25 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:25 --> Total execution time: 0.0382
INFO - 2023-01-08 07:33:28 --> Config Class Initialized
INFO - 2023-01-08 07:33:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:28 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:28 --> URI Class Initialized
INFO - 2023-01-08 07:33:28 --> Router Class Initialized
INFO - 2023-01-08 07:33:28 --> Output Class Initialized
INFO - 2023-01-08 07:33:28 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:28 --> Input Class Initialized
INFO - 2023-01-08 07:33:28 --> Language Class Initialized
INFO - 2023-01-08 07:33:28 --> Language Class Initialized
INFO - 2023-01-08 07:33:28 --> Config Class Initialized
INFO - 2023-01-08 07:33:28 --> Loader Class Initialized
INFO - 2023-01-08 07:33:28 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:28 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:28 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:28 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:28 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-08 07:33:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:28 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:28 --> Total execution time: 0.0381
INFO - 2023-01-08 07:33:29 --> Config Class Initialized
INFO - 2023-01-08 07:33:29 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:29 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:29 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:29 --> URI Class Initialized
INFO - 2023-01-08 07:33:29 --> Router Class Initialized
INFO - 2023-01-08 07:33:29 --> Output Class Initialized
INFO - 2023-01-08 07:33:29 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:29 --> Input Class Initialized
INFO - 2023-01-08 07:33:29 --> Language Class Initialized
INFO - 2023-01-08 07:33:29 --> Language Class Initialized
INFO - 2023-01-08 07:33:29 --> Config Class Initialized
INFO - 2023-01-08 07:33:29 --> Loader Class Initialized
INFO - 2023-01-08 07:33:29 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:29 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:29 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:29 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:29 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:29 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_absensi/views/list.php
DEBUG - 2023-01-08 07:33:29 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:29 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:29 --> Total execution time: 0.0273
INFO - 2023-01-08 07:33:30 --> Config Class Initialized
INFO - 2023-01-08 07:33:30 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:30 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:30 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:30 --> URI Class Initialized
INFO - 2023-01-08 07:33:30 --> Router Class Initialized
INFO - 2023-01-08 07:33:30 --> Output Class Initialized
INFO - 2023-01-08 07:33:30 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:30 --> Input Class Initialized
INFO - 2023-01-08 07:33:30 --> Language Class Initialized
INFO - 2023-01-08 07:33:30 --> Language Class Initialized
INFO - 2023-01-08 07:33:30 --> Config Class Initialized
INFO - 2023-01-08 07:33:30 --> Loader Class Initialized
INFO - 2023-01-08 07:33:30 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:30 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:30 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:30 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:30 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:30 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-08 07:33:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:30 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:30 --> Total execution time: 0.0381
INFO - 2023-01-08 07:33:32 --> Config Class Initialized
INFO - 2023-01-08 07:33:32 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:32 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:32 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:32 --> URI Class Initialized
INFO - 2023-01-08 07:33:32 --> Router Class Initialized
INFO - 2023-01-08 07:33:32 --> Output Class Initialized
INFO - 2023-01-08 07:33:32 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:32 --> Input Class Initialized
INFO - 2023-01-08 07:33:32 --> Language Class Initialized
INFO - 2023-01-08 07:33:32 --> Language Class Initialized
INFO - 2023-01-08 07:33:32 --> Config Class Initialized
INFO - 2023-01-08 07:33:32 --> Loader Class Initialized
INFO - 2023-01-08 07:33:32 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:32 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:32 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:32 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:32 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:32 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-08 07:33:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:32 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:32 --> Total execution time: 0.0259
INFO - 2023-01-08 07:33:34 --> Config Class Initialized
INFO - 2023-01-08 07:33:34 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:34 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:34 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:34 --> URI Class Initialized
INFO - 2023-01-08 07:33:34 --> Router Class Initialized
INFO - 2023-01-08 07:33:34 --> Output Class Initialized
INFO - 2023-01-08 07:33:34 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:34 --> Input Class Initialized
INFO - 2023-01-08 07:33:34 --> Language Class Initialized
INFO - 2023-01-08 07:33:34 --> Language Class Initialized
INFO - 2023-01-08 07:33:34 --> Config Class Initialized
INFO - 2023-01-08 07:33:34 --> Loader Class Initialized
INFO - 2023-01-08 07:33:34 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:34 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:34 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:34 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:34 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:34 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-08 07:33:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:34 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:34 --> Total execution time: 0.0376
INFO - 2023-01-08 07:33:35 --> Config Class Initialized
INFO - 2023-01-08 07:33:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:33:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:33:35 --> Utf8 Class Initialized
INFO - 2023-01-08 07:33:35 --> URI Class Initialized
INFO - 2023-01-08 07:33:35 --> Router Class Initialized
INFO - 2023-01-08 07:33:35 --> Output Class Initialized
INFO - 2023-01-08 07:33:35 --> Security Class Initialized
DEBUG - 2023-01-08 07:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:33:35 --> Input Class Initialized
INFO - 2023-01-08 07:33:35 --> Language Class Initialized
INFO - 2023-01-08 07:33:35 --> Language Class Initialized
INFO - 2023-01-08 07:33:35 --> Config Class Initialized
INFO - 2023-01-08 07:33:35 --> Loader Class Initialized
INFO - 2023-01-08 07:33:35 --> Helper loaded: url_helper
INFO - 2023-01-08 07:33:35 --> Helper loaded: file_helper
INFO - 2023-01-08 07:33:35 --> Helper loaded: form_helper
INFO - 2023-01-08 07:33:35 --> Helper loaded: my_helper
INFO - 2023-01-08 07:33:35 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:33:35 --> Controller Class Initialized
DEBUG - 2023-01-08 07:33:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_sp/views/list.php
DEBUG - 2023-01-08 07:33:35 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:33:35 --> Final output sent to browser
DEBUG - 2023-01-08 07:33:35 --> Total execution time: 0.0228
INFO - 2023-01-08 07:34:17 --> Config Class Initialized
INFO - 2023-01-08 07:34:17 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:34:17 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:34:17 --> Utf8 Class Initialized
INFO - 2023-01-08 07:34:17 --> URI Class Initialized
INFO - 2023-01-08 07:34:17 --> Router Class Initialized
INFO - 2023-01-08 07:34:17 --> Output Class Initialized
INFO - 2023-01-08 07:34:17 --> Security Class Initialized
DEBUG - 2023-01-08 07:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:34:17 --> Input Class Initialized
INFO - 2023-01-08 07:34:17 --> Language Class Initialized
INFO - 2023-01-08 07:34:17 --> Language Class Initialized
INFO - 2023-01-08 07:34:17 --> Config Class Initialized
INFO - 2023-01-08 07:34:17 --> Loader Class Initialized
INFO - 2023-01-08 07:34:17 --> Helper loaded: url_helper
INFO - 2023-01-08 07:34:17 --> Helper loaded: file_helper
INFO - 2023-01-08 07:34:17 --> Helper loaded: form_helper
INFO - 2023-01-08 07:34:17 --> Helper loaded: my_helper
INFO - 2023-01-08 07:34:17 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:34:17 --> Controller Class Initialized
DEBUG - 2023-01-08 07:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_sikap_so/views/list.php
DEBUG - 2023-01-08 07:34:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:34:17 --> Final output sent to browser
DEBUG - 2023-01-08 07:34:17 --> Total execution time: 0.0375
INFO - 2023-01-08 07:41:34 --> Config Class Initialized
INFO - 2023-01-08 07:41:34 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:34 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:34 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:34 --> URI Class Initialized
INFO - 2023-01-08 07:41:34 --> Router Class Initialized
INFO - 2023-01-08 07:41:34 --> Output Class Initialized
INFO - 2023-01-08 07:41:34 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:34 --> Input Class Initialized
INFO - 2023-01-08 07:41:34 --> Language Class Initialized
INFO - 2023-01-08 07:41:34 --> Language Class Initialized
INFO - 2023-01-08 07:41:34 --> Config Class Initialized
INFO - 2023-01-08 07:41:34 --> Loader Class Initialized
INFO - 2023-01-08 07:41:34 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:34 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:34 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:34 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:34 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:34 --> Controller Class Initialized
DEBUG - 2023-01-08 07:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-08 07:41:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:41:34 --> Final output sent to browser
DEBUG - 2023-01-08 07:41:34 --> Total execution time: 0.0564
INFO - 2023-01-08 07:41:35 --> Config Class Initialized
INFO - 2023-01-08 07:41:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:35 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:35 --> URI Class Initialized
INFO - 2023-01-08 07:41:35 --> Router Class Initialized
INFO - 2023-01-08 07:41:35 --> Output Class Initialized
INFO - 2023-01-08 07:41:35 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:35 --> Input Class Initialized
INFO - 2023-01-08 07:41:35 --> Language Class Initialized
INFO - 2023-01-08 07:41:35 --> Language Class Initialized
INFO - 2023-01-08 07:41:35 --> Config Class Initialized
INFO - 2023-01-08 07:41:35 --> Loader Class Initialized
INFO - 2023-01-08 07:41:35 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:35 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:35 --> Controller Class Initialized
INFO - 2023-01-08 07:41:35 --> Helper loaded: cookie_helper
INFO - 2023-01-08 07:41:35 --> Config Class Initialized
INFO - 2023-01-08 07:41:35 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:35 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:35 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:35 --> URI Class Initialized
INFO - 2023-01-08 07:41:35 --> Router Class Initialized
INFO - 2023-01-08 07:41:35 --> Output Class Initialized
INFO - 2023-01-08 07:41:35 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:35 --> Input Class Initialized
INFO - 2023-01-08 07:41:35 --> Language Class Initialized
INFO - 2023-01-08 07:41:35 --> Language Class Initialized
INFO - 2023-01-08 07:41:35 --> Config Class Initialized
INFO - 2023-01-08 07:41:35 --> Loader Class Initialized
INFO - 2023-01-08 07:41:35 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:35 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:36 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:36 --> Controller Class Initialized
INFO - 2023-01-08 07:41:36 --> Config Class Initialized
INFO - 2023-01-08 07:41:36 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:36 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:36 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:36 --> URI Class Initialized
INFO - 2023-01-08 07:41:36 --> Router Class Initialized
INFO - 2023-01-08 07:41:36 --> Output Class Initialized
INFO - 2023-01-08 07:41:36 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:36 --> Input Class Initialized
INFO - 2023-01-08 07:41:36 --> Language Class Initialized
INFO - 2023-01-08 07:41:36 --> Language Class Initialized
INFO - 2023-01-08 07:41:36 --> Config Class Initialized
INFO - 2023-01-08 07:41:36 --> Loader Class Initialized
INFO - 2023-01-08 07:41:36 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:36 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:36 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:36 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:36 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:36 --> Controller Class Initialized
DEBUG - 2023-01-08 07:41:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 07:41:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:41:36 --> Final output sent to browser
DEBUG - 2023-01-08 07:41:36 --> Total execution time: 0.0234
INFO - 2023-01-08 07:41:41 --> Config Class Initialized
INFO - 2023-01-08 07:41:41 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:41 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:41 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:41 --> URI Class Initialized
INFO - 2023-01-08 07:41:41 --> Router Class Initialized
INFO - 2023-01-08 07:41:41 --> Output Class Initialized
INFO - 2023-01-08 07:41:41 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:41 --> Input Class Initialized
INFO - 2023-01-08 07:41:41 --> Language Class Initialized
INFO - 2023-01-08 07:41:41 --> Language Class Initialized
INFO - 2023-01-08 07:41:41 --> Config Class Initialized
INFO - 2023-01-08 07:41:41 --> Loader Class Initialized
INFO - 2023-01-08 07:41:41 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:41 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:41 --> Controller Class Initialized
INFO - 2023-01-08 07:41:41 --> Helper loaded: cookie_helper
INFO - 2023-01-08 07:41:41 --> Final output sent to browser
DEBUG - 2023-01-08 07:41:41 --> Total execution time: 0.0361
INFO - 2023-01-08 07:41:41 --> Config Class Initialized
INFO - 2023-01-08 07:41:41 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:41 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:41 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:41 --> URI Class Initialized
INFO - 2023-01-08 07:41:41 --> Router Class Initialized
INFO - 2023-01-08 07:41:41 --> Output Class Initialized
INFO - 2023-01-08 07:41:41 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:41 --> Input Class Initialized
INFO - 2023-01-08 07:41:41 --> Language Class Initialized
INFO - 2023-01-08 07:41:41 --> Language Class Initialized
INFO - 2023-01-08 07:41:41 --> Config Class Initialized
INFO - 2023-01-08 07:41:41 --> Loader Class Initialized
INFO - 2023-01-08 07:41:41 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:41 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:41 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:41 --> Controller Class Initialized
DEBUG - 2023-01-08 07:41:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 07:41:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:41:41 --> Final output sent to browser
DEBUG - 2023-01-08 07:41:41 --> Total execution time: 0.0372
INFO - 2023-01-08 07:41:44 --> Config Class Initialized
INFO - 2023-01-08 07:41:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:44 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:44 --> URI Class Initialized
INFO - 2023-01-08 07:41:44 --> Router Class Initialized
INFO - 2023-01-08 07:41:44 --> Output Class Initialized
INFO - 2023-01-08 07:41:44 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:44 --> Input Class Initialized
INFO - 2023-01-08 07:41:44 --> Language Class Initialized
INFO - 2023-01-08 07:41:44 --> Language Class Initialized
INFO - 2023-01-08 07:41:44 --> Config Class Initialized
INFO - 2023-01-08 07:41:44 --> Loader Class Initialized
INFO - 2023-01-08 07:41:44 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:44 --> Controller Class Initialized
DEBUG - 2023-01-08 07:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 07:41:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 07:41:44 --> Final output sent to browser
DEBUG - 2023-01-08 07:41:44 --> Total execution time: 0.0256
INFO - 2023-01-08 07:41:44 --> Config Class Initialized
INFO - 2023-01-08 07:41:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:41:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:41:44 --> Utf8 Class Initialized
INFO - 2023-01-08 07:41:44 --> URI Class Initialized
INFO - 2023-01-08 07:41:44 --> Router Class Initialized
INFO - 2023-01-08 07:41:44 --> Output Class Initialized
INFO - 2023-01-08 07:41:44 --> Security Class Initialized
DEBUG - 2023-01-08 07:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:41:44 --> Input Class Initialized
INFO - 2023-01-08 07:41:44 --> Language Class Initialized
INFO - 2023-01-08 07:41:44 --> Language Class Initialized
INFO - 2023-01-08 07:41:44 --> Config Class Initialized
INFO - 2023-01-08 07:41:44 --> Loader Class Initialized
INFO - 2023-01-08 07:41:44 --> Helper loaded: url_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: file_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: form_helper
INFO - 2023-01-08 07:41:44 --> Helper loaded: my_helper
INFO - 2023-01-08 07:41:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:41:44 --> Controller Class Initialized
INFO - 2023-01-08 07:52:25 --> Config Class Initialized
INFO - 2023-01-08 07:52:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:52:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:52:25 --> Utf8 Class Initialized
INFO - 2023-01-08 07:52:25 --> URI Class Initialized
INFO - 2023-01-08 07:52:25 --> Router Class Initialized
INFO - 2023-01-08 07:52:25 --> Output Class Initialized
INFO - 2023-01-08 07:52:25 --> Security Class Initialized
DEBUG - 2023-01-08 07:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:52:25 --> Input Class Initialized
INFO - 2023-01-08 07:52:25 --> Language Class Initialized
INFO - 2023-01-08 07:52:25 --> Language Class Initialized
INFO - 2023-01-08 07:52:25 --> Config Class Initialized
INFO - 2023-01-08 07:52:25 --> Loader Class Initialized
INFO - 2023-01-08 07:52:25 --> Helper loaded: url_helper
INFO - 2023-01-08 07:52:25 --> Helper loaded: file_helper
INFO - 2023-01-08 07:52:25 --> Helper loaded: form_helper
INFO - 2023-01-08 07:52:25 --> Helper loaded: my_helper
INFO - 2023-01-08 07:52:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:52:25 --> Controller Class Initialized
INFO - 2023-01-08 07:57:58 --> Config Class Initialized
INFO - 2023-01-08 07:57:58 --> Hooks Class Initialized
DEBUG - 2023-01-08 07:57:58 --> UTF-8 Support Enabled
INFO - 2023-01-08 07:57:58 --> Utf8 Class Initialized
INFO - 2023-01-08 07:57:58 --> URI Class Initialized
INFO - 2023-01-08 07:57:58 --> Router Class Initialized
INFO - 2023-01-08 07:57:58 --> Output Class Initialized
INFO - 2023-01-08 07:57:58 --> Security Class Initialized
DEBUG - 2023-01-08 07:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 07:57:58 --> Input Class Initialized
INFO - 2023-01-08 07:57:58 --> Language Class Initialized
INFO - 2023-01-08 07:57:58 --> Language Class Initialized
INFO - 2023-01-08 07:57:58 --> Config Class Initialized
INFO - 2023-01-08 07:57:58 --> Loader Class Initialized
INFO - 2023-01-08 07:57:58 --> Helper loaded: url_helper
INFO - 2023-01-08 07:57:58 --> Helper loaded: file_helper
INFO - 2023-01-08 07:57:58 --> Helper loaded: form_helper
INFO - 2023-01-08 07:57:58 --> Helper loaded: my_helper
INFO - 2023-01-08 07:57:58 --> Database Driver Class Initialized
DEBUG - 2023-01-08 07:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 07:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 07:57:59 --> Controller Class Initialized
INFO - 2023-01-08 08:14:19 --> Config Class Initialized
INFO - 2023-01-08 08:14:19 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:14:19 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:14:19 --> Utf8 Class Initialized
INFO - 2023-01-08 08:14:19 --> URI Class Initialized
INFO - 2023-01-08 08:14:19 --> Router Class Initialized
INFO - 2023-01-08 08:14:20 --> Output Class Initialized
INFO - 2023-01-08 08:14:20 --> Security Class Initialized
DEBUG - 2023-01-08 08:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:14:20 --> Input Class Initialized
INFO - 2023-01-08 08:14:20 --> Language Class Initialized
INFO - 2023-01-08 08:14:20 --> Language Class Initialized
INFO - 2023-01-08 08:14:20 --> Config Class Initialized
INFO - 2023-01-08 08:14:20 --> Loader Class Initialized
INFO - 2023-01-08 08:14:20 --> Helper loaded: url_helper
INFO - 2023-01-08 08:14:20 --> Helper loaded: file_helper
INFO - 2023-01-08 08:14:20 --> Helper loaded: form_helper
INFO - 2023-01-08 08:14:20 --> Helper loaded: my_helper
INFO - 2023-01-08 08:14:20 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:14:20 --> Controller Class Initialized
INFO - 2023-01-08 08:34:11 --> Config Class Initialized
INFO - 2023-01-08 08:34:11 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:34:11 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:34:11 --> Utf8 Class Initialized
INFO - 2023-01-08 08:34:11 --> URI Class Initialized
INFO - 2023-01-08 08:34:11 --> Router Class Initialized
INFO - 2023-01-08 08:34:11 --> Output Class Initialized
INFO - 2023-01-08 08:34:11 --> Security Class Initialized
DEBUG - 2023-01-08 08:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:34:11 --> Input Class Initialized
INFO - 2023-01-08 08:34:11 --> Language Class Initialized
INFO - 2023-01-08 08:34:11 --> Language Class Initialized
INFO - 2023-01-08 08:34:12 --> Config Class Initialized
INFO - 2023-01-08 08:34:12 --> Loader Class Initialized
INFO - 2023-01-08 08:34:12 --> Helper loaded: url_helper
INFO - 2023-01-08 08:34:12 --> Helper loaded: file_helper
INFO - 2023-01-08 08:34:12 --> Helper loaded: form_helper
INFO - 2023-01-08 08:34:12 --> Helper loaded: my_helper
INFO - 2023-01-08 08:34:12 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:34:12 --> Controller Class Initialized
DEBUG - 2023-01-08 08:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 08:34:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 08:34:12 --> Final output sent to browser
DEBUG - 2023-01-08 08:34:12 --> Total execution time: 0.2737
INFO - 2023-01-08 08:41:26 --> Config Class Initialized
INFO - 2023-01-08 08:41:26 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:41:26 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:41:26 --> Utf8 Class Initialized
INFO - 2023-01-08 08:41:26 --> URI Class Initialized
INFO - 2023-01-08 08:41:26 --> Router Class Initialized
INFO - 2023-01-08 08:41:26 --> Output Class Initialized
INFO - 2023-01-08 08:41:26 --> Security Class Initialized
DEBUG - 2023-01-08 08:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:41:26 --> Input Class Initialized
INFO - 2023-01-08 08:41:26 --> Language Class Initialized
INFO - 2023-01-08 08:41:26 --> Language Class Initialized
INFO - 2023-01-08 08:41:26 --> Config Class Initialized
INFO - 2023-01-08 08:41:26 --> Loader Class Initialized
INFO - 2023-01-08 08:41:26 --> Helper loaded: url_helper
INFO - 2023-01-08 08:41:26 --> Helper loaded: file_helper
INFO - 2023-01-08 08:41:26 --> Helper loaded: form_helper
INFO - 2023-01-08 08:41:26 --> Helper loaded: my_helper
INFO - 2023-01-08 08:41:26 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:41:26 --> Controller Class Initialized
DEBUG - 2023-01-08 08:41:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 08:41:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 08:41:26 --> Final output sent to browser
DEBUG - 2023-01-08 08:41:26 --> Total execution time: 0.1187
INFO - 2023-01-08 08:41:28 --> Config Class Initialized
INFO - 2023-01-08 08:41:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:41:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:41:28 --> Utf8 Class Initialized
INFO - 2023-01-08 08:41:28 --> URI Class Initialized
INFO - 2023-01-08 08:41:28 --> Router Class Initialized
INFO - 2023-01-08 08:41:28 --> Output Class Initialized
INFO - 2023-01-08 08:41:28 --> Security Class Initialized
DEBUG - 2023-01-08 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:41:28 --> Input Class Initialized
INFO - 2023-01-08 08:41:28 --> Language Class Initialized
INFO - 2023-01-08 08:41:28 --> Language Class Initialized
INFO - 2023-01-08 08:41:28 --> Config Class Initialized
INFO - 2023-01-08 08:41:28 --> Loader Class Initialized
INFO - 2023-01-08 08:41:28 --> Helper loaded: url_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: file_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: form_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: my_helper
INFO - 2023-01-08 08:41:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:41:28 --> Controller Class Initialized
DEBUG - 2023-01-08 08:41:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 08:41:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 08:41:28 --> Final output sent to browser
DEBUG - 2023-01-08 08:41:28 --> Total execution time: 0.1020
INFO - 2023-01-08 08:41:28 --> Config Class Initialized
INFO - 2023-01-08 08:41:28 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:41:28 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:41:28 --> Utf8 Class Initialized
INFO - 2023-01-08 08:41:28 --> URI Class Initialized
INFO - 2023-01-08 08:41:28 --> Router Class Initialized
INFO - 2023-01-08 08:41:28 --> Output Class Initialized
INFO - 2023-01-08 08:41:28 --> Security Class Initialized
DEBUG - 2023-01-08 08:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:41:28 --> Input Class Initialized
INFO - 2023-01-08 08:41:28 --> Language Class Initialized
INFO - 2023-01-08 08:41:28 --> Language Class Initialized
INFO - 2023-01-08 08:41:28 --> Config Class Initialized
INFO - 2023-01-08 08:41:28 --> Loader Class Initialized
INFO - 2023-01-08 08:41:28 --> Helper loaded: url_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: file_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: form_helper
INFO - 2023-01-08 08:41:28 --> Helper loaded: my_helper
INFO - 2023-01-08 08:41:28 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:41:28 --> Controller Class Initialized
INFO - 2023-01-08 08:41:51 --> Config Class Initialized
INFO - 2023-01-08 08:41:51 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:41:51 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:41:51 --> Utf8 Class Initialized
INFO - 2023-01-08 08:41:51 --> URI Class Initialized
INFO - 2023-01-08 08:41:51 --> Router Class Initialized
INFO - 2023-01-08 08:41:51 --> Output Class Initialized
INFO - 2023-01-08 08:41:51 --> Security Class Initialized
DEBUG - 2023-01-08 08:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:41:51 --> Input Class Initialized
INFO - 2023-01-08 08:41:51 --> Language Class Initialized
INFO - 2023-01-08 08:41:51 --> Language Class Initialized
INFO - 2023-01-08 08:41:51 --> Config Class Initialized
INFO - 2023-01-08 08:41:51 --> Loader Class Initialized
INFO - 2023-01-08 08:41:51 --> Helper loaded: url_helper
INFO - 2023-01-08 08:41:51 --> Helper loaded: file_helper
INFO - 2023-01-08 08:41:51 --> Helper loaded: form_helper
INFO - 2023-01-08 08:41:51 --> Helper loaded: my_helper
INFO - 2023-01-08 08:41:51 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:41:51 --> Controller Class Initialized
INFO - 2023-01-08 08:41:51 --> Final output sent to browser
DEBUG - 2023-01-08 08:41:51 --> Total execution time: 0.0669
INFO - 2023-01-08 08:42:44 --> Config Class Initialized
INFO - 2023-01-08 08:42:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:42:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:42:44 --> Utf8 Class Initialized
INFO - 2023-01-08 08:42:44 --> URI Class Initialized
INFO - 2023-01-08 08:42:44 --> Router Class Initialized
INFO - 2023-01-08 08:42:44 --> Output Class Initialized
INFO - 2023-01-08 08:42:44 --> Security Class Initialized
DEBUG - 2023-01-08 08:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:42:44 --> Input Class Initialized
INFO - 2023-01-08 08:42:44 --> Language Class Initialized
INFO - 2023-01-08 08:42:44 --> Language Class Initialized
INFO - 2023-01-08 08:42:44 --> Config Class Initialized
INFO - 2023-01-08 08:42:44 --> Loader Class Initialized
INFO - 2023-01-08 08:42:44 --> Helper loaded: url_helper
INFO - 2023-01-08 08:42:44 --> Helper loaded: file_helper
INFO - 2023-01-08 08:42:44 --> Helper loaded: form_helper
INFO - 2023-01-08 08:42:44 --> Helper loaded: my_helper
INFO - 2023-01-08 08:42:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:42:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:42:44 --> Controller Class Initialized
INFO - 2023-01-08 08:43:54 --> Config Class Initialized
INFO - 2023-01-08 08:43:54 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:43:54 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:43:54 --> Utf8 Class Initialized
INFO - 2023-01-08 08:43:54 --> URI Class Initialized
INFO - 2023-01-08 08:43:54 --> Router Class Initialized
INFO - 2023-01-08 08:43:54 --> Output Class Initialized
INFO - 2023-01-08 08:43:54 --> Security Class Initialized
DEBUG - 2023-01-08 08:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:43:54 --> Input Class Initialized
INFO - 2023-01-08 08:43:54 --> Language Class Initialized
ERROR - 2023-01-08 08:43:54 --> Severity: error --> Exception: syntax error, unexpected '$kolom_akhir_kd' (T_VARIABLE) C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 391
INFO - 2023-01-08 08:44:05 --> Config Class Initialized
INFO - 2023-01-08 08:44:05 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:44:05 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:44:05 --> Utf8 Class Initialized
INFO - 2023-01-08 08:44:05 --> URI Class Initialized
INFO - 2023-01-08 08:44:05 --> Router Class Initialized
INFO - 2023-01-08 08:44:05 --> Output Class Initialized
INFO - 2023-01-08 08:44:05 --> Security Class Initialized
DEBUG - 2023-01-08 08:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:44:05 --> Input Class Initialized
INFO - 2023-01-08 08:44:05 --> Language Class Initialized
INFO - 2023-01-08 08:44:05 --> Language Class Initialized
INFO - 2023-01-08 08:44:05 --> Config Class Initialized
INFO - 2023-01-08 08:44:05 --> Loader Class Initialized
INFO - 2023-01-08 08:44:05 --> Helper loaded: url_helper
INFO - 2023-01-08 08:44:05 --> Helper loaded: file_helper
INFO - 2023-01-08 08:44:05 --> Helper loaded: form_helper
INFO - 2023-01-08 08:44:05 --> Helper loaded: my_helper
INFO - 2023-01-08 08:44:05 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:44:05 --> Controller Class Initialized
INFO - 2023-01-08 08:48:27 --> Config Class Initialized
INFO - 2023-01-08 08:48:27 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:48:27 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:48:27 --> Utf8 Class Initialized
INFO - 2023-01-08 08:48:27 --> URI Class Initialized
INFO - 2023-01-08 08:48:27 --> Router Class Initialized
INFO - 2023-01-08 08:48:27 --> Output Class Initialized
INFO - 2023-01-08 08:48:27 --> Security Class Initialized
DEBUG - 2023-01-08 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:48:27 --> Input Class Initialized
INFO - 2023-01-08 08:48:27 --> Language Class Initialized
INFO - 2023-01-08 08:48:27 --> Language Class Initialized
INFO - 2023-01-08 08:48:27 --> Config Class Initialized
INFO - 2023-01-08 08:48:27 --> Loader Class Initialized
INFO - 2023-01-08 08:48:27 --> Helper loaded: url_helper
INFO - 2023-01-08 08:48:27 --> Helper loaded: file_helper
INFO - 2023-01-08 08:48:27 --> Helper loaded: form_helper
INFO - 2023-01-08 08:48:27 --> Helper loaded: my_helper
INFO - 2023-01-08 08:48:27 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:48:27 --> Controller Class Initialized
INFO - 2023-01-08 08:49:40 --> Config Class Initialized
INFO - 2023-01-08 08:49:40 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:49:40 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:49:40 --> Utf8 Class Initialized
INFO - 2023-01-08 08:49:40 --> URI Class Initialized
INFO - 2023-01-08 08:49:40 --> Router Class Initialized
INFO - 2023-01-08 08:49:40 --> Output Class Initialized
INFO - 2023-01-08 08:49:40 --> Security Class Initialized
DEBUG - 2023-01-08 08:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:49:40 --> Input Class Initialized
INFO - 2023-01-08 08:49:40 --> Language Class Initialized
INFO - 2023-01-08 08:49:40 --> Language Class Initialized
INFO - 2023-01-08 08:49:40 --> Config Class Initialized
INFO - 2023-01-08 08:49:40 --> Loader Class Initialized
INFO - 2023-01-08 08:49:40 --> Helper loaded: url_helper
INFO - 2023-01-08 08:49:40 --> Helper loaded: file_helper
INFO - 2023-01-08 08:49:40 --> Helper loaded: form_helper
INFO - 2023-01-08 08:49:40 --> Helper loaded: my_helper
INFO - 2023-01-08 08:49:40 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:49:40 --> Controller Class Initialized
INFO - 2023-01-08 08:50:18 --> Config Class Initialized
INFO - 2023-01-08 08:50:18 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:50:18 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:50:18 --> Utf8 Class Initialized
INFO - 2023-01-08 08:50:18 --> URI Class Initialized
INFO - 2023-01-08 08:50:18 --> Router Class Initialized
INFO - 2023-01-08 08:50:18 --> Output Class Initialized
INFO - 2023-01-08 08:50:18 --> Security Class Initialized
DEBUG - 2023-01-08 08:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:50:18 --> Input Class Initialized
INFO - 2023-01-08 08:50:18 --> Language Class Initialized
INFO - 2023-01-08 08:50:18 --> Language Class Initialized
INFO - 2023-01-08 08:50:18 --> Config Class Initialized
INFO - 2023-01-08 08:50:18 --> Loader Class Initialized
INFO - 2023-01-08 08:50:18 --> Helper loaded: url_helper
INFO - 2023-01-08 08:50:18 --> Helper loaded: file_helper
INFO - 2023-01-08 08:50:18 --> Helper loaded: form_helper
INFO - 2023-01-08 08:50:18 --> Helper loaded: my_helper
INFO - 2023-01-08 08:50:18 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:50:18 --> Controller Class Initialized
INFO - 2023-01-08 08:51:07 --> Config Class Initialized
INFO - 2023-01-08 08:51:07 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:51:07 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:51:07 --> Utf8 Class Initialized
INFO - 2023-01-08 08:51:07 --> URI Class Initialized
INFO - 2023-01-08 08:51:07 --> Router Class Initialized
INFO - 2023-01-08 08:51:07 --> Output Class Initialized
INFO - 2023-01-08 08:51:07 --> Security Class Initialized
DEBUG - 2023-01-08 08:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:51:07 --> Input Class Initialized
INFO - 2023-01-08 08:51:07 --> Language Class Initialized
INFO - 2023-01-08 08:51:07 --> Language Class Initialized
INFO - 2023-01-08 08:51:07 --> Config Class Initialized
INFO - 2023-01-08 08:51:07 --> Loader Class Initialized
INFO - 2023-01-08 08:51:07 --> Helper loaded: url_helper
INFO - 2023-01-08 08:51:07 --> Helper loaded: file_helper
INFO - 2023-01-08 08:51:07 --> Helper loaded: form_helper
INFO - 2023-01-08 08:51:07 --> Helper loaded: my_helper
INFO - 2023-01-08 08:51:07 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:51:07 --> Controller Class Initialized
INFO - 2023-01-08 08:54:25 --> Config Class Initialized
INFO - 2023-01-08 08:54:25 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:54:25 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:54:25 --> Utf8 Class Initialized
INFO - 2023-01-08 08:54:25 --> URI Class Initialized
INFO - 2023-01-08 08:54:25 --> Router Class Initialized
INFO - 2023-01-08 08:54:25 --> Output Class Initialized
INFO - 2023-01-08 08:54:25 --> Security Class Initialized
DEBUG - 2023-01-08 08:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:54:25 --> Input Class Initialized
INFO - 2023-01-08 08:54:25 --> Language Class Initialized
INFO - 2023-01-08 08:54:25 --> Language Class Initialized
INFO - 2023-01-08 08:54:25 --> Config Class Initialized
INFO - 2023-01-08 08:54:25 --> Loader Class Initialized
INFO - 2023-01-08 08:54:25 --> Helper loaded: url_helper
INFO - 2023-01-08 08:54:25 --> Helper loaded: file_helper
INFO - 2023-01-08 08:54:25 --> Helper loaded: form_helper
INFO - 2023-01-08 08:54:25 --> Helper loaded: my_helper
INFO - 2023-01-08 08:54:25 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:54:25 --> Controller Class Initialized
INFO - 2023-01-08 08:58:07 --> Config Class Initialized
INFO - 2023-01-08 08:58:07 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:58:07 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:58:07 --> Utf8 Class Initialized
INFO - 2023-01-08 08:58:07 --> URI Class Initialized
INFO - 2023-01-08 08:58:07 --> Router Class Initialized
INFO - 2023-01-08 08:58:07 --> Output Class Initialized
INFO - 2023-01-08 08:58:07 --> Security Class Initialized
DEBUG - 2023-01-08 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:58:07 --> Input Class Initialized
INFO - 2023-01-08 08:58:07 --> Language Class Initialized
INFO - 2023-01-08 08:58:07 --> Language Class Initialized
INFO - 2023-01-08 08:58:07 --> Config Class Initialized
INFO - 2023-01-08 08:58:07 --> Loader Class Initialized
INFO - 2023-01-08 08:58:07 --> Helper loaded: url_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: file_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: form_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: my_helper
INFO - 2023-01-08 08:58:07 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:58:07 --> Controller Class Initialized
DEBUG - 2023-01-08 08:58:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 08:58:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 08:58:07 --> Final output sent to browser
DEBUG - 2023-01-08 08:58:07 --> Total execution time: 0.0682
INFO - 2023-01-08 08:58:07 --> Config Class Initialized
INFO - 2023-01-08 08:58:07 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:58:07 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:58:07 --> Utf8 Class Initialized
INFO - 2023-01-08 08:58:07 --> URI Class Initialized
INFO - 2023-01-08 08:58:07 --> Router Class Initialized
INFO - 2023-01-08 08:58:07 --> Output Class Initialized
INFO - 2023-01-08 08:58:07 --> Security Class Initialized
DEBUG - 2023-01-08 08:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:58:07 --> Input Class Initialized
INFO - 2023-01-08 08:58:07 --> Language Class Initialized
INFO - 2023-01-08 08:58:07 --> Language Class Initialized
INFO - 2023-01-08 08:58:07 --> Config Class Initialized
INFO - 2023-01-08 08:58:07 --> Loader Class Initialized
INFO - 2023-01-08 08:58:07 --> Helper loaded: url_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: file_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: form_helper
INFO - 2023-01-08 08:58:07 --> Helper loaded: my_helper
INFO - 2023-01-08 08:58:07 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:58:07 --> Controller Class Initialized
INFO - 2023-01-08 08:58:09 --> Config Class Initialized
INFO - 2023-01-08 08:58:09 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:58:09 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:58:09 --> Utf8 Class Initialized
INFO - 2023-01-08 08:58:09 --> URI Class Initialized
INFO - 2023-01-08 08:58:09 --> Router Class Initialized
INFO - 2023-01-08 08:58:09 --> Output Class Initialized
INFO - 2023-01-08 08:58:09 --> Security Class Initialized
DEBUG - 2023-01-08 08:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:58:09 --> Input Class Initialized
INFO - 2023-01-08 08:58:09 --> Language Class Initialized
INFO - 2023-01-08 08:58:09 --> Language Class Initialized
INFO - 2023-01-08 08:58:09 --> Config Class Initialized
INFO - 2023-01-08 08:58:09 --> Loader Class Initialized
INFO - 2023-01-08 08:58:09 --> Helper loaded: url_helper
INFO - 2023-01-08 08:58:09 --> Helper loaded: file_helper
INFO - 2023-01-08 08:58:09 --> Helper loaded: form_helper
INFO - 2023-01-08 08:58:09 --> Helper loaded: my_helper
INFO - 2023-01-08 08:58:09 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:58:09 --> Controller Class Initialized
INFO - 2023-01-08 08:59:59 --> Config Class Initialized
INFO - 2023-01-08 08:59:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 08:59:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 08:59:59 --> Utf8 Class Initialized
INFO - 2023-01-08 08:59:59 --> URI Class Initialized
INFO - 2023-01-08 08:59:59 --> Router Class Initialized
INFO - 2023-01-08 08:59:59 --> Output Class Initialized
INFO - 2023-01-08 08:59:59 --> Security Class Initialized
DEBUG - 2023-01-08 08:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 08:59:59 --> Input Class Initialized
INFO - 2023-01-08 08:59:59 --> Language Class Initialized
INFO - 2023-01-08 08:59:59 --> Language Class Initialized
INFO - 2023-01-08 08:59:59 --> Config Class Initialized
INFO - 2023-01-08 08:59:59 --> Loader Class Initialized
INFO - 2023-01-08 08:59:59 --> Helper loaded: url_helper
INFO - 2023-01-08 08:59:59 --> Helper loaded: file_helper
INFO - 2023-01-08 08:59:59 --> Helper loaded: form_helper
INFO - 2023-01-08 08:59:59 --> Helper loaded: my_helper
INFO - 2023-01-08 08:59:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 08:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 08:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 08:59:59 --> Controller Class Initialized
INFO - 2023-01-08 09:00:34 --> Config Class Initialized
INFO - 2023-01-08 09:00:34 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:00:34 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:00:34 --> Utf8 Class Initialized
INFO - 2023-01-08 09:00:34 --> URI Class Initialized
INFO - 2023-01-08 09:00:34 --> Router Class Initialized
INFO - 2023-01-08 09:00:34 --> Output Class Initialized
INFO - 2023-01-08 09:00:34 --> Security Class Initialized
DEBUG - 2023-01-08 09:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:00:34 --> Input Class Initialized
INFO - 2023-01-08 09:00:34 --> Language Class Initialized
INFO - 2023-01-08 09:00:34 --> Language Class Initialized
INFO - 2023-01-08 09:00:34 --> Config Class Initialized
INFO - 2023-01-08 09:00:34 --> Loader Class Initialized
INFO - 2023-01-08 09:00:34 --> Helper loaded: url_helper
INFO - 2023-01-08 09:00:34 --> Helper loaded: file_helper
INFO - 2023-01-08 09:00:34 --> Helper loaded: form_helper
INFO - 2023-01-08 09:00:34 --> Helper loaded: my_helper
INFO - 2023-01-08 09:00:34 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:00:34 --> Controller Class Initialized
INFO - 2023-01-08 09:11:07 --> Config Class Initialized
INFO - 2023-01-08 09:11:07 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:11:07 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:11:07 --> Utf8 Class Initialized
INFO - 2023-01-08 09:11:07 --> URI Class Initialized
INFO - 2023-01-08 09:11:07 --> Router Class Initialized
INFO - 2023-01-08 09:11:07 --> Output Class Initialized
INFO - 2023-01-08 09:11:07 --> Security Class Initialized
DEBUG - 2023-01-08 09:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:11:07 --> Input Class Initialized
INFO - 2023-01-08 09:11:07 --> Language Class Initialized
INFO - 2023-01-08 09:11:07 --> Language Class Initialized
INFO - 2023-01-08 09:11:07 --> Config Class Initialized
INFO - 2023-01-08 09:11:07 --> Loader Class Initialized
INFO - 2023-01-08 09:11:07 --> Helper loaded: url_helper
INFO - 2023-01-08 09:11:07 --> Helper loaded: file_helper
INFO - 2023-01-08 09:11:07 --> Helper loaded: form_helper
INFO - 2023-01-08 09:11:07 --> Helper loaded: my_helper
INFO - 2023-01-08 09:11:07 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:11:07 --> Controller Class Initialized
INFO - 2023-01-08 09:11:19 --> Config Class Initialized
INFO - 2023-01-08 09:11:19 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:11:19 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:11:19 --> Utf8 Class Initialized
INFO - 2023-01-08 09:11:19 --> URI Class Initialized
INFO - 2023-01-08 09:11:19 --> Router Class Initialized
INFO - 2023-01-08 09:11:19 --> Output Class Initialized
INFO - 2023-01-08 09:11:19 --> Security Class Initialized
DEBUG - 2023-01-08 09:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:11:19 --> Input Class Initialized
INFO - 2023-01-08 09:11:19 --> Language Class Initialized
INFO - 2023-01-08 09:11:19 --> Language Class Initialized
INFO - 2023-01-08 09:11:19 --> Config Class Initialized
INFO - 2023-01-08 09:11:19 --> Loader Class Initialized
INFO - 2023-01-08 09:11:19 --> Helper loaded: url_helper
INFO - 2023-01-08 09:11:19 --> Helper loaded: file_helper
INFO - 2023-01-08 09:11:19 --> Helper loaded: form_helper
INFO - 2023-01-08 09:11:19 --> Helper loaded: my_helper
INFO - 2023-01-08 09:11:19 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:11:19 --> Controller Class Initialized
INFO - 2023-01-08 09:15:11 --> Config Class Initialized
INFO - 2023-01-08 09:15:11 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:15:11 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:15:11 --> Utf8 Class Initialized
INFO - 2023-01-08 09:15:11 --> URI Class Initialized
INFO - 2023-01-08 09:15:11 --> Router Class Initialized
INFO - 2023-01-08 09:15:11 --> Output Class Initialized
INFO - 2023-01-08 09:15:11 --> Security Class Initialized
DEBUG - 2023-01-08 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:15:11 --> Input Class Initialized
INFO - 2023-01-08 09:15:11 --> Language Class Initialized
INFO - 2023-01-08 09:15:11 --> Language Class Initialized
INFO - 2023-01-08 09:15:11 --> Config Class Initialized
INFO - 2023-01-08 09:15:11 --> Loader Class Initialized
INFO - 2023-01-08 09:15:11 --> Helper loaded: url_helper
INFO - 2023-01-08 09:15:11 --> Helper loaded: file_helper
INFO - 2023-01-08 09:15:11 --> Helper loaded: form_helper
INFO - 2023-01-08 09:15:11 --> Helper loaded: my_helper
INFO - 2023-01-08 09:15:11 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:15:12 --> Controller Class Initialized
INFO - 2023-01-08 09:16:59 --> Config Class Initialized
INFO - 2023-01-08 09:16:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:16:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:16:59 --> Utf8 Class Initialized
INFO - 2023-01-08 09:16:59 --> URI Class Initialized
INFO - 2023-01-08 09:16:59 --> Router Class Initialized
INFO - 2023-01-08 09:16:59 --> Output Class Initialized
INFO - 2023-01-08 09:16:59 --> Security Class Initialized
DEBUG - 2023-01-08 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:16:59 --> Input Class Initialized
INFO - 2023-01-08 09:16:59 --> Language Class Initialized
INFO - 2023-01-08 09:16:59 --> Language Class Initialized
INFO - 2023-01-08 09:16:59 --> Config Class Initialized
INFO - 2023-01-08 09:16:59 --> Loader Class Initialized
INFO - 2023-01-08 09:16:59 --> Helper loaded: url_helper
INFO - 2023-01-08 09:16:59 --> Helper loaded: file_helper
INFO - 2023-01-08 09:16:59 --> Helper loaded: form_helper
INFO - 2023-01-08 09:16:59 --> Helper loaded: my_helper
INFO - 2023-01-08 09:16:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:16:59 --> Controller Class Initialized
INFO - 2023-01-08 09:18:37 --> Config Class Initialized
INFO - 2023-01-08 09:18:37 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:18:37 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:18:37 --> Utf8 Class Initialized
INFO - 2023-01-08 09:18:37 --> URI Class Initialized
INFO - 2023-01-08 09:18:37 --> Router Class Initialized
INFO - 2023-01-08 09:18:37 --> Output Class Initialized
INFO - 2023-01-08 09:18:37 --> Security Class Initialized
DEBUG - 2023-01-08 09:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:18:37 --> Input Class Initialized
INFO - 2023-01-08 09:18:37 --> Language Class Initialized
INFO - 2023-01-08 09:18:37 --> Language Class Initialized
INFO - 2023-01-08 09:18:37 --> Config Class Initialized
INFO - 2023-01-08 09:18:37 --> Loader Class Initialized
INFO - 2023-01-08 09:18:37 --> Helper loaded: url_helper
INFO - 2023-01-08 09:18:37 --> Helper loaded: file_helper
INFO - 2023-01-08 09:18:37 --> Helper loaded: form_helper
INFO - 2023-01-08 09:18:37 --> Helper loaded: my_helper
INFO - 2023-01-08 09:18:37 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:18:37 --> Controller Class Initialized
INFO - 2023-01-08 09:19:02 --> Config Class Initialized
INFO - 2023-01-08 09:19:02 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:19:02 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:19:02 --> Utf8 Class Initialized
INFO - 2023-01-08 09:19:02 --> URI Class Initialized
INFO - 2023-01-08 09:19:02 --> Router Class Initialized
INFO - 2023-01-08 09:19:02 --> Output Class Initialized
INFO - 2023-01-08 09:19:02 --> Security Class Initialized
DEBUG - 2023-01-08 09:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:19:02 --> Input Class Initialized
INFO - 2023-01-08 09:19:02 --> Language Class Initialized
INFO - 2023-01-08 09:19:02 --> Language Class Initialized
INFO - 2023-01-08 09:19:02 --> Config Class Initialized
INFO - 2023-01-08 09:19:02 --> Loader Class Initialized
INFO - 2023-01-08 09:19:02 --> Helper loaded: url_helper
INFO - 2023-01-08 09:19:02 --> Helper loaded: file_helper
INFO - 2023-01-08 09:19:02 --> Helper loaded: form_helper
INFO - 2023-01-08 09:19:02 --> Helper loaded: my_helper
INFO - 2023-01-08 09:19:02 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:19:02 --> Controller Class Initialized
INFO - 2023-01-08 09:19:50 --> Config Class Initialized
INFO - 2023-01-08 09:19:50 --> Hooks Class Initialized
DEBUG - 2023-01-08 09:19:50 --> UTF-8 Support Enabled
INFO - 2023-01-08 09:19:50 --> Utf8 Class Initialized
INFO - 2023-01-08 09:19:50 --> URI Class Initialized
INFO - 2023-01-08 09:19:50 --> Router Class Initialized
INFO - 2023-01-08 09:19:50 --> Output Class Initialized
INFO - 2023-01-08 09:19:50 --> Security Class Initialized
DEBUG - 2023-01-08 09:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 09:19:50 --> Input Class Initialized
INFO - 2023-01-08 09:19:50 --> Language Class Initialized
INFO - 2023-01-08 09:19:50 --> Language Class Initialized
INFO - 2023-01-08 09:19:50 --> Config Class Initialized
INFO - 2023-01-08 09:19:50 --> Loader Class Initialized
INFO - 2023-01-08 09:19:50 --> Helper loaded: url_helper
INFO - 2023-01-08 09:19:50 --> Helper loaded: file_helper
INFO - 2023-01-08 09:19:50 --> Helper loaded: form_helper
INFO - 2023-01-08 09:19:50 --> Helper loaded: my_helper
INFO - 2023-01-08 09:19:50 --> Database Driver Class Initialized
DEBUG - 2023-01-08 09:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 09:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 09:19:50 --> Controller Class Initialized
INFO - 2023-01-08 13:52:54 --> Config Class Initialized
INFO - 2023-01-08 13:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:52:54 --> Utf8 Class Initialized
INFO - 2023-01-08 13:52:54 --> URI Class Initialized
INFO - 2023-01-08 13:52:54 --> Router Class Initialized
INFO - 2023-01-08 13:52:54 --> Output Class Initialized
INFO - 2023-01-08 13:52:54 --> Security Class Initialized
DEBUG - 2023-01-08 13:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:52:54 --> Input Class Initialized
INFO - 2023-01-08 13:52:54 --> Language Class Initialized
INFO - 2023-01-08 13:52:54 --> Language Class Initialized
INFO - 2023-01-08 13:52:54 --> Config Class Initialized
INFO - 2023-01-08 13:52:54 --> Loader Class Initialized
INFO - 2023-01-08 13:52:54 --> Helper loaded: url_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: file_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: form_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: my_helper
INFO - 2023-01-08 13:52:54 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:52:54 --> Controller Class Initialized
INFO - 2023-01-08 13:52:54 --> Config Class Initialized
INFO - 2023-01-08 13:52:54 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:52:54 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:52:54 --> Utf8 Class Initialized
INFO - 2023-01-08 13:52:54 --> URI Class Initialized
INFO - 2023-01-08 13:52:54 --> Router Class Initialized
INFO - 2023-01-08 13:52:54 --> Output Class Initialized
INFO - 2023-01-08 13:52:54 --> Security Class Initialized
DEBUG - 2023-01-08 13:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:52:54 --> Input Class Initialized
INFO - 2023-01-08 13:52:54 --> Language Class Initialized
INFO - 2023-01-08 13:52:54 --> Language Class Initialized
INFO - 2023-01-08 13:52:54 --> Config Class Initialized
INFO - 2023-01-08 13:52:54 --> Loader Class Initialized
INFO - 2023-01-08 13:52:54 --> Helper loaded: url_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: file_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: form_helper
INFO - 2023-01-08 13:52:54 --> Helper loaded: my_helper
INFO - 2023-01-08 13:52:55 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:52:55 --> Controller Class Initialized
DEBUG - 2023-01-08 13:52:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-01-08 13:52:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:52:55 --> Final output sent to browser
DEBUG - 2023-01-08 13:52:55 --> Total execution time: 0.0816
INFO - 2023-01-08 13:53:00 --> Config Class Initialized
INFO - 2023-01-08 13:53:00 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:00 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:00 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:00 --> URI Class Initialized
INFO - 2023-01-08 13:53:00 --> Router Class Initialized
INFO - 2023-01-08 13:53:00 --> Output Class Initialized
INFO - 2023-01-08 13:53:00 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:00 --> Input Class Initialized
INFO - 2023-01-08 13:53:00 --> Language Class Initialized
INFO - 2023-01-08 13:53:00 --> Language Class Initialized
INFO - 2023-01-08 13:53:00 --> Config Class Initialized
INFO - 2023-01-08 13:53:00 --> Loader Class Initialized
INFO - 2023-01-08 13:53:00 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:00 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:00 --> Controller Class Initialized
INFO - 2023-01-08 13:53:00 --> Helper loaded: cookie_helper
INFO - 2023-01-08 13:53:00 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:00 --> Total execution time: 0.1027
INFO - 2023-01-08 13:53:00 --> Config Class Initialized
INFO - 2023-01-08 13:53:00 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:00 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:00 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:00 --> URI Class Initialized
INFO - 2023-01-08 13:53:00 --> Router Class Initialized
INFO - 2023-01-08 13:53:00 --> Output Class Initialized
INFO - 2023-01-08 13:53:00 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:00 --> Input Class Initialized
INFO - 2023-01-08 13:53:00 --> Language Class Initialized
INFO - 2023-01-08 13:53:00 --> Language Class Initialized
INFO - 2023-01-08 13:53:00 --> Config Class Initialized
INFO - 2023-01-08 13:53:00 --> Loader Class Initialized
INFO - 2023-01-08 13:53:00 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:00 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:00 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:00 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-01-08 13:53:00 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:00 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:00 --> Total execution time: 0.1327
INFO - 2023-01-08 13:53:03 --> Config Class Initialized
INFO - 2023-01-08 13:53:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:03 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:03 --> URI Class Initialized
INFO - 2023-01-08 13:53:03 --> Router Class Initialized
INFO - 2023-01-08 13:53:03 --> Output Class Initialized
INFO - 2023-01-08 13:53:03 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:03 --> Input Class Initialized
INFO - 2023-01-08 13:53:03 --> Language Class Initialized
INFO - 2023-01-08 13:53:03 --> Language Class Initialized
INFO - 2023-01-08 13:53:03 --> Config Class Initialized
INFO - 2023-01-08 13:53:03 --> Loader Class Initialized
INFO - 2023-01-08 13:53:03 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:03 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:03 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:04 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:04 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:04 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-01-08 13:53:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:04 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:04 --> Total execution time: 0.1052
INFO - 2023-01-08 13:53:07 --> Config Class Initialized
INFO - 2023-01-08 13:53:07 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:07 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:07 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:07 --> URI Class Initialized
INFO - 2023-01-08 13:53:07 --> Router Class Initialized
INFO - 2023-01-08 13:53:07 --> Output Class Initialized
INFO - 2023-01-08 13:53:07 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:07 --> Input Class Initialized
INFO - 2023-01-08 13:53:07 --> Language Class Initialized
INFO - 2023-01-08 13:53:07 --> Language Class Initialized
INFO - 2023-01-08 13:53:07 --> Config Class Initialized
INFO - 2023-01-08 13:53:07 --> Loader Class Initialized
INFO - 2023-01-08 13:53:07 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:07 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:07 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:07 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:07 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:07 --> Controller Class Initialized
INFO - 2023-01-08 13:53:09 --> Config Class Initialized
INFO - 2023-01-08 13:53:09 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:09 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:09 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:09 --> URI Class Initialized
INFO - 2023-01-08 13:53:09 --> Router Class Initialized
INFO - 2023-01-08 13:53:09 --> Output Class Initialized
INFO - 2023-01-08 13:53:09 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:09 --> Input Class Initialized
INFO - 2023-01-08 13:53:09 --> Language Class Initialized
INFO - 2023-01-08 13:53:09 --> Language Class Initialized
INFO - 2023-01-08 13:53:09 --> Config Class Initialized
INFO - 2023-01-08 13:53:09 --> Loader Class Initialized
INFO - 2023-01-08 13:53:09 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:09 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:09 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:09 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:09 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:09 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-01-08 13:53:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:09 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:09 --> Total execution time: 0.0611
INFO - 2023-01-08 13:53:15 --> Config Class Initialized
INFO - 2023-01-08 13:53:15 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:15 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:15 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:15 --> URI Class Initialized
INFO - 2023-01-08 13:53:15 --> Router Class Initialized
INFO - 2023-01-08 13:53:15 --> Output Class Initialized
INFO - 2023-01-08 13:53:15 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:15 --> Input Class Initialized
INFO - 2023-01-08 13:53:15 --> Language Class Initialized
INFO - 2023-01-08 13:53:15 --> Language Class Initialized
INFO - 2023-01-08 13:53:15 --> Config Class Initialized
INFO - 2023-01-08 13:53:15 --> Loader Class Initialized
INFO - 2023-01-08 13:53:15 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:15 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:15 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:15 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:15 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:15 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 13:53:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:15 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:15 --> Total execution time: 0.0460
INFO - 2023-01-08 13:53:16 --> Config Class Initialized
INFO - 2023-01-08 13:53:16 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:16 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:16 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:16 --> URI Class Initialized
INFO - 2023-01-08 13:53:16 --> Router Class Initialized
INFO - 2023-01-08 13:53:16 --> Output Class Initialized
INFO - 2023-01-08 13:53:16 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:16 --> Input Class Initialized
INFO - 2023-01-08 13:53:16 --> Language Class Initialized
INFO - 2023-01-08 13:53:16 --> Language Class Initialized
INFO - 2023-01-08 13:53:16 --> Config Class Initialized
INFO - 2023-01-08 13:53:16 --> Loader Class Initialized
INFO - 2023-01-08 13:53:16 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:16 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:16 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:16 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:17 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:17 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-08 13:53:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:17 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:17 --> Total execution time: 0.0837
INFO - 2023-01-08 13:53:19 --> Config Class Initialized
INFO - 2023-01-08 13:53:19 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:19 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:19 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:19 --> URI Class Initialized
INFO - 2023-01-08 13:53:19 --> Router Class Initialized
INFO - 2023-01-08 13:53:19 --> Output Class Initialized
INFO - 2023-01-08 13:53:19 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:19 --> Input Class Initialized
INFO - 2023-01-08 13:53:19 --> Language Class Initialized
INFO - 2023-01-08 13:53:19 --> Language Class Initialized
INFO - 2023-01-08 13:53:19 --> Config Class Initialized
INFO - 2023-01-08 13:53:19 --> Loader Class Initialized
INFO - 2023-01-08 13:53:19 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:19 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:19 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:19 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:19 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:19 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 13:53:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:19 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:19 --> Total execution time: 0.0499
INFO - 2023-01-08 13:53:21 --> Config Class Initialized
INFO - 2023-01-08 13:53:21 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:21 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:21 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:21 --> URI Class Initialized
INFO - 2023-01-08 13:53:21 --> Router Class Initialized
INFO - 2023-01-08 13:53:21 --> Output Class Initialized
INFO - 2023-01-08 13:53:21 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:21 --> Input Class Initialized
INFO - 2023-01-08 13:53:21 --> Language Class Initialized
INFO - 2023-01-08 13:53:21 --> Language Class Initialized
INFO - 2023-01-08 13:53:21 --> Config Class Initialized
INFO - 2023-01-08 13:53:21 --> Loader Class Initialized
INFO - 2023-01-08 13:53:21 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:21 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:21 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:21 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:21 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:21 --> Controller Class Initialized
DEBUG - 2023-01-08 13:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 13:53:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 13:53:21 --> Final output sent to browser
DEBUG - 2023-01-08 13:53:21 --> Total execution time: 0.0659
INFO - 2023-01-08 13:53:22 --> Config Class Initialized
INFO - 2023-01-08 13:53:22 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:53:22 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:53:22 --> Utf8 Class Initialized
INFO - 2023-01-08 13:53:22 --> URI Class Initialized
INFO - 2023-01-08 13:53:22 --> Router Class Initialized
INFO - 2023-01-08 13:53:22 --> Output Class Initialized
INFO - 2023-01-08 13:53:22 --> Security Class Initialized
DEBUG - 2023-01-08 13:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:53:22 --> Input Class Initialized
INFO - 2023-01-08 13:53:22 --> Language Class Initialized
INFO - 2023-01-08 13:53:22 --> Language Class Initialized
INFO - 2023-01-08 13:53:22 --> Config Class Initialized
INFO - 2023-01-08 13:53:22 --> Loader Class Initialized
INFO - 2023-01-08 13:53:22 --> Helper loaded: url_helper
INFO - 2023-01-08 13:53:22 --> Helper loaded: file_helper
INFO - 2023-01-08 13:53:22 --> Helper loaded: form_helper
INFO - 2023-01-08 13:53:22 --> Helper loaded: my_helper
INFO - 2023-01-08 13:53:22 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:53:22 --> Controller Class Initialized
INFO - 2023-01-08 13:58:29 --> Config Class Initialized
INFO - 2023-01-08 13:58:29 --> Hooks Class Initialized
DEBUG - 2023-01-08 13:58:29 --> UTF-8 Support Enabled
INFO - 2023-01-08 13:58:29 --> Utf8 Class Initialized
INFO - 2023-01-08 13:58:29 --> URI Class Initialized
INFO - 2023-01-08 13:58:29 --> Router Class Initialized
INFO - 2023-01-08 13:58:29 --> Output Class Initialized
INFO - 2023-01-08 13:58:29 --> Security Class Initialized
DEBUG - 2023-01-08 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 13:58:29 --> Input Class Initialized
INFO - 2023-01-08 13:58:29 --> Language Class Initialized
INFO - 2023-01-08 13:58:29 --> Language Class Initialized
INFO - 2023-01-08 13:58:29 --> Config Class Initialized
INFO - 2023-01-08 13:58:29 --> Loader Class Initialized
INFO - 2023-01-08 13:58:29 --> Helper loaded: url_helper
INFO - 2023-01-08 13:58:29 --> Helper loaded: file_helper
INFO - 2023-01-08 13:58:29 --> Helper loaded: form_helper
INFO - 2023-01-08 13:58:29 --> Helper loaded: my_helper
INFO - 2023-01-08 13:58:29 --> Database Driver Class Initialized
DEBUG - 2023-01-08 13:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 13:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 13:58:29 --> Controller Class Initialized
INFO - 2023-01-08 14:00:09 --> Config Class Initialized
INFO - 2023-01-08 14:00:09 --> Hooks Class Initialized
DEBUG - 2023-01-08 14:00:09 --> UTF-8 Support Enabled
INFO - 2023-01-08 14:00:09 --> Utf8 Class Initialized
INFO - 2023-01-08 14:00:09 --> URI Class Initialized
INFO - 2023-01-08 14:00:09 --> Router Class Initialized
INFO - 2023-01-08 14:00:09 --> Output Class Initialized
INFO - 2023-01-08 14:00:09 --> Security Class Initialized
DEBUG - 2023-01-08 14:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 14:00:09 --> Input Class Initialized
INFO - 2023-01-08 14:00:09 --> Language Class Initialized
INFO - 2023-01-08 14:00:09 --> Language Class Initialized
INFO - 2023-01-08 14:00:09 --> Config Class Initialized
INFO - 2023-01-08 14:00:09 --> Loader Class Initialized
INFO - 2023-01-08 14:00:09 --> Helper loaded: url_helper
INFO - 2023-01-08 14:00:09 --> Helper loaded: file_helper
INFO - 2023-01-08 14:00:09 --> Helper loaded: form_helper
INFO - 2023-01-08 14:00:09 --> Helper loaded: my_helper
INFO - 2023-01-08 14:00:09 --> Database Driver Class Initialized
DEBUG - 2023-01-08 14:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 14:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 14:00:09 --> Controller Class Initialized
INFO - 2023-01-08 14:01:31 --> Config Class Initialized
INFO - 2023-01-08 14:01:31 --> Hooks Class Initialized
DEBUG - 2023-01-08 14:01:31 --> UTF-8 Support Enabled
INFO - 2023-01-08 14:01:31 --> Utf8 Class Initialized
INFO - 2023-01-08 14:01:31 --> URI Class Initialized
INFO - 2023-01-08 14:01:31 --> Router Class Initialized
INFO - 2023-01-08 14:01:31 --> Output Class Initialized
INFO - 2023-01-08 14:01:31 --> Security Class Initialized
DEBUG - 2023-01-08 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 14:01:31 --> Input Class Initialized
INFO - 2023-01-08 14:01:31 --> Language Class Initialized
INFO - 2023-01-08 14:01:31 --> Language Class Initialized
INFO - 2023-01-08 14:01:31 --> Config Class Initialized
INFO - 2023-01-08 14:01:31 --> Loader Class Initialized
INFO - 2023-01-08 14:01:31 --> Helper loaded: url_helper
INFO - 2023-01-08 14:01:31 --> Helper loaded: file_helper
INFO - 2023-01-08 14:01:31 --> Helper loaded: form_helper
INFO - 2023-01-08 14:01:31 --> Helper loaded: my_helper
INFO - 2023-01-08 14:01:31 --> Database Driver Class Initialized
DEBUG - 2023-01-08 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 14:01:31 --> Controller Class Initialized
INFO - 2023-01-08 14:03:38 --> Config Class Initialized
INFO - 2023-01-08 14:03:38 --> Hooks Class Initialized
DEBUG - 2023-01-08 14:03:38 --> UTF-8 Support Enabled
INFO - 2023-01-08 14:03:38 --> Utf8 Class Initialized
INFO - 2023-01-08 14:03:38 --> URI Class Initialized
INFO - 2023-01-08 14:03:38 --> Router Class Initialized
INFO - 2023-01-08 14:03:38 --> Output Class Initialized
INFO - 2023-01-08 14:03:38 --> Security Class Initialized
DEBUG - 2023-01-08 14:03:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 14:03:38 --> Input Class Initialized
INFO - 2023-01-08 14:03:38 --> Language Class Initialized
INFO - 2023-01-08 14:03:38 --> Language Class Initialized
INFO - 2023-01-08 14:03:38 --> Config Class Initialized
INFO - 2023-01-08 14:03:38 --> Loader Class Initialized
INFO - 2023-01-08 14:03:38 --> Helper loaded: url_helper
INFO - 2023-01-08 14:03:38 --> Helper loaded: file_helper
INFO - 2023-01-08 14:03:38 --> Helper loaded: form_helper
INFO - 2023-01-08 14:03:38 --> Helper loaded: my_helper
INFO - 2023-01-08 14:03:38 --> Database Driver Class Initialized
DEBUG - 2023-01-08 14:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 14:03:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 14:03:38 --> Controller Class Initialized
INFO - 2023-01-08 15:28:32 --> Config Class Initialized
INFO - 2023-01-08 15:28:32 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:28:32 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:28:32 --> Utf8 Class Initialized
INFO - 2023-01-08 15:28:32 --> URI Class Initialized
INFO - 2023-01-08 15:28:32 --> Router Class Initialized
INFO - 2023-01-08 15:28:32 --> Output Class Initialized
INFO - 2023-01-08 15:28:32 --> Security Class Initialized
DEBUG - 2023-01-08 15:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:28:32 --> Input Class Initialized
INFO - 2023-01-08 15:28:32 --> Language Class Initialized
INFO - 2023-01-08 15:28:32 --> Language Class Initialized
INFO - 2023-01-08 15:28:32 --> Config Class Initialized
INFO - 2023-01-08 15:28:32 --> Loader Class Initialized
INFO - 2023-01-08 15:28:32 --> Helper loaded: url_helper
INFO - 2023-01-08 15:28:32 --> Helper loaded: file_helper
INFO - 2023-01-08 15:28:32 --> Helper loaded: form_helper
INFO - 2023-01-08 15:28:32 --> Helper loaded: my_helper
INFO - 2023-01-08 15:28:32 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:28:32 --> Controller Class Initialized
INFO - 2023-01-08 15:32:37 --> Config Class Initialized
INFO - 2023-01-08 15:32:37 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:32:37 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:32:37 --> Utf8 Class Initialized
INFO - 2023-01-08 15:32:37 --> URI Class Initialized
INFO - 2023-01-08 15:32:37 --> Router Class Initialized
INFO - 2023-01-08 15:32:37 --> Output Class Initialized
INFO - 2023-01-08 15:32:37 --> Security Class Initialized
DEBUG - 2023-01-08 15:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:32:37 --> Input Class Initialized
INFO - 2023-01-08 15:32:37 --> Language Class Initialized
INFO - 2023-01-08 15:32:37 --> Language Class Initialized
INFO - 2023-01-08 15:32:37 --> Config Class Initialized
INFO - 2023-01-08 15:32:37 --> Loader Class Initialized
INFO - 2023-01-08 15:32:37 --> Helper loaded: url_helper
INFO - 2023-01-08 15:32:37 --> Helper loaded: file_helper
INFO - 2023-01-08 15:32:37 --> Helper loaded: form_helper
INFO - 2023-01-08 15:32:37 --> Helper loaded: my_helper
INFO - 2023-01-08 15:32:37 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:32:37 --> Controller Class Initialized
INFO - 2023-01-08 15:39:03 --> Config Class Initialized
INFO - 2023-01-08 15:39:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:39:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:39:03 --> Utf8 Class Initialized
INFO - 2023-01-08 15:39:03 --> URI Class Initialized
INFO - 2023-01-08 15:39:03 --> Router Class Initialized
INFO - 2023-01-08 15:39:03 --> Output Class Initialized
INFO - 2023-01-08 15:39:03 --> Security Class Initialized
DEBUG - 2023-01-08 15:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:39:03 --> Input Class Initialized
INFO - 2023-01-08 15:39:03 --> Language Class Initialized
INFO - 2023-01-08 15:39:03 --> Language Class Initialized
INFO - 2023-01-08 15:39:03 --> Config Class Initialized
INFO - 2023-01-08 15:39:03 --> Loader Class Initialized
INFO - 2023-01-08 15:39:03 --> Helper loaded: url_helper
INFO - 2023-01-08 15:39:03 --> Helper loaded: file_helper
INFO - 2023-01-08 15:39:03 --> Helper loaded: form_helper
INFO - 2023-01-08 15:39:03 --> Helper loaded: my_helper
INFO - 2023-01-08 15:39:03 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:39:03 --> Controller Class Initialized
ERROR - 2023-01-08 15:39:03 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 445
ERROR - 2023-01-08 15:39:03 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 445
INFO - 2023-01-08 15:45:53 --> Config Class Initialized
INFO - 2023-01-08 15:45:53 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:45:53 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:45:53 --> Utf8 Class Initialized
INFO - 2023-01-08 15:45:53 --> URI Class Initialized
INFO - 2023-01-08 15:45:53 --> Router Class Initialized
INFO - 2023-01-08 15:45:53 --> Output Class Initialized
INFO - 2023-01-08 15:45:53 --> Security Class Initialized
DEBUG - 2023-01-08 15:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:45:53 --> Input Class Initialized
INFO - 2023-01-08 15:45:53 --> Language Class Initialized
INFO - 2023-01-08 15:45:53 --> Language Class Initialized
INFO - 2023-01-08 15:45:53 --> Config Class Initialized
INFO - 2023-01-08 15:45:53 --> Loader Class Initialized
INFO - 2023-01-08 15:45:53 --> Helper loaded: url_helper
INFO - 2023-01-08 15:45:53 --> Helper loaded: file_helper
INFO - 2023-01-08 15:45:53 --> Helper loaded: form_helper
INFO - 2023-01-08 15:45:53 --> Helper loaded: my_helper
INFO - 2023-01-08 15:45:53 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:45:53 --> Controller Class Initialized
INFO - 2023-01-08 15:48:11 --> Config Class Initialized
INFO - 2023-01-08 15:48:11 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:48:11 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:48:11 --> Utf8 Class Initialized
INFO - 2023-01-08 15:48:11 --> URI Class Initialized
INFO - 2023-01-08 15:48:11 --> Router Class Initialized
INFO - 2023-01-08 15:48:11 --> Output Class Initialized
INFO - 2023-01-08 15:48:11 --> Security Class Initialized
DEBUG - 2023-01-08 15:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:48:11 --> Input Class Initialized
INFO - 2023-01-08 15:48:11 --> Language Class Initialized
INFO - 2023-01-08 15:48:11 --> Language Class Initialized
INFO - 2023-01-08 15:48:11 --> Config Class Initialized
INFO - 2023-01-08 15:48:11 --> Loader Class Initialized
INFO - 2023-01-08 15:48:11 --> Helper loaded: url_helper
INFO - 2023-01-08 15:48:11 --> Helper loaded: file_helper
INFO - 2023-01-08 15:48:11 --> Helper loaded: form_helper
INFO - 2023-01-08 15:48:11 --> Helper loaded: my_helper
INFO - 2023-01-08 15:48:11 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:48:11 --> Controller Class Initialized
INFO - 2023-01-08 15:50:04 --> Config Class Initialized
INFO - 2023-01-08 15:50:04 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:50:04 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:50:04 --> Utf8 Class Initialized
INFO - 2023-01-08 15:50:04 --> URI Class Initialized
INFO - 2023-01-08 15:50:04 --> Router Class Initialized
INFO - 2023-01-08 15:50:04 --> Output Class Initialized
INFO - 2023-01-08 15:50:04 --> Security Class Initialized
DEBUG - 2023-01-08 15:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:50:04 --> Input Class Initialized
INFO - 2023-01-08 15:50:04 --> Language Class Initialized
INFO - 2023-01-08 15:50:04 --> Language Class Initialized
INFO - 2023-01-08 15:50:04 --> Config Class Initialized
INFO - 2023-01-08 15:50:04 --> Loader Class Initialized
INFO - 2023-01-08 15:50:04 --> Helper loaded: url_helper
INFO - 2023-01-08 15:50:04 --> Helper loaded: file_helper
INFO - 2023-01-08 15:50:04 --> Helper loaded: form_helper
INFO - 2023-01-08 15:50:04 --> Helper loaded: my_helper
INFO - 2023-01-08 15:50:04 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:50:04 --> Controller Class Initialized
ERROR - 2023-01-08 15:50:04 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 345
INFO - 2023-01-08 15:56:38 --> Config Class Initialized
INFO - 2023-01-08 15:56:38 --> Hooks Class Initialized
DEBUG - 2023-01-08 15:56:38 --> UTF-8 Support Enabled
INFO - 2023-01-08 15:56:38 --> Utf8 Class Initialized
INFO - 2023-01-08 15:56:38 --> URI Class Initialized
INFO - 2023-01-08 15:56:38 --> Router Class Initialized
INFO - 2023-01-08 15:56:38 --> Output Class Initialized
INFO - 2023-01-08 15:56:38 --> Security Class Initialized
DEBUG - 2023-01-08 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 15:56:38 --> Input Class Initialized
INFO - 2023-01-08 15:56:38 --> Language Class Initialized
INFO - 2023-01-08 15:56:38 --> Language Class Initialized
INFO - 2023-01-08 15:56:38 --> Config Class Initialized
INFO - 2023-01-08 15:56:38 --> Loader Class Initialized
INFO - 2023-01-08 15:56:38 --> Helper loaded: url_helper
INFO - 2023-01-08 15:56:38 --> Helper loaded: file_helper
INFO - 2023-01-08 15:56:38 --> Helper loaded: form_helper
INFO - 2023-01-08 15:56:38 --> Helper loaded: my_helper
INFO - 2023-01-08 15:56:38 --> Database Driver Class Initialized
DEBUG - 2023-01-08 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 15:56:38 --> Controller Class Initialized
INFO - 2023-01-08 16:00:42 --> Config Class Initialized
INFO - 2023-01-08 16:00:42 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:00:42 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:00:42 --> Utf8 Class Initialized
INFO - 2023-01-08 16:00:42 --> URI Class Initialized
INFO - 2023-01-08 16:00:42 --> Router Class Initialized
INFO - 2023-01-08 16:00:42 --> Output Class Initialized
INFO - 2023-01-08 16:00:42 --> Security Class Initialized
DEBUG - 2023-01-08 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:00:42 --> Input Class Initialized
INFO - 2023-01-08 16:00:42 --> Language Class Initialized
INFO - 2023-01-08 16:00:42 --> Language Class Initialized
INFO - 2023-01-08 16:00:42 --> Config Class Initialized
INFO - 2023-01-08 16:00:42 --> Loader Class Initialized
INFO - 2023-01-08 16:00:42 --> Helper loaded: url_helper
INFO - 2023-01-08 16:00:42 --> Helper loaded: file_helper
INFO - 2023-01-08 16:00:42 --> Helper loaded: form_helper
INFO - 2023-01-08 16:00:42 --> Helper loaded: my_helper
INFO - 2023-01-08 16:00:42 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:00:42 --> Controller Class Initialized
DEBUG - 2023-01-08 16:00:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 16:00:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:00:42 --> Final output sent to browser
DEBUG - 2023-01-08 16:00:42 --> Total execution time: 0.0356
INFO - 2023-01-08 16:11:19 --> Config Class Initialized
INFO - 2023-01-08 16:11:19 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:19 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:19 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:19 --> URI Class Initialized
INFO - 2023-01-08 16:11:19 --> Router Class Initialized
INFO - 2023-01-08 16:11:19 --> Output Class Initialized
INFO - 2023-01-08 16:11:19 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:19 --> Input Class Initialized
INFO - 2023-01-08 16:11:19 --> Language Class Initialized
INFO - 2023-01-08 16:11:19 --> Language Class Initialized
INFO - 2023-01-08 16:11:19 --> Config Class Initialized
INFO - 2023-01-08 16:11:19 --> Loader Class Initialized
INFO - 2023-01-08 16:11:19 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:19 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:19 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:19 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:19 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:19 --> Controller Class Initialized
DEBUG - 2023-01-08 16:11:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2023-01-08 16:11:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:11:19 --> Final output sent to browser
DEBUG - 2023-01-08 16:11:19 --> Total execution time: 0.0345
INFO - 2023-01-08 16:11:22 --> Config Class Initialized
INFO - 2023-01-08 16:11:22 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:22 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:22 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:22 --> URI Class Initialized
INFO - 2023-01-08 16:11:22 --> Router Class Initialized
INFO - 2023-01-08 16:11:22 --> Output Class Initialized
INFO - 2023-01-08 16:11:22 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:22 --> Input Class Initialized
INFO - 2023-01-08 16:11:22 --> Language Class Initialized
INFO - 2023-01-08 16:11:22 --> Language Class Initialized
INFO - 2023-01-08 16:11:22 --> Config Class Initialized
INFO - 2023-01-08 16:11:22 --> Loader Class Initialized
INFO - 2023-01-08 16:11:22 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:22 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:22 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:22 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:22 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:22 --> Controller Class Initialized
DEBUG - 2023-01-08 16:11:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-01-08 16:11:22 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:11:22 --> Final output sent to browser
DEBUG - 2023-01-08 16:11:22 --> Total execution time: 0.0287
INFO - 2023-01-08 16:11:24 --> Config Class Initialized
INFO - 2023-01-08 16:11:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:24 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:24 --> URI Class Initialized
INFO - 2023-01-08 16:11:24 --> Router Class Initialized
INFO - 2023-01-08 16:11:24 --> Output Class Initialized
INFO - 2023-01-08 16:11:24 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:24 --> Input Class Initialized
INFO - 2023-01-08 16:11:24 --> Language Class Initialized
INFO - 2023-01-08 16:11:24 --> Language Class Initialized
INFO - 2023-01-08 16:11:24 --> Config Class Initialized
INFO - 2023-01-08 16:11:24 --> Loader Class Initialized
INFO - 2023-01-08 16:11:24 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:24 --> Controller Class Initialized
DEBUG - 2023-01-08 16:11:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 16:11:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:11:24 --> Final output sent to browser
DEBUG - 2023-01-08 16:11:24 --> Total execution time: 0.0316
INFO - 2023-01-08 16:11:24 --> Config Class Initialized
INFO - 2023-01-08 16:11:24 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:24 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:24 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:24 --> URI Class Initialized
INFO - 2023-01-08 16:11:24 --> Router Class Initialized
INFO - 2023-01-08 16:11:24 --> Output Class Initialized
INFO - 2023-01-08 16:11:24 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:24 --> Input Class Initialized
INFO - 2023-01-08 16:11:24 --> Language Class Initialized
INFO - 2023-01-08 16:11:24 --> Language Class Initialized
INFO - 2023-01-08 16:11:24 --> Config Class Initialized
INFO - 2023-01-08 16:11:24 --> Loader Class Initialized
INFO - 2023-01-08 16:11:24 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:24 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:24 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:24 --> Controller Class Initialized
INFO - 2023-01-08 16:11:26 --> Config Class Initialized
INFO - 2023-01-08 16:11:26 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:26 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:26 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:26 --> URI Class Initialized
INFO - 2023-01-08 16:11:26 --> Router Class Initialized
INFO - 2023-01-08 16:11:26 --> Output Class Initialized
INFO - 2023-01-08 16:11:26 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:26 --> Input Class Initialized
INFO - 2023-01-08 16:11:26 --> Language Class Initialized
INFO - 2023-01-08 16:11:26 --> Language Class Initialized
INFO - 2023-01-08 16:11:26 --> Config Class Initialized
INFO - 2023-01-08 16:11:26 --> Loader Class Initialized
INFO - 2023-01-08 16:11:26 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:26 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:26 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:26 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:26 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:26 --> Controller Class Initialized
INFO - 2023-01-08 16:11:45 --> Config Class Initialized
INFO - 2023-01-08 16:11:45 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:45 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:45 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:45 --> URI Class Initialized
INFO - 2023-01-08 16:11:45 --> Router Class Initialized
INFO - 2023-01-08 16:11:45 --> Output Class Initialized
INFO - 2023-01-08 16:11:45 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:45 --> Input Class Initialized
INFO - 2023-01-08 16:11:45 --> Language Class Initialized
INFO - 2023-01-08 16:11:45 --> Language Class Initialized
INFO - 2023-01-08 16:11:45 --> Config Class Initialized
INFO - 2023-01-08 16:11:45 --> Loader Class Initialized
INFO - 2023-01-08 16:11:45 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:45 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:45 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:45 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:45 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:45 --> Controller Class Initialized
DEBUG - 2023-01-08 16:11:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 16:11:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:11:45 --> Final output sent to browser
DEBUG - 2023-01-08 16:11:45 --> Total execution time: 0.0310
INFO - 2023-01-08 16:11:54 --> Config Class Initialized
INFO - 2023-01-08 16:11:54 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:11:54 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:11:54 --> Utf8 Class Initialized
INFO - 2023-01-08 16:11:54 --> URI Class Initialized
INFO - 2023-01-08 16:11:54 --> Router Class Initialized
INFO - 2023-01-08 16:11:54 --> Output Class Initialized
INFO - 2023-01-08 16:11:54 --> Security Class Initialized
DEBUG - 2023-01-08 16:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:11:54 --> Input Class Initialized
INFO - 2023-01-08 16:11:54 --> Language Class Initialized
INFO - 2023-01-08 16:11:54 --> Language Class Initialized
INFO - 2023-01-08 16:11:54 --> Config Class Initialized
INFO - 2023-01-08 16:11:54 --> Loader Class Initialized
INFO - 2023-01-08 16:11:54 --> Helper loaded: url_helper
INFO - 2023-01-08 16:11:54 --> Helper loaded: file_helper
INFO - 2023-01-08 16:11:54 --> Helper loaded: form_helper
INFO - 2023-01-08 16:11:54 --> Helper loaded: my_helper
INFO - 2023-01-08 16:11:54 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:11:54 --> Controller Class Initialized
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:11:54 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\helpers\url_helper.php 564
INFO - 2023-01-08 16:12:53 --> Config Class Initialized
INFO - 2023-01-08 16:12:53 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:12:53 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:12:53 --> Utf8 Class Initialized
INFO - 2023-01-08 16:12:53 --> URI Class Initialized
INFO - 2023-01-08 16:12:53 --> Router Class Initialized
INFO - 2023-01-08 16:12:53 --> Output Class Initialized
INFO - 2023-01-08 16:12:53 --> Security Class Initialized
DEBUG - 2023-01-08 16:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:12:53 --> Input Class Initialized
INFO - 2023-01-08 16:12:53 --> Language Class Initialized
INFO - 2023-01-08 16:12:53 --> Language Class Initialized
INFO - 2023-01-08 16:12:53 --> Config Class Initialized
INFO - 2023-01-08 16:12:53 --> Loader Class Initialized
INFO - 2023-01-08 16:12:53 --> Helper loaded: url_helper
INFO - 2023-01-08 16:12:53 --> Helper loaded: file_helper
INFO - 2023-01-08 16:12:53 --> Helper loaded: form_helper
INFO - 2023-01-08 16:12:53 --> Helper loaded: my_helper
INFO - 2023-01-08 16:12:53 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:12:53 --> Controller Class Initialized
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Notice --> Undefined index: catatan C:\xampp\htdocs\myraportk13\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 658
ERROR - 2023-01-08 16:12:53 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\myraportk13\system\core\Exceptions.php:271) C:\xampp\htdocs\myraportk13\system\helpers\url_helper.php 564
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:15:56 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:15:56 --> Utf8 Class Initialized
INFO - 2023-01-08 16:15:56 --> URI Class Initialized
INFO - 2023-01-08 16:15:56 --> Router Class Initialized
INFO - 2023-01-08 16:15:56 --> Output Class Initialized
INFO - 2023-01-08 16:15:56 --> Security Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:15:56 --> Input Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Loader Class Initialized
INFO - 2023-01-08 16:15:56 --> Helper loaded: url_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: file_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: form_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: my_helper
INFO - 2023-01-08 16:15:56 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:15:56 --> Controller Class Initialized
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:15:56 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:15:56 --> Utf8 Class Initialized
INFO - 2023-01-08 16:15:56 --> URI Class Initialized
INFO - 2023-01-08 16:15:56 --> Router Class Initialized
INFO - 2023-01-08 16:15:56 --> Output Class Initialized
INFO - 2023-01-08 16:15:56 --> Security Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:15:56 --> Input Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Loader Class Initialized
INFO - 2023-01-08 16:15:56 --> Helper loaded: url_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: file_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: form_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: my_helper
INFO - 2023-01-08 16:15:56 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:15:56 --> Controller Class Initialized
DEBUG - 2023-01-08 16:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 16:15:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:15:56 --> Final output sent to browser
DEBUG - 2023-01-08 16:15:56 --> Total execution time: 0.0371
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:15:56 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:15:56 --> Utf8 Class Initialized
INFO - 2023-01-08 16:15:56 --> URI Class Initialized
INFO - 2023-01-08 16:15:56 --> Router Class Initialized
INFO - 2023-01-08 16:15:56 --> Output Class Initialized
INFO - 2023-01-08 16:15:56 --> Security Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:15:56 --> Input Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Language Class Initialized
INFO - 2023-01-08 16:15:56 --> Config Class Initialized
INFO - 2023-01-08 16:15:56 --> Loader Class Initialized
INFO - 2023-01-08 16:15:56 --> Helper loaded: url_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: file_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: form_helper
INFO - 2023-01-08 16:15:56 --> Helper loaded: my_helper
INFO - 2023-01-08 16:15:56 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:15:56 --> Controller Class Initialized
INFO - 2023-01-08 16:16:52 --> Config Class Initialized
INFO - 2023-01-08 16:16:52 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:16:52 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:16:52 --> Utf8 Class Initialized
INFO - 2023-01-08 16:16:52 --> URI Class Initialized
INFO - 2023-01-08 16:16:52 --> Router Class Initialized
INFO - 2023-01-08 16:16:52 --> Output Class Initialized
INFO - 2023-01-08 16:16:52 --> Security Class Initialized
DEBUG - 2023-01-08 16:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:16:52 --> Input Class Initialized
INFO - 2023-01-08 16:16:52 --> Language Class Initialized
INFO - 2023-01-08 16:16:52 --> Language Class Initialized
INFO - 2023-01-08 16:16:52 --> Config Class Initialized
INFO - 2023-01-08 16:16:52 --> Loader Class Initialized
INFO - 2023-01-08 16:16:52 --> Helper loaded: url_helper
INFO - 2023-01-08 16:16:52 --> Helper loaded: file_helper
INFO - 2023-01-08 16:16:52 --> Helper loaded: form_helper
INFO - 2023-01-08 16:16:52 --> Helper loaded: my_helper
INFO - 2023-01-08 16:16:52 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:16:52 --> Controller Class Initialized
DEBUG - 2023-01-08 16:16:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 16:16:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:16:52 --> Final output sent to browser
DEBUG - 2023-01-08 16:16:52 --> Total execution time: 0.0681
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:16:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:16:59 --> Utf8 Class Initialized
INFO - 2023-01-08 16:16:59 --> URI Class Initialized
INFO - 2023-01-08 16:16:59 --> Router Class Initialized
INFO - 2023-01-08 16:16:59 --> Output Class Initialized
INFO - 2023-01-08 16:16:59 --> Security Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:16:59 --> Input Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Loader Class Initialized
INFO - 2023-01-08 16:16:59 --> Helper loaded: url_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: file_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: form_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: my_helper
INFO - 2023-01-08 16:16:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:16:59 --> Controller Class Initialized
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:16:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:16:59 --> Utf8 Class Initialized
INFO - 2023-01-08 16:16:59 --> URI Class Initialized
INFO - 2023-01-08 16:16:59 --> Router Class Initialized
INFO - 2023-01-08 16:16:59 --> Output Class Initialized
INFO - 2023-01-08 16:16:59 --> Security Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:16:59 --> Input Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Loader Class Initialized
INFO - 2023-01-08 16:16:59 --> Helper loaded: url_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: file_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: form_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: my_helper
INFO - 2023-01-08 16:16:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:16:59 --> Controller Class Initialized
DEBUG - 2023-01-08 16:16:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 16:16:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:16:59 --> Final output sent to browser
DEBUG - 2023-01-08 16:16:59 --> Total execution time: 0.0430
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:16:59 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:16:59 --> Utf8 Class Initialized
INFO - 2023-01-08 16:16:59 --> URI Class Initialized
INFO - 2023-01-08 16:16:59 --> Router Class Initialized
INFO - 2023-01-08 16:16:59 --> Output Class Initialized
INFO - 2023-01-08 16:16:59 --> Security Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:16:59 --> Input Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Language Class Initialized
INFO - 2023-01-08 16:16:59 --> Config Class Initialized
INFO - 2023-01-08 16:16:59 --> Loader Class Initialized
INFO - 2023-01-08 16:16:59 --> Helper loaded: url_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: file_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: form_helper
INFO - 2023-01-08 16:16:59 --> Helper loaded: my_helper
INFO - 2023-01-08 16:16:59 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:16:59 --> Controller Class Initialized
INFO - 2023-01-08 16:20:36 --> Config Class Initialized
INFO - 2023-01-08 16:20:36 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:20:36 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:20:36 --> Utf8 Class Initialized
INFO - 2023-01-08 16:20:36 --> URI Class Initialized
INFO - 2023-01-08 16:20:36 --> Router Class Initialized
INFO - 2023-01-08 16:20:36 --> Output Class Initialized
INFO - 2023-01-08 16:20:36 --> Security Class Initialized
DEBUG - 2023-01-08 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:20:37 --> Input Class Initialized
INFO - 2023-01-08 16:20:37 --> Language Class Initialized
INFO - 2023-01-08 16:20:37 --> Language Class Initialized
INFO - 2023-01-08 16:20:37 --> Config Class Initialized
INFO - 2023-01-08 16:20:37 --> Loader Class Initialized
INFO - 2023-01-08 16:20:37 --> Helper loaded: url_helper
INFO - 2023-01-08 16:20:37 --> Helper loaded: file_helper
INFO - 2023-01-08 16:20:37 --> Helper loaded: form_helper
INFO - 2023-01-08 16:20:37 --> Helper loaded: my_helper
INFO - 2023-01-08 16:20:37 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:20:37 --> Controller Class Initialized
DEBUG - 2023-01-08 16:20:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/form.php
DEBUG - 2023-01-08 16:20:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:20:37 --> Final output sent to browser
DEBUG - 2023-01-08 16:20:37 --> Total execution time: 0.7010
INFO - 2023-01-08 16:20:42 --> Config Class Initialized
INFO - 2023-01-08 16:20:42 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:20:42 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:20:42 --> Utf8 Class Initialized
INFO - 2023-01-08 16:20:42 --> URI Class Initialized
INFO - 2023-01-08 16:20:42 --> Router Class Initialized
INFO - 2023-01-08 16:20:42 --> Output Class Initialized
INFO - 2023-01-08 16:20:42 --> Security Class Initialized
DEBUG - 2023-01-08 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:20:42 --> Input Class Initialized
INFO - 2023-01-08 16:20:42 --> Language Class Initialized
INFO - 2023-01-08 16:20:42 --> Language Class Initialized
INFO - 2023-01-08 16:20:42 --> Config Class Initialized
INFO - 2023-01-08 16:20:42 --> Loader Class Initialized
INFO - 2023-01-08 16:20:42 --> Helper loaded: url_helper
INFO - 2023-01-08 16:20:42 --> Helper loaded: file_helper
INFO - 2023-01-08 16:20:42 --> Helper loaded: form_helper
INFO - 2023-01-08 16:20:42 --> Helper loaded: my_helper
INFO - 2023-01-08 16:20:42 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:20:42 --> Controller Class Initialized
INFO - 2023-01-08 16:20:43 --> Config Class Initialized
INFO - 2023-01-08 16:20:43 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:20:43 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:20:43 --> Utf8 Class Initialized
INFO - 2023-01-08 16:20:43 --> URI Class Initialized
INFO - 2023-01-08 16:20:43 --> Router Class Initialized
INFO - 2023-01-08 16:20:43 --> Output Class Initialized
INFO - 2023-01-08 16:20:43 --> Security Class Initialized
DEBUG - 2023-01-08 16:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:20:43 --> Input Class Initialized
INFO - 2023-01-08 16:20:43 --> Language Class Initialized
INFO - 2023-01-08 16:20:43 --> Language Class Initialized
INFO - 2023-01-08 16:20:43 --> Config Class Initialized
INFO - 2023-01-08 16:20:43 --> Loader Class Initialized
INFO - 2023-01-08 16:20:43 --> Helper loaded: url_helper
INFO - 2023-01-08 16:20:43 --> Helper loaded: file_helper
INFO - 2023-01-08 16:20:43 --> Helper loaded: form_helper
INFO - 2023-01-08 16:20:43 --> Helper loaded: my_helper
INFO - 2023-01-08 16:20:43 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:20:43 --> Controller Class Initialized
DEBUG - 2023-01-08 16:20:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-01-08 16:20:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-01-08 16:20:43 --> Final output sent to browser
DEBUG - 2023-01-08 16:20:43 --> Total execution time: 0.0818
INFO - 2023-01-08 16:20:44 --> Config Class Initialized
INFO - 2023-01-08 16:20:44 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:20:44 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:20:44 --> Utf8 Class Initialized
INFO - 2023-01-08 16:20:44 --> URI Class Initialized
INFO - 2023-01-08 16:20:44 --> Router Class Initialized
INFO - 2023-01-08 16:20:44 --> Output Class Initialized
INFO - 2023-01-08 16:20:44 --> Security Class Initialized
DEBUG - 2023-01-08 16:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:20:44 --> Input Class Initialized
INFO - 2023-01-08 16:20:44 --> Language Class Initialized
INFO - 2023-01-08 16:20:44 --> Language Class Initialized
INFO - 2023-01-08 16:20:44 --> Config Class Initialized
INFO - 2023-01-08 16:20:44 --> Loader Class Initialized
INFO - 2023-01-08 16:20:44 --> Helper loaded: url_helper
INFO - 2023-01-08 16:20:44 --> Helper loaded: file_helper
INFO - 2023-01-08 16:20:44 --> Helper loaded: form_helper
INFO - 2023-01-08 16:20:44 --> Helper loaded: my_helper
INFO - 2023-01-08 16:20:44 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:20:44 --> Controller Class Initialized
INFO - 2023-01-08 16:21:03 --> Config Class Initialized
INFO - 2023-01-08 16:21:03 --> Hooks Class Initialized
DEBUG - 2023-01-08 16:21:03 --> UTF-8 Support Enabled
INFO - 2023-01-08 16:21:03 --> Utf8 Class Initialized
INFO - 2023-01-08 16:21:03 --> URI Class Initialized
INFO - 2023-01-08 16:21:03 --> Router Class Initialized
INFO - 2023-01-08 16:21:03 --> Output Class Initialized
INFO - 2023-01-08 16:21:03 --> Security Class Initialized
DEBUG - 2023-01-08 16:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-01-08 16:21:03 --> Input Class Initialized
INFO - 2023-01-08 16:21:03 --> Language Class Initialized
INFO - 2023-01-08 16:21:03 --> Language Class Initialized
INFO - 2023-01-08 16:21:03 --> Config Class Initialized
INFO - 2023-01-08 16:21:03 --> Loader Class Initialized
INFO - 2023-01-08 16:21:03 --> Helper loaded: url_helper
INFO - 2023-01-08 16:21:03 --> Helper loaded: file_helper
INFO - 2023-01-08 16:21:03 --> Helper loaded: form_helper
INFO - 2023-01-08 16:21:03 --> Helper loaded: my_helper
INFO - 2023-01-08 16:21:03 --> Database Driver Class Initialized
DEBUG - 2023-01-08 16:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-01-08 16:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-01-08 16:21:03 --> Controller Class Initialized
