<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-06 09:27:49 --> Config Class Initialized
INFO - 2024-03-06 09:27:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:49 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:49 --> URI Class Initialized
DEBUG - 2024-03-06 09:27:49 --> No URI present. Default controller set.
INFO - 2024-03-06 09:27:49 --> Router Class Initialized
INFO - 2024-03-06 09:27:49 --> Output Class Initialized
INFO - 2024-03-06 09:27:49 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:49 --> Input Class Initialized
INFO - 2024-03-06 09:27:49 --> Language Class Initialized
INFO - 2024-03-06 09:27:49 --> Language Class Initialized
INFO - 2024-03-06 09:27:49 --> Config Class Initialized
INFO - 2024-03-06 09:27:49 --> Loader Class Initialized
INFO - 2024-03-06 09:27:49 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:49 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:49 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:49 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:49 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:49 --> Controller Class Initialized
DEBUG - 2024-03-06 09:27:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 09:27:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 09:27:49 --> Final output sent to browser
DEBUG - 2024-03-06 09:27:49 --> Total execution time: 0.0815
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:53 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:53 --> URI Class Initialized
INFO - 2024-03-06 09:27:53 --> Router Class Initialized
INFO - 2024-03-06 09:27:53 --> Output Class Initialized
INFO - 2024-03-06 09:27:53 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:53 --> Input Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Loader Class Initialized
INFO - 2024-03-06 09:27:53 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:53 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:53 --> Controller Class Initialized
INFO - 2024-03-06 09:27:53 --> Helper loaded: cookie_helper
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:53 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:53 --> URI Class Initialized
INFO - 2024-03-06 09:27:53 --> Router Class Initialized
INFO - 2024-03-06 09:27:53 --> Output Class Initialized
INFO - 2024-03-06 09:27:53 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:53 --> Input Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Loader Class Initialized
INFO - 2024-03-06 09:27:53 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:53 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:53 --> Controller Class Initialized
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:53 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:53 --> URI Class Initialized
INFO - 2024-03-06 09:27:53 --> Router Class Initialized
INFO - 2024-03-06 09:27:53 --> Output Class Initialized
INFO - 2024-03-06 09:27:53 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:53 --> Input Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Language Class Initialized
INFO - 2024-03-06 09:27:53 --> Config Class Initialized
INFO - 2024-03-06 09:27:53 --> Loader Class Initialized
INFO - 2024-03-06 09:27:53 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:53 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:53 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:53 --> Controller Class Initialized
DEBUG - 2024-03-06 09:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 09:27:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 09:27:53 --> Final output sent to browser
DEBUG - 2024-03-06 09:27:53 --> Total execution time: 0.0474
INFO - 2024-03-06 09:27:58 --> Config Class Initialized
INFO - 2024-03-06 09:27:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:58 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:58 --> URI Class Initialized
INFO - 2024-03-06 09:27:58 --> Router Class Initialized
INFO - 2024-03-06 09:27:58 --> Output Class Initialized
INFO - 2024-03-06 09:27:58 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:58 --> Input Class Initialized
INFO - 2024-03-06 09:27:58 --> Language Class Initialized
INFO - 2024-03-06 09:27:58 --> Language Class Initialized
INFO - 2024-03-06 09:27:58 --> Config Class Initialized
INFO - 2024-03-06 09:27:58 --> Loader Class Initialized
INFO - 2024-03-06 09:27:58 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:58 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:58 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:58 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:58 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:58 --> Controller Class Initialized
INFO - 2024-03-06 09:27:59 --> Helper loaded: cookie_helper
INFO - 2024-03-06 09:27:59 --> Final output sent to browser
DEBUG - 2024-03-06 09:27:59 --> Total execution time: 0.3138
INFO - 2024-03-06 09:27:59 --> Config Class Initialized
INFO - 2024-03-06 09:27:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:27:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:27:59 --> Utf8 Class Initialized
INFO - 2024-03-06 09:27:59 --> URI Class Initialized
INFO - 2024-03-06 09:27:59 --> Router Class Initialized
INFO - 2024-03-06 09:27:59 --> Output Class Initialized
INFO - 2024-03-06 09:27:59 --> Security Class Initialized
DEBUG - 2024-03-06 09:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:27:59 --> Input Class Initialized
INFO - 2024-03-06 09:27:59 --> Language Class Initialized
INFO - 2024-03-06 09:27:59 --> Language Class Initialized
INFO - 2024-03-06 09:27:59 --> Config Class Initialized
INFO - 2024-03-06 09:27:59 --> Loader Class Initialized
INFO - 2024-03-06 09:27:59 --> Helper loaded: url_helper
INFO - 2024-03-06 09:27:59 --> Helper loaded: file_helper
INFO - 2024-03-06 09:27:59 --> Helper loaded: form_helper
INFO - 2024-03-06 09:27:59 --> Helper loaded: my_helper
INFO - 2024-03-06 09:27:59 --> Database Driver Class Initialized
INFO - 2024-03-06 09:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:27:59 --> Controller Class Initialized
DEBUG - 2024-03-06 09:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 09:27:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 09:27:59 --> Final output sent to browser
DEBUG - 2024-03-06 09:27:59 --> Total execution time: 0.0343
INFO - 2024-03-06 09:28:05 --> Config Class Initialized
INFO - 2024-03-06 09:28:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:28:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:28:05 --> Utf8 Class Initialized
INFO - 2024-03-06 09:28:05 --> URI Class Initialized
INFO - 2024-03-06 09:28:05 --> Router Class Initialized
INFO - 2024-03-06 09:28:05 --> Output Class Initialized
INFO - 2024-03-06 09:28:05 --> Security Class Initialized
DEBUG - 2024-03-06 09:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:28:05 --> Input Class Initialized
INFO - 2024-03-06 09:28:05 --> Language Class Initialized
INFO - 2024-03-06 09:28:05 --> Language Class Initialized
INFO - 2024-03-06 09:28:05 --> Config Class Initialized
INFO - 2024-03-06 09:28:05 --> Loader Class Initialized
INFO - 2024-03-06 09:28:05 --> Helper loaded: url_helper
INFO - 2024-03-06 09:28:05 --> Helper loaded: file_helper
INFO - 2024-03-06 09:28:05 --> Helper loaded: form_helper
INFO - 2024-03-06 09:28:05 --> Helper loaded: my_helper
INFO - 2024-03-06 09:28:05 --> Database Driver Class Initialized
INFO - 2024-03-06 09:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:28:05 --> Controller Class Initialized
DEBUG - 2024-03-06 09:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 09:28:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 09:28:05 --> Final output sent to browser
DEBUG - 2024-03-06 09:28:05 --> Total execution time: 0.0582
INFO - 2024-03-06 09:28:07 --> Config Class Initialized
INFO - 2024-03-06 09:28:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 09:28:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 09:28:07 --> Utf8 Class Initialized
INFO - 2024-03-06 09:28:07 --> URI Class Initialized
DEBUG - 2024-03-06 09:28:07 --> No URI present. Default controller set.
INFO - 2024-03-06 09:28:07 --> Router Class Initialized
INFO - 2024-03-06 09:28:07 --> Output Class Initialized
INFO - 2024-03-06 09:28:07 --> Security Class Initialized
DEBUG - 2024-03-06 09:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 09:28:07 --> Input Class Initialized
INFO - 2024-03-06 09:28:07 --> Language Class Initialized
INFO - 2024-03-06 09:28:07 --> Language Class Initialized
INFO - 2024-03-06 09:28:07 --> Config Class Initialized
INFO - 2024-03-06 09:28:07 --> Loader Class Initialized
INFO - 2024-03-06 09:28:07 --> Helper loaded: url_helper
INFO - 2024-03-06 09:28:07 --> Helper loaded: file_helper
INFO - 2024-03-06 09:28:07 --> Helper loaded: form_helper
INFO - 2024-03-06 09:28:07 --> Helper loaded: my_helper
INFO - 2024-03-06 09:28:07 --> Database Driver Class Initialized
INFO - 2024-03-06 09:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 09:28:07 --> Controller Class Initialized
DEBUG - 2024-03-06 09:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 09:28:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 09:28:07 --> Final output sent to browser
DEBUG - 2024-03-06 09:28:07 --> Total execution time: 0.0288
INFO - 2024-03-06 13:10:50 --> Config Class Initialized
INFO - 2024-03-06 13:10:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:50 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:50 --> URI Class Initialized
DEBUG - 2024-03-06 13:10:50 --> No URI present. Default controller set.
INFO - 2024-03-06 13:10:50 --> Router Class Initialized
INFO - 2024-03-06 13:10:50 --> Output Class Initialized
INFO - 2024-03-06 13:10:50 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:50 --> Input Class Initialized
INFO - 2024-03-06 13:10:50 --> Language Class Initialized
INFO - 2024-03-06 13:10:50 --> Language Class Initialized
INFO - 2024-03-06 13:10:50 --> Config Class Initialized
INFO - 2024-03-06 13:10:50 --> Loader Class Initialized
INFO - 2024-03-06 13:10:50 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:50 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:50 --> Controller Class Initialized
INFO - 2024-03-06 13:10:50 --> Config Class Initialized
INFO - 2024-03-06 13:10:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:50 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:50 --> URI Class Initialized
INFO - 2024-03-06 13:10:50 --> Router Class Initialized
INFO - 2024-03-06 13:10:50 --> Output Class Initialized
INFO - 2024-03-06 13:10:50 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:50 --> Input Class Initialized
INFO - 2024-03-06 13:10:50 --> Language Class Initialized
INFO - 2024-03-06 13:10:50 --> Language Class Initialized
INFO - 2024-03-06 13:10:50 --> Config Class Initialized
INFO - 2024-03-06 13:10:50 --> Loader Class Initialized
INFO - 2024-03-06 13:10:50 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:50 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:50 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:50 --> Controller Class Initialized
DEBUG - 2024-03-06 13:10:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 13:10:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:10:50 --> Final output sent to browser
DEBUG - 2024-03-06 13:10:50 --> Total execution time: 0.0464
INFO - 2024-03-06 13:10:54 --> Config Class Initialized
INFO - 2024-03-06 13:10:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:54 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:54 --> URI Class Initialized
INFO - 2024-03-06 13:10:54 --> Router Class Initialized
INFO - 2024-03-06 13:10:54 --> Output Class Initialized
INFO - 2024-03-06 13:10:54 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:54 --> Input Class Initialized
INFO - 2024-03-06 13:10:54 --> Language Class Initialized
INFO - 2024-03-06 13:10:54 --> Language Class Initialized
INFO - 2024-03-06 13:10:54 --> Config Class Initialized
INFO - 2024-03-06 13:10:54 --> Loader Class Initialized
INFO - 2024-03-06 13:10:54 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:54 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:54 --> Controller Class Initialized
INFO - 2024-03-06 13:10:54 --> Helper loaded: cookie_helper
INFO - 2024-03-06 13:10:54 --> Final output sent to browser
DEBUG - 2024-03-06 13:10:54 --> Total execution time: 0.1855
INFO - 2024-03-06 13:10:54 --> Config Class Initialized
INFO - 2024-03-06 13:10:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:54 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:54 --> URI Class Initialized
INFO - 2024-03-06 13:10:54 --> Router Class Initialized
INFO - 2024-03-06 13:10:54 --> Output Class Initialized
INFO - 2024-03-06 13:10:54 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:54 --> Input Class Initialized
INFO - 2024-03-06 13:10:54 --> Language Class Initialized
INFO - 2024-03-06 13:10:54 --> Language Class Initialized
INFO - 2024-03-06 13:10:54 --> Config Class Initialized
INFO - 2024-03-06 13:10:54 --> Loader Class Initialized
INFO - 2024-03-06 13:10:54 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:54 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:54 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:54 --> Controller Class Initialized
DEBUG - 2024-03-06 13:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 13:10:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:10:55 --> Final output sent to browser
DEBUG - 2024-03-06 13:10:55 --> Total execution time: 0.9882
INFO - 2024-03-06 13:10:58 --> Config Class Initialized
INFO - 2024-03-06 13:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:58 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:58 --> URI Class Initialized
INFO - 2024-03-06 13:10:58 --> Router Class Initialized
INFO - 2024-03-06 13:10:58 --> Output Class Initialized
INFO - 2024-03-06 13:10:58 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:58 --> Input Class Initialized
INFO - 2024-03-06 13:10:58 --> Language Class Initialized
INFO - 2024-03-06 13:10:58 --> Language Class Initialized
INFO - 2024-03-06 13:10:58 --> Config Class Initialized
INFO - 2024-03-06 13:10:58 --> Loader Class Initialized
INFO - 2024-03-06 13:10:58 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:58 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:58 --> Controller Class Initialized
DEBUG - 2024-03-06 13:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-06 13:10:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:10:58 --> Final output sent to browser
DEBUG - 2024-03-06 13:10:58 --> Total execution time: 0.0415
INFO - 2024-03-06 13:10:58 --> Config Class Initialized
INFO - 2024-03-06 13:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:58 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:58 --> URI Class Initialized
INFO - 2024-03-06 13:10:58 --> Router Class Initialized
INFO - 2024-03-06 13:10:58 --> Output Class Initialized
INFO - 2024-03-06 13:10:58 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:58 --> Input Class Initialized
INFO - 2024-03-06 13:10:58 --> Language Class Initialized
ERROR - 2024-03-06 13:10:58 --> 404 Page Not Found: /index
INFO - 2024-03-06 13:10:58 --> Config Class Initialized
INFO - 2024-03-06 13:10:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:10:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:10:58 --> Utf8 Class Initialized
INFO - 2024-03-06 13:10:58 --> URI Class Initialized
INFO - 2024-03-06 13:10:58 --> Router Class Initialized
INFO - 2024-03-06 13:10:58 --> Output Class Initialized
INFO - 2024-03-06 13:10:58 --> Security Class Initialized
DEBUG - 2024-03-06 13:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:10:58 --> Input Class Initialized
INFO - 2024-03-06 13:10:58 --> Language Class Initialized
INFO - 2024-03-06 13:10:58 --> Language Class Initialized
INFO - 2024-03-06 13:10:58 --> Config Class Initialized
INFO - 2024-03-06 13:10:58 --> Loader Class Initialized
INFO - 2024-03-06 13:10:58 --> Helper loaded: url_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: file_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: form_helper
INFO - 2024-03-06 13:10:58 --> Helper loaded: my_helper
INFO - 2024-03-06 13:10:58 --> Database Driver Class Initialized
INFO - 2024-03-06 13:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:10:58 --> Controller Class Initialized
INFO - 2024-03-06 13:11:00 --> Config Class Initialized
INFO - 2024-03-06 13:11:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:00 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:00 --> URI Class Initialized
INFO - 2024-03-06 13:11:00 --> Router Class Initialized
INFO - 2024-03-06 13:11:00 --> Output Class Initialized
INFO - 2024-03-06 13:11:00 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:00 --> Input Class Initialized
INFO - 2024-03-06 13:11:00 --> Language Class Initialized
INFO - 2024-03-06 13:11:00 --> Language Class Initialized
INFO - 2024-03-06 13:11:00 --> Config Class Initialized
INFO - 2024-03-06 13:11:00 --> Loader Class Initialized
INFO - 2024-03-06 13:11:00 --> Helper loaded: url_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: file_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: form_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: my_helper
INFO - 2024-03-06 13:11:00 --> Database Driver Class Initialized
INFO - 2024-03-06 13:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:11:00 --> Controller Class Initialized
DEBUG - 2024-03-06 13:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-03-06 13:11:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:11:00 --> Final output sent to browser
DEBUG - 2024-03-06 13:11:00 --> Total execution time: 0.0845
INFO - 2024-03-06 13:11:00 --> Config Class Initialized
INFO - 2024-03-06 13:11:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:00 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:00 --> URI Class Initialized
INFO - 2024-03-06 13:11:00 --> Router Class Initialized
INFO - 2024-03-06 13:11:00 --> Output Class Initialized
INFO - 2024-03-06 13:11:00 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:00 --> Input Class Initialized
INFO - 2024-03-06 13:11:00 --> Language Class Initialized
ERROR - 2024-03-06 13:11:00 --> 404 Page Not Found: /index
INFO - 2024-03-06 13:11:00 --> Config Class Initialized
INFO - 2024-03-06 13:11:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:00 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:00 --> URI Class Initialized
INFO - 2024-03-06 13:11:00 --> Router Class Initialized
INFO - 2024-03-06 13:11:00 --> Output Class Initialized
INFO - 2024-03-06 13:11:00 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:00 --> Input Class Initialized
INFO - 2024-03-06 13:11:00 --> Language Class Initialized
INFO - 2024-03-06 13:11:00 --> Language Class Initialized
INFO - 2024-03-06 13:11:00 --> Config Class Initialized
INFO - 2024-03-06 13:11:00 --> Loader Class Initialized
INFO - 2024-03-06 13:11:00 --> Helper loaded: url_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: file_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: form_helper
INFO - 2024-03-06 13:11:00 --> Helper loaded: my_helper
INFO - 2024-03-06 13:11:00 --> Database Driver Class Initialized
INFO - 2024-03-06 13:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:11:00 --> Controller Class Initialized
INFO - 2024-03-06 13:11:02 --> Config Class Initialized
INFO - 2024-03-06 13:11:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:02 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:02 --> URI Class Initialized
INFO - 2024-03-06 13:11:02 --> Router Class Initialized
INFO - 2024-03-06 13:11:02 --> Output Class Initialized
INFO - 2024-03-06 13:11:02 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:02 --> Input Class Initialized
INFO - 2024-03-06 13:11:02 --> Language Class Initialized
INFO - 2024-03-06 13:11:02 --> Language Class Initialized
INFO - 2024-03-06 13:11:02 --> Config Class Initialized
INFO - 2024-03-06 13:11:02 --> Loader Class Initialized
INFO - 2024-03-06 13:11:02 --> Helper loaded: url_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: file_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: form_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: my_helper
INFO - 2024-03-06 13:11:02 --> Database Driver Class Initialized
INFO - 2024-03-06 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:11:02 --> Controller Class Initialized
DEBUG - 2024-03-06 13:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 13:11:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:11:02 --> Final output sent to browser
DEBUG - 2024-03-06 13:11:02 --> Total execution time: 0.0556
INFO - 2024-03-06 13:11:02 --> Config Class Initialized
INFO - 2024-03-06 13:11:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:02 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:02 --> URI Class Initialized
INFO - 2024-03-06 13:11:02 --> Router Class Initialized
INFO - 2024-03-06 13:11:02 --> Output Class Initialized
INFO - 2024-03-06 13:11:02 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:02 --> Input Class Initialized
INFO - 2024-03-06 13:11:02 --> Language Class Initialized
ERROR - 2024-03-06 13:11:02 --> 404 Page Not Found: /index
INFO - 2024-03-06 13:11:02 --> Config Class Initialized
INFO - 2024-03-06 13:11:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:11:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:11:02 --> Utf8 Class Initialized
INFO - 2024-03-06 13:11:02 --> URI Class Initialized
INFO - 2024-03-06 13:11:02 --> Router Class Initialized
INFO - 2024-03-06 13:11:02 --> Output Class Initialized
INFO - 2024-03-06 13:11:02 --> Security Class Initialized
DEBUG - 2024-03-06 13:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:11:02 --> Input Class Initialized
INFO - 2024-03-06 13:11:02 --> Language Class Initialized
INFO - 2024-03-06 13:11:02 --> Language Class Initialized
INFO - 2024-03-06 13:11:02 --> Config Class Initialized
INFO - 2024-03-06 13:11:02 --> Loader Class Initialized
INFO - 2024-03-06 13:11:02 --> Helper loaded: url_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: file_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: form_helper
INFO - 2024-03-06 13:11:02 --> Helper loaded: my_helper
INFO - 2024-03-06 13:11:02 --> Database Driver Class Initialized
INFO - 2024-03-06 13:11:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:11:02 --> Controller Class Initialized
INFO - 2024-03-06 13:30:44 --> Config Class Initialized
INFO - 2024-03-06 13:30:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:30:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:30:44 --> Utf8 Class Initialized
INFO - 2024-03-06 13:30:44 --> URI Class Initialized
INFO - 2024-03-06 13:30:44 --> Router Class Initialized
INFO - 2024-03-06 13:30:44 --> Output Class Initialized
INFO - 2024-03-06 13:30:44 --> Security Class Initialized
DEBUG - 2024-03-06 13:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:30:44 --> Input Class Initialized
INFO - 2024-03-06 13:30:44 --> Language Class Initialized
INFO - 2024-03-06 13:30:44 --> Language Class Initialized
INFO - 2024-03-06 13:30:44 --> Config Class Initialized
INFO - 2024-03-06 13:30:44 --> Loader Class Initialized
INFO - 2024-03-06 13:30:44 --> Helper loaded: url_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: file_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: form_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: my_helper
INFO - 2024-03-06 13:30:44 --> Database Driver Class Initialized
INFO - 2024-03-06 13:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:30:44 --> Controller Class Initialized
DEBUG - 2024-03-06 13:30:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 13:30:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 13:30:44 --> Final output sent to browser
DEBUG - 2024-03-06 13:30:44 --> Total execution time: 0.0621
INFO - 2024-03-06 13:30:44 --> Config Class Initialized
INFO - 2024-03-06 13:30:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:30:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:30:44 --> Utf8 Class Initialized
INFO - 2024-03-06 13:30:44 --> URI Class Initialized
INFO - 2024-03-06 13:30:44 --> Router Class Initialized
INFO - 2024-03-06 13:30:44 --> Output Class Initialized
INFO - 2024-03-06 13:30:44 --> Security Class Initialized
DEBUG - 2024-03-06 13:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:30:44 --> Input Class Initialized
INFO - 2024-03-06 13:30:44 --> Language Class Initialized
ERROR - 2024-03-06 13:30:44 --> 404 Page Not Found: /index
INFO - 2024-03-06 13:30:44 --> Config Class Initialized
INFO - 2024-03-06 13:30:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 13:30:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 13:30:44 --> Utf8 Class Initialized
INFO - 2024-03-06 13:30:44 --> URI Class Initialized
INFO - 2024-03-06 13:30:44 --> Router Class Initialized
INFO - 2024-03-06 13:30:44 --> Output Class Initialized
INFO - 2024-03-06 13:30:44 --> Security Class Initialized
DEBUG - 2024-03-06 13:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 13:30:44 --> Input Class Initialized
INFO - 2024-03-06 13:30:44 --> Language Class Initialized
INFO - 2024-03-06 13:30:44 --> Language Class Initialized
INFO - 2024-03-06 13:30:44 --> Config Class Initialized
INFO - 2024-03-06 13:30:44 --> Loader Class Initialized
INFO - 2024-03-06 13:30:44 --> Helper loaded: url_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: file_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: form_helper
INFO - 2024-03-06 13:30:44 --> Helper loaded: my_helper
INFO - 2024-03-06 13:30:44 --> Database Driver Class Initialized
INFO - 2024-03-06 13:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 13:30:44 --> Controller Class Initialized
INFO - 2024-03-06 14:33:56 --> Config Class Initialized
INFO - 2024-03-06 14:33:56 --> Hooks Class Initialized
DEBUG - 2024-03-06 14:33:56 --> UTF-8 Support Enabled
INFO - 2024-03-06 14:33:56 --> Utf8 Class Initialized
INFO - 2024-03-06 14:33:56 --> URI Class Initialized
INFO - 2024-03-06 14:33:56 --> Router Class Initialized
INFO - 2024-03-06 14:33:56 --> Output Class Initialized
INFO - 2024-03-06 14:33:56 --> Security Class Initialized
DEBUG - 2024-03-06 14:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 14:33:56 --> Input Class Initialized
INFO - 2024-03-06 14:33:56 --> Language Class Initialized
INFO - 2024-03-06 14:33:56 --> Language Class Initialized
INFO - 2024-03-06 14:33:56 --> Config Class Initialized
INFO - 2024-03-06 14:33:56 --> Loader Class Initialized
INFO - 2024-03-06 14:33:56 --> Helper loaded: url_helper
INFO - 2024-03-06 14:33:56 --> Helper loaded: file_helper
INFO - 2024-03-06 14:33:56 --> Helper loaded: form_helper
INFO - 2024-03-06 14:33:56 --> Helper loaded: my_helper
INFO - 2024-03-06 14:33:56 --> Database Driver Class Initialized
INFO - 2024-03-06 14:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 14:33:57 --> Controller Class Initialized
DEBUG - 2024-03-06 14:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 14:33:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 14:33:57 --> Final output sent to browser
DEBUG - 2024-03-06 14:33:57 --> Total execution time: 0.1000
INFO - 2024-03-06 14:55:42 --> Config Class Initialized
INFO - 2024-03-06 14:55:42 --> Hooks Class Initialized
DEBUG - 2024-03-06 14:55:42 --> UTF-8 Support Enabled
INFO - 2024-03-06 14:55:42 --> Utf8 Class Initialized
INFO - 2024-03-06 14:55:42 --> URI Class Initialized
INFO - 2024-03-06 14:55:42 --> Router Class Initialized
INFO - 2024-03-06 14:55:42 --> Output Class Initialized
INFO - 2024-03-06 14:55:42 --> Security Class Initialized
DEBUG - 2024-03-06 14:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 14:55:42 --> Input Class Initialized
INFO - 2024-03-06 14:55:42 --> Language Class Initialized
INFO - 2024-03-06 14:55:42 --> Language Class Initialized
INFO - 2024-03-06 14:55:42 --> Config Class Initialized
INFO - 2024-03-06 14:55:42 --> Loader Class Initialized
INFO - 2024-03-06 14:55:42 --> Helper loaded: url_helper
INFO - 2024-03-06 14:55:42 --> Helper loaded: file_helper
INFO - 2024-03-06 14:55:42 --> Helper loaded: form_helper
INFO - 2024-03-06 14:55:42 --> Helper loaded: my_helper
INFO - 2024-03-06 14:55:42 --> Database Driver Class Initialized
INFO - 2024-03-06 14:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 14:55:42 --> Controller Class Initialized
DEBUG - 2024-03-06 14:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 14:55:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 14:55:42 --> Final output sent to browser
DEBUG - 2024-03-06 14:55:42 --> Total execution time: 0.0560
INFO - 2024-03-06 14:55:43 --> Config Class Initialized
INFO - 2024-03-06 14:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 14:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 14:55:43 --> Utf8 Class Initialized
INFO - 2024-03-06 14:55:43 --> URI Class Initialized
INFO - 2024-03-06 14:55:43 --> Router Class Initialized
INFO - 2024-03-06 14:55:43 --> Output Class Initialized
INFO - 2024-03-06 14:55:43 --> Security Class Initialized
DEBUG - 2024-03-06 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 14:55:43 --> Input Class Initialized
INFO - 2024-03-06 14:55:43 --> Language Class Initialized
ERROR - 2024-03-06 14:55:43 --> 404 Page Not Found: /index
INFO - 2024-03-06 14:55:43 --> Config Class Initialized
INFO - 2024-03-06 14:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 14:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 14:55:43 --> Utf8 Class Initialized
INFO - 2024-03-06 14:55:43 --> URI Class Initialized
INFO - 2024-03-06 14:55:43 --> Router Class Initialized
INFO - 2024-03-06 14:55:43 --> Output Class Initialized
INFO - 2024-03-06 14:55:43 --> Security Class Initialized
DEBUG - 2024-03-06 14:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 14:55:43 --> Input Class Initialized
INFO - 2024-03-06 14:55:43 --> Language Class Initialized
INFO - 2024-03-06 14:55:43 --> Language Class Initialized
INFO - 2024-03-06 14:55:43 --> Config Class Initialized
INFO - 2024-03-06 14:55:43 --> Loader Class Initialized
INFO - 2024-03-06 14:55:43 --> Helper loaded: url_helper
INFO - 2024-03-06 14:55:43 --> Helper loaded: file_helper
INFO - 2024-03-06 14:55:43 --> Helper loaded: form_helper
INFO - 2024-03-06 14:55:43 --> Helper loaded: my_helper
INFO - 2024-03-06 14:55:43 --> Database Driver Class Initialized
INFO - 2024-03-06 14:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 14:55:43 --> Controller Class Initialized
INFO - 2024-03-06 15:35:58 --> Config Class Initialized
INFO - 2024-03-06 15:35:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:35:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:35:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:35:58 --> URI Class Initialized
INFO - 2024-03-06 15:35:58 --> Router Class Initialized
INFO - 2024-03-06 15:35:58 --> Output Class Initialized
INFO - 2024-03-06 15:35:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:35:58 --> Input Class Initialized
INFO - 2024-03-06 15:35:58 --> Language Class Initialized
INFO - 2024-03-06 15:35:58 --> Language Class Initialized
INFO - 2024-03-06 15:35:58 --> Config Class Initialized
INFO - 2024-03-06 15:35:58 --> Loader Class Initialized
INFO - 2024-03-06 15:35:58 --> Helper loaded: url_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: file_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: form_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: my_helper
INFO - 2024-03-06 15:35:58 --> Database Driver Class Initialized
INFO - 2024-03-06 15:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:35:58 --> Controller Class Initialized
INFO - 2024-03-06 15:35:58 --> Config Class Initialized
INFO - 2024-03-06 15:35:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:35:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:35:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:35:58 --> URI Class Initialized
INFO - 2024-03-06 15:35:58 --> Router Class Initialized
INFO - 2024-03-06 15:35:58 --> Output Class Initialized
INFO - 2024-03-06 15:35:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:35:58 --> Input Class Initialized
INFO - 2024-03-06 15:35:58 --> Language Class Initialized
INFO - 2024-03-06 15:35:58 --> Language Class Initialized
INFO - 2024-03-06 15:35:58 --> Config Class Initialized
INFO - 2024-03-06 15:35:58 --> Loader Class Initialized
INFO - 2024-03-06 15:35:58 --> Helper loaded: url_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: file_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: form_helper
INFO - 2024-03-06 15:35:58 --> Helper loaded: my_helper
INFO - 2024-03-06 15:35:58 --> Database Driver Class Initialized
INFO - 2024-03-06 15:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:35:59 --> Controller Class Initialized
DEBUG - 2024-03-06 15:35:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:35:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:35:59 --> Final output sent to browser
DEBUG - 2024-03-06 15:35:59 --> Total execution time: 0.3860
INFO - 2024-03-06 15:36:02 --> Config Class Initialized
INFO - 2024-03-06 15:36:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:02 --> URI Class Initialized
INFO - 2024-03-06 15:36:02 --> Router Class Initialized
INFO - 2024-03-06 15:36:02 --> Output Class Initialized
INFO - 2024-03-06 15:36:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:02 --> Input Class Initialized
INFO - 2024-03-06 15:36:02 --> Language Class Initialized
INFO - 2024-03-06 15:36:02 --> Language Class Initialized
INFO - 2024-03-06 15:36:02 --> Config Class Initialized
INFO - 2024-03-06 15:36:02 --> Loader Class Initialized
INFO - 2024-03-06 15:36:02 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:02 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:02 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:02 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:02 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:02 --> Controller Class Initialized
INFO - 2024-03-06 15:36:02 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:36:02 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:02 --> Total execution time: 0.1871
INFO - 2024-03-06 15:36:03 --> Config Class Initialized
INFO - 2024-03-06 15:36:03 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:03 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:03 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:03 --> URI Class Initialized
INFO - 2024-03-06 15:36:03 --> Router Class Initialized
INFO - 2024-03-06 15:36:03 --> Output Class Initialized
INFO - 2024-03-06 15:36:03 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:03 --> Input Class Initialized
INFO - 2024-03-06 15:36:03 --> Language Class Initialized
INFO - 2024-03-06 15:36:03 --> Language Class Initialized
INFO - 2024-03-06 15:36:03 --> Config Class Initialized
INFO - 2024-03-06 15:36:03 --> Loader Class Initialized
INFO - 2024-03-06 15:36:03 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:03 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:03 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:03 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:03 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:03 --> Controller Class Initialized
DEBUG - 2024-03-06 15:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:36:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:36:03 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:03 --> Total execution time: 0.0645
INFO - 2024-03-06 15:36:39 --> Config Class Initialized
INFO - 2024-03-06 15:36:39 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:39 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:39 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:40 --> URI Class Initialized
INFO - 2024-03-06 15:36:40 --> Router Class Initialized
INFO - 2024-03-06 15:36:40 --> Output Class Initialized
INFO - 2024-03-06 15:36:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:40 --> Input Class Initialized
INFO - 2024-03-06 15:36:40 --> Language Class Initialized
INFO - 2024-03-06 15:36:40 --> Language Class Initialized
INFO - 2024-03-06 15:36:40 --> Config Class Initialized
INFO - 2024-03-06 15:36:40 --> Loader Class Initialized
INFO - 2024-03-06 15:36:40 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:40 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:40 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:40 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:40 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:40 --> Controller Class Initialized
DEBUG - 2024-03-06 15:36:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:36:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:36:40 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:40 --> Total execution time: 0.4655
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:45 --> URI Class Initialized
INFO - 2024-03-06 15:36:45 --> Router Class Initialized
INFO - 2024-03-06 15:36:45 --> Output Class Initialized
INFO - 2024-03-06 15:36:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:45 --> Input Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Loader Class Initialized
INFO - 2024-03-06 15:36:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:45 --> Controller Class Initialized
INFO - 2024-03-06 15:36:45 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:45 --> URI Class Initialized
INFO - 2024-03-06 15:36:45 --> Router Class Initialized
INFO - 2024-03-06 15:36:45 --> Output Class Initialized
INFO - 2024-03-06 15:36:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:45 --> Input Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Loader Class Initialized
INFO - 2024-03-06 15:36:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:45 --> Controller Class Initialized
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:45 --> URI Class Initialized
INFO - 2024-03-06 15:36:45 --> Router Class Initialized
INFO - 2024-03-06 15:36:45 --> Output Class Initialized
INFO - 2024-03-06 15:36:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:45 --> Input Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Language Class Initialized
INFO - 2024-03-06 15:36:45 --> Config Class Initialized
INFO - 2024-03-06 15:36:45 --> Loader Class Initialized
INFO - 2024-03-06 15:36:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:45 --> Controller Class Initialized
DEBUG - 2024-03-06 15:36:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:36:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:36:45 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:45 --> Total execution time: 0.0305
INFO - 2024-03-06 15:36:48 --> Config Class Initialized
INFO - 2024-03-06 15:36:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:48 --> URI Class Initialized
INFO - 2024-03-06 15:36:48 --> Router Class Initialized
INFO - 2024-03-06 15:36:48 --> Output Class Initialized
INFO - 2024-03-06 15:36:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:48 --> Input Class Initialized
INFO - 2024-03-06 15:36:48 --> Language Class Initialized
INFO - 2024-03-06 15:36:48 --> Language Class Initialized
INFO - 2024-03-06 15:36:48 --> Config Class Initialized
INFO - 2024-03-06 15:36:48 --> Loader Class Initialized
INFO - 2024-03-06 15:36:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:48 --> Controller Class Initialized
INFO - 2024-03-06 15:36:48 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:36:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:48 --> Total execution time: 0.0426
INFO - 2024-03-06 15:36:48 --> Config Class Initialized
INFO - 2024-03-06 15:36:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:48 --> URI Class Initialized
INFO - 2024-03-06 15:36:48 --> Router Class Initialized
INFO - 2024-03-06 15:36:48 --> Output Class Initialized
INFO - 2024-03-06 15:36:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:48 --> Input Class Initialized
INFO - 2024-03-06 15:36:48 --> Language Class Initialized
INFO - 2024-03-06 15:36:48 --> Language Class Initialized
INFO - 2024-03-06 15:36:48 --> Config Class Initialized
INFO - 2024-03-06 15:36:48 --> Loader Class Initialized
INFO - 2024-03-06 15:36:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:48 --> Controller Class Initialized
DEBUG - 2024-03-06 15:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:36:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:36:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:48 --> Total execution time: 0.0318
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:59 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:59 --> URI Class Initialized
INFO - 2024-03-06 15:36:59 --> Router Class Initialized
INFO - 2024-03-06 15:36:59 --> Output Class Initialized
INFO - 2024-03-06 15:36:59 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:59 --> Input Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Loader Class Initialized
INFO - 2024-03-06 15:36:59 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:59 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:59 --> Controller Class Initialized
INFO - 2024-03-06 15:36:59 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:59 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:59 --> URI Class Initialized
INFO - 2024-03-06 15:36:59 --> Router Class Initialized
INFO - 2024-03-06 15:36:59 --> Output Class Initialized
INFO - 2024-03-06 15:36:59 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:59 --> Input Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Loader Class Initialized
INFO - 2024-03-06 15:36:59 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:59 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:59 --> Controller Class Initialized
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:36:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:36:59 --> Utf8 Class Initialized
INFO - 2024-03-06 15:36:59 --> URI Class Initialized
INFO - 2024-03-06 15:36:59 --> Router Class Initialized
INFO - 2024-03-06 15:36:59 --> Output Class Initialized
INFO - 2024-03-06 15:36:59 --> Security Class Initialized
DEBUG - 2024-03-06 15:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:36:59 --> Input Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Language Class Initialized
INFO - 2024-03-06 15:36:59 --> Config Class Initialized
INFO - 2024-03-06 15:36:59 --> Loader Class Initialized
INFO - 2024-03-06 15:36:59 --> Helper loaded: url_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: file_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: form_helper
INFO - 2024-03-06 15:36:59 --> Helper loaded: my_helper
INFO - 2024-03-06 15:36:59 --> Database Driver Class Initialized
INFO - 2024-03-06 15:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:36:59 --> Controller Class Initialized
DEBUG - 2024-03-06 15:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:36:59 --> Final output sent to browser
DEBUG - 2024-03-06 15:36:59 --> Total execution time: 0.0726
INFO - 2024-03-06 15:37:04 --> Config Class Initialized
INFO - 2024-03-06 15:37:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:37:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:37:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:37:04 --> URI Class Initialized
INFO - 2024-03-06 15:37:04 --> Router Class Initialized
INFO - 2024-03-06 15:37:04 --> Output Class Initialized
INFO - 2024-03-06 15:37:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:37:04 --> Input Class Initialized
INFO - 2024-03-06 15:37:04 --> Language Class Initialized
INFO - 2024-03-06 15:37:04 --> Language Class Initialized
INFO - 2024-03-06 15:37:04 --> Config Class Initialized
INFO - 2024-03-06 15:37:04 --> Loader Class Initialized
INFO - 2024-03-06 15:37:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:37:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:37:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:37:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:37:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:37:05 --> Controller Class Initialized
DEBUG - 2024-03-06 15:37:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:37:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:37:05 --> Final output sent to browser
DEBUG - 2024-03-06 15:37:05 --> Total execution time: 0.0288
INFO - 2024-03-06 15:37:09 --> Config Class Initialized
INFO - 2024-03-06 15:37:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:37:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:37:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:37:09 --> URI Class Initialized
INFO - 2024-03-06 15:37:09 --> Router Class Initialized
INFO - 2024-03-06 15:37:09 --> Output Class Initialized
INFO - 2024-03-06 15:37:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:37:09 --> Input Class Initialized
INFO - 2024-03-06 15:37:09 --> Language Class Initialized
INFO - 2024-03-06 15:37:09 --> Language Class Initialized
INFO - 2024-03-06 15:37:09 --> Config Class Initialized
INFO - 2024-03-06 15:37:09 --> Loader Class Initialized
INFO - 2024-03-06 15:37:09 --> Helper loaded: url_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: file_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: form_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: my_helper
INFO - 2024-03-06 15:37:09 --> Database Driver Class Initialized
INFO - 2024-03-06 15:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:37:09 --> Controller Class Initialized
INFO - 2024-03-06 15:37:09 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:37:09 --> Final output sent to browser
DEBUG - 2024-03-06 15:37:09 --> Total execution time: 0.0588
INFO - 2024-03-06 15:37:09 --> Config Class Initialized
INFO - 2024-03-06 15:37:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:37:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:37:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:37:09 --> URI Class Initialized
INFO - 2024-03-06 15:37:09 --> Router Class Initialized
INFO - 2024-03-06 15:37:09 --> Output Class Initialized
INFO - 2024-03-06 15:37:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:37:09 --> Input Class Initialized
INFO - 2024-03-06 15:37:09 --> Language Class Initialized
INFO - 2024-03-06 15:37:09 --> Language Class Initialized
INFO - 2024-03-06 15:37:09 --> Config Class Initialized
INFO - 2024-03-06 15:37:09 --> Loader Class Initialized
INFO - 2024-03-06 15:37:09 --> Helper loaded: url_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: file_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: form_helper
INFO - 2024-03-06 15:37:09 --> Helper loaded: my_helper
INFO - 2024-03-06 15:37:09 --> Database Driver Class Initialized
INFO - 2024-03-06 15:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:37:09 --> Controller Class Initialized
DEBUG - 2024-03-06 15:37:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:37:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:37:09 --> Final output sent to browser
DEBUG - 2024-03-06 15:37:09 --> Total execution time: 0.1422
INFO - 2024-03-06 15:38:01 --> Config Class Initialized
INFO - 2024-03-06 15:38:01 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:38:01 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:38:01 --> Utf8 Class Initialized
INFO - 2024-03-06 15:38:01 --> URI Class Initialized
INFO - 2024-03-06 15:38:01 --> Router Class Initialized
INFO - 2024-03-06 15:38:01 --> Output Class Initialized
INFO - 2024-03-06 15:38:01 --> Security Class Initialized
DEBUG - 2024-03-06 15:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:38:01 --> Input Class Initialized
INFO - 2024-03-06 15:38:01 --> Language Class Initialized
INFO - 2024-03-06 15:38:01 --> Language Class Initialized
INFO - 2024-03-06 15:38:01 --> Config Class Initialized
INFO - 2024-03-06 15:38:01 --> Loader Class Initialized
INFO - 2024-03-06 15:38:01 --> Helper loaded: url_helper
INFO - 2024-03-06 15:38:01 --> Helper loaded: file_helper
INFO - 2024-03-06 15:38:01 --> Helper loaded: form_helper
INFO - 2024-03-06 15:38:01 --> Helper loaded: my_helper
INFO - 2024-03-06 15:38:01 --> Database Driver Class Initialized
INFO - 2024-03-06 15:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:38:01 --> Controller Class Initialized
DEBUG - 2024-03-06 15:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:38:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:38:01 --> Final output sent to browser
DEBUG - 2024-03-06 15:38:01 --> Total execution time: 0.0900
INFO - 2024-03-06 15:39:20 --> Config Class Initialized
INFO - 2024-03-06 15:39:20 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:20 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:20 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:20 --> URI Class Initialized
INFO - 2024-03-06 15:39:20 --> Router Class Initialized
INFO - 2024-03-06 15:39:20 --> Output Class Initialized
INFO - 2024-03-06 15:39:20 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:20 --> Input Class Initialized
INFO - 2024-03-06 15:39:20 --> Language Class Initialized
INFO - 2024-03-06 15:39:20 --> Language Class Initialized
INFO - 2024-03-06 15:39:20 --> Config Class Initialized
INFO - 2024-03-06 15:39:20 --> Loader Class Initialized
INFO - 2024-03-06 15:39:20 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:20 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:20 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:20 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:20 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:20 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:39:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:20 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:20 --> Total execution time: 0.1244
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:22 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:22 --> URI Class Initialized
INFO - 2024-03-06 15:39:22 --> Router Class Initialized
INFO - 2024-03-06 15:39:22 --> Output Class Initialized
INFO - 2024-03-06 15:39:22 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:22 --> Input Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Loader Class Initialized
INFO - 2024-03-06 15:39:22 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:22 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:22 --> Controller Class Initialized
INFO - 2024-03-06 15:39:22 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:22 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:22 --> URI Class Initialized
INFO - 2024-03-06 15:39:22 --> Router Class Initialized
INFO - 2024-03-06 15:39:22 --> Output Class Initialized
INFO - 2024-03-06 15:39:22 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:22 --> Input Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Loader Class Initialized
INFO - 2024-03-06 15:39:22 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:22 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:22 --> Controller Class Initialized
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:22 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:22 --> URI Class Initialized
INFO - 2024-03-06 15:39:22 --> Router Class Initialized
INFO - 2024-03-06 15:39:22 --> Output Class Initialized
INFO - 2024-03-06 15:39:22 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:22 --> Input Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Language Class Initialized
INFO - 2024-03-06 15:39:22 --> Config Class Initialized
INFO - 2024-03-06 15:39:22 --> Loader Class Initialized
INFO - 2024-03-06 15:39:22 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:22 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:22 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:22 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:39:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:22 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:22 --> Total execution time: 0.0326
INFO - 2024-03-06 15:39:25 --> Config Class Initialized
INFO - 2024-03-06 15:39:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:25 --> URI Class Initialized
INFO - 2024-03-06 15:39:25 --> Router Class Initialized
INFO - 2024-03-06 15:39:25 --> Output Class Initialized
INFO - 2024-03-06 15:39:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:25 --> Input Class Initialized
INFO - 2024-03-06 15:39:25 --> Language Class Initialized
INFO - 2024-03-06 15:39:25 --> Language Class Initialized
INFO - 2024-03-06 15:39:25 --> Config Class Initialized
INFO - 2024-03-06 15:39:25 --> Loader Class Initialized
INFO - 2024-03-06 15:39:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:25 --> Controller Class Initialized
INFO - 2024-03-06 15:39:25 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:39:25 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:25 --> Total execution time: 0.0705
INFO - 2024-03-06 15:39:25 --> Config Class Initialized
INFO - 2024-03-06 15:39:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:25 --> URI Class Initialized
INFO - 2024-03-06 15:39:25 --> Router Class Initialized
INFO - 2024-03-06 15:39:25 --> Output Class Initialized
INFO - 2024-03-06 15:39:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:25 --> Input Class Initialized
INFO - 2024-03-06 15:39:25 --> Language Class Initialized
INFO - 2024-03-06 15:39:25 --> Language Class Initialized
INFO - 2024-03-06 15:39:25 --> Config Class Initialized
INFO - 2024-03-06 15:39:25 --> Loader Class Initialized
INFO - 2024-03-06 15:39:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:25 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:39:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:25 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:25 --> Total execution time: 0.1070
INFO - 2024-03-06 15:39:41 --> Config Class Initialized
INFO - 2024-03-06 15:39:41 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:41 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:41 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:41 --> URI Class Initialized
DEBUG - 2024-03-06 15:39:41 --> No URI present. Default controller set.
INFO - 2024-03-06 15:39:41 --> Router Class Initialized
INFO - 2024-03-06 15:39:41 --> Output Class Initialized
INFO - 2024-03-06 15:39:41 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:41 --> Input Class Initialized
INFO - 2024-03-06 15:39:41 --> Language Class Initialized
INFO - 2024-03-06 15:39:41 --> Language Class Initialized
INFO - 2024-03-06 15:39:41 --> Config Class Initialized
INFO - 2024-03-06 15:39:41 --> Loader Class Initialized
INFO - 2024-03-06 15:39:41 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:41 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:41 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:41 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:41 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:41 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:39:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:41 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:41 --> Total execution time: 0.0301
INFO - 2024-03-06 15:39:49 --> Config Class Initialized
INFO - 2024-03-06 15:39:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:49 --> URI Class Initialized
DEBUG - 2024-03-06 15:39:49 --> No URI present. Default controller set.
INFO - 2024-03-06 15:39:49 --> Router Class Initialized
INFO - 2024-03-06 15:39:49 --> Output Class Initialized
INFO - 2024-03-06 15:39:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:49 --> Input Class Initialized
INFO - 2024-03-06 15:39:49 --> Language Class Initialized
INFO - 2024-03-06 15:39:49 --> Language Class Initialized
INFO - 2024-03-06 15:39:49 --> Config Class Initialized
INFO - 2024-03-06 15:39:49 --> Loader Class Initialized
INFO - 2024-03-06 15:39:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:49 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:39:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:49 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:49 --> Total execution time: 0.0461
INFO - 2024-03-06 15:39:52 --> Config Class Initialized
INFO - 2024-03-06 15:39:52 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:39:52 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:39:52 --> Utf8 Class Initialized
INFO - 2024-03-06 15:39:52 --> URI Class Initialized
DEBUG - 2024-03-06 15:39:52 --> No URI present. Default controller set.
INFO - 2024-03-06 15:39:52 --> Router Class Initialized
INFO - 2024-03-06 15:39:52 --> Output Class Initialized
INFO - 2024-03-06 15:39:52 --> Security Class Initialized
DEBUG - 2024-03-06 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:39:52 --> Input Class Initialized
INFO - 2024-03-06 15:39:52 --> Language Class Initialized
INFO - 2024-03-06 15:39:52 --> Language Class Initialized
INFO - 2024-03-06 15:39:52 --> Config Class Initialized
INFO - 2024-03-06 15:39:52 --> Loader Class Initialized
INFO - 2024-03-06 15:39:52 --> Helper loaded: url_helper
INFO - 2024-03-06 15:39:52 --> Helper loaded: file_helper
INFO - 2024-03-06 15:39:52 --> Helper loaded: form_helper
INFO - 2024-03-06 15:39:52 --> Helper loaded: my_helper
INFO - 2024-03-06 15:39:52 --> Database Driver Class Initialized
INFO - 2024-03-06 15:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:39:52 --> Controller Class Initialized
DEBUG - 2024-03-06 15:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:39:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:39:52 --> Final output sent to browser
DEBUG - 2024-03-06 15:39:52 --> Total execution time: 0.0503
INFO - 2024-03-06 15:41:14 --> Config Class Initialized
INFO - 2024-03-06 15:41:14 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:14 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:14 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:14 --> URI Class Initialized
DEBUG - 2024-03-06 15:41:14 --> No URI present. Default controller set.
INFO - 2024-03-06 15:41:14 --> Router Class Initialized
INFO - 2024-03-06 15:41:14 --> Output Class Initialized
INFO - 2024-03-06 15:41:14 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:14 --> Input Class Initialized
INFO - 2024-03-06 15:41:14 --> Language Class Initialized
INFO - 2024-03-06 15:41:14 --> Language Class Initialized
INFO - 2024-03-06 15:41:14 --> Config Class Initialized
INFO - 2024-03-06 15:41:14 --> Loader Class Initialized
INFO - 2024-03-06 15:41:14 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:14 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:14 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:14 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:14 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:14 --> Controller Class Initialized
DEBUG - 2024-03-06 15:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:41:14 --> Final output sent to browser
DEBUG - 2024-03-06 15:41:14 --> Total execution time: 0.1758
INFO - 2024-03-06 15:41:20 --> Config Class Initialized
INFO - 2024-03-06 15:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:20 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:20 --> URI Class Initialized
INFO - 2024-03-06 15:41:20 --> Router Class Initialized
INFO - 2024-03-06 15:41:20 --> Output Class Initialized
INFO - 2024-03-06 15:41:20 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:20 --> Input Class Initialized
INFO - 2024-03-06 15:41:20 --> Language Class Initialized
INFO - 2024-03-06 15:41:20 --> Language Class Initialized
INFO - 2024-03-06 15:41:20 --> Config Class Initialized
INFO - 2024-03-06 15:41:20 --> Loader Class Initialized
INFO - 2024-03-06 15:41:20 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:20 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:20 --> Controller Class Initialized
INFO - 2024-03-06 15:41:20 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:41:20 --> Config Class Initialized
INFO - 2024-03-06 15:41:20 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:20 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:20 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:20 --> URI Class Initialized
INFO - 2024-03-06 15:41:20 --> Router Class Initialized
INFO - 2024-03-06 15:41:20 --> Output Class Initialized
INFO - 2024-03-06 15:41:20 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:20 --> Input Class Initialized
INFO - 2024-03-06 15:41:20 --> Language Class Initialized
INFO - 2024-03-06 15:41:20 --> Language Class Initialized
INFO - 2024-03-06 15:41:20 --> Config Class Initialized
INFO - 2024-03-06 15:41:20 --> Loader Class Initialized
INFO - 2024-03-06 15:41:20 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:20 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:20 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:20 --> Controller Class Initialized
INFO - 2024-03-06 15:41:21 --> Config Class Initialized
INFO - 2024-03-06 15:41:21 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:21 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:21 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:21 --> URI Class Initialized
INFO - 2024-03-06 15:41:21 --> Router Class Initialized
INFO - 2024-03-06 15:41:21 --> Output Class Initialized
INFO - 2024-03-06 15:41:21 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:21 --> Input Class Initialized
INFO - 2024-03-06 15:41:21 --> Language Class Initialized
INFO - 2024-03-06 15:41:21 --> Language Class Initialized
INFO - 2024-03-06 15:41:21 --> Config Class Initialized
INFO - 2024-03-06 15:41:21 --> Loader Class Initialized
INFO - 2024-03-06 15:41:21 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:21 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:21 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:21 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:21 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:21 --> Controller Class Initialized
DEBUG - 2024-03-06 15:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:41:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:41:21 --> Final output sent to browser
DEBUG - 2024-03-06 15:41:21 --> Total execution time: 0.0796
INFO - 2024-03-06 15:41:23 --> Config Class Initialized
INFO - 2024-03-06 15:41:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:23 --> URI Class Initialized
INFO - 2024-03-06 15:41:23 --> Router Class Initialized
INFO - 2024-03-06 15:41:23 --> Output Class Initialized
INFO - 2024-03-06 15:41:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:23 --> Input Class Initialized
INFO - 2024-03-06 15:41:23 --> Language Class Initialized
INFO - 2024-03-06 15:41:23 --> Language Class Initialized
INFO - 2024-03-06 15:41:23 --> Config Class Initialized
INFO - 2024-03-06 15:41:23 --> Loader Class Initialized
INFO - 2024-03-06 15:41:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:23 --> Controller Class Initialized
INFO - 2024-03-06 15:41:23 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:41:23 --> Final output sent to browser
DEBUG - 2024-03-06 15:41:23 --> Total execution time: 0.1021
INFO - 2024-03-06 15:41:23 --> Config Class Initialized
INFO - 2024-03-06 15:41:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:41:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:41:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:41:23 --> URI Class Initialized
INFO - 2024-03-06 15:41:23 --> Router Class Initialized
INFO - 2024-03-06 15:41:23 --> Output Class Initialized
INFO - 2024-03-06 15:41:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:41:23 --> Input Class Initialized
INFO - 2024-03-06 15:41:23 --> Language Class Initialized
INFO - 2024-03-06 15:41:23 --> Language Class Initialized
INFO - 2024-03-06 15:41:23 --> Config Class Initialized
INFO - 2024-03-06 15:41:23 --> Loader Class Initialized
INFO - 2024-03-06 15:41:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:41:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:41:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:41:23 --> Controller Class Initialized
DEBUG - 2024-03-06 15:41:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:41:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:41:23 --> Final output sent to browser
DEBUG - 2024-03-06 15:41:23 --> Total execution time: 0.0831
INFO - 2024-03-06 15:42:44 --> Config Class Initialized
INFO - 2024-03-06 15:42:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:44 --> URI Class Initialized
INFO - 2024-03-06 15:42:44 --> Router Class Initialized
INFO - 2024-03-06 15:42:44 --> Output Class Initialized
INFO - 2024-03-06 15:42:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:44 --> Input Class Initialized
INFO - 2024-03-06 15:42:44 --> Language Class Initialized
INFO - 2024-03-06 15:42:44 --> Language Class Initialized
INFO - 2024-03-06 15:42:44 --> Config Class Initialized
INFO - 2024-03-06 15:42:44 --> Loader Class Initialized
INFO - 2024-03-06 15:42:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:45 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:42:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:45 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:45 --> Total execution time: 0.1688
INFO - 2024-03-06 15:42:48 --> Config Class Initialized
INFO - 2024-03-06 15:42:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:48 --> URI Class Initialized
INFO - 2024-03-06 15:42:48 --> Router Class Initialized
INFO - 2024-03-06 15:42:48 --> Output Class Initialized
INFO - 2024-03-06 15:42:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:48 --> Input Class Initialized
INFO - 2024-03-06 15:42:48 --> Language Class Initialized
INFO - 2024-03-06 15:42:48 --> Language Class Initialized
INFO - 2024-03-06 15:42:48 --> Config Class Initialized
INFO - 2024-03-06 15:42:48 --> Loader Class Initialized
INFO - 2024-03-06 15:42:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:48 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-06 15:42:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:48 --> Total execution time: 0.1452
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:49 --> URI Class Initialized
INFO - 2024-03-06 15:42:49 --> Router Class Initialized
INFO - 2024-03-06 15:42:49 --> Output Class Initialized
INFO - 2024-03-06 15:42:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:49 --> Input Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Loader Class Initialized
INFO - 2024-03-06 15:42:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:49 --> Controller Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:49 --> URI Class Initialized
INFO - 2024-03-06 15:42:49 --> Router Class Initialized
INFO - 2024-03-06 15:42:49 --> Output Class Initialized
INFO - 2024-03-06 15:42:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:49 --> Input Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Loader Class Initialized
INFO - 2024-03-06 15:42:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:49 --> Controller Class Initialized
INFO - 2024-03-06 15:42:49 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:49 --> URI Class Initialized
INFO - 2024-03-06 15:42:49 --> Router Class Initialized
INFO - 2024-03-06 15:42:49 --> Output Class Initialized
INFO - 2024-03-06 15:42:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:49 --> Input Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Loader Class Initialized
INFO - 2024-03-06 15:42:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:49 --> Controller Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:49 --> URI Class Initialized
INFO - 2024-03-06 15:42:49 --> Router Class Initialized
INFO - 2024-03-06 15:42:49 --> Output Class Initialized
INFO - 2024-03-06 15:42:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:49 --> Input Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Language Class Initialized
INFO - 2024-03-06 15:42:49 --> Config Class Initialized
INFO - 2024-03-06 15:42:49 --> Loader Class Initialized
INFO - 2024-03-06 15:42:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:49 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:42:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:49 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:49 --> Total execution time: 0.0525
INFO - 2024-03-06 15:42:52 --> Config Class Initialized
INFO - 2024-03-06 15:42:52 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:52 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:52 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:52 --> URI Class Initialized
INFO - 2024-03-06 15:42:52 --> Router Class Initialized
INFO - 2024-03-06 15:42:52 --> Output Class Initialized
INFO - 2024-03-06 15:42:52 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:52 --> Input Class Initialized
INFO - 2024-03-06 15:42:52 --> Language Class Initialized
INFO - 2024-03-06 15:42:52 --> Language Class Initialized
INFO - 2024-03-06 15:42:52 --> Config Class Initialized
INFO - 2024-03-06 15:42:52 --> Loader Class Initialized
INFO - 2024-03-06 15:42:52 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:52 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:52 --> Controller Class Initialized
INFO - 2024-03-06 15:42:52 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:42:52 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:52 --> Total execution time: 0.1250
INFO - 2024-03-06 15:42:52 --> Config Class Initialized
INFO - 2024-03-06 15:42:52 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:52 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:52 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:52 --> URI Class Initialized
INFO - 2024-03-06 15:42:52 --> Router Class Initialized
INFO - 2024-03-06 15:42:52 --> Output Class Initialized
INFO - 2024-03-06 15:42:52 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:52 --> Input Class Initialized
INFO - 2024-03-06 15:42:52 --> Language Class Initialized
INFO - 2024-03-06 15:42:52 --> Language Class Initialized
INFO - 2024-03-06 15:42:52 --> Config Class Initialized
INFO - 2024-03-06 15:42:52 --> Loader Class Initialized
INFO - 2024-03-06 15:42:52 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:52 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:52 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:52 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:42:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:52 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:52 --> Total execution time: 0.0311
INFO - 2024-03-06 15:42:54 --> Config Class Initialized
INFO - 2024-03-06 15:42:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:54 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:54 --> URI Class Initialized
DEBUG - 2024-03-06 15:42:54 --> No URI present. Default controller set.
INFO - 2024-03-06 15:42:54 --> Router Class Initialized
INFO - 2024-03-06 15:42:54 --> Output Class Initialized
INFO - 2024-03-06 15:42:54 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:54 --> Input Class Initialized
INFO - 2024-03-06 15:42:54 --> Language Class Initialized
INFO - 2024-03-06 15:42:54 --> Language Class Initialized
INFO - 2024-03-06 15:42:54 --> Config Class Initialized
INFO - 2024-03-06 15:42:54 --> Loader Class Initialized
INFO - 2024-03-06 15:42:54 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:54 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:54 --> Controller Class Initialized
INFO - 2024-03-06 15:42:54 --> Config Class Initialized
INFO - 2024-03-06 15:42:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:54 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:54 --> URI Class Initialized
INFO - 2024-03-06 15:42:54 --> Router Class Initialized
INFO - 2024-03-06 15:42:54 --> Output Class Initialized
INFO - 2024-03-06 15:42:54 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:54 --> Input Class Initialized
INFO - 2024-03-06 15:42:54 --> Language Class Initialized
INFO - 2024-03-06 15:42:54 --> Language Class Initialized
INFO - 2024-03-06 15:42:54 --> Config Class Initialized
INFO - 2024-03-06 15:42:54 --> Loader Class Initialized
INFO - 2024-03-06 15:42:54 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:54 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:54 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:54 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:42:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:54 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:54 --> Total execution time: 0.0434
INFO - 2024-03-06 15:42:55 --> Config Class Initialized
INFO - 2024-03-06 15:42:55 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:55 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:55 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:55 --> URI Class Initialized
INFO - 2024-03-06 15:42:55 --> Router Class Initialized
INFO - 2024-03-06 15:42:55 --> Output Class Initialized
INFO - 2024-03-06 15:42:55 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:55 --> Input Class Initialized
INFO - 2024-03-06 15:42:55 --> Language Class Initialized
INFO - 2024-03-06 15:42:55 --> Language Class Initialized
INFO - 2024-03-06 15:42:55 --> Config Class Initialized
INFO - 2024-03-06 15:42:55 --> Loader Class Initialized
INFO - 2024-03-06 15:42:55 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:55 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:55 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:55 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:55 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:55 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:42:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:55 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:55 --> Total execution time: 0.0407
INFO - 2024-03-06 15:42:59 --> Config Class Initialized
INFO - 2024-03-06 15:42:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:59 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:59 --> URI Class Initialized
INFO - 2024-03-06 15:42:59 --> Router Class Initialized
INFO - 2024-03-06 15:42:59 --> Output Class Initialized
INFO - 2024-03-06 15:42:59 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:59 --> Input Class Initialized
INFO - 2024-03-06 15:42:59 --> Language Class Initialized
INFO - 2024-03-06 15:42:59 --> Language Class Initialized
INFO - 2024-03-06 15:42:59 --> Config Class Initialized
INFO - 2024-03-06 15:42:59 --> Loader Class Initialized
INFO - 2024-03-06 15:42:59 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:59 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:59 --> Controller Class Initialized
INFO - 2024-03-06 15:42:59 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:42:59 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:59 --> Total execution time: 0.0755
INFO - 2024-03-06 15:42:59 --> Config Class Initialized
INFO - 2024-03-06 15:42:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:42:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:42:59 --> Utf8 Class Initialized
INFO - 2024-03-06 15:42:59 --> URI Class Initialized
INFO - 2024-03-06 15:42:59 --> Router Class Initialized
INFO - 2024-03-06 15:42:59 --> Output Class Initialized
INFO - 2024-03-06 15:42:59 --> Security Class Initialized
DEBUG - 2024-03-06 15:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:42:59 --> Input Class Initialized
INFO - 2024-03-06 15:42:59 --> Language Class Initialized
INFO - 2024-03-06 15:42:59 --> Language Class Initialized
INFO - 2024-03-06 15:42:59 --> Config Class Initialized
INFO - 2024-03-06 15:42:59 --> Loader Class Initialized
INFO - 2024-03-06 15:42:59 --> Helper loaded: url_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: file_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: form_helper
INFO - 2024-03-06 15:42:59 --> Helper loaded: my_helper
INFO - 2024-03-06 15:42:59 --> Database Driver Class Initialized
INFO - 2024-03-06 15:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:42:59 --> Controller Class Initialized
DEBUG - 2024-03-06 15:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:42:59 --> Final output sent to browser
DEBUG - 2024-03-06 15:42:59 --> Total execution time: 0.0469
INFO - 2024-03-06 15:43:01 --> Config Class Initialized
INFO - 2024-03-06 15:43:01 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:43:01 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:43:01 --> Utf8 Class Initialized
INFO - 2024-03-06 15:43:01 --> URI Class Initialized
DEBUG - 2024-03-06 15:43:01 --> No URI present. Default controller set.
INFO - 2024-03-06 15:43:01 --> Router Class Initialized
INFO - 2024-03-06 15:43:01 --> Output Class Initialized
INFO - 2024-03-06 15:43:01 --> Security Class Initialized
DEBUG - 2024-03-06 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:43:01 --> Input Class Initialized
INFO - 2024-03-06 15:43:01 --> Language Class Initialized
INFO - 2024-03-06 15:43:01 --> Language Class Initialized
INFO - 2024-03-06 15:43:01 --> Config Class Initialized
INFO - 2024-03-06 15:43:01 --> Loader Class Initialized
INFO - 2024-03-06 15:43:01 --> Helper loaded: url_helper
INFO - 2024-03-06 15:43:01 --> Helper loaded: file_helper
INFO - 2024-03-06 15:43:01 --> Helper loaded: form_helper
INFO - 2024-03-06 15:43:01 --> Helper loaded: my_helper
INFO - 2024-03-06 15:43:01 --> Database Driver Class Initialized
INFO - 2024-03-06 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:43:01 --> Controller Class Initialized
DEBUG - 2024-03-06 15:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:43:01 --> Final output sent to browser
DEBUG - 2024-03-06 15:43:01 --> Total execution time: 0.0442
INFO - 2024-03-06 15:43:05 --> Config Class Initialized
INFO - 2024-03-06 15:43:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:43:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:43:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:43:05 --> URI Class Initialized
INFO - 2024-03-06 15:43:05 --> Router Class Initialized
INFO - 2024-03-06 15:43:05 --> Output Class Initialized
INFO - 2024-03-06 15:43:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:43:05 --> Input Class Initialized
INFO - 2024-03-06 15:43:05 --> Language Class Initialized
INFO - 2024-03-06 15:43:05 --> Language Class Initialized
INFO - 2024-03-06 15:43:05 --> Config Class Initialized
INFO - 2024-03-06 15:43:05 --> Loader Class Initialized
INFO - 2024-03-06 15:43:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:43:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:43:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:43:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:43:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:43:05 --> Controller Class Initialized
DEBUG - 2024-03-06 15:43:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:43:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:43:05 --> Final output sent to browser
DEBUG - 2024-03-06 15:43:05 --> Total execution time: 0.0809
INFO - 2024-03-06 15:44:01 --> Config Class Initialized
INFO - 2024-03-06 15:44:01 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:01 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:01 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:01 --> URI Class Initialized
INFO - 2024-03-06 15:44:01 --> Router Class Initialized
INFO - 2024-03-06 15:44:01 --> Output Class Initialized
INFO - 2024-03-06 15:44:01 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:01 --> Input Class Initialized
INFO - 2024-03-06 15:44:01 --> Language Class Initialized
INFO - 2024-03-06 15:44:01 --> Language Class Initialized
INFO - 2024-03-06 15:44:01 --> Config Class Initialized
INFO - 2024-03-06 15:44:01 --> Loader Class Initialized
INFO - 2024-03-06 15:44:01 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:01 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:01 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:01 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:01 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:01 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:44:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:01 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:01 --> Total execution time: 0.2244
INFO - 2024-03-06 15:44:03 --> Config Class Initialized
INFO - 2024-03-06 15:44:03 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:03 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:03 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:03 --> URI Class Initialized
DEBUG - 2024-03-06 15:44:03 --> No URI present. Default controller set.
INFO - 2024-03-06 15:44:03 --> Router Class Initialized
INFO - 2024-03-06 15:44:03 --> Output Class Initialized
INFO - 2024-03-06 15:44:03 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:03 --> Input Class Initialized
INFO - 2024-03-06 15:44:03 --> Language Class Initialized
INFO - 2024-03-06 15:44:03 --> Language Class Initialized
INFO - 2024-03-06 15:44:03 --> Config Class Initialized
INFO - 2024-03-06 15:44:03 --> Loader Class Initialized
INFO - 2024-03-06 15:44:03 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:03 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:03 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:03 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:04 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:04 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:44:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:04 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:04 --> Total execution time: 0.0942
INFO - 2024-03-06 15:44:05 --> Config Class Initialized
INFO - 2024-03-06 15:44:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:05 --> URI Class Initialized
INFO - 2024-03-06 15:44:05 --> Router Class Initialized
INFO - 2024-03-06 15:44:05 --> Output Class Initialized
INFO - 2024-03-06 15:44:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:05 --> Input Class Initialized
INFO - 2024-03-06 15:44:05 --> Language Class Initialized
INFO - 2024-03-06 15:44:05 --> Language Class Initialized
INFO - 2024-03-06 15:44:05 --> Config Class Initialized
INFO - 2024-03-06 15:44:05 --> Loader Class Initialized
INFO - 2024-03-06 15:44:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:05 --> Controller Class Initialized
INFO - 2024-03-06 15:44:05 --> Config Class Initialized
INFO - 2024-03-06 15:44:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:05 --> URI Class Initialized
INFO - 2024-03-06 15:44:05 --> Router Class Initialized
INFO - 2024-03-06 15:44:05 --> Output Class Initialized
INFO - 2024-03-06 15:44:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:05 --> Input Class Initialized
INFO - 2024-03-06 15:44:05 --> Language Class Initialized
INFO - 2024-03-06 15:44:05 --> Language Class Initialized
INFO - 2024-03-06 15:44:05 --> Config Class Initialized
INFO - 2024-03-06 15:44:05 --> Loader Class Initialized
INFO - 2024-03-06 15:44:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:05 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:44:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:05 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:05 --> Total execution time: 0.1020
INFO - 2024-03-06 15:44:08 --> Config Class Initialized
INFO - 2024-03-06 15:44:08 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:08 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:08 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:08 --> URI Class Initialized
INFO - 2024-03-06 15:44:08 --> Router Class Initialized
INFO - 2024-03-06 15:44:08 --> Output Class Initialized
INFO - 2024-03-06 15:44:08 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:08 --> Input Class Initialized
INFO - 2024-03-06 15:44:08 --> Language Class Initialized
INFO - 2024-03-06 15:44:08 --> Language Class Initialized
INFO - 2024-03-06 15:44:08 --> Config Class Initialized
INFO - 2024-03-06 15:44:08 --> Loader Class Initialized
INFO - 2024-03-06 15:44:08 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:08 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:08 --> Controller Class Initialized
INFO - 2024-03-06 15:44:08 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:44:08 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:08 --> Total execution time: 0.0491
INFO - 2024-03-06 15:44:08 --> Config Class Initialized
INFO - 2024-03-06 15:44:08 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:08 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:08 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:08 --> URI Class Initialized
INFO - 2024-03-06 15:44:08 --> Router Class Initialized
INFO - 2024-03-06 15:44:08 --> Output Class Initialized
INFO - 2024-03-06 15:44:08 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:08 --> Input Class Initialized
INFO - 2024-03-06 15:44:08 --> Language Class Initialized
INFO - 2024-03-06 15:44:08 --> Language Class Initialized
INFO - 2024-03-06 15:44:08 --> Config Class Initialized
INFO - 2024-03-06 15:44:08 --> Loader Class Initialized
INFO - 2024-03-06 15:44:08 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:08 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:08 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:08 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:44:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:08 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:08 --> Total execution time: 0.0387
INFO - 2024-03-06 15:44:11 --> Config Class Initialized
INFO - 2024-03-06 15:44:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:11 --> URI Class Initialized
INFO - 2024-03-06 15:44:11 --> Router Class Initialized
INFO - 2024-03-06 15:44:11 --> Output Class Initialized
INFO - 2024-03-06 15:44:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:11 --> Input Class Initialized
INFO - 2024-03-06 15:44:11 --> Language Class Initialized
INFO - 2024-03-06 15:44:11 --> Language Class Initialized
INFO - 2024-03-06 15:44:11 --> Config Class Initialized
INFO - 2024-03-06 15:44:11 --> Loader Class Initialized
INFO - 2024-03-06 15:44:11 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:11 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:11 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:11 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:11 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:11 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:11 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:11 --> Total execution time: 0.0598
INFO - 2024-03-06 15:44:19 --> Config Class Initialized
INFO - 2024-03-06 15:44:19 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:19 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:19 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:19 --> URI Class Initialized
INFO - 2024-03-06 15:44:19 --> Router Class Initialized
INFO - 2024-03-06 15:44:19 --> Output Class Initialized
INFO - 2024-03-06 15:44:19 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:19 --> Input Class Initialized
INFO - 2024-03-06 15:44:19 --> Language Class Initialized
INFO - 2024-03-06 15:44:19 --> Language Class Initialized
INFO - 2024-03-06 15:44:19 --> Config Class Initialized
INFO - 2024-03-06 15:44:19 --> Loader Class Initialized
INFO - 2024-03-06 15:44:19 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:19 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:19 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:19 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:19 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:19 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:19 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:19 --> Total execution time: 0.0317
INFO - 2024-03-06 15:44:40 --> Config Class Initialized
INFO - 2024-03-06 15:44:40 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:40 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:40 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:40 --> URI Class Initialized
INFO - 2024-03-06 15:44:40 --> Router Class Initialized
INFO - 2024-03-06 15:44:40 --> Output Class Initialized
INFO - 2024-03-06 15:44:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:40 --> Input Class Initialized
INFO - 2024-03-06 15:44:40 --> Language Class Initialized
INFO - 2024-03-06 15:44:40 --> Language Class Initialized
INFO - 2024-03-06 15:44:40 --> Config Class Initialized
INFO - 2024-03-06 15:44:40 --> Loader Class Initialized
INFO - 2024-03-06 15:44:40 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:40 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:40 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:40 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:40 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:40 --> Controller Class Initialized
INFO - 2024-03-06 15:44:41 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:44:41 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:41 --> Total execution time: 0.0685
INFO - 2024-03-06 15:44:41 --> Config Class Initialized
INFO - 2024-03-06 15:44:41 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:41 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:41 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:41 --> URI Class Initialized
INFO - 2024-03-06 15:44:41 --> Router Class Initialized
INFO - 2024-03-06 15:44:41 --> Output Class Initialized
INFO - 2024-03-06 15:44:41 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:41 --> Input Class Initialized
INFO - 2024-03-06 15:44:41 --> Language Class Initialized
INFO - 2024-03-06 15:44:41 --> Language Class Initialized
INFO - 2024-03-06 15:44:41 --> Config Class Initialized
INFO - 2024-03-06 15:44:41 --> Loader Class Initialized
INFO - 2024-03-06 15:44:41 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:41 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:41 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:41 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:41 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:41 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:44:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:41 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:41 --> Total execution time: 0.3164
INFO - 2024-03-06 15:44:45 --> Config Class Initialized
INFO - 2024-03-06 15:44:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:45 --> URI Class Initialized
INFO - 2024-03-06 15:44:45 --> Router Class Initialized
INFO - 2024-03-06 15:44:45 --> Output Class Initialized
INFO - 2024-03-06 15:44:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:45 --> Input Class Initialized
INFO - 2024-03-06 15:44:45 --> Language Class Initialized
INFO - 2024-03-06 15:44:45 --> Language Class Initialized
INFO - 2024-03-06 15:44:45 --> Config Class Initialized
INFO - 2024-03-06 15:44:45 --> Loader Class Initialized
INFO - 2024-03-06 15:44:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:45 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-06 15:44:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:45 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:45 --> Total execution time: 0.0415
INFO - 2024-03-06 15:44:54 --> Config Class Initialized
INFO - 2024-03-06 15:44:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:44:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:44:54 --> Utf8 Class Initialized
INFO - 2024-03-06 15:44:54 --> URI Class Initialized
INFO - 2024-03-06 15:44:54 --> Router Class Initialized
INFO - 2024-03-06 15:44:54 --> Output Class Initialized
INFO - 2024-03-06 15:44:54 --> Security Class Initialized
DEBUG - 2024-03-06 15:44:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:44:54 --> Input Class Initialized
INFO - 2024-03-06 15:44:54 --> Language Class Initialized
INFO - 2024-03-06 15:44:54 --> Language Class Initialized
INFO - 2024-03-06 15:44:54 --> Config Class Initialized
INFO - 2024-03-06 15:44:54 --> Loader Class Initialized
INFO - 2024-03-06 15:44:54 --> Helper loaded: url_helper
INFO - 2024-03-06 15:44:54 --> Helper loaded: file_helper
INFO - 2024-03-06 15:44:54 --> Helper loaded: form_helper
INFO - 2024-03-06 15:44:54 --> Helper loaded: my_helper
INFO - 2024-03-06 15:44:54 --> Database Driver Class Initialized
INFO - 2024-03-06 15:44:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:44:54 --> Controller Class Initialized
DEBUG - 2024-03-06 15:44:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 15:44:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:44:54 --> Final output sent to browser
DEBUG - 2024-03-06 15:44:54 --> Total execution time: 0.0328
INFO - 2024-03-06 15:45:03 --> Config Class Initialized
INFO - 2024-03-06 15:45:03 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:03 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:03 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:03 --> URI Class Initialized
INFO - 2024-03-06 15:45:03 --> Router Class Initialized
INFO - 2024-03-06 15:45:03 --> Output Class Initialized
INFO - 2024-03-06 15:45:03 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:03 --> Input Class Initialized
INFO - 2024-03-06 15:45:03 --> Language Class Initialized
INFO - 2024-03-06 15:45:03 --> Language Class Initialized
INFO - 2024-03-06 15:45:03 --> Config Class Initialized
INFO - 2024-03-06 15:45:03 --> Loader Class Initialized
INFO - 2024-03-06 15:45:03 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:03 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:03 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:03 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:03 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:03 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-03-06 15:45:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:03 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:03 --> Total execution time: 0.1050
INFO - 2024-03-06 15:45:06 --> Config Class Initialized
INFO - 2024-03-06 15:45:06 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:06 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:06 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:06 --> URI Class Initialized
INFO - 2024-03-06 15:45:07 --> Router Class Initialized
INFO - 2024-03-06 15:45:07 --> Output Class Initialized
INFO - 2024-03-06 15:45:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:07 --> Input Class Initialized
INFO - 2024-03-06 15:45:07 --> Language Class Initialized
INFO - 2024-03-06 15:45:07 --> Language Class Initialized
INFO - 2024-03-06 15:45:07 --> Config Class Initialized
INFO - 2024-03-06 15:45:07 --> Loader Class Initialized
INFO - 2024-03-06 15:45:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:07 --> Controller Class Initialized
INFO - 2024-03-06 15:45:07 --> Helper loaded: cookie_helper
INFO - 2024-03-06 15:45:07 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:07 --> Total execution time: 0.0935
INFO - 2024-03-06 15:45:07 --> Config Class Initialized
INFO - 2024-03-06 15:45:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:07 --> URI Class Initialized
INFO - 2024-03-06 15:45:07 --> Router Class Initialized
INFO - 2024-03-06 15:45:07 --> Output Class Initialized
INFO - 2024-03-06 15:45:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:07 --> Input Class Initialized
INFO - 2024-03-06 15:45:07 --> Language Class Initialized
INFO - 2024-03-06 15:45:07 --> Language Class Initialized
INFO - 2024-03-06 15:45:07 --> Config Class Initialized
INFO - 2024-03-06 15:45:07 --> Loader Class Initialized
INFO - 2024-03-06 15:45:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:07 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 15:45:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:07 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:07 --> Total execution time: 0.0470
INFO - 2024-03-06 15:45:10 --> Config Class Initialized
INFO - 2024-03-06 15:45:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:10 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:10 --> URI Class Initialized
INFO - 2024-03-06 15:45:10 --> Router Class Initialized
INFO - 2024-03-06 15:45:10 --> Output Class Initialized
INFO - 2024-03-06 15:45:10 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:10 --> Input Class Initialized
INFO - 2024-03-06 15:45:10 --> Language Class Initialized
INFO - 2024-03-06 15:45:10 --> Language Class Initialized
INFO - 2024-03-06 15:45:10 --> Config Class Initialized
INFO - 2024-03-06 15:45:10 --> Loader Class Initialized
INFO - 2024-03-06 15:45:10 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:10 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:10 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:10 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:10 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:10 --> Controller Class Initialized
ERROR - 2024-03-06 15:45:10 --> Severity: Notice --> Undefined variable: q_siswa_kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2024-03-06 15:45:10 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 115
ERROR - 2024-03-06 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 130
ERROR - 2024-03-06 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 130
ERROR - 2024-03-06 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 130
ERROR - 2024-03-06 15:45:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/controllers/N_pengetahuan.php 150
DEBUG - 2024-03-06 15:45:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-06 15:45:10 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:10 --> Total execution time: 0.2177
INFO - 2024-03-06 15:45:14 --> Config Class Initialized
INFO - 2024-03-06 15:45:14 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:14 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:14 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:14 --> URI Class Initialized
INFO - 2024-03-06 15:45:14 --> Router Class Initialized
INFO - 2024-03-06 15:45:14 --> Output Class Initialized
INFO - 2024-03-06 15:45:14 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:14 --> Input Class Initialized
INFO - 2024-03-06 15:45:14 --> Language Class Initialized
INFO - 2024-03-06 15:45:14 --> Language Class Initialized
INFO - 2024-03-06 15:45:14 --> Config Class Initialized
INFO - 2024-03-06 15:45:14 --> Loader Class Initialized
INFO - 2024-03-06 15:45:14 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:14 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:14 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:14 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:14 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:14 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-03-06 15:45:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:14 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:14 --> Total execution time: 0.0455
INFO - 2024-03-06 15:45:16 --> Config Class Initialized
INFO - 2024-03-06 15:45:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:16 --> URI Class Initialized
INFO - 2024-03-06 15:45:16 --> Router Class Initialized
INFO - 2024-03-06 15:45:16 --> Output Class Initialized
INFO - 2024-03-06 15:45:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:16 --> Input Class Initialized
INFO - 2024-03-06 15:45:16 --> Language Class Initialized
INFO - 2024-03-06 15:45:16 --> Language Class Initialized
INFO - 2024-03-06 15:45:16 --> Config Class Initialized
INFO - 2024-03-06 15:45:16 --> Loader Class Initialized
INFO - 2024-03-06 15:45:16 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:16 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:16 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:16 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:16 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:16 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-03-06 15:45:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:16 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:16 --> Total execution time: 0.0423
INFO - 2024-03-06 15:45:19 --> Config Class Initialized
INFO - 2024-03-06 15:45:19 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:19 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:19 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:19 --> URI Class Initialized
INFO - 2024-03-06 15:45:19 --> Router Class Initialized
INFO - 2024-03-06 15:45:19 --> Output Class Initialized
INFO - 2024-03-06 15:45:19 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:19 --> Input Class Initialized
INFO - 2024-03-06 15:45:19 --> Language Class Initialized
INFO - 2024-03-06 15:45:19 --> Language Class Initialized
INFO - 2024-03-06 15:45:19 --> Config Class Initialized
INFO - 2024-03-06 15:45:19 --> Loader Class Initialized
INFO - 2024-03-06 15:45:19 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:19 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:19 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:19 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:19 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:19 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-03-06 15:45:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:19 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:19 --> Total execution time: 0.2380
INFO - 2024-03-06 15:45:20 --> Config Class Initialized
INFO - 2024-03-06 15:45:20 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:20 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:20 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:20 --> URI Class Initialized
INFO - 2024-03-06 15:45:20 --> Router Class Initialized
INFO - 2024-03-06 15:45:20 --> Output Class Initialized
INFO - 2024-03-06 15:45:20 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:20 --> Input Class Initialized
INFO - 2024-03-06 15:45:20 --> Language Class Initialized
INFO - 2024-03-06 15:45:20 --> Language Class Initialized
INFO - 2024-03-06 15:45:20 --> Config Class Initialized
INFO - 2024-03-06 15:45:20 --> Loader Class Initialized
INFO - 2024-03-06 15:45:20 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:20 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:20 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:20 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:20 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:20 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-03-06 15:45:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:20 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:20 --> Total execution time: 0.0382
INFO - 2024-03-06 15:45:21 --> Config Class Initialized
INFO - 2024-03-06 15:45:21 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:21 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:21 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:21 --> URI Class Initialized
INFO - 2024-03-06 15:45:21 --> Router Class Initialized
INFO - 2024-03-06 15:45:21 --> Output Class Initialized
INFO - 2024-03-06 15:45:21 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:21 --> Input Class Initialized
INFO - 2024-03-06 15:45:21 --> Language Class Initialized
INFO - 2024-03-06 15:45:21 --> Language Class Initialized
INFO - 2024-03-06 15:45:21 --> Config Class Initialized
INFO - 2024-03-06 15:45:21 --> Loader Class Initialized
INFO - 2024-03-06 15:45:21 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:21 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:21 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:21 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:21 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:21 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-03-06 15:45:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:21 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:21 --> Total execution time: 0.0490
INFO - 2024-03-06 15:45:21 --> Config Class Initialized
INFO - 2024-03-06 15:45:21 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:21 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:21 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:21 --> URI Class Initialized
INFO - 2024-03-06 15:45:21 --> Router Class Initialized
INFO - 2024-03-06 15:45:21 --> Output Class Initialized
INFO - 2024-03-06 15:45:21 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:21 --> Input Class Initialized
INFO - 2024-03-06 15:45:21 --> Language Class Initialized
ERROR - 2024-03-06 15:45:21 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:45:22 --> Config Class Initialized
INFO - 2024-03-06 15:45:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:22 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:22 --> URI Class Initialized
INFO - 2024-03-06 15:45:22 --> Router Class Initialized
INFO - 2024-03-06 15:45:22 --> Output Class Initialized
INFO - 2024-03-06 15:45:22 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:22 --> Input Class Initialized
INFO - 2024-03-06 15:45:22 --> Language Class Initialized
INFO - 2024-03-06 15:45:22 --> Language Class Initialized
INFO - 2024-03-06 15:45:22 --> Config Class Initialized
INFO - 2024-03-06 15:45:22 --> Loader Class Initialized
INFO - 2024-03-06 15:45:22 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:22 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:22 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:22 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:22 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:22 --> Controller Class Initialized
INFO - 2024-03-06 15:45:26 --> Config Class Initialized
INFO - 2024-03-06 15:45:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:26 --> URI Class Initialized
INFO - 2024-03-06 15:45:26 --> Router Class Initialized
INFO - 2024-03-06 15:45:26 --> Output Class Initialized
INFO - 2024-03-06 15:45:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:26 --> Input Class Initialized
INFO - 2024-03-06 15:45:26 --> Language Class Initialized
INFO - 2024-03-06 15:45:26 --> Language Class Initialized
INFO - 2024-03-06 15:45:26 --> Config Class Initialized
INFO - 2024-03-06 15:45:26 --> Loader Class Initialized
INFO - 2024-03-06 15:45:26 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:26 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:26 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-03-06 15:45:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:26 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:26 --> Total execution time: 0.0667
INFO - 2024-03-06 15:45:26 --> Config Class Initialized
INFO - 2024-03-06 15:45:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:26 --> URI Class Initialized
INFO - 2024-03-06 15:45:26 --> Router Class Initialized
INFO - 2024-03-06 15:45:26 --> Output Class Initialized
INFO - 2024-03-06 15:45:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:26 --> Input Class Initialized
INFO - 2024-03-06 15:45:26 --> Language Class Initialized
ERROR - 2024-03-06 15:45:26 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:45:26 --> Config Class Initialized
INFO - 2024-03-06 15:45:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:26 --> URI Class Initialized
INFO - 2024-03-06 15:45:26 --> Router Class Initialized
INFO - 2024-03-06 15:45:26 --> Output Class Initialized
INFO - 2024-03-06 15:45:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:26 --> Input Class Initialized
INFO - 2024-03-06 15:45:26 --> Language Class Initialized
INFO - 2024-03-06 15:45:26 --> Language Class Initialized
INFO - 2024-03-06 15:45:26 --> Config Class Initialized
INFO - 2024-03-06 15:45:26 --> Loader Class Initialized
INFO - 2024-03-06 15:45:26 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:26 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:26 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:26 --> Controller Class Initialized
INFO - 2024-03-06 15:45:28 --> Config Class Initialized
INFO - 2024-03-06 15:45:28 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:28 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:28 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:28 --> URI Class Initialized
DEBUG - 2024-03-06 15:45:28 --> No URI present. Default controller set.
INFO - 2024-03-06 15:45:28 --> Router Class Initialized
INFO - 2024-03-06 15:45:28 --> Output Class Initialized
INFO - 2024-03-06 15:45:28 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:28 --> Input Class Initialized
INFO - 2024-03-06 15:45:28 --> Language Class Initialized
INFO - 2024-03-06 15:45:28 --> Language Class Initialized
INFO - 2024-03-06 15:45:28 --> Config Class Initialized
INFO - 2024-03-06 15:45:28 --> Loader Class Initialized
INFO - 2024-03-06 15:45:28 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:28 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:28 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:28 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:28 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:28 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 15:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:28 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:28 --> Total execution time: 0.0739
INFO - 2024-03-06 15:45:46 --> Config Class Initialized
INFO - 2024-03-06 15:45:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:46 --> URI Class Initialized
INFO - 2024-03-06 15:45:46 --> Router Class Initialized
INFO - 2024-03-06 15:45:46 --> Output Class Initialized
INFO - 2024-03-06 15:45:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:46 --> Input Class Initialized
INFO - 2024-03-06 15:45:46 --> Language Class Initialized
INFO - 2024-03-06 15:45:46 --> Language Class Initialized
INFO - 2024-03-06 15:45:46 --> Config Class Initialized
INFO - 2024-03-06 15:45:46 --> Loader Class Initialized
INFO - 2024-03-06 15:45:46 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:46 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:46 --> Controller Class Initialized
DEBUG - 2024-03-06 15:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-06 15:45:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:45:46 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:46 --> Total execution time: 0.0389
INFO - 2024-03-06 15:45:46 --> Config Class Initialized
INFO - 2024-03-06 15:45:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:46 --> URI Class Initialized
INFO - 2024-03-06 15:45:46 --> Router Class Initialized
INFO - 2024-03-06 15:45:46 --> Output Class Initialized
INFO - 2024-03-06 15:45:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:46 --> Input Class Initialized
INFO - 2024-03-06 15:45:46 --> Language Class Initialized
ERROR - 2024-03-06 15:45:46 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:45:46 --> Config Class Initialized
INFO - 2024-03-06 15:45:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:46 --> URI Class Initialized
INFO - 2024-03-06 15:45:46 --> Router Class Initialized
INFO - 2024-03-06 15:45:46 --> Output Class Initialized
INFO - 2024-03-06 15:45:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:46 --> Input Class Initialized
INFO - 2024-03-06 15:45:46 --> Language Class Initialized
INFO - 2024-03-06 15:45:46 --> Language Class Initialized
INFO - 2024-03-06 15:45:46 --> Config Class Initialized
INFO - 2024-03-06 15:45:46 --> Loader Class Initialized
INFO - 2024-03-06 15:45:46 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:46 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:46 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:46 --> Controller Class Initialized
INFO - 2024-03-06 15:45:49 --> Config Class Initialized
INFO - 2024-03-06 15:45:49 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:45:49 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:45:49 --> Utf8 Class Initialized
INFO - 2024-03-06 15:45:49 --> URI Class Initialized
INFO - 2024-03-06 15:45:49 --> Router Class Initialized
INFO - 2024-03-06 15:45:49 --> Output Class Initialized
INFO - 2024-03-06 15:45:49 --> Security Class Initialized
DEBUG - 2024-03-06 15:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:45:49 --> Input Class Initialized
INFO - 2024-03-06 15:45:49 --> Language Class Initialized
INFO - 2024-03-06 15:45:49 --> Language Class Initialized
INFO - 2024-03-06 15:45:49 --> Config Class Initialized
INFO - 2024-03-06 15:45:49 --> Loader Class Initialized
INFO - 2024-03-06 15:45:49 --> Helper loaded: url_helper
INFO - 2024-03-06 15:45:49 --> Helper loaded: file_helper
INFO - 2024-03-06 15:45:49 --> Helper loaded: form_helper
INFO - 2024-03-06 15:45:49 --> Helper loaded: my_helper
INFO - 2024-03-06 15:45:49 --> Database Driver Class Initialized
INFO - 2024-03-06 15:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:45:49 --> Controller Class Initialized
INFO - 2024-03-06 15:45:49 --> Final output sent to browser
DEBUG - 2024-03-06 15:45:49 --> Total execution time: 0.0765
INFO - 2024-03-06 15:46:00 --> Config Class Initialized
INFO - 2024-03-06 15:46:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:46:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:46:00 --> Utf8 Class Initialized
INFO - 2024-03-06 15:46:00 --> URI Class Initialized
INFO - 2024-03-06 15:46:00 --> Router Class Initialized
INFO - 2024-03-06 15:46:00 --> Output Class Initialized
INFO - 2024-03-06 15:46:00 --> Security Class Initialized
DEBUG - 2024-03-06 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:46:00 --> Input Class Initialized
INFO - 2024-03-06 15:46:00 --> Language Class Initialized
INFO - 2024-03-06 15:46:00 --> Language Class Initialized
INFO - 2024-03-06 15:46:00 --> Config Class Initialized
INFO - 2024-03-06 15:46:00 --> Loader Class Initialized
INFO - 2024-03-06 15:46:00 --> Helper loaded: url_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: file_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: form_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: my_helper
INFO - 2024-03-06 15:46:00 --> Database Driver Class Initialized
INFO - 2024-03-06 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:46:00 --> Controller Class Initialized
INFO - 2024-03-06 15:46:00 --> Final output sent to browser
DEBUG - 2024-03-06 15:46:00 --> Total execution time: 0.0322
INFO - 2024-03-06 15:46:00 --> Config Class Initialized
INFO - 2024-03-06 15:46:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:46:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:46:00 --> Utf8 Class Initialized
INFO - 2024-03-06 15:46:00 --> URI Class Initialized
INFO - 2024-03-06 15:46:00 --> Router Class Initialized
INFO - 2024-03-06 15:46:00 --> Output Class Initialized
INFO - 2024-03-06 15:46:00 --> Security Class Initialized
DEBUG - 2024-03-06 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:46:00 --> Input Class Initialized
INFO - 2024-03-06 15:46:00 --> Language Class Initialized
ERROR - 2024-03-06 15:46:00 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:46:00 --> Config Class Initialized
INFO - 2024-03-06 15:46:00 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:46:00 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:46:00 --> Utf8 Class Initialized
INFO - 2024-03-06 15:46:00 --> URI Class Initialized
INFO - 2024-03-06 15:46:00 --> Router Class Initialized
INFO - 2024-03-06 15:46:00 --> Output Class Initialized
INFO - 2024-03-06 15:46:00 --> Security Class Initialized
DEBUG - 2024-03-06 15:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:46:00 --> Input Class Initialized
INFO - 2024-03-06 15:46:00 --> Language Class Initialized
INFO - 2024-03-06 15:46:00 --> Language Class Initialized
INFO - 2024-03-06 15:46:00 --> Config Class Initialized
INFO - 2024-03-06 15:46:00 --> Loader Class Initialized
INFO - 2024-03-06 15:46:00 --> Helper loaded: url_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: file_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: form_helper
INFO - 2024-03-06 15:46:00 --> Helper loaded: my_helper
INFO - 2024-03-06 15:46:00 --> Database Driver Class Initialized
INFO - 2024-03-06 15:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:46:00 --> Controller Class Initialized
INFO - 2024-03-06 15:46:53 --> Config Class Initialized
INFO - 2024-03-06 15:46:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:46:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:46:53 --> Utf8 Class Initialized
INFO - 2024-03-06 15:46:53 --> URI Class Initialized
DEBUG - 2024-03-06 15:46:53 --> No URI present. Default controller set.
INFO - 2024-03-06 15:46:53 --> Router Class Initialized
INFO - 2024-03-06 15:46:53 --> Output Class Initialized
INFO - 2024-03-06 15:46:53 --> Security Class Initialized
DEBUG - 2024-03-06 15:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:46:53 --> Input Class Initialized
INFO - 2024-03-06 15:46:53 --> Language Class Initialized
INFO - 2024-03-06 15:46:53 --> Language Class Initialized
INFO - 2024-03-06 15:46:53 --> Config Class Initialized
INFO - 2024-03-06 15:46:53 --> Loader Class Initialized
INFO - 2024-03-06 15:46:53 --> Helper loaded: url_helper
INFO - 2024-03-06 15:46:53 --> Helper loaded: file_helper
INFO - 2024-03-06 15:46:53 --> Helper loaded: form_helper
INFO - 2024-03-06 15:46:53 --> Helper loaded: my_helper
INFO - 2024-03-06 15:46:53 --> Database Driver Class Initialized
INFO - 2024-03-06 15:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:46:53 --> Controller Class Initialized
DEBUG - 2024-03-06 15:46:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-06 15:46:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:46:53 --> Final output sent to browser
DEBUG - 2024-03-06 15:46:53 --> Total execution time: 0.1078
INFO - 2024-03-06 15:48:43 --> Config Class Initialized
INFO - 2024-03-06 15:48:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:48:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:48:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:48:43 --> URI Class Initialized
INFO - 2024-03-06 15:48:43 --> Router Class Initialized
INFO - 2024-03-06 15:48:43 --> Output Class Initialized
INFO - 2024-03-06 15:48:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:48:43 --> Input Class Initialized
INFO - 2024-03-06 15:48:43 --> Language Class Initialized
INFO - 2024-03-06 15:48:43 --> Language Class Initialized
INFO - 2024-03-06 15:48:43 --> Config Class Initialized
INFO - 2024-03-06 15:48:43 --> Loader Class Initialized
INFO - 2024-03-06 15:48:43 --> Helper loaded: url_helper
INFO - 2024-03-06 15:48:43 --> Helper loaded: file_helper
INFO - 2024-03-06 15:48:43 --> Helper loaded: form_helper
INFO - 2024-03-06 15:48:43 --> Helper loaded: my_helper
INFO - 2024-03-06 15:48:43 --> Database Driver Class Initialized
INFO - 2024-03-06 15:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:48:43 --> Controller Class Initialized
INFO - 2024-03-06 15:48:43 --> Final output sent to browser
DEBUG - 2024-03-06 15:48:43 --> Total execution time: 0.0941
INFO - 2024-03-06 15:48:46 --> Config Class Initialized
INFO - 2024-03-06 15:48:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:48:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:48:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:48:46 --> URI Class Initialized
INFO - 2024-03-06 15:48:46 --> Router Class Initialized
INFO - 2024-03-06 15:48:46 --> Output Class Initialized
INFO - 2024-03-06 15:48:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:48:46 --> Input Class Initialized
INFO - 2024-03-06 15:48:46 --> Language Class Initialized
INFO - 2024-03-06 15:48:46 --> Language Class Initialized
INFO - 2024-03-06 15:48:46 --> Config Class Initialized
INFO - 2024-03-06 15:48:46 --> Loader Class Initialized
INFO - 2024-03-06 15:48:46 --> Helper loaded: url_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: file_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: form_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: my_helper
INFO - 2024-03-06 15:48:46 --> Database Driver Class Initialized
INFO - 2024-03-06 15:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:48:46 --> Controller Class Initialized
INFO - 2024-03-06 15:48:46 --> Final output sent to browser
DEBUG - 2024-03-06 15:48:46 --> Total execution time: 0.0640
INFO - 2024-03-06 15:48:46 --> Config Class Initialized
INFO - 2024-03-06 15:48:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:48:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:48:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:48:46 --> URI Class Initialized
INFO - 2024-03-06 15:48:46 --> Router Class Initialized
INFO - 2024-03-06 15:48:46 --> Output Class Initialized
INFO - 2024-03-06 15:48:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:48:46 --> Input Class Initialized
INFO - 2024-03-06 15:48:46 --> Language Class Initialized
ERROR - 2024-03-06 15:48:46 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:48:46 --> Config Class Initialized
INFO - 2024-03-06 15:48:46 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:48:46 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:48:46 --> Utf8 Class Initialized
INFO - 2024-03-06 15:48:46 --> URI Class Initialized
INFO - 2024-03-06 15:48:46 --> Router Class Initialized
INFO - 2024-03-06 15:48:46 --> Output Class Initialized
INFO - 2024-03-06 15:48:46 --> Security Class Initialized
DEBUG - 2024-03-06 15:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:48:46 --> Input Class Initialized
INFO - 2024-03-06 15:48:46 --> Language Class Initialized
INFO - 2024-03-06 15:48:46 --> Language Class Initialized
INFO - 2024-03-06 15:48:46 --> Config Class Initialized
INFO - 2024-03-06 15:48:46 --> Loader Class Initialized
INFO - 2024-03-06 15:48:46 --> Helper loaded: url_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: file_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: form_helper
INFO - 2024-03-06 15:48:46 --> Helper loaded: my_helper
INFO - 2024-03-06 15:48:46 --> Database Driver Class Initialized
INFO - 2024-03-06 15:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:48:46 --> Controller Class Initialized
INFO - 2024-03-06 15:48:56 --> Config Class Initialized
INFO - 2024-03-06 15:48:56 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:48:56 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:48:56 --> Utf8 Class Initialized
INFO - 2024-03-06 15:48:56 --> URI Class Initialized
DEBUG - 2024-03-06 15:48:56 --> No URI present. Default controller set.
INFO - 2024-03-06 15:48:56 --> Router Class Initialized
INFO - 2024-03-06 15:48:56 --> Output Class Initialized
INFO - 2024-03-06 15:48:56 --> Security Class Initialized
DEBUG - 2024-03-06 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:48:56 --> Input Class Initialized
INFO - 2024-03-06 15:48:56 --> Language Class Initialized
INFO - 2024-03-06 15:48:56 --> Language Class Initialized
INFO - 2024-03-06 15:48:56 --> Config Class Initialized
INFO - 2024-03-06 15:48:56 --> Loader Class Initialized
INFO - 2024-03-06 15:48:56 --> Helper loaded: url_helper
INFO - 2024-03-06 15:48:56 --> Helper loaded: file_helper
INFO - 2024-03-06 15:48:56 --> Helper loaded: form_helper
INFO - 2024-03-06 15:48:56 --> Helper loaded: my_helper
INFO - 2024-03-06 15:48:56 --> Database Driver Class Initialized
INFO - 2024-03-06 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:48:56 --> Controller Class Initialized
DEBUG - 2024-03-06 15:48:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 15:48:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:48:56 --> Final output sent to browser
DEBUG - 2024-03-06 15:48:56 --> Total execution time: 0.0372
INFO - 2024-03-06 15:49:09 --> Config Class Initialized
INFO - 2024-03-06 15:49:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:09 --> URI Class Initialized
INFO - 2024-03-06 15:49:09 --> Router Class Initialized
INFO - 2024-03-06 15:49:09 --> Output Class Initialized
INFO - 2024-03-06 15:49:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:09 --> Input Class Initialized
INFO - 2024-03-06 15:49:09 --> Language Class Initialized
INFO - 2024-03-06 15:49:09 --> Language Class Initialized
INFO - 2024-03-06 15:49:09 --> Config Class Initialized
INFO - 2024-03-06 15:49:09 --> Loader Class Initialized
INFO - 2024-03-06 15:49:09 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:09 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:09 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-03-06 15:49:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:09 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:09 --> Total execution time: 0.0596
INFO - 2024-03-06 15:49:09 --> Config Class Initialized
INFO - 2024-03-06 15:49:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:09 --> URI Class Initialized
INFO - 2024-03-06 15:49:09 --> Router Class Initialized
INFO - 2024-03-06 15:49:09 --> Output Class Initialized
INFO - 2024-03-06 15:49:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:09 --> Input Class Initialized
INFO - 2024-03-06 15:49:09 --> Language Class Initialized
ERROR - 2024-03-06 15:49:09 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:09 --> Config Class Initialized
INFO - 2024-03-06 15:49:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:09 --> URI Class Initialized
INFO - 2024-03-06 15:49:09 --> Router Class Initialized
INFO - 2024-03-06 15:49:09 --> Output Class Initialized
INFO - 2024-03-06 15:49:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:09 --> Input Class Initialized
INFO - 2024-03-06 15:49:09 --> Language Class Initialized
INFO - 2024-03-06 15:49:09 --> Language Class Initialized
INFO - 2024-03-06 15:49:09 --> Config Class Initialized
INFO - 2024-03-06 15:49:09 --> Loader Class Initialized
INFO - 2024-03-06 15:49:09 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:09 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:09 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:09 --> Controller Class Initialized
INFO - 2024-03-06 15:49:15 --> Config Class Initialized
INFO - 2024-03-06 15:49:15 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:15 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:15 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:15 --> URI Class Initialized
INFO - 2024-03-06 15:49:15 --> Router Class Initialized
INFO - 2024-03-06 15:49:15 --> Output Class Initialized
INFO - 2024-03-06 15:49:15 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:15 --> Input Class Initialized
INFO - 2024-03-06 15:49:15 --> Language Class Initialized
INFO - 2024-03-06 15:49:15 --> Language Class Initialized
INFO - 2024-03-06 15:49:15 --> Config Class Initialized
INFO - 2024-03-06 15:49:15 --> Loader Class Initialized
INFO - 2024-03-06 15:49:15 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:15 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:15 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:15 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:15 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:15 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-06 15:49:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:16 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:16 --> Total execution time: 0.0751
INFO - 2024-03-06 15:49:16 --> Config Class Initialized
INFO - 2024-03-06 15:49:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:16 --> URI Class Initialized
INFO - 2024-03-06 15:49:16 --> Router Class Initialized
INFO - 2024-03-06 15:49:16 --> Output Class Initialized
INFO - 2024-03-06 15:49:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:16 --> Input Class Initialized
INFO - 2024-03-06 15:49:16 --> Language Class Initialized
ERROR - 2024-03-06 15:49:16 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:16 --> Config Class Initialized
INFO - 2024-03-06 15:49:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:16 --> URI Class Initialized
INFO - 2024-03-06 15:49:16 --> Router Class Initialized
INFO - 2024-03-06 15:49:16 --> Output Class Initialized
INFO - 2024-03-06 15:49:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:16 --> Input Class Initialized
INFO - 2024-03-06 15:49:16 --> Language Class Initialized
INFO - 2024-03-06 15:49:16 --> Language Class Initialized
INFO - 2024-03-06 15:49:16 --> Config Class Initialized
INFO - 2024-03-06 15:49:16 --> Loader Class Initialized
INFO - 2024-03-06 15:49:16 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:16 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:16 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:16 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:16 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:16 --> Controller Class Initialized
INFO - 2024-03-06 15:49:20 --> Config Class Initialized
INFO - 2024-03-06 15:49:20 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:20 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:20 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:20 --> URI Class Initialized
INFO - 2024-03-06 15:49:20 --> Router Class Initialized
INFO - 2024-03-06 15:49:20 --> Output Class Initialized
INFO - 2024-03-06 15:49:20 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:20 --> Input Class Initialized
INFO - 2024-03-06 15:49:20 --> Language Class Initialized
INFO - 2024-03-06 15:49:20 --> Language Class Initialized
INFO - 2024-03-06 15:49:20 --> Config Class Initialized
INFO - 2024-03-06 15:49:20 --> Loader Class Initialized
INFO - 2024-03-06 15:49:20 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:20 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:20 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:20 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:20 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:20 --> Controller Class Initialized
INFO - 2024-03-06 15:49:20 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:20 --> Total execution time: 0.0533
INFO - 2024-03-06 15:49:25 --> Config Class Initialized
INFO - 2024-03-06 15:49:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:25 --> URI Class Initialized
INFO - 2024-03-06 15:49:25 --> Router Class Initialized
INFO - 2024-03-06 15:49:25 --> Output Class Initialized
INFO - 2024-03-06 15:49:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:25 --> Input Class Initialized
INFO - 2024-03-06 15:49:25 --> Language Class Initialized
INFO - 2024-03-06 15:49:25 --> Language Class Initialized
INFO - 2024-03-06 15:49:25 --> Config Class Initialized
INFO - 2024-03-06 15:49:25 --> Loader Class Initialized
INFO - 2024-03-06 15:49:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:25 --> Controller Class Initialized
INFO - 2024-03-06 15:49:25 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:25 --> Total execution time: 0.0896
INFO - 2024-03-06 15:49:25 --> Config Class Initialized
INFO - 2024-03-06 15:49:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:25 --> URI Class Initialized
INFO - 2024-03-06 15:49:25 --> Router Class Initialized
INFO - 2024-03-06 15:49:25 --> Output Class Initialized
INFO - 2024-03-06 15:49:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:25 --> Input Class Initialized
INFO - 2024-03-06 15:49:25 --> Language Class Initialized
ERROR - 2024-03-06 15:49:25 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:25 --> Config Class Initialized
INFO - 2024-03-06 15:49:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:25 --> URI Class Initialized
INFO - 2024-03-06 15:49:25 --> Router Class Initialized
INFO - 2024-03-06 15:49:25 --> Output Class Initialized
INFO - 2024-03-06 15:49:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:25 --> Input Class Initialized
INFO - 2024-03-06 15:49:25 --> Language Class Initialized
INFO - 2024-03-06 15:49:25 --> Language Class Initialized
INFO - 2024-03-06 15:49:25 --> Config Class Initialized
INFO - 2024-03-06 15:49:25 --> Loader Class Initialized
INFO - 2024-03-06 15:49:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:25 --> Controller Class Initialized
INFO - 2024-03-06 15:49:33 --> Config Class Initialized
INFO - 2024-03-06 15:49:33 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:33 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:33 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:33 --> URI Class Initialized
INFO - 2024-03-06 15:49:33 --> Router Class Initialized
INFO - 2024-03-06 15:49:33 --> Output Class Initialized
INFO - 2024-03-06 15:49:33 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:33 --> Input Class Initialized
INFO - 2024-03-06 15:49:33 --> Language Class Initialized
INFO - 2024-03-06 15:49:33 --> Language Class Initialized
INFO - 2024-03-06 15:49:33 --> Config Class Initialized
INFO - 2024-03-06 15:49:33 --> Loader Class Initialized
INFO - 2024-03-06 15:49:33 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:33 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:33 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:49:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:33 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:33 --> Total execution time: 0.1053
INFO - 2024-03-06 15:49:33 --> Config Class Initialized
INFO - 2024-03-06 15:49:33 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:33 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:33 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:33 --> URI Class Initialized
INFO - 2024-03-06 15:49:33 --> Router Class Initialized
INFO - 2024-03-06 15:49:33 --> Output Class Initialized
INFO - 2024-03-06 15:49:33 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:33 --> Input Class Initialized
INFO - 2024-03-06 15:49:33 --> Language Class Initialized
ERROR - 2024-03-06 15:49:33 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:33 --> Config Class Initialized
INFO - 2024-03-06 15:49:33 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:33 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:33 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:33 --> URI Class Initialized
INFO - 2024-03-06 15:49:33 --> Router Class Initialized
INFO - 2024-03-06 15:49:33 --> Output Class Initialized
INFO - 2024-03-06 15:49:33 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:33 --> Input Class Initialized
INFO - 2024-03-06 15:49:33 --> Language Class Initialized
INFO - 2024-03-06 15:49:33 --> Language Class Initialized
INFO - 2024-03-06 15:49:33 --> Config Class Initialized
INFO - 2024-03-06 15:49:33 --> Loader Class Initialized
INFO - 2024-03-06 15:49:33 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:33 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:33 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:33 --> Controller Class Initialized
INFO - 2024-03-06 15:49:38 --> Config Class Initialized
INFO - 2024-03-06 15:49:38 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:38 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:38 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:38 --> URI Class Initialized
INFO - 2024-03-06 15:49:38 --> Router Class Initialized
INFO - 2024-03-06 15:49:38 --> Output Class Initialized
INFO - 2024-03-06 15:49:38 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:38 --> Input Class Initialized
INFO - 2024-03-06 15:49:38 --> Language Class Initialized
INFO - 2024-03-06 15:49:38 --> Language Class Initialized
INFO - 2024-03-06 15:49:38 --> Config Class Initialized
INFO - 2024-03-06 15:49:38 --> Loader Class Initialized
INFO - 2024-03-06 15:49:38 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:38 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:38 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-06 15:49:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:38 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:38 --> Total execution time: 0.0500
INFO - 2024-03-06 15:49:38 --> Config Class Initialized
INFO - 2024-03-06 15:49:38 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:38 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:38 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:38 --> URI Class Initialized
INFO - 2024-03-06 15:49:38 --> Router Class Initialized
INFO - 2024-03-06 15:49:38 --> Output Class Initialized
INFO - 2024-03-06 15:49:38 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:38 --> Input Class Initialized
INFO - 2024-03-06 15:49:38 --> Language Class Initialized
ERROR - 2024-03-06 15:49:38 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:38 --> Config Class Initialized
INFO - 2024-03-06 15:49:38 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:38 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:38 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:38 --> URI Class Initialized
INFO - 2024-03-06 15:49:38 --> Router Class Initialized
INFO - 2024-03-06 15:49:38 --> Output Class Initialized
INFO - 2024-03-06 15:49:38 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:38 --> Input Class Initialized
INFO - 2024-03-06 15:49:38 --> Language Class Initialized
INFO - 2024-03-06 15:49:38 --> Language Class Initialized
INFO - 2024-03-06 15:49:38 --> Config Class Initialized
INFO - 2024-03-06 15:49:38 --> Loader Class Initialized
INFO - 2024-03-06 15:49:38 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:38 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:38 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:38 --> Controller Class Initialized
INFO - 2024-03-06 15:49:43 --> Config Class Initialized
INFO - 2024-03-06 15:49:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:43 --> URI Class Initialized
INFO - 2024-03-06 15:49:43 --> Router Class Initialized
INFO - 2024-03-06 15:49:43 --> Output Class Initialized
INFO - 2024-03-06 15:49:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:43 --> Input Class Initialized
INFO - 2024-03-06 15:49:43 --> Language Class Initialized
INFO - 2024-03-06 15:49:43 --> Language Class Initialized
INFO - 2024-03-06 15:49:43 --> Config Class Initialized
INFO - 2024-03-06 15:49:43 --> Loader Class Initialized
INFO - 2024-03-06 15:49:43 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:43 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:43 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:43 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:43 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:43 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:49:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:43 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:43 --> Total execution time: 0.0371
INFO - 2024-03-06 15:49:43 --> Config Class Initialized
INFO - 2024-03-06 15:49:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:43 --> URI Class Initialized
INFO - 2024-03-06 15:49:43 --> Router Class Initialized
INFO - 2024-03-06 15:49:44 --> Output Class Initialized
INFO - 2024-03-06 15:49:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:44 --> Input Class Initialized
INFO - 2024-03-06 15:49:44 --> Language Class Initialized
ERROR - 2024-03-06 15:49:44 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:49:44 --> Config Class Initialized
INFO - 2024-03-06 15:49:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:44 --> URI Class Initialized
INFO - 2024-03-06 15:49:44 --> Router Class Initialized
INFO - 2024-03-06 15:49:44 --> Output Class Initialized
INFO - 2024-03-06 15:49:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:44 --> Input Class Initialized
INFO - 2024-03-06 15:49:44 --> Language Class Initialized
INFO - 2024-03-06 15:49:44 --> Language Class Initialized
INFO - 2024-03-06 15:49:44 --> Config Class Initialized
INFO - 2024-03-06 15:49:44 --> Loader Class Initialized
INFO - 2024-03-06 15:49:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:44 --> Controller Class Initialized
INFO - 2024-03-06 15:49:45 --> Config Class Initialized
INFO - 2024-03-06 15:49:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:49:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:49:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:49:45 --> URI Class Initialized
INFO - 2024-03-06 15:49:45 --> Router Class Initialized
INFO - 2024-03-06 15:49:45 --> Output Class Initialized
INFO - 2024-03-06 15:49:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:49:45 --> Input Class Initialized
INFO - 2024-03-06 15:49:45 --> Language Class Initialized
INFO - 2024-03-06 15:49:45 --> Language Class Initialized
INFO - 2024-03-06 15:49:45 --> Config Class Initialized
INFO - 2024-03-06 15:49:45 --> Loader Class Initialized
INFO - 2024-03-06 15:49:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:49:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:49:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:49:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:49:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:49:45 --> Controller Class Initialized
DEBUG - 2024-03-06 15:49:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:49:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:49:45 --> Final output sent to browser
DEBUG - 2024-03-06 15:49:45 --> Total execution time: 0.0822
INFO - 2024-03-06 15:50:01 --> Config Class Initialized
INFO - 2024-03-06 15:50:01 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:50:01 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:50:01 --> Utf8 Class Initialized
INFO - 2024-03-06 15:50:01 --> URI Class Initialized
INFO - 2024-03-06 15:50:01 --> Router Class Initialized
INFO - 2024-03-06 15:50:01 --> Output Class Initialized
INFO - 2024-03-06 15:50:01 --> Security Class Initialized
DEBUG - 2024-03-06 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:50:01 --> Input Class Initialized
INFO - 2024-03-06 15:50:01 --> Language Class Initialized
INFO - 2024-03-06 15:50:01 --> Language Class Initialized
INFO - 2024-03-06 15:50:01 --> Config Class Initialized
INFO - 2024-03-06 15:50:01 --> Loader Class Initialized
INFO - 2024-03-06 15:50:01 --> Helper loaded: url_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: file_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: form_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: my_helper
INFO - 2024-03-06 15:50:01 --> Database Driver Class Initialized
INFO - 2024-03-06 15:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:50:01 --> Controller Class Initialized
INFO - 2024-03-06 15:50:01 --> Config Class Initialized
INFO - 2024-03-06 15:50:01 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:50:01 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:50:01 --> Utf8 Class Initialized
INFO - 2024-03-06 15:50:01 --> URI Class Initialized
INFO - 2024-03-06 15:50:01 --> Router Class Initialized
INFO - 2024-03-06 15:50:01 --> Output Class Initialized
INFO - 2024-03-06 15:50:01 --> Security Class Initialized
DEBUG - 2024-03-06 15:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:50:01 --> Input Class Initialized
INFO - 2024-03-06 15:50:01 --> Language Class Initialized
INFO - 2024-03-06 15:50:01 --> Language Class Initialized
INFO - 2024-03-06 15:50:01 --> Config Class Initialized
INFO - 2024-03-06 15:50:01 --> Loader Class Initialized
INFO - 2024-03-06 15:50:01 --> Helper loaded: url_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: file_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: form_helper
INFO - 2024-03-06 15:50:01 --> Helper loaded: my_helper
INFO - 2024-03-06 15:50:01 --> Database Driver Class Initialized
INFO - 2024-03-06 15:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:50:01 --> Controller Class Initialized
DEBUG - 2024-03-06 15:50:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:50:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:50:01 --> Final output sent to browser
DEBUG - 2024-03-06 15:50:01 --> Total execution time: 0.2056
INFO - 2024-03-06 15:50:02 --> Config Class Initialized
INFO - 2024-03-06 15:50:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:50:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:50:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:50:02 --> URI Class Initialized
INFO - 2024-03-06 15:50:02 --> Router Class Initialized
INFO - 2024-03-06 15:50:02 --> Output Class Initialized
INFO - 2024-03-06 15:50:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:50:02 --> Input Class Initialized
INFO - 2024-03-06 15:50:02 --> Language Class Initialized
ERROR - 2024-03-06 15:50:02 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:50:02 --> Config Class Initialized
INFO - 2024-03-06 15:50:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:50:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:50:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:50:02 --> URI Class Initialized
INFO - 2024-03-06 15:50:02 --> Router Class Initialized
INFO - 2024-03-06 15:50:02 --> Output Class Initialized
INFO - 2024-03-06 15:50:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:50:02 --> Input Class Initialized
INFO - 2024-03-06 15:50:02 --> Language Class Initialized
INFO - 2024-03-06 15:50:02 --> Language Class Initialized
INFO - 2024-03-06 15:50:02 --> Config Class Initialized
INFO - 2024-03-06 15:50:02 --> Loader Class Initialized
INFO - 2024-03-06 15:50:02 --> Helper loaded: url_helper
INFO - 2024-03-06 15:50:02 --> Helper loaded: file_helper
INFO - 2024-03-06 15:50:02 --> Helper loaded: form_helper
INFO - 2024-03-06 15:50:02 --> Helper loaded: my_helper
INFO - 2024-03-06 15:50:02 --> Database Driver Class Initialized
INFO - 2024-03-06 15:50:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:50:02 --> Controller Class Initialized
INFO - 2024-03-06 15:50:06 --> Config Class Initialized
INFO - 2024-03-06 15:50:06 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:50:06 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:50:06 --> Utf8 Class Initialized
INFO - 2024-03-06 15:50:06 --> URI Class Initialized
INFO - 2024-03-06 15:50:06 --> Router Class Initialized
INFO - 2024-03-06 15:50:06 --> Output Class Initialized
INFO - 2024-03-06 15:50:06 --> Security Class Initialized
DEBUG - 2024-03-06 15:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:50:06 --> Input Class Initialized
INFO - 2024-03-06 15:50:06 --> Language Class Initialized
INFO - 2024-03-06 15:50:06 --> Language Class Initialized
INFO - 2024-03-06 15:50:06 --> Config Class Initialized
INFO - 2024-03-06 15:50:06 --> Loader Class Initialized
INFO - 2024-03-06 15:50:06 --> Helper loaded: url_helper
INFO - 2024-03-06 15:50:06 --> Helper loaded: file_helper
INFO - 2024-03-06 15:50:06 --> Helper loaded: form_helper
INFO - 2024-03-06 15:50:06 --> Helper loaded: my_helper
INFO - 2024-03-06 15:50:06 --> Database Driver Class Initialized
INFO - 2024-03-06 15:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:50:06 --> Controller Class Initialized
DEBUG - 2024-03-06 15:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:50:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:50:06 --> Final output sent to browser
DEBUG - 2024-03-06 15:50:06 --> Total execution time: 0.0397
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:07 --> URI Class Initialized
INFO - 2024-03-06 15:51:07 --> Router Class Initialized
INFO - 2024-03-06 15:51:07 --> Output Class Initialized
INFO - 2024-03-06 15:51:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:07 --> Input Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Loader Class Initialized
INFO - 2024-03-06 15:51:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:07 --> Controller Class Initialized
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:07 --> URI Class Initialized
INFO - 2024-03-06 15:51:07 --> Router Class Initialized
INFO - 2024-03-06 15:51:07 --> Output Class Initialized
INFO - 2024-03-06 15:51:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:07 --> Input Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Loader Class Initialized
INFO - 2024-03-06 15:51:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:07 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:51:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:07 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:07 --> Total execution time: 0.0377
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:07 --> URI Class Initialized
INFO - 2024-03-06 15:51:07 --> Router Class Initialized
INFO - 2024-03-06 15:51:07 --> Output Class Initialized
INFO - 2024-03-06 15:51:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:07 --> Input Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
ERROR - 2024-03-06 15:51:07 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:07 --> URI Class Initialized
INFO - 2024-03-06 15:51:07 --> Router Class Initialized
INFO - 2024-03-06 15:51:07 --> Output Class Initialized
INFO - 2024-03-06 15:51:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:07 --> Input Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Language Class Initialized
INFO - 2024-03-06 15:51:07 --> Config Class Initialized
INFO - 2024-03-06 15:51:07 --> Loader Class Initialized
INFO - 2024-03-06 15:51:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:07 --> Controller Class Initialized
INFO - 2024-03-06 15:51:09 --> Config Class Initialized
INFO - 2024-03-06 15:51:09 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:09 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:09 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:09 --> URI Class Initialized
INFO - 2024-03-06 15:51:09 --> Router Class Initialized
INFO - 2024-03-06 15:51:09 --> Output Class Initialized
INFO - 2024-03-06 15:51:09 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:09 --> Input Class Initialized
INFO - 2024-03-06 15:51:09 --> Language Class Initialized
INFO - 2024-03-06 15:51:09 --> Language Class Initialized
INFO - 2024-03-06 15:51:09 --> Config Class Initialized
INFO - 2024-03-06 15:51:09 --> Loader Class Initialized
INFO - 2024-03-06 15:51:09 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:09 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:09 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:09 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:09 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:09 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:51:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:09 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:09 --> Total execution time: 0.0939
INFO - 2024-03-06 15:51:24 --> Config Class Initialized
INFO - 2024-03-06 15:51:24 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:24 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:24 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:24 --> URI Class Initialized
INFO - 2024-03-06 15:51:24 --> Router Class Initialized
INFO - 2024-03-06 15:51:24 --> Output Class Initialized
INFO - 2024-03-06 15:51:24 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:24 --> Input Class Initialized
INFO - 2024-03-06 15:51:24 --> Language Class Initialized
INFO - 2024-03-06 15:51:24 --> Language Class Initialized
INFO - 2024-03-06 15:51:24 --> Config Class Initialized
INFO - 2024-03-06 15:51:24 --> Loader Class Initialized
INFO - 2024-03-06 15:51:24 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:24 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:24 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:24 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:24 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:24 --> Controller Class Initialized
INFO - 2024-03-06 15:51:25 --> Config Class Initialized
INFO - 2024-03-06 15:51:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:25 --> URI Class Initialized
INFO - 2024-03-06 15:51:25 --> Router Class Initialized
INFO - 2024-03-06 15:51:25 --> Output Class Initialized
INFO - 2024-03-06 15:51:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:25 --> Input Class Initialized
INFO - 2024-03-06 15:51:25 --> Language Class Initialized
INFO - 2024-03-06 15:51:25 --> Language Class Initialized
INFO - 2024-03-06 15:51:25 --> Config Class Initialized
INFO - 2024-03-06 15:51:25 --> Loader Class Initialized
INFO - 2024-03-06 15:51:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:25 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:51:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:25 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:25 --> Total execution time: 0.0651
INFO - 2024-03-06 15:51:25 --> Config Class Initialized
INFO - 2024-03-06 15:51:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:25 --> URI Class Initialized
INFO - 2024-03-06 15:51:25 --> Router Class Initialized
INFO - 2024-03-06 15:51:25 --> Output Class Initialized
INFO - 2024-03-06 15:51:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:25 --> Input Class Initialized
INFO - 2024-03-06 15:51:25 --> Language Class Initialized
ERROR - 2024-03-06 15:51:25 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:51:25 --> Config Class Initialized
INFO - 2024-03-06 15:51:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:25 --> URI Class Initialized
INFO - 2024-03-06 15:51:25 --> Router Class Initialized
INFO - 2024-03-06 15:51:25 --> Output Class Initialized
INFO - 2024-03-06 15:51:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:25 --> Input Class Initialized
INFO - 2024-03-06 15:51:25 --> Language Class Initialized
INFO - 2024-03-06 15:51:25 --> Language Class Initialized
INFO - 2024-03-06 15:51:25 --> Config Class Initialized
INFO - 2024-03-06 15:51:25 --> Loader Class Initialized
INFO - 2024-03-06 15:51:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:25 --> Controller Class Initialized
INFO - 2024-03-06 15:51:27 --> Config Class Initialized
INFO - 2024-03-06 15:51:27 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:27 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:27 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:27 --> URI Class Initialized
INFO - 2024-03-06 15:51:27 --> Router Class Initialized
INFO - 2024-03-06 15:51:27 --> Output Class Initialized
INFO - 2024-03-06 15:51:27 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:27 --> Input Class Initialized
INFO - 2024-03-06 15:51:27 --> Language Class Initialized
INFO - 2024-03-06 15:51:27 --> Language Class Initialized
INFO - 2024-03-06 15:51:27 --> Config Class Initialized
INFO - 2024-03-06 15:51:27 --> Loader Class Initialized
INFO - 2024-03-06 15:51:27 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:27 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:27 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:27 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:27 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:27 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:51:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:27 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:27 --> Total execution time: 0.0767
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:40 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:40 --> URI Class Initialized
INFO - 2024-03-06 15:51:40 --> Router Class Initialized
INFO - 2024-03-06 15:51:40 --> Output Class Initialized
INFO - 2024-03-06 15:51:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:40 --> Input Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Loader Class Initialized
INFO - 2024-03-06 15:51:40 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:40 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:40 --> Controller Class Initialized
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:40 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:40 --> URI Class Initialized
INFO - 2024-03-06 15:51:40 --> Router Class Initialized
INFO - 2024-03-06 15:51:40 --> Output Class Initialized
INFO - 2024-03-06 15:51:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:40 --> Input Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Loader Class Initialized
INFO - 2024-03-06 15:51:40 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:40 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:40 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:51:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:40 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:40 --> Total execution time: 0.0389
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:40 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:40 --> URI Class Initialized
INFO - 2024-03-06 15:51:40 --> Router Class Initialized
INFO - 2024-03-06 15:51:40 --> Output Class Initialized
INFO - 2024-03-06 15:51:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:40 --> Input Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
ERROR - 2024-03-06 15:51:40 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:40 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:40 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:40 --> URI Class Initialized
INFO - 2024-03-06 15:51:40 --> Router Class Initialized
INFO - 2024-03-06 15:51:40 --> Output Class Initialized
INFO - 2024-03-06 15:51:40 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:40 --> Input Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Language Class Initialized
INFO - 2024-03-06 15:51:40 --> Config Class Initialized
INFO - 2024-03-06 15:51:40 --> Loader Class Initialized
INFO - 2024-03-06 15:51:40 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:40 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:40 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:40 --> Controller Class Initialized
INFO - 2024-03-06 15:51:43 --> Config Class Initialized
INFO - 2024-03-06 15:51:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:51:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:51:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:51:43 --> URI Class Initialized
INFO - 2024-03-06 15:51:43 --> Router Class Initialized
INFO - 2024-03-06 15:51:43 --> Output Class Initialized
INFO - 2024-03-06 15:51:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:51:43 --> Input Class Initialized
INFO - 2024-03-06 15:51:43 --> Language Class Initialized
INFO - 2024-03-06 15:51:43 --> Language Class Initialized
INFO - 2024-03-06 15:51:43 --> Config Class Initialized
INFO - 2024-03-06 15:51:43 --> Loader Class Initialized
INFO - 2024-03-06 15:51:43 --> Helper loaded: url_helper
INFO - 2024-03-06 15:51:43 --> Helper loaded: file_helper
INFO - 2024-03-06 15:51:43 --> Helper loaded: form_helper
INFO - 2024-03-06 15:51:43 --> Helper loaded: my_helper
INFO - 2024-03-06 15:51:43 --> Database Driver Class Initialized
INFO - 2024-03-06 15:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:51:43 --> Controller Class Initialized
DEBUG - 2024-03-06 15:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:51:43 --> Final output sent to browser
DEBUG - 2024-03-06 15:51:43 --> Total execution time: 0.0294
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:11 --> URI Class Initialized
INFO - 2024-03-06 15:52:11 --> Router Class Initialized
INFO - 2024-03-06 15:52:11 --> Output Class Initialized
INFO - 2024-03-06 15:52:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:11 --> Input Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Loader Class Initialized
INFO - 2024-03-06 15:52:11 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:11 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:11 --> Controller Class Initialized
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:11 --> URI Class Initialized
INFO - 2024-03-06 15:52:11 --> Router Class Initialized
INFO - 2024-03-06 15:52:11 --> Output Class Initialized
INFO - 2024-03-06 15:52:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:11 --> Input Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Loader Class Initialized
INFO - 2024-03-06 15:52:11 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:11 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:11 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:52:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:11 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:11 --> Total execution time: 0.0389
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:11 --> URI Class Initialized
INFO - 2024-03-06 15:52:11 --> Router Class Initialized
INFO - 2024-03-06 15:52:11 --> Output Class Initialized
INFO - 2024-03-06 15:52:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:11 --> Input Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
ERROR - 2024-03-06 15:52:11 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:11 --> URI Class Initialized
INFO - 2024-03-06 15:52:11 --> Router Class Initialized
INFO - 2024-03-06 15:52:11 --> Output Class Initialized
INFO - 2024-03-06 15:52:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:11 --> Input Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Language Class Initialized
INFO - 2024-03-06 15:52:11 --> Config Class Initialized
INFO - 2024-03-06 15:52:11 --> Loader Class Initialized
INFO - 2024-03-06 15:52:11 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:11 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:11 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:11 --> Controller Class Initialized
INFO - 2024-03-06 15:52:12 --> Config Class Initialized
INFO - 2024-03-06 15:52:12 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:12 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:12 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:12 --> URI Class Initialized
INFO - 2024-03-06 15:52:12 --> Router Class Initialized
INFO - 2024-03-06 15:52:12 --> Output Class Initialized
INFO - 2024-03-06 15:52:12 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:12 --> Input Class Initialized
INFO - 2024-03-06 15:52:12 --> Language Class Initialized
INFO - 2024-03-06 15:52:12 --> Language Class Initialized
INFO - 2024-03-06 15:52:12 --> Config Class Initialized
INFO - 2024-03-06 15:52:12 --> Loader Class Initialized
INFO - 2024-03-06 15:52:12 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:12 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:12 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:12 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:12 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:12 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:52:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:12 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:12 --> Total execution time: 0.0537
INFO - 2024-03-06 15:52:22 --> Config Class Initialized
INFO - 2024-03-06 15:52:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:22 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:22 --> URI Class Initialized
INFO - 2024-03-06 15:52:22 --> Router Class Initialized
INFO - 2024-03-06 15:52:22 --> Output Class Initialized
INFO - 2024-03-06 15:52:22 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:22 --> Input Class Initialized
INFO - 2024-03-06 15:52:22 --> Language Class Initialized
INFO - 2024-03-06 15:52:22 --> Language Class Initialized
INFO - 2024-03-06 15:52:22 --> Config Class Initialized
INFO - 2024-03-06 15:52:22 --> Loader Class Initialized
INFO - 2024-03-06 15:52:22 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:22 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:22 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:22 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:22 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:23 --> Controller Class Initialized
INFO - 2024-03-06 15:52:23 --> Config Class Initialized
INFO - 2024-03-06 15:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:23 --> URI Class Initialized
INFO - 2024-03-06 15:52:23 --> Router Class Initialized
INFO - 2024-03-06 15:52:23 --> Output Class Initialized
INFO - 2024-03-06 15:52:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:23 --> Input Class Initialized
INFO - 2024-03-06 15:52:23 --> Language Class Initialized
INFO - 2024-03-06 15:52:23 --> Language Class Initialized
INFO - 2024-03-06 15:52:23 --> Config Class Initialized
INFO - 2024-03-06 15:52:23 --> Loader Class Initialized
INFO - 2024-03-06 15:52:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:23 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:52:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:23 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:23 --> Total execution time: 0.0416
INFO - 2024-03-06 15:52:23 --> Config Class Initialized
INFO - 2024-03-06 15:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:23 --> URI Class Initialized
INFO - 2024-03-06 15:52:23 --> Router Class Initialized
INFO - 2024-03-06 15:52:23 --> Output Class Initialized
INFO - 2024-03-06 15:52:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:23 --> Input Class Initialized
INFO - 2024-03-06 15:52:23 --> Language Class Initialized
ERROR - 2024-03-06 15:52:23 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:52:23 --> Config Class Initialized
INFO - 2024-03-06 15:52:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:23 --> URI Class Initialized
INFO - 2024-03-06 15:52:23 --> Router Class Initialized
INFO - 2024-03-06 15:52:23 --> Output Class Initialized
INFO - 2024-03-06 15:52:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:23 --> Input Class Initialized
INFO - 2024-03-06 15:52:23 --> Language Class Initialized
INFO - 2024-03-06 15:52:23 --> Language Class Initialized
INFO - 2024-03-06 15:52:23 --> Config Class Initialized
INFO - 2024-03-06 15:52:23 --> Loader Class Initialized
INFO - 2024-03-06 15:52:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:23 --> Controller Class Initialized
INFO - 2024-03-06 15:52:26 --> Config Class Initialized
INFO - 2024-03-06 15:52:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:26 --> URI Class Initialized
INFO - 2024-03-06 15:52:26 --> Router Class Initialized
INFO - 2024-03-06 15:52:26 --> Output Class Initialized
INFO - 2024-03-06 15:52:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:26 --> Input Class Initialized
INFO - 2024-03-06 15:52:26 --> Language Class Initialized
INFO - 2024-03-06 15:52:26 --> Language Class Initialized
INFO - 2024-03-06 15:52:26 --> Config Class Initialized
INFO - 2024-03-06 15:52:26 --> Loader Class Initialized
INFO - 2024-03-06 15:52:26 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:26 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:26 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:26 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:26 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:26 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:52:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:26 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:26 --> Total execution time: 0.1371
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:48 --> URI Class Initialized
INFO - 2024-03-06 15:52:48 --> Router Class Initialized
INFO - 2024-03-06 15:52:48 --> Output Class Initialized
INFO - 2024-03-06 15:52:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:48 --> Input Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Loader Class Initialized
INFO - 2024-03-06 15:52:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:48 --> Controller Class Initialized
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:48 --> URI Class Initialized
INFO - 2024-03-06 15:52:48 --> Router Class Initialized
INFO - 2024-03-06 15:52:48 --> Output Class Initialized
INFO - 2024-03-06 15:52:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:48 --> Input Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Loader Class Initialized
INFO - 2024-03-06 15:52:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:48 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:52:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:48 --> Total execution time: 0.0351
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:48 --> URI Class Initialized
INFO - 2024-03-06 15:52:48 --> Router Class Initialized
INFO - 2024-03-06 15:52:48 --> Output Class Initialized
INFO - 2024-03-06 15:52:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:48 --> Input Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
ERROR - 2024-03-06 15:52:48 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:48 --> URI Class Initialized
INFO - 2024-03-06 15:52:48 --> Router Class Initialized
INFO - 2024-03-06 15:52:48 --> Output Class Initialized
INFO - 2024-03-06 15:52:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:48 --> Input Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Language Class Initialized
INFO - 2024-03-06 15:52:48 --> Config Class Initialized
INFO - 2024-03-06 15:52:48 --> Loader Class Initialized
INFO - 2024-03-06 15:52:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:48 --> Controller Class Initialized
INFO - 2024-03-06 15:52:50 --> Config Class Initialized
INFO - 2024-03-06 15:52:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:52:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:52:50 --> Utf8 Class Initialized
INFO - 2024-03-06 15:52:50 --> URI Class Initialized
INFO - 2024-03-06 15:52:50 --> Router Class Initialized
INFO - 2024-03-06 15:52:50 --> Output Class Initialized
INFO - 2024-03-06 15:52:50 --> Security Class Initialized
DEBUG - 2024-03-06 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:52:50 --> Input Class Initialized
INFO - 2024-03-06 15:52:50 --> Language Class Initialized
INFO - 2024-03-06 15:52:50 --> Language Class Initialized
INFO - 2024-03-06 15:52:50 --> Config Class Initialized
INFO - 2024-03-06 15:52:50 --> Loader Class Initialized
INFO - 2024-03-06 15:52:50 --> Helper loaded: url_helper
INFO - 2024-03-06 15:52:50 --> Helper loaded: file_helper
INFO - 2024-03-06 15:52:50 --> Helper loaded: form_helper
INFO - 2024-03-06 15:52:50 --> Helper loaded: my_helper
INFO - 2024-03-06 15:52:50 --> Database Driver Class Initialized
INFO - 2024-03-06 15:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:52:50 --> Controller Class Initialized
DEBUG - 2024-03-06 15:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:52:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:52:50 --> Final output sent to browser
DEBUG - 2024-03-06 15:52:50 --> Total execution time: 0.0676
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:10 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:10 --> URI Class Initialized
INFO - 2024-03-06 15:53:10 --> Router Class Initialized
INFO - 2024-03-06 15:53:10 --> Output Class Initialized
INFO - 2024-03-06 15:53:10 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:10 --> Input Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Loader Class Initialized
INFO - 2024-03-06 15:53:10 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:10 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:10 --> Controller Class Initialized
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:10 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:10 --> URI Class Initialized
INFO - 2024-03-06 15:53:10 --> Router Class Initialized
INFO - 2024-03-06 15:53:10 --> Output Class Initialized
INFO - 2024-03-06 15:53:10 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:10 --> Input Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Loader Class Initialized
INFO - 2024-03-06 15:53:10 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:10 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:10 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:10 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:10 --> Total execution time: 0.0323
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:10 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:10 --> URI Class Initialized
INFO - 2024-03-06 15:53:10 --> Router Class Initialized
INFO - 2024-03-06 15:53:10 --> Output Class Initialized
INFO - 2024-03-06 15:53:10 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:10 --> Input Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
ERROR - 2024-03-06 15:53:10 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:10 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:10 --> URI Class Initialized
INFO - 2024-03-06 15:53:10 --> Router Class Initialized
INFO - 2024-03-06 15:53:10 --> Output Class Initialized
INFO - 2024-03-06 15:53:10 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:10 --> Input Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Language Class Initialized
INFO - 2024-03-06 15:53:10 --> Config Class Initialized
INFO - 2024-03-06 15:53:10 --> Loader Class Initialized
INFO - 2024-03-06 15:53:10 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:10 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:10 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:10 --> Controller Class Initialized
INFO - 2024-03-06 15:53:11 --> Config Class Initialized
INFO - 2024-03-06 15:53:11 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:11 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:11 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:11 --> URI Class Initialized
INFO - 2024-03-06 15:53:11 --> Router Class Initialized
INFO - 2024-03-06 15:53:11 --> Output Class Initialized
INFO - 2024-03-06 15:53:11 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:11 --> Input Class Initialized
INFO - 2024-03-06 15:53:11 --> Language Class Initialized
INFO - 2024-03-06 15:53:11 --> Language Class Initialized
INFO - 2024-03-06 15:53:11 --> Config Class Initialized
INFO - 2024-03-06 15:53:11 --> Loader Class Initialized
INFO - 2024-03-06 15:53:11 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:11 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:11 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:11 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:11 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:11 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:53:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:11 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:11 --> Total execution time: 0.0320
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:31 --> URI Class Initialized
INFO - 2024-03-06 15:53:31 --> Router Class Initialized
INFO - 2024-03-06 15:53:31 --> Output Class Initialized
INFO - 2024-03-06 15:53:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:31 --> Input Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Loader Class Initialized
INFO - 2024-03-06 15:53:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:31 --> Controller Class Initialized
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:31 --> URI Class Initialized
INFO - 2024-03-06 15:53:31 --> Router Class Initialized
INFO - 2024-03-06 15:53:31 --> Output Class Initialized
INFO - 2024-03-06 15:53:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:31 --> Input Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Loader Class Initialized
INFO - 2024-03-06 15:53:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:31 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:53:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:31 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:31 --> Total execution time: 0.0390
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:31 --> URI Class Initialized
INFO - 2024-03-06 15:53:31 --> Router Class Initialized
INFO - 2024-03-06 15:53:31 --> Output Class Initialized
INFO - 2024-03-06 15:53:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:31 --> Input Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
ERROR - 2024-03-06 15:53:31 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:31 --> URI Class Initialized
INFO - 2024-03-06 15:53:31 --> Router Class Initialized
INFO - 2024-03-06 15:53:31 --> Output Class Initialized
INFO - 2024-03-06 15:53:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:31 --> Input Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Language Class Initialized
INFO - 2024-03-06 15:53:31 --> Config Class Initialized
INFO - 2024-03-06 15:53:31 --> Loader Class Initialized
INFO - 2024-03-06 15:53:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:31 --> Controller Class Initialized
INFO - 2024-03-06 15:53:33 --> Config Class Initialized
INFO - 2024-03-06 15:53:33 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:33 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:33 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:33 --> URI Class Initialized
INFO - 2024-03-06 15:53:33 --> Router Class Initialized
INFO - 2024-03-06 15:53:33 --> Output Class Initialized
INFO - 2024-03-06 15:53:33 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:33 --> Input Class Initialized
INFO - 2024-03-06 15:53:33 --> Language Class Initialized
INFO - 2024-03-06 15:53:33 --> Language Class Initialized
INFO - 2024-03-06 15:53:33 --> Config Class Initialized
INFO - 2024-03-06 15:53:33 --> Loader Class Initialized
INFO - 2024-03-06 15:53:33 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:33 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:33 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:33 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:33 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:33 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:53:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:33 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:33 --> Total execution time: 0.0294
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:44 --> URI Class Initialized
INFO - 2024-03-06 15:53:44 --> Router Class Initialized
INFO - 2024-03-06 15:53:44 --> Output Class Initialized
INFO - 2024-03-06 15:53:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:44 --> Input Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Loader Class Initialized
INFO - 2024-03-06 15:53:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:44 --> Controller Class Initialized
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:44 --> URI Class Initialized
INFO - 2024-03-06 15:53:44 --> Router Class Initialized
INFO - 2024-03-06 15:53:44 --> Output Class Initialized
INFO - 2024-03-06 15:53:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:44 --> Input Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Loader Class Initialized
INFO - 2024-03-06 15:53:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:44 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:44 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:44 --> Total execution time: 0.0320
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:44 --> URI Class Initialized
INFO - 2024-03-06 15:53:44 --> Router Class Initialized
INFO - 2024-03-06 15:53:44 --> Output Class Initialized
INFO - 2024-03-06 15:53:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:44 --> Input Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
ERROR - 2024-03-06 15:53:44 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:44 --> URI Class Initialized
INFO - 2024-03-06 15:53:44 --> Router Class Initialized
INFO - 2024-03-06 15:53:44 --> Output Class Initialized
INFO - 2024-03-06 15:53:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:44 --> Input Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Language Class Initialized
INFO - 2024-03-06 15:53:44 --> Config Class Initialized
INFO - 2024-03-06 15:53:44 --> Loader Class Initialized
INFO - 2024-03-06 15:53:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:44 --> Controller Class Initialized
INFO - 2024-03-06 15:53:54 --> Config Class Initialized
INFO - 2024-03-06 15:53:54 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:53:54 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:53:54 --> Utf8 Class Initialized
INFO - 2024-03-06 15:53:54 --> URI Class Initialized
INFO - 2024-03-06 15:53:54 --> Router Class Initialized
INFO - 2024-03-06 15:53:54 --> Output Class Initialized
INFO - 2024-03-06 15:53:54 --> Security Class Initialized
DEBUG - 2024-03-06 15:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:53:54 --> Input Class Initialized
INFO - 2024-03-06 15:53:54 --> Language Class Initialized
INFO - 2024-03-06 15:53:54 --> Language Class Initialized
INFO - 2024-03-06 15:53:54 --> Config Class Initialized
INFO - 2024-03-06 15:53:54 --> Loader Class Initialized
INFO - 2024-03-06 15:53:54 --> Helper loaded: url_helper
INFO - 2024-03-06 15:53:54 --> Helper loaded: file_helper
INFO - 2024-03-06 15:53:54 --> Helper loaded: form_helper
INFO - 2024-03-06 15:53:54 --> Helper loaded: my_helper
INFO - 2024-03-06 15:53:54 --> Database Driver Class Initialized
INFO - 2024-03-06 15:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:53:54 --> Controller Class Initialized
DEBUG - 2024-03-06 15:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:53:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:53:54 --> Final output sent to browser
DEBUG - 2024-03-06 15:53:54 --> Total execution time: 0.0380
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:05 --> URI Class Initialized
INFO - 2024-03-06 15:54:05 --> Router Class Initialized
INFO - 2024-03-06 15:54:05 --> Output Class Initialized
INFO - 2024-03-06 15:54:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:05 --> Input Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Loader Class Initialized
INFO - 2024-03-06 15:54:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:05 --> Controller Class Initialized
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:05 --> URI Class Initialized
INFO - 2024-03-06 15:54:05 --> Router Class Initialized
INFO - 2024-03-06 15:54:05 --> Output Class Initialized
INFO - 2024-03-06 15:54:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:05 --> Input Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Loader Class Initialized
INFO - 2024-03-06 15:54:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:05 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:54:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:05 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:05 --> Total execution time: 0.0536
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:05 --> URI Class Initialized
INFO - 2024-03-06 15:54:05 --> Router Class Initialized
INFO - 2024-03-06 15:54:05 --> Output Class Initialized
INFO - 2024-03-06 15:54:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:05 --> Input Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
ERROR - 2024-03-06 15:54:05 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:05 --> URI Class Initialized
INFO - 2024-03-06 15:54:05 --> Router Class Initialized
INFO - 2024-03-06 15:54:05 --> Output Class Initialized
INFO - 2024-03-06 15:54:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:05 --> Input Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Language Class Initialized
INFO - 2024-03-06 15:54:05 --> Config Class Initialized
INFO - 2024-03-06 15:54:05 --> Loader Class Initialized
INFO - 2024-03-06 15:54:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:05 --> Controller Class Initialized
INFO - 2024-03-06 15:54:07 --> Config Class Initialized
INFO - 2024-03-06 15:54:07 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:07 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:07 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:07 --> URI Class Initialized
INFO - 2024-03-06 15:54:07 --> Router Class Initialized
INFO - 2024-03-06 15:54:07 --> Output Class Initialized
INFO - 2024-03-06 15:54:07 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:07 --> Input Class Initialized
INFO - 2024-03-06 15:54:07 --> Language Class Initialized
INFO - 2024-03-06 15:54:07 --> Language Class Initialized
INFO - 2024-03-06 15:54:07 --> Config Class Initialized
INFO - 2024-03-06 15:54:07 --> Loader Class Initialized
INFO - 2024-03-06 15:54:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:07 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:54:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:07 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:07 --> Total execution time: 0.0584
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:25 --> URI Class Initialized
INFO - 2024-03-06 15:54:25 --> Router Class Initialized
INFO - 2024-03-06 15:54:25 --> Output Class Initialized
INFO - 2024-03-06 15:54:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:25 --> Input Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Loader Class Initialized
INFO - 2024-03-06 15:54:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:25 --> Controller Class Initialized
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:25 --> URI Class Initialized
INFO - 2024-03-06 15:54:25 --> Router Class Initialized
INFO - 2024-03-06 15:54:25 --> Output Class Initialized
INFO - 2024-03-06 15:54:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:25 --> Input Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Loader Class Initialized
INFO - 2024-03-06 15:54:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:25 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:54:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:25 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:25 --> Total execution time: 0.0288
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:25 --> URI Class Initialized
INFO - 2024-03-06 15:54:25 --> Router Class Initialized
INFO - 2024-03-06 15:54:25 --> Output Class Initialized
INFO - 2024-03-06 15:54:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:25 --> Input Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
ERROR - 2024-03-06 15:54:25 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:25 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:25 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:25 --> URI Class Initialized
INFO - 2024-03-06 15:54:25 --> Router Class Initialized
INFO - 2024-03-06 15:54:25 --> Output Class Initialized
INFO - 2024-03-06 15:54:25 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:25 --> Input Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Language Class Initialized
INFO - 2024-03-06 15:54:25 --> Config Class Initialized
INFO - 2024-03-06 15:54:25 --> Loader Class Initialized
INFO - 2024-03-06 15:54:25 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:25 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:25 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:25 --> Controller Class Initialized
INFO - 2024-03-06 15:54:26 --> Config Class Initialized
INFO - 2024-03-06 15:54:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:26 --> URI Class Initialized
INFO - 2024-03-06 15:54:26 --> Router Class Initialized
INFO - 2024-03-06 15:54:26 --> Output Class Initialized
INFO - 2024-03-06 15:54:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:26 --> Input Class Initialized
INFO - 2024-03-06 15:54:26 --> Language Class Initialized
INFO - 2024-03-06 15:54:26 --> Language Class Initialized
INFO - 2024-03-06 15:54:26 --> Config Class Initialized
INFO - 2024-03-06 15:54:26 --> Loader Class Initialized
INFO - 2024-03-06 15:54:26 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:26 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:26 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:26 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:26 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:27 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:54:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:27 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:27 --> Total execution time: 0.0758
INFO - 2024-03-06 15:54:44 --> Config Class Initialized
INFO - 2024-03-06 15:54:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:44 --> URI Class Initialized
INFO - 2024-03-06 15:54:44 --> Router Class Initialized
INFO - 2024-03-06 15:54:44 --> Output Class Initialized
INFO - 2024-03-06 15:54:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:44 --> Input Class Initialized
INFO - 2024-03-06 15:54:44 --> Language Class Initialized
INFO - 2024-03-06 15:54:44 --> Language Class Initialized
INFO - 2024-03-06 15:54:44 --> Config Class Initialized
INFO - 2024-03-06 15:54:44 --> Loader Class Initialized
INFO - 2024-03-06 15:54:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:44 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:54:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:44 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:44 --> Total execution time: 0.0285
INFO - 2024-03-06 15:54:44 --> Config Class Initialized
INFO - 2024-03-06 15:54:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:44 --> URI Class Initialized
INFO - 2024-03-06 15:54:44 --> Router Class Initialized
INFO - 2024-03-06 15:54:44 --> Output Class Initialized
INFO - 2024-03-06 15:54:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:44 --> Input Class Initialized
INFO - 2024-03-06 15:54:44 --> Language Class Initialized
ERROR - 2024-03-06 15:54:44 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:54:44 --> Config Class Initialized
INFO - 2024-03-06 15:54:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:44 --> URI Class Initialized
INFO - 2024-03-06 15:54:44 --> Router Class Initialized
INFO - 2024-03-06 15:54:44 --> Output Class Initialized
INFO - 2024-03-06 15:54:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:44 --> Input Class Initialized
INFO - 2024-03-06 15:54:44 --> Language Class Initialized
INFO - 2024-03-06 15:54:44 --> Language Class Initialized
INFO - 2024-03-06 15:54:44 --> Config Class Initialized
INFO - 2024-03-06 15:54:44 --> Loader Class Initialized
INFO - 2024-03-06 15:54:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:44 --> Controller Class Initialized
INFO - 2024-03-06 15:54:53 --> Config Class Initialized
INFO - 2024-03-06 15:54:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:54:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:54:53 --> Utf8 Class Initialized
INFO - 2024-03-06 15:54:53 --> URI Class Initialized
INFO - 2024-03-06 15:54:53 --> Router Class Initialized
INFO - 2024-03-06 15:54:53 --> Output Class Initialized
INFO - 2024-03-06 15:54:53 --> Security Class Initialized
DEBUG - 2024-03-06 15:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:54:53 --> Input Class Initialized
INFO - 2024-03-06 15:54:53 --> Language Class Initialized
INFO - 2024-03-06 15:54:53 --> Language Class Initialized
INFO - 2024-03-06 15:54:53 --> Config Class Initialized
INFO - 2024-03-06 15:54:53 --> Loader Class Initialized
INFO - 2024-03-06 15:54:53 --> Helper loaded: url_helper
INFO - 2024-03-06 15:54:53 --> Helper loaded: file_helper
INFO - 2024-03-06 15:54:53 --> Helper loaded: form_helper
INFO - 2024-03-06 15:54:53 --> Helper loaded: my_helper
INFO - 2024-03-06 15:54:53 --> Database Driver Class Initialized
INFO - 2024-03-06 15:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:54:53 --> Controller Class Initialized
DEBUG - 2024-03-06 15:54:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:54:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:54:53 --> Final output sent to browser
DEBUG - 2024-03-06 15:54:53 --> Total execution time: 0.0330
INFO - 2024-03-06 15:55:03 --> Config Class Initialized
INFO - 2024-03-06 15:55:03 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:03 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:03 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:03 --> URI Class Initialized
INFO - 2024-03-06 15:55:03 --> Router Class Initialized
INFO - 2024-03-06 15:55:03 --> Output Class Initialized
INFO - 2024-03-06 15:55:03 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:03 --> Input Class Initialized
INFO - 2024-03-06 15:55:03 --> Language Class Initialized
INFO - 2024-03-06 15:55:03 --> Language Class Initialized
INFO - 2024-03-06 15:55:03 --> Config Class Initialized
INFO - 2024-03-06 15:55:03 --> Loader Class Initialized
INFO - 2024-03-06 15:55:03 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:03 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:03 --> Controller Class Initialized
INFO - 2024-03-06 15:55:03 --> Config Class Initialized
INFO - 2024-03-06 15:55:03 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:03 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:03 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:03 --> URI Class Initialized
INFO - 2024-03-06 15:55:03 --> Router Class Initialized
INFO - 2024-03-06 15:55:03 --> Output Class Initialized
INFO - 2024-03-06 15:55:03 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:03 --> Input Class Initialized
INFO - 2024-03-06 15:55:03 --> Language Class Initialized
INFO - 2024-03-06 15:55:03 --> Language Class Initialized
INFO - 2024-03-06 15:55:03 --> Config Class Initialized
INFO - 2024-03-06 15:55:03 --> Loader Class Initialized
INFO - 2024-03-06 15:55:03 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:03 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:03 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:03 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:55:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:03 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:03 --> Total execution time: 0.0531
INFO - 2024-03-06 15:55:04 --> Config Class Initialized
INFO - 2024-03-06 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:04 --> URI Class Initialized
INFO - 2024-03-06 15:55:04 --> Router Class Initialized
INFO - 2024-03-06 15:55:04 --> Output Class Initialized
INFO - 2024-03-06 15:55:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:04 --> Input Class Initialized
INFO - 2024-03-06 15:55:04 --> Language Class Initialized
ERROR - 2024-03-06 15:55:04 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:55:04 --> Config Class Initialized
INFO - 2024-03-06 15:55:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:04 --> URI Class Initialized
INFO - 2024-03-06 15:55:04 --> Router Class Initialized
INFO - 2024-03-06 15:55:04 --> Output Class Initialized
INFO - 2024-03-06 15:55:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:04 --> Input Class Initialized
INFO - 2024-03-06 15:55:04 --> Language Class Initialized
INFO - 2024-03-06 15:55:04 --> Language Class Initialized
INFO - 2024-03-06 15:55:04 --> Config Class Initialized
INFO - 2024-03-06 15:55:04 --> Loader Class Initialized
INFO - 2024-03-06 15:55:04 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:04 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:04 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:04 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:04 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:04 --> Controller Class Initialized
INFO - 2024-03-06 15:55:05 --> Config Class Initialized
INFO - 2024-03-06 15:55:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:05 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:05 --> URI Class Initialized
INFO - 2024-03-06 15:55:05 --> Router Class Initialized
INFO - 2024-03-06 15:55:05 --> Output Class Initialized
INFO - 2024-03-06 15:55:05 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:05 --> Input Class Initialized
INFO - 2024-03-06 15:55:05 --> Language Class Initialized
INFO - 2024-03-06 15:55:05 --> Language Class Initialized
INFO - 2024-03-06 15:55:05 --> Config Class Initialized
INFO - 2024-03-06 15:55:05 --> Loader Class Initialized
INFO - 2024-03-06 15:55:05 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:05 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:05 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:05 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:05 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:05 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:55:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:05 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:05 --> Total execution time: 0.0475
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:31 --> URI Class Initialized
INFO - 2024-03-06 15:55:31 --> Router Class Initialized
INFO - 2024-03-06 15:55:31 --> Output Class Initialized
INFO - 2024-03-06 15:55:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:31 --> Input Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Loader Class Initialized
INFO - 2024-03-06 15:55:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:31 --> Controller Class Initialized
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:31 --> URI Class Initialized
INFO - 2024-03-06 15:55:31 --> Router Class Initialized
INFO - 2024-03-06 15:55:31 --> Output Class Initialized
INFO - 2024-03-06 15:55:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:31 --> Input Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Loader Class Initialized
INFO - 2024-03-06 15:55:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:31 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:55:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:31 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:31 --> Total execution time: 0.1196
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:31 --> URI Class Initialized
INFO - 2024-03-06 15:55:31 --> Router Class Initialized
INFO - 2024-03-06 15:55:31 --> Output Class Initialized
INFO - 2024-03-06 15:55:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:31 --> Input Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
ERROR - 2024-03-06 15:55:31 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:31 --> URI Class Initialized
INFO - 2024-03-06 15:55:31 --> Router Class Initialized
INFO - 2024-03-06 15:55:31 --> Output Class Initialized
INFO - 2024-03-06 15:55:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:31 --> Input Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Language Class Initialized
INFO - 2024-03-06 15:55:31 --> Config Class Initialized
INFO - 2024-03-06 15:55:31 --> Loader Class Initialized
INFO - 2024-03-06 15:55:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:32 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:32 --> Controller Class Initialized
INFO - 2024-03-06 15:55:33 --> Config Class Initialized
INFO - 2024-03-06 15:55:33 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:33 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:33 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:33 --> URI Class Initialized
INFO - 2024-03-06 15:55:33 --> Router Class Initialized
INFO - 2024-03-06 15:55:33 --> Output Class Initialized
INFO - 2024-03-06 15:55:33 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:33 --> Input Class Initialized
INFO - 2024-03-06 15:55:33 --> Language Class Initialized
INFO - 2024-03-06 15:55:33 --> Language Class Initialized
INFO - 2024-03-06 15:55:33 --> Config Class Initialized
INFO - 2024-03-06 15:55:33 --> Loader Class Initialized
INFO - 2024-03-06 15:55:33 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:33 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:33 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:33 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:33 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:33 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:33 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:33 --> Total execution time: 0.0302
INFO - 2024-03-06 15:55:43 --> Config Class Initialized
INFO - 2024-03-06 15:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:43 --> URI Class Initialized
INFO - 2024-03-06 15:55:43 --> Router Class Initialized
INFO - 2024-03-06 15:55:43 --> Output Class Initialized
INFO - 2024-03-06 15:55:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:43 --> Input Class Initialized
INFO - 2024-03-06 15:55:43 --> Language Class Initialized
INFO - 2024-03-06 15:55:43 --> Language Class Initialized
INFO - 2024-03-06 15:55:43 --> Config Class Initialized
INFO - 2024-03-06 15:55:43 --> Loader Class Initialized
INFO - 2024-03-06 15:55:43 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:43 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:43 --> Controller Class Initialized
INFO - 2024-03-06 15:55:43 --> Config Class Initialized
INFO - 2024-03-06 15:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:43 --> URI Class Initialized
INFO - 2024-03-06 15:55:43 --> Router Class Initialized
INFO - 2024-03-06 15:55:43 --> Output Class Initialized
INFO - 2024-03-06 15:55:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:43 --> Input Class Initialized
INFO - 2024-03-06 15:55:43 --> Language Class Initialized
INFO - 2024-03-06 15:55:43 --> Language Class Initialized
INFO - 2024-03-06 15:55:43 --> Config Class Initialized
INFO - 2024-03-06 15:55:43 --> Loader Class Initialized
INFO - 2024-03-06 15:55:43 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:43 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:43 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:43 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:55:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:43 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:43 --> Total execution time: 0.0751
INFO - 2024-03-06 15:55:43 --> Config Class Initialized
INFO - 2024-03-06 15:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:43 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:43 --> URI Class Initialized
INFO - 2024-03-06 15:55:43 --> Router Class Initialized
INFO - 2024-03-06 15:55:43 --> Output Class Initialized
INFO - 2024-03-06 15:55:43 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:43 --> Input Class Initialized
INFO - 2024-03-06 15:55:43 --> Language Class Initialized
ERROR - 2024-03-06 15:55:43 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:55:44 --> Config Class Initialized
INFO - 2024-03-06 15:55:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:44 --> URI Class Initialized
INFO - 2024-03-06 15:55:44 --> Router Class Initialized
INFO - 2024-03-06 15:55:44 --> Output Class Initialized
INFO - 2024-03-06 15:55:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:44 --> Input Class Initialized
INFO - 2024-03-06 15:55:44 --> Language Class Initialized
INFO - 2024-03-06 15:55:44 --> Language Class Initialized
INFO - 2024-03-06 15:55:44 --> Config Class Initialized
INFO - 2024-03-06 15:55:44 --> Loader Class Initialized
INFO - 2024-03-06 15:55:44 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:44 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:44 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:44 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:44 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:44 --> Controller Class Initialized
INFO - 2024-03-06 15:55:47 --> Config Class Initialized
INFO - 2024-03-06 15:55:47 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:55:47 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:55:47 --> Utf8 Class Initialized
INFO - 2024-03-06 15:55:47 --> URI Class Initialized
INFO - 2024-03-06 15:55:47 --> Router Class Initialized
INFO - 2024-03-06 15:55:47 --> Output Class Initialized
INFO - 2024-03-06 15:55:47 --> Security Class Initialized
DEBUG - 2024-03-06 15:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:55:47 --> Input Class Initialized
INFO - 2024-03-06 15:55:47 --> Language Class Initialized
INFO - 2024-03-06 15:55:47 --> Language Class Initialized
INFO - 2024-03-06 15:55:47 --> Config Class Initialized
INFO - 2024-03-06 15:55:47 --> Loader Class Initialized
INFO - 2024-03-06 15:55:47 --> Helper loaded: url_helper
INFO - 2024-03-06 15:55:47 --> Helper loaded: file_helper
INFO - 2024-03-06 15:55:47 --> Helper loaded: form_helper
INFO - 2024-03-06 15:55:47 --> Helper loaded: my_helper
INFO - 2024-03-06 15:55:47 --> Database Driver Class Initialized
INFO - 2024-03-06 15:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:55:47 --> Controller Class Initialized
DEBUG - 2024-03-06 15:55:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:55:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:55:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:55:48 --> Total execution time: 0.0622
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:02 --> URI Class Initialized
INFO - 2024-03-06 15:56:02 --> Router Class Initialized
INFO - 2024-03-06 15:56:02 --> Output Class Initialized
INFO - 2024-03-06 15:56:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:02 --> Input Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Loader Class Initialized
INFO - 2024-03-06 15:56:02 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:02 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:02 --> Controller Class Initialized
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:02 --> URI Class Initialized
INFO - 2024-03-06 15:56:02 --> Router Class Initialized
INFO - 2024-03-06 15:56:02 --> Output Class Initialized
INFO - 2024-03-06 15:56:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:02 --> Input Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Loader Class Initialized
INFO - 2024-03-06 15:56:02 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:02 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:02 --> Controller Class Initialized
DEBUG - 2024-03-06 15:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-03-06 15:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:56:02 --> Final output sent to browser
DEBUG - 2024-03-06 15:56:02 --> Total execution time: 0.0567
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:02 --> URI Class Initialized
INFO - 2024-03-06 15:56:02 --> Router Class Initialized
INFO - 2024-03-06 15:56:02 --> Output Class Initialized
INFO - 2024-03-06 15:56:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:02 --> Input Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
ERROR - 2024-03-06 15:56:02 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:02 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:02 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:02 --> URI Class Initialized
INFO - 2024-03-06 15:56:02 --> Router Class Initialized
INFO - 2024-03-06 15:56:02 --> Output Class Initialized
INFO - 2024-03-06 15:56:02 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:02 --> Input Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Language Class Initialized
INFO - 2024-03-06 15:56:02 --> Config Class Initialized
INFO - 2024-03-06 15:56:02 --> Loader Class Initialized
INFO - 2024-03-06 15:56:02 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:02 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:02 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:02 --> Controller Class Initialized
INFO - 2024-03-06 15:56:04 --> Config Class Initialized
INFO - 2024-03-06 15:56:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:04 --> URI Class Initialized
INFO - 2024-03-06 15:56:04 --> Router Class Initialized
INFO - 2024-03-06 15:56:04 --> Output Class Initialized
INFO - 2024-03-06 15:56:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:04 --> Input Class Initialized
INFO - 2024-03-06 15:56:04 --> Language Class Initialized
INFO - 2024-03-06 15:56:04 --> Language Class Initialized
INFO - 2024-03-06 15:56:04 --> Config Class Initialized
INFO - 2024-03-06 15:56:04 --> Loader Class Initialized
INFO - 2024-03-06 15:56:04 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:04 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:04 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:04 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:04 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:04 --> Controller Class Initialized
DEBUG - 2024-03-06 15:56:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-03-06 15:56:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:56:04 --> Final output sent to browser
DEBUG - 2024-03-06 15:56:04 --> Total execution time: 0.0553
INFO - 2024-03-06 15:56:23 --> Config Class Initialized
INFO - 2024-03-06 15:56:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:23 --> URI Class Initialized
INFO - 2024-03-06 15:56:23 --> Router Class Initialized
INFO - 2024-03-06 15:56:23 --> Output Class Initialized
INFO - 2024-03-06 15:56:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:23 --> Input Class Initialized
INFO - 2024-03-06 15:56:23 --> Language Class Initialized
INFO - 2024-03-06 15:56:23 --> Language Class Initialized
INFO - 2024-03-06 15:56:23 --> Config Class Initialized
INFO - 2024-03-06 15:56:23 --> Loader Class Initialized
INFO - 2024-03-06 15:56:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:23 --> Controller Class Initialized
DEBUG - 2024-03-06 15:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-03-06 15:56:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:56:23 --> Final output sent to browser
DEBUG - 2024-03-06 15:56:23 --> Total execution time: 0.0445
INFO - 2024-03-06 15:56:23 --> Config Class Initialized
INFO - 2024-03-06 15:56:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:23 --> URI Class Initialized
INFO - 2024-03-06 15:56:23 --> Router Class Initialized
INFO - 2024-03-06 15:56:23 --> Output Class Initialized
INFO - 2024-03-06 15:56:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:23 --> Input Class Initialized
INFO - 2024-03-06 15:56:23 --> Language Class Initialized
ERROR - 2024-03-06 15:56:23 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:56:23 --> Config Class Initialized
INFO - 2024-03-06 15:56:23 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:23 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:23 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:23 --> URI Class Initialized
INFO - 2024-03-06 15:56:23 --> Router Class Initialized
INFO - 2024-03-06 15:56:23 --> Output Class Initialized
INFO - 2024-03-06 15:56:23 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:23 --> Input Class Initialized
INFO - 2024-03-06 15:56:23 --> Language Class Initialized
INFO - 2024-03-06 15:56:23 --> Language Class Initialized
INFO - 2024-03-06 15:56:23 --> Config Class Initialized
INFO - 2024-03-06 15:56:23 --> Loader Class Initialized
INFO - 2024-03-06 15:56:23 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:23 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:23 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:23 --> Controller Class Initialized
INFO - 2024-03-06 15:56:35 --> Config Class Initialized
INFO - 2024-03-06 15:56:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:35 --> URI Class Initialized
INFO - 2024-03-06 15:56:35 --> Router Class Initialized
INFO - 2024-03-06 15:56:35 --> Output Class Initialized
INFO - 2024-03-06 15:56:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:35 --> Input Class Initialized
INFO - 2024-03-06 15:56:35 --> Language Class Initialized
INFO - 2024-03-06 15:56:35 --> Language Class Initialized
INFO - 2024-03-06 15:56:35 --> Config Class Initialized
INFO - 2024-03-06 15:56:35 --> Loader Class Initialized
INFO - 2024-03-06 15:56:35 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:35 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:35 --> Controller Class Initialized
DEBUG - 2024-03-06 15:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:56:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:56:35 --> Final output sent to browser
DEBUG - 2024-03-06 15:56:35 --> Total execution time: 0.2306
INFO - 2024-03-06 15:56:35 --> Config Class Initialized
INFO - 2024-03-06 15:56:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:35 --> URI Class Initialized
INFO - 2024-03-06 15:56:35 --> Router Class Initialized
INFO - 2024-03-06 15:56:35 --> Output Class Initialized
INFO - 2024-03-06 15:56:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:35 --> Input Class Initialized
INFO - 2024-03-06 15:56:35 --> Language Class Initialized
ERROR - 2024-03-06 15:56:35 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:56:35 --> Config Class Initialized
INFO - 2024-03-06 15:56:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:35 --> URI Class Initialized
INFO - 2024-03-06 15:56:35 --> Router Class Initialized
INFO - 2024-03-06 15:56:35 --> Output Class Initialized
INFO - 2024-03-06 15:56:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:35 --> Input Class Initialized
INFO - 2024-03-06 15:56:35 --> Language Class Initialized
INFO - 2024-03-06 15:56:35 --> Language Class Initialized
INFO - 2024-03-06 15:56:35 --> Config Class Initialized
INFO - 2024-03-06 15:56:35 --> Loader Class Initialized
INFO - 2024-03-06 15:56:35 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:35 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:35 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:35 --> Controller Class Initialized
INFO - 2024-03-06 15:56:38 --> Config Class Initialized
INFO - 2024-03-06 15:56:38 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:56:38 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:56:38 --> Utf8 Class Initialized
INFO - 2024-03-06 15:56:38 --> URI Class Initialized
INFO - 2024-03-06 15:56:38 --> Router Class Initialized
INFO - 2024-03-06 15:56:38 --> Output Class Initialized
INFO - 2024-03-06 15:56:38 --> Security Class Initialized
DEBUG - 2024-03-06 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:56:38 --> Input Class Initialized
INFO - 2024-03-06 15:56:38 --> Language Class Initialized
INFO - 2024-03-06 15:56:38 --> Language Class Initialized
INFO - 2024-03-06 15:56:38 --> Config Class Initialized
INFO - 2024-03-06 15:56:38 --> Loader Class Initialized
INFO - 2024-03-06 15:56:38 --> Helper loaded: url_helper
INFO - 2024-03-06 15:56:38 --> Helper loaded: file_helper
INFO - 2024-03-06 15:56:38 --> Helper loaded: form_helper
INFO - 2024-03-06 15:56:38 --> Helper loaded: my_helper
INFO - 2024-03-06 15:56:38 --> Database Driver Class Initialized
INFO - 2024-03-06 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:56:38 --> Controller Class Initialized
DEBUG - 2024-03-06 15:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:56:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:56:38 --> Final output sent to browser
DEBUG - 2024-03-06 15:56:38 --> Total execution time: 0.1594
INFO - 2024-03-06 15:57:26 --> Config Class Initialized
INFO - 2024-03-06 15:57:26 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:26 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:26 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:26 --> URI Class Initialized
INFO - 2024-03-06 15:57:26 --> Router Class Initialized
INFO - 2024-03-06 15:57:26 --> Output Class Initialized
INFO - 2024-03-06 15:57:26 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:26 --> Input Class Initialized
INFO - 2024-03-06 15:57:26 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Loader Class Initialized
INFO - 2024-03-06 15:57:27 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:27 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:27 --> Controller Class Initialized
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:27 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:27 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:27 --> URI Class Initialized
INFO - 2024-03-06 15:57:27 --> Router Class Initialized
INFO - 2024-03-06 15:57:27 --> Output Class Initialized
INFO - 2024-03-06 15:57:27 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:27 --> Input Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Loader Class Initialized
INFO - 2024-03-06 15:57:27 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:27 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:27 --> Controller Class Initialized
DEBUG - 2024-03-06 15:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:57:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:57:27 --> Final output sent to browser
DEBUG - 2024-03-06 15:57:27 --> Total execution time: 0.0424
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:27 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:27 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:27 --> URI Class Initialized
INFO - 2024-03-06 15:57:27 --> Router Class Initialized
INFO - 2024-03-06 15:57:27 --> Output Class Initialized
INFO - 2024-03-06 15:57:27 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:27 --> Input Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
ERROR - 2024-03-06 15:57:27 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:27 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:27 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:27 --> URI Class Initialized
INFO - 2024-03-06 15:57:27 --> Router Class Initialized
INFO - 2024-03-06 15:57:27 --> Output Class Initialized
INFO - 2024-03-06 15:57:27 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:27 --> Input Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Language Class Initialized
INFO - 2024-03-06 15:57:27 --> Config Class Initialized
INFO - 2024-03-06 15:57:27 --> Loader Class Initialized
INFO - 2024-03-06 15:57:27 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:27 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:27 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:27 --> Controller Class Initialized
INFO - 2024-03-06 15:57:28 --> Config Class Initialized
INFO - 2024-03-06 15:57:28 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:28 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:28 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:28 --> URI Class Initialized
INFO - 2024-03-06 15:57:28 --> Router Class Initialized
INFO - 2024-03-06 15:57:28 --> Output Class Initialized
INFO - 2024-03-06 15:57:28 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:28 --> Input Class Initialized
INFO - 2024-03-06 15:57:28 --> Language Class Initialized
INFO - 2024-03-06 15:57:28 --> Language Class Initialized
INFO - 2024-03-06 15:57:28 --> Config Class Initialized
INFO - 2024-03-06 15:57:28 --> Loader Class Initialized
INFO - 2024-03-06 15:57:28 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:28 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:28 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:28 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:28 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:28 --> Controller Class Initialized
DEBUG - 2024-03-06 15:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:57:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:57:28 --> Final output sent to browser
DEBUG - 2024-03-06 15:57:28 --> Total execution time: 0.0944
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:35 --> URI Class Initialized
INFO - 2024-03-06 15:57:35 --> Router Class Initialized
INFO - 2024-03-06 15:57:35 --> Output Class Initialized
INFO - 2024-03-06 15:57:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:35 --> Input Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Loader Class Initialized
INFO - 2024-03-06 15:57:35 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:35 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:35 --> Controller Class Initialized
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:35 --> URI Class Initialized
INFO - 2024-03-06 15:57:35 --> Router Class Initialized
INFO - 2024-03-06 15:57:35 --> Output Class Initialized
INFO - 2024-03-06 15:57:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:35 --> Input Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Loader Class Initialized
INFO - 2024-03-06 15:57:35 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:35 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:35 --> Controller Class Initialized
DEBUG - 2024-03-06 15:57:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:57:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:57:35 --> Final output sent to browser
DEBUG - 2024-03-06 15:57:35 --> Total execution time: 0.0316
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:35 --> URI Class Initialized
INFO - 2024-03-06 15:57:35 --> Router Class Initialized
INFO - 2024-03-06 15:57:35 --> Output Class Initialized
INFO - 2024-03-06 15:57:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:35 --> Input Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
ERROR - 2024-03-06 15:57:35 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:57:35 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:57:35 --> Utf8 Class Initialized
INFO - 2024-03-06 15:57:35 --> URI Class Initialized
INFO - 2024-03-06 15:57:35 --> Router Class Initialized
INFO - 2024-03-06 15:57:35 --> Output Class Initialized
INFO - 2024-03-06 15:57:35 --> Security Class Initialized
DEBUG - 2024-03-06 15:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:57:35 --> Input Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Language Class Initialized
INFO - 2024-03-06 15:57:35 --> Config Class Initialized
INFO - 2024-03-06 15:57:35 --> Loader Class Initialized
INFO - 2024-03-06 15:57:35 --> Helper loaded: url_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: file_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: form_helper
INFO - 2024-03-06 15:57:35 --> Helper loaded: my_helper
INFO - 2024-03-06 15:57:35 --> Database Driver Class Initialized
INFO - 2024-03-06 15:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:57:35 --> Controller Class Initialized
INFO - 2024-03-06 15:58:06 --> Config Class Initialized
INFO - 2024-03-06 15:58:06 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:06 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:06 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:06 --> URI Class Initialized
INFO - 2024-03-06 15:58:06 --> Router Class Initialized
INFO - 2024-03-06 15:58:06 --> Output Class Initialized
INFO - 2024-03-06 15:58:06 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:06 --> Input Class Initialized
INFO - 2024-03-06 15:58:06 --> Language Class Initialized
INFO - 2024-03-06 15:58:07 --> Language Class Initialized
INFO - 2024-03-06 15:58:07 --> Config Class Initialized
INFO - 2024-03-06 15:58:07 --> Loader Class Initialized
INFO - 2024-03-06 15:58:07 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:07 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:07 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:07 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:07 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:07 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:58:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:07 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:07 --> Total execution time: 0.3773
INFO - 2024-03-06 15:58:15 --> Config Class Initialized
INFO - 2024-03-06 15:58:15 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:15 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:15 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:15 --> URI Class Initialized
INFO - 2024-03-06 15:58:16 --> Router Class Initialized
INFO - 2024-03-06 15:58:16 --> Output Class Initialized
INFO - 2024-03-06 15:58:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:16 --> Input Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Loader Class Initialized
INFO - 2024-03-06 15:58:16 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:16 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:16 --> Controller Class Initialized
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:16 --> URI Class Initialized
INFO - 2024-03-06 15:58:16 --> Router Class Initialized
INFO - 2024-03-06 15:58:16 --> Output Class Initialized
INFO - 2024-03-06 15:58:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:16 --> Input Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Loader Class Initialized
INFO - 2024-03-06 15:58:16 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:16 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:16 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:16 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:16 --> Total execution time: 0.0630
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:16 --> URI Class Initialized
INFO - 2024-03-06 15:58:16 --> Router Class Initialized
INFO - 2024-03-06 15:58:16 --> Output Class Initialized
INFO - 2024-03-06 15:58:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:16 --> Input Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
ERROR - 2024-03-06 15:58:16 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:16 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:16 --> URI Class Initialized
INFO - 2024-03-06 15:58:16 --> Router Class Initialized
INFO - 2024-03-06 15:58:16 --> Output Class Initialized
INFO - 2024-03-06 15:58:16 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:16 --> Input Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Language Class Initialized
INFO - 2024-03-06 15:58:16 --> Config Class Initialized
INFO - 2024-03-06 15:58:16 --> Loader Class Initialized
INFO - 2024-03-06 15:58:16 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:16 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:16 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:16 --> Controller Class Initialized
INFO - 2024-03-06 15:58:18 --> Config Class Initialized
INFO - 2024-03-06 15:58:18 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:18 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:18 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:18 --> URI Class Initialized
INFO - 2024-03-06 15:58:18 --> Router Class Initialized
INFO - 2024-03-06 15:58:18 --> Output Class Initialized
INFO - 2024-03-06 15:58:18 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:18 --> Input Class Initialized
INFO - 2024-03-06 15:58:18 --> Language Class Initialized
INFO - 2024-03-06 15:58:18 --> Language Class Initialized
INFO - 2024-03-06 15:58:18 --> Config Class Initialized
INFO - 2024-03-06 15:58:18 --> Loader Class Initialized
INFO - 2024-03-06 15:58:18 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:18 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:18 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:18 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:18 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:18 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:58:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:18 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:18 --> Total execution time: 0.0788
INFO - 2024-03-06 15:58:28 --> Config Class Initialized
INFO - 2024-03-06 15:58:28 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:28 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:28 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:28 --> URI Class Initialized
INFO - 2024-03-06 15:58:28 --> Router Class Initialized
INFO - 2024-03-06 15:58:28 --> Output Class Initialized
INFO - 2024-03-06 15:58:28 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:28 --> Input Class Initialized
INFO - 2024-03-06 15:58:28 --> Language Class Initialized
INFO - 2024-03-06 15:58:28 --> Language Class Initialized
INFO - 2024-03-06 15:58:28 --> Config Class Initialized
INFO - 2024-03-06 15:58:28 --> Loader Class Initialized
INFO - 2024-03-06 15:58:28 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:28 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:28 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:28 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:28 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:28 --> Controller Class Initialized
INFO - 2024-03-06 15:58:29 --> Config Class Initialized
INFO - 2024-03-06 15:58:29 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:29 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:29 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:29 --> URI Class Initialized
INFO - 2024-03-06 15:58:29 --> Router Class Initialized
INFO - 2024-03-06 15:58:29 --> Output Class Initialized
INFO - 2024-03-06 15:58:29 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:29 --> Input Class Initialized
INFO - 2024-03-06 15:58:29 --> Language Class Initialized
INFO - 2024-03-06 15:58:29 --> Language Class Initialized
INFO - 2024-03-06 15:58:29 --> Config Class Initialized
INFO - 2024-03-06 15:58:29 --> Loader Class Initialized
INFO - 2024-03-06 15:58:29 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:29 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:29 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:58:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:29 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:29 --> Total execution time: 0.2333
INFO - 2024-03-06 15:58:29 --> Config Class Initialized
INFO - 2024-03-06 15:58:29 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:29 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:29 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:29 --> URI Class Initialized
INFO - 2024-03-06 15:58:29 --> Router Class Initialized
INFO - 2024-03-06 15:58:29 --> Output Class Initialized
INFO - 2024-03-06 15:58:29 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:29 --> Input Class Initialized
INFO - 2024-03-06 15:58:29 --> Language Class Initialized
ERROR - 2024-03-06 15:58:29 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:58:29 --> Config Class Initialized
INFO - 2024-03-06 15:58:29 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:29 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:29 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:29 --> URI Class Initialized
INFO - 2024-03-06 15:58:29 --> Router Class Initialized
INFO - 2024-03-06 15:58:29 --> Output Class Initialized
INFO - 2024-03-06 15:58:29 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:29 --> Input Class Initialized
INFO - 2024-03-06 15:58:29 --> Language Class Initialized
INFO - 2024-03-06 15:58:29 --> Language Class Initialized
INFO - 2024-03-06 15:58:29 --> Config Class Initialized
INFO - 2024-03-06 15:58:29 --> Loader Class Initialized
INFO - 2024-03-06 15:58:29 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:29 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:29 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:29 --> Controller Class Initialized
INFO - 2024-03-06 15:58:31 --> Config Class Initialized
INFO - 2024-03-06 15:58:31 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:31 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:31 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:31 --> URI Class Initialized
INFO - 2024-03-06 15:58:31 --> Router Class Initialized
INFO - 2024-03-06 15:58:31 --> Output Class Initialized
INFO - 2024-03-06 15:58:31 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:31 --> Input Class Initialized
INFO - 2024-03-06 15:58:31 --> Language Class Initialized
INFO - 2024-03-06 15:58:31 --> Language Class Initialized
INFO - 2024-03-06 15:58:31 --> Config Class Initialized
INFO - 2024-03-06 15:58:31 --> Loader Class Initialized
INFO - 2024-03-06 15:58:31 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:31 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:31 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:31 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:31 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:31 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:58:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:31 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:31 --> Total execution time: 0.0360
INFO - 2024-03-06 15:58:44 --> Config Class Initialized
INFO - 2024-03-06 15:58:44 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:44 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:44 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:44 --> URI Class Initialized
INFO - 2024-03-06 15:58:44 --> Router Class Initialized
INFO - 2024-03-06 15:58:44 --> Output Class Initialized
INFO - 2024-03-06 15:58:44 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:44 --> Input Class Initialized
INFO - 2024-03-06 15:58:44 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Loader Class Initialized
INFO - 2024-03-06 15:58:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:45 --> Controller Class Initialized
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:45 --> URI Class Initialized
INFO - 2024-03-06 15:58:45 --> Router Class Initialized
INFO - 2024-03-06 15:58:45 --> Output Class Initialized
INFO - 2024-03-06 15:58:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:45 --> Input Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Loader Class Initialized
INFO - 2024-03-06 15:58:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:45 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:58:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:45 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:45 --> Total execution time: 0.0637
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:45 --> URI Class Initialized
INFO - 2024-03-06 15:58:45 --> Router Class Initialized
INFO - 2024-03-06 15:58:45 --> Output Class Initialized
INFO - 2024-03-06 15:58:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:45 --> Input Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
ERROR - 2024-03-06 15:58:45 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:45 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:45 --> URI Class Initialized
INFO - 2024-03-06 15:58:45 --> Router Class Initialized
INFO - 2024-03-06 15:58:45 --> Output Class Initialized
INFO - 2024-03-06 15:58:45 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:45 --> Input Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Language Class Initialized
INFO - 2024-03-06 15:58:45 --> Config Class Initialized
INFO - 2024-03-06 15:58:45 --> Loader Class Initialized
INFO - 2024-03-06 15:58:45 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:45 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:45 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:45 --> Controller Class Initialized
INFO - 2024-03-06 15:58:48 --> Config Class Initialized
INFO - 2024-03-06 15:58:48 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:48 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:48 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:48 --> URI Class Initialized
INFO - 2024-03-06 15:58:48 --> Router Class Initialized
INFO - 2024-03-06 15:58:48 --> Output Class Initialized
INFO - 2024-03-06 15:58:48 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:48 --> Input Class Initialized
INFO - 2024-03-06 15:58:48 --> Language Class Initialized
INFO - 2024-03-06 15:58:48 --> Language Class Initialized
INFO - 2024-03-06 15:58:48 --> Config Class Initialized
INFO - 2024-03-06 15:58:48 --> Loader Class Initialized
INFO - 2024-03-06 15:58:48 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:48 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:48 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:48 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:48 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:48 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:58:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:48 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:48 --> Total execution time: 0.0586
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:58 --> URI Class Initialized
INFO - 2024-03-06 15:58:58 --> Router Class Initialized
INFO - 2024-03-06 15:58:58 --> Output Class Initialized
INFO - 2024-03-06 15:58:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:58 --> Input Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Loader Class Initialized
INFO - 2024-03-06 15:58:58 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:58 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:58 --> Controller Class Initialized
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:58 --> URI Class Initialized
INFO - 2024-03-06 15:58:58 --> Router Class Initialized
INFO - 2024-03-06 15:58:58 --> Output Class Initialized
INFO - 2024-03-06 15:58:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:58 --> Input Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Loader Class Initialized
INFO - 2024-03-06 15:58:58 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:58 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:58 --> Controller Class Initialized
DEBUG - 2024-03-06 15:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:58:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:58:58 --> Final output sent to browser
DEBUG - 2024-03-06 15:58:58 --> Total execution time: 0.0498
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:58 --> URI Class Initialized
INFO - 2024-03-06 15:58:58 --> Router Class Initialized
INFO - 2024-03-06 15:58:58 --> Output Class Initialized
INFO - 2024-03-06 15:58:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:58 --> Input Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
ERROR - 2024-03-06 15:58:58 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:58:58 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:58:58 --> Utf8 Class Initialized
INFO - 2024-03-06 15:58:58 --> URI Class Initialized
INFO - 2024-03-06 15:58:58 --> Router Class Initialized
INFO - 2024-03-06 15:58:58 --> Output Class Initialized
INFO - 2024-03-06 15:58:58 --> Security Class Initialized
DEBUG - 2024-03-06 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:58:58 --> Input Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Language Class Initialized
INFO - 2024-03-06 15:58:58 --> Config Class Initialized
INFO - 2024-03-06 15:58:58 --> Loader Class Initialized
INFO - 2024-03-06 15:58:58 --> Helper loaded: url_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: file_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: form_helper
INFO - 2024-03-06 15:58:58 --> Helper loaded: my_helper
INFO - 2024-03-06 15:58:58 --> Database Driver Class Initialized
INFO - 2024-03-06 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:58:58 --> Controller Class Initialized
INFO - 2024-03-06 15:59:04 --> Config Class Initialized
INFO - 2024-03-06 15:59:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:04 --> URI Class Initialized
INFO - 2024-03-06 15:59:04 --> Router Class Initialized
INFO - 2024-03-06 15:59:04 --> Output Class Initialized
INFO - 2024-03-06 15:59:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:04 --> Input Class Initialized
INFO - 2024-03-06 15:59:04 --> Language Class Initialized
INFO - 2024-03-06 15:59:04 --> Language Class Initialized
INFO - 2024-03-06 15:59:04 --> Config Class Initialized
INFO - 2024-03-06 15:59:04 --> Loader Class Initialized
INFO - 2024-03-06 15:59:04 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:04 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:04 --> Controller Class Initialized
INFO - 2024-03-06 15:59:04 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:04 --> Total execution time: 0.0671
INFO - 2024-03-06 15:59:04 --> Config Class Initialized
INFO - 2024-03-06 15:59:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:04 --> URI Class Initialized
INFO - 2024-03-06 15:59:04 --> Router Class Initialized
INFO - 2024-03-06 15:59:04 --> Output Class Initialized
INFO - 2024-03-06 15:59:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:04 --> Input Class Initialized
INFO - 2024-03-06 15:59:04 --> Language Class Initialized
ERROR - 2024-03-06 15:59:04 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:59:04 --> Config Class Initialized
INFO - 2024-03-06 15:59:04 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:04 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:04 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:04 --> URI Class Initialized
INFO - 2024-03-06 15:59:04 --> Router Class Initialized
INFO - 2024-03-06 15:59:04 --> Output Class Initialized
INFO - 2024-03-06 15:59:04 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:04 --> Input Class Initialized
INFO - 2024-03-06 15:59:04 --> Language Class Initialized
INFO - 2024-03-06 15:59:04 --> Language Class Initialized
INFO - 2024-03-06 15:59:04 --> Config Class Initialized
INFO - 2024-03-06 15:59:04 --> Loader Class Initialized
INFO - 2024-03-06 15:59:04 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:04 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:04 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:04 --> Controller Class Initialized
INFO - 2024-03-06 15:59:06 --> Config Class Initialized
INFO - 2024-03-06 15:59:06 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:06 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:06 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:06 --> URI Class Initialized
INFO - 2024-03-06 15:59:06 --> Router Class Initialized
INFO - 2024-03-06 15:59:06 --> Output Class Initialized
INFO - 2024-03-06 15:59:06 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:06 --> Input Class Initialized
INFO - 2024-03-06 15:59:06 --> Language Class Initialized
INFO - 2024-03-06 15:59:06 --> Language Class Initialized
INFO - 2024-03-06 15:59:06 --> Config Class Initialized
INFO - 2024-03-06 15:59:06 --> Loader Class Initialized
INFO - 2024-03-06 15:59:06 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:06 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:06 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:06 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:06 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:06 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:59:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:06 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:06 --> Total execution time: 0.0681
INFO - 2024-03-06 15:59:17 --> Config Class Initialized
INFO - 2024-03-06 15:59:17 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:17 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:17 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:17 --> URI Class Initialized
INFO - 2024-03-06 15:59:17 --> Router Class Initialized
INFO - 2024-03-06 15:59:17 --> Output Class Initialized
INFO - 2024-03-06 15:59:17 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:17 --> Input Class Initialized
INFO - 2024-03-06 15:59:17 --> Language Class Initialized
INFO - 2024-03-06 15:59:17 --> Language Class Initialized
INFO - 2024-03-06 15:59:17 --> Config Class Initialized
INFO - 2024-03-06 15:59:17 --> Loader Class Initialized
INFO - 2024-03-06 15:59:17 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:17 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:17 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:17 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:17 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:17 --> Controller Class Initialized
INFO - 2024-03-06 15:59:18 --> Config Class Initialized
INFO - 2024-03-06 15:59:18 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:18 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:18 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:18 --> URI Class Initialized
INFO - 2024-03-06 15:59:18 --> Router Class Initialized
INFO - 2024-03-06 15:59:18 --> Output Class Initialized
INFO - 2024-03-06 15:59:18 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:18 --> Input Class Initialized
INFO - 2024-03-06 15:59:18 --> Language Class Initialized
INFO - 2024-03-06 15:59:18 --> Language Class Initialized
INFO - 2024-03-06 15:59:18 --> Config Class Initialized
INFO - 2024-03-06 15:59:18 --> Loader Class Initialized
INFO - 2024-03-06 15:59:18 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:18 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:18 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:18 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:18 --> Total execution time: 0.0737
INFO - 2024-03-06 15:59:18 --> Config Class Initialized
INFO - 2024-03-06 15:59:18 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:18 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:18 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:18 --> URI Class Initialized
INFO - 2024-03-06 15:59:18 --> Router Class Initialized
INFO - 2024-03-06 15:59:18 --> Output Class Initialized
INFO - 2024-03-06 15:59:18 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:18 --> Input Class Initialized
INFO - 2024-03-06 15:59:18 --> Language Class Initialized
ERROR - 2024-03-06 15:59:18 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:59:18 --> Config Class Initialized
INFO - 2024-03-06 15:59:18 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:18 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:18 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:18 --> URI Class Initialized
INFO - 2024-03-06 15:59:18 --> Router Class Initialized
INFO - 2024-03-06 15:59:18 --> Output Class Initialized
INFO - 2024-03-06 15:59:18 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:18 --> Input Class Initialized
INFO - 2024-03-06 15:59:18 --> Language Class Initialized
INFO - 2024-03-06 15:59:18 --> Language Class Initialized
INFO - 2024-03-06 15:59:18 --> Config Class Initialized
INFO - 2024-03-06 15:59:18 --> Loader Class Initialized
INFO - 2024-03-06 15:59:18 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:18 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:18 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:18 --> Controller Class Initialized
INFO - 2024-03-06 15:59:19 --> Config Class Initialized
INFO - 2024-03-06 15:59:19 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:19 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:19 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:19 --> URI Class Initialized
INFO - 2024-03-06 15:59:19 --> Router Class Initialized
INFO - 2024-03-06 15:59:19 --> Output Class Initialized
INFO - 2024-03-06 15:59:19 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:19 --> Input Class Initialized
INFO - 2024-03-06 15:59:19 --> Language Class Initialized
INFO - 2024-03-06 15:59:19 --> Language Class Initialized
INFO - 2024-03-06 15:59:19 --> Config Class Initialized
INFO - 2024-03-06 15:59:19 --> Loader Class Initialized
INFO - 2024-03-06 15:59:19 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:19 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:19 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:19 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:19 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:19 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2024-03-06 15:59:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:19 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:19 --> Total execution time: 0.0331
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:32 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:32 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:32 --> URI Class Initialized
INFO - 2024-03-06 15:59:32 --> Router Class Initialized
INFO - 2024-03-06 15:59:32 --> Output Class Initialized
INFO - 2024-03-06 15:59:32 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:32 --> Input Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Loader Class Initialized
INFO - 2024-03-06 15:59:32 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:32 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:32 --> Controller Class Initialized
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:32 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:32 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:32 --> URI Class Initialized
INFO - 2024-03-06 15:59:32 --> Router Class Initialized
INFO - 2024-03-06 15:59:32 --> Output Class Initialized
INFO - 2024-03-06 15:59:32 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:32 --> Input Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Loader Class Initialized
INFO - 2024-03-06 15:59:32 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:32 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:32 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2024-03-06 15:59:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:32 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:32 --> Total execution time: 0.0350
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:32 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:32 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:32 --> URI Class Initialized
INFO - 2024-03-06 15:59:32 --> Router Class Initialized
INFO - 2024-03-06 15:59:32 --> Output Class Initialized
INFO - 2024-03-06 15:59:32 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:32 --> Input Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
ERROR - 2024-03-06 15:59:32 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:32 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:32 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:32 --> URI Class Initialized
INFO - 2024-03-06 15:59:32 --> Router Class Initialized
INFO - 2024-03-06 15:59:32 --> Output Class Initialized
INFO - 2024-03-06 15:59:32 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:32 --> Input Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Language Class Initialized
INFO - 2024-03-06 15:59:32 --> Config Class Initialized
INFO - 2024-03-06 15:59:32 --> Loader Class Initialized
INFO - 2024-03-06 15:59:32 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:32 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:32 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:32 --> Controller Class Initialized
INFO - 2024-03-06 15:59:42 --> Config Class Initialized
INFO - 2024-03-06 15:59:42 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:42 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:42 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:42 --> URI Class Initialized
INFO - 2024-03-06 15:59:42 --> Router Class Initialized
INFO - 2024-03-06 15:59:42 --> Output Class Initialized
INFO - 2024-03-06 15:59:42 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:42 --> Input Class Initialized
INFO - 2024-03-06 15:59:42 --> Language Class Initialized
INFO - 2024-03-06 15:59:42 --> Language Class Initialized
INFO - 2024-03-06 15:59:42 --> Config Class Initialized
INFO - 2024-03-06 15:59:42 --> Loader Class Initialized
INFO - 2024-03-06 15:59:42 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:42 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:42 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2024-03-06 15:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:42 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:42 --> Total execution time: 0.2114
INFO - 2024-03-06 15:59:42 --> Config Class Initialized
INFO - 2024-03-06 15:59:42 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:42 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:42 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:42 --> URI Class Initialized
INFO - 2024-03-06 15:59:42 --> Router Class Initialized
INFO - 2024-03-06 15:59:42 --> Output Class Initialized
INFO - 2024-03-06 15:59:42 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:42 --> Input Class Initialized
INFO - 2024-03-06 15:59:42 --> Language Class Initialized
ERROR - 2024-03-06 15:59:42 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:59:42 --> Config Class Initialized
INFO - 2024-03-06 15:59:42 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:42 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:42 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:42 --> URI Class Initialized
INFO - 2024-03-06 15:59:42 --> Router Class Initialized
INFO - 2024-03-06 15:59:42 --> Output Class Initialized
INFO - 2024-03-06 15:59:42 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:42 --> Input Class Initialized
INFO - 2024-03-06 15:59:42 --> Language Class Initialized
INFO - 2024-03-06 15:59:42 --> Language Class Initialized
INFO - 2024-03-06 15:59:42 --> Config Class Initialized
INFO - 2024-03-06 15:59:42 --> Loader Class Initialized
INFO - 2024-03-06 15:59:42 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:42 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:42 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:42 --> Controller Class Initialized
INFO - 2024-03-06 15:59:50 --> Config Class Initialized
INFO - 2024-03-06 15:59:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:50 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:50 --> URI Class Initialized
INFO - 2024-03-06 15:59:50 --> Router Class Initialized
INFO - 2024-03-06 15:59:50 --> Output Class Initialized
INFO - 2024-03-06 15:59:50 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:50 --> Input Class Initialized
INFO - 2024-03-06 15:59:50 --> Language Class Initialized
INFO - 2024-03-06 15:59:50 --> Language Class Initialized
INFO - 2024-03-06 15:59:50 --> Config Class Initialized
INFO - 2024-03-06 15:59:50 --> Loader Class Initialized
INFO - 2024-03-06 15:59:50 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:50 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:50 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-03-06 15:59:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:50 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:50 --> Total execution time: 0.0815
INFO - 2024-03-06 15:59:50 --> Config Class Initialized
INFO - 2024-03-06 15:59:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:50 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:50 --> URI Class Initialized
INFO - 2024-03-06 15:59:50 --> Router Class Initialized
INFO - 2024-03-06 15:59:50 --> Output Class Initialized
INFO - 2024-03-06 15:59:50 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:50 --> Input Class Initialized
INFO - 2024-03-06 15:59:50 --> Language Class Initialized
ERROR - 2024-03-06 15:59:50 --> 404 Page Not Found: /index
INFO - 2024-03-06 15:59:50 --> Config Class Initialized
INFO - 2024-03-06 15:59:50 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:50 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:50 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:50 --> URI Class Initialized
INFO - 2024-03-06 15:59:50 --> Router Class Initialized
INFO - 2024-03-06 15:59:50 --> Output Class Initialized
INFO - 2024-03-06 15:59:50 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:50 --> Input Class Initialized
INFO - 2024-03-06 15:59:50 --> Language Class Initialized
INFO - 2024-03-06 15:59:50 --> Language Class Initialized
INFO - 2024-03-06 15:59:50 --> Config Class Initialized
INFO - 2024-03-06 15:59:50 --> Loader Class Initialized
INFO - 2024-03-06 15:59:50 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:50 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:50 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:50 --> Controller Class Initialized
INFO - 2024-03-06 15:59:55 --> Config Class Initialized
INFO - 2024-03-06 15:59:55 --> Hooks Class Initialized
DEBUG - 2024-03-06 15:59:55 --> UTF-8 Support Enabled
INFO - 2024-03-06 15:59:55 --> Utf8 Class Initialized
INFO - 2024-03-06 15:59:55 --> URI Class Initialized
INFO - 2024-03-06 15:59:55 --> Router Class Initialized
INFO - 2024-03-06 15:59:55 --> Output Class Initialized
INFO - 2024-03-06 15:59:55 --> Security Class Initialized
DEBUG - 2024-03-06 15:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 15:59:55 --> Input Class Initialized
INFO - 2024-03-06 15:59:55 --> Language Class Initialized
INFO - 2024-03-06 15:59:55 --> Language Class Initialized
INFO - 2024-03-06 15:59:55 --> Config Class Initialized
INFO - 2024-03-06 15:59:55 --> Loader Class Initialized
INFO - 2024-03-06 15:59:55 --> Helper loaded: url_helper
INFO - 2024-03-06 15:59:55 --> Helper loaded: file_helper
INFO - 2024-03-06 15:59:55 --> Helper loaded: form_helper
INFO - 2024-03-06 15:59:55 --> Helper loaded: my_helper
INFO - 2024-03-06 15:59:55 --> Database Driver Class Initialized
INFO - 2024-03-06 15:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 15:59:55 --> Controller Class Initialized
DEBUG - 2024-03-06 15:59:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-03-06 15:59:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 15:59:55 --> Final output sent to browser
DEBUG - 2024-03-06 15:59:55 --> Total execution time: 0.0503
INFO - 2024-03-06 16:00:52 --> Config Class Initialized
INFO - 2024-03-06 16:00:52 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:00:52 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:00:52 --> Utf8 Class Initialized
INFO - 2024-03-06 16:00:52 --> URI Class Initialized
INFO - 2024-03-06 16:00:52 --> Router Class Initialized
INFO - 2024-03-06 16:00:52 --> Output Class Initialized
INFO - 2024-03-06 16:00:52 --> Security Class Initialized
DEBUG - 2024-03-06 16:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:00:52 --> Input Class Initialized
INFO - 2024-03-06 16:00:52 --> Language Class Initialized
INFO - 2024-03-06 16:00:52 --> Language Class Initialized
INFO - 2024-03-06 16:00:52 --> Config Class Initialized
INFO - 2024-03-06 16:00:52 --> Loader Class Initialized
INFO - 2024-03-06 16:00:52 --> Helper loaded: url_helper
INFO - 2024-03-06 16:00:52 --> Helper loaded: file_helper
INFO - 2024-03-06 16:00:52 --> Helper loaded: form_helper
INFO - 2024-03-06 16:00:52 --> Helper loaded: my_helper
INFO - 2024-03-06 16:00:52 --> Database Driver Class Initialized
INFO - 2024-03-06 16:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:00:52 --> Controller Class Initialized
DEBUG - 2024-03-06 16:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-06 16:00:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:00:52 --> Final output sent to browser
DEBUG - 2024-03-06 16:00:52 --> Total execution time: 0.0482
INFO - 2024-03-06 16:00:53 --> Config Class Initialized
INFO - 2024-03-06 16:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:00:53 --> Utf8 Class Initialized
INFO - 2024-03-06 16:00:53 --> URI Class Initialized
INFO - 2024-03-06 16:00:53 --> Router Class Initialized
INFO - 2024-03-06 16:00:53 --> Output Class Initialized
INFO - 2024-03-06 16:00:53 --> Security Class Initialized
DEBUG - 2024-03-06 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:00:53 --> Input Class Initialized
INFO - 2024-03-06 16:00:53 --> Language Class Initialized
ERROR - 2024-03-06 16:00:53 --> 404 Page Not Found: /index
INFO - 2024-03-06 16:00:53 --> Config Class Initialized
INFO - 2024-03-06 16:00:53 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:00:53 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:00:53 --> Utf8 Class Initialized
INFO - 2024-03-06 16:00:53 --> URI Class Initialized
INFO - 2024-03-06 16:00:53 --> Router Class Initialized
INFO - 2024-03-06 16:00:53 --> Output Class Initialized
INFO - 2024-03-06 16:00:53 --> Security Class Initialized
DEBUG - 2024-03-06 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:00:53 --> Input Class Initialized
INFO - 2024-03-06 16:00:53 --> Language Class Initialized
INFO - 2024-03-06 16:00:53 --> Language Class Initialized
INFO - 2024-03-06 16:00:53 --> Config Class Initialized
INFO - 2024-03-06 16:00:53 --> Loader Class Initialized
INFO - 2024-03-06 16:00:53 --> Helper loaded: url_helper
INFO - 2024-03-06 16:00:53 --> Helper loaded: file_helper
INFO - 2024-03-06 16:00:53 --> Helper loaded: form_helper
INFO - 2024-03-06 16:00:53 --> Helper loaded: my_helper
INFO - 2024-03-06 16:00:53 --> Database Driver Class Initialized
INFO - 2024-03-06 16:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:00:53 --> Controller Class Initialized
INFO - 2024-03-06 16:00:59 --> Config Class Initialized
INFO - 2024-03-06 16:00:59 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:00:59 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:00:59 --> Utf8 Class Initialized
INFO - 2024-03-06 16:00:59 --> URI Class Initialized
INFO - 2024-03-06 16:00:59 --> Router Class Initialized
INFO - 2024-03-06 16:00:59 --> Output Class Initialized
INFO - 2024-03-06 16:00:59 --> Security Class Initialized
DEBUG - 2024-03-06 16:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:00:59 --> Input Class Initialized
INFO - 2024-03-06 16:00:59 --> Language Class Initialized
INFO - 2024-03-06 16:00:59 --> Language Class Initialized
INFO - 2024-03-06 16:00:59 --> Config Class Initialized
INFO - 2024-03-06 16:00:59 --> Loader Class Initialized
INFO - 2024-03-06 16:00:59 --> Helper loaded: url_helper
INFO - 2024-03-06 16:00:59 --> Helper loaded: file_helper
INFO - 2024-03-06 16:00:59 --> Helper loaded: form_helper
INFO - 2024-03-06 16:00:59 --> Helper loaded: my_helper
INFO - 2024-03-06 16:00:59 --> Database Driver Class Initialized
INFO - 2024-03-06 16:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:00:59 --> Controller Class Initialized
DEBUG - 2024-03-06 16:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-03-06 16:00:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:00:59 --> Final output sent to browser
DEBUG - 2024-03-06 16:00:59 --> Total execution time: 0.0415
INFO - 2024-03-06 16:01:05 --> Config Class Initialized
INFO - 2024-03-06 16:01:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:01:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:01:05 --> Utf8 Class Initialized
INFO - 2024-03-06 16:01:05 --> URI Class Initialized
INFO - 2024-03-06 16:01:05 --> Router Class Initialized
INFO - 2024-03-06 16:01:05 --> Output Class Initialized
INFO - 2024-03-06 16:01:05 --> Security Class Initialized
DEBUG - 2024-03-06 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:01:05 --> Input Class Initialized
INFO - 2024-03-06 16:01:05 --> Language Class Initialized
INFO - 2024-03-06 16:01:05 --> Language Class Initialized
INFO - 2024-03-06 16:01:05 --> Config Class Initialized
INFO - 2024-03-06 16:01:05 --> Loader Class Initialized
INFO - 2024-03-06 16:01:05 --> Helper loaded: url_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: file_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: form_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: my_helper
INFO - 2024-03-06 16:01:05 --> Database Driver Class Initialized
INFO - 2024-03-06 16:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:01:05 --> Controller Class Initialized
DEBUG - 2024-03-06 16:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas/views/list.php
DEBUG - 2024-03-06 16:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:01:05 --> Final output sent to browser
DEBUG - 2024-03-06 16:01:05 --> Total execution time: 0.0407
INFO - 2024-03-06 16:01:05 --> Config Class Initialized
INFO - 2024-03-06 16:01:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:01:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:01:05 --> Utf8 Class Initialized
INFO - 2024-03-06 16:01:05 --> URI Class Initialized
INFO - 2024-03-06 16:01:05 --> Router Class Initialized
INFO - 2024-03-06 16:01:05 --> Output Class Initialized
INFO - 2024-03-06 16:01:05 --> Security Class Initialized
DEBUG - 2024-03-06 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:01:05 --> Input Class Initialized
INFO - 2024-03-06 16:01:05 --> Language Class Initialized
ERROR - 2024-03-06 16:01:05 --> 404 Page Not Found: /index
INFO - 2024-03-06 16:01:05 --> Config Class Initialized
INFO - 2024-03-06 16:01:05 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:01:05 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:01:05 --> Utf8 Class Initialized
INFO - 2024-03-06 16:01:05 --> URI Class Initialized
INFO - 2024-03-06 16:01:05 --> Router Class Initialized
INFO - 2024-03-06 16:01:05 --> Output Class Initialized
INFO - 2024-03-06 16:01:05 --> Security Class Initialized
DEBUG - 2024-03-06 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:01:05 --> Input Class Initialized
INFO - 2024-03-06 16:01:05 --> Language Class Initialized
INFO - 2024-03-06 16:01:05 --> Language Class Initialized
INFO - 2024-03-06 16:01:05 --> Config Class Initialized
INFO - 2024-03-06 16:01:05 --> Loader Class Initialized
INFO - 2024-03-06 16:01:05 --> Helper loaded: url_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: file_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: form_helper
INFO - 2024-03-06 16:01:05 --> Helper loaded: my_helper
INFO - 2024-03-06 16:01:05 --> Database Driver Class Initialized
INFO - 2024-03-06 16:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:01:05 --> Controller Class Initialized
INFO - 2024-03-06 16:01:10 --> Config Class Initialized
INFO - 2024-03-06 16:01:10 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:01:10 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:01:10 --> Utf8 Class Initialized
INFO - 2024-03-06 16:01:10 --> URI Class Initialized
DEBUG - 2024-03-06 16:01:10 --> No URI present. Default controller set.
INFO - 2024-03-06 16:01:10 --> Router Class Initialized
INFO - 2024-03-06 16:01:10 --> Output Class Initialized
INFO - 2024-03-06 16:01:10 --> Security Class Initialized
DEBUG - 2024-03-06 16:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:01:10 --> Input Class Initialized
INFO - 2024-03-06 16:01:10 --> Language Class Initialized
INFO - 2024-03-06 16:01:10 --> Language Class Initialized
INFO - 2024-03-06 16:01:10 --> Config Class Initialized
INFO - 2024-03-06 16:01:10 --> Loader Class Initialized
INFO - 2024-03-06 16:01:10 --> Helper loaded: url_helper
INFO - 2024-03-06 16:01:10 --> Helper loaded: file_helper
INFO - 2024-03-06 16:01:10 --> Helper loaded: form_helper
INFO - 2024-03-06 16:01:10 --> Helper loaded: my_helper
INFO - 2024-03-06 16:01:10 --> Database Driver Class Initialized
INFO - 2024-03-06 16:01:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:01:10 --> Controller Class Initialized
DEBUG - 2024-03-06 16:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 16:01:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:01:10 --> Final output sent to browser
DEBUG - 2024-03-06 16:01:10 --> Total execution time: 0.0408
INFO - 2024-03-06 16:14:17 --> Config Class Initialized
INFO - 2024-03-06 16:14:17 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:14:17 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:14:17 --> Utf8 Class Initialized
INFO - 2024-03-06 16:14:17 --> URI Class Initialized
INFO - 2024-03-06 16:14:17 --> Router Class Initialized
INFO - 2024-03-06 16:14:17 --> Output Class Initialized
INFO - 2024-03-06 16:14:17 --> Security Class Initialized
DEBUG - 2024-03-06 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:14:17 --> Input Class Initialized
INFO - 2024-03-06 16:14:17 --> Language Class Initialized
INFO - 2024-03-06 16:14:17 --> Language Class Initialized
INFO - 2024-03-06 16:14:17 --> Config Class Initialized
INFO - 2024-03-06 16:14:17 --> Loader Class Initialized
INFO - 2024-03-06 16:14:17 --> Helper loaded: url_helper
INFO - 2024-03-06 16:14:17 --> Helper loaded: file_helper
INFO - 2024-03-06 16:14:17 --> Helper loaded: form_helper
INFO - 2024-03-06 16:14:17 --> Helper loaded: my_helper
INFO - 2024-03-06 16:14:17 --> Database Driver Class Initialized
INFO - 2024-03-06 16:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:14:17 --> Controller Class Initialized
DEBUG - 2024-03-06 16:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-03-06 16:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:14:17 --> Final output sent to browser
DEBUG - 2024-03-06 16:14:17 --> Total execution time: 0.2857
INFO - 2024-03-06 16:14:17 --> Config Class Initialized
INFO - 2024-03-06 16:14:17 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:14:17 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:14:17 --> Utf8 Class Initialized
INFO - 2024-03-06 16:14:17 --> URI Class Initialized
INFO - 2024-03-06 16:14:17 --> Router Class Initialized
INFO - 2024-03-06 16:14:17 --> Output Class Initialized
INFO - 2024-03-06 16:14:17 --> Security Class Initialized
DEBUG - 2024-03-06 16:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:14:17 --> Input Class Initialized
INFO - 2024-03-06 16:14:17 --> Language Class Initialized
ERROR - 2024-03-06 16:14:17 --> 404 Page Not Found: /index
INFO - 2024-03-06 16:14:17 --> Config Class Initialized
INFO - 2024-03-06 16:14:17 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:14:17 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:14:17 --> Utf8 Class Initialized
INFO - 2024-03-06 16:14:17 --> URI Class Initialized
INFO - 2024-03-06 16:14:17 --> Router Class Initialized
INFO - 2024-03-06 16:14:18 --> Output Class Initialized
INFO - 2024-03-06 16:14:18 --> Security Class Initialized
DEBUG - 2024-03-06 16:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:14:18 --> Input Class Initialized
INFO - 2024-03-06 16:14:18 --> Language Class Initialized
INFO - 2024-03-06 16:14:18 --> Language Class Initialized
INFO - 2024-03-06 16:14:18 --> Config Class Initialized
INFO - 2024-03-06 16:14:18 --> Loader Class Initialized
INFO - 2024-03-06 16:14:18 --> Helper loaded: url_helper
INFO - 2024-03-06 16:14:18 --> Helper loaded: file_helper
INFO - 2024-03-06 16:14:18 --> Helper loaded: form_helper
INFO - 2024-03-06 16:14:18 --> Helper loaded: my_helper
INFO - 2024-03-06 16:14:18 --> Database Driver Class Initialized
INFO - 2024-03-06 16:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:14:18 --> Controller Class Initialized
INFO - 2024-03-06 16:14:22 --> Config Class Initialized
INFO - 2024-03-06 16:14:22 --> Hooks Class Initialized
DEBUG - 2024-03-06 16:14:22 --> UTF-8 Support Enabled
INFO - 2024-03-06 16:14:22 --> Utf8 Class Initialized
INFO - 2024-03-06 16:14:22 --> URI Class Initialized
DEBUG - 2024-03-06 16:14:22 --> No URI present. Default controller set.
INFO - 2024-03-06 16:14:22 --> Router Class Initialized
INFO - 2024-03-06 16:14:22 --> Output Class Initialized
INFO - 2024-03-06 16:14:22 --> Security Class Initialized
DEBUG - 2024-03-06 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 16:14:22 --> Input Class Initialized
INFO - 2024-03-06 16:14:22 --> Language Class Initialized
INFO - 2024-03-06 16:14:22 --> Language Class Initialized
INFO - 2024-03-06 16:14:22 --> Config Class Initialized
INFO - 2024-03-06 16:14:22 --> Loader Class Initialized
INFO - 2024-03-06 16:14:22 --> Helper loaded: url_helper
INFO - 2024-03-06 16:14:22 --> Helper loaded: file_helper
INFO - 2024-03-06 16:14:22 --> Helper loaded: form_helper
INFO - 2024-03-06 16:14:22 --> Helper loaded: my_helper
INFO - 2024-03-06 16:14:22 --> Database Driver Class Initialized
INFO - 2024-03-06 16:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 16:14:22 --> Controller Class Initialized
DEBUG - 2024-03-06 16:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-06 16:14:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 16:14:22 --> Final output sent to browser
DEBUG - 2024-03-06 16:14:22 --> Total execution time: 0.2545
INFO - 2024-03-06 17:52:15 --> Config Class Initialized
INFO - 2024-03-06 17:52:15 --> Hooks Class Initialized
DEBUG - 2024-03-06 17:52:15 --> UTF-8 Support Enabled
INFO - 2024-03-06 17:52:15 --> Utf8 Class Initialized
INFO - 2024-03-06 17:52:15 --> URI Class Initialized
INFO - 2024-03-06 17:52:15 --> Router Class Initialized
INFO - 2024-03-06 17:52:16 --> Output Class Initialized
INFO - 2024-03-06 17:52:16 --> Security Class Initialized
DEBUG - 2024-03-06 17:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 17:52:16 --> Input Class Initialized
INFO - 2024-03-06 17:52:16 --> Language Class Initialized
INFO - 2024-03-06 17:52:16 --> Language Class Initialized
INFO - 2024-03-06 17:52:16 --> Config Class Initialized
INFO - 2024-03-06 17:52:16 --> Loader Class Initialized
INFO - 2024-03-06 17:52:16 --> Helper loaded: url_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: file_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: form_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: my_helper
INFO - 2024-03-06 17:52:16 --> Database Driver Class Initialized
INFO - 2024-03-06 17:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 17:52:16 --> Controller Class Initialized
INFO - 2024-03-06 17:52:16 --> Config Class Initialized
INFO - 2024-03-06 17:52:16 --> Hooks Class Initialized
DEBUG - 2024-03-06 17:52:16 --> UTF-8 Support Enabled
INFO - 2024-03-06 17:52:16 --> Utf8 Class Initialized
INFO - 2024-03-06 17:52:16 --> URI Class Initialized
INFO - 2024-03-06 17:52:16 --> Router Class Initialized
INFO - 2024-03-06 17:52:16 --> Output Class Initialized
INFO - 2024-03-06 17:52:16 --> Security Class Initialized
DEBUG - 2024-03-06 17:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-06 17:52:16 --> Input Class Initialized
INFO - 2024-03-06 17:52:16 --> Language Class Initialized
INFO - 2024-03-06 17:52:16 --> Language Class Initialized
INFO - 2024-03-06 17:52:16 --> Config Class Initialized
INFO - 2024-03-06 17:52:16 --> Loader Class Initialized
INFO - 2024-03-06 17:52:16 --> Helper loaded: url_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: file_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: form_helper
INFO - 2024-03-06 17:52:16 --> Helper loaded: my_helper
INFO - 2024-03-06 17:52:16 --> Database Driver Class Initialized
INFO - 2024-03-06 17:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-06 17:52:16 --> Controller Class Initialized
DEBUG - 2024-03-06 17:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-06 17:52:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-06 17:52:16 --> Final output sent to browser
DEBUG - 2024-03-06 17:52:16 --> Total execution time: 0.0792
