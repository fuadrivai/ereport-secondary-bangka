<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-03 14:34:07 --> Config Class Initialized
INFO - 2024-12-03 14:34:07 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:34:07 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:34:07 --> Utf8 Class Initialized
INFO - 2024-12-03 14:34:07 --> URI Class Initialized
INFO - 2024-12-03 14:34:07 --> Router Class Initialized
INFO - 2024-12-03 14:34:07 --> Output Class Initialized
INFO - 2024-12-03 14:34:07 --> Security Class Initialized
DEBUG - 2024-12-03 14:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:34:07 --> Input Class Initialized
INFO - 2024-12-03 14:34:07 --> Language Class Initialized
INFO - 2024-12-03 14:34:07 --> Language Class Initialized
INFO - 2024-12-03 14:34:07 --> Config Class Initialized
INFO - 2024-12-03 14:34:07 --> Loader Class Initialized
INFO - 2024-12-03 14:34:07 --> Helper loaded: url_helper
INFO - 2024-12-03 14:34:07 --> Helper loaded: file_helper
INFO - 2024-12-03 14:34:07 --> Helper loaded: form_helper
INFO - 2024-12-03 14:34:07 --> Helper loaded: my_helper
INFO - 2024-12-03 14:34:07 --> Database Driver Class Initialized
INFO - 2024-12-03 14:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:34:08 --> Controller Class Initialized
DEBUG - 2024-12-03 14:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-03 14:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:34:08 --> Final output sent to browser
DEBUG - 2024-12-03 14:34:08 --> Total execution time: 0.9226
INFO - 2024-12-03 14:34:18 --> Config Class Initialized
INFO - 2024-12-03 14:34:18 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:34:18 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:34:18 --> Utf8 Class Initialized
INFO - 2024-12-03 14:34:18 --> URI Class Initialized
INFO - 2024-12-03 14:34:18 --> Router Class Initialized
INFO - 2024-12-03 14:34:19 --> Output Class Initialized
INFO - 2024-12-03 14:34:19 --> Security Class Initialized
DEBUG - 2024-12-03 14:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:34:19 --> Input Class Initialized
INFO - 2024-12-03 14:34:19 --> Language Class Initialized
INFO - 2024-12-03 14:34:19 --> Language Class Initialized
INFO - 2024-12-03 14:34:19 --> Config Class Initialized
INFO - 2024-12-03 14:34:19 --> Loader Class Initialized
INFO - 2024-12-03 14:34:19 --> Helper loaded: url_helper
INFO - 2024-12-03 14:34:19 --> Helper loaded: file_helper
INFO - 2024-12-03 14:34:19 --> Helper loaded: form_helper
INFO - 2024-12-03 14:34:19 --> Helper loaded: my_helper
INFO - 2024-12-03 14:34:19 --> Database Driver Class Initialized
INFO - 2024-12-03 14:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:34:19 --> Controller Class Initialized
INFO - 2024-12-03 14:34:20 --> Helper loaded: cookie_helper
INFO - 2024-12-03 14:34:20 --> Final output sent to browser
DEBUG - 2024-12-03 14:34:20 --> Total execution time: 1.9620
INFO - 2024-12-03 14:34:20 --> Config Class Initialized
INFO - 2024-12-03 14:34:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:34:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:34:20 --> Utf8 Class Initialized
INFO - 2024-12-03 14:34:20 --> URI Class Initialized
INFO - 2024-12-03 14:34:20 --> Router Class Initialized
INFO - 2024-12-03 14:34:20 --> Output Class Initialized
INFO - 2024-12-03 14:34:20 --> Security Class Initialized
DEBUG - 2024-12-03 14:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:34:20 --> Input Class Initialized
INFO - 2024-12-03 14:34:20 --> Language Class Initialized
INFO - 2024-12-03 14:34:20 --> Language Class Initialized
INFO - 2024-12-03 14:34:20 --> Config Class Initialized
INFO - 2024-12-03 14:34:20 --> Loader Class Initialized
INFO - 2024-12-03 14:34:20 --> Helper loaded: url_helper
INFO - 2024-12-03 14:34:20 --> Helper loaded: file_helper
INFO - 2024-12-03 14:34:20 --> Helper loaded: form_helper
INFO - 2024-12-03 14:34:20 --> Helper loaded: my_helper
INFO - 2024-12-03 14:34:21 --> Database Driver Class Initialized
INFO - 2024-12-03 14:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:34:21 --> Controller Class Initialized
DEBUG - 2024-12-03 14:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-03 14:34:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:34:21 --> Final output sent to browser
DEBUG - 2024-12-03 14:34:21 --> Total execution time: 0.6581
INFO - 2024-12-03 14:35:23 --> Config Class Initialized
INFO - 2024-12-03 14:35:23 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:23 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:23 --> URI Class Initialized
INFO - 2024-12-03 14:35:23 --> Router Class Initialized
INFO - 2024-12-03 14:35:23 --> Output Class Initialized
INFO - 2024-12-03 14:35:23 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:23 --> Input Class Initialized
INFO - 2024-12-03 14:35:23 --> Language Class Initialized
INFO - 2024-12-03 14:35:23 --> Language Class Initialized
INFO - 2024-12-03 14:35:23 --> Config Class Initialized
INFO - 2024-12-03 14:35:23 --> Loader Class Initialized
INFO - 2024-12-03 14:35:23 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:23 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:23 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:23 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:24 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:24 --> Controller Class Initialized
DEBUG - 2024-12-03 14:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-03 14:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:35:24 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:24 --> Total execution time: 0.7419
INFO - 2024-12-03 14:35:26 --> Config Class Initialized
INFO - 2024-12-03 14:35:26 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:26 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:26 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:26 --> URI Class Initialized
INFO - 2024-12-03 14:35:26 --> Router Class Initialized
INFO - 2024-12-03 14:35:26 --> Output Class Initialized
INFO - 2024-12-03 14:35:26 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:26 --> Input Class Initialized
INFO - 2024-12-03 14:35:26 --> Language Class Initialized
INFO - 2024-12-03 14:35:26 --> Language Class Initialized
INFO - 2024-12-03 14:35:26 --> Config Class Initialized
INFO - 2024-12-03 14:35:26 --> Loader Class Initialized
INFO - 2024-12-03 14:35:26 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:26 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:26 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:26 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:26 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:26 --> Controller Class Initialized
DEBUG - 2024-12-03 14:35:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-03 14:35:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:35:27 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:27 --> Total execution time: 0.1561
INFO - 2024-12-03 14:35:27 --> Config Class Initialized
INFO - 2024-12-03 14:35:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:27 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:27 --> URI Class Initialized
INFO - 2024-12-03 14:35:27 --> Router Class Initialized
INFO - 2024-12-03 14:35:27 --> Output Class Initialized
INFO - 2024-12-03 14:35:27 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:27 --> Input Class Initialized
INFO - 2024-12-03 14:35:27 --> Language Class Initialized
INFO - 2024-12-03 14:35:27 --> Language Class Initialized
INFO - 2024-12-03 14:35:27 --> Config Class Initialized
INFO - 2024-12-03 14:35:27 --> Loader Class Initialized
INFO - 2024-12-03 14:35:27 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:27 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:27 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:27 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:27 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:27 --> Controller Class Initialized
INFO - 2024-12-03 14:35:30 --> Config Class Initialized
INFO - 2024-12-03 14:35:30 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:30 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:30 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:30 --> URI Class Initialized
INFO - 2024-12-03 14:35:30 --> Router Class Initialized
INFO - 2024-12-03 14:35:30 --> Output Class Initialized
INFO - 2024-12-03 14:35:30 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:31 --> Input Class Initialized
INFO - 2024-12-03 14:35:31 --> Language Class Initialized
INFO - 2024-12-03 14:35:31 --> Language Class Initialized
INFO - 2024-12-03 14:35:31 --> Config Class Initialized
INFO - 2024-12-03 14:35:31 --> Loader Class Initialized
INFO - 2024-12-03 14:35:31 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:31 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:31 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:31 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:31 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:31 --> Controller Class Initialized
DEBUG - 2024-12-03 14:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-03 14:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:35:31 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:31 --> Total execution time: 1.2971
INFO - 2024-12-03 14:35:34 --> Config Class Initialized
INFO - 2024-12-03 14:35:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:34 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:34 --> URI Class Initialized
INFO - 2024-12-03 14:35:34 --> Router Class Initialized
INFO - 2024-12-03 14:35:34 --> Output Class Initialized
INFO - 2024-12-03 14:35:34 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:34 --> Input Class Initialized
INFO - 2024-12-03 14:35:34 --> Language Class Initialized
INFO - 2024-12-03 14:35:34 --> Language Class Initialized
INFO - 2024-12-03 14:35:34 --> Config Class Initialized
INFO - 2024-12-03 14:35:34 --> Loader Class Initialized
INFO - 2024-12-03 14:35:34 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:34 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:34 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:34 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:34 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:34 --> Controller Class Initialized
DEBUG - 2024-12-03 14:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-03 14:35:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 14:35:34 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:34 --> Total execution time: 0.1362
INFO - 2024-12-03 14:35:34 --> Config Class Initialized
INFO - 2024-12-03 14:35:34 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:34 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:34 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:34 --> URI Class Initialized
INFO - 2024-12-03 14:35:34 --> Router Class Initialized
INFO - 2024-12-03 14:35:35 --> Output Class Initialized
INFO - 2024-12-03 14:35:35 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:35 --> Input Class Initialized
INFO - 2024-12-03 14:35:35 --> Language Class Initialized
INFO - 2024-12-03 14:35:35 --> Language Class Initialized
INFO - 2024-12-03 14:35:35 --> Config Class Initialized
INFO - 2024-12-03 14:35:35 --> Loader Class Initialized
INFO - 2024-12-03 14:35:35 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:35 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:35 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:35 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:35 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:35 --> Controller Class Initialized
INFO - 2024-12-03 14:35:37 --> Config Class Initialized
INFO - 2024-12-03 14:35:37 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:37 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:37 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:37 --> URI Class Initialized
INFO - 2024-12-03 14:35:37 --> Router Class Initialized
INFO - 2024-12-03 14:35:37 --> Output Class Initialized
INFO - 2024-12-03 14:35:37 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:37 --> Input Class Initialized
INFO - 2024-12-03 14:35:37 --> Language Class Initialized
INFO - 2024-12-03 14:35:37 --> Language Class Initialized
INFO - 2024-12-03 14:35:37 --> Config Class Initialized
INFO - 2024-12-03 14:35:37 --> Loader Class Initialized
INFO - 2024-12-03 14:35:37 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:37 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:37 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:37 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:37 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:37 --> Controller Class Initialized
INFO - 2024-12-03 14:35:38 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:38 --> Total execution time: 0.2788
INFO - 2024-12-03 14:35:38 --> Config Class Initialized
INFO - 2024-12-03 14:35:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 14:35:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 14:35:38 --> Utf8 Class Initialized
INFO - 2024-12-03 14:35:38 --> URI Class Initialized
INFO - 2024-12-03 14:35:38 --> Router Class Initialized
INFO - 2024-12-03 14:35:38 --> Output Class Initialized
INFO - 2024-12-03 14:35:38 --> Security Class Initialized
DEBUG - 2024-12-03 14:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 14:35:38 --> Input Class Initialized
INFO - 2024-12-03 14:35:38 --> Language Class Initialized
INFO - 2024-12-03 14:35:38 --> Language Class Initialized
INFO - 2024-12-03 14:35:38 --> Config Class Initialized
INFO - 2024-12-03 14:35:38 --> Loader Class Initialized
INFO - 2024-12-03 14:35:38 --> Helper loaded: url_helper
INFO - 2024-12-03 14:35:38 --> Helper loaded: file_helper
INFO - 2024-12-03 14:35:38 --> Helper loaded: form_helper
INFO - 2024-12-03 14:35:38 --> Helper loaded: my_helper
INFO - 2024-12-03 14:35:38 --> Database Driver Class Initialized
INFO - 2024-12-03 14:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 14:35:38 --> Controller Class Initialized
INFO - 2024-12-03 14:35:38 --> Final output sent to browser
DEBUG - 2024-12-03 14:35:38 --> Total execution time: 0.0567
INFO - 2024-12-03 15:06:52 --> Config Class Initialized
INFO - 2024-12-03 15:06:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:06:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:06:52 --> Utf8 Class Initialized
INFO - 2024-12-03 15:06:52 --> URI Class Initialized
INFO - 2024-12-03 15:06:52 --> Router Class Initialized
INFO - 2024-12-03 15:06:52 --> Output Class Initialized
INFO - 2024-12-03 15:06:52 --> Security Class Initialized
DEBUG - 2024-12-03 15:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:06:52 --> Input Class Initialized
INFO - 2024-12-03 15:06:52 --> Language Class Initialized
INFO - 2024-12-03 15:06:52 --> Language Class Initialized
INFO - 2024-12-03 15:06:52 --> Config Class Initialized
INFO - 2024-12-03 15:06:52 --> Loader Class Initialized
INFO - 2024-12-03 15:06:52 --> Helper loaded: url_helper
INFO - 2024-12-03 15:06:52 --> Helper loaded: file_helper
INFO - 2024-12-03 15:06:52 --> Helper loaded: form_helper
INFO - 2024-12-03 15:06:52 --> Helper loaded: my_helper
INFO - 2024-12-03 15:06:52 --> Database Driver Class Initialized
INFO - 2024-12-03 15:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:06:52 --> Controller Class Initialized
INFO - 2024-12-03 15:06:52 --> Final output sent to browser
DEBUG - 2024-12-03 15:06:52 --> Total execution time: 0.0745
INFO - 2024-12-03 15:06:59 --> Config Class Initialized
INFO - 2024-12-03 15:06:59 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:06:59 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:06:59 --> Utf8 Class Initialized
INFO - 2024-12-03 15:06:59 --> URI Class Initialized
INFO - 2024-12-03 15:06:59 --> Router Class Initialized
INFO - 2024-12-03 15:06:59 --> Output Class Initialized
INFO - 2024-12-03 15:06:59 --> Security Class Initialized
DEBUG - 2024-12-03 15:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:06:59 --> Input Class Initialized
INFO - 2024-12-03 15:06:59 --> Language Class Initialized
INFO - 2024-12-03 15:06:59 --> Language Class Initialized
INFO - 2024-12-03 15:06:59 --> Config Class Initialized
INFO - 2024-12-03 15:06:59 --> Loader Class Initialized
INFO - 2024-12-03 15:06:59 --> Helper loaded: url_helper
INFO - 2024-12-03 15:06:59 --> Helper loaded: file_helper
INFO - 2024-12-03 15:06:59 --> Helper loaded: form_helper
INFO - 2024-12-03 15:06:59 --> Helper loaded: my_helper
INFO - 2024-12-03 15:06:59 --> Database Driver Class Initialized
INFO - 2024-12-03 15:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:06:59 --> Controller Class Initialized
INFO - 2024-12-03 15:06:59 --> Final output sent to browser
DEBUG - 2024-12-03 15:06:59 --> Total execution time: 0.3426
INFO - 2024-12-03 15:07:40 --> Config Class Initialized
INFO - 2024-12-03 15:07:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:07:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:07:40 --> Utf8 Class Initialized
INFO - 2024-12-03 15:07:40 --> URI Class Initialized
INFO - 2024-12-03 15:07:40 --> Router Class Initialized
INFO - 2024-12-03 15:07:40 --> Output Class Initialized
INFO - 2024-12-03 15:07:40 --> Security Class Initialized
DEBUG - 2024-12-03 15:07:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:07:40 --> Input Class Initialized
INFO - 2024-12-03 15:07:40 --> Language Class Initialized
INFO - 2024-12-03 15:07:40 --> Language Class Initialized
INFO - 2024-12-03 15:07:40 --> Config Class Initialized
INFO - 2024-12-03 15:07:40 --> Loader Class Initialized
INFO - 2024-12-03 15:07:40 --> Helper loaded: url_helper
INFO - 2024-12-03 15:07:40 --> Helper loaded: file_helper
INFO - 2024-12-03 15:07:40 --> Helper loaded: form_helper
INFO - 2024-12-03 15:07:40 --> Helper loaded: my_helper
INFO - 2024-12-03 15:07:40 --> Database Driver Class Initialized
INFO - 2024-12-03 15:07:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:07:40 --> Controller Class Initialized
INFO - 2024-12-03 15:07:41 --> Final output sent to browser
DEBUG - 2024-12-03 15:07:41 --> Total execution time: 0.7394
INFO - 2024-12-03 15:07:45 --> Config Class Initialized
INFO - 2024-12-03 15:07:45 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:07:45 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:07:45 --> Utf8 Class Initialized
INFO - 2024-12-03 15:07:45 --> URI Class Initialized
INFO - 2024-12-03 15:07:45 --> Router Class Initialized
INFO - 2024-12-03 15:07:45 --> Output Class Initialized
INFO - 2024-12-03 15:07:45 --> Security Class Initialized
DEBUG - 2024-12-03 15:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:07:45 --> Input Class Initialized
INFO - 2024-12-03 15:07:45 --> Language Class Initialized
INFO - 2024-12-03 15:07:45 --> Language Class Initialized
INFO - 2024-12-03 15:07:45 --> Config Class Initialized
INFO - 2024-12-03 15:07:45 --> Loader Class Initialized
INFO - 2024-12-03 15:07:45 --> Helper loaded: url_helper
INFO - 2024-12-03 15:07:45 --> Helper loaded: file_helper
INFO - 2024-12-03 15:07:45 --> Helper loaded: form_helper
INFO - 2024-12-03 15:07:45 --> Helper loaded: my_helper
INFO - 2024-12-03 15:07:45 --> Database Driver Class Initialized
INFO - 2024-12-03 15:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:07:45 --> Controller Class Initialized
INFO - 2024-12-03 15:07:45 --> Final output sent to browser
DEBUG - 2024-12-03 15:07:45 --> Total execution time: 0.1606
INFO - 2024-12-03 15:08:33 --> Config Class Initialized
INFO - 2024-12-03 15:08:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:08:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:08:33 --> Utf8 Class Initialized
INFO - 2024-12-03 15:08:33 --> URI Class Initialized
INFO - 2024-12-03 15:08:33 --> Router Class Initialized
INFO - 2024-12-03 15:08:33 --> Output Class Initialized
INFO - 2024-12-03 15:08:33 --> Security Class Initialized
DEBUG - 2024-12-03 15:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:08:33 --> Input Class Initialized
INFO - 2024-12-03 15:08:33 --> Language Class Initialized
INFO - 2024-12-03 15:08:33 --> Language Class Initialized
INFO - 2024-12-03 15:08:33 --> Config Class Initialized
INFO - 2024-12-03 15:08:33 --> Loader Class Initialized
INFO - 2024-12-03 15:08:33 --> Helper loaded: url_helper
INFO - 2024-12-03 15:08:33 --> Helper loaded: file_helper
INFO - 2024-12-03 15:08:33 --> Helper loaded: form_helper
INFO - 2024-12-03 15:08:33 --> Helper loaded: my_helper
INFO - 2024-12-03 15:08:33 --> Database Driver Class Initialized
INFO - 2024-12-03 15:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:08:33 --> Controller Class Initialized
INFO - 2024-12-03 15:08:33 --> Final output sent to browser
DEBUG - 2024-12-03 15:08:33 --> Total execution time: 0.1969
INFO - 2024-12-03 15:08:36 --> Config Class Initialized
INFO - 2024-12-03 15:08:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:08:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:08:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:08:36 --> URI Class Initialized
INFO - 2024-12-03 15:08:36 --> Router Class Initialized
INFO - 2024-12-03 15:08:36 --> Output Class Initialized
INFO - 2024-12-03 15:08:36 --> Security Class Initialized
DEBUG - 2024-12-03 15:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:08:36 --> Input Class Initialized
INFO - 2024-12-03 15:08:36 --> Language Class Initialized
INFO - 2024-12-03 15:08:36 --> Language Class Initialized
INFO - 2024-12-03 15:08:36 --> Config Class Initialized
INFO - 2024-12-03 15:08:36 --> Loader Class Initialized
INFO - 2024-12-03 15:08:36 --> Helper loaded: url_helper
INFO - 2024-12-03 15:08:36 --> Helper loaded: file_helper
INFO - 2024-12-03 15:08:36 --> Helper loaded: form_helper
INFO - 2024-12-03 15:08:36 --> Helper loaded: my_helper
INFO - 2024-12-03 15:08:36 --> Database Driver Class Initialized
INFO - 2024-12-03 15:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:08:36 --> Controller Class Initialized
INFO - 2024-12-03 15:08:36 --> Final output sent to browser
DEBUG - 2024-12-03 15:08:36 --> Total execution time: 0.3790
INFO - 2024-12-03 15:08:38 --> Config Class Initialized
INFO - 2024-12-03 15:08:38 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:08:38 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:08:38 --> Utf8 Class Initialized
INFO - 2024-12-03 15:08:38 --> URI Class Initialized
INFO - 2024-12-03 15:08:38 --> Router Class Initialized
INFO - 2024-12-03 15:08:38 --> Output Class Initialized
INFO - 2024-12-03 15:08:38 --> Security Class Initialized
DEBUG - 2024-12-03 15:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:08:38 --> Input Class Initialized
INFO - 2024-12-03 15:08:38 --> Language Class Initialized
INFO - 2024-12-03 15:08:38 --> Language Class Initialized
INFO - 2024-12-03 15:08:38 --> Config Class Initialized
INFO - 2024-12-03 15:08:38 --> Loader Class Initialized
INFO - 2024-12-03 15:08:38 --> Helper loaded: url_helper
INFO - 2024-12-03 15:08:38 --> Helper loaded: file_helper
INFO - 2024-12-03 15:08:38 --> Helper loaded: form_helper
INFO - 2024-12-03 15:08:38 --> Helper loaded: my_helper
INFO - 2024-12-03 15:08:38 --> Database Driver Class Initialized
INFO - 2024-12-03 15:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:08:38 --> Controller Class Initialized
INFO - 2024-12-03 15:08:38 --> Final output sent to browser
DEBUG - 2024-12-03 15:08:38 --> Total execution time: 0.0710
INFO - 2024-12-03 15:09:20 --> Config Class Initialized
INFO - 2024-12-03 15:09:20 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:09:20 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:09:20 --> Utf8 Class Initialized
INFO - 2024-12-03 15:09:20 --> URI Class Initialized
INFO - 2024-12-03 15:09:20 --> Router Class Initialized
INFO - 2024-12-03 15:09:20 --> Output Class Initialized
INFO - 2024-12-03 15:09:20 --> Security Class Initialized
DEBUG - 2024-12-03 15:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:09:20 --> Input Class Initialized
INFO - 2024-12-03 15:09:20 --> Language Class Initialized
INFO - 2024-12-03 15:09:20 --> Language Class Initialized
INFO - 2024-12-03 15:09:20 --> Config Class Initialized
INFO - 2024-12-03 15:09:20 --> Loader Class Initialized
INFO - 2024-12-03 15:09:20 --> Helper loaded: url_helper
INFO - 2024-12-03 15:09:20 --> Helper loaded: file_helper
INFO - 2024-12-03 15:09:20 --> Helper loaded: form_helper
INFO - 2024-12-03 15:09:20 --> Helper loaded: my_helper
INFO - 2024-12-03 15:09:20 --> Database Driver Class Initialized
INFO - 2024-12-03 15:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:09:20 --> Controller Class Initialized
INFO - 2024-12-03 15:09:21 --> Final output sent to browser
DEBUG - 2024-12-03 15:09:21 --> Total execution time: 0.6644
INFO - 2024-12-03 15:09:23 --> Config Class Initialized
INFO - 2024-12-03 15:09:23 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:09:23 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:09:23 --> Utf8 Class Initialized
INFO - 2024-12-03 15:09:23 --> URI Class Initialized
INFO - 2024-12-03 15:09:23 --> Router Class Initialized
INFO - 2024-12-03 15:09:23 --> Output Class Initialized
INFO - 2024-12-03 15:09:23 --> Security Class Initialized
DEBUG - 2024-12-03 15:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:09:23 --> Input Class Initialized
INFO - 2024-12-03 15:09:23 --> Language Class Initialized
INFO - 2024-12-03 15:09:23 --> Language Class Initialized
INFO - 2024-12-03 15:09:23 --> Config Class Initialized
INFO - 2024-12-03 15:09:23 --> Loader Class Initialized
INFO - 2024-12-03 15:09:23 --> Helper loaded: url_helper
INFO - 2024-12-03 15:09:23 --> Helper loaded: file_helper
INFO - 2024-12-03 15:09:23 --> Helper loaded: form_helper
INFO - 2024-12-03 15:09:23 --> Helper loaded: my_helper
INFO - 2024-12-03 15:09:23 --> Database Driver Class Initialized
INFO - 2024-12-03 15:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:09:23 --> Controller Class Initialized
INFO - 2024-12-03 15:09:23 --> Final output sent to browser
DEBUG - 2024-12-03 15:09:23 --> Total execution time: 0.0296
INFO - 2024-12-03 15:10:12 --> Config Class Initialized
INFO - 2024-12-03 15:10:12 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:12 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:12 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:12 --> URI Class Initialized
INFO - 2024-12-03 15:10:12 --> Router Class Initialized
INFO - 2024-12-03 15:10:12 --> Output Class Initialized
INFO - 2024-12-03 15:10:12 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:12 --> Input Class Initialized
INFO - 2024-12-03 15:10:12 --> Language Class Initialized
INFO - 2024-12-03 15:10:12 --> Language Class Initialized
INFO - 2024-12-03 15:10:12 --> Config Class Initialized
INFO - 2024-12-03 15:10:12 --> Loader Class Initialized
INFO - 2024-12-03 15:10:12 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:12 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:12 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:12 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:12 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:12 --> Controller Class Initialized
INFO - 2024-12-03 15:10:12 --> Final output sent to browser
DEBUG - 2024-12-03 15:10:12 --> Total execution time: 0.0352
INFO - 2024-12-03 15:10:27 --> Config Class Initialized
INFO - 2024-12-03 15:10:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:27 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:27 --> URI Class Initialized
INFO - 2024-12-03 15:10:27 --> Router Class Initialized
INFO - 2024-12-03 15:10:27 --> Output Class Initialized
INFO - 2024-12-03 15:10:27 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:27 --> Input Class Initialized
INFO - 2024-12-03 15:10:27 --> Language Class Initialized
INFO - 2024-12-03 15:10:27 --> Language Class Initialized
INFO - 2024-12-03 15:10:27 --> Config Class Initialized
INFO - 2024-12-03 15:10:27 --> Loader Class Initialized
INFO - 2024-12-03 15:10:27 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:27 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:27 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:27 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:27 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:27 --> Controller Class Initialized
INFO - 2024-12-03 15:10:27 --> Final output sent to browser
DEBUG - 2024-12-03 15:10:27 --> Total execution time: 0.0335
INFO - 2024-12-03 15:10:28 --> Config Class Initialized
INFO - 2024-12-03 15:10:28 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:28 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:28 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:28 --> URI Class Initialized
INFO - 2024-12-03 15:10:28 --> Router Class Initialized
INFO - 2024-12-03 15:10:28 --> Output Class Initialized
INFO - 2024-12-03 15:10:28 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:28 --> Input Class Initialized
INFO - 2024-12-03 15:10:28 --> Language Class Initialized
INFO - 2024-12-03 15:10:28 --> Language Class Initialized
INFO - 2024-12-03 15:10:28 --> Config Class Initialized
INFO - 2024-12-03 15:10:28 --> Loader Class Initialized
INFO - 2024-12-03 15:10:28 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:28 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:28 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:28 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:28 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:28 --> Controller Class Initialized
INFO - 2024-12-03 15:10:29 --> Config Class Initialized
INFO - 2024-12-03 15:10:29 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:29 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:29 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:29 --> URI Class Initialized
INFO - 2024-12-03 15:10:29 --> Router Class Initialized
INFO - 2024-12-03 15:10:29 --> Output Class Initialized
INFO - 2024-12-03 15:10:29 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:29 --> Input Class Initialized
INFO - 2024-12-03 15:10:29 --> Language Class Initialized
INFO - 2024-12-03 15:10:29 --> Language Class Initialized
INFO - 2024-12-03 15:10:29 --> Config Class Initialized
INFO - 2024-12-03 15:10:29 --> Loader Class Initialized
INFO - 2024-12-03 15:10:29 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:29 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:29 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:29 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:29 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:29 --> Controller Class Initialized
INFO - 2024-12-03 15:10:29 --> Final output sent to browser
DEBUG - 2024-12-03 15:10:29 --> Total execution time: 0.1088
INFO - 2024-12-03 15:10:54 --> Config Class Initialized
INFO - 2024-12-03 15:10:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:54 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:54 --> URI Class Initialized
INFO - 2024-12-03 15:10:54 --> Router Class Initialized
INFO - 2024-12-03 15:10:54 --> Output Class Initialized
INFO - 2024-12-03 15:10:54 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:54 --> Input Class Initialized
INFO - 2024-12-03 15:10:54 --> Language Class Initialized
INFO - 2024-12-03 15:10:54 --> Language Class Initialized
INFO - 2024-12-03 15:10:54 --> Config Class Initialized
INFO - 2024-12-03 15:10:54 --> Loader Class Initialized
INFO - 2024-12-03 15:10:54 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:54 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:54 --> Controller Class Initialized
INFO - 2024-12-03 15:10:54 --> Final output sent to browser
DEBUG - 2024-12-03 15:10:54 --> Total execution time: 0.0299
INFO - 2024-12-03 15:10:54 --> Config Class Initialized
INFO - 2024-12-03 15:10:54 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:54 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:54 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:54 --> URI Class Initialized
INFO - 2024-12-03 15:10:54 --> Router Class Initialized
INFO - 2024-12-03 15:10:54 --> Output Class Initialized
INFO - 2024-12-03 15:10:54 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:54 --> Input Class Initialized
INFO - 2024-12-03 15:10:54 --> Language Class Initialized
INFO - 2024-12-03 15:10:54 --> Language Class Initialized
INFO - 2024-12-03 15:10:54 --> Config Class Initialized
INFO - 2024-12-03 15:10:54 --> Loader Class Initialized
INFO - 2024-12-03 15:10:54 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:54 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:54 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:54 --> Controller Class Initialized
INFO - 2024-12-03 15:10:56 --> Config Class Initialized
INFO - 2024-12-03 15:10:56 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:10:56 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:10:56 --> Utf8 Class Initialized
INFO - 2024-12-03 15:10:56 --> URI Class Initialized
INFO - 2024-12-03 15:10:56 --> Router Class Initialized
INFO - 2024-12-03 15:10:56 --> Output Class Initialized
INFO - 2024-12-03 15:10:56 --> Security Class Initialized
DEBUG - 2024-12-03 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:10:56 --> Input Class Initialized
INFO - 2024-12-03 15:10:56 --> Language Class Initialized
INFO - 2024-12-03 15:10:56 --> Language Class Initialized
INFO - 2024-12-03 15:10:56 --> Config Class Initialized
INFO - 2024-12-03 15:10:56 --> Loader Class Initialized
INFO - 2024-12-03 15:10:56 --> Helper loaded: url_helper
INFO - 2024-12-03 15:10:56 --> Helper loaded: file_helper
INFO - 2024-12-03 15:10:56 --> Helper loaded: form_helper
INFO - 2024-12-03 15:10:56 --> Helper loaded: my_helper
INFO - 2024-12-03 15:10:56 --> Database Driver Class Initialized
INFO - 2024-12-03 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:10:56 --> Controller Class Initialized
INFO - 2024-12-03 15:10:56 --> Final output sent to browser
DEBUG - 2024-12-03 15:10:56 --> Total execution time: 0.0916
INFO - 2024-12-03 15:11:16 --> Config Class Initialized
INFO - 2024-12-03 15:11:16 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:11:16 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:11:16 --> Utf8 Class Initialized
INFO - 2024-12-03 15:11:16 --> URI Class Initialized
INFO - 2024-12-03 15:11:16 --> Router Class Initialized
INFO - 2024-12-03 15:11:16 --> Output Class Initialized
INFO - 2024-12-03 15:11:16 --> Security Class Initialized
DEBUG - 2024-12-03 15:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:11:16 --> Input Class Initialized
INFO - 2024-12-03 15:11:16 --> Language Class Initialized
INFO - 2024-12-03 15:11:16 --> Language Class Initialized
INFO - 2024-12-03 15:11:16 --> Config Class Initialized
INFO - 2024-12-03 15:11:16 --> Loader Class Initialized
INFO - 2024-12-03 15:11:16 --> Helper loaded: url_helper
INFO - 2024-12-03 15:11:16 --> Helper loaded: file_helper
INFO - 2024-12-03 15:11:16 --> Helper loaded: form_helper
INFO - 2024-12-03 15:11:16 --> Helper loaded: my_helper
INFO - 2024-12-03 15:11:16 --> Database Driver Class Initialized
INFO - 2024-12-03 15:11:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:11:16 --> Controller Class Initialized
INFO - 2024-12-03 15:11:16 --> Final output sent to browser
DEBUG - 2024-12-03 15:11:16 --> Total execution time: 0.1252
INFO - 2024-12-03 15:11:52 --> Config Class Initialized
INFO - 2024-12-03 15:11:52 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:11:52 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:11:52 --> Utf8 Class Initialized
INFO - 2024-12-03 15:11:52 --> URI Class Initialized
INFO - 2024-12-03 15:11:52 --> Router Class Initialized
INFO - 2024-12-03 15:11:52 --> Output Class Initialized
INFO - 2024-12-03 15:11:52 --> Security Class Initialized
DEBUG - 2024-12-03 15:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:11:52 --> Input Class Initialized
INFO - 2024-12-03 15:11:52 --> Language Class Initialized
INFO - 2024-12-03 15:11:52 --> Language Class Initialized
INFO - 2024-12-03 15:11:52 --> Config Class Initialized
INFO - 2024-12-03 15:11:52 --> Loader Class Initialized
INFO - 2024-12-03 15:11:52 --> Helper loaded: url_helper
INFO - 2024-12-03 15:11:52 --> Helper loaded: file_helper
INFO - 2024-12-03 15:11:52 --> Helper loaded: form_helper
INFO - 2024-12-03 15:11:52 --> Helper loaded: my_helper
INFO - 2024-12-03 15:11:52 --> Database Driver Class Initialized
INFO - 2024-12-03 15:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:11:52 --> Controller Class Initialized
INFO - 2024-12-03 15:11:52 --> Final output sent to browser
DEBUG - 2024-12-03 15:11:52 --> Total execution time: 0.3415
INFO - 2024-12-03 15:13:03 --> Config Class Initialized
INFO - 2024-12-03 15:13:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:13:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:13:03 --> Utf8 Class Initialized
INFO - 2024-12-03 15:13:03 --> URI Class Initialized
INFO - 2024-12-03 15:13:03 --> Router Class Initialized
INFO - 2024-12-03 15:13:03 --> Output Class Initialized
INFO - 2024-12-03 15:13:03 --> Security Class Initialized
DEBUG - 2024-12-03 15:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:13:03 --> Input Class Initialized
INFO - 2024-12-03 15:13:03 --> Language Class Initialized
INFO - 2024-12-03 15:13:03 --> Language Class Initialized
INFO - 2024-12-03 15:13:03 --> Config Class Initialized
INFO - 2024-12-03 15:13:03 --> Loader Class Initialized
INFO - 2024-12-03 15:13:03 --> Helper loaded: url_helper
INFO - 2024-12-03 15:13:03 --> Helper loaded: file_helper
INFO - 2024-12-03 15:13:03 --> Helper loaded: form_helper
INFO - 2024-12-03 15:13:03 --> Helper loaded: my_helper
INFO - 2024-12-03 15:13:03 --> Database Driver Class Initialized
INFO - 2024-12-03 15:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:13:03 --> Controller Class Initialized
INFO - 2024-12-03 15:13:03 --> Final output sent to browser
DEBUG - 2024-12-03 15:13:03 --> Total execution time: 0.4134
INFO - 2024-12-03 15:13:10 --> Config Class Initialized
INFO - 2024-12-03 15:13:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:13:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:13:10 --> Utf8 Class Initialized
INFO - 2024-12-03 15:13:10 --> URI Class Initialized
INFO - 2024-12-03 15:13:10 --> Router Class Initialized
INFO - 2024-12-03 15:13:10 --> Output Class Initialized
INFO - 2024-12-03 15:13:10 --> Security Class Initialized
DEBUG - 2024-12-03 15:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:13:10 --> Input Class Initialized
INFO - 2024-12-03 15:13:10 --> Language Class Initialized
INFO - 2024-12-03 15:13:10 --> Language Class Initialized
INFO - 2024-12-03 15:13:10 --> Config Class Initialized
INFO - 2024-12-03 15:13:10 --> Loader Class Initialized
INFO - 2024-12-03 15:13:10 --> Helper loaded: url_helper
INFO - 2024-12-03 15:13:10 --> Helper loaded: file_helper
INFO - 2024-12-03 15:13:10 --> Helper loaded: form_helper
INFO - 2024-12-03 15:13:10 --> Helper loaded: my_helper
INFO - 2024-12-03 15:13:10 --> Database Driver Class Initialized
INFO - 2024-12-03 15:13:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:13:11 --> Controller Class Initialized
INFO - 2024-12-03 15:13:11 --> Final output sent to browser
DEBUG - 2024-12-03 15:13:11 --> Total execution time: 0.1939
INFO - 2024-12-03 15:13:15 --> Config Class Initialized
INFO - 2024-12-03 15:13:15 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:13:15 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:13:15 --> Utf8 Class Initialized
INFO - 2024-12-03 15:13:15 --> URI Class Initialized
INFO - 2024-12-03 15:13:15 --> Router Class Initialized
INFO - 2024-12-03 15:13:15 --> Output Class Initialized
INFO - 2024-12-03 15:13:15 --> Security Class Initialized
DEBUG - 2024-12-03 15:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:13:15 --> Input Class Initialized
INFO - 2024-12-03 15:13:15 --> Language Class Initialized
INFO - 2024-12-03 15:13:15 --> Language Class Initialized
INFO - 2024-12-03 15:13:15 --> Config Class Initialized
INFO - 2024-12-03 15:13:15 --> Loader Class Initialized
INFO - 2024-12-03 15:13:15 --> Helper loaded: url_helper
INFO - 2024-12-03 15:13:15 --> Helper loaded: file_helper
INFO - 2024-12-03 15:13:15 --> Helper loaded: form_helper
INFO - 2024-12-03 15:13:15 --> Helper loaded: my_helper
INFO - 2024-12-03 15:13:15 --> Database Driver Class Initialized
INFO - 2024-12-03 15:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:13:15 --> Controller Class Initialized
INFO - 2024-12-03 15:13:15 --> Final output sent to browser
DEBUG - 2024-12-03 15:13:15 --> Total execution time: 0.0631
INFO - 2024-12-03 15:13:22 --> Config Class Initialized
INFO - 2024-12-03 15:13:22 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:13:22 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:13:22 --> Utf8 Class Initialized
INFO - 2024-12-03 15:13:22 --> URI Class Initialized
INFO - 2024-12-03 15:13:22 --> Router Class Initialized
INFO - 2024-12-03 15:13:22 --> Output Class Initialized
INFO - 2024-12-03 15:13:22 --> Security Class Initialized
DEBUG - 2024-12-03 15:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:13:22 --> Input Class Initialized
INFO - 2024-12-03 15:13:22 --> Language Class Initialized
INFO - 2024-12-03 15:13:22 --> Language Class Initialized
INFO - 2024-12-03 15:13:22 --> Config Class Initialized
INFO - 2024-12-03 15:13:22 --> Loader Class Initialized
INFO - 2024-12-03 15:13:22 --> Helper loaded: url_helper
INFO - 2024-12-03 15:13:22 --> Helper loaded: file_helper
INFO - 2024-12-03 15:13:22 --> Helper loaded: form_helper
INFO - 2024-12-03 15:13:22 --> Helper loaded: my_helper
INFO - 2024-12-03 15:13:22 --> Database Driver Class Initialized
INFO - 2024-12-03 15:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:13:22 --> Controller Class Initialized
INFO - 2024-12-03 15:13:23 --> Final output sent to browser
DEBUG - 2024-12-03 15:13:23 --> Total execution time: 0.6687
INFO - 2024-12-03 15:14:18 --> Config Class Initialized
INFO - 2024-12-03 15:14:18 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:14:18 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:14:18 --> Utf8 Class Initialized
INFO - 2024-12-03 15:14:18 --> URI Class Initialized
INFO - 2024-12-03 15:14:18 --> Router Class Initialized
INFO - 2024-12-03 15:14:18 --> Output Class Initialized
INFO - 2024-12-03 15:14:18 --> Security Class Initialized
DEBUG - 2024-12-03 15:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:14:18 --> Input Class Initialized
INFO - 2024-12-03 15:14:18 --> Language Class Initialized
INFO - 2024-12-03 15:14:18 --> Language Class Initialized
INFO - 2024-12-03 15:14:18 --> Config Class Initialized
INFO - 2024-12-03 15:14:18 --> Loader Class Initialized
INFO - 2024-12-03 15:14:18 --> Helper loaded: url_helper
INFO - 2024-12-03 15:14:18 --> Helper loaded: file_helper
INFO - 2024-12-03 15:14:18 --> Helper loaded: form_helper
INFO - 2024-12-03 15:14:18 --> Helper loaded: my_helper
INFO - 2024-12-03 15:14:18 --> Database Driver Class Initialized
INFO - 2024-12-03 15:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:14:18 --> Controller Class Initialized
INFO - 2024-12-03 15:14:18 --> Final output sent to browser
DEBUG - 2024-12-03 15:14:18 --> Total execution time: 0.2586
INFO - 2024-12-03 15:14:21 --> Config Class Initialized
INFO - 2024-12-03 15:14:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:14:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:14:21 --> Utf8 Class Initialized
INFO - 2024-12-03 15:14:21 --> URI Class Initialized
INFO - 2024-12-03 15:14:21 --> Router Class Initialized
INFO - 2024-12-03 15:14:21 --> Output Class Initialized
INFO - 2024-12-03 15:14:21 --> Security Class Initialized
DEBUG - 2024-12-03 15:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:14:21 --> Input Class Initialized
INFO - 2024-12-03 15:14:21 --> Language Class Initialized
INFO - 2024-12-03 15:14:21 --> Language Class Initialized
INFO - 2024-12-03 15:14:21 --> Config Class Initialized
INFO - 2024-12-03 15:14:21 --> Loader Class Initialized
INFO - 2024-12-03 15:14:21 --> Helper loaded: url_helper
INFO - 2024-12-03 15:14:21 --> Helper loaded: file_helper
INFO - 2024-12-03 15:14:21 --> Helper loaded: form_helper
INFO - 2024-12-03 15:14:21 --> Helper loaded: my_helper
INFO - 2024-12-03 15:14:21 --> Database Driver Class Initialized
INFO - 2024-12-03 15:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:14:21 --> Controller Class Initialized
INFO - 2024-12-03 15:14:21 --> Final output sent to browser
DEBUG - 2024-12-03 15:14:21 --> Total execution time: 0.0944
INFO - 2024-12-03 15:14:49 --> Config Class Initialized
INFO - 2024-12-03 15:14:49 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:14:49 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:14:49 --> Utf8 Class Initialized
INFO - 2024-12-03 15:14:49 --> URI Class Initialized
INFO - 2024-12-03 15:14:49 --> Router Class Initialized
INFO - 2024-12-03 15:14:49 --> Output Class Initialized
INFO - 2024-12-03 15:14:49 --> Security Class Initialized
DEBUG - 2024-12-03 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:14:49 --> Input Class Initialized
INFO - 2024-12-03 15:14:49 --> Language Class Initialized
INFO - 2024-12-03 15:14:49 --> Language Class Initialized
INFO - 2024-12-03 15:14:49 --> Config Class Initialized
INFO - 2024-12-03 15:14:49 --> Loader Class Initialized
INFO - 2024-12-03 15:14:49 --> Helper loaded: url_helper
INFO - 2024-12-03 15:14:49 --> Helper loaded: file_helper
INFO - 2024-12-03 15:14:49 --> Helper loaded: form_helper
INFO - 2024-12-03 15:14:49 --> Helper loaded: my_helper
INFO - 2024-12-03 15:14:49 --> Database Driver Class Initialized
INFO - 2024-12-03 15:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:14:49 --> Controller Class Initialized
INFO - 2024-12-03 15:14:49 --> Final output sent to browser
DEBUG - 2024-12-03 15:14:49 --> Total execution time: 0.1611
INFO - 2024-12-03 15:15:03 --> Config Class Initialized
INFO - 2024-12-03 15:15:03 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:03 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:03 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:03 --> URI Class Initialized
DEBUG - 2024-12-03 15:15:03 --> No URI present. Default controller set.
INFO - 2024-12-03 15:15:03 --> Router Class Initialized
INFO - 2024-12-03 15:15:03 --> Output Class Initialized
INFO - 2024-12-03 15:15:03 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:03 --> Input Class Initialized
INFO - 2024-12-03 15:15:03 --> Language Class Initialized
INFO - 2024-12-03 15:15:03 --> Language Class Initialized
INFO - 2024-12-03 15:15:03 --> Config Class Initialized
INFO - 2024-12-03 15:15:03 --> Loader Class Initialized
INFO - 2024-12-03 15:15:03 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:03 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:03 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:03 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:03 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:03 --> Controller Class Initialized
DEBUG - 2024-12-03 15:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-12-03 15:15:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 15:15:03 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:03 --> Total execution time: 0.1670
INFO - 2024-12-03 15:15:05 --> Config Class Initialized
INFO - 2024-12-03 15:15:05 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:05 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:05 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:05 --> URI Class Initialized
INFO - 2024-12-03 15:15:05 --> Router Class Initialized
INFO - 2024-12-03 15:15:05 --> Output Class Initialized
INFO - 2024-12-03 15:15:05 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:05 --> Input Class Initialized
INFO - 2024-12-03 15:15:05 --> Language Class Initialized
INFO - 2024-12-03 15:15:05 --> Language Class Initialized
INFO - 2024-12-03 15:15:05 --> Config Class Initialized
INFO - 2024-12-03 15:15:05 --> Loader Class Initialized
INFO - 2024-12-03 15:15:05 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:05 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:05 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:05 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:05 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:05 --> Controller Class Initialized
DEBUG - 2024-12-03 15:15:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-03 15:15:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 15:15:05 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:05 --> Total execution time: 0.0825
INFO - 2024-12-03 15:15:08 --> Config Class Initialized
INFO - 2024-12-03 15:15:08 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:08 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:08 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:08 --> URI Class Initialized
INFO - 2024-12-03 15:15:08 --> Router Class Initialized
INFO - 2024-12-03 15:15:08 --> Output Class Initialized
INFO - 2024-12-03 15:15:08 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:08 --> Input Class Initialized
INFO - 2024-12-03 15:15:08 --> Language Class Initialized
INFO - 2024-12-03 15:15:08 --> Language Class Initialized
INFO - 2024-12-03 15:15:08 --> Config Class Initialized
INFO - 2024-12-03 15:15:08 --> Loader Class Initialized
INFO - 2024-12-03 15:15:08 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:08 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:08 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:08 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:08 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:08 --> Controller Class Initialized
DEBUG - 2024-12-03 15:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-12-03 15:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 15:15:08 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:08 --> Total execution time: 0.1186
INFO - 2024-12-03 15:15:09 --> Config Class Initialized
INFO - 2024-12-03 15:15:09 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:09 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:09 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:09 --> URI Class Initialized
INFO - 2024-12-03 15:15:09 --> Router Class Initialized
INFO - 2024-12-03 15:15:09 --> Output Class Initialized
INFO - 2024-12-03 15:15:09 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:09 --> Input Class Initialized
INFO - 2024-12-03 15:15:09 --> Language Class Initialized
INFO - 2024-12-03 15:15:09 --> Language Class Initialized
INFO - 2024-12-03 15:15:09 --> Config Class Initialized
INFO - 2024-12-03 15:15:09 --> Loader Class Initialized
INFO - 2024-12-03 15:15:09 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:09 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:09 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:09 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:09 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:09 --> Controller Class Initialized
INFO - 2024-12-03 15:15:17 --> Config Class Initialized
INFO - 2024-12-03 15:15:17 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:17 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:17 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:17 --> URI Class Initialized
INFO - 2024-12-03 15:15:17 --> Router Class Initialized
INFO - 2024-12-03 15:15:17 --> Output Class Initialized
INFO - 2024-12-03 15:15:17 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:17 --> Input Class Initialized
INFO - 2024-12-03 15:15:17 --> Language Class Initialized
INFO - 2024-12-03 15:15:17 --> Language Class Initialized
INFO - 2024-12-03 15:15:17 --> Config Class Initialized
INFO - 2024-12-03 15:15:17 --> Loader Class Initialized
INFO - 2024-12-03 15:15:17 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:17 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:17 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:17 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:17 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:17 --> Controller Class Initialized
INFO - 2024-12-03 15:15:17 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:17 --> Total execution time: 0.0405
INFO - 2024-12-03 15:15:45 --> Config Class Initialized
INFO - 2024-12-03 15:15:45 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:45 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:45 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:45 --> URI Class Initialized
INFO - 2024-12-03 15:15:45 --> Router Class Initialized
INFO - 2024-12-03 15:15:45 --> Output Class Initialized
INFO - 2024-12-03 15:15:45 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:45 --> Input Class Initialized
INFO - 2024-12-03 15:15:45 --> Language Class Initialized
INFO - 2024-12-03 15:15:45 --> Language Class Initialized
INFO - 2024-12-03 15:15:45 --> Config Class Initialized
INFO - 2024-12-03 15:15:45 --> Loader Class Initialized
INFO - 2024-12-03 15:15:45 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:45 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:45 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:45 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:45 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:45 --> Controller Class Initialized
INFO - 2024-12-03 15:15:45 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:45 --> Total execution time: 0.2428
INFO - 2024-12-03 15:15:48 --> Config Class Initialized
INFO - 2024-12-03 15:15:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:15:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:15:48 --> Utf8 Class Initialized
INFO - 2024-12-03 15:15:48 --> URI Class Initialized
INFO - 2024-12-03 15:15:48 --> Router Class Initialized
INFO - 2024-12-03 15:15:48 --> Output Class Initialized
INFO - 2024-12-03 15:15:48 --> Security Class Initialized
DEBUG - 2024-12-03 15:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:15:48 --> Input Class Initialized
INFO - 2024-12-03 15:15:48 --> Language Class Initialized
INFO - 2024-12-03 15:15:48 --> Language Class Initialized
INFO - 2024-12-03 15:15:48 --> Config Class Initialized
INFO - 2024-12-03 15:15:48 --> Loader Class Initialized
INFO - 2024-12-03 15:15:48 --> Helper loaded: url_helper
INFO - 2024-12-03 15:15:48 --> Helper loaded: file_helper
INFO - 2024-12-03 15:15:48 --> Helper loaded: form_helper
INFO - 2024-12-03 15:15:48 --> Helper loaded: my_helper
INFO - 2024-12-03 15:15:48 --> Database Driver Class Initialized
INFO - 2024-12-03 15:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:15:48 --> Controller Class Initialized
INFO - 2024-12-03 15:15:48 --> Final output sent to browser
DEBUG - 2024-12-03 15:15:48 --> Total execution time: 0.2426
INFO - 2024-12-03 15:16:44 --> Config Class Initialized
INFO - 2024-12-03 15:16:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:16:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:16:44 --> Utf8 Class Initialized
INFO - 2024-12-03 15:16:44 --> URI Class Initialized
INFO - 2024-12-03 15:16:44 --> Router Class Initialized
INFO - 2024-12-03 15:16:44 --> Output Class Initialized
INFO - 2024-12-03 15:16:44 --> Security Class Initialized
DEBUG - 2024-12-03 15:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:16:44 --> Input Class Initialized
INFO - 2024-12-03 15:16:44 --> Language Class Initialized
INFO - 2024-12-03 15:16:44 --> Language Class Initialized
INFO - 2024-12-03 15:16:44 --> Config Class Initialized
INFO - 2024-12-03 15:16:44 --> Loader Class Initialized
INFO - 2024-12-03 15:16:44 --> Helper loaded: url_helper
INFO - 2024-12-03 15:16:44 --> Helper loaded: file_helper
INFO - 2024-12-03 15:16:44 --> Helper loaded: form_helper
INFO - 2024-12-03 15:16:44 --> Helper loaded: my_helper
INFO - 2024-12-03 15:16:45 --> Database Driver Class Initialized
INFO - 2024-12-03 15:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:16:45 --> Controller Class Initialized
INFO - 2024-12-03 15:16:45 --> Final output sent to browser
DEBUG - 2024-12-03 15:16:45 --> Total execution time: 0.5964
INFO - 2024-12-03 15:16:48 --> Config Class Initialized
INFO - 2024-12-03 15:16:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:16:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:16:48 --> Utf8 Class Initialized
INFO - 2024-12-03 15:16:48 --> URI Class Initialized
INFO - 2024-12-03 15:16:48 --> Router Class Initialized
INFO - 2024-12-03 15:16:48 --> Output Class Initialized
INFO - 2024-12-03 15:16:48 --> Security Class Initialized
DEBUG - 2024-12-03 15:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:16:48 --> Input Class Initialized
INFO - 2024-12-03 15:16:48 --> Language Class Initialized
INFO - 2024-12-03 15:16:48 --> Language Class Initialized
INFO - 2024-12-03 15:16:48 --> Config Class Initialized
INFO - 2024-12-03 15:16:48 --> Loader Class Initialized
INFO - 2024-12-03 15:16:48 --> Helper loaded: url_helper
INFO - 2024-12-03 15:16:48 --> Helper loaded: file_helper
INFO - 2024-12-03 15:16:48 --> Helper loaded: form_helper
INFO - 2024-12-03 15:16:48 --> Helper loaded: my_helper
INFO - 2024-12-03 15:16:48 --> Database Driver Class Initialized
INFO - 2024-12-03 15:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:16:48 --> Controller Class Initialized
INFO - 2024-12-03 15:16:48 --> Final output sent to browser
DEBUG - 2024-12-03 15:16:48 --> Total execution time: 0.1678
INFO - 2024-12-03 15:17:21 --> Config Class Initialized
INFO - 2024-12-03 15:17:21 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:21 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:21 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:21 --> URI Class Initialized
INFO - 2024-12-03 15:17:21 --> Router Class Initialized
INFO - 2024-12-03 15:17:21 --> Output Class Initialized
INFO - 2024-12-03 15:17:21 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:21 --> Input Class Initialized
INFO - 2024-12-03 15:17:21 --> Language Class Initialized
INFO - 2024-12-03 15:17:21 --> Language Class Initialized
INFO - 2024-12-03 15:17:21 --> Config Class Initialized
INFO - 2024-12-03 15:17:21 --> Loader Class Initialized
INFO - 2024-12-03 15:17:21 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:21 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:21 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:21 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:21 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:21 --> Controller Class Initialized
INFO - 2024-12-03 15:17:22 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:22 --> Total execution time: 0.2967
INFO - 2024-12-03 15:17:25 --> Config Class Initialized
INFO - 2024-12-03 15:17:25 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:25 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:25 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:25 --> URI Class Initialized
INFO - 2024-12-03 15:17:25 --> Router Class Initialized
INFO - 2024-12-03 15:17:25 --> Output Class Initialized
INFO - 2024-12-03 15:17:25 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:25 --> Input Class Initialized
INFO - 2024-12-03 15:17:25 --> Language Class Initialized
INFO - 2024-12-03 15:17:25 --> Language Class Initialized
INFO - 2024-12-03 15:17:25 --> Config Class Initialized
INFO - 2024-12-03 15:17:25 --> Loader Class Initialized
INFO - 2024-12-03 15:17:25 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:25 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:25 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:25 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:25 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:25 --> Controller Class Initialized
INFO - 2024-12-03 15:17:25 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:25 --> Total execution time: 0.0438
INFO - 2024-12-03 15:17:27 --> Config Class Initialized
INFO - 2024-12-03 15:17:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:27 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:27 --> URI Class Initialized
INFO - 2024-12-03 15:17:27 --> Router Class Initialized
INFO - 2024-12-03 15:17:27 --> Output Class Initialized
INFO - 2024-12-03 15:17:27 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:27 --> Input Class Initialized
INFO - 2024-12-03 15:17:27 --> Language Class Initialized
INFO - 2024-12-03 15:17:27 --> Language Class Initialized
INFO - 2024-12-03 15:17:27 --> Config Class Initialized
INFO - 2024-12-03 15:17:27 --> Loader Class Initialized
INFO - 2024-12-03 15:17:27 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:27 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:27 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:27 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:27 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:27 --> Controller Class Initialized
INFO - 2024-12-03 15:17:28 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:28 --> Total execution time: 0.1653
INFO - 2024-12-03 15:17:44 --> Config Class Initialized
INFO - 2024-12-03 15:17:44 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:44 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:44 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:44 --> URI Class Initialized
INFO - 2024-12-03 15:17:44 --> Router Class Initialized
INFO - 2024-12-03 15:17:44 --> Output Class Initialized
INFO - 2024-12-03 15:17:44 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:44 --> Input Class Initialized
INFO - 2024-12-03 15:17:44 --> Language Class Initialized
INFO - 2024-12-03 15:17:44 --> Language Class Initialized
INFO - 2024-12-03 15:17:44 --> Config Class Initialized
INFO - 2024-12-03 15:17:44 --> Loader Class Initialized
INFO - 2024-12-03 15:17:44 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:44 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:44 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:44 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:44 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:44 --> Controller Class Initialized
INFO - 2024-12-03 15:17:45 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:45 --> Total execution time: 0.1835
INFO - 2024-12-03 15:17:48 --> Config Class Initialized
INFO - 2024-12-03 15:17:48 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:48 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:48 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:48 --> URI Class Initialized
INFO - 2024-12-03 15:17:48 --> Router Class Initialized
INFO - 2024-12-03 15:17:48 --> Output Class Initialized
INFO - 2024-12-03 15:17:48 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:48 --> Input Class Initialized
INFO - 2024-12-03 15:17:48 --> Language Class Initialized
INFO - 2024-12-03 15:17:48 --> Language Class Initialized
INFO - 2024-12-03 15:17:48 --> Config Class Initialized
INFO - 2024-12-03 15:17:48 --> Loader Class Initialized
INFO - 2024-12-03 15:17:48 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:48 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:48 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:48 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:48 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:48 --> Controller Class Initialized
INFO - 2024-12-03 15:17:48 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:48 --> Total execution time: 0.1050
INFO - 2024-12-03 15:17:51 --> Config Class Initialized
INFO - 2024-12-03 15:17:51 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:17:51 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:17:51 --> Utf8 Class Initialized
INFO - 2024-12-03 15:17:51 --> URI Class Initialized
INFO - 2024-12-03 15:17:51 --> Router Class Initialized
INFO - 2024-12-03 15:17:51 --> Output Class Initialized
INFO - 2024-12-03 15:17:51 --> Security Class Initialized
DEBUG - 2024-12-03 15:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:17:51 --> Input Class Initialized
INFO - 2024-12-03 15:17:51 --> Language Class Initialized
INFO - 2024-12-03 15:17:51 --> Language Class Initialized
INFO - 2024-12-03 15:17:51 --> Config Class Initialized
INFO - 2024-12-03 15:17:51 --> Loader Class Initialized
INFO - 2024-12-03 15:17:51 --> Helper loaded: url_helper
INFO - 2024-12-03 15:17:51 --> Helper loaded: file_helper
INFO - 2024-12-03 15:17:51 --> Helper loaded: form_helper
INFO - 2024-12-03 15:17:51 --> Helper loaded: my_helper
INFO - 2024-12-03 15:17:51 --> Database Driver Class Initialized
INFO - 2024-12-03 15:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:17:51 --> Controller Class Initialized
INFO - 2024-12-03 15:17:51 --> Final output sent to browser
DEBUG - 2024-12-03 15:17:51 --> Total execution time: 0.0332
INFO - 2024-12-03 15:19:33 --> Config Class Initialized
INFO - 2024-12-03 15:19:33 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:19:33 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:19:33 --> Utf8 Class Initialized
INFO - 2024-12-03 15:19:33 --> URI Class Initialized
INFO - 2024-12-03 15:19:33 --> Router Class Initialized
INFO - 2024-12-03 15:19:33 --> Output Class Initialized
INFO - 2024-12-03 15:19:33 --> Security Class Initialized
DEBUG - 2024-12-03 15:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:19:33 --> Input Class Initialized
INFO - 2024-12-03 15:19:33 --> Language Class Initialized
INFO - 2024-12-03 15:19:33 --> Language Class Initialized
INFO - 2024-12-03 15:19:33 --> Config Class Initialized
INFO - 2024-12-03 15:19:33 --> Loader Class Initialized
INFO - 2024-12-03 15:19:33 --> Helper loaded: url_helper
INFO - 2024-12-03 15:19:33 --> Helper loaded: file_helper
INFO - 2024-12-03 15:19:33 --> Helper loaded: form_helper
INFO - 2024-12-03 15:19:33 --> Helper loaded: my_helper
INFO - 2024-12-03 15:19:33 --> Database Driver Class Initialized
INFO - 2024-12-03 15:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:19:33 --> Controller Class Initialized
INFO - 2024-12-03 15:19:33 --> Final output sent to browser
DEBUG - 2024-12-03 15:19:33 --> Total execution time: 0.4496
INFO - 2024-12-03 15:19:36 --> Config Class Initialized
INFO - 2024-12-03 15:19:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:19:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:19:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:19:36 --> URI Class Initialized
INFO - 2024-12-03 15:19:36 --> Router Class Initialized
INFO - 2024-12-03 15:19:36 --> Output Class Initialized
INFO - 2024-12-03 15:19:36 --> Security Class Initialized
DEBUG - 2024-12-03 15:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:19:36 --> Input Class Initialized
INFO - 2024-12-03 15:19:36 --> Language Class Initialized
INFO - 2024-12-03 15:19:36 --> Language Class Initialized
INFO - 2024-12-03 15:19:36 --> Config Class Initialized
INFO - 2024-12-03 15:19:36 --> Loader Class Initialized
INFO - 2024-12-03 15:19:36 --> Helper loaded: url_helper
INFO - 2024-12-03 15:19:36 --> Helper loaded: file_helper
INFO - 2024-12-03 15:19:36 --> Helper loaded: form_helper
INFO - 2024-12-03 15:19:36 --> Helper loaded: my_helper
INFO - 2024-12-03 15:19:36 --> Database Driver Class Initialized
INFO - 2024-12-03 15:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:19:36 --> Controller Class Initialized
INFO - 2024-12-03 15:19:36 --> Final output sent to browser
DEBUG - 2024-12-03 15:19:36 --> Total execution time: 0.2658
INFO - 2024-12-03 15:20:36 --> Config Class Initialized
INFO - 2024-12-03 15:20:36 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:20:36 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:20:36 --> Utf8 Class Initialized
INFO - 2024-12-03 15:20:36 --> URI Class Initialized
INFO - 2024-12-03 15:20:36 --> Router Class Initialized
INFO - 2024-12-03 15:20:36 --> Output Class Initialized
INFO - 2024-12-03 15:20:36 --> Security Class Initialized
DEBUG - 2024-12-03 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:20:36 --> Input Class Initialized
INFO - 2024-12-03 15:20:36 --> Language Class Initialized
INFO - 2024-12-03 15:20:36 --> Language Class Initialized
INFO - 2024-12-03 15:20:36 --> Config Class Initialized
INFO - 2024-12-03 15:20:36 --> Loader Class Initialized
INFO - 2024-12-03 15:20:36 --> Helper loaded: url_helper
INFO - 2024-12-03 15:20:36 --> Helper loaded: file_helper
INFO - 2024-12-03 15:20:36 --> Helper loaded: form_helper
INFO - 2024-12-03 15:20:36 --> Helper loaded: my_helper
INFO - 2024-12-03 15:20:36 --> Database Driver Class Initialized
INFO - 2024-12-03 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:20:36 --> Controller Class Initialized
INFO - 2024-12-03 15:20:36 --> Final output sent to browser
DEBUG - 2024-12-03 15:20:36 --> Total execution time: 0.4117
INFO - 2024-12-03 15:20:40 --> Config Class Initialized
INFO - 2024-12-03 15:20:40 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:20:40 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:20:40 --> Utf8 Class Initialized
INFO - 2024-12-03 15:20:40 --> URI Class Initialized
INFO - 2024-12-03 15:20:40 --> Router Class Initialized
INFO - 2024-12-03 15:20:40 --> Output Class Initialized
INFO - 2024-12-03 15:20:40 --> Security Class Initialized
DEBUG - 2024-12-03 15:20:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:20:40 --> Input Class Initialized
INFO - 2024-12-03 15:20:40 --> Language Class Initialized
INFO - 2024-12-03 15:20:40 --> Language Class Initialized
INFO - 2024-12-03 15:20:40 --> Config Class Initialized
INFO - 2024-12-03 15:20:40 --> Loader Class Initialized
INFO - 2024-12-03 15:20:40 --> Helper loaded: url_helper
INFO - 2024-12-03 15:20:40 --> Helper loaded: file_helper
INFO - 2024-12-03 15:20:40 --> Helper loaded: form_helper
INFO - 2024-12-03 15:20:40 --> Helper loaded: my_helper
INFO - 2024-12-03 15:20:40 --> Database Driver Class Initialized
INFO - 2024-12-03 15:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:20:40 --> Controller Class Initialized
INFO - 2024-12-03 15:20:40 --> Final output sent to browser
DEBUG - 2024-12-03 15:20:40 --> Total execution time: 0.0377
INFO - 2024-12-03 15:20:46 --> Config Class Initialized
INFO - 2024-12-03 15:20:46 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:20:46 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:20:46 --> Utf8 Class Initialized
INFO - 2024-12-03 15:20:46 --> URI Class Initialized
INFO - 2024-12-03 15:20:46 --> Router Class Initialized
INFO - 2024-12-03 15:20:46 --> Output Class Initialized
INFO - 2024-12-03 15:20:46 --> Security Class Initialized
DEBUG - 2024-12-03 15:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:20:46 --> Input Class Initialized
INFO - 2024-12-03 15:20:46 --> Language Class Initialized
INFO - 2024-12-03 15:20:46 --> Language Class Initialized
INFO - 2024-12-03 15:20:46 --> Config Class Initialized
INFO - 2024-12-03 15:20:46 --> Loader Class Initialized
INFO - 2024-12-03 15:20:46 --> Helper loaded: url_helper
INFO - 2024-12-03 15:20:46 --> Helper loaded: file_helper
INFO - 2024-12-03 15:20:46 --> Helper loaded: form_helper
INFO - 2024-12-03 15:20:46 --> Helper loaded: my_helper
INFO - 2024-12-03 15:20:46 --> Database Driver Class Initialized
INFO - 2024-12-03 15:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:20:46 --> Controller Class Initialized
INFO - 2024-12-03 15:20:46 --> Final output sent to browser
DEBUG - 2024-12-03 15:20:46 --> Total execution time: 0.0790
INFO - 2024-12-03 15:21:24 --> Config Class Initialized
INFO - 2024-12-03 15:21:24 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:21:24 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:21:24 --> Utf8 Class Initialized
INFO - 2024-12-03 15:21:24 --> URI Class Initialized
INFO - 2024-12-03 15:21:24 --> Router Class Initialized
INFO - 2024-12-03 15:21:24 --> Output Class Initialized
INFO - 2024-12-03 15:21:24 --> Security Class Initialized
DEBUG - 2024-12-03 15:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:21:24 --> Input Class Initialized
INFO - 2024-12-03 15:21:24 --> Language Class Initialized
INFO - 2024-12-03 15:21:24 --> Language Class Initialized
INFO - 2024-12-03 15:21:24 --> Config Class Initialized
INFO - 2024-12-03 15:21:24 --> Loader Class Initialized
INFO - 2024-12-03 15:21:24 --> Helper loaded: url_helper
INFO - 2024-12-03 15:21:24 --> Helper loaded: file_helper
INFO - 2024-12-03 15:21:24 --> Helper loaded: form_helper
INFO - 2024-12-03 15:21:24 --> Helper loaded: my_helper
INFO - 2024-12-03 15:21:24 --> Database Driver Class Initialized
INFO - 2024-12-03 15:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:21:24 --> Controller Class Initialized
INFO - 2024-12-03 15:21:24 --> Final output sent to browser
DEBUG - 2024-12-03 15:21:24 --> Total execution time: 0.1729
INFO - 2024-12-03 15:21:27 --> Config Class Initialized
INFO - 2024-12-03 15:21:27 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:21:27 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:21:27 --> Utf8 Class Initialized
INFO - 2024-12-03 15:21:28 --> URI Class Initialized
INFO - 2024-12-03 15:21:28 --> Router Class Initialized
INFO - 2024-12-03 15:21:28 --> Output Class Initialized
INFO - 2024-12-03 15:21:28 --> Security Class Initialized
DEBUG - 2024-12-03 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:21:28 --> Input Class Initialized
INFO - 2024-12-03 15:21:28 --> Language Class Initialized
INFO - 2024-12-03 15:21:28 --> Language Class Initialized
INFO - 2024-12-03 15:21:28 --> Config Class Initialized
INFO - 2024-12-03 15:21:28 --> Loader Class Initialized
INFO - 2024-12-03 15:21:28 --> Helper loaded: url_helper
INFO - 2024-12-03 15:21:28 --> Helper loaded: file_helper
INFO - 2024-12-03 15:21:28 --> Helper loaded: form_helper
INFO - 2024-12-03 15:21:28 --> Helper loaded: my_helper
INFO - 2024-12-03 15:21:28 --> Database Driver Class Initialized
INFO - 2024-12-03 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:21:28 --> Controller Class Initialized
INFO - 2024-12-03 15:21:28 --> Final output sent to browser
DEBUG - 2024-12-03 15:21:28 --> Total execution time: 0.0319
INFO - 2024-12-03 15:23:00 --> Config Class Initialized
INFO - 2024-12-03 15:23:00 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:23:00 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:23:00 --> Utf8 Class Initialized
INFO - 2024-12-03 15:23:00 --> URI Class Initialized
INFO - 2024-12-03 15:23:00 --> Router Class Initialized
INFO - 2024-12-03 15:23:00 --> Output Class Initialized
INFO - 2024-12-03 15:23:00 --> Security Class Initialized
DEBUG - 2024-12-03 15:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:23:00 --> Input Class Initialized
INFO - 2024-12-03 15:23:00 --> Language Class Initialized
INFO - 2024-12-03 15:23:00 --> Language Class Initialized
INFO - 2024-12-03 15:23:00 --> Config Class Initialized
INFO - 2024-12-03 15:23:00 --> Loader Class Initialized
INFO - 2024-12-03 15:23:00 --> Helper loaded: url_helper
INFO - 2024-12-03 15:23:00 --> Helper loaded: file_helper
INFO - 2024-12-03 15:23:00 --> Helper loaded: form_helper
INFO - 2024-12-03 15:23:00 --> Helper loaded: my_helper
INFO - 2024-12-03 15:23:01 --> Database Driver Class Initialized
INFO - 2024-12-03 15:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:23:01 --> Controller Class Initialized
INFO - 2024-12-03 15:23:01 --> Final output sent to browser
DEBUG - 2024-12-03 15:23:01 --> Total execution time: 0.7012
INFO - 2024-12-03 15:23:10 --> Config Class Initialized
INFO - 2024-12-03 15:23:10 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:23:10 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:23:10 --> Utf8 Class Initialized
INFO - 2024-12-03 15:23:10 --> URI Class Initialized
INFO - 2024-12-03 15:23:10 --> Router Class Initialized
INFO - 2024-12-03 15:23:10 --> Output Class Initialized
INFO - 2024-12-03 15:23:10 --> Security Class Initialized
DEBUG - 2024-12-03 15:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:23:10 --> Input Class Initialized
INFO - 2024-12-03 15:23:10 --> Language Class Initialized
INFO - 2024-12-03 15:23:10 --> Language Class Initialized
INFO - 2024-12-03 15:23:10 --> Config Class Initialized
INFO - 2024-12-03 15:23:10 --> Loader Class Initialized
INFO - 2024-12-03 15:23:10 --> Helper loaded: url_helper
INFO - 2024-12-03 15:23:10 --> Helper loaded: file_helper
INFO - 2024-12-03 15:23:10 --> Helper loaded: form_helper
INFO - 2024-12-03 15:23:10 --> Helper loaded: my_helper
INFO - 2024-12-03 15:23:10 --> Database Driver Class Initialized
INFO - 2024-12-03 15:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:23:10 --> Controller Class Initialized
DEBUG - 2024-12-03 15:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-12-03 15:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 15:23:10 --> Final output sent to browser
DEBUG - 2024-12-03 15:23:10 --> Total execution time: 0.1075
INFO - 2024-12-03 15:25:37 --> Config Class Initialized
INFO - 2024-12-03 15:25:37 --> Hooks Class Initialized
DEBUG - 2024-12-03 15:25:37 --> UTF-8 Support Enabled
INFO - 2024-12-03 15:25:37 --> Utf8 Class Initialized
INFO - 2024-12-03 15:25:37 --> URI Class Initialized
INFO - 2024-12-03 15:25:37 --> Router Class Initialized
INFO - 2024-12-03 15:25:37 --> Output Class Initialized
INFO - 2024-12-03 15:25:37 --> Security Class Initialized
DEBUG - 2024-12-03 15:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-03 15:25:37 --> Input Class Initialized
INFO - 2024-12-03 15:25:37 --> Language Class Initialized
INFO - 2024-12-03 15:25:37 --> Language Class Initialized
INFO - 2024-12-03 15:25:37 --> Config Class Initialized
INFO - 2024-12-03 15:25:37 --> Loader Class Initialized
INFO - 2024-12-03 15:25:37 --> Helper loaded: url_helper
INFO - 2024-12-03 15:25:37 --> Helper loaded: file_helper
INFO - 2024-12-03 15:25:37 --> Helper loaded: form_helper
INFO - 2024-12-03 15:25:37 --> Helper loaded: my_helper
INFO - 2024-12-03 15:25:37 --> Database Driver Class Initialized
INFO - 2024-12-03 15:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-03 15:25:37 --> Controller Class Initialized
DEBUG - 2024-12-03 15:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-12-03 15:25:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-03 15:25:37 --> Final output sent to browser
DEBUG - 2024-12-03 15:25:37 --> Total execution time: 0.0414
