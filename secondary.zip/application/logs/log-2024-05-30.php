<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-05-30 08:29:28 --> Config Class Initialized
INFO - 2024-05-30 08:29:28 --> Hooks Class Initialized
DEBUG - 2024-05-30 08:29:28 --> UTF-8 Support Enabled
INFO - 2024-05-30 08:29:28 --> Utf8 Class Initialized
INFO - 2024-05-30 08:29:28 --> URI Class Initialized
INFO - 2024-05-30 08:29:28 --> Router Class Initialized
INFO - 2024-05-30 08:29:28 --> Output Class Initialized
INFO - 2024-05-30 08:29:28 --> Security Class Initialized
DEBUG - 2024-05-30 08:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 08:29:28 --> Input Class Initialized
INFO - 2024-05-30 08:29:28 --> Language Class Initialized
INFO - 2024-05-30 08:29:28 --> Language Class Initialized
INFO - 2024-05-30 08:29:28 --> Config Class Initialized
INFO - 2024-05-30 08:29:28 --> Loader Class Initialized
INFO - 2024-05-30 08:29:28 --> Helper loaded: url_helper
INFO - 2024-05-30 08:29:28 --> Helper loaded: file_helper
INFO - 2024-05-30 08:29:28 --> Helper loaded: form_helper
INFO - 2024-05-30 08:29:28 --> Helper loaded: my_helper
INFO - 2024-05-30 08:29:28 --> Database Driver Class Initialized
INFO - 2024-05-30 08:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 08:29:28 --> Controller Class Initialized
DEBUG - 2024-05-30 08:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-30 08:29:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 08:29:28 --> Final output sent to browser
DEBUG - 2024-05-30 08:29:28 --> Total execution time: 0.0698
INFO - 2024-05-30 08:32:58 --> Config Class Initialized
INFO - 2024-05-30 08:32:58 --> Hooks Class Initialized
DEBUG - 2024-05-30 08:32:58 --> UTF-8 Support Enabled
INFO - 2024-05-30 08:32:58 --> Utf8 Class Initialized
INFO - 2024-05-30 08:32:58 --> URI Class Initialized
INFO - 2024-05-30 08:32:58 --> Router Class Initialized
INFO - 2024-05-30 08:32:58 --> Output Class Initialized
INFO - 2024-05-30 08:32:58 --> Security Class Initialized
DEBUG - 2024-05-30 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 08:32:58 --> Input Class Initialized
INFO - 2024-05-30 08:32:58 --> Language Class Initialized
INFO - 2024-05-30 08:32:58 --> Language Class Initialized
INFO - 2024-05-30 08:32:58 --> Config Class Initialized
INFO - 2024-05-30 08:32:58 --> Loader Class Initialized
INFO - 2024-05-30 08:32:58 --> Helper loaded: url_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: file_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: form_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: my_helper
INFO - 2024-05-30 08:32:58 --> Database Driver Class Initialized
INFO - 2024-05-30 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 08:32:58 --> Controller Class Initialized
INFO - 2024-05-30 08:32:58 --> Helper loaded: cookie_helper
INFO - 2024-05-30 08:32:58 --> Final output sent to browser
DEBUG - 2024-05-30 08:32:58 --> Total execution time: 0.0361
INFO - 2024-05-30 08:32:58 --> Config Class Initialized
INFO - 2024-05-30 08:32:58 --> Hooks Class Initialized
DEBUG - 2024-05-30 08:32:58 --> UTF-8 Support Enabled
INFO - 2024-05-30 08:32:58 --> Utf8 Class Initialized
INFO - 2024-05-30 08:32:58 --> URI Class Initialized
INFO - 2024-05-30 08:32:58 --> Router Class Initialized
INFO - 2024-05-30 08:32:58 --> Output Class Initialized
INFO - 2024-05-30 08:32:58 --> Security Class Initialized
DEBUG - 2024-05-30 08:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 08:32:58 --> Input Class Initialized
INFO - 2024-05-30 08:32:58 --> Language Class Initialized
INFO - 2024-05-30 08:32:58 --> Language Class Initialized
INFO - 2024-05-30 08:32:58 --> Config Class Initialized
INFO - 2024-05-30 08:32:58 --> Loader Class Initialized
INFO - 2024-05-30 08:32:58 --> Helper loaded: url_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: file_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: form_helper
INFO - 2024-05-30 08:32:58 --> Helper loaded: my_helper
INFO - 2024-05-30 08:32:58 --> Database Driver Class Initialized
INFO - 2024-05-30 08:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 08:32:58 --> Controller Class Initialized
DEBUG - 2024-05-30 08:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-30 08:32:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 08:32:58 --> Final output sent to browser
DEBUG - 2024-05-30 08:32:58 --> Total execution time: 0.0448
INFO - 2024-05-30 08:36:20 --> Config Class Initialized
INFO - 2024-05-30 08:36:20 --> Hooks Class Initialized
DEBUG - 2024-05-30 08:36:20 --> UTF-8 Support Enabled
INFO - 2024-05-30 08:36:20 --> Utf8 Class Initialized
INFO - 2024-05-30 08:36:20 --> URI Class Initialized
INFO - 2024-05-30 08:36:20 --> Router Class Initialized
INFO - 2024-05-30 08:36:20 --> Output Class Initialized
INFO - 2024-05-30 08:36:20 --> Security Class Initialized
DEBUG - 2024-05-30 08:36:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 08:36:20 --> Input Class Initialized
INFO - 2024-05-30 08:36:20 --> Language Class Initialized
INFO - 2024-05-30 08:36:20 --> Language Class Initialized
INFO - 2024-05-30 08:36:20 --> Config Class Initialized
INFO - 2024-05-30 08:36:20 --> Loader Class Initialized
INFO - 2024-05-30 08:36:20 --> Helper loaded: url_helper
INFO - 2024-05-30 08:36:20 --> Helper loaded: file_helper
INFO - 2024-05-30 08:36:20 --> Helper loaded: form_helper
INFO - 2024-05-30 08:36:20 --> Helper loaded: my_helper
INFO - 2024-05-30 08:36:20 --> Database Driver Class Initialized
INFO - 2024-05-30 08:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 08:36:20 --> Controller Class Initialized
DEBUG - 2024-05-30 08:36:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-30 08:36:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 08:36:20 --> Final output sent to browser
DEBUG - 2024-05-30 08:36:20 --> Total execution time: 0.0483
INFO - 2024-05-30 09:09:58 --> Config Class Initialized
INFO - 2024-05-30 09:09:58 --> Hooks Class Initialized
DEBUG - 2024-05-30 09:09:58 --> UTF-8 Support Enabled
INFO - 2024-05-30 09:09:58 --> Utf8 Class Initialized
INFO - 2024-05-30 09:09:58 --> URI Class Initialized
INFO - 2024-05-30 09:09:58 --> Router Class Initialized
INFO - 2024-05-30 09:09:58 --> Output Class Initialized
INFO - 2024-05-30 09:09:58 --> Security Class Initialized
DEBUG - 2024-05-30 09:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 09:09:58 --> Input Class Initialized
INFO - 2024-05-30 09:09:58 --> Language Class Initialized
INFO - 2024-05-30 09:09:58 --> Language Class Initialized
INFO - 2024-05-30 09:09:58 --> Config Class Initialized
INFO - 2024-05-30 09:09:58 --> Loader Class Initialized
INFO - 2024-05-30 09:09:58 --> Helper loaded: url_helper
INFO - 2024-05-30 09:09:58 --> Helper loaded: file_helper
INFO - 2024-05-30 09:09:58 --> Helper loaded: form_helper
INFO - 2024-05-30 09:09:58 --> Helper loaded: my_helper
INFO - 2024-05-30 09:09:59 --> Database Driver Class Initialized
INFO - 2024-05-30 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 09:09:59 --> Controller Class Initialized
INFO - 2024-05-30 09:09:59 --> Config Class Initialized
INFO - 2024-05-30 09:09:59 --> Hooks Class Initialized
DEBUG - 2024-05-30 09:09:59 --> UTF-8 Support Enabled
INFO - 2024-05-30 09:09:59 --> Utf8 Class Initialized
INFO - 2024-05-30 09:09:59 --> URI Class Initialized
INFO - 2024-05-30 09:09:59 --> Router Class Initialized
INFO - 2024-05-30 09:09:59 --> Output Class Initialized
INFO - 2024-05-30 09:09:59 --> Security Class Initialized
DEBUG - 2024-05-30 09:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 09:09:59 --> Input Class Initialized
INFO - 2024-05-30 09:09:59 --> Language Class Initialized
INFO - 2024-05-30 09:09:59 --> Language Class Initialized
INFO - 2024-05-30 09:09:59 --> Config Class Initialized
INFO - 2024-05-30 09:09:59 --> Loader Class Initialized
INFO - 2024-05-30 09:09:59 --> Helper loaded: url_helper
INFO - 2024-05-30 09:09:59 --> Helper loaded: file_helper
INFO - 2024-05-30 09:09:59 --> Helper loaded: form_helper
INFO - 2024-05-30 09:09:59 --> Helper loaded: my_helper
INFO - 2024-05-30 09:09:59 --> Database Driver Class Initialized
INFO - 2024-05-30 09:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 09:09:59 --> Controller Class Initialized
DEBUG - 2024-05-30 09:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-30 09:09:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 09:09:59 --> Final output sent to browser
DEBUG - 2024-05-30 09:09:59 --> Total execution time: 0.0850
INFO - 2024-05-30 09:49:49 --> Config Class Initialized
INFO - 2024-05-30 09:49:49 --> Hooks Class Initialized
DEBUG - 2024-05-30 09:49:49 --> UTF-8 Support Enabled
INFO - 2024-05-30 09:49:49 --> Utf8 Class Initialized
INFO - 2024-05-30 09:49:49 --> URI Class Initialized
INFO - 2024-05-30 09:49:49 --> Router Class Initialized
INFO - 2024-05-30 09:49:49 --> Output Class Initialized
INFO - 2024-05-30 09:49:49 --> Security Class Initialized
DEBUG - 2024-05-30 09:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 09:49:49 --> Input Class Initialized
INFO - 2024-05-30 09:49:49 --> Language Class Initialized
INFO - 2024-05-30 09:49:49 --> Language Class Initialized
INFO - 2024-05-30 09:49:49 --> Config Class Initialized
INFO - 2024-05-30 09:49:49 --> Loader Class Initialized
INFO - 2024-05-30 09:49:49 --> Helper loaded: url_helper
INFO - 2024-05-30 09:49:49 --> Helper loaded: file_helper
INFO - 2024-05-30 09:49:49 --> Helper loaded: form_helper
INFO - 2024-05-30 09:49:49 --> Helper loaded: my_helper
INFO - 2024-05-30 09:49:49 --> Database Driver Class Initialized
INFO - 2024-05-30 09:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 09:49:49 --> Controller Class Initialized
DEBUG - 2024-05-30 09:49:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-05-30 09:49:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 09:49:49 --> Final output sent to browser
DEBUG - 2024-05-30 09:49:49 --> Total execution time: 0.0602
INFO - 2024-05-30 09:49:50 --> Config Class Initialized
INFO - 2024-05-30 09:49:50 --> Hooks Class Initialized
DEBUG - 2024-05-30 09:49:50 --> UTF-8 Support Enabled
INFO - 2024-05-30 09:49:50 --> Utf8 Class Initialized
INFO - 2024-05-30 09:49:50 --> URI Class Initialized
INFO - 2024-05-30 09:49:50 --> Router Class Initialized
INFO - 2024-05-30 09:49:50 --> Output Class Initialized
INFO - 2024-05-30 09:49:50 --> Security Class Initialized
DEBUG - 2024-05-30 09:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 09:49:50 --> Input Class Initialized
INFO - 2024-05-30 09:49:50 --> Language Class Initialized
ERROR - 2024-05-30 09:49:50 --> 404 Page Not Found: /index
INFO - 2024-05-30 09:49:50 --> Config Class Initialized
INFO - 2024-05-30 09:49:50 --> Hooks Class Initialized
DEBUG - 2024-05-30 09:49:50 --> UTF-8 Support Enabled
INFO - 2024-05-30 09:49:50 --> Utf8 Class Initialized
INFO - 2024-05-30 09:49:50 --> URI Class Initialized
INFO - 2024-05-30 09:49:50 --> Router Class Initialized
INFO - 2024-05-30 09:49:50 --> Output Class Initialized
INFO - 2024-05-30 09:49:50 --> Security Class Initialized
DEBUG - 2024-05-30 09:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 09:49:50 --> Input Class Initialized
INFO - 2024-05-30 09:49:50 --> Language Class Initialized
INFO - 2024-05-30 09:49:50 --> Language Class Initialized
INFO - 2024-05-30 09:49:50 --> Config Class Initialized
INFO - 2024-05-30 09:49:50 --> Loader Class Initialized
INFO - 2024-05-30 09:49:50 --> Helper loaded: url_helper
INFO - 2024-05-30 09:49:50 --> Helper loaded: file_helper
INFO - 2024-05-30 09:49:50 --> Helper loaded: form_helper
INFO - 2024-05-30 09:49:50 --> Helper loaded: my_helper
INFO - 2024-05-30 09:49:50 --> Database Driver Class Initialized
INFO - 2024-05-30 09:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 09:49:50 --> Controller Class Initialized
INFO - 2024-05-30 10:11:18 --> Config Class Initialized
INFO - 2024-05-30 10:11:18 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:11:18 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:11:18 --> Utf8 Class Initialized
INFO - 2024-05-30 10:11:18 --> URI Class Initialized
INFO - 2024-05-30 10:11:18 --> Router Class Initialized
INFO - 2024-05-30 10:11:18 --> Output Class Initialized
INFO - 2024-05-30 10:11:18 --> Security Class Initialized
DEBUG - 2024-05-30 10:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:11:18 --> Input Class Initialized
INFO - 2024-05-30 10:11:18 --> Language Class Initialized
INFO - 2024-05-30 10:11:18 --> Language Class Initialized
INFO - 2024-05-30 10:11:18 --> Config Class Initialized
INFO - 2024-05-30 10:11:18 --> Loader Class Initialized
INFO - 2024-05-30 10:11:18 --> Helper loaded: url_helper
INFO - 2024-05-30 10:11:18 --> Helper loaded: file_helper
INFO - 2024-05-30 10:11:18 --> Helper loaded: form_helper
INFO - 2024-05-30 10:11:18 --> Helper loaded: my_helper
INFO - 2024-05-30 10:11:18 --> Database Driver Class Initialized
INFO - 2024-05-30 10:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 10:11:18 --> Controller Class Initialized
DEBUG - 2024-05-30 10:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-30 10:11:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 10:11:18 --> Final output sent to browser
DEBUG - 2024-05-30 10:11:18 --> Total execution time: 0.0512
INFO - 2024-05-30 10:16:40 --> Config Class Initialized
INFO - 2024-05-30 10:16:40 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:40 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:40 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:40 --> URI Class Initialized
INFO - 2024-05-30 10:16:40 --> Router Class Initialized
INFO - 2024-05-30 10:16:40 --> Output Class Initialized
INFO - 2024-05-30 10:16:40 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:40 --> Input Class Initialized
INFO - 2024-05-30 10:16:40 --> Language Class Initialized
INFO - 2024-05-30 10:16:40 --> Language Class Initialized
INFO - 2024-05-30 10:16:40 --> Config Class Initialized
INFO - 2024-05-30 10:16:40 --> Loader Class Initialized
INFO - 2024-05-30 10:16:40 --> Helper loaded: url_helper
INFO - 2024-05-30 10:16:40 --> Helper loaded: file_helper
INFO - 2024-05-30 10:16:40 --> Helper loaded: form_helper
INFO - 2024-05-30 10:16:40 --> Helper loaded: my_helper
INFO - 2024-05-30 10:16:40 --> Database Driver Class Initialized
INFO - 2024-05-30 10:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 10:16:40 --> Controller Class Initialized
DEBUG - 2024-05-30 10:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2024-05-30 10:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 10:16:40 --> Final output sent to browser
DEBUG - 2024-05-30 10:16:40 --> Total execution time: 0.0590
INFO - 2024-05-30 10:16:41 --> Config Class Initialized
INFO - 2024-05-30 10:16:41 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:41 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:41 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:41 --> URI Class Initialized
INFO - 2024-05-30 10:16:41 --> Router Class Initialized
INFO - 2024-05-30 10:16:41 --> Output Class Initialized
INFO - 2024-05-30 10:16:41 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:41 --> Input Class Initialized
INFO - 2024-05-30 10:16:41 --> Language Class Initialized
ERROR - 2024-05-30 10:16:41 --> 404 Page Not Found: /index
INFO - 2024-05-30 10:16:41 --> Config Class Initialized
INFO - 2024-05-30 10:16:41 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:41 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:41 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:41 --> URI Class Initialized
INFO - 2024-05-30 10:16:41 --> Router Class Initialized
INFO - 2024-05-30 10:16:41 --> Output Class Initialized
INFO - 2024-05-30 10:16:41 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:41 --> Input Class Initialized
INFO - 2024-05-30 10:16:41 --> Language Class Initialized
INFO - 2024-05-30 10:16:41 --> Language Class Initialized
INFO - 2024-05-30 10:16:41 --> Config Class Initialized
INFO - 2024-05-30 10:16:41 --> Loader Class Initialized
INFO - 2024-05-30 10:16:41 --> Helper loaded: url_helper
INFO - 2024-05-30 10:16:41 --> Helper loaded: file_helper
INFO - 2024-05-30 10:16:41 --> Helper loaded: form_helper
INFO - 2024-05-30 10:16:41 --> Helper loaded: my_helper
INFO - 2024-05-30 10:16:41 --> Database Driver Class Initialized
INFO - 2024-05-30 10:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 10:16:41 --> Controller Class Initialized
INFO - 2024-05-30 10:16:58 --> Config Class Initialized
INFO - 2024-05-30 10:16:58 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:58 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:58 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:58 --> URI Class Initialized
INFO - 2024-05-30 10:16:58 --> Router Class Initialized
INFO - 2024-05-30 10:16:58 --> Output Class Initialized
INFO - 2024-05-30 10:16:58 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:58 --> Input Class Initialized
INFO - 2024-05-30 10:16:58 --> Language Class Initialized
INFO - 2024-05-30 10:16:58 --> Language Class Initialized
INFO - 2024-05-30 10:16:58 --> Config Class Initialized
INFO - 2024-05-30 10:16:58 --> Loader Class Initialized
INFO - 2024-05-30 10:16:58 --> Helper loaded: url_helper
INFO - 2024-05-30 10:16:58 --> Helper loaded: file_helper
INFO - 2024-05-30 10:16:58 --> Helper loaded: form_helper
INFO - 2024-05-30 10:16:58 --> Helper loaded: my_helper
INFO - 2024-05-30 10:16:58 --> Database Driver Class Initialized
INFO - 2024-05-30 10:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 10:16:58 --> Controller Class Initialized
DEBUG - 2024-05-30 10:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-05-30 10:16:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 10:16:58 --> Final output sent to browser
DEBUG - 2024-05-30 10:16:58 --> Total execution time: 0.0294
INFO - 2024-05-30 10:16:58 --> Config Class Initialized
INFO - 2024-05-30 10:16:58 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:58 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:58 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:58 --> URI Class Initialized
INFO - 2024-05-30 10:16:59 --> Router Class Initialized
INFO - 2024-05-30 10:16:59 --> Output Class Initialized
INFO - 2024-05-30 10:16:59 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:59 --> Input Class Initialized
INFO - 2024-05-30 10:16:59 --> Language Class Initialized
ERROR - 2024-05-30 10:16:59 --> 404 Page Not Found: /index
INFO - 2024-05-30 10:16:59 --> Config Class Initialized
INFO - 2024-05-30 10:16:59 --> Hooks Class Initialized
DEBUG - 2024-05-30 10:16:59 --> UTF-8 Support Enabled
INFO - 2024-05-30 10:16:59 --> Utf8 Class Initialized
INFO - 2024-05-30 10:16:59 --> URI Class Initialized
INFO - 2024-05-30 10:16:59 --> Router Class Initialized
INFO - 2024-05-30 10:16:59 --> Output Class Initialized
INFO - 2024-05-30 10:16:59 --> Security Class Initialized
DEBUG - 2024-05-30 10:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 10:16:59 --> Input Class Initialized
INFO - 2024-05-30 10:16:59 --> Language Class Initialized
INFO - 2024-05-30 10:16:59 --> Language Class Initialized
INFO - 2024-05-30 10:16:59 --> Config Class Initialized
INFO - 2024-05-30 10:16:59 --> Loader Class Initialized
INFO - 2024-05-30 10:16:59 --> Helper loaded: url_helper
INFO - 2024-05-30 10:16:59 --> Helper loaded: file_helper
INFO - 2024-05-30 10:16:59 --> Helper loaded: form_helper
INFO - 2024-05-30 10:16:59 --> Helper loaded: my_helper
INFO - 2024-05-30 10:16:59 --> Database Driver Class Initialized
INFO - 2024-05-30 10:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 10:16:59 --> Controller Class Initialized
INFO - 2024-05-30 14:15:36 --> Config Class Initialized
INFO - 2024-05-30 14:15:36 --> Hooks Class Initialized
DEBUG - 2024-05-30 14:15:36 --> UTF-8 Support Enabled
INFO - 2024-05-30 14:15:36 --> Utf8 Class Initialized
INFO - 2024-05-30 14:15:36 --> URI Class Initialized
INFO - 2024-05-30 14:15:36 --> Router Class Initialized
INFO - 2024-05-30 14:15:36 --> Output Class Initialized
INFO - 2024-05-30 14:15:36 --> Security Class Initialized
DEBUG - 2024-05-30 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 14:15:36 --> Input Class Initialized
INFO - 2024-05-30 14:15:36 --> Language Class Initialized
INFO - 2024-05-30 14:15:36 --> Language Class Initialized
INFO - 2024-05-30 14:15:36 --> Config Class Initialized
INFO - 2024-05-30 14:15:36 --> Loader Class Initialized
INFO - 2024-05-30 14:15:36 --> Helper loaded: url_helper
INFO - 2024-05-30 14:15:36 --> Helper loaded: file_helper
INFO - 2024-05-30 14:15:36 --> Helper loaded: form_helper
INFO - 2024-05-30 14:15:36 --> Helper loaded: my_helper
INFO - 2024-05-30 14:15:36 --> Database Driver Class Initialized
INFO - 2024-05-30 14:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 14:15:36 --> Controller Class Initialized
DEBUG - 2024-05-30 14:15:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2024-05-30 14:15:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 14:15:36 --> Final output sent to browser
DEBUG - 2024-05-30 14:15:36 --> Total execution time: 0.0675
INFO - 2024-05-30 14:15:36 --> Config Class Initialized
INFO - 2024-05-30 14:15:36 --> Hooks Class Initialized
DEBUG - 2024-05-30 14:15:36 --> UTF-8 Support Enabled
INFO - 2024-05-30 14:15:36 --> Utf8 Class Initialized
INFO - 2024-05-30 14:15:36 --> URI Class Initialized
INFO - 2024-05-30 14:15:36 --> Router Class Initialized
INFO - 2024-05-30 14:15:36 --> Output Class Initialized
INFO - 2024-05-30 14:15:36 --> Security Class Initialized
DEBUG - 2024-05-30 14:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 14:15:36 --> Input Class Initialized
INFO - 2024-05-30 14:15:36 --> Language Class Initialized
ERROR - 2024-05-30 14:15:36 --> 404 Page Not Found: /index
INFO - 2024-05-30 14:15:37 --> Config Class Initialized
INFO - 2024-05-30 14:15:37 --> Hooks Class Initialized
DEBUG - 2024-05-30 14:15:37 --> UTF-8 Support Enabled
INFO - 2024-05-30 14:15:37 --> Utf8 Class Initialized
INFO - 2024-05-30 14:15:37 --> URI Class Initialized
INFO - 2024-05-30 14:15:37 --> Router Class Initialized
INFO - 2024-05-30 14:15:37 --> Output Class Initialized
INFO - 2024-05-30 14:15:37 --> Security Class Initialized
DEBUG - 2024-05-30 14:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 14:15:37 --> Input Class Initialized
INFO - 2024-05-30 14:15:37 --> Language Class Initialized
INFO - 2024-05-30 14:15:37 --> Language Class Initialized
INFO - 2024-05-30 14:15:37 --> Config Class Initialized
INFO - 2024-05-30 14:15:37 --> Loader Class Initialized
INFO - 2024-05-30 14:15:37 --> Helper loaded: url_helper
INFO - 2024-05-30 14:15:37 --> Helper loaded: file_helper
INFO - 2024-05-30 14:15:37 --> Helper loaded: form_helper
INFO - 2024-05-30 14:15:37 --> Helper loaded: my_helper
INFO - 2024-05-30 14:15:37 --> Database Driver Class Initialized
INFO - 2024-05-30 14:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 14:15:37 --> Controller Class Initialized
INFO - 2024-05-30 15:18:24 --> Config Class Initialized
INFO - 2024-05-30 15:18:24 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:24 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:24 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:24 --> URI Class Initialized
DEBUG - 2024-05-30 15:18:24 --> No URI present. Default controller set.
INFO - 2024-05-30 15:18:24 --> Router Class Initialized
INFO - 2024-05-30 15:18:24 --> Output Class Initialized
INFO - 2024-05-30 15:18:24 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:24 --> Input Class Initialized
INFO - 2024-05-30 15:18:24 --> Language Class Initialized
INFO - 2024-05-30 15:18:24 --> Language Class Initialized
INFO - 2024-05-30 15:18:24 --> Config Class Initialized
INFO - 2024-05-30 15:18:24 --> Loader Class Initialized
INFO - 2024-05-30 15:18:24 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:24 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:24 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:24 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:24 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:24 --> Controller Class Initialized
INFO - 2024-05-30 15:18:24 --> Config Class Initialized
INFO - 2024-05-30 15:18:24 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:24 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:24 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:24 --> URI Class Initialized
INFO - 2024-05-30 15:18:25 --> Router Class Initialized
INFO - 2024-05-30 15:18:25 --> Output Class Initialized
INFO - 2024-05-30 15:18:25 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:25 --> Input Class Initialized
INFO - 2024-05-30 15:18:25 --> Language Class Initialized
INFO - 2024-05-30 15:18:25 --> Language Class Initialized
INFO - 2024-05-30 15:18:25 --> Config Class Initialized
INFO - 2024-05-30 15:18:25 --> Loader Class Initialized
INFO - 2024-05-30 15:18:25 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:25 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:25 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:25 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:25 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:25 --> Controller Class Initialized
DEBUG - 2024-05-30 15:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-05-30 15:18:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:18:25 --> Final output sent to browser
DEBUG - 2024-05-30 15:18:25 --> Total execution time: 0.0315
INFO - 2024-05-30 15:18:28 --> Config Class Initialized
INFO - 2024-05-30 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:28 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:28 --> URI Class Initialized
INFO - 2024-05-30 15:18:28 --> Router Class Initialized
INFO - 2024-05-30 15:18:28 --> Output Class Initialized
INFO - 2024-05-30 15:18:28 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:28 --> Input Class Initialized
INFO - 2024-05-30 15:18:28 --> Language Class Initialized
INFO - 2024-05-30 15:18:28 --> Language Class Initialized
INFO - 2024-05-30 15:18:28 --> Config Class Initialized
INFO - 2024-05-30 15:18:28 --> Loader Class Initialized
INFO - 2024-05-30 15:18:28 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:28 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:28 --> Controller Class Initialized
INFO - 2024-05-30 15:18:28 --> Helper loaded: cookie_helper
INFO - 2024-05-30 15:18:28 --> Final output sent to browser
DEBUG - 2024-05-30 15:18:28 --> Total execution time: 0.0332
INFO - 2024-05-30 15:18:28 --> Config Class Initialized
INFO - 2024-05-30 15:18:28 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:28 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:28 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:28 --> URI Class Initialized
INFO - 2024-05-30 15:18:28 --> Router Class Initialized
INFO - 2024-05-30 15:18:28 --> Output Class Initialized
INFO - 2024-05-30 15:18:28 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:28 --> Input Class Initialized
INFO - 2024-05-30 15:18:28 --> Language Class Initialized
INFO - 2024-05-30 15:18:28 --> Language Class Initialized
INFO - 2024-05-30 15:18:28 --> Config Class Initialized
INFO - 2024-05-30 15:18:28 --> Loader Class Initialized
INFO - 2024-05-30 15:18:28 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:28 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:28 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:28 --> Controller Class Initialized
DEBUG - 2024-05-30 15:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-30 15:18:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:18:28 --> Final output sent to browser
DEBUG - 2024-05-30 15:18:28 --> Total execution time: 0.0360
INFO - 2024-05-30 15:18:30 --> Config Class Initialized
INFO - 2024-05-30 15:18:30 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:30 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:30 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:30 --> URI Class Initialized
DEBUG - 2024-05-30 15:18:30 --> No URI present. Default controller set.
INFO - 2024-05-30 15:18:30 --> Router Class Initialized
INFO - 2024-05-30 15:18:30 --> Output Class Initialized
INFO - 2024-05-30 15:18:30 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:30 --> Input Class Initialized
INFO - 2024-05-30 15:18:30 --> Language Class Initialized
INFO - 2024-05-30 15:18:30 --> Language Class Initialized
INFO - 2024-05-30 15:18:30 --> Config Class Initialized
INFO - 2024-05-30 15:18:30 --> Loader Class Initialized
INFO - 2024-05-30 15:18:30 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:30 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:30 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:30 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:30 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:30 --> Controller Class Initialized
DEBUG - 2024-05-30 15:18:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-30 15:18:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:18:30 --> Final output sent to browser
DEBUG - 2024-05-30 15:18:30 --> Total execution time: 0.0322
INFO - 2024-05-30 15:18:33 --> Config Class Initialized
INFO - 2024-05-30 15:18:33 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:33 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:33 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:33 --> URI Class Initialized
INFO - 2024-05-30 15:18:33 --> Router Class Initialized
INFO - 2024-05-30 15:18:33 --> Output Class Initialized
INFO - 2024-05-30 15:18:33 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:33 --> Input Class Initialized
INFO - 2024-05-30 15:18:33 --> Language Class Initialized
INFO - 2024-05-30 15:18:33 --> Language Class Initialized
INFO - 2024-05-30 15:18:33 --> Config Class Initialized
INFO - 2024-05-30 15:18:33 --> Loader Class Initialized
INFO - 2024-05-30 15:18:33 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:33 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:33 --> Controller Class Initialized
DEBUG - 2024-05-30 15:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-05-30 15:18:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:18:33 --> Final output sent to browser
DEBUG - 2024-05-30 15:18:33 --> Total execution time: 0.0293
INFO - 2024-05-30 15:18:33 --> Config Class Initialized
INFO - 2024-05-30 15:18:33 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:33 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:33 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:33 --> URI Class Initialized
INFO - 2024-05-30 15:18:33 --> Router Class Initialized
INFO - 2024-05-30 15:18:33 --> Output Class Initialized
INFO - 2024-05-30 15:18:33 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:33 --> Input Class Initialized
INFO - 2024-05-30 15:18:33 --> Language Class Initialized
ERROR - 2024-05-30 15:18:33 --> 404 Page Not Found: /index
INFO - 2024-05-30 15:18:33 --> Config Class Initialized
INFO - 2024-05-30 15:18:33 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:18:33 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:18:33 --> Utf8 Class Initialized
INFO - 2024-05-30 15:18:33 --> URI Class Initialized
INFO - 2024-05-30 15:18:33 --> Router Class Initialized
INFO - 2024-05-30 15:18:33 --> Output Class Initialized
INFO - 2024-05-30 15:18:33 --> Security Class Initialized
DEBUG - 2024-05-30 15:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:18:33 --> Input Class Initialized
INFO - 2024-05-30 15:18:33 --> Language Class Initialized
INFO - 2024-05-30 15:18:33 --> Language Class Initialized
INFO - 2024-05-30 15:18:33 --> Config Class Initialized
INFO - 2024-05-30 15:18:33 --> Loader Class Initialized
INFO - 2024-05-30 15:18:33 --> Helper loaded: url_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: file_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: form_helper
INFO - 2024-05-30 15:18:33 --> Helper loaded: my_helper
INFO - 2024-05-30 15:18:33 --> Database Driver Class Initialized
INFO - 2024-05-30 15:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:18:33 --> Controller Class Initialized
INFO - 2024-05-30 15:21:36 --> Config Class Initialized
INFO - 2024-05-30 15:21:36 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:36 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:36 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:36 --> URI Class Initialized
DEBUG - 2024-05-30 15:21:36 --> No URI present. Default controller set.
INFO - 2024-05-30 15:21:36 --> Router Class Initialized
INFO - 2024-05-30 15:21:36 --> Output Class Initialized
INFO - 2024-05-30 15:21:36 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:36 --> Input Class Initialized
INFO - 2024-05-30 15:21:36 --> Language Class Initialized
INFO - 2024-05-30 15:21:36 --> Language Class Initialized
INFO - 2024-05-30 15:21:36 --> Config Class Initialized
INFO - 2024-05-30 15:21:36 --> Loader Class Initialized
INFO - 2024-05-30 15:21:36 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:36 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:36 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:36 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:36 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:36 --> Controller Class Initialized
DEBUG - 2024-05-30 15:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-30 15:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:21:36 --> Final output sent to browser
DEBUG - 2024-05-30 15:21:36 --> Total execution time: 0.0307
INFO - 2024-05-30 15:21:39 --> Config Class Initialized
INFO - 2024-05-30 15:21:39 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:39 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:39 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:39 --> URI Class Initialized
INFO - 2024-05-30 15:21:39 --> Router Class Initialized
INFO - 2024-05-30 15:21:39 --> Output Class Initialized
INFO - 2024-05-30 15:21:39 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:39 --> Input Class Initialized
INFO - 2024-05-30 15:21:39 --> Language Class Initialized
INFO - 2024-05-30 15:21:39 --> Language Class Initialized
INFO - 2024-05-30 15:21:39 --> Config Class Initialized
INFO - 2024-05-30 15:21:39 --> Loader Class Initialized
INFO - 2024-05-30 15:21:39 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:39 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:39 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:39 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:39 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:39 --> Controller Class Initialized
DEBUG - 2024-05-30 15:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-05-30 15:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:21:39 --> Final output sent to browser
DEBUG - 2024-05-30 15:21:39 --> Total execution time: 0.0321
INFO - 2024-05-30 15:21:40 --> Config Class Initialized
INFO - 2024-05-30 15:21:40 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:40 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:40 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:40 --> URI Class Initialized
INFO - 2024-05-30 15:21:40 --> Router Class Initialized
INFO - 2024-05-30 15:21:40 --> Output Class Initialized
INFO - 2024-05-30 15:21:40 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:40 --> Input Class Initialized
INFO - 2024-05-30 15:21:40 --> Language Class Initialized
ERROR - 2024-05-30 15:21:40 --> 404 Page Not Found: /index
INFO - 2024-05-30 15:21:40 --> Config Class Initialized
INFO - 2024-05-30 15:21:40 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:40 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:40 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:40 --> URI Class Initialized
INFO - 2024-05-30 15:21:40 --> Router Class Initialized
INFO - 2024-05-30 15:21:40 --> Output Class Initialized
INFO - 2024-05-30 15:21:40 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:40 --> Input Class Initialized
INFO - 2024-05-30 15:21:40 --> Language Class Initialized
INFO - 2024-05-30 15:21:40 --> Language Class Initialized
INFO - 2024-05-30 15:21:40 --> Config Class Initialized
INFO - 2024-05-30 15:21:40 --> Loader Class Initialized
INFO - 2024-05-30 15:21:40 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:40 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:40 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:40 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:40 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:40 --> Controller Class Initialized
INFO - 2024-05-30 15:21:41 --> Config Class Initialized
INFO - 2024-05-30 15:21:41 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:41 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:41 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:41 --> URI Class Initialized
INFO - 2024-05-30 15:21:41 --> Router Class Initialized
INFO - 2024-05-30 15:21:41 --> Output Class Initialized
INFO - 2024-05-30 15:21:41 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:41 --> Input Class Initialized
INFO - 2024-05-30 15:21:41 --> Language Class Initialized
INFO - 2024-05-30 15:21:41 --> Language Class Initialized
INFO - 2024-05-30 15:21:41 --> Config Class Initialized
INFO - 2024-05-30 15:21:41 --> Loader Class Initialized
INFO - 2024-05-30 15:21:41 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:41 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:41 --> Controller Class Initialized
DEBUG - 2024-05-30 15:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2024-05-30 15:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:21:41 --> Final output sent to browser
DEBUG - 2024-05-30 15:21:41 --> Total execution time: 0.0312
INFO - 2024-05-30 15:21:41 --> Config Class Initialized
INFO - 2024-05-30 15:21:41 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:41 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:41 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:41 --> URI Class Initialized
INFO - 2024-05-30 15:21:41 --> Router Class Initialized
INFO - 2024-05-30 15:21:41 --> Output Class Initialized
INFO - 2024-05-30 15:21:41 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:41 --> Input Class Initialized
INFO - 2024-05-30 15:21:41 --> Language Class Initialized
ERROR - 2024-05-30 15:21:41 --> 404 Page Not Found: /index
INFO - 2024-05-30 15:21:41 --> Config Class Initialized
INFO - 2024-05-30 15:21:41 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:41 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:41 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:41 --> URI Class Initialized
INFO - 2024-05-30 15:21:41 --> Router Class Initialized
INFO - 2024-05-30 15:21:41 --> Output Class Initialized
INFO - 2024-05-30 15:21:41 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:41 --> Input Class Initialized
INFO - 2024-05-30 15:21:41 --> Language Class Initialized
INFO - 2024-05-30 15:21:41 --> Language Class Initialized
INFO - 2024-05-30 15:21:41 --> Config Class Initialized
INFO - 2024-05-30 15:21:41 --> Loader Class Initialized
INFO - 2024-05-30 15:21:41 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:41 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:41 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:41 --> Controller Class Initialized
INFO - 2024-05-30 15:21:43 --> Config Class Initialized
INFO - 2024-05-30 15:21:43 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:43 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:43 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:43 --> URI Class Initialized
INFO - 2024-05-30 15:21:43 --> Router Class Initialized
INFO - 2024-05-30 15:21:43 --> Output Class Initialized
INFO - 2024-05-30 15:21:43 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:43 --> Input Class Initialized
INFO - 2024-05-30 15:21:43 --> Language Class Initialized
INFO - 2024-05-30 15:21:43 --> Language Class Initialized
INFO - 2024-05-30 15:21:43 --> Config Class Initialized
INFO - 2024-05-30 15:21:43 --> Loader Class Initialized
INFO - 2024-05-30 15:21:43 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:43 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:43 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:43 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:43 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:43 --> Controller Class Initialized
DEBUG - 2024-05-30 15:21:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2024-05-30 15:21:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 15:21:43 --> Final output sent to browser
DEBUG - 2024-05-30 15:21:43 --> Total execution time: 0.0317
INFO - 2024-05-30 15:21:43 --> Config Class Initialized
INFO - 2024-05-30 15:21:43 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:44 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:44 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:44 --> URI Class Initialized
INFO - 2024-05-30 15:21:44 --> Router Class Initialized
INFO - 2024-05-30 15:21:44 --> Output Class Initialized
INFO - 2024-05-30 15:21:44 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:44 --> Input Class Initialized
INFO - 2024-05-30 15:21:44 --> Language Class Initialized
ERROR - 2024-05-30 15:21:44 --> 404 Page Not Found: /index
INFO - 2024-05-30 15:21:44 --> Config Class Initialized
INFO - 2024-05-30 15:21:44 --> Hooks Class Initialized
DEBUG - 2024-05-30 15:21:44 --> UTF-8 Support Enabled
INFO - 2024-05-30 15:21:44 --> Utf8 Class Initialized
INFO - 2024-05-30 15:21:44 --> URI Class Initialized
INFO - 2024-05-30 15:21:44 --> Router Class Initialized
INFO - 2024-05-30 15:21:44 --> Output Class Initialized
INFO - 2024-05-30 15:21:44 --> Security Class Initialized
DEBUG - 2024-05-30 15:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 15:21:44 --> Input Class Initialized
INFO - 2024-05-30 15:21:44 --> Language Class Initialized
INFO - 2024-05-30 15:21:44 --> Language Class Initialized
INFO - 2024-05-30 15:21:44 --> Config Class Initialized
INFO - 2024-05-30 15:21:44 --> Loader Class Initialized
INFO - 2024-05-30 15:21:44 --> Helper loaded: url_helper
INFO - 2024-05-30 15:21:44 --> Helper loaded: file_helper
INFO - 2024-05-30 15:21:44 --> Helper loaded: form_helper
INFO - 2024-05-30 15:21:44 --> Helper loaded: my_helper
INFO - 2024-05-30 15:21:44 --> Database Driver Class Initialized
INFO - 2024-05-30 15:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 15:21:44 --> Controller Class Initialized
INFO - 2024-05-30 16:01:42 --> Config Class Initialized
INFO - 2024-05-30 16:01:42 --> Hooks Class Initialized
DEBUG - 2024-05-30 16:01:42 --> UTF-8 Support Enabled
INFO - 2024-05-30 16:01:42 --> Utf8 Class Initialized
INFO - 2024-05-30 16:01:42 --> URI Class Initialized
DEBUG - 2024-05-30 16:01:42 --> No URI present. Default controller set.
INFO - 2024-05-30 16:01:42 --> Router Class Initialized
INFO - 2024-05-30 16:01:42 --> Output Class Initialized
INFO - 2024-05-30 16:01:42 --> Security Class Initialized
DEBUG - 2024-05-30 16:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-05-30 16:01:42 --> Input Class Initialized
INFO - 2024-05-30 16:01:42 --> Language Class Initialized
INFO - 2024-05-30 16:01:42 --> Language Class Initialized
INFO - 2024-05-30 16:01:42 --> Config Class Initialized
INFO - 2024-05-30 16:01:42 --> Loader Class Initialized
INFO - 2024-05-30 16:01:42 --> Helper loaded: url_helper
INFO - 2024-05-30 16:01:42 --> Helper loaded: file_helper
INFO - 2024-05-30 16:01:42 --> Helper loaded: form_helper
INFO - 2024-05-30 16:01:42 --> Helper loaded: my_helper
INFO - 2024-05-30 16:01:42 --> Database Driver Class Initialized
INFO - 2024-05-30 16:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-05-30 16:01:42 --> Controller Class Initialized
DEBUG - 2024-05-30 16:01:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-05-30 16:01:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-05-30 16:01:42 --> Final output sent to browser
DEBUG - 2024-05-30 16:01:42 --> Total execution time: 0.0560
