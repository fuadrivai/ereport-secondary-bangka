<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-05 08:14:34 --> Config Class Initialized
INFO - 2023-12-05 08:14:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:14:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:14:34 --> Utf8 Class Initialized
INFO - 2023-12-05 08:14:34 --> URI Class Initialized
INFO - 2023-12-05 08:14:34 --> Router Class Initialized
INFO - 2023-12-05 08:14:34 --> Output Class Initialized
INFO - 2023-12-05 08:14:34 --> Security Class Initialized
DEBUG - 2023-12-05 08:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:14:34 --> Input Class Initialized
INFO - 2023-12-05 08:14:34 --> Language Class Initialized
INFO - 2023-12-05 08:14:34 --> Language Class Initialized
INFO - 2023-12-05 08:14:34 --> Config Class Initialized
INFO - 2023-12-05 08:14:34 --> Loader Class Initialized
INFO - 2023-12-05 08:14:34 --> Helper loaded: url_helper
INFO - 2023-12-05 08:14:34 --> Helper loaded: file_helper
INFO - 2023-12-05 08:14:34 --> Helper loaded: form_helper
INFO - 2023-12-05 08:14:34 --> Helper loaded: my_helper
INFO - 2023-12-05 08:14:34 --> Database Driver Class Initialized
INFO - 2023-12-05 08:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:14:34 --> Controller Class Initialized
DEBUG - 2023-12-05 08:14:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 08:14:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:14:34 --> Final output sent to browser
DEBUG - 2023-12-05 08:14:34 --> Total execution time: 0.1059
INFO - 2023-12-05 08:38:13 --> Config Class Initialized
INFO - 2023-12-05 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:13 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:13 --> URI Class Initialized
DEBUG - 2023-12-05 08:38:13 --> No URI present. Default controller set.
INFO - 2023-12-05 08:38:13 --> Router Class Initialized
INFO - 2023-12-05 08:38:13 --> Output Class Initialized
INFO - 2023-12-05 08:38:13 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:13 --> Input Class Initialized
INFO - 2023-12-05 08:38:13 --> Language Class Initialized
INFO - 2023-12-05 08:38:13 --> Language Class Initialized
INFO - 2023-12-05 08:38:13 --> Config Class Initialized
INFO - 2023-12-05 08:38:13 --> Loader Class Initialized
INFO - 2023-12-05 08:38:13 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:13 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:13 --> Controller Class Initialized
INFO - 2023-12-05 08:38:13 --> Config Class Initialized
INFO - 2023-12-05 08:38:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:13 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:13 --> URI Class Initialized
INFO - 2023-12-05 08:38:13 --> Router Class Initialized
INFO - 2023-12-05 08:38:13 --> Output Class Initialized
INFO - 2023-12-05 08:38:13 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:13 --> Input Class Initialized
INFO - 2023-12-05 08:38:13 --> Language Class Initialized
INFO - 2023-12-05 08:38:13 --> Language Class Initialized
INFO - 2023-12-05 08:38:13 --> Config Class Initialized
INFO - 2023-12-05 08:38:13 --> Loader Class Initialized
INFO - 2023-12-05 08:38:13 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:13 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:13 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:13 --> Controller Class Initialized
DEBUG - 2023-12-05 08:38:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 08:38:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:38:13 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:13 --> Total execution time: 0.0400
INFO - 2023-12-05 08:38:17 --> Config Class Initialized
INFO - 2023-12-05 08:38:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:17 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:17 --> URI Class Initialized
INFO - 2023-12-05 08:38:17 --> Router Class Initialized
INFO - 2023-12-05 08:38:17 --> Output Class Initialized
INFO - 2023-12-05 08:38:17 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:17 --> Input Class Initialized
INFO - 2023-12-05 08:38:17 --> Language Class Initialized
INFO - 2023-12-05 08:38:17 --> Language Class Initialized
INFO - 2023-12-05 08:38:17 --> Config Class Initialized
INFO - 2023-12-05 08:38:17 --> Loader Class Initialized
INFO - 2023-12-05 08:38:17 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:17 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:17 --> Controller Class Initialized
INFO - 2023-12-05 08:38:17 --> Helper loaded: cookie_helper
INFO - 2023-12-05 08:38:17 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:17 --> Total execution time: 0.0671
INFO - 2023-12-05 08:38:17 --> Config Class Initialized
INFO - 2023-12-05 08:38:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:17 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:17 --> URI Class Initialized
INFO - 2023-12-05 08:38:17 --> Router Class Initialized
INFO - 2023-12-05 08:38:17 --> Output Class Initialized
INFO - 2023-12-05 08:38:17 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:17 --> Input Class Initialized
INFO - 2023-12-05 08:38:17 --> Language Class Initialized
INFO - 2023-12-05 08:38:17 --> Language Class Initialized
INFO - 2023-12-05 08:38:17 --> Config Class Initialized
INFO - 2023-12-05 08:38:17 --> Loader Class Initialized
INFO - 2023-12-05 08:38:17 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:17 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:17 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:17 --> Controller Class Initialized
DEBUG - 2023-12-05 08:38:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-05 08:38:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:38:17 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:17 --> Total execution time: 0.0471
INFO - 2023-12-05 08:38:22 --> Config Class Initialized
INFO - 2023-12-05 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:22 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:22 --> URI Class Initialized
INFO - 2023-12-05 08:38:22 --> Router Class Initialized
INFO - 2023-12-05 08:38:22 --> Output Class Initialized
INFO - 2023-12-05 08:38:22 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:22 --> Input Class Initialized
INFO - 2023-12-05 08:38:22 --> Language Class Initialized
INFO - 2023-12-05 08:38:22 --> Language Class Initialized
INFO - 2023-12-05 08:38:22 --> Config Class Initialized
INFO - 2023-12-05 08:38:22 --> Loader Class Initialized
INFO - 2023-12-05 08:38:22 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:22 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:22 --> Controller Class Initialized
DEBUG - 2023-12-05 08:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-05 08:38:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:38:22 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:22 --> Total execution time: 0.0404
INFO - 2023-12-05 08:38:22 --> Config Class Initialized
INFO - 2023-12-05 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:22 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:22 --> URI Class Initialized
INFO - 2023-12-05 08:38:22 --> Router Class Initialized
INFO - 2023-12-05 08:38:22 --> Output Class Initialized
INFO - 2023-12-05 08:38:22 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:22 --> Input Class Initialized
INFO - 2023-12-05 08:38:22 --> Language Class Initialized
ERROR - 2023-12-05 08:38:22 --> 404 Page Not Found: /index
INFO - 2023-12-05 08:38:22 --> Config Class Initialized
INFO - 2023-12-05 08:38:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:22 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:22 --> URI Class Initialized
INFO - 2023-12-05 08:38:22 --> Router Class Initialized
INFO - 2023-12-05 08:38:22 --> Output Class Initialized
INFO - 2023-12-05 08:38:22 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:22 --> Input Class Initialized
INFO - 2023-12-05 08:38:22 --> Language Class Initialized
INFO - 2023-12-05 08:38:22 --> Language Class Initialized
INFO - 2023-12-05 08:38:22 --> Config Class Initialized
INFO - 2023-12-05 08:38:22 --> Loader Class Initialized
INFO - 2023-12-05 08:38:22 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:22 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:22 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:22 --> Controller Class Initialized
INFO - 2023-12-05 08:38:24 --> Config Class Initialized
INFO - 2023-12-05 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:24 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:24 --> URI Class Initialized
INFO - 2023-12-05 08:38:24 --> Router Class Initialized
INFO - 2023-12-05 08:38:24 --> Output Class Initialized
INFO - 2023-12-05 08:38:24 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:24 --> Input Class Initialized
INFO - 2023-12-05 08:38:24 --> Language Class Initialized
INFO - 2023-12-05 08:38:24 --> Language Class Initialized
INFO - 2023-12-05 08:38:24 --> Config Class Initialized
INFO - 2023-12-05 08:38:24 --> Loader Class Initialized
INFO - 2023-12-05 08:38:24 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:24 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:24 --> Controller Class Initialized
DEBUG - 2023-12-05 08:38:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2023-12-05 08:38:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:38:24 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:24 --> Total execution time: 0.0542
INFO - 2023-12-05 08:38:24 --> Config Class Initialized
INFO - 2023-12-05 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:24 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:24 --> URI Class Initialized
INFO - 2023-12-05 08:38:24 --> Router Class Initialized
INFO - 2023-12-05 08:38:24 --> Output Class Initialized
INFO - 2023-12-05 08:38:24 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:24 --> Input Class Initialized
INFO - 2023-12-05 08:38:24 --> Language Class Initialized
ERROR - 2023-12-05 08:38:24 --> 404 Page Not Found: /index
INFO - 2023-12-05 08:38:24 --> Config Class Initialized
INFO - 2023-12-05 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:24 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:24 --> URI Class Initialized
INFO - 2023-12-05 08:38:24 --> Router Class Initialized
INFO - 2023-12-05 08:38:24 --> Output Class Initialized
INFO - 2023-12-05 08:38:24 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:24 --> Input Class Initialized
INFO - 2023-12-05 08:38:24 --> Language Class Initialized
INFO - 2023-12-05 08:38:24 --> Language Class Initialized
INFO - 2023-12-05 08:38:24 --> Config Class Initialized
INFO - 2023-12-05 08:38:24 --> Loader Class Initialized
INFO - 2023-12-05 08:38:24 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:24 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:24 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:24 --> Controller Class Initialized
INFO - 2023-12-05 08:38:32 --> Config Class Initialized
INFO - 2023-12-05 08:38:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:32 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:32 --> URI Class Initialized
INFO - 2023-12-05 08:38:32 --> Router Class Initialized
INFO - 2023-12-05 08:38:32 --> Output Class Initialized
INFO - 2023-12-05 08:38:32 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:32 --> Input Class Initialized
INFO - 2023-12-05 08:38:32 --> Language Class Initialized
INFO - 2023-12-05 08:38:32 --> Language Class Initialized
INFO - 2023-12-05 08:38:32 --> Config Class Initialized
INFO - 2023-12-05 08:38:32 --> Loader Class Initialized
INFO - 2023-12-05 08:38:32 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:32 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:32 --> Controller Class Initialized
DEBUG - 2023-12-05 08:38:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-05 08:38:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:38:32 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:32 --> Total execution time: 0.0442
INFO - 2023-12-05 08:38:32 --> Config Class Initialized
INFO - 2023-12-05 08:38:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:32 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:32 --> URI Class Initialized
INFO - 2023-12-05 08:38:32 --> Router Class Initialized
INFO - 2023-12-05 08:38:32 --> Output Class Initialized
INFO - 2023-12-05 08:38:32 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:32 --> Input Class Initialized
INFO - 2023-12-05 08:38:32 --> Language Class Initialized
ERROR - 2023-12-05 08:38:32 --> 404 Page Not Found: /index
INFO - 2023-12-05 08:38:32 --> Config Class Initialized
INFO - 2023-12-05 08:38:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:32 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:32 --> URI Class Initialized
INFO - 2023-12-05 08:38:32 --> Router Class Initialized
INFO - 2023-12-05 08:38:32 --> Output Class Initialized
INFO - 2023-12-05 08:38:32 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:32 --> Input Class Initialized
INFO - 2023-12-05 08:38:32 --> Language Class Initialized
INFO - 2023-12-05 08:38:32 --> Language Class Initialized
INFO - 2023-12-05 08:38:32 --> Config Class Initialized
INFO - 2023-12-05 08:38:32 --> Loader Class Initialized
INFO - 2023-12-05 08:38:32 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:32 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:32 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:32 --> Controller Class Initialized
INFO - 2023-12-05 08:38:33 --> Config Class Initialized
INFO - 2023-12-05 08:38:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:38:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:38:33 --> Utf8 Class Initialized
INFO - 2023-12-05 08:38:33 --> URI Class Initialized
INFO - 2023-12-05 08:38:33 --> Router Class Initialized
INFO - 2023-12-05 08:38:33 --> Output Class Initialized
INFO - 2023-12-05 08:38:33 --> Security Class Initialized
DEBUG - 2023-12-05 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:38:33 --> Input Class Initialized
INFO - 2023-12-05 08:38:33 --> Language Class Initialized
INFO - 2023-12-05 08:38:33 --> Language Class Initialized
INFO - 2023-12-05 08:38:33 --> Config Class Initialized
INFO - 2023-12-05 08:38:33 --> Loader Class Initialized
INFO - 2023-12-05 08:38:33 --> Helper loaded: url_helper
INFO - 2023-12-05 08:38:33 --> Helper loaded: file_helper
INFO - 2023-12-05 08:38:33 --> Helper loaded: form_helper
INFO - 2023-12-05 08:38:33 --> Helper loaded: my_helper
INFO - 2023-12-05 08:38:33 --> Database Driver Class Initialized
INFO - 2023-12-05 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:38:33 --> Controller Class Initialized
INFO - 2023-12-05 08:38:33 --> Final output sent to browser
DEBUG - 2023-12-05 08:38:33 --> Total execution time: 0.0680
INFO - 2023-12-05 08:40:11 --> Config Class Initialized
INFO - 2023-12-05 08:40:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:11 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:11 --> URI Class Initialized
INFO - 2023-12-05 08:40:11 --> Router Class Initialized
INFO - 2023-12-05 08:40:11 --> Output Class Initialized
INFO - 2023-12-05 08:40:11 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:11 --> Input Class Initialized
INFO - 2023-12-05 08:40:11 --> Language Class Initialized
INFO - 2023-12-05 08:40:11 --> Language Class Initialized
INFO - 2023-12-05 08:40:11 --> Config Class Initialized
INFO - 2023-12-05 08:40:11 --> Loader Class Initialized
INFO - 2023-12-05 08:40:11 --> Helper loaded: url_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: file_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: form_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: my_helper
INFO - 2023-12-05 08:40:11 --> Database Driver Class Initialized
INFO - 2023-12-05 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:40:11 --> Controller Class Initialized
DEBUG - 2023-12-05 08:40:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-05 08:40:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:40:11 --> Final output sent to browser
DEBUG - 2023-12-05 08:40:11 --> Total execution time: 0.0502
INFO - 2023-12-05 08:40:11 --> Config Class Initialized
INFO - 2023-12-05 08:40:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:11 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:11 --> URI Class Initialized
INFO - 2023-12-05 08:40:11 --> Router Class Initialized
INFO - 2023-12-05 08:40:11 --> Output Class Initialized
INFO - 2023-12-05 08:40:11 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:11 --> Input Class Initialized
INFO - 2023-12-05 08:40:11 --> Language Class Initialized
ERROR - 2023-12-05 08:40:11 --> 404 Page Not Found: /index
INFO - 2023-12-05 08:40:11 --> Config Class Initialized
INFO - 2023-12-05 08:40:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:11 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:11 --> URI Class Initialized
INFO - 2023-12-05 08:40:11 --> Router Class Initialized
INFO - 2023-12-05 08:40:11 --> Output Class Initialized
INFO - 2023-12-05 08:40:11 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:11 --> Input Class Initialized
INFO - 2023-12-05 08:40:11 --> Language Class Initialized
INFO - 2023-12-05 08:40:11 --> Language Class Initialized
INFO - 2023-12-05 08:40:11 --> Config Class Initialized
INFO - 2023-12-05 08:40:11 --> Loader Class Initialized
INFO - 2023-12-05 08:40:11 --> Helper loaded: url_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: file_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: form_helper
INFO - 2023-12-05 08:40:11 --> Helper loaded: my_helper
INFO - 2023-12-05 08:40:11 --> Database Driver Class Initialized
INFO - 2023-12-05 08:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:40:11 --> Controller Class Initialized
INFO - 2023-12-05 08:40:51 --> Config Class Initialized
INFO - 2023-12-05 08:40:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:51 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:51 --> URI Class Initialized
INFO - 2023-12-05 08:40:51 --> Router Class Initialized
INFO - 2023-12-05 08:40:51 --> Output Class Initialized
INFO - 2023-12-05 08:40:51 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:51 --> Input Class Initialized
INFO - 2023-12-05 08:40:51 --> Language Class Initialized
INFO - 2023-12-05 08:40:51 --> Language Class Initialized
INFO - 2023-12-05 08:40:51 --> Config Class Initialized
INFO - 2023-12-05 08:40:51 --> Loader Class Initialized
INFO - 2023-12-05 08:40:51 --> Helper loaded: url_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: file_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: form_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: my_helper
INFO - 2023-12-05 08:40:51 --> Database Driver Class Initialized
INFO - 2023-12-05 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:40:51 --> Controller Class Initialized
DEBUG - 2023-12-05 08:40:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 08:40:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 08:40:51 --> Final output sent to browser
DEBUG - 2023-12-05 08:40:51 --> Total execution time: 0.1032
INFO - 2023-12-05 08:40:51 --> Config Class Initialized
INFO - 2023-12-05 08:40:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:51 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:51 --> URI Class Initialized
INFO - 2023-12-05 08:40:51 --> Router Class Initialized
INFO - 2023-12-05 08:40:51 --> Output Class Initialized
INFO - 2023-12-05 08:40:51 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:51 --> Input Class Initialized
INFO - 2023-12-05 08:40:51 --> Language Class Initialized
ERROR - 2023-12-05 08:40:51 --> 404 Page Not Found: /index
INFO - 2023-12-05 08:40:51 --> Config Class Initialized
INFO - 2023-12-05 08:40:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:51 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:51 --> URI Class Initialized
INFO - 2023-12-05 08:40:51 --> Router Class Initialized
INFO - 2023-12-05 08:40:51 --> Output Class Initialized
INFO - 2023-12-05 08:40:51 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:51 --> Input Class Initialized
INFO - 2023-12-05 08:40:51 --> Language Class Initialized
INFO - 2023-12-05 08:40:51 --> Language Class Initialized
INFO - 2023-12-05 08:40:51 --> Config Class Initialized
INFO - 2023-12-05 08:40:51 --> Loader Class Initialized
INFO - 2023-12-05 08:40:51 --> Helper loaded: url_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: file_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: form_helper
INFO - 2023-12-05 08:40:51 --> Helper loaded: my_helper
INFO - 2023-12-05 08:40:51 --> Database Driver Class Initialized
INFO - 2023-12-05 08:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:40:51 --> Controller Class Initialized
INFO - 2023-12-05 08:40:53 --> Config Class Initialized
INFO - 2023-12-05 08:40:53 --> Hooks Class Initialized
DEBUG - 2023-12-05 08:40:53 --> UTF-8 Support Enabled
INFO - 2023-12-05 08:40:53 --> Utf8 Class Initialized
INFO - 2023-12-05 08:40:53 --> URI Class Initialized
INFO - 2023-12-05 08:40:53 --> Router Class Initialized
INFO - 2023-12-05 08:40:53 --> Output Class Initialized
INFO - 2023-12-05 08:40:53 --> Security Class Initialized
DEBUG - 2023-12-05 08:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 08:40:53 --> Input Class Initialized
INFO - 2023-12-05 08:40:53 --> Language Class Initialized
INFO - 2023-12-05 08:40:53 --> Language Class Initialized
INFO - 2023-12-05 08:40:53 --> Config Class Initialized
INFO - 2023-12-05 08:40:53 --> Loader Class Initialized
INFO - 2023-12-05 08:40:53 --> Helper loaded: url_helper
INFO - 2023-12-05 08:40:53 --> Helper loaded: file_helper
INFO - 2023-12-05 08:40:53 --> Helper loaded: form_helper
INFO - 2023-12-05 08:40:53 --> Helper loaded: my_helper
INFO - 2023-12-05 08:40:53 --> Database Driver Class Initialized
INFO - 2023-12-05 08:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 08:40:53 --> Controller Class Initialized
INFO - 2023-12-05 08:40:53 --> Final output sent to browser
DEBUG - 2023-12-05 08:40:53 --> Total execution time: 0.0405
INFO - 2023-12-05 09:10:56 --> Config Class Initialized
INFO - 2023-12-05 09:10:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 09:10:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 09:10:56 --> Utf8 Class Initialized
INFO - 2023-12-05 09:10:56 --> URI Class Initialized
INFO - 2023-12-05 09:10:56 --> Router Class Initialized
INFO - 2023-12-05 09:10:56 --> Output Class Initialized
INFO - 2023-12-05 09:10:56 --> Security Class Initialized
DEBUG - 2023-12-05 09:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 09:10:56 --> Input Class Initialized
INFO - 2023-12-05 09:10:56 --> Language Class Initialized
INFO - 2023-12-05 09:10:56 --> Language Class Initialized
INFO - 2023-12-05 09:10:56 --> Config Class Initialized
INFO - 2023-12-05 09:10:56 --> Loader Class Initialized
INFO - 2023-12-05 09:10:56 --> Helper loaded: url_helper
INFO - 2023-12-05 09:10:56 --> Helper loaded: file_helper
INFO - 2023-12-05 09:10:56 --> Helper loaded: form_helper
INFO - 2023-12-05 09:10:56 --> Helper loaded: my_helper
INFO - 2023-12-05 09:10:56 --> Database Driver Class Initialized
INFO - 2023-12-05 09:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 09:10:56 --> Controller Class Initialized
INFO - 2023-12-05 09:10:56 --> Helper loaded: cookie_helper
INFO - 2023-12-05 09:10:56 --> Config Class Initialized
INFO - 2023-12-05 09:10:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 09:10:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 09:10:56 --> Utf8 Class Initialized
INFO - 2023-12-05 09:10:56 --> URI Class Initialized
INFO - 2023-12-05 09:10:57 --> Router Class Initialized
INFO - 2023-12-05 09:10:57 --> Output Class Initialized
INFO - 2023-12-05 09:10:57 --> Security Class Initialized
DEBUG - 2023-12-05 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 09:10:57 --> Input Class Initialized
INFO - 2023-12-05 09:10:57 --> Language Class Initialized
INFO - 2023-12-05 09:10:57 --> Language Class Initialized
INFO - 2023-12-05 09:10:57 --> Config Class Initialized
INFO - 2023-12-05 09:10:57 --> Loader Class Initialized
INFO - 2023-12-05 09:10:57 --> Helper loaded: url_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: file_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: form_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: my_helper
INFO - 2023-12-05 09:10:57 --> Database Driver Class Initialized
INFO - 2023-12-05 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 09:10:57 --> Controller Class Initialized
INFO - 2023-12-05 09:10:57 --> Config Class Initialized
INFO - 2023-12-05 09:10:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 09:10:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 09:10:57 --> Utf8 Class Initialized
INFO - 2023-12-05 09:10:57 --> URI Class Initialized
INFO - 2023-12-05 09:10:57 --> Router Class Initialized
INFO - 2023-12-05 09:10:57 --> Output Class Initialized
INFO - 2023-12-05 09:10:57 --> Security Class Initialized
DEBUG - 2023-12-05 09:10:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 09:10:57 --> Input Class Initialized
INFO - 2023-12-05 09:10:57 --> Language Class Initialized
INFO - 2023-12-05 09:10:57 --> Language Class Initialized
INFO - 2023-12-05 09:10:57 --> Config Class Initialized
INFO - 2023-12-05 09:10:57 --> Loader Class Initialized
INFO - 2023-12-05 09:10:57 --> Helper loaded: url_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: file_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: form_helper
INFO - 2023-12-05 09:10:57 --> Helper loaded: my_helper
INFO - 2023-12-05 09:10:57 --> Database Driver Class Initialized
INFO - 2023-12-05 09:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 09:10:57 --> Controller Class Initialized
DEBUG - 2023-12-05 09:10:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 09:10:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 09:10:57 --> Final output sent to browser
DEBUG - 2023-12-05 09:10:57 --> Total execution time: 0.0314
INFO - 2023-12-05 10:07:27 --> Config Class Initialized
INFO - 2023-12-05 10:07:27 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:27 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:27 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:27 --> URI Class Initialized
INFO - 2023-12-05 10:07:27 --> Router Class Initialized
INFO - 2023-12-05 10:07:27 --> Output Class Initialized
INFO - 2023-12-05 10:07:27 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:27 --> Input Class Initialized
INFO - 2023-12-05 10:07:27 --> Language Class Initialized
INFO - 2023-12-05 10:07:27 --> Language Class Initialized
INFO - 2023-12-05 10:07:27 --> Config Class Initialized
INFO - 2023-12-05 10:07:27 --> Loader Class Initialized
INFO - 2023-12-05 10:07:27 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:27 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:27 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:27 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:27 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:27 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 10:07:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:27 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:27 --> Total execution time: 0.0684
INFO - 2023-12-05 10:07:33 --> Config Class Initialized
INFO - 2023-12-05 10:07:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:33 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:33 --> URI Class Initialized
INFO - 2023-12-05 10:07:33 --> Router Class Initialized
INFO - 2023-12-05 10:07:33 --> Output Class Initialized
INFO - 2023-12-05 10:07:33 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:33 --> Input Class Initialized
INFO - 2023-12-05 10:07:33 --> Language Class Initialized
INFO - 2023-12-05 10:07:33 --> Language Class Initialized
INFO - 2023-12-05 10:07:33 --> Config Class Initialized
INFO - 2023-12-05 10:07:33 --> Loader Class Initialized
INFO - 2023-12-05 10:07:33 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:33 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:33 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:33 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:33 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:33 --> Controller Class Initialized
INFO - 2023-12-05 10:07:33 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:07:33 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:33 --> Total execution time: 0.0558
INFO - 2023-12-05 10:07:34 --> Config Class Initialized
INFO - 2023-12-05 10:07:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:34 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:34 --> URI Class Initialized
INFO - 2023-12-05 10:07:34 --> Router Class Initialized
INFO - 2023-12-05 10:07:34 --> Output Class Initialized
INFO - 2023-12-05 10:07:34 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:34 --> Input Class Initialized
INFO - 2023-12-05 10:07:34 --> Language Class Initialized
INFO - 2023-12-05 10:07:34 --> Language Class Initialized
INFO - 2023-12-05 10:07:34 --> Config Class Initialized
INFO - 2023-12-05 10:07:34 --> Loader Class Initialized
INFO - 2023-12-05 10:07:34 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:34 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:34 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:34 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:34 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:34 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 10:07:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:34 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:34 --> Total execution time: 0.1294
INFO - 2023-12-05 10:07:39 --> Config Class Initialized
INFO - 2023-12-05 10:07:39 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:39 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:39 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:39 --> URI Class Initialized
INFO - 2023-12-05 10:07:39 --> Router Class Initialized
INFO - 2023-12-05 10:07:39 --> Output Class Initialized
INFO - 2023-12-05 10:07:39 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:39 --> Input Class Initialized
INFO - 2023-12-05 10:07:39 --> Language Class Initialized
INFO - 2023-12-05 10:07:39 --> Language Class Initialized
INFO - 2023-12-05 10:07:39 --> Config Class Initialized
INFO - 2023-12-05 10:07:39 --> Loader Class Initialized
INFO - 2023-12-05 10:07:39 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:39 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:39 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:39 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:39 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:39 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 10:07:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:39 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:39 --> Total execution time: 0.1084
INFO - 2023-12-05 10:07:42 --> Config Class Initialized
INFO - 2023-12-05 10:07:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:42 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:42 --> URI Class Initialized
INFO - 2023-12-05 10:07:42 --> Router Class Initialized
INFO - 2023-12-05 10:07:42 --> Output Class Initialized
INFO - 2023-12-05 10:07:42 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:42 --> Input Class Initialized
INFO - 2023-12-05 10:07:42 --> Language Class Initialized
INFO - 2023-12-05 10:07:42 --> Language Class Initialized
INFO - 2023-12-05 10:07:42 --> Config Class Initialized
INFO - 2023-12-05 10:07:42 --> Loader Class Initialized
INFO - 2023-12-05 10:07:42 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:42 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:42 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:42 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:42 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:42 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-05 10:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:42 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:42 --> Total execution time: 0.0342
INFO - 2023-12-05 10:07:44 --> Config Class Initialized
INFO - 2023-12-05 10:07:44 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:44 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:44 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:44 --> URI Class Initialized
INFO - 2023-12-05 10:07:44 --> Router Class Initialized
INFO - 2023-12-05 10:07:44 --> Output Class Initialized
INFO - 2023-12-05 10:07:44 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:44 --> Input Class Initialized
INFO - 2023-12-05 10:07:44 --> Language Class Initialized
INFO - 2023-12-05 10:07:44 --> Language Class Initialized
INFO - 2023-12-05 10:07:44 --> Config Class Initialized
INFO - 2023-12-05 10:07:44 --> Loader Class Initialized
INFO - 2023-12-05 10:07:44 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:44 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:44 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:44 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:44 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:44 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 10:07:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:44 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:44 --> Total execution time: 0.0476
INFO - 2023-12-05 10:07:46 --> Config Class Initialized
INFO - 2023-12-05 10:07:46 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:46 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:46 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:46 --> URI Class Initialized
INFO - 2023-12-05 10:07:46 --> Router Class Initialized
INFO - 2023-12-05 10:07:46 --> Output Class Initialized
INFO - 2023-12-05 10:07:46 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:46 --> Input Class Initialized
INFO - 2023-12-05 10:07:46 --> Language Class Initialized
INFO - 2023-12-05 10:07:46 --> Language Class Initialized
INFO - 2023-12-05 10:07:46 --> Config Class Initialized
INFO - 2023-12-05 10:07:46 --> Loader Class Initialized
INFO - 2023-12-05 10:07:46 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:46 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:46 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:46 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:46 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:47 --> Controller Class Initialized
DEBUG - 2023-12-05 10:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 10:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:07:47 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:47 --> Total execution time: 0.3548
INFO - 2023-12-05 10:07:48 --> Config Class Initialized
INFO - 2023-12-05 10:07:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:48 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:48 --> URI Class Initialized
INFO - 2023-12-05 10:07:48 --> Router Class Initialized
INFO - 2023-12-05 10:07:48 --> Output Class Initialized
INFO - 2023-12-05 10:07:48 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:48 --> Input Class Initialized
INFO - 2023-12-05 10:07:48 --> Language Class Initialized
INFO - 2023-12-05 10:07:48 --> Language Class Initialized
INFO - 2023-12-05 10:07:48 --> Config Class Initialized
INFO - 2023-12-05 10:07:48 --> Loader Class Initialized
INFO - 2023-12-05 10:07:48 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:48 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:48 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:48 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:48 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:48 --> Controller Class Initialized
INFO - 2023-12-05 10:07:56 --> Config Class Initialized
INFO - 2023-12-05 10:07:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:56 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:56 --> URI Class Initialized
INFO - 2023-12-05 10:07:56 --> Router Class Initialized
INFO - 2023-12-05 10:07:56 --> Output Class Initialized
INFO - 2023-12-05 10:07:56 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:56 --> Input Class Initialized
INFO - 2023-12-05 10:07:56 --> Language Class Initialized
INFO - 2023-12-05 10:07:56 --> Language Class Initialized
INFO - 2023-12-05 10:07:56 --> Config Class Initialized
INFO - 2023-12-05 10:07:56 --> Loader Class Initialized
INFO - 2023-12-05 10:07:56 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:56 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:56 --> Controller Class Initialized
INFO - 2023-12-05 10:07:56 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:56 --> Total execution time: 0.0405
INFO - 2023-12-05 10:07:56 --> Config Class Initialized
INFO - 2023-12-05 10:07:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:56 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:56 --> URI Class Initialized
INFO - 2023-12-05 10:07:56 --> Router Class Initialized
INFO - 2023-12-05 10:07:56 --> Output Class Initialized
INFO - 2023-12-05 10:07:56 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:56 --> Input Class Initialized
INFO - 2023-12-05 10:07:56 --> Language Class Initialized
INFO - 2023-12-05 10:07:56 --> Language Class Initialized
INFO - 2023-12-05 10:07:56 --> Config Class Initialized
INFO - 2023-12-05 10:07:56 --> Loader Class Initialized
INFO - 2023-12-05 10:07:56 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:56 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:56 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:56 --> Controller Class Initialized
INFO - 2023-12-05 10:07:56 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:56 --> Total execution time: 0.0410
INFO - 2023-12-05 10:07:57 --> Config Class Initialized
INFO - 2023-12-05 10:07:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:07:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:07:57 --> Utf8 Class Initialized
INFO - 2023-12-05 10:07:57 --> URI Class Initialized
INFO - 2023-12-05 10:07:57 --> Router Class Initialized
INFO - 2023-12-05 10:07:57 --> Output Class Initialized
INFO - 2023-12-05 10:07:57 --> Security Class Initialized
DEBUG - 2023-12-05 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:07:57 --> Input Class Initialized
INFO - 2023-12-05 10:07:57 --> Language Class Initialized
INFO - 2023-12-05 10:07:57 --> Language Class Initialized
INFO - 2023-12-05 10:07:57 --> Config Class Initialized
INFO - 2023-12-05 10:07:57 --> Loader Class Initialized
INFO - 2023-12-05 10:07:57 --> Helper loaded: url_helper
INFO - 2023-12-05 10:07:57 --> Helper loaded: file_helper
INFO - 2023-12-05 10:07:57 --> Helper loaded: form_helper
INFO - 2023-12-05 10:07:57 --> Helper loaded: my_helper
INFO - 2023-12-05 10:07:57 --> Database Driver Class Initialized
INFO - 2023-12-05 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:07:57 --> Controller Class Initialized
INFO - 2023-12-05 10:07:57 --> Final output sent to browser
DEBUG - 2023-12-05 10:07:57 --> Total execution time: 0.0813
INFO - 2023-12-05 10:08:00 --> Config Class Initialized
INFO - 2023-12-05 10:08:00 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:08:00 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:08:00 --> Utf8 Class Initialized
INFO - 2023-12-05 10:08:00 --> URI Class Initialized
INFO - 2023-12-05 10:08:00 --> Router Class Initialized
INFO - 2023-12-05 10:08:00 --> Output Class Initialized
INFO - 2023-12-05 10:08:00 --> Security Class Initialized
DEBUG - 2023-12-05 10:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:08:00 --> Input Class Initialized
INFO - 2023-12-05 10:08:00 --> Language Class Initialized
INFO - 2023-12-05 10:08:00 --> Language Class Initialized
INFO - 2023-12-05 10:08:00 --> Config Class Initialized
INFO - 2023-12-05 10:08:00 --> Loader Class Initialized
INFO - 2023-12-05 10:08:00 --> Helper loaded: url_helper
INFO - 2023-12-05 10:08:00 --> Helper loaded: file_helper
INFO - 2023-12-05 10:08:00 --> Helper loaded: form_helper
INFO - 2023-12-05 10:08:00 --> Helper loaded: my_helper
INFO - 2023-12-05 10:08:00 --> Database Driver Class Initialized
INFO - 2023-12-05 10:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:08:00 --> Controller Class Initialized
INFO - 2023-12-05 10:08:00 --> Final output sent to browser
DEBUG - 2023-12-05 10:08:00 --> Total execution time: 0.0387
INFO - 2023-12-05 10:12:59 --> Config Class Initialized
INFO - 2023-12-05 10:12:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:12:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:12:59 --> Utf8 Class Initialized
INFO - 2023-12-05 10:12:59 --> URI Class Initialized
INFO - 2023-12-05 10:12:59 --> Router Class Initialized
INFO - 2023-12-05 10:12:59 --> Output Class Initialized
INFO - 2023-12-05 10:12:59 --> Security Class Initialized
DEBUG - 2023-12-05 10:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:12:59 --> Input Class Initialized
INFO - 2023-12-05 10:12:59 --> Language Class Initialized
INFO - 2023-12-05 10:12:59 --> Language Class Initialized
INFO - 2023-12-05 10:12:59 --> Config Class Initialized
INFO - 2023-12-05 10:12:59 --> Loader Class Initialized
INFO - 2023-12-05 10:12:59 --> Helper loaded: url_helper
INFO - 2023-12-05 10:12:59 --> Helper loaded: file_helper
INFO - 2023-12-05 10:12:59 --> Helper loaded: form_helper
INFO - 2023-12-05 10:12:59 --> Helper loaded: my_helper
INFO - 2023-12-05 10:13:00 --> Database Driver Class Initialized
INFO - 2023-12-05 10:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:13:00 --> Controller Class Initialized
INFO - 2023-12-05 10:13:00 --> Final output sent to browser
DEBUG - 2023-12-05 10:13:00 --> Total execution time: 0.4820
INFO - 2023-12-05 10:15:37 --> Config Class Initialized
INFO - 2023-12-05 10:15:37 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:15:37 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:15:37 --> Utf8 Class Initialized
INFO - 2023-12-05 10:15:37 --> URI Class Initialized
INFO - 2023-12-05 10:15:37 --> Router Class Initialized
INFO - 2023-12-05 10:15:38 --> Output Class Initialized
INFO - 2023-12-05 10:15:38 --> Security Class Initialized
DEBUG - 2023-12-05 10:15:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:15:38 --> Input Class Initialized
INFO - 2023-12-05 10:15:38 --> Language Class Initialized
INFO - 2023-12-05 10:15:38 --> Language Class Initialized
INFO - 2023-12-05 10:15:38 --> Config Class Initialized
INFO - 2023-12-05 10:15:38 --> Loader Class Initialized
INFO - 2023-12-05 10:15:38 --> Helper loaded: url_helper
INFO - 2023-12-05 10:15:38 --> Helper loaded: file_helper
INFO - 2023-12-05 10:15:38 --> Helper loaded: form_helper
INFO - 2023-12-05 10:15:38 --> Helper loaded: my_helper
INFO - 2023-12-05 10:15:38 --> Database Driver Class Initialized
INFO - 2023-12-05 10:15:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:15:38 --> Controller Class Initialized
INFO - 2023-12-05 10:15:39 --> Final output sent to browser
DEBUG - 2023-12-05 10:15:39 --> Total execution time: 1.0493
INFO - 2023-12-05 10:15:39 --> Config Class Initialized
INFO - 2023-12-05 10:15:39 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:15:39 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:15:39 --> Utf8 Class Initialized
INFO - 2023-12-05 10:15:39 --> URI Class Initialized
INFO - 2023-12-05 10:15:39 --> Router Class Initialized
INFO - 2023-12-05 10:15:39 --> Output Class Initialized
INFO - 2023-12-05 10:15:39 --> Security Class Initialized
DEBUG - 2023-12-05 10:15:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:15:39 --> Input Class Initialized
INFO - 2023-12-05 10:15:39 --> Language Class Initialized
INFO - 2023-12-05 10:15:39 --> Language Class Initialized
INFO - 2023-12-05 10:15:39 --> Config Class Initialized
INFO - 2023-12-05 10:15:39 --> Loader Class Initialized
INFO - 2023-12-05 10:15:39 --> Helper loaded: url_helper
INFO - 2023-12-05 10:15:39 --> Helper loaded: file_helper
INFO - 2023-12-05 10:15:39 --> Helper loaded: form_helper
INFO - 2023-12-05 10:15:39 --> Helper loaded: my_helper
INFO - 2023-12-05 10:15:39 --> Database Driver Class Initialized
INFO - 2023-12-05 10:15:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:15:39 --> Controller Class Initialized
INFO - 2023-12-05 10:17:03 --> Config Class Initialized
INFO - 2023-12-05 10:17:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:03 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:03 --> URI Class Initialized
INFO - 2023-12-05 10:17:03 --> Router Class Initialized
INFO - 2023-12-05 10:17:03 --> Output Class Initialized
INFO - 2023-12-05 10:17:03 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:04 --> Input Class Initialized
INFO - 2023-12-05 10:17:04 --> Language Class Initialized
INFO - 2023-12-05 10:17:04 --> Language Class Initialized
INFO - 2023-12-05 10:17:04 --> Config Class Initialized
INFO - 2023-12-05 10:17:04 --> Loader Class Initialized
INFO - 2023-12-05 10:17:04 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:04 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:04 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:04 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:04 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:04 --> Controller Class Initialized
INFO - 2023-12-05 10:17:04 --> Final output sent to browser
DEBUG - 2023-12-05 10:17:04 --> Total execution time: 0.2241
INFO - 2023-12-05 10:17:05 --> Config Class Initialized
INFO - 2023-12-05 10:17:05 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:05 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:05 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:05 --> URI Class Initialized
INFO - 2023-12-05 10:17:05 --> Router Class Initialized
INFO - 2023-12-05 10:17:05 --> Output Class Initialized
INFO - 2023-12-05 10:17:05 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:05 --> Input Class Initialized
INFO - 2023-12-05 10:17:05 --> Language Class Initialized
INFO - 2023-12-05 10:17:05 --> Language Class Initialized
INFO - 2023-12-05 10:17:05 --> Config Class Initialized
INFO - 2023-12-05 10:17:05 --> Loader Class Initialized
INFO - 2023-12-05 10:17:05 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:05 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:05 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:05 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:05 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:05 --> Controller Class Initialized
INFO - 2023-12-05 10:17:05 --> Final output sent to browser
DEBUG - 2023-12-05 10:17:05 --> Total execution time: 0.1148
INFO - 2023-12-05 10:17:08 --> Config Class Initialized
INFO - 2023-12-05 10:17:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:08 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:08 --> URI Class Initialized
INFO - 2023-12-05 10:17:08 --> Router Class Initialized
INFO - 2023-12-05 10:17:08 --> Output Class Initialized
INFO - 2023-12-05 10:17:08 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:08 --> Input Class Initialized
INFO - 2023-12-05 10:17:08 --> Language Class Initialized
INFO - 2023-12-05 10:17:08 --> Language Class Initialized
INFO - 2023-12-05 10:17:08 --> Config Class Initialized
INFO - 2023-12-05 10:17:08 --> Loader Class Initialized
INFO - 2023-12-05 10:17:08 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:08 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:08 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:08 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:08 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:08 --> Controller Class Initialized
INFO - 2023-12-05 10:17:08 --> Final output sent to browser
DEBUG - 2023-12-05 10:17:08 --> Total execution time: 0.0965
INFO - 2023-12-05 10:17:13 --> Config Class Initialized
INFO - 2023-12-05 10:17:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:13 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:13 --> URI Class Initialized
INFO - 2023-12-05 10:17:13 --> Router Class Initialized
INFO - 2023-12-05 10:17:13 --> Output Class Initialized
INFO - 2023-12-05 10:17:13 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:13 --> Input Class Initialized
INFO - 2023-12-05 10:17:13 --> Language Class Initialized
INFO - 2023-12-05 10:17:13 --> Language Class Initialized
INFO - 2023-12-05 10:17:13 --> Config Class Initialized
INFO - 2023-12-05 10:17:13 --> Loader Class Initialized
INFO - 2023-12-05 10:17:13 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:13 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:13 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:13 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:13 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:13 --> Controller Class Initialized
INFO - 2023-12-05 10:17:13 --> Final output sent to browser
DEBUG - 2023-12-05 10:17:13 --> Total execution time: 0.0539
INFO - 2023-12-05 10:17:20 --> Config Class Initialized
INFO - 2023-12-05 10:17:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:20 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:20 --> URI Class Initialized
INFO - 2023-12-05 10:17:20 --> Router Class Initialized
INFO - 2023-12-05 10:17:20 --> Output Class Initialized
INFO - 2023-12-05 10:17:20 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:20 --> Input Class Initialized
INFO - 2023-12-05 10:17:20 --> Language Class Initialized
INFO - 2023-12-05 10:17:20 --> Language Class Initialized
INFO - 2023-12-05 10:17:20 --> Config Class Initialized
INFO - 2023-12-05 10:17:20 --> Loader Class Initialized
INFO - 2023-12-05 10:17:20 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:20 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:20 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:20 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:20 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:20 --> Controller Class Initialized
INFO - 2023-12-05 10:17:21 --> Final output sent to browser
DEBUG - 2023-12-05 10:17:21 --> Total execution time: 0.0551
INFO - 2023-12-05 10:17:21 --> Config Class Initialized
INFO - 2023-12-05 10:17:21 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:17:21 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:17:21 --> Utf8 Class Initialized
INFO - 2023-12-05 10:17:21 --> URI Class Initialized
INFO - 2023-12-05 10:17:21 --> Router Class Initialized
INFO - 2023-12-05 10:17:21 --> Output Class Initialized
INFO - 2023-12-05 10:17:21 --> Security Class Initialized
DEBUG - 2023-12-05 10:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:17:21 --> Input Class Initialized
INFO - 2023-12-05 10:17:21 --> Language Class Initialized
INFO - 2023-12-05 10:17:21 --> Language Class Initialized
INFO - 2023-12-05 10:17:21 --> Config Class Initialized
INFO - 2023-12-05 10:17:21 --> Loader Class Initialized
INFO - 2023-12-05 10:17:21 --> Helper loaded: url_helper
INFO - 2023-12-05 10:17:21 --> Helper loaded: file_helper
INFO - 2023-12-05 10:17:21 --> Helper loaded: form_helper
INFO - 2023-12-05 10:17:21 --> Helper loaded: my_helper
INFO - 2023-12-05 10:17:21 --> Database Driver Class Initialized
INFO - 2023-12-05 10:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:17:21 --> Controller Class Initialized
INFO - 2023-12-05 10:26:04 --> Config Class Initialized
INFO - 2023-12-05 10:26:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:04 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:04 --> URI Class Initialized
INFO - 2023-12-05 10:26:04 --> Router Class Initialized
INFO - 2023-12-05 10:26:04 --> Output Class Initialized
INFO - 2023-12-05 10:26:04 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:04 --> Input Class Initialized
INFO - 2023-12-05 10:26:04 --> Language Class Initialized
INFO - 2023-12-05 10:26:04 --> Language Class Initialized
INFO - 2023-12-05 10:26:04 --> Config Class Initialized
INFO - 2023-12-05 10:26:04 --> Loader Class Initialized
INFO - 2023-12-05 10:26:04 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:04 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:04 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:04 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:04 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:04 --> Controller Class Initialized
INFO - 2023-12-05 10:26:05 --> Config Class Initialized
INFO - 2023-12-05 10:26:05 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:05 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:05 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:05 --> URI Class Initialized
INFO - 2023-12-05 10:26:05 --> Router Class Initialized
INFO - 2023-12-05 10:26:05 --> Output Class Initialized
INFO - 2023-12-05 10:26:05 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:05 --> Input Class Initialized
INFO - 2023-12-05 10:26:05 --> Language Class Initialized
INFO - 2023-12-05 10:26:05 --> Language Class Initialized
INFO - 2023-12-05 10:26:05 --> Config Class Initialized
INFO - 2023-12-05 10:26:05 --> Loader Class Initialized
INFO - 2023-12-05 10:26:05 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:05 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:05 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:05 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:05 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:05 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 10:26:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:05 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:05 --> Total execution time: 0.0423
INFO - 2023-12-05 10:26:07 --> Config Class Initialized
INFO - 2023-12-05 10:26:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:07 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:07 --> URI Class Initialized
INFO - 2023-12-05 10:26:07 --> Router Class Initialized
INFO - 2023-12-05 10:26:07 --> Output Class Initialized
INFO - 2023-12-05 10:26:07 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:07 --> Input Class Initialized
INFO - 2023-12-05 10:26:07 --> Language Class Initialized
INFO - 2023-12-05 10:26:07 --> Language Class Initialized
INFO - 2023-12-05 10:26:07 --> Config Class Initialized
INFO - 2023-12-05 10:26:07 --> Loader Class Initialized
INFO - 2023-12-05 10:26:07 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:07 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:07 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:07 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:08 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:08 --> Controller Class Initialized
INFO - 2023-12-05 10:26:08 --> Helper loaded: cookie_helper
INFO - 2023-12-05 10:26:08 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:08 --> Total execution time: 0.1325
INFO - 2023-12-05 10:26:08 --> Config Class Initialized
INFO - 2023-12-05 10:26:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:08 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:08 --> URI Class Initialized
INFO - 2023-12-05 10:26:08 --> Router Class Initialized
INFO - 2023-12-05 10:26:08 --> Output Class Initialized
INFO - 2023-12-05 10:26:08 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:08 --> Input Class Initialized
INFO - 2023-12-05 10:26:08 --> Language Class Initialized
INFO - 2023-12-05 10:26:08 --> Language Class Initialized
INFO - 2023-12-05 10:26:08 --> Config Class Initialized
INFO - 2023-12-05 10:26:08 --> Loader Class Initialized
INFO - 2023-12-05 10:26:08 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:08 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:08 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:08 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:08 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:08 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 10:26:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:08 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:08 --> Total execution time: 0.0527
INFO - 2023-12-05 10:26:10 --> Config Class Initialized
INFO - 2023-12-05 10:26:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:10 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:10 --> URI Class Initialized
INFO - 2023-12-05 10:26:10 --> Router Class Initialized
INFO - 2023-12-05 10:26:10 --> Output Class Initialized
INFO - 2023-12-05 10:26:10 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:10 --> Input Class Initialized
INFO - 2023-12-05 10:26:10 --> Language Class Initialized
INFO - 2023-12-05 10:26:10 --> Language Class Initialized
INFO - 2023-12-05 10:26:10 --> Config Class Initialized
INFO - 2023-12-05 10:26:10 --> Loader Class Initialized
INFO - 2023-12-05 10:26:10 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:10 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:10 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:10 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:10 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:10 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 10:26:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:10 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:10 --> Total execution time: 0.0499
INFO - 2023-12-05 10:26:13 --> Config Class Initialized
INFO - 2023-12-05 10:26:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:13 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:13 --> URI Class Initialized
INFO - 2023-12-05 10:26:13 --> Router Class Initialized
INFO - 2023-12-05 10:26:13 --> Output Class Initialized
INFO - 2023-12-05 10:26:13 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:13 --> Input Class Initialized
INFO - 2023-12-05 10:26:13 --> Language Class Initialized
INFO - 2023-12-05 10:26:13 --> Language Class Initialized
INFO - 2023-12-05 10:26:13 --> Config Class Initialized
INFO - 2023-12-05 10:26:13 --> Loader Class Initialized
INFO - 2023-12-05 10:26:13 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:13 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:13 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:13 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:13 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:13 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 10:26:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:13 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:13 --> Total execution time: 0.1127
INFO - 2023-12-05 10:26:18 --> Config Class Initialized
INFO - 2023-12-05 10:26:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:18 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:18 --> URI Class Initialized
INFO - 2023-12-05 10:26:18 --> Router Class Initialized
INFO - 2023-12-05 10:26:18 --> Output Class Initialized
INFO - 2023-12-05 10:26:18 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:18 --> Input Class Initialized
INFO - 2023-12-05 10:26:18 --> Language Class Initialized
INFO - 2023-12-05 10:26:18 --> Language Class Initialized
INFO - 2023-12-05 10:26:18 --> Config Class Initialized
INFO - 2023-12-05 10:26:18 --> Loader Class Initialized
INFO - 2023-12-05 10:26:18 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:18 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:18 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:18 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:18 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:18 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-12-05 10:26:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:18 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:18 --> Total execution time: 0.0477
INFO - 2023-12-05 10:26:31 --> Config Class Initialized
INFO - 2023-12-05 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:31 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:31 --> URI Class Initialized
INFO - 2023-12-05 10:26:31 --> Router Class Initialized
INFO - 2023-12-05 10:26:31 --> Output Class Initialized
INFO - 2023-12-05 10:26:31 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:31 --> Input Class Initialized
INFO - 2023-12-05 10:26:31 --> Language Class Initialized
INFO - 2023-12-05 10:26:31 --> Language Class Initialized
INFO - 2023-12-05 10:26:31 --> Config Class Initialized
INFO - 2023-12-05 10:26:31 --> Loader Class Initialized
INFO - 2023-12-05 10:26:31 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:31 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:31 --> Controller Class Initialized
INFO - 2023-12-05 10:26:31 --> Config Class Initialized
INFO - 2023-12-05 10:26:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:31 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:31 --> URI Class Initialized
INFO - 2023-12-05 10:26:31 --> Router Class Initialized
INFO - 2023-12-05 10:26:31 --> Output Class Initialized
INFO - 2023-12-05 10:26:31 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:31 --> Input Class Initialized
INFO - 2023-12-05 10:26:31 --> Language Class Initialized
INFO - 2023-12-05 10:26:31 --> Language Class Initialized
INFO - 2023-12-05 10:26:31 --> Config Class Initialized
INFO - 2023-12-05 10:26:31 --> Loader Class Initialized
INFO - 2023-12-05 10:26:31 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:31 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:31 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:31 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 10:26:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:31 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:31 --> Total execution time: 0.0360
INFO - 2023-12-05 10:26:35 --> Config Class Initialized
INFO - 2023-12-05 10:26:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:35 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:35 --> URI Class Initialized
INFO - 2023-12-05 10:26:35 --> Router Class Initialized
INFO - 2023-12-05 10:26:35 --> Output Class Initialized
INFO - 2023-12-05 10:26:35 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:35 --> Input Class Initialized
INFO - 2023-12-05 10:26:35 --> Language Class Initialized
INFO - 2023-12-05 10:26:35 --> Language Class Initialized
INFO - 2023-12-05 10:26:35 --> Config Class Initialized
INFO - 2023-12-05 10:26:35 --> Loader Class Initialized
INFO - 2023-12-05 10:26:35 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:35 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:35 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:35 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:35 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:35 --> Controller Class Initialized
INFO - 2023-12-05 10:26:36 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:36 --> Total execution time: 0.3150
INFO - 2023-12-05 10:26:50 --> Config Class Initialized
INFO - 2023-12-05 10:26:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:50 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:50 --> URI Class Initialized
INFO - 2023-12-05 10:26:50 --> Router Class Initialized
INFO - 2023-12-05 10:26:50 --> Output Class Initialized
INFO - 2023-12-05 10:26:50 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:50 --> Input Class Initialized
INFO - 2023-12-05 10:26:50 --> Language Class Initialized
INFO - 2023-12-05 10:26:50 --> Language Class Initialized
INFO - 2023-12-05 10:26:50 --> Config Class Initialized
INFO - 2023-12-05 10:26:50 --> Loader Class Initialized
INFO - 2023-12-05 10:26:50 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:50 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:50 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:50 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:50 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:50 --> Controller Class Initialized
INFO - 2023-12-05 10:26:51 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:51 --> Total execution time: 0.0932
INFO - 2023-12-05 10:26:59 --> Config Class Initialized
INFO - 2023-12-05 10:26:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:26:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:26:59 --> Utf8 Class Initialized
INFO - 2023-12-05 10:26:59 --> URI Class Initialized
INFO - 2023-12-05 10:26:59 --> Router Class Initialized
INFO - 2023-12-05 10:26:59 --> Output Class Initialized
INFO - 2023-12-05 10:26:59 --> Security Class Initialized
DEBUG - 2023-12-05 10:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:26:59 --> Input Class Initialized
INFO - 2023-12-05 10:26:59 --> Language Class Initialized
INFO - 2023-12-05 10:26:59 --> Language Class Initialized
INFO - 2023-12-05 10:26:59 --> Config Class Initialized
INFO - 2023-12-05 10:26:59 --> Loader Class Initialized
INFO - 2023-12-05 10:26:59 --> Helper loaded: url_helper
INFO - 2023-12-05 10:26:59 --> Helper loaded: file_helper
INFO - 2023-12-05 10:26:59 --> Helper loaded: form_helper
INFO - 2023-12-05 10:26:59 --> Helper loaded: my_helper
INFO - 2023-12-05 10:26:59 --> Database Driver Class Initialized
INFO - 2023-12-05 10:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:26:59 --> Controller Class Initialized
DEBUG - 2023-12-05 10:26:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 10:26:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:26:59 --> Final output sent to browser
DEBUG - 2023-12-05 10:26:59 --> Total execution time: 0.1462
INFO - 2023-12-05 10:27:01 --> Config Class Initialized
INFO - 2023-12-05 10:27:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:01 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:01 --> URI Class Initialized
INFO - 2023-12-05 10:27:01 --> Router Class Initialized
INFO - 2023-12-05 10:27:01 --> Output Class Initialized
INFO - 2023-12-05 10:27:01 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:01 --> Input Class Initialized
INFO - 2023-12-05 10:27:01 --> Language Class Initialized
INFO - 2023-12-05 10:27:01 --> Language Class Initialized
INFO - 2023-12-05 10:27:01 --> Config Class Initialized
INFO - 2023-12-05 10:27:01 --> Loader Class Initialized
INFO - 2023-12-05 10:27:01 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:01 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:01 --> Controller Class Initialized
DEBUG - 2023-12-05 10:27:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 10:27:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:27:01 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:01 --> Total execution time: 0.0993
INFO - 2023-12-05 10:27:01 --> Config Class Initialized
INFO - 2023-12-05 10:27:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:01 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:01 --> URI Class Initialized
INFO - 2023-12-05 10:27:01 --> Router Class Initialized
INFO - 2023-12-05 10:27:01 --> Output Class Initialized
INFO - 2023-12-05 10:27:01 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:01 --> Input Class Initialized
INFO - 2023-12-05 10:27:01 --> Language Class Initialized
INFO - 2023-12-05 10:27:01 --> Language Class Initialized
INFO - 2023-12-05 10:27:01 --> Config Class Initialized
INFO - 2023-12-05 10:27:01 --> Loader Class Initialized
INFO - 2023-12-05 10:27:01 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:01 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:01 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:01 --> Controller Class Initialized
INFO - 2023-12-05 10:27:04 --> Config Class Initialized
INFO - 2023-12-05 10:27:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:04 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:04 --> URI Class Initialized
INFO - 2023-12-05 10:27:04 --> Router Class Initialized
INFO - 2023-12-05 10:27:04 --> Output Class Initialized
INFO - 2023-12-05 10:27:04 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:04 --> Input Class Initialized
INFO - 2023-12-05 10:27:04 --> Language Class Initialized
INFO - 2023-12-05 10:27:04 --> Language Class Initialized
INFO - 2023-12-05 10:27:04 --> Config Class Initialized
INFO - 2023-12-05 10:27:04 --> Loader Class Initialized
INFO - 2023-12-05 10:27:04 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:04 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:04 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:04 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:04 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:04 --> Controller Class Initialized
INFO - 2023-12-05 10:27:04 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:04 --> Total execution time: 0.1509
INFO - 2023-12-05 10:27:08 --> Config Class Initialized
INFO - 2023-12-05 10:27:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:08 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:08 --> URI Class Initialized
INFO - 2023-12-05 10:27:08 --> Router Class Initialized
INFO - 2023-12-05 10:27:08 --> Output Class Initialized
INFO - 2023-12-05 10:27:08 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:08 --> Input Class Initialized
INFO - 2023-12-05 10:27:08 --> Language Class Initialized
INFO - 2023-12-05 10:27:08 --> Language Class Initialized
INFO - 2023-12-05 10:27:08 --> Config Class Initialized
INFO - 2023-12-05 10:27:08 --> Loader Class Initialized
INFO - 2023-12-05 10:27:08 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:08 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:08 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:08 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:08 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:08 --> Controller Class Initialized
INFO - 2023-12-05 10:27:08 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:08 --> Total execution time: 0.0378
INFO - 2023-12-05 10:27:10 --> Config Class Initialized
INFO - 2023-12-05 10:27:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:10 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:10 --> URI Class Initialized
INFO - 2023-12-05 10:27:10 --> Router Class Initialized
INFO - 2023-12-05 10:27:10 --> Output Class Initialized
INFO - 2023-12-05 10:27:10 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:10 --> Input Class Initialized
INFO - 2023-12-05 10:27:10 --> Language Class Initialized
INFO - 2023-12-05 10:27:10 --> Language Class Initialized
INFO - 2023-12-05 10:27:10 --> Config Class Initialized
INFO - 2023-12-05 10:27:10 --> Loader Class Initialized
INFO - 2023-12-05 10:27:10 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:10 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:10 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:10 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:10 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:10 --> Controller Class Initialized
INFO - 2023-12-05 10:27:10 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:10 --> Total execution time: 0.0634
INFO - 2023-12-05 10:27:11 --> Config Class Initialized
INFO - 2023-12-05 10:27:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:11 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:11 --> URI Class Initialized
INFO - 2023-12-05 10:27:11 --> Router Class Initialized
INFO - 2023-12-05 10:27:11 --> Output Class Initialized
INFO - 2023-12-05 10:27:11 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:11 --> Input Class Initialized
INFO - 2023-12-05 10:27:11 --> Language Class Initialized
INFO - 2023-12-05 10:27:11 --> Language Class Initialized
INFO - 2023-12-05 10:27:11 --> Config Class Initialized
INFO - 2023-12-05 10:27:11 --> Loader Class Initialized
INFO - 2023-12-05 10:27:11 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:11 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:11 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:11 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:11 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:11 --> Controller Class Initialized
INFO - 2023-12-05 10:27:11 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:11 --> Total execution time: 0.0588
INFO - 2023-12-05 10:27:13 --> Config Class Initialized
INFO - 2023-12-05 10:27:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:13 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:13 --> URI Class Initialized
INFO - 2023-12-05 10:27:13 --> Router Class Initialized
INFO - 2023-12-05 10:27:13 --> Output Class Initialized
INFO - 2023-12-05 10:27:13 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:13 --> Input Class Initialized
INFO - 2023-12-05 10:27:13 --> Language Class Initialized
INFO - 2023-12-05 10:27:13 --> Language Class Initialized
INFO - 2023-12-05 10:27:13 --> Config Class Initialized
INFO - 2023-12-05 10:27:13 --> Loader Class Initialized
INFO - 2023-12-05 10:27:13 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:13 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:13 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:13 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:13 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:13 --> Controller Class Initialized
INFO - 2023-12-05 10:27:14 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:14 --> Total execution time: 0.2694
INFO - 2023-12-05 10:27:18 --> Config Class Initialized
INFO - 2023-12-05 10:27:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:18 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:18 --> URI Class Initialized
INFO - 2023-12-05 10:27:18 --> Router Class Initialized
INFO - 2023-12-05 10:27:18 --> Output Class Initialized
INFO - 2023-12-05 10:27:18 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:18 --> Input Class Initialized
INFO - 2023-12-05 10:27:18 --> Language Class Initialized
INFO - 2023-12-05 10:27:18 --> Language Class Initialized
INFO - 2023-12-05 10:27:18 --> Config Class Initialized
INFO - 2023-12-05 10:27:18 --> Loader Class Initialized
INFO - 2023-12-05 10:27:18 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:18 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:18 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:18 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:18 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:18 --> Controller Class Initialized
INFO - 2023-12-05 10:27:18 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:18 --> Total execution time: 0.0415
INFO - 2023-12-05 10:27:22 --> Config Class Initialized
INFO - 2023-12-05 10:27:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:27:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:27:22 --> Utf8 Class Initialized
INFO - 2023-12-05 10:27:22 --> URI Class Initialized
INFO - 2023-12-05 10:27:22 --> Router Class Initialized
INFO - 2023-12-05 10:27:22 --> Output Class Initialized
INFO - 2023-12-05 10:27:22 --> Security Class Initialized
DEBUG - 2023-12-05 10:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:27:22 --> Input Class Initialized
INFO - 2023-12-05 10:27:22 --> Language Class Initialized
INFO - 2023-12-05 10:27:22 --> Language Class Initialized
INFO - 2023-12-05 10:27:22 --> Config Class Initialized
INFO - 2023-12-05 10:27:22 --> Loader Class Initialized
INFO - 2023-12-05 10:27:22 --> Helper loaded: url_helper
INFO - 2023-12-05 10:27:22 --> Helper loaded: file_helper
INFO - 2023-12-05 10:27:22 --> Helper loaded: form_helper
INFO - 2023-12-05 10:27:22 --> Helper loaded: my_helper
INFO - 2023-12-05 10:27:22 --> Database Driver Class Initialized
INFO - 2023-12-05 10:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:27:22 --> Controller Class Initialized
INFO - 2023-12-05 10:27:22 --> Final output sent to browser
DEBUG - 2023-12-05 10:27:22 --> Total execution time: 0.0455
INFO - 2023-12-05 10:29:06 --> Config Class Initialized
INFO - 2023-12-05 10:29:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:29:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:29:06 --> Utf8 Class Initialized
INFO - 2023-12-05 10:29:06 --> URI Class Initialized
INFO - 2023-12-05 10:29:06 --> Router Class Initialized
INFO - 2023-12-05 10:29:06 --> Output Class Initialized
INFO - 2023-12-05 10:29:06 --> Security Class Initialized
DEBUG - 2023-12-05 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:29:06 --> Input Class Initialized
INFO - 2023-12-05 10:29:06 --> Language Class Initialized
INFO - 2023-12-05 10:29:06 --> Language Class Initialized
INFO - 2023-12-05 10:29:06 --> Config Class Initialized
INFO - 2023-12-05 10:29:06 --> Loader Class Initialized
INFO - 2023-12-05 10:29:06 --> Helper loaded: url_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: file_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: form_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: my_helper
INFO - 2023-12-05 10:29:06 --> Database Driver Class Initialized
INFO - 2023-12-05 10:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:29:06 --> Controller Class Initialized
INFO - 2023-12-05 10:29:06 --> Final output sent to browser
DEBUG - 2023-12-05 10:29:06 --> Total execution time: 0.0758
INFO - 2023-12-05 10:29:06 --> Config Class Initialized
INFO - 2023-12-05 10:29:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:29:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:29:06 --> Utf8 Class Initialized
INFO - 2023-12-05 10:29:06 --> URI Class Initialized
INFO - 2023-12-05 10:29:06 --> Router Class Initialized
INFO - 2023-12-05 10:29:06 --> Output Class Initialized
INFO - 2023-12-05 10:29:06 --> Security Class Initialized
DEBUG - 2023-12-05 10:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:29:06 --> Input Class Initialized
INFO - 2023-12-05 10:29:06 --> Language Class Initialized
INFO - 2023-12-05 10:29:06 --> Language Class Initialized
INFO - 2023-12-05 10:29:06 --> Config Class Initialized
INFO - 2023-12-05 10:29:06 --> Loader Class Initialized
INFO - 2023-12-05 10:29:06 --> Helper loaded: url_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: file_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: form_helper
INFO - 2023-12-05 10:29:06 --> Helper loaded: my_helper
INFO - 2023-12-05 10:29:06 --> Database Driver Class Initialized
INFO - 2023-12-05 10:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:29:06 --> Controller Class Initialized
INFO - 2023-12-05 10:41:16 --> Config Class Initialized
INFO - 2023-12-05 10:41:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:16 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:16 --> URI Class Initialized
INFO - 2023-12-05 10:41:16 --> Router Class Initialized
INFO - 2023-12-05 10:41:16 --> Output Class Initialized
INFO - 2023-12-05 10:41:16 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:16 --> Input Class Initialized
INFO - 2023-12-05 10:41:16 --> Language Class Initialized
INFO - 2023-12-05 10:41:16 --> Language Class Initialized
INFO - 2023-12-05 10:41:16 --> Config Class Initialized
INFO - 2023-12-05 10:41:16 --> Loader Class Initialized
INFO - 2023-12-05 10:41:16 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:16 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:16 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:16 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:16 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:16 --> Controller Class Initialized
INFO - 2023-12-05 10:41:16 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:16 --> Total execution time: 0.0991
INFO - 2023-12-05 10:41:23 --> Config Class Initialized
INFO - 2023-12-05 10:41:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:23 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:23 --> URI Class Initialized
INFO - 2023-12-05 10:41:23 --> Router Class Initialized
INFO - 2023-12-05 10:41:23 --> Output Class Initialized
INFO - 2023-12-05 10:41:23 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:23 --> Input Class Initialized
INFO - 2023-12-05 10:41:23 --> Language Class Initialized
INFO - 2023-12-05 10:41:23 --> Language Class Initialized
INFO - 2023-12-05 10:41:23 --> Config Class Initialized
INFO - 2023-12-05 10:41:23 --> Loader Class Initialized
INFO - 2023-12-05 10:41:23 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:23 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:23 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:23 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:23 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:23 --> Controller Class Initialized
INFO - 2023-12-05 10:41:24 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:24 --> Total execution time: 0.2706
INFO - 2023-12-05 10:41:26 --> Config Class Initialized
INFO - 2023-12-05 10:41:26 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:26 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:26 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:26 --> URI Class Initialized
INFO - 2023-12-05 10:41:26 --> Router Class Initialized
INFO - 2023-12-05 10:41:26 --> Output Class Initialized
INFO - 2023-12-05 10:41:26 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:26 --> Input Class Initialized
INFO - 2023-12-05 10:41:26 --> Language Class Initialized
INFO - 2023-12-05 10:41:26 --> Language Class Initialized
INFO - 2023-12-05 10:41:26 --> Config Class Initialized
INFO - 2023-12-05 10:41:26 --> Loader Class Initialized
INFO - 2023-12-05 10:41:26 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:26 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:26 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:26 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:26 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:26 --> Controller Class Initialized
INFO - 2023-12-05 10:41:26 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:26 --> Total execution time: 0.0339
INFO - 2023-12-05 10:41:28 --> Config Class Initialized
INFO - 2023-12-05 10:41:28 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:28 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:28 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:28 --> URI Class Initialized
INFO - 2023-12-05 10:41:28 --> Router Class Initialized
INFO - 2023-12-05 10:41:28 --> Output Class Initialized
INFO - 2023-12-05 10:41:28 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:28 --> Input Class Initialized
INFO - 2023-12-05 10:41:28 --> Language Class Initialized
INFO - 2023-12-05 10:41:28 --> Language Class Initialized
INFO - 2023-12-05 10:41:28 --> Config Class Initialized
INFO - 2023-12-05 10:41:28 --> Loader Class Initialized
INFO - 2023-12-05 10:41:28 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:28 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:28 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:28 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:28 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:28 --> Controller Class Initialized
INFO - 2023-12-05 10:41:28 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:28 --> Total execution time: 0.0621
INFO - 2023-12-05 10:41:40 --> Config Class Initialized
INFO - 2023-12-05 10:41:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:40 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:40 --> URI Class Initialized
INFO - 2023-12-05 10:41:40 --> Router Class Initialized
INFO - 2023-12-05 10:41:40 --> Output Class Initialized
INFO - 2023-12-05 10:41:40 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:40 --> Input Class Initialized
INFO - 2023-12-05 10:41:40 --> Language Class Initialized
INFO - 2023-12-05 10:41:40 --> Language Class Initialized
INFO - 2023-12-05 10:41:40 --> Config Class Initialized
INFO - 2023-12-05 10:41:40 --> Loader Class Initialized
INFO - 2023-12-05 10:41:40 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:40 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:40 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:40 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:40 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:40 --> Controller Class Initialized
INFO - 2023-12-05 10:41:40 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:40 --> Total execution time: 0.0450
INFO - 2023-12-05 10:41:42 --> Config Class Initialized
INFO - 2023-12-05 10:41:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:42 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:42 --> URI Class Initialized
INFO - 2023-12-05 10:41:42 --> Router Class Initialized
INFO - 2023-12-05 10:41:42 --> Output Class Initialized
INFO - 2023-12-05 10:41:42 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:42 --> Input Class Initialized
INFO - 2023-12-05 10:41:42 --> Language Class Initialized
INFO - 2023-12-05 10:41:42 --> Language Class Initialized
INFO - 2023-12-05 10:41:42 --> Config Class Initialized
INFO - 2023-12-05 10:41:42 --> Loader Class Initialized
INFO - 2023-12-05 10:41:42 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:42 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:42 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:42 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:42 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:42 --> Controller Class Initialized
INFO - 2023-12-05 10:41:42 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:42 --> Total execution time: 0.1200
INFO - 2023-12-05 10:41:53 --> Config Class Initialized
INFO - 2023-12-05 10:41:53 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:53 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:53 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:53 --> URI Class Initialized
INFO - 2023-12-05 10:41:53 --> Router Class Initialized
INFO - 2023-12-05 10:41:53 --> Output Class Initialized
INFO - 2023-12-05 10:41:53 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:53 --> Input Class Initialized
INFO - 2023-12-05 10:41:53 --> Language Class Initialized
INFO - 2023-12-05 10:41:53 --> Language Class Initialized
INFO - 2023-12-05 10:41:53 --> Config Class Initialized
INFO - 2023-12-05 10:41:53 --> Loader Class Initialized
INFO - 2023-12-05 10:41:53 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:53 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:53 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:53 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:53 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:53 --> Controller Class Initialized
INFO - 2023-12-05 10:41:53 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:53 --> Total execution time: 0.0455
INFO - 2023-12-05 10:41:56 --> Config Class Initialized
INFO - 2023-12-05 10:41:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:41:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:41:56 --> Utf8 Class Initialized
INFO - 2023-12-05 10:41:56 --> URI Class Initialized
INFO - 2023-12-05 10:41:56 --> Router Class Initialized
INFO - 2023-12-05 10:41:56 --> Output Class Initialized
INFO - 2023-12-05 10:41:56 --> Security Class Initialized
DEBUG - 2023-12-05 10:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:41:56 --> Input Class Initialized
INFO - 2023-12-05 10:41:56 --> Language Class Initialized
INFO - 2023-12-05 10:41:56 --> Language Class Initialized
INFO - 2023-12-05 10:41:56 --> Config Class Initialized
INFO - 2023-12-05 10:41:56 --> Loader Class Initialized
INFO - 2023-12-05 10:41:56 --> Helper loaded: url_helper
INFO - 2023-12-05 10:41:56 --> Helper loaded: file_helper
INFO - 2023-12-05 10:41:56 --> Helper loaded: form_helper
INFO - 2023-12-05 10:41:56 --> Helper loaded: my_helper
INFO - 2023-12-05 10:41:56 --> Database Driver Class Initialized
INFO - 2023-12-05 10:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:41:56 --> Controller Class Initialized
INFO - 2023-12-05 10:41:56 --> Final output sent to browser
DEBUG - 2023-12-05 10:41:56 --> Total execution time: 0.4042
INFO - 2023-12-05 10:53:22 --> Config Class Initialized
INFO - 2023-12-05 10:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:22 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:22 --> URI Class Initialized
INFO - 2023-12-05 10:53:22 --> Router Class Initialized
INFO - 2023-12-05 10:53:22 --> Output Class Initialized
INFO - 2023-12-05 10:53:22 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:22 --> Input Class Initialized
INFO - 2023-12-05 10:53:22 --> Language Class Initialized
INFO - 2023-12-05 10:53:22 --> Language Class Initialized
INFO - 2023-12-05 10:53:22 --> Config Class Initialized
INFO - 2023-12-05 10:53:22 --> Loader Class Initialized
INFO - 2023-12-05 10:53:22 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: my_helper
INFO - 2023-12-05 10:53:22 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:22 --> Controller Class Initialized
DEBUG - 2023-12-05 10:53:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 10:53:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 10:53:22 --> Final output sent to browser
DEBUG - 2023-12-05 10:53:22 --> Total execution time: 0.0930
INFO - 2023-12-05 10:53:22 --> Config Class Initialized
INFO - 2023-12-05 10:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 10:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 10:53:22 --> Utf8 Class Initialized
INFO - 2023-12-05 10:53:22 --> URI Class Initialized
INFO - 2023-12-05 10:53:22 --> Router Class Initialized
INFO - 2023-12-05 10:53:22 --> Output Class Initialized
INFO - 2023-12-05 10:53:22 --> Security Class Initialized
DEBUG - 2023-12-05 10:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 10:53:22 --> Input Class Initialized
INFO - 2023-12-05 10:53:22 --> Language Class Initialized
INFO - 2023-12-05 10:53:22 --> Language Class Initialized
INFO - 2023-12-05 10:53:22 --> Config Class Initialized
INFO - 2023-12-05 10:53:22 --> Loader Class Initialized
INFO - 2023-12-05 10:53:22 --> Helper loaded: url_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: file_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: form_helper
INFO - 2023-12-05 10:53:22 --> Helper loaded: my_helper
INFO - 2023-12-05 10:53:22 --> Database Driver Class Initialized
INFO - 2023-12-05 10:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 10:53:22 --> Controller Class Initialized
INFO - 2023-12-05 11:13:16 --> Config Class Initialized
INFO - 2023-12-05 11:13:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 11:13:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 11:13:16 --> Utf8 Class Initialized
INFO - 2023-12-05 11:13:16 --> URI Class Initialized
INFO - 2023-12-05 11:13:16 --> Router Class Initialized
INFO - 2023-12-05 11:13:16 --> Output Class Initialized
INFO - 2023-12-05 11:13:16 --> Security Class Initialized
DEBUG - 2023-12-05 11:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 11:13:16 --> Input Class Initialized
INFO - 2023-12-05 11:13:16 --> Language Class Initialized
INFO - 2023-12-05 11:13:16 --> Language Class Initialized
INFO - 2023-12-05 11:13:16 --> Config Class Initialized
INFO - 2023-12-05 11:13:16 --> Loader Class Initialized
INFO - 2023-12-05 11:13:16 --> Helper loaded: url_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: file_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: form_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: my_helper
INFO - 2023-12-05 11:13:16 --> Database Driver Class Initialized
INFO - 2023-12-05 11:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 11:13:16 --> Controller Class Initialized
DEBUG - 2023-12-05 11:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 11:13:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 11:13:16 --> Final output sent to browser
DEBUG - 2023-12-05 11:13:16 --> Total execution time: 0.0828
INFO - 2023-12-05 11:13:16 --> Config Class Initialized
INFO - 2023-12-05 11:13:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 11:13:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 11:13:16 --> Utf8 Class Initialized
INFO - 2023-12-05 11:13:16 --> URI Class Initialized
INFO - 2023-12-05 11:13:16 --> Router Class Initialized
INFO - 2023-12-05 11:13:16 --> Output Class Initialized
INFO - 2023-12-05 11:13:16 --> Security Class Initialized
DEBUG - 2023-12-05 11:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 11:13:16 --> Input Class Initialized
INFO - 2023-12-05 11:13:16 --> Language Class Initialized
INFO - 2023-12-05 11:13:16 --> Language Class Initialized
INFO - 2023-12-05 11:13:16 --> Config Class Initialized
INFO - 2023-12-05 11:13:16 --> Loader Class Initialized
INFO - 2023-12-05 11:13:16 --> Helper loaded: url_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: file_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: form_helper
INFO - 2023-12-05 11:13:16 --> Helper loaded: my_helper
INFO - 2023-12-05 11:13:16 --> Database Driver Class Initialized
INFO - 2023-12-05 11:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 11:13:17 --> Controller Class Initialized
INFO - 2023-12-05 13:52:55 --> Config Class Initialized
INFO - 2023-12-05 13:52:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:52:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:52:55 --> Utf8 Class Initialized
INFO - 2023-12-05 13:52:55 --> URI Class Initialized
DEBUG - 2023-12-05 13:52:55 --> No URI present. Default controller set.
INFO - 2023-12-05 13:52:55 --> Router Class Initialized
INFO - 2023-12-05 13:52:55 --> Output Class Initialized
INFO - 2023-12-05 13:52:55 --> Security Class Initialized
DEBUG - 2023-12-05 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:52:55 --> Input Class Initialized
INFO - 2023-12-05 13:52:55 --> Language Class Initialized
INFO - 2023-12-05 13:52:55 --> Language Class Initialized
INFO - 2023-12-05 13:52:55 --> Config Class Initialized
INFO - 2023-12-05 13:52:55 --> Loader Class Initialized
INFO - 2023-12-05 13:52:55 --> Helper loaded: url_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: file_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: form_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: my_helper
INFO - 2023-12-05 13:52:55 --> Database Driver Class Initialized
INFO - 2023-12-05 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:52:55 --> Controller Class Initialized
INFO - 2023-12-05 13:52:55 --> Config Class Initialized
INFO - 2023-12-05 13:52:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:52:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:52:55 --> Utf8 Class Initialized
INFO - 2023-12-05 13:52:55 --> URI Class Initialized
INFO - 2023-12-05 13:52:55 --> Router Class Initialized
INFO - 2023-12-05 13:52:55 --> Output Class Initialized
INFO - 2023-12-05 13:52:55 --> Security Class Initialized
DEBUG - 2023-12-05 13:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:52:55 --> Input Class Initialized
INFO - 2023-12-05 13:52:55 --> Language Class Initialized
INFO - 2023-12-05 13:52:55 --> Language Class Initialized
INFO - 2023-12-05 13:52:55 --> Config Class Initialized
INFO - 2023-12-05 13:52:55 --> Loader Class Initialized
INFO - 2023-12-05 13:52:55 --> Helper loaded: url_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: file_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: form_helper
INFO - 2023-12-05 13:52:55 --> Helper loaded: my_helper
INFO - 2023-12-05 13:52:55 --> Database Driver Class Initialized
INFO - 2023-12-05 13:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:52:55 --> Controller Class Initialized
DEBUG - 2023-12-05 13:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 13:52:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:52:55 --> Final output sent to browser
DEBUG - 2023-12-05 13:52:55 --> Total execution time: 0.0903
INFO - 2023-12-05 13:53:07 --> Config Class Initialized
INFO - 2023-12-05 13:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:53:07 --> Utf8 Class Initialized
INFO - 2023-12-05 13:53:07 --> URI Class Initialized
INFO - 2023-12-05 13:53:07 --> Router Class Initialized
INFO - 2023-12-05 13:53:07 --> Output Class Initialized
INFO - 2023-12-05 13:53:07 --> Security Class Initialized
DEBUG - 2023-12-05 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:53:07 --> Input Class Initialized
INFO - 2023-12-05 13:53:07 --> Language Class Initialized
INFO - 2023-12-05 13:53:07 --> Language Class Initialized
INFO - 2023-12-05 13:53:07 --> Config Class Initialized
INFO - 2023-12-05 13:53:07 --> Loader Class Initialized
INFO - 2023-12-05 13:53:07 --> Helper loaded: url_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: file_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: form_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: my_helper
INFO - 2023-12-05 13:53:07 --> Database Driver Class Initialized
INFO - 2023-12-05 13:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:53:07 --> Controller Class Initialized
INFO - 2023-12-05 13:53:07 --> Helper loaded: cookie_helper
INFO - 2023-12-05 13:53:07 --> Final output sent to browser
DEBUG - 2023-12-05 13:53:07 --> Total execution time: 0.2197
INFO - 2023-12-05 13:53:07 --> Config Class Initialized
INFO - 2023-12-05 13:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:53:07 --> Utf8 Class Initialized
INFO - 2023-12-05 13:53:07 --> URI Class Initialized
INFO - 2023-12-05 13:53:07 --> Router Class Initialized
INFO - 2023-12-05 13:53:07 --> Output Class Initialized
INFO - 2023-12-05 13:53:07 --> Security Class Initialized
DEBUG - 2023-12-05 13:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:53:07 --> Input Class Initialized
INFO - 2023-12-05 13:53:07 --> Language Class Initialized
INFO - 2023-12-05 13:53:07 --> Language Class Initialized
INFO - 2023-12-05 13:53:07 --> Config Class Initialized
INFO - 2023-12-05 13:53:07 --> Loader Class Initialized
INFO - 2023-12-05 13:53:07 --> Helper loaded: url_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: file_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: form_helper
INFO - 2023-12-05 13:53:07 --> Helper loaded: my_helper
INFO - 2023-12-05 13:53:07 --> Database Driver Class Initialized
INFO - 2023-12-05 13:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:53:07 --> Controller Class Initialized
DEBUG - 2023-12-05 13:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 13:53:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:53:07 --> Final output sent to browser
DEBUG - 2023-12-05 13:53:07 --> Total execution time: 0.0700
INFO - 2023-12-05 13:53:10 --> Config Class Initialized
INFO - 2023-12-05 13:53:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:53:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:53:10 --> Utf8 Class Initialized
INFO - 2023-12-05 13:53:10 --> URI Class Initialized
INFO - 2023-12-05 13:53:10 --> Router Class Initialized
INFO - 2023-12-05 13:53:10 --> Output Class Initialized
INFO - 2023-12-05 13:53:10 --> Security Class Initialized
DEBUG - 2023-12-05 13:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:53:10 --> Input Class Initialized
INFO - 2023-12-05 13:53:10 --> Language Class Initialized
INFO - 2023-12-05 13:53:10 --> Language Class Initialized
INFO - 2023-12-05 13:53:10 --> Config Class Initialized
INFO - 2023-12-05 13:53:10 --> Loader Class Initialized
INFO - 2023-12-05 13:53:10 --> Helper loaded: url_helper
INFO - 2023-12-05 13:53:10 --> Helper loaded: file_helper
INFO - 2023-12-05 13:53:10 --> Helper loaded: form_helper
INFO - 2023-12-05 13:53:10 --> Helper loaded: my_helper
INFO - 2023-12-05 13:53:10 --> Database Driver Class Initialized
INFO - 2023-12-05 13:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:53:10 --> Controller Class Initialized
DEBUG - 2023-12-05 13:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-05 13:53:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:53:10 --> Final output sent to browser
DEBUG - 2023-12-05 13:53:10 --> Total execution time: 0.1195
INFO - 2023-12-05 13:53:12 --> Config Class Initialized
INFO - 2023-12-05 13:53:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:53:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:53:12 --> Utf8 Class Initialized
INFO - 2023-12-05 13:53:12 --> URI Class Initialized
INFO - 2023-12-05 13:53:12 --> Router Class Initialized
INFO - 2023-12-05 13:53:12 --> Output Class Initialized
INFO - 2023-12-05 13:53:12 --> Security Class Initialized
DEBUG - 2023-12-05 13:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:53:12 --> Input Class Initialized
INFO - 2023-12-05 13:53:12 --> Language Class Initialized
INFO - 2023-12-05 13:53:12 --> Language Class Initialized
INFO - 2023-12-05 13:53:12 --> Config Class Initialized
INFO - 2023-12-05 13:53:12 --> Loader Class Initialized
INFO - 2023-12-05 13:53:12 --> Helper loaded: url_helper
INFO - 2023-12-05 13:53:12 --> Helper loaded: file_helper
INFO - 2023-12-05 13:53:12 --> Helper loaded: form_helper
INFO - 2023-12-05 13:53:12 --> Helper loaded: my_helper
INFO - 2023-12-05 13:53:12 --> Database Driver Class Initialized
INFO - 2023-12-05 13:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:53:12 --> Controller Class Initialized
DEBUG - 2023-12-05 13:53:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-05 13:53:15 --> Final output sent to browser
DEBUG - 2023-12-05 13:53:15 --> Total execution time: 2.8948
INFO - 2023-12-05 13:54:34 --> Config Class Initialized
INFO - 2023-12-05 13:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:54:34 --> Utf8 Class Initialized
INFO - 2023-12-05 13:54:34 --> URI Class Initialized
INFO - 2023-12-05 13:54:34 --> Router Class Initialized
INFO - 2023-12-05 13:54:34 --> Output Class Initialized
INFO - 2023-12-05 13:54:34 --> Security Class Initialized
DEBUG - 2023-12-05 13:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:54:34 --> Input Class Initialized
INFO - 2023-12-05 13:54:34 --> Language Class Initialized
INFO - 2023-12-05 13:54:34 --> Language Class Initialized
INFO - 2023-12-05 13:54:34 --> Config Class Initialized
INFO - 2023-12-05 13:54:34 --> Loader Class Initialized
INFO - 2023-12-05 13:54:34 --> Helper loaded: url_helper
INFO - 2023-12-05 13:54:34 --> Helper loaded: file_helper
INFO - 2023-12-05 13:54:34 --> Helper loaded: form_helper
INFO - 2023-12-05 13:54:34 --> Helper loaded: my_helper
INFO - 2023-12-05 13:54:34 --> Database Driver Class Initialized
INFO - 2023-12-05 13:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:54:34 --> Controller Class Initialized
DEBUG - 2023-12-05 13:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-05 13:54:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:54:34 --> Final output sent to browser
DEBUG - 2023-12-05 13:54:34 --> Total execution time: 0.4469
INFO - 2023-12-05 13:56:03 --> Config Class Initialized
INFO - 2023-12-05 13:56:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:56:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:56:03 --> Utf8 Class Initialized
INFO - 2023-12-05 13:56:03 --> URI Class Initialized
INFO - 2023-12-05 13:56:03 --> Router Class Initialized
INFO - 2023-12-05 13:56:03 --> Output Class Initialized
INFO - 2023-12-05 13:56:03 --> Security Class Initialized
DEBUG - 2023-12-05 13:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:56:03 --> Input Class Initialized
INFO - 2023-12-05 13:56:03 --> Language Class Initialized
INFO - 2023-12-05 13:56:03 --> Language Class Initialized
INFO - 2023-12-05 13:56:03 --> Config Class Initialized
INFO - 2023-12-05 13:56:03 --> Loader Class Initialized
INFO - 2023-12-05 13:56:03 --> Helper loaded: url_helper
INFO - 2023-12-05 13:56:03 --> Helper loaded: file_helper
INFO - 2023-12-05 13:56:03 --> Helper loaded: form_helper
INFO - 2023-12-05 13:56:03 --> Helper loaded: my_helper
INFO - 2023-12-05 13:56:03 --> Database Driver Class Initialized
INFO - 2023-12-05 13:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:56:03 --> Controller Class Initialized
DEBUG - 2023-12-05 13:56:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-05 13:56:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:56:03 --> Final output sent to browser
DEBUG - 2023-12-05 13:56:03 --> Total execution time: 0.0634
INFO - 2023-12-05 13:56:06 --> Config Class Initialized
INFO - 2023-12-05 13:56:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:56:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:56:06 --> Utf8 Class Initialized
INFO - 2023-12-05 13:56:06 --> URI Class Initialized
INFO - 2023-12-05 13:56:06 --> Router Class Initialized
INFO - 2023-12-05 13:56:06 --> Output Class Initialized
INFO - 2023-12-05 13:56:06 --> Security Class Initialized
DEBUG - 2023-12-05 13:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:56:06 --> Input Class Initialized
INFO - 2023-12-05 13:56:06 --> Language Class Initialized
INFO - 2023-12-05 13:56:06 --> Language Class Initialized
INFO - 2023-12-05 13:56:06 --> Config Class Initialized
INFO - 2023-12-05 13:56:06 --> Loader Class Initialized
INFO - 2023-12-05 13:56:06 --> Helper loaded: url_helper
INFO - 2023-12-05 13:56:06 --> Helper loaded: file_helper
INFO - 2023-12-05 13:56:06 --> Helper loaded: form_helper
INFO - 2023-12-05 13:56:06 --> Helper loaded: my_helper
INFO - 2023-12-05 13:56:07 --> Database Driver Class Initialized
INFO - 2023-12-05 13:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:56:07 --> Controller Class Initialized
DEBUG - 2023-12-05 13:56:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-05 13:56:12 --> Final output sent to browser
DEBUG - 2023-12-05 13:56:12 --> Total execution time: 5.7840
INFO - 2023-12-05 13:56:55 --> Config Class Initialized
INFO - 2023-12-05 13:56:55 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:56:55 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:56:55 --> Utf8 Class Initialized
INFO - 2023-12-05 13:56:55 --> URI Class Initialized
INFO - 2023-12-05 13:56:55 --> Router Class Initialized
INFO - 2023-12-05 13:56:55 --> Output Class Initialized
INFO - 2023-12-05 13:56:55 --> Security Class Initialized
DEBUG - 2023-12-05 13:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:56:55 --> Input Class Initialized
INFO - 2023-12-05 13:56:55 --> Language Class Initialized
INFO - 2023-12-05 13:56:55 --> Language Class Initialized
INFO - 2023-12-05 13:56:55 --> Config Class Initialized
INFO - 2023-12-05 13:56:55 --> Loader Class Initialized
INFO - 2023-12-05 13:56:55 --> Helper loaded: url_helper
INFO - 2023-12-05 13:56:55 --> Helper loaded: file_helper
INFO - 2023-12-05 13:56:55 --> Helper loaded: form_helper
INFO - 2023-12-05 13:56:55 --> Helper loaded: my_helper
INFO - 2023-12-05 13:56:55 --> Database Driver Class Initialized
INFO - 2023-12-05 13:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:56:55 --> Controller Class Initialized
DEBUG - 2023-12-05 13:56:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-05 13:56:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 13:56:55 --> Final output sent to browser
DEBUG - 2023-12-05 13:56:55 --> Total execution time: 0.1643
INFO - 2023-12-05 13:56:57 --> Config Class Initialized
INFO - 2023-12-05 13:56:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 13:56:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 13:56:57 --> Utf8 Class Initialized
INFO - 2023-12-05 13:56:57 --> URI Class Initialized
INFO - 2023-12-05 13:56:57 --> Router Class Initialized
INFO - 2023-12-05 13:56:57 --> Output Class Initialized
INFO - 2023-12-05 13:56:57 --> Security Class Initialized
DEBUG - 2023-12-05 13:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 13:56:57 --> Input Class Initialized
INFO - 2023-12-05 13:56:57 --> Language Class Initialized
INFO - 2023-12-05 13:56:57 --> Language Class Initialized
INFO - 2023-12-05 13:56:57 --> Config Class Initialized
INFO - 2023-12-05 13:56:57 --> Loader Class Initialized
INFO - 2023-12-05 13:56:57 --> Helper loaded: url_helper
INFO - 2023-12-05 13:56:57 --> Helper loaded: file_helper
INFO - 2023-12-05 13:56:57 --> Helper loaded: form_helper
INFO - 2023-12-05 13:56:57 --> Helper loaded: my_helper
INFO - 2023-12-05 13:56:57 --> Database Driver Class Initialized
INFO - 2023-12-05 13:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 13:56:57 --> Controller Class Initialized
ERROR - 2023-12-05 13:56:57 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-05 13:56:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-05 13:57:01 --> Final output sent to browser
DEBUG - 2023-12-05 13:57:01 --> Total execution time: 3.9676
INFO - 2023-12-05 14:00:34 --> Config Class Initialized
INFO - 2023-12-05 14:00:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:00:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:00:34 --> Utf8 Class Initialized
INFO - 2023-12-05 14:00:34 --> URI Class Initialized
INFO - 2023-12-05 14:00:34 --> Router Class Initialized
INFO - 2023-12-05 14:00:34 --> Output Class Initialized
INFO - 2023-12-05 14:00:34 --> Security Class Initialized
DEBUG - 2023-12-05 14:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:00:34 --> Input Class Initialized
INFO - 2023-12-05 14:00:34 --> Language Class Initialized
INFO - 2023-12-05 14:00:34 --> Language Class Initialized
INFO - 2023-12-05 14:00:34 --> Config Class Initialized
INFO - 2023-12-05 14:00:34 --> Loader Class Initialized
INFO - 2023-12-05 14:00:34 --> Helper loaded: url_helper
INFO - 2023-12-05 14:00:34 --> Helper loaded: file_helper
INFO - 2023-12-05 14:00:34 --> Helper loaded: form_helper
INFO - 2023-12-05 14:00:34 --> Helper loaded: my_helper
INFO - 2023-12-05 14:00:34 --> Database Driver Class Initialized
INFO - 2023-12-05 14:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:00:34 --> Controller Class Initialized
DEBUG - 2023-12-05 14:00:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-05 14:00:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 14:00:34 --> Final output sent to browser
DEBUG - 2023-12-05 14:00:34 --> Total execution time: 0.0951
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:00:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:00:35 --> Utf8 Class Initialized
INFO - 2023-12-05 14:00:35 --> URI Class Initialized
INFO - 2023-12-05 14:00:35 --> Router Class Initialized
INFO - 2023-12-05 14:00:35 --> Output Class Initialized
INFO - 2023-12-05 14:00:35 --> Security Class Initialized
DEBUG - 2023-12-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:00:35 --> Input Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Loader Class Initialized
INFO - 2023-12-05 14:00:35 --> Helper loaded: url_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: file_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: form_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: my_helper
INFO - 2023-12-05 14:00:35 --> Database Driver Class Initialized
INFO - 2023-12-05 14:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:00:35 --> Controller Class Initialized
INFO - 2023-12-05 14:00:35 --> Helper loaded: cookie_helper
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:00:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:00:35 --> Utf8 Class Initialized
INFO - 2023-12-05 14:00:35 --> URI Class Initialized
INFO - 2023-12-05 14:00:35 --> Router Class Initialized
INFO - 2023-12-05 14:00:35 --> Output Class Initialized
INFO - 2023-12-05 14:00:35 --> Security Class Initialized
DEBUG - 2023-12-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:00:35 --> Input Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Loader Class Initialized
INFO - 2023-12-05 14:00:35 --> Helper loaded: url_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: file_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: form_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: my_helper
INFO - 2023-12-05 14:00:35 --> Database Driver Class Initialized
INFO - 2023-12-05 14:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:00:35 --> Controller Class Initialized
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:00:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:00:35 --> Utf8 Class Initialized
INFO - 2023-12-05 14:00:35 --> URI Class Initialized
INFO - 2023-12-05 14:00:35 --> Router Class Initialized
INFO - 2023-12-05 14:00:35 --> Output Class Initialized
INFO - 2023-12-05 14:00:35 --> Security Class Initialized
DEBUG - 2023-12-05 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:00:35 --> Input Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Language Class Initialized
INFO - 2023-12-05 14:00:35 --> Config Class Initialized
INFO - 2023-12-05 14:00:35 --> Loader Class Initialized
INFO - 2023-12-05 14:00:35 --> Helper loaded: url_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: file_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: form_helper
INFO - 2023-12-05 14:00:35 --> Helper loaded: my_helper
INFO - 2023-12-05 14:00:35 --> Database Driver Class Initialized
INFO - 2023-12-05 14:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:00:35 --> Controller Class Initialized
DEBUG - 2023-12-05 14:00:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 14:00:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 14:00:35 --> Final output sent to browser
DEBUG - 2023-12-05 14:00:35 --> Total execution time: 0.0468
INFO - 2023-12-05 14:29:42 --> Config Class Initialized
INFO - 2023-12-05 14:29:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:29:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:29:42 --> Utf8 Class Initialized
INFO - 2023-12-05 14:29:42 --> URI Class Initialized
INFO - 2023-12-05 14:29:42 --> Router Class Initialized
INFO - 2023-12-05 14:29:42 --> Output Class Initialized
INFO - 2023-12-05 14:29:42 --> Security Class Initialized
DEBUG - 2023-12-05 14:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:29:42 --> Input Class Initialized
INFO - 2023-12-05 14:29:42 --> Language Class Initialized
INFO - 2023-12-05 14:29:42 --> Language Class Initialized
INFO - 2023-12-05 14:29:42 --> Config Class Initialized
INFO - 2023-12-05 14:29:42 --> Loader Class Initialized
INFO - 2023-12-05 14:29:42 --> Helper loaded: url_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: file_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: form_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: my_helper
INFO - 2023-12-05 14:29:42 --> Database Driver Class Initialized
INFO - 2023-12-05 14:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:29:42 --> Controller Class Initialized
DEBUG - 2023-12-05 14:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 14:29:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 14:29:42 --> Final output sent to browser
DEBUG - 2023-12-05 14:29:42 --> Total execution time: 0.1012
INFO - 2023-12-05 14:29:42 --> Config Class Initialized
INFO - 2023-12-05 14:29:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 14:29:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 14:29:42 --> Utf8 Class Initialized
INFO - 2023-12-05 14:29:42 --> URI Class Initialized
INFO - 2023-12-05 14:29:42 --> Router Class Initialized
INFO - 2023-12-05 14:29:42 --> Output Class Initialized
INFO - 2023-12-05 14:29:42 --> Security Class Initialized
DEBUG - 2023-12-05 14:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 14:29:42 --> Input Class Initialized
INFO - 2023-12-05 14:29:42 --> Language Class Initialized
INFO - 2023-12-05 14:29:42 --> Language Class Initialized
INFO - 2023-12-05 14:29:42 --> Config Class Initialized
INFO - 2023-12-05 14:29:42 --> Loader Class Initialized
INFO - 2023-12-05 14:29:42 --> Helper loaded: url_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: file_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: form_helper
INFO - 2023-12-05 14:29:42 --> Helper loaded: my_helper
INFO - 2023-12-05 14:29:42 --> Database Driver Class Initialized
INFO - 2023-12-05 14:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 14:29:42 --> Controller Class Initialized
INFO - 2023-12-05 15:18:45 --> Config Class Initialized
INFO - 2023-12-05 15:18:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:45 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:45 --> URI Class Initialized
DEBUG - 2023-12-05 15:18:45 --> No URI present. Default controller set.
INFO - 2023-12-05 15:18:45 --> Router Class Initialized
INFO - 2023-12-05 15:18:45 --> Output Class Initialized
INFO - 2023-12-05 15:18:45 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:45 --> Input Class Initialized
INFO - 2023-12-05 15:18:45 --> Language Class Initialized
INFO - 2023-12-05 15:18:45 --> Language Class Initialized
INFO - 2023-12-05 15:18:45 --> Config Class Initialized
INFO - 2023-12-05 15:18:45 --> Loader Class Initialized
INFO - 2023-12-05 15:18:45 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:45 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:45 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:45 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:45 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:45 --> Controller Class Initialized
DEBUG - 2023-12-05 15:18:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:18:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:18:45 --> Final output sent to browser
DEBUG - 2023-12-05 15:18:45 --> Total execution time: 0.0924
INFO - 2023-12-05 15:18:49 --> Config Class Initialized
INFO - 2023-12-05 15:18:49 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:49 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:49 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:49 --> URI Class Initialized
DEBUG - 2023-12-05 15:18:49 --> No URI present. Default controller set.
INFO - 2023-12-05 15:18:49 --> Router Class Initialized
INFO - 2023-12-05 15:18:49 --> Output Class Initialized
INFO - 2023-12-05 15:18:49 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:49 --> Input Class Initialized
INFO - 2023-12-05 15:18:49 --> Language Class Initialized
INFO - 2023-12-05 15:18:49 --> Language Class Initialized
INFO - 2023-12-05 15:18:49 --> Config Class Initialized
INFO - 2023-12-05 15:18:49 --> Loader Class Initialized
INFO - 2023-12-05 15:18:49 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:49 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:49 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:49 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:49 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:49 --> Controller Class Initialized
DEBUG - 2023-12-05 15:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:18:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:18:49 --> Final output sent to browser
DEBUG - 2023-12-05 15:18:49 --> Total execution time: 0.0345
INFO - 2023-12-05 15:18:52 --> Config Class Initialized
INFO - 2023-12-05 15:18:52 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:52 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:52 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:52 --> URI Class Initialized
DEBUG - 2023-12-05 15:18:52 --> No URI present. Default controller set.
INFO - 2023-12-05 15:18:52 --> Router Class Initialized
INFO - 2023-12-05 15:18:52 --> Output Class Initialized
INFO - 2023-12-05 15:18:52 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:52 --> Input Class Initialized
INFO - 2023-12-05 15:18:52 --> Language Class Initialized
INFO - 2023-12-05 15:18:52 --> Language Class Initialized
INFO - 2023-12-05 15:18:52 --> Config Class Initialized
INFO - 2023-12-05 15:18:52 --> Loader Class Initialized
INFO - 2023-12-05 15:18:52 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:52 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:52 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:52 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:52 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:52 --> Controller Class Initialized
DEBUG - 2023-12-05 15:18:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:18:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:18:52 --> Final output sent to browser
DEBUG - 2023-12-05 15:18:52 --> Total execution time: 0.0420
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:54 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:54 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:54 --> URI Class Initialized
INFO - 2023-12-05 15:18:54 --> Router Class Initialized
INFO - 2023-12-05 15:18:54 --> Output Class Initialized
INFO - 2023-12-05 15:18:54 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:54 --> Input Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Loader Class Initialized
INFO - 2023-12-05 15:18:54 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:54 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:54 --> Controller Class Initialized
INFO - 2023-12-05 15:18:54 --> Helper loaded: cookie_helper
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:54 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:54 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:54 --> URI Class Initialized
INFO - 2023-12-05 15:18:54 --> Router Class Initialized
INFO - 2023-12-05 15:18:54 --> Output Class Initialized
INFO - 2023-12-05 15:18:54 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:54 --> Input Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Loader Class Initialized
INFO - 2023-12-05 15:18:54 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:54 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:54 --> Controller Class Initialized
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:18:54 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:18:54 --> Utf8 Class Initialized
INFO - 2023-12-05 15:18:54 --> URI Class Initialized
INFO - 2023-12-05 15:18:54 --> Router Class Initialized
INFO - 2023-12-05 15:18:54 --> Output Class Initialized
INFO - 2023-12-05 15:18:54 --> Security Class Initialized
DEBUG - 2023-12-05 15:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:18:54 --> Input Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Language Class Initialized
INFO - 2023-12-05 15:18:54 --> Config Class Initialized
INFO - 2023-12-05 15:18:54 --> Loader Class Initialized
INFO - 2023-12-05 15:18:54 --> Helper loaded: url_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: file_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: form_helper
INFO - 2023-12-05 15:18:54 --> Helper loaded: my_helper
INFO - 2023-12-05 15:18:54 --> Database Driver Class Initialized
INFO - 2023-12-05 15:18:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:18:54 --> Controller Class Initialized
DEBUG - 2023-12-05 15:18:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 15:18:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:18:54 --> Final output sent to browser
DEBUG - 2023-12-05 15:18:54 --> Total execution time: 0.0391
INFO - 2023-12-05 15:19:01 --> Config Class Initialized
INFO - 2023-12-05 15:19:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:01 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:01 --> URI Class Initialized
INFO - 2023-12-05 15:19:01 --> Router Class Initialized
INFO - 2023-12-05 15:19:01 --> Output Class Initialized
INFO - 2023-12-05 15:19:01 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:01 --> Input Class Initialized
INFO - 2023-12-05 15:19:01 --> Language Class Initialized
INFO - 2023-12-05 15:19:01 --> Language Class Initialized
INFO - 2023-12-05 15:19:01 --> Config Class Initialized
INFO - 2023-12-05 15:19:01 --> Loader Class Initialized
INFO - 2023-12-05 15:19:01 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:01 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:01 --> Controller Class Initialized
INFO - 2023-12-05 15:19:01 --> Helper loaded: cookie_helper
INFO - 2023-12-05 15:19:01 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:01 --> Total execution time: 0.2084
INFO - 2023-12-05 15:19:01 --> Config Class Initialized
INFO - 2023-12-05 15:19:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:01 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:01 --> URI Class Initialized
INFO - 2023-12-05 15:19:01 --> Router Class Initialized
INFO - 2023-12-05 15:19:01 --> Output Class Initialized
INFO - 2023-12-05 15:19:01 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:01 --> Input Class Initialized
INFO - 2023-12-05 15:19:01 --> Language Class Initialized
INFO - 2023-12-05 15:19:01 --> Language Class Initialized
INFO - 2023-12-05 15:19:01 --> Config Class Initialized
INFO - 2023-12-05 15:19:01 --> Loader Class Initialized
INFO - 2023-12-05 15:19:01 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:01 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:01 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:01 --> Controller Class Initialized
DEBUG - 2023-12-05 15:19:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:19:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:19:01 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:01 --> Total execution time: 0.0525
INFO - 2023-12-05 15:19:05 --> Config Class Initialized
INFO - 2023-12-05 15:19:05 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:05 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:05 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:05 --> URI Class Initialized
DEBUG - 2023-12-05 15:19:05 --> No URI present. Default controller set.
INFO - 2023-12-05 15:19:05 --> Router Class Initialized
INFO - 2023-12-05 15:19:05 --> Output Class Initialized
INFO - 2023-12-05 15:19:05 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:05 --> Input Class Initialized
INFO - 2023-12-05 15:19:05 --> Language Class Initialized
INFO - 2023-12-05 15:19:05 --> Language Class Initialized
INFO - 2023-12-05 15:19:05 --> Config Class Initialized
INFO - 2023-12-05 15:19:05 --> Loader Class Initialized
INFO - 2023-12-05 15:19:05 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:05 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:05 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:05 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:05 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:05 --> Controller Class Initialized
DEBUG - 2023-12-05 15:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:19:05 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:05 --> Total execution time: 0.0429
INFO - 2023-12-05 15:19:10 --> Config Class Initialized
INFO - 2023-12-05 15:19:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:10 --> URI Class Initialized
DEBUG - 2023-12-05 15:19:10 --> No URI present. Default controller set.
INFO - 2023-12-05 15:19:10 --> Router Class Initialized
INFO - 2023-12-05 15:19:10 --> Output Class Initialized
INFO - 2023-12-05 15:19:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:10 --> Input Class Initialized
INFO - 2023-12-05 15:19:10 --> Language Class Initialized
INFO - 2023-12-05 15:19:10 --> Language Class Initialized
INFO - 2023-12-05 15:19:10 --> Config Class Initialized
INFO - 2023-12-05 15:19:10 --> Loader Class Initialized
INFO - 2023-12-05 15:19:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:10 --> Controller Class Initialized
DEBUG - 2023-12-05 15:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:19:10 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:10 --> Total execution time: 0.0662
INFO - 2023-12-05 15:19:10 --> Config Class Initialized
INFO - 2023-12-05 15:19:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:10 --> URI Class Initialized
INFO - 2023-12-05 15:19:10 --> Router Class Initialized
INFO - 2023-12-05 15:19:10 --> Output Class Initialized
INFO - 2023-12-05 15:19:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:10 --> Input Class Initialized
INFO - 2023-12-05 15:19:10 --> Language Class Initialized
INFO - 2023-12-05 15:19:10 --> Language Class Initialized
INFO - 2023-12-05 15:19:10 --> Config Class Initialized
INFO - 2023-12-05 15:19:10 --> Loader Class Initialized
INFO - 2023-12-05 15:19:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:10 --> Controller Class Initialized
DEBUG - 2023-12-05 15:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:19:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:19:10 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:10 --> Total execution time: 0.0485
INFO - 2023-12-05 15:19:13 --> Config Class Initialized
INFO - 2023-12-05 15:19:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:13 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:13 --> URI Class Initialized
INFO - 2023-12-05 15:19:13 --> Router Class Initialized
INFO - 2023-12-05 15:19:13 --> Output Class Initialized
INFO - 2023-12-05 15:19:13 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:13 --> Input Class Initialized
INFO - 2023-12-05 15:19:13 --> Language Class Initialized
INFO - 2023-12-05 15:19:13 --> Language Class Initialized
INFO - 2023-12-05 15:19:13 --> Config Class Initialized
INFO - 2023-12-05 15:19:13 --> Loader Class Initialized
INFO - 2023-12-05 15:19:13 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:13 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:13 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:13 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:13 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:13 --> Controller Class Initialized
DEBUG - 2023-12-05 15:19:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:19:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:19:14 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:14 --> Total execution time: 0.0515
INFO - 2023-12-05 15:19:14 --> Config Class Initialized
INFO - 2023-12-05 15:19:14 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:14 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:14 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:14 --> URI Class Initialized
INFO - 2023-12-05 15:19:14 --> Router Class Initialized
INFO - 2023-12-05 15:19:14 --> Output Class Initialized
INFO - 2023-12-05 15:19:14 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:14 --> Input Class Initialized
INFO - 2023-12-05 15:19:14 --> Language Class Initialized
INFO - 2023-12-05 15:19:14 --> Language Class Initialized
INFO - 2023-12-05 15:19:14 --> Config Class Initialized
INFO - 2023-12-05 15:19:14 --> Loader Class Initialized
INFO - 2023-12-05 15:19:14 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:14 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:14 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:14 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:14 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:14 --> Controller Class Initialized
INFO - 2023-12-05 15:19:16 --> Config Class Initialized
INFO - 2023-12-05 15:19:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:19:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:19:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:19:16 --> URI Class Initialized
INFO - 2023-12-05 15:19:16 --> Router Class Initialized
INFO - 2023-12-05 15:19:16 --> Output Class Initialized
INFO - 2023-12-05 15:19:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:19:16 --> Input Class Initialized
INFO - 2023-12-05 15:19:16 --> Language Class Initialized
INFO - 2023-12-05 15:19:16 --> Language Class Initialized
INFO - 2023-12-05 15:19:16 --> Config Class Initialized
INFO - 2023-12-05 15:19:16 --> Loader Class Initialized
INFO - 2023-12-05 15:19:16 --> Helper loaded: url_helper
INFO - 2023-12-05 15:19:16 --> Helper loaded: file_helper
INFO - 2023-12-05 15:19:16 --> Helper loaded: form_helper
INFO - 2023-12-05 15:19:16 --> Helper loaded: my_helper
INFO - 2023-12-05 15:19:16 --> Database Driver Class Initialized
INFO - 2023-12-05 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:19:16 --> Controller Class Initialized
INFO - 2023-12-05 15:19:16 --> Final output sent to browser
DEBUG - 2023-12-05 15:19:16 --> Total execution time: 0.0564
INFO - 2023-12-05 15:27:13 --> Config Class Initialized
INFO - 2023-12-05 15:27:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:13 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:13 --> URI Class Initialized
INFO - 2023-12-05 15:27:13 --> Router Class Initialized
INFO - 2023-12-05 15:27:13 --> Output Class Initialized
INFO - 2023-12-05 15:27:13 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:13 --> Input Class Initialized
INFO - 2023-12-05 15:27:13 --> Language Class Initialized
INFO - 2023-12-05 15:27:13 --> Language Class Initialized
INFO - 2023-12-05 15:27:13 --> Config Class Initialized
INFO - 2023-12-05 15:27:13 --> Loader Class Initialized
INFO - 2023-12-05 15:27:13 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:13 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:13 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:13 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:13 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:13 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:27:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:13 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:13 --> Total execution time: 0.0885
INFO - 2023-12-05 15:27:14 --> Config Class Initialized
INFO - 2023-12-05 15:27:14 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:14 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:14 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:14 --> URI Class Initialized
INFO - 2023-12-05 15:27:14 --> Router Class Initialized
INFO - 2023-12-05 15:27:14 --> Output Class Initialized
INFO - 2023-12-05 15:27:14 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:14 --> Input Class Initialized
INFO - 2023-12-05 15:27:14 --> Language Class Initialized
INFO - 2023-12-05 15:27:14 --> Language Class Initialized
INFO - 2023-12-05 15:27:14 --> Config Class Initialized
INFO - 2023-12-05 15:27:14 --> Loader Class Initialized
INFO - 2023-12-05 15:27:14 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:14 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:14 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:14 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:14 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:14 --> Controller Class Initialized
INFO - 2023-12-05 15:27:19 --> Config Class Initialized
INFO - 2023-12-05 15:27:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:19 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:19 --> URI Class Initialized
INFO - 2023-12-05 15:27:19 --> Router Class Initialized
INFO - 2023-12-05 15:27:19 --> Output Class Initialized
INFO - 2023-12-05 15:27:19 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:19 --> Input Class Initialized
INFO - 2023-12-05 15:27:19 --> Language Class Initialized
INFO - 2023-12-05 15:27:19 --> Language Class Initialized
INFO - 2023-12-05 15:27:19 --> Config Class Initialized
INFO - 2023-12-05 15:27:19 --> Loader Class Initialized
INFO - 2023-12-05 15:27:19 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:19 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:19 --> Controller Class Initialized
INFO - 2023-12-05 15:27:19 --> Config Class Initialized
INFO - 2023-12-05 15:27:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:19 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:19 --> URI Class Initialized
INFO - 2023-12-05 15:27:19 --> Router Class Initialized
INFO - 2023-12-05 15:27:19 --> Output Class Initialized
INFO - 2023-12-05 15:27:19 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:19 --> Input Class Initialized
INFO - 2023-12-05 15:27:19 --> Language Class Initialized
INFO - 2023-12-05 15:27:19 --> Language Class Initialized
INFO - 2023-12-05 15:27:19 --> Config Class Initialized
INFO - 2023-12-05 15:27:19 --> Loader Class Initialized
INFO - 2023-12-05 15:27:19 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:19 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:19 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:19 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 15:27:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:19 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:19 --> Total execution time: 0.0347
INFO - 2023-12-05 15:27:21 --> Config Class Initialized
INFO - 2023-12-05 15:27:21 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:21 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:21 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:21 --> URI Class Initialized
INFO - 2023-12-05 15:27:21 --> Router Class Initialized
INFO - 2023-12-05 15:27:21 --> Output Class Initialized
INFO - 2023-12-05 15:27:21 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:21 --> Input Class Initialized
INFO - 2023-12-05 15:27:21 --> Language Class Initialized
INFO - 2023-12-05 15:27:21 --> Language Class Initialized
INFO - 2023-12-05 15:27:21 --> Config Class Initialized
INFO - 2023-12-05 15:27:21 --> Loader Class Initialized
INFO - 2023-12-05 15:27:21 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:21 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:21 --> Controller Class Initialized
INFO - 2023-12-05 15:27:21 --> Helper loaded: cookie_helper
INFO - 2023-12-05 15:27:21 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:21 --> Total execution time: 0.0415
INFO - 2023-12-05 15:27:21 --> Config Class Initialized
INFO - 2023-12-05 15:27:21 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:21 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:21 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:21 --> URI Class Initialized
INFO - 2023-12-05 15:27:21 --> Router Class Initialized
INFO - 2023-12-05 15:27:21 --> Output Class Initialized
INFO - 2023-12-05 15:27:21 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:21 --> Input Class Initialized
INFO - 2023-12-05 15:27:21 --> Language Class Initialized
INFO - 2023-12-05 15:27:21 --> Language Class Initialized
INFO - 2023-12-05 15:27:21 --> Config Class Initialized
INFO - 2023-12-05 15:27:21 --> Loader Class Initialized
INFO - 2023-12-05 15:27:21 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:21 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:21 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:21 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 15:27:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:21 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:21 --> Total execution time: 0.0403
INFO - 2023-12-05 15:27:24 --> Config Class Initialized
INFO - 2023-12-05 15:27:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:24 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:24 --> URI Class Initialized
INFO - 2023-12-05 15:27:24 --> Router Class Initialized
INFO - 2023-12-05 15:27:24 --> Output Class Initialized
INFO - 2023-12-05 15:27:24 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:24 --> Input Class Initialized
INFO - 2023-12-05 15:27:24 --> Language Class Initialized
INFO - 2023-12-05 15:27:24 --> Language Class Initialized
INFO - 2023-12-05 15:27:24 --> Config Class Initialized
INFO - 2023-12-05 15:27:24 --> Loader Class Initialized
INFO - 2023-12-05 15:27:24 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:24 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:24 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:24 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:24 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:24 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:27:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:24 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:24 --> Total execution time: 0.0522
INFO - 2023-12-05 15:27:25 --> Config Class Initialized
INFO - 2023-12-05 15:27:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:25 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:25 --> URI Class Initialized
INFO - 2023-12-05 15:27:25 --> Router Class Initialized
INFO - 2023-12-05 15:27:25 --> Output Class Initialized
INFO - 2023-12-05 15:27:25 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:25 --> Input Class Initialized
INFO - 2023-12-05 15:27:25 --> Language Class Initialized
INFO - 2023-12-05 15:27:25 --> Language Class Initialized
INFO - 2023-12-05 15:27:25 --> Config Class Initialized
INFO - 2023-12-05 15:27:25 --> Loader Class Initialized
INFO - 2023-12-05 15:27:25 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:25 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:25 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:25 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:25 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:25 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 15:27:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:26 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:26 --> Total execution time: 0.0673
INFO - 2023-12-05 15:27:30 --> Config Class Initialized
INFO - 2023-12-05 15:27:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:30 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:30 --> URI Class Initialized
INFO - 2023-12-05 15:27:30 --> Router Class Initialized
INFO - 2023-12-05 15:27:30 --> Output Class Initialized
INFO - 2023-12-05 15:27:30 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:30 --> Input Class Initialized
INFO - 2023-12-05 15:27:30 --> Language Class Initialized
INFO - 2023-12-05 15:27:30 --> Language Class Initialized
INFO - 2023-12-05 15:27:30 --> Config Class Initialized
INFO - 2023-12-05 15:27:30 --> Loader Class Initialized
INFO - 2023-12-05 15:27:30 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:30 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:30 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:30 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:30 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:30 --> Controller Class Initialized
INFO - 2023-12-05 15:27:30 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:30 --> Total execution time: 0.0466
INFO - 2023-12-05 15:27:33 --> Config Class Initialized
INFO - 2023-12-05 15:27:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:33 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:33 --> URI Class Initialized
INFO - 2023-12-05 15:27:33 --> Router Class Initialized
INFO - 2023-12-05 15:27:33 --> Output Class Initialized
INFO - 2023-12-05 15:27:33 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:33 --> Input Class Initialized
INFO - 2023-12-05 15:27:33 --> Language Class Initialized
INFO - 2023-12-05 15:27:33 --> Language Class Initialized
INFO - 2023-12-05 15:27:33 --> Config Class Initialized
INFO - 2023-12-05 15:27:33 --> Loader Class Initialized
INFO - 2023-12-05 15:27:33 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:33 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:33 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:33 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:33 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:33 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2023-12-05 15:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:33 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:33 --> Total execution time: 0.0459
INFO - 2023-12-05 15:27:43 --> Config Class Initialized
INFO - 2023-12-05 15:27:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:43 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:43 --> URI Class Initialized
INFO - 2023-12-05 15:27:43 --> Router Class Initialized
INFO - 2023-12-05 15:27:43 --> Output Class Initialized
INFO - 2023-12-05 15:27:43 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:43 --> Input Class Initialized
INFO - 2023-12-05 15:27:43 --> Language Class Initialized
INFO - 2023-12-05 15:27:43 --> Language Class Initialized
INFO - 2023-12-05 15:27:43 --> Config Class Initialized
INFO - 2023-12-05 15:27:43 --> Loader Class Initialized
INFO - 2023-12-05 15:27:43 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:43 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:43 --> Controller Class Initialized
INFO - 2023-12-05 15:27:43 --> Config Class Initialized
INFO - 2023-12-05 15:27:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:43 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:43 --> URI Class Initialized
INFO - 2023-12-05 15:27:43 --> Router Class Initialized
INFO - 2023-12-05 15:27:43 --> Output Class Initialized
INFO - 2023-12-05 15:27:43 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:43 --> Input Class Initialized
INFO - 2023-12-05 15:27:43 --> Language Class Initialized
INFO - 2023-12-05 15:27:43 --> Language Class Initialized
INFO - 2023-12-05 15:27:43 --> Config Class Initialized
INFO - 2023-12-05 15:27:43 --> Loader Class Initialized
INFO - 2023-12-05 15:27:43 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:43 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:43 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:43 --> Controller Class Initialized
DEBUG - 2023-12-05 15:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 15:27:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:27:43 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:43 --> Total execution time: 0.0402
INFO - 2023-12-05 15:27:46 --> Config Class Initialized
INFO - 2023-12-05 15:27:46 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:27:46 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:27:46 --> Utf8 Class Initialized
INFO - 2023-12-05 15:27:46 --> URI Class Initialized
INFO - 2023-12-05 15:27:46 --> Router Class Initialized
INFO - 2023-12-05 15:27:46 --> Output Class Initialized
INFO - 2023-12-05 15:27:46 --> Security Class Initialized
DEBUG - 2023-12-05 15:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:27:46 --> Input Class Initialized
INFO - 2023-12-05 15:27:46 --> Language Class Initialized
INFO - 2023-12-05 15:27:46 --> Language Class Initialized
INFO - 2023-12-05 15:27:46 --> Config Class Initialized
INFO - 2023-12-05 15:27:46 --> Loader Class Initialized
INFO - 2023-12-05 15:27:46 --> Helper loaded: url_helper
INFO - 2023-12-05 15:27:46 --> Helper loaded: file_helper
INFO - 2023-12-05 15:27:46 --> Helper loaded: form_helper
INFO - 2023-12-05 15:27:46 --> Helper loaded: my_helper
INFO - 2023-12-05 15:27:46 --> Database Driver Class Initialized
INFO - 2023-12-05 15:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:27:46 --> Controller Class Initialized
INFO - 2023-12-05 15:27:46 --> Final output sent to browser
DEBUG - 2023-12-05 15:27:46 --> Total execution time: 0.0637
INFO - 2023-12-05 15:28:14 --> Config Class Initialized
INFO - 2023-12-05 15:28:14 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:28:14 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:28:14 --> Utf8 Class Initialized
INFO - 2023-12-05 15:28:14 --> URI Class Initialized
INFO - 2023-12-05 15:28:14 --> Router Class Initialized
INFO - 2023-12-05 15:28:14 --> Output Class Initialized
INFO - 2023-12-05 15:28:14 --> Security Class Initialized
DEBUG - 2023-12-05 15:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:28:14 --> Input Class Initialized
INFO - 2023-12-05 15:28:14 --> Language Class Initialized
INFO - 2023-12-05 15:28:14 --> Language Class Initialized
INFO - 2023-12-05 15:28:14 --> Config Class Initialized
INFO - 2023-12-05 15:28:14 --> Loader Class Initialized
INFO - 2023-12-05 15:28:14 --> Helper loaded: url_helper
INFO - 2023-12-05 15:28:14 --> Helper loaded: file_helper
INFO - 2023-12-05 15:28:14 --> Helper loaded: form_helper
INFO - 2023-12-05 15:28:14 --> Helper loaded: my_helper
INFO - 2023-12-05 15:28:14 --> Database Driver Class Initialized
INFO - 2023-12-05 15:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:28:14 --> Controller Class Initialized
INFO - 2023-12-05 15:28:14 --> Final output sent to browser
DEBUG - 2023-12-05 15:28:14 --> Total execution time: 0.2228
INFO - 2023-12-05 15:28:20 --> Config Class Initialized
INFO - 2023-12-05 15:28:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:28:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:28:20 --> Utf8 Class Initialized
INFO - 2023-12-05 15:28:20 --> URI Class Initialized
INFO - 2023-12-05 15:28:20 --> Router Class Initialized
INFO - 2023-12-05 15:28:20 --> Output Class Initialized
INFO - 2023-12-05 15:28:20 --> Security Class Initialized
DEBUG - 2023-12-05 15:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:28:20 --> Input Class Initialized
INFO - 2023-12-05 15:28:20 --> Language Class Initialized
INFO - 2023-12-05 15:28:20 --> Language Class Initialized
INFO - 2023-12-05 15:28:20 --> Config Class Initialized
INFO - 2023-12-05 15:28:20 --> Loader Class Initialized
INFO - 2023-12-05 15:28:20 --> Helper loaded: url_helper
INFO - 2023-12-05 15:28:20 --> Helper loaded: file_helper
INFO - 2023-12-05 15:28:20 --> Helper loaded: form_helper
INFO - 2023-12-05 15:28:20 --> Helper loaded: my_helper
INFO - 2023-12-05 15:28:20 --> Database Driver Class Initialized
INFO - 2023-12-05 15:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:28:20 --> Controller Class Initialized
DEBUG - 2023-12-05 15:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:28:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:28:20 --> Final output sent to browser
DEBUG - 2023-12-05 15:28:20 --> Total execution time: 0.0330
INFO - 2023-12-05 15:28:22 --> Config Class Initialized
INFO - 2023-12-05 15:28:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:28:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:28:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:28:22 --> URI Class Initialized
INFO - 2023-12-05 15:28:22 --> Router Class Initialized
INFO - 2023-12-05 15:28:22 --> Output Class Initialized
INFO - 2023-12-05 15:28:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:28:22 --> Input Class Initialized
INFO - 2023-12-05 15:28:22 --> Language Class Initialized
INFO - 2023-12-05 15:28:22 --> Language Class Initialized
INFO - 2023-12-05 15:28:22 --> Config Class Initialized
INFO - 2023-12-05 15:28:22 --> Loader Class Initialized
INFO - 2023-12-05 15:28:22 --> Helper loaded: url_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: file_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: form_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: my_helper
INFO - 2023-12-05 15:28:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:28:22 --> Controller Class Initialized
DEBUG - 2023-12-05 15:28:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:28:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:28:22 --> Final output sent to browser
DEBUG - 2023-12-05 15:28:22 --> Total execution time: 0.0873
INFO - 2023-12-05 15:28:22 --> Config Class Initialized
INFO - 2023-12-05 15:28:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:28:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:28:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:28:22 --> URI Class Initialized
INFO - 2023-12-05 15:28:22 --> Router Class Initialized
INFO - 2023-12-05 15:28:22 --> Output Class Initialized
INFO - 2023-12-05 15:28:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:28:22 --> Input Class Initialized
INFO - 2023-12-05 15:28:22 --> Language Class Initialized
INFO - 2023-12-05 15:28:22 --> Language Class Initialized
INFO - 2023-12-05 15:28:22 --> Config Class Initialized
INFO - 2023-12-05 15:28:22 --> Loader Class Initialized
INFO - 2023-12-05 15:28:22 --> Helper loaded: url_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: file_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: form_helper
INFO - 2023-12-05 15:28:22 --> Helper loaded: my_helper
INFO - 2023-12-05 15:28:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:28:22 --> Controller Class Initialized
INFO - 2023-12-05 15:28:45 --> Config Class Initialized
INFO - 2023-12-05 15:28:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:28:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:28:45 --> Utf8 Class Initialized
INFO - 2023-12-05 15:28:45 --> URI Class Initialized
INFO - 2023-12-05 15:28:45 --> Router Class Initialized
INFO - 2023-12-05 15:28:45 --> Output Class Initialized
INFO - 2023-12-05 15:28:45 --> Security Class Initialized
DEBUG - 2023-12-05 15:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:28:45 --> Input Class Initialized
INFO - 2023-12-05 15:28:45 --> Language Class Initialized
INFO - 2023-12-05 15:28:45 --> Language Class Initialized
INFO - 2023-12-05 15:28:45 --> Config Class Initialized
INFO - 2023-12-05 15:28:45 --> Loader Class Initialized
INFO - 2023-12-05 15:28:45 --> Helper loaded: url_helper
INFO - 2023-12-05 15:28:45 --> Helper loaded: file_helper
INFO - 2023-12-05 15:28:45 --> Helper loaded: form_helper
INFO - 2023-12-05 15:28:45 --> Helper loaded: my_helper
INFO - 2023-12-05 15:28:45 --> Database Driver Class Initialized
INFO - 2023-12-05 15:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:28:45 --> Controller Class Initialized
INFO - 2023-12-05 15:28:45 --> Final output sent to browser
DEBUG - 2023-12-05 15:28:45 --> Total execution time: 0.1105
INFO - 2023-12-05 15:29:01 --> Config Class Initialized
INFO - 2023-12-05 15:29:01 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:29:01 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:29:01 --> Utf8 Class Initialized
INFO - 2023-12-05 15:29:01 --> URI Class Initialized
INFO - 2023-12-05 15:29:01 --> Router Class Initialized
INFO - 2023-12-05 15:29:01 --> Output Class Initialized
INFO - 2023-12-05 15:29:01 --> Security Class Initialized
DEBUG - 2023-12-05 15:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:29:01 --> Input Class Initialized
INFO - 2023-12-05 15:29:01 --> Language Class Initialized
INFO - 2023-12-05 15:29:01 --> Language Class Initialized
INFO - 2023-12-05 15:29:01 --> Config Class Initialized
INFO - 2023-12-05 15:29:01 --> Loader Class Initialized
INFO - 2023-12-05 15:29:01 --> Helper loaded: url_helper
INFO - 2023-12-05 15:29:01 --> Helper loaded: file_helper
INFO - 2023-12-05 15:29:01 --> Helper loaded: form_helper
INFO - 2023-12-05 15:29:01 --> Helper loaded: my_helper
INFO - 2023-12-05 15:29:01 --> Database Driver Class Initialized
INFO - 2023-12-05 15:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:29:01 --> Controller Class Initialized
DEBUG - 2023-12-05 15:29:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:29:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:29:01 --> Final output sent to browser
DEBUG - 2023-12-05 15:29:01 --> Total execution time: 0.0619
INFO - 2023-12-05 15:29:15 --> Config Class Initialized
INFO - 2023-12-05 15:29:15 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:29:15 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:29:15 --> Utf8 Class Initialized
INFO - 2023-12-05 15:29:15 --> URI Class Initialized
INFO - 2023-12-05 15:29:15 --> Router Class Initialized
INFO - 2023-12-05 15:29:15 --> Output Class Initialized
INFO - 2023-12-05 15:29:15 --> Security Class Initialized
DEBUG - 2023-12-05 15:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:29:15 --> Input Class Initialized
INFO - 2023-12-05 15:29:15 --> Language Class Initialized
INFO - 2023-12-05 15:29:15 --> Language Class Initialized
INFO - 2023-12-05 15:29:15 --> Config Class Initialized
INFO - 2023-12-05 15:29:15 --> Loader Class Initialized
INFO - 2023-12-05 15:29:15 --> Helper loaded: url_helper
INFO - 2023-12-05 15:29:15 --> Helper loaded: file_helper
INFO - 2023-12-05 15:29:15 --> Helper loaded: form_helper
INFO - 2023-12-05 15:29:15 --> Helper loaded: my_helper
INFO - 2023-12-05 15:29:15 --> Database Driver Class Initialized
INFO - 2023-12-05 15:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:29:15 --> Controller Class Initialized
DEBUG - 2023-12-05 15:29:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-05 15:29:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:29:15 --> Final output sent to browser
DEBUG - 2023-12-05 15:29:15 --> Total execution time: 0.0667
INFO - 2023-12-05 15:30:23 --> Config Class Initialized
INFO - 2023-12-05 15:30:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:30:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:30:23 --> Utf8 Class Initialized
INFO - 2023-12-05 15:30:23 --> URI Class Initialized
INFO - 2023-12-05 15:30:23 --> Router Class Initialized
INFO - 2023-12-05 15:30:23 --> Output Class Initialized
INFO - 2023-12-05 15:30:23 --> Security Class Initialized
DEBUG - 2023-12-05 15:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:30:23 --> Input Class Initialized
INFO - 2023-12-05 15:30:23 --> Language Class Initialized
INFO - 2023-12-05 15:30:23 --> Language Class Initialized
INFO - 2023-12-05 15:30:23 --> Config Class Initialized
INFO - 2023-12-05 15:30:23 --> Loader Class Initialized
INFO - 2023-12-05 15:30:23 --> Helper loaded: url_helper
INFO - 2023-12-05 15:30:23 --> Helper loaded: file_helper
INFO - 2023-12-05 15:30:23 --> Helper loaded: form_helper
INFO - 2023-12-05 15:30:23 --> Helper loaded: my_helper
INFO - 2023-12-05 15:30:23 --> Database Driver Class Initialized
INFO - 2023-12-05 15:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:30:23 --> Controller Class Initialized
INFO - 2023-12-05 15:30:23 --> Final output sent to browser
DEBUG - 2023-12-05 15:30:23 --> Total execution time: 0.2092
INFO - 2023-12-05 15:34:07 --> Config Class Initialized
INFO - 2023-12-05 15:34:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:07 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:07 --> URI Class Initialized
INFO - 2023-12-05 15:34:07 --> Router Class Initialized
INFO - 2023-12-05 15:34:07 --> Output Class Initialized
INFO - 2023-12-05 15:34:07 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:07 --> Input Class Initialized
INFO - 2023-12-05 15:34:07 --> Language Class Initialized
INFO - 2023-12-05 15:34:07 --> Language Class Initialized
INFO - 2023-12-05 15:34:07 --> Config Class Initialized
INFO - 2023-12-05 15:34:07 --> Loader Class Initialized
INFO - 2023-12-05 15:34:07 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:07 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:07 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:07 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:07 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:07 --> Controller Class Initialized
DEBUG - 2023-12-05 15:34:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-05 15:34:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:34:07 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:07 --> Total execution time: 0.0727
INFO - 2023-12-05 15:34:16 --> Config Class Initialized
INFO - 2023-12-05 15:34:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:16 --> URI Class Initialized
INFO - 2023-12-05 15:34:16 --> Router Class Initialized
INFO - 2023-12-05 15:34:16 --> Output Class Initialized
INFO - 2023-12-05 15:34:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:16 --> Input Class Initialized
INFO - 2023-12-05 15:34:16 --> Language Class Initialized
INFO - 2023-12-05 15:34:16 --> Language Class Initialized
INFO - 2023-12-05 15:34:16 --> Config Class Initialized
INFO - 2023-12-05 15:34:16 --> Loader Class Initialized
INFO - 2023-12-05 15:34:16 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:16 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:16 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:16 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:16 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:16 --> Controller Class Initialized
INFO - 2023-12-05 15:34:17 --> Config Class Initialized
INFO - 2023-12-05 15:34:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:17 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:17 --> URI Class Initialized
INFO - 2023-12-05 15:34:17 --> Router Class Initialized
INFO - 2023-12-05 15:34:17 --> Output Class Initialized
INFO - 2023-12-05 15:34:17 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:17 --> Input Class Initialized
INFO - 2023-12-05 15:34:17 --> Language Class Initialized
INFO - 2023-12-05 15:34:17 --> Language Class Initialized
INFO - 2023-12-05 15:34:17 --> Config Class Initialized
INFO - 2023-12-05 15:34:17 --> Loader Class Initialized
INFO - 2023-12-05 15:34:17 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:17 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:17 --> Controller Class Initialized
DEBUG - 2023-12-05 15:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:34:17 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:17 --> Total execution time: 0.0431
INFO - 2023-12-05 15:34:17 --> Config Class Initialized
INFO - 2023-12-05 15:34:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:17 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:17 --> URI Class Initialized
INFO - 2023-12-05 15:34:17 --> Router Class Initialized
INFO - 2023-12-05 15:34:17 --> Output Class Initialized
INFO - 2023-12-05 15:34:17 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:17 --> Input Class Initialized
INFO - 2023-12-05 15:34:17 --> Language Class Initialized
INFO - 2023-12-05 15:34:17 --> Language Class Initialized
INFO - 2023-12-05 15:34:17 --> Config Class Initialized
INFO - 2023-12-05 15:34:17 --> Loader Class Initialized
INFO - 2023-12-05 15:34:17 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:17 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:17 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:17 --> Controller Class Initialized
INFO - 2023-12-05 15:34:20 --> Config Class Initialized
INFO - 2023-12-05 15:34:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:20 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:20 --> URI Class Initialized
INFO - 2023-12-05 15:34:20 --> Router Class Initialized
INFO - 2023-12-05 15:34:20 --> Output Class Initialized
INFO - 2023-12-05 15:34:20 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:20 --> Input Class Initialized
INFO - 2023-12-05 15:34:20 --> Language Class Initialized
INFO - 2023-12-05 15:34:20 --> Language Class Initialized
INFO - 2023-12-05 15:34:20 --> Config Class Initialized
INFO - 2023-12-05 15:34:20 --> Loader Class Initialized
INFO - 2023-12-05 15:34:20 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:20 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:20 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:20 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:20 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:20 --> Controller Class Initialized
INFO - 2023-12-05 15:34:20 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:20 --> Total execution time: 0.0549
INFO - 2023-12-05 15:34:23 --> Config Class Initialized
INFO - 2023-12-05 15:34:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:23 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:23 --> URI Class Initialized
INFO - 2023-12-05 15:34:23 --> Router Class Initialized
INFO - 2023-12-05 15:34:23 --> Output Class Initialized
INFO - 2023-12-05 15:34:23 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:23 --> Input Class Initialized
INFO - 2023-12-05 15:34:23 --> Language Class Initialized
INFO - 2023-12-05 15:34:23 --> Language Class Initialized
INFO - 2023-12-05 15:34:23 --> Config Class Initialized
INFO - 2023-12-05 15:34:23 --> Loader Class Initialized
INFO - 2023-12-05 15:34:23 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:23 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:23 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:23 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:23 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:23 --> Controller Class Initialized
INFO - 2023-12-05 15:34:23 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:23 --> Total execution time: 0.0511
INFO - 2023-12-05 15:34:26 --> Config Class Initialized
INFO - 2023-12-05 15:34:26 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:26 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:26 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:26 --> URI Class Initialized
INFO - 2023-12-05 15:34:26 --> Router Class Initialized
INFO - 2023-12-05 15:34:26 --> Output Class Initialized
INFO - 2023-12-05 15:34:26 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:26 --> Input Class Initialized
INFO - 2023-12-05 15:34:26 --> Language Class Initialized
INFO - 2023-12-05 15:34:26 --> Language Class Initialized
INFO - 2023-12-05 15:34:26 --> Config Class Initialized
INFO - 2023-12-05 15:34:26 --> Loader Class Initialized
INFO - 2023-12-05 15:34:26 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:26 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:26 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:26 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:26 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:26 --> Controller Class Initialized
INFO - 2023-12-05 15:34:26 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:26 --> Total execution time: 0.0505
INFO - 2023-12-05 15:34:30 --> Config Class Initialized
INFO - 2023-12-05 15:34:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:30 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:30 --> URI Class Initialized
INFO - 2023-12-05 15:34:30 --> Router Class Initialized
INFO - 2023-12-05 15:34:30 --> Output Class Initialized
INFO - 2023-12-05 15:34:30 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:30 --> Input Class Initialized
INFO - 2023-12-05 15:34:30 --> Language Class Initialized
INFO - 2023-12-05 15:34:30 --> Language Class Initialized
INFO - 2023-12-05 15:34:30 --> Config Class Initialized
INFO - 2023-12-05 15:34:30 --> Loader Class Initialized
INFO - 2023-12-05 15:34:30 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:30 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:30 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:30 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:30 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:30 --> Controller Class Initialized
INFO - 2023-12-05 15:34:30 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:30 --> Total execution time: 0.0383
INFO - 2023-12-05 15:34:35 --> Config Class Initialized
INFO - 2023-12-05 15:34:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:35 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:35 --> URI Class Initialized
INFO - 2023-12-05 15:34:35 --> Router Class Initialized
INFO - 2023-12-05 15:34:35 --> Output Class Initialized
INFO - 2023-12-05 15:34:35 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:35 --> Input Class Initialized
INFO - 2023-12-05 15:34:35 --> Language Class Initialized
INFO - 2023-12-05 15:34:35 --> Language Class Initialized
INFO - 2023-12-05 15:34:35 --> Config Class Initialized
INFO - 2023-12-05 15:34:35 --> Loader Class Initialized
INFO - 2023-12-05 15:34:35 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:35 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:35 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:35 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:35 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:35 --> Controller Class Initialized
INFO - 2023-12-05 15:34:35 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:35 --> Total execution time: 0.0365
INFO - 2023-12-05 15:34:39 --> Config Class Initialized
INFO - 2023-12-05 15:34:39 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:34:39 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:34:39 --> Utf8 Class Initialized
INFO - 2023-12-05 15:34:39 --> URI Class Initialized
INFO - 2023-12-05 15:34:39 --> Router Class Initialized
INFO - 2023-12-05 15:34:39 --> Output Class Initialized
INFO - 2023-12-05 15:34:39 --> Security Class Initialized
DEBUG - 2023-12-05 15:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:34:39 --> Input Class Initialized
INFO - 2023-12-05 15:34:39 --> Language Class Initialized
INFO - 2023-12-05 15:34:39 --> Language Class Initialized
INFO - 2023-12-05 15:34:39 --> Config Class Initialized
INFO - 2023-12-05 15:34:39 --> Loader Class Initialized
INFO - 2023-12-05 15:34:39 --> Helper loaded: url_helper
INFO - 2023-12-05 15:34:39 --> Helper loaded: file_helper
INFO - 2023-12-05 15:34:39 --> Helper loaded: form_helper
INFO - 2023-12-05 15:34:39 --> Helper loaded: my_helper
INFO - 2023-12-05 15:34:39 --> Database Driver Class Initialized
INFO - 2023-12-05 15:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:34:39 --> Controller Class Initialized
INFO - 2023-12-05 15:34:39 --> Final output sent to browser
DEBUG - 2023-12-05 15:34:39 --> Total execution time: 0.0430
INFO - 2023-12-05 15:35:25 --> Config Class Initialized
INFO - 2023-12-05 15:35:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:25 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:25 --> URI Class Initialized
INFO - 2023-12-05 15:35:25 --> Router Class Initialized
INFO - 2023-12-05 15:35:25 --> Output Class Initialized
INFO - 2023-12-05 15:35:25 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:25 --> Input Class Initialized
INFO - 2023-12-05 15:35:25 --> Language Class Initialized
INFO - 2023-12-05 15:35:25 --> Language Class Initialized
INFO - 2023-12-05 15:35:25 --> Config Class Initialized
INFO - 2023-12-05 15:35:25 --> Loader Class Initialized
INFO - 2023-12-05 15:35:25 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:25 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:25 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:25 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:25 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:25 --> Controller Class Initialized
INFO - 2023-12-05 15:35:25 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:25 --> Total execution time: 0.1393
INFO - 2023-12-05 15:35:37 --> Config Class Initialized
INFO - 2023-12-05 15:35:37 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:37 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:37 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:37 --> URI Class Initialized
INFO - 2023-12-05 15:35:37 --> Router Class Initialized
INFO - 2023-12-05 15:35:37 --> Output Class Initialized
INFO - 2023-12-05 15:35:37 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:37 --> Input Class Initialized
INFO - 2023-12-05 15:35:37 --> Language Class Initialized
INFO - 2023-12-05 15:35:37 --> Language Class Initialized
INFO - 2023-12-05 15:35:37 --> Config Class Initialized
INFO - 2023-12-05 15:35:37 --> Loader Class Initialized
INFO - 2023-12-05 15:35:37 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:37 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:37 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:37 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:37 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:37 --> Controller Class Initialized
DEBUG - 2023-12-05 15:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:35:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:35:37 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:37 --> Total execution time: 0.0441
INFO - 2023-12-05 15:35:39 --> Config Class Initialized
INFO - 2023-12-05 15:35:39 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:39 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:39 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:39 --> URI Class Initialized
INFO - 2023-12-05 15:35:39 --> Router Class Initialized
INFO - 2023-12-05 15:35:39 --> Output Class Initialized
INFO - 2023-12-05 15:35:39 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:39 --> Input Class Initialized
INFO - 2023-12-05 15:35:39 --> Language Class Initialized
INFO - 2023-12-05 15:35:39 --> Language Class Initialized
INFO - 2023-12-05 15:35:39 --> Config Class Initialized
INFO - 2023-12-05 15:35:39 --> Loader Class Initialized
INFO - 2023-12-05 15:35:39 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:39 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:39 --> Controller Class Initialized
DEBUG - 2023-12-05 15:35:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:35:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:35:39 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:39 --> Total execution time: 0.0354
INFO - 2023-12-05 15:35:39 --> Config Class Initialized
INFO - 2023-12-05 15:35:39 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:39 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:39 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:39 --> URI Class Initialized
INFO - 2023-12-05 15:35:39 --> Router Class Initialized
INFO - 2023-12-05 15:35:39 --> Output Class Initialized
INFO - 2023-12-05 15:35:39 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:39 --> Input Class Initialized
INFO - 2023-12-05 15:35:39 --> Language Class Initialized
INFO - 2023-12-05 15:35:39 --> Language Class Initialized
INFO - 2023-12-05 15:35:39 --> Config Class Initialized
INFO - 2023-12-05 15:35:39 --> Loader Class Initialized
INFO - 2023-12-05 15:35:39 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:39 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:39 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:40 --> Controller Class Initialized
INFO - 2023-12-05 15:35:41 --> Config Class Initialized
INFO - 2023-12-05 15:35:41 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:41 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:41 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:41 --> URI Class Initialized
INFO - 2023-12-05 15:35:41 --> Router Class Initialized
INFO - 2023-12-05 15:35:41 --> Output Class Initialized
INFO - 2023-12-05 15:35:41 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:41 --> Input Class Initialized
INFO - 2023-12-05 15:35:41 --> Language Class Initialized
INFO - 2023-12-05 15:35:41 --> Language Class Initialized
INFO - 2023-12-05 15:35:41 --> Config Class Initialized
INFO - 2023-12-05 15:35:41 --> Loader Class Initialized
INFO - 2023-12-05 15:35:41 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:41 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:41 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:41 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:41 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:41 --> Controller Class Initialized
DEBUG - 2023-12-05 15:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/form.php
DEBUG - 2023-12-05 15:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:35:41 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:41 --> Total execution time: 0.0486
INFO - 2023-12-05 15:35:48 --> Config Class Initialized
INFO - 2023-12-05 15:35:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:48 --> URI Class Initialized
INFO - 2023-12-05 15:35:48 --> Router Class Initialized
INFO - 2023-12-05 15:35:48 --> Output Class Initialized
INFO - 2023-12-05 15:35:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:48 --> Input Class Initialized
INFO - 2023-12-05 15:35:48 --> Language Class Initialized
INFO - 2023-12-05 15:35:48 --> Language Class Initialized
INFO - 2023-12-05 15:35:48 --> Config Class Initialized
INFO - 2023-12-05 15:35:48 --> Loader Class Initialized
INFO - 2023-12-05 15:35:48 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:48 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:48 --> Controller Class Initialized
INFO - 2023-12-05 15:35:48 --> Config Class Initialized
INFO - 2023-12-05 15:35:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:48 --> URI Class Initialized
INFO - 2023-12-05 15:35:48 --> Router Class Initialized
INFO - 2023-12-05 15:35:48 --> Output Class Initialized
INFO - 2023-12-05 15:35:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:48 --> Input Class Initialized
INFO - 2023-12-05 15:35:48 --> Language Class Initialized
INFO - 2023-12-05 15:35:48 --> Language Class Initialized
INFO - 2023-12-05 15:35:48 --> Config Class Initialized
INFO - 2023-12-05 15:35:48 --> Loader Class Initialized
INFO - 2023-12-05 15:35:48 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:48 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:48 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:48 --> Controller Class Initialized
DEBUG - 2023-12-05 15:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-05 15:35:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:35:48 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:48 --> Total execution time: 0.0397
INFO - 2023-12-05 15:35:48 --> Config Class Initialized
INFO - 2023-12-05 15:35:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:48 --> URI Class Initialized
INFO - 2023-12-05 15:35:48 --> Router Class Initialized
INFO - 2023-12-05 15:35:48 --> Output Class Initialized
INFO - 2023-12-05 15:35:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:48 --> Input Class Initialized
INFO - 2023-12-05 15:35:48 --> Language Class Initialized
INFO - 2023-12-05 15:35:49 --> Language Class Initialized
INFO - 2023-12-05 15:35:49 --> Config Class Initialized
INFO - 2023-12-05 15:35:49 --> Loader Class Initialized
INFO - 2023-12-05 15:35:49 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:49 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:49 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:49 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:49 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:49 --> Controller Class Initialized
INFO - 2023-12-05 15:35:51 --> Config Class Initialized
INFO - 2023-12-05 15:35:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:51 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:51 --> URI Class Initialized
INFO - 2023-12-05 15:35:51 --> Router Class Initialized
INFO - 2023-12-05 15:35:51 --> Output Class Initialized
INFO - 2023-12-05 15:35:51 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:51 --> Input Class Initialized
INFO - 2023-12-05 15:35:51 --> Language Class Initialized
INFO - 2023-12-05 15:35:51 --> Language Class Initialized
INFO - 2023-12-05 15:35:51 --> Config Class Initialized
INFO - 2023-12-05 15:35:51 --> Loader Class Initialized
INFO - 2023-12-05 15:35:51 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:51 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:51 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:51 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:51 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:51 --> Controller Class Initialized
INFO - 2023-12-05 15:35:51 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:51 --> Total execution time: 0.0804
INFO - 2023-12-05 15:35:56 --> Config Class Initialized
INFO - 2023-12-05 15:35:56 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:56 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:56 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:56 --> URI Class Initialized
INFO - 2023-12-05 15:35:56 --> Router Class Initialized
INFO - 2023-12-05 15:35:56 --> Output Class Initialized
INFO - 2023-12-05 15:35:56 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:56 --> Input Class Initialized
INFO - 2023-12-05 15:35:56 --> Language Class Initialized
INFO - 2023-12-05 15:35:56 --> Language Class Initialized
INFO - 2023-12-05 15:35:56 --> Config Class Initialized
INFO - 2023-12-05 15:35:56 --> Loader Class Initialized
INFO - 2023-12-05 15:35:56 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:56 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:56 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:56 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:56 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:57 --> Controller Class Initialized
INFO - 2023-12-05 15:35:57 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:57 --> Total execution time: 0.0462
INFO - 2023-12-05 15:35:59 --> Config Class Initialized
INFO - 2023-12-05 15:35:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:35:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:35:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:35:59 --> URI Class Initialized
INFO - 2023-12-05 15:35:59 --> Router Class Initialized
INFO - 2023-12-05 15:35:59 --> Output Class Initialized
INFO - 2023-12-05 15:35:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:35:59 --> Input Class Initialized
INFO - 2023-12-05 15:35:59 --> Language Class Initialized
INFO - 2023-12-05 15:35:59 --> Language Class Initialized
INFO - 2023-12-05 15:35:59 --> Config Class Initialized
INFO - 2023-12-05 15:35:59 --> Loader Class Initialized
INFO - 2023-12-05 15:35:59 --> Helper loaded: url_helper
INFO - 2023-12-05 15:35:59 --> Helper loaded: file_helper
INFO - 2023-12-05 15:35:59 --> Helper loaded: form_helper
INFO - 2023-12-05 15:35:59 --> Helper loaded: my_helper
INFO - 2023-12-05 15:35:59 --> Database Driver Class Initialized
INFO - 2023-12-05 15:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:35:59 --> Controller Class Initialized
INFO - 2023-12-05 15:35:59 --> Final output sent to browser
DEBUG - 2023-12-05 15:35:59 --> Total execution time: 0.0960
INFO - 2023-12-05 15:36:47 --> Config Class Initialized
INFO - 2023-12-05 15:36:47 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:36:47 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:36:47 --> Utf8 Class Initialized
INFO - 2023-12-05 15:36:47 --> URI Class Initialized
INFO - 2023-12-05 15:36:47 --> Router Class Initialized
INFO - 2023-12-05 15:36:47 --> Output Class Initialized
INFO - 2023-12-05 15:36:47 --> Security Class Initialized
DEBUG - 2023-12-05 15:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:36:47 --> Input Class Initialized
INFO - 2023-12-05 15:36:47 --> Language Class Initialized
INFO - 2023-12-05 15:36:47 --> Language Class Initialized
INFO - 2023-12-05 15:36:47 --> Config Class Initialized
INFO - 2023-12-05 15:36:47 --> Loader Class Initialized
INFO - 2023-12-05 15:36:47 --> Helper loaded: url_helper
INFO - 2023-12-05 15:36:47 --> Helper loaded: file_helper
INFO - 2023-12-05 15:36:47 --> Helper loaded: form_helper
INFO - 2023-12-05 15:36:47 --> Helper loaded: my_helper
INFO - 2023-12-05 15:36:47 --> Database Driver Class Initialized
INFO - 2023-12-05 15:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:36:47 --> Controller Class Initialized
DEBUG - 2023-12-05 15:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-05 15:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:36:47 --> Final output sent to browser
DEBUG - 2023-12-05 15:36:47 --> Total execution time: 0.0484
INFO - 2023-12-05 15:49:40 --> Config Class Initialized
INFO - 2023-12-05 15:49:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:49:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:49:40 --> Utf8 Class Initialized
INFO - 2023-12-05 15:49:40 --> URI Class Initialized
INFO - 2023-12-05 15:49:40 --> Router Class Initialized
INFO - 2023-12-05 15:49:40 --> Output Class Initialized
INFO - 2023-12-05 15:49:40 --> Security Class Initialized
DEBUG - 2023-12-05 15:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:49:40 --> Input Class Initialized
INFO - 2023-12-05 15:49:40 --> Language Class Initialized
INFO - 2023-12-05 15:49:40 --> Language Class Initialized
INFO - 2023-12-05 15:49:40 --> Config Class Initialized
INFO - 2023-12-05 15:49:40 --> Loader Class Initialized
INFO - 2023-12-05 15:49:40 --> Helper loaded: url_helper
INFO - 2023-12-05 15:49:40 --> Helper loaded: file_helper
INFO - 2023-12-05 15:49:40 --> Helper loaded: form_helper
INFO - 2023-12-05 15:49:40 --> Helper loaded: my_helper
INFO - 2023-12-05 15:49:40 --> Database Driver Class Initialized
INFO - 2023-12-05 15:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:49:40 --> Controller Class Initialized
DEBUG - 2023-12-05 15:49:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 15:49:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:49:40 --> Final output sent to browser
DEBUG - 2023-12-05 15:49:40 --> Total execution time: 0.0630
INFO - 2023-12-05 15:51:33 --> Config Class Initialized
INFO - 2023-12-05 15:51:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:33 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:33 --> URI Class Initialized
INFO - 2023-12-05 15:51:33 --> Router Class Initialized
INFO - 2023-12-05 15:51:33 --> Output Class Initialized
INFO - 2023-12-05 15:51:33 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:33 --> Input Class Initialized
INFO - 2023-12-05 15:51:33 --> Language Class Initialized
INFO - 2023-12-05 15:51:33 --> Language Class Initialized
INFO - 2023-12-05 15:51:33 --> Config Class Initialized
INFO - 2023-12-05 15:51:33 --> Loader Class Initialized
INFO - 2023-12-05 15:51:33 --> Helper loaded: url_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: file_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: form_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: my_helper
INFO - 2023-12-05 15:51:33 --> Database Driver Class Initialized
INFO - 2023-12-05 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:51:33 --> Controller Class Initialized
INFO - 2023-12-05 15:51:33 --> Helper loaded: cookie_helper
INFO - 2023-12-05 15:51:33 --> Final output sent to browser
DEBUG - 2023-12-05 15:51:33 --> Total execution time: 0.0422
INFO - 2023-12-05 15:51:33 --> Config Class Initialized
INFO - 2023-12-05 15:51:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:33 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:33 --> URI Class Initialized
INFO - 2023-12-05 15:51:33 --> Router Class Initialized
INFO - 2023-12-05 15:51:33 --> Output Class Initialized
INFO - 2023-12-05 15:51:33 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:33 --> Input Class Initialized
INFO - 2023-12-05 15:51:33 --> Language Class Initialized
INFO - 2023-12-05 15:51:33 --> Language Class Initialized
INFO - 2023-12-05 15:51:33 --> Config Class Initialized
INFO - 2023-12-05 15:51:33 --> Loader Class Initialized
INFO - 2023-12-05 15:51:33 --> Helper loaded: url_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: file_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: form_helper
INFO - 2023-12-05 15:51:33 --> Helper loaded: my_helper
INFO - 2023-12-05 15:51:33 --> Database Driver Class Initialized
INFO - 2023-12-05 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:51:33 --> Controller Class Initialized
DEBUG - 2023-12-05 15:51:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-05 15:51:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:51:33 --> Final output sent to browser
DEBUG - 2023-12-05 15:51:33 --> Total execution time: 0.0399
INFO - 2023-12-05 15:51:38 --> Config Class Initialized
INFO - 2023-12-05 15:51:38 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:38 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:38 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:38 --> URI Class Initialized
INFO - 2023-12-05 15:51:38 --> Router Class Initialized
INFO - 2023-12-05 15:51:38 --> Output Class Initialized
INFO - 2023-12-05 15:51:38 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:38 --> Input Class Initialized
INFO - 2023-12-05 15:51:38 --> Language Class Initialized
INFO - 2023-12-05 15:51:38 --> Language Class Initialized
INFO - 2023-12-05 15:51:38 --> Config Class Initialized
INFO - 2023-12-05 15:51:38 --> Loader Class Initialized
INFO - 2023-12-05 15:51:38 --> Helper loaded: url_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: file_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: form_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: my_helper
INFO - 2023-12-05 15:51:38 --> Database Driver Class Initialized
INFO - 2023-12-05 15:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:51:38 --> Controller Class Initialized
DEBUG - 2023-12-05 15:51:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2023-12-05 15:51:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:51:38 --> Final output sent to browser
DEBUG - 2023-12-05 15:51:38 --> Total execution time: 0.0383
INFO - 2023-12-05 15:51:38 --> Config Class Initialized
INFO - 2023-12-05 15:51:38 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:38 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:38 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:38 --> URI Class Initialized
INFO - 2023-12-05 15:51:38 --> Router Class Initialized
INFO - 2023-12-05 15:51:38 --> Output Class Initialized
INFO - 2023-12-05 15:51:38 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:38 --> Input Class Initialized
INFO - 2023-12-05 15:51:38 --> Language Class Initialized
ERROR - 2023-12-05 15:51:38 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:51:38 --> Config Class Initialized
INFO - 2023-12-05 15:51:38 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:38 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:38 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:38 --> URI Class Initialized
INFO - 2023-12-05 15:51:38 --> Router Class Initialized
INFO - 2023-12-05 15:51:38 --> Output Class Initialized
INFO - 2023-12-05 15:51:38 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:38 --> Input Class Initialized
INFO - 2023-12-05 15:51:38 --> Language Class Initialized
INFO - 2023-12-05 15:51:38 --> Language Class Initialized
INFO - 2023-12-05 15:51:38 --> Config Class Initialized
INFO - 2023-12-05 15:51:38 --> Loader Class Initialized
INFO - 2023-12-05 15:51:38 --> Helper loaded: url_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: file_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: form_helper
INFO - 2023-12-05 15:51:38 --> Helper loaded: my_helper
INFO - 2023-12-05 15:51:38 --> Database Driver Class Initialized
INFO - 2023-12-05 15:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:51:38 --> Controller Class Initialized
INFO - 2023-12-05 15:51:40 --> Config Class Initialized
INFO - 2023-12-05 15:51:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:51:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:51:40 --> Utf8 Class Initialized
INFO - 2023-12-05 15:51:40 --> URI Class Initialized
INFO - 2023-12-05 15:51:40 --> Router Class Initialized
INFO - 2023-12-05 15:51:40 --> Output Class Initialized
INFO - 2023-12-05 15:51:40 --> Security Class Initialized
DEBUG - 2023-12-05 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:51:40 --> Input Class Initialized
INFO - 2023-12-05 15:51:40 --> Language Class Initialized
INFO - 2023-12-05 15:51:40 --> Language Class Initialized
INFO - 2023-12-05 15:51:40 --> Config Class Initialized
INFO - 2023-12-05 15:51:40 --> Loader Class Initialized
INFO - 2023-12-05 15:51:40 --> Helper loaded: url_helper
INFO - 2023-12-05 15:51:40 --> Helper loaded: file_helper
INFO - 2023-12-05 15:51:40 --> Helper loaded: form_helper
INFO - 2023-12-05 15:51:40 --> Helper loaded: my_helper
INFO - 2023-12-05 15:51:40 --> Database Driver Class Initialized
INFO - 2023-12-05 15:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:51:40 --> Controller Class Initialized
INFO - 2023-12-05 15:51:40 --> Final output sent to browser
DEBUG - 2023-12-05 15:51:40 --> Total execution time: 0.0654
INFO - 2023-12-05 15:52:24 --> Config Class Initialized
INFO - 2023-12-05 15:52:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:52:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:52:24 --> Utf8 Class Initialized
INFO - 2023-12-05 15:52:24 --> URI Class Initialized
INFO - 2023-12-05 15:52:24 --> Router Class Initialized
INFO - 2023-12-05 15:52:24 --> Output Class Initialized
INFO - 2023-12-05 15:52:24 --> Security Class Initialized
DEBUG - 2023-12-05 15:52:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:52:24 --> Input Class Initialized
INFO - 2023-12-05 15:52:24 --> Language Class Initialized
INFO - 2023-12-05 15:52:24 --> Language Class Initialized
INFO - 2023-12-05 15:52:24 --> Config Class Initialized
INFO - 2023-12-05 15:52:24 --> Loader Class Initialized
INFO - 2023-12-05 15:52:24 --> Helper loaded: url_helper
INFO - 2023-12-05 15:52:24 --> Helper loaded: file_helper
INFO - 2023-12-05 15:52:24 --> Helper loaded: form_helper
INFO - 2023-12-05 15:52:24 --> Helper loaded: my_helper
INFO - 2023-12-05 15:52:24 --> Database Driver Class Initialized
INFO - 2023-12-05 15:52:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:52:24 --> Controller Class Initialized
INFO - 2023-12-05 15:52:25 --> Final output sent to browser
DEBUG - 2023-12-05 15:52:25 --> Total execution time: 0.1034
INFO - 2023-12-05 15:52:25 --> Config Class Initialized
INFO - 2023-12-05 15:52:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:52:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:52:25 --> Utf8 Class Initialized
INFO - 2023-12-05 15:52:25 --> URI Class Initialized
INFO - 2023-12-05 15:52:25 --> Router Class Initialized
INFO - 2023-12-05 15:52:25 --> Output Class Initialized
INFO - 2023-12-05 15:52:25 --> Security Class Initialized
DEBUG - 2023-12-05 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:52:25 --> Input Class Initialized
INFO - 2023-12-05 15:52:25 --> Language Class Initialized
ERROR - 2023-12-05 15:52:25 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:52:25 --> Config Class Initialized
INFO - 2023-12-05 15:52:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:52:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:52:25 --> Utf8 Class Initialized
INFO - 2023-12-05 15:52:25 --> URI Class Initialized
INFO - 2023-12-05 15:52:25 --> Router Class Initialized
INFO - 2023-12-05 15:52:25 --> Output Class Initialized
INFO - 2023-12-05 15:52:25 --> Security Class Initialized
DEBUG - 2023-12-05 15:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:52:25 --> Input Class Initialized
INFO - 2023-12-05 15:52:25 --> Language Class Initialized
INFO - 2023-12-05 15:52:25 --> Language Class Initialized
INFO - 2023-12-05 15:52:25 --> Config Class Initialized
INFO - 2023-12-05 15:52:25 --> Loader Class Initialized
INFO - 2023-12-05 15:52:25 --> Helper loaded: url_helper
INFO - 2023-12-05 15:52:25 --> Helper loaded: file_helper
INFO - 2023-12-05 15:52:25 --> Helper loaded: form_helper
INFO - 2023-12-05 15:52:25 --> Helper loaded: my_helper
INFO - 2023-12-05 15:52:25 --> Database Driver Class Initialized
INFO - 2023-12-05 15:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:52:25 --> Controller Class Initialized
INFO - 2023-12-05 15:52:29 --> Config Class Initialized
INFO - 2023-12-05 15:52:29 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:52:29 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:52:29 --> Utf8 Class Initialized
INFO - 2023-12-05 15:52:29 --> URI Class Initialized
INFO - 2023-12-05 15:52:29 --> Router Class Initialized
INFO - 2023-12-05 15:52:29 --> Output Class Initialized
INFO - 2023-12-05 15:52:29 --> Security Class Initialized
DEBUG - 2023-12-05 15:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:52:29 --> Input Class Initialized
INFO - 2023-12-05 15:52:29 --> Language Class Initialized
INFO - 2023-12-05 15:52:29 --> Language Class Initialized
INFO - 2023-12-05 15:52:29 --> Config Class Initialized
INFO - 2023-12-05 15:52:29 --> Loader Class Initialized
INFO - 2023-12-05 15:52:29 --> Helper loaded: url_helper
INFO - 2023-12-05 15:52:29 --> Helper loaded: file_helper
INFO - 2023-12-05 15:52:29 --> Helper loaded: form_helper
INFO - 2023-12-05 15:52:29 --> Helper loaded: my_helper
INFO - 2023-12-05 15:52:29 --> Database Driver Class Initialized
INFO - 2023-12-05 15:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:52:29 --> Controller Class Initialized
INFO - 2023-12-05 15:52:29 --> Final output sent to browser
DEBUG - 2023-12-05 15:52:29 --> Total execution time: 0.0556
INFO - 2023-12-05 15:53:06 --> Config Class Initialized
INFO - 2023-12-05 15:53:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:06 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:06 --> URI Class Initialized
INFO - 2023-12-05 15:53:06 --> Router Class Initialized
INFO - 2023-12-05 15:53:06 --> Output Class Initialized
INFO - 2023-12-05 15:53:06 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:06 --> Input Class Initialized
INFO - 2023-12-05 15:53:06 --> Language Class Initialized
INFO - 2023-12-05 15:53:06 --> Language Class Initialized
INFO - 2023-12-05 15:53:06 --> Config Class Initialized
INFO - 2023-12-05 15:53:06 --> Loader Class Initialized
INFO - 2023-12-05 15:53:06 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:06 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:06 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:06 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:06 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:07 --> Controller Class Initialized
INFO - 2023-12-05 15:53:07 --> Final output sent to browser
DEBUG - 2023-12-05 15:53:07 --> Total execution time: 0.1077
INFO - 2023-12-05 15:53:07 --> Config Class Initialized
INFO - 2023-12-05 15:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:07 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:07 --> URI Class Initialized
INFO - 2023-12-05 15:53:07 --> Router Class Initialized
INFO - 2023-12-05 15:53:07 --> Output Class Initialized
INFO - 2023-12-05 15:53:07 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:07 --> Input Class Initialized
INFO - 2023-12-05 15:53:07 --> Language Class Initialized
ERROR - 2023-12-05 15:53:07 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:53:07 --> Config Class Initialized
INFO - 2023-12-05 15:53:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:07 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:07 --> URI Class Initialized
INFO - 2023-12-05 15:53:07 --> Router Class Initialized
INFO - 2023-12-05 15:53:07 --> Output Class Initialized
INFO - 2023-12-05 15:53:07 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:07 --> Input Class Initialized
INFO - 2023-12-05 15:53:07 --> Language Class Initialized
INFO - 2023-12-05 15:53:07 --> Language Class Initialized
INFO - 2023-12-05 15:53:07 --> Config Class Initialized
INFO - 2023-12-05 15:53:07 --> Loader Class Initialized
INFO - 2023-12-05 15:53:07 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:07 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:07 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:07 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:07 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:07 --> Controller Class Initialized
INFO - 2023-12-05 15:53:22 --> Config Class Initialized
INFO - 2023-12-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:22 --> URI Class Initialized
INFO - 2023-12-05 15:53:22 --> Router Class Initialized
INFO - 2023-12-05 15:53:22 --> Output Class Initialized
INFO - 2023-12-05 15:53:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:22 --> Input Class Initialized
INFO - 2023-12-05 15:53:22 --> Language Class Initialized
INFO - 2023-12-05 15:53:22 --> Language Class Initialized
INFO - 2023-12-05 15:53:22 --> Config Class Initialized
INFO - 2023-12-05 15:53:22 --> Loader Class Initialized
INFO - 2023-12-05 15:53:22 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:22 --> Controller Class Initialized
DEBUG - 2023-12-05 15:53:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelompok/views/list.php
DEBUG - 2023-12-05 15:53:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:53:22 --> Final output sent to browser
DEBUG - 2023-12-05 15:53:22 --> Total execution time: 0.0361
INFO - 2023-12-05 15:53:22 --> Config Class Initialized
INFO - 2023-12-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:22 --> URI Class Initialized
INFO - 2023-12-05 15:53:22 --> Router Class Initialized
INFO - 2023-12-05 15:53:22 --> Output Class Initialized
INFO - 2023-12-05 15:53:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:22 --> Input Class Initialized
INFO - 2023-12-05 15:53:22 --> Language Class Initialized
ERROR - 2023-12-05 15:53:22 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:53:22 --> Config Class Initialized
INFO - 2023-12-05 15:53:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:22 --> URI Class Initialized
INFO - 2023-12-05 15:53:22 --> Router Class Initialized
INFO - 2023-12-05 15:53:22 --> Output Class Initialized
INFO - 2023-12-05 15:53:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:22 --> Input Class Initialized
INFO - 2023-12-05 15:53:22 --> Language Class Initialized
INFO - 2023-12-05 15:53:22 --> Language Class Initialized
INFO - 2023-12-05 15:53:22 --> Config Class Initialized
INFO - 2023-12-05 15:53:22 --> Loader Class Initialized
INFO - 2023-12-05 15:53:22 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:22 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:22 --> Controller Class Initialized
INFO - 2023-12-05 15:53:24 --> Config Class Initialized
INFO - 2023-12-05 15:53:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:24 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:24 --> URI Class Initialized
INFO - 2023-12-05 15:53:24 --> Router Class Initialized
INFO - 2023-12-05 15:53:24 --> Output Class Initialized
INFO - 2023-12-05 15:53:24 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:24 --> Input Class Initialized
INFO - 2023-12-05 15:53:24 --> Language Class Initialized
INFO - 2023-12-05 15:53:24 --> Language Class Initialized
INFO - 2023-12-05 15:53:24 --> Config Class Initialized
INFO - 2023-12-05 15:53:24 --> Loader Class Initialized
INFO - 2023-12-05 15:53:24 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:24 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:24 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:24 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:24 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:24 --> Controller Class Initialized
INFO - 2023-12-05 15:53:24 --> Final output sent to browser
DEBUG - 2023-12-05 15:53:24 --> Total execution time: 0.0469
INFO - 2023-12-05 15:53:42 --> Config Class Initialized
INFO - 2023-12-05 15:53:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:53:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:53:42 --> Utf8 Class Initialized
INFO - 2023-12-05 15:53:42 --> URI Class Initialized
INFO - 2023-12-05 15:53:42 --> Router Class Initialized
INFO - 2023-12-05 15:53:42 --> Output Class Initialized
INFO - 2023-12-05 15:53:42 --> Security Class Initialized
DEBUG - 2023-12-05 15:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:53:42 --> Input Class Initialized
INFO - 2023-12-05 15:53:42 --> Language Class Initialized
INFO - 2023-12-05 15:53:42 --> Language Class Initialized
INFO - 2023-12-05 15:53:42 --> Config Class Initialized
INFO - 2023-12-05 15:53:42 --> Loader Class Initialized
INFO - 2023-12-05 15:53:42 --> Helper loaded: url_helper
INFO - 2023-12-05 15:53:42 --> Helper loaded: file_helper
INFO - 2023-12-05 15:53:42 --> Helper loaded: form_helper
INFO - 2023-12-05 15:53:42 --> Helper loaded: my_helper
INFO - 2023-12-05 15:53:42 --> Database Driver Class Initialized
INFO - 2023-12-05 15:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:53:42 --> Controller Class Initialized
INFO - 2023-12-05 15:53:42 --> Final output sent to browser
DEBUG - 2023-12-05 15:53:42 --> Total execution time: 0.0351
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Loader Class Initialized
INFO - 2023-12-05 15:54:03 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:03 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:03 --> Controller Class Initialized
INFO - 2023-12-05 15:54:03 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:03 --> Total execution time: 0.1450
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
ERROR - 2023-12-05 15:54:03 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Loader Class Initialized
INFO - 2023-12-05 15:54:03 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Loader Class Initialized
INFO - 2023-12-05 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:03 --> Controller Class Initialized
INFO - 2023-12-05 15:54:03 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:03 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:03 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:03 --> Total execution time: 0.1528
INFO - 2023-12-05 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:03 --> Controller Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
ERROR - 2023-12-05 15:54:03 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:03 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:03 --> URI Class Initialized
INFO - 2023-12-05 15:54:03 --> Router Class Initialized
INFO - 2023-12-05 15:54:03 --> Output Class Initialized
INFO - 2023-12-05 15:54:03 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:03 --> Input Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Language Class Initialized
INFO - 2023-12-05 15:54:03 --> Config Class Initialized
INFO - 2023-12-05 15:54:03 --> Loader Class Initialized
INFO - 2023-12-05 15:54:03 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:03 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:03 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:03 --> Controller Class Initialized
INFO - 2023-12-05 15:54:07 --> Config Class Initialized
INFO - 2023-12-05 15:54:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:07 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:07 --> URI Class Initialized
INFO - 2023-12-05 15:54:07 --> Router Class Initialized
INFO - 2023-12-05 15:54:07 --> Output Class Initialized
INFO - 2023-12-05 15:54:07 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:07 --> Input Class Initialized
INFO - 2023-12-05 15:54:07 --> Language Class Initialized
INFO - 2023-12-05 15:54:07 --> Language Class Initialized
INFO - 2023-12-05 15:54:07 --> Config Class Initialized
INFO - 2023-12-05 15:54:07 --> Loader Class Initialized
INFO - 2023-12-05 15:54:07 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:07 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:07 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:07 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:07 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:07 --> Controller Class Initialized
INFO - 2023-12-05 15:54:08 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:08 --> Total execution time: 0.1124
INFO - 2023-12-05 15:54:08 --> Config Class Initialized
INFO - 2023-12-05 15:54:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:08 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:08 --> URI Class Initialized
INFO - 2023-12-05 15:54:08 --> Router Class Initialized
INFO - 2023-12-05 15:54:08 --> Output Class Initialized
INFO - 2023-12-05 15:54:08 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:08 --> Input Class Initialized
INFO - 2023-12-05 15:54:08 --> Language Class Initialized
ERROR - 2023-12-05 15:54:08 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:54:08 --> Config Class Initialized
INFO - 2023-12-05 15:54:08 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:08 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:08 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:08 --> URI Class Initialized
INFO - 2023-12-05 15:54:08 --> Router Class Initialized
INFO - 2023-12-05 15:54:08 --> Output Class Initialized
INFO - 2023-12-05 15:54:08 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:08 --> Input Class Initialized
INFO - 2023-12-05 15:54:08 --> Language Class Initialized
INFO - 2023-12-05 15:54:08 --> Language Class Initialized
INFO - 2023-12-05 15:54:08 --> Config Class Initialized
INFO - 2023-12-05 15:54:08 --> Loader Class Initialized
INFO - 2023-12-05 15:54:08 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:08 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:08 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:08 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:08 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:08 --> Controller Class Initialized
INFO - 2023-12-05 15:54:09 --> Config Class Initialized
INFO - 2023-12-05 15:54:09 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:09 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:09 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:09 --> URI Class Initialized
INFO - 2023-12-05 15:54:09 --> Router Class Initialized
INFO - 2023-12-05 15:54:09 --> Output Class Initialized
INFO - 2023-12-05 15:54:09 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:09 --> Input Class Initialized
INFO - 2023-12-05 15:54:09 --> Language Class Initialized
INFO - 2023-12-05 15:54:09 --> Language Class Initialized
INFO - 2023-12-05 15:54:09 --> Config Class Initialized
INFO - 2023-12-05 15:54:09 --> Loader Class Initialized
INFO - 2023-12-05 15:54:09 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:09 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:09 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:09 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:09 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:09 --> Controller Class Initialized
INFO - 2023-12-05 15:54:09 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:09 --> Total execution time: 0.0346
INFO - 2023-12-05 15:54:33 --> Config Class Initialized
INFO - 2023-12-05 15:54:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:33 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:33 --> URI Class Initialized
INFO - 2023-12-05 15:54:33 --> Router Class Initialized
INFO - 2023-12-05 15:54:33 --> Output Class Initialized
INFO - 2023-12-05 15:54:33 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:33 --> Input Class Initialized
INFO - 2023-12-05 15:54:33 --> Language Class Initialized
INFO - 2023-12-05 15:54:33 --> Language Class Initialized
INFO - 2023-12-05 15:54:33 --> Config Class Initialized
INFO - 2023-12-05 15:54:33 --> Loader Class Initialized
INFO - 2023-12-05 15:54:33 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:33 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:33 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:33 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:33 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:33 --> Controller Class Initialized
INFO - 2023-12-05 15:54:33 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:33 --> Total execution time: 0.0577
INFO - 2023-12-05 15:54:34 --> Config Class Initialized
INFO - 2023-12-05 15:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:34 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:34 --> URI Class Initialized
INFO - 2023-12-05 15:54:34 --> Router Class Initialized
INFO - 2023-12-05 15:54:34 --> Output Class Initialized
INFO - 2023-12-05 15:54:34 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:34 --> Input Class Initialized
INFO - 2023-12-05 15:54:34 --> Language Class Initialized
ERROR - 2023-12-05 15:54:34 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:54:34 --> Config Class Initialized
INFO - 2023-12-05 15:54:34 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:34 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:34 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:34 --> URI Class Initialized
INFO - 2023-12-05 15:54:34 --> Router Class Initialized
INFO - 2023-12-05 15:54:34 --> Output Class Initialized
INFO - 2023-12-05 15:54:34 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:34 --> Input Class Initialized
INFO - 2023-12-05 15:54:34 --> Language Class Initialized
INFO - 2023-12-05 15:54:34 --> Language Class Initialized
INFO - 2023-12-05 15:54:34 --> Config Class Initialized
INFO - 2023-12-05 15:54:34 --> Loader Class Initialized
INFO - 2023-12-05 15:54:34 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:34 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:34 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:34 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:34 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:34 --> Controller Class Initialized
INFO - 2023-12-05 15:54:36 --> Config Class Initialized
INFO - 2023-12-05 15:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:36 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:36 --> URI Class Initialized
INFO - 2023-12-05 15:54:36 --> Router Class Initialized
INFO - 2023-12-05 15:54:36 --> Output Class Initialized
INFO - 2023-12-05 15:54:36 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:36 --> Input Class Initialized
INFO - 2023-12-05 15:54:36 --> Language Class Initialized
INFO - 2023-12-05 15:54:36 --> Language Class Initialized
INFO - 2023-12-05 15:54:36 --> Config Class Initialized
INFO - 2023-12-05 15:54:36 --> Loader Class Initialized
INFO - 2023-12-05 15:54:36 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:36 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:36 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:36 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:36 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:36 --> Controller Class Initialized
INFO - 2023-12-05 15:54:36 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:36 --> Total execution time: 0.0364
INFO - 2023-12-05 15:54:50 --> Config Class Initialized
INFO - 2023-12-05 15:54:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:50 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:50 --> URI Class Initialized
INFO - 2023-12-05 15:54:50 --> Router Class Initialized
INFO - 2023-12-05 15:54:50 --> Output Class Initialized
INFO - 2023-12-05 15:54:50 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:50 --> Input Class Initialized
INFO - 2023-12-05 15:54:50 --> Language Class Initialized
INFO - 2023-12-05 15:54:50 --> Language Class Initialized
INFO - 2023-12-05 15:54:50 --> Config Class Initialized
INFO - 2023-12-05 15:54:50 --> Loader Class Initialized
INFO - 2023-12-05 15:54:50 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:50 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:50 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:50 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:50 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:50 --> Controller Class Initialized
INFO - 2023-12-05 15:54:50 --> Final output sent to browser
DEBUG - 2023-12-05 15:54:50 --> Total execution time: 0.0518
INFO - 2023-12-05 15:54:50 --> Config Class Initialized
INFO - 2023-12-05 15:54:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:50 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:50 --> URI Class Initialized
INFO - 2023-12-05 15:54:50 --> Router Class Initialized
INFO - 2023-12-05 15:54:50 --> Output Class Initialized
INFO - 2023-12-05 15:54:50 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:50 --> Input Class Initialized
INFO - 2023-12-05 15:54:50 --> Language Class Initialized
ERROR - 2023-12-05 15:54:50 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:54:51 --> Config Class Initialized
INFO - 2023-12-05 15:54:51 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:54:51 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:54:51 --> Utf8 Class Initialized
INFO - 2023-12-05 15:54:51 --> URI Class Initialized
INFO - 2023-12-05 15:54:51 --> Router Class Initialized
INFO - 2023-12-05 15:54:51 --> Output Class Initialized
INFO - 2023-12-05 15:54:51 --> Security Class Initialized
DEBUG - 2023-12-05 15:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:54:51 --> Input Class Initialized
INFO - 2023-12-05 15:54:51 --> Language Class Initialized
INFO - 2023-12-05 15:54:51 --> Language Class Initialized
INFO - 2023-12-05 15:54:51 --> Config Class Initialized
INFO - 2023-12-05 15:54:51 --> Loader Class Initialized
INFO - 2023-12-05 15:54:51 --> Helper loaded: url_helper
INFO - 2023-12-05 15:54:51 --> Helper loaded: file_helper
INFO - 2023-12-05 15:54:51 --> Helper loaded: form_helper
INFO - 2023-12-05 15:54:51 --> Helper loaded: my_helper
INFO - 2023-12-05 15:54:51 --> Database Driver Class Initialized
INFO - 2023-12-05 15:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:54:51 --> Controller Class Initialized
INFO - 2023-12-05 15:55:07 --> Config Class Initialized
INFO - 2023-12-05 15:55:07 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:07 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:07 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:07 --> URI Class Initialized
INFO - 2023-12-05 15:55:07 --> Router Class Initialized
INFO - 2023-12-05 15:55:07 --> Output Class Initialized
INFO - 2023-12-05 15:55:07 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:07 --> Input Class Initialized
INFO - 2023-12-05 15:55:07 --> Language Class Initialized
INFO - 2023-12-05 15:55:07 --> Language Class Initialized
INFO - 2023-12-05 15:55:07 --> Config Class Initialized
INFO - 2023-12-05 15:55:07 --> Loader Class Initialized
INFO - 2023-12-05 15:55:07 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:07 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:07 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:07 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:07 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:07 --> Controller Class Initialized
INFO - 2023-12-05 15:55:07 --> Final output sent to browser
DEBUG - 2023-12-05 15:55:07 --> Total execution time: 0.0713
INFO - 2023-12-05 15:55:29 --> Config Class Initialized
INFO - 2023-12-05 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:29 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:29 --> URI Class Initialized
INFO - 2023-12-05 15:55:29 --> Router Class Initialized
INFO - 2023-12-05 15:55:29 --> Output Class Initialized
INFO - 2023-12-05 15:55:29 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:29 --> Input Class Initialized
INFO - 2023-12-05 15:55:29 --> Language Class Initialized
INFO - 2023-12-05 15:55:29 --> Language Class Initialized
INFO - 2023-12-05 15:55:29 --> Config Class Initialized
INFO - 2023-12-05 15:55:29 --> Loader Class Initialized
INFO - 2023-12-05 15:55:29 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:29 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:29 --> Controller Class Initialized
INFO - 2023-12-05 15:55:29 --> Final output sent to browser
DEBUG - 2023-12-05 15:55:29 --> Total execution time: 0.0989
INFO - 2023-12-05 15:55:29 --> Config Class Initialized
INFO - 2023-12-05 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:29 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:29 --> URI Class Initialized
INFO - 2023-12-05 15:55:29 --> Router Class Initialized
INFO - 2023-12-05 15:55:29 --> Output Class Initialized
INFO - 2023-12-05 15:55:29 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:29 --> Input Class Initialized
INFO - 2023-12-05 15:55:29 --> Language Class Initialized
ERROR - 2023-12-05 15:55:29 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:55:29 --> Config Class Initialized
INFO - 2023-12-05 15:55:29 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:29 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:29 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:29 --> URI Class Initialized
INFO - 2023-12-05 15:55:29 --> Router Class Initialized
INFO - 2023-12-05 15:55:29 --> Output Class Initialized
INFO - 2023-12-05 15:55:29 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:29 --> Input Class Initialized
INFO - 2023-12-05 15:55:29 --> Language Class Initialized
INFO - 2023-12-05 15:55:29 --> Language Class Initialized
INFO - 2023-12-05 15:55:29 --> Config Class Initialized
INFO - 2023-12-05 15:55:29 --> Loader Class Initialized
INFO - 2023-12-05 15:55:29 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:29 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:29 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:29 --> Controller Class Initialized
INFO - 2023-12-05 15:55:35 --> Config Class Initialized
INFO - 2023-12-05 15:55:35 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:35 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:35 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:35 --> URI Class Initialized
INFO - 2023-12-05 15:55:35 --> Router Class Initialized
INFO - 2023-12-05 15:55:35 --> Output Class Initialized
INFO - 2023-12-05 15:55:35 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:35 --> Input Class Initialized
INFO - 2023-12-05 15:55:35 --> Language Class Initialized
INFO - 2023-12-05 15:55:35 --> Language Class Initialized
INFO - 2023-12-05 15:55:35 --> Config Class Initialized
INFO - 2023-12-05 15:55:35 --> Loader Class Initialized
INFO - 2023-12-05 15:55:35 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:35 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:35 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:35 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:35 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:35 --> Controller Class Initialized
INFO - 2023-12-05 15:55:35 --> Final output sent to browser
DEBUG - 2023-12-05 15:55:35 --> Total execution time: 0.0347
INFO - 2023-12-05 15:55:48 --> Config Class Initialized
INFO - 2023-12-05 15:55:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:48 --> URI Class Initialized
INFO - 2023-12-05 15:55:48 --> Router Class Initialized
INFO - 2023-12-05 15:55:48 --> Output Class Initialized
INFO - 2023-12-05 15:55:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:48 --> Input Class Initialized
INFO - 2023-12-05 15:55:48 --> Language Class Initialized
INFO - 2023-12-05 15:55:48 --> Language Class Initialized
INFO - 2023-12-05 15:55:48 --> Config Class Initialized
INFO - 2023-12-05 15:55:48 --> Loader Class Initialized
INFO - 2023-12-05 15:55:48 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:48 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:48 --> Controller Class Initialized
INFO - 2023-12-05 15:55:48 --> Final output sent to browser
DEBUG - 2023-12-05 15:55:48 --> Total execution time: 0.0757
INFO - 2023-12-05 15:55:48 --> Config Class Initialized
INFO - 2023-12-05 15:55:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:48 --> URI Class Initialized
INFO - 2023-12-05 15:55:48 --> Router Class Initialized
INFO - 2023-12-05 15:55:48 --> Output Class Initialized
INFO - 2023-12-05 15:55:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:48 --> Input Class Initialized
INFO - 2023-12-05 15:55:48 --> Language Class Initialized
ERROR - 2023-12-05 15:55:48 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:55:48 --> Config Class Initialized
INFO - 2023-12-05 15:55:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:55:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:55:48 --> Utf8 Class Initialized
INFO - 2023-12-05 15:55:48 --> URI Class Initialized
INFO - 2023-12-05 15:55:48 --> Router Class Initialized
INFO - 2023-12-05 15:55:48 --> Output Class Initialized
INFO - 2023-12-05 15:55:48 --> Security Class Initialized
DEBUG - 2023-12-05 15:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:55:48 --> Input Class Initialized
INFO - 2023-12-05 15:55:48 --> Language Class Initialized
INFO - 2023-12-05 15:55:48 --> Language Class Initialized
INFO - 2023-12-05 15:55:48 --> Config Class Initialized
INFO - 2023-12-05 15:55:48 --> Loader Class Initialized
INFO - 2023-12-05 15:55:48 --> Helper loaded: url_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: file_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: form_helper
INFO - 2023-12-05 15:55:48 --> Helper loaded: my_helper
INFO - 2023-12-05 15:55:48 --> Database Driver Class Initialized
INFO - 2023-12-05 15:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:55:48 --> Controller Class Initialized
INFO - 2023-12-05 15:56:04 --> Config Class Initialized
INFO - 2023-12-05 15:56:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:04 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:04 --> URI Class Initialized
INFO - 2023-12-05 15:56:04 --> Router Class Initialized
INFO - 2023-12-05 15:56:04 --> Output Class Initialized
INFO - 2023-12-05 15:56:04 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:04 --> Input Class Initialized
INFO - 2023-12-05 15:56:04 --> Language Class Initialized
INFO - 2023-12-05 15:56:04 --> Language Class Initialized
INFO - 2023-12-05 15:56:04 --> Config Class Initialized
INFO - 2023-12-05 15:56:04 --> Loader Class Initialized
INFO - 2023-12-05 15:56:04 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:04 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:04 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:04 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:04 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:04 --> Controller Class Initialized
INFO - 2023-12-05 15:56:04 --> Final output sent to browser
DEBUG - 2023-12-05 15:56:04 --> Total execution time: 0.0388
INFO - 2023-12-05 15:56:18 --> Config Class Initialized
INFO - 2023-12-05 15:56:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:18 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:18 --> URI Class Initialized
INFO - 2023-12-05 15:56:18 --> Router Class Initialized
INFO - 2023-12-05 15:56:18 --> Output Class Initialized
INFO - 2023-12-05 15:56:18 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:18 --> Input Class Initialized
INFO - 2023-12-05 15:56:18 --> Language Class Initialized
INFO - 2023-12-05 15:56:18 --> Language Class Initialized
INFO - 2023-12-05 15:56:18 --> Config Class Initialized
INFO - 2023-12-05 15:56:18 --> Loader Class Initialized
INFO - 2023-12-05 15:56:18 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:18 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:18 --> Controller Class Initialized
INFO - 2023-12-05 15:56:18 --> Final output sent to browser
DEBUG - 2023-12-05 15:56:18 --> Total execution time: 0.0341
INFO - 2023-12-05 15:56:18 --> Config Class Initialized
INFO - 2023-12-05 15:56:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:18 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:18 --> URI Class Initialized
INFO - 2023-12-05 15:56:18 --> Router Class Initialized
INFO - 2023-12-05 15:56:18 --> Output Class Initialized
INFO - 2023-12-05 15:56:18 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:18 --> Input Class Initialized
INFO - 2023-12-05 15:56:18 --> Language Class Initialized
ERROR - 2023-12-05 15:56:18 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:56:18 --> Config Class Initialized
INFO - 2023-12-05 15:56:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:18 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:18 --> URI Class Initialized
INFO - 2023-12-05 15:56:18 --> Router Class Initialized
INFO - 2023-12-05 15:56:18 --> Output Class Initialized
INFO - 2023-12-05 15:56:18 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:18 --> Input Class Initialized
INFO - 2023-12-05 15:56:18 --> Language Class Initialized
INFO - 2023-12-05 15:56:18 --> Language Class Initialized
INFO - 2023-12-05 15:56:18 --> Config Class Initialized
INFO - 2023-12-05 15:56:18 --> Loader Class Initialized
INFO - 2023-12-05 15:56:18 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:18 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:18 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:18 --> Controller Class Initialized
INFO - 2023-12-05 15:56:19 --> Config Class Initialized
INFO - 2023-12-05 15:56:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:19 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:19 --> URI Class Initialized
INFO - 2023-12-05 15:56:19 --> Router Class Initialized
INFO - 2023-12-05 15:56:19 --> Output Class Initialized
INFO - 2023-12-05 15:56:19 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:19 --> Input Class Initialized
INFO - 2023-12-05 15:56:19 --> Language Class Initialized
INFO - 2023-12-05 15:56:19 --> Language Class Initialized
INFO - 2023-12-05 15:56:19 --> Config Class Initialized
INFO - 2023-12-05 15:56:19 --> Loader Class Initialized
INFO - 2023-12-05 15:56:19 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:19 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:19 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:19 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:19 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:19 --> Controller Class Initialized
INFO - 2023-12-05 15:56:19 --> Final output sent to browser
DEBUG - 2023-12-05 15:56:19 --> Total execution time: 0.0872
INFO - 2023-12-05 15:56:32 --> Config Class Initialized
INFO - 2023-12-05 15:56:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:32 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:32 --> URI Class Initialized
INFO - 2023-12-05 15:56:32 --> Router Class Initialized
INFO - 2023-12-05 15:56:32 --> Output Class Initialized
INFO - 2023-12-05 15:56:32 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:32 --> Input Class Initialized
INFO - 2023-12-05 15:56:32 --> Language Class Initialized
INFO - 2023-12-05 15:56:32 --> Language Class Initialized
INFO - 2023-12-05 15:56:32 --> Config Class Initialized
INFO - 2023-12-05 15:56:32 --> Loader Class Initialized
INFO - 2023-12-05 15:56:32 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:32 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:32 --> Controller Class Initialized
INFO - 2023-12-05 15:56:32 --> Final output sent to browser
DEBUG - 2023-12-05 15:56:32 --> Total execution time: 0.0845
INFO - 2023-12-05 15:56:32 --> Config Class Initialized
INFO - 2023-12-05 15:56:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:32 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:32 --> URI Class Initialized
INFO - 2023-12-05 15:56:32 --> Router Class Initialized
INFO - 2023-12-05 15:56:32 --> Output Class Initialized
INFO - 2023-12-05 15:56:32 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:32 --> Input Class Initialized
INFO - 2023-12-05 15:56:32 --> Language Class Initialized
ERROR - 2023-12-05 15:56:32 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:56:32 --> Config Class Initialized
INFO - 2023-12-05 15:56:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:56:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:56:32 --> Utf8 Class Initialized
INFO - 2023-12-05 15:56:32 --> URI Class Initialized
INFO - 2023-12-05 15:56:32 --> Router Class Initialized
INFO - 2023-12-05 15:56:32 --> Output Class Initialized
INFO - 2023-12-05 15:56:32 --> Security Class Initialized
DEBUG - 2023-12-05 15:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:56:32 --> Input Class Initialized
INFO - 2023-12-05 15:56:32 --> Language Class Initialized
INFO - 2023-12-05 15:56:32 --> Language Class Initialized
INFO - 2023-12-05 15:56:32 --> Config Class Initialized
INFO - 2023-12-05 15:56:32 --> Loader Class Initialized
INFO - 2023-12-05 15:56:32 --> Helper loaded: url_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: file_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: form_helper
INFO - 2023-12-05 15:56:32 --> Helper loaded: my_helper
INFO - 2023-12-05 15:56:32 --> Database Driver Class Initialized
INFO - 2023-12-05 15:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:56:32 --> Controller Class Initialized
INFO - 2023-12-05 15:57:10 --> Config Class Initialized
INFO - 2023-12-05 15:57:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:10 --> URI Class Initialized
INFO - 2023-12-05 15:57:10 --> Router Class Initialized
INFO - 2023-12-05 15:57:10 --> Output Class Initialized
INFO - 2023-12-05 15:57:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:10 --> Input Class Initialized
INFO - 2023-12-05 15:57:10 --> Language Class Initialized
INFO - 2023-12-05 15:57:10 --> Language Class Initialized
INFO - 2023-12-05 15:57:10 --> Config Class Initialized
INFO - 2023-12-05 15:57:10 --> Loader Class Initialized
INFO - 2023-12-05 15:57:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:10 --> Controller Class Initialized
DEBUG - 2023-12-05 15:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:57:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:57:10 --> Final output sent to browser
DEBUG - 2023-12-05 15:57:10 --> Total execution time: 0.0755
INFO - 2023-12-05 15:57:10 --> Config Class Initialized
INFO - 2023-12-05 15:57:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:10 --> URI Class Initialized
INFO - 2023-12-05 15:57:10 --> Router Class Initialized
INFO - 2023-12-05 15:57:10 --> Output Class Initialized
INFO - 2023-12-05 15:57:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:10 --> Input Class Initialized
INFO - 2023-12-05 15:57:10 --> Language Class Initialized
ERROR - 2023-12-05 15:57:10 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:57:10 --> Config Class Initialized
INFO - 2023-12-05 15:57:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:10 --> URI Class Initialized
INFO - 2023-12-05 15:57:10 --> Router Class Initialized
INFO - 2023-12-05 15:57:10 --> Output Class Initialized
INFO - 2023-12-05 15:57:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:10 --> Input Class Initialized
INFO - 2023-12-05 15:57:10 --> Language Class Initialized
INFO - 2023-12-05 15:57:10 --> Language Class Initialized
INFO - 2023-12-05 15:57:10 --> Config Class Initialized
INFO - 2023-12-05 15:57:10 --> Loader Class Initialized
INFO - 2023-12-05 15:57:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:10 --> Controller Class Initialized
INFO - 2023-12-05 15:57:12 --> Config Class Initialized
INFO - 2023-12-05 15:57:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:12 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:12 --> URI Class Initialized
INFO - 2023-12-05 15:57:12 --> Router Class Initialized
INFO - 2023-12-05 15:57:12 --> Output Class Initialized
INFO - 2023-12-05 15:57:12 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:12 --> Input Class Initialized
INFO - 2023-12-05 15:57:12 --> Language Class Initialized
INFO - 2023-12-05 15:57:12 --> Language Class Initialized
INFO - 2023-12-05 15:57:12 --> Config Class Initialized
INFO - 2023-12-05 15:57:12 --> Loader Class Initialized
INFO - 2023-12-05 15:57:12 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:12 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:12 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:12 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:12 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:12 --> Controller Class Initialized
DEBUG - 2023-12-05 15:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:57:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:57:12 --> Final output sent to browser
DEBUG - 2023-12-05 15:57:12 --> Total execution time: 0.0489
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:57 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:57 --> URI Class Initialized
INFO - 2023-12-05 15:57:57 --> Router Class Initialized
INFO - 2023-12-05 15:57:57 --> Output Class Initialized
INFO - 2023-12-05 15:57:57 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:57 --> Input Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Loader Class Initialized
INFO - 2023-12-05 15:57:57 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:57 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:57 --> Controller Class Initialized
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:57 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:57 --> URI Class Initialized
INFO - 2023-12-05 15:57:57 --> Router Class Initialized
INFO - 2023-12-05 15:57:57 --> Output Class Initialized
INFO - 2023-12-05 15:57:57 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:57 --> Input Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Loader Class Initialized
INFO - 2023-12-05 15:57:57 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:57 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:57 --> Controller Class Initialized
DEBUG - 2023-12-05 15:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:57:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:57:57 --> Final output sent to browser
DEBUG - 2023-12-05 15:57:57 --> Total execution time: 0.0344
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:57 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:57 --> URI Class Initialized
INFO - 2023-12-05 15:57:57 --> Router Class Initialized
INFO - 2023-12-05 15:57:57 --> Output Class Initialized
INFO - 2023-12-05 15:57:57 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:57 --> Input Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
ERROR - 2023-12-05 15:57:57 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:57 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:57 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:57 --> URI Class Initialized
INFO - 2023-12-05 15:57:57 --> Router Class Initialized
INFO - 2023-12-05 15:57:57 --> Output Class Initialized
INFO - 2023-12-05 15:57:57 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:57 --> Input Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Language Class Initialized
INFO - 2023-12-05 15:57:57 --> Config Class Initialized
INFO - 2023-12-05 15:57:57 --> Loader Class Initialized
INFO - 2023-12-05 15:57:57 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:57 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:57 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:57 --> Controller Class Initialized
INFO - 2023-12-05 15:57:59 --> Config Class Initialized
INFO - 2023-12-05 15:57:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:57:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:57:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:57:59 --> URI Class Initialized
INFO - 2023-12-05 15:57:59 --> Router Class Initialized
INFO - 2023-12-05 15:57:59 --> Output Class Initialized
INFO - 2023-12-05 15:57:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:57:59 --> Input Class Initialized
INFO - 2023-12-05 15:57:59 --> Language Class Initialized
INFO - 2023-12-05 15:57:59 --> Language Class Initialized
INFO - 2023-12-05 15:57:59 --> Config Class Initialized
INFO - 2023-12-05 15:57:59 --> Loader Class Initialized
INFO - 2023-12-05 15:57:59 --> Helper loaded: url_helper
INFO - 2023-12-05 15:57:59 --> Helper loaded: file_helper
INFO - 2023-12-05 15:57:59 --> Helper loaded: form_helper
INFO - 2023-12-05 15:57:59 --> Helper loaded: my_helper
INFO - 2023-12-05 15:57:59 --> Database Driver Class Initialized
INFO - 2023-12-05 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:57:59 --> Controller Class Initialized
DEBUG - 2023-12-05 15:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:57:59 --> Final output sent to browser
DEBUG - 2023-12-05 15:57:59 --> Total execution time: 0.0359
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:10 --> URI Class Initialized
INFO - 2023-12-05 15:58:10 --> Router Class Initialized
INFO - 2023-12-05 15:58:10 --> Output Class Initialized
INFO - 2023-12-05 15:58:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:10 --> Input Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Loader Class Initialized
INFO - 2023-12-05 15:58:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:10 --> Controller Class Initialized
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:10 --> URI Class Initialized
INFO - 2023-12-05 15:58:10 --> Router Class Initialized
INFO - 2023-12-05 15:58:10 --> Output Class Initialized
INFO - 2023-12-05 15:58:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:10 --> Input Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Loader Class Initialized
INFO - 2023-12-05 15:58:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:10 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:58:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:10 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:10 --> Total execution time: 0.0361
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:10 --> URI Class Initialized
INFO - 2023-12-05 15:58:10 --> Router Class Initialized
INFO - 2023-12-05 15:58:10 --> Output Class Initialized
INFO - 2023-12-05 15:58:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:10 --> Input Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
ERROR - 2023-12-05 15:58:10 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:10 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:10 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:10 --> URI Class Initialized
INFO - 2023-12-05 15:58:10 --> Router Class Initialized
INFO - 2023-12-05 15:58:10 --> Output Class Initialized
INFO - 2023-12-05 15:58:10 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:10 --> Input Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Language Class Initialized
INFO - 2023-12-05 15:58:10 --> Config Class Initialized
INFO - 2023-12-05 15:58:10 --> Loader Class Initialized
INFO - 2023-12-05 15:58:10 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:10 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:10 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:10 --> Controller Class Initialized
INFO - 2023-12-05 15:58:12 --> Config Class Initialized
INFO - 2023-12-05 15:58:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:12 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:12 --> URI Class Initialized
INFO - 2023-12-05 15:58:12 --> Router Class Initialized
INFO - 2023-12-05 15:58:12 --> Output Class Initialized
INFO - 2023-12-05 15:58:12 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:12 --> Input Class Initialized
INFO - 2023-12-05 15:58:12 --> Language Class Initialized
INFO - 2023-12-05 15:58:12 --> Language Class Initialized
INFO - 2023-12-05 15:58:12 --> Config Class Initialized
INFO - 2023-12-05 15:58:12 --> Loader Class Initialized
INFO - 2023-12-05 15:58:12 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:12 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:12 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:12 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:12 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:12 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:12 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:12 --> Total execution time: 0.0818
INFO - 2023-12-05 15:58:21 --> Config Class Initialized
INFO - 2023-12-05 15:58:21 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:21 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:21 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:21 --> URI Class Initialized
INFO - 2023-12-05 15:58:21 --> Router Class Initialized
INFO - 2023-12-05 15:58:21 --> Output Class Initialized
INFO - 2023-12-05 15:58:21 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:21 --> Input Class Initialized
INFO - 2023-12-05 15:58:21 --> Language Class Initialized
INFO - 2023-12-05 15:58:21 --> Language Class Initialized
INFO - 2023-12-05 15:58:21 --> Config Class Initialized
INFO - 2023-12-05 15:58:21 --> Loader Class Initialized
INFO - 2023-12-05 15:58:21 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:21 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:21 --> Controller Class Initialized
INFO - 2023-12-05 15:58:21 --> Config Class Initialized
INFO - 2023-12-05 15:58:21 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:21 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:21 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:21 --> URI Class Initialized
INFO - 2023-12-05 15:58:21 --> Router Class Initialized
INFO - 2023-12-05 15:58:21 --> Output Class Initialized
INFO - 2023-12-05 15:58:21 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:21 --> Input Class Initialized
INFO - 2023-12-05 15:58:21 --> Language Class Initialized
INFO - 2023-12-05 15:58:21 --> Language Class Initialized
INFO - 2023-12-05 15:58:21 --> Config Class Initialized
INFO - 2023-12-05 15:58:21 --> Loader Class Initialized
INFO - 2023-12-05 15:58:21 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:21 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:22 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:22 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:22 --> Total execution time: 0.0399
INFO - 2023-12-05 15:58:22 --> Config Class Initialized
INFO - 2023-12-05 15:58:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:22 --> URI Class Initialized
INFO - 2023-12-05 15:58:22 --> Router Class Initialized
INFO - 2023-12-05 15:58:22 --> Output Class Initialized
INFO - 2023-12-05 15:58:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:22 --> Input Class Initialized
INFO - 2023-12-05 15:58:22 --> Language Class Initialized
ERROR - 2023-12-05 15:58:22 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:58:22 --> Config Class Initialized
INFO - 2023-12-05 15:58:22 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:22 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:22 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:22 --> URI Class Initialized
INFO - 2023-12-05 15:58:22 --> Router Class Initialized
INFO - 2023-12-05 15:58:22 --> Output Class Initialized
INFO - 2023-12-05 15:58:22 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:22 --> Input Class Initialized
INFO - 2023-12-05 15:58:22 --> Language Class Initialized
INFO - 2023-12-05 15:58:22 --> Language Class Initialized
INFO - 2023-12-05 15:58:22 --> Config Class Initialized
INFO - 2023-12-05 15:58:22 --> Loader Class Initialized
INFO - 2023-12-05 15:58:22 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:22 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:22 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:22 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:22 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:22 --> Controller Class Initialized
INFO - 2023-12-05 15:58:23 --> Config Class Initialized
INFO - 2023-12-05 15:58:23 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:23 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:23 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:23 --> URI Class Initialized
INFO - 2023-12-05 15:58:23 --> Router Class Initialized
INFO - 2023-12-05 15:58:23 --> Output Class Initialized
INFO - 2023-12-05 15:58:23 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:23 --> Input Class Initialized
INFO - 2023-12-05 15:58:23 --> Language Class Initialized
INFO - 2023-12-05 15:58:23 --> Language Class Initialized
INFO - 2023-12-05 15:58:23 --> Config Class Initialized
INFO - 2023-12-05 15:58:23 --> Loader Class Initialized
INFO - 2023-12-05 15:58:23 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:23 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:23 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:23 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:23 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:23 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:58:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:23 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:23 --> Total execution time: 0.0369
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:36 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:36 --> URI Class Initialized
INFO - 2023-12-05 15:58:36 --> Router Class Initialized
INFO - 2023-12-05 15:58:36 --> Output Class Initialized
INFO - 2023-12-05 15:58:36 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:36 --> Input Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Loader Class Initialized
INFO - 2023-12-05 15:58:36 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:36 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:36 --> Controller Class Initialized
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:36 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:36 --> URI Class Initialized
INFO - 2023-12-05 15:58:36 --> Router Class Initialized
INFO - 2023-12-05 15:58:36 --> Output Class Initialized
INFO - 2023-12-05 15:58:36 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:36 --> Input Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Loader Class Initialized
INFO - 2023-12-05 15:58:36 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:36 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:36 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:58:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:36 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:36 --> Total execution time: 0.0668
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:36 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:36 --> URI Class Initialized
INFO - 2023-12-05 15:58:36 --> Router Class Initialized
INFO - 2023-12-05 15:58:36 --> Output Class Initialized
INFO - 2023-12-05 15:58:36 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:36 --> Input Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
ERROR - 2023-12-05 15:58:36 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:36 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:36 --> URI Class Initialized
INFO - 2023-12-05 15:58:36 --> Router Class Initialized
INFO - 2023-12-05 15:58:36 --> Output Class Initialized
INFO - 2023-12-05 15:58:36 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:36 --> Input Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Language Class Initialized
INFO - 2023-12-05 15:58:36 --> Config Class Initialized
INFO - 2023-12-05 15:58:36 --> Loader Class Initialized
INFO - 2023-12-05 15:58:36 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:36 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:36 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:36 --> Controller Class Initialized
INFO - 2023-12-05 15:58:45 --> Config Class Initialized
INFO - 2023-12-05 15:58:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:45 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:45 --> URI Class Initialized
INFO - 2023-12-05 15:58:45 --> Router Class Initialized
INFO - 2023-12-05 15:58:45 --> Output Class Initialized
INFO - 2023-12-05 15:58:45 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:45 --> Input Class Initialized
INFO - 2023-12-05 15:58:45 --> Language Class Initialized
INFO - 2023-12-05 15:58:46 --> Language Class Initialized
INFO - 2023-12-05 15:58:46 --> Config Class Initialized
INFO - 2023-12-05 15:58:46 --> Loader Class Initialized
INFO - 2023-12-05 15:58:46 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:46 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:46 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:46 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:46 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:46 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:58:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:46 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:46 --> Total execution time: 0.0550
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:59 --> URI Class Initialized
INFO - 2023-12-05 15:58:59 --> Router Class Initialized
INFO - 2023-12-05 15:58:59 --> Output Class Initialized
INFO - 2023-12-05 15:58:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:59 --> Input Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Loader Class Initialized
INFO - 2023-12-05 15:58:59 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:59 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:59 --> Controller Class Initialized
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:59 --> URI Class Initialized
INFO - 2023-12-05 15:58:59 --> Router Class Initialized
INFO - 2023-12-05 15:58:59 --> Output Class Initialized
INFO - 2023-12-05 15:58:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:59 --> Input Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Loader Class Initialized
INFO - 2023-12-05 15:58:59 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:59 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:59 --> Controller Class Initialized
DEBUG - 2023-12-05 15:58:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:58:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:58:59 --> Final output sent to browser
DEBUG - 2023-12-05 15:58:59 --> Total execution time: 0.0528
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:59 --> URI Class Initialized
INFO - 2023-12-05 15:58:59 --> Router Class Initialized
INFO - 2023-12-05 15:58:59 --> Output Class Initialized
INFO - 2023-12-05 15:58:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:59 --> Input Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
ERROR - 2023-12-05 15:58:59 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:58:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:58:59 --> Utf8 Class Initialized
INFO - 2023-12-05 15:58:59 --> URI Class Initialized
INFO - 2023-12-05 15:58:59 --> Router Class Initialized
INFO - 2023-12-05 15:58:59 --> Output Class Initialized
INFO - 2023-12-05 15:58:59 --> Security Class Initialized
DEBUG - 2023-12-05 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:58:59 --> Input Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Language Class Initialized
INFO - 2023-12-05 15:58:59 --> Config Class Initialized
INFO - 2023-12-05 15:58:59 --> Loader Class Initialized
INFO - 2023-12-05 15:58:59 --> Helper loaded: url_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: file_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: form_helper
INFO - 2023-12-05 15:58:59 --> Helper loaded: my_helper
INFO - 2023-12-05 15:58:59 --> Database Driver Class Initialized
INFO - 2023-12-05 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:58:59 --> Controller Class Initialized
INFO - 2023-12-05 15:59:04 --> Config Class Initialized
INFO - 2023-12-05 15:59:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:04 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:04 --> URI Class Initialized
INFO - 2023-12-05 15:59:04 --> Router Class Initialized
INFO - 2023-12-05 15:59:04 --> Output Class Initialized
INFO - 2023-12-05 15:59:04 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:04 --> Input Class Initialized
INFO - 2023-12-05 15:59:04 --> Language Class Initialized
INFO - 2023-12-05 15:59:04 --> Language Class Initialized
INFO - 2023-12-05 15:59:04 --> Config Class Initialized
INFO - 2023-12-05 15:59:04 --> Loader Class Initialized
INFO - 2023-12-05 15:59:04 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:04 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:04 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:04 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:04 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:04 --> Controller Class Initialized
DEBUG - 2023-12-05 15:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:59:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:59:04 --> Final output sent to browser
DEBUG - 2023-12-05 15:59:04 --> Total execution time: 0.0434
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:16 --> URI Class Initialized
INFO - 2023-12-05 15:59:16 --> Router Class Initialized
INFO - 2023-12-05 15:59:16 --> Output Class Initialized
INFO - 2023-12-05 15:59:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:16 --> Input Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Loader Class Initialized
INFO - 2023-12-05 15:59:16 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:16 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:16 --> Controller Class Initialized
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:16 --> URI Class Initialized
INFO - 2023-12-05 15:59:16 --> Router Class Initialized
INFO - 2023-12-05 15:59:16 --> Output Class Initialized
INFO - 2023-12-05 15:59:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:16 --> Input Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Loader Class Initialized
INFO - 2023-12-05 15:59:16 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:16 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:16 --> Controller Class Initialized
DEBUG - 2023-12-05 15:59:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:59:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:59:16 --> Final output sent to browser
DEBUG - 2023-12-05 15:59:16 --> Total execution time: 0.0408
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:16 --> URI Class Initialized
INFO - 2023-12-05 15:59:16 --> Router Class Initialized
INFO - 2023-12-05 15:59:16 --> Output Class Initialized
INFO - 2023-12-05 15:59:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:16 --> Input Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
ERROR - 2023-12-05 15:59:16 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:16 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:16 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:16 --> URI Class Initialized
INFO - 2023-12-05 15:59:16 --> Router Class Initialized
INFO - 2023-12-05 15:59:16 --> Output Class Initialized
INFO - 2023-12-05 15:59:16 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:16 --> Input Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Language Class Initialized
INFO - 2023-12-05 15:59:16 --> Config Class Initialized
INFO - 2023-12-05 15:59:16 --> Loader Class Initialized
INFO - 2023-12-05 15:59:16 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:16 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:16 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:16 --> Controller Class Initialized
INFO - 2023-12-05 15:59:17 --> Config Class Initialized
INFO - 2023-12-05 15:59:17 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:17 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:17 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:17 --> URI Class Initialized
INFO - 2023-12-05 15:59:17 --> Router Class Initialized
INFO - 2023-12-05 15:59:17 --> Output Class Initialized
INFO - 2023-12-05 15:59:17 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:17 --> Input Class Initialized
INFO - 2023-12-05 15:59:17 --> Language Class Initialized
INFO - 2023-12-05 15:59:17 --> Language Class Initialized
INFO - 2023-12-05 15:59:17 --> Config Class Initialized
INFO - 2023-12-05 15:59:17 --> Loader Class Initialized
INFO - 2023-12-05 15:59:17 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:17 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:17 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:17 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:17 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:17 --> Controller Class Initialized
DEBUG - 2023-12-05 15:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/form.php
DEBUG - 2023-12-05 15:59:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:59:17 --> Final output sent to browser
DEBUG - 2023-12-05 15:59:17 --> Total execution time: 0.1005
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:31 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:31 --> URI Class Initialized
INFO - 2023-12-05 15:59:31 --> Router Class Initialized
INFO - 2023-12-05 15:59:31 --> Output Class Initialized
INFO - 2023-12-05 15:59:31 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:31 --> Input Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Loader Class Initialized
INFO - 2023-12-05 15:59:31 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:31 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:31 --> Controller Class Initialized
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:31 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:31 --> URI Class Initialized
INFO - 2023-12-05 15:59:31 --> Router Class Initialized
INFO - 2023-12-05 15:59:31 --> Output Class Initialized
INFO - 2023-12-05 15:59:31 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:31 --> Input Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Loader Class Initialized
INFO - 2023-12-05 15:59:31 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:31 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:31 --> Controller Class Initialized
DEBUG - 2023-12-05 15:59:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelompok/views/list.php
DEBUG - 2023-12-05 15:59:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 15:59:31 --> Final output sent to browser
DEBUG - 2023-12-05 15:59:31 --> Total execution time: 0.0367
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:31 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:31 --> URI Class Initialized
INFO - 2023-12-05 15:59:31 --> Router Class Initialized
INFO - 2023-12-05 15:59:31 --> Output Class Initialized
INFO - 2023-12-05 15:59:31 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:31 --> Input Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
ERROR - 2023-12-05 15:59:31 --> 404 Page Not Found: /index
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 15:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 15:59:31 --> Utf8 Class Initialized
INFO - 2023-12-05 15:59:31 --> URI Class Initialized
INFO - 2023-12-05 15:59:31 --> Router Class Initialized
INFO - 2023-12-05 15:59:31 --> Output Class Initialized
INFO - 2023-12-05 15:59:31 --> Security Class Initialized
DEBUG - 2023-12-05 15:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 15:59:31 --> Input Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Language Class Initialized
INFO - 2023-12-05 15:59:31 --> Config Class Initialized
INFO - 2023-12-05 15:59:31 --> Loader Class Initialized
INFO - 2023-12-05 15:59:31 --> Helper loaded: url_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: file_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: form_helper
INFO - 2023-12-05 15:59:31 --> Helper loaded: my_helper
INFO - 2023-12-05 15:59:31 --> Database Driver Class Initialized
INFO - 2023-12-05 15:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 15:59:31 --> Controller Class Initialized
INFO - 2023-12-05 16:05:45 --> Config Class Initialized
INFO - 2023-12-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:45 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:45 --> URI Class Initialized
INFO - 2023-12-05 16:05:45 --> Router Class Initialized
INFO - 2023-12-05 16:05:45 --> Output Class Initialized
INFO - 2023-12-05 16:05:45 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:45 --> Input Class Initialized
INFO - 2023-12-05 16:05:45 --> Language Class Initialized
INFO - 2023-12-05 16:05:45 --> Language Class Initialized
INFO - 2023-12-05 16:05:45 --> Config Class Initialized
INFO - 2023-12-05 16:05:45 --> Loader Class Initialized
INFO - 2023-12-05 16:05:45 --> Helper loaded: url_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: file_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: form_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: my_helper
INFO - 2023-12-05 16:05:45 --> Database Driver Class Initialized
INFO - 2023-12-05 16:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:05:45 --> Controller Class Initialized
DEBUG - 2023-12-05 16:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:05:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:05:45 --> Final output sent to browser
DEBUG - 2023-12-05 16:05:45 --> Total execution time: 0.0380
INFO - 2023-12-05 16:05:45 --> Config Class Initialized
INFO - 2023-12-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:45 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:45 --> URI Class Initialized
INFO - 2023-12-05 16:05:45 --> Router Class Initialized
INFO - 2023-12-05 16:05:45 --> Output Class Initialized
INFO - 2023-12-05 16:05:45 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:45 --> Input Class Initialized
INFO - 2023-12-05 16:05:45 --> Language Class Initialized
ERROR - 2023-12-05 16:05:45 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:05:45 --> Config Class Initialized
INFO - 2023-12-05 16:05:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:45 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:45 --> URI Class Initialized
INFO - 2023-12-05 16:05:45 --> Router Class Initialized
INFO - 2023-12-05 16:05:45 --> Output Class Initialized
INFO - 2023-12-05 16:05:45 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:45 --> Input Class Initialized
INFO - 2023-12-05 16:05:45 --> Language Class Initialized
INFO - 2023-12-05 16:05:45 --> Language Class Initialized
INFO - 2023-12-05 16:05:45 --> Config Class Initialized
INFO - 2023-12-05 16:05:45 --> Loader Class Initialized
INFO - 2023-12-05 16:05:45 --> Helper loaded: url_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: file_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: form_helper
INFO - 2023-12-05 16:05:45 --> Helper loaded: my_helper
INFO - 2023-12-05 16:05:45 --> Database Driver Class Initialized
INFO - 2023-12-05 16:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:05:45 --> Controller Class Initialized
INFO - 2023-12-05 16:05:48 --> Config Class Initialized
INFO - 2023-12-05 16:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:48 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:48 --> URI Class Initialized
INFO - 2023-12-05 16:05:48 --> Router Class Initialized
INFO - 2023-12-05 16:05:48 --> Output Class Initialized
INFO - 2023-12-05 16:05:48 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:48 --> Input Class Initialized
INFO - 2023-12-05 16:05:48 --> Language Class Initialized
INFO - 2023-12-05 16:05:48 --> Language Class Initialized
INFO - 2023-12-05 16:05:48 --> Config Class Initialized
INFO - 2023-12-05 16:05:48 --> Loader Class Initialized
INFO - 2023-12-05 16:05:48 --> Helper loaded: url_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: file_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: form_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: my_helper
INFO - 2023-12-05 16:05:48 --> Database Driver Class Initialized
INFO - 2023-12-05 16:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:05:48 --> Controller Class Initialized
DEBUG - 2023-12-05 16:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:05:48 --> Final output sent to browser
DEBUG - 2023-12-05 16:05:48 --> Total execution time: 0.0346
INFO - 2023-12-05 16:05:48 --> Config Class Initialized
INFO - 2023-12-05 16:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:48 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:48 --> URI Class Initialized
INFO - 2023-12-05 16:05:48 --> Router Class Initialized
INFO - 2023-12-05 16:05:48 --> Output Class Initialized
INFO - 2023-12-05 16:05:48 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:48 --> Input Class Initialized
INFO - 2023-12-05 16:05:48 --> Language Class Initialized
ERROR - 2023-12-05 16:05:48 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:05:48 --> Config Class Initialized
INFO - 2023-12-05 16:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:48 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:48 --> URI Class Initialized
INFO - 2023-12-05 16:05:48 --> Router Class Initialized
INFO - 2023-12-05 16:05:48 --> Output Class Initialized
INFO - 2023-12-05 16:05:48 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:48 --> Input Class Initialized
INFO - 2023-12-05 16:05:48 --> Language Class Initialized
INFO - 2023-12-05 16:05:48 --> Language Class Initialized
INFO - 2023-12-05 16:05:48 --> Config Class Initialized
INFO - 2023-12-05 16:05:48 --> Loader Class Initialized
INFO - 2023-12-05 16:05:48 --> Helper loaded: url_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: file_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: form_helper
INFO - 2023-12-05 16:05:48 --> Helper loaded: my_helper
INFO - 2023-12-05 16:05:48 --> Database Driver Class Initialized
INFO - 2023-12-05 16:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:05:48 --> Controller Class Initialized
INFO - 2023-12-05 16:05:50 --> Config Class Initialized
INFO - 2023-12-05 16:05:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:05:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:05:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:05:50 --> URI Class Initialized
INFO - 2023-12-05 16:05:50 --> Router Class Initialized
INFO - 2023-12-05 16:05:50 --> Output Class Initialized
INFO - 2023-12-05 16:05:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:05:50 --> Input Class Initialized
INFO - 2023-12-05 16:05:50 --> Language Class Initialized
INFO - 2023-12-05 16:05:50 --> Language Class Initialized
INFO - 2023-12-05 16:05:50 --> Config Class Initialized
INFO - 2023-12-05 16:05:50 --> Loader Class Initialized
INFO - 2023-12-05 16:05:50 --> Helper loaded: url_helper
INFO - 2023-12-05 16:05:50 --> Helper loaded: file_helper
INFO - 2023-12-05 16:05:50 --> Helper loaded: form_helper
INFO - 2023-12-05 16:05:50 --> Helper loaded: my_helper
INFO - 2023-12-05 16:05:50 --> Database Driver Class Initialized
INFO - 2023-12-05 16:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:05:50 --> Controller Class Initialized
INFO - 2023-12-05 16:05:50 --> Final output sent to browser
DEBUG - 2023-12-05 16:05:50 --> Total execution time: 0.0514
INFO - 2023-12-05 16:06:32 --> Config Class Initialized
INFO - 2023-12-05 16:06:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:32 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:32 --> URI Class Initialized
INFO - 2023-12-05 16:06:32 --> Router Class Initialized
INFO - 2023-12-05 16:06:32 --> Output Class Initialized
INFO - 2023-12-05 16:06:32 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:32 --> Input Class Initialized
INFO - 2023-12-05 16:06:32 --> Language Class Initialized
INFO - 2023-12-05 16:06:32 --> Language Class Initialized
INFO - 2023-12-05 16:06:32 --> Config Class Initialized
INFO - 2023-12-05 16:06:32 --> Loader Class Initialized
INFO - 2023-12-05 16:06:32 --> Helper loaded: url_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: file_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: form_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: my_helper
INFO - 2023-12-05 16:06:32 --> Database Driver Class Initialized
INFO - 2023-12-05 16:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:06:32 --> Controller Class Initialized
DEBUG - 2023-12-05 16:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:06:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:06:32 --> Final output sent to browser
DEBUG - 2023-12-05 16:06:32 --> Total execution time: 0.0392
INFO - 2023-12-05 16:06:32 --> Config Class Initialized
INFO - 2023-12-05 16:06:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:32 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:32 --> URI Class Initialized
INFO - 2023-12-05 16:06:32 --> Router Class Initialized
INFO - 2023-12-05 16:06:32 --> Output Class Initialized
INFO - 2023-12-05 16:06:32 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:32 --> Input Class Initialized
INFO - 2023-12-05 16:06:32 --> Language Class Initialized
ERROR - 2023-12-05 16:06:32 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:06:32 --> Config Class Initialized
INFO - 2023-12-05 16:06:32 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:32 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:32 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:32 --> URI Class Initialized
INFO - 2023-12-05 16:06:32 --> Router Class Initialized
INFO - 2023-12-05 16:06:32 --> Output Class Initialized
INFO - 2023-12-05 16:06:32 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:32 --> Input Class Initialized
INFO - 2023-12-05 16:06:32 --> Language Class Initialized
INFO - 2023-12-05 16:06:32 --> Language Class Initialized
INFO - 2023-12-05 16:06:32 --> Config Class Initialized
INFO - 2023-12-05 16:06:32 --> Loader Class Initialized
INFO - 2023-12-05 16:06:32 --> Helper loaded: url_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: file_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: form_helper
INFO - 2023-12-05 16:06:32 --> Helper loaded: my_helper
INFO - 2023-12-05 16:06:32 --> Database Driver Class Initialized
INFO - 2023-12-05 16:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:06:32 --> Controller Class Initialized
INFO - 2023-12-05 16:06:33 --> Config Class Initialized
INFO - 2023-12-05 16:06:33 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:33 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:33 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:33 --> URI Class Initialized
INFO - 2023-12-05 16:06:33 --> Router Class Initialized
INFO - 2023-12-05 16:06:33 --> Output Class Initialized
INFO - 2023-12-05 16:06:33 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:33 --> Input Class Initialized
INFO - 2023-12-05 16:06:33 --> Language Class Initialized
INFO - 2023-12-05 16:06:33 --> Language Class Initialized
INFO - 2023-12-05 16:06:33 --> Config Class Initialized
INFO - 2023-12-05 16:06:33 --> Loader Class Initialized
INFO - 2023-12-05 16:06:33 --> Helper loaded: url_helper
INFO - 2023-12-05 16:06:33 --> Helper loaded: file_helper
INFO - 2023-12-05 16:06:33 --> Helper loaded: form_helper
INFO - 2023-12-05 16:06:33 --> Helper loaded: my_helper
INFO - 2023-12-05 16:06:33 --> Database Driver Class Initialized
INFO - 2023-12-05 16:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:06:33 --> Controller Class Initialized
INFO - 2023-12-05 16:06:33 --> Final output sent to browser
DEBUG - 2023-12-05 16:06:33 --> Total execution time: 0.0340
INFO - 2023-12-05 16:06:59 --> Config Class Initialized
INFO - 2023-12-05 16:06:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:59 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:59 --> URI Class Initialized
INFO - 2023-12-05 16:06:59 --> Router Class Initialized
INFO - 2023-12-05 16:06:59 --> Output Class Initialized
INFO - 2023-12-05 16:06:59 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:59 --> Input Class Initialized
INFO - 2023-12-05 16:06:59 --> Language Class Initialized
INFO - 2023-12-05 16:06:59 --> Language Class Initialized
INFO - 2023-12-05 16:06:59 --> Config Class Initialized
INFO - 2023-12-05 16:06:59 --> Loader Class Initialized
INFO - 2023-12-05 16:06:59 --> Helper loaded: url_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: file_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: form_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: my_helper
INFO - 2023-12-05 16:06:59 --> Database Driver Class Initialized
INFO - 2023-12-05 16:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:06:59 --> Controller Class Initialized
INFO - 2023-12-05 16:06:59 --> Final output sent to browser
DEBUG - 2023-12-05 16:06:59 --> Total execution time: 0.0466
INFO - 2023-12-05 16:06:59 --> Config Class Initialized
INFO - 2023-12-05 16:06:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:59 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:59 --> URI Class Initialized
INFO - 2023-12-05 16:06:59 --> Router Class Initialized
INFO - 2023-12-05 16:06:59 --> Output Class Initialized
INFO - 2023-12-05 16:06:59 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:59 --> Input Class Initialized
INFO - 2023-12-05 16:06:59 --> Language Class Initialized
ERROR - 2023-12-05 16:06:59 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:06:59 --> Config Class Initialized
INFO - 2023-12-05 16:06:59 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:06:59 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:06:59 --> Utf8 Class Initialized
INFO - 2023-12-05 16:06:59 --> URI Class Initialized
INFO - 2023-12-05 16:06:59 --> Router Class Initialized
INFO - 2023-12-05 16:06:59 --> Output Class Initialized
INFO - 2023-12-05 16:06:59 --> Security Class Initialized
DEBUG - 2023-12-05 16:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:06:59 --> Input Class Initialized
INFO - 2023-12-05 16:06:59 --> Language Class Initialized
INFO - 2023-12-05 16:06:59 --> Language Class Initialized
INFO - 2023-12-05 16:06:59 --> Config Class Initialized
INFO - 2023-12-05 16:06:59 --> Loader Class Initialized
INFO - 2023-12-05 16:06:59 --> Helper loaded: url_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: file_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: form_helper
INFO - 2023-12-05 16:06:59 --> Helper loaded: my_helper
INFO - 2023-12-05 16:06:59 --> Database Driver Class Initialized
INFO - 2023-12-05 16:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:06:59 --> Controller Class Initialized
INFO - 2023-12-05 16:07:04 --> Config Class Initialized
INFO - 2023-12-05 16:07:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:07:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:07:04 --> Utf8 Class Initialized
INFO - 2023-12-05 16:07:04 --> URI Class Initialized
INFO - 2023-12-05 16:07:04 --> Router Class Initialized
INFO - 2023-12-05 16:07:04 --> Output Class Initialized
INFO - 2023-12-05 16:07:04 --> Security Class Initialized
DEBUG - 2023-12-05 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:07:04 --> Input Class Initialized
INFO - 2023-12-05 16:07:04 --> Language Class Initialized
INFO - 2023-12-05 16:07:04 --> Language Class Initialized
INFO - 2023-12-05 16:07:04 --> Config Class Initialized
INFO - 2023-12-05 16:07:04 --> Loader Class Initialized
INFO - 2023-12-05 16:07:04 --> Helper loaded: url_helper
INFO - 2023-12-05 16:07:04 --> Helper loaded: file_helper
INFO - 2023-12-05 16:07:04 --> Helper loaded: form_helper
INFO - 2023-12-05 16:07:04 --> Helper loaded: my_helper
INFO - 2023-12-05 16:07:04 --> Database Driver Class Initialized
INFO - 2023-12-05 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:07:04 --> Controller Class Initialized
INFO - 2023-12-05 16:07:04 --> Final output sent to browser
DEBUG - 2023-12-05 16:07:04 --> Total execution time: 0.0392
INFO - 2023-12-05 16:07:12 --> Config Class Initialized
INFO - 2023-12-05 16:07:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:07:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:07:12 --> Utf8 Class Initialized
INFO - 2023-12-05 16:07:12 --> URI Class Initialized
INFO - 2023-12-05 16:07:12 --> Router Class Initialized
INFO - 2023-12-05 16:07:12 --> Output Class Initialized
INFO - 2023-12-05 16:07:12 --> Security Class Initialized
DEBUG - 2023-12-05 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:07:12 --> Input Class Initialized
INFO - 2023-12-05 16:07:12 --> Language Class Initialized
INFO - 2023-12-05 16:07:12 --> Language Class Initialized
INFO - 2023-12-05 16:07:12 --> Config Class Initialized
INFO - 2023-12-05 16:07:12 --> Loader Class Initialized
INFO - 2023-12-05 16:07:12 --> Helper loaded: url_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: file_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: form_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: my_helper
INFO - 2023-12-05 16:07:12 --> Database Driver Class Initialized
INFO - 2023-12-05 16:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:07:12 --> Controller Class Initialized
INFO - 2023-12-05 16:07:12 --> Final output sent to browser
DEBUG - 2023-12-05 16:07:12 --> Total execution time: 0.1052
INFO - 2023-12-05 16:07:12 --> Config Class Initialized
INFO - 2023-12-05 16:07:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:07:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:07:12 --> Utf8 Class Initialized
INFO - 2023-12-05 16:07:12 --> URI Class Initialized
INFO - 2023-12-05 16:07:12 --> Router Class Initialized
INFO - 2023-12-05 16:07:12 --> Output Class Initialized
INFO - 2023-12-05 16:07:12 --> Security Class Initialized
DEBUG - 2023-12-05 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:07:12 --> Input Class Initialized
INFO - 2023-12-05 16:07:12 --> Language Class Initialized
ERROR - 2023-12-05 16:07:12 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:07:12 --> Config Class Initialized
INFO - 2023-12-05 16:07:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:07:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:07:12 --> Utf8 Class Initialized
INFO - 2023-12-05 16:07:12 --> URI Class Initialized
INFO - 2023-12-05 16:07:12 --> Router Class Initialized
INFO - 2023-12-05 16:07:12 --> Output Class Initialized
INFO - 2023-12-05 16:07:12 --> Security Class Initialized
DEBUG - 2023-12-05 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:07:12 --> Input Class Initialized
INFO - 2023-12-05 16:07:12 --> Language Class Initialized
INFO - 2023-12-05 16:07:12 --> Language Class Initialized
INFO - 2023-12-05 16:07:12 --> Config Class Initialized
INFO - 2023-12-05 16:07:12 --> Loader Class Initialized
INFO - 2023-12-05 16:07:12 --> Helper loaded: url_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: file_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: form_helper
INFO - 2023-12-05 16:07:12 --> Helper loaded: my_helper
INFO - 2023-12-05 16:07:12 --> Database Driver Class Initialized
INFO - 2023-12-05 16:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:07:12 --> Controller Class Initialized
INFO - 2023-12-05 16:07:15 --> Config Class Initialized
INFO - 2023-12-05 16:07:15 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:07:15 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:07:15 --> Utf8 Class Initialized
INFO - 2023-12-05 16:07:15 --> URI Class Initialized
INFO - 2023-12-05 16:07:15 --> Router Class Initialized
INFO - 2023-12-05 16:07:15 --> Output Class Initialized
INFO - 2023-12-05 16:07:15 --> Security Class Initialized
DEBUG - 2023-12-05 16:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:07:15 --> Input Class Initialized
INFO - 2023-12-05 16:07:15 --> Language Class Initialized
INFO - 2023-12-05 16:07:15 --> Language Class Initialized
INFO - 2023-12-05 16:07:15 --> Config Class Initialized
INFO - 2023-12-05 16:07:15 --> Loader Class Initialized
INFO - 2023-12-05 16:07:15 --> Helper loaded: url_helper
INFO - 2023-12-05 16:07:15 --> Helper loaded: file_helper
INFO - 2023-12-05 16:07:15 --> Helper loaded: form_helper
INFO - 2023-12-05 16:07:15 --> Helper loaded: my_helper
INFO - 2023-12-05 16:07:15 --> Database Driver Class Initialized
INFO - 2023-12-05 16:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:07:15 --> Controller Class Initialized
INFO - 2023-12-05 16:07:15 --> Final output sent to browser
DEBUG - 2023-12-05 16:07:15 --> Total execution time: 0.0328
INFO - 2023-12-05 16:08:40 --> Config Class Initialized
INFO - 2023-12-05 16:08:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:08:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:08:40 --> Utf8 Class Initialized
INFO - 2023-12-05 16:08:40 --> URI Class Initialized
INFO - 2023-12-05 16:08:40 --> Router Class Initialized
INFO - 2023-12-05 16:08:40 --> Output Class Initialized
INFO - 2023-12-05 16:08:40 --> Security Class Initialized
DEBUG - 2023-12-05 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:08:40 --> Input Class Initialized
INFO - 2023-12-05 16:08:40 --> Language Class Initialized
INFO - 2023-12-05 16:08:40 --> Language Class Initialized
INFO - 2023-12-05 16:08:40 --> Config Class Initialized
INFO - 2023-12-05 16:08:40 --> Loader Class Initialized
INFO - 2023-12-05 16:08:40 --> Helper loaded: url_helper
INFO - 2023-12-05 16:08:40 --> Helper loaded: file_helper
INFO - 2023-12-05 16:08:40 --> Helper loaded: form_helper
INFO - 2023-12-05 16:08:40 --> Helper loaded: my_helper
INFO - 2023-12-05 16:08:40 --> Database Driver Class Initialized
INFO - 2023-12-05 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:08:40 --> Controller Class Initialized
INFO - 2023-12-05 16:08:40 --> Final output sent to browser
DEBUG - 2023-12-05 16:08:40 --> Total execution time: 0.0399
INFO - 2023-12-05 16:09:18 --> Config Class Initialized
INFO - 2023-12-05 16:09:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:18 --> URI Class Initialized
INFO - 2023-12-05 16:09:18 --> Router Class Initialized
INFO - 2023-12-05 16:09:18 --> Output Class Initialized
INFO - 2023-12-05 16:09:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:18 --> Input Class Initialized
INFO - 2023-12-05 16:09:18 --> Language Class Initialized
INFO - 2023-12-05 16:09:18 --> Language Class Initialized
INFO - 2023-12-05 16:09:18 --> Config Class Initialized
INFO - 2023-12-05 16:09:18 --> Loader Class Initialized
INFO - 2023-12-05 16:09:18 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:18 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:18 --> Controller Class Initialized
INFO - 2023-12-05 16:09:18 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:18 --> Total execution time: 0.0355
INFO - 2023-12-05 16:09:18 --> Config Class Initialized
INFO - 2023-12-05 16:09:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:18 --> URI Class Initialized
INFO - 2023-12-05 16:09:18 --> Router Class Initialized
INFO - 2023-12-05 16:09:18 --> Output Class Initialized
INFO - 2023-12-05 16:09:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:18 --> Input Class Initialized
INFO - 2023-12-05 16:09:18 --> Language Class Initialized
ERROR - 2023-12-05 16:09:18 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:09:18 --> Config Class Initialized
INFO - 2023-12-05 16:09:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:18 --> URI Class Initialized
INFO - 2023-12-05 16:09:18 --> Router Class Initialized
INFO - 2023-12-05 16:09:18 --> Output Class Initialized
INFO - 2023-12-05 16:09:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:18 --> Input Class Initialized
INFO - 2023-12-05 16:09:18 --> Language Class Initialized
INFO - 2023-12-05 16:09:18 --> Language Class Initialized
INFO - 2023-12-05 16:09:18 --> Config Class Initialized
INFO - 2023-12-05 16:09:18 --> Loader Class Initialized
INFO - 2023-12-05 16:09:18 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:18 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:18 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:18 --> Controller Class Initialized
INFO - 2023-12-05 16:09:20 --> Config Class Initialized
INFO - 2023-12-05 16:09:20 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:20 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:20 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:20 --> URI Class Initialized
INFO - 2023-12-05 16:09:20 --> Router Class Initialized
INFO - 2023-12-05 16:09:20 --> Output Class Initialized
INFO - 2023-12-05 16:09:20 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:20 --> Input Class Initialized
INFO - 2023-12-05 16:09:20 --> Language Class Initialized
INFO - 2023-12-05 16:09:20 --> Language Class Initialized
INFO - 2023-12-05 16:09:20 --> Config Class Initialized
INFO - 2023-12-05 16:09:20 --> Loader Class Initialized
INFO - 2023-12-05 16:09:20 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:20 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:20 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:20 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:20 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:20 --> Controller Class Initialized
INFO - 2023-12-05 16:09:20 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:20 --> Total execution time: 0.0343
INFO - 2023-12-05 16:09:30 --> Config Class Initialized
INFO - 2023-12-05 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:30 --> URI Class Initialized
INFO - 2023-12-05 16:09:30 --> Router Class Initialized
INFO - 2023-12-05 16:09:30 --> Output Class Initialized
INFO - 2023-12-05 16:09:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:30 --> Input Class Initialized
INFO - 2023-12-05 16:09:30 --> Language Class Initialized
INFO - 2023-12-05 16:09:30 --> Language Class Initialized
INFO - 2023-12-05 16:09:30 --> Config Class Initialized
INFO - 2023-12-05 16:09:30 --> Loader Class Initialized
INFO - 2023-12-05 16:09:30 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:30 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:30 --> Controller Class Initialized
INFO - 2023-12-05 16:09:30 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:30 --> Total execution time: 0.0435
INFO - 2023-12-05 16:09:30 --> Config Class Initialized
INFO - 2023-12-05 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:30 --> URI Class Initialized
INFO - 2023-12-05 16:09:30 --> Router Class Initialized
INFO - 2023-12-05 16:09:30 --> Output Class Initialized
INFO - 2023-12-05 16:09:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:30 --> Input Class Initialized
INFO - 2023-12-05 16:09:30 --> Language Class Initialized
ERROR - 2023-12-05 16:09:30 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:09:30 --> Config Class Initialized
INFO - 2023-12-05 16:09:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:30 --> URI Class Initialized
INFO - 2023-12-05 16:09:30 --> Router Class Initialized
INFO - 2023-12-05 16:09:30 --> Output Class Initialized
INFO - 2023-12-05 16:09:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:30 --> Input Class Initialized
INFO - 2023-12-05 16:09:30 --> Language Class Initialized
INFO - 2023-12-05 16:09:30 --> Language Class Initialized
INFO - 2023-12-05 16:09:30 --> Config Class Initialized
INFO - 2023-12-05 16:09:30 --> Loader Class Initialized
INFO - 2023-12-05 16:09:30 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:30 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:30 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:30 --> Controller Class Initialized
INFO - 2023-12-05 16:09:31 --> Config Class Initialized
INFO - 2023-12-05 16:09:31 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:31 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:31 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:31 --> URI Class Initialized
INFO - 2023-12-05 16:09:31 --> Router Class Initialized
INFO - 2023-12-05 16:09:31 --> Output Class Initialized
INFO - 2023-12-05 16:09:31 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:31 --> Input Class Initialized
INFO - 2023-12-05 16:09:31 --> Language Class Initialized
INFO - 2023-12-05 16:09:31 --> Language Class Initialized
INFO - 2023-12-05 16:09:31 --> Config Class Initialized
INFO - 2023-12-05 16:09:31 --> Loader Class Initialized
INFO - 2023-12-05 16:09:31 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:31 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:31 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:31 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:31 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:31 --> Controller Class Initialized
INFO - 2023-12-05 16:09:31 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:31 --> Total execution time: 0.0443
INFO - 2023-12-05 16:09:41 --> Config Class Initialized
INFO - 2023-12-05 16:09:41 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:41 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:41 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:41 --> URI Class Initialized
INFO - 2023-12-05 16:09:41 --> Router Class Initialized
INFO - 2023-12-05 16:09:41 --> Output Class Initialized
INFO - 2023-12-05 16:09:41 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:41 --> Input Class Initialized
INFO - 2023-12-05 16:09:41 --> Language Class Initialized
INFO - 2023-12-05 16:09:41 --> Language Class Initialized
INFO - 2023-12-05 16:09:41 --> Config Class Initialized
INFO - 2023-12-05 16:09:41 --> Loader Class Initialized
INFO - 2023-12-05 16:09:41 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:41 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:41 --> Controller Class Initialized
INFO - 2023-12-05 16:09:41 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:41 --> Total execution time: 0.0426
INFO - 2023-12-05 16:09:41 --> Config Class Initialized
INFO - 2023-12-05 16:09:41 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:41 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:41 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:41 --> URI Class Initialized
INFO - 2023-12-05 16:09:41 --> Router Class Initialized
INFO - 2023-12-05 16:09:41 --> Output Class Initialized
INFO - 2023-12-05 16:09:41 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:41 --> Input Class Initialized
INFO - 2023-12-05 16:09:41 --> Language Class Initialized
ERROR - 2023-12-05 16:09:41 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:09:41 --> Config Class Initialized
INFO - 2023-12-05 16:09:41 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:41 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:41 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:41 --> URI Class Initialized
INFO - 2023-12-05 16:09:41 --> Router Class Initialized
INFO - 2023-12-05 16:09:41 --> Output Class Initialized
INFO - 2023-12-05 16:09:41 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:41 --> Input Class Initialized
INFO - 2023-12-05 16:09:41 --> Language Class Initialized
INFO - 2023-12-05 16:09:41 --> Language Class Initialized
INFO - 2023-12-05 16:09:41 --> Config Class Initialized
INFO - 2023-12-05 16:09:41 --> Loader Class Initialized
INFO - 2023-12-05 16:09:41 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:41 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:41 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:41 --> Controller Class Initialized
INFO - 2023-12-05 16:09:42 --> Config Class Initialized
INFO - 2023-12-05 16:09:42 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:42 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:42 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:42 --> URI Class Initialized
INFO - 2023-12-05 16:09:42 --> Router Class Initialized
INFO - 2023-12-05 16:09:42 --> Output Class Initialized
INFO - 2023-12-05 16:09:42 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:42 --> Input Class Initialized
INFO - 2023-12-05 16:09:42 --> Language Class Initialized
INFO - 2023-12-05 16:09:43 --> Language Class Initialized
INFO - 2023-12-05 16:09:43 --> Config Class Initialized
INFO - 2023-12-05 16:09:43 --> Loader Class Initialized
INFO - 2023-12-05 16:09:43 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:43 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:43 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:43 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:43 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:43 --> Controller Class Initialized
INFO - 2023-12-05 16:09:43 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:43 --> Total execution time: 0.0872
INFO - 2023-12-05 16:09:50 --> Config Class Initialized
INFO - 2023-12-05 16:09:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:50 --> URI Class Initialized
INFO - 2023-12-05 16:09:50 --> Router Class Initialized
INFO - 2023-12-05 16:09:50 --> Output Class Initialized
INFO - 2023-12-05 16:09:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:50 --> Input Class Initialized
INFO - 2023-12-05 16:09:50 --> Language Class Initialized
INFO - 2023-12-05 16:09:50 --> Language Class Initialized
INFO - 2023-12-05 16:09:50 --> Config Class Initialized
INFO - 2023-12-05 16:09:50 --> Loader Class Initialized
INFO - 2023-12-05 16:09:50 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:50 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:50 --> Controller Class Initialized
INFO - 2023-12-05 16:09:50 --> Final output sent to browser
DEBUG - 2023-12-05 16:09:50 --> Total execution time: 0.0373
INFO - 2023-12-05 16:09:50 --> Config Class Initialized
INFO - 2023-12-05 16:09:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:50 --> URI Class Initialized
INFO - 2023-12-05 16:09:50 --> Router Class Initialized
INFO - 2023-12-05 16:09:50 --> Output Class Initialized
INFO - 2023-12-05 16:09:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:50 --> Input Class Initialized
INFO - 2023-12-05 16:09:50 --> Language Class Initialized
ERROR - 2023-12-05 16:09:50 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:09:50 --> Config Class Initialized
INFO - 2023-12-05 16:09:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:09:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:09:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:09:50 --> URI Class Initialized
INFO - 2023-12-05 16:09:50 --> Router Class Initialized
INFO - 2023-12-05 16:09:50 --> Output Class Initialized
INFO - 2023-12-05 16:09:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:09:50 --> Input Class Initialized
INFO - 2023-12-05 16:09:50 --> Language Class Initialized
INFO - 2023-12-05 16:09:50 --> Language Class Initialized
INFO - 2023-12-05 16:09:50 --> Config Class Initialized
INFO - 2023-12-05 16:09:50 --> Loader Class Initialized
INFO - 2023-12-05 16:09:50 --> Helper loaded: url_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: file_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: form_helper
INFO - 2023-12-05 16:09:50 --> Helper loaded: my_helper
INFO - 2023-12-05 16:09:50 --> Database Driver Class Initialized
INFO - 2023-12-05 16:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:09:50 --> Controller Class Initialized
INFO - 2023-12-05 16:10:05 --> Config Class Initialized
INFO - 2023-12-05 16:10:05 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:05 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:05 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:05 --> URI Class Initialized
INFO - 2023-12-05 16:10:05 --> Router Class Initialized
INFO - 2023-12-05 16:10:05 --> Output Class Initialized
INFO - 2023-12-05 16:10:05 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:05 --> Input Class Initialized
INFO - 2023-12-05 16:10:05 --> Language Class Initialized
INFO - 2023-12-05 16:10:05 --> Language Class Initialized
INFO - 2023-12-05 16:10:05 --> Config Class Initialized
INFO - 2023-12-05 16:10:05 --> Loader Class Initialized
INFO - 2023-12-05 16:10:05 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:05 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:05 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:05 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:05 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:05 --> Controller Class Initialized
INFO - 2023-12-05 16:10:05 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:05 --> Total execution time: 0.0378
INFO - 2023-12-05 16:10:11 --> Config Class Initialized
INFO - 2023-12-05 16:10:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:11 --> URI Class Initialized
INFO - 2023-12-05 16:10:11 --> Router Class Initialized
INFO - 2023-12-05 16:10:11 --> Output Class Initialized
INFO - 2023-12-05 16:10:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:11 --> Input Class Initialized
INFO - 2023-12-05 16:10:11 --> Language Class Initialized
INFO - 2023-12-05 16:10:11 --> Language Class Initialized
INFO - 2023-12-05 16:10:11 --> Config Class Initialized
INFO - 2023-12-05 16:10:11 --> Loader Class Initialized
INFO - 2023-12-05 16:10:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:11 --> Controller Class Initialized
INFO - 2023-12-05 16:10:11 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:11 --> Total execution time: 0.0360
INFO - 2023-12-05 16:10:11 --> Config Class Initialized
INFO - 2023-12-05 16:10:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:11 --> URI Class Initialized
INFO - 2023-12-05 16:10:11 --> Router Class Initialized
INFO - 2023-12-05 16:10:11 --> Output Class Initialized
INFO - 2023-12-05 16:10:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:11 --> Input Class Initialized
INFO - 2023-12-05 16:10:11 --> Language Class Initialized
ERROR - 2023-12-05 16:10:11 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:10:11 --> Config Class Initialized
INFO - 2023-12-05 16:10:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:11 --> URI Class Initialized
INFO - 2023-12-05 16:10:11 --> Router Class Initialized
INFO - 2023-12-05 16:10:11 --> Output Class Initialized
INFO - 2023-12-05 16:10:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:11 --> Input Class Initialized
INFO - 2023-12-05 16:10:11 --> Language Class Initialized
INFO - 2023-12-05 16:10:11 --> Language Class Initialized
INFO - 2023-12-05 16:10:11 --> Config Class Initialized
INFO - 2023-12-05 16:10:11 --> Loader Class Initialized
INFO - 2023-12-05 16:10:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:11 --> Controller Class Initialized
INFO - 2023-12-05 16:10:15 --> Config Class Initialized
INFO - 2023-12-05 16:10:15 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:15 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:15 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:15 --> URI Class Initialized
INFO - 2023-12-05 16:10:15 --> Router Class Initialized
INFO - 2023-12-05 16:10:15 --> Output Class Initialized
INFO - 2023-12-05 16:10:15 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:15 --> Input Class Initialized
INFO - 2023-12-05 16:10:15 --> Language Class Initialized
INFO - 2023-12-05 16:10:15 --> Language Class Initialized
INFO - 2023-12-05 16:10:15 --> Config Class Initialized
INFO - 2023-12-05 16:10:15 --> Loader Class Initialized
INFO - 2023-12-05 16:10:15 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:15 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:15 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:15 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:15 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:15 --> Controller Class Initialized
INFO - 2023-12-05 16:10:15 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:15 --> Total execution time: 0.0388
INFO - 2023-12-05 16:10:19 --> Config Class Initialized
INFO - 2023-12-05 16:10:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:19 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:19 --> URI Class Initialized
INFO - 2023-12-05 16:10:19 --> Router Class Initialized
INFO - 2023-12-05 16:10:19 --> Output Class Initialized
INFO - 2023-12-05 16:10:19 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:19 --> Input Class Initialized
INFO - 2023-12-05 16:10:19 --> Language Class Initialized
INFO - 2023-12-05 16:10:19 --> Language Class Initialized
INFO - 2023-12-05 16:10:19 --> Config Class Initialized
INFO - 2023-12-05 16:10:19 --> Loader Class Initialized
INFO - 2023-12-05 16:10:19 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:19 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:19 --> Controller Class Initialized
INFO - 2023-12-05 16:10:19 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:19 --> Total execution time: 0.0322
INFO - 2023-12-05 16:10:19 --> Config Class Initialized
INFO - 2023-12-05 16:10:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:19 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:19 --> URI Class Initialized
INFO - 2023-12-05 16:10:19 --> Router Class Initialized
INFO - 2023-12-05 16:10:19 --> Output Class Initialized
INFO - 2023-12-05 16:10:19 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:19 --> Input Class Initialized
INFO - 2023-12-05 16:10:19 --> Language Class Initialized
ERROR - 2023-12-05 16:10:19 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:10:19 --> Config Class Initialized
INFO - 2023-12-05 16:10:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:19 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:19 --> URI Class Initialized
INFO - 2023-12-05 16:10:19 --> Router Class Initialized
INFO - 2023-12-05 16:10:19 --> Output Class Initialized
INFO - 2023-12-05 16:10:19 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:19 --> Input Class Initialized
INFO - 2023-12-05 16:10:19 --> Language Class Initialized
INFO - 2023-12-05 16:10:19 --> Language Class Initialized
INFO - 2023-12-05 16:10:19 --> Config Class Initialized
INFO - 2023-12-05 16:10:19 --> Loader Class Initialized
INFO - 2023-12-05 16:10:19 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:19 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:19 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:19 --> Controller Class Initialized
INFO - 2023-12-05 16:10:25 --> Config Class Initialized
INFO - 2023-12-05 16:10:25 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:25 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:25 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:25 --> URI Class Initialized
INFO - 2023-12-05 16:10:25 --> Router Class Initialized
INFO - 2023-12-05 16:10:25 --> Output Class Initialized
INFO - 2023-12-05 16:10:25 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:25 --> Input Class Initialized
INFO - 2023-12-05 16:10:25 --> Language Class Initialized
INFO - 2023-12-05 16:10:25 --> Language Class Initialized
INFO - 2023-12-05 16:10:25 --> Config Class Initialized
INFO - 2023-12-05 16:10:25 --> Loader Class Initialized
INFO - 2023-12-05 16:10:25 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:25 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:25 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:25 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:25 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:25 --> Controller Class Initialized
DEBUG - 2023-12-05 16:10:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:10:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:10:25 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:25 --> Total execution time: 0.0458
INFO - 2023-12-05 16:10:27 --> Config Class Initialized
INFO - 2023-12-05 16:10:27 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:10:27 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:10:27 --> Utf8 Class Initialized
INFO - 2023-12-05 16:10:27 --> URI Class Initialized
INFO - 2023-12-05 16:10:27 --> Router Class Initialized
INFO - 2023-12-05 16:10:27 --> Output Class Initialized
INFO - 2023-12-05 16:10:27 --> Security Class Initialized
DEBUG - 2023-12-05 16:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:10:27 --> Input Class Initialized
INFO - 2023-12-05 16:10:27 --> Language Class Initialized
INFO - 2023-12-05 16:10:27 --> Language Class Initialized
INFO - 2023-12-05 16:10:27 --> Config Class Initialized
INFO - 2023-12-05 16:10:27 --> Loader Class Initialized
INFO - 2023-12-05 16:10:27 --> Helper loaded: url_helper
INFO - 2023-12-05 16:10:27 --> Helper loaded: file_helper
INFO - 2023-12-05 16:10:27 --> Helper loaded: form_helper
INFO - 2023-12-05 16:10:27 --> Helper loaded: my_helper
INFO - 2023-12-05 16:10:27 --> Database Driver Class Initialized
INFO - 2023-12-05 16:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:10:27 --> Controller Class Initialized
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:10:27 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2023-12-05 16:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-05 16:10:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:10:27 --> Final output sent to browser
DEBUG - 2023-12-05 16:10:27 --> Total execution time: 0.0969
INFO - 2023-12-05 16:11:52 --> Config Class Initialized
INFO - 2023-12-05 16:11:52 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:11:52 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:11:52 --> Utf8 Class Initialized
INFO - 2023-12-05 16:11:52 --> URI Class Initialized
INFO - 2023-12-05 16:11:52 --> Router Class Initialized
INFO - 2023-12-05 16:11:52 --> Output Class Initialized
INFO - 2023-12-05 16:11:52 --> Security Class Initialized
DEBUG - 2023-12-05 16:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:11:52 --> Input Class Initialized
INFO - 2023-12-05 16:11:52 --> Language Class Initialized
INFO - 2023-12-05 16:11:52 --> Language Class Initialized
INFO - 2023-12-05 16:11:52 --> Config Class Initialized
INFO - 2023-12-05 16:11:52 --> Loader Class Initialized
INFO - 2023-12-05 16:11:52 --> Helper loaded: url_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: file_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: form_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: my_helper
INFO - 2023-12-05 16:11:52 --> Database Driver Class Initialized
INFO - 2023-12-05 16:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:11:52 --> Controller Class Initialized
INFO - 2023-12-05 16:11:52 --> Config Class Initialized
INFO - 2023-12-05 16:11:52 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:11:52 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:11:52 --> Utf8 Class Initialized
INFO - 2023-12-05 16:11:52 --> URI Class Initialized
INFO - 2023-12-05 16:11:52 --> Router Class Initialized
INFO - 2023-12-05 16:11:52 --> Output Class Initialized
INFO - 2023-12-05 16:11:52 --> Security Class Initialized
DEBUG - 2023-12-05 16:11:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:11:52 --> Input Class Initialized
INFO - 2023-12-05 16:11:52 --> Language Class Initialized
INFO - 2023-12-05 16:11:52 --> Language Class Initialized
INFO - 2023-12-05 16:11:52 --> Config Class Initialized
INFO - 2023-12-05 16:11:52 --> Loader Class Initialized
INFO - 2023-12-05 16:11:52 --> Helper loaded: url_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: file_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: form_helper
INFO - 2023-12-05 16:11:52 --> Helper loaded: my_helper
INFO - 2023-12-05 16:11:52 --> Database Driver Class Initialized
INFO - 2023-12-05 16:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:11:52 --> Controller Class Initialized
DEBUG - 2023-12-05 16:11:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:11:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:11:52 --> Final output sent to browser
DEBUG - 2023-12-05 16:11:52 --> Total execution time: 0.0376
INFO - 2023-12-05 16:12:02 --> Config Class Initialized
INFO - 2023-12-05 16:12:02 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:02 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:02 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:02 --> URI Class Initialized
INFO - 2023-12-05 16:12:02 --> Router Class Initialized
INFO - 2023-12-05 16:12:02 --> Output Class Initialized
INFO - 2023-12-05 16:12:02 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:02 --> Input Class Initialized
INFO - 2023-12-05 16:12:02 --> Language Class Initialized
INFO - 2023-12-05 16:12:02 --> Language Class Initialized
INFO - 2023-12-05 16:12:02 --> Config Class Initialized
INFO - 2023-12-05 16:12:02 --> Loader Class Initialized
INFO - 2023-12-05 16:12:02 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:02 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:02 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:02 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:02 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:02 --> Controller Class Initialized
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:02 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2023-12-05 16:12:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-05 16:12:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:12:02 --> Final output sent to browser
DEBUG - 2023-12-05 16:12:02 --> Total execution time: 0.0636
INFO - 2023-12-05 16:12:11 --> Config Class Initialized
INFO - 2023-12-05 16:12:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:11 --> URI Class Initialized
INFO - 2023-12-05 16:12:11 --> Router Class Initialized
INFO - 2023-12-05 16:12:11 --> Output Class Initialized
INFO - 2023-12-05 16:12:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:11 --> Input Class Initialized
INFO - 2023-12-05 16:12:11 --> Language Class Initialized
INFO - 2023-12-05 16:12:11 --> Language Class Initialized
INFO - 2023-12-05 16:12:11 --> Config Class Initialized
INFO - 2023-12-05 16:12:11 --> Loader Class Initialized
INFO - 2023-12-05 16:12:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:11 --> Controller Class Initialized
INFO - 2023-12-05 16:12:11 --> Config Class Initialized
INFO - 2023-12-05 16:12:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:11 --> URI Class Initialized
INFO - 2023-12-05 16:12:11 --> Router Class Initialized
INFO - 2023-12-05 16:12:11 --> Output Class Initialized
INFO - 2023-12-05 16:12:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:11 --> Input Class Initialized
INFO - 2023-12-05 16:12:11 --> Language Class Initialized
INFO - 2023-12-05 16:12:11 --> Language Class Initialized
INFO - 2023-12-05 16:12:11 --> Config Class Initialized
INFO - 2023-12-05 16:12:11 --> Loader Class Initialized
INFO - 2023-12-05 16:12:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:11 --> Controller Class Initialized
DEBUG - 2023-12-05 16:12:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:12:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:12:11 --> Final output sent to browser
DEBUG - 2023-12-05 16:12:11 --> Total execution time: 0.0437
INFO - 2023-12-05 16:12:13 --> Config Class Initialized
INFO - 2023-12-05 16:12:13 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:13 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:13 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:13 --> URI Class Initialized
INFO - 2023-12-05 16:12:13 --> Router Class Initialized
INFO - 2023-12-05 16:12:13 --> Output Class Initialized
INFO - 2023-12-05 16:12:13 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:13 --> Input Class Initialized
INFO - 2023-12-05 16:12:13 --> Language Class Initialized
INFO - 2023-12-05 16:12:13 --> Language Class Initialized
INFO - 2023-12-05 16:12:13 --> Config Class Initialized
INFO - 2023-12-05 16:12:13 --> Loader Class Initialized
INFO - 2023-12-05 16:12:13 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:13 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:13 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:13 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:13 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:13 --> Controller Class Initialized
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:12:13 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2023-12-05 16:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-05 16:12:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:12:13 --> Final output sent to browser
DEBUG - 2023-12-05 16:12:13 --> Total execution time: 0.0759
INFO - 2023-12-05 16:12:50 --> Config Class Initialized
INFO - 2023-12-05 16:12:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:50 --> URI Class Initialized
INFO - 2023-12-05 16:12:50 --> Router Class Initialized
INFO - 2023-12-05 16:12:50 --> Output Class Initialized
INFO - 2023-12-05 16:12:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:50 --> Input Class Initialized
INFO - 2023-12-05 16:12:50 --> Language Class Initialized
INFO - 2023-12-05 16:12:50 --> Language Class Initialized
INFO - 2023-12-05 16:12:50 --> Config Class Initialized
INFO - 2023-12-05 16:12:50 --> Loader Class Initialized
INFO - 2023-12-05 16:12:50 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:50 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:50 --> Controller Class Initialized
INFO - 2023-12-05 16:12:50 --> Config Class Initialized
INFO - 2023-12-05 16:12:50 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:12:50 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:12:50 --> Utf8 Class Initialized
INFO - 2023-12-05 16:12:50 --> URI Class Initialized
INFO - 2023-12-05 16:12:50 --> Router Class Initialized
INFO - 2023-12-05 16:12:50 --> Output Class Initialized
INFO - 2023-12-05 16:12:50 --> Security Class Initialized
DEBUG - 2023-12-05 16:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:12:50 --> Input Class Initialized
INFO - 2023-12-05 16:12:50 --> Language Class Initialized
INFO - 2023-12-05 16:12:50 --> Language Class Initialized
INFO - 2023-12-05 16:12:50 --> Config Class Initialized
INFO - 2023-12-05 16:12:50 --> Loader Class Initialized
INFO - 2023-12-05 16:12:50 --> Helper loaded: url_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: file_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: form_helper
INFO - 2023-12-05 16:12:50 --> Helper loaded: my_helper
INFO - 2023-12-05 16:12:50 --> Database Driver Class Initialized
INFO - 2023-12-05 16:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:12:50 --> Controller Class Initialized
DEBUG - 2023-12-05 16:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:12:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:12:50 --> Final output sent to browser
DEBUG - 2023-12-05 16:12:50 --> Total execution time: 0.0435
INFO - 2023-12-05 16:13:06 --> Config Class Initialized
INFO - 2023-12-05 16:13:06 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:06 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:06 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:06 --> URI Class Initialized
INFO - 2023-12-05 16:13:06 --> Router Class Initialized
INFO - 2023-12-05 16:13:06 --> Output Class Initialized
INFO - 2023-12-05 16:13:06 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:06 --> Input Class Initialized
INFO - 2023-12-05 16:13:06 --> Language Class Initialized
INFO - 2023-12-05 16:13:06 --> Language Class Initialized
INFO - 2023-12-05 16:13:06 --> Config Class Initialized
INFO - 2023-12-05 16:13:06 --> Loader Class Initialized
INFO - 2023-12-05 16:13:06 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:06 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:06 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:06 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:06 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:06 --> Controller Class Initialized
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:06 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2023-12-05 16:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-05 16:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:13:06 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:06 --> Total execution time: 0.1139
INFO - 2023-12-05 16:13:24 --> Config Class Initialized
INFO - 2023-12-05 16:13:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:24 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:24 --> URI Class Initialized
INFO - 2023-12-05 16:13:24 --> Router Class Initialized
INFO - 2023-12-05 16:13:24 --> Output Class Initialized
INFO - 2023-12-05 16:13:24 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:24 --> Input Class Initialized
INFO - 2023-12-05 16:13:24 --> Language Class Initialized
INFO - 2023-12-05 16:13:24 --> Language Class Initialized
INFO - 2023-12-05 16:13:24 --> Config Class Initialized
INFO - 2023-12-05 16:13:24 --> Loader Class Initialized
INFO - 2023-12-05 16:13:24 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:24 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:24 --> Controller Class Initialized
INFO - 2023-12-05 16:13:24 --> Config Class Initialized
INFO - 2023-12-05 16:13:24 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:24 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:24 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:24 --> URI Class Initialized
INFO - 2023-12-05 16:13:24 --> Router Class Initialized
INFO - 2023-12-05 16:13:24 --> Output Class Initialized
INFO - 2023-12-05 16:13:24 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:24 --> Input Class Initialized
INFO - 2023-12-05 16:13:24 --> Language Class Initialized
INFO - 2023-12-05 16:13:24 --> Language Class Initialized
INFO - 2023-12-05 16:13:24 --> Config Class Initialized
INFO - 2023-12-05 16:13:24 --> Loader Class Initialized
INFO - 2023-12-05 16:13:24 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:24 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:24 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:24 --> Controller Class Initialized
DEBUG - 2023-12-05 16:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:13:24 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:24 --> Total execution time: 0.0375
INFO - 2023-12-05 16:13:26 --> Config Class Initialized
INFO - 2023-12-05 16:13:26 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:26 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:26 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:26 --> URI Class Initialized
INFO - 2023-12-05 16:13:26 --> Router Class Initialized
INFO - 2023-12-05 16:13:26 --> Output Class Initialized
INFO - 2023-12-05 16:13:26 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:26 --> Input Class Initialized
INFO - 2023-12-05 16:13:26 --> Language Class Initialized
INFO - 2023-12-05 16:13:26 --> Language Class Initialized
INFO - 2023-12-05 16:13:26 --> Config Class Initialized
INFO - 2023-12-05 16:13:26 --> Loader Class Initialized
INFO - 2023-12-05 16:13:26 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:26 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:26 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:26 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:26 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:26 --> Controller Class Initialized
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 47
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 49
ERROR - 2023-12-05 16:13:26 --> Severity: Notice --> Undefined index: kelas /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php 59
DEBUG - 2023-12-05 16:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/form.php
DEBUG - 2023-12-05 16:13:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:13:26 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:26 --> Total execution time: 0.0411
INFO - 2023-12-05 16:13:36 --> Config Class Initialized
INFO - 2023-12-05 16:13:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:36 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:36 --> URI Class Initialized
INFO - 2023-12-05 16:13:36 --> Router Class Initialized
INFO - 2023-12-05 16:13:36 --> Output Class Initialized
INFO - 2023-12-05 16:13:36 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:36 --> Input Class Initialized
INFO - 2023-12-05 16:13:36 --> Language Class Initialized
INFO - 2023-12-05 16:13:36 --> Language Class Initialized
INFO - 2023-12-05 16:13:36 --> Config Class Initialized
INFO - 2023-12-05 16:13:36 --> Loader Class Initialized
INFO - 2023-12-05 16:13:36 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:36 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:36 --> Controller Class Initialized
INFO - 2023-12-05 16:13:36 --> Config Class Initialized
INFO - 2023-12-05 16:13:36 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:36 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:36 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:36 --> URI Class Initialized
INFO - 2023-12-05 16:13:36 --> Router Class Initialized
INFO - 2023-12-05 16:13:36 --> Output Class Initialized
INFO - 2023-12-05 16:13:36 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:36 --> Input Class Initialized
INFO - 2023-12-05 16:13:36 --> Language Class Initialized
INFO - 2023-12-05 16:13:36 --> Language Class Initialized
INFO - 2023-12-05 16:13:36 --> Config Class Initialized
INFO - 2023-12-05 16:13:36 --> Loader Class Initialized
INFO - 2023-12-05 16:13:36 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:36 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:36 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:36 --> Controller Class Initialized
DEBUG - 2023-12-05 16:13:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:13:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:13:36 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:36 --> Total execution time: 0.0904
INFO - 2023-12-05 16:13:43 --> Config Class Initialized
INFO - 2023-12-05 16:13:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:43 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:43 --> URI Class Initialized
INFO - 2023-12-05 16:13:43 --> Router Class Initialized
INFO - 2023-12-05 16:13:43 --> Output Class Initialized
INFO - 2023-12-05 16:13:43 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:43 --> Input Class Initialized
INFO - 2023-12-05 16:13:43 --> Language Class Initialized
INFO - 2023-12-05 16:13:43 --> Language Class Initialized
INFO - 2023-12-05 16:13:43 --> Config Class Initialized
INFO - 2023-12-05 16:13:43 --> Loader Class Initialized
INFO - 2023-12-05 16:13:43 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:43 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:43 --> Controller Class Initialized
DEBUG - 2023-12-05 16:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2023-12-05 16:13:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:13:43 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:43 --> Total execution time: 0.0850
INFO - 2023-12-05 16:13:43 --> Config Class Initialized
INFO - 2023-12-05 16:13:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:43 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:43 --> URI Class Initialized
INFO - 2023-12-05 16:13:43 --> Router Class Initialized
INFO - 2023-12-05 16:13:43 --> Output Class Initialized
INFO - 2023-12-05 16:13:43 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:43 --> Input Class Initialized
INFO - 2023-12-05 16:13:43 --> Language Class Initialized
ERROR - 2023-12-05 16:13:43 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:13:43 --> Config Class Initialized
INFO - 2023-12-05 16:13:43 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:43 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:43 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:43 --> URI Class Initialized
INFO - 2023-12-05 16:13:43 --> Router Class Initialized
INFO - 2023-12-05 16:13:43 --> Output Class Initialized
INFO - 2023-12-05 16:13:43 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:43 --> Input Class Initialized
INFO - 2023-12-05 16:13:43 --> Language Class Initialized
INFO - 2023-12-05 16:13:43 --> Language Class Initialized
INFO - 2023-12-05 16:13:43 --> Config Class Initialized
INFO - 2023-12-05 16:13:43 --> Loader Class Initialized
INFO - 2023-12-05 16:13:43 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:43 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:43 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:43 --> Controller Class Initialized
INFO - 2023-12-05 16:13:45 --> Config Class Initialized
INFO - 2023-12-05 16:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:13:45 --> Utf8 Class Initialized
INFO - 2023-12-05 16:13:45 --> URI Class Initialized
INFO - 2023-12-05 16:13:45 --> Router Class Initialized
INFO - 2023-12-05 16:13:45 --> Output Class Initialized
INFO - 2023-12-05 16:13:45 --> Security Class Initialized
DEBUG - 2023-12-05 16:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:13:45 --> Input Class Initialized
INFO - 2023-12-05 16:13:45 --> Language Class Initialized
INFO - 2023-12-05 16:13:45 --> Language Class Initialized
INFO - 2023-12-05 16:13:45 --> Config Class Initialized
INFO - 2023-12-05 16:13:45 --> Loader Class Initialized
INFO - 2023-12-05 16:13:45 --> Helper loaded: url_helper
INFO - 2023-12-05 16:13:45 --> Helper loaded: file_helper
INFO - 2023-12-05 16:13:45 --> Helper loaded: form_helper
INFO - 2023-12-05 16:13:45 --> Helper loaded: my_helper
INFO - 2023-12-05 16:13:45 --> Database Driver Class Initialized
INFO - 2023-12-05 16:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:13:45 --> Controller Class Initialized
INFO - 2023-12-05 16:13:45 --> Final output sent to browser
DEBUG - 2023-12-05 16:13:45 --> Total execution time: 0.0409
INFO - 2023-12-05 16:15:03 --> Config Class Initialized
INFO - 2023-12-05 16:15:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:03 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:03 --> URI Class Initialized
INFO - 2023-12-05 16:15:03 --> Router Class Initialized
INFO - 2023-12-05 16:15:03 --> Output Class Initialized
INFO - 2023-12-05 16:15:03 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:03 --> Input Class Initialized
INFO - 2023-12-05 16:15:03 --> Language Class Initialized
INFO - 2023-12-05 16:15:03 --> Language Class Initialized
INFO - 2023-12-05 16:15:03 --> Config Class Initialized
INFO - 2023-12-05 16:15:03 --> Loader Class Initialized
INFO - 2023-12-05 16:15:03 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:03 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:03 --> Controller Class Initialized
INFO - 2023-12-05 16:15:03 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:03 --> Total execution time: 0.0522
INFO - 2023-12-05 16:15:03 --> Config Class Initialized
INFO - 2023-12-05 16:15:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:03 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:03 --> URI Class Initialized
INFO - 2023-12-05 16:15:03 --> Router Class Initialized
INFO - 2023-12-05 16:15:03 --> Output Class Initialized
INFO - 2023-12-05 16:15:03 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:03 --> Input Class Initialized
INFO - 2023-12-05 16:15:03 --> Language Class Initialized
ERROR - 2023-12-05 16:15:03 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:15:03 --> Config Class Initialized
INFO - 2023-12-05 16:15:03 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:03 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:03 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:03 --> URI Class Initialized
INFO - 2023-12-05 16:15:03 --> Router Class Initialized
INFO - 2023-12-05 16:15:03 --> Output Class Initialized
INFO - 2023-12-05 16:15:03 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:03 --> Input Class Initialized
INFO - 2023-12-05 16:15:03 --> Language Class Initialized
INFO - 2023-12-05 16:15:03 --> Language Class Initialized
INFO - 2023-12-05 16:15:03 --> Config Class Initialized
INFO - 2023-12-05 16:15:03 --> Loader Class Initialized
INFO - 2023-12-05 16:15:03 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:03 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:03 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:03 --> Controller Class Initialized
INFO - 2023-12-05 16:15:04 --> Config Class Initialized
INFO - 2023-12-05 16:15:04 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:04 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:04 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:04 --> URI Class Initialized
INFO - 2023-12-05 16:15:04 --> Router Class Initialized
INFO - 2023-12-05 16:15:04 --> Output Class Initialized
INFO - 2023-12-05 16:15:04 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:04 --> Input Class Initialized
INFO - 2023-12-05 16:15:04 --> Language Class Initialized
INFO - 2023-12-05 16:15:04 --> Language Class Initialized
INFO - 2023-12-05 16:15:04 --> Config Class Initialized
INFO - 2023-12-05 16:15:04 --> Loader Class Initialized
INFO - 2023-12-05 16:15:04 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:04 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:04 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:04 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:04 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:04 --> Controller Class Initialized
INFO - 2023-12-05 16:15:04 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:04 --> Total execution time: 0.0396
INFO - 2023-12-05 16:15:11 --> Config Class Initialized
INFO - 2023-12-05 16:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:11 --> URI Class Initialized
INFO - 2023-12-05 16:15:11 --> Router Class Initialized
INFO - 2023-12-05 16:15:11 --> Output Class Initialized
INFO - 2023-12-05 16:15:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:11 --> Input Class Initialized
INFO - 2023-12-05 16:15:11 --> Language Class Initialized
INFO - 2023-12-05 16:15:11 --> Language Class Initialized
INFO - 2023-12-05 16:15:11 --> Config Class Initialized
INFO - 2023-12-05 16:15:11 --> Loader Class Initialized
INFO - 2023-12-05 16:15:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:11 --> Controller Class Initialized
INFO - 2023-12-05 16:15:11 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:11 --> Total execution time: 0.0651
INFO - 2023-12-05 16:15:11 --> Config Class Initialized
INFO - 2023-12-05 16:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:11 --> URI Class Initialized
INFO - 2023-12-05 16:15:11 --> Router Class Initialized
INFO - 2023-12-05 16:15:11 --> Output Class Initialized
INFO - 2023-12-05 16:15:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:11 --> Input Class Initialized
INFO - 2023-12-05 16:15:11 --> Language Class Initialized
ERROR - 2023-12-05 16:15:11 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:15:11 --> Config Class Initialized
INFO - 2023-12-05 16:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:11 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:11 --> URI Class Initialized
INFO - 2023-12-05 16:15:11 --> Router Class Initialized
INFO - 2023-12-05 16:15:11 --> Output Class Initialized
INFO - 2023-12-05 16:15:11 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:11 --> Input Class Initialized
INFO - 2023-12-05 16:15:11 --> Language Class Initialized
INFO - 2023-12-05 16:15:11 --> Language Class Initialized
INFO - 2023-12-05 16:15:11 --> Config Class Initialized
INFO - 2023-12-05 16:15:11 --> Loader Class Initialized
INFO - 2023-12-05 16:15:11 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:11 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:11 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:11 --> Controller Class Initialized
INFO - 2023-12-05 16:15:12 --> Config Class Initialized
INFO - 2023-12-05 16:15:12 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:12 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:12 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:12 --> URI Class Initialized
INFO - 2023-12-05 16:15:12 --> Router Class Initialized
INFO - 2023-12-05 16:15:12 --> Output Class Initialized
INFO - 2023-12-05 16:15:12 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:12 --> Input Class Initialized
INFO - 2023-12-05 16:15:12 --> Language Class Initialized
INFO - 2023-12-05 16:15:12 --> Language Class Initialized
INFO - 2023-12-05 16:15:12 --> Config Class Initialized
INFO - 2023-12-05 16:15:12 --> Loader Class Initialized
INFO - 2023-12-05 16:15:12 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:12 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:12 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:12 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:12 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:12 --> Controller Class Initialized
INFO - 2023-12-05 16:15:12 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:12 --> Total execution time: 0.0414
INFO - 2023-12-05 16:15:18 --> Config Class Initialized
INFO - 2023-12-05 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:18 --> URI Class Initialized
INFO - 2023-12-05 16:15:18 --> Router Class Initialized
INFO - 2023-12-05 16:15:18 --> Output Class Initialized
INFO - 2023-12-05 16:15:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:18 --> Input Class Initialized
INFO - 2023-12-05 16:15:18 --> Language Class Initialized
INFO - 2023-12-05 16:15:18 --> Language Class Initialized
INFO - 2023-12-05 16:15:18 --> Config Class Initialized
INFO - 2023-12-05 16:15:18 --> Loader Class Initialized
INFO - 2023-12-05 16:15:18 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:18 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:18 --> Controller Class Initialized
INFO - 2023-12-05 16:15:18 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:18 --> Total execution time: 0.0408
INFO - 2023-12-05 16:15:18 --> Config Class Initialized
INFO - 2023-12-05 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:18 --> URI Class Initialized
INFO - 2023-12-05 16:15:18 --> Router Class Initialized
INFO - 2023-12-05 16:15:18 --> Output Class Initialized
INFO - 2023-12-05 16:15:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:18 --> Input Class Initialized
INFO - 2023-12-05 16:15:18 --> Language Class Initialized
ERROR - 2023-12-05 16:15:18 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:15:18 --> Config Class Initialized
INFO - 2023-12-05 16:15:18 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:18 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:18 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:18 --> URI Class Initialized
INFO - 2023-12-05 16:15:18 --> Router Class Initialized
INFO - 2023-12-05 16:15:18 --> Output Class Initialized
INFO - 2023-12-05 16:15:18 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:18 --> Input Class Initialized
INFO - 2023-12-05 16:15:18 --> Language Class Initialized
INFO - 2023-12-05 16:15:18 --> Language Class Initialized
INFO - 2023-12-05 16:15:18 --> Config Class Initialized
INFO - 2023-12-05 16:15:18 --> Loader Class Initialized
INFO - 2023-12-05 16:15:18 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:18 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:18 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:18 --> Controller Class Initialized
INFO - 2023-12-05 16:15:19 --> Config Class Initialized
INFO - 2023-12-05 16:15:19 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:19 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:19 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:19 --> URI Class Initialized
INFO - 2023-12-05 16:15:19 --> Router Class Initialized
INFO - 2023-12-05 16:15:19 --> Output Class Initialized
INFO - 2023-12-05 16:15:19 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:19 --> Input Class Initialized
INFO - 2023-12-05 16:15:19 --> Language Class Initialized
INFO - 2023-12-05 16:15:19 --> Language Class Initialized
INFO - 2023-12-05 16:15:19 --> Config Class Initialized
INFO - 2023-12-05 16:15:19 --> Loader Class Initialized
INFO - 2023-12-05 16:15:19 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:19 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:19 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:19 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:19 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:19 --> Controller Class Initialized
INFO - 2023-12-05 16:15:19 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:19 --> Total execution time: 0.0345
INFO - 2023-12-05 16:15:30 --> Config Class Initialized
INFO - 2023-12-05 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:30 --> URI Class Initialized
INFO - 2023-12-05 16:15:30 --> Router Class Initialized
INFO - 2023-12-05 16:15:30 --> Output Class Initialized
INFO - 2023-12-05 16:15:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:30 --> Input Class Initialized
INFO - 2023-12-05 16:15:30 --> Language Class Initialized
INFO - 2023-12-05 16:15:30 --> Language Class Initialized
INFO - 2023-12-05 16:15:30 --> Config Class Initialized
INFO - 2023-12-05 16:15:30 --> Loader Class Initialized
INFO - 2023-12-05 16:15:30 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:30 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:30 --> Controller Class Initialized
INFO - 2023-12-05 16:15:30 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:30 --> Total execution time: 0.0403
INFO - 2023-12-05 16:15:30 --> Config Class Initialized
INFO - 2023-12-05 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:30 --> URI Class Initialized
INFO - 2023-12-05 16:15:30 --> Router Class Initialized
INFO - 2023-12-05 16:15:30 --> Output Class Initialized
INFO - 2023-12-05 16:15:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:30 --> Input Class Initialized
INFO - 2023-12-05 16:15:30 --> Language Class Initialized
ERROR - 2023-12-05 16:15:30 --> 404 Page Not Found: /index
INFO - 2023-12-05 16:15:30 --> Config Class Initialized
INFO - 2023-12-05 16:15:30 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:30 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:30 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:30 --> URI Class Initialized
INFO - 2023-12-05 16:15:30 --> Router Class Initialized
INFO - 2023-12-05 16:15:30 --> Output Class Initialized
INFO - 2023-12-05 16:15:30 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:30 --> Input Class Initialized
INFO - 2023-12-05 16:15:30 --> Language Class Initialized
INFO - 2023-12-05 16:15:30 --> Language Class Initialized
INFO - 2023-12-05 16:15:30 --> Config Class Initialized
INFO - 2023-12-05 16:15:30 --> Loader Class Initialized
INFO - 2023-12-05 16:15:30 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:30 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:30 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:30 --> Controller Class Initialized
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:40 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:40 --> URI Class Initialized
INFO - 2023-12-05 16:15:40 --> Router Class Initialized
INFO - 2023-12-05 16:15:40 --> Output Class Initialized
INFO - 2023-12-05 16:15:40 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:40 --> Input Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Loader Class Initialized
INFO - 2023-12-05 16:15:40 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:40 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:40 --> Controller Class Initialized
INFO - 2023-12-05 16:15:40 --> Helper loaded: cookie_helper
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:40 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:40 --> URI Class Initialized
INFO - 2023-12-05 16:15:40 --> Router Class Initialized
INFO - 2023-12-05 16:15:40 --> Output Class Initialized
INFO - 2023-12-05 16:15:40 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:40 --> Input Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Loader Class Initialized
INFO - 2023-12-05 16:15:40 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:40 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:40 --> Controller Class Initialized
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:40 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:40 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:40 --> URI Class Initialized
INFO - 2023-12-05 16:15:40 --> Router Class Initialized
INFO - 2023-12-05 16:15:40 --> Output Class Initialized
INFO - 2023-12-05 16:15:40 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:40 --> Input Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Language Class Initialized
INFO - 2023-12-05 16:15:40 --> Config Class Initialized
INFO - 2023-12-05 16:15:40 --> Loader Class Initialized
INFO - 2023-12-05 16:15:40 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:40 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:40 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:40 --> Controller Class Initialized
DEBUG - 2023-12-05 16:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-05 16:15:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:15:40 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:40 --> Total execution time: 0.0332
INFO - 2023-12-05 16:15:44 --> Config Class Initialized
INFO - 2023-12-05 16:15:44 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:44 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:44 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:44 --> URI Class Initialized
INFO - 2023-12-05 16:15:44 --> Router Class Initialized
INFO - 2023-12-05 16:15:44 --> Output Class Initialized
INFO - 2023-12-05 16:15:44 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:44 --> Input Class Initialized
INFO - 2023-12-05 16:15:44 --> Language Class Initialized
INFO - 2023-12-05 16:15:44 --> Language Class Initialized
INFO - 2023-12-05 16:15:44 --> Config Class Initialized
INFO - 2023-12-05 16:15:44 --> Loader Class Initialized
INFO - 2023-12-05 16:15:44 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:44 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:44 --> Controller Class Initialized
INFO - 2023-12-05 16:15:44 --> Helper loaded: cookie_helper
INFO - 2023-12-05 16:15:44 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:44 --> Total execution time: 0.0320
INFO - 2023-12-05 16:15:44 --> Config Class Initialized
INFO - 2023-12-05 16:15:44 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:44 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:44 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:44 --> URI Class Initialized
INFO - 2023-12-05 16:15:44 --> Router Class Initialized
INFO - 2023-12-05 16:15:44 --> Output Class Initialized
INFO - 2023-12-05 16:15:44 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:44 --> Input Class Initialized
INFO - 2023-12-05 16:15:44 --> Language Class Initialized
INFO - 2023-12-05 16:15:44 --> Language Class Initialized
INFO - 2023-12-05 16:15:44 --> Config Class Initialized
INFO - 2023-12-05 16:15:44 --> Loader Class Initialized
INFO - 2023-12-05 16:15:44 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:44 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:44 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:44 --> Controller Class Initialized
DEBUG - 2023-12-05 16:15:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-05 16:15:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:15:44 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:44 --> Total execution time: 0.0357
INFO - 2023-12-05 16:15:47 --> Config Class Initialized
INFO - 2023-12-05 16:15:47 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:47 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:47 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:47 --> URI Class Initialized
INFO - 2023-12-05 16:15:47 --> Router Class Initialized
INFO - 2023-12-05 16:15:47 --> Output Class Initialized
INFO - 2023-12-05 16:15:47 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:47 --> Input Class Initialized
INFO - 2023-12-05 16:15:47 --> Language Class Initialized
INFO - 2023-12-05 16:15:47 --> Language Class Initialized
INFO - 2023-12-05 16:15:47 --> Config Class Initialized
INFO - 2023-12-05 16:15:47 --> Loader Class Initialized
INFO - 2023-12-05 16:15:47 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:47 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:47 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:47 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:47 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:47 --> Controller Class Initialized
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:47 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-05 16:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-05 16:15:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:15:47 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:47 --> Total execution time: 0.0466
INFO - 2023-12-05 16:15:52 --> Config Class Initialized
INFO - 2023-12-05 16:15:52 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:52 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:52 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:52 --> URI Class Initialized
INFO - 2023-12-05 16:15:52 --> Router Class Initialized
INFO - 2023-12-05 16:15:52 --> Output Class Initialized
INFO - 2023-12-05 16:15:52 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:52 --> Input Class Initialized
INFO - 2023-12-05 16:15:52 --> Language Class Initialized
INFO - 2023-12-05 16:15:52 --> Language Class Initialized
INFO - 2023-12-05 16:15:52 --> Config Class Initialized
INFO - 2023-12-05 16:15:52 --> Loader Class Initialized
INFO - 2023-12-05 16:15:52 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:52 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:52 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:52 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:52 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:52 --> Controller Class Initialized
DEBUG - 2023-12-05 16:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-05 16:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:15:52 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:52 --> Total execution time: 0.1360
INFO - 2023-12-05 16:15:53 --> Config Class Initialized
INFO - 2023-12-05 16:15:53 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:53 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:53 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:53 --> URI Class Initialized
INFO - 2023-12-05 16:15:53 --> Router Class Initialized
INFO - 2023-12-05 16:15:53 --> Output Class Initialized
INFO - 2023-12-05 16:15:53 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:53 --> Input Class Initialized
INFO - 2023-12-05 16:15:53 --> Language Class Initialized
INFO - 2023-12-05 16:15:53 --> Language Class Initialized
INFO - 2023-12-05 16:15:53 --> Config Class Initialized
INFO - 2023-12-05 16:15:53 --> Loader Class Initialized
INFO - 2023-12-05 16:15:53 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:53 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:53 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:53 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:53 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:53 --> Controller Class Initialized
INFO - 2023-12-05 16:15:58 --> Config Class Initialized
INFO - 2023-12-05 16:15:58 --> Hooks Class Initialized
DEBUG - 2023-12-05 16:15:58 --> UTF-8 Support Enabled
INFO - 2023-12-05 16:15:58 --> Utf8 Class Initialized
INFO - 2023-12-05 16:15:58 --> URI Class Initialized
INFO - 2023-12-05 16:15:58 --> Router Class Initialized
INFO - 2023-12-05 16:15:58 --> Output Class Initialized
INFO - 2023-12-05 16:15:58 --> Security Class Initialized
DEBUG - 2023-12-05 16:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-05 16:15:58 --> Input Class Initialized
INFO - 2023-12-05 16:15:58 --> Language Class Initialized
INFO - 2023-12-05 16:15:58 --> Language Class Initialized
INFO - 2023-12-05 16:15:58 --> Config Class Initialized
INFO - 2023-12-05 16:15:58 --> Loader Class Initialized
INFO - 2023-12-05 16:15:58 --> Helper loaded: url_helper
INFO - 2023-12-05 16:15:58 --> Helper loaded: file_helper
INFO - 2023-12-05 16:15:58 --> Helper loaded: form_helper
INFO - 2023-12-05 16:15:58 --> Helper loaded: my_helper
INFO - 2023-12-05 16:15:58 --> Database Driver Class Initialized
INFO - 2023-12-05 16:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-05 16:15:58 --> Controller Class Initialized
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-05 16:15:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-05 16:15:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-05 16:15:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-05 16:15:58 --> Final output sent to browser
DEBUG - 2023-12-05 16:15:58 --> Total execution time: 0.0389
