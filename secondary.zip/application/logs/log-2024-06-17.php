<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-06-17 13:10:59 --> Config Class Initialized
INFO - 2024-06-17 13:10:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 13:10:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 13:10:59 --> Utf8 Class Initialized
INFO - 2024-06-17 13:10:59 --> URI Class Initialized
INFO - 2024-06-17 13:10:59 --> Router Class Initialized
INFO - 2024-06-17 13:10:59 --> Output Class Initialized
INFO - 2024-06-17 13:10:59 --> Security Class Initialized
DEBUG - 2024-06-17 13:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 13:10:59 --> Input Class Initialized
INFO - 2024-06-17 13:10:59 --> Language Class Initialized
INFO - 2024-06-17 13:10:59 --> Language Class Initialized
INFO - 2024-06-17 13:10:59 --> Config Class Initialized
INFO - 2024-06-17 13:10:59 --> Loader Class Initialized
INFO - 2024-06-17 13:10:59 --> Helper loaded: url_helper
INFO - 2024-06-17 13:10:59 --> Helper loaded: file_helper
INFO - 2024-06-17 13:10:59 --> Helper loaded: form_helper
INFO - 2024-06-17 13:10:59 --> Helper loaded: my_helper
INFO - 2024-06-17 13:10:59 --> Database Driver Class Initialized
INFO - 2024-06-17 13:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 13:10:59 --> Controller Class Initialized
DEBUG - 2024-06-17 13:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 13:10:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 13:10:59 --> Final output sent to browser
DEBUG - 2024-06-17 13:10:59 --> Total execution time: 0.0642
INFO - 2024-06-17 21:23:46 --> Config Class Initialized
INFO - 2024-06-17 21:23:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:46 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:46 --> URI Class Initialized
INFO - 2024-06-17 21:23:46 --> Router Class Initialized
INFO - 2024-06-17 21:23:46 --> Output Class Initialized
INFO - 2024-06-17 21:23:46 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:46 --> Input Class Initialized
INFO - 2024-06-17 21:23:46 --> Language Class Initialized
INFO - 2024-06-17 21:23:46 --> Language Class Initialized
INFO - 2024-06-17 21:23:46 --> Config Class Initialized
INFO - 2024-06-17 21:23:46 --> Loader Class Initialized
INFO - 2024-06-17 21:23:46 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:46 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:46 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:46 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:46 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:46 --> Controller Class Initialized
DEBUG - 2024-06-17 21:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-17 21:23:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:23:46 --> Final output sent to browser
DEBUG - 2024-06-17 21:23:46 --> Total execution time: 0.0474
INFO - 2024-06-17 21:23:47 --> Config Class Initialized
INFO - 2024-06-17 21:23:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:47 --> URI Class Initialized
INFO - 2024-06-17 21:23:47 --> Router Class Initialized
INFO - 2024-06-17 21:23:47 --> Output Class Initialized
INFO - 2024-06-17 21:23:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:47 --> Input Class Initialized
INFO - 2024-06-17 21:23:47 --> Language Class Initialized
INFO - 2024-06-17 21:23:47 --> Language Class Initialized
INFO - 2024-06-17 21:23:47 --> Config Class Initialized
INFO - 2024-06-17 21:23:47 --> Loader Class Initialized
INFO - 2024-06-17 21:23:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:47 --> Controller Class Initialized
INFO - 2024-06-17 21:23:51 --> Config Class Initialized
INFO - 2024-06-17 21:23:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:51 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:51 --> URI Class Initialized
INFO - 2024-06-17 21:23:51 --> Router Class Initialized
INFO - 2024-06-17 21:23:51 --> Output Class Initialized
INFO - 2024-06-17 21:23:51 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:51 --> Input Class Initialized
INFO - 2024-06-17 21:23:51 --> Language Class Initialized
INFO - 2024-06-17 21:23:51 --> Language Class Initialized
INFO - 2024-06-17 21:23:51 --> Config Class Initialized
INFO - 2024-06-17 21:23:51 --> Loader Class Initialized
INFO - 2024-06-17 21:23:51 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:51 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:51 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:51 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:51 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:51 --> Controller Class Initialized
DEBUG - 2024-06-17 21:23:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-17 21:23:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:23:51 --> Final output sent to browser
DEBUG - 2024-06-17 21:23:51 --> Total execution time: 0.0282
INFO - 2024-06-17 21:23:52 --> Config Class Initialized
INFO - 2024-06-17 21:23:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:52 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:52 --> URI Class Initialized
INFO - 2024-06-17 21:23:52 --> Router Class Initialized
INFO - 2024-06-17 21:23:52 --> Output Class Initialized
INFO - 2024-06-17 21:23:52 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:52 --> Input Class Initialized
INFO - 2024-06-17 21:23:52 --> Language Class Initialized
INFO - 2024-06-17 21:23:52 --> Language Class Initialized
INFO - 2024-06-17 21:23:52 --> Config Class Initialized
INFO - 2024-06-17 21:23:52 --> Loader Class Initialized
INFO - 2024-06-17 21:23:52 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:52 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:52 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:52 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:52 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:52 --> Controller Class Initialized
INFO - 2024-06-17 21:23:55 --> Config Class Initialized
INFO - 2024-06-17 21:23:55 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:55 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:55 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:55 --> URI Class Initialized
INFO - 2024-06-17 21:23:55 --> Router Class Initialized
INFO - 2024-06-17 21:23:55 --> Output Class Initialized
INFO - 2024-06-17 21:23:55 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:55 --> Input Class Initialized
INFO - 2024-06-17 21:23:55 --> Language Class Initialized
INFO - 2024-06-17 21:23:55 --> Language Class Initialized
INFO - 2024-06-17 21:23:55 --> Config Class Initialized
INFO - 2024-06-17 21:23:55 --> Loader Class Initialized
INFO - 2024-06-17 21:23:55 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:55 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:55 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:55 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:55 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:55 --> Controller Class Initialized
INFO - 2024-06-17 21:23:55 --> Final output sent to browser
DEBUG - 2024-06-17 21:23:55 --> Total execution time: 0.1844
INFO - 2024-06-17 21:23:57 --> Config Class Initialized
INFO - 2024-06-17 21:23:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:57 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:57 --> URI Class Initialized
INFO - 2024-06-17 21:23:57 --> Router Class Initialized
INFO - 2024-06-17 21:23:57 --> Output Class Initialized
INFO - 2024-06-17 21:23:57 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:57 --> Input Class Initialized
INFO - 2024-06-17 21:23:57 --> Language Class Initialized
INFO - 2024-06-17 21:23:57 --> Language Class Initialized
INFO - 2024-06-17 21:23:57 --> Config Class Initialized
INFO - 2024-06-17 21:23:57 --> Loader Class Initialized
INFO - 2024-06-17 21:23:57 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:57 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:57 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:57 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:57 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:57 --> Controller Class Initialized
INFO - 2024-06-17 21:23:57 --> Final output sent to browser
DEBUG - 2024-06-17 21:23:57 --> Total execution time: 0.0500
INFO - 2024-06-17 21:23:59 --> Config Class Initialized
INFO - 2024-06-17 21:23:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:23:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:23:59 --> Utf8 Class Initialized
INFO - 2024-06-17 21:23:59 --> URI Class Initialized
INFO - 2024-06-17 21:23:59 --> Router Class Initialized
INFO - 2024-06-17 21:23:59 --> Output Class Initialized
INFO - 2024-06-17 21:23:59 --> Security Class Initialized
DEBUG - 2024-06-17 21:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:23:59 --> Input Class Initialized
INFO - 2024-06-17 21:23:59 --> Language Class Initialized
INFO - 2024-06-17 21:23:59 --> Language Class Initialized
INFO - 2024-06-17 21:23:59 --> Config Class Initialized
INFO - 2024-06-17 21:23:59 --> Loader Class Initialized
INFO - 2024-06-17 21:23:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:23:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:23:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:23:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:23:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:23:59 --> Controller Class Initialized
INFO - 2024-06-17 21:23:59 --> Final output sent to browser
DEBUG - 2024-06-17 21:23:59 --> Total execution time: 0.0291
INFO - 2024-06-17 21:24:16 --> Config Class Initialized
INFO - 2024-06-17 21:24:16 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:24:16 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:24:16 --> Utf8 Class Initialized
INFO - 2024-06-17 21:24:16 --> URI Class Initialized
INFO - 2024-06-17 21:24:16 --> Router Class Initialized
INFO - 2024-06-17 21:24:16 --> Output Class Initialized
INFO - 2024-06-17 21:24:16 --> Security Class Initialized
DEBUG - 2024-06-17 21:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:24:16 --> Input Class Initialized
INFO - 2024-06-17 21:24:16 --> Language Class Initialized
INFO - 2024-06-17 21:24:16 --> Language Class Initialized
INFO - 2024-06-17 21:24:16 --> Config Class Initialized
INFO - 2024-06-17 21:24:16 --> Loader Class Initialized
INFO - 2024-06-17 21:24:16 --> Helper loaded: url_helper
INFO - 2024-06-17 21:24:16 --> Helper loaded: file_helper
INFO - 2024-06-17 21:24:16 --> Helper loaded: form_helper
INFO - 2024-06-17 21:24:16 --> Helper loaded: my_helper
INFO - 2024-06-17 21:24:16 --> Database Driver Class Initialized
INFO - 2024-06-17 21:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:24:16 --> Controller Class Initialized
INFO - 2024-06-17 21:24:16 --> Final output sent to browser
DEBUG - 2024-06-17 21:24:16 --> Total execution time: 0.0263
INFO - 2024-06-17 21:24:17 --> Config Class Initialized
INFO - 2024-06-17 21:24:17 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:24:17 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:24:17 --> Utf8 Class Initialized
INFO - 2024-06-17 21:24:17 --> URI Class Initialized
INFO - 2024-06-17 21:24:17 --> Router Class Initialized
INFO - 2024-06-17 21:24:17 --> Output Class Initialized
INFO - 2024-06-17 21:24:17 --> Security Class Initialized
DEBUG - 2024-06-17 21:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:24:17 --> Input Class Initialized
INFO - 2024-06-17 21:24:17 --> Language Class Initialized
INFO - 2024-06-17 21:24:17 --> Language Class Initialized
INFO - 2024-06-17 21:24:17 --> Config Class Initialized
INFO - 2024-06-17 21:24:17 --> Loader Class Initialized
INFO - 2024-06-17 21:24:17 --> Helper loaded: url_helper
INFO - 2024-06-17 21:24:17 --> Helper loaded: file_helper
INFO - 2024-06-17 21:24:17 --> Helper loaded: form_helper
INFO - 2024-06-17 21:24:17 --> Helper loaded: my_helper
INFO - 2024-06-17 21:24:17 --> Database Driver Class Initialized
INFO - 2024-06-17 21:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:24:17 --> Controller Class Initialized
INFO - 2024-06-17 21:24:17 --> Final output sent to browser
DEBUG - 2024-06-17 21:24:17 --> Total execution time: 0.0328
INFO - 2024-06-17 21:24:20 --> Config Class Initialized
INFO - 2024-06-17 21:24:20 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:24:20 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:24:20 --> Utf8 Class Initialized
INFO - 2024-06-17 21:24:20 --> URI Class Initialized
INFO - 2024-06-17 21:24:20 --> Router Class Initialized
INFO - 2024-06-17 21:24:20 --> Output Class Initialized
INFO - 2024-06-17 21:24:20 --> Security Class Initialized
DEBUG - 2024-06-17 21:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:24:20 --> Input Class Initialized
INFO - 2024-06-17 21:24:20 --> Language Class Initialized
INFO - 2024-06-17 21:24:20 --> Language Class Initialized
INFO - 2024-06-17 21:24:20 --> Config Class Initialized
INFO - 2024-06-17 21:24:20 --> Loader Class Initialized
INFO - 2024-06-17 21:24:20 --> Helper loaded: url_helper
INFO - 2024-06-17 21:24:20 --> Helper loaded: file_helper
INFO - 2024-06-17 21:24:20 --> Helper loaded: form_helper
INFO - 2024-06-17 21:24:20 --> Helper loaded: my_helper
INFO - 2024-06-17 21:24:20 --> Database Driver Class Initialized
INFO - 2024-06-17 21:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:24:20 --> Controller Class Initialized
INFO - 2024-06-17 21:24:20 --> Final output sent to browser
DEBUG - 2024-06-17 21:24:20 --> Total execution time: 0.0482
INFO - 2024-06-17 21:28:48 --> Config Class Initialized
INFO - 2024-06-17 21:28:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:28:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:28:48 --> Utf8 Class Initialized
INFO - 2024-06-17 21:28:48 --> URI Class Initialized
INFO - 2024-06-17 21:28:48 --> Router Class Initialized
INFO - 2024-06-17 21:28:48 --> Output Class Initialized
INFO - 2024-06-17 21:28:48 --> Security Class Initialized
DEBUG - 2024-06-17 21:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:28:48 --> Input Class Initialized
INFO - 2024-06-17 21:28:48 --> Language Class Initialized
INFO - 2024-06-17 21:28:48 --> Language Class Initialized
INFO - 2024-06-17 21:28:48 --> Config Class Initialized
INFO - 2024-06-17 21:28:48 --> Loader Class Initialized
INFO - 2024-06-17 21:28:48 --> Helper loaded: url_helper
INFO - 2024-06-17 21:28:48 --> Helper loaded: file_helper
INFO - 2024-06-17 21:28:48 --> Helper loaded: form_helper
INFO - 2024-06-17 21:28:48 --> Helper loaded: my_helper
INFO - 2024-06-17 21:28:48 --> Database Driver Class Initialized
INFO - 2024-06-17 21:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:28:48 --> Controller Class Initialized
INFO - 2024-06-17 21:28:48 --> Final output sent to browser
DEBUG - 2024-06-17 21:28:48 --> Total execution time: 0.0393
INFO - 2024-06-17 21:28:54 --> Config Class Initialized
INFO - 2024-06-17 21:28:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:28:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:28:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:28:54 --> URI Class Initialized
INFO - 2024-06-17 21:28:54 --> Router Class Initialized
INFO - 2024-06-17 21:28:54 --> Output Class Initialized
INFO - 2024-06-17 21:28:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:28:54 --> Input Class Initialized
INFO - 2024-06-17 21:28:54 --> Language Class Initialized
INFO - 2024-06-17 21:28:54 --> Language Class Initialized
INFO - 2024-06-17 21:28:54 --> Config Class Initialized
INFO - 2024-06-17 21:28:54 --> Loader Class Initialized
INFO - 2024-06-17 21:28:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:28:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:28:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:28:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:28:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:28:54 --> Controller Class Initialized
INFO - 2024-06-17 21:28:54 --> Final output sent to browser
DEBUG - 2024-06-17 21:28:54 --> Total execution time: 0.0492
INFO - 2024-06-17 21:29:25 --> Config Class Initialized
INFO - 2024-06-17 21:29:25 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:29:25 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:29:25 --> Utf8 Class Initialized
INFO - 2024-06-17 21:29:25 --> URI Class Initialized
INFO - 2024-06-17 21:29:25 --> Router Class Initialized
INFO - 2024-06-17 21:29:25 --> Output Class Initialized
INFO - 2024-06-17 21:29:25 --> Security Class Initialized
DEBUG - 2024-06-17 21:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:29:25 --> Input Class Initialized
INFO - 2024-06-17 21:29:25 --> Language Class Initialized
INFO - 2024-06-17 21:29:25 --> Language Class Initialized
INFO - 2024-06-17 21:29:25 --> Config Class Initialized
INFO - 2024-06-17 21:29:25 --> Loader Class Initialized
INFO - 2024-06-17 21:29:25 --> Helper loaded: url_helper
INFO - 2024-06-17 21:29:25 --> Helper loaded: file_helper
INFO - 2024-06-17 21:29:25 --> Helper loaded: form_helper
INFO - 2024-06-17 21:29:25 --> Helper loaded: my_helper
INFO - 2024-06-17 21:29:25 --> Database Driver Class Initialized
INFO - 2024-06-17 21:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:29:25 --> Controller Class Initialized
INFO - 2024-06-17 21:29:25 --> Final output sent to browser
DEBUG - 2024-06-17 21:29:25 --> Total execution time: 0.0519
INFO - 2024-06-17 21:29:31 --> Config Class Initialized
INFO - 2024-06-17 21:29:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:29:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:29:31 --> Utf8 Class Initialized
INFO - 2024-06-17 21:29:31 --> URI Class Initialized
INFO - 2024-06-17 21:29:31 --> Router Class Initialized
INFO - 2024-06-17 21:29:31 --> Output Class Initialized
INFO - 2024-06-17 21:29:31 --> Security Class Initialized
DEBUG - 2024-06-17 21:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:29:31 --> Input Class Initialized
INFO - 2024-06-17 21:29:31 --> Language Class Initialized
INFO - 2024-06-17 21:29:31 --> Language Class Initialized
INFO - 2024-06-17 21:29:31 --> Config Class Initialized
INFO - 2024-06-17 21:29:31 --> Loader Class Initialized
INFO - 2024-06-17 21:29:31 --> Helper loaded: url_helper
INFO - 2024-06-17 21:29:31 --> Helper loaded: file_helper
INFO - 2024-06-17 21:29:31 --> Helper loaded: form_helper
INFO - 2024-06-17 21:29:31 --> Helper loaded: my_helper
INFO - 2024-06-17 21:29:31 --> Database Driver Class Initialized
INFO - 2024-06-17 21:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:29:31 --> Controller Class Initialized
INFO - 2024-06-17 21:29:31 --> Final output sent to browser
DEBUG - 2024-06-17 21:29:31 --> Total execution time: 0.0332
INFO - 2024-06-17 21:30:05 --> Config Class Initialized
INFO - 2024-06-17 21:30:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:05 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:05 --> URI Class Initialized
INFO - 2024-06-17 21:30:05 --> Router Class Initialized
INFO - 2024-06-17 21:30:05 --> Output Class Initialized
INFO - 2024-06-17 21:30:05 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:05 --> Input Class Initialized
INFO - 2024-06-17 21:30:05 --> Language Class Initialized
INFO - 2024-06-17 21:30:05 --> Language Class Initialized
INFO - 2024-06-17 21:30:05 --> Config Class Initialized
INFO - 2024-06-17 21:30:05 --> Loader Class Initialized
INFO - 2024-06-17 21:30:05 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:05 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:05 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:05 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:05 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:05 --> Controller Class Initialized
INFO - 2024-06-17 21:30:05 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:05 --> Total execution time: 0.0413
INFO - 2024-06-17 21:30:08 --> Config Class Initialized
INFO - 2024-06-17 21:30:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:08 --> URI Class Initialized
INFO - 2024-06-17 21:30:08 --> Router Class Initialized
INFO - 2024-06-17 21:30:08 --> Output Class Initialized
INFO - 2024-06-17 21:30:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:08 --> Input Class Initialized
INFO - 2024-06-17 21:30:08 --> Language Class Initialized
INFO - 2024-06-17 21:30:08 --> Language Class Initialized
INFO - 2024-06-17 21:30:08 --> Config Class Initialized
INFO - 2024-06-17 21:30:08 --> Loader Class Initialized
INFO - 2024-06-17 21:30:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:08 --> Controller Class Initialized
INFO - 2024-06-17 21:30:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:08 --> Total execution time: 0.0320
INFO - 2024-06-17 21:30:09 --> Config Class Initialized
INFO - 2024-06-17 21:30:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:09 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:09 --> URI Class Initialized
INFO - 2024-06-17 21:30:09 --> Router Class Initialized
INFO - 2024-06-17 21:30:09 --> Output Class Initialized
INFO - 2024-06-17 21:30:09 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:09 --> Input Class Initialized
INFO - 2024-06-17 21:30:09 --> Language Class Initialized
INFO - 2024-06-17 21:30:09 --> Language Class Initialized
INFO - 2024-06-17 21:30:09 --> Config Class Initialized
INFO - 2024-06-17 21:30:09 --> Loader Class Initialized
INFO - 2024-06-17 21:30:09 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:09 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:09 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:09 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:09 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:09 --> Controller Class Initialized
INFO - 2024-06-17 21:30:09 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:09 --> Total execution time: 0.0301
INFO - 2024-06-17 21:30:11 --> Config Class Initialized
INFO - 2024-06-17 21:30:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:11 --> URI Class Initialized
INFO - 2024-06-17 21:30:11 --> Router Class Initialized
INFO - 2024-06-17 21:30:11 --> Output Class Initialized
INFO - 2024-06-17 21:30:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:11 --> Input Class Initialized
INFO - 2024-06-17 21:30:11 --> Language Class Initialized
INFO - 2024-06-17 21:30:11 --> Language Class Initialized
INFO - 2024-06-17 21:30:11 --> Config Class Initialized
INFO - 2024-06-17 21:30:11 --> Loader Class Initialized
INFO - 2024-06-17 21:30:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:11 --> Controller Class Initialized
INFO - 2024-06-17 21:30:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:11 --> Total execution time: 0.0495
INFO - 2024-06-17 21:30:29 --> Config Class Initialized
INFO - 2024-06-17 21:30:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:29 --> URI Class Initialized
INFO - 2024-06-17 21:30:29 --> Router Class Initialized
INFO - 2024-06-17 21:30:29 --> Output Class Initialized
INFO - 2024-06-17 21:30:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:29 --> Input Class Initialized
INFO - 2024-06-17 21:30:29 --> Language Class Initialized
INFO - 2024-06-17 21:30:29 --> Language Class Initialized
INFO - 2024-06-17 21:30:29 --> Config Class Initialized
INFO - 2024-06-17 21:30:29 --> Loader Class Initialized
INFO - 2024-06-17 21:30:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:29 --> Controller Class Initialized
INFO - 2024-06-17 21:30:29 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:29 --> Total execution time: 0.1246
INFO - 2024-06-17 21:30:31 --> Config Class Initialized
INFO - 2024-06-17 21:30:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:31 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:31 --> URI Class Initialized
INFO - 2024-06-17 21:30:31 --> Router Class Initialized
INFO - 2024-06-17 21:30:31 --> Output Class Initialized
INFO - 2024-06-17 21:30:31 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:31 --> Input Class Initialized
INFO - 2024-06-17 21:30:31 --> Language Class Initialized
INFO - 2024-06-17 21:30:31 --> Language Class Initialized
INFO - 2024-06-17 21:30:31 --> Config Class Initialized
INFO - 2024-06-17 21:30:31 --> Loader Class Initialized
INFO - 2024-06-17 21:30:31 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:31 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:31 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:31 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:31 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:31 --> Controller Class Initialized
INFO - 2024-06-17 21:30:32 --> Config Class Initialized
INFO - 2024-06-17 21:30:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:32 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:32 --> URI Class Initialized
INFO - 2024-06-17 21:30:32 --> Router Class Initialized
INFO - 2024-06-17 21:30:32 --> Output Class Initialized
INFO - 2024-06-17 21:30:32 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:32 --> Input Class Initialized
INFO - 2024-06-17 21:30:32 --> Language Class Initialized
INFO - 2024-06-17 21:30:32 --> Language Class Initialized
INFO - 2024-06-17 21:30:32 --> Config Class Initialized
INFO - 2024-06-17 21:30:32 --> Loader Class Initialized
INFO - 2024-06-17 21:30:32 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:32 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:32 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:32 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:32 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:32 --> Controller Class Initialized
DEBUG - 2024-06-17 21:30:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 21:30:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:30:32 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:32 --> Total execution time: 0.0294
INFO - 2024-06-17 21:30:38 --> Config Class Initialized
INFO - 2024-06-17 21:30:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:38 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:38 --> URI Class Initialized
INFO - 2024-06-17 21:30:38 --> Router Class Initialized
INFO - 2024-06-17 21:30:38 --> Output Class Initialized
INFO - 2024-06-17 21:30:38 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:38 --> Input Class Initialized
INFO - 2024-06-17 21:30:38 --> Language Class Initialized
INFO - 2024-06-17 21:30:38 --> Language Class Initialized
INFO - 2024-06-17 21:30:38 --> Config Class Initialized
INFO - 2024-06-17 21:30:38 --> Loader Class Initialized
INFO - 2024-06-17 21:30:38 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:38 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:38 --> Controller Class Initialized
INFO - 2024-06-17 21:30:38 --> Helper loaded: cookie_helper
INFO - 2024-06-17 21:30:38 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:38 --> Total execution time: 0.0339
INFO - 2024-06-17 21:30:38 --> Config Class Initialized
INFO - 2024-06-17 21:30:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:38 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:38 --> URI Class Initialized
INFO - 2024-06-17 21:30:38 --> Router Class Initialized
INFO - 2024-06-17 21:30:38 --> Output Class Initialized
INFO - 2024-06-17 21:30:38 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:38 --> Input Class Initialized
INFO - 2024-06-17 21:30:38 --> Language Class Initialized
INFO - 2024-06-17 21:30:38 --> Language Class Initialized
INFO - 2024-06-17 21:30:38 --> Config Class Initialized
INFO - 2024-06-17 21:30:38 --> Loader Class Initialized
INFO - 2024-06-17 21:30:38 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:38 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:38 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:38 --> Controller Class Initialized
DEBUG - 2024-06-17 21:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 21:30:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:30:38 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:38 --> Total execution time: 0.0330
INFO - 2024-06-17 21:30:40 --> Config Class Initialized
INFO - 2024-06-17 21:30:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:40 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:40 --> URI Class Initialized
INFO - 2024-06-17 21:30:40 --> Router Class Initialized
INFO - 2024-06-17 21:30:40 --> Output Class Initialized
INFO - 2024-06-17 21:30:40 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:40 --> Input Class Initialized
INFO - 2024-06-17 21:30:40 --> Language Class Initialized
INFO - 2024-06-17 21:30:40 --> Language Class Initialized
INFO - 2024-06-17 21:30:40 --> Config Class Initialized
INFO - 2024-06-17 21:30:40 --> Loader Class Initialized
INFO - 2024-06-17 21:30:40 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:40 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:40 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:40 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:40 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:40 --> Controller Class Initialized
INFO - 2024-06-17 21:30:41 --> Config Class Initialized
INFO - 2024-06-17 21:30:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:41 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:41 --> URI Class Initialized
INFO - 2024-06-17 21:30:41 --> Router Class Initialized
INFO - 2024-06-17 21:30:41 --> Output Class Initialized
INFO - 2024-06-17 21:30:41 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:41 --> Input Class Initialized
INFO - 2024-06-17 21:30:41 --> Language Class Initialized
INFO - 2024-06-17 21:30:41 --> Language Class Initialized
INFO - 2024-06-17 21:30:41 --> Config Class Initialized
INFO - 2024-06-17 21:30:41 --> Loader Class Initialized
INFO - 2024-06-17 21:30:41 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:41 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:41 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:41 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:41 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:41 --> Controller Class Initialized
DEBUG - 2024-06-17 21:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 21:30:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:30:41 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:41 --> Total execution time: 0.0274
INFO - 2024-06-17 21:30:43 --> Config Class Initialized
INFO - 2024-06-17 21:30:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:43 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:43 --> URI Class Initialized
INFO - 2024-06-17 21:30:43 --> Router Class Initialized
INFO - 2024-06-17 21:30:43 --> Output Class Initialized
INFO - 2024-06-17 21:30:43 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:43 --> Input Class Initialized
INFO - 2024-06-17 21:30:43 --> Language Class Initialized
INFO - 2024-06-17 21:30:43 --> Language Class Initialized
INFO - 2024-06-17 21:30:43 --> Config Class Initialized
INFO - 2024-06-17 21:30:43 --> Loader Class Initialized
INFO - 2024-06-17 21:30:43 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:43 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:43 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:43 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:43 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:43 --> Controller Class Initialized
DEBUG - 2024-06-17 21:30:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 21:30:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:30:43 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:43 --> Total execution time: 0.0383
INFO - 2024-06-17 21:30:45 --> Config Class Initialized
INFO - 2024-06-17 21:30:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:45 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:45 --> URI Class Initialized
INFO - 2024-06-17 21:30:45 --> Router Class Initialized
INFO - 2024-06-17 21:30:45 --> Output Class Initialized
INFO - 2024-06-17 21:30:45 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:45 --> Input Class Initialized
INFO - 2024-06-17 21:30:45 --> Language Class Initialized
INFO - 2024-06-17 21:30:45 --> Language Class Initialized
INFO - 2024-06-17 21:30:45 --> Config Class Initialized
INFO - 2024-06-17 21:30:45 --> Loader Class Initialized
INFO - 2024-06-17 21:30:45 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:45 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:45 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:45 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:45 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:45 --> Controller Class Initialized
DEBUG - 2024-06-17 21:30:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-06-17 21:30:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:30:45 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:45 --> Total execution time: 0.0309
INFO - 2024-06-17 21:30:46 --> Config Class Initialized
INFO - 2024-06-17 21:30:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:46 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:46 --> URI Class Initialized
INFO - 2024-06-17 21:30:46 --> Router Class Initialized
INFO - 2024-06-17 21:30:46 --> Output Class Initialized
INFO - 2024-06-17 21:30:46 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:46 --> Input Class Initialized
INFO - 2024-06-17 21:30:46 --> Language Class Initialized
INFO - 2024-06-17 21:30:46 --> Language Class Initialized
INFO - 2024-06-17 21:30:46 --> Config Class Initialized
INFO - 2024-06-17 21:30:46 --> Loader Class Initialized
INFO - 2024-06-17 21:30:46 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:46 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:46 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:46 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:46 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:46 --> Controller Class Initialized
INFO - 2024-06-17 21:30:48 --> Config Class Initialized
INFO - 2024-06-17 21:30:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:30:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:30:48 --> Utf8 Class Initialized
INFO - 2024-06-17 21:30:48 --> URI Class Initialized
INFO - 2024-06-17 21:30:48 --> Router Class Initialized
INFO - 2024-06-17 21:30:48 --> Output Class Initialized
INFO - 2024-06-17 21:30:48 --> Security Class Initialized
DEBUG - 2024-06-17 21:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:30:48 --> Input Class Initialized
INFO - 2024-06-17 21:30:48 --> Language Class Initialized
INFO - 2024-06-17 21:30:48 --> Language Class Initialized
INFO - 2024-06-17 21:30:48 --> Config Class Initialized
INFO - 2024-06-17 21:30:48 --> Loader Class Initialized
INFO - 2024-06-17 21:30:48 --> Helper loaded: url_helper
INFO - 2024-06-17 21:30:48 --> Helper loaded: file_helper
INFO - 2024-06-17 21:30:48 --> Helper loaded: form_helper
INFO - 2024-06-17 21:30:48 --> Helper loaded: my_helper
INFO - 2024-06-17 21:30:48 --> Database Driver Class Initialized
INFO - 2024-06-17 21:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:30:48 --> Controller Class Initialized
INFO - 2024-06-17 21:30:48 --> Final output sent to browser
DEBUG - 2024-06-17 21:30:48 --> Total execution time: 0.0321
INFO - 2024-06-17 21:31:50 --> Config Class Initialized
INFO - 2024-06-17 21:31:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:31:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:31:50 --> Utf8 Class Initialized
INFO - 2024-06-17 21:31:50 --> URI Class Initialized
INFO - 2024-06-17 21:31:50 --> Router Class Initialized
INFO - 2024-06-17 21:31:50 --> Output Class Initialized
INFO - 2024-06-17 21:31:50 --> Security Class Initialized
DEBUG - 2024-06-17 21:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:31:50 --> Input Class Initialized
INFO - 2024-06-17 21:31:50 --> Language Class Initialized
INFO - 2024-06-17 21:31:50 --> Language Class Initialized
INFO - 2024-06-17 21:31:50 --> Config Class Initialized
INFO - 2024-06-17 21:31:50 --> Loader Class Initialized
INFO - 2024-06-17 21:31:50 --> Helper loaded: url_helper
INFO - 2024-06-17 21:31:50 --> Helper loaded: file_helper
INFO - 2024-06-17 21:31:50 --> Helper loaded: form_helper
INFO - 2024-06-17 21:31:50 --> Helper loaded: my_helper
INFO - 2024-06-17 21:31:50 --> Database Driver Class Initialized
INFO - 2024-06-17 21:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:31:50 --> Controller Class Initialized
INFO - 2024-06-17 21:31:50 --> Final output sent to browser
DEBUG - 2024-06-17 21:31:50 --> Total execution time: 0.0385
INFO - 2024-06-17 21:31:54 --> Config Class Initialized
INFO - 2024-06-17 21:31:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:31:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:31:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:31:54 --> URI Class Initialized
INFO - 2024-06-17 21:31:54 --> Router Class Initialized
INFO - 2024-06-17 21:31:54 --> Output Class Initialized
INFO - 2024-06-17 21:31:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:31:54 --> Input Class Initialized
INFO - 2024-06-17 21:31:54 --> Language Class Initialized
INFO - 2024-06-17 21:31:54 --> Language Class Initialized
INFO - 2024-06-17 21:31:54 --> Config Class Initialized
INFO - 2024-06-17 21:31:54 --> Loader Class Initialized
INFO - 2024-06-17 21:31:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:31:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:31:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:31:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:31:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:31:54 --> Controller Class Initialized
INFO - 2024-06-17 21:31:54 --> Final output sent to browser
DEBUG - 2024-06-17 21:31:54 --> Total execution time: 0.0277
INFO - 2024-06-17 21:32:07 --> Config Class Initialized
INFO - 2024-06-17 21:32:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:07 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:07 --> URI Class Initialized
INFO - 2024-06-17 21:32:07 --> Router Class Initialized
INFO - 2024-06-17 21:32:07 --> Output Class Initialized
INFO - 2024-06-17 21:32:07 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:07 --> Input Class Initialized
INFO - 2024-06-17 21:32:07 --> Language Class Initialized
INFO - 2024-06-17 21:32:07 --> Language Class Initialized
INFO - 2024-06-17 21:32:07 --> Config Class Initialized
INFO - 2024-06-17 21:32:07 --> Loader Class Initialized
INFO - 2024-06-17 21:32:07 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:07 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:07 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:07 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:07 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:07 --> Controller Class Initialized
INFO - 2024-06-17 21:32:07 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:07 --> Total execution time: 0.0406
INFO - 2024-06-17 21:32:11 --> Config Class Initialized
INFO - 2024-06-17 21:32:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:11 --> URI Class Initialized
INFO - 2024-06-17 21:32:11 --> Router Class Initialized
INFO - 2024-06-17 21:32:11 --> Output Class Initialized
INFO - 2024-06-17 21:32:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:11 --> Input Class Initialized
INFO - 2024-06-17 21:32:11 --> Language Class Initialized
INFO - 2024-06-17 21:32:11 --> Language Class Initialized
INFO - 2024-06-17 21:32:11 --> Config Class Initialized
INFO - 2024-06-17 21:32:11 --> Loader Class Initialized
INFO - 2024-06-17 21:32:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:11 --> Controller Class Initialized
INFO - 2024-06-17 21:32:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:11 --> Total execution time: 0.0358
INFO - 2024-06-17 21:32:21 --> Config Class Initialized
INFO - 2024-06-17 21:32:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:21 --> URI Class Initialized
INFO - 2024-06-17 21:32:21 --> Router Class Initialized
INFO - 2024-06-17 21:32:21 --> Output Class Initialized
INFO - 2024-06-17 21:32:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:21 --> Input Class Initialized
INFO - 2024-06-17 21:32:21 --> Language Class Initialized
INFO - 2024-06-17 21:32:21 --> Language Class Initialized
INFO - 2024-06-17 21:32:21 --> Config Class Initialized
INFO - 2024-06-17 21:32:21 --> Loader Class Initialized
INFO - 2024-06-17 21:32:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:21 --> Controller Class Initialized
INFO - 2024-06-17 21:32:21 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:21 --> Total execution time: 0.0406
INFO - 2024-06-17 21:32:25 --> Config Class Initialized
INFO - 2024-06-17 21:32:25 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:25 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:25 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:25 --> URI Class Initialized
INFO - 2024-06-17 21:32:25 --> Router Class Initialized
INFO - 2024-06-17 21:32:25 --> Output Class Initialized
INFO - 2024-06-17 21:32:25 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:25 --> Input Class Initialized
INFO - 2024-06-17 21:32:25 --> Language Class Initialized
INFO - 2024-06-17 21:32:25 --> Language Class Initialized
INFO - 2024-06-17 21:32:25 --> Config Class Initialized
INFO - 2024-06-17 21:32:25 --> Loader Class Initialized
INFO - 2024-06-17 21:32:25 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:25 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:25 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:25 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:25 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:25 --> Controller Class Initialized
INFO - 2024-06-17 21:32:25 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:25 --> Total execution time: 0.0298
INFO - 2024-06-17 21:32:35 --> Config Class Initialized
INFO - 2024-06-17 21:32:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:35 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:35 --> URI Class Initialized
INFO - 2024-06-17 21:32:35 --> Router Class Initialized
INFO - 2024-06-17 21:32:35 --> Output Class Initialized
INFO - 2024-06-17 21:32:35 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:35 --> Input Class Initialized
INFO - 2024-06-17 21:32:35 --> Language Class Initialized
INFO - 2024-06-17 21:32:35 --> Language Class Initialized
INFO - 2024-06-17 21:32:35 --> Config Class Initialized
INFO - 2024-06-17 21:32:35 --> Loader Class Initialized
INFO - 2024-06-17 21:32:35 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:35 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:35 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:35 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:35 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:35 --> Controller Class Initialized
INFO - 2024-06-17 21:32:35 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:35 --> Total execution time: 0.0407
INFO - 2024-06-17 21:32:39 --> Config Class Initialized
INFO - 2024-06-17 21:32:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:39 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:39 --> URI Class Initialized
INFO - 2024-06-17 21:32:39 --> Router Class Initialized
INFO - 2024-06-17 21:32:39 --> Output Class Initialized
INFO - 2024-06-17 21:32:39 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:39 --> Input Class Initialized
INFO - 2024-06-17 21:32:39 --> Language Class Initialized
INFO - 2024-06-17 21:32:39 --> Language Class Initialized
INFO - 2024-06-17 21:32:39 --> Config Class Initialized
INFO - 2024-06-17 21:32:39 --> Loader Class Initialized
INFO - 2024-06-17 21:32:39 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:39 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:39 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:39 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:39 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:39 --> Controller Class Initialized
INFO - 2024-06-17 21:32:39 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:39 --> Total execution time: 0.0297
INFO - 2024-06-17 21:32:51 --> Config Class Initialized
INFO - 2024-06-17 21:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:51 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:51 --> URI Class Initialized
INFO - 2024-06-17 21:32:51 --> Router Class Initialized
INFO - 2024-06-17 21:32:51 --> Output Class Initialized
INFO - 2024-06-17 21:32:51 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:51 --> Input Class Initialized
INFO - 2024-06-17 21:32:51 --> Language Class Initialized
INFO - 2024-06-17 21:32:51 --> Language Class Initialized
INFO - 2024-06-17 21:32:51 --> Config Class Initialized
INFO - 2024-06-17 21:32:51 --> Loader Class Initialized
INFO - 2024-06-17 21:32:51 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:51 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:51 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:51 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:51 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:51 --> Controller Class Initialized
INFO - 2024-06-17 21:32:51 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:51 --> Total execution time: 0.1785
INFO - 2024-06-17 21:32:53 --> Config Class Initialized
INFO - 2024-06-17 21:32:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:32:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:32:53 --> Utf8 Class Initialized
INFO - 2024-06-17 21:32:53 --> URI Class Initialized
INFO - 2024-06-17 21:32:53 --> Router Class Initialized
INFO - 2024-06-17 21:32:53 --> Output Class Initialized
INFO - 2024-06-17 21:32:53 --> Security Class Initialized
DEBUG - 2024-06-17 21:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:32:53 --> Input Class Initialized
INFO - 2024-06-17 21:32:53 --> Language Class Initialized
INFO - 2024-06-17 21:32:53 --> Language Class Initialized
INFO - 2024-06-17 21:32:53 --> Config Class Initialized
INFO - 2024-06-17 21:32:53 --> Loader Class Initialized
INFO - 2024-06-17 21:32:53 --> Helper loaded: url_helper
INFO - 2024-06-17 21:32:53 --> Helper loaded: file_helper
INFO - 2024-06-17 21:32:53 --> Helper loaded: form_helper
INFO - 2024-06-17 21:32:53 --> Helper loaded: my_helper
INFO - 2024-06-17 21:32:53 --> Database Driver Class Initialized
INFO - 2024-06-17 21:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:32:53 --> Controller Class Initialized
INFO - 2024-06-17 21:32:53 --> Final output sent to browser
DEBUG - 2024-06-17 21:32:53 --> Total execution time: 0.0523
INFO - 2024-06-17 21:33:13 --> Config Class Initialized
INFO - 2024-06-17 21:33:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:13 --> URI Class Initialized
INFO - 2024-06-17 21:33:13 --> Router Class Initialized
INFO - 2024-06-17 21:33:13 --> Output Class Initialized
INFO - 2024-06-17 21:33:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:13 --> Input Class Initialized
INFO - 2024-06-17 21:33:13 --> Language Class Initialized
INFO - 2024-06-17 21:33:13 --> Language Class Initialized
INFO - 2024-06-17 21:33:13 --> Config Class Initialized
INFO - 2024-06-17 21:33:13 --> Loader Class Initialized
INFO - 2024-06-17 21:33:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:13 --> Controller Class Initialized
INFO - 2024-06-17 21:33:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:13 --> Total execution time: 0.0431
INFO - 2024-06-17 21:33:18 --> Config Class Initialized
INFO - 2024-06-17 21:33:18 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:18 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:18 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:18 --> URI Class Initialized
INFO - 2024-06-17 21:33:18 --> Router Class Initialized
INFO - 2024-06-17 21:33:18 --> Output Class Initialized
INFO - 2024-06-17 21:33:18 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:18 --> Input Class Initialized
INFO - 2024-06-17 21:33:18 --> Language Class Initialized
INFO - 2024-06-17 21:33:18 --> Language Class Initialized
INFO - 2024-06-17 21:33:18 --> Config Class Initialized
INFO - 2024-06-17 21:33:18 --> Loader Class Initialized
INFO - 2024-06-17 21:33:18 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:18 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:18 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:18 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:18 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:18 --> Controller Class Initialized
DEBUG - 2024-06-17 21:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 21:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:33:18 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:18 --> Total execution time: 0.0286
INFO - 2024-06-17 21:33:20 --> Config Class Initialized
INFO - 2024-06-17 21:33:20 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:20 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:20 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:20 --> URI Class Initialized
INFO - 2024-06-17 21:33:20 --> Router Class Initialized
INFO - 2024-06-17 21:33:20 --> Output Class Initialized
INFO - 2024-06-17 21:33:20 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:20 --> Input Class Initialized
INFO - 2024-06-17 21:33:20 --> Language Class Initialized
INFO - 2024-06-17 21:33:20 --> Language Class Initialized
INFO - 2024-06-17 21:33:20 --> Config Class Initialized
INFO - 2024-06-17 21:33:20 --> Loader Class Initialized
INFO - 2024-06-17 21:33:20 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:20 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:20 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:20 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:20 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:20 --> Controller Class Initialized
DEBUG - 2024-06-17 21:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-06-17 21:33:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:33:20 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:20 --> Total execution time: 0.0281
INFO - 2024-06-17 21:33:21 --> Config Class Initialized
INFO - 2024-06-17 21:33:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:21 --> URI Class Initialized
INFO - 2024-06-17 21:33:21 --> Router Class Initialized
INFO - 2024-06-17 21:33:21 --> Output Class Initialized
INFO - 2024-06-17 21:33:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:21 --> Input Class Initialized
INFO - 2024-06-17 21:33:21 --> Language Class Initialized
INFO - 2024-06-17 21:33:21 --> Language Class Initialized
INFO - 2024-06-17 21:33:21 --> Config Class Initialized
INFO - 2024-06-17 21:33:21 --> Loader Class Initialized
INFO - 2024-06-17 21:33:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:21 --> Controller Class Initialized
INFO - 2024-06-17 21:33:22 --> Config Class Initialized
INFO - 2024-06-17 21:33:22 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:22 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:22 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:22 --> URI Class Initialized
INFO - 2024-06-17 21:33:22 --> Router Class Initialized
INFO - 2024-06-17 21:33:22 --> Output Class Initialized
INFO - 2024-06-17 21:33:22 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:22 --> Input Class Initialized
INFO - 2024-06-17 21:33:22 --> Language Class Initialized
INFO - 2024-06-17 21:33:22 --> Language Class Initialized
INFO - 2024-06-17 21:33:22 --> Config Class Initialized
INFO - 2024-06-17 21:33:22 --> Loader Class Initialized
INFO - 2024-06-17 21:33:22 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:22 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:22 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:22 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:22 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:22 --> Controller Class Initialized
INFO - 2024-06-17 21:33:22 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:22 --> Total execution time: 0.0289
INFO - 2024-06-17 21:33:24 --> Config Class Initialized
INFO - 2024-06-17 21:33:24 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:24 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:24 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:24 --> URI Class Initialized
INFO - 2024-06-17 21:33:24 --> Router Class Initialized
INFO - 2024-06-17 21:33:24 --> Output Class Initialized
INFO - 2024-06-17 21:33:24 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:24 --> Input Class Initialized
INFO - 2024-06-17 21:33:24 --> Language Class Initialized
INFO - 2024-06-17 21:33:24 --> Language Class Initialized
INFO - 2024-06-17 21:33:24 --> Config Class Initialized
INFO - 2024-06-17 21:33:24 --> Loader Class Initialized
INFO - 2024-06-17 21:33:24 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:24 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:24 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:24 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:24 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:24 --> Controller Class Initialized
INFO - 2024-06-17 21:33:24 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:24 --> Total execution time: 0.0282
INFO - 2024-06-17 21:33:32 --> Config Class Initialized
INFO - 2024-06-17 21:33:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:32 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:32 --> URI Class Initialized
INFO - 2024-06-17 21:33:32 --> Router Class Initialized
INFO - 2024-06-17 21:33:32 --> Output Class Initialized
INFO - 2024-06-17 21:33:32 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:32 --> Input Class Initialized
INFO - 2024-06-17 21:33:32 --> Language Class Initialized
INFO - 2024-06-17 21:33:32 --> Language Class Initialized
INFO - 2024-06-17 21:33:32 --> Config Class Initialized
INFO - 2024-06-17 21:33:32 --> Loader Class Initialized
INFO - 2024-06-17 21:33:32 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:32 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:32 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:32 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:32 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:32 --> Controller Class Initialized
INFO - 2024-06-17 21:33:32 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:32 --> Total execution time: 0.0609
INFO - 2024-06-17 21:33:35 --> Config Class Initialized
INFO - 2024-06-17 21:33:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:35 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:35 --> URI Class Initialized
INFO - 2024-06-17 21:33:35 --> Router Class Initialized
INFO - 2024-06-17 21:33:35 --> Output Class Initialized
INFO - 2024-06-17 21:33:35 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:35 --> Input Class Initialized
INFO - 2024-06-17 21:33:35 --> Language Class Initialized
INFO - 2024-06-17 21:33:35 --> Language Class Initialized
INFO - 2024-06-17 21:33:35 --> Config Class Initialized
INFO - 2024-06-17 21:33:35 --> Loader Class Initialized
INFO - 2024-06-17 21:33:35 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:35 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:35 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:35 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:35 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:35 --> Controller Class Initialized
INFO - 2024-06-17 21:33:35 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:35 --> Total execution time: 0.0322
INFO - 2024-06-17 21:33:39 --> Config Class Initialized
INFO - 2024-06-17 21:33:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:39 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:39 --> URI Class Initialized
INFO - 2024-06-17 21:33:39 --> Router Class Initialized
INFO - 2024-06-17 21:33:39 --> Output Class Initialized
INFO - 2024-06-17 21:33:39 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:39 --> Input Class Initialized
INFO - 2024-06-17 21:33:39 --> Language Class Initialized
INFO - 2024-06-17 21:33:39 --> Language Class Initialized
INFO - 2024-06-17 21:33:39 --> Config Class Initialized
INFO - 2024-06-17 21:33:39 --> Loader Class Initialized
INFO - 2024-06-17 21:33:39 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:39 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:39 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:39 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:39 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:39 --> Controller Class Initialized
INFO - 2024-06-17 21:33:39 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:39 --> Total execution time: 0.0292
INFO - 2024-06-17 21:33:42 --> Config Class Initialized
INFO - 2024-06-17 21:33:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:42 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:42 --> URI Class Initialized
INFO - 2024-06-17 21:33:42 --> Router Class Initialized
INFO - 2024-06-17 21:33:42 --> Output Class Initialized
INFO - 2024-06-17 21:33:42 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:42 --> Input Class Initialized
INFO - 2024-06-17 21:33:42 --> Language Class Initialized
INFO - 2024-06-17 21:33:42 --> Language Class Initialized
INFO - 2024-06-17 21:33:42 --> Config Class Initialized
INFO - 2024-06-17 21:33:42 --> Loader Class Initialized
INFO - 2024-06-17 21:33:42 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:42 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:42 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:42 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:42 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:42 --> Controller Class Initialized
INFO - 2024-06-17 21:33:42 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:42 --> Total execution time: 0.0263
INFO - 2024-06-17 21:33:45 --> Config Class Initialized
INFO - 2024-06-17 21:33:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:45 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:45 --> URI Class Initialized
INFO - 2024-06-17 21:33:45 --> Router Class Initialized
INFO - 2024-06-17 21:33:45 --> Output Class Initialized
INFO - 2024-06-17 21:33:45 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:45 --> Input Class Initialized
INFO - 2024-06-17 21:33:45 --> Language Class Initialized
INFO - 2024-06-17 21:33:45 --> Language Class Initialized
INFO - 2024-06-17 21:33:45 --> Config Class Initialized
INFO - 2024-06-17 21:33:45 --> Loader Class Initialized
INFO - 2024-06-17 21:33:45 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:45 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:45 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:45 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:45 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:45 --> Controller Class Initialized
DEBUG - 2024-06-17 21:33:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 21:33:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:33:45 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:45 --> Total execution time: 0.0268
INFO - 2024-06-17 21:33:47 --> Config Class Initialized
INFO - 2024-06-17 21:33:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:47 --> URI Class Initialized
INFO - 2024-06-17 21:33:47 --> Router Class Initialized
INFO - 2024-06-17 21:33:47 --> Output Class Initialized
INFO - 2024-06-17 21:33:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:47 --> Input Class Initialized
INFO - 2024-06-17 21:33:47 --> Language Class Initialized
INFO - 2024-06-17 21:33:47 --> Language Class Initialized
INFO - 2024-06-17 21:33:47 --> Config Class Initialized
INFO - 2024-06-17 21:33:47 --> Loader Class Initialized
INFO - 2024-06-17 21:33:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:47 --> Controller Class Initialized
DEBUG - 2024-06-17 21:33:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-06-17 21:33:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:33:47 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:47 --> Total execution time: 0.0323
INFO - 2024-06-17 21:33:47 --> Config Class Initialized
INFO - 2024-06-17 21:33:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:47 --> URI Class Initialized
INFO - 2024-06-17 21:33:47 --> Router Class Initialized
INFO - 2024-06-17 21:33:47 --> Output Class Initialized
INFO - 2024-06-17 21:33:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:47 --> Input Class Initialized
INFO - 2024-06-17 21:33:47 --> Language Class Initialized
INFO - 2024-06-17 21:33:47 --> Language Class Initialized
INFO - 2024-06-17 21:33:47 --> Config Class Initialized
INFO - 2024-06-17 21:33:47 --> Loader Class Initialized
INFO - 2024-06-17 21:33:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:47 --> Controller Class Initialized
INFO - 2024-06-17 21:33:49 --> Config Class Initialized
INFO - 2024-06-17 21:33:49 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:33:49 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:33:49 --> Utf8 Class Initialized
INFO - 2024-06-17 21:33:49 --> URI Class Initialized
INFO - 2024-06-17 21:33:49 --> Router Class Initialized
INFO - 2024-06-17 21:33:49 --> Output Class Initialized
INFO - 2024-06-17 21:33:49 --> Security Class Initialized
DEBUG - 2024-06-17 21:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:33:49 --> Input Class Initialized
INFO - 2024-06-17 21:33:49 --> Language Class Initialized
INFO - 2024-06-17 21:33:49 --> Language Class Initialized
INFO - 2024-06-17 21:33:49 --> Config Class Initialized
INFO - 2024-06-17 21:33:49 --> Loader Class Initialized
INFO - 2024-06-17 21:33:49 --> Helper loaded: url_helper
INFO - 2024-06-17 21:33:49 --> Helper loaded: file_helper
INFO - 2024-06-17 21:33:49 --> Helper loaded: form_helper
INFO - 2024-06-17 21:33:49 --> Helper loaded: my_helper
INFO - 2024-06-17 21:33:49 --> Database Driver Class Initialized
INFO - 2024-06-17 21:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:33:49 --> Controller Class Initialized
INFO - 2024-06-17 21:33:49 --> Final output sent to browser
DEBUG - 2024-06-17 21:33:49 --> Total execution time: 0.0385
INFO - 2024-06-17 21:34:13 --> Config Class Initialized
INFO - 2024-06-17 21:34:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:34:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:34:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:34:13 --> URI Class Initialized
INFO - 2024-06-17 21:34:13 --> Router Class Initialized
INFO - 2024-06-17 21:34:13 --> Output Class Initialized
INFO - 2024-06-17 21:34:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:34:13 --> Input Class Initialized
INFO - 2024-06-17 21:34:13 --> Language Class Initialized
INFO - 2024-06-17 21:34:13 --> Language Class Initialized
INFO - 2024-06-17 21:34:13 --> Config Class Initialized
INFO - 2024-06-17 21:34:13 --> Loader Class Initialized
INFO - 2024-06-17 21:34:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:34:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:34:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:34:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:34:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:34:13 --> Controller Class Initialized
INFO - 2024-06-17 21:34:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:34:13 --> Total execution time: 0.2973
INFO - 2024-06-17 21:34:21 --> Config Class Initialized
INFO - 2024-06-17 21:34:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:34:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:34:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:34:21 --> URI Class Initialized
INFO - 2024-06-17 21:34:21 --> Router Class Initialized
INFO - 2024-06-17 21:34:21 --> Output Class Initialized
INFO - 2024-06-17 21:34:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:34:21 --> Input Class Initialized
INFO - 2024-06-17 21:34:21 --> Language Class Initialized
INFO - 2024-06-17 21:34:21 --> Language Class Initialized
INFO - 2024-06-17 21:34:21 --> Config Class Initialized
INFO - 2024-06-17 21:34:21 --> Loader Class Initialized
INFO - 2024-06-17 21:34:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:34:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:34:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:34:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:34:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:34:21 --> Controller Class Initialized
INFO - 2024-06-17 21:34:21 --> Final output sent to browser
DEBUG - 2024-06-17 21:34:21 --> Total execution time: 0.0295
INFO - 2024-06-17 21:34:53 --> Config Class Initialized
INFO - 2024-06-17 21:34:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:34:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:34:53 --> Utf8 Class Initialized
INFO - 2024-06-17 21:34:53 --> URI Class Initialized
INFO - 2024-06-17 21:34:53 --> Router Class Initialized
INFO - 2024-06-17 21:34:53 --> Output Class Initialized
INFO - 2024-06-17 21:34:53 --> Security Class Initialized
DEBUG - 2024-06-17 21:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:34:53 --> Input Class Initialized
INFO - 2024-06-17 21:34:53 --> Language Class Initialized
INFO - 2024-06-17 21:34:53 --> Language Class Initialized
INFO - 2024-06-17 21:34:53 --> Config Class Initialized
INFO - 2024-06-17 21:34:53 --> Loader Class Initialized
INFO - 2024-06-17 21:34:53 --> Helper loaded: url_helper
INFO - 2024-06-17 21:34:53 --> Helper loaded: file_helper
INFO - 2024-06-17 21:34:53 --> Helper loaded: form_helper
INFO - 2024-06-17 21:34:53 --> Helper loaded: my_helper
INFO - 2024-06-17 21:34:53 --> Database Driver Class Initialized
INFO - 2024-06-17 21:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:34:53 --> Controller Class Initialized
INFO - 2024-06-17 21:34:53 --> Final output sent to browser
DEBUG - 2024-06-17 21:34:53 --> Total execution time: 0.0560
INFO - 2024-06-17 21:34:56 --> Config Class Initialized
INFO - 2024-06-17 21:34:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:34:56 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:34:56 --> Utf8 Class Initialized
INFO - 2024-06-17 21:34:56 --> URI Class Initialized
INFO - 2024-06-17 21:34:56 --> Router Class Initialized
INFO - 2024-06-17 21:34:56 --> Output Class Initialized
INFO - 2024-06-17 21:34:56 --> Security Class Initialized
DEBUG - 2024-06-17 21:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:34:56 --> Input Class Initialized
INFO - 2024-06-17 21:34:56 --> Language Class Initialized
INFO - 2024-06-17 21:34:56 --> Language Class Initialized
INFO - 2024-06-17 21:34:56 --> Config Class Initialized
INFO - 2024-06-17 21:34:56 --> Loader Class Initialized
INFO - 2024-06-17 21:34:56 --> Helper loaded: url_helper
INFO - 2024-06-17 21:34:56 --> Helper loaded: file_helper
INFO - 2024-06-17 21:34:56 --> Helper loaded: form_helper
INFO - 2024-06-17 21:34:56 --> Helper loaded: my_helper
INFO - 2024-06-17 21:34:56 --> Database Driver Class Initialized
INFO - 2024-06-17 21:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:34:56 --> Controller Class Initialized
INFO - 2024-06-17 21:34:56 --> Final output sent to browser
DEBUG - 2024-06-17 21:34:56 --> Total execution time: 0.0280
INFO - 2024-06-17 21:35:26 --> Config Class Initialized
INFO - 2024-06-17 21:35:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:35:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:35:26 --> Utf8 Class Initialized
INFO - 2024-06-17 21:35:26 --> URI Class Initialized
INFO - 2024-06-17 21:35:26 --> Router Class Initialized
INFO - 2024-06-17 21:35:26 --> Output Class Initialized
INFO - 2024-06-17 21:35:26 --> Security Class Initialized
DEBUG - 2024-06-17 21:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:35:26 --> Input Class Initialized
INFO - 2024-06-17 21:35:26 --> Language Class Initialized
INFO - 2024-06-17 21:35:26 --> Language Class Initialized
INFO - 2024-06-17 21:35:26 --> Config Class Initialized
INFO - 2024-06-17 21:35:26 --> Loader Class Initialized
INFO - 2024-06-17 21:35:26 --> Helper loaded: url_helper
INFO - 2024-06-17 21:35:26 --> Helper loaded: file_helper
INFO - 2024-06-17 21:35:26 --> Helper loaded: form_helper
INFO - 2024-06-17 21:35:26 --> Helper loaded: my_helper
INFO - 2024-06-17 21:35:26 --> Database Driver Class Initialized
INFO - 2024-06-17 21:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:35:26 --> Controller Class Initialized
INFO - 2024-06-17 21:35:26 --> Final output sent to browser
DEBUG - 2024-06-17 21:35:26 --> Total execution time: 0.3030
INFO - 2024-06-17 21:35:30 --> Config Class Initialized
INFO - 2024-06-17 21:35:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:35:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:35:30 --> Utf8 Class Initialized
INFO - 2024-06-17 21:35:30 --> URI Class Initialized
INFO - 2024-06-17 21:35:30 --> Router Class Initialized
INFO - 2024-06-17 21:35:30 --> Output Class Initialized
INFO - 2024-06-17 21:35:30 --> Security Class Initialized
DEBUG - 2024-06-17 21:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:35:30 --> Input Class Initialized
INFO - 2024-06-17 21:35:30 --> Language Class Initialized
INFO - 2024-06-17 21:35:30 --> Language Class Initialized
INFO - 2024-06-17 21:35:30 --> Config Class Initialized
INFO - 2024-06-17 21:35:30 --> Loader Class Initialized
INFO - 2024-06-17 21:35:30 --> Helper loaded: url_helper
INFO - 2024-06-17 21:35:30 --> Helper loaded: file_helper
INFO - 2024-06-17 21:35:30 --> Helper loaded: form_helper
INFO - 2024-06-17 21:35:30 --> Helper loaded: my_helper
INFO - 2024-06-17 21:35:30 --> Database Driver Class Initialized
INFO - 2024-06-17 21:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:35:30 --> Controller Class Initialized
INFO - 2024-06-17 21:35:30 --> Final output sent to browser
DEBUG - 2024-06-17 21:35:30 --> Total execution time: 0.0386
INFO - 2024-06-17 21:36:10 --> Config Class Initialized
INFO - 2024-06-17 21:36:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:10 --> URI Class Initialized
INFO - 2024-06-17 21:36:10 --> Router Class Initialized
INFO - 2024-06-17 21:36:10 --> Output Class Initialized
INFO - 2024-06-17 21:36:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:10 --> Input Class Initialized
INFO - 2024-06-17 21:36:10 --> Language Class Initialized
INFO - 2024-06-17 21:36:10 --> Language Class Initialized
INFO - 2024-06-17 21:36:10 --> Config Class Initialized
INFO - 2024-06-17 21:36:10 --> Loader Class Initialized
INFO - 2024-06-17 21:36:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:10 --> Controller Class Initialized
INFO - 2024-06-17 21:36:10 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:10 --> Total execution time: 0.0531
INFO - 2024-06-17 21:36:13 --> Config Class Initialized
INFO - 2024-06-17 21:36:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:13 --> URI Class Initialized
INFO - 2024-06-17 21:36:13 --> Router Class Initialized
INFO - 2024-06-17 21:36:13 --> Output Class Initialized
INFO - 2024-06-17 21:36:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:13 --> Input Class Initialized
INFO - 2024-06-17 21:36:13 --> Language Class Initialized
INFO - 2024-06-17 21:36:13 --> Language Class Initialized
INFO - 2024-06-17 21:36:13 --> Config Class Initialized
INFO - 2024-06-17 21:36:13 --> Loader Class Initialized
INFO - 2024-06-17 21:36:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:13 --> Controller Class Initialized
INFO - 2024-06-17 21:36:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:13 --> Total execution time: 0.0307
INFO - 2024-06-17 21:36:22 --> Config Class Initialized
INFO - 2024-06-17 21:36:22 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:22 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:22 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:22 --> URI Class Initialized
INFO - 2024-06-17 21:36:22 --> Router Class Initialized
INFO - 2024-06-17 21:36:22 --> Output Class Initialized
INFO - 2024-06-17 21:36:22 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:22 --> Input Class Initialized
INFO - 2024-06-17 21:36:22 --> Language Class Initialized
INFO - 2024-06-17 21:36:22 --> Language Class Initialized
INFO - 2024-06-17 21:36:22 --> Config Class Initialized
INFO - 2024-06-17 21:36:22 --> Loader Class Initialized
INFO - 2024-06-17 21:36:22 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:22 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:22 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:22 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:22 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:22 --> Controller Class Initialized
INFO - 2024-06-17 21:36:22 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:22 --> Total execution time: 0.0362
INFO - 2024-06-17 21:36:24 --> Config Class Initialized
INFO - 2024-06-17 21:36:24 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:24 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:24 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:24 --> URI Class Initialized
INFO - 2024-06-17 21:36:24 --> Router Class Initialized
INFO - 2024-06-17 21:36:24 --> Output Class Initialized
INFO - 2024-06-17 21:36:24 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:24 --> Input Class Initialized
INFO - 2024-06-17 21:36:24 --> Language Class Initialized
INFO - 2024-06-17 21:36:24 --> Language Class Initialized
INFO - 2024-06-17 21:36:24 --> Config Class Initialized
INFO - 2024-06-17 21:36:24 --> Loader Class Initialized
INFO - 2024-06-17 21:36:24 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:24 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:24 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:24 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:24 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:24 --> Controller Class Initialized
INFO - 2024-06-17 21:36:24 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:24 --> Total execution time: 0.0263
INFO - 2024-06-17 21:36:25 --> Config Class Initialized
INFO - 2024-06-17 21:36:25 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:25 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:25 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:25 --> URI Class Initialized
INFO - 2024-06-17 21:36:25 --> Router Class Initialized
INFO - 2024-06-17 21:36:25 --> Output Class Initialized
INFO - 2024-06-17 21:36:25 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:25 --> Input Class Initialized
INFO - 2024-06-17 21:36:25 --> Language Class Initialized
INFO - 2024-06-17 21:36:25 --> Language Class Initialized
INFO - 2024-06-17 21:36:25 --> Config Class Initialized
INFO - 2024-06-17 21:36:25 --> Loader Class Initialized
INFO - 2024-06-17 21:36:25 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:25 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:25 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:25 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:25 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:25 --> Controller Class Initialized
INFO - 2024-06-17 21:36:25 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:25 --> Total execution time: 0.0285
INFO - 2024-06-17 21:36:47 --> Config Class Initialized
INFO - 2024-06-17 21:36:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:47 --> URI Class Initialized
INFO - 2024-06-17 21:36:47 --> Router Class Initialized
INFO - 2024-06-17 21:36:47 --> Output Class Initialized
INFO - 2024-06-17 21:36:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:47 --> Input Class Initialized
INFO - 2024-06-17 21:36:47 --> Language Class Initialized
INFO - 2024-06-17 21:36:47 --> Language Class Initialized
INFO - 2024-06-17 21:36:47 --> Config Class Initialized
INFO - 2024-06-17 21:36:47 --> Loader Class Initialized
INFO - 2024-06-17 21:36:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:47 --> Controller Class Initialized
INFO - 2024-06-17 21:36:47 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:47 --> Total execution time: 0.0382
INFO - 2024-06-17 21:36:49 --> Config Class Initialized
INFO - 2024-06-17 21:36:49 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:49 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:49 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:49 --> URI Class Initialized
INFO - 2024-06-17 21:36:49 --> Router Class Initialized
INFO - 2024-06-17 21:36:49 --> Output Class Initialized
INFO - 2024-06-17 21:36:49 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:49 --> Input Class Initialized
INFO - 2024-06-17 21:36:49 --> Language Class Initialized
INFO - 2024-06-17 21:36:49 --> Language Class Initialized
INFO - 2024-06-17 21:36:49 --> Config Class Initialized
INFO - 2024-06-17 21:36:49 --> Loader Class Initialized
INFO - 2024-06-17 21:36:49 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:49 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:49 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:49 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:49 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:49 --> Controller Class Initialized
DEBUG - 2024-06-17 21:36:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 21:36:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:36:49 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:49 --> Total execution time: 0.0270
INFO - 2024-06-17 21:36:58 --> Config Class Initialized
INFO - 2024-06-17 21:36:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:36:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:36:58 --> Utf8 Class Initialized
INFO - 2024-06-17 21:36:58 --> URI Class Initialized
INFO - 2024-06-17 21:36:58 --> Router Class Initialized
INFO - 2024-06-17 21:36:58 --> Output Class Initialized
INFO - 2024-06-17 21:36:58 --> Security Class Initialized
DEBUG - 2024-06-17 21:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:36:58 --> Input Class Initialized
INFO - 2024-06-17 21:36:58 --> Language Class Initialized
INFO - 2024-06-17 21:36:58 --> Language Class Initialized
INFO - 2024-06-17 21:36:58 --> Config Class Initialized
INFO - 2024-06-17 21:36:58 --> Loader Class Initialized
INFO - 2024-06-17 21:36:58 --> Helper loaded: url_helper
INFO - 2024-06-17 21:36:58 --> Helper loaded: file_helper
INFO - 2024-06-17 21:36:58 --> Helper loaded: form_helper
INFO - 2024-06-17 21:36:58 --> Helper loaded: my_helper
INFO - 2024-06-17 21:36:58 --> Database Driver Class Initialized
INFO - 2024-06-17 21:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:36:58 --> Controller Class Initialized
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:36:58 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:36:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:36:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:36:58 --> Final output sent to browser
DEBUG - 2024-06-17 21:36:58 --> Total execution time: 0.0413
INFO - 2024-06-17 21:37:01 --> Config Class Initialized
INFO - 2024-06-17 21:37:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:01 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:01 --> URI Class Initialized
INFO - 2024-06-17 21:37:01 --> Router Class Initialized
INFO - 2024-06-17 21:37:01 --> Output Class Initialized
INFO - 2024-06-17 21:37:01 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:01 --> Input Class Initialized
INFO - 2024-06-17 21:37:01 --> Language Class Initialized
INFO - 2024-06-17 21:37:01 --> Language Class Initialized
INFO - 2024-06-17 21:37:01 --> Config Class Initialized
INFO - 2024-06-17 21:37:01 --> Loader Class Initialized
INFO - 2024-06-17 21:37:01 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:01 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:01 --> Controller Class Initialized
DEBUG - 2024-06-17 21:37:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:37:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:37:01 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:01 --> Total execution time: 0.1022
INFO - 2024-06-17 21:37:01 --> Config Class Initialized
INFO - 2024-06-17 21:37:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:01 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:01 --> URI Class Initialized
INFO - 2024-06-17 21:37:01 --> Router Class Initialized
INFO - 2024-06-17 21:37:01 --> Output Class Initialized
INFO - 2024-06-17 21:37:01 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:01 --> Input Class Initialized
INFO - 2024-06-17 21:37:01 --> Language Class Initialized
INFO - 2024-06-17 21:37:01 --> Language Class Initialized
INFO - 2024-06-17 21:37:01 --> Config Class Initialized
INFO - 2024-06-17 21:37:01 --> Loader Class Initialized
INFO - 2024-06-17 21:37:01 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:01 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:01 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:01 --> Controller Class Initialized
INFO - 2024-06-17 21:37:04 --> Config Class Initialized
INFO - 2024-06-17 21:37:04 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:04 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:04 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:04 --> URI Class Initialized
INFO - 2024-06-17 21:37:04 --> Router Class Initialized
INFO - 2024-06-17 21:37:04 --> Output Class Initialized
INFO - 2024-06-17 21:37:04 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:04 --> Input Class Initialized
INFO - 2024-06-17 21:37:04 --> Language Class Initialized
INFO - 2024-06-17 21:37:04 --> Language Class Initialized
INFO - 2024-06-17 21:37:04 --> Config Class Initialized
INFO - 2024-06-17 21:37:04 --> Loader Class Initialized
INFO - 2024-06-17 21:37:04 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:04 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:04 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:04 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:04 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:04 --> Controller Class Initialized
INFO - 2024-06-17 21:37:04 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:04 --> Total execution time: 0.0675
INFO - 2024-06-17 21:37:10 --> Config Class Initialized
INFO - 2024-06-17 21:37:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:10 --> URI Class Initialized
INFO - 2024-06-17 21:37:10 --> Router Class Initialized
INFO - 2024-06-17 21:37:10 --> Output Class Initialized
INFO - 2024-06-17 21:37:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:10 --> Input Class Initialized
INFO - 2024-06-17 21:37:10 --> Language Class Initialized
INFO - 2024-06-17 21:37:10 --> Language Class Initialized
INFO - 2024-06-17 21:37:10 --> Config Class Initialized
INFO - 2024-06-17 21:37:10 --> Loader Class Initialized
INFO - 2024-06-17 21:37:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:10 --> Controller Class Initialized
INFO - 2024-06-17 21:37:10 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:10 --> Total execution time: 0.0308
INFO - 2024-06-17 21:37:12 --> Config Class Initialized
INFO - 2024-06-17 21:37:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:12 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:12 --> URI Class Initialized
INFO - 2024-06-17 21:37:12 --> Router Class Initialized
INFO - 2024-06-17 21:37:12 --> Output Class Initialized
INFO - 2024-06-17 21:37:12 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:12 --> Input Class Initialized
INFO - 2024-06-17 21:37:12 --> Language Class Initialized
INFO - 2024-06-17 21:37:12 --> Language Class Initialized
INFO - 2024-06-17 21:37:12 --> Config Class Initialized
INFO - 2024-06-17 21:37:12 --> Loader Class Initialized
INFO - 2024-06-17 21:37:12 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:12 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:12 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:12 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:12 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:12 --> Controller Class Initialized
INFO - 2024-06-17 21:37:12 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:12 --> Total execution time: 0.0357
INFO - 2024-06-17 21:37:15 --> Config Class Initialized
INFO - 2024-06-17 21:37:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:15 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:15 --> URI Class Initialized
INFO - 2024-06-17 21:37:15 --> Router Class Initialized
INFO - 2024-06-17 21:37:15 --> Output Class Initialized
INFO - 2024-06-17 21:37:15 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:15 --> Input Class Initialized
INFO - 2024-06-17 21:37:15 --> Language Class Initialized
INFO - 2024-06-17 21:37:15 --> Language Class Initialized
INFO - 2024-06-17 21:37:15 --> Config Class Initialized
INFO - 2024-06-17 21:37:15 --> Loader Class Initialized
INFO - 2024-06-17 21:37:15 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:15 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:15 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:15 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:15 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:15 --> Controller Class Initialized
INFO - 2024-06-17 21:37:15 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:15 --> Total execution time: 0.0504
INFO - 2024-06-17 21:37:19 --> Config Class Initialized
INFO - 2024-06-17 21:37:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:19 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:19 --> URI Class Initialized
INFO - 2024-06-17 21:37:19 --> Router Class Initialized
INFO - 2024-06-17 21:37:19 --> Output Class Initialized
INFO - 2024-06-17 21:37:19 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:19 --> Input Class Initialized
INFO - 2024-06-17 21:37:19 --> Language Class Initialized
INFO - 2024-06-17 21:37:19 --> Language Class Initialized
INFO - 2024-06-17 21:37:19 --> Config Class Initialized
INFO - 2024-06-17 21:37:19 --> Loader Class Initialized
INFO - 2024-06-17 21:37:19 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:19 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:19 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:19 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:19 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:19 --> Controller Class Initialized
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:19 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:37:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:37:19 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:19 --> Total execution time: 0.0341
INFO - 2024-06-17 21:37:20 --> Config Class Initialized
INFO - 2024-06-17 21:37:20 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:20 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:20 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:20 --> URI Class Initialized
INFO - 2024-06-17 21:37:20 --> Router Class Initialized
INFO - 2024-06-17 21:37:20 --> Output Class Initialized
INFO - 2024-06-17 21:37:20 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:20 --> Input Class Initialized
INFO - 2024-06-17 21:37:20 --> Language Class Initialized
INFO - 2024-06-17 21:37:20 --> Language Class Initialized
INFO - 2024-06-17 21:37:20 --> Config Class Initialized
INFO - 2024-06-17 21:37:20 --> Loader Class Initialized
INFO - 2024-06-17 21:37:20 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:20 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:20 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:20 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:20 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:20 --> Controller Class Initialized
DEBUG - 2024-06-17 21:37:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:37:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:37:20 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:20 --> Total execution time: 0.0319
INFO - 2024-06-17 21:37:21 --> Config Class Initialized
INFO - 2024-06-17 21:37:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:21 --> URI Class Initialized
INFO - 2024-06-17 21:37:21 --> Router Class Initialized
INFO - 2024-06-17 21:37:21 --> Output Class Initialized
INFO - 2024-06-17 21:37:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:21 --> Input Class Initialized
INFO - 2024-06-17 21:37:21 --> Language Class Initialized
INFO - 2024-06-17 21:37:21 --> Language Class Initialized
INFO - 2024-06-17 21:37:21 --> Config Class Initialized
INFO - 2024-06-17 21:37:21 --> Loader Class Initialized
INFO - 2024-06-17 21:37:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:21 --> Controller Class Initialized
INFO - 2024-06-17 21:37:23 --> Config Class Initialized
INFO - 2024-06-17 21:37:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:23 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:23 --> URI Class Initialized
INFO - 2024-06-17 21:37:23 --> Router Class Initialized
INFO - 2024-06-17 21:37:23 --> Output Class Initialized
INFO - 2024-06-17 21:37:23 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:23 --> Input Class Initialized
INFO - 2024-06-17 21:37:23 --> Language Class Initialized
INFO - 2024-06-17 21:37:23 --> Language Class Initialized
INFO - 2024-06-17 21:37:23 --> Config Class Initialized
INFO - 2024-06-17 21:37:23 --> Loader Class Initialized
INFO - 2024-06-17 21:37:23 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:23 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:23 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:23 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:23 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:23 --> Controller Class Initialized
INFO - 2024-06-17 21:37:23 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:23 --> Total execution time: 0.0335
INFO - 2024-06-17 21:37:27 --> Config Class Initialized
INFO - 2024-06-17 21:37:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:27 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:27 --> URI Class Initialized
INFO - 2024-06-17 21:37:27 --> Router Class Initialized
INFO - 2024-06-17 21:37:27 --> Output Class Initialized
INFO - 2024-06-17 21:37:27 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:27 --> Input Class Initialized
INFO - 2024-06-17 21:37:27 --> Language Class Initialized
INFO - 2024-06-17 21:37:27 --> Language Class Initialized
INFO - 2024-06-17 21:37:27 --> Config Class Initialized
INFO - 2024-06-17 21:37:27 --> Loader Class Initialized
INFO - 2024-06-17 21:37:27 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:27 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:27 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:27 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:27 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:27 --> Controller Class Initialized
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:37:27 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:37:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:37:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:37:27 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:27 --> Total execution time: 0.0293
INFO - 2024-06-17 21:37:58 --> Config Class Initialized
INFO - 2024-06-17 21:37:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:58 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:58 --> URI Class Initialized
INFO - 2024-06-17 21:37:58 --> Router Class Initialized
INFO - 2024-06-17 21:37:58 --> Output Class Initialized
INFO - 2024-06-17 21:37:58 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:58 --> Input Class Initialized
INFO - 2024-06-17 21:37:58 --> Language Class Initialized
INFO - 2024-06-17 21:37:58 --> Language Class Initialized
INFO - 2024-06-17 21:37:58 --> Config Class Initialized
INFO - 2024-06-17 21:37:58 --> Loader Class Initialized
INFO - 2024-06-17 21:37:58 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:58 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:58 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:58 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:58 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:58 --> Controller Class Initialized
DEBUG - 2024-06-17 21:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:37:58 --> Final output sent to browser
DEBUG - 2024-06-17 21:37:58 --> Total execution time: 0.0588
INFO - 2024-06-17 21:37:58 --> Config Class Initialized
INFO - 2024-06-17 21:37:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:37:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:37:58 --> Utf8 Class Initialized
INFO - 2024-06-17 21:37:58 --> URI Class Initialized
INFO - 2024-06-17 21:37:58 --> Router Class Initialized
INFO - 2024-06-17 21:37:58 --> Output Class Initialized
INFO - 2024-06-17 21:37:58 --> Security Class Initialized
DEBUG - 2024-06-17 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:37:59 --> Input Class Initialized
INFO - 2024-06-17 21:37:59 --> Language Class Initialized
INFO - 2024-06-17 21:37:59 --> Language Class Initialized
INFO - 2024-06-17 21:37:59 --> Config Class Initialized
INFO - 2024-06-17 21:37:59 --> Loader Class Initialized
INFO - 2024-06-17 21:37:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:37:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:37:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:37:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:37:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:37:59 --> Controller Class Initialized
INFO - 2024-06-17 21:38:01 --> Config Class Initialized
INFO - 2024-06-17 21:38:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:38:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:38:01 --> Utf8 Class Initialized
INFO - 2024-06-17 21:38:01 --> URI Class Initialized
INFO - 2024-06-17 21:38:01 --> Router Class Initialized
INFO - 2024-06-17 21:38:01 --> Output Class Initialized
INFO - 2024-06-17 21:38:01 --> Security Class Initialized
DEBUG - 2024-06-17 21:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:38:01 --> Input Class Initialized
INFO - 2024-06-17 21:38:01 --> Language Class Initialized
INFO - 2024-06-17 21:38:01 --> Language Class Initialized
INFO - 2024-06-17 21:38:01 --> Config Class Initialized
INFO - 2024-06-17 21:38:01 --> Loader Class Initialized
INFO - 2024-06-17 21:38:01 --> Helper loaded: url_helper
INFO - 2024-06-17 21:38:01 --> Helper loaded: file_helper
INFO - 2024-06-17 21:38:01 --> Helper loaded: form_helper
INFO - 2024-06-17 21:38:01 --> Helper loaded: my_helper
INFO - 2024-06-17 21:38:01 --> Database Driver Class Initialized
INFO - 2024-06-17 21:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:38:01 --> Controller Class Initialized
INFO - 2024-06-17 21:38:01 --> Final output sent to browser
DEBUG - 2024-06-17 21:38:01 --> Total execution time: 0.2084
INFO - 2024-06-17 21:39:29 --> Config Class Initialized
INFO - 2024-06-17 21:39:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:39:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:39:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:39:29 --> URI Class Initialized
INFO - 2024-06-17 21:39:29 --> Router Class Initialized
INFO - 2024-06-17 21:39:29 --> Output Class Initialized
INFO - 2024-06-17 21:39:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:39:29 --> Input Class Initialized
INFO - 2024-06-17 21:39:29 --> Language Class Initialized
INFO - 2024-06-17 21:39:29 --> Language Class Initialized
INFO - 2024-06-17 21:39:29 --> Config Class Initialized
INFO - 2024-06-17 21:39:29 --> Loader Class Initialized
INFO - 2024-06-17 21:39:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:39:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:39:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:39:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:39:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:39:29 --> Controller Class Initialized
INFO - 2024-06-17 21:39:29 --> Final output sent to browser
DEBUG - 2024-06-17 21:39:29 --> Total execution time: 0.0430
INFO - 2024-06-17 21:39:31 --> Config Class Initialized
INFO - 2024-06-17 21:39:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:39:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:39:31 --> Utf8 Class Initialized
INFO - 2024-06-17 21:39:31 --> URI Class Initialized
INFO - 2024-06-17 21:39:31 --> Router Class Initialized
INFO - 2024-06-17 21:39:31 --> Output Class Initialized
INFO - 2024-06-17 21:39:31 --> Security Class Initialized
DEBUG - 2024-06-17 21:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:39:31 --> Input Class Initialized
INFO - 2024-06-17 21:39:31 --> Language Class Initialized
INFO - 2024-06-17 21:39:31 --> Language Class Initialized
INFO - 2024-06-17 21:39:31 --> Config Class Initialized
INFO - 2024-06-17 21:39:31 --> Loader Class Initialized
INFO - 2024-06-17 21:39:31 --> Helper loaded: url_helper
INFO - 2024-06-17 21:39:31 --> Helper loaded: file_helper
INFO - 2024-06-17 21:39:31 --> Helper loaded: form_helper
INFO - 2024-06-17 21:39:31 --> Helper loaded: my_helper
INFO - 2024-06-17 21:39:31 --> Database Driver Class Initialized
INFO - 2024-06-17 21:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:39:31 --> Controller Class Initialized
INFO - 2024-06-17 21:39:31 --> Final output sent to browser
DEBUG - 2024-06-17 21:39:31 --> Total execution time: 0.0297
INFO - 2024-06-17 21:40:10 --> Config Class Initialized
INFO - 2024-06-17 21:40:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:40:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:40:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:40:10 --> URI Class Initialized
INFO - 2024-06-17 21:40:10 --> Router Class Initialized
INFO - 2024-06-17 21:40:10 --> Output Class Initialized
INFO - 2024-06-17 21:40:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:40:10 --> Input Class Initialized
INFO - 2024-06-17 21:40:10 --> Language Class Initialized
INFO - 2024-06-17 21:40:10 --> Language Class Initialized
INFO - 2024-06-17 21:40:10 --> Config Class Initialized
INFO - 2024-06-17 21:40:10 --> Loader Class Initialized
INFO - 2024-06-17 21:40:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:40:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:40:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:40:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:40:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:40:10 --> Controller Class Initialized
INFO - 2024-06-17 21:40:10 --> Final output sent to browser
DEBUG - 2024-06-17 21:40:10 --> Total execution time: 0.0494
INFO - 2024-06-17 21:40:16 --> Config Class Initialized
INFO - 2024-06-17 21:40:16 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:40:16 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:40:16 --> Utf8 Class Initialized
INFO - 2024-06-17 21:40:16 --> URI Class Initialized
INFO - 2024-06-17 21:40:16 --> Router Class Initialized
INFO - 2024-06-17 21:40:16 --> Output Class Initialized
INFO - 2024-06-17 21:40:16 --> Security Class Initialized
DEBUG - 2024-06-17 21:40:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:40:16 --> Input Class Initialized
INFO - 2024-06-17 21:40:16 --> Language Class Initialized
INFO - 2024-06-17 21:40:16 --> Language Class Initialized
INFO - 2024-06-17 21:40:16 --> Config Class Initialized
INFO - 2024-06-17 21:40:16 --> Loader Class Initialized
INFO - 2024-06-17 21:40:16 --> Helper loaded: url_helper
INFO - 2024-06-17 21:40:16 --> Helper loaded: file_helper
INFO - 2024-06-17 21:40:16 --> Helper loaded: form_helper
INFO - 2024-06-17 21:40:16 --> Helper loaded: my_helper
INFO - 2024-06-17 21:40:16 --> Database Driver Class Initialized
INFO - 2024-06-17 21:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:40:16 --> Controller Class Initialized
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:40:16 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:40:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:40:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:40:16 --> Final output sent to browser
DEBUG - 2024-06-17 21:40:16 --> Total execution time: 0.0310
INFO - 2024-06-17 21:40:50 --> Config Class Initialized
INFO - 2024-06-17 21:40:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:40:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:40:50 --> Utf8 Class Initialized
INFO - 2024-06-17 21:40:50 --> URI Class Initialized
INFO - 2024-06-17 21:40:50 --> Router Class Initialized
INFO - 2024-06-17 21:40:50 --> Output Class Initialized
INFO - 2024-06-17 21:40:50 --> Security Class Initialized
DEBUG - 2024-06-17 21:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:40:50 --> Input Class Initialized
INFO - 2024-06-17 21:40:50 --> Language Class Initialized
INFO - 2024-06-17 21:40:50 --> Language Class Initialized
INFO - 2024-06-17 21:40:50 --> Config Class Initialized
INFO - 2024-06-17 21:40:50 --> Loader Class Initialized
INFO - 2024-06-17 21:40:50 --> Helper loaded: url_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: file_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: form_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: my_helper
INFO - 2024-06-17 21:40:50 --> Database Driver Class Initialized
INFO - 2024-06-17 21:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:40:50 --> Controller Class Initialized
DEBUG - 2024-06-17 21:40:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:40:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:40:50 --> Final output sent to browser
DEBUG - 2024-06-17 21:40:50 --> Total execution time: 0.0568
INFO - 2024-06-17 21:40:50 --> Config Class Initialized
INFO - 2024-06-17 21:40:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:40:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:40:50 --> Utf8 Class Initialized
INFO - 2024-06-17 21:40:50 --> URI Class Initialized
INFO - 2024-06-17 21:40:50 --> Router Class Initialized
INFO - 2024-06-17 21:40:50 --> Output Class Initialized
INFO - 2024-06-17 21:40:50 --> Security Class Initialized
DEBUG - 2024-06-17 21:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:40:50 --> Input Class Initialized
INFO - 2024-06-17 21:40:50 --> Language Class Initialized
INFO - 2024-06-17 21:40:50 --> Language Class Initialized
INFO - 2024-06-17 21:40:50 --> Config Class Initialized
INFO - 2024-06-17 21:40:50 --> Loader Class Initialized
INFO - 2024-06-17 21:40:50 --> Helper loaded: url_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: file_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: form_helper
INFO - 2024-06-17 21:40:50 --> Helper loaded: my_helper
INFO - 2024-06-17 21:40:50 --> Database Driver Class Initialized
INFO - 2024-06-17 21:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:40:50 --> Controller Class Initialized
INFO - 2024-06-17 21:40:52 --> Config Class Initialized
INFO - 2024-06-17 21:40:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:40:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:40:52 --> Utf8 Class Initialized
INFO - 2024-06-17 21:40:52 --> URI Class Initialized
INFO - 2024-06-17 21:40:52 --> Router Class Initialized
INFO - 2024-06-17 21:40:52 --> Output Class Initialized
INFO - 2024-06-17 21:40:52 --> Security Class Initialized
DEBUG - 2024-06-17 21:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:40:52 --> Input Class Initialized
INFO - 2024-06-17 21:40:52 --> Language Class Initialized
INFO - 2024-06-17 21:40:52 --> Language Class Initialized
INFO - 2024-06-17 21:40:52 --> Config Class Initialized
INFO - 2024-06-17 21:40:52 --> Loader Class Initialized
INFO - 2024-06-17 21:40:52 --> Helper loaded: url_helper
INFO - 2024-06-17 21:40:52 --> Helper loaded: file_helper
INFO - 2024-06-17 21:40:52 --> Helper loaded: form_helper
INFO - 2024-06-17 21:40:52 --> Helper loaded: my_helper
INFO - 2024-06-17 21:40:52 --> Database Driver Class Initialized
INFO - 2024-06-17 21:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:40:52 --> Controller Class Initialized
INFO - 2024-06-17 21:40:52 --> Final output sent to browser
DEBUG - 2024-06-17 21:40:52 --> Total execution time: 0.0521
INFO - 2024-06-17 21:41:10 --> Config Class Initialized
INFO - 2024-06-17 21:41:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:10 --> URI Class Initialized
INFO - 2024-06-17 21:41:10 --> Router Class Initialized
INFO - 2024-06-17 21:41:10 --> Output Class Initialized
INFO - 2024-06-17 21:41:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:10 --> Input Class Initialized
INFO - 2024-06-17 21:41:10 --> Language Class Initialized
INFO - 2024-06-17 21:41:10 --> Language Class Initialized
INFO - 2024-06-17 21:41:10 --> Config Class Initialized
INFO - 2024-06-17 21:41:10 --> Loader Class Initialized
INFO - 2024-06-17 21:41:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:10 --> Controller Class Initialized
INFO - 2024-06-17 21:41:10 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:10 --> Total execution time: 0.4451
INFO - 2024-06-17 21:41:13 --> Config Class Initialized
INFO - 2024-06-17 21:41:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:13 --> URI Class Initialized
INFO - 2024-06-17 21:41:13 --> Router Class Initialized
INFO - 2024-06-17 21:41:13 --> Output Class Initialized
INFO - 2024-06-17 21:41:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:13 --> Input Class Initialized
INFO - 2024-06-17 21:41:13 --> Language Class Initialized
INFO - 2024-06-17 21:41:13 --> Language Class Initialized
INFO - 2024-06-17 21:41:13 --> Config Class Initialized
INFO - 2024-06-17 21:41:13 --> Loader Class Initialized
INFO - 2024-06-17 21:41:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:13 --> Controller Class Initialized
INFO - 2024-06-17 21:41:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:13 --> Total execution time: 0.0536
INFO - 2024-06-17 21:41:30 --> Config Class Initialized
INFO - 2024-06-17 21:41:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:30 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:30 --> URI Class Initialized
INFO - 2024-06-17 21:41:30 --> Router Class Initialized
INFO - 2024-06-17 21:41:30 --> Output Class Initialized
INFO - 2024-06-17 21:41:30 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:30 --> Input Class Initialized
INFO - 2024-06-17 21:41:30 --> Language Class Initialized
INFO - 2024-06-17 21:41:30 --> Language Class Initialized
INFO - 2024-06-17 21:41:30 --> Config Class Initialized
INFO - 2024-06-17 21:41:30 --> Loader Class Initialized
INFO - 2024-06-17 21:41:30 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:30 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:30 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:30 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:30 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:30 --> Controller Class Initialized
INFO - 2024-06-17 21:41:30 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:30 --> Total execution time: 0.0693
INFO - 2024-06-17 21:41:33 --> Config Class Initialized
INFO - 2024-06-17 21:41:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:33 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:33 --> URI Class Initialized
INFO - 2024-06-17 21:41:33 --> Router Class Initialized
INFO - 2024-06-17 21:41:33 --> Output Class Initialized
INFO - 2024-06-17 21:41:33 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:33 --> Input Class Initialized
INFO - 2024-06-17 21:41:33 --> Language Class Initialized
INFO - 2024-06-17 21:41:33 --> Language Class Initialized
INFO - 2024-06-17 21:41:33 --> Config Class Initialized
INFO - 2024-06-17 21:41:33 --> Loader Class Initialized
INFO - 2024-06-17 21:41:33 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:33 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:33 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:33 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:33 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:33 --> Controller Class Initialized
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:33 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:41:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:41:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:33 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:33 --> Total execution time: 0.0682
INFO - 2024-06-17 21:41:35 --> Config Class Initialized
INFO - 2024-06-17 21:41:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:35 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:35 --> URI Class Initialized
INFO - 2024-06-17 21:41:35 --> Router Class Initialized
INFO - 2024-06-17 21:41:35 --> Output Class Initialized
INFO - 2024-06-17 21:41:35 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:35 --> Input Class Initialized
INFO - 2024-06-17 21:41:35 --> Language Class Initialized
INFO - 2024-06-17 21:41:35 --> Language Class Initialized
INFO - 2024-06-17 21:41:35 --> Config Class Initialized
INFO - 2024-06-17 21:41:35 --> Loader Class Initialized
INFO - 2024-06-17 21:41:35 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:35 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:35 --> Controller Class Initialized
DEBUG - 2024-06-17 21:41:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:41:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:35 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:35 --> Total execution time: 0.0291
INFO - 2024-06-17 21:41:35 --> Config Class Initialized
INFO - 2024-06-17 21:41:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:35 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:35 --> URI Class Initialized
INFO - 2024-06-17 21:41:35 --> Router Class Initialized
INFO - 2024-06-17 21:41:35 --> Output Class Initialized
INFO - 2024-06-17 21:41:35 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:35 --> Input Class Initialized
INFO - 2024-06-17 21:41:35 --> Language Class Initialized
INFO - 2024-06-17 21:41:35 --> Language Class Initialized
INFO - 2024-06-17 21:41:35 --> Config Class Initialized
INFO - 2024-06-17 21:41:35 --> Loader Class Initialized
INFO - 2024-06-17 21:41:35 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:35 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:35 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:35 --> Controller Class Initialized
INFO - 2024-06-17 21:41:37 --> Config Class Initialized
INFO - 2024-06-17 21:41:37 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:37 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:37 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:37 --> URI Class Initialized
INFO - 2024-06-17 21:41:37 --> Router Class Initialized
INFO - 2024-06-17 21:41:37 --> Output Class Initialized
INFO - 2024-06-17 21:41:37 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:37 --> Input Class Initialized
INFO - 2024-06-17 21:41:37 --> Language Class Initialized
INFO - 2024-06-17 21:41:37 --> Language Class Initialized
INFO - 2024-06-17 21:41:37 --> Config Class Initialized
INFO - 2024-06-17 21:41:37 --> Loader Class Initialized
INFO - 2024-06-17 21:41:37 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:37 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:37 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:37 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:37 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:37 --> Controller Class Initialized
INFO - 2024-06-17 21:41:37 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:37 --> Total execution time: 0.0275
INFO - 2024-06-17 21:41:39 --> Config Class Initialized
INFO - 2024-06-17 21:41:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:39 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:39 --> URI Class Initialized
INFO - 2024-06-17 21:41:39 --> Router Class Initialized
INFO - 2024-06-17 21:41:39 --> Output Class Initialized
INFO - 2024-06-17 21:41:39 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:39 --> Input Class Initialized
INFO - 2024-06-17 21:41:39 --> Language Class Initialized
INFO - 2024-06-17 21:41:39 --> Language Class Initialized
INFO - 2024-06-17 21:41:39 --> Config Class Initialized
INFO - 2024-06-17 21:41:39 --> Loader Class Initialized
INFO - 2024-06-17 21:41:39 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:39 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:39 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:39 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:39 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:39 --> Controller Class Initialized
INFO - 2024-06-17 21:41:39 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:39 --> Total execution time: 0.0288
INFO - 2024-06-17 21:41:42 --> Config Class Initialized
INFO - 2024-06-17 21:41:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:42 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:42 --> URI Class Initialized
INFO - 2024-06-17 21:41:42 --> Router Class Initialized
INFO - 2024-06-17 21:41:42 --> Output Class Initialized
INFO - 2024-06-17 21:41:42 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:42 --> Input Class Initialized
INFO - 2024-06-17 21:41:42 --> Language Class Initialized
INFO - 2024-06-17 21:41:42 --> Language Class Initialized
INFO - 2024-06-17 21:41:42 --> Config Class Initialized
INFO - 2024-06-17 21:41:42 --> Loader Class Initialized
INFO - 2024-06-17 21:41:42 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:42 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:42 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:42 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:42 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:42 --> Controller Class Initialized
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:42 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:41:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:42 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:42 --> Total execution time: 0.0322
INFO - 2024-06-17 21:41:44 --> Config Class Initialized
INFO - 2024-06-17 21:41:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:44 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:44 --> URI Class Initialized
INFO - 2024-06-17 21:41:44 --> Router Class Initialized
INFO - 2024-06-17 21:41:44 --> Output Class Initialized
INFO - 2024-06-17 21:41:44 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:44 --> Input Class Initialized
INFO - 2024-06-17 21:41:44 --> Language Class Initialized
INFO - 2024-06-17 21:41:44 --> Language Class Initialized
INFO - 2024-06-17 21:41:44 --> Config Class Initialized
INFO - 2024-06-17 21:41:44 --> Loader Class Initialized
INFO - 2024-06-17 21:41:44 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:44 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:44 --> Controller Class Initialized
DEBUG - 2024-06-17 21:41:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:41:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:44 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:44 --> Total execution time: 0.0307
INFO - 2024-06-17 21:41:44 --> Config Class Initialized
INFO - 2024-06-17 21:41:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:44 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:44 --> URI Class Initialized
INFO - 2024-06-17 21:41:44 --> Router Class Initialized
INFO - 2024-06-17 21:41:44 --> Output Class Initialized
INFO - 2024-06-17 21:41:44 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:44 --> Input Class Initialized
INFO - 2024-06-17 21:41:44 --> Language Class Initialized
INFO - 2024-06-17 21:41:44 --> Language Class Initialized
INFO - 2024-06-17 21:41:44 --> Config Class Initialized
INFO - 2024-06-17 21:41:44 --> Loader Class Initialized
INFO - 2024-06-17 21:41:44 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:44 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:44 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:44 --> Controller Class Initialized
INFO - 2024-06-17 21:41:47 --> Config Class Initialized
INFO - 2024-06-17 21:41:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:47 --> URI Class Initialized
INFO - 2024-06-17 21:41:47 --> Router Class Initialized
INFO - 2024-06-17 21:41:47 --> Output Class Initialized
INFO - 2024-06-17 21:41:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:47 --> Input Class Initialized
INFO - 2024-06-17 21:41:47 --> Language Class Initialized
INFO - 2024-06-17 21:41:47 --> Language Class Initialized
INFO - 2024-06-17 21:41:47 --> Config Class Initialized
INFO - 2024-06-17 21:41:47 --> Loader Class Initialized
INFO - 2024-06-17 21:41:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:47 --> Controller Class Initialized
INFO - 2024-06-17 21:41:47 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:47 --> Total execution time: 0.0325
INFO - 2024-06-17 21:41:51 --> Config Class Initialized
INFO - 2024-06-17 21:41:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:51 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:51 --> URI Class Initialized
INFO - 2024-06-17 21:41:51 --> Router Class Initialized
INFO - 2024-06-17 21:41:51 --> Output Class Initialized
INFO - 2024-06-17 21:41:51 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:51 --> Input Class Initialized
INFO - 2024-06-17 21:41:51 --> Language Class Initialized
INFO - 2024-06-17 21:41:51 --> Language Class Initialized
INFO - 2024-06-17 21:41:51 --> Config Class Initialized
INFO - 2024-06-17 21:41:51 --> Loader Class Initialized
INFO - 2024-06-17 21:41:51 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:51 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:51 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:51 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:51 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:51 --> Controller Class Initialized
INFO - 2024-06-17 21:41:51 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:51 --> Total execution time: 0.0348
INFO - 2024-06-17 21:41:53 --> Config Class Initialized
INFO - 2024-06-17 21:41:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:53 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:53 --> URI Class Initialized
INFO - 2024-06-17 21:41:53 --> Router Class Initialized
INFO - 2024-06-17 21:41:53 --> Output Class Initialized
INFO - 2024-06-17 21:41:53 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:53 --> Input Class Initialized
INFO - 2024-06-17 21:41:53 --> Language Class Initialized
INFO - 2024-06-17 21:41:53 --> Language Class Initialized
INFO - 2024-06-17 21:41:53 --> Config Class Initialized
INFO - 2024-06-17 21:41:53 --> Loader Class Initialized
INFO - 2024-06-17 21:41:53 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:53 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:53 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:53 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:53 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:53 --> Controller Class Initialized
INFO - 2024-06-17 21:41:53 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:53 --> Total execution time: 0.0287
INFO - 2024-06-17 21:41:55 --> Config Class Initialized
INFO - 2024-06-17 21:41:55 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:55 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:55 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:55 --> URI Class Initialized
INFO - 2024-06-17 21:41:55 --> Router Class Initialized
INFO - 2024-06-17 21:41:55 --> Output Class Initialized
INFO - 2024-06-17 21:41:55 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:55 --> Input Class Initialized
INFO - 2024-06-17 21:41:55 --> Language Class Initialized
INFO - 2024-06-17 21:41:55 --> Language Class Initialized
INFO - 2024-06-17 21:41:55 --> Config Class Initialized
INFO - 2024-06-17 21:41:55 --> Loader Class Initialized
INFO - 2024-06-17 21:41:55 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:55 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:55 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:55 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:55 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:55 --> Controller Class Initialized
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:41:55 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:41:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:55 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:55 --> Total execution time: 0.0327
INFO - 2024-06-17 21:41:59 --> Config Class Initialized
INFO - 2024-06-17 21:41:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:59 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:59 --> URI Class Initialized
INFO - 2024-06-17 21:41:59 --> Router Class Initialized
INFO - 2024-06-17 21:41:59 --> Output Class Initialized
INFO - 2024-06-17 21:41:59 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:59 --> Input Class Initialized
INFO - 2024-06-17 21:41:59 --> Language Class Initialized
INFO - 2024-06-17 21:41:59 --> Language Class Initialized
INFO - 2024-06-17 21:41:59 --> Config Class Initialized
INFO - 2024-06-17 21:41:59 --> Loader Class Initialized
INFO - 2024-06-17 21:41:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:59 --> Controller Class Initialized
DEBUG - 2024-06-17 21:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:41:59 --> Final output sent to browser
DEBUG - 2024-06-17 21:41:59 --> Total execution time: 0.0290
INFO - 2024-06-17 21:41:59 --> Config Class Initialized
INFO - 2024-06-17 21:41:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:41:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:41:59 --> Utf8 Class Initialized
INFO - 2024-06-17 21:41:59 --> URI Class Initialized
INFO - 2024-06-17 21:41:59 --> Router Class Initialized
INFO - 2024-06-17 21:41:59 --> Output Class Initialized
INFO - 2024-06-17 21:41:59 --> Security Class Initialized
DEBUG - 2024-06-17 21:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:41:59 --> Input Class Initialized
INFO - 2024-06-17 21:41:59 --> Language Class Initialized
INFO - 2024-06-17 21:41:59 --> Language Class Initialized
INFO - 2024-06-17 21:41:59 --> Config Class Initialized
INFO - 2024-06-17 21:41:59 --> Loader Class Initialized
INFO - 2024-06-17 21:41:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:41:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:41:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:41:59 --> Controller Class Initialized
INFO - 2024-06-17 21:42:00 --> Config Class Initialized
INFO - 2024-06-17 21:42:00 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:00 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:00 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:00 --> URI Class Initialized
INFO - 2024-06-17 21:42:00 --> Router Class Initialized
INFO - 2024-06-17 21:42:00 --> Output Class Initialized
INFO - 2024-06-17 21:42:01 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:01 --> Input Class Initialized
INFO - 2024-06-17 21:42:01 --> Language Class Initialized
INFO - 2024-06-17 21:42:01 --> Language Class Initialized
INFO - 2024-06-17 21:42:01 --> Config Class Initialized
INFO - 2024-06-17 21:42:01 --> Loader Class Initialized
INFO - 2024-06-17 21:42:01 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:01 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:01 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:01 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:01 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:01 --> Controller Class Initialized
INFO - 2024-06-17 21:42:01 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:01 --> Total execution time: 0.0408
INFO - 2024-06-17 21:42:10 --> Config Class Initialized
INFO - 2024-06-17 21:42:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:10 --> URI Class Initialized
INFO - 2024-06-17 21:42:10 --> Router Class Initialized
INFO - 2024-06-17 21:42:10 --> Output Class Initialized
INFO - 2024-06-17 21:42:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:10 --> Input Class Initialized
INFO - 2024-06-17 21:42:10 --> Language Class Initialized
INFO - 2024-06-17 21:42:10 --> Language Class Initialized
INFO - 2024-06-17 21:42:10 --> Config Class Initialized
INFO - 2024-06-17 21:42:10 --> Loader Class Initialized
INFO - 2024-06-17 21:42:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:10 --> Controller Class Initialized
INFO - 2024-06-17 21:42:10 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:10 --> Total execution time: 0.0408
INFO - 2024-06-17 21:42:12 --> Config Class Initialized
INFO - 2024-06-17 21:42:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:12 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:12 --> URI Class Initialized
INFO - 2024-06-17 21:42:12 --> Router Class Initialized
INFO - 2024-06-17 21:42:12 --> Output Class Initialized
INFO - 2024-06-17 21:42:12 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:12 --> Input Class Initialized
INFO - 2024-06-17 21:42:12 --> Language Class Initialized
INFO - 2024-06-17 21:42:12 --> Language Class Initialized
INFO - 2024-06-17 21:42:12 --> Config Class Initialized
INFO - 2024-06-17 21:42:12 --> Loader Class Initialized
INFO - 2024-06-17 21:42:12 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:12 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:12 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:12 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:12 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:12 --> Controller Class Initialized
INFO - 2024-06-17 21:42:12 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:12 --> Total execution time: 0.0335
INFO - 2024-06-17 21:42:22 --> Config Class Initialized
INFO - 2024-06-17 21:42:22 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:22 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:22 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:22 --> URI Class Initialized
INFO - 2024-06-17 21:42:22 --> Router Class Initialized
INFO - 2024-06-17 21:42:22 --> Output Class Initialized
INFO - 2024-06-17 21:42:22 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:22 --> Input Class Initialized
INFO - 2024-06-17 21:42:22 --> Language Class Initialized
INFO - 2024-06-17 21:42:22 --> Language Class Initialized
INFO - 2024-06-17 21:42:22 --> Config Class Initialized
INFO - 2024-06-17 21:42:22 --> Loader Class Initialized
INFO - 2024-06-17 21:42:22 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:22 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:22 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:22 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:22 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:22 --> Controller Class Initialized
INFO - 2024-06-17 21:42:22 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:22 --> Total execution time: 0.0389
INFO - 2024-06-17 21:42:26 --> Config Class Initialized
INFO - 2024-06-17 21:42:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:26 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:26 --> URI Class Initialized
INFO - 2024-06-17 21:42:26 --> Router Class Initialized
INFO - 2024-06-17 21:42:26 --> Output Class Initialized
INFO - 2024-06-17 21:42:26 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:26 --> Input Class Initialized
INFO - 2024-06-17 21:42:26 --> Language Class Initialized
INFO - 2024-06-17 21:42:26 --> Language Class Initialized
INFO - 2024-06-17 21:42:26 --> Config Class Initialized
INFO - 2024-06-17 21:42:26 --> Loader Class Initialized
INFO - 2024-06-17 21:42:26 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:26 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:26 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:26 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:26 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:26 --> Controller Class Initialized
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:42:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:42:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:42:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:42:26 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:26 --> Total execution time: 0.0334
INFO - 2024-06-17 21:42:30 --> Config Class Initialized
INFO - 2024-06-17 21:42:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:30 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:30 --> URI Class Initialized
INFO - 2024-06-17 21:42:30 --> Router Class Initialized
INFO - 2024-06-17 21:42:30 --> Output Class Initialized
INFO - 2024-06-17 21:42:30 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:30 --> Input Class Initialized
INFO - 2024-06-17 21:42:30 --> Language Class Initialized
INFO - 2024-06-17 21:42:30 --> Language Class Initialized
INFO - 2024-06-17 21:42:30 --> Config Class Initialized
INFO - 2024-06-17 21:42:30 --> Loader Class Initialized
INFO - 2024-06-17 21:42:30 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:30 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:30 --> Controller Class Initialized
DEBUG - 2024-06-17 21:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:42:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:42:30 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:30 --> Total execution time: 0.0702
INFO - 2024-06-17 21:42:30 --> Config Class Initialized
INFO - 2024-06-17 21:42:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:30 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:30 --> URI Class Initialized
INFO - 2024-06-17 21:42:30 --> Router Class Initialized
INFO - 2024-06-17 21:42:30 --> Output Class Initialized
INFO - 2024-06-17 21:42:30 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:30 --> Input Class Initialized
INFO - 2024-06-17 21:42:30 --> Language Class Initialized
INFO - 2024-06-17 21:42:30 --> Language Class Initialized
INFO - 2024-06-17 21:42:30 --> Config Class Initialized
INFO - 2024-06-17 21:42:30 --> Loader Class Initialized
INFO - 2024-06-17 21:42:30 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:30 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:30 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:30 --> Controller Class Initialized
INFO - 2024-06-17 21:42:33 --> Config Class Initialized
INFO - 2024-06-17 21:42:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:42:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:42:33 --> Utf8 Class Initialized
INFO - 2024-06-17 21:42:33 --> URI Class Initialized
INFO - 2024-06-17 21:42:33 --> Router Class Initialized
INFO - 2024-06-17 21:42:33 --> Output Class Initialized
INFO - 2024-06-17 21:42:33 --> Security Class Initialized
DEBUG - 2024-06-17 21:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:42:33 --> Input Class Initialized
INFO - 2024-06-17 21:42:33 --> Language Class Initialized
INFO - 2024-06-17 21:42:33 --> Language Class Initialized
INFO - 2024-06-17 21:42:33 --> Config Class Initialized
INFO - 2024-06-17 21:42:33 --> Loader Class Initialized
INFO - 2024-06-17 21:42:33 --> Helper loaded: url_helper
INFO - 2024-06-17 21:42:33 --> Helper loaded: file_helper
INFO - 2024-06-17 21:42:33 --> Helper loaded: form_helper
INFO - 2024-06-17 21:42:33 --> Helper loaded: my_helper
INFO - 2024-06-17 21:42:33 --> Database Driver Class Initialized
INFO - 2024-06-17 21:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:42:33 --> Controller Class Initialized
INFO - 2024-06-17 21:42:33 --> Final output sent to browser
DEBUG - 2024-06-17 21:42:33 --> Total execution time: 0.0303
INFO - 2024-06-17 21:43:35 --> Config Class Initialized
INFO - 2024-06-17 21:43:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:43:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:43:35 --> Utf8 Class Initialized
INFO - 2024-06-17 21:43:35 --> URI Class Initialized
INFO - 2024-06-17 21:43:35 --> Router Class Initialized
INFO - 2024-06-17 21:43:35 --> Output Class Initialized
INFO - 2024-06-17 21:43:35 --> Security Class Initialized
DEBUG - 2024-06-17 21:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:43:35 --> Input Class Initialized
INFO - 2024-06-17 21:43:35 --> Language Class Initialized
INFO - 2024-06-17 21:43:35 --> Language Class Initialized
INFO - 2024-06-17 21:43:35 --> Config Class Initialized
INFO - 2024-06-17 21:43:35 --> Loader Class Initialized
INFO - 2024-06-17 21:43:35 --> Helper loaded: url_helper
INFO - 2024-06-17 21:43:35 --> Helper loaded: file_helper
INFO - 2024-06-17 21:43:35 --> Helper loaded: form_helper
INFO - 2024-06-17 21:43:35 --> Helper loaded: my_helper
INFO - 2024-06-17 21:43:35 --> Database Driver Class Initialized
INFO - 2024-06-17 21:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:43:35 --> Controller Class Initialized
INFO - 2024-06-17 21:43:35 --> Final output sent to browser
DEBUG - 2024-06-17 21:43:35 --> Total execution time: 0.0944
INFO - 2024-06-17 21:43:37 --> Config Class Initialized
INFO - 2024-06-17 21:43:37 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:43:37 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:43:37 --> Utf8 Class Initialized
INFO - 2024-06-17 21:43:37 --> URI Class Initialized
INFO - 2024-06-17 21:43:37 --> Router Class Initialized
INFO - 2024-06-17 21:43:37 --> Output Class Initialized
INFO - 2024-06-17 21:43:37 --> Security Class Initialized
DEBUG - 2024-06-17 21:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:43:37 --> Input Class Initialized
INFO - 2024-06-17 21:43:37 --> Language Class Initialized
INFO - 2024-06-17 21:43:37 --> Language Class Initialized
INFO - 2024-06-17 21:43:37 --> Config Class Initialized
INFO - 2024-06-17 21:43:37 --> Loader Class Initialized
INFO - 2024-06-17 21:43:37 --> Helper loaded: url_helper
INFO - 2024-06-17 21:43:37 --> Helper loaded: file_helper
INFO - 2024-06-17 21:43:37 --> Helper loaded: form_helper
INFO - 2024-06-17 21:43:37 --> Helper loaded: my_helper
INFO - 2024-06-17 21:43:37 --> Database Driver Class Initialized
INFO - 2024-06-17 21:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:43:37 --> Controller Class Initialized
INFO - 2024-06-17 21:43:37 --> Final output sent to browser
DEBUG - 2024-06-17 21:43:37 --> Total execution time: 0.0347
INFO - 2024-06-17 21:44:08 --> Config Class Initialized
INFO - 2024-06-17 21:44:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:08 --> URI Class Initialized
INFO - 2024-06-17 21:44:08 --> Router Class Initialized
INFO - 2024-06-17 21:44:08 --> Output Class Initialized
INFO - 2024-06-17 21:44:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:08 --> Input Class Initialized
INFO - 2024-06-17 21:44:08 --> Language Class Initialized
INFO - 2024-06-17 21:44:08 --> Language Class Initialized
INFO - 2024-06-17 21:44:08 --> Config Class Initialized
INFO - 2024-06-17 21:44:08 --> Loader Class Initialized
INFO - 2024-06-17 21:44:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:08 --> Controller Class Initialized
INFO - 2024-06-17 21:44:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:08 --> Total execution time: 0.2019
INFO - 2024-06-17 21:44:11 --> Config Class Initialized
INFO - 2024-06-17 21:44:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:11 --> URI Class Initialized
INFO - 2024-06-17 21:44:11 --> Router Class Initialized
INFO - 2024-06-17 21:44:11 --> Output Class Initialized
INFO - 2024-06-17 21:44:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:11 --> Input Class Initialized
INFO - 2024-06-17 21:44:11 --> Language Class Initialized
INFO - 2024-06-17 21:44:11 --> Language Class Initialized
INFO - 2024-06-17 21:44:11 --> Config Class Initialized
INFO - 2024-06-17 21:44:11 --> Loader Class Initialized
INFO - 2024-06-17 21:44:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:11 --> Controller Class Initialized
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:44:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:44:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:44:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:11 --> Total execution time: 0.0735
INFO - 2024-06-17 21:44:14 --> Config Class Initialized
INFO - 2024-06-17 21:44:14 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:14 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:14 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:14 --> URI Class Initialized
INFO - 2024-06-17 21:44:14 --> Router Class Initialized
INFO - 2024-06-17 21:44:14 --> Output Class Initialized
INFO - 2024-06-17 21:44:14 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:14 --> Input Class Initialized
INFO - 2024-06-17 21:44:14 --> Language Class Initialized
INFO - 2024-06-17 21:44:14 --> Language Class Initialized
INFO - 2024-06-17 21:44:14 --> Config Class Initialized
INFO - 2024-06-17 21:44:14 --> Loader Class Initialized
INFO - 2024-06-17 21:44:14 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:14 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:14 --> Controller Class Initialized
DEBUG - 2024-06-17 21:44:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:44:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:44:14 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:14 --> Total execution time: 0.0304
INFO - 2024-06-17 21:44:14 --> Config Class Initialized
INFO - 2024-06-17 21:44:14 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:14 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:14 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:14 --> URI Class Initialized
INFO - 2024-06-17 21:44:14 --> Router Class Initialized
INFO - 2024-06-17 21:44:14 --> Output Class Initialized
INFO - 2024-06-17 21:44:14 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:14 --> Input Class Initialized
INFO - 2024-06-17 21:44:14 --> Language Class Initialized
INFO - 2024-06-17 21:44:14 --> Language Class Initialized
INFO - 2024-06-17 21:44:14 --> Config Class Initialized
INFO - 2024-06-17 21:44:14 --> Loader Class Initialized
INFO - 2024-06-17 21:44:14 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:14 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:14 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:14 --> Controller Class Initialized
INFO - 2024-06-17 21:44:15 --> Config Class Initialized
INFO - 2024-06-17 21:44:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:15 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:15 --> URI Class Initialized
INFO - 2024-06-17 21:44:15 --> Router Class Initialized
INFO - 2024-06-17 21:44:15 --> Output Class Initialized
INFO - 2024-06-17 21:44:15 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:15 --> Input Class Initialized
INFO - 2024-06-17 21:44:15 --> Language Class Initialized
INFO - 2024-06-17 21:44:15 --> Language Class Initialized
INFO - 2024-06-17 21:44:15 --> Config Class Initialized
INFO - 2024-06-17 21:44:15 --> Loader Class Initialized
INFO - 2024-06-17 21:44:15 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:15 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:15 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:15 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:15 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:15 --> Controller Class Initialized
INFO - 2024-06-17 21:44:15 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:15 --> Total execution time: 0.0297
INFO - 2024-06-17 21:44:34 --> Config Class Initialized
INFO - 2024-06-17 21:44:34 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:34 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:34 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:34 --> URI Class Initialized
INFO - 2024-06-17 21:44:34 --> Router Class Initialized
INFO - 2024-06-17 21:44:34 --> Output Class Initialized
INFO - 2024-06-17 21:44:34 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:34 --> Input Class Initialized
INFO - 2024-06-17 21:44:34 --> Language Class Initialized
INFO - 2024-06-17 21:44:34 --> Language Class Initialized
INFO - 2024-06-17 21:44:34 --> Config Class Initialized
INFO - 2024-06-17 21:44:34 --> Loader Class Initialized
INFO - 2024-06-17 21:44:34 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:34 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:34 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:34 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:34 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:34 --> Controller Class Initialized
INFO - 2024-06-17 21:44:34 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:34 --> Total execution time: 0.0465
INFO - 2024-06-17 21:44:39 --> Config Class Initialized
INFO - 2024-06-17 21:44:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:44:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:44:39 --> Utf8 Class Initialized
INFO - 2024-06-17 21:44:39 --> URI Class Initialized
INFO - 2024-06-17 21:44:39 --> Router Class Initialized
INFO - 2024-06-17 21:44:39 --> Output Class Initialized
INFO - 2024-06-17 21:44:39 --> Security Class Initialized
DEBUG - 2024-06-17 21:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:44:39 --> Input Class Initialized
INFO - 2024-06-17 21:44:39 --> Language Class Initialized
INFO - 2024-06-17 21:44:39 --> Language Class Initialized
INFO - 2024-06-17 21:44:39 --> Config Class Initialized
INFO - 2024-06-17 21:44:39 --> Loader Class Initialized
INFO - 2024-06-17 21:44:39 --> Helper loaded: url_helper
INFO - 2024-06-17 21:44:39 --> Helper loaded: file_helper
INFO - 2024-06-17 21:44:39 --> Helper loaded: form_helper
INFO - 2024-06-17 21:44:39 --> Helper loaded: my_helper
INFO - 2024-06-17 21:44:39 --> Database Driver Class Initialized
INFO - 2024-06-17 21:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:44:39 --> Controller Class Initialized
INFO - 2024-06-17 21:44:39 --> Final output sent to browser
DEBUG - 2024-06-17 21:44:39 --> Total execution time: 0.0284
INFO - 2024-06-17 21:45:16 --> Config Class Initialized
INFO - 2024-06-17 21:45:16 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:16 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:16 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:16 --> URI Class Initialized
INFO - 2024-06-17 21:45:16 --> Router Class Initialized
INFO - 2024-06-17 21:45:16 --> Output Class Initialized
INFO - 2024-06-17 21:45:16 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:16 --> Input Class Initialized
INFO - 2024-06-17 21:45:16 --> Language Class Initialized
INFO - 2024-06-17 21:45:16 --> Language Class Initialized
INFO - 2024-06-17 21:45:16 --> Config Class Initialized
INFO - 2024-06-17 21:45:16 --> Loader Class Initialized
INFO - 2024-06-17 21:45:16 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:16 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:16 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:16 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:16 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:16 --> Controller Class Initialized
INFO - 2024-06-17 21:45:16 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:16 --> Total execution time: 0.0379
INFO - 2024-06-17 21:45:20 --> Config Class Initialized
INFO - 2024-06-17 21:45:20 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:20 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:20 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:20 --> URI Class Initialized
INFO - 2024-06-17 21:45:20 --> Router Class Initialized
INFO - 2024-06-17 21:45:20 --> Output Class Initialized
INFO - 2024-06-17 21:45:20 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:20 --> Input Class Initialized
INFO - 2024-06-17 21:45:20 --> Language Class Initialized
INFO - 2024-06-17 21:45:20 --> Language Class Initialized
INFO - 2024-06-17 21:45:20 --> Config Class Initialized
INFO - 2024-06-17 21:45:20 --> Loader Class Initialized
INFO - 2024-06-17 21:45:20 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:20 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:20 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:20 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:20 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:20 --> Controller Class Initialized
INFO - 2024-06-17 21:45:20 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:20 --> Total execution time: 0.0281
INFO - 2024-06-17 21:45:21 --> Config Class Initialized
INFO - 2024-06-17 21:45:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:21 --> URI Class Initialized
INFO - 2024-06-17 21:45:21 --> Router Class Initialized
INFO - 2024-06-17 21:45:21 --> Output Class Initialized
INFO - 2024-06-17 21:45:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:21 --> Input Class Initialized
INFO - 2024-06-17 21:45:21 --> Language Class Initialized
INFO - 2024-06-17 21:45:21 --> Language Class Initialized
INFO - 2024-06-17 21:45:21 --> Config Class Initialized
INFO - 2024-06-17 21:45:21 --> Loader Class Initialized
INFO - 2024-06-17 21:45:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:21 --> Controller Class Initialized
INFO - 2024-06-17 21:45:21 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:21 --> Total execution time: 0.0278
INFO - 2024-06-17 21:45:23 --> Config Class Initialized
INFO - 2024-06-17 21:45:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:23 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:23 --> URI Class Initialized
INFO - 2024-06-17 21:45:23 --> Router Class Initialized
INFO - 2024-06-17 21:45:23 --> Output Class Initialized
INFO - 2024-06-17 21:45:23 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:23 --> Input Class Initialized
INFO - 2024-06-17 21:45:23 --> Language Class Initialized
INFO - 2024-06-17 21:45:23 --> Language Class Initialized
INFO - 2024-06-17 21:45:23 --> Config Class Initialized
INFO - 2024-06-17 21:45:23 --> Loader Class Initialized
INFO - 2024-06-17 21:45:23 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:23 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:23 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:23 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:23 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:23 --> Controller Class Initialized
INFO - 2024-06-17 21:45:23 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:23 --> Total execution time: 0.0536
INFO - 2024-06-17 21:45:34 --> Config Class Initialized
INFO - 2024-06-17 21:45:34 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:34 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:34 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:34 --> URI Class Initialized
INFO - 2024-06-17 21:45:34 --> Router Class Initialized
INFO - 2024-06-17 21:45:34 --> Output Class Initialized
INFO - 2024-06-17 21:45:34 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:34 --> Input Class Initialized
INFO - 2024-06-17 21:45:34 --> Language Class Initialized
INFO - 2024-06-17 21:45:34 --> Language Class Initialized
INFO - 2024-06-17 21:45:34 --> Config Class Initialized
INFO - 2024-06-17 21:45:34 --> Loader Class Initialized
INFO - 2024-06-17 21:45:34 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:34 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:34 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:34 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:34 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:34 --> Controller Class Initialized
INFO - 2024-06-17 21:45:34 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:34 --> Total execution time: 0.1960
INFO - 2024-06-17 21:45:37 --> Config Class Initialized
INFO - 2024-06-17 21:45:37 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:37 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:37 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:37 --> URI Class Initialized
INFO - 2024-06-17 21:45:37 --> Router Class Initialized
INFO - 2024-06-17 21:45:37 --> Output Class Initialized
INFO - 2024-06-17 21:45:37 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:37 --> Input Class Initialized
INFO - 2024-06-17 21:45:37 --> Language Class Initialized
INFO - 2024-06-17 21:45:37 --> Language Class Initialized
INFO - 2024-06-17 21:45:37 --> Config Class Initialized
INFO - 2024-06-17 21:45:37 --> Loader Class Initialized
INFO - 2024-06-17 21:45:37 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:37 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:37 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:37 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:37 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:37 --> Controller Class Initialized
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:45:37 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:45:37 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:37 --> Total execution time: 0.0298
INFO - 2024-06-17 21:45:43 --> Config Class Initialized
INFO - 2024-06-17 21:45:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:43 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:43 --> URI Class Initialized
INFO - 2024-06-17 21:45:43 --> Router Class Initialized
INFO - 2024-06-17 21:45:43 --> Output Class Initialized
INFO - 2024-06-17 21:45:43 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:43 --> Input Class Initialized
INFO - 2024-06-17 21:45:43 --> Language Class Initialized
INFO - 2024-06-17 21:45:43 --> Language Class Initialized
INFO - 2024-06-17 21:45:43 --> Config Class Initialized
INFO - 2024-06-17 21:45:43 --> Loader Class Initialized
INFO - 2024-06-17 21:45:43 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:43 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:43 --> Controller Class Initialized
DEBUG - 2024-06-17 21:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:45:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:45:43 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:43 --> Total execution time: 0.0308
INFO - 2024-06-17 21:45:43 --> Config Class Initialized
INFO - 2024-06-17 21:45:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:43 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:43 --> URI Class Initialized
INFO - 2024-06-17 21:45:43 --> Router Class Initialized
INFO - 2024-06-17 21:45:43 --> Output Class Initialized
INFO - 2024-06-17 21:45:43 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:43 --> Input Class Initialized
INFO - 2024-06-17 21:45:43 --> Language Class Initialized
INFO - 2024-06-17 21:45:43 --> Language Class Initialized
INFO - 2024-06-17 21:45:43 --> Config Class Initialized
INFO - 2024-06-17 21:45:43 --> Loader Class Initialized
INFO - 2024-06-17 21:45:43 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:43 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:43 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:43 --> Controller Class Initialized
INFO - 2024-06-17 21:45:45 --> Config Class Initialized
INFO - 2024-06-17 21:45:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:45 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:45 --> URI Class Initialized
INFO - 2024-06-17 21:45:45 --> Router Class Initialized
INFO - 2024-06-17 21:45:45 --> Output Class Initialized
INFO - 2024-06-17 21:45:45 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:45 --> Input Class Initialized
INFO - 2024-06-17 21:45:45 --> Language Class Initialized
INFO - 2024-06-17 21:45:45 --> Language Class Initialized
INFO - 2024-06-17 21:45:45 --> Config Class Initialized
INFO - 2024-06-17 21:45:45 --> Loader Class Initialized
INFO - 2024-06-17 21:45:45 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:45 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:45 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:45 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:45 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:45 --> Controller Class Initialized
INFO - 2024-06-17 21:45:45 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:45 --> Total execution time: 0.0283
INFO - 2024-06-17 21:45:56 --> Config Class Initialized
INFO - 2024-06-17 21:45:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:56 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:56 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:56 --> URI Class Initialized
INFO - 2024-06-17 21:45:56 --> Router Class Initialized
INFO - 2024-06-17 21:45:56 --> Output Class Initialized
INFO - 2024-06-17 21:45:56 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:56 --> Input Class Initialized
INFO - 2024-06-17 21:45:56 --> Language Class Initialized
INFO - 2024-06-17 21:45:56 --> Language Class Initialized
INFO - 2024-06-17 21:45:56 --> Config Class Initialized
INFO - 2024-06-17 21:45:56 --> Loader Class Initialized
INFO - 2024-06-17 21:45:56 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:56 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:56 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:56 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:56 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:56 --> Controller Class Initialized
INFO - 2024-06-17 21:45:56 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:56 --> Total execution time: 0.0512
INFO - 2024-06-17 21:45:59 --> Config Class Initialized
INFO - 2024-06-17 21:45:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:45:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:45:59 --> Utf8 Class Initialized
INFO - 2024-06-17 21:45:59 --> URI Class Initialized
INFO - 2024-06-17 21:45:59 --> Router Class Initialized
INFO - 2024-06-17 21:45:59 --> Output Class Initialized
INFO - 2024-06-17 21:45:59 --> Security Class Initialized
DEBUG - 2024-06-17 21:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:45:59 --> Input Class Initialized
INFO - 2024-06-17 21:45:59 --> Language Class Initialized
INFO - 2024-06-17 21:45:59 --> Language Class Initialized
INFO - 2024-06-17 21:45:59 --> Config Class Initialized
INFO - 2024-06-17 21:45:59 --> Loader Class Initialized
INFO - 2024-06-17 21:45:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:45:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:45:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:45:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:45:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:45:59 --> Controller Class Initialized
INFO - 2024-06-17 21:45:59 --> Final output sent to browser
DEBUG - 2024-06-17 21:45:59 --> Total execution time: 0.0286
INFO - 2024-06-17 21:46:29 --> Config Class Initialized
INFO - 2024-06-17 21:46:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:29 --> URI Class Initialized
INFO - 2024-06-17 21:46:29 --> Router Class Initialized
INFO - 2024-06-17 21:46:29 --> Output Class Initialized
INFO - 2024-06-17 21:46:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:29 --> Input Class Initialized
INFO - 2024-06-17 21:46:29 --> Language Class Initialized
INFO - 2024-06-17 21:46:29 --> Language Class Initialized
INFO - 2024-06-17 21:46:29 --> Config Class Initialized
INFO - 2024-06-17 21:46:29 --> Loader Class Initialized
INFO - 2024-06-17 21:46:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:29 --> Controller Class Initialized
INFO - 2024-06-17 21:46:29 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:29 --> Total execution time: 0.0365
INFO - 2024-06-17 21:46:32 --> Config Class Initialized
INFO - 2024-06-17 21:46:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:32 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:32 --> URI Class Initialized
INFO - 2024-06-17 21:46:32 --> Router Class Initialized
INFO - 2024-06-17 21:46:32 --> Output Class Initialized
INFO - 2024-06-17 21:46:32 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:32 --> Input Class Initialized
INFO - 2024-06-17 21:46:32 --> Language Class Initialized
INFO - 2024-06-17 21:46:32 --> Language Class Initialized
INFO - 2024-06-17 21:46:32 --> Config Class Initialized
INFO - 2024-06-17 21:46:32 --> Loader Class Initialized
INFO - 2024-06-17 21:46:32 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:32 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:32 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:32 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:32 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:32 --> Controller Class Initialized
INFO - 2024-06-17 21:46:32 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:32 --> Total execution time: 0.0282
INFO - 2024-06-17 21:46:47 --> Config Class Initialized
INFO - 2024-06-17 21:46:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:47 --> URI Class Initialized
INFO - 2024-06-17 21:46:47 --> Router Class Initialized
INFO - 2024-06-17 21:46:47 --> Output Class Initialized
INFO - 2024-06-17 21:46:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:47 --> Input Class Initialized
INFO - 2024-06-17 21:46:47 --> Language Class Initialized
INFO - 2024-06-17 21:46:47 --> Language Class Initialized
INFO - 2024-06-17 21:46:47 --> Config Class Initialized
INFO - 2024-06-17 21:46:47 --> Loader Class Initialized
INFO - 2024-06-17 21:46:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:47 --> Controller Class Initialized
INFO - 2024-06-17 21:46:47 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:47 --> Total execution time: 0.0426
INFO - 2024-06-17 21:46:49 --> Config Class Initialized
INFO - 2024-06-17 21:46:49 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:49 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:49 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:49 --> URI Class Initialized
INFO - 2024-06-17 21:46:49 --> Router Class Initialized
INFO - 2024-06-17 21:46:49 --> Output Class Initialized
INFO - 2024-06-17 21:46:49 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:49 --> Input Class Initialized
INFO - 2024-06-17 21:46:49 --> Language Class Initialized
INFO - 2024-06-17 21:46:49 --> Language Class Initialized
INFO - 2024-06-17 21:46:49 --> Config Class Initialized
INFO - 2024-06-17 21:46:49 --> Loader Class Initialized
INFO - 2024-06-17 21:46:49 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:49 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:49 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:49 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:49 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:49 --> Controller Class Initialized
INFO - 2024-06-17 21:46:49 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:49 --> Total execution time: 0.0270
INFO - 2024-06-17 21:46:53 --> Config Class Initialized
INFO - 2024-06-17 21:46:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:53 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:53 --> URI Class Initialized
INFO - 2024-06-17 21:46:53 --> Router Class Initialized
INFO - 2024-06-17 21:46:53 --> Output Class Initialized
INFO - 2024-06-17 21:46:53 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:53 --> Input Class Initialized
INFO - 2024-06-17 21:46:53 --> Language Class Initialized
INFO - 2024-06-17 21:46:53 --> Language Class Initialized
INFO - 2024-06-17 21:46:53 --> Config Class Initialized
INFO - 2024-06-17 21:46:53 --> Loader Class Initialized
INFO - 2024-06-17 21:46:53 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:53 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:53 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:53 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:53 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:53 --> Controller Class Initialized
INFO - 2024-06-17 21:46:53 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:53 --> Total execution time: 0.0404
INFO - 2024-06-17 21:46:54 --> Config Class Initialized
INFO - 2024-06-17 21:46:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:54 --> URI Class Initialized
INFO - 2024-06-17 21:46:54 --> Router Class Initialized
INFO - 2024-06-17 21:46:54 --> Output Class Initialized
INFO - 2024-06-17 21:46:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:54 --> Input Class Initialized
INFO - 2024-06-17 21:46:54 --> Language Class Initialized
INFO - 2024-06-17 21:46:54 --> Language Class Initialized
INFO - 2024-06-17 21:46:54 --> Config Class Initialized
INFO - 2024-06-17 21:46:54 --> Loader Class Initialized
INFO - 2024-06-17 21:46:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:54 --> Controller Class Initialized
INFO - 2024-06-17 21:46:54 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:54 --> Total execution time: 0.0298
INFO - 2024-06-17 21:46:56 --> Config Class Initialized
INFO - 2024-06-17 21:46:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:46:56 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:46:56 --> Utf8 Class Initialized
INFO - 2024-06-17 21:46:56 --> URI Class Initialized
INFO - 2024-06-17 21:46:56 --> Router Class Initialized
INFO - 2024-06-17 21:46:56 --> Output Class Initialized
INFO - 2024-06-17 21:46:56 --> Security Class Initialized
DEBUG - 2024-06-17 21:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:46:56 --> Input Class Initialized
INFO - 2024-06-17 21:46:56 --> Language Class Initialized
INFO - 2024-06-17 21:46:56 --> Language Class Initialized
INFO - 2024-06-17 21:46:56 --> Config Class Initialized
INFO - 2024-06-17 21:46:56 --> Loader Class Initialized
INFO - 2024-06-17 21:46:56 --> Helper loaded: url_helper
INFO - 2024-06-17 21:46:56 --> Helper loaded: file_helper
INFO - 2024-06-17 21:46:56 --> Helper loaded: form_helper
INFO - 2024-06-17 21:46:56 --> Helper loaded: my_helper
INFO - 2024-06-17 21:46:56 --> Database Driver Class Initialized
INFO - 2024-06-17 21:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:46:56 --> Controller Class Initialized
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:46:56 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:46:56 --> Final output sent to browser
DEBUG - 2024-06-17 21:46:56 --> Total execution time: 0.0406
INFO - 2024-06-17 21:47:07 --> Config Class Initialized
INFO - 2024-06-17 21:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:47:07 --> Utf8 Class Initialized
INFO - 2024-06-17 21:47:07 --> URI Class Initialized
INFO - 2024-06-17 21:47:07 --> Router Class Initialized
INFO - 2024-06-17 21:47:07 --> Output Class Initialized
INFO - 2024-06-17 21:47:07 --> Security Class Initialized
DEBUG - 2024-06-17 21:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:47:07 --> Input Class Initialized
INFO - 2024-06-17 21:47:07 --> Language Class Initialized
INFO - 2024-06-17 21:47:07 --> Language Class Initialized
INFO - 2024-06-17 21:47:07 --> Config Class Initialized
INFO - 2024-06-17 21:47:07 --> Loader Class Initialized
INFO - 2024-06-17 21:47:07 --> Helper loaded: url_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: file_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: form_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: my_helper
INFO - 2024-06-17 21:47:07 --> Database Driver Class Initialized
INFO - 2024-06-17 21:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:47:07 --> Controller Class Initialized
DEBUG - 2024-06-17 21:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:47:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:47:07 --> Final output sent to browser
DEBUG - 2024-06-17 21:47:07 --> Total execution time: 0.0315
INFO - 2024-06-17 21:47:07 --> Config Class Initialized
INFO - 2024-06-17 21:47:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:47:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:47:07 --> Utf8 Class Initialized
INFO - 2024-06-17 21:47:07 --> URI Class Initialized
INFO - 2024-06-17 21:47:07 --> Router Class Initialized
INFO - 2024-06-17 21:47:07 --> Output Class Initialized
INFO - 2024-06-17 21:47:07 --> Security Class Initialized
DEBUG - 2024-06-17 21:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:47:07 --> Input Class Initialized
INFO - 2024-06-17 21:47:07 --> Language Class Initialized
INFO - 2024-06-17 21:47:07 --> Language Class Initialized
INFO - 2024-06-17 21:47:07 --> Config Class Initialized
INFO - 2024-06-17 21:47:07 --> Loader Class Initialized
INFO - 2024-06-17 21:47:07 --> Helper loaded: url_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: file_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: form_helper
INFO - 2024-06-17 21:47:07 --> Helper loaded: my_helper
INFO - 2024-06-17 21:47:07 --> Database Driver Class Initialized
INFO - 2024-06-17 21:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:47:07 --> Controller Class Initialized
INFO - 2024-06-17 21:47:17 --> Config Class Initialized
INFO - 2024-06-17 21:47:17 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:47:17 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:47:17 --> Utf8 Class Initialized
INFO - 2024-06-17 21:47:17 --> URI Class Initialized
INFO - 2024-06-17 21:47:17 --> Router Class Initialized
INFO - 2024-06-17 21:47:17 --> Output Class Initialized
INFO - 2024-06-17 21:47:17 --> Security Class Initialized
DEBUG - 2024-06-17 21:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:47:17 --> Input Class Initialized
INFO - 2024-06-17 21:47:17 --> Language Class Initialized
INFO - 2024-06-17 21:47:17 --> Language Class Initialized
INFO - 2024-06-17 21:47:17 --> Config Class Initialized
INFO - 2024-06-17 21:47:17 --> Loader Class Initialized
INFO - 2024-06-17 21:47:17 --> Helper loaded: url_helper
INFO - 2024-06-17 21:47:17 --> Helper loaded: file_helper
INFO - 2024-06-17 21:47:17 --> Helper loaded: form_helper
INFO - 2024-06-17 21:47:17 --> Helper loaded: my_helper
INFO - 2024-06-17 21:47:17 --> Database Driver Class Initialized
INFO - 2024-06-17 21:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:47:17 --> Controller Class Initialized
INFO - 2024-06-17 21:47:17 --> Final output sent to browser
DEBUG - 2024-06-17 21:47:17 --> Total execution time: 0.0347
INFO - 2024-06-17 21:47:43 --> Config Class Initialized
INFO - 2024-06-17 21:47:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:47:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:47:43 --> Utf8 Class Initialized
INFO - 2024-06-17 21:47:43 --> URI Class Initialized
INFO - 2024-06-17 21:47:43 --> Router Class Initialized
INFO - 2024-06-17 21:47:43 --> Output Class Initialized
INFO - 2024-06-17 21:47:43 --> Security Class Initialized
DEBUG - 2024-06-17 21:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:47:43 --> Input Class Initialized
INFO - 2024-06-17 21:47:43 --> Language Class Initialized
INFO - 2024-06-17 21:47:43 --> Language Class Initialized
INFO - 2024-06-17 21:47:43 --> Config Class Initialized
INFO - 2024-06-17 21:47:43 --> Loader Class Initialized
INFO - 2024-06-17 21:47:43 --> Helper loaded: url_helper
INFO - 2024-06-17 21:47:43 --> Helper loaded: file_helper
INFO - 2024-06-17 21:47:43 --> Helper loaded: form_helper
INFO - 2024-06-17 21:47:43 --> Helper loaded: my_helper
INFO - 2024-06-17 21:47:43 --> Database Driver Class Initialized
INFO - 2024-06-17 21:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:47:43 --> Controller Class Initialized
INFO - 2024-06-17 21:47:43 --> Final output sent to browser
DEBUG - 2024-06-17 21:47:43 --> Total execution time: 0.0808
INFO - 2024-06-17 21:47:46 --> Config Class Initialized
INFO - 2024-06-17 21:47:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:47:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:47:46 --> Utf8 Class Initialized
INFO - 2024-06-17 21:47:46 --> URI Class Initialized
INFO - 2024-06-17 21:47:46 --> Router Class Initialized
INFO - 2024-06-17 21:47:46 --> Output Class Initialized
INFO - 2024-06-17 21:47:46 --> Security Class Initialized
DEBUG - 2024-06-17 21:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:47:46 --> Input Class Initialized
INFO - 2024-06-17 21:47:46 --> Language Class Initialized
INFO - 2024-06-17 21:47:46 --> Language Class Initialized
INFO - 2024-06-17 21:47:46 --> Config Class Initialized
INFO - 2024-06-17 21:47:46 --> Loader Class Initialized
INFO - 2024-06-17 21:47:46 --> Helper loaded: url_helper
INFO - 2024-06-17 21:47:46 --> Helper loaded: file_helper
INFO - 2024-06-17 21:47:46 --> Helper loaded: form_helper
INFO - 2024-06-17 21:47:46 --> Helper loaded: my_helper
INFO - 2024-06-17 21:47:46 --> Database Driver Class Initialized
INFO - 2024-06-17 21:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:47:46 --> Controller Class Initialized
INFO - 2024-06-17 21:47:46 --> Final output sent to browser
DEBUG - 2024-06-17 21:47:46 --> Total execution time: 0.0285
INFO - 2024-06-17 21:48:00 --> Config Class Initialized
INFO - 2024-06-17 21:48:00 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:00 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:00 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:00 --> URI Class Initialized
INFO - 2024-06-17 21:48:00 --> Router Class Initialized
INFO - 2024-06-17 21:48:00 --> Output Class Initialized
INFO - 2024-06-17 21:48:00 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:00 --> Input Class Initialized
INFO - 2024-06-17 21:48:00 --> Language Class Initialized
INFO - 2024-06-17 21:48:00 --> Language Class Initialized
INFO - 2024-06-17 21:48:00 --> Config Class Initialized
INFO - 2024-06-17 21:48:00 --> Loader Class Initialized
INFO - 2024-06-17 21:48:00 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:00 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:00 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:00 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:00 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:00 --> Controller Class Initialized
INFO - 2024-06-17 21:48:00 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:00 --> Total execution time: 0.0465
INFO - 2024-06-17 21:48:03 --> Config Class Initialized
INFO - 2024-06-17 21:48:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:03 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:03 --> URI Class Initialized
INFO - 2024-06-17 21:48:03 --> Router Class Initialized
INFO - 2024-06-17 21:48:03 --> Output Class Initialized
INFO - 2024-06-17 21:48:03 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:03 --> Input Class Initialized
INFO - 2024-06-17 21:48:03 --> Language Class Initialized
INFO - 2024-06-17 21:48:03 --> Language Class Initialized
INFO - 2024-06-17 21:48:03 --> Config Class Initialized
INFO - 2024-06-17 21:48:03 --> Loader Class Initialized
INFO - 2024-06-17 21:48:03 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:03 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:03 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:03 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:03 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:03 --> Controller Class Initialized
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:48:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:48:03 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:03 --> Total execution time: 0.0552
INFO - 2024-06-17 21:48:09 --> Config Class Initialized
INFO - 2024-06-17 21:48:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:09 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:09 --> URI Class Initialized
INFO - 2024-06-17 21:48:09 --> Router Class Initialized
INFO - 2024-06-17 21:48:09 --> Output Class Initialized
INFO - 2024-06-17 21:48:09 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:09 --> Input Class Initialized
INFO - 2024-06-17 21:48:09 --> Language Class Initialized
INFO - 2024-06-17 21:48:09 --> Language Class Initialized
INFO - 2024-06-17 21:48:09 --> Config Class Initialized
INFO - 2024-06-17 21:48:09 --> Loader Class Initialized
INFO - 2024-06-17 21:48:09 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:09 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:09 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:09 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:09 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:09 --> Controller Class Initialized
DEBUG - 2024-06-17 21:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:48:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:48:09 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:09 --> Total execution time: 0.0278
INFO - 2024-06-17 21:48:10 --> Config Class Initialized
INFO - 2024-06-17 21:48:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:10 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:10 --> URI Class Initialized
INFO - 2024-06-17 21:48:10 --> Router Class Initialized
INFO - 2024-06-17 21:48:10 --> Output Class Initialized
INFO - 2024-06-17 21:48:10 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:10 --> Input Class Initialized
INFO - 2024-06-17 21:48:10 --> Language Class Initialized
INFO - 2024-06-17 21:48:10 --> Language Class Initialized
INFO - 2024-06-17 21:48:10 --> Config Class Initialized
INFO - 2024-06-17 21:48:10 --> Loader Class Initialized
INFO - 2024-06-17 21:48:10 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:10 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:10 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:10 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:10 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:10 --> Controller Class Initialized
INFO - 2024-06-17 21:48:11 --> Config Class Initialized
INFO - 2024-06-17 21:48:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:11 --> URI Class Initialized
INFO - 2024-06-17 21:48:11 --> Router Class Initialized
INFO - 2024-06-17 21:48:11 --> Output Class Initialized
INFO - 2024-06-17 21:48:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:11 --> Input Class Initialized
INFO - 2024-06-17 21:48:11 --> Language Class Initialized
INFO - 2024-06-17 21:48:11 --> Language Class Initialized
INFO - 2024-06-17 21:48:11 --> Config Class Initialized
INFO - 2024-06-17 21:48:11 --> Loader Class Initialized
INFO - 2024-06-17 21:48:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:11 --> Controller Class Initialized
INFO - 2024-06-17 21:48:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:11 --> Total execution time: 0.0275
INFO - 2024-06-17 21:48:41 --> Config Class Initialized
INFO - 2024-06-17 21:48:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:41 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:41 --> URI Class Initialized
INFO - 2024-06-17 21:48:41 --> Router Class Initialized
INFO - 2024-06-17 21:48:41 --> Output Class Initialized
INFO - 2024-06-17 21:48:41 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:41 --> Input Class Initialized
INFO - 2024-06-17 21:48:41 --> Language Class Initialized
INFO - 2024-06-17 21:48:41 --> Language Class Initialized
INFO - 2024-06-17 21:48:41 --> Config Class Initialized
INFO - 2024-06-17 21:48:41 --> Loader Class Initialized
INFO - 2024-06-17 21:48:41 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:41 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:41 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:41 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:41 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:41 --> Controller Class Initialized
INFO - 2024-06-17 21:48:41 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:41 --> Total execution time: 0.0487
INFO - 2024-06-17 21:48:44 --> Config Class Initialized
INFO - 2024-06-17 21:48:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:48:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:48:44 --> Utf8 Class Initialized
INFO - 2024-06-17 21:48:44 --> URI Class Initialized
INFO - 2024-06-17 21:48:44 --> Router Class Initialized
INFO - 2024-06-17 21:48:44 --> Output Class Initialized
INFO - 2024-06-17 21:48:44 --> Security Class Initialized
DEBUG - 2024-06-17 21:48:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:48:44 --> Input Class Initialized
INFO - 2024-06-17 21:48:44 --> Language Class Initialized
INFO - 2024-06-17 21:48:44 --> Language Class Initialized
INFO - 2024-06-17 21:48:44 --> Config Class Initialized
INFO - 2024-06-17 21:48:44 --> Loader Class Initialized
INFO - 2024-06-17 21:48:44 --> Helper loaded: url_helper
INFO - 2024-06-17 21:48:44 --> Helper loaded: file_helper
INFO - 2024-06-17 21:48:44 --> Helper loaded: form_helper
INFO - 2024-06-17 21:48:44 --> Helper loaded: my_helper
INFO - 2024-06-17 21:48:44 --> Database Driver Class Initialized
INFO - 2024-06-17 21:48:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:48:44 --> Controller Class Initialized
INFO - 2024-06-17 21:48:44 --> Final output sent to browser
DEBUG - 2024-06-17 21:48:44 --> Total execution time: 0.0303
INFO - 2024-06-17 21:49:17 --> Config Class Initialized
INFO - 2024-06-17 21:49:17 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:17 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:17 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:17 --> URI Class Initialized
INFO - 2024-06-17 21:49:17 --> Router Class Initialized
INFO - 2024-06-17 21:49:17 --> Output Class Initialized
INFO - 2024-06-17 21:49:17 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:17 --> Input Class Initialized
INFO - 2024-06-17 21:49:17 --> Language Class Initialized
INFO - 2024-06-17 21:49:17 --> Language Class Initialized
INFO - 2024-06-17 21:49:17 --> Config Class Initialized
INFO - 2024-06-17 21:49:17 --> Loader Class Initialized
INFO - 2024-06-17 21:49:17 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:17 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:17 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:17 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:17 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:17 --> Controller Class Initialized
INFO - 2024-06-17 21:49:17 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:17 --> Total execution time: 0.3815
INFO - 2024-06-17 21:49:19 --> Config Class Initialized
INFO - 2024-06-17 21:49:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:19 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:19 --> URI Class Initialized
INFO - 2024-06-17 21:49:19 --> Router Class Initialized
INFO - 2024-06-17 21:49:19 --> Output Class Initialized
INFO - 2024-06-17 21:49:19 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:19 --> Input Class Initialized
INFO - 2024-06-17 21:49:19 --> Language Class Initialized
INFO - 2024-06-17 21:49:19 --> Language Class Initialized
INFO - 2024-06-17 21:49:19 --> Config Class Initialized
INFO - 2024-06-17 21:49:19 --> Loader Class Initialized
INFO - 2024-06-17 21:49:19 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:19 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:19 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:19 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:19 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:19 --> Controller Class Initialized
INFO - 2024-06-17 21:49:19 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:19 --> Total execution time: 0.0381
INFO - 2024-06-17 21:49:21 --> Config Class Initialized
INFO - 2024-06-17 21:49:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:21 --> URI Class Initialized
INFO - 2024-06-17 21:49:21 --> Router Class Initialized
INFO - 2024-06-17 21:49:21 --> Output Class Initialized
INFO - 2024-06-17 21:49:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:21 --> Input Class Initialized
INFO - 2024-06-17 21:49:21 --> Language Class Initialized
INFO - 2024-06-17 21:49:21 --> Language Class Initialized
INFO - 2024-06-17 21:49:21 --> Config Class Initialized
INFO - 2024-06-17 21:49:21 --> Loader Class Initialized
INFO - 2024-06-17 21:49:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:21 --> Controller Class Initialized
INFO - 2024-06-17 21:49:21 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:21 --> Total execution time: 0.0388
INFO - 2024-06-17 21:49:23 --> Config Class Initialized
INFO - 2024-06-17 21:49:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:23 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:23 --> URI Class Initialized
INFO - 2024-06-17 21:49:23 --> Router Class Initialized
INFO - 2024-06-17 21:49:23 --> Output Class Initialized
INFO - 2024-06-17 21:49:23 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:23 --> Input Class Initialized
INFO - 2024-06-17 21:49:23 --> Language Class Initialized
INFO - 2024-06-17 21:49:23 --> Language Class Initialized
INFO - 2024-06-17 21:49:23 --> Config Class Initialized
INFO - 2024-06-17 21:49:23 --> Loader Class Initialized
INFO - 2024-06-17 21:49:23 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:23 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:23 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:23 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:23 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:23 --> Controller Class Initialized
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:49:23 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:49:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:49:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:49:23 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:23 --> Total execution time: 0.0310
INFO - 2024-06-17 21:49:29 --> Config Class Initialized
INFO - 2024-06-17 21:49:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:29 --> URI Class Initialized
INFO - 2024-06-17 21:49:29 --> Router Class Initialized
INFO - 2024-06-17 21:49:29 --> Output Class Initialized
INFO - 2024-06-17 21:49:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:29 --> Input Class Initialized
INFO - 2024-06-17 21:49:29 --> Language Class Initialized
INFO - 2024-06-17 21:49:29 --> Language Class Initialized
INFO - 2024-06-17 21:49:29 --> Config Class Initialized
INFO - 2024-06-17 21:49:29 --> Loader Class Initialized
INFO - 2024-06-17 21:49:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:29 --> Controller Class Initialized
DEBUG - 2024-06-17 21:49:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:49:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:49:29 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:29 --> Total execution time: 0.0304
INFO - 2024-06-17 21:49:29 --> Config Class Initialized
INFO - 2024-06-17 21:49:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:29 --> URI Class Initialized
INFO - 2024-06-17 21:49:29 --> Router Class Initialized
INFO - 2024-06-17 21:49:29 --> Output Class Initialized
INFO - 2024-06-17 21:49:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:29 --> Input Class Initialized
INFO - 2024-06-17 21:49:29 --> Language Class Initialized
INFO - 2024-06-17 21:49:29 --> Language Class Initialized
INFO - 2024-06-17 21:49:29 --> Config Class Initialized
INFO - 2024-06-17 21:49:29 --> Loader Class Initialized
INFO - 2024-06-17 21:49:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:29 --> Controller Class Initialized
INFO - 2024-06-17 21:49:33 --> Config Class Initialized
INFO - 2024-06-17 21:49:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:33 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:33 --> URI Class Initialized
INFO - 2024-06-17 21:49:33 --> Router Class Initialized
INFO - 2024-06-17 21:49:33 --> Output Class Initialized
INFO - 2024-06-17 21:49:33 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:33 --> Input Class Initialized
INFO - 2024-06-17 21:49:33 --> Language Class Initialized
INFO - 2024-06-17 21:49:33 --> Language Class Initialized
INFO - 2024-06-17 21:49:33 --> Config Class Initialized
INFO - 2024-06-17 21:49:33 --> Loader Class Initialized
INFO - 2024-06-17 21:49:33 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:33 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:33 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:33 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:33 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:33 --> Controller Class Initialized
INFO - 2024-06-17 21:49:33 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:33 --> Total execution time: 0.0315
INFO - 2024-06-17 21:49:52 --> Config Class Initialized
INFO - 2024-06-17 21:49:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:52 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:52 --> URI Class Initialized
INFO - 2024-06-17 21:49:52 --> Router Class Initialized
INFO - 2024-06-17 21:49:52 --> Output Class Initialized
INFO - 2024-06-17 21:49:52 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:52 --> Input Class Initialized
INFO - 2024-06-17 21:49:52 --> Language Class Initialized
INFO - 2024-06-17 21:49:52 --> Language Class Initialized
INFO - 2024-06-17 21:49:52 --> Config Class Initialized
INFO - 2024-06-17 21:49:52 --> Loader Class Initialized
INFO - 2024-06-17 21:49:52 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:52 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:52 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:52 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:52 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:52 --> Controller Class Initialized
INFO - 2024-06-17 21:49:52 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:52 --> Total execution time: 0.0505
INFO - 2024-06-17 21:49:54 --> Config Class Initialized
INFO - 2024-06-17 21:49:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:49:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:49:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:49:54 --> URI Class Initialized
INFO - 2024-06-17 21:49:54 --> Router Class Initialized
INFO - 2024-06-17 21:49:54 --> Output Class Initialized
INFO - 2024-06-17 21:49:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:49:54 --> Input Class Initialized
INFO - 2024-06-17 21:49:54 --> Language Class Initialized
INFO - 2024-06-17 21:49:54 --> Language Class Initialized
INFO - 2024-06-17 21:49:54 --> Config Class Initialized
INFO - 2024-06-17 21:49:54 --> Loader Class Initialized
INFO - 2024-06-17 21:49:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:49:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:49:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:49:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:49:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:49:54 --> Controller Class Initialized
INFO - 2024-06-17 21:49:54 --> Final output sent to browser
DEBUG - 2024-06-17 21:49:54 --> Total execution time: 0.0300
INFO - 2024-06-17 21:50:05 --> Config Class Initialized
INFO - 2024-06-17 21:50:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:05 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:05 --> URI Class Initialized
INFO - 2024-06-17 21:50:05 --> Router Class Initialized
INFO - 2024-06-17 21:50:05 --> Output Class Initialized
INFO - 2024-06-17 21:50:05 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:05 --> Input Class Initialized
INFO - 2024-06-17 21:50:05 --> Language Class Initialized
INFO - 2024-06-17 21:50:05 --> Language Class Initialized
INFO - 2024-06-17 21:50:05 --> Config Class Initialized
INFO - 2024-06-17 21:50:05 --> Loader Class Initialized
INFO - 2024-06-17 21:50:05 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:05 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:05 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:05 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:05 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:05 --> Controller Class Initialized
INFO - 2024-06-17 21:50:05 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:05 --> Total execution time: 0.0541
INFO - 2024-06-17 21:50:08 --> Config Class Initialized
INFO - 2024-06-17 21:50:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:08 --> URI Class Initialized
INFO - 2024-06-17 21:50:08 --> Router Class Initialized
INFO - 2024-06-17 21:50:08 --> Output Class Initialized
INFO - 2024-06-17 21:50:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:08 --> Input Class Initialized
INFO - 2024-06-17 21:50:08 --> Language Class Initialized
INFO - 2024-06-17 21:50:08 --> Language Class Initialized
INFO - 2024-06-17 21:50:08 --> Config Class Initialized
INFO - 2024-06-17 21:50:08 --> Loader Class Initialized
INFO - 2024-06-17 21:50:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:08 --> Controller Class Initialized
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:50:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:50:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:50:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:08 --> Total execution time: 0.0320
INFO - 2024-06-17 21:50:13 --> Config Class Initialized
INFO - 2024-06-17 21:50:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:13 --> URI Class Initialized
INFO - 2024-06-17 21:50:13 --> Router Class Initialized
INFO - 2024-06-17 21:50:13 --> Output Class Initialized
INFO - 2024-06-17 21:50:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:13 --> Input Class Initialized
INFO - 2024-06-17 21:50:13 --> Language Class Initialized
INFO - 2024-06-17 21:50:13 --> Language Class Initialized
INFO - 2024-06-17 21:50:13 --> Config Class Initialized
INFO - 2024-06-17 21:50:13 --> Loader Class Initialized
INFO - 2024-06-17 21:50:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:13 --> Controller Class Initialized
DEBUG - 2024-06-17 21:50:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:50:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:50:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:13 --> Total execution time: 0.0312
INFO - 2024-06-17 21:50:13 --> Config Class Initialized
INFO - 2024-06-17 21:50:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:13 --> URI Class Initialized
INFO - 2024-06-17 21:50:13 --> Router Class Initialized
INFO - 2024-06-17 21:50:13 --> Output Class Initialized
INFO - 2024-06-17 21:50:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:13 --> Input Class Initialized
INFO - 2024-06-17 21:50:13 --> Language Class Initialized
INFO - 2024-06-17 21:50:13 --> Language Class Initialized
INFO - 2024-06-17 21:50:13 --> Config Class Initialized
INFO - 2024-06-17 21:50:13 --> Loader Class Initialized
INFO - 2024-06-17 21:50:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:13 --> Controller Class Initialized
INFO - 2024-06-17 21:50:15 --> Config Class Initialized
INFO - 2024-06-17 21:50:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:15 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:15 --> URI Class Initialized
INFO - 2024-06-17 21:50:15 --> Router Class Initialized
INFO - 2024-06-17 21:50:15 --> Output Class Initialized
INFO - 2024-06-17 21:50:15 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:15 --> Input Class Initialized
INFO - 2024-06-17 21:50:15 --> Language Class Initialized
INFO - 2024-06-17 21:50:15 --> Language Class Initialized
INFO - 2024-06-17 21:50:15 --> Config Class Initialized
INFO - 2024-06-17 21:50:15 --> Loader Class Initialized
INFO - 2024-06-17 21:50:15 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:15 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:15 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:15 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:15 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:15 --> Controller Class Initialized
INFO - 2024-06-17 21:50:15 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:15 --> Total execution time: 0.0313
INFO - 2024-06-17 21:50:33 --> Config Class Initialized
INFO - 2024-06-17 21:50:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:33 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:33 --> URI Class Initialized
INFO - 2024-06-17 21:50:33 --> Router Class Initialized
INFO - 2024-06-17 21:50:33 --> Output Class Initialized
INFO - 2024-06-17 21:50:33 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:33 --> Input Class Initialized
INFO - 2024-06-17 21:50:33 --> Language Class Initialized
INFO - 2024-06-17 21:50:33 --> Language Class Initialized
INFO - 2024-06-17 21:50:33 --> Config Class Initialized
INFO - 2024-06-17 21:50:33 --> Loader Class Initialized
INFO - 2024-06-17 21:50:33 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:33 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:33 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:33 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:33 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:33 --> Controller Class Initialized
INFO - 2024-06-17 21:50:33 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:33 --> Total execution time: 0.0354
INFO - 2024-06-17 21:50:52 --> Config Class Initialized
INFO - 2024-06-17 21:50:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:52 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:52 --> URI Class Initialized
INFO - 2024-06-17 21:50:52 --> Router Class Initialized
INFO - 2024-06-17 21:50:52 --> Output Class Initialized
INFO - 2024-06-17 21:50:52 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:52 --> Input Class Initialized
INFO - 2024-06-17 21:50:52 --> Language Class Initialized
INFO - 2024-06-17 21:50:52 --> Language Class Initialized
INFO - 2024-06-17 21:50:52 --> Config Class Initialized
INFO - 2024-06-17 21:50:52 --> Loader Class Initialized
INFO - 2024-06-17 21:50:52 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:52 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:52 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:52 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:52 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:52 --> Controller Class Initialized
INFO - 2024-06-17 21:50:52 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:52 --> Total execution time: 0.0970
INFO - 2024-06-17 21:50:54 --> Config Class Initialized
INFO - 2024-06-17 21:50:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:50:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:50:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:50:54 --> URI Class Initialized
INFO - 2024-06-17 21:50:54 --> Router Class Initialized
INFO - 2024-06-17 21:50:54 --> Output Class Initialized
INFO - 2024-06-17 21:50:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:50:54 --> Input Class Initialized
INFO - 2024-06-17 21:50:54 --> Language Class Initialized
INFO - 2024-06-17 21:50:54 --> Language Class Initialized
INFO - 2024-06-17 21:50:54 --> Config Class Initialized
INFO - 2024-06-17 21:50:54 --> Loader Class Initialized
INFO - 2024-06-17 21:50:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:50:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:50:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:50:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:50:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:50:54 --> Controller Class Initialized
INFO - 2024-06-17 21:50:54 --> Final output sent to browser
DEBUG - 2024-06-17 21:50:54 --> Total execution time: 0.0292
INFO - 2024-06-17 21:51:08 --> Config Class Initialized
INFO - 2024-06-17 21:51:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:08 --> URI Class Initialized
INFO - 2024-06-17 21:51:08 --> Router Class Initialized
INFO - 2024-06-17 21:51:08 --> Output Class Initialized
INFO - 2024-06-17 21:51:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:08 --> Input Class Initialized
INFO - 2024-06-17 21:51:08 --> Language Class Initialized
INFO - 2024-06-17 21:51:08 --> Language Class Initialized
INFO - 2024-06-17 21:51:08 --> Config Class Initialized
INFO - 2024-06-17 21:51:08 --> Loader Class Initialized
INFO - 2024-06-17 21:51:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:08 --> Controller Class Initialized
INFO - 2024-06-17 21:51:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:08 --> Total execution time: 0.0463
INFO - 2024-06-17 21:51:11 --> Config Class Initialized
INFO - 2024-06-17 21:51:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:11 --> URI Class Initialized
INFO - 2024-06-17 21:51:11 --> Router Class Initialized
INFO - 2024-06-17 21:51:11 --> Output Class Initialized
INFO - 2024-06-17 21:51:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:11 --> Input Class Initialized
INFO - 2024-06-17 21:51:11 --> Language Class Initialized
INFO - 2024-06-17 21:51:11 --> Language Class Initialized
INFO - 2024-06-17 21:51:11 --> Config Class Initialized
INFO - 2024-06-17 21:51:11 --> Loader Class Initialized
INFO - 2024-06-17 21:51:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:11 --> Controller Class Initialized
INFO - 2024-06-17 21:51:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:11 --> Total execution time: 0.0324
INFO - 2024-06-17 21:51:38 --> Config Class Initialized
INFO - 2024-06-17 21:51:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:38 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:38 --> URI Class Initialized
INFO - 2024-06-17 21:51:38 --> Router Class Initialized
INFO - 2024-06-17 21:51:38 --> Output Class Initialized
INFO - 2024-06-17 21:51:38 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:38 --> Input Class Initialized
INFO - 2024-06-17 21:51:38 --> Language Class Initialized
INFO - 2024-06-17 21:51:38 --> Language Class Initialized
INFO - 2024-06-17 21:51:38 --> Config Class Initialized
INFO - 2024-06-17 21:51:38 --> Loader Class Initialized
INFO - 2024-06-17 21:51:38 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:38 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:38 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:38 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:38 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:38 --> Controller Class Initialized
INFO - 2024-06-17 21:51:38 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:38 --> Total execution time: 0.0505
INFO - 2024-06-17 21:51:41 --> Config Class Initialized
INFO - 2024-06-17 21:51:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:41 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:41 --> URI Class Initialized
INFO - 2024-06-17 21:51:41 --> Router Class Initialized
INFO - 2024-06-17 21:51:41 --> Output Class Initialized
INFO - 2024-06-17 21:51:41 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:41 --> Input Class Initialized
INFO - 2024-06-17 21:51:41 --> Language Class Initialized
INFO - 2024-06-17 21:51:41 --> Language Class Initialized
INFO - 2024-06-17 21:51:41 --> Config Class Initialized
INFO - 2024-06-17 21:51:41 --> Loader Class Initialized
INFO - 2024-06-17 21:51:41 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:41 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:41 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:41 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:41 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:41 --> Controller Class Initialized
INFO - 2024-06-17 21:51:41 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:41 --> Total execution time: 0.0627
INFO - 2024-06-17 21:51:44 --> Config Class Initialized
INFO - 2024-06-17 21:51:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:44 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:44 --> URI Class Initialized
INFO - 2024-06-17 21:51:44 --> Router Class Initialized
INFO - 2024-06-17 21:51:44 --> Output Class Initialized
INFO - 2024-06-17 21:51:44 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:44 --> Input Class Initialized
INFO - 2024-06-17 21:51:44 --> Language Class Initialized
INFO - 2024-06-17 21:51:44 --> Language Class Initialized
INFO - 2024-06-17 21:51:44 --> Config Class Initialized
INFO - 2024-06-17 21:51:44 --> Loader Class Initialized
INFO - 2024-06-17 21:51:44 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:44 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:44 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:44 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:44 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:44 --> Controller Class Initialized
INFO - 2024-06-17 21:51:44 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:44 --> Total execution time: 0.0375
INFO - 2024-06-17 21:51:46 --> Config Class Initialized
INFO - 2024-06-17 21:51:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:46 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:46 --> URI Class Initialized
INFO - 2024-06-17 21:51:46 --> Router Class Initialized
INFO - 2024-06-17 21:51:46 --> Output Class Initialized
INFO - 2024-06-17 21:51:46 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:46 --> Input Class Initialized
INFO - 2024-06-17 21:51:46 --> Language Class Initialized
INFO - 2024-06-17 21:51:46 --> Language Class Initialized
INFO - 2024-06-17 21:51:46 --> Config Class Initialized
INFO - 2024-06-17 21:51:46 --> Loader Class Initialized
INFO - 2024-06-17 21:51:46 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:46 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:46 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:46 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:46 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:46 --> Controller Class Initialized
INFO - 2024-06-17 21:51:46 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:46 --> Total execution time: 0.0367
INFO - 2024-06-17 21:51:48 --> Config Class Initialized
INFO - 2024-06-17 21:51:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:51:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:51:48 --> Utf8 Class Initialized
INFO - 2024-06-17 21:51:48 --> URI Class Initialized
INFO - 2024-06-17 21:51:48 --> Router Class Initialized
INFO - 2024-06-17 21:51:48 --> Output Class Initialized
INFO - 2024-06-17 21:51:48 --> Security Class Initialized
DEBUG - 2024-06-17 21:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:51:48 --> Input Class Initialized
INFO - 2024-06-17 21:51:48 --> Language Class Initialized
INFO - 2024-06-17 21:51:48 --> Language Class Initialized
INFO - 2024-06-17 21:51:48 --> Config Class Initialized
INFO - 2024-06-17 21:51:48 --> Loader Class Initialized
INFO - 2024-06-17 21:51:48 --> Helper loaded: url_helper
INFO - 2024-06-17 21:51:48 --> Helper loaded: file_helper
INFO - 2024-06-17 21:51:48 --> Helper loaded: form_helper
INFO - 2024-06-17 21:51:48 --> Helper loaded: my_helper
INFO - 2024-06-17 21:51:48 --> Database Driver Class Initialized
INFO - 2024-06-17 21:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:51:48 --> Controller Class Initialized
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:51:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:51:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:51:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:51:48 --> Final output sent to browser
DEBUG - 2024-06-17 21:51:48 --> Total execution time: 0.0341
INFO - 2024-06-17 21:52:06 --> Config Class Initialized
INFO - 2024-06-17 21:52:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:06 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:06 --> URI Class Initialized
INFO - 2024-06-17 21:52:06 --> Router Class Initialized
INFO - 2024-06-17 21:52:06 --> Output Class Initialized
INFO - 2024-06-17 21:52:06 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:06 --> Input Class Initialized
INFO - 2024-06-17 21:52:06 --> Language Class Initialized
INFO - 2024-06-17 21:52:06 --> Language Class Initialized
INFO - 2024-06-17 21:52:06 --> Config Class Initialized
INFO - 2024-06-17 21:52:06 --> Loader Class Initialized
INFO - 2024-06-17 21:52:06 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:06 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:06 --> Controller Class Initialized
DEBUG - 2024-06-17 21:52:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:52:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:52:06 --> Final output sent to browser
DEBUG - 2024-06-17 21:52:06 --> Total execution time: 0.0292
INFO - 2024-06-17 21:52:06 --> Config Class Initialized
INFO - 2024-06-17 21:52:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:06 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:06 --> URI Class Initialized
INFO - 2024-06-17 21:52:06 --> Router Class Initialized
INFO - 2024-06-17 21:52:06 --> Output Class Initialized
INFO - 2024-06-17 21:52:06 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:06 --> Input Class Initialized
INFO - 2024-06-17 21:52:06 --> Language Class Initialized
INFO - 2024-06-17 21:52:06 --> Language Class Initialized
INFO - 2024-06-17 21:52:06 --> Config Class Initialized
INFO - 2024-06-17 21:52:06 --> Loader Class Initialized
INFO - 2024-06-17 21:52:06 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:06 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:06 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:06 --> Controller Class Initialized
INFO - 2024-06-17 21:52:09 --> Config Class Initialized
INFO - 2024-06-17 21:52:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:09 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:09 --> URI Class Initialized
INFO - 2024-06-17 21:52:09 --> Router Class Initialized
INFO - 2024-06-17 21:52:09 --> Output Class Initialized
INFO - 2024-06-17 21:52:09 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:09 --> Input Class Initialized
INFO - 2024-06-17 21:52:09 --> Language Class Initialized
INFO - 2024-06-17 21:52:09 --> Language Class Initialized
INFO - 2024-06-17 21:52:09 --> Config Class Initialized
INFO - 2024-06-17 21:52:09 --> Loader Class Initialized
INFO - 2024-06-17 21:52:09 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:09 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:09 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:09 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:09 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:09 --> Controller Class Initialized
INFO - 2024-06-17 21:52:09 --> Final output sent to browser
DEBUG - 2024-06-17 21:52:09 --> Total execution time: 0.0319
INFO - 2024-06-17 21:52:39 --> Config Class Initialized
INFO - 2024-06-17 21:52:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:39 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:39 --> URI Class Initialized
INFO - 2024-06-17 21:52:39 --> Router Class Initialized
INFO - 2024-06-17 21:52:39 --> Output Class Initialized
INFO - 2024-06-17 21:52:39 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:39 --> Input Class Initialized
INFO - 2024-06-17 21:52:39 --> Language Class Initialized
INFO - 2024-06-17 21:52:39 --> Language Class Initialized
INFO - 2024-06-17 21:52:39 --> Config Class Initialized
INFO - 2024-06-17 21:52:39 --> Loader Class Initialized
INFO - 2024-06-17 21:52:39 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:39 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:39 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:39 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:39 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:39 --> Controller Class Initialized
INFO - 2024-06-17 21:52:40 --> Final output sent to browser
DEBUG - 2024-06-17 21:52:40 --> Total execution time: 0.4403
INFO - 2024-06-17 21:52:41 --> Config Class Initialized
INFO - 2024-06-17 21:52:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:41 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:41 --> URI Class Initialized
INFO - 2024-06-17 21:52:41 --> Router Class Initialized
INFO - 2024-06-17 21:52:41 --> Output Class Initialized
INFO - 2024-06-17 21:52:41 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:41 --> Input Class Initialized
INFO - 2024-06-17 21:52:41 --> Language Class Initialized
INFO - 2024-06-17 21:52:41 --> Language Class Initialized
INFO - 2024-06-17 21:52:41 --> Config Class Initialized
INFO - 2024-06-17 21:52:41 --> Loader Class Initialized
INFO - 2024-06-17 21:52:41 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:41 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:41 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:41 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:41 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:42 --> Controller Class Initialized
INFO - 2024-06-17 21:52:42 --> Final output sent to browser
DEBUG - 2024-06-17 21:52:42 --> Total execution time: 0.2848
INFO - 2024-06-17 21:52:44 --> Config Class Initialized
INFO - 2024-06-17 21:52:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:52:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:52:44 --> Utf8 Class Initialized
INFO - 2024-06-17 21:52:44 --> URI Class Initialized
INFO - 2024-06-17 21:52:44 --> Router Class Initialized
INFO - 2024-06-17 21:52:44 --> Output Class Initialized
INFO - 2024-06-17 21:52:44 --> Security Class Initialized
DEBUG - 2024-06-17 21:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:52:44 --> Input Class Initialized
INFO - 2024-06-17 21:52:44 --> Language Class Initialized
INFO - 2024-06-17 21:52:44 --> Language Class Initialized
INFO - 2024-06-17 21:52:44 --> Config Class Initialized
INFO - 2024-06-17 21:52:44 --> Loader Class Initialized
INFO - 2024-06-17 21:52:44 --> Helper loaded: url_helper
INFO - 2024-06-17 21:52:44 --> Helper loaded: file_helper
INFO - 2024-06-17 21:52:44 --> Helper loaded: form_helper
INFO - 2024-06-17 21:52:44 --> Helper loaded: my_helper
INFO - 2024-06-17 21:52:44 --> Database Driver Class Initialized
INFO - 2024-06-17 21:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:52:44 --> Controller Class Initialized
INFO - 2024-06-17 21:52:44 --> Final output sent to browser
DEBUG - 2024-06-17 21:52:44 --> Total execution time: 0.1156
INFO - 2024-06-17 21:53:00 --> Config Class Initialized
INFO - 2024-06-17 21:53:00 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:00 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:00 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:00 --> URI Class Initialized
INFO - 2024-06-17 21:53:00 --> Router Class Initialized
INFO - 2024-06-17 21:53:00 --> Output Class Initialized
INFO - 2024-06-17 21:53:00 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:00 --> Input Class Initialized
INFO - 2024-06-17 21:53:01 --> Language Class Initialized
INFO - 2024-06-17 21:53:01 --> Language Class Initialized
INFO - 2024-06-17 21:53:01 --> Config Class Initialized
INFO - 2024-06-17 21:53:01 --> Loader Class Initialized
INFO - 2024-06-17 21:53:01 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:01 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:01 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:01 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:01 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:01 --> Controller Class Initialized
INFO - 2024-06-17 21:53:01 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:01 --> Total execution time: 0.3909
INFO - 2024-06-17 21:53:04 --> Config Class Initialized
INFO - 2024-06-17 21:53:04 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:04 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:04 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:04 --> URI Class Initialized
INFO - 2024-06-17 21:53:04 --> Router Class Initialized
INFO - 2024-06-17 21:53:04 --> Output Class Initialized
INFO - 2024-06-17 21:53:04 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:04 --> Input Class Initialized
INFO - 2024-06-17 21:53:04 --> Language Class Initialized
INFO - 2024-06-17 21:53:04 --> Language Class Initialized
INFO - 2024-06-17 21:53:04 --> Config Class Initialized
INFO - 2024-06-17 21:53:04 --> Loader Class Initialized
INFO - 2024-06-17 21:53:04 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:04 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:04 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:04 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:04 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:04 --> Controller Class Initialized
INFO - 2024-06-17 21:53:04 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:04 --> Total execution time: 0.2276
INFO - 2024-06-17 21:53:23 --> Config Class Initialized
INFO - 2024-06-17 21:53:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:23 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:23 --> URI Class Initialized
INFO - 2024-06-17 21:53:23 --> Router Class Initialized
INFO - 2024-06-17 21:53:23 --> Output Class Initialized
INFO - 2024-06-17 21:53:23 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:23 --> Input Class Initialized
INFO - 2024-06-17 21:53:23 --> Language Class Initialized
INFO - 2024-06-17 21:53:23 --> Language Class Initialized
INFO - 2024-06-17 21:53:23 --> Config Class Initialized
INFO - 2024-06-17 21:53:23 --> Loader Class Initialized
INFO - 2024-06-17 21:53:23 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:23 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:23 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:23 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:23 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:23 --> Controller Class Initialized
INFO - 2024-06-17 21:53:23 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:23 --> Total execution time: 0.2265
INFO - 2024-06-17 21:53:26 --> Config Class Initialized
INFO - 2024-06-17 21:53:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:26 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:26 --> URI Class Initialized
INFO - 2024-06-17 21:53:26 --> Router Class Initialized
INFO - 2024-06-17 21:53:26 --> Output Class Initialized
INFO - 2024-06-17 21:53:26 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:26 --> Input Class Initialized
INFO - 2024-06-17 21:53:26 --> Language Class Initialized
INFO - 2024-06-17 21:53:26 --> Language Class Initialized
INFO - 2024-06-17 21:53:26 --> Config Class Initialized
INFO - 2024-06-17 21:53:26 --> Loader Class Initialized
INFO - 2024-06-17 21:53:26 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:26 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:26 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:26 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:26 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:26 --> Controller Class Initialized
INFO - 2024-06-17 21:53:26 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:26 --> Total execution time: 0.1921
INFO - 2024-06-17 21:53:42 --> Config Class Initialized
INFO - 2024-06-17 21:53:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:42 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:42 --> URI Class Initialized
INFO - 2024-06-17 21:53:42 --> Router Class Initialized
INFO - 2024-06-17 21:53:42 --> Output Class Initialized
INFO - 2024-06-17 21:53:42 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:42 --> Input Class Initialized
INFO - 2024-06-17 21:53:42 --> Language Class Initialized
INFO - 2024-06-17 21:53:42 --> Language Class Initialized
INFO - 2024-06-17 21:53:42 --> Config Class Initialized
INFO - 2024-06-17 21:53:42 --> Loader Class Initialized
INFO - 2024-06-17 21:53:42 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:42 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:42 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:42 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:42 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:42 --> Controller Class Initialized
INFO - 2024-06-17 21:53:42 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:42 --> Total execution time: 0.2983
INFO - 2024-06-17 21:53:47 --> Config Class Initialized
INFO - 2024-06-17 21:53:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:47 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:47 --> URI Class Initialized
INFO - 2024-06-17 21:53:47 --> Router Class Initialized
INFO - 2024-06-17 21:53:47 --> Output Class Initialized
INFO - 2024-06-17 21:53:47 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:47 --> Input Class Initialized
INFO - 2024-06-17 21:53:47 --> Language Class Initialized
INFO - 2024-06-17 21:53:47 --> Language Class Initialized
INFO - 2024-06-17 21:53:47 --> Config Class Initialized
INFO - 2024-06-17 21:53:47 --> Loader Class Initialized
INFO - 2024-06-17 21:53:47 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:47 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:47 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:47 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:47 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:48 --> Controller Class Initialized
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:48 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:53:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:53:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:53:48 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:48 --> Total execution time: 0.8998
INFO - 2024-06-17 21:53:54 --> Config Class Initialized
INFO - 2024-06-17 21:53:54 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:54 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:54 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:54 --> URI Class Initialized
INFO - 2024-06-17 21:53:54 --> Router Class Initialized
INFO - 2024-06-17 21:53:54 --> Output Class Initialized
INFO - 2024-06-17 21:53:54 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:54 --> Input Class Initialized
INFO - 2024-06-17 21:53:54 --> Language Class Initialized
INFO - 2024-06-17 21:53:54 --> Language Class Initialized
INFO - 2024-06-17 21:53:54 --> Config Class Initialized
INFO - 2024-06-17 21:53:54 --> Loader Class Initialized
INFO - 2024-06-17 21:53:54 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:54 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:54 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:54 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:54 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:55 --> Controller Class Initialized
DEBUG - 2024-06-17 21:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:53:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:53:55 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:55 --> Total execution time: 0.1663
INFO - 2024-06-17 21:53:55 --> Config Class Initialized
INFO - 2024-06-17 21:53:55 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:55 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:55 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:55 --> URI Class Initialized
INFO - 2024-06-17 21:53:55 --> Router Class Initialized
INFO - 2024-06-17 21:53:55 --> Output Class Initialized
INFO - 2024-06-17 21:53:55 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:55 --> Input Class Initialized
INFO - 2024-06-17 21:53:55 --> Language Class Initialized
INFO - 2024-06-17 21:53:55 --> Language Class Initialized
INFO - 2024-06-17 21:53:55 --> Config Class Initialized
INFO - 2024-06-17 21:53:55 --> Loader Class Initialized
INFO - 2024-06-17 21:53:55 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:55 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:55 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:55 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:55 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:55 --> Controller Class Initialized
INFO - 2024-06-17 21:53:56 --> Config Class Initialized
INFO - 2024-06-17 21:53:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:57 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:57 --> URI Class Initialized
INFO - 2024-06-17 21:53:57 --> Router Class Initialized
INFO - 2024-06-17 21:53:57 --> Output Class Initialized
INFO - 2024-06-17 21:53:57 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:57 --> Input Class Initialized
INFO - 2024-06-17 21:53:57 --> Language Class Initialized
INFO - 2024-06-17 21:53:57 --> Language Class Initialized
INFO - 2024-06-17 21:53:57 --> Config Class Initialized
INFO - 2024-06-17 21:53:57 --> Loader Class Initialized
INFO - 2024-06-17 21:53:57 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:57 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:57 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:57 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:57 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:57 --> Controller Class Initialized
INFO - 2024-06-17 21:53:57 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:57 --> Total execution time: 0.2527
INFO - 2024-06-17 21:53:59 --> Config Class Initialized
INFO - 2024-06-17 21:53:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:53:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:53:59 --> Utf8 Class Initialized
INFO - 2024-06-17 21:53:59 --> URI Class Initialized
INFO - 2024-06-17 21:53:59 --> Router Class Initialized
INFO - 2024-06-17 21:53:59 --> Output Class Initialized
INFO - 2024-06-17 21:53:59 --> Security Class Initialized
DEBUG - 2024-06-17 21:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:53:59 --> Input Class Initialized
INFO - 2024-06-17 21:53:59 --> Language Class Initialized
INFO - 2024-06-17 21:53:59 --> Language Class Initialized
INFO - 2024-06-17 21:53:59 --> Config Class Initialized
INFO - 2024-06-17 21:53:59 --> Loader Class Initialized
INFO - 2024-06-17 21:53:59 --> Helper loaded: url_helper
INFO - 2024-06-17 21:53:59 --> Helper loaded: file_helper
INFO - 2024-06-17 21:53:59 --> Helper loaded: form_helper
INFO - 2024-06-17 21:53:59 --> Helper loaded: my_helper
INFO - 2024-06-17 21:53:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:53:59 --> Controller Class Initialized
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:53:59 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:53:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:53:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:53:59 --> Final output sent to browser
DEBUG - 2024-06-17 21:53:59 --> Total execution time: 0.0727
INFO - 2024-06-17 21:54:05 --> Config Class Initialized
INFO - 2024-06-17 21:54:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:05 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:05 --> URI Class Initialized
INFO - 2024-06-17 21:54:05 --> Router Class Initialized
INFO - 2024-06-17 21:54:05 --> Output Class Initialized
INFO - 2024-06-17 21:54:05 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:05 --> Input Class Initialized
INFO - 2024-06-17 21:54:05 --> Language Class Initialized
INFO - 2024-06-17 21:54:05 --> Language Class Initialized
INFO - 2024-06-17 21:54:05 --> Config Class Initialized
INFO - 2024-06-17 21:54:05 --> Loader Class Initialized
INFO - 2024-06-17 21:54:05 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:05 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:05 --> Controller Class Initialized
DEBUG - 2024-06-17 21:54:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:54:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:05 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:05 --> Total execution time: 0.1108
INFO - 2024-06-17 21:54:05 --> Config Class Initialized
INFO - 2024-06-17 21:54:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:05 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:05 --> URI Class Initialized
INFO - 2024-06-17 21:54:05 --> Router Class Initialized
INFO - 2024-06-17 21:54:05 --> Output Class Initialized
INFO - 2024-06-17 21:54:05 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:05 --> Input Class Initialized
INFO - 2024-06-17 21:54:05 --> Language Class Initialized
INFO - 2024-06-17 21:54:05 --> Language Class Initialized
INFO - 2024-06-17 21:54:05 --> Config Class Initialized
INFO - 2024-06-17 21:54:05 --> Loader Class Initialized
INFO - 2024-06-17 21:54:05 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:05 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:05 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:05 --> Controller Class Initialized
INFO - 2024-06-17 21:54:08 --> Config Class Initialized
INFO - 2024-06-17 21:54:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:08 --> URI Class Initialized
INFO - 2024-06-17 21:54:08 --> Router Class Initialized
INFO - 2024-06-17 21:54:08 --> Output Class Initialized
INFO - 2024-06-17 21:54:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:08 --> Input Class Initialized
INFO - 2024-06-17 21:54:08 --> Language Class Initialized
INFO - 2024-06-17 21:54:08 --> Language Class Initialized
INFO - 2024-06-17 21:54:08 --> Config Class Initialized
INFO - 2024-06-17 21:54:08 --> Loader Class Initialized
INFO - 2024-06-17 21:54:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:08 --> Controller Class Initialized
INFO - 2024-06-17 21:54:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:08 --> Total execution time: 0.3350
INFO - 2024-06-17 21:54:13 --> Config Class Initialized
INFO - 2024-06-17 21:54:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:13 --> URI Class Initialized
INFO - 2024-06-17 21:54:13 --> Router Class Initialized
INFO - 2024-06-17 21:54:13 --> Output Class Initialized
INFO - 2024-06-17 21:54:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:13 --> Input Class Initialized
INFO - 2024-06-17 21:54:13 --> Language Class Initialized
INFO - 2024-06-17 21:54:13 --> Language Class Initialized
INFO - 2024-06-17 21:54:13 --> Config Class Initialized
INFO - 2024-06-17 21:54:13 --> Loader Class Initialized
INFO - 2024-06-17 21:54:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:13 --> Controller Class Initialized
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:13 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:54:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:54:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:13 --> Total execution time: 0.1573
INFO - 2024-06-17 21:54:23 --> Config Class Initialized
INFO - 2024-06-17 21:54:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:23 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:23 --> URI Class Initialized
INFO - 2024-06-17 21:54:23 --> Router Class Initialized
INFO - 2024-06-17 21:54:23 --> Output Class Initialized
INFO - 2024-06-17 21:54:23 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:23 --> Input Class Initialized
INFO - 2024-06-17 21:54:23 --> Language Class Initialized
INFO - 2024-06-17 21:54:23 --> Language Class Initialized
INFO - 2024-06-17 21:54:23 --> Config Class Initialized
INFO - 2024-06-17 21:54:23 --> Loader Class Initialized
INFO - 2024-06-17 21:54:23 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:23 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:23 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:23 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:23 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:23 --> Controller Class Initialized
DEBUG - 2024-06-17 21:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:54:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:23 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:23 --> Total execution time: 0.1529
INFO - 2024-06-17 21:54:24 --> Config Class Initialized
INFO - 2024-06-17 21:54:24 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:24 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:24 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:24 --> URI Class Initialized
INFO - 2024-06-17 21:54:24 --> Router Class Initialized
INFO - 2024-06-17 21:54:24 --> Output Class Initialized
INFO - 2024-06-17 21:54:24 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:24 --> Input Class Initialized
INFO - 2024-06-17 21:54:24 --> Language Class Initialized
INFO - 2024-06-17 21:54:24 --> Language Class Initialized
INFO - 2024-06-17 21:54:24 --> Config Class Initialized
INFO - 2024-06-17 21:54:24 --> Loader Class Initialized
INFO - 2024-06-17 21:54:24 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:24 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:24 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:24 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:24 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:24 --> Controller Class Initialized
INFO - 2024-06-17 21:54:27 --> Config Class Initialized
INFO - 2024-06-17 21:54:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:27 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:27 --> URI Class Initialized
INFO - 2024-06-17 21:54:27 --> Router Class Initialized
INFO - 2024-06-17 21:54:27 --> Output Class Initialized
INFO - 2024-06-17 21:54:27 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:27 --> Input Class Initialized
INFO - 2024-06-17 21:54:27 --> Language Class Initialized
INFO - 2024-06-17 21:54:27 --> Language Class Initialized
INFO - 2024-06-17 21:54:27 --> Config Class Initialized
INFO - 2024-06-17 21:54:27 --> Loader Class Initialized
INFO - 2024-06-17 21:54:27 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:27 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:27 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:27 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:27 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:27 --> Controller Class Initialized
INFO - 2024-06-17 21:54:27 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:27 --> Total execution time: 0.2239
INFO - 2024-06-17 21:54:28 --> Config Class Initialized
INFO - 2024-06-17 21:54:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:29 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:29 --> URI Class Initialized
INFO - 2024-06-17 21:54:29 --> Router Class Initialized
INFO - 2024-06-17 21:54:29 --> Output Class Initialized
INFO - 2024-06-17 21:54:29 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:29 --> Input Class Initialized
INFO - 2024-06-17 21:54:29 --> Language Class Initialized
INFO - 2024-06-17 21:54:29 --> Language Class Initialized
INFO - 2024-06-17 21:54:29 --> Config Class Initialized
INFO - 2024-06-17 21:54:29 --> Loader Class Initialized
INFO - 2024-06-17 21:54:29 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:29 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:29 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:29 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:29 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:29 --> Controller Class Initialized
INFO - 2024-06-17 21:54:29 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:29 --> Total execution time: 0.4225
INFO - 2024-06-17 21:54:31 --> Config Class Initialized
INFO - 2024-06-17 21:54:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:31 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:31 --> URI Class Initialized
INFO - 2024-06-17 21:54:31 --> Router Class Initialized
INFO - 2024-06-17 21:54:31 --> Output Class Initialized
INFO - 2024-06-17 21:54:32 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:32 --> Input Class Initialized
INFO - 2024-06-17 21:54:32 --> Language Class Initialized
INFO - 2024-06-17 21:54:32 --> Language Class Initialized
INFO - 2024-06-17 21:54:32 --> Config Class Initialized
INFO - 2024-06-17 21:54:32 --> Loader Class Initialized
INFO - 2024-06-17 21:54:32 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:32 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:32 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:32 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:32 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:32 --> Controller Class Initialized
INFO - 2024-06-17 21:54:32 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:32 --> Total execution time: 0.3431
INFO - 2024-06-17 21:54:33 --> Config Class Initialized
INFO - 2024-06-17 21:54:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:33 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:33 --> URI Class Initialized
INFO - 2024-06-17 21:54:33 --> Router Class Initialized
INFO - 2024-06-17 21:54:33 --> Output Class Initialized
INFO - 2024-06-17 21:54:33 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:33 --> Input Class Initialized
INFO - 2024-06-17 21:54:33 --> Language Class Initialized
INFO - 2024-06-17 21:54:33 --> Language Class Initialized
INFO - 2024-06-17 21:54:33 --> Config Class Initialized
INFO - 2024-06-17 21:54:33 --> Loader Class Initialized
INFO - 2024-06-17 21:54:33 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:33 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:33 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:33 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:33 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:33 --> Controller Class Initialized
INFO - 2024-06-17 21:54:34 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:34 --> Total execution time: 0.2734
INFO - 2024-06-17 21:54:36 --> Config Class Initialized
INFO - 2024-06-17 21:54:36 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:36 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:36 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:36 --> URI Class Initialized
INFO - 2024-06-17 21:54:36 --> Router Class Initialized
INFO - 2024-06-17 21:54:36 --> Output Class Initialized
INFO - 2024-06-17 21:54:36 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:36 --> Input Class Initialized
INFO - 2024-06-17 21:54:36 --> Language Class Initialized
INFO - 2024-06-17 21:54:36 --> Language Class Initialized
INFO - 2024-06-17 21:54:36 --> Config Class Initialized
INFO - 2024-06-17 21:54:36 --> Loader Class Initialized
INFO - 2024-06-17 21:54:36 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:36 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:36 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:36 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:36 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:36 --> Controller Class Initialized
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:36 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:54:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:36 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:36 --> Total execution time: 0.1453
INFO - 2024-06-17 21:54:40 --> Config Class Initialized
INFO - 2024-06-17 21:54:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:40 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:40 --> URI Class Initialized
INFO - 2024-06-17 21:54:40 --> Router Class Initialized
INFO - 2024-06-17 21:54:40 --> Output Class Initialized
INFO - 2024-06-17 21:54:40 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:40 --> Input Class Initialized
INFO - 2024-06-17 21:54:40 --> Language Class Initialized
INFO - 2024-06-17 21:54:40 --> Language Class Initialized
INFO - 2024-06-17 21:54:40 --> Config Class Initialized
INFO - 2024-06-17 21:54:40 --> Loader Class Initialized
INFO - 2024-06-17 21:54:40 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:40 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:40 --> Controller Class Initialized
DEBUG - 2024-06-17 21:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:40 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:40 --> Total execution time: 0.3110
INFO - 2024-06-17 21:54:40 --> Config Class Initialized
INFO - 2024-06-17 21:54:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:40 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:40 --> URI Class Initialized
INFO - 2024-06-17 21:54:40 --> Router Class Initialized
INFO - 2024-06-17 21:54:40 --> Output Class Initialized
INFO - 2024-06-17 21:54:40 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:40 --> Input Class Initialized
INFO - 2024-06-17 21:54:40 --> Language Class Initialized
INFO - 2024-06-17 21:54:40 --> Language Class Initialized
INFO - 2024-06-17 21:54:40 --> Config Class Initialized
INFO - 2024-06-17 21:54:40 --> Loader Class Initialized
INFO - 2024-06-17 21:54:40 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:40 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:40 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:40 --> Controller Class Initialized
INFO - 2024-06-17 21:54:43 --> Config Class Initialized
INFO - 2024-06-17 21:54:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:43 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:43 --> URI Class Initialized
INFO - 2024-06-17 21:54:43 --> Router Class Initialized
INFO - 2024-06-17 21:54:43 --> Output Class Initialized
INFO - 2024-06-17 21:54:43 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:43 --> Input Class Initialized
INFO - 2024-06-17 21:54:43 --> Language Class Initialized
INFO - 2024-06-17 21:54:43 --> Language Class Initialized
INFO - 2024-06-17 21:54:43 --> Config Class Initialized
INFO - 2024-06-17 21:54:43 --> Loader Class Initialized
INFO - 2024-06-17 21:54:43 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:43 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:43 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:43 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:43 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:43 --> Controller Class Initialized
INFO - 2024-06-17 21:54:43 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:43 --> Total execution time: 0.3099
INFO - 2024-06-17 21:54:46 --> Config Class Initialized
INFO - 2024-06-17 21:54:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:46 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:46 --> URI Class Initialized
INFO - 2024-06-17 21:54:46 --> Router Class Initialized
INFO - 2024-06-17 21:54:46 --> Output Class Initialized
INFO - 2024-06-17 21:54:46 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:46 --> Input Class Initialized
INFO - 2024-06-17 21:54:46 --> Language Class Initialized
INFO - 2024-06-17 21:54:46 --> Language Class Initialized
INFO - 2024-06-17 21:54:46 --> Config Class Initialized
INFO - 2024-06-17 21:54:46 --> Loader Class Initialized
INFO - 2024-06-17 21:54:46 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:46 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:46 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:46 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:46 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:46 --> Controller Class Initialized
INFO - 2024-06-17 21:54:46 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:46 --> Total execution time: 0.3510
INFO - 2024-06-17 21:54:52 --> Config Class Initialized
INFO - 2024-06-17 21:54:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:52 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:52 --> URI Class Initialized
INFO - 2024-06-17 21:54:52 --> Router Class Initialized
INFO - 2024-06-17 21:54:52 --> Output Class Initialized
INFO - 2024-06-17 21:54:52 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:52 --> Input Class Initialized
INFO - 2024-06-17 21:54:52 --> Language Class Initialized
INFO - 2024-06-17 21:54:52 --> Language Class Initialized
INFO - 2024-06-17 21:54:52 --> Config Class Initialized
INFO - 2024-06-17 21:54:52 --> Loader Class Initialized
INFO - 2024-06-17 21:54:52 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:52 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:52 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:52 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:52 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:52 --> Controller Class Initialized
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:54:52 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:54:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:54:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:52 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:52 --> Total execution time: 0.2287
INFO - 2024-06-17 21:54:56 --> Config Class Initialized
INFO - 2024-06-17 21:54:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:56 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:56 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:56 --> URI Class Initialized
INFO - 2024-06-17 21:54:56 --> Router Class Initialized
INFO - 2024-06-17 21:54:56 --> Output Class Initialized
INFO - 2024-06-17 21:54:56 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:56 --> Input Class Initialized
INFO - 2024-06-17 21:54:56 --> Language Class Initialized
INFO - 2024-06-17 21:54:56 --> Language Class Initialized
INFO - 2024-06-17 21:54:56 --> Config Class Initialized
INFO - 2024-06-17 21:54:56 --> Loader Class Initialized
INFO - 2024-06-17 21:54:56 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:56 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:56 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:56 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:56 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:57 --> Controller Class Initialized
DEBUG - 2024-06-17 21:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:54:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:54:57 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:57 --> Total execution time: 0.3038
INFO - 2024-06-17 21:54:57 --> Config Class Initialized
INFO - 2024-06-17 21:54:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:57 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:57 --> URI Class Initialized
INFO - 2024-06-17 21:54:57 --> Router Class Initialized
INFO - 2024-06-17 21:54:57 --> Output Class Initialized
INFO - 2024-06-17 21:54:57 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:57 --> Input Class Initialized
INFO - 2024-06-17 21:54:57 --> Language Class Initialized
INFO - 2024-06-17 21:54:57 --> Language Class Initialized
INFO - 2024-06-17 21:54:57 --> Config Class Initialized
INFO - 2024-06-17 21:54:57 --> Loader Class Initialized
INFO - 2024-06-17 21:54:57 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:57 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:57 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:57 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:57 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:57 --> Controller Class Initialized
INFO - 2024-06-17 21:54:58 --> Config Class Initialized
INFO - 2024-06-17 21:54:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:54:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:54:58 --> Utf8 Class Initialized
INFO - 2024-06-17 21:54:58 --> URI Class Initialized
INFO - 2024-06-17 21:54:58 --> Router Class Initialized
INFO - 2024-06-17 21:54:58 --> Output Class Initialized
INFO - 2024-06-17 21:54:58 --> Security Class Initialized
DEBUG - 2024-06-17 21:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:54:58 --> Input Class Initialized
INFO - 2024-06-17 21:54:58 --> Language Class Initialized
INFO - 2024-06-17 21:54:58 --> Language Class Initialized
INFO - 2024-06-17 21:54:58 --> Config Class Initialized
INFO - 2024-06-17 21:54:58 --> Loader Class Initialized
INFO - 2024-06-17 21:54:58 --> Helper loaded: url_helper
INFO - 2024-06-17 21:54:58 --> Helper loaded: file_helper
INFO - 2024-06-17 21:54:58 --> Helper loaded: form_helper
INFO - 2024-06-17 21:54:58 --> Helper loaded: my_helper
INFO - 2024-06-17 21:54:59 --> Database Driver Class Initialized
INFO - 2024-06-17 21:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:54:59 --> Controller Class Initialized
INFO - 2024-06-17 21:54:59 --> Final output sent to browser
DEBUG - 2024-06-17 21:54:59 --> Total execution time: 0.1099
INFO - 2024-06-17 21:55:02 --> Config Class Initialized
INFO - 2024-06-17 21:55:02 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:02 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:02 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:02 --> URI Class Initialized
INFO - 2024-06-17 21:55:02 --> Router Class Initialized
INFO - 2024-06-17 21:55:02 --> Output Class Initialized
INFO - 2024-06-17 21:55:02 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:02 --> Input Class Initialized
INFO - 2024-06-17 21:55:02 --> Language Class Initialized
INFO - 2024-06-17 21:55:02 --> Language Class Initialized
INFO - 2024-06-17 21:55:02 --> Config Class Initialized
INFO - 2024-06-17 21:55:02 --> Loader Class Initialized
INFO - 2024-06-17 21:55:02 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:02 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:02 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:02 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:02 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:02 --> Controller Class Initialized
INFO - 2024-06-17 21:55:02 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:02 --> Total execution time: 0.1334
INFO - 2024-06-17 21:55:04 --> Config Class Initialized
INFO - 2024-06-17 21:55:04 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:04 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:04 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:04 --> URI Class Initialized
INFO - 2024-06-17 21:55:04 --> Router Class Initialized
INFO - 2024-06-17 21:55:04 --> Output Class Initialized
INFO - 2024-06-17 21:55:04 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:04 --> Input Class Initialized
INFO - 2024-06-17 21:55:04 --> Language Class Initialized
INFO - 2024-06-17 21:55:04 --> Language Class Initialized
INFO - 2024-06-17 21:55:04 --> Config Class Initialized
INFO - 2024-06-17 21:55:04 --> Loader Class Initialized
INFO - 2024-06-17 21:55:04 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:04 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:04 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:04 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:04 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:04 --> Controller Class Initialized
INFO - 2024-06-17 21:55:04 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:04 --> Total execution time: 0.1417
INFO - 2024-06-17 21:55:06 --> Config Class Initialized
INFO - 2024-06-17 21:55:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:06 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:06 --> URI Class Initialized
INFO - 2024-06-17 21:55:06 --> Router Class Initialized
INFO - 2024-06-17 21:55:06 --> Output Class Initialized
INFO - 2024-06-17 21:55:06 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:06 --> Input Class Initialized
INFO - 2024-06-17 21:55:06 --> Language Class Initialized
INFO - 2024-06-17 21:55:06 --> Language Class Initialized
INFO - 2024-06-17 21:55:06 --> Config Class Initialized
INFO - 2024-06-17 21:55:06 --> Loader Class Initialized
INFO - 2024-06-17 21:55:06 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:06 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:06 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:06 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:06 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:06 --> Controller Class Initialized
INFO - 2024-06-17 21:55:06 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:06 --> Total execution time: 0.1652
INFO - 2024-06-17 21:55:08 --> Config Class Initialized
INFO - 2024-06-17 21:55:08 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:08 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:08 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:08 --> URI Class Initialized
INFO - 2024-06-17 21:55:08 --> Router Class Initialized
INFO - 2024-06-17 21:55:08 --> Output Class Initialized
INFO - 2024-06-17 21:55:08 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:08 --> Input Class Initialized
INFO - 2024-06-17 21:55:08 --> Language Class Initialized
INFO - 2024-06-17 21:55:08 --> Language Class Initialized
INFO - 2024-06-17 21:55:08 --> Config Class Initialized
INFO - 2024-06-17 21:55:08 --> Loader Class Initialized
INFO - 2024-06-17 21:55:08 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:08 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:08 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:08 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:08 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:08 --> Controller Class Initialized
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:08 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:55:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:08 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:08 --> Total execution time: 0.1137
INFO - 2024-06-17 21:55:11 --> Config Class Initialized
INFO - 2024-06-17 21:55:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:11 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:11 --> URI Class Initialized
INFO - 2024-06-17 21:55:11 --> Router Class Initialized
INFO - 2024-06-17 21:55:11 --> Output Class Initialized
INFO - 2024-06-17 21:55:11 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:11 --> Input Class Initialized
INFO - 2024-06-17 21:55:11 --> Language Class Initialized
INFO - 2024-06-17 21:55:11 --> Language Class Initialized
INFO - 2024-06-17 21:55:11 --> Config Class Initialized
INFO - 2024-06-17 21:55:11 --> Loader Class Initialized
INFO - 2024-06-17 21:55:11 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:11 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:11 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:11 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:11 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:11 --> Controller Class Initialized
DEBUG - 2024-06-17 21:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:55:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:11 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:11 --> Total execution time: 0.2045
INFO - 2024-06-17 21:55:12 --> Config Class Initialized
INFO - 2024-06-17 21:55:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:12 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:12 --> URI Class Initialized
INFO - 2024-06-17 21:55:12 --> Router Class Initialized
INFO - 2024-06-17 21:55:12 --> Output Class Initialized
INFO - 2024-06-17 21:55:12 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:12 --> Input Class Initialized
INFO - 2024-06-17 21:55:12 --> Language Class Initialized
INFO - 2024-06-17 21:55:12 --> Language Class Initialized
INFO - 2024-06-17 21:55:12 --> Config Class Initialized
INFO - 2024-06-17 21:55:12 --> Loader Class Initialized
INFO - 2024-06-17 21:55:12 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:12 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:12 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:12 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:12 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:12 --> Controller Class Initialized
INFO - 2024-06-17 21:55:13 --> Config Class Initialized
INFO - 2024-06-17 21:55:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:13 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:13 --> URI Class Initialized
INFO - 2024-06-17 21:55:13 --> Router Class Initialized
INFO - 2024-06-17 21:55:13 --> Output Class Initialized
INFO - 2024-06-17 21:55:13 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:13 --> Input Class Initialized
INFO - 2024-06-17 21:55:13 --> Language Class Initialized
INFO - 2024-06-17 21:55:13 --> Language Class Initialized
INFO - 2024-06-17 21:55:13 --> Config Class Initialized
INFO - 2024-06-17 21:55:13 --> Loader Class Initialized
INFO - 2024-06-17 21:55:13 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:13 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:13 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:13 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:13 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:13 --> Controller Class Initialized
INFO - 2024-06-17 21:55:13 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:13 --> Total execution time: 0.1182
INFO - 2024-06-17 21:55:15 --> Config Class Initialized
INFO - 2024-06-17 21:55:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:15 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:15 --> URI Class Initialized
INFO - 2024-06-17 21:55:15 --> Router Class Initialized
INFO - 2024-06-17 21:55:15 --> Output Class Initialized
INFO - 2024-06-17 21:55:15 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:15 --> Input Class Initialized
INFO - 2024-06-17 21:55:15 --> Language Class Initialized
INFO - 2024-06-17 21:55:15 --> Language Class Initialized
INFO - 2024-06-17 21:55:15 --> Config Class Initialized
INFO - 2024-06-17 21:55:15 --> Loader Class Initialized
INFO - 2024-06-17 21:55:15 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:15 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:15 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:15 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:15 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:15 --> Controller Class Initialized
INFO - 2024-06-17 21:55:16 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:16 --> Total execution time: 0.3538
INFO - 2024-06-17 21:55:18 --> Config Class Initialized
INFO - 2024-06-17 21:55:18 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:18 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:18 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:19 --> URI Class Initialized
INFO - 2024-06-17 21:55:19 --> Router Class Initialized
INFO - 2024-06-17 21:55:19 --> Output Class Initialized
INFO - 2024-06-17 21:55:19 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:19 --> Input Class Initialized
INFO - 2024-06-17 21:55:19 --> Language Class Initialized
INFO - 2024-06-17 21:55:19 --> Language Class Initialized
INFO - 2024-06-17 21:55:19 --> Config Class Initialized
INFO - 2024-06-17 21:55:19 --> Loader Class Initialized
INFO - 2024-06-17 21:55:19 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:19 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:19 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:19 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:19 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:19 --> Controller Class Initialized
INFO - 2024-06-17 21:55:19 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:19 --> Total execution time: 0.4806
INFO - 2024-06-17 21:55:21 --> Config Class Initialized
INFO - 2024-06-17 21:55:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:21 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:21 --> URI Class Initialized
INFO - 2024-06-17 21:55:21 --> Router Class Initialized
INFO - 2024-06-17 21:55:21 --> Output Class Initialized
INFO - 2024-06-17 21:55:21 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:21 --> Input Class Initialized
INFO - 2024-06-17 21:55:21 --> Language Class Initialized
INFO - 2024-06-17 21:55:21 --> Language Class Initialized
INFO - 2024-06-17 21:55:21 --> Config Class Initialized
INFO - 2024-06-17 21:55:21 --> Loader Class Initialized
INFO - 2024-06-17 21:55:21 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:21 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:21 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:21 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:21 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:21 --> Controller Class Initialized
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:21 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:55:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:21 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:21 --> Total execution time: 0.1335
INFO - 2024-06-17 21:55:25 --> Config Class Initialized
INFO - 2024-06-17 21:55:25 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:25 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:25 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:25 --> URI Class Initialized
INFO - 2024-06-17 21:55:25 --> Router Class Initialized
INFO - 2024-06-17 21:55:25 --> Output Class Initialized
INFO - 2024-06-17 21:55:25 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:25 --> Input Class Initialized
INFO - 2024-06-17 21:55:25 --> Language Class Initialized
INFO - 2024-06-17 21:55:25 --> Language Class Initialized
INFO - 2024-06-17 21:55:25 --> Config Class Initialized
INFO - 2024-06-17 21:55:25 --> Loader Class Initialized
INFO - 2024-06-17 21:55:25 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:25 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:25 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:25 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:25 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:25 --> Controller Class Initialized
DEBUG - 2024-06-17 21:55:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:55:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:25 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:25 --> Total execution time: 0.0335
INFO - 2024-06-17 21:55:26 --> Config Class Initialized
INFO - 2024-06-17 21:55:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:26 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:26 --> URI Class Initialized
INFO - 2024-06-17 21:55:26 --> Router Class Initialized
INFO - 2024-06-17 21:55:26 --> Output Class Initialized
INFO - 2024-06-17 21:55:26 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:26 --> Input Class Initialized
INFO - 2024-06-17 21:55:26 --> Language Class Initialized
INFO - 2024-06-17 21:55:26 --> Language Class Initialized
INFO - 2024-06-17 21:55:26 --> Config Class Initialized
INFO - 2024-06-17 21:55:26 --> Loader Class Initialized
INFO - 2024-06-17 21:55:26 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:26 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:26 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:26 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:26 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:26 --> Controller Class Initialized
INFO - 2024-06-17 21:55:27 --> Config Class Initialized
INFO - 2024-06-17 21:55:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:27 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:27 --> URI Class Initialized
INFO - 2024-06-17 21:55:27 --> Router Class Initialized
INFO - 2024-06-17 21:55:27 --> Output Class Initialized
INFO - 2024-06-17 21:55:27 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:27 --> Input Class Initialized
INFO - 2024-06-17 21:55:27 --> Language Class Initialized
INFO - 2024-06-17 21:55:27 --> Language Class Initialized
INFO - 2024-06-17 21:55:27 --> Config Class Initialized
INFO - 2024-06-17 21:55:27 --> Loader Class Initialized
INFO - 2024-06-17 21:55:27 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:27 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:27 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:27 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:27 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:27 --> Controller Class Initialized
INFO - 2024-06-17 21:55:27 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:27 --> Total execution time: 0.0383
INFO - 2024-06-17 21:55:30 --> Config Class Initialized
INFO - 2024-06-17 21:55:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:30 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:30 --> URI Class Initialized
INFO - 2024-06-17 21:55:30 --> Router Class Initialized
INFO - 2024-06-17 21:55:30 --> Output Class Initialized
INFO - 2024-06-17 21:55:30 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:30 --> Input Class Initialized
INFO - 2024-06-17 21:55:30 --> Language Class Initialized
INFO - 2024-06-17 21:55:30 --> Language Class Initialized
INFO - 2024-06-17 21:55:30 --> Config Class Initialized
INFO - 2024-06-17 21:55:30 --> Loader Class Initialized
INFO - 2024-06-17 21:55:30 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:30 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:30 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:30 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:30 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:30 --> Controller Class Initialized
INFO - 2024-06-17 21:55:30 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:30 --> Total execution time: 0.0366
INFO - 2024-06-17 21:55:32 --> Config Class Initialized
INFO - 2024-06-17 21:55:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:32 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:32 --> URI Class Initialized
INFO - 2024-06-17 21:55:32 --> Router Class Initialized
INFO - 2024-06-17 21:55:32 --> Output Class Initialized
INFO - 2024-06-17 21:55:32 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:32 --> Input Class Initialized
INFO - 2024-06-17 21:55:32 --> Language Class Initialized
INFO - 2024-06-17 21:55:32 --> Language Class Initialized
INFO - 2024-06-17 21:55:32 --> Config Class Initialized
INFO - 2024-06-17 21:55:32 --> Loader Class Initialized
INFO - 2024-06-17 21:55:32 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:32 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:32 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:32 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:32 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:32 --> Controller Class Initialized
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:55:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:32 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:32 --> Total execution time: 0.0390
INFO - 2024-06-17 21:55:36 --> Config Class Initialized
INFO - 2024-06-17 21:55:36 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:36 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:36 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:36 --> URI Class Initialized
INFO - 2024-06-17 21:55:36 --> Router Class Initialized
INFO - 2024-06-17 21:55:36 --> Output Class Initialized
INFO - 2024-06-17 21:55:36 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:36 --> Input Class Initialized
INFO - 2024-06-17 21:55:36 --> Language Class Initialized
INFO - 2024-06-17 21:55:36 --> Language Class Initialized
INFO - 2024-06-17 21:55:36 --> Config Class Initialized
INFO - 2024-06-17 21:55:36 --> Loader Class Initialized
INFO - 2024-06-17 21:55:36 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:36 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:36 --> Controller Class Initialized
DEBUG - 2024-06-17 21:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2024-06-17 21:55:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:36 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:36 --> Total execution time: 0.0359
INFO - 2024-06-17 21:55:36 --> Config Class Initialized
INFO - 2024-06-17 21:55:36 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:36 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:36 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:36 --> URI Class Initialized
INFO - 2024-06-17 21:55:36 --> Router Class Initialized
INFO - 2024-06-17 21:55:36 --> Output Class Initialized
INFO - 2024-06-17 21:55:36 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:36 --> Input Class Initialized
INFO - 2024-06-17 21:55:36 --> Language Class Initialized
INFO - 2024-06-17 21:55:36 --> Language Class Initialized
INFO - 2024-06-17 21:55:36 --> Config Class Initialized
INFO - 2024-06-17 21:55:36 --> Loader Class Initialized
INFO - 2024-06-17 21:55:36 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:36 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:36 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:36 --> Controller Class Initialized
INFO - 2024-06-17 21:55:38 --> Config Class Initialized
INFO - 2024-06-17 21:55:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:38 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:38 --> URI Class Initialized
INFO - 2024-06-17 21:55:38 --> Router Class Initialized
INFO - 2024-06-17 21:55:38 --> Output Class Initialized
INFO - 2024-06-17 21:55:38 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:38 --> Input Class Initialized
INFO - 2024-06-17 21:55:38 --> Language Class Initialized
INFO - 2024-06-17 21:55:38 --> Language Class Initialized
INFO - 2024-06-17 21:55:38 --> Config Class Initialized
INFO - 2024-06-17 21:55:38 --> Loader Class Initialized
INFO - 2024-06-17 21:55:38 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:38 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:38 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:38 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:38 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:38 --> Controller Class Initialized
INFO - 2024-06-17 21:55:38 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:38 --> Total execution time: 0.0377
INFO - 2024-06-17 21:55:40 --> Config Class Initialized
INFO - 2024-06-17 21:55:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:40 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:40 --> URI Class Initialized
INFO - 2024-06-17 21:55:40 --> Router Class Initialized
INFO - 2024-06-17 21:55:40 --> Output Class Initialized
INFO - 2024-06-17 21:55:40 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:40 --> Input Class Initialized
INFO - 2024-06-17 21:55:40 --> Language Class Initialized
INFO - 2024-06-17 21:55:40 --> Language Class Initialized
INFO - 2024-06-17 21:55:40 --> Config Class Initialized
INFO - 2024-06-17 21:55:40 --> Loader Class Initialized
INFO - 2024-06-17 21:55:40 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:40 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:40 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:40 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:40 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:40 --> Controller Class Initialized
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 21:55:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 21:55:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 21:55:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:40 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:40 --> Total execution time: 0.0338
INFO - 2024-06-17 21:55:49 --> Config Class Initialized
INFO - 2024-06-17 21:55:49 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:49 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:49 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:49 --> URI Class Initialized
INFO - 2024-06-17 21:55:49 --> Router Class Initialized
INFO - 2024-06-17 21:55:49 --> Output Class Initialized
INFO - 2024-06-17 21:55:49 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:49 --> Input Class Initialized
INFO - 2024-06-17 21:55:49 --> Language Class Initialized
INFO - 2024-06-17 21:55:49 --> Language Class Initialized
INFO - 2024-06-17 21:55:49 --> Config Class Initialized
INFO - 2024-06-17 21:55:49 --> Loader Class Initialized
INFO - 2024-06-17 21:55:49 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:49 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:49 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:49 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:49 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:49 --> Controller Class Initialized
DEBUG - 2024-06-17 21:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2024-06-17 21:55:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:49 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:49 --> Total execution time: 0.0493
INFO - 2024-06-17 21:55:53 --> Config Class Initialized
INFO - 2024-06-17 21:55:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:55:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:55:53 --> Utf8 Class Initialized
INFO - 2024-06-17 21:55:53 --> URI Class Initialized
INFO - 2024-06-17 21:55:53 --> Router Class Initialized
INFO - 2024-06-17 21:55:53 --> Output Class Initialized
INFO - 2024-06-17 21:55:53 --> Security Class Initialized
DEBUG - 2024-06-17 21:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:55:53 --> Input Class Initialized
INFO - 2024-06-17 21:55:53 --> Language Class Initialized
INFO - 2024-06-17 21:55:53 --> Language Class Initialized
INFO - 2024-06-17 21:55:53 --> Config Class Initialized
INFO - 2024-06-17 21:55:53 --> Loader Class Initialized
INFO - 2024-06-17 21:55:53 --> Helper loaded: url_helper
INFO - 2024-06-17 21:55:53 --> Helper loaded: file_helper
INFO - 2024-06-17 21:55:53 --> Helper loaded: form_helper
INFO - 2024-06-17 21:55:53 --> Helper loaded: my_helper
INFO - 2024-06-17 21:55:53 --> Database Driver Class Initialized
INFO - 2024-06-17 21:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:55:53 --> Controller Class Initialized
DEBUG - 2024-06-17 21:55:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2024-06-17 21:55:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:55:53 --> Final output sent to browser
DEBUG - 2024-06-17 21:55:53 --> Total execution time: 0.0452
INFO - 2024-06-17 21:57:37 --> Config Class Initialized
INFO - 2024-06-17 21:57:37 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:57:37 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:57:37 --> Utf8 Class Initialized
INFO - 2024-06-17 21:57:37 --> URI Class Initialized
INFO - 2024-06-17 21:57:37 --> Router Class Initialized
INFO - 2024-06-17 21:57:37 --> Output Class Initialized
INFO - 2024-06-17 21:57:37 --> Security Class Initialized
DEBUG - 2024-06-17 21:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:57:37 --> Input Class Initialized
INFO - 2024-06-17 21:57:37 --> Language Class Initialized
INFO - 2024-06-17 21:57:37 --> Language Class Initialized
INFO - 2024-06-17 21:57:37 --> Config Class Initialized
INFO - 2024-06-17 21:57:37 --> Loader Class Initialized
INFO - 2024-06-17 21:57:37 --> Helper loaded: url_helper
INFO - 2024-06-17 21:57:37 --> Helper loaded: file_helper
INFO - 2024-06-17 21:57:37 --> Helper loaded: form_helper
INFO - 2024-06-17 21:57:37 --> Helper loaded: my_helper
INFO - 2024-06-17 21:57:37 --> Database Driver Class Initialized
INFO - 2024-06-17 21:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:57:38 --> Controller Class Initialized
INFO - 2024-06-17 21:57:38 --> Final output sent to browser
DEBUG - 2024-06-17 21:57:38 --> Total execution time: 0.3478
INFO - 2024-06-17 21:58:03 --> Config Class Initialized
INFO - 2024-06-17 21:58:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:58:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:58:03 --> Utf8 Class Initialized
INFO - 2024-06-17 21:58:03 --> URI Class Initialized
INFO - 2024-06-17 21:58:03 --> Router Class Initialized
INFO - 2024-06-17 21:58:03 --> Output Class Initialized
INFO - 2024-06-17 21:58:03 --> Security Class Initialized
DEBUG - 2024-06-17 21:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:58:03 --> Input Class Initialized
INFO - 2024-06-17 21:58:03 --> Language Class Initialized
INFO - 2024-06-17 21:58:03 --> Language Class Initialized
INFO - 2024-06-17 21:58:03 --> Config Class Initialized
INFO - 2024-06-17 21:58:03 --> Loader Class Initialized
INFO - 2024-06-17 21:58:03 --> Helper loaded: url_helper
INFO - 2024-06-17 21:58:03 --> Helper loaded: file_helper
INFO - 2024-06-17 21:58:03 --> Helper loaded: form_helper
INFO - 2024-06-17 21:58:03 --> Helper loaded: my_helper
INFO - 2024-06-17 21:58:03 --> Database Driver Class Initialized
INFO - 2024-06-17 21:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:58:03 --> Controller Class Initialized
DEBUG - 2024-06-17 21:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_projek/views/list.php
DEBUG - 2024-06-17 21:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:58:03 --> Final output sent to browser
DEBUG - 2024-06-17 21:58:03 --> Total execution time: 0.1931
INFO - 2024-06-17 21:58:12 --> Config Class Initialized
INFO - 2024-06-17 21:58:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:58:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:58:12 --> Utf8 Class Initialized
INFO - 2024-06-17 21:58:12 --> URI Class Initialized
INFO - 2024-06-17 21:58:12 --> Router Class Initialized
INFO - 2024-06-17 21:58:12 --> Output Class Initialized
INFO - 2024-06-17 21:58:12 --> Security Class Initialized
DEBUG - 2024-06-17 21:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:58:12 --> Input Class Initialized
INFO - 2024-06-17 21:58:12 --> Language Class Initialized
INFO - 2024-06-17 21:58:12 --> Language Class Initialized
INFO - 2024-06-17 21:58:12 --> Config Class Initialized
INFO - 2024-06-17 21:58:12 --> Loader Class Initialized
INFO - 2024-06-17 21:58:12 --> Helper loaded: url_helper
INFO - 2024-06-17 21:58:12 --> Helper loaded: file_helper
INFO - 2024-06-17 21:58:12 --> Helper loaded: form_helper
INFO - 2024-06-17 21:58:12 --> Helper loaded: my_helper
INFO - 2024-06-17 21:58:12 --> Database Driver Class Initialized
INFO - 2024-06-17 21:58:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:58:12 --> Controller Class Initialized
DEBUG - 2024-06-17 21:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2024-06-17 21:58:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:58:12 --> Final output sent to browser
DEBUG - 2024-06-17 21:58:12 --> Total execution time: 0.0323
INFO - 2024-06-17 21:59:36 --> Config Class Initialized
INFO - 2024-06-17 21:59:36 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:59:36 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:59:36 --> Utf8 Class Initialized
INFO - 2024-06-17 21:59:36 --> URI Class Initialized
INFO - 2024-06-17 21:59:36 --> Router Class Initialized
INFO - 2024-06-17 21:59:36 --> Output Class Initialized
INFO - 2024-06-17 21:59:36 --> Security Class Initialized
DEBUG - 2024-06-17 21:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:59:36 --> Input Class Initialized
INFO - 2024-06-17 21:59:36 --> Language Class Initialized
INFO - 2024-06-17 21:59:36 --> Language Class Initialized
INFO - 2024-06-17 21:59:36 --> Config Class Initialized
INFO - 2024-06-17 21:59:36 --> Loader Class Initialized
INFO - 2024-06-17 21:59:36 --> Helper loaded: url_helper
INFO - 2024-06-17 21:59:36 --> Helper loaded: file_helper
INFO - 2024-06-17 21:59:36 --> Helper loaded: form_helper
INFO - 2024-06-17 21:59:36 --> Helper loaded: my_helper
INFO - 2024-06-17 21:59:36 --> Database Driver Class Initialized
INFO - 2024-06-17 21:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:59:36 --> Controller Class Initialized
INFO - 2024-06-17 21:59:36 --> Final output sent to browser
DEBUG - 2024-06-17 21:59:36 --> Total execution time: 0.0423
INFO - 2024-06-17 21:59:42 --> Config Class Initialized
INFO - 2024-06-17 21:59:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 21:59:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 21:59:42 --> Utf8 Class Initialized
INFO - 2024-06-17 21:59:42 --> URI Class Initialized
INFO - 2024-06-17 21:59:42 --> Router Class Initialized
INFO - 2024-06-17 21:59:42 --> Output Class Initialized
INFO - 2024-06-17 21:59:42 --> Security Class Initialized
DEBUG - 2024-06-17 21:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 21:59:42 --> Input Class Initialized
INFO - 2024-06-17 21:59:42 --> Language Class Initialized
INFO - 2024-06-17 21:59:42 --> Language Class Initialized
INFO - 2024-06-17 21:59:42 --> Config Class Initialized
INFO - 2024-06-17 21:59:42 --> Loader Class Initialized
INFO - 2024-06-17 21:59:42 --> Helper loaded: url_helper
INFO - 2024-06-17 21:59:42 --> Helper loaded: file_helper
INFO - 2024-06-17 21:59:42 --> Helper loaded: form_helper
INFO - 2024-06-17 21:59:42 --> Helper loaded: my_helper
INFO - 2024-06-17 21:59:42 --> Database Driver Class Initialized
INFO - 2024-06-17 21:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 21:59:42 --> Controller Class Initialized
DEBUG - 2024-06-17 21:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2024-06-17 21:59:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 21:59:42 --> Final output sent to browser
DEBUG - 2024-06-17 21:59:42 --> Total execution time: 0.2969
INFO - 2024-06-17 22:01:16 --> Config Class Initialized
INFO - 2024-06-17 22:01:16 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:01:16 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:01:16 --> Utf8 Class Initialized
INFO - 2024-06-17 22:01:16 --> URI Class Initialized
INFO - 2024-06-17 22:01:16 --> Router Class Initialized
INFO - 2024-06-17 22:01:16 --> Output Class Initialized
INFO - 2024-06-17 22:01:16 --> Security Class Initialized
DEBUG - 2024-06-17 22:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:01:16 --> Input Class Initialized
INFO - 2024-06-17 22:01:16 --> Language Class Initialized
INFO - 2024-06-17 22:01:16 --> Language Class Initialized
INFO - 2024-06-17 22:01:16 --> Config Class Initialized
INFO - 2024-06-17 22:01:16 --> Loader Class Initialized
INFO - 2024-06-17 22:01:16 --> Helper loaded: url_helper
INFO - 2024-06-17 22:01:16 --> Helper loaded: file_helper
INFO - 2024-06-17 22:01:16 --> Helper loaded: form_helper
INFO - 2024-06-17 22:01:16 --> Helper loaded: my_helper
INFO - 2024-06-17 22:01:16 --> Database Driver Class Initialized
INFO - 2024-06-17 22:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:01:16 --> Controller Class Initialized
INFO - 2024-06-17 22:01:16 --> Final output sent to browser
DEBUG - 2024-06-17 22:01:16 --> Total execution time: 0.1885
INFO - 2024-06-17 22:01:22 --> Config Class Initialized
INFO - 2024-06-17 22:01:22 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:01:22 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:01:22 --> Utf8 Class Initialized
INFO - 2024-06-17 22:01:22 --> URI Class Initialized
INFO - 2024-06-17 22:01:22 --> Router Class Initialized
INFO - 2024-06-17 22:01:22 --> Output Class Initialized
INFO - 2024-06-17 22:01:22 --> Security Class Initialized
DEBUG - 2024-06-17 22:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:01:22 --> Input Class Initialized
INFO - 2024-06-17 22:01:22 --> Language Class Initialized
INFO - 2024-06-17 22:01:22 --> Language Class Initialized
INFO - 2024-06-17 22:01:22 --> Config Class Initialized
INFO - 2024-06-17 22:01:22 --> Loader Class Initialized
INFO - 2024-06-17 22:01:22 --> Helper loaded: url_helper
INFO - 2024-06-17 22:01:22 --> Helper loaded: file_helper
INFO - 2024-06-17 22:01:22 --> Helper loaded: form_helper
INFO - 2024-06-17 22:01:22 --> Helper loaded: my_helper
INFO - 2024-06-17 22:01:22 --> Database Driver Class Initialized
INFO - 2024-06-17 22:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:01:22 --> Controller Class Initialized
DEBUG - 2024-06-17 22:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2024-06-17 22:01:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:01:22 --> Final output sent to browser
DEBUG - 2024-06-17 22:01:22 --> Total execution time: 0.0346
INFO - 2024-06-17 22:02:46 --> Config Class Initialized
INFO - 2024-06-17 22:02:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:02:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:02:46 --> Utf8 Class Initialized
INFO - 2024-06-17 22:02:46 --> URI Class Initialized
INFO - 2024-06-17 22:02:46 --> Router Class Initialized
INFO - 2024-06-17 22:02:46 --> Output Class Initialized
INFO - 2024-06-17 22:02:46 --> Security Class Initialized
DEBUG - 2024-06-17 22:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:02:46 --> Input Class Initialized
INFO - 2024-06-17 22:02:46 --> Language Class Initialized
INFO - 2024-06-17 22:02:46 --> Language Class Initialized
INFO - 2024-06-17 22:02:46 --> Config Class Initialized
INFO - 2024-06-17 22:02:46 --> Loader Class Initialized
INFO - 2024-06-17 22:02:46 --> Helper loaded: url_helper
INFO - 2024-06-17 22:02:46 --> Helper loaded: file_helper
INFO - 2024-06-17 22:02:46 --> Helper loaded: form_helper
INFO - 2024-06-17 22:02:46 --> Helper loaded: my_helper
INFO - 2024-06-17 22:02:46 --> Database Driver Class Initialized
INFO - 2024-06-17 22:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:02:46 --> Controller Class Initialized
INFO - 2024-06-17 22:02:46 --> Final output sent to browser
DEBUG - 2024-06-17 22:02:46 --> Total execution time: 0.0435
INFO - 2024-06-17 22:02:52 --> Config Class Initialized
INFO - 2024-06-17 22:02:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:02:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:02:52 --> Utf8 Class Initialized
INFO - 2024-06-17 22:02:52 --> URI Class Initialized
INFO - 2024-06-17 22:02:52 --> Router Class Initialized
INFO - 2024-06-17 22:02:52 --> Output Class Initialized
INFO - 2024-06-17 22:02:52 --> Security Class Initialized
DEBUG - 2024-06-17 22:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:02:52 --> Input Class Initialized
INFO - 2024-06-17 22:02:52 --> Language Class Initialized
INFO - 2024-06-17 22:02:52 --> Language Class Initialized
INFO - 2024-06-17 22:02:52 --> Config Class Initialized
INFO - 2024-06-17 22:02:52 --> Loader Class Initialized
INFO - 2024-06-17 22:02:52 --> Helper loaded: url_helper
INFO - 2024-06-17 22:02:52 --> Helper loaded: file_helper
INFO - 2024-06-17 22:02:52 --> Helper loaded: form_helper
INFO - 2024-06-17 22:02:52 --> Helper loaded: my_helper
INFO - 2024-06-17 22:02:52 --> Database Driver Class Initialized
INFO - 2024-06-17 22:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:02:52 --> Controller Class Initialized
DEBUG - 2024-06-17 22:02:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kelompok/views/list.php
DEBUG - 2024-06-17 22:02:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:02:52 --> Final output sent to browser
DEBUG - 2024-06-17 22:02:52 --> Total execution time: 0.0305
INFO - 2024-06-17 22:04:26 --> Config Class Initialized
INFO - 2024-06-17 22:04:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:04:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:04:26 --> Utf8 Class Initialized
INFO - 2024-06-17 22:04:26 --> URI Class Initialized
INFO - 2024-06-17 22:04:26 --> Router Class Initialized
INFO - 2024-06-17 22:04:26 --> Output Class Initialized
INFO - 2024-06-17 22:04:26 --> Security Class Initialized
DEBUG - 2024-06-17 22:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:04:26 --> Input Class Initialized
INFO - 2024-06-17 22:04:26 --> Language Class Initialized
INFO - 2024-06-17 22:04:26 --> Language Class Initialized
INFO - 2024-06-17 22:04:26 --> Config Class Initialized
INFO - 2024-06-17 22:04:26 --> Loader Class Initialized
INFO - 2024-06-17 22:04:26 --> Helper loaded: url_helper
INFO - 2024-06-17 22:04:26 --> Helper loaded: file_helper
INFO - 2024-06-17 22:04:26 --> Helper loaded: form_helper
INFO - 2024-06-17 22:04:26 --> Helper loaded: my_helper
INFO - 2024-06-17 22:04:26 --> Database Driver Class Initialized
INFO - 2024-06-17 22:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:04:26 --> Controller Class Initialized
INFO - 2024-06-17 22:04:26 --> Final output sent to browser
DEBUG - 2024-06-17 22:04:26 --> Total execution time: 0.0486
INFO - 2024-06-17 22:04:39 --> Config Class Initialized
INFO - 2024-06-17 22:04:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:04:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:04:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:04:39 --> URI Class Initialized
INFO - 2024-06-17 22:04:39 --> Router Class Initialized
INFO - 2024-06-17 22:04:39 --> Output Class Initialized
INFO - 2024-06-17 22:04:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:04:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:04:39 --> Input Class Initialized
INFO - 2024-06-17 22:04:39 --> Language Class Initialized
INFO - 2024-06-17 22:04:39 --> Language Class Initialized
INFO - 2024-06-17 22:04:39 --> Config Class Initialized
INFO - 2024-06-17 22:04:39 --> Loader Class Initialized
INFO - 2024-06-17 22:04:39 --> Helper loaded: url_helper
INFO - 2024-06-17 22:04:39 --> Helper loaded: file_helper
INFO - 2024-06-17 22:04:39 --> Helper loaded: form_helper
INFO - 2024-06-17 22:04:39 --> Helper loaded: my_helper
INFO - 2024-06-17 22:04:39 --> Database Driver Class Initialized
INFO - 2024-06-17 22:04:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:04:39 --> Controller Class Initialized
DEBUG - 2024-06-17 22:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2024-06-17 22:04:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:04:39 --> Final output sent to browser
DEBUG - 2024-06-17 22:04:39 --> Total execution time: 0.0382
INFO - 2024-06-17 22:04:51 --> Config Class Initialized
INFO - 2024-06-17 22:04:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:04:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:04:51 --> Utf8 Class Initialized
INFO - 2024-06-17 22:04:51 --> URI Class Initialized
INFO - 2024-06-17 22:04:51 --> Router Class Initialized
INFO - 2024-06-17 22:04:51 --> Output Class Initialized
INFO - 2024-06-17 22:04:51 --> Security Class Initialized
DEBUG - 2024-06-17 22:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:04:51 --> Input Class Initialized
INFO - 2024-06-17 22:04:51 --> Language Class Initialized
INFO - 2024-06-17 22:04:51 --> Language Class Initialized
INFO - 2024-06-17 22:04:51 --> Config Class Initialized
INFO - 2024-06-17 22:04:51 --> Loader Class Initialized
INFO - 2024-06-17 22:04:51 --> Helper loaded: url_helper
INFO - 2024-06-17 22:04:51 --> Helper loaded: file_helper
INFO - 2024-06-17 22:04:51 --> Helper loaded: form_helper
INFO - 2024-06-17 22:04:51 --> Helper loaded: my_helper
INFO - 2024-06-17 22:04:51 --> Database Driver Class Initialized
INFO - 2024-06-17 22:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:04:51 --> Controller Class Initialized
DEBUG - 2024-06-17 22:04:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2024-06-17 22:04:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:04:51 --> Final output sent to browser
DEBUG - 2024-06-17 22:04:51 --> Total execution time: 0.0300
INFO - 2024-06-17 22:04:59 --> Config Class Initialized
INFO - 2024-06-17 22:04:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:04:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:04:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:04:59 --> URI Class Initialized
INFO - 2024-06-17 22:04:59 --> Router Class Initialized
INFO - 2024-06-17 22:04:59 --> Output Class Initialized
INFO - 2024-06-17 22:04:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:04:59 --> Input Class Initialized
INFO - 2024-06-17 22:04:59 --> Language Class Initialized
INFO - 2024-06-17 22:04:59 --> Language Class Initialized
INFO - 2024-06-17 22:04:59 --> Config Class Initialized
INFO - 2024-06-17 22:04:59 --> Loader Class Initialized
INFO - 2024-06-17 22:04:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:04:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:04:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:04:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:04:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:04:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:04:59 --> Controller Class Initialized
DEBUG - 2024-06-17 22:04:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-17 22:04:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:04:59 --> Final output sent to browser
DEBUG - 2024-06-17 22:04:59 --> Total execution time: 0.0304
INFO - 2024-06-17 22:07:42 --> Config Class Initialized
INFO - 2024-06-17 22:07:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:07:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:07:42 --> Utf8 Class Initialized
INFO - 2024-06-17 22:07:42 --> URI Class Initialized
INFO - 2024-06-17 22:07:42 --> Router Class Initialized
INFO - 2024-06-17 22:07:42 --> Output Class Initialized
INFO - 2024-06-17 22:07:42 --> Security Class Initialized
DEBUG - 2024-06-17 22:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:07:42 --> Input Class Initialized
INFO - 2024-06-17 22:07:42 --> Language Class Initialized
INFO - 2024-06-17 22:07:42 --> Language Class Initialized
INFO - 2024-06-17 22:07:42 --> Config Class Initialized
INFO - 2024-06-17 22:07:42 --> Loader Class Initialized
INFO - 2024-06-17 22:07:42 --> Helper loaded: url_helper
INFO - 2024-06-17 22:07:42 --> Helper loaded: file_helper
INFO - 2024-06-17 22:07:42 --> Helper loaded: form_helper
INFO - 2024-06-17 22:07:42 --> Helper loaded: my_helper
INFO - 2024-06-17 22:07:42 --> Database Driver Class Initialized
INFO - 2024-06-17 22:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:07:42 --> Controller Class Initialized
DEBUG - 2024-06-17 22:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2024-06-17 22:07:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:07:42 --> Final output sent to browser
DEBUG - 2024-06-17 22:07:42 --> Total execution time: 0.0316
INFO - 2024-06-17 22:07:47 --> Config Class Initialized
INFO - 2024-06-17 22:07:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:07:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:07:47 --> Utf8 Class Initialized
INFO - 2024-06-17 22:07:47 --> URI Class Initialized
INFO - 2024-06-17 22:07:47 --> Router Class Initialized
INFO - 2024-06-17 22:07:47 --> Output Class Initialized
INFO - 2024-06-17 22:07:47 --> Security Class Initialized
DEBUG - 2024-06-17 22:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:07:47 --> Input Class Initialized
INFO - 2024-06-17 22:07:47 --> Language Class Initialized
INFO - 2024-06-17 22:07:47 --> Language Class Initialized
INFO - 2024-06-17 22:07:47 --> Config Class Initialized
INFO - 2024-06-17 22:07:47 --> Loader Class Initialized
INFO - 2024-06-17 22:07:47 --> Helper loaded: url_helper
INFO - 2024-06-17 22:07:47 --> Helper loaded: file_helper
INFO - 2024-06-17 22:07:47 --> Helper loaded: form_helper
INFO - 2024-06-17 22:07:47 --> Helper loaded: my_helper
INFO - 2024-06-17 22:07:47 --> Database Driver Class Initialized
INFO - 2024-06-17 22:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:07:47 --> Controller Class Initialized
DEBUG - 2024-06-17 22:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-17 22:07:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:07:47 --> Final output sent to browser
DEBUG - 2024-06-17 22:07:47 --> Total execution time: 0.1834
INFO - 2024-06-17 22:07:51 --> Config Class Initialized
INFO - 2024-06-17 22:07:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:07:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:07:51 --> Utf8 Class Initialized
INFO - 2024-06-17 22:07:51 --> URI Class Initialized
INFO - 2024-06-17 22:07:51 --> Router Class Initialized
INFO - 2024-06-17 22:07:51 --> Output Class Initialized
INFO - 2024-06-17 22:07:51 --> Security Class Initialized
DEBUG - 2024-06-17 22:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:07:51 --> Input Class Initialized
INFO - 2024-06-17 22:07:51 --> Language Class Initialized
INFO - 2024-06-17 22:07:51 --> Language Class Initialized
INFO - 2024-06-17 22:07:51 --> Config Class Initialized
INFO - 2024-06-17 22:07:51 --> Loader Class Initialized
INFO - 2024-06-17 22:07:51 --> Helper loaded: url_helper
INFO - 2024-06-17 22:07:51 --> Helper loaded: file_helper
INFO - 2024-06-17 22:07:51 --> Helper loaded: form_helper
INFO - 2024-06-17 22:07:51 --> Helper loaded: my_helper
INFO - 2024-06-17 22:07:51 --> Database Driver Class Initialized
INFO - 2024-06-17 22:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:07:51 --> Controller Class Initialized
ERROR - 2024-06-17 22:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-17 22:07:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-17 22:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-17 22:07:56 --> Final output sent to browser
DEBUG - 2024-06-17 22:07:56 --> Total execution time: 4.0956
INFO - 2024-06-17 22:07:56 --> Config Class Initialized
INFO - 2024-06-17 22:07:56 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:07:56 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:07:56 --> Utf8 Class Initialized
INFO - 2024-06-17 22:07:56 --> URI Class Initialized
INFO - 2024-06-17 22:07:56 --> Router Class Initialized
INFO - 2024-06-17 22:07:56 --> Output Class Initialized
INFO - 2024-06-17 22:07:56 --> Security Class Initialized
DEBUG - 2024-06-17 22:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:07:56 --> Input Class Initialized
INFO - 2024-06-17 22:07:56 --> Language Class Initialized
INFO - 2024-06-17 22:07:56 --> Language Class Initialized
INFO - 2024-06-17 22:07:56 --> Config Class Initialized
INFO - 2024-06-17 22:07:56 --> Loader Class Initialized
INFO - 2024-06-17 22:07:56 --> Helper loaded: url_helper
INFO - 2024-06-17 22:07:56 --> Helper loaded: file_helper
INFO - 2024-06-17 22:07:56 --> Helper loaded: form_helper
INFO - 2024-06-17 22:07:56 --> Helper loaded: my_helper
INFO - 2024-06-17 22:07:56 --> Database Driver Class Initialized
INFO - 2024-06-17 22:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:07:56 --> Controller Class Initialized
DEBUG - 2024-06-17 22:07:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-06-17 22:07:58 --> Final output sent to browser
DEBUG - 2024-06-17 22:07:58 --> Total execution time: 1.6760
INFO - 2024-06-17 22:07:59 --> Config Class Initialized
INFO - 2024-06-17 22:07:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:07:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:07:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:07:59 --> URI Class Initialized
INFO - 2024-06-17 22:07:59 --> Router Class Initialized
INFO - 2024-06-17 22:07:59 --> Output Class Initialized
INFO - 2024-06-17 22:07:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:07:59 --> Input Class Initialized
INFO - 2024-06-17 22:07:59 --> Language Class Initialized
INFO - 2024-06-17 22:07:59 --> Language Class Initialized
INFO - 2024-06-17 22:07:59 --> Config Class Initialized
INFO - 2024-06-17 22:07:59 --> Loader Class Initialized
INFO - 2024-06-17 22:07:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:07:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:07:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:07:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:07:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:07:59 --> Controller Class Initialized
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:07:59 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-17 22:07:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-17 22:08:01 --> Config Class Initialized
INFO - 2024-06-17 22:08:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:08:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:08:01 --> Utf8 Class Initialized
INFO - 2024-06-17 22:08:01 --> URI Class Initialized
INFO - 2024-06-17 22:08:01 --> Router Class Initialized
INFO - 2024-06-17 22:08:01 --> Output Class Initialized
INFO - 2024-06-17 22:08:01 --> Security Class Initialized
DEBUG - 2024-06-17 22:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:08:01 --> Input Class Initialized
INFO - 2024-06-17 22:08:01 --> Language Class Initialized
INFO - 2024-06-17 22:08:01 --> Language Class Initialized
INFO - 2024-06-17 22:08:01 --> Config Class Initialized
INFO - 2024-06-17 22:08:01 --> Loader Class Initialized
INFO - 2024-06-17 22:08:01 --> Helper loaded: url_helper
INFO - 2024-06-17 22:08:01 --> Helper loaded: file_helper
INFO - 2024-06-17 22:08:01 --> Helper loaded: form_helper
INFO - 2024-06-17 22:08:01 --> Helper loaded: my_helper
INFO - 2024-06-17 22:08:01 --> Database Driver Class Initialized
INFO - 2024-06-17 22:08:05 --> Final output sent to browser
DEBUG - 2024-06-17 22:08:05 --> Total execution time: 6.1853
INFO - 2024-06-17 22:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:08:05 --> Controller Class Initialized
DEBUG - 2024-06-17 22:08:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-17 22:08:09 --> Final output sent to browser
DEBUG - 2024-06-17 22:08:09 --> Total execution time: 7.3593
INFO - 2024-06-17 22:20:12 --> Config Class Initialized
INFO - 2024-06-17 22:20:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:20:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:20:12 --> Utf8 Class Initialized
INFO - 2024-06-17 22:20:12 --> URI Class Initialized
INFO - 2024-06-17 22:20:12 --> Router Class Initialized
INFO - 2024-06-17 22:20:12 --> Output Class Initialized
INFO - 2024-06-17 22:20:12 --> Security Class Initialized
DEBUG - 2024-06-17 22:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:20:12 --> Input Class Initialized
INFO - 2024-06-17 22:20:12 --> Language Class Initialized
INFO - 2024-06-17 22:20:12 --> Language Class Initialized
INFO - 2024-06-17 22:20:12 --> Config Class Initialized
INFO - 2024-06-17 22:20:12 --> Loader Class Initialized
INFO - 2024-06-17 22:20:12 --> Helper loaded: url_helper
INFO - 2024-06-17 22:20:12 --> Helper loaded: file_helper
INFO - 2024-06-17 22:20:12 --> Helper loaded: form_helper
INFO - 2024-06-17 22:20:12 --> Helper loaded: my_helper
INFO - 2024-06-17 22:20:12 --> Database Driver Class Initialized
INFO - 2024-06-17 22:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:20:12 --> Controller Class Initialized
ERROR - 2024-06-17 22:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3014
ERROR - 2024-06-17 22:20:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3015
DEBUG - 2024-06-17 22:20:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-06-17 22:20:19 --> Final output sent to browser
DEBUG - 2024-06-17 22:20:19 --> Total execution time: 6.2019
INFO - 2024-06-17 22:20:43 --> Config Class Initialized
INFO - 2024-06-17 22:20:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:20:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:20:43 --> Utf8 Class Initialized
INFO - 2024-06-17 22:20:43 --> URI Class Initialized
INFO - 2024-06-17 22:20:43 --> Router Class Initialized
INFO - 2024-06-17 22:20:43 --> Output Class Initialized
INFO - 2024-06-17 22:20:43 --> Security Class Initialized
DEBUG - 2024-06-17 22:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:20:43 --> Input Class Initialized
INFO - 2024-06-17 22:20:43 --> Language Class Initialized
INFO - 2024-06-17 22:20:43 --> Language Class Initialized
INFO - 2024-06-17 22:20:43 --> Config Class Initialized
INFO - 2024-06-17 22:20:43 --> Loader Class Initialized
INFO - 2024-06-17 22:20:43 --> Helper loaded: url_helper
INFO - 2024-06-17 22:20:43 --> Helper loaded: file_helper
INFO - 2024-06-17 22:20:43 --> Helper loaded: form_helper
INFO - 2024-06-17 22:20:43 --> Helper loaded: my_helper
INFO - 2024-06-17 22:20:43 --> Database Driver Class Initialized
INFO - 2024-06-17 22:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:20:43 --> Controller Class Initialized
DEBUG - 2024-06-17 22:20:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-17 22:20:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:20:43 --> Final output sent to browser
DEBUG - 2024-06-17 22:20:43 --> Total execution time: 0.0348
INFO - 2024-06-17 22:20:52 --> Config Class Initialized
INFO - 2024-06-17 22:20:52 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:20:52 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:20:52 --> Utf8 Class Initialized
INFO - 2024-06-17 22:20:52 --> URI Class Initialized
INFO - 2024-06-17 22:20:52 --> Router Class Initialized
INFO - 2024-06-17 22:20:52 --> Output Class Initialized
INFO - 2024-06-17 22:20:52 --> Security Class Initialized
DEBUG - 2024-06-17 22:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:20:52 --> Input Class Initialized
INFO - 2024-06-17 22:20:52 --> Language Class Initialized
INFO - 2024-06-17 22:20:52 --> Language Class Initialized
INFO - 2024-06-17 22:20:52 --> Config Class Initialized
INFO - 2024-06-17 22:20:52 --> Loader Class Initialized
INFO - 2024-06-17 22:20:52 --> Helper loaded: url_helper
INFO - 2024-06-17 22:20:52 --> Helper loaded: file_helper
INFO - 2024-06-17 22:20:52 --> Helper loaded: form_helper
INFO - 2024-06-17 22:20:52 --> Helper loaded: my_helper
INFO - 2024-06-17 22:20:52 --> Database Driver Class Initialized
INFO - 2024-06-17 22:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:20:52 --> Controller Class Initialized
DEBUG - 2024-06-17 22:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-17 22:20:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:20:52 --> Final output sent to browser
DEBUG - 2024-06-17 22:20:52 --> Total execution time: 0.0278
INFO - 2024-06-17 22:20:57 --> Config Class Initialized
INFO - 2024-06-17 22:20:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:20:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:20:57 --> Utf8 Class Initialized
INFO - 2024-06-17 22:20:57 --> URI Class Initialized
INFO - 2024-06-17 22:20:57 --> Router Class Initialized
INFO - 2024-06-17 22:20:57 --> Output Class Initialized
INFO - 2024-06-17 22:20:57 --> Security Class Initialized
DEBUG - 2024-06-17 22:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:20:57 --> Input Class Initialized
INFO - 2024-06-17 22:20:57 --> Language Class Initialized
INFO - 2024-06-17 22:20:57 --> Language Class Initialized
INFO - 2024-06-17 22:20:57 --> Config Class Initialized
INFO - 2024-06-17 22:20:57 --> Loader Class Initialized
INFO - 2024-06-17 22:20:57 --> Helper loaded: url_helper
INFO - 2024-06-17 22:20:57 --> Helper loaded: file_helper
INFO - 2024-06-17 22:20:57 --> Helper loaded: form_helper
INFO - 2024-06-17 22:20:57 --> Helper loaded: my_helper
INFO - 2024-06-17 22:20:57 --> Database Driver Class Initialized
INFO - 2024-06-17 22:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:20:57 --> Controller Class Initialized
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:20:57 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 22:20:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 22:20:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:20:57 --> Final output sent to browser
DEBUG - 2024-06-17 22:20:57 --> Total execution time: 0.0299
INFO - 2024-06-17 22:21:01 --> Config Class Initialized
INFO - 2024-06-17 22:21:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:21:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:21:01 --> Utf8 Class Initialized
INFO - 2024-06-17 22:21:01 --> URI Class Initialized
INFO - 2024-06-17 22:21:01 --> Router Class Initialized
INFO - 2024-06-17 22:21:01 --> Output Class Initialized
INFO - 2024-06-17 22:21:01 --> Security Class Initialized
DEBUG - 2024-06-17 22:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:21:01 --> Input Class Initialized
INFO - 2024-06-17 22:21:01 --> Language Class Initialized
INFO - 2024-06-17 22:21:01 --> Language Class Initialized
INFO - 2024-06-17 22:21:01 --> Config Class Initialized
INFO - 2024-06-17 22:21:01 --> Loader Class Initialized
INFO - 2024-06-17 22:21:01 --> Helper loaded: url_helper
INFO - 2024-06-17 22:21:01 --> Helper loaded: file_helper
INFO - 2024-06-17 22:21:01 --> Helper loaded: form_helper
INFO - 2024-06-17 22:21:01 --> Helper loaded: my_helper
INFO - 2024-06-17 22:21:01 --> Database Driver Class Initialized
INFO - 2024-06-17 22:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:21:01 --> Controller Class Initialized
DEBUG - 2024-06-17 22:21:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2024-06-17 22:21:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:21:01 --> Final output sent to browser
DEBUG - 2024-06-17 22:21:01 --> Total execution time: 0.0352
INFO - 2024-06-17 22:21:03 --> Config Class Initialized
INFO - 2024-06-17 22:21:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:21:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:21:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:21:03 --> URI Class Initialized
INFO - 2024-06-17 22:21:03 --> Router Class Initialized
INFO - 2024-06-17 22:21:03 --> Output Class Initialized
INFO - 2024-06-17 22:21:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:21:03 --> Input Class Initialized
INFO - 2024-06-17 22:21:03 --> Language Class Initialized
INFO - 2024-06-17 22:21:03 --> Language Class Initialized
INFO - 2024-06-17 22:21:03 --> Config Class Initialized
INFO - 2024-06-17 22:21:03 --> Loader Class Initialized
INFO - 2024-06-17 22:21:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:21:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:21:03 --> Controller Class Initialized
DEBUG - 2024-06-17 22:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-06-17 22:21:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:21:03 --> Final output sent to browser
DEBUG - 2024-06-17 22:21:03 --> Total execution time: 0.0440
INFO - 2024-06-17 22:21:03 --> Config Class Initialized
INFO - 2024-06-17 22:21:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:21:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:21:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:21:03 --> URI Class Initialized
INFO - 2024-06-17 22:21:03 --> Router Class Initialized
INFO - 2024-06-17 22:21:03 --> Output Class Initialized
INFO - 2024-06-17 22:21:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:21:03 --> Input Class Initialized
INFO - 2024-06-17 22:21:03 --> Language Class Initialized
ERROR - 2024-06-17 22:21:03 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:21:03 --> Config Class Initialized
INFO - 2024-06-17 22:21:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:21:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:21:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:21:03 --> URI Class Initialized
INFO - 2024-06-17 22:21:03 --> Router Class Initialized
INFO - 2024-06-17 22:21:03 --> Output Class Initialized
INFO - 2024-06-17 22:21:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:21:03 --> Input Class Initialized
INFO - 2024-06-17 22:21:03 --> Language Class Initialized
INFO - 2024-06-17 22:21:03 --> Language Class Initialized
INFO - 2024-06-17 22:21:03 --> Config Class Initialized
INFO - 2024-06-17 22:21:03 --> Loader Class Initialized
INFO - 2024-06-17 22:21:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:21:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:21:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:21:03 --> Controller Class Initialized
INFO - 2024-06-17 22:21:04 --> Config Class Initialized
INFO - 2024-06-17 22:21:04 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:21:04 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:21:04 --> Utf8 Class Initialized
INFO - 2024-06-17 22:21:04 --> URI Class Initialized
INFO - 2024-06-17 22:21:04 --> Router Class Initialized
INFO - 2024-06-17 22:21:04 --> Output Class Initialized
INFO - 2024-06-17 22:21:04 --> Security Class Initialized
DEBUG - 2024-06-17 22:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:21:04 --> Input Class Initialized
INFO - 2024-06-17 22:21:04 --> Language Class Initialized
INFO - 2024-06-17 22:21:04 --> Language Class Initialized
INFO - 2024-06-17 22:21:04 --> Config Class Initialized
INFO - 2024-06-17 22:21:04 --> Loader Class Initialized
INFO - 2024-06-17 22:21:04 --> Helper loaded: url_helper
INFO - 2024-06-17 22:21:04 --> Helper loaded: file_helper
INFO - 2024-06-17 22:21:04 --> Helper loaded: form_helper
INFO - 2024-06-17 22:21:04 --> Helper loaded: my_helper
INFO - 2024-06-17 22:21:04 --> Database Driver Class Initialized
INFO - 2024-06-17 22:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:21:04 --> Controller Class Initialized
DEBUG - 2024-06-17 22:21:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2024-06-17 22:21:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:21:04 --> Final output sent to browser
DEBUG - 2024-06-17 22:21:04 --> Total execution time: 0.0707
INFO - 2024-06-17 22:24:23 --> Config Class Initialized
INFO - 2024-06-17 22:24:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:23 --> URI Class Initialized
INFO - 2024-06-17 22:24:23 --> Router Class Initialized
INFO - 2024-06-17 22:24:23 --> Output Class Initialized
INFO - 2024-06-17 22:24:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:23 --> Input Class Initialized
INFO - 2024-06-17 22:24:23 --> Language Class Initialized
INFO - 2024-06-17 22:24:23 --> Language Class Initialized
INFO - 2024-06-17 22:24:23 --> Config Class Initialized
INFO - 2024-06-17 22:24:23 --> Loader Class Initialized
INFO - 2024-06-17 22:24:23 --> Helper loaded: url_helper
INFO - 2024-06-17 22:24:23 --> Helper loaded: file_helper
INFO - 2024-06-17 22:24:23 --> Helper loaded: form_helper
INFO - 2024-06-17 22:24:23 --> Helper loaded: my_helper
INFO - 2024-06-17 22:24:23 --> Database Driver Class Initialized
INFO - 2024-06-17 22:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:24:23 --> Controller Class Initialized
DEBUG - 2024-06-17 22:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:24:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:24:23 --> Final output sent to browser
DEBUG - 2024-06-17 22:24:23 --> Total execution time: 0.0246
INFO - 2024-06-17 22:24:26 --> Config Class Initialized
INFO - 2024-06-17 22:24:26 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:26 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:26 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:26 --> URI Class Initialized
INFO - 2024-06-17 22:24:26 --> Router Class Initialized
INFO - 2024-06-17 22:24:26 --> Output Class Initialized
INFO - 2024-06-17 22:24:26 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:26 --> Input Class Initialized
INFO - 2024-06-17 22:24:26 --> Language Class Initialized
INFO - 2024-06-17 22:24:26 --> Language Class Initialized
INFO - 2024-06-17 22:24:26 --> Config Class Initialized
INFO - 2024-06-17 22:24:26 --> Loader Class Initialized
INFO - 2024-06-17 22:24:26 --> Helper loaded: url_helper
INFO - 2024-06-17 22:24:26 --> Helper loaded: file_helper
INFO - 2024-06-17 22:24:26 --> Helper loaded: form_helper
INFO - 2024-06-17 22:24:26 --> Helper loaded: my_helper
INFO - 2024-06-17 22:24:26 --> Database Driver Class Initialized
INFO - 2024-06-17 22:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:24:26 --> Controller Class Initialized
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-06-17 22:24:26 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-06-17 22:24:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-06-17 22:24:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:24:26 --> Final output sent to browser
DEBUG - 2024-06-17 22:24:26 --> Total execution time: 0.0369
INFO - 2024-06-17 22:24:27 --> Config Class Initialized
INFO - 2024-06-17 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:27 --> URI Class Initialized
INFO - 2024-06-17 22:24:27 --> Router Class Initialized
INFO - 2024-06-17 22:24:27 --> Output Class Initialized
INFO - 2024-06-17 22:24:27 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:27 --> Input Class Initialized
INFO - 2024-06-17 22:24:27 --> Language Class Initialized
INFO - 2024-06-17 22:24:27 --> Language Class Initialized
INFO - 2024-06-17 22:24:27 --> Config Class Initialized
INFO - 2024-06-17 22:24:27 --> Loader Class Initialized
INFO - 2024-06-17 22:24:27 --> Helper loaded: url_helper
INFO - 2024-06-17 22:24:27 --> Helper loaded: file_helper
INFO - 2024-06-17 22:24:27 --> Helper loaded: form_helper
INFO - 2024-06-17 22:24:27 --> Helper loaded: my_helper
INFO - 2024-06-17 22:24:27 --> Database Driver Class Initialized
INFO - 2024-06-17 22:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:24:27 --> Controller Class Initialized
DEBUG - 2024-06-17 22:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2024-06-17 22:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:24:27 --> Final output sent to browser
DEBUG - 2024-06-17 22:24:27 --> Total execution time: 0.0333
INFO - 2024-06-17 22:24:27 --> Config Class Initialized
INFO - 2024-06-17 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:27 --> URI Class Initialized
INFO - 2024-06-17 22:24:27 --> Router Class Initialized
INFO - 2024-06-17 22:24:27 --> Output Class Initialized
INFO - 2024-06-17 22:24:27 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:27 --> Input Class Initialized
INFO - 2024-06-17 22:24:27 --> Language Class Initialized
ERROR - 2024-06-17 22:24:27 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:24:27 --> Config Class Initialized
INFO - 2024-06-17 22:24:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:27 --> URI Class Initialized
INFO - 2024-06-17 22:24:27 --> Router Class Initialized
INFO - 2024-06-17 22:24:28 --> Output Class Initialized
INFO - 2024-06-17 22:24:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:28 --> Input Class Initialized
INFO - 2024-06-17 22:24:28 --> Language Class Initialized
INFO - 2024-06-17 22:24:28 --> Language Class Initialized
INFO - 2024-06-17 22:24:28 --> Config Class Initialized
INFO - 2024-06-17 22:24:28 --> Loader Class Initialized
INFO - 2024-06-17 22:24:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:24:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:24:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:24:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:24:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:24:28 --> Controller Class Initialized
INFO - 2024-06-17 22:24:31 --> Config Class Initialized
INFO - 2024-06-17 22:24:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:24:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:24:31 --> Utf8 Class Initialized
INFO - 2024-06-17 22:24:31 --> URI Class Initialized
INFO - 2024-06-17 22:24:31 --> Router Class Initialized
INFO - 2024-06-17 22:24:31 --> Output Class Initialized
INFO - 2024-06-17 22:24:31 --> Security Class Initialized
DEBUG - 2024-06-17 22:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:24:31 --> Input Class Initialized
INFO - 2024-06-17 22:24:31 --> Language Class Initialized
INFO - 2024-06-17 22:24:31 --> Language Class Initialized
INFO - 2024-06-17 22:24:31 --> Config Class Initialized
INFO - 2024-06-17 22:24:31 --> Loader Class Initialized
INFO - 2024-06-17 22:24:31 --> Helper loaded: url_helper
INFO - 2024-06-17 22:24:31 --> Helper loaded: file_helper
INFO - 2024-06-17 22:24:31 --> Helper loaded: form_helper
INFO - 2024-06-17 22:24:31 --> Helper loaded: my_helper
INFO - 2024-06-17 22:24:31 --> Database Driver Class Initialized
INFO - 2024-06-17 22:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:24:31 --> Controller Class Initialized
DEBUG - 2024-06-17 22:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2024-06-17 22:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:24:31 --> Final output sent to browser
DEBUG - 2024-06-17 22:24:31 --> Total execution time: 0.0288
INFO - 2024-06-17 22:32:23 --> Config Class Initialized
INFO - 2024-06-17 22:32:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:23 --> URI Class Initialized
INFO - 2024-06-17 22:32:23 --> Router Class Initialized
INFO - 2024-06-17 22:32:23 --> Output Class Initialized
INFO - 2024-06-17 22:32:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:23 --> Input Class Initialized
INFO - 2024-06-17 22:32:23 --> Language Class Initialized
INFO - 2024-06-17 22:32:23 --> Language Class Initialized
INFO - 2024-06-17 22:32:23 --> Config Class Initialized
INFO - 2024-06-17 22:32:23 --> Loader Class Initialized
INFO - 2024-06-17 22:32:23 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:23 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:23 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:23 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:23 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:23 --> Controller Class Initialized
DEBUG - 2024-06-17 22:32:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-06-17 22:32:26 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:26 --> Total execution time: 3.2921
INFO - 2024-06-17 22:32:28 --> Config Class Initialized
INFO - 2024-06-17 22:32:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:28 --> URI Class Initialized
INFO - 2024-06-17 22:32:28 --> Router Class Initialized
INFO - 2024-06-17 22:32:28 --> Output Class Initialized
INFO - 2024-06-17 22:32:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:28 --> Input Class Initialized
INFO - 2024-06-17 22:32:28 --> Language Class Initialized
INFO - 2024-06-17 22:32:28 --> Language Class Initialized
INFO - 2024-06-17 22:32:28 --> Config Class Initialized
INFO - 2024-06-17 22:32:28 --> Loader Class Initialized
INFO - 2024-06-17 22:32:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:28 --> Controller Class Initialized
ERROR - 2024-06-17 22:32:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2024-06-17 22:32:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-17 22:32:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:32:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:28 --> Total execution time: 0.0333
INFO - 2024-06-17 22:32:37 --> Config Class Initialized
INFO - 2024-06-17 22:32:37 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:37 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:37 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:37 --> URI Class Initialized
INFO - 2024-06-17 22:32:37 --> Router Class Initialized
INFO - 2024-06-17 22:32:37 --> Output Class Initialized
INFO - 2024-06-17 22:32:37 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:37 --> Input Class Initialized
INFO - 2024-06-17 22:32:37 --> Language Class Initialized
INFO - 2024-06-17 22:32:37 --> Language Class Initialized
INFO - 2024-06-17 22:32:37 --> Config Class Initialized
INFO - 2024-06-17 22:32:37 --> Loader Class Initialized
INFO - 2024-06-17 22:32:37 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:37 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:37 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:37 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:37 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:37 --> Controller Class Initialized
DEBUG - 2024-06-17 22:32:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:32:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:32:37 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:37 --> Total execution time: 0.0286
INFO - 2024-06-17 22:32:45 --> Config Class Initialized
INFO - 2024-06-17 22:32:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:45 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:45 --> URI Class Initialized
INFO - 2024-06-17 22:32:45 --> Router Class Initialized
INFO - 2024-06-17 22:32:45 --> Output Class Initialized
INFO - 2024-06-17 22:32:45 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:45 --> Input Class Initialized
INFO - 2024-06-17 22:32:45 --> Language Class Initialized
INFO - 2024-06-17 22:32:45 --> Language Class Initialized
INFO - 2024-06-17 22:32:45 --> Config Class Initialized
INFO - 2024-06-17 22:32:45 --> Loader Class Initialized
INFO - 2024-06-17 22:32:45 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:45 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:45 --> Controller Class Initialized
INFO - 2024-06-17 22:32:45 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:32:45 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:45 --> Total execution time: 0.0577
INFO - 2024-06-17 22:32:45 --> Config Class Initialized
INFO - 2024-06-17 22:32:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:45 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:45 --> URI Class Initialized
INFO - 2024-06-17 22:32:45 --> Router Class Initialized
INFO - 2024-06-17 22:32:45 --> Output Class Initialized
INFO - 2024-06-17 22:32:45 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:45 --> Input Class Initialized
INFO - 2024-06-17 22:32:45 --> Language Class Initialized
INFO - 2024-06-17 22:32:45 --> Language Class Initialized
INFO - 2024-06-17 22:32:45 --> Config Class Initialized
INFO - 2024-06-17 22:32:45 --> Loader Class Initialized
INFO - 2024-06-17 22:32:45 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:45 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:45 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:45 --> Controller Class Initialized
DEBUG - 2024-06-17 22:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-17 22:32:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:32:45 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:45 --> Total execution time: 0.0273
INFO - 2024-06-17 22:32:51 --> Config Class Initialized
INFO - 2024-06-17 22:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:51 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:51 --> URI Class Initialized
INFO - 2024-06-17 22:32:51 --> Router Class Initialized
INFO - 2024-06-17 22:32:51 --> Output Class Initialized
INFO - 2024-06-17 22:32:51 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:51 --> Input Class Initialized
INFO - 2024-06-17 22:32:51 --> Language Class Initialized
INFO - 2024-06-17 22:32:51 --> Language Class Initialized
INFO - 2024-06-17 22:32:51 --> Config Class Initialized
INFO - 2024-06-17 22:32:51 --> Loader Class Initialized
INFO - 2024-06-17 22:32:51 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:51 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:51 --> Controller Class Initialized
DEBUG - 2024-06-17 22:32:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-17 22:32:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:32:51 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:51 --> Total execution time: 0.0251
INFO - 2024-06-17 22:32:51 --> Config Class Initialized
INFO - 2024-06-17 22:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:51 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:51 --> URI Class Initialized
INFO - 2024-06-17 22:32:51 --> Router Class Initialized
INFO - 2024-06-17 22:32:51 --> Output Class Initialized
INFO - 2024-06-17 22:32:51 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:51 --> Input Class Initialized
INFO - 2024-06-17 22:32:51 --> Language Class Initialized
ERROR - 2024-06-17 22:32:51 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:32:51 --> Config Class Initialized
INFO - 2024-06-17 22:32:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:51 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:51 --> URI Class Initialized
INFO - 2024-06-17 22:32:51 --> Router Class Initialized
INFO - 2024-06-17 22:32:51 --> Output Class Initialized
INFO - 2024-06-17 22:32:51 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:51 --> Input Class Initialized
INFO - 2024-06-17 22:32:51 --> Language Class Initialized
INFO - 2024-06-17 22:32:51 --> Language Class Initialized
INFO - 2024-06-17 22:32:51 --> Config Class Initialized
INFO - 2024-06-17 22:32:51 --> Loader Class Initialized
INFO - 2024-06-17 22:32:51 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:51 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:51 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:51 --> Controller Class Initialized
INFO - 2024-06-17 22:32:59 --> Config Class Initialized
INFO - 2024-06-17 22:32:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:32:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:32:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:32:59 --> URI Class Initialized
INFO - 2024-06-17 22:32:59 --> Router Class Initialized
INFO - 2024-06-17 22:32:59 --> Output Class Initialized
INFO - 2024-06-17 22:32:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:32:59 --> Input Class Initialized
INFO - 2024-06-17 22:32:59 --> Language Class Initialized
INFO - 2024-06-17 22:32:59 --> Language Class Initialized
INFO - 2024-06-17 22:32:59 --> Config Class Initialized
INFO - 2024-06-17 22:32:59 --> Loader Class Initialized
INFO - 2024-06-17 22:32:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:32:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:32:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:32:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:32:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:32:59 --> Controller Class Initialized
DEBUG - 2024-06-17 22:32:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-06-17 22:32:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:32:59 --> Final output sent to browser
DEBUG - 2024-06-17 22:32:59 --> Total execution time: 0.0337
INFO - 2024-06-17 22:33:10 --> Config Class Initialized
INFO - 2024-06-17 22:33:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:10 --> URI Class Initialized
INFO - 2024-06-17 22:33:10 --> Router Class Initialized
INFO - 2024-06-17 22:33:10 --> Output Class Initialized
INFO - 2024-06-17 22:33:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:10 --> Input Class Initialized
INFO - 2024-06-17 22:33:10 --> Language Class Initialized
INFO - 2024-06-17 22:33:10 --> Language Class Initialized
INFO - 2024-06-17 22:33:10 --> Config Class Initialized
INFO - 2024-06-17 22:33:10 --> Loader Class Initialized
INFO - 2024-06-17 22:33:10 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:10 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:10 --> Controller Class Initialized
DEBUG - 2024-06-17 22:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:33:10 --> Final output sent to browser
DEBUG - 2024-06-17 22:33:10 --> Total execution time: 0.0258
INFO - 2024-06-17 22:33:10 --> Config Class Initialized
INFO - 2024-06-17 22:33:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:10 --> URI Class Initialized
INFO - 2024-06-17 22:33:10 --> Router Class Initialized
INFO - 2024-06-17 22:33:10 --> Output Class Initialized
INFO - 2024-06-17 22:33:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:10 --> Input Class Initialized
INFO - 2024-06-17 22:33:10 --> Language Class Initialized
ERROR - 2024-06-17 22:33:10 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:33:10 --> Config Class Initialized
INFO - 2024-06-17 22:33:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:10 --> URI Class Initialized
INFO - 2024-06-17 22:33:10 --> Router Class Initialized
INFO - 2024-06-17 22:33:10 --> Output Class Initialized
INFO - 2024-06-17 22:33:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:10 --> Input Class Initialized
INFO - 2024-06-17 22:33:10 --> Language Class Initialized
INFO - 2024-06-17 22:33:10 --> Language Class Initialized
INFO - 2024-06-17 22:33:10 --> Config Class Initialized
INFO - 2024-06-17 22:33:10 --> Loader Class Initialized
INFO - 2024-06-17 22:33:10 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:10 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:10 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:10 --> Controller Class Initialized
INFO - 2024-06-17 22:33:17 --> Config Class Initialized
INFO - 2024-06-17 22:33:17 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:17 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:17 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:17 --> URI Class Initialized
INFO - 2024-06-17 22:33:17 --> Router Class Initialized
INFO - 2024-06-17 22:33:17 --> Output Class Initialized
INFO - 2024-06-17 22:33:17 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:17 --> Input Class Initialized
INFO - 2024-06-17 22:33:17 --> Language Class Initialized
INFO - 2024-06-17 22:33:17 --> Language Class Initialized
INFO - 2024-06-17 22:33:17 --> Config Class Initialized
INFO - 2024-06-17 22:33:17 --> Loader Class Initialized
INFO - 2024-06-17 22:33:17 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:17 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:17 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:17 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:17 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:17 --> Controller Class Initialized
INFO - 2024-06-17 22:33:21 --> Config Class Initialized
INFO - 2024-06-17 22:33:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:21 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:21 --> URI Class Initialized
INFO - 2024-06-17 22:33:21 --> Router Class Initialized
INFO - 2024-06-17 22:33:21 --> Output Class Initialized
INFO - 2024-06-17 22:33:21 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:21 --> Input Class Initialized
INFO - 2024-06-17 22:33:21 --> Language Class Initialized
INFO - 2024-06-17 22:33:21 --> Language Class Initialized
INFO - 2024-06-17 22:33:21 --> Config Class Initialized
INFO - 2024-06-17 22:33:21 --> Loader Class Initialized
INFO - 2024-06-17 22:33:21 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:21 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:21 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:21 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:21 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:21 --> Controller Class Initialized
INFO - 2024-06-17 22:33:33 --> Config Class Initialized
INFO - 2024-06-17 22:33:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:33 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:33 --> URI Class Initialized
INFO - 2024-06-17 22:33:33 --> Router Class Initialized
INFO - 2024-06-17 22:33:33 --> Output Class Initialized
INFO - 2024-06-17 22:33:33 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:33 --> Input Class Initialized
INFO - 2024-06-17 22:33:33 --> Language Class Initialized
INFO - 2024-06-17 22:33:33 --> Language Class Initialized
INFO - 2024-06-17 22:33:33 --> Config Class Initialized
INFO - 2024-06-17 22:33:33 --> Loader Class Initialized
INFO - 2024-06-17 22:33:33 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:33 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:33 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:33 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:33 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:33 --> Controller Class Initialized
DEBUG - 2024-06-17 22:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:33:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:33:33 --> Final output sent to browser
DEBUG - 2024-06-17 22:33:33 --> Total execution time: 0.0368
INFO - 2024-06-17 22:33:41 --> Config Class Initialized
INFO - 2024-06-17 22:33:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:41 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:41 --> URI Class Initialized
INFO - 2024-06-17 22:33:41 --> Router Class Initialized
INFO - 2024-06-17 22:33:41 --> Output Class Initialized
INFO - 2024-06-17 22:33:41 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:41 --> Input Class Initialized
INFO - 2024-06-17 22:33:41 --> Language Class Initialized
INFO - 2024-06-17 22:33:41 --> Language Class Initialized
INFO - 2024-06-17 22:33:41 --> Config Class Initialized
INFO - 2024-06-17 22:33:41 --> Loader Class Initialized
INFO - 2024-06-17 22:33:41 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:41 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:41 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:41 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:41 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:41 --> Controller Class Initialized
DEBUG - 2024-06-17 22:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:33:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:33:41 --> Final output sent to browser
DEBUG - 2024-06-17 22:33:41 --> Total execution time: 0.0267
INFO - 2024-06-17 22:33:48 --> Config Class Initialized
INFO - 2024-06-17 22:33:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:48 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:48 --> URI Class Initialized
INFO - 2024-06-17 22:33:48 --> Router Class Initialized
INFO - 2024-06-17 22:33:48 --> Output Class Initialized
INFO - 2024-06-17 22:33:48 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:48 --> Input Class Initialized
INFO - 2024-06-17 22:33:48 --> Language Class Initialized
INFO - 2024-06-17 22:33:48 --> Language Class Initialized
INFO - 2024-06-17 22:33:48 --> Config Class Initialized
INFO - 2024-06-17 22:33:48 --> Loader Class Initialized
INFO - 2024-06-17 22:33:48 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:48 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:48 --> Controller Class Initialized
DEBUG - 2024-06-17 22:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:33:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:33:48 --> Final output sent to browser
DEBUG - 2024-06-17 22:33:48 --> Total execution time: 0.0304
INFO - 2024-06-17 22:33:48 --> Config Class Initialized
INFO - 2024-06-17 22:33:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:48 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:48 --> URI Class Initialized
INFO - 2024-06-17 22:33:48 --> Router Class Initialized
INFO - 2024-06-17 22:33:48 --> Output Class Initialized
INFO - 2024-06-17 22:33:48 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:48 --> Input Class Initialized
INFO - 2024-06-17 22:33:48 --> Language Class Initialized
ERROR - 2024-06-17 22:33:48 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:33:48 --> Config Class Initialized
INFO - 2024-06-17 22:33:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:33:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:33:48 --> Utf8 Class Initialized
INFO - 2024-06-17 22:33:48 --> URI Class Initialized
INFO - 2024-06-17 22:33:48 --> Router Class Initialized
INFO - 2024-06-17 22:33:48 --> Output Class Initialized
INFO - 2024-06-17 22:33:48 --> Security Class Initialized
DEBUG - 2024-06-17 22:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:33:48 --> Input Class Initialized
INFO - 2024-06-17 22:33:48 --> Language Class Initialized
INFO - 2024-06-17 22:33:48 --> Language Class Initialized
INFO - 2024-06-17 22:33:48 --> Config Class Initialized
INFO - 2024-06-17 22:33:48 --> Loader Class Initialized
INFO - 2024-06-17 22:33:48 --> Helper loaded: url_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: file_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: form_helper
INFO - 2024-06-17 22:33:48 --> Helper loaded: my_helper
INFO - 2024-06-17 22:33:48 --> Database Driver Class Initialized
INFO - 2024-06-17 22:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:33:48 --> Controller Class Initialized
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:06 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:06 --> URI Class Initialized
INFO - 2024-06-17 22:34:06 --> Router Class Initialized
INFO - 2024-06-17 22:34:06 --> Output Class Initialized
INFO - 2024-06-17 22:34:06 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:06 --> Input Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Loader Class Initialized
INFO - 2024-06-17 22:34:06 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:06 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:06 --> Controller Class Initialized
INFO - 2024-06-17 22:34:06 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:06 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:06 --> URI Class Initialized
INFO - 2024-06-17 22:34:06 --> Router Class Initialized
INFO - 2024-06-17 22:34:06 --> Output Class Initialized
INFO - 2024-06-17 22:34:06 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:06 --> Input Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Loader Class Initialized
INFO - 2024-06-17 22:34:06 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:06 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:06 --> Controller Class Initialized
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:06 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:06 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:06 --> URI Class Initialized
INFO - 2024-06-17 22:34:06 --> Router Class Initialized
INFO - 2024-06-17 22:34:06 --> Output Class Initialized
INFO - 2024-06-17 22:34:06 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:06 --> Input Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Language Class Initialized
INFO - 2024-06-17 22:34:06 --> Config Class Initialized
INFO - 2024-06-17 22:34:06 --> Loader Class Initialized
INFO - 2024-06-17 22:34:06 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:06 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:06 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:06 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:34:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:06 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:06 --> Total execution time: 0.0244
INFO - 2024-06-17 22:34:13 --> Config Class Initialized
INFO - 2024-06-17 22:34:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:13 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:13 --> URI Class Initialized
INFO - 2024-06-17 22:34:13 --> Router Class Initialized
INFO - 2024-06-17 22:34:13 --> Output Class Initialized
INFO - 2024-06-17 22:34:13 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:13 --> Input Class Initialized
INFO - 2024-06-17 22:34:13 --> Language Class Initialized
INFO - 2024-06-17 22:34:13 --> Language Class Initialized
INFO - 2024-06-17 22:34:13 --> Config Class Initialized
INFO - 2024-06-17 22:34:13 --> Loader Class Initialized
INFO - 2024-06-17 22:34:13 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:13 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:13 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:13 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:13 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:13 --> Controller Class Initialized
INFO - 2024-06-17 22:34:13 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:34:13 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:13 --> Total execution time: 0.0302
INFO - 2024-06-17 22:34:13 --> Config Class Initialized
INFO - 2024-06-17 22:34:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:13 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:13 --> URI Class Initialized
INFO - 2024-06-17 22:34:13 --> Router Class Initialized
INFO - 2024-06-17 22:34:13 --> Output Class Initialized
INFO - 2024-06-17 22:34:13 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:13 --> Input Class Initialized
INFO - 2024-06-17 22:34:13 --> Language Class Initialized
INFO - 2024-06-17 22:34:13 --> Language Class Initialized
INFO - 2024-06-17 22:34:13 --> Config Class Initialized
INFO - 2024-06-17 22:34:13 --> Loader Class Initialized
INFO - 2024-06-17 22:34:14 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:14 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:14 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:14 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:14 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:14 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 22:34:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:14 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:14 --> Total execution time: 0.0269
INFO - 2024-06-17 22:34:18 --> Config Class Initialized
INFO - 2024-06-17 22:34:18 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:18 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:18 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:18 --> URI Class Initialized
INFO - 2024-06-17 22:34:18 --> Router Class Initialized
INFO - 2024-06-17 22:34:18 --> Output Class Initialized
INFO - 2024-06-17 22:34:18 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:18 --> Input Class Initialized
INFO - 2024-06-17 22:34:18 --> Language Class Initialized
INFO - 2024-06-17 22:34:18 --> Language Class Initialized
INFO - 2024-06-17 22:34:18 --> Config Class Initialized
INFO - 2024-06-17 22:34:18 --> Loader Class Initialized
INFO - 2024-06-17 22:34:18 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:18 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:18 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:18 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:18 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:18 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-06-17 22:34:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:18 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:18 --> Total execution time: 0.0256
INFO - 2024-06-17 22:34:19 --> Config Class Initialized
INFO - 2024-06-17 22:34:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:19 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:19 --> URI Class Initialized
INFO - 2024-06-17 22:34:19 --> Router Class Initialized
INFO - 2024-06-17 22:34:19 --> Output Class Initialized
INFO - 2024-06-17 22:34:19 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:19 --> Input Class Initialized
INFO - 2024-06-17 22:34:19 --> Language Class Initialized
INFO - 2024-06-17 22:34:19 --> Language Class Initialized
INFO - 2024-06-17 22:34:19 --> Config Class Initialized
INFO - 2024-06-17 22:34:19 --> Loader Class Initialized
INFO - 2024-06-17 22:34:19 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:19 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:19 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:19 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:19 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:19 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:34:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:19 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:19 --> Total execution time: 0.0251
INFO - 2024-06-17 22:34:28 --> Config Class Initialized
INFO - 2024-06-17 22:34:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:28 --> URI Class Initialized
INFO - 2024-06-17 22:34:28 --> Router Class Initialized
INFO - 2024-06-17 22:34:28 --> Output Class Initialized
INFO - 2024-06-17 22:34:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:28 --> Input Class Initialized
INFO - 2024-06-17 22:34:28 --> Language Class Initialized
INFO - 2024-06-17 22:34:28 --> Language Class Initialized
INFO - 2024-06-17 22:34:28 --> Config Class Initialized
INFO - 2024-06-17 22:34:28 --> Loader Class Initialized
INFO - 2024-06-17 22:34:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:28 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:34:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:28 --> Total execution time: 0.0294
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:31 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:31 --> URI Class Initialized
INFO - 2024-06-17 22:34:31 --> Router Class Initialized
INFO - 2024-06-17 22:34:31 --> Output Class Initialized
INFO - 2024-06-17 22:34:31 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:31 --> Input Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Loader Class Initialized
INFO - 2024-06-17 22:34:31 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:31 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:31 --> Controller Class Initialized
INFO - 2024-06-17 22:34:31 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:31 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:31 --> URI Class Initialized
INFO - 2024-06-17 22:34:31 --> Router Class Initialized
INFO - 2024-06-17 22:34:31 --> Output Class Initialized
INFO - 2024-06-17 22:34:31 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:31 --> Input Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Loader Class Initialized
INFO - 2024-06-17 22:34:31 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:31 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:31 --> Controller Class Initialized
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:31 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:31 --> URI Class Initialized
INFO - 2024-06-17 22:34:31 --> Router Class Initialized
INFO - 2024-06-17 22:34:31 --> Output Class Initialized
INFO - 2024-06-17 22:34:31 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:31 --> Input Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Language Class Initialized
INFO - 2024-06-17 22:34:31 --> Config Class Initialized
INFO - 2024-06-17 22:34:31 --> Loader Class Initialized
INFO - 2024-06-17 22:34:31 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:31 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:31 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:31 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:34:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:31 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:31 --> Total execution time: 0.0265
INFO - 2024-06-17 22:34:42 --> Config Class Initialized
INFO - 2024-06-17 22:34:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:42 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:42 --> URI Class Initialized
INFO - 2024-06-17 22:34:42 --> Router Class Initialized
INFO - 2024-06-17 22:34:42 --> Output Class Initialized
INFO - 2024-06-17 22:34:42 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:42 --> Input Class Initialized
INFO - 2024-06-17 22:34:42 --> Language Class Initialized
INFO - 2024-06-17 22:34:42 --> Language Class Initialized
INFO - 2024-06-17 22:34:42 --> Config Class Initialized
INFO - 2024-06-17 22:34:42 --> Loader Class Initialized
INFO - 2024-06-17 22:34:42 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:42 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:42 --> Controller Class Initialized
INFO - 2024-06-17 22:34:42 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:34:42 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:42 --> Total execution time: 0.0290
INFO - 2024-06-17 22:34:42 --> Config Class Initialized
INFO - 2024-06-17 22:34:42 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:42 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:42 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:42 --> URI Class Initialized
INFO - 2024-06-17 22:34:42 --> Router Class Initialized
INFO - 2024-06-17 22:34:42 --> Output Class Initialized
INFO - 2024-06-17 22:34:42 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:42 --> Input Class Initialized
INFO - 2024-06-17 22:34:42 --> Language Class Initialized
INFO - 2024-06-17 22:34:42 --> Language Class Initialized
INFO - 2024-06-17 22:34:42 --> Config Class Initialized
INFO - 2024-06-17 22:34:42 --> Loader Class Initialized
INFO - 2024-06-17 22:34:42 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:42 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:42 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:42 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 22:34:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:42 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:42 --> Total execution time: 0.0341
INFO - 2024-06-17 22:34:44 --> Config Class Initialized
INFO - 2024-06-17 22:34:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:44 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:44 --> URI Class Initialized
INFO - 2024-06-17 22:34:44 --> Router Class Initialized
INFO - 2024-06-17 22:34:44 --> Output Class Initialized
INFO - 2024-06-17 22:34:44 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:44 --> Input Class Initialized
INFO - 2024-06-17 22:34:44 --> Language Class Initialized
INFO - 2024-06-17 22:34:44 --> Language Class Initialized
INFO - 2024-06-17 22:34:44 --> Config Class Initialized
INFO - 2024-06-17 22:34:44 --> Loader Class Initialized
INFO - 2024-06-17 22:34:44 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:44 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:44 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:44 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:44 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:44 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:34:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:44 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:44 --> Total execution time: 0.0267
INFO - 2024-06-17 22:34:58 --> Config Class Initialized
INFO - 2024-06-17 22:34:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:58 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:58 --> URI Class Initialized
INFO - 2024-06-17 22:34:58 --> Router Class Initialized
INFO - 2024-06-17 22:34:58 --> Output Class Initialized
INFO - 2024-06-17 22:34:58 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:58 --> Input Class Initialized
INFO - 2024-06-17 22:34:58 --> Language Class Initialized
INFO - 2024-06-17 22:34:58 --> Language Class Initialized
INFO - 2024-06-17 22:34:58 --> Config Class Initialized
INFO - 2024-06-17 22:34:58 --> Loader Class Initialized
INFO - 2024-06-17 22:34:58 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:58 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:58 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:58 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:58 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:58 --> Controller Class Initialized
INFO - 2024-06-17 22:34:58 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:34:59 --> Config Class Initialized
INFO - 2024-06-17 22:34:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:59 --> URI Class Initialized
INFO - 2024-06-17 22:34:59 --> Router Class Initialized
INFO - 2024-06-17 22:34:59 --> Output Class Initialized
INFO - 2024-06-17 22:34:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:59 --> Input Class Initialized
INFO - 2024-06-17 22:34:59 --> Language Class Initialized
INFO - 2024-06-17 22:34:59 --> Language Class Initialized
INFO - 2024-06-17 22:34:59 --> Config Class Initialized
INFO - 2024-06-17 22:34:59 --> Loader Class Initialized
INFO - 2024-06-17 22:34:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:59 --> Controller Class Initialized
INFO - 2024-06-17 22:34:59 --> Config Class Initialized
INFO - 2024-06-17 22:34:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:34:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:34:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:34:59 --> URI Class Initialized
INFO - 2024-06-17 22:34:59 --> Router Class Initialized
INFO - 2024-06-17 22:34:59 --> Output Class Initialized
INFO - 2024-06-17 22:34:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:34:59 --> Input Class Initialized
INFO - 2024-06-17 22:34:59 --> Language Class Initialized
INFO - 2024-06-17 22:34:59 --> Language Class Initialized
INFO - 2024-06-17 22:34:59 --> Config Class Initialized
INFO - 2024-06-17 22:34:59 --> Loader Class Initialized
INFO - 2024-06-17 22:34:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:34:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:34:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:34:59 --> Controller Class Initialized
DEBUG - 2024-06-17 22:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:34:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:34:59 --> Final output sent to browser
DEBUG - 2024-06-17 22:34:59 --> Total execution time: 0.0261
INFO - 2024-06-17 22:35:05 --> Config Class Initialized
INFO - 2024-06-17 22:35:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:05 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:05 --> URI Class Initialized
INFO - 2024-06-17 22:35:05 --> Router Class Initialized
INFO - 2024-06-17 22:35:05 --> Output Class Initialized
INFO - 2024-06-17 22:35:05 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:05 --> Input Class Initialized
INFO - 2024-06-17 22:35:05 --> Language Class Initialized
INFO - 2024-06-17 22:35:05 --> Language Class Initialized
INFO - 2024-06-17 22:35:05 --> Config Class Initialized
INFO - 2024-06-17 22:35:05 --> Loader Class Initialized
INFO - 2024-06-17 22:35:05 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:05 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:05 --> Controller Class Initialized
INFO - 2024-06-17 22:35:05 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:35:05 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:05 --> Total execution time: 0.0321
INFO - 2024-06-17 22:35:05 --> Config Class Initialized
INFO - 2024-06-17 22:35:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:05 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:05 --> URI Class Initialized
INFO - 2024-06-17 22:35:05 --> Router Class Initialized
INFO - 2024-06-17 22:35:05 --> Output Class Initialized
INFO - 2024-06-17 22:35:05 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:05 --> Input Class Initialized
INFO - 2024-06-17 22:35:05 --> Language Class Initialized
INFO - 2024-06-17 22:35:05 --> Language Class Initialized
INFO - 2024-06-17 22:35:05 --> Config Class Initialized
INFO - 2024-06-17 22:35:05 --> Loader Class Initialized
INFO - 2024-06-17 22:35:05 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:05 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:05 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:05 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-17 22:35:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:05 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:05 --> Total execution time: 0.0294
INFO - 2024-06-17 22:35:09 --> Config Class Initialized
INFO - 2024-06-17 22:35:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:09 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:09 --> URI Class Initialized
INFO - 2024-06-17 22:35:09 --> Router Class Initialized
INFO - 2024-06-17 22:35:09 --> Output Class Initialized
INFO - 2024-06-17 22:35:09 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:09 --> Input Class Initialized
INFO - 2024-06-17 22:35:09 --> Language Class Initialized
INFO - 2024-06-17 22:35:09 --> Language Class Initialized
INFO - 2024-06-17 22:35:09 --> Config Class Initialized
INFO - 2024-06-17 22:35:09 --> Loader Class Initialized
INFO - 2024-06-17 22:35:09 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:09 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:09 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:35:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:09 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:09 --> Total execution time: 0.0269
INFO - 2024-06-17 22:35:09 --> Config Class Initialized
INFO - 2024-06-17 22:35:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:09 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:09 --> URI Class Initialized
INFO - 2024-06-17 22:35:09 --> Router Class Initialized
INFO - 2024-06-17 22:35:09 --> Output Class Initialized
INFO - 2024-06-17 22:35:09 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:09 --> Input Class Initialized
INFO - 2024-06-17 22:35:09 --> Language Class Initialized
ERROR - 2024-06-17 22:35:09 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:35:09 --> Config Class Initialized
INFO - 2024-06-17 22:35:09 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:09 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:09 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:09 --> URI Class Initialized
INFO - 2024-06-17 22:35:09 --> Router Class Initialized
INFO - 2024-06-17 22:35:09 --> Output Class Initialized
INFO - 2024-06-17 22:35:09 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:09 --> Input Class Initialized
INFO - 2024-06-17 22:35:09 --> Language Class Initialized
INFO - 2024-06-17 22:35:09 --> Language Class Initialized
INFO - 2024-06-17 22:35:09 --> Config Class Initialized
INFO - 2024-06-17 22:35:09 --> Loader Class Initialized
INFO - 2024-06-17 22:35:09 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:09 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:09 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:09 --> Controller Class Initialized
INFO - 2024-06-17 22:35:13 --> Config Class Initialized
INFO - 2024-06-17 22:35:13 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:13 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:13 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:13 --> URI Class Initialized
INFO - 2024-06-17 22:35:13 --> Router Class Initialized
INFO - 2024-06-17 22:35:13 --> Output Class Initialized
INFO - 2024-06-17 22:35:13 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:13 --> Input Class Initialized
INFO - 2024-06-17 22:35:13 --> Language Class Initialized
INFO - 2024-06-17 22:35:13 --> Language Class Initialized
INFO - 2024-06-17 22:35:13 --> Config Class Initialized
INFO - 2024-06-17 22:35:13 --> Loader Class Initialized
INFO - 2024-06-17 22:35:13 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:13 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:13 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:13 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:13 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:13 --> Controller Class Initialized
INFO - 2024-06-17 22:35:13 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:13 --> Total execution time: 0.0287
INFO - 2024-06-17 22:35:20 --> Config Class Initialized
INFO - 2024-06-17 22:35:20 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:20 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:20 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:20 --> URI Class Initialized
INFO - 2024-06-17 22:35:20 --> Router Class Initialized
INFO - 2024-06-17 22:35:20 --> Output Class Initialized
INFO - 2024-06-17 22:35:20 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:20 --> Input Class Initialized
INFO - 2024-06-17 22:35:20 --> Language Class Initialized
INFO - 2024-06-17 22:35:20 --> Language Class Initialized
INFO - 2024-06-17 22:35:20 --> Config Class Initialized
INFO - 2024-06-17 22:35:20 --> Loader Class Initialized
INFO - 2024-06-17 22:35:20 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:20 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:20 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:20 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:20 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:20 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:35:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:20 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:20 --> Total execution time: 0.0325
INFO - 2024-06-17 22:35:28 --> Config Class Initialized
INFO - 2024-06-17 22:35:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:28 --> URI Class Initialized
INFO - 2024-06-17 22:35:28 --> Router Class Initialized
INFO - 2024-06-17 22:35:28 --> Output Class Initialized
INFO - 2024-06-17 22:35:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:28 --> Input Class Initialized
INFO - 2024-06-17 22:35:28 --> Language Class Initialized
INFO - 2024-06-17 22:35:28 --> Language Class Initialized
INFO - 2024-06-17 22:35:28 --> Config Class Initialized
INFO - 2024-06-17 22:35:28 --> Loader Class Initialized
INFO - 2024-06-17 22:35:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:28 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:35:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:28 --> Total execution time: 0.0301
INFO - 2024-06-17 22:35:28 --> Config Class Initialized
INFO - 2024-06-17 22:35:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:28 --> URI Class Initialized
INFO - 2024-06-17 22:35:28 --> Router Class Initialized
INFO - 2024-06-17 22:35:28 --> Output Class Initialized
INFO - 2024-06-17 22:35:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:28 --> Input Class Initialized
INFO - 2024-06-17 22:35:28 --> Language Class Initialized
ERROR - 2024-06-17 22:35:28 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:35:28 --> Config Class Initialized
INFO - 2024-06-17 22:35:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:28 --> URI Class Initialized
INFO - 2024-06-17 22:35:28 --> Router Class Initialized
INFO - 2024-06-17 22:35:28 --> Output Class Initialized
INFO - 2024-06-17 22:35:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:28 --> Input Class Initialized
INFO - 2024-06-17 22:35:28 --> Language Class Initialized
INFO - 2024-06-17 22:35:28 --> Language Class Initialized
INFO - 2024-06-17 22:35:28 --> Config Class Initialized
INFO - 2024-06-17 22:35:28 --> Loader Class Initialized
INFO - 2024-06-17 22:35:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:28 --> Controller Class Initialized
INFO - 2024-06-17 22:35:32 --> Config Class Initialized
INFO - 2024-06-17 22:35:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:33 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:33 --> URI Class Initialized
INFO - 2024-06-17 22:35:33 --> Router Class Initialized
INFO - 2024-06-17 22:35:33 --> Output Class Initialized
INFO - 2024-06-17 22:35:33 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:33 --> Input Class Initialized
INFO - 2024-06-17 22:35:33 --> Language Class Initialized
INFO - 2024-06-17 22:35:33 --> Language Class Initialized
INFO - 2024-06-17 22:35:33 --> Config Class Initialized
INFO - 2024-06-17 22:35:33 --> Loader Class Initialized
INFO - 2024-06-17 22:35:33 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:33 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:33 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:33 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:33 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:33 --> Controller Class Initialized
INFO - 2024-06-17 22:35:33 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:33 --> Total execution time: 0.0255
INFO - 2024-06-17 22:35:38 --> Config Class Initialized
INFO - 2024-06-17 22:35:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:38 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:38 --> URI Class Initialized
INFO - 2024-06-17 22:35:38 --> Router Class Initialized
INFO - 2024-06-17 22:35:38 --> Output Class Initialized
INFO - 2024-06-17 22:35:38 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:38 --> Input Class Initialized
INFO - 2024-06-17 22:35:38 --> Language Class Initialized
INFO - 2024-06-17 22:35:38 --> Language Class Initialized
INFO - 2024-06-17 22:35:38 --> Config Class Initialized
INFO - 2024-06-17 22:35:38 --> Loader Class Initialized
INFO - 2024-06-17 22:35:38 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:38 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:38 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:38 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:38 --> Total execution time: 0.0494
INFO - 2024-06-17 22:35:38 --> Config Class Initialized
INFO - 2024-06-17 22:35:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:38 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:38 --> URI Class Initialized
INFO - 2024-06-17 22:35:38 --> Router Class Initialized
INFO - 2024-06-17 22:35:38 --> Output Class Initialized
INFO - 2024-06-17 22:35:38 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:38 --> Input Class Initialized
INFO - 2024-06-17 22:35:38 --> Language Class Initialized
ERROR - 2024-06-17 22:35:38 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:35:38 --> Config Class Initialized
INFO - 2024-06-17 22:35:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:38 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:38 --> URI Class Initialized
INFO - 2024-06-17 22:35:38 --> Router Class Initialized
INFO - 2024-06-17 22:35:38 --> Output Class Initialized
INFO - 2024-06-17 22:35:38 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:38 --> Input Class Initialized
INFO - 2024-06-17 22:35:38 --> Language Class Initialized
INFO - 2024-06-17 22:35:38 --> Language Class Initialized
INFO - 2024-06-17 22:35:38 --> Config Class Initialized
INFO - 2024-06-17 22:35:38 --> Loader Class Initialized
INFO - 2024-06-17 22:35:38 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:38 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:38 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:38 --> Controller Class Initialized
INFO - 2024-06-17 22:35:40 --> Config Class Initialized
INFO - 2024-06-17 22:35:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:35:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:35:40 --> Utf8 Class Initialized
INFO - 2024-06-17 22:35:40 --> URI Class Initialized
INFO - 2024-06-17 22:35:40 --> Router Class Initialized
INFO - 2024-06-17 22:35:40 --> Output Class Initialized
INFO - 2024-06-17 22:35:40 --> Security Class Initialized
DEBUG - 2024-06-17 22:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:35:40 --> Input Class Initialized
INFO - 2024-06-17 22:35:40 --> Language Class Initialized
INFO - 2024-06-17 22:35:40 --> Language Class Initialized
INFO - 2024-06-17 22:35:40 --> Config Class Initialized
INFO - 2024-06-17 22:35:40 --> Loader Class Initialized
INFO - 2024-06-17 22:35:40 --> Helper loaded: url_helper
INFO - 2024-06-17 22:35:40 --> Helper loaded: file_helper
INFO - 2024-06-17 22:35:40 --> Helper loaded: form_helper
INFO - 2024-06-17 22:35:40 --> Helper loaded: my_helper
INFO - 2024-06-17 22:35:40 --> Database Driver Class Initialized
INFO - 2024-06-17 22:35:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:35:40 --> Controller Class Initialized
DEBUG - 2024-06-17 22:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:35:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:35:40 --> Final output sent to browser
DEBUG - 2024-06-17 22:35:40 --> Total execution time: 0.0349
INFO - 2024-06-17 22:36:05 --> Config Class Initialized
INFO - 2024-06-17 22:36:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:05 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:05 --> URI Class Initialized
INFO - 2024-06-17 22:36:05 --> Router Class Initialized
INFO - 2024-06-17 22:36:05 --> Output Class Initialized
INFO - 2024-06-17 22:36:05 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:05 --> Input Class Initialized
INFO - 2024-06-17 22:36:05 --> Language Class Initialized
INFO - 2024-06-17 22:36:05 --> Language Class Initialized
INFO - 2024-06-17 22:36:05 --> Config Class Initialized
INFO - 2024-06-17 22:36:05 --> Loader Class Initialized
INFO - 2024-06-17 22:36:05 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:05 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:05 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_walikelas_tahfiz/views/list.php
DEBUG - 2024-06-17 22:36:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:05 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:05 --> Total execution time: 0.0328
INFO - 2024-06-17 22:36:05 --> Config Class Initialized
INFO - 2024-06-17 22:36:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:05 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:05 --> URI Class Initialized
INFO - 2024-06-17 22:36:05 --> Router Class Initialized
INFO - 2024-06-17 22:36:05 --> Output Class Initialized
INFO - 2024-06-17 22:36:05 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:05 --> Input Class Initialized
INFO - 2024-06-17 22:36:05 --> Language Class Initialized
ERROR - 2024-06-17 22:36:05 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:36:05 --> Config Class Initialized
INFO - 2024-06-17 22:36:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:05 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:05 --> URI Class Initialized
INFO - 2024-06-17 22:36:05 --> Router Class Initialized
INFO - 2024-06-17 22:36:05 --> Output Class Initialized
INFO - 2024-06-17 22:36:05 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:05 --> Input Class Initialized
INFO - 2024-06-17 22:36:05 --> Language Class Initialized
INFO - 2024-06-17 22:36:05 --> Language Class Initialized
INFO - 2024-06-17 22:36:05 --> Config Class Initialized
INFO - 2024-06-17 22:36:05 --> Loader Class Initialized
INFO - 2024-06-17 22:36:05 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:05 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:05 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:05 --> Controller Class Initialized
INFO - 2024-06-17 22:36:12 --> Config Class Initialized
INFO - 2024-06-17 22:36:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:12 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:12 --> URI Class Initialized
INFO - 2024-06-17 22:36:12 --> Router Class Initialized
INFO - 2024-06-17 22:36:12 --> Output Class Initialized
INFO - 2024-06-17 22:36:12 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:12 --> Input Class Initialized
INFO - 2024-06-17 22:36:12 --> Language Class Initialized
INFO - 2024-06-17 22:36:12 --> Language Class Initialized
INFO - 2024-06-17 22:36:12 --> Config Class Initialized
INFO - 2024-06-17 22:36:12 --> Loader Class Initialized
INFO - 2024-06-17 22:36:12 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:12 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:12 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:36:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:12 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:12 --> Total execution time: 0.0243
INFO - 2024-06-17 22:36:12 --> Config Class Initialized
INFO - 2024-06-17 22:36:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:12 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:12 --> URI Class Initialized
INFO - 2024-06-17 22:36:12 --> Router Class Initialized
INFO - 2024-06-17 22:36:12 --> Output Class Initialized
INFO - 2024-06-17 22:36:12 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:12 --> Input Class Initialized
INFO - 2024-06-17 22:36:12 --> Language Class Initialized
ERROR - 2024-06-17 22:36:12 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:36:12 --> Config Class Initialized
INFO - 2024-06-17 22:36:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:12 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:12 --> URI Class Initialized
INFO - 2024-06-17 22:36:12 --> Router Class Initialized
INFO - 2024-06-17 22:36:12 --> Output Class Initialized
INFO - 2024-06-17 22:36:12 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:12 --> Input Class Initialized
INFO - 2024-06-17 22:36:12 --> Language Class Initialized
INFO - 2024-06-17 22:36:12 --> Language Class Initialized
INFO - 2024-06-17 22:36:12 --> Config Class Initialized
INFO - 2024-06-17 22:36:12 --> Loader Class Initialized
INFO - 2024-06-17 22:36:12 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:12 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:12 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:12 --> Controller Class Initialized
INFO - 2024-06-17 22:36:18 --> Config Class Initialized
INFO - 2024-06-17 22:36:18 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:18 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:18 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:18 --> URI Class Initialized
INFO - 2024-06-17 22:36:18 --> Router Class Initialized
INFO - 2024-06-17 22:36:18 --> Output Class Initialized
INFO - 2024-06-17 22:36:18 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:18 --> Input Class Initialized
INFO - 2024-06-17 22:36:18 --> Language Class Initialized
INFO - 2024-06-17 22:36:18 --> Language Class Initialized
INFO - 2024-06-17 22:36:18 --> Config Class Initialized
INFO - 2024-06-17 22:36:18 --> Loader Class Initialized
INFO - 2024-06-17 22:36:18 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:18 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:18 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:18 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:18 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:18 --> Controller Class Initialized
INFO - 2024-06-17 22:36:21 --> Config Class Initialized
INFO - 2024-06-17 22:36:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:21 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:21 --> URI Class Initialized
INFO - 2024-06-17 22:36:21 --> Router Class Initialized
INFO - 2024-06-17 22:36:21 --> Output Class Initialized
INFO - 2024-06-17 22:36:21 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:21 --> Input Class Initialized
INFO - 2024-06-17 22:36:21 --> Language Class Initialized
INFO - 2024-06-17 22:36:21 --> Language Class Initialized
INFO - 2024-06-17 22:36:21 --> Config Class Initialized
INFO - 2024-06-17 22:36:21 --> Loader Class Initialized
INFO - 2024-06-17 22:36:21 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:21 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:21 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:21 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:21 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:21 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:36:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:21 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:21 --> Total execution time: 0.0684
INFO - 2024-06-17 22:36:34 --> Config Class Initialized
INFO - 2024-06-17 22:36:34 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:34 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:34 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:34 --> URI Class Initialized
INFO - 2024-06-17 22:36:34 --> Router Class Initialized
INFO - 2024-06-17 22:36:34 --> Output Class Initialized
INFO - 2024-06-17 22:36:34 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:34 --> Input Class Initialized
INFO - 2024-06-17 22:36:34 --> Language Class Initialized
INFO - 2024-06-17 22:36:34 --> Language Class Initialized
INFO - 2024-06-17 22:36:34 --> Config Class Initialized
INFO - 2024-06-17 22:36:34 --> Loader Class Initialized
INFO - 2024-06-17 22:36:34 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:34 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:34 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:34 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:34 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:34 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-17 22:36:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:34 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:34 --> Total execution time: 0.0236
INFO - 2024-06-17 22:36:34 --> Config Class Initialized
INFO - 2024-06-17 22:36:34 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:34 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:34 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:34 --> URI Class Initialized
INFO - 2024-06-17 22:36:34 --> Router Class Initialized
INFO - 2024-06-17 22:36:34 --> Output Class Initialized
INFO - 2024-06-17 22:36:34 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:34 --> Input Class Initialized
INFO - 2024-06-17 22:36:34 --> Language Class Initialized
ERROR - 2024-06-17 22:36:34 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:36:35 --> Config Class Initialized
INFO - 2024-06-17 22:36:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:35 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:35 --> URI Class Initialized
INFO - 2024-06-17 22:36:35 --> Router Class Initialized
INFO - 2024-06-17 22:36:35 --> Output Class Initialized
INFO - 2024-06-17 22:36:35 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:35 --> Input Class Initialized
INFO - 2024-06-17 22:36:35 --> Language Class Initialized
INFO - 2024-06-17 22:36:35 --> Language Class Initialized
INFO - 2024-06-17 22:36:35 --> Config Class Initialized
INFO - 2024-06-17 22:36:35 --> Loader Class Initialized
INFO - 2024-06-17 22:36:35 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:35 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:35 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:35 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:35 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:35 --> Controller Class Initialized
INFO - 2024-06-17 22:36:40 --> Config Class Initialized
INFO - 2024-06-17 22:36:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:40 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:40 --> URI Class Initialized
INFO - 2024-06-17 22:36:40 --> Router Class Initialized
INFO - 2024-06-17 22:36:40 --> Output Class Initialized
INFO - 2024-06-17 22:36:40 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:40 --> Input Class Initialized
INFO - 2024-06-17 22:36:40 --> Language Class Initialized
INFO - 2024-06-17 22:36:40 --> Language Class Initialized
INFO - 2024-06-17 22:36:40 --> Config Class Initialized
INFO - 2024-06-17 22:36:40 --> Loader Class Initialized
INFO - 2024-06-17 22:36:40 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:40 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:40 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:40 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:40 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:40 --> Controller Class Initialized
INFO - 2024-06-17 22:36:40 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:40 --> Total execution time: 0.0280
INFO - 2024-06-17 22:36:46 --> Config Class Initialized
INFO - 2024-06-17 22:36:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:46 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:46 --> URI Class Initialized
INFO - 2024-06-17 22:36:46 --> Router Class Initialized
INFO - 2024-06-17 22:36:46 --> Output Class Initialized
INFO - 2024-06-17 22:36:46 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:46 --> Input Class Initialized
INFO - 2024-06-17 22:36:46 --> Language Class Initialized
INFO - 2024-06-17 22:36:46 --> Language Class Initialized
INFO - 2024-06-17 22:36:46 --> Config Class Initialized
INFO - 2024-06-17 22:36:46 --> Loader Class Initialized
INFO - 2024-06-17 22:36:46 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:46 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:46 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:46 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:46 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:46 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kelas/views/list.php
DEBUG - 2024-06-17 22:36:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:46 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:46 --> Total execution time: 0.0483
INFO - 2024-06-17 22:36:53 --> Config Class Initialized
INFO - 2024-06-17 22:36:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:53 --> URI Class Initialized
INFO - 2024-06-17 22:36:53 --> Router Class Initialized
INFO - 2024-06-17 22:36:53 --> Output Class Initialized
INFO - 2024-06-17 22:36:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:53 --> Input Class Initialized
INFO - 2024-06-17 22:36:53 --> Language Class Initialized
INFO - 2024-06-17 22:36:53 --> Language Class Initialized
INFO - 2024-06-17 22:36:53 --> Config Class Initialized
INFO - 2024-06-17 22:36:53 --> Loader Class Initialized
INFO - 2024-06-17 22:36:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:53 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-06-17 22:36:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:53 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:53 --> Total execution time: 0.0449
INFO - 2024-06-17 22:36:53 --> Config Class Initialized
INFO - 2024-06-17 22:36:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:53 --> URI Class Initialized
INFO - 2024-06-17 22:36:53 --> Router Class Initialized
INFO - 2024-06-17 22:36:53 --> Output Class Initialized
INFO - 2024-06-17 22:36:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:53 --> Input Class Initialized
INFO - 2024-06-17 22:36:53 --> Language Class Initialized
ERROR - 2024-06-17 22:36:53 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:36:53 --> Config Class Initialized
INFO - 2024-06-17 22:36:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:53 --> URI Class Initialized
INFO - 2024-06-17 22:36:53 --> Router Class Initialized
INFO - 2024-06-17 22:36:53 --> Output Class Initialized
INFO - 2024-06-17 22:36:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:53 --> Input Class Initialized
INFO - 2024-06-17 22:36:53 --> Language Class Initialized
INFO - 2024-06-17 22:36:53 --> Language Class Initialized
INFO - 2024-06-17 22:36:53 --> Config Class Initialized
INFO - 2024-06-17 22:36:53 --> Loader Class Initialized
INFO - 2024-06-17 22:36:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:53 --> Controller Class Initialized
INFO - 2024-06-17 22:36:59 --> Config Class Initialized
INFO - 2024-06-17 22:36:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:59 --> URI Class Initialized
INFO - 2024-06-17 22:36:59 --> Router Class Initialized
INFO - 2024-06-17 22:36:59 --> Output Class Initialized
INFO - 2024-06-17 22:36:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:59 --> Input Class Initialized
INFO - 2024-06-17 22:36:59 --> Language Class Initialized
INFO - 2024-06-17 22:36:59 --> Language Class Initialized
INFO - 2024-06-17 22:36:59 --> Config Class Initialized
INFO - 2024-06-17 22:36:59 --> Loader Class Initialized
INFO - 2024-06-17 22:36:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:59 --> Controller Class Initialized
DEBUG - 2024-06-17 22:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:36:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:36:59 --> Final output sent to browser
DEBUG - 2024-06-17 22:36:59 --> Total execution time: 0.0257
INFO - 2024-06-17 22:36:59 --> Config Class Initialized
INFO - 2024-06-17 22:36:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:59 --> URI Class Initialized
INFO - 2024-06-17 22:36:59 --> Router Class Initialized
INFO - 2024-06-17 22:36:59 --> Output Class Initialized
INFO - 2024-06-17 22:36:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:59 --> Input Class Initialized
INFO - 2024-06-17 22:36:59 --> Language Class Initialized
ERROR - 2024-06-17 22:36:59 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:36:59 --> Config Class Initialized
INFO - 2024-06-17 22:36:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:36:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:36:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:36:59 --> URI Class Initialized
INFO - 2024-06-17 22:36:59 --> Router Class Initialized
INFO - 2024-06-17 22:36:59 --> Output Class Initialized
INFO - 2024-06-17 22:36:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:36:59 --> Input Class Initialized
INFO - 2024-06-17 22:36:59 --> Language Class Initialized
INFO - 2024-06-17 22:36:59 --> Language Class Initialized
INFO - 2024-06-17 22:36:59 --> Config Class Initialized
INFO - 2024-06-17 22:36:59 --> Loader Class Initialized
INFO - 2024-06-17 22:36:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:36:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:36:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:36:59 --> Controller Class Initialized
INFO - 2024-06-17 22:37:03 --> Config Class Initialized
INFO - 2024-06-17 22:37:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:37:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:37:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:37:03 --> URI Class Initialized
INFO - 2024-06-17 22:37:03 --> Router Class Initialized
INFO - 2024-06-17 22:37:03 --> Output Class Initialized
INFO - 2024-06-17 22:37:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:37:03 --> Input Class Initialized
INFO - 2024-06-17 22:37:03 --> Language Class Initialized
INFO - 2024-06-17 22:37:03 --> Language Class Initialized
INFO - 2024-06-17 22:37:03 --> Config Class Initialized
INFO - 2024-06-17 22:37:03 --> Loader Class Initialized
INFO - 2024-06-17 22:37:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:37:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:37:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:37:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:37:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:37:03 --> Controller Class Initialized
DEBUG - 2024-06-17 22:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:37:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:37:03 --> Final output sent to browser
DEBUG - 2024-06-17 22:37:03 --> Total execution time: 0.0263
INFO - 2024-06-17 22:37:58 --> Config Class Initialized
INFO - 2024-06-17 22:37:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:37:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:37:58 --> Utf8 Class Initialized
INFO - 2024-06-17 22:37:58 --> URI Class Initialized
INFO - 2024-06-17 22:37:58 --> Router Class Initialized
INFO - 2024-06-17 22:37:58 --> Output Class Initialized
INFO - 2024-06-17 22:37:58 --> Security Class Initialized
DEBUG - 2024-06-17 22:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:37:58 --> Input Class Initialized
INFO - 2024-06-17 22:37:58 --> Language Class Initialized
INFO - 2024-06-17 22:37:58 --> Language Class Initialized
INFO - 2024-06-17 22:37:58 --> Config Class Initialized
INFO - 2024-06-17 22:37:58 --> Loader Class Initialized
INFO - 2024-06-17 22:37:58 --> Helper loaded: url_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: file_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: form_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: my_helper
INFO - 2024-06-17 22:37:58 --> Database Driver Class Initialized
INFO - 2024-06-17 22:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:37:58 --> Controller Class Initialized
INFO - 2024-06-17 22:37:58 --> Config Class Initialized
INFO - 2024-06-17 22:37:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:37:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:37:58 --> Utf8 Class Initialized
INFO - 2024-06-17 22:37:58 --> URI Class Initialized
INFO - 2024-06-17 22:37:58 --> Router Class Initialized
INFO - 2024-06-17 22:37:58 --> Output Class Initialized
INFO - 2024-06-17 22:37:58 --> Security Class Initialized
DEBUG - 2024-06-17 22:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:37:58 --> Input Class Initialized
INFO - 2024-06-17 22:37:58 --> Language Class Initialized
INFO - 2024-06-17 22:37:58 --> Language Class Initialized
INFO - 2024-06-17 22:37:58 --> Config Class Initialized
INFO - 2024-06-17 22:37:58 --> Loader Class Initialized
INFO - 2024-06-17 22:37:58 --> Helper loaded: url_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: file_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: form_helper
INFO - 2024-06-17 22:37:58 --> Helper loaded: my_helper
INFO - 2024-06-17 22:37:58 --> Database Driver Class Initialized
INFO - 2024-06-17 22:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:37:58 --> Controller Class Initialized
DEBUG - 2024-06-17 22:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:37:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:37:58 --> Final output sent to browser
DEBUG - 2024-06-17 22:37:58 --> Total execution time: 0.0279
INFO - 2024-06-17 22:37:58 --> Config Class Initialized
INFO - 2024-06-17 22:37:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:37:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:37:58 --> Utf8 Class Initialized
INFO - 2024-06-17 22:37:58 --> URI Class Initialized
INFO - 2024-06-17 22:37:58 --> Router Class Initialized
INFO - 2024-06-17 22:37:58 --> Output Class Initialized
INFO - 2024-06-17 22:37:58 --> Security Class Initialized
DEBUG - 2024-06-17 22:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:37:58 --> Input Class Initialized
INFO - 2024-06-17 22:37:58 --> Language Class Initialized
ERROR - 2024-06-17 22:37:58 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:37:59 --> Config Class Initialized
INFO - 2024-06-17 22:37:59 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:37:59 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:37:59 --> Utf8 Class Initialized
INFO - 2024-06-17 22:37:59 --> URI Class Initialized
INFO - 2024-06-17 22:37:59 --> Router Class Initialized
INFO - 2024-06-17 22:37:59 --> Output Class Initialized
INFO - 2024-06-17 22:37:59 --> Security Class Initialized
DEBUG - 2024-06-17 22:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:37:59 --> Input Class Initialized
INFO - 2024-06-17 22:37:59 --> Language Class Initialized
INFO - 2024-06-17 22:37:59 --> Language Class Initialized
INFO - 2024-06-17 22:37:59 --> Config Class Initialized
INFO - 2024-06-17 22:37:59 --> Loader Class Initialized
INFO - 2024-06-17 22:37:59 --> Helper loaded: url_helper
INFO - 2024-06-17 22:37:59 --> Helper loaded: file_helper
INFO - 2024-06-17 22:37:59 --> Helper loaded: form_helper
INFO - 2024-06-17 22:37:59 --> Helper loaded: my_helper
INFO - 2024-06-17 22:37:59 --> Database Driver Class Initialized
INFO - 2024-06-17 22:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:37:59 --> Controller Class Initialized
INFO - 2024-06-17 22:38:00 --> Config Class Initialized
INFO - 2024-06-17 22:38:00 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:38:00 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:38:00 --> Utf8 Class Initialized
INFO - 2024-06-17 22:38:00 --> URI Class Initialized
INFO - 2024-06-17 22:38:00 --> Router Class Initialized
INFO - 2024-06-17 22:38:00 --> Output Class Initialized
INFO - 2024-06-17 22:38:00 --> Security Class Initialized
DEBUG - 2024-06-17 22:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:38:00 --> Input Class Initialized
INFO - 2024-06-17 22:38:00 --> Language Class Initialized
INFO - 2024-06-17 22:38:00 --> Language Class Initialized
INFO - 2024-06-17 22:38:00 --> Config Class Initialized
INFO - 2024-06-17 22:38:00 --> Loader Class Initialized
INFO - 2024-06-17 22:38:00 --> Helper loaded: url_helper
INFO - 2024-06-17 22:38:00 --> Helper loaded: file_helper
INFO - 2024-06-17 22:38:00 --> Helper loaded: form_helper
INFO - 2024-06-17 22:38:00 --> Helper loaded: my_helper
INFO - 2024-06-17 22:38:00 --> Database Driver Class Initialized
INFO - 2024-06-17 22:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:38:00 --> Controller Class Initialized
DEBUG - 2024-06-17 22:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:38:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:38:00 --> Final output sent to browser
DEBUG - 2024-06-17 22:38:00 --> Total execution time: 0.0539
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:38:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:38:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:38:10 --> URI Class Initialized
INFO - 2024-06-17 22:38:10 --> Router Class Initialized
INFO - 2024-06-17 22:38:10 --> Output Class Initialized
INFO - 2024-06-17 22:38:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:38:10 --> Input Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Loader Class Initialized
INFO - 2024-06-17 22:38:10 --> Helper loaded: url_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: file_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: form_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: my_helper
INFO - 2024-06-17 22:38:10 --> Database Driver Class Initialized
INFO - 2024-06-17 22:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:38:10 --> Controller Class Initialized
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:38:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:38:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:38:10 --> URI Class Initialized
INFO - 2024-06-17 22:38:10 --> Router Class Initialized
INFO - 2024-06-17 22:38:10 --> Output Class Initialized
INFO - 2024-06-17 22:38:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:38:10 --> Input Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Loader Class Initialized
INFO - 2024-06-17 22:38:10 --> Helper loaded: url_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: file_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: form_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: my_helper
INFO - 2024-06-17 22:38:10 --> Database Driver Class Initialized
INFO - 2024-06-17 22:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:38:10 --> Controller Class Initialized
DEBUG - 2024-06-17 22:38:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:38:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:38:10 --> Final output sent to browser
DEBUG - 2024-06-17 22:38:10 --> Total execution time: 0.0269
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:38:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:38:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:38:10 --> URI Class Initialized
INFO - 2024-06-17 22:38:10 --> Router Class Initialized
INFO - 2024-06-17 22:38:10 --> Output Class Initialized
INFO - 2024-06-17 22:38:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:38:10 --> Input Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
ERROR - 2024-06-17 22:38:10 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:38:10 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:38:10 --> Utf8 Class Initialized
INFO - 2024-06-17 22:38:10 --> URI Class Initialized
INFO - 2024-06-17 22:38:10 --> Router Class Initialized
INFO - 2024-06-17 22:38:10 --> Output Class Initialized
INFO - 2024-06-17 22:38:10 --> Security Class Initialized
DEBUG - 2024-06-17 22:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:38:10 --> Input Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Language Class Initialized
INFO - 2024-06-17 22:38:10 --> Config Class Initialized
INFO - 2024-06-17 22:38:10 --> Loader Class Initialized
INFO - 2024-06-17 22:38:10 --> Helper loaded: url_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: file_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: form_helper
INFO - 2024-06-17 22:38:10 --> Helper loaded: my_helper
INFO - 2024-06-17 22:38:10 --> Database Driver Class Initialized
INFO - 2024-06-17 22:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:38:10 --> Controller Class Initialized
INFO - 2024-06-17 22:39:01 --> Config Class Initialized
INFO - 2024-06-17 22:39:01 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:39:01 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:39:01 --> Utf8 Class Initialized
INFO - 2024-06-17 22:39:01 --> URI Class Initialized
INFO - 2024-06-17 22:39:01 --> Router Class Initialized
INFO - 2024-06-17 22:39:01 --> Output Class Initialized
INFO - 2024-06-17 22:39:01 --> Security Class Initialized
DEBUG - 2024-06-17 22:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:39:01 --> Input Class Initialized
INFO - 2024-06-17 22:39:01 --> Language Class Initialized
INFO - 2024-06-17 22:39:01 --> Language Class Initialized
INFO - 2024-06-17 22:39:01 --> Config Class Initialized
INFO - 2024-06-17 22:39:01 --> Loader Class Initialized
INFO - 2024-06-17 22:39:01 --> Helper loaded: url_helper
INFO - 2024-06-17 22:39:01 --> Helper loaded: file_helper
INFO - 2024-06-17 22:39:01 --> Helper loaded: form_helper
INFO - 2024-06-17 22:39:01 --> Helper loaded: my_helper
INFO - 2024-06-17 22:39:01 --> Database Driver Class Initialized
INFO - 2024-06-17 22:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:39:01 --> Controller Class Initialized
DEBUG - 2024-06-17 22:39:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:39:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:39:01 --> Final output sent to browser
DEBUG - 2024-06-17 22:39:01 --> Total execution time: 0.0508
INFO - 2024-06-17 22:39:02 --> Config Class Initialized
INFO - 2024-06-17 22:39:02 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:39:02 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:39:02 --> Utf8 Class Initialized
INFO - 2024-06-17 22:39:02 --> URI Class Initialized
INFO - 2024-06-17 22:39:02 --> Router Class Initialized
INFO - 2024-06-17 22:39:02 --> Output Class Initialized
INFO - 2024-06-17 22:39:02 --> Security Class Initialized
DEBUG - 2024-06-17 22:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:39:02 --> Input Class Initialized
INFO - 2024-06-17 22:39:02 --> Language Class Initialized
ERROR - 2024-06-17 22:39:02 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:39:02 --> Config Class Initialized
INFO - 2024-06-17 22:39:02 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:39:02 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:39:02 --> Utf8 Class Initialized
INFO - 2024-06-17 22:39:02 --> URI Class Initialized
INFO - 2024-06-17 22:39:02 --> Router Class Initialized
INFO - 2024-06-17 22:39:02 --> Output Class Initialized
INFO - 2024-06-17 22:39:02 --> Security Class Initialized
DEBUG - 2024-06-17 22:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:39:02 --> Input Class Initialized
INFO - 2024-06-17 22:39:02 --> Language Class Initialized
INFO - 2024-06-17 22:39:02 --> Language Class Initialized
INFO - 2024-06-17 22:39:02 --> Config Class Initialized
INFO - 2024-06-17 22:39:02 --> Loader Class Initialized
INFO - 2024-06-17 22:39:02 --> Helper loaded: url_helper
INFO - 2024-06-17 22:39:02 --> Helper loaded: file_helper
INFO - 2024-06-17 22:39:02 --> Helper loaded: form_helper
INFO - 2024-06-17 22:39:02 --> Helper loaded: my_helper
INFO - 2024-06-17 22:39:02 --> Database Driver Class Initialized
INFO - 2024-06-17 22:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:39:02 --> Controller Class Initialized
INFO - 2024-06-17 22:39:16 --> Config Class Initialized
INFO - 2024-06-17 22:39:16 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:39:16 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:39:16 --> Utf8 Class Initialized
INFO - 2024-06-17 22:39:16 --> URI Class Initialized
INFO - 2024-06-17 22:39:16 --> Router Class Initialized
INFO - 2024-06-17 22:39:16 --> Output Class Initialized
INFO - 2024-06-17 22:39:16 --> Security Class Initialized
DEBUG - 2024-06-17 22:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:39:16 --> Input Class Initialized
INFO - 2024-06-17 22:39:16 --> Language Class Initialized
INFO - 2024-06-17 22:39:16 --> Language Class Initialized
INFO - 2024-06-17 22:39:16 --> Config Class Initialized
INFO - 2024-06-17 22:39:16 --> Loader Class Initialized
INFO - 2024-06-17 22:39:16 --> Helper loaded: url_helper
INFO - 2024-06-17 22:39:16 --> Helper loaded: file_helper
INFO - 2024-06-17 22:39:16 --> Helper loaded: form_helper
INFO - 2024-06-17 22:39:16 --> Helper loaded: my_helper
INFO - 2024-06-17 22:39:16 --> Database Driver Class Initialized
INFO - 2024-06-17 22:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:39:16 --> Controller Class Initialized
INFO - 2024-06-17 22:39:22 --> Config Class Initialized
INFO - 2024-06-17 22:39:22 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:39:22 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:39:22 --> Utf8 Class Initialized
INFO - 2024-06-17 22:39:22 --> URI Class Initialized
INFO - 2024-06-17 22:39:22 --> Router Class Initialized
INFO - 2024-06-17 22:39:22 --> Output Class Initialized
INFO - 2024-06-17 22:39:22 --> Security Class Initialized
DEBUG - 2024-06-17 22:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:39:22 --> Input Class Initialized
INFO - 2024-06-17 22:39:22 --> Language Class Initialized
INFO - 2024-06-17 22:39:22 --> Language Class Initialized
INFO - 2024-06-17 22:39:22 --> Config Class Initialized
INFO - 2024-06-17 22:39:22 --> Loader Class Initialized
INFO - 2024-06-17 22:39:22 --> Helper loaded: url_helper
INFO - 2024-06-17 22:39:22 --> Helper loaded: file_helper
INFO - 2024-06-17 22:39:22 --> Helper loaded: form_helper
INFO - 2024-06-17 22:39:22 --> Helper loaded: my_helper
INFO - 2024-06-17 22:39:22 --> Database Driver Class Initialized
INFO - 2024-06-17 22:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:39:22 --> Controller Class Initialized
INFO - 2024-06-17 22:40:27 --> Config Class Initialized
INFO - 2024-06-17 22:40:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:40:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:40:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:40:27 --> URI Class Initialized
INFO - 2024-06-17 22:40:27 --> Router Class Initialized
INFO - 2024-06-17 22:40:27 --> Output Class Initialized
INFO - 2024-06-17 22:40:27 --> Security Class Initialized
DEBUG - 2024-06-17 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:40:27 --> Input Class Initialized
INFO - 2024-06-17 22:40:27 --> Language Class Initialized
INFO - 2024-06-17 22:40:27 --> Language Class Initialized
INFO - 2024-06-17 22:40:27 --> Config Class Initialized
INFO - 2024-06-17 22:40:27 --> Loader Class Initialized
INFO - 2024-06-17 22:40:27 --> Helper loaded: url_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: file_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: form_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: my_helper
INFO - 2024-06-17 22:40:27 --> Database Driver Class Initialized
INFO - 2024-06-17 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:40:27 --> Controller Class Initialized
DEBUG - 2024-06-17 22:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_projek/views/list.php
DEBUG - 2024-06-17 22:40:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:40:27 --> Final output sent to browser
DEBUG - 2024-06-17 22:40:27 --> Total execution time: 0.0276
INFO - 2024-06-17 22:40:27 --> Config Class Initialized
INFO - 2024-06-17 22:40:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:40:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:40:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:40:27 --> URI Class Initialized
INFO - 2024-06-17 22:40:27 --> Router Class Initialized
INFO - 2024-06-17 22:40:27 --> Output Class Initialized
INFO - 2024-06-17 22:40:27 --> Security Class Initialized
DEBUG - 2024-06-17 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:40:27 --> Input Class Initialized
INFO - 2024-06-17 22:40:27 --> Language Class Initialized
ERROR - 2024-06-17 22:40:27 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:40:27 --> Config Class Initialized
INFO - 2024-06-17 22:40:27 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:40:27 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:40:27 --> Utf8 Class Initialized
INFO - 2024-06-17 22:40:27 --> URI Class Initialized
INFO - 2024-06-17 22:40:27 --> Router Class Initialized
INFO - 2024-06-17 22:40:27 --> Output Class Initialized
INFO - 2024-06-17 22:40:27 --> Security Class Initialized
DEBUG - 2024-06-17 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:40:27 --> Input Class Initialized
INFO - 2024-06-17 22:40:27 --> Language Class Initialized
INFO - 2024-06-17 22:40:27 --> Language Class Initialized
INFO - 2024-06-17 22:40:27 --> Config Class Initialized
INFO - 2024-06-17 22:40:27 --> Loader Class Initialized
INFO - 2024-06-17 22:40:27 --> Helper loaded: url_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: file_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: form_helper
INFO - 2024-06-17 22:40:27 --> Helper loaded: my_helper
INFO - 2024-06-17 22:40:27 --> Database Driver Class Initialized
INFO - 2024-06-17 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:40:27 --> Controller Class Initialized
INFO - 2024-06-17 22:40:30 --> Config Class Initialized
INFO - 2024-06-17 22:40:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:40:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:40:30 --> Utf8 Class Initialized
INFO - 2024-06-17 22:40:30 --> URI Class Initialized
INFO - 2024-06-17 22:40:30 --> Router Class Initialized
INFO - 2024-06-17 22:40:30 --> Output Class Initialized
INFO - 2024-06-17 22:40:30 --> Security Class Initialized
DEBUG - 2024-06-17 22:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:40:30 --> Input Class Initialized
INFO - 2024-06-17 22:40:30 --> Language Class Initialized
INFO - 2024-06-17 22:40:30 --> Language Class Initialized
INFO - 2024-06-17 22:40:30 --> Config Class Initialized
INFO - 2024-06-17 22:40:30 --> Loader Class Initialized
INFO - 2024-06-17 22:40:30 --> Helper loaded: url_helper
INFO - 2024-06-17 22:40:30 --> Helper loaded: file_helper
INFO - 2024-06-17 22:40:30 --> Helper loaded: form_helper
INFO - 2024-06-17 22:40:30 --> Helper loaded: my_helper
INFO - 2024-06-17 22:40:30 --> Database Driver Class Initialized
INFO - 2024-06-17 22:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:40:30 --> Controller Class Initialized
INFO - 2024-06-17 22:40:30 --> Final output sent to browser
DEBUG - 2024-06-17 22:40:30 --> Total execution time: 0.0235
INFO - 2024-06-17 22:41:39 --> Config Class Initialized
INFO - 2024-06-17 22:41:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:39 --> URI Class Initialized
INFO - 2024-06-17 22:41:39 --> Router Class Initialized
INFO - 2024-06-17 22:41:39 --> Output Class Initialized
INFO - 2024-06-17 22:41:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:39 --> Input Class Initialized
INFO - 2024-06-17 22:41:39 --> Language Class Initialized
INFO - 2024-06-17 22:41:39 --> Language Class Initialized
INFO - 2024-06-17 22:41:39 --> Config Class Initialized
INFO - 2024-06-17 22:41:39 --> Loader Class Initialized
INFO - 2024-06-17 22:41:39 --> Helper loaded: url_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: file_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: form_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: my_helper
INFO - 2024-06-17 22:41:39 --> Database Driver Class Initialized
INFO - 2024-06-17 22:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:41:39 --> Controller Class Initialized
INFO - 2024-06-17 22:41:39 --> Final output sent to browser
DEBUG - 2024-06-17 22:41:39 --> Total execution time: 0.0338
INFO - 2024-06-17 22:41:39 --> Config Class Initialized
INFO - 2024-06-17 22:41:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:39 --> URI Class Initialized
INFO - 2024-06-17 22:41:39 --> Router Class Initialized
INFO - 2024-06-17 22:41:39 --> Output Class Initialized
INFO - 2024-06-17 22:41:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:39 --> Input Class Initialized
INFO - 2024-06-17 22:41:39 --> Language Class Initialized
ERROR - 2024-06-17 22:41:39 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:41:39 --> Config Class Initialized
INFO - 2024-06-17 22:41:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:39 --> URI Class Initialized
INFO - 2024-06-17 22:41:39 --> Router Class Initialized
INFO - 2024-06-17 22:41:39 --> Output Class Initialized
INFO - 2024-06-17 22:41:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:39 --> Input Class Initialized
INFO - 2024-06-17 22:41:39 --> Language Class Initialized
INFO - 2024-06-17 22:41:39 --> Language Class Initialized
INFO - 2024-06-17 22:41:39 --> Config Class Initialized
INFO - 2024-06-17 22:41:39 --> Loader Class Initialized
INFO - 2024-06-17 22:41:39 --> Helper loaded: url_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: file_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: form_helper
INFO - 2024-06-17 22:41:39 --> Helper loaded: my_helper
INFO - 2024-06-17 22:41:39 --> Database Driver Class Initialized
INFO - 2024-06-17 22:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:41:39 --> Controller Class Initialized
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:50 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:50 --> URI Class Initialized
INFO - 2024-06-17 22:41:50 --> Router Class Initialized
INFO - 2024-06-17 22:41:50 --> Output Class Initialized
INFO - 2024-06-17 22:41:50 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:50 --> Input Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Loader Class Initialized
INFO - 2024-06-17 22:41:50 --> Helper loaded: url_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: file_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: form_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: my_helper
INFO - 2024-06-17 22:41:50 --> Database Driver Class Initialized
INFO - 2024-06-17 22:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:41:50 --> Controller Class Initialized
INFO - 2024-06-17 22:41:50 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:50 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:50 --> URI Class Initialized
INFO - 2024-06-17 22:41:50 --> Router Class Initialized
INFO - 2024-06-17 22:41:50 --> Output Class Initialized
INFO - 2024-06-17 22:41:50 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:50 --> Input Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Loader Class Initialized
INFO - 2024-06-17 22:41:50 --> Helper loaded: url_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: file_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: form_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: my_helper
INFO - 2024-06-17 22:41:50 --> Database Driver Class Initialized
INFO - 2024-06-17 22:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:41:50 --> Controller Class Initialized
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:41:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:41:50 --> Utf8 Class Initialized
INFO - 2024-06-17 22:41:50 --> URI Class Initialized
INFO - 2024-06-17 22:41:50 --> Router Class Initialized
INFO - 2024-06-17 22:41:50 --> Output Class Initialized
INFO - 2024-06-17 22:41:50 --> Security Class Initialized
DEBUG - 2024-06-17 22:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:41:50 --> Input Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Language Class Initialized
INFO - 2024-06-17 22:41:50 --> Config Class Initialized
INFO - 2024-06-17 22:41:50 --> Loader Class Initialized
INFO - 2024-06-17 22:41:50 --> Helper loaded: url_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: file_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: form_helper
INFO - 2024-06-17 22:41:50 --> Helper loaded: my_helper
INFO - 2024-06-17 22:41:50 --> Database Driver Class Initialized
INFO - 2024-06-17 22:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:41:50 --> Controller Class Initialized
DEBUG - 2024-06-17 22:41:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:41:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:41:50 --> Final output sent to browser
DEBUG - 2024-06-17 22:41:50 --> Total execution time: 0.0247
INFO - 2024-06-17 22:42:11 --> Config Class Initialized
INFO - 2024-06-17 22:42:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:11 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:11 --> URI Class Initialized
INFO - 2024-06-17 22:42:11 --> Router Class Initialized
INFO - 2024-06-17 22:42:11 --> Output Class Initialized
INFO - 2024-06-17 22:42:11 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:11 --> Input Class Initialized
INFO - 2024-06-17 22:42:11 --> Language Class Initialized
INFO - 2024-06-17 22:42:11 --> Language Class Initialized
INFO - 2024-06-17 22:42:11 --> Config Class Initialized
INFO - 2024-06-17 22:42:11 --> Loader Class Initialized
INFO - 2024-06-17 22:42:11 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:11 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:11 --> Controller Class Initialized
INFO - 2024-06-17 22:42:11 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:42:11 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:11 --> Total execution time: 0.0329
INFO - 2024-06-17 22:42:11 --> Config Class Initialized
INFO - 2024-06-17 22:42:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:11 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:11 --> URI Class Initialized
INFO - 2024-06-17 22:42:11 --> Router Class Initialized
INFO - 2024-06-17 22:42:11 --> Output Class Initialized
INFO - 2024-06-17 22:42:11 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:11 --> Input Class Initialized
INFO - 2024-06-17 22:42:11 --> Language Class Initialized
INFO - 2024-06-17 22:42:11 --> Language Class Initialized
INFO - 2024-06-17 22:42:11 --> Config Class Initialized
INFO - 2024-06-17 22:42:11 --> Loader Class Initialized
INFO - 2024-06-17 22:42:11 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:11 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:11 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:11 --> Controller Class Initialized
DEBUG - 2024-06-17 22:42:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-17 22:42:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:42:11 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:11 --> Total execution time: 0.0350
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:19 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:19 --> URI Class Initialized
INFO - 2024-06-17 22:42:19 --> Router Class Initialized
INFO - 2024-06-17 22:42:19 --> Output Class Initialized
INFO - 2024-06-17 22:42:19 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:19 --> Input Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Loader Class Initialized
INFO - 2024-06-17 22:42:19 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:19 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:19 --> Controller Class Initialized
INFO - 2024-06-17 22:42:19 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:19 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:19 --> URI Class Initialized
INFO - 2024-06-17 22:42:19 --> Router Class Initialized
INFO - 2024-06-17 22:42:19 --> Output Class Initialized
INFO - 2024-06-17 22:42:19 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:19 --> Input Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Loader Class Initialized
INFO - 2024-06-17 22:42:19 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:19 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:19 --> Controller Class Initialized
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:19 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:19 --> URI Class Initialized
INFO - 2024-06-17 22:42:19 --> Router Class Initialized
INFO - 2024-06-17 22:42:19 --> Output Class Initialized
INFO - 2024-06-17 22:42:19 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:19 --> Input Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Language Class Initialized
INFO - 2024-06-17 22:42:19 --> Config Class Initialized
INFO - 2024-06-17 22:42:19 --> Loader Class Initialized
INFO - 2024-06-17 22:42:19 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:19 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:19 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:19 --> Controller Class Initialized
DEBUG - 2024-06-17 22:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:42:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:42:19 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:19 --> Total execution time: 0.0252
INFO - 2024-06-17 22:42:28 --> Config Class Initialized
INFO - 2024-06-17 22:42:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:28 --> URI Class Initialized
INFO - 2024-06-17 22:42:28 --> Router Class Initialized
INFO - 2024-06-17 22:42:28 --> Output Class Initialized
INFO - 2024-06-17 22:42:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:28 --> Input Class Initialized
INFO - 2024-06-17 22:42:28 --> Language Class Initialized
INFO - 2024-06-17 22:42:28 --> Language Class Initialized
INFO - 2024-06-17 22:42:28 --> Config Class Initialized
INFO - 2024-06-17 22:42:28 --> Loader Class Initialized
INFO - 2024-06-17 22:42:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:28 --> Controller Class Initialized
INFO - 2024-06-17 22:42:28 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:42:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:28 --> Total execution time: 0.0267
INFO - 2024-06-17 22:42:28 --> Config Class Initialized
INFO - 2024-06-17 22:42:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:28 --> URI Class Initialized
INFO - 2024-06-17 22:42:28 --> Router Class Initialized
INFO - 2024-06-17 22:42:28 --> Output Class Initialized
INFO - 2024-06-17 22:42:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:28 --> Input Class Initialized
INFO - 2024-06-17 22:42:28 --> Language Class Initialized
INFO - 2024-06-17 22:42:28 --> Language Class Initialized
INFO - 2024-06-17 22:42:28 --> Config Class Initialized
INFO - 2024-06-17 22:42:28 --> Loader Class Initialized
INFO - 2024-06-17 22:42:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:28 --> Controller Class Initialized
DEBUG - 2024-06-17 22:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 22:42:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:42:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:28 --> Total execution time: 0.0263
INFO - 2024-06-17 22:42:32 --> Config Class Initialized
INFO - 2024-06-17 22:42:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:32 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:32 --> URI Class Initialized
INFO - 2024-06-17 22:42:32 --> Router Class Initialized
INFO - 2024-06-17 22:42:32 --> Output Class Initialized
INFO - 2024-06-17 22:42:32 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:32 --> Input Class Initialized
INFO - 2024-06-17 22:42:32 --> Language Class Initialized
INFO - 2024-06-17 22:42:32 --> Language Class Initialized
INFO - 2024-06-17 22:42:32 --> Config Class Initialized
INFO - 2024-06-17 22:42:32 --> Loader Class Initialized
INFO - 2024-06-17 22:42:32 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:32 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:32 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:32 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:32 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:32 --> Controller Class Initialized
DEBUG - 2024-06-17 22:42:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2024-06-17 22:42:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:42:32 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:32 --> Total execution time: 0.0313
INFO - 2024-06-17 22:42:35 --> Config Class Initialized
INFO - 2024-06-17 22:42:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:42:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:42:35 --> Utf8 Class Initialized
INFO - 2024-06-17 22:42:35 --> URI Class Initialized
INFO - 2024-06-17 22:42:35 --> Router Class Initialized
INFO - 2024-06-17 22:42:35 --> Output Class Initialized
INFO - 2024-06-17 22:42:35 --> Security Class Initialized
DEBUG - 2024-06-17 22:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:42:35 --> Input Class Initialized
INFO - 2024-06-17 22:42:35 --> Language Class Initialized
INFO - 2024-06-17 22:42:35 --> Language Class Initialized
INFO - 2024-06-17 22:42:35 --> Config Class Initialized
INFO - 2024-06-17 22:42:35 --> Loader Class Initialized
INFO - 2024-06-17 22:42:35 --> Helper loaded: url_helper
INFO - 2024-06-17 22:42:35 --> Helper loaded: file_helper
INFO - 2024-06-17 22:42:35 --> Helper loaded: form_helper
INFO - 2024-06-17 22:42:35 --> Helper loaded: my_helper
INFO - 2024-06-17 22:42:35 --> Database Driver Class Initialized
INFO - 2024-06-17 22:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:42:35 --> Controller Class Initialized
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-06-17 22:42:35 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-06-17 22:42:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-06-17 22:42:39 --> Final output sent to browser
DEBUG - 2024-06-17 22:42:39 --> Total execution time: 4.7230
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:03 --> URI Class Initialized
INFO - 2024-06-17 22:44:03 --> Router Class Initialized
INFO - 2024-06-17 22:44:03 --> Output Class Initialized
INFO - 2024-06-17 22:44:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:03 --> Input Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Loader Class Initialized
INFO - 2024-06-17 22:44:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:03 --> Controller Class Initialized
INFO - 2024-06-17 22:44:03 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:03 --> URI Class Initialized
INFO - 2024-06-17 22:44:03 --> Router Class Initialized
INFO - 2024-06-17 22:44:03 --> Output Class Initialized
INFO - 2024-06-17 22:44:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:03 --> Input Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Loader Class Initialized
INFO - 2024-06-17 22:44:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:03 --> Controller Class Initialized
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:03 --> URI Class Initialized
INFO - 2024-06-17 22:44:03 --> Router Class Initialized
INFO - 2024-06-17 22:44:03 --> Output Class Initialized
INFO - 2024-06-17 22:44:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:03 --> Input Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Language Class Initialized
INFO - 2024-06-17 22:44:03 --> Config Class Initialized
INFO - 2024-06-17 22:44:03 --> Loader Class Initialized
INFO - 2024-06-17 22:44:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:03 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:44:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:03 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:03 --> Total execution time: 0.0270
INFO - 2024-06-17 22:44:15 --> Config Class Initialized
INFO - 2024-06-17 22:44:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:15 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:15 --> URI Class Initialized
INFO - 2024-06-17 22:44:15 --> Router Class Initialized
INFO - 2024-06-17 22:44:15 --> Output Class Initialized
INFO - 2024-06-17 22:44:15 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:15 --> Input Class Initialized
INFO - 2024-06-17 22:44:15 --> Language Class Initialized
INFO - 2024-06-17 22:44:15 --> Language Class Initialized
INFO - 2024-06-17 22:44:15 --> Config Class Initialized
INFO - 2024-06-17 22:44:15 --> Loader Class Initialized
INFO - 2024-06-17 22:44:15 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:15 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:15 --> Controller Class Initialized
INFO - 2024-06-17 22:44:15 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:44:15 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:15 --> Total execution time: 0.0295
INFO - 2024-06-17 22:44:15 --> Config Class Initialized
INFO - 2024-06-17 22:44:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:15 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:15 --> URI Class Initialized
INFO - 2024-06-17 22:44:15 --> Router Class Initialized
INFO - 2024-06-17 22:44:15 --> Output Class Initialized
INFO - 2024-06-17 22:44:15 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:15 --> Input Class Initialized
INFO - 2024-06-17 22:44:15 --> Language Class Initialized
INFO - 2024-06-17 22:44:15 --> Language Class Initialized
INFO - 2024-06-17 22:44:15 --> Config Class Initialized
INFO - 2024-06-17 22:44:15 --> Loader Class Initialized
INFO - 2024-06-17 22:44:15 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:15 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:15 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:15 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 22:44:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:15 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:15 --> Total execution time: 0.0266
INFO - 2024-06-17 22:44:17 --> Config Class Initialized
INFO - 2024-06-17 22:44:17 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:17 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:17 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:17 --> URI Class Initialized
INFO - 2024-06-17 22:44:17 --> Router Class Initialized
INFO - 2024-06-17 22:44:17 --> Output Class Initialized
INFO - 2024-06-17 22:44:17 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:17 --> Input Class Initialized
INFO - 2024-06-17 22:44:17 --> Language Class Initialized
INFO - 2024-06-17 22:44:17 --> Language Class Initialized
INFO - 2024-06-17 22:44:17 --> Config Class Initialized
INFO - 2024-06-17 22:44:17 --> Loader Class Initialized
INFO - 2024-06-17 22:44:17 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:17 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:17 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:17 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:17 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:17 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:44:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:17 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:17 --> Total execution time: 0.0295
INFO - 2024-06-17 22:44:19 --> Config Class Initialized
INFO - 2024-06-17 22:44:19 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:19 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:19 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:19 --> URI Class Initialized
INFO - 2024-06-17 22:44:19 --> Router Class Initialized
INFO - 2024-06-17 22:44:19 --> Output Class Initialized
INFO - 2024-06-17 22:44:19 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:19 --> Input Class Initialized
INFO - 2024-06-17 22:44:19 --> Language Class Initialized
INFO - 2024-06-17 22:44:19 --> Language Class Initialized
INFO - 2024-06-17 22:44:19 --> Config Class Initialized
INFO - 2024-06-17 22:44:19 --> Loader Class Initialized
INFO - 2024-06-17 22:44:19 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:19 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:19 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:19 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:19 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:19 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 22:44:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:19 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:19 --> Total execution time: 0.0295
INFO - 2024-06-17 22:44:21 --> Config Class Initialized
INFO - 2024-06-17 22:44:21 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:21 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:21 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:21 --> URI Class Initialized
INFO - 2024-06-17 22:44:21 --> Router Class Initialized
INFO - 2024-06-17 22:44:21 --> Output Class Initialized
INFO - 2024-06-17 22:44:21 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:21 --> Input Class Initialized
INFO - 2024-06-17 22:44:21 --> Language Class Initialized
INFO - 2024-06-17 22:44:21 --> Language Class Initialized
INFO - 2024-06-17 22:44:21 --> Config Class Initialized
INFO - 2024-06-17 22:44:21 --> Loader Class Initialized
INFO - 2024-06-17 22:44:21 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:21 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:21 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:21 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:21 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:21 --> Controller Class Initialized
INFO - 2024-06-17 22:44:21 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:21 --> Total execution time: 0.0298
INFO - 2024-06-17 22:44:25 --> Config Class Initialized
INFO - 2024-06-17 22:44:25 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:25 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:25 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:25 --> URI Class Initialized
INFO - 2024-06-17 22:44:25 --> Router Class Initialized
INFO - 2024-06-17 22:44:25 --> Output Class Initialized
INFO - 2024-06-17 22:44:25 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:25 --> Input Class Initialized
INFO - 2024-06-17 22:44:25 --> Language Class Initialized
INFO - 2024-06-17 22:44:25 --> Language Class Initialized
INFO - 2024-06-17 22:44:25 --> Config Class Initialized
INFO - 2024-06-17 22:44:25 --> Loader Class Initialized
INFO - 2024-06-17 22:44:25 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:25 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:25 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:25 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:25 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:25 --> Controller Class Initialized
INFO - 2024-06-17 22:44:28 --> Config Class Initialized
INFO - 2024-06-17 22:44:28 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:28 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:28 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:28 --> URI Class Initialized
INFO - 2024-06-17 22:44:28 --> Router Class Initialized
INFO - 2024-06-17 22:44:28 --> Output Class Initialized
INFO - 2024-06-17 22:44:28 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:28 --> Input Class Initialized
INFO - 2024-06-17 22:44:28 --> Language Class Initialized
INFO - 2024-06-17 22:44:28 --> Language Class Initialized
INFO - 2024-06-17 22:44:28 --> Config Class Initialized
INFO - 2024-06-17 22:44:28 --> Loader Class Initialized
INFO - 2024-06-17 22:44:28 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:28 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:28 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:28 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:28 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:28 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:44:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:28 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:28 --> Total execution time: 0.0497
INFO - 2024-06-17 22:44:30 --> Config Class Initialized
INFO - 2024-06-17 22:44:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:30 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:30 --> URI Class Initialized
INFO - 2024-06-17 22:44:30 --> Router Class Initialized
INFO - 2024-06-17 22:44:30 --> Output Class Initialized
INFO - 2024-06-17 22:44:30 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:30 --> Input Class Initialized
INFO - 2024-06-17 22:44:30 --> Language Class Initialized
INFO - 2024-06-17 22:44:30 --> Language Class Initialized
INFO - 2024-06-17 22:44:30 --> Config Class Initialized
INFO - 2024-06-17 22:44:30 --> Loader Class Initialized
INFO - 2024-06-17 22:44:30 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:30 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:30 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-17 22:44:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:30 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:30 --> Total execution time: 0.0375
INFO - 2024-06-17 22:44:30 --> Config Class Initialized
INFO - 2024-06-17 22:44:30 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:30 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:30 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:30 --> URI Class Initialized
INFO - 2024-06-17 22:44:30 --> Router Class Initialized
INFO - 2024-06-17 22:44:30 --> Output Class Initialized
INFO - 2024-06-17 22:44:30 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:30 --> Input Class Initialized
INFO - 2024-06-17 22:44:30 --> Language Class Initialized
INFO - 2024-06-17 22:44:30 --> Language Class Initialized
INFO - 2024-06-17 22:44:30 --> Config Class Initialized
INFO - 2024-06-17 22:44:30 --> Loader Class Initialized
INFO - 2024-06-17 22:44:30 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:30 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:30 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:30 --> Controller Class Initialized
INFO - 2024-06-17 22:44:32 --> Config Class Initialized
INFO - 2024-06-17 22:44:32 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:32 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:32 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:32 --> URI Class Initialized
INFO - 2024-06-17 22:44:32 --> Router Class Initialized
INFO - 2024-06-17 22:44:32 --> Output Class Initialized
INFO - 2024-06-17 22:44:32 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:32 --> Input Class Initialized
INFO - 2024-06-17 22:44:32 --> Language Class Initialized
INFO - 2024-06-17 22:44:32 --> Language Class Initialized
INFO - 2024-06-17 22:44:32 --> Config Class Initialized
INFO - 2024-06-17 22:44:32 --> Loader Class Initialized
INFO - 2024-06-17 22:44:32 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:32 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:32 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:32 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:32 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:32 --> Controller Class Initialized
INFO - 2024-06-17 22:44:35 --> Config Class Initialized
INFO - 2024-06-17 22:44:35 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:35 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:35 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:35 --> URI Class Initialized
INFO - 2024-06-17 22:44:35 --> Router Class Initialized
INFO - 2024-06-17 22:44:35 --> Output Class Initialized
INFO - 2024-06-17 22:44:35 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:35 --> Input Class Initialized
INFO - 2024-06-17 22:44:35 --> Language Class Initialized
INFO - 2024-06-17 22:44:35 --> Language Class Initialized
INFO - 2024-06-17 22:44:35 --> Config Class Initialized
INFO - 2024-06-17 22:44:35 --> Loader Class Initialized
INFO - 2024-06-17 22:44:35 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:35 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:35 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:35 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:35 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:35 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 22:44:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:35 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:35 --> Total execution time: 0.0268
INFO - 2024-06-17 22:44:50 --> Config Class Initialized
INFO - 2024-06-17 22:44:50 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:50 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:50 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:50 --> URI Class Initialized
INFO - 2024-06-17 22:44:50 --> Router Class Initialized
INFO - 2024-06-17 22:44:50 --> Output Class Initialized
INFO - 2024-06-17 22:44:50 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:50 --> Input Class Initialized
INFO - 2024-06-17 22:44:50 --> Language Class Initialized
INFO - 2024-06-17 22:44:50 --> Language Class Initialized
INFO - 2024-06-17 22:44:50 --> Config Class Initialized
INFO - 2024-06-17 22:44:50 --> Loader Class Initialized
INFO - 2024-06-17 22:44:50 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:50 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:50 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:50 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:50 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:50 --> Controller Class Initialized
DEBUG - 2024-06-17 22:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 22:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:44:50 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:50 --> Total execution time: 0.0315
INFO - 2024-06-17 22:44:53 --> Config Class Initialized
INFO - 2024-06-17 22:44:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:44:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:44:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:44:53 --> URI Class Initialized
INFO - 2024-06-17 22:44:53 --> Router Class Initialized
INFO - 2024-06-17 22:44:53 --> Output Class Initialized
INFO - 2024-06-17 22:44:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:44:53 --> Input Class Initialized
INFO - 2024-06-17 22:44:53 --> Language Class Initialized
INFO - 2024-06-17 22:44:53 --> Language Class Initialized
INFO - 2024-06-17 22:44:53 --> Config Class Initialized
INFO - 2024-06-17 22:44:53 --> Loader Class Initialized
INFO - 2024-06-17 22:44:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:44:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:44:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:44:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:44:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:44:53 --> Controller Class Initialized
INFO - 2024-06-17 22:44:53 --> Final output sent to browser
DEBUG - 2024-06-17 22:44:53 --> Total execution time: 0.0526
INFO - 2024-06-17 22:47:23 --> Config Class Initialized
INFO - 2024-06-17 22:47:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:47:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:47:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:47:23 --> URI Class Initialized
INFO - 2024-06-17 22:47:23 --> Router Class Initialized
INFO - 2024-06-17 22:47:23 --> Output Class Initialized
INFO - 2024-06-17 22:47:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:47:23 --> Input Class Initialized
INFO - 2024-06-17 22:47:23 --> Language Class Initialized
INFO - 2024-06-17 22:47:23 --> Language Class Initialized
INFO - 2024-06-17 22:47:23 --> Config Class Initialized
INFO - 2024-06-17 22:47:23 --> Loader Class Initialized
INFO - 2024-06-17 22:47:23 --> Helper loaded: url_helper
INFO - 2024-06-17 22:47:23 --> Helper loaded: file_helper
INFO - 2024-06-17 22:47:23 --> Helper loaded: form_helper
INFO - 2024-06-17 22:47:23 --> Helper loaded: my_helper
INFO - 2024-06-17 22:47:23 --> Database Driver Class Initialized
INFO - 2024-06-17 22:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:47:23 --> Controller Class Initialized
DEBUG - 2024-06-17 22:47:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-06-17 22:47:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:47:23 --> Final output sent to browser
DEBUG - 2024-06-17 22:47:23 --> Total execution time: 0.0276
INFO - 2024-06-17 22:47:29 --> Config Class Initialized
INFO - 2024-06-17 22:47:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:47:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:47:29 --> Utf8 Class Initialized
INFO - 2024-06-17 22:47:29 --> URI Class Initialized
INFO - 2024-06-17 22:47:29 --> Router Class Initialized
INFO - 2024-06-17 22:47:29 --> Output Class Initialized
INFO - 2024-06-17 22:47:29 --> Security Class Initialized
DEBUG - 2024-06-17 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:47:29 --> Input Class Initialized
INFO - 2024-06-17 22:47:29 --> Language Class Initialized
INFO - 2024-06-17 22:47:29 --> Language Class Initialized
INFO - 2024-06-17 22:47:29 --> Config Class Initialized
INFO - 2024-06-17 22:47:29 --> Loader Class Initialized
INFO - 2024-06-17 22:47:29 --> Helper loaded: url_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: file_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: form_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: my_helper
INFO - 2024-06-17 22:47:29 --> Database Driver Class Initialized
INFO - 2024-06-17 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:47:29 --> Controller Class Initialized
INFO - 2024-06-17 22:47:29 --> Config Class Initialized
INFO - 2024-06-17 22:47:29 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:47:29 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:47:29 --> Utf8 Class Initialized
INFO - 2024-06-17 22:47:29 --> URI Class Initialized
INFO - 2024-06-17 22:47:29 --> Router Class Initialized
INFO - 2024-06-17 22:47:29 --> Output Class Initialized
INFO - 2024-06-17 22:47:29 --> Security Class Initialized
DEBUG - 2024-06-17 22:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:47:29 --> Input Class Initialized
INFO - 2024-06-17 22:47:29 --> Language Class Initialized
INFO - 2024-06-17 22:47:29 --> Language Class Initialized
INFO - 2024-06-17 22:47:29 --> Config Class Initialized
INFO - 2024-06-17 22:47:29 --> Loader Class Initialized
INFO - 2024-06-17 22:47:29 --> Helper loaded: url_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: file_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: form_helper
INFO - 2024-06-17 22:47:29 --> Helper loaded: my_helper
INFO - 2024-06-17 22:47:29 --> Database Driver Class Initialized
INFO - 2024-06-17 22:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:47:29 --> Controller Class Initialized
DEBUG - 2024-06-17 22:47:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 22:47:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:47:29 --> Final output sent to browser
DEBUG - 2024-06-17 22:47:29 --> Total execution time: 0.0258
INFO - 2024-06-17 22:47:31 --> Config Class Initialized
INFO - 2024-06-17 22:47:31 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:47:31 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:47:31 --> Utf8 Class Initialized
INFO - 2024-06-17 22:47:31 --> URI Class Initialized
INFO - 2024-06-17 22:47:31 --> Router Class Initialized
INFO - 2024-06-17 22:47:31 --> Output Class Initialized
INFO - 2024-06-17 22:47:31 --> Security Class Initialized
DEBUG - 2024-06-17 22:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:47:31 --> Input Class Initialized
INFO - 2024-06-17 22:47:31 --> Language Class Initialized
INFO - 2024-06-17 22:47:31 --> Language Class Initialized
INFO - 2024-06-17 22:47:31 --> Config Class Initialized
INFO - 2024-06-17 22:47:31 --> Loader Class Initialized
INFO - 2024-06-17 22:47:31 --> Helper loaded: url_helper
INFO - 2024-06-17 22:47:31 --> Helper loaded: file_helper
INFO - 2024-06-17 22:47:31 --> Helper loaded: form_helper
INFO - 2024-06-17 22:47:31 --> Helper loaded: my_helper
INFO - 2024-06-17 22:47:31 --> Database Driver Class Initialized
INFO - 2024-06-17 22:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:47:31 --> Controller Class Initialized
INFO - 2024-06-17 22:47:31 --> Final output sent to browser
DEBUG - 2024-06-17 22:47:31 --> Total execution time: 0.0298
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:50:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:50:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:50:53 --> URI Class Initialized
INFO - 2024-06-17 22:50:53 --> Router Class Initialized
INFO - 2024-06-17 22:50:53 --> Output Class Initialized
INFO - 2024-06-17 22:50:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:50:53 --> Input Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Loader Class Initialized
INFO - 2024-06-17 22:50:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:50:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:50:53 --> Controller Class Initialized
INFO - 2024-06-17 22:50:53 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:50:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:50:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:50:53 --> URI Class Initialized
INFO - 2024-06-17 22:50:53 --> Router Class Initialized
INFO - 2024-06-17 22:50:53 --> Output Class Initialized
INFO - 2024-06-17 22:50:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:50:53 --> Input Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Loader Class Initialized
INFO - 2024-06-17 22:50:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:50:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:50:53 --> Controller Class Initialized
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:50:53 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:50:53 --> Utf8 Class Initialized
INFO - 2024-06-17 22:50:53 --> URI Class Initialized
INFO - 2024-06-17 22:50:53 --> Router Class Initialized
INFO - 2024-06-17 22:50:53 --> Output Class Initialized
INFO - 2024-06-17 22:50:53 --> Security Class Initialized
DEBUG - 2024-06-17 22:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:50:53 --> Input Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Language Class Initialized
INFO - 2024-06-17 22:50:53 --> Config Class Initialized
INFO - 2024-06-17 22:50:53 --> Loader Class Initialized
INFO - 2024-06-17 22:50:53 --> Helper loaded: url_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: file_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: form_helper
INFO - 2024-06-17 22:50:53 --> Helper loaded: my_helper
INFO - 2024-06-17 22:50:53 --> Database Driver Class Initialized
INFO - 2024-06-17 22:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:50:53 --> Controller Class Initialized
DEBUG - 2024-06-17 22:50:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 22:50:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:50:53 --> Final output sent to browser
DEBUG - 2024-06-17 22:50:53 --> Total execution time: 0.0316
INFO - 2024-06-17 22:51:03 --> Config Class Initialized
INFO - 2024-06-17 22:51:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:03 --> URI Class Initialized
INFO - 2024-06-17 22:51:03 --> Router Class Initialized
INFO - 2024-06-17 22:51:03 --> Output Class Initialized
INFO - 2024-06-17 22:51:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:03 --> Input Class Initialized
INFO - 2024-06-17 22:51:03 --> Language Class Initialized
INFO - 2024-06-17 22:51:03 --> Language Class Initialized
INFO - 2024-06-17 22:51:03 --> Config Class Initialized
INFO - 2024-06-17 22:51:03 --> Loader Class Initialized
INFO - 2024-06-17 22:51:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:03 --> Controller Class Initialized
INFO - 2024-06-17 22:51:03 --> Helper loaded: cookie_helper
INFO - 2024-06-17 22:51:03 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:03 --> Total execution time: 0.0397
INFO - 2024-06-17 22:51:03 --> Config Class Initialized
INFO - 2024-06-17 22:51:03 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:03 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:03 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:03 --> URI Class Initialized
INFO - 2024-06-17 22:51:03 --> Router Class Initialized
INFO - 2024-06-17 22:51:03 --> Output Class Initialized
INFO - 2024-06-17 22:51:03 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:03 --> Input Class Initialized
INFO - 2024-06-17 22:51:03 --> Language Class Initialized
INFO - 2024-06-17 22:51:03 --> Language Class Initialized
INFO - 2024-06-17 22:51:03 --> Config Class Initialized
INFO - 2024-06-17 22:51:03 --> Loader Class Initialized
INFO - 2024-06-17 22:51:03 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:03 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:03 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:03 --> Controller Class Initialized
DEBUG - 2024-06-17 22:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-06-17 22:51:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:51:03 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:03 --> Total execution time: 0.0320
INFO - 2024-06-17 22:51:23 --> Config Class Initialized
INFO - 2024-06-17 22:51:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:23 --> URI Class Initialized
INFO - 2024-06-17 22:51:23 --> Router Class Initialized
INFO - 2024-06-17 22:51:23 --> Output Class Initialized
INFO - 2024-06-17 22:51:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:23 --> Input Class Initialized
INFO - 2024-06-17 22:51:23 --> Language Class Initialized
INFO - 2024-06-17 22:51:23 --> Language Class Initialized
INFO - 2024-06-17 22:51:23 --> Config Class Initialized
INFO - 2024-06-17 22:51:23 --> Loader Class Initialized
INFO - 2024-06-17 22:51:23 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:23 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:23 --> Controller Class Initialized
DEBUG - 2024-06-17 22:51:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:51:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:51:23 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:23 --> Total execution time: 0.0258
INFO - 2024-06-17 22:51:23 --> Config Class Initialized
INFO - 2024-06-17 22:51:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:23 --> URI Class Initialized
INFO - 2024-06-17 22:51:23 --> Router Class Initialized
INFO - 2024-06-17 22:51:23 --> Output Class Initialized
INFO - 2024-06-17 22:51:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:23 --> Input Class Initialized
INFO - 2024-06-17 22:51:23 --> Language Class Initialized
ERROR - 2024-06-17 22:51:23 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:51:23 --> Config Class Initialized
INFO - 2024-06-17 22:51:23 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:23 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:23 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:23 --> URI Class Initialized
INFO - 2024-06-17 22:51:23 --> Router Class Initialized
INFO - 2024-06-17 22:51:23 --> Output Class Initialized
INFO - 2024-06-17 22:51:23 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:23 --> Input Class Initialized
INFO - 2024-06-17 22:51:23 --> Language Class Initialized
INFO - 2024-06-17 22:51:23 --> Language Class Initialized
INFO - 2024-06-17 22:51:23 --> Config Class Initialized
INFO - 2024-06-17 22:51:23 --> Loader Class Initialized
INFO - 2024-06-17 22:51:23 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:23 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:23 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:23 --> Controller Class Initialized
INFO - 2024-06-17 22:51:33 --> Config Class Initialized
INFO - 2024-06-17 22:51:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:33 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:33 --> URI Class Initialized
INFO - 2024-06-17 22:51:33 --> Router Class Initialized
INFO - 2024-06-17 22:51:33 --> Output Class Initialized
INFO - 2024-06-17 22:51:33 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:33 --> Input Class Initialized
INFO - 2024-06-17 22:51:33 --> Language Class Initialized
INFO - 2024-06-17 22:51:33 --> Language Class Initialized
INFO - 2024-06-17 22:51:33 --> Config Class Initialized
INFO - 2024-06-17 22:51:33 --> Loader Class Initialized
INFO - 2024-06-17 22:51:33 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:33 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:33 --> Controller Class Initialized
INFO - 2024-06-17 22:51:33 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:33 --> Total execution time: 0.0687
INFO - 2024-06-17 22:51:33 --> Config Class Initialized
INFO - 2024-06-17 22:51:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:33 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:33 --> URI Class Initialized
INFO - 2024-06-17 22:51:33 --> Router Class Initialized
INFO - 2024-06-17 22:51:33 --> Output Class Initialized
INFO - 2024-06-17 22:51:33 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:33 --> Input Class Initialized
INFO - 2024-06-17 22:51:33 --> Language Class Initialized
ERROR - 2024-06-17 22:51:33 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:51:33 --> Config Class Initialized
INFO - 2024-06-17 22:51:33 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:33 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:33 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:33 --> URI Class Initialized
INFO - 2024-06-17 22:51:33 --> Router Class Initialized
INFO - 2024-06-17 22:51:33 --> Output Class Initialized
INFO - 2024-06-17 22:51:33 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:33 --> Input Class Initialized
INFO - 2024-06-17 22:51:33 --> Language Class Initialized
INFO - 2024-06-17 22:51:33 --> Language Class Initialized
INFO - 2024-06-17 22:51:33 --> Config Class Initialized
INFO - 2024-06-17 22:51:33 --> Loader Class Initialized
INFO - 2024-06-17 22:51:33 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:33 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:33 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:33 --> Controller Class Initialized
INFO - 2024-06-17 22:51:39 --> Config Class Initialized
INFO - 2024-06-17 22:51:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:39 --> URI Class Initialized
INFO - 2024-06-17 22:51:39 --> Router Class Initialized
INFO - 2024-06-17 22:51:39 --> Output Class Initialized
INFO - 2024-06-17 22:51:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:39 --> Input Class Initialized
INFO - 2024-06-17 22:51:39 --> Language Class Initialized
INFO - 2024-06-17 22:51:39 --> Language Class Initialized
INFO - 2024-06-17 22:51:39 --> Config Class Initialized
INFO - 2024-06-17 22:51:39 --> Loader Class Initialized
INFO - 2024-06-17 22:51:39 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:39 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:39 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:39 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:39 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:39 --> Controller Class Initialized
INFO - 2024-06-17 22:51:39 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:39 --> Total execution time: 0.0710
INFO - 2024-06-17 22:51:39 --> Config Class Initialized
INFO - 2024-06-17 22:51:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:39 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:39 --> URI Class Initialized
INFO - 2024-06-17 22:51:39 --> Router Class Initialized
INFO - 2024-06-17 22:51:39 --> Output Class Initialized
INFO - 2024-06-17 22:51:39 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:39 --> Input Class Initialized
INFO - 2024-06-17 22:51:39 --> Language Class Initialized
ERROR - 2024-06-17 22:51:39 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:51:40 --> Config Class Initialized
INFO - 2024-06-17 22:51:40 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:40 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:40 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:40 --> URI Class Initialized
INFO - 2024-06-17 22:51:40 --> Router Class Initialized
INFO - 2024-06-17 22:51:40 --> Output Class Initialized
INFO - 2024-06-17 22:51:40 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:40 --> Input Class Initialized
INFO - 2024-06-17 22:51:40 --> Language Class Initialized
INFO - 2024-06-17 22:51:40 --> Language Class Initialized
INFO - 2024-06-17 22:51:40 --> Config Class Initialized
INFO - 2024-06-17 22:51:40 --> Loader Class Initialized
INFO - 2024-06-17 22:51:40 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:40 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:40 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:40 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:40 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:40 --> Controller Class Initialized
INFO - 2024-06-17 22:51:43 --> Config Class Initialized
INFO - 2024-06-17 22:51:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:43 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:43 --> URI Class Initialized
INFO - 2024-06-17 22:51:43 --> Router Class Initialized
INFO - 2024-06-17 22:51:43 --> Output Class Initialized
INFO - 2024-06-17 22:51:43 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:43 --> Input Class Initialized
INFO - 2024-06-17 22:51:43 --> Language Class Initialized
INFO - 2024-06-17 22:51:43 --> Language Class Initialized
INFO - 2024-06-17 22:51:43 --> Config Class Initialized
INFO - 2024-06-17 22:51:43 --> Loader Class Initialized
INFO - 2024-06-17 22:51:43 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:43 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:43 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:43 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:43 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:43 --> Controller Class Initialized
INFO - 2024-06-17 22:51:46 --> Config Class Initialized
INFO - 2024-06-17 22:51:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:46 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:46 --> URI Class Initialized
INFO - 2024-06-17 22:51:46 --> Router Class Initialized
INFO - 2024-06-17 22:51:46 --> Output Class Initialized
INFO - 2024-06-17 22:51:46 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:46 --> Input Class Initialized
INFO - 2024-06-17 22:51:46 --> Language Class Initialized
INFO - 2024-06-17 22:51:46 --> Language Class Initialized
INFO - 2024-06-17 22:51:46 --> Config Class Initialized
INFO - 2024-06-17 22:51:46 --> Loader Class Initialized
INFO - 2024-06-17 22:51:46 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:46 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:46 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:46 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:46 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:46 --> Controller Class Initialized
DEBUG - 2024-06-17 22:51:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:51:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:51:46 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:46 --> Total execution time: 0.0250
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:57 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:57 --> URI Class Initialized
INFO - 2024-06-17 22:51:57 --> Router Class Initialized
INFO - 2024-06-17 22:51:57 --> Output Class Initialized
INFO - 2024-06-17 22:51:57 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:57 --> Input Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Loader Class Initialized
INFO - 2024-06-17 22:51:57 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:57 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:57 --> Controller Class Initialized
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:57 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:57 --> URI Class Initialized
INFO - 2024-06-17 22:51:57 --> Router Class Initialized
INFO - 2024-06-17 22:51:57 --> Output Class Initialized
INFO - 2024-06-17 22:51:57 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:57 --> Input Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Loader Class Initialized
INFO - 2024-06-17 22:51:57 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:57 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:57 --> Controller Class Initialized
DEBUG - 2024-06-17 22:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:51:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:51:57 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:57 --> Total execution time: 0.0253
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:57 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:57 --> URI Class Initialized
INFO - 2024-06-17 22:51:57 --> Router Class Initialized
INFO - 2024-06-17 22:51:57 --> Output Class Initialized
INFO - 2024-06-17 22:51:57 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:57 --> Input Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
ERROR - 2024-06-17 22:51:57 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:57 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:57 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:57 --> URI Class Initialized
INFO - 2024-06-17 22:51:57 --> Router Class Initialized
INFO - 2024-06-17 22:51:57 --> Output Class Initialized
INFO - 2024-06-17 22:51:57 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:57 --> Input Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Language Class Initialized
INFO - 2024-06-17 22:51:57 --> Config Class Initialized
INFO - 2024-06-17 22:51:57 --> Loader Class Initialized
INFO - 2024-06-17 22:51:57 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:57 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:57 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:57 --> Controller Class Initialized
INFO - 2024-06-17 22:51:58 --> Config Class Initialized
INFO - 2024-06-17 22:51:58 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:51:58 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:51:58 --> Utf8 Class Initialized
INFO - 2024-06-17 22:51:58 --> URI Class Initialized
INFO - 2024-06-17 22:51:58 --> Router Class Initialized
INFO - 2024-06-17 22:51:58 --> Output Class Initialized
INFO - 2024-06-17 22:51:58 --> Security Class Initialized
DEBUG - 2024-06-17 22:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:51:58 --> Input Class Initialized
INFO - 2024-06-17 22:51:58 --> Language Class Initialized
INFO - 2024-06-17 22:51:58 --> Language Class Initialized
INFO - 2024-06-17 22:51:58 --> Config Class Initialized
INFO - 2024-06-17 22:51:58 --> Loader Class Initialized
INFO - 2024-06-17 22:51:58 --> Helper loaded: url_helper
INFO - 2024-06-17 22:51:58 --> Helper loaded: file_helper
INFO - 2024-06-17 22:51:58 --> Helper loaded: form_helper
INFO - 2024-06-17 22:51:58 --> Helper loaded: my_helper
INFO - 2024-06-17 22:51:58 --> Database Driver Class Initialized
INFO - 2024-06-17 22:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:51:58 --> Controller Class Initialized
DEBUG - 2024-06-17 22:51:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/form.php
DEBUG - 2024-06-17 22:51:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:51:58 --> Final output sent to browser
DEBUG - 2024-06-17 22:51:58 --> Total execution time: 0.0285
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:52:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:52:07 --> Utf8 Class Initialized
INFO - 2024-06-17 22:52:07 --> URI Class Initialized
INFO - 2024-06-17 22:52:07 --> Router Class Initialized
INFO - 2024-06-17 22:52:07 --> Output Class Initialized
INFO - 2024-06-17 22:52:07 --> Security Class Initialized
DEBUG - 2024-06-17 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:52:07 --> Input Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Loader Class Initialized
INFO - 2024-06-17 22:52:07 --> Helper loaded: url_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: file_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: form_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: my_helper
INFO - 2024-06-17 22:52:07 --> Database Driver Class Initialized
INFO - 2024-06-17 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:52:07 --> Controller Class Initialized
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:52:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:52:07 --> Utf8 Class Initialized
INFO - 2024-06-17 22:52:07 --> URI Class Initialized
INFO - 2024-06-17 22:52:07 --> Router Class Initialized
INFO - 2024-06-17 22:52:07 --> Output Class Initialized
INFO - 2024-06-17 22:52:07 --> Security Class Initialized
DEBUG - 2024-06-17 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:52:07 --> Input Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Loader Class Initialized
INFO - 2024-06-17 22:52:07 --> Helper loaded: url_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: file_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: form_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: my_helper
INFO - 2024-06-17 22:52:07 --> Database Driver Class Initialized
INFO - 2024-06-17 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:52:07 --> Controller Class Initialized
DEBUG - 2024-06-17 22:52:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2024-06-17 22:52:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 22:52:07 --> Final output sent to browser
DEBUG - 2024-06-17 22:52:07 --> Total execution time: 0.0321
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:52:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:52:07 --> Utf8 Class Initialized
INFO - 2024-06-17 22:52:07 --> URI Class Initialized
INFO - 2024-06-17 22:52:07 --> Router Class Initialized
INFO - 2024-06-17 22:52:07 --> Output Class Initialized
INFO - 2024-06-17 22:52:07 --> Security Class Initialized
DEBUG - 2024-06-17 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:52:07 --> Input Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
ERROR - 2024-06-17 22:52:07 --> 404 Page Not Found: /index
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:52:07 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:52:07 --> Utf8 Class Initialized
INFO - 2024-06-17 22:52:07 --> URI Class Initialized
INFO - 2024-06-17 22:52:07 --> Router Class Initialized
INFO - 2024-06-17 22:52:07 --> Output Class Initialized
INFO - 2024-06-17 22:52:07 --> Security Class Initialized
DEBUG - 2024-06-17 22:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:52:07 --> Input Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Language Class Initialized
INFO - 2024-06-17 22:52:07 --> Config Class Initialized
INFO - 2024-06-17 22:52:07 --> Loader Class Initialized
INFO - 2024-06-17 22:52:07 --> Helper loaded: url_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: file_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: form_helper
INFO - 2024-06-17 22:52:07 --> Helper loaded: my_helper
INFO - 2024-06-17 22:52:07 --> Database Driver Class Initialized
INFO - 2024-06-17 22:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:52:07 --> Controller Class Initialized
INFO - 2024-06-17 22:55:12 --> Config Class Initialized
INFO - 2024-06-17 22:55:12 --> Hooks Class Initialized
DEBUG - 2024-06-17 22:55:12 --> UTF-8 Support Enabled
INFO - 2024-06-17 22:55:12 --> Utf8 Class Initialized
INFO - 2024-06-17 22:55:12 --> URI Class Initialized
INFO - 2024-06-17 22:55:12 --> Router Class Initialized
INFO - 2024-06-17 22:55:12 --> Output Class Initialized
INFO - 2024-06-17 22:55:12 --> Security Class Initialized
DEBUG - 2024-06-17 22:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 22:55:12 --> Input Class Initialized
INFO - 2024-06-17 22:55:12 --> Language Class Initialized
INFO - 2024-06-17 22:55:12 --> Language Class Initialized
INFO - 2024-06-17 22:55:12 --> Config Class Initialized
INFO - 2024-06-17 22:55:12 --> Loader Class Initialized
INFO - 2024-06-17 22:55:12 --> Helper loaded: url_helper
INFO - 2024-06-17 22:55:12 --> Helper loaded: file_helper
INFO - 2024-06-17 22:55:12 --> Helper loaded: form_helper
INFO - 2024-06-17 22:55:12 --> Helper loaded: my_helper
INFO - 2024-06-17 22:55:12 --> Database Driver Class Initialized
INFO - 2024-06-17 22:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 22:55:12 --> Controller Class Initialized
INFO - 2024-06-17 23:28:47 --> Config Class Initialized
INFO - 2024-06-17 23:28:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:28:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:28:47 --> Utf8 Class Initialized
INFO - 2024-06-17 23:28:47 --> URI Class Initialized
DEBUG - 2024-06-17 23:28:47 --> No URI present. Default controller set.
INFO - 2024-06-17 23:28:47 --> Router Class Initialized
INFO - 2024-06-17 23:28:47 --> Output Class Initialized
INFO - 2024-06-17 23:28:47 --> Security Class Initialized
DEBUG - 2024-06-17 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:28:47 --> Input Class Initialized
INFO - 2024-06-17 23:28:47 --> Language Class Initialized
INFO - 2024-06-17 23:28:47 --> Language Class Initialized
INFO - 2024-06-17 23:28:47 --> Config Class Initialized
INFO - 2024-06-17 23:28:47 --> Loader Class Initialized
INFO - 2024-06-17 23:28:47 --> Helper loaded: url_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: file_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: form_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: my_helper
INFO - 2024-06-17 23:28:47 --> Database Driver Class Initialized
INFO - 2024-06-17 23:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:28:47 --> Controller Class Initialized
INFO - 2024-06-17 23:28:47 --> Config Class Initialized
INFO - 2024-06-17 23:28:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:28:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:28:47 --> Utf8 Class Initialized
INFO - 2024-06-17 23:28:47 --> URI Class Initialized
INFO - 2024-06-17 23:28:47 --> Router Class Initialized
INFO - 2024-06-17 23:28:47 --> Output Class Initialized
INFO - 2024-06-17 23:28:47 --> Security Class Initialized
DEBUG - 2024-06-17 23:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:28:47 --> Input Class Initialized
INFO - 2024-06-17 23:28:47 --> Language Class Initialized
INFO - 2024-06-17 23:28:47 --> Language Class Initialized
INFO - 2024-06-17 23:28:47 --> Config Class Initialized
INFO - 2024-06-17 23:28:47 --> Loader Class Initialized
INFO - 2024-06-17 23:28:47 --> Helper loaded: url_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: file_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: form_helper
INFO - 2024-06-17 23:28:47 --> Helper loaded: my_helper
INFO - 2024-06-17 23:28:47 --> Database Driver Class Initialized
INFO - 2024-06-17 23:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:28:47 --> Controller Class Initialized
DEBUG - 2024-06-17 23:28:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-06-17 23:28:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:28:47 --> Final output sent to browser
DEBUG - 2024-06-17 23:28:47 --> Total execution time: 0.0268
INFO - 2024-06-17 23:29:05 --> Config Class Initialized
INFO - 2024-06-17 23:29:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:05 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:05 --> URI Class Initialized
INFO - 2024-06-17 23:29:05 --> Router Class Initialized
INFO - 2024-06-17 23:29:05 --> Output Class Initialized
INFO - 2024-06-17 23:29:05 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:05 --> Input Class Initialized
INFO - 2024-06-17 23:29:05 --> Language Class Initialized
INFO - 2024-06-17 23:29:05 --> Language Class Initialized
INFO - 2024-06-17 23:29:05 --> Config Class Initialized
INFO - 2024-06-17 23:29:05 --> Loader Class Initialized
INFO - 2024-06-17 23:29:05 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:05 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:05 --> Controller Class Initialized
INFO - 2024-06-17 23:29:05 --> Helper loaded: cookie_helper
INFO - 2024-06-17 23:29:05 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:05 --> Total execution time: 0.0288
INFO - 2024-06-17 23:29:05 --> Config Class Initialized
INFO - 2024-06-17 23:29:05 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:05 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:05 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:05 --> URI Class Initialized
INFO - 2024-06-17 23:29:05 --> Router Class Initialized
INFO - 2024-06-17 23:29:05 --> Output Class Initialized
INFO - 2024-06-17 23:29:05 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:05 --> Input Class Initialized
INFO - 2024-06-17 23:29:05 --> Language Class Initialized
INFO - 2024-06-17 23:29:05 --> Language Class Initialized
INFO - 2024-06-17 23:29:05 --> Config Class Initialized
INFO - 2024-06-17 23:29:05 --> Loader Class Initialized
INFO - 2024-06-17 23:29:05 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:05 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:05 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:05 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 23:29:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:05 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:05 --> Total execution time: 0.0269
INFO - 2024-06-17 23:29:11 --> Config Class Initialized
INFO - 2024-06-17 23:29:11 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:11 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:11 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:11 --> URI Class Initialized
INFO - 2024-06-17 23:29:11 --> Router Class Initialized
INFO - 2024-06-17 23:29:11 --> Output Class Initialized
INFO - 2024-06-17 23:29:11 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:11 --> Input Class Initialized
INFO - 2024-06-17 23:29:11 --> Language Class Initialized
INFO - 2024-06-17 23:29:11 --> Language Class Initialized
INFO - 2024-06-17 23:29:11 --> Config Class Initialized
INFO - 2024-06-17 23:29:11 --> Loader Class Initialized
INFO - 2024-06-17 23:29:11 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:11 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:11 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:11 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:11 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:11 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 23:29:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:11 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:11 --> Total execution time: 0.0280
INFO - 2024-06-17 23:29:15 --> Config Class Initialized
INFO - 2024-06-17 23:29:15 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:15 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:15 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:15 --> URI Class Initialized
INFO - 2024-06-17 23:29:15 --> Router Class Initialized
INFO - 2024-06-17 23:29:15 --> Output Class Initialized
INFO - 2024-06-17 23:29:15 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:15 --> Input Class Initialized
INFO - 2024-06-17 23:29:15 --> Language Class Initialized
INFO - 2024-06-17 23:29:15 --> Language Class Initialized
INFO - 2024-06-17 23:29:15 --> Config Class Initialized
INFO - 2024-06-17 23:29:15 --> Loader Class Initialized
INFO - 2024-06-17 23:29:15 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:15 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:15 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:15 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:15 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:15 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 23:29:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:15 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:15 --> Total execution time: 0.0288
INFO - 2024-06-17 23:29:18 --> Config Class Initialized
INFO - 2024-06-17 23:29:18 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:18 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:18 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:18 --> URI Class Initialized
INFO - 2024-06-17 23:29:18 --> Router Class Initialized
INFO - 2024-06-17 23:29:18 --> Output Class Initialized
INFO - 2024-06-17 23:29:18 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:18 --> Input Class Initialized
INFO - 2024-06-17 23:29:18 --> Language Class Initialized
INFO - 2024-06-17 23:29:18 --> Language Class Initialized
INFO - 2024-06-17 23:29:18 --> Config Class Initialized
INFO - 2024-06-17 23:29:18 --> Loader Class Initialized
INFO - 2024-06-17 23:29:18 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:18 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:18 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:18 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:18 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:18 --> Controller Class Initialized
INFO - 2024-06-17 23:29:18 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:18 --> Total execution time: 0.0315
INFO - 2024-06-17 23:29:39 --> Config Class Initialized
INFO - 2024-06-17 23:29:39 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:39 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:39 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:39 --> URI Class Initialized
INFO - 2024-06-17 23:29:39 --> Router Class Initialized
INFO - 2024-06-17 23:29:39 --> Output Class Initialized
INFO - 2024-06-17 23:29:39 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:39 --> Input Class Initialized
INFO - 2024-06-17 23:29:39 --> Language Class Initialized
INFO - 2024-06-17 23:29:39 --> Language Class Initialized
INFO - 2024-06-17 23:29:39 --> Config Class Initialized
INFO - 2024-06-17 23:29:39 --> Loader Class Initialized
INFO - 2024-06-17 23:29:39 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:39 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:39 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:39 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:39 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:39 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 23:29:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:39 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:39 --> Total execution time: 0.0263
INFO - 2024-06-17 23:29:41 --> Config Class Initialized
INFO - 2024-06-17 23:29:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:41 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:41 --> URI Class Initialized
INFO - 2024-06-17 23:29:41 --> Router Class Initialized
INFO - 2024-06-17 23:29:41 --> Output Class Initialized
INFO - 2024-06-17 23:29:41 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:41 --> Input Class Initialized
INFO - 2024-06-17 23:29:41 --> Language Class Initialized
INFO - 2024-06-17 23:29:41 --> Language Class Initialized
INFO - 2024-06-17 23:29:41 --> Config Class Initialized
INFO - 2024-06-17 23:29:41 --> Loader Class Initialized
INFO - 2024-06-17 23:29:41 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:41 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:41 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:41 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:41 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:41 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 23:29:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:41 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:41 --> Total execution time: 0.0521
INFO - 2024-06-17 23:29:44 --> Config Class Initialized
INFO - 2024-06-17 23:29:44 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:44 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:44 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:44 --> URI Class Initialized
INFO - 2024-06-17 23:29:44 --> Router Class Initialized
INFO - 2024-06-17 23:29:44 --> Output Class Initialized
INFO - 2024-06-17 23:29:44 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:44 --> Input Class Initialized
INFO - 2024-06-17 23:29:44 --> Language Class Initialized
INFO - 2024-06-17 23:29:44 --> Language Class Initialized
INFO - 2024-06-17 23:29:44 --> Config Class Initialized
INFO - 2024-06-17 23:29:44 --> Loader Class Initialized
INFO - 2024-06-17 23:29:44 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:44 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:44 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:44 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:44 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:44 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 23:29:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:44 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:44 --> Total execution time: 0.0792
INFO - 2024-06-17 23:29:45 --> Config Class Initialized
INFO - 2024-06-17 23:29:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:45 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:45 --> URI Class Initialized
INFO - 2024-06-17 23:29:45 --> Router Class Initialized
INFO - 2024-06-17 23:29:45 --> Output Class Initialized
INFO - 2024-06-17 23:29:45 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:45 --> Input Class Initialized
INFO - 2024-06-17 23:29:45 --> Language Class Initialized
INFO - 2024-06-17 23:29:45 --> Language Class Initialized
INFO - 2024-06-17 23:29:45 --> Config Class Initialized
INFO - 2024-06-17 23:29:45 --> Loader Class Initialized
INFO - 2024-06-17 23:29:45 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:45 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:45 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:45 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:45 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:45 --> Controller Class Initialized
DEBUG - 2024-06-17 23:29:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-06-17 23:29:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:29:45 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:45 --> Total execution time: 0.0310
INFO - 2024-06-17 23:29:46 --> Config Class Initialized
INFO - 2024-06-17 23:29:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:46 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:46 --> URI Class Initialized
INFO - 2024-06-17 23:29:46 --> Router Class Initialized
INFO - 2024-06-17 23:29:46 --> Output Class Initialized
INFO - 2024-06-17 23:29:46 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:46 --> Input Class Initialized
INFO - 2024-06-17 23:29:46 --> Language Class Initialized
INFO - 2024-06-17 23:29:46 --> Language Class Initialized
INFO - 2024-06-17 23:29:46 --> Config Class Initialized
INFO - 2024-06-17 23:29:46 --> Loader Class Initialized
INFO - 2024-06-17 23:29:46 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:46 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:46 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:46 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:46 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:47 --> Controller Class Initialized
INFO - 2024-06-17 23:29:51 --> Config Class Initialized
INFO - 2024-06-17 23:29:51 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:29:51 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:29:51 --> Utf8 Class Initialized
INFO - 2024-06-17 23:29:51 --> URI Class Initialized
INFO - 2024-06-17 23:29:51 --> Router Class Initialized
INFO - 2024-06-17 23:29:51 --> Output Class Initialized
INFO - 2024-06-17 23:29:51 --> Security Class Initialized
DEBUG - 2024-06-17 23:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:29:51 --> Input Class Initialized
INFO - 2024-06-17 23:29:51 --> Language Class Initialized
INFO - 2024-06-17 23:29:51 --> Language Class Initialized
INFO - 2024-06-17 23:29:51 --> Config Class Initialized
INFO - 2024-06-17 23:29:51 --> Loader Class Initialized
INFO - 2024-06-17 23:29:51 --> Helper loaded: url_helper
INFO - 2024-06-17 23:29:51 --> Helper loaded: file_helper
INFO - 2024-06-17 23:29:51 --> Helper loaded: form_helper
INFO - 2024-06-17 23:29:51 --> Helper loaded: my_helper
INFO - 2024-06-17 23:29:51 --> Database Driver Class Initialized
INFO - 2024-06-17 23:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:29:51 --> Controller Class Initialized
INFO - 2024-06-17 23:29:51 --> Final output sent to browser
DEBUG - 2024-06-17 23:29:51 --> Total execution time: 0.0310
INFO - 2024-06-17 23:35:34 --> Config Class Initialized
INFO - 2024-06-17 23:35:34 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:34 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:34 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:34 --> URI Class Initialized
INFO - 2024-06-17 23:35:34 --> Router Class Initialized
INFO - 2024-06-17 23:35:34 --> Output Class Initialized
INFO - 2024-06-17 23:35:34 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:34 --> Input Class Initialized
INFO - 2024-06-17 23:35:34 --> Language Class Initialized
INFO - 2024-06-17 23:35:34 --> Language Class Initialized
INFO - 2024-06-17 23:35:34 --> Config Class Initialized
INFO - 2024-06-17 23:35:34 --> Loader Class Initialized
INFO - 2024-06-17 23:35:34 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:34 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:34 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:34 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:34 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:34 --> Controller Class Initialized
INFO - 2024-06-17 23:35:34 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:34 --> Total execution time: 0.0625
INFO - 2024-06-17 23:35:38 --> Config Class Initialized
INFO - 2024-06-17 23:35:38 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:38 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:38 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:38 --> URI Class Initialized
INFO - 2024-06-17 23:35:38 --> Router Class Initialized
INFO - 2024-06-17 23:35:38 --> Output Class Initialized
INFO - 2024-06-17 23:35:38 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:38 --> Input Class Initialized
INFO - 2024-06-17 23:35:38 --> Language Class Initialized
INFO - 2024-06-17 23:35:38 --> Language Class Initialized
INFO - 2024-06-17 23:35:38 --> Config Class Initialized
INFO - 2024-06-17 23:35:38 --> Loader Class Initialized
INFO - 2024-06-17 23:35:38 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:38 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:38 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:38 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:38 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:38 --> Controller Class Initialized
DEBUG - 2024-06-17 23:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-06-17 23:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:35:38 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:38 --> Total execution time: 0.0926
INFO - 2024-06-17 23:35:41 --> Config Class Initialized
INFO - 2024-06-17 23:35:41 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:41 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:41 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:41 --> URI Class Initialized
INFO - 2024-06-17 23:35:41 --> Router Class Initialized
INFO - 2024-06-17 23:35:41 --> Output Class Initialized
INFO - 2024-06-17 23:35:41 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:41 --> Input Class Initialized
INFO - 2024-06-17 23:35:41 --> Language Class Initialized
INFO - 2024-06-17 23:35:41 --> Language Class Initialized
INFO - 2024-06-17 23:35:41 --> Config Class Initialized
INFO - 2024-06-17 23:35:41 --> Loader Class Initialized
INFO - 2024-06-17 23:35:41 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:41 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:41 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:41 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:41 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:41 --> Controller Class Initialized
DEBUG - 2024-06-17 23:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-06-17 23:35:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:35:41 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:41 --> Total execution time: 0.0338
INFO - 2024-06-17 23:35:43 --> Config Class Initialized
INFO - 2024-06-17 23:35:43 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:43 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:43 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:43 --> URI Class Initialized
INFO - 2024-06-17 23:35:43 --> Router Class Initialized
INFO - 2024-06-17 23:35:43 --> Output Class Initialized
INFO - 2024-06-17 23:35:43 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:43 --> Input Class Initialized
INFO - 2024-06-17 23:35:43 --> Language Class Initialized
INFO - 2024-06-17 23:35:43 --> Language Class Initialized
INFO - 2024-06-17 23:35:43 --> Config Class Initialized
INFO - 2024-06-17 23:35:43 --> Loader Class Initialized
INFO - 2024-06-17 23:35:43 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:43 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:43 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:43 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:43 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:43 --> Controller Class Initialized
INFO - 2024-06-17 23:35:43 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:43 --> Total execution time: 0.0288
INFO - 2024-06-17 23:35:45 --> Config Class Initialized
INFO - 2024-06-17 23:35:45 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:45 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:45 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:45 --> URI Class Initialized
INFO - 2024-06-17 23:35:45 --> Router Class Initialized
INFO - 2024-06-17 23:35:45 --> Output Class Initialized
INFO - 2024-06-17 23:35:45 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:45 --> Input Class Initialized
INFO - 2024-06-17 23:35:45 --> Language Class Initialized
INFO - 2024-06-17 23:35:45 --> Language Class Initialized
INFO - 2024-06-17 23:35:45 --> Config Class Initialized
INFO - 2024-06-17 23:35:45 --> Loader Class Initialized
INFO - 2024-06-17 23:35:45 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:45 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:45 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:45 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:45 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:45 --> Controller Class Initialized
INFO - 2024-06-17 23:35:45 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:45 --> Total execution time: 0.0274
INFO - 2024-06-17 23:35:46 --> Config Class Initialized
INFO - 2024-06-17 23:35:46 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:46 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:46 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:46 --> URI Class Initialized
INFO - 2024-06-17 23:35:46 --> Router Class Initialized
INFO - 2024-06-17 23:35:46 --> Output Class Initialized
INFO - 2024-06-17 23:35:46 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:46 --> Input Class Initialized
INFO - 2024-06-17 23:35:46 --> Language Class Initialized
INFO - 2024-06-17 23:35:46 --> Language Class Initialized
INFO - 2024-06-17 23:35:46 --> Config Class Initialized
INFO - 2024-06-17 23:35:46 --> Loader Class Initialized
INFO - 2024-06-17 23:35:46 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:46 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:46 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:46 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:46 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:46 --> Controller Class Initialized
INFO - 2024-06-17 23:35:46 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:46 --> Total execution time: 0.0417
INFO - 2024-06-17 23:35:47 --> Config Class Initialized
INFO - 2024-06-17 23:35:47 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:47 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:47 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:47 --> URI Class Initialized
INFO - 2024-06-17 23:35:47 --> Router Class Initialized
INFO - 2024-06-17 23:35:47 --> Output Class Initialized
INFO - 2024-06-17 23:35:47 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:47 --> Input Class Initialized
INFO - 2024-06-17 23:35:47 --> Language Class Initialized
INFO - 2024-06-17 23:35:47 --> Language Class Initialized
INFO - 2024-06-17 23:35:47 --> Config Class Initialized
INFO - 2024-06-17 23:35:47 --> Loader Class Initialized
INFO - 2024-06-17 23:35:47 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:47 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:47 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:47 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:47 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:47 --> Controller Class Initialized
INFO - 2024-06-17 23:35:47 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:47 --> Total execution time: 0.0294
INFO - 2024-06-17 23:35:48 --> Config Class Initialized
INFO - 2024-06-17 23:35:48 --> Hooks Class Initialized
DEBUG - 2024-06-17 23:35:48 --> UTF-8 Support Enabled
INFO - 2024-06-17 23:35:48 --> Utf8 Class Initialized
INFO - 2024-06-17 23:35:48 --> URI Class Initialized
DEBUG - 2024-06-17 23:35:48 --> No URI present. Default controller set.
INFO - 2024-06-17 23:35:48 --> Router Class Initialized
INFO - 2024-06-17 23:35:49 --> Output Class Initialized
INFO - 2024-06-17 23:35:49 --> Security Class Initialized
DEBUG - 2024-06-17 23:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-06-17 23:35:49 --> Input Class Initialized
INFO - 2024-06-17 23:35:49 --> Language Class Initialized
INFO - 2024-06-17 23:35:49 --> Language Class Initialized
INFO - 2024-06-17 23:35:49 --> Config Class Initialized
INFO - 2024-06-17 23:35:49 --> Loader Class Initialized
INFO - 2024-06-17 23:35:49 --> Helper loaded: url_helper
INFO - 2024-06-17 23:35:49 --> Helper loaded: file_helper
INFO - 2024-06-17 23:35:49 --> Helper loaded: form_helper
INFO - 2024-06-17 23:35:49 --> Helper loaded: my_helper
INFO - 2024-06-17 23:35:49 --> Database Driver Class Initialized
INFO - 2024-06-17 23:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-06-17 23:35:49 --> Controller Class Initialized
DEBUG - 2024-06-17 23:35:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-06-17 23:35:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-06-17 23:35:49 --> Final output sent to browser
DEBUG - 2024-06-17 23:35:49 --> Total execution time: 0.0541
