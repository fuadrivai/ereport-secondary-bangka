<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-01 10:25:46 --> Config Class Initialized
INFO - 2023-10-01 10:25:46 --> Hooks Class Initialized
DEBUG - 2023-10-01 10:25:46 --> UTF-8 Support Enabled
INFO - 2023-10-01 10:25:46 --> Utf8 Class Initialized
INFO - 2023-10-01 10:25:46 --> URI Class Initialized
INFO - 2023-10-01 10:25:46 --> Router Class Initialized
INFO - 2023-10-01 10:25:46 --> Output Class Initialized
INFO - 2023-10-01 10:25:46 --> Security Class Initialized
DEBUG - 2023-10-01 10:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-01 10:25:46 --> Input Class Initialized
INFO - 2023-10-01 10:25:46 --> Language Class Initialized
INFO - 2023-10-01 10:25:46 --> Language Class Initialized
INFO - 2023-10-01 10:25:46 --> Config Class Initialized
INFO - 2023-10-01 10:25:46 --> Loader Class Initialized
INFO - 2023-10-01 10:25:46 --> Helper loaded: url_helper
INFO - 2023-10-01 10:25:46 --> Helper loaded: file_helper
INFO - 2023-10-01 10:25:46 --> Helper loaded: form_helper
INFO - 2023-10-01 10:25:46 --> Helper loaded: my_helper
INFO - 2023-10-01 10:25:46 --> Database Driver Class Initialized
INFO - 2023-10-01 10:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-01 10:25:46 --> Controller Class Initialized
DEBUG - 2023-10-01 10:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-01 10:25:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-01 10:25:46 --> Final output sent to browser
DEBUG - 2023-10-01 10:25:46 --> Total execution time: 0.0588
INFO - 2023-10-01 17:38:43 --> Config Class Initialized
INFO - 2023-10-01 17:38:43 --> Hooks Class Initialized
DEBUG - 2023-10-01 17:38:43 --> UTF-8 Support Enabled
INFO - 2023-10-01 17:38:43 --> Utf8 Class Initialized
INFO - 2023-10-01 17:38:43 --> URI Class Initialized
INFO - 2023-10-01 17:38:43 --> Router Class Initialized
INFO - 2023-10-01 17:38:43 --> Output Class Initialized
INFO - 2023-10-01 17:38:43 --> Security Class Initialized
DEBUG - 2023-10-01 17:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-01 17:38:43 --> Input Class Initialized
INFO - 2023-10-01 17:38:43 --> Language Class Initialized
INFO - 2023-10-01 17:38:43 --> Language Class Initialized
INFO - 2023-10-01 17:38:43 --> Config Class Initialized
INFO - 2023-10-01 17:38:43 --> Loader Class Initialized
INFO - 2023-10-01 17:38:43 --> Helper loaded: url_helper
INFO - 2023-10-01 17:38:43 --> Helper loaded: file_helper
INFO - 2023-10-01 17:38:43 --> Helper loaded: form_helper
INFO - 2023-10-01 17:38:43 --> Helper loaded: my_helper
INFO - 2023-10-01 17:38:43 --> Database Driver Class Initialized
INFO - 2023-10-01 17:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-01 17:38:43 --> Controller Class Initialized
DEBUG - 2023-10-01 17:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-10-01 17:38:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-01 17:38:43 --> Final output sent to browser
DEBUG - 2023-10-01 17:38:43 --> Total execution time: 0.0529
INFO - 2023-10-01 17:38:56 --> Config Class Initialized
INFO - 2023-10-01 17:38:56 --> Hooks Class Initialized
DEBUG - 2023-10-01 17:38:56 --> UTF-8 Support Enabled
INFO - 2023-10-01 17:38:56 --> Utf8 Class Initialized
INFO - 2023-10-01 17:38:56 --> URI Class Initialized
INFO - 2023-10-01 17:38:56 --> Router Class Initialized
INFO - 2023-10-01 17:38:56 --> Output Class Initialized
INFO - 2023-10-01 17:38:56 --> Security Class Initialized
DEBUG - 2023-10-01 17:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-01 17:38:56 --> Input Class Initialized
INFO - 2023-10-01 17:38:56 --> Language Class Initialized
INFO - 2023-10-01 17:38:56 --> Language Class Initialized
INFO - 2023-10-01 17:38:56 --> Config Class Initialized
INFO - 2023-10-01 17:38:56 --> Loader Class Initialized
INFO - 2023-10-01 17:38:56 --> Helper loaded: url_helper
INFO - 2023-10-01 17:38:56 --> Helper loaded: file_helper
INFO - 2023-10-01 17:38:56 --> Helper loaded: form_helper
INFO - 2023-10-01 17:38:56 --> Helper loaded: my_helper
INFO - 2023-10-01 17:38:56 --> Database Driver Class Initialized
INFO - 2023-10-01 17:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-01 17:38:56 --> Controller Class Initialized
INFO - 2023-10-01 17:38:56 --> Final output sent to browser
DEBUG - 2023-10-01 17:38:56 --> Total execution time: 0.0469
INFO - 2023-10-01 17:38:59 --> Config Class Initialized
INFO - 2023-10-01 17:38:59 --> Hooks Class Initialized
DEBUG - 2023-10-01 17:38:59 --> UTF-8 Support Enabled
INFO - 2023-10-01 17:38:59 --> Utf8 Class Initialized
INFO - 2023-10-01 17:38:59 --> URI Class Initialized
DEBUG - 2023-10-01 17:38:59 --> No URI present. Default controller set.
INFO - 2023-10-01 17:38:59 --> Router Class Initialized
INFO - 2023-10-01 17:38:59 --> Output Class Initialized
INFO - 2023-10-01 17:38:59 --> Security Class Initialized
DEBUG - 2023-10-01 17:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-01 17:38:59 --> Input Class Initialized
INFO - 2023-10-01 17:38:59 --> Language Class Initialized
INFO - 2023-10-01 17:38:59 --> Language Class Initialized
INFO - 2023-10-01 17:38:59 --> Config Class Initialized
INFO - 2023-10-01 17:38:59 --> Loader Class Initialized
INFO - 2023-10-01 17:38:59 --> Helper loaded: url_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: file_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: form_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: my_helper
INFO - 2023-10-01 17:38:59 --> Database Driver Class Initialized
INFO - 2023-10-01 17:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-01 17:38:59 --> Controller Class Initialized
INFO - 2023-10-01 17:38:59 --> Config Class Initialized
INFO - 2023-10-01 17:38:59 --> Hooks Class Initialized
DEBUG - 2023-10-01 17:38:59 --> UTF-8 Support Enabled
INFO - 2023-10-01 17:38:59 --> Utf8 Class Initialized
INFO - 2023-10-01 17:38:59 --> URI Class Initialized
INFO - 2023-10-01 17:38:59 --> Router Class Initialized
INFO - 2023-10-01 17:38:59 --> Output Class Initialized
INFO - 2023-10-01 17:38:59 --> Security Class Initialized
DEBUG - 2023-10-01 17:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-01 17:38:59 --> Input Class Initialized
INFO - 2023-10-01 17:38:59 --> Language Class Initialized
INFO - 2023-10-01 17:38:59 --> Language Class Initialized
INFO - 2023-10-01 17:38:59 --> Config Class Initialized
INFO - 2023-10-01 17:38:59 --> Loader Class Initialized
INFO - 2023-10-01 17:38:59 --> Helper loaded: url_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: file_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: form_helper
INFO - 2023-10-01 17:38:59 --> Helper loaded: my_helper
INFO - 2023-10-01 17:38:59 --> Database Driver Class Initialized
INFO - 2023-10-01 17:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-01 17:38:59 --> Controller Class Initialized
DEBUG - 2023-10-01 17:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-01 17:38:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-01 17:38:59 --> Final output sent to browser
DEBUG - 2023-10-01 17:38:59 --> Total execution time: 0.0348
