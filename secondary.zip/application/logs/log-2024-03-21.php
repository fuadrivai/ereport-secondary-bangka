<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-21 14:16:46 --> Config Class Initialized
INFO - 2024-03-21 14:16:46 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:16:46 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:16:46 --> Utf8 Class Initialized
INFO - 2024-03-21 14:16:46 --> URI Class Initialized
INFO - 2024-03-21 14:16:46 --> Config Class Initialized
INFO - 2024-03-21 14:16:46 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:16:46 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:16:46 --> Utf8 Class Initialized
INFO - 2024-03-21 14:16:46 --> URI Class Initialized
INFO - 2024-03-21 14:16:46 --> Router Class Initialized
INFO - 2024-03-21 14:16:46 --> Router Class Initialized
INFO - 2024-03-21 14:16:46 --> Output Class Initialized
INFO - 2024-03-21 14:16:46 --> Output Class Initialized
INFO - 2024-03-21 14:16:46 --> Security Class Initialized
INFO - 2024-03-21 14:16:46 --> Security Class Initialized
DEBUG - 2024-03-21 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:16:46 --> Input Class Initialized
DEBUG - 2024-03-21 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:16:46 --> Input Class Initialized
INFO - 2024-03-21 14:16:46 --> Language Class Initialized
INFO - 2024-03-21 14:16:46 --> Language Class Initialized
INFO - 2024-03-21 14:16:46 --> Language Class Initialized
INFO - 2024-03-21 14:16:46 --> Config Class Initialized
INFO - 2024-03-21 14:16:46 --> Loader Class Initialized
INFO - 2024-03-21 14:16:46 --> Language Class Initialized
INFO - 2024-03-21 14:16:46 --> Config Class Initialized
INFO - 2024-03-21 14:16:46 --> Loader Class Initialized
INFO - 2024-03-21 14:16:46 --> Helper loaded: url_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: url_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: file_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: file_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: form_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: form_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: my_helper
INFO - 2024-03-21 14:16:46 --> Helper loaded: my_helper
INFO - 2024-03-21 14:16:46 --> Database Driver Class Initialized
INFO - 2024-03-21 14:16:46 --> Database Driver Class Initialized
INFO - 2024-03-21 14:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:16:47 --> Controller Class Initialized
INFO - 2024-03-21 14:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:16:47 --> Controller Class Initialized
DEBUG - 2024-03-21 14:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-21 14:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-21 14:16:47 --> Final output sent to browser
DEBUG - 2024-03-21 14:16:47 --> Total execution time: 0.0758
DEBUG - 2024-03-21 14:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-21 14:16:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-21 14:16:47 --> Final output sent to browser
DEBUG - 2024-03-21 14:16:47 --> Total execution time: 0.0894
INFO - 2024-03-21 14:26:42 --> Config Class Initialized
INFO - 2024-03-21 14:26:42 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:26:42 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:26:42 --> Utf8 Class Initialized
INFO - 2024-03-21 14:26:42 --> URI Class Initialized
INFO - 2024-03-21 14:26:42 --> Router Class Initialized
INFO - 2024-03-21 14:26:42 --> Output Class Initialized
INFO - 2024-03-21 14:26:42 --> Security Class Initialized
DEBUG - 2024-03-21 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:26:42 --> Input Class Initialized
INFO - 2024-03-21 14:26:42 --> Language Class Initialized
INFO - 2024-03-21 14:26:42 --> Language Class Initialized
INFO - 2024-03-21 14:26:42 --> Config Class Initialized
INFO - 2024-03-21 14:26:42 --> Loader Class Initialized
INFO - 2024-03-21 14:26:42 --> Helper loaded: url_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: file_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: form_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: my_helper
INFO - 2024-03-21 14:26:42 --> Database Driver Class Initialized
INFO - 2024-03-21 14:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:26:42 --> Controller Class Initialized
INFO - 2024-03-21 14:26:42 --> Helper loaded: cookie_helper
INFO - 2024-03-21 14:26:42 --> Final output sent to browser
DEBUG - 2024-03-21 14:26:42 --> Total execution time: 0.0467
INFO - 2024-03-21 14:26:42 --> Config Class Initialized
INFO - 2024-03-21 14:26:42 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:26:42 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:26:42 --> Utf8 Class Initialized
INFO - 2024-03-21 14:26:42 --> URI Class Initialized
INFO - 2024-03-21 14:26:42 --> Router Class Initialized
INFO - 2024-03-21 14:26:42 --> Output Class Initialized
INFO - 2024-03-21 14:26:42 --> Security Class Initialized
DEBUG - 2024-03-21 14:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:26:42 --> Input Class Initialized
INFO - 2024-03-21 14:26:42 --> Language Class Initialized
INFO - 2024-03-21 14:26:42 --> Language Class Initialized
INFO - 2024-03-21 14:26:42 --> Config Class Initialized
INFO - 2024-03-21 14:26:42 --> Loader Class Initialized
INFO - 2024-03-21 14:26:42 --> Helper loaded: url_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: file_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: form_helper
INFO - 2024-03-21 14:26:42 --> Helper loaded: my_helper
INFO - 2024-03-21 14:26:42 --> Database Driver Class Initialized
INFO - 2024-03-21 14:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:26:42 --> Controller Class Initialized
DEBUG - 2024-03-21 14:26:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-21 14:26:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-21 14:26:42 --> Final output sent to browser
DEBUG - 2024-03-21 14:26:42 --> Total execution time: 0.0444
INFO - 2024-03-21 14:27:05 --> Config Class Initialized
INFO - 2024-03-21 14:27:05 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:27:05 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:27:05 --> Utf8 Class Initialized
INFO - 2024-03-21 14:27:05 --> URI Class Initialized
INFO - 2024-03-21 14:27:05 --> Router Class Initialized
INFO - 2024-03-21 14:27:05 --> Output Class Initialized
INFO - 2024-03-21 14:27:05 --> Security Class Initialized
DEBUG - 2024-03-21 14:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:27:05 --> Input Class Initialized
INFO - 2024-03-21 14:27:05 --> Language Class Initialized
INFO - 2024-03-21 14:27:05 --> Language Class Initialized
INFO - 2024-03-21 14:27:05 --> Config Class Initialized
INFO - 2024-03-21 14:27:05 --> Loader Class Initialized
INFO - 2024-03-21 14:27:05 --> Helper loaded: url_helper
INFO - 2024-03-21 14:27:05 --> Helper loaded: file_helper
INFO - 2024-03-21 14:27:05 --> Helper loaded: form_helper
INFO - 2024-03-21 14:27:05 --> Helper loaded: my_helper
INFO - 2024-03-21 14:27:05 --> Database Driver Class Initialized
INFO - 2024-03-21 14:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:27:05 --> Controller Class Initialized
DEBUG - 2024-03-21 14:27:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2024-03-21 14:27:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-21 14:27:05 --> Final output sent to browser
DEBUG - 2024-03-21 14:27:05 --> Total execution time: 0.0444
INFO - 2024-03-21 14:27:11 --> Config Class Initialized
INFO - 2024-03-21 14:27:11 --> Hooks Class Initialized
DEBUG - 2024-03-21 14:27:11 --> UTF-8 Support Enabled
INFO - 2024-03-21 14:27:11 --> Utf8 Class Initialized
INFO - 2024-03-21 14:27:11 --> URI Class Initialized
INFO - 2024-03-21 14:27:11 --> Router Class Initialized
INFO - 2024-03-21 14:27:11 --> Output Class Initialized
INFO - 2024-03-21 14:27:11 --> Security Class Initialized
DEBUG - 2024-03-21 14:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-21 14:27:11 --> Input Class Initialized
INFO - 2024-03-21 14:27:11 --> Language Class Initialized
INFO - 2024-03-21 14:27:11 --> Language Class Initialized
INFO - 2024-03-21 14:27:11 --> Config Class Initialized
INFO - 2024-03-21 14:27:11 --> Loader Class Initialized
INFO - 2024-03-21 14:27:11 --> Helper loaded: url_helper
INFO - 2024-03-21 14:27:11 --> Helper loaded: file_helper
INFO - 2024-03-21 14:27:11 --> Helper loaded: form_helper
INFO - 2024-03-21 14:27:11 --> Helper loaded: my_helper
INFO - 2024-03-21 14:27:11 --> Database Driver Class Initialized
INFO - 2024-03-21 14:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-21 14:27:11 --> Controller Class Initialized
DEBUG - 2024-03-21 14:27:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/cetak.php
INFO - 2024-03-21 14:27:11 --> Final output sent to browser
DEBUG - 2024-03-21 14:27:11 --> Total execution time: 0.1484
