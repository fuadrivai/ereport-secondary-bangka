<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-21 09:28:01 --> Config Class Initialized
INFO - 2023-12-21 09:28:01 --> Hooks Class Initialized
DEBUG - 2023-12-21 09:28:01 --> UTF-8 Support Enabled
INFO - 2023-12-21 09:28:01 --> Utf8 Class Initialized
INFO - 2023-12-21 09:28:01 --> URI Class Initialized
INFO - 2023-12-21 09:28:01 --> Router Class Initialized
INFO - 2023-12-21 09:28:01 --> Output Class Initialized
INFO - 2023-12-21 09:28:01 --> Security Class Initialized
DEBUG - 2023-12-21 09:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 09:28:01 --> Input Class Initialized
INFO - 2023-12-21 09:28:01 --> Language Class Initialized
INFO - 2023-12-21 09:28:02 --> Language Class Initialized
INFO - 2023-12-21 09:28:02 --> Config Class Initialized
INFO - 2023-12-21 09:28:02 --> Loader Class Initialized
INFO - 2023-12-21 09:28:02 --> Helper loaded: url_helper
INFO - 2023-12-21 09:28:02 --> Helper loaded: file_helper
INFO - 2023-12-21 09:28:02 --> Helper loaded: form_helper
INFO - 2023-12-21 09:28:02 --> Helper loaded: my_helper
INFO - 2023-12-21 09:28:02 --> Database Driver Class Initialized
INFO - 2023-12-21 09:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 09:28:02 --> Controller Class Initialized
DEBUG - 2023-12-21 09:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-21 09:28:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-21 09:28:03 --> Final output sent to browser
DEBUG - 2023-12-21 09:28:03 --> Total execution time: 1.1750
INFO - 2023-12-21 12:53:20 --> Config Class Initialized
INFO - 2023-12-21 12:53:20 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:20 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:20 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:20 --> URI Class Initialized
INFO - 2023-12-21 12:53:20 --> Router Class Initialized
INFO - 2023-12-21 12:53:20 --> Output Class Initialized
INFO - 2023-12-21 12:53:20 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:20 --> Input Class Initialized
INFO - 2023-12-21 12:53:20 --> Language Class Initialized
INFO - 2023-12-21 12:53:20 --> Language Class Initialized
INFO - 2023-12-21 12:53:20 --> Config Class Initialized
INFO - 2023-12-21 12:53:20 --> Loader Class Initialized
INFO - 2023-12-21 12:53:20 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:20 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:20 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:20 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:20 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:20 --> Controller Class Initialized
INFO - 2023-12-21 12:53:20 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:53:20 --> Final output sent to browser
DEBUG - 2023-12-21 12:53:20 --> Total execution time: 0.2450
INFO - 2023-12-21 12:53:21 --> Config Class Initialized
INFO - 2023-12-21 12:53:21 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:21 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:21 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:21 --> URI Class Initialized
INFO - 2023-12-21 12:53:21 --> Router Class Initialized
INFO - 2023-12-21 12:53:21 --> Output Class Initialized
INFO - 2023-12-21 12:53:21 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:21 --> Input Class Initialized
INFO - 2023-12-21 12:53:21 --> Language Class Initialized
INFO - 2023-12-21 12:53:21 --> Language Class Initialized
INFO - 2023-12-21 12:53:21 --> Config Class Initialized
INFO - 2023-12-21 12:53:21 --> Loader Class Initialized
INFO - 2023-12-21 12:53:21 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:21 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:21 --> Controller Class Initialized
INFO - 2023-12-21 12:53:21 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:53:21 --> Config Class Initialized
INFO - 2023-12-21 12:53:21 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:21 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:21 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:21 --> URI Class Initialized
INFO - 2023-12-21 12:53:21 --> Router Class Initialized
INFO - 2023-12-21 12:53:21 --> Output Class Initialized
INFO - 2023-12-21 12:53:21 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:21 --> Input Class Initialized
INFO - 2023-12-21 12:53:21 --> Language Class Initialized
INFO - 2023-12-21 12:53:21 --> Language Class Initialized
INFO - 2023-12-21 12:53:21 --> Config Class Initialized
INFO - 2023-12-21 12:53:21 --> Loader Class Initialized
INFO - 2023-12-21 12:53:21 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:21 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:21 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:21 --> Controller Class Initialized
DEBUG - 2023-12-21 12:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-21 12:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-21 12:53:21 --> Final output sent to browser
DEBUG - 2023-12-21 12:53:21 --> Total execution time: 0.1080
INFO - 2023-12-21 12:53:27 --> Config Class Initialized
INFO - 2023-12-21 12:53:27 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:27 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:27 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:27 --> URI Class Initialized
INFO - 2023-12-21 12:53:27 --> Router Class Initialized
INFO - 2023-12-21 12:53:27 --> Output Class Initialized
INFO - 2023-12-21 12:53:27 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:27 --> Input Class Initialized
INFO - 2023-12-21 12:53:27 --> Language Class Initialized
INFO - 2023-12-21 12:53:27 --> Language Class Initialized
INFO - 2023-12-21 12:53:27 --> Config Class Initialized
INFO - 2023-12-21 12:53:27 --> Loader Class Initialized
INFO - 2023-12-21 12:53:27 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:27 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:27 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:27 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:27 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:27 --> Controller Class Initialized
DEBUG - 2023-12-21 12:53:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:53:35 --> Final output sent to browser
DEBUG - 2023-12-21 12:53:35 --> Total execution time: 8.3814
INFO - 2023-12-21 12:53:36 --> Config Class Initialized
INFO - 2023-12-21 12:53:36 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:36 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:36 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:36 --> URI Class Initialized
INFO - 2023-12-21 12:53:36 --> Router Class Initialized
INFO - 2023-12-21 12:53:36 --> Output Class Initialized
INFO - 2023-12-21 12:53:36 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:36 --> Input Class Initialized
INFO - 2023-12-21 12:53:36 --> Language Class Initialized
INFO - 2023-12-21 12:53:36 --> Language Class Initialized
INFO - 2023-12-21 12:53:36 --> Config Class Initialized
INFO - 2023-12-21 12:53:36 --> Loader Class Initialized
INFO - 2023-12-21 12:53:36 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:36 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:36 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:36 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:36 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:36 --> Controller Class Initialized
DEBUG - 2023-12-21 12:53:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:53:38 --> Config Class Initialized
INFO - 2023-12-21 12:53:38 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:38 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:38 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:38 --> URI Class Initialized
INFO - 2023-12-21 12:53:38 --> Router Class Initialized
INFO - 2023-12-21 12:53:38 --> Output Class Initialized
INFO - 2023-12-21 12:53:39 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:39 --> Input Class Initialized
INFO - 2023-12-21 12:53:39 --> Language Class Initialized
INFO - 2023-12-21 12:53:40 --> Language Class Initialized
INFO - 2023-12-21 12:53:40 --> Config Class Initialized
INFO - 2023-12-21 12:53:40 --> Loader Class Initialized
INFO - 2023-12-21 12:53:40 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:40 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:40 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:40 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:40 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:41 --> Controller Class Initialized
DEBUG - 2023-12-21 12:53:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:53:51 --> Final output sent to browser
DEBUG - 2023-12-21 12:53:51 --> Total execution time: 14.6344
INFO - 2023-12-21 12:53:52 --> Final output sent to browser
DEBUG - 2023-12-21 12:53:52 --> Total execution time: 13.8811
INFO - 2023-12-21 12:53:53 --> Config Class Initialized
INFO - 2023-12-21 12:53:53 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:53:53 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:53:53 --> Utf8 Class Initialized
INFO - 2023-12-21 12:53:53 --> URI Class Initialized
INFO - 2023-12-21 12:53:53 --> Router Class Initialized
INFO - 2023-12-21 12:53:53 --> Output Class Initialized
INFO - 2023-12-21 12:53:53 --> Security Class Initialized
DEBUG - 2023-12-21 12:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:53:53 --> Input Class Initialized
INFO - 2023-12-21 12:53:53 --> Language Class Initialized
INFO - 2023-12-21 12:53:53 --> Language Class Initialized
INFO - 2023-12-21 12:53:53 --> Config Class Initialized
INFO - 2023-12-21 12:53:53 --> Loader Class Initialized
INFO - 2023-12-21 12:53:53 --> Helper loaded: url_helper
INFO - 2023-12-21 12:53:53 --> Helper loaded: file_helper
INFO - 2023-12-21 12:53:53 --> Helper loaded: form_helper
INFO - 2023-12-21 12:53:53 --> Helper loaded: my_helper
INFO - 2023-12-21 12:53:53 --> Database Driver Class Initialized
INFO - 2023-12-21 12:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:53:53 --> Controller Class Initialized
DEBUG - 2023-12-21 12:53:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:54:00 --> Final output sent to browser
DEBUG - 2023-12-21 12:54:00 --> Total execution time: 7.4175
INFO - 2023-12-21 12:55:53 --> Config Class Initialized
INFO - 2023-12-21 12:55:53 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:55:53 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:55:53 --> Utf8 Class Initialized
INFO - 2023-12-21 12:55:53 --> URI Class Initialized
INFO - 2023-12-21 12:55:53 --> Router Class Initialized
INFO - 2023-12-21 12:55:53 --> Output Class Initialized
INFO - 2023-12-21 12:55:53 --> Security Class Initialized
DEBUG - 2023-12-21 12:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:55:53 --> Input Class Initialized
INFO - 2023-12-21 12:55:53 --> Language Class Initialized
INFO - 2023-12-21 12:55:53 --> Language Class Initialized
INFO - 2023-12-21 12:55:53 --> Config Class Initialized
INFO - 2023-12-21 12:55:53 --> Loader Class Initialized
INFO - 2023-12-21 12:55:53 --> Helper loaded: url_helper
INFO - 2023-12-21 12:55:53 --> Helper loaded: file_helper
INFO - 2023-12-21 12:55:53 --> Helper loaded: form_helper
INFO - 2023-12-21 12:55:53 --> Helper loaded: my_helper
INFO - 2023-12-21 12:55:53 --> Database Driver Class Initialized
INFO - 2023-12-21 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:55:53 --> Controller Class Initialized
DEBUG - 2023-12-21 12:55:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:56:05 --> Final output sent to browser
DEBUG - 2023-12-21 12:56:05 --> Total execution time: 11.7923
INFO - 2023-12-21 12:56:06 --> Config Class Initialized
INFO - 2023-12-21 12:56:06 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:56:06 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:56:06 --> Utf8 Class Initialized
INFO - 2023-12-21 12:56:06 --> URI Class Initialized
INFO - 2023-12-21 12:56:06 --> Router Class Initialized
INFO - 2023-12-21 12:56:06 --> Output Class Initialized
INFO - 2023-12-21 12:56:06 --> Security Class Initialized
DEBUG - 2023-12-21 12:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:56:06 --> Input Class Initialized
INFO - 2023-12-21 12:56:06 --> Language Class Initialized
INFO - 2023-12-21 12:56:06 --> Language Class Initialized
INFO - 2023-12-21 12:56:06 --> Config Class Initialized
INFO - 2023-12-21 12:56:06 --> Loader Class Initialized
INFO - 2023-12-21 12:56:06 --> Helper loaded: url_helper
INFO - 2023-12-21 12:56:06 --> Helper loaded: file_helper
INFO - 2023-12-21 12:56:06 --> Helper loaded: form_helper
INFO - 2023-12-21 12:56:06 --> Helper loaded: my_helper
INFO - 2023-12-21 12:56:06 --> Database Driver Class Initialized
INFO - 2023-12-21 12:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:56:06 --> Controller Class Initialized
DEBUG - 2023-12-21 12:56:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:56:08 --> Config Class Initialized
INFO - 2023-12-21 12:56:08 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:56:08 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:56:08 --> Utf8 Class Initialized
INFO - 2023-12-21 12:56:09 --> URI Class Initialized
INFO - 2023-12-21 12:56:09 --> Router Class Initialized
INFO - 2023-12-21 12:56:09 --> Output Class Initialized
INFO - 2023-12-21 12:56:09 --> Security Class Initialized
DEBUG - 2023-12-21 12:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:56:09 --> Input Class Initialized
INFO - 2023-12-21 12:56:09 --> Language Class Initialized
INFO - 2023-12-21 12:56:10 --> Language Class Initialized
INFO - 2023-12-21 12:56:10 --> Config Class Initialized
INFO - 2023-12-21 12:56:10 --> Loader Class Initialized
INFO - 2023-12-21 12:56:10 --> Helper loaded: url_helper
INFO - 2023-12-21 12:56:10 --> Helper loaded: file_helper
INFO - 2023-12-21 12:56:10 --> Helper loaded: form_helper
INFO - 2023-12-21 12:56:10 --> Helper loaded: my_helper
INFO - 2023-12-21 12:56:10 --> Database Driver Class Initialized
INFO - 2023-12-21 12:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:56:11 --> Controller Class Initialized
DEBUG - 2023-12-21 12:56:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:56:14 --> Final output sent to browser
DEBUG - 2023-12-21 12:56:14 --> Total execution time: 8.2339
INFO - 2023-12-21 12:56:26 --> Final output sent to browser
DEBUG - 2023-12-21 12:56:26 --> Total execution time: 17.3084
INFO - 2023-12-21 12:56:27 --> Config Class Initialized
INFO - 2023-12-21 12:56:27 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:56:27 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:56:27 --> Utf8 Class Initialized
INFO - 2023-12-21 12:56:27 --> URI Class Initialized
INFO - 2023-12-21 12:56:27 --> Router Class Initialized
INFO - 2023-12-21 12:56:27 --> Output Class Initialized
INFO - 2023-12-21 12:56:27 --> Security Class Initialized
DEBUG - 2023-12-21 12:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:56:27 --> Input Class Initialized
INFO - 2023-12-21 12:56:27 --> Language Class Initialized
INFO - 2023-12-21 12:56:28 --> Language Class Initialized
INFO - 2023-12-21 12:56:28 --> Config Class Initialized
INFO - 2023-12-21 12:56:28 --> Loader Class Initialized
INFO - 2023-12-21 12:56:28 --> Helper loaded: url_helper
INFO - 2023-12-21 12:56:28 --> Helper loaded: file_helper
INFO - 2023-12-21 12:56:28 --> Helper loaded: form_helper
INFO - 2023-12-21 12:56:28 --> Helper loaded: my_helper
INFO - 2023-12-21 12:56:28 --> Database Driver Class Initialized
INFO - 2023-12-21 12:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:56:28 --> Controller Class Initialized
DEBUG - 2023-12-21 12:56:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:56:42 --> Final output sent to browser
DEBUG - 2023-12-21 12:56:42 --> Total execution time: 15.5431
INFO - 2023-12-21 12:58:03 --> Config Class Initialized
INFO - 2023-12-21 12:58:03 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:58:03 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:58:03 --> Utf8 Class Initialized
INFO - 2023-12-21 12:58:03 --> URI Class Initialized
INFO - 2023-12-21 12:58:03 --> Router Class Initialized
INFO - 2023-12-21 12:58:03 --> Output Class Initialized
INFO - 2023-12-21 12:58:03 --> Security Class Initialized
DEBUG - 2023-12-21 12:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:58:03 --> Input Class Initialized
INFO - 2023-12-21 12:58:03 --> Language Class Initialized
INFO - 2023-12-21 12:58:03 --> Language Class Initialized
INFO - 2023-12-21 12:58:03 --> Config Class Initialized
INFO - 2023-12-21 12:58:03 --> Loader Class Initialized
INFO - 2023-12-21 12:58:03 --> Helper loaded: url_helper
INFO - 2023-12-21 12:58:03 --> Helper loaded: file_helper
INFO - 2023-12-21 12:58:03 --> Helper loaded: form_helper
INFO - 2023-12-21 12:58:03 --> Helper loaded: my_helper
INFO - 2023-12-21 12:58:03 --> Database Driver Class Initialized
INFO - 2023-12-21 12:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:58:03 --> Controller Class Initialized
DEBUG - 2023-12-21 12:58:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:58:14 --> Final output sent to browser
DEBUG - 2023-12-21 12:58:14 --> Total execution time: 11.2881
INFO - 2023-12-21 12:59:10 --> Config Class Initialized
INFO - 2023-12-21 12:59:10 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:10 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:10 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:10 --> URI Class Initialized
INFO - 2023-12-21 12:59:10 --> Router Class Initialized
INFO - 2023-12-21 12:59:10 --> Output Class Initialized
INFO - 2023-12-21 12:59:10 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:10 --> Input Class Initialized
INFO - 2023-12-21 12:59:10 --> Language Class Initialized
INFO - 2023-12-21 12:59:10 --> Language Class Initialized
INFO - 2023-12-21 12:59:10 --> Config Class Initialized
INFO - 2023-12-21 12:59:10 --> Loader Class Initialized
INFO - 2023-12-21 12:59:10 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:10 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:10 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:10 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:10 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:10 --> Controller Class Initialized
INFO - 2023-12-21 12:59:11 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:11 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:11 --> Total execution time: 0.5306
INFO - 2023-12-21 12:59:11 --> Config Class Initialized
INFO - 2023-12-21 12:59:11 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:11 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:11 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:11 --> URI Class Initialized
INFO - 2023-12-21 12:59:11 --> Router Class Initialized
INFO - 2023-12-21 12:59:11 --> Output Class Initialized
INFO - 2023-12-21 12:59:11 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:11 --> Input Class Initialized
INFO - 2023-12-21 12:59:11 --> Language Class Initialized
INFO - 2023-12-21 12:59:11 --> Language Class Initialized
INFO - 2023-12-21 12:59:11 --> Config Class Initialized
INFO - 2023-12-21 12:59:11 --> Loader Class Initialized
INFO - 2023-12-21 12:59:11 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:11 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:11 --> Controller Class Initialized
INFO - 2023-12-21 12:59:11 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:11 --> Config Class Initialized
INFO - 2023-12-21 12:59:11 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:11 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:11 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:11 --> URI Class Initialized
INFO - 2023-12-21 12:59:11 --> Router Class Initialized
INFO - 2023-12-21 12:59:11 --> Output Class Initialized
INFO - 2023-12-21 12:59:11 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:11 --> Input Class Initialized
INFO - 2023-12-21 12:59:11 --> Language Class Initialized
INFO - 2023-12-21 12:59:11 --> Language Class Initialized
INFO - 2023-12-21 12:59:11 --> Config Class Initialized
INFO - 2023-12-21 12:59:11 --> Loader Class Initialized
INFO - 2023-12-21 12:59:11 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:11 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:11 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:11 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-21 12:59:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-21 12:59:11 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:11 --> Total execution time: 0.0740
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
INFO - 2023-12-21 12:59:13 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:13 --> Total execution time: 0.1657
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:13 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:13 --> Total execution time: 0.4709
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: cookie_helper
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:13 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:13 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> URI Class Initialized
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Router Class Initialized
INFO - 2023-12-21 12:59:13 --> Output Class Initialized
INFO - 2023-12-21 12:59:13 --> Security Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
DEBUG - 2023-12-21 12:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:13 --> Input Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Language Class Initialized
INFO - 2023-12-21 12:59:13 --> Config Class Initialized
INFO - 2023-12-21 12:59:13 --> Loader Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:13 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
INFO - 2023-12-21 12:59:13 --> Helper loaded: cookie_helper
INFO - 2023-12-21 12:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:13 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-21 12:59:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-21 12:59:13 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:13 --> Total execution time: 0.0846
INFO - 2023-12-21 12:59:14 --> Config Class Initialized
INFO - 2023-12-21 12:59:14 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:14 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:14 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:14 --> URI Class Initialized
INFO - 2023-12-21 12:59:14 --> Router Class Initialized
INFO - 2023-12-21 12:59:14 --> Output Class Initialized
INFO - 2023-12-21 12:59:14 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:14 --> Input Class Initialized
INFO - 2023-12-21 12:59:14 --> Language Class Initialized
INFO - 2023-12-21 12:59:14 --> Language Class Initialized
INFO - 2023-12-21 12:59:14 --> Config Class Initialized
INFO - 2023-12-21 12:59:14 --> Loader Class Initialized
INFO - 2023-12-21 12:59:14 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:14 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:14 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:14 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:14 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:14 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-21 12:59:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-21 12:59:14 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:14 --> Total execution time: 0.0928
INFO - 2023-12-21 12:59:17 --> Config Class Initialized
INFO - 2023-12-21 12:59:17 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:17 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:17 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:17 --> URI Class Initialized
INFO - 2023-12-21 12:59:17 --> Router Class Initialized
INFO - 2023-12-21 12:59:17 --> Output Class Initialized
INFO - 2023-12-21 12:59:18 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:18 --> Input Class Initialized
INFO - 2023-12-21 12:59:18 --> Language Class Initialized
INFO - 2023-12-21 12:59:18 --> Language Class Initialized
INFO - 2023-12-21 12:59:18 --> Config Class Initialized
INFO - 2023-12-21 12:59:18 --> Loader Class Initialized
INFO - 2023-12-21 12:59:18 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:18 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:18 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:18 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:18 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:18 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:59:27 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:27 --> Total execution time: 9.5869
INFO - 2023-12-21 12:59:27 --> Config Class Initialized
INFO - 2023-12-21 12:59:27 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:27 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:27 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:27 --> URI Class Initialized
INFO - 2023-12-21 12:59:27 --> Router Class Initialized
INFO - 2023-12-21 12:59:27 --> Output Class Initialized
INFO - 2023-12-21 12:59:27 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:27 --> Input Class Initialized
INFO - 2023-12-21 12:59:27 --> Language Class Initialized
INFO - 2023-12-21 12:59:27 --> Language Class Initialized
INFO - 2023-12-21 12:59:27 --> Config Class Initialized
INFO - 2023-12-21 12:59:27 --> Loader Class Initialized
INFO - 2023-12-21 12:59:27 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:27 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:27 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:27 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:27 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:27 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:59:31 --> Config Class Initialized
INFO - 2023-12-21 12:59:31 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:31 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:31 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:31 --> URI Class Initialized
INFO - 2023-12-21 12:59:31 --> Router Class Initialized
INFO - 2023-12-21 12:59:32 --> Output Class Initialized
INFO - 2023-12-21 12:59:32 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:32 --> Input Class Initialized
INFO - 2023-12-21 12:59:32 --> Language Class Initialized
INFO - 2023-12-21 12:59:33 --> Language Class Initialized
INFO - 2023-12-21 12:59:33 --> Config Class Initialized
INFO - 2023-12-21 12:59:33 --> Loader Class Initialized
INFO - 2023-12-21 12:59:33 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:33 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:33 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:33 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:33 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:34 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 12:59:40 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:40 --> Total execution time: 12.6216
INFO - 2023-12-21 12:59:47 --> Final output sent to browser
DEBUG - 2023-12-21 12:59:47 --> Total execution time: 16.2182
INFO - 2023-12-21 12:59:48 --> Config Class Initialized
INFO - 2023-12-21 12:59:48 --> Hooks Class Initialized
DEBUG - 2023-12-21 12:59:48 --> UTF-8 Support Enabled
INFO - 2023-12-21 12:59:48 --> Utf8 Class Initialized
INFO - 2023-12-21 12:59:48 --> URI Class Initialized
INFO - 2023-12-21 12:59:48 --> Router Class Initialized
INFO - 2023-12-21 12:59:48 --> Output Class Initialized
INFO - 2023-12-21 12:59:48 --> Security Class Initialized
DEBUG - 2023-12-21 12:59:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 12:59:48 --> Input Class Initialized
INFO - 2023-12-21 12:59:48 --> Language Class Initialized
INFO - 2023-12-21 12:59:49 --> Language Class Initialized
INFO - 2023-12-21 12:59:49 --> Config Class Initialized
INFO - 2023-12-21 12:59:49 --> Loader Class Initialized
INFO - 2023-12-21 12:59:49 --> Helper loaded: url_helper
INFO - 2023-12-21 12:59:49 --> Helper loaded: file_helper
INFO - 2023-12-21 12:59:49 --> Helper loaded: form_helper
INFO - 2023-12-21 12:59:49 --> Helper loaded: my_helper
INFO - 2023-12-21 12:59:49 --> Database Driver Class Initialized
INFO - 2023-12-21 12:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 12:59:49 --> Controller Class Initialized
DEBUG - 2023-12-21 12:59:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 13:00:03 --> Final output sent to browser
DEBUG - 2023-12-21 13:00:03 --> Total execution time: 15.2903
INFO - 2023-12-21 13:00:33 --> Config Class Initialized
INFO - 2023-12-21 13:00:33 --> Hooks Class Initialized
DEBUG - 2023-12-21 13:00:33 --> UTF-8 Support Enabled
INFO - 2023-12-21 13:00:33 --> Utf8 Class Initialized
INFO - 2023-12-21 13:00:33 --> URI Class Initialized
INFO - 2023-12-21 13:00:33 --> Router Class Initialized
INFO - 2023-12-21 13:00:33 --> Output Class Initialized
INFO - 2023-12-21 13:00:33 --> Security Class Initialized
DEBUG - 2023-12-21 13:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 13:00:33 --> Input Class Initialized
INFO - 2023-12-21 13:00:33 --> Language Class Initialized
INFO - 2023-12-21 13:00:33 --> Language Class Initialized
INFO - 2023-12-21 13:00:33 --> Config Class Initialized
INFO - 2023-12-21 13:00:33 --> Loader Class Initialized
INFO - 2023-12-21 13:00:33 --> Helper loaded: url_helper
INFO - 2023-12-21 13:00:34 --> Helper loaded: file_helper
INFO - 2023-12-21 13:00:34 --> Helper loaded: form_helper
INFO - 2023-12-21 13:00:34 --> Helper loaded: my_helper
INFO - 2023-12-21 13:00:34 --> Database Driver Class Initialized
INFO - 2023-12-21 13:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 13:00:34 --> Controller Class Initialized
DEBUG - 2023-12-21 13:00:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 13:00:40 --> Final output sent to browser
DEBUG - 2023-12-21 13:00:40 --> Total execution time: 6.8346
INFO - 2023-12-21 14:05:15 --> Config Class Initialized
INFO - 2023-12-21 14:05:15 --> Hooks Class Initialized
DEBUG - 2023-12-21 14:05:15 --> UTF-8 Support Enabled
INFO - 2023-12-21 14:05:15 --> Utf8 Class Initialized
INFO - 2023-12-21 14:05:15 --> URI Class Initialized
INFO - 2023-12-21 14:05:15 --> Router Class Initialized
INFO - 2023-12-21 14:05:15 --> Output Class Initialized
INFO - 2023-12-21 14:05:15 --> Security Class Initialized
DEBUG - 2023-12-21 14:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 14:05:15 --> Input Class Initialized
INFO - 2023-12-21 14:05:15 --> Language Class Initialized
INFO - 2023-12-21 14:05:15 --> Language Class Initialized
INFO - 2023-12-21 14:05:15 --> Config Class Initialized
INFO - 2023-12-21 14:05:15 --> Loader Class Initialized
INFO - 2023-12-21 14:05:15 --> Helper loaded: url_helper
INFO - 2023-12-21 14:05:15 --> Helper loaded: file_helper
INFO - 2023-12-21 14:05:15 --> Helper loaded: form_helper
INFO - 2023-12-21 14:05:15 --> Helper loaded: my_helper
INFO - 2023-12-21 14:05:15 --> Database Driver Class Initialized
INFO - 2023-12-21 14:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 14:05:15 --> Controller Class Initialized
DEBUG - 2023-12-21 14:05:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 14:05:23 --> Final output sent to browser
DEBUG - 2023-12-21 14:05:23 --> Total execution time: 8.0092
INFO - 2023-12-21 19:01:02 --> Config Class Initialized
INFO - 2023-12-21 19:01:02 --> Hooks Class Initialized
DEBUG - 2023-12-21 19:01:02 --> UTF-8 Support Enabled
INFO - 2023-12-21 19:01:02 --> Utf8 Class Initialized
INFO - 2023-12-21 19:01:02 --> URI Class Initialized
INFO - 2023-12-21 19:01:02 --> Router Class Initialized
INFO - 2023-12-21 19:01:02 --> Output Class Initialized
INFO - 2023-12-21 19:01:02 --> Security Class Initialized
DEBUG - 2023-12-21 19:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 19:01:02 --> Input Class Initialized
INFO - 2023-12-21 19:01:02 --> Language Class Initialized
INFO - 2023-12-21 19:01:02 --> Language Class Initialized
INFO - 2023-12-21 19:01:02 --> Config Class Initialized
INFO - 2023-12-21 19:01:02 --> Loader Class Initialized
INFO - 2023-12-21 19:01:02 --> Helper loaded: url_helper
INFO - 2023-12-21 19:01:02 --> Helper loaded: file_helper
INFO - 2023-12-21 19:01:02 --> Helper loaded: form_helper
INFO - 2023-12-21 19:01:02 --> Helper loaded: my_helper
INFO - 2023-12-21 19:01:02 --> Database Driver Class Initialized
INFO - 2023-12-21 19:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 19:01:02 --> Controller Class Initialized
DEBUG - 2023-12-21 19:01:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 19:01:04 --> Config Class Initialized
INFO - 2023-12-21 19:01:04 --> Hooks Class Initialized
DEBUG - 2023-12-21 19:01:04 --> UTF-8 Support Enabled
INFO - 2023-12-21 19:01:04 --> Utf8 Class Initialized
INFO - 2023-12-21 19:01:04 --> URI Class Initialized
INFO - 2023-12-21 19:01:04 --> Router Class Initialized
INFO - 2023-12-21 19:01:04 --> Output Class Initialized
INFO - 2023-12-21 19:01:04 --> Security Class Initialized
DEBUG - 2023-12-21 19:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-21 19:01:04 --> Input Class Initialized
INFO - 2023-12-21 19:01:04 --> Language Class Initialized
INFO - 2023-12-21 19:01:04 --> Language Class Initialized
INFO - 2023-12-21 19:01:04 --> Config Class Initialized
INFO - 2023-12-21 19:01:04 --> Loader Class Initialized
INFO - 2023-12-21 19:01:04 --> Helper loaded: url_helper
INFO - 2023-12-21 19:01:04 --> Helper loaded: file_helper
INFO - 2023-12-21 19:01:04 --> Helper loaded: form_helper
INFO - 2023-12-21 19:01:04 --> Helper loaded: my_helper
INFO - 2023-12-21 19:01:04 --> Database Driver Class Initialized
INFO - 2023-12-21 19:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-21 19:01:04 --> Controller Class Initialized
DEBUG - 2023-12-21 19:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-21 19:01:20 --> Final output sent to browser
DEBUG - 2023-12-21 19:01:20 --> Total execution time: 17.8499
INFO - 2023-12-21 19:01:24 --> Final output sent to browser
DEBUG - 2023-12-21 19:01:24 --> Total execution time: 19.7231
