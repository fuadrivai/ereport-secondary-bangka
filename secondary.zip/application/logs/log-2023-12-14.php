<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-14 07:53:09 --> Config Class Initialized
INFO - 2023-12-14 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:09 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:09 --> URI Class Initialized
DEBUG - 2023-12-14 07:53:09 --> No URI present. Default controller set.
INFO - 2023-12-14 07:53:09 --> Router Class Initialized
INFO - 2023-12-14 07:53:09 --> Output Class Initialized
INFO - 2023-12-14 07:53:09 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:09 --> Input Class Initialized
INFO - 2023-12-14 07:53:09 --> Language Class Initialized
INFO - 2023-12-14 07:53:09 --> Language Class Initialized
INFO - 2023-12-14 07:53:09 --> Config Class Initialized
INFO - 2023-12-14 07:53:09 --> Loader Class Initialized
INFO - 2023-12-14 07:53:09 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:09 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:09 --> Controller Class Initialized
INFO - 2023-12-14 07:53:09 --> Config Class Initialized
INFO - 2023-12-14 07:53:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:09 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:09 --> URI Class Initialized
INFO - 2023-12-14 07:53:09 --> Router Class Initialized
INFO - 2023-12-14 07:53:09 --> Output Class Initialized
INFO - 2023-12-14 07:53:09 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:09 --> Input Class Initialized
INFO - 2023-12-14 07:53:09 --> Language Class Initialized
INFO - 2023-12-14 07:53:09 --> Language Class Initialized
INFO - 2023-12-14 07:53:09 --> Config Class Initialized
INFO - 2023-12-14 07:53:09 --> Loader Class Initialized
INFO - 2023-12-14 07:53:09 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:09 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:09 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:09 --> Controller Class Initialized
DEBUG - 2023-12-14 07:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 07:53:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 07:53:09 --> Final output sent to browser
DEBUG - 2023-12-14 07:53:09 --> Total execution time: 0.0784
INFO - 2023-12-14 07:53:19 --> Config Class Initialized
INFO - 2023-12-14 07:53:19 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:19 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:19 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:19 --> URI Class Initialized
INFO - 2023-12-14 07:53:19 --> Router Class Initialized
INFO - 2023-12-14 07:53:19 --> Output Class Initialized
INFO - 2023-12-14 07:53:19 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:19 --> Input Class Initialized
INFO - 2023-12-14 07:53:19 --> Language Class Initialized
INFO - 2023-12-14 07:53:19 --> Language Class Initialized
INFO - 2023-12-14 07:53:19 --> Config Class Initialized
INFO - 2023-12-14 07:53:19 --> Loader Class Initialized
INFO - 2023-12-14 07:53:19 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:19 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:19 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:19 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:20 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:20 --> Controller Class Initialized
INFO - 2023-12-14 07:53:20 --> Helper loaded: cookie_helper
INFO - 2023-12-14 07:53:20 --> Final output sent to browser
DEBUG - 2023-12-14 07:53:20 --> Total execution time: 0.5541
INFO - 2023-12-14 07:53:20 --> Config Class Initialized
INFO - 2023-12-14 07:53:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:20 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:20 --> URI Class Initialized
INFO - 2023-12-14 07:53:20 --> Router Class Initialized
INFO - 2023-12-14 07:53:20 --> Output Class Initialized
INFO - 2023-12-14 07:53:20 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:20 --> Input Class Initialized
INFO - 2023-12-14 07:53:20 --> Language Class Initialized
INFO - 2023-12-14 07:53:20 --> Language Class Initialized
INFO - 2023-12-14 07:53:20 --> Config Class Initialized
INFO - 2023-12-14 07:53:20 --> Loader Class Initialized
INFO - 2023-12-14 07:53:20 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:20 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:20 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:20 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:20 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:20 --> Controller Class Initialized
DEBUG - 2023-12-14 07:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 07:53:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 07:53:21 --> Final output sent to browser
DEBUG - 2023-12-14 07:53:21 --> Total execution time: 0.3021
INFO - 2023-12-14 07:53:35 --> Config Class Initialized
INFO - 2023-12-14 07:53:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:35 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:35 --> URI Class Initialized
INFO - 2023-12-14 07:53:35 --> Router Class Initialized
INFO - 2023-12-14 07:53:35 --> Output Class Initialized
INFO - 2023-12-14 07:53:35 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:35 --> Input Class Initialized
INFO - 2023-12-14 07:53:35 --> Language Class Initialized
INFO - 2023-12-14 07:53:35 --> Language Class Initialized
INFO - 2023-12-14 07:53:35 --> Config Class Initialized
INFO - 2023-12-14 07:53:35 --> Loader Class Initialized
INFO - 2023-12-14 07:53:35 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:35 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:35 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:35 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:35 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:35 --> Controller Class Initialized
DEBUG - 2023-12-14 07:53:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-14 07:53:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 07:53:35 --> Final output sent to browser
DEBUG - 2023-12-14 07:53:35 --> Total execution time: 0.0326
INFO - 2023-12-14 07:53:59 --> Config Class Initialized
INFO - 2023-12-14 07:53:59 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:53:59 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:53:59 --> Utf8 Class Initialized
INFO - 2023-12-14 07:53:59 --> URI Class Initialized
INFO - 2023-12-14 07:53:59 --> Router Class Initialized
INFO - 2023-12-14 07:53:59 --> Output Class Initialized
INFO - 2023-12-14 07:53:59 --> Security Class Initialized
DEBUG - 2023-12-14 07:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:53:59 --> Input Class Initialized
INFO - 2023-12-14 07:53:59 --> Language Class Initialized
INFO - 2023-12-14 07:53:59 --> Language Class Initialized
INFO - 2023-12-14 07:53:59 --> Config Class Initialized
INFO - 2023-12-14 07:53:59 --> Loader Class Initialized
INFO - 2023-12-14 07:53:59 --> Helper loaded: url_helper
INFO - 2023-12-14 07:53:59 --> Helper loaded: file_helper
INFO - 2023-12-14 07:53:59 --> Helper loaded: form_helper
INFO - 2023-12-14 07:53:59 --> Helper loaded: my_helper
INFO - 2023-12-14 07:53:59 --> Database Driver Class Initialized
INFO - 2023-12-14 07:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:53:59 --> Controller Class Initialized
INFO - 2023-12-14 07:53:59 --> Final output sent to browser
DEBUG - 2023-12-14 07:53:59 --> Total execution time: 0.2583
INFO - 2023-12-14 07:54:25 --> Config Class Initialized
INFO - 2023-12-14 07:54:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:54:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:54:25 --> Utf8 Class Initialized
INFO - 2023-12-14 07:54:25 --> URI Class Initialized
INFO - 2023-12-14 07:54:25 --> Router Class Initialized
INFO - 2023-12-14 07:54:25 --> Output Class Initialized
INFO - 2023-12-14 07:54:25 --> Security Class Initialized
DEBUG - 2023-12-14 07:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:54:25 --> Input Class Initialized
INFO - 2023-12-14 07:54:25 --> Language Class Initialized
INFO - 2023-12-14 07:54:25 --> Language Class Initialized
INFO - 2023-12-14 07:54:25 --> Config Class Initialized
INFO - 2023-12-14 07:54:25 --> Loader Class Initialized
INFO - 2023-12-14 07:54:25 --> Helper loaded: url_helper
INFO - 2023-12-14 07:54:25 --> Helper loaded: file_helper
INFO - 2023-12-14 07:54:25 --> Helper loaded: form_helper
INFO - 2023-12-14 07:54:25 --> Helper loaded: my_helper
INFO - 2023-12-14 07:54:26 --> Database Driver Class Initialized
INFO - 2023-12-14 07:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:54:26 --> Controller Class Initialized
INFO - 2023-12-14 07:54:27 --> Final output sent to browser
DEBUG - 2023-12-14 07:54:27 --> Total execution time: 1.9321
INFO - 2023-12-14 07:54:30 --> Config Class Initialized
INFO - 2023-12-14 07:54:30 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:54:30 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:54:30 --> Utf8 Class Initialized
INFO - 2023-12-14 07:54:30 --> URI Class Initialized
INFO - 2023-12-14 07:54:30 --> Router Class Initialized
INFO - 2023-12-14 07:54:30 --> Output Class Initialized
INFO - 2023-12-14 07:54:30 --> Security Class Initialized
DEBUG - 2023-12-14 07:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:54:30 --> Input Class Initialized
INFO - 2023-12-14 07:54:30 --> Language Class Initialized
INFO - 2023-12-14 07:54:30 --> Language Class Initialized
INFO - 2023-12-14 07:54:30 --> Config Class Initialized
INFO - 2023-12-14 07:54:30 --> Loader Class Initialized
INFO - 2023-12-14 07:54:30 --> Helper loaded: url_helper
INFO - 2023-12-14 07:54:30 --> Helper loaded: file_helper
INFO - 2023-12-14 07:54:31 --> Helper loaded: form_helper
INFO - 2023-12-14 07:54:31 --> Helper loaded: my_helper
INFO - 2023-12-14 07:54:31 --> Database Driver Class Initialized
INFO - 2023-12-14 07:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:54:31 --> Controller Class Initialized
INFO - 2023-12-14 07:54:31 --> Final output sent to browser
DEBUG - 2023-12-14 07:54:31 --> Total execution time: 1.0095
INFO - 2023-12-14 07:54:38 --> Config Class Initialized
INFO - 2023-12-14 07:54:38 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:54:38 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:54:38 --> Utf8 Class Initialized
INFO - 2023-12-14 07:54:38 --> URI Class Initialized
INFO - 2023-12-14 07:54:38 --> Router Class Initialized
INFO - 2023-12-14 07:54:38 --> Output Class Initialized
INFO - 2023-12-14 07:54:38 --> Security Class Initialized
DEBUG - 2023-12-14 07:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:54:38 --> Input Class Initialized
INFO - 2023-12-14 07:54:38 --> Language Class Initialized
INFO - 2023-12-14 07:54:38 --> Language Class Initialized
INFO - 2023-12-14 07:54:38 --> Config Class Initialized
INFO - 2023-12-14 07:54:38 --> Loader Class Initialized
INFO - 2023-12-14 07:54:38 --> Helper loaded: url_helper
INFO - 2023-12-14 07:54:38 --> Helper loaded: file_helper
INFO - 2023-12-14 07:54:38 --> Helper loaded: form_helper
INFO - 2023-12-14 07:54:38 --> Helper loaded: my_helper
INFO - 2023-12-14 07:54:38 --> Database Driver Class Initialized
INFO - 2023-12-14 07:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:54:38 --> Controller Class Initialized
INFO - 2023-12-14 07:54:39 --> Final output sent to browser
DEBUG - 2023-12-14 07:54:39 --> Total execution time: 0.1184
INFO - 2023-12-14 07:54:51 --> Config Class Initialized
INFO - 2023-12-14 07:54:51 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:54:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:54:51 --> Utf8 Class Initialized
INFO - 2023-12-14 07:54:51 --> URI Class Initialized
INFO - 2023-12-14 07:54:51 --> Router Class Initialized
INFO - 2023-12-14 07:54:51 --> Output Class Initialized
INFO - 2023-12-14 07:54:51 --> Security Class Initialized
DEBUG - 2023-12-14 07:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:54:51 --> Input Class Initialized
INFO - 2023-12-14 07:54:51 --> Language Class Initialized
INFO - 2023-12-14 07:54:51 --> Language Class Initialized
INFO - 2023-12-14 07:54:51 --> Config Class Initialized
INFO - 2023-12-14 07:54:51 --> Loader Class Initialized
INFO - 2023-12-14 07:54:51 --> Helper loaded: url_helper
INFO - 2023-12-14 07:54:51 --> Helper loaded: file_helper
INFO - 2023-12-14 07:54:51 --> Helper loaded: form_helper
INFO - 2023-12-14 07:54:51 --> Helper loaded: my_helper
INFO - 2023-12-14 07:54:51 --> Database Driver Class Initialized
INFO - 2023-12-14 07:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:54:51 --> Controller Class Initialized
INFO - 2023-12-14 07:54:51 --> Final output sent to browser
DEBUG - 2023-12-14 07:54:51 --> Total execution time: 0.2451
INFO - 2023-12-14 07:54:57 --> Config Class Initialized
INFO - 2023-12-14 07:54:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:54:57 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:54:57 --> Utf8 Class Initialized
INFO - 2023-12-14 07:54:57 --> URI Class Initialized
INFO - 2023-12-14 07:54:57 --> Router Class Initialized
INFO - 2023-12-14 07:54:57 --> Output Class Initialized
INFO - 2023-12-14 07:54:57 --> Security Class Initialized
DEBUG - 2023-12-14 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:54:57 --> Input Class Initialized
INFO - 2023-12-14 07:54:57 --> Language Class Initialized
INFO - 2023-12-14 07:54:57 --> Language Class Initialized
INFO - 2023-12-14 07:54:57 --> Config Class Initialized
INFO - 2023-12-14 07:54:57 --> Loader Class Initialized
INFO - 2023-12-14 07:54:57 --> Helper loaded: url_helper
INFO - 2023-12-14 07:54:57 --> Helper loaded: file_helper
INFO - 2023-12-14 07:54:57 --> Helper loaded: form_helper
INFO - 2023-12-14 07:54:57 --> Helper loaded: my_helper
INFO - 2023-12-14 07:54:57 --> Database Driver Class Initialized
INFO - 2023-12-14 07:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:54:57 --> Controller Class Initialized
INFO - 2023-12-14 07:54:57 --> Final output sent to browser
DEBUG - 2023-12-14 07:54:57 --> Total execution time: 0.0886
INFO - 2023-12-14 07:57:23 --> Config Class Initialized
INFO - 2023-12-14 07:57:23 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:57:23 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:57:23 --> Utf8 Class Initialized
INFO - 2023-12-14 07:57:23 --> URI Class Initialized
INFO - 2023-12-14 07:57:23 --> Router Class Initialized
INFO - 2023-12-14 07:57:23 --> Output Class Initialized
INFO - 2023-12-14 07:57:23 --> Security Class Initialized
DEBUG - 2023-12-14 07:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:57:23 --> Input Class Initialized
INFO - 2023-12-14 07:57:23 --> Language Class Initialized
INFO - 2023-12-14 07:57:23 --> Language Class Initialized
INFO - 2023-12-14 07:57:23 --> Config Class Initialized
INFO - 2023-12-14 07:57:23 --> Loader Class Initialized
INFO - 2023-12-14 07:57:23 --> Helper loaded: url_helper
INFO - 2023-12-14 07:57:23 --> Helper loaded: file_helper
INFO - 2023-12-14 07:57:23 --> Helper loaded: form_helper
INFO - 2023-12-14 07:57:23 --> Helper loaded: my_helper
INFO - 2023-12-14 07:57:23 --> Database Driver Class Initialized
INFO - 2023-12-14 07:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:57:23 --> Controller Class Initialized
INFO - 2023-12-14 07:57:23 --> Final output sent to browser
DEBUG - 2023-12-14 07:57:23 --> Total execution time: 0.1584
INFO - 2023-12-14 07:57:55 --> Config Class Initialized
INFO - 2023-12-14 07:57:55 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:57:55 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:57:55 --> Utf8 Class Initialized
INFO - 2023-12-14 07:57:55 --> URI Class Initialized
INFO - 2023-12-14 07:57:55 --> Router Class Initialized
INFO - 2023-12-14 07:57:55 --> Output Class Initialized
INFO - 2023-12-14 07:57:55 --> Security Class Initialized
DEBUG - 2023-12-14 07:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:57:55 --> Input Class Initialized
INFO - 2023-12-14 07:57:55 --> Language Class Initialized
INFO - 2023-12-14 07:57:55 --> Language Class Initialized
INFO - 2023-12-14 07:57:55 --> Config Class Initialized
INFO - 2023-12-14 07:57:55 --> Loader Class Initialized
INFO - 2023-12-14 07:57:55 --> Helper loaded: url_helper
INFO - 2023-12-14 07:57:55 --> Helper loaded: file_helper
INFO - 2023-12-14 07:57:55 --> Helper loaded: form_helper
INFO - 2023-12-14 07:57:55 --> Helper loaded: my_helper
INFO - 2023-12-14 07:57:55 --> Database Driver Class Initialized
INFO - 2023-12-14 07:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:57:55 --> Controller Class Initialized
DEBUG - 2023-12-14 07:57:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 07:57:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 07:57:55 --> Final output sent to browser
DEBUG - 2023-12-14 07:57:55 --> Total execution time: 0.1953
INFO - 2023-12-14 07:57:59 --> Config Class Initialized
INFO - 2023-12-14 07:57:59 --> Hooks Class Initialized
DEBUG - 2023-12-14 07:57:59 --> UTF-8 Support Enabled
INFO - 2023-12-14 07:57:59 --> Utf8 Class Initialized
INFO - 2023-12-14 07:57:59 --> URI Class Initialized
INFO - 2023-12-14 07:57:59 --> Router Class Initialized
INFO - 2023-12-14 07:57:59 --> Output Class Initialized
INFO - 2023-12-14 07:57:59 --> Security Class Initialized
DEBUG - 2023-12-14 07:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 07:57:59 --> Input Class Initialized
INFO - 2023-12-14 07:57:59 --> Language Class Initialized
INFO - 2023-12-14 07:57:59 --> Language Class Initialized
INFO - 2023-12-14 07:57:59 --> Config Class Initialized
INFO - 2023-12-14 07:57:59 --> Loader Class Initialized
INFO - 2023-12-14 07:57:59 --> Helper loaded: url_helper
INFO - 2023-12-14 07:57:59 --> Helper loaded: file_helper
INFO - 2023-12-14 07:57:59 --> Helper loaded: form_helper
INFO - 2023-12-14 07:57:59 --> Helper loaded: my_helper
INFO - 2023-12-14 07:57:59 --> Database Driver Class Initialized
INFO - 2023-12-14 07:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 07:57:59 --> Controller Class Initialized
DEBUG - 2023-12-14 07:58:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 07:58:06 --> Final output sent to browser
DEBUG - 2023-12-14 07:58:06 --> Total execution time: 7.1478
INFO - 2023-12-14 08:00:18 --> Config Class Initialized
INFO - 2023-12-14 08:00:18 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:00:18 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:00:18 --> Utf8 Class Initialized
INFO - 2023-12-14 08:00:18 --> URI Class Initialized
INFO - 2023-12-14 08:00:18 --> Router Class Initialized
INFO - 2023-12-14 08:00:18 --> Output Class Initialized
INFO - 2023-12-14 08:00:18 --> Security Class Initialized
DEBUG - 2023-12-14 08:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:00:18 --> Input Class Initialized
INFO - 2023-12-14 08:00:18 --> Language Class Initialized
INFO - 2023-12-14 08:00:19 --> Language Class Initialized
INFO - 2023-12-14 08:00:19 --> Config Class Initialized
INFO - 2023-12-14 08:00:19 --> Loader Class Initialized
INFO - 2023-12-14 08:00:19 --> Helper loaded: url_helper
INFO - 2023-12-14 08:00:19 --> Helper loaded: file_helper
INFO - 2023-12-14 08:00:19 --> Helper loaded: form_helper
INFO - 2023-12-14 08:00:19 --> Helper loaded: my_helper
INFO - 2023-12-14 08:00:19 --> Database Driver Class Initialized
INFO - 2023-12-14 08:00:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:00:19 --> Controller Class Initialized
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 08:00:19 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 08:00:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 08:00:33 --> Final output sent to browser
DEBUG - 2023-12-14 08:00:33 --> Total execution time: 14.9866
INFO - 2023-12-14 08:21:24 --> Config Class Initialized
INFO - 2023-12-14 08:21:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:21:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:21:24 --> Utf8 Class Initialized
INFO - 2023-12-14 08:21:24 --> URI Class Initialized
INFO - 2023-12-14 08:21:24 --> Router Class Initialized
INFO - 2023-12-14 08:21:24 --> Output Class Initialized
INFO - 2023-12-14 08:21:24 --> Security Class Initialized
DEBUG - 2023-12-14 08:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:21:24 --> Input Class Initialized
INFO - 2023-12-14 08:21:24 --> Language Class Initialized
INFO - 2023-12-14 08:21:24 --> Language Class Initialized
INFO - 2023-12-14 08:21:24 --> Config Class Initialized
INFO - 2023-12-14 08:21:24 --> Loader Class Initialized
INFO - 2023-12-14 08:21:24 --> Helper loaded: url_helper
INFO - 2023-12-14 08:21:24 --> Helper loaded: file_helper
INFO - 2023-12-14 08:21:24 --> Helper loaded: form_helper
INFO - 2023-12-14 08:21:24 --> Helper loaded: my_helper
INFO - 2023-12-14 08:21:24 --> Database Driver Class Initialized
INFO - 2023-12-14 08:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:21:24 --> Controller Class Initialized
DEBUG - 2023-12-14 08:21:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 08:21:42 --> Final output sent to browser
DEBUG - 2023-12-14 08:21:42 --> Total execution time: 18.0824
INFO - 2023-12-14 08:22:45 --> Config Class Initialized
INFO - 2023-12-14 08:22:45 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:22:45 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:22:45 --> Utf8 Class Initialized
INFO - 2023-12-14 08:22:45 --> URI Class Initialized
INFO - 2023-12-14 08:22:45 --> Router Class Initialized
INFO - 2023-12-14 08:22:45 --> Output Class Initialized
INFO - 2023-12-14 08:22:45 --> Security Class Initialized
DEBUG - 2023-12-14 08:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:22:45 --> Input Class Initialized
INFO - 2023-12-14 08:22:45 --> Language Class Initialized
INFO - 2023-12-14 08:22:45 --> Language Class Initialized
INFO - 2023-12-14 08:22:45 --> Config Class Initialized
INFO - 2023-12-14 08:22:45 --> Loader Class Initialized
INFO - 2023-12-14 08:22:45 --> Helper loaded: url_helper
INFO - 2023-12-14 08:22:45 --> Helper loaded: file_helper
INFO - 2023-12-14 08:22:45 --> Helper loaded: form_helper
INFO - 2023-12-14 08:22:45 --> Helper loaded: my_helper
INFO - 2023-12-14 08:22:45 --> Database Driver Class Initialized
INFO - 2023-12-14 08:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:22:45 --> Controller Class Initialized
DEBUG - 2023-12-14 08:22:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 08:22:59 --> Final output sent to browser
DEBUG - 2023-12-14 08:22:59 --> Total execution time: 14.1477
INFO - 2023-12-14 08:24:27 --> Config Class Initialized
INFO - 2023-12-14 08:24:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:27 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:27 --> URI Class Initialized
INFO - 2023-12-14 08:24:27 --> Router Class Initialized
INFO - 2023-12-14 08:24:27 --> Output Class Initialized
INFO - 2023-12-14 08:24:27 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:27 --> Input Class Initialized
INFO - 2023-12-14 08:24:27 --> Language Class Initialized
INFO - 2023-12-14 08:24:27 --> Language Class Initialized
INFO - 2023-12-14 08:24:27 --> Config Class Initialized
INFO - 2023-12-14 08:24:27 --> Loader Class Initialized
INFO - 2023-12-14 08:24:27 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:27 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:27 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:27 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:27 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:27 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_homeroom/views/list.php
DEBUG - 2023-12-14 08:24:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:27 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:27 --> Total execution time: 0.2491
INFO - 2023-12-14 08:24:31 --> Config Class Initialized
INFO - 2023-12-14 08:24:31 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:31 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:31 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:31 --> URI Class Initialized
INFO - 2023-12-14 08:24:31 --> Router Class Initialized
INFO - 2023-12-14 08:24:31 --> Output Class Initialized
INFO - 2023-12-14 08:24:31 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:31 --> Input Class Initialized
INFO - 2023-12-14 08:24:31 --> Language Class Initialized
INFO - 2023-12-14 08:24:31 --> Language Class Initialized
INFO - 2023-12-14 08:24:31 --> Config Class Initialized
INFO - 2023-12-14 08:24:31 --> Loader Class Initialized
INFO - 2023-12-14 08:24:31 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:31 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:31 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:31 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:31 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:31 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan/views/list.php
DEBUG - 2023-12-14 08:24:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:31 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:31 --> Total execution time: 0.1879
INFO - 2023-12-14 08:24:37 --> Config Class Initialized
INFO - 2023-12-14 08:24:37 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:37 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:37 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:37 --> URI Class Initialized
INFO - 2023-12-14 08:24:37 --> Router Class Initialized
INFO - 2023-12-14 08:24:37 --> Output Class Initialized
INFO - 2023-12-14 08:24:37 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:37 --> Input Class Initialized
INFO - 2023-12-14 08:24:37 --> Language Class Initialized
INFO - 2023-12-14 08:24:37 --> Language Class Initialized
INFO - 2023-12-14 08:24:37 --> Config Class Initialized
INFO - 2023-12-14 08:24:37 --> Loader Class Initialized
INFO - 2023-12-14 08:24:37 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:37 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:37 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:37 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:38 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:38 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-12-14 08:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:38 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:38 --> Total execution time: 1.6326
INFO - 2023-12-14 08:24:46 --> Config Class Initialized
INFO - 2023-12-14 08:24:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:46 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:46 --> URI Class Initialized
INFO - 2023-12-14 08:24:46 --> Router Class Initialized
INFO - 2023-12-14 08:24:46 --> Output Class Initialized
INFO - 2023-12-14 08:24:46 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:46 --> Input Class Initialized
INFO - 2023-12-14 08:24:46 --> Language Class Initialized
INFO - 2023-12-14 08:24:46 --> Language Class Initialized
INFO - 2023-12-14 08:24:46 --> Config Class Initialized
INFO - 2023-12-14 08:24:46 --> Loader Class Initialized
INFO - 2023-12-14 08:24:46 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:46 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:46 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:46 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:46 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:47 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-12-14 08:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:47 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:47 --> Total execution time: 0.4419
INFO - 2023-12-14 08:24:55 --> Config Class Initialized
INFO - 2023-12-14 08:24:55 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:55 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:55 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:55 --> URI Class Initialized
INFO - 2023-12-14 08:24:55 --> Router Class Initialized
INFO - 2023-12-14 08:24:55 --> Output Class Initialized
INFO - 2023-12-14 08:24:55 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:55 --> Input Class Initialized
INFO - 2023-12-14 08:24:55 --> Language Class Initialized
INFO - 2023-12-14 08:24:55 --> Language Class Initialized
INFO - 2023-12-14 08:24:55 --> Config Class Initialized
INFO - 2023-12-14 08:24:55 --> Loader Class Initialized
INFO - 2023-12-14 08:24:55 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:55 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:55 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:55 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:55 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:55 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 08:24:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:55 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:55 --> Total execution time: 0.1148
INFO - 2023-12-14 08:24:58 --> Config Class Initialized
INFO - 2023-12-14 08:24:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:24:59 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:24:59 --> Utf8 Class Initialized
INFO - 2023-12-14 08:24:59 --> URI Class Initialized
INFO - 2023-12-14 08:24:59 --> Router Class Initialized
INFO - 2023-12-14 08:24:59 --> Output Class Initialized
INFO - 2023-12-14 08:24:59 --> Security Class Initialized
DEBUG - 2023-12-14 08:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:24:59 --> Input Class Initialized
INFO - 2023-12-14 08:24:59 --> Language Class Initialized
INFO - 2023-12-14 08:24:59 --> Language Class Initialized
INFO - 2023-12-14 08:24:59 --> Config Class Initialized
INFO - 2023-12-14 08:24:59 --> Loader Class Initialized
INFO - 2023-12-14 08:24:59 --> Helper loaded: url_helper
INFO - 2023-12-14 08:24:59 --> Helper loaded: file_helper
INFO - 2023-12-14 08:24:59 --> Helper loaded: form_helper
INFO - 2023-12-14 08:24:59 --> Helper loaded: my_helper
INFO - 2023-12-14 08:24:59 --> Database Driver Class Initialized
INFO - 2023-12-14 08:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:24:59 --> Controller Class Initialized
DEBUG - 2023-12-14 08:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 08:24:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 08:24:59 --> Final output sent to browser
DEBUG - 2023-12-14 08:24:59 --> Total execution time: 0.2806
INFO - 2023-12-14 08:25:00 --> Config Class Initialized
INFO - 2023-12-14 08:25:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:25:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:25:00 --> Utf8 Class Initialized
INFO - 2023-12-14 08:25:00 --> URI Class Initialized
INFO - 2023-12-14 08:25:00 --> Router Class Initialized
INFO - 2023-12-14 08:25:00 --> Output Class Initialized
INFO - 2023-12-14 08:25:00 --> Security Class Initialized
DEBUG - 2023-12-14 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:25:00 --> Input Class Initialized
INFO - 2023-12-14 08:25:00 --> Language Class Initialized
INFO - 2023-12-14 08:25:00 --> Language Class Initialized
INFO - 2023-12-14 08:25:00 --> Config Class Initialized
INFO - 2023-12-14 08:25:00 --> Loader Class Initialized
INFO - 2023-12-14 08:25:00 --> Helper loaded: url_helper
INFO - 2023-12-14 08:25:00 --> Helper loaded: file_helper
INFO - 2023-12-14 08:25:00 --> Helper loaded: form_helper
INFO - 2023-12-14 08:25:00 --> Helper loaded: my_helper
INFO - 2023-12-14 08:25:00 --> Database Driver Class Initialized
INFO - 2023-12-14 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:25:00 --> Controller Class Initialized
INFO - 2023-12-14 08:25:00 --> Final output sent to browser
DEBUG - 2023-12-14 08:25:00 --> Total execution time: 0.0522
INFO - 2023-12-14 08:49:03 --> Config Class Initialized
INFO - 2023-12-14 08:49:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 08:49:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 08:49:04 --> Utf8 Class Initialized
INFO - 2023-12-14 08:49:04 --> URI Class Initialized
INFO - 2023-12-14 08:49:04 --> Router Class Initialized
INFO - 2023-12-14 08:49:04 --> Output Class Initialized
INFO - 2023-12-14 08:49:04 --> Security Class Initialized
DEBUG - 2023-12-14 08:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 08:49:04 --> Input Class Initialized
INFO - 2023-12-14 08:49:04 --> Language Class Initialized
INFO - 2023-12-14 08:49:04 --> Language Class Initialized
INFO - 2023-12-14 08:49:04 --> Config Class Initialized
INFO - 2023-12-14 08:49:04 --> Loader Class Initialized
INFO - 2023-12-14 08:49:04 --> Helper loaded: url_helper
INFO - 2023-12-14 08:49:04 --> Helper loaded: file_helper
INFO - 2023-12-14 08:49:04 --> Helper loaded: form_helper
INFO - 2023-12-14 08:49:04 --> Helper loaded: my_helper
INFO - 2023-12-14 08:49:04 --> Database Driver Class Initialized
INFO - 2023-12-14 08:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 08:49:04 --> Controller Class Initialized
INFO - 2023-12-14 08:49:05 --> Final output sent to browser
DEBUG - 2023-12-14 08:49:05 --> Total execution time: 1.6441
INFO - 2023-12-14 09:00:05 --> Config Class Initialized
INFO - 2023-12-14 09:00:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:00:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:00:05 --> Utf8 Class Initialized
INFO - 2023-12-14 09:00:05 --> URI Class Initialized
INFO - 2023-12-14 09:00:05 --> Router Class Initialized
INFO - 2023-12-14 09:00:05 --> Output Class Initialized
INFO - 2023-12-14 09:00:05 --> Security Class Initialized
DEBUG - 2023-12-14 09:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:00:05 --> Input Class Initialized
INFO - 2023-12-14 09:00:05 --> Language Class Initialized
INFO - 2023-12-14 09:00:05 --> Language Class Initialized
INFO - 2023-12-14 09:00:05 --> Config Class Initialized
INFO - 2023-12-14 09:00:05 --> Loader Class Initialized
INFO - 2023-12-14 09:00:05 --> Helper loaded: url_helper
INFO - 2023-12-14 09:00:05 --> Helper loaded: file_helper
INFO - 2023-12-14 09:00:05 --> Helper loaded: form_helper
INFO - 2023-12-14 09:00:05 --> Helper loaded: my_helper
INFO - 2023-12-14 09:00:05 --> Database Driver Class Initialized
INFO - 2023-12-14 09:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:00:05 --> Controller Class Initialized
DEBUG - 2023-12-14 09:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 09:00:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:00:05 --> Final output sent to browser
DEBUG - 2023-12-14 09:00:05 --> Total execution time: 0.5126
INFO - 2023-12-14 09:14:33 --> Config Class Initialized
INFO - 2023-12-14 09:14:33 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:14:33 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:14:33 --> Utf8 Class Initialized
INFO - 2023-12-14 09:14:33 --> URI Class Initialized
INFO - 2023-12-14 09:14:33 --> Router Class Initialized
INFO - 2023-12-14 09:14:33 --> Output Class Initialized
INFO - 2023-12-14 09:14:33 --> Security Class Initialized
DEBUG - 2023-12-14 09:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:14:33 --> Input Class Initialized
INFO - 2023-12-14 09:14:33 --> Language Class Initialized
INFO - 2023-12-14 09:14:33 --> Language Class Initialized
INFO - 2023-12-14 09:14:33 --> Config Class Initialized
INFO - 2023-12-14 09:14:33 --> Loader Class Initialized
INFO - 2023-12-14 09:14:33 --> Helper loaded: url_helper
INFO - 2023-12-14 09:14:33 --> Helper loaded: file_helper
INFO - 2023-12-14 09:14:33 --> Helper loaded: form_helper
INFO - 2023-12-14 09:14:33 --> Helper loaded: my_helper
INFO - 2023-12-14 09:14:33 --> Database Driver Class Initialized
INFO - 2023-12-14 09:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:14:33 --> Controller Class Initialized
INFO - 2023-12-14 09:14:34 --> Final output sent to browser
DEBUG - 2023-12-14 09:14:34 --> Total execution time: 1.2642
INFO - 2023-12-14 09:14:34 --> Config Class Initialized
INFO - 2023-12-14 09:14:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:14:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:14:34 --> Utf8 Class Initialized
INFO - 2023-12-14 09:14:34 --> URI Class Initialized
INFO - 2023-12-14 09:14:34 --> Config Class Initialized
INFO - 2023-12-14 09:14:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:14:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:14:34 --> Utf8 Class Initialized
INFO - 2023-12-14 09:14:34 --> URI Class Initialized
INFO - 2023-12-14 09:14:34 --> Router Class Initialized
INFO - 2023-12-14 09:14:34 --> Output Class Initialized
INFO - 2023-12-14 09:14:34 --> Security Class Initialized
DEBUG - 2023-12-14 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:14:34 --> Input Class Initialized
INFO - 2023-12-14 09:14:34 --> Language Class Initialized
INFO - 2023-12-14 09:14:34 --> Router Class Initialized
INFO - 2023-12-14 09:14:34 --> Output Class Initialized
INFO - 2023-12-14 09:14:34 --> Security Class Initialized
DEBUG - 2023-12-14 09:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:14:34 --> Input Class Initialized
INFO - 2023-12-14 09:14:34 --> Language Class Initialized
INFO - 2023-12-14 09:14:34 --> Language Class Initialized
INFO - 2023-12-14 09:14:34 --> Config Class Initialized
INFO - 2023-12-14 09:14:34 --> Loader Class Initialized
INFO - 2023-12-14 09:14:34 --> Helper loaded: url_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: file_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: form_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: my_helper
INFO - 2023-12-14 09:14:34 --> Language Class Initialized
INFO - 2023-12-14 09:14:34 --> Config Class Initialized
INFO - 2023-12-14 09:14:34 --> Loader Class Initialized
INFO - 2023-12-14 09:14:34 --> Helper loaded: url_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: file_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: form_helper
INFO - 2023-12-14 09:14:34 --> Helper loaded: my_helper
INFO - 2023-12-14 09:14:34 --> Database Driver Class Initialized
INFO - 2023-12-14 09:14:34 --> Database Driver Class Initialized
INFO - 2023-12-14 09:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:14:34 --> Controller Class Initialized
INFO - 2023-12-14 09:14:35 --> Final output sent to browser
DEBUG - 2023-12-14 09:14:35 --> Total execution time: 0.7269
INFO - 2023-12-14 09:14:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:14:35 --> Controller Class Initialized
DEBUG - 2023-12-14 09:14:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 09:14:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:14:36 --> Final output sent to browser
DEBUG - 2023-12-14 09:14:36 --> Total execution time: 1.4592
INFO - 2023-12-14 09:14:39 --> Config Class Initialized
INFO - 2023-12-14 09:14:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:14:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:14:39 --> Utf8 Class Initialized
INFO - 2023-12-14 09:14:39 --> URI Class Initialized
INFO - 2023-12-14 09:14:39 --> Router Class Initialized
INFO - 2023-12-14 09:14:39 --> Output Class Initialized
INFO - 2023-12-14 09:14:39 --> Security Class Initialized
DEBUG - 2023-12-14 09:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:14:39 --> Input Class Initialized
INFO - 2023-12-14 09:14:39 --> Language Class Initialized
INFO - 2023-12-14 09:14:39 --> Language Class Initialized
INFO - 2023-12-14 09:14:39 --> Config Class Initialized
INFO - 2023-12-14 09:14:39 --> Loader Class Initialized
INFO - 2023-12-14 09:14:39 --> Helper loaded: url_helper
INFO - 2023-12-14 09:14:39 --> Helper loaded: file_helper
INFO - 2023-12-14 09:14:39 --> Helper loaded: form_helper
INFO - 2023-12-14 09:14:39 --> Helper loaded: my_helper
INFO - 2023-12-14 09:14:39 --> Database Driver Class Initialized
INFO - 2023-12-14 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:14:39 --> Controller Class Initialized
INFO - 2023-12-14 09:14:40 --> Final output sent to browser
DEBUG - 2023-12-14 09:14:40 --> Total execution time: 0.8720
INFO - 2023-12-14 09:14:46 --> Config Class Initialized
INFO - 2023-12-14 09:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:14:46 --> Utf8 Class Initialized
INFO - 2023-12-14 09:14:46 --> URI Class Initialized
INFO - 2023-12-14 09:14:47 --> Router Class Initialized
INFO - 2023-12-14 09:14:47 --> Output Class Initialized
INFO - 2023-12-14 09:14:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:14:47 --> Input Class Initialized
INFO - 2023-12-14 09:14:47 --> Language Class Initialized
INFO - 2023-12-14 09:14:47 --> Language Class Initialized
INFO - 2023-12-14 09:14:47 --> Config Class Initialized
INFO - 2023-12-14 09:14:47 --> Loader Class Initialized
INFO - 2023-12-14 09:14:47 --> Helper loaded: url_helper
INFO - 2023-12-14 09:14:47 --> Helper loaded: file_helper
INFO - 2023-12-14 09:14:47 --> Helper loaded: form_helper
INFO - 2023-12-14 09:14:47 --> Helper loaded: my_helper
INFO - 2023-12-14 09:14:47 --> Database Driver Class Initialized
INFO - 2023-12-14 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:14:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:14:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:14:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:14:47 --> Final output sent to browser
DEBUG - 2023-12-14 09:14:47 --> Total execution time: 0.6286
INFO - 2023-12-14 09:19:00 --> Config Class Initialized
INFO - 2023-12-14 09:19:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:19:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:19:00 --> Utf8 Class Initialized
INFO - 2023-12-14 09:19:00 --> URI Class Initialized
INFO - 2023-12-14 09:19:00 --> Router Class Initialized
INFO - 2023-12-14 09:19:00 --> Output Class Initialized
INFO - 2023-12-14 09:19:00 --> Security Class Initialized
DEBUG - 2023-12-14 09:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:19:00 --> Input Class Initialized
INFO - 2023-12-14 09:19:00 --> Language Class Initialized
INFO - 2023-12-14 09:19:00 --> Language Class Initialized
INFO - 2023-12-14 09:19:00 --> Config Class Initialized
INFO - 2023-12-14 09:19:00 --> Loader Class Initialized
INFO - 2023-12-14 09:19:00 --> Helper loaded: url_helper
INFO - 2023-12-14 09:19:00 --> Helper loaded: file_helper
INFO - 2023-12-14 09:19:00 --> Helper loaded: form_helper
INFO - 2023-12-14 09:19:00 --> Helper loaded: my_helper
INFO - 2023-12-14 09:19:00 --> Database Driver Class Initialized
INFO - 2023-12-14 09:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:19:00 --> Controller Class Initialized
DEBUG - 2023-12-14 09:19:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 09:19:16 --> Final output sent to browser
DEBUG - 2023-12-14 09:19:16 --> Total execution time: 16.5514
INFO - 2023-12-14 09:21:27 --> Config Class Initialized
INFO - 2023-12-14 09:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:27 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:27 --> URI Class Initialized
DEBUG - 2023-12-14 09:21:27 --> No URI present. Default controller set.
INFO - 2023-12-14 09:21:27 --> Router Class Initialized
INFO - 2023-12-14 09:21:27 --> Output Class Initialized
INFO - 2023-12-14 09:21:27 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:27 --> Input Class Initialized
INFO - 2023-12-14 09:21:27 --> Language Class Initialized
INFO - 2023-12-14 09:21:27 --> Language Class Initialized
INFO - 2023-12-14 09:21:27 --> Config Class Initialized
INFO - 2023-12-14 09:21:27 --> Loader Class Initialized
INFO - 2023-12-14 09:21:27 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:27 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:27 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:27 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:27 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:27 --> Controller Class Initialized
DEBUG - 2023-12-14 09:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 09:21:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:21:28 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:28 --> Total execution time: 1.0057
INFO - 2023-12-14 09:21:32 --> Config Class Initialized
INFO - 2023-12-14 09:21:32 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:32 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:32 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:32 --> URI Class Initialized
INFO - 2023-12-14 09:21:32 --> Router Class Initialized
INFO - 2023-12-14 09:21:32 --> Output Class Initialized
INFO - 2023-12-14 09:21:32 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:32 --> Input Class Initialized
INFO - 2023-12-14 09:21:32 --> Language Class Initialized
INFO - 2023-12-14 09:21:32 --> Language Class Initialized
INFO - 2023-12-14 09:21:32 --> Config Class Initialized
INFO - 2023-12-14 09:21:32 --> Loader Class Initialized
INFO - 2023-12-14 09:21:32 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:32 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:32 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:32 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:32 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:32 --> Controller Class Initialized
DEBUG - 2023-12-14 09:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 09:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:21:33 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:33 --> Total execution time: 0.4629
INFO - 2023-12-14 09:21:34 --> Config Class Initialized
INFO - 2023-12-14 09:21:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:34 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:34 --> URI Class Initialized
INFO - 2023-12-14 09:21:34 --> Router Class Initialized
INFO - 2023-12-14 09:21:34 --> Output Class Initialized
INFO - 2023-12-14 09:21:34 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:34 --> Input Class Initialized
INFO - 2023-12-14 09:21:34 --> Language Class Initialized
INFO - 2023-12-14 09:21:34 --> Language Class Initialized
INFO - 2023-12-14 09:21:34 --> Config Class Initialized
INFO - 2023-12-14 09:21:34 --> Loader Class Initialized
INFO - 2023-12-14 09:21:34 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:34 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:34 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:34 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:34 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:34 --> Controller Class Initialized
DEBUG - 2023-12-14 09:21:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-14 09:21:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:21:35 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:35 --> Total execution time: 0.1846
INFO - 2023-12-14 09:21:35 --> Config Class Initialized
INFO - 2023-12-14 09:21:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:35 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:35 --> URI Class Initialized
INFO - 2023-12-14 09:21:35 --> Router Class Initialized
INFO - 2023-12-14 09:21:35 --> Output Class Initialized
INFO - 2023-12-14 09:21:35 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:35 --> Input Class Initialized
INFO - 2023-12-14 09:21:35 --> Language Class Initialized
INFO - 2023-12-14 09:21:35 --> Language Class Initialized
INFO - 2023-12-14 09:21:35 --> Config Class Initialized
INFO - 2023-12-14 09:21:35 --> Loader Class Initialized
INFO - 2023-12-14 09:21:35 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:35 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:35 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:35 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:35 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:35 --> Controller Class Initialized
INFO - 2023-12-14 09:21:38 --> Config Class Initialized
INFO - 2023-12-14 09:21:38 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:38 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:38 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:38 --> URI Class Initialized
INFO - 2023-12-14 09:21:38 --> Router Class Initialized
INFO - 2023-12-14 09:21:38 --> Output Class Initialized
INFO - 2023-12-14 09:21:38 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:38 --> Input Class Initialized
INFO - 2023-12-14 09:21:38 --> Language Class Initialized
INFO - 2023-12-14 09:21:39 --> Language Class Initialized
INFO - 2023-12-14 09:21:39 --> Config Class Initialized
INFO - 2023-12-14 09:21:39 --> Loader Class Initialized
INFO - 2023-12-14 09:21:39 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:39 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:39 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:39 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:39 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:39 --> Controller Class Initialized
INFO - 2023-12-14 09:21:39 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:39 --> Total execution time: 0.6065
INFO - 2023-12-14 09:21:41 --> Config Class Initialized
INFO - 2023-12-14 09:21:41 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:41 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:41 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:41 --> URI Class Initialized
INFO - 2023-12-14 09:21:41 --> Router Class Initialized
INFO - 2023-12-14 09:21:41 --> Output Class Initialized
INFO - 2023-12-14 09:21:41 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:41 --> Input Class Initialized
INFO - 2023-12-14 09:21:41 --> Language Class Initialized
INFO - 2023-12-14 09:21:41 --> Language Class Initialized
INFO - 2023-12-14 09:21:41 --> Config Class Initialized
INFO - 2023-12-14 09:21:41 --> Loader Class Initialized
INFO - 2023-12-14 09:21:41 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:41 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:41 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:41 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:41 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:41 --> Controller Class Initialized
INFO - 2023-12-14 09:21:41 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:41 --> Total execution time: 0.4153
INFO - 2023-12-14 09:21:48 --> Config Class Initialized
INFO - 2023-12-14 09:21:48 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:21:48 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:21:48 --> Utf8 Class Initialized
INFO - 2023-12-14 09:21:48 --> URI Class Initialized
INFO - 2023-12-14 09:21:48 --> Router Class Initialized
INFO - 2023-12-14 09:21:48 --> Output Class Initialized
INFO - 2023-12-14 09:21:49 --> Security Class Initialized
DEBUG - 2023-12-14 09:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:21:49 --> Input Class Initialized
INFO - 2023-12-14 09:21:49 --> Language Class Initialized
INFO - 2023-12-14 09:21:49 --> Language Class Initialized
INFO - 2023-12-14 09:21:49 --> Config Class Initialized
INFO - 2023-12-14 09:21:49 --> Loader Class Initialized
INFO - 2023-12-14 09:21:49 --> Helper loaded: url_helper
INFO - 2023-12-14 09:21:49 --> Helper loaded: file_helper
INFO - 2023-12-14 09:21:50 --> Helper loaded: form_helper
INFO - 2023-12-14 09:21:50 --> Helper loaded: my_helper
INFO - 2023-12-14 09:21:50 --> Database Driver Class Initialized
INFO - 2023-12-14 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:21:50 --> Controller Class Initialized
INFO - 2023-12-14 09:21:50 --> Final output sent to browser
DEBUG - 2023-12-14 09:21:50 --> Total execution time: 2.5775
INFO - 2023-12-14 09:22:02 --> Config Class Initialized
INFO - 2023-12-14 09:22:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:22:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:22:02 --> Utf8 Class Initialized
INFO - 2023-12-14 09:22:02 --> URI Class Initialized
INFO - 2023-12-14 09:22:02 --> Router Class Initialized
INFO - 2023-12-14 09:22:02 --> Output Class Initialized
INFO - 2023-12-14 09:22:02 --> Security Class Initialized
DEBUG - 2023-12-14 09:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:22:03 --> Input Class Initialized
INFO - 2023-12-14 09:22:03 --> Language Class Initialized
INFO - 2023-12-14 09:22:03 --> Language Class Initialized
INFO - 2023-12-14 09:22:03 --> Config Class Initialized
INFO - 2023-12-14 09:22:03 --> Loader Class Initialized
INFO - 2023-12-14 09:22:03 --> Helper loaded: url_helper
INFO - 2023-12-14 09:22:03 --> Helper loaded: file_helper
INFO - 2023-12-14 09:22:03 --> Helper loaded: form_helper
INFO - 2023-12-14 09:22:03 --> Helper loaded: my_helper
INFO - 2023-12-14 09:22:03 --> Database Driver Class Initialized
INFO - 2023-12-14 09:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:22:03 --> Controller Class Initialized
DEBUG - 2023-12-14 09:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-14 09:22:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:22:03 --> Final output sent to browser
DEBUG - 2023-12-14 09:22:03 --> Total execution time: 0.7692
INFO - 2023-12-14 09:22:04 --> Config Class Initialized
INFO - 2023-12-14 09:22:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:22:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:22:04 --> Utf8 Class Initialized
INFO - 2023-12-14 09:22:04 --> URI Class Initialized
INFO - 2023-12-14 09:22:04 --> Router Class Initialized
INFO - 2023-12-14 09:22:04 --> Output Class Initialized
INFO - 2023-12-14 09:22:04 --> Security Class Initialized
DEBUG - 2023-12-14 09:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:22:04 --> Input Class Initialized
INFO - 2023-12-14 09:22:04 --> Language Class Initialized
INFO - 2023-12-14 09:22:04 --> Language Class Initialized
INFO - 2023-12-14 09:22:04 --> Config Class Initialized
INFO - 2023-12-14 09:22:04 --> Loader Class Initialized
INFO - 2023-12-14 09:22:04 --> Helper loaded: url_helper
INFO - 2023-12-14 09:22:04 --> Helper loaded: file_helper
INFO - 2023-12-14 09:22:04 --> Helper loaded: form_helper
INFO - 2023-12-14 09:22:04 --> Helper loaded: my_helper
INFO - 2023-12-14 09:22:04 --> Database Driver Class Initialized
INFO - 2023-12-14 09:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:22:04 --> Controller Class Initialized
INFO - 2023-12-14 09:22:22 --> Config Class Initialized
INFO - 2023-12-14 09:22:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:22:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:22:22 --> Utf8 Class Initialized
INFO - 2023-12-14 09:22:22 --> URI Class Initialized
INFO - 2023-12-14 09:22:22 --> Router Class Initialized
INFO - 2023-12-14 09:22:22 --> Output Class Initialized
INFO - 2023-12-14 09:22:22 --> Security Class Initialized
DEBUG - 2023-12-14 09:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:22:22 --> Input Class Initialized
INFO - 2023-12-14 09:22:22 --> Language Class Initialized
INFO - 2023-12-14 09:22:22 --> Language Class Initialized
INFO - 2023-12-14 09:22:22 --> Config Class Initialized
INFO - 2023-12-14 09:22:22 --> Loader Class Initialized
INFO - 2023-12-14 09:22:22 --> Helper loaded: url_helper
INFO - 2023-12-14 09:22:22 --> Helper loaded: file_helper
INFO - 2023-12-14 09:22:22 --> Helper loaded: form_helper
INFO - 2023-12-14 09:22:22 --> Helper loaded: my_helper
INFO - 2023-12-14 09:22:22 --> Database Driver Class Initialized
INFO - 2023-12-14 09:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:22:22 --> Controller Class Initialized
DEBUG - 2023-12-14 09:22:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 09:22:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:22:22 --> Final output sent to browser
DEBUG - 2023-12-14 09:22:22 --> Total execution time: 0.2407
INFO - 2023-12-14 09:22:32 --> Config Class Initialized
INFO - 2023-12-14 09:22:32 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:22:32 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:22:32 --> Utf8 Class Initialized
INFO - 2023-12-14 09:22:32 --> URI Class Initialized
INFO - 2023-12-14 09:22:32 --> Router Class Initialized
INFO - 2023-12-14 09:22:32 --> Output Class Initialized
INFO - 2023-12-14 09:22:32 --> Security Class Initialized
DEBUG - 2023-12-14 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:22:32 --> Input Class Initialized
INFO - 2023-12-14 09:22:32 --> Language Class Initialized
INFO - 2023-12-14 09:22:32 --> Language Class Initialized
INFO - 2023-12-14 09:22:32 --> Config Class Initialized
INFO - 2023-12-14 09:22:32 --> Loader Class Initialized
INFO - 2023-12-14 09:22:32 --> Helper loaded: url_helper
INFO - 2023-12-14 09:22:32 --> Helper loaded: file_helper
INFO - 2023-12-14 09:22:32 --> Helper loaded: form_helper
INFO - 2023-12-14 09:22:32 --> Helper loaded: my_helper
INFO - 2023-12-14 09:22:32 --> Database Driver Class Initialized
INFO - 2023-12-14 09:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:22:32 --> Controller Class Initialized
DEBUG - 2023-12-14 09:22:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 09:22:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:22:32 --> Final output sent to browser
DEBUG - 2023-12-14 09:22:32 --> Total execution time: 0.3963
INFO - 2023-12-14 09:22:35 --> Config Class Initialized
INFO - 2023-12-14 09:22:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:22:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:22:35 --> Utf8 Class Initialized
INFO - 2023-12-14 09:22:35 --> URI Class Initialized
INFO - 2023-12-14 09:22:35 --> Router Class Initialized
INFO - 2023-12-14 09:22:35 --> Output Class Initialized
INFO - 2023-12-14 09:22:35 --> Security Class Initialized
DEBUG - 2023-12-14 09:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:22:35 --> Input Class Initialized
INFO - 2023-12-14 09:22:36 --> Language Class Initialized
INFO - 2023-12-14 09:22:36 --> Language Class Initialized
INFO - 2023-12-14 09:22:36 --> Config Class Initialized
INFO - 2023-12-14 09:22:36 --> Loader Class Initialized
INFO - 2023-12-14 09:22:36 --> Helper loaded: url_helper
INFO - 2023-12-14 09:22:36 --> Helper loaded: file_helper
INFO - 2023-12-14 09:22:36 --> Helper loaded: form_helper
INFO - 2023-12-14 09:22:36 --> Helper loaded: my_helper
INFO - 2023-12-14 09:22:36 --> Database Driver Class Initialized
INFO - 2023-12-14 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:22:36 --> Controller Class Initialized
INFO - 2023-12-14 09:22:36 --> Final output sent to browser
DEBUG - 2023-12-14 09:22:36 --> Total execution time: 0.2738
INFO - 2023-12-14 09:23:52 --> Config Class Initialized
INFO - 2023-12-14 09:23:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:23:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:23:52 --> Utf8 Class Initialized
INFO - 2023-12-14 09:23:52 --> URI Class Initialized
INFO - 2023-12-14 09:23:52 --> Router Class Initialized
INFO - 2023-12-14 09:23:52 --> Output Class Initialized
INFO - 2023-12-14 09:23:52 --> Security Class Initialized
DEBUG - 2023-12-14 09:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:23:52 --> Input Class Initialized
INFO - 2023-12-14 09:23:52 --> Language Class Initialized
INFO - 2023-12-14 09:23:52 --> Language Class Initialized
INFO - 2023-12-14 09:23:52 --> Config Class Initialized
INFO - 2023-12-14 09:23:52 --> Loader Class Initialized
INFO - 2023-12-14 09:23:53 --> Helper loaded: url_helper
INFO - 2023-12-14 09:23:53 --> Helper loaded: file_helper
INFO - 2023-12-14 09:23:53 --> Helper loaded: form_helper
INFO - 2023-12-14 09:23:53 --> Helper loaded: my_helper
INFO - 2023-12-14 09:23:53 --> Database Driver Class Initialized
INFO - 2023-12-14 09:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:23:53 --> Controller Class Initialized
INFO - 2023-12-14 09:23:54 --> Final output sent to browser
DEBUG - 2023-12-14 09:23:54 --> Total execution time: 1.8631
INFO - 2023-12-14 09:24:26 --> Config Class Initialized
INFO - 2023-12-14 09:24:26 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:24:26 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:24:26 --> Utf8 Class Initialized
INFO - 2023-12-14 09:24:26 --> URI Class Initialized
INFO - 2023-12-14 09:24:26 --> Router Class Initialized
INFO - 2023-12-14 09:24:26 --> Output Class Initialized
INFO - 2023-12-14 09:24:26 --> Security Class Initialized
DEBUG - 2023-12-14 09:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:24:26 --> Input Class Initialized
INFO - 2023-12-14 09:24:26 --> Language Class Initialized
INFO - 2023-12-14 09:24:26 --> Language Class Initialized
INFO - 2023-12-14 09:24:26 --> Config Class Initialized
INFO - 2023-12-14 09:24:26 --> Loader Class Initialized
INFO - 2023-12-14 09:24:26 --> Helper loaded: url_helper
INFO - 2023-12-14 09:24:26 --> Helper loaded: file_helper
INFO - 2023-12-14 09:24:26 --> Helper loaded: form_helper
INFO - 2023-12-14 09:24:26 --> Helper loaded: my_helper
INFO - 2023-12-14 09:24:26 --> Database Driver Class Initialized
INFO - 2023-12-14 09:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:24:26 --> Controller Class Initialized
INFO - 2023-12-14 09:24:27 --> Final output sent to browser
DEBUG - 2023-12-14 09:24:27 --> Total execution time: 0.5555
INFO - 2023-12-14 09:24:38 --> Config Class Initialized
INFO - 2023-12-14 09:24:38 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:24:38 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:24:38 --> Utf8 Class Initialized
INFO - 2023-12-14 09:24:38 --> URI Class Initialized
INFO - 2023-12-14 09:24:38 --> Router Class Initialized
INFO - 2023-12-14 09:24:38 --> Output Class Initialized
INFO - 2023-12-14 09:24:38 --> Security Class Initialized
DEBUG - 2023-12-14 09:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:24:38 --> Input Class Initialized
INFO - 2023-12-14 09:24:38 --> Language Class Initialized
INFO - 2023-12-14 09:24:38 --> Language Class Initialized
INFO - 2023-12-14 09:24:38 --> Config Class Initialized
INFO - 2023-12-14 09:24:38 --> Loader Class Initialized
INFO - 2023-12-14 09:24:38 --> Helper loaded: url_helper
INFO - 2023-12-14 09:24:38 --> Helper loaded: file_helper
INFO - 2023-12-14 09:24:38 --> Helper loaded: form_helper
INFO - 2023-12-14 09:24:38 --> Helper loaded: my_helper
INFO - 2023-12-14 09:24:38 --> Database Driver Class Initialized
INFO - 2023-12-14 09:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:24:38 --> Controller Class Initialized
DEBUG - 2023-12-14 09:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 09:24:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:24:38 --> Final output sent to browser
DEBUG - 2023-12-14 09:24:38 --> Total execution time: 0.1416
INFO - 2023-12-14 09:24:42 --> Config Class Initialized
INFO - 2023-12-14 09:24:42 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:24:42 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:24:42 --> Utf8 Class Initialized
INFO - 2023-12-14 09:24:42 --> URI Class Initialized
INFO - 2023-12-14 09:24:42 --> Router Class Initialized
INFO - 2023-12-14 09:24:42 --> Output Class Initialized
INFO - 2023-12-14 09:24:42 --> Security Class Initialized
DEBUG - 2023-12-14 09:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:24:42 --> Input Class Initialized
INFO - 2023-12-14 09:24:42 --> Language Class Initialized
INFO - 2023-12-14 09:24:42 --> Language Class Initialized
INFO - 2023-12-14 09:24:42 --> Config Class Initialized
INFO - 2023-12-14 09:24:42 --> Loader Class Initialized
INFO - 2023-12-14 09:24:42 --> Helper loaded: url_helper
INFO - 2023-12-14 09:24:42 --> Helper loaded: file_helper
INFO - 2023-12-14 09:24:42 --> Helper loaded: form_helper
INFO - 2023-12-14 09:24:42 --> Helper loaded: my_helper
INFO - 2023-12-14 09:24:42 --> Database Driver Class Initialized
INFO - 2023-12-14 09:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:24:42 --> Controller Class Initialized
DEBUG - 2023-12-14 09:24:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:24:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:24:42 --> Final output sent to browser
DEBUG - 2023-12-14 09:24:42 --> Total execution time: 0.1989
INFO - 2023-12-14 09:24:44 --> Config Class Initialized
INFO - 2023-12-14 09:24:44 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:24:44 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:24:44 --> Utf8 Class Initialized
INFO - 2023-12-14 09:24:44 --> URI Class Initialized
INFO - 2023-12-14 09:24:44 --> Router Class Initialized
INFO - 2023-12-14 09:24:44 --> Output Class Initialized
INFO - 2023-12-14 09:24:44 --> Security Class Initialized
DEBUG - 2023-12-14 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:24:44 --> Input Class Initialized
INFO - 2023-12-14 09:24:44 --> Language Class Initialized
INFO - 2023-12-14 09:24:44 --> Language Class Initialized
INFO - 2023-12-14 09:24:44 --> Config Class Initialized
INFO - 2023-12-14 09:24:44 --> Loader Class Initialized
INFO - 2023-12-14 09:24:44 --> Helper loaded: url_helper
INFO - 2023-12-14 09:24:44 --> Helper loaded: file_helper
INFO - 2023-12-14 09:24:44 --> Helper loaded: form_helper
INFO - 2023-12-14 09:24:44 --> Helper loaded: my_helper
INFO - 2023-12-14 09:24:44 --> Database Driver Class Initialized
INFO - 2023-12-14 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:24:44 --> Controller Class Initialized
DEBUG - 2023-12-14 09:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 09:24:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:24:44 --> Final output sent to browser
DEBUG - 2023-12-14 09:24:44 --> Total execution time: 0.1301
INFO - 2023-12-14 09:24:47 --> Config Class Initialized
INFO - 2023-12-14 09:24:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:24:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:24:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:24:47 --> URI Class Initialized
INFO - 2023-12-14 09:24:47 --> Router Class Initialized
INFO - 2023-12-14 09:24:47 --> Output Class Initialized
INFO - 2023-12-14 09:24:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:24:47 --> Input Class Initialized
INFO - 2023-12-14 09:24:47 --> Language Class Initialized
INFO - 2023-12-14 09:24:47 --> Language Class Initialized
INFO - 2023-12-14 09:24:47 --> Config Class Initialized
INFO - 2023-12-14 09:24:47 --> Loader Class Initialized
INFO - 2023-12-14 09:24:47 --> Helper loaded: url_helper
INFO - 2023-12-14 09:24:47 --> Helper loaded: file_helper
INFO - 2023-12-14 09:24:47 --> Helper loaded: form_helper
INFO - 2023-12-14 09:24:47 --> Helper loaded: my_helper
INFO - 2023-12-14 09:24:47 --> Database Driver Class Initialized
INFO - 2023-12-14 09:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:24:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:24:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 09:25:19 --> Config Class Initialized
INFO - 2023-12-14 09:25:19 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:25:19 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:25:19 --> Utf8 Class Initialized
INFO - 2023-12-14 09:25:19 --> URI Class Initialized
INFO - 2023-12-14 09:25:19 --> Router Class Initialized
INFO - 2023-12-14 09:25:19 --> Output Class Initialized
INFO - 2023-12-14 09:25:19 --> Security Class Initialized
DEBUG - 2023-12-14 09:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:25:19 --> Input Class Initialized
INFO - 2023-12-14 09:25:19 --> Language Class Initialized
INFO - 2023-12-14 09:25:19 --> Language Class Initialized
INFO - 2023-12-14 09:25:19 --> Config Class Initialized
INFO - 2023-12-14 09:25:19 --> Loader Class Initialized
INFO - 2023-12-14 09:25:19 --> Helper loaded: url_helper
INFO - 2023-12-14 09:25:19 --> Helper loaded: file_helper
INFO - 2023-12-14 09:25:19 --> Helper loaded: form_helper
INFO - 2023-12-14 09:25:19 --> Helper loaded: my_helper
INFO - 2023-12-14 09:25:19 --> Database Driver Class Initialized
INFO - 2023-12-14 09:25:22 --> Final output sent to browser
DEBUG - 2023-12-14 09:25:22 --> Total execution time: 35.0600
INFO - 2023-12-14 09:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:25:22 --> Controller Class Initialized
DEBUG - 2023-12-14 09:25:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:26:01 --> Final output sent to browser
DEBUG - 2023-12-14 09:26:01 --> Total execution time: 42.4977
INFO - 2023-12-14 09:26:47 --> Config Class Initialized
INFO - 2023-12-14 09:26:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:26:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:26:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:26:47 --> URI Class Initialized
INFO - 2023-12-14 09:26:47 --> Router Class Initialized
INFO - 2023-12-14 09:26:47 --> Output Class Initialized
INFO - 2023-12-14 09:26:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:26:47 --> Input Class Initialized
INFO - 2023-12-14 09:26:47 --> Language Class Initialized
INFO - 2023-12-14 09:26:47 --> Language Class Initialized
INFO - 2023-12-14 09:26:47 --> Config Class Initialized
INFO - 2023-12-14 09:26:47 --> Loader Class Initialized
INFO - 2023-12-14 09:26:47 --> Helper loaded: url_helper
INFO - 2023-12-14 09:26:47 --> Helper loaded: file_helper
INFO - 2023-12-14 09:26:47 --> Helper loaded: form_helper
INFO - 2023-12-14 09:26:47 --> Helper loaded: my_helper
INFO - 2023-12-14 09:26:47 --> Database Driver Class Initialized
INFO - 2023-12-14 09:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:26:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:26:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:26:47 --> Final output sent to browser
DEBUG - 2023-12-14 09:26:47 --> Total execution time: 0.1450
INFO - 2023-12-14 09:26:50 --> Config Class Initialized
INFO - 2023-12-14 09:26:50 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:26:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:26:51 --> Utf8 Class Initialized
INFO - 2023-12-14 09:26:51 --> URI Class Initialized
INFO - 2023-12-14 09:26:51 --> Router Class Initialized
INFO - 2023-12-14 09:26:51 --> Output Class Initialized
INFO - 2023-12-14 09:26:51 --> Security Class Initialized
DEBUG - 2023-12-14 09:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:26:51 --> Input Class Initialized
INFO - 2023-12-14 09:26:51 --> Language Class Initialized
INFO - 2023-12-14 09:26:51 --> Language Class Initialized
INFO - 2023-12-14 09:26:51 --> Config Class Initialized
INFO - 2023-12-14 09:26:51 --> Loader Class Initialized
INFO - 2023-12-14 09:26:51 --> Helper loaded: url_helper
INFO - 2023-12-14 09:26:51 --> Helper loaded: file_helper
INFO - 2023-12-14 09:26:51 --> Helper loaded: form_helper
INFO - 2023-12-14 09:26:51 --> Helper loaded: my_helper
INFO - 2023-12-14 09:26:51 --> Database Driver Class Initialized
INFO - 2023-12-14 09:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:26:51 --> Controller Class Initialized
INFO - 2023-12-14 09:26:51 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:26:52 --> Config Class Initialized
INFO - 2023-12-14 09:26:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:26:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:26:52 --> Utf8 Class Initialized
INFO - 2023-12-14 09:26:52 --> URI Class Initialized
INFO - 2023-12-14 09:26:52 --> Router Class Initialized
INFO - 2023-12-14 09:26:52 --> Output Class Initialized
INFO - 2023-12-14 09:26:52 --> Security Class Initialized
DEBUG - 2023-12-14 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:26:52 --> Input Class Initialized
INFO - 2023-12-14 09:26:52 --> Language Class Initialized
INFO - 2023-12-14 09:26:52 --> Language Class Initialized
INFO - 2023-12-14 09:26:52 --> Config Class Initialized
INFO - 2023-12-14 09:26:52 --> Loader Class Initialized
INFO - 2023-12-14 09:26:52 --> Helper loaded: url_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: file_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: form_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: my_helper
INFO - 2023-12-14 09:26:52 --> Database Driver Class Initialized
INFO - 2023-12-14 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:26:52 --> Controller Class Initialized
INFO - 2023-12-14 09:26:52 --> Config Class Initialized
INFO - 2023-12-14 09:26:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:26:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:26:52 --> Utf8 Class Initialized
INFO - 2023-12-14 09:26:52 --> URI Class Initialized
INFO - 2023-12-14 09:26:52 --> Router Class Initialized
INFO - 2023-12-14 09:26:52 --> Output Class Initialized
INFO - 2023-12-14 09:26:52 --> Security Class Initialized
DEBUG - 2023-12-14 09:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:26:52 --> Input Class Initialized
INFO - 2023-12-14 09:26:52 --> Language Class Initialized
INFO - 2023-12-14 09:26:52 --> Language Class Initialized
INFO - 2023-12-14 09:26:52 --> Config Class Initialized
INFO - 2023-12-14 09:26:52 --> Loader Class Initialized
INFO - 2023-12-14 09:26:52 --> Helper loaded: url_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: file_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: form_helper
INFO - 2023-12-14 09:26:52 --> Helper loaded: my_helper
INFO - 2023-12-14 09:26:52 --> Database Driver Class Initialized
INFO - 2023-12-14 09:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:26:52 --> Controller Class Initialized
DEBUG - 2023-12-14 09:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 09:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:26:52 --> Final output sent to browser
DEBUG - 2023-12-14 09:26:52 --> Total execution time: 0.2877
INFO - 2023-12-14 09:27:02 --> Config Class Initialized
INFO - 2023-12-14 09:27:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:02 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:02 --> URI Class Initialized
INFO - 2023-12-14 09:27:02 --> Router Class Initialized
INFO - 2023-12-14 09:27:02 --> Output Class Initialized
INFO - 2023-12-14 09:27:02 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:02 --> Input Class Initialized
INFO - 2023-12-14 09:27:02 --> Language Class Initialized
INFO - 2023-12-14 09:27:02 --> Language Class Initialized
INFO - 2023-12-14 09:27:02 --> Config Class Initialized
INFO - 2023-12-14 09:27:02 --> Loader Class Initialized
INFO - 2023-12-14 09:27:02 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:02 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:02 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:02 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:03 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:27:03 --> Controller Class Initialized
INFO - 2023-12-14 09:27:03 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:27:03 --> Final output sent to browser
DEBUG - 2023-12-14 09:27:03 --> Total execution time: 0.6006
INFO - 2023-12-14 09:27:03 --> Config Class Initialized
INFO - 2023-12-14 09:27:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:03 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:03 --> URI Class Initialized
INFO - 2023-12-14 09:27:03 --> Router Class Initialized
INFO - 2023-12-14 09:27:03 --> Output Class Initialized
INFO - 2023-12-14 09:27:03 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:03 --> Input Class Initialized
INFO - 2023-12-14 09:27:03 --> Language Class Initialized
INFO - 2023-12-14 09:27:03 --> Language Class Initialized
INFO - 2023-12-14 09:27:03 --> Config Class Initialized
INFO - 2023-12-14 09:27:03 --> Loader Class Initialized
INFO - 2023-12-14 09:27:03 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:03 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:03 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:03 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:03 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:27:03 --> Controller Class Initialized
DEBUG - 2023-12-14 09:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 09:27:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:27:03 --> Final output sent to browser
DEBUG - 2023-12-14 09:27:03 --> Total execution time: 0.1893
INFO - 2023-12-14 09:27:09 --> Config Class Initialized
INFO - 2023-12-14 09:27:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:09 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:09 --> URI Class Initialized
INFO - 2023-12-14 09:27:09 --> Router Class Initialized
INFO - 2023-12-14 09:27:10 --> Output Class Initialized
INFO - 2023-12-14 09:27:10 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:10 --> Input Class Initialized
INFO - 2023-12-14 09:27:10 --> Language Class Initialized
INFO - 2023-12-14 09:27:11 --> Language Class Initialized
INFO - 2023-12-14 09:27:11 --> Config Class Initialized
INFO - 2023-12-14 09:27:11 --> Loader Class Initialized
INFO - 2023-12-14 09:27:11 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:11 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:11 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:11 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:11 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:27:11 --> Controller Class Initialized
DEBUG - 2023-12-14 09:27:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:27:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:27:11 --> Final output sent to browser
DEBUG - 2023-12-14 09:27:11 --> Total execution time: 1.6441
INFO - 2023-12-14 09:27:15 --> Config Class Initialized
INFO - 2023-12-14 09:27:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:15 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:15 --> URI Class Initialized
INFO - 2023-12-14 09:27:15 --> Router Class Initialized
INFO - 2023-12-14 09:27:15 --> Output Class Initialized
INFO - 2023-12-14 09:27:15 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:15 --> Input Class Initialized
INFO - 2023-12-14 09:27:15 --> Language Class Initialized
INFO - 2023-12-14 09:27:15 --> Language Class Initialized
INFO - 2023-12-14 09:27:15 --> Config Class Initialized
INFO - 2023-12-14 09:27:15 --> Loader Class Initialized
INFO - 2023-12-14 09:27:15 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:15 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:15 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:15 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:16 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:27:16 --> Controller Class Initialized
DEBUG - 2023-12-14 09:27:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:27:22 --> Config Class Initialized
INFO - 2023-12-14 09:27:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:22 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:22 --> URI Class Initialized
INFO - 2023-12-14 09:27:22 --> Router Class Initialized
INFO - 2023-12-14 09:27:22 --> Output Class Initialized
INFO - 2023-12-14 09:27:22 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:22 --> Input Class Initialized
INFO - 2023-12-14 09:27:22 --> Language Class Initialized
INFO - 2023-12-14 09:27:23 --> Language Class Initialized
INFO - 2023-12-14 09:27:23 --> Config Class Initialized
INFO - 2023-12-14 09:27:23 --> Loader Class Initialized
INFO - 2023-12-14 09:27:23 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:23 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:23 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:23 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:23 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:29 --> Config Class Initialized
INFO - 2023-12-14 09:27:29 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:27:29 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:27:29 --> Utf8 Class Initialized
INFO - 2023-12-14 09:27:29 --> URI Class Initialized
INFO - 2023-12-14 09:27:29 --> Router Class Initialized
INFO - 2023-12-14 09:27:29 --> Output Class Initialized
INFO - 2023-12-14 09:27:29 --> Security Class Initialized
DEBUG - 2023-12-14 09:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:27:29 --> Input Class Initialized
INFO - 2023-12-14 09:27:29 --> Language Class Initialized
INFO - 2023-12-14 09:27:29 --> Language Class Initialized
INFO - 2023-12-14 09:27:29 --> Config Class Initialized
INFO - 2023-12-14 09:27:29 --> Loader Class Initialized
INFO - 2023-12-14 09:27:29 --> Helper loaded: url_helper
INFO - 2023-12-14 09:27:29 --> Helper loaded: file_helper
INFO - 2023-12-14 09:27:29 --> Helper loaded: form_helper
INFO - 2023-12-14 09:27:29 --> Helper loaded: my_helper
INFO - 2023-12-14 09:27:29 --> Database Driver Class Initialized
INFO - 2023-12-14 09:27:58 --> Final output sent to browser
DEBUG - 2023-12-14 09:27:58 --> Total execution time: 43.4006
INFO - 2023-12-14 09:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:27:58 --> Controller Class Initialized
DEBUG - 2023-12-14 09:28:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 09:28:24 --> Final output sent to browser
DEBUG - 2023-12-14 09:28:24 --> Total execution time: 54.9779
INFO - 2023-12-14 09:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:28:24 --> Controller Class Initialized
DEBUG - 2023-12-14 09:28:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:28:44 --> Final output sent to browser
DEBUG - 2023-12-14 09:28:44 --> Total execution time: 82.2540
INFO - 2023-12-14 09:30:47 --> Config Class Initialized
INFO - 2023-12-14 09:30:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:30:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:30:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:30:47 --> URI Class Initialized
INFO - 2023-12-14 09:30:47 --> Router Class Initialized
INFO - 2023-12-14 09:30:47 --> Output Class Initialized
INFO - 2023-12-14 09:30:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:30:47 --> Input Class Initialized
INFO - 2023-12-14 09:30:47 --> Language Class Initialized
INFO - 2023-12-14 09:30:48 --> Language Class Initialized
INFO - 2023-12-14 09:30:48 --> Config Class Initialized
INFO - 2023-12-14 09:30:48 --> Loader Class Initialized
INFO - 2023-12-14 09:30:48 --> Helper loaded: url_helper
INFO - 2023-12-14 09:30:48 --> Helper loaded: file_helper
INFO - 2023-12-14 09:30:48 --> Helper loaded: form_helper
INFO - 2023-12-14 09:30:48 --> Helper loaded: my_helper
INFO - 2023-12-14 09:30:48 --> Database Driver Class Initialized
INFO - 2023-12-14 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:30:48 --> Controller Class Initialized
DEBUG - 2023-12-14 09:30:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:30:51 --> Config Class Initialized
INFO - 2023-12-14 09:30:51 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:30:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:30:51 --> Utf8 Class Initialized
INFO - 2023-12-14 09:30:51 --> URI Class Initialized
INFO - 2023-12-14 09:30:51 --> Router Class Initialized
INFO - 2023-12-14 09:30:51 --> Output Class Initialized
INFO - 2023-12-14 09:30:51 --> Security Class Initialized
DEBUG - 2023-12-14 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:30:51 --> Input Class Initialized
INFO - 2023-12-14 09:30:51 --> Language Class Initialized
INFO - 2023-12-14 09:30:51 --> Language Class Initialized
INFO - 2023-12-14 09:30:51 --> Config Class Initialized
INFO - 2023-12-14 09:30:51 --> Loader Class Initialized
INFO - 2023-12-14 09:30:51 --> Helper loaded: url_helper
INFO - 2023-12-14 09:30:51 --> Helper loaded: file_helper
INFO - 2023-12-14 09:30:51 --> Helper loaded: form_helper
INFO - 2023-12-14 09:30:51 --> Helper loaded: my_helper
INFO - 2023-12-14 09:30:51 --> Database Driver Class Initialized
INFO - 2023-12-14 09:30:55 --> Config Class Initialized
INFO - 2023-12-14 09:30:55 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:30:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:30:56 --> Utf8 Class Initialized
INFO - 2023-12-14 09:30:56 --> URI Class Initialized
INFO - 2023-12-14 09:30:56 --> Router Class Initialized
INFO - 2023-12-14 09:30:56 --> Output Class Initialized
INFO - 2023-12-14 09:30:56 --> Security Class Initialized
DEBUG - 2023-12-14 09:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:30:56 --> Input Class Initialized
INFO - 2023-12-14 09:30:56 --> Language Class Initialized
INFO - 2023-12-14 09:30:56 --> Language Class Initialized
INFO - 2023-12-14 09:30:56 --> Config Class Initialized
INFO - 2023-12-14 09:30:56 --> Loader Class Initialized
INFO - 2023-12-14 09:30:56 --> Helper loaded: url_helper
INFO - 2023-12-14 09:30:56 --> Helper loaded: file_helper
INFO - 2023-12-14 09:30:56 --> Helper loaded: form_helper
INFO - 2023-12-14 09:30:56 --> Helper loaded: my_helper
INFO - 2023-12-14 09:30:57 --> Database Driver Class Initialized
INFO - 2023-12-14 09:30:58 --> Config Class Initialized
INFO - 2023-12-14 09:30:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:30:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:30:58 --> Utf8 Class Initialized
INFO - 2023-12-14 09:30:58 --> URI Class Initialized
INFO - 2023-12-14 09:30:58 --> Router Class Initialized
INFO - 2023-12-14 09:30:58 --> Output Class Initialized
INFO - 2023-12-14 09:30:58 --> Security Class Initialized
DEBUG - 2023-12-14 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:30:58 --> Input Class Initialized
INFO - 2023-12-14 09:30:58 --> Language Class Initialized
INFO - 2023-12-14 09:30:59 --> Language Class Initialized
INFO - 2023-12-14 09:30:59 --> Config Class Initialized
INFO - 2023-12-14 09:30:59 --> Loader Class Initialized
INFO - 2023-12-14 09:30:59 --> Helper loaded: url_helper
INFO - 2023-12-14 09:30:59 --> Helper loaded: file_helper
INFO - 2023-12-14 09:30:59 --> Helper loaded: form_helper
INFO - 2023-12-14 09:30:59 --> Helper loaded: my_helper
INFO - 2023-12-14 09:30:59 --> Database Driver Class Initialized
INFO - 2023-12-14 09:31:01 --> Config Class Initialized
INFO - 2023-12-14 09:31:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:31:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:31:01 --> Utf8 Class Initialized
INFO - 2023-12-14 09:31:01 --> URI Class Initialized
INFO - 2023-12-14 09:31:01 --> Router Class Initialized
INFO - 2023-12-14 09:31:01 --> Output Class Initialized
INFO - 2023-12-14 09:31:01 --> Security Class Initialized
DEBUG - 2023-12-14 09:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:31:01 --> Input Class Initialized
INFO - 2023-12-14 09:31:01 --> Language Class Initialized
INFO - 2023-12-14 09:31:01 --> Language Class Initialized
INFO - 2023-12-14 09:31:01 --> Config Class Initialized
INFO - 2023-12-14 09:31:01 --> Loader Class Initialized
INFO - 2023-12-14 09:31:01 --> Helper loaded: url_helper
INFO - 2023-12-14 09:31:01 --> Helper loaded: file_helper
INFO - 2023-12-14 09:31:01 --> Helper loaded: form_helper
INFO - 2023-12-14 09:31:01 --> Helper loaded: my_helper
INFO - 2023-12-14 09:31:01 --> Database Driver Class Initialized
INFO - 2023-12-14 09:31:04 --> Config Class Initialized
INFO - 2023-12-14 09:31:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:31:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:31:04 --> Utf8 Class Initialized
INFO - 2023-12-14 09:31:04 --> URI Class Initialized
INFO - 2023-12-14 09:31:04 --> Router Class Initialized
INFO - 2023-12-14 09:31:04 --> Output Class Initialized
INFO - 2023-12-14 09:31:04 --> Security Class Initialized
DEBUG - 2023-12-14 09:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:31:04 --> Input Class Initialized
INFO - 2023-12-14 09:31:04 --> Language Class Initialized
INFO - 2023-12-14 09:31:04 --> Language Class Initialized
INFO - 2023-12-14 09:31:04 --> Config Class Initialized
INFO - 2023-12-14 09:31:04 --> Loader Class Initialized
INFO - 2023-12-14 09:31:04 --> Helper loaded: url_helper
INFO - 2023-12-14 09:31:04 --> Helper loaded: file_helper
INFO - 2023-12-14 09:31:05 --> Helper loaded: form_helper
INFO - 2023-12-14 09:31:05 --> Helper loaded: my_helper
INFO - 2023-12-14 09:31:05 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:15 --> Final output sent to browser
DEBUG - 2023-12-14 09:32:15 --> Total execution time: 88.5542
INFO - 2023-12-14 09:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:32:15 --> Controller Class Initialized
INFO - 2023-12-14 09:32:15 --> Controller Class Initialized
DEBUG - 2023-12-14 09:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
DEBUG - 2023-12-14 09:32:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:32:20 --> Config Class Initialized
INFO - 2023-12-14 09:32:20 --> Hooks Class Initialized
INFO - 2023-12-14 09:32:20 --> Config Class Initialized
INFO - 2023-12-14 09:32:20 --> Hooks Class Initialized
INFO - 2023-12-14 09:32:20 --> Config Class Initialized
INFO - 2023-12-14 09:32:20 --> Hooks Class Initialized
INFO - 2023-12-14 09:32:20 --> Config Class Initialized
INFO - 2023-12-14 09:32:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:32:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:20 --> Utf8 Class Initialized
DEBUG - 2023-12-14 09:32:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:20 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:20 --> URI Class Initialized
DEBUG - 2023-12-14 09:32:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:20 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:20 --> URI Class Initialized
DEBUG - 2023-12-14 09:32:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:20 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:20 --> URI Class Initialized
INFO - 2023-12-14 09:32:20 --> URI Class Initialized
INFO - 2023-12-14 09:32:20 --> Router Class Initialized
INFO - 2023-12-14 09:32:20 --> Router Class Initialized
INFO - 2023-12-14 09:32:20 --> Router Class Initialized
INFO - 2023-12-14 09:32:20 --> Output Class Initialized
INFO - 2023-12-14 09:32:20 --> Router Class Initialized
INFO - 2023-12-14 09:32:20 --> Output Class Initialized
INFO - 2023-12-14 09:32:20 --> Output Class Initialized
INFO - 2023-12-14 09:32:20 --> Output Class Initialized
INFO - 2023-12-14 09:32:20 --> Security Class Initialized
INFO - 2023-12-14 09:32:20 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:20 --> Input Class Initialized
INFO - 2023-12-14 09:32:20 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:20 --> Input Class Initialized
INFO - 2023-12-14 09:32:20 --> Language Class Initialized
INFO - 2023-12-14 09:32:20 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:20 --> Input Class Initialized
INFO - 2023-12-14 09:32:20 --> Language Class Initialized
DEBUG - 2023-12-14 09:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:20 --> Input Class Initialized
INFO - 2023-12-14 09:32:20 --> Language Class Initialized
INFO - 2023-12-14 09:32:20 --> Language Class Initialized
INFO - 2023-12-14 09:32:20 --> Language Class Initialized
INFO - 2023-12-14 09:32:20 --> Config Class Initialized
INFO - 2023-12-14 09:32:20 --> Loader Class Initialized
INFO - 2023-12-14 09:32:21 --> Language Class Initialized
INFO - 2023-12-14 09:32:21 --> Config Class Initialized
INFO - 2023-12-14 09:32:21 --> Loader Class Initialized
INFO - 2023-12-14 09:32:21 --> Language Class Initialized
INFO - 2023-12-14 09:32:21 --> Config Class Initialized
INFO - 2023-12-14 09:32:21 --> Loader Class Initialized
INFO - 2023-12-14 09:32:21 --> Language Class Initialized
INFO - 2023-12-14 09:32:21 --> Config Class Initialized
INFO - 2023-12-14 09:32:21 --> Loader Class Initialized
INFO - 2023-12-14 09:32:21 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:21 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:21 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:21 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:21 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:21 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:25 --> Config Class Initialized
INFO - 2023-12-14 09:32:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:32:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:25 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:25 --> URI Class Initialized
INFO - 2023-12-14 09:32:25 --> Router Class Initialized
INFO - 2023-12-14 09:32:25 --> Output Class Initialized
INFO - 2023-12-14 09:32:25 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:25 --> Input Class Initialized
INFO - 2023-12-14 09:32:25 --> Language Class Initialized
INFO - 2023-12-14 09:32:25 --> Language Class Initialized
INFO - 2023-12-14 09:32:25 --> Config Class Initialized
INFO - 2023-12-14 09:32:25 --> Loader Class Initialized
INFO - 2023-12-14 09:32:25 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:25 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:25 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:25 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:25 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:27 --> Config Class Initialized
INFO - 2023-12-14 09:32:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:32:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:27 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:27 --> Config Class Initialized
INFO - 2023-12-14 09:32:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:32:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:27 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:27 --> URI Class Initialized
INFO - 2023-12-14 09:32:27 --> Router Class Initialized
INFO - 2023-12-14 09:32:27 --> Output Class Initialized
INFO - 2023-12-14 09:32:27 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:27 --> Input Class Initialized
INFO - 2023-12-14 09:32:27 --> Language Class Initialized
INFO - 2023-12-14 09:32:27 --> URI Class Initialized
INFO - 2023-12-14 09:32:27 --> Router Class Initialized
INFO - 2023-12-14 09:32:27 --> Output Class Initialized
INFO - 2023-12-14 09:32:27 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:27 --> Input Class Initialized
INFO - 2023-12-14 09:32:28 --> Language Class Initialized
INFO - 2023-12-14 09:32:28 --> Language Class Initialized
INFO - 2023-12-14 09:32:28 --> Config Class Initialized
INFO - 2023-12-14 09:32:28 --> Loader Class Initialized
INFO - 2023-12-14 09:32:28 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:28 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:28 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:28 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:28 --> Language Class Initialized
INFO - 2023-12-14 09:32:28 --> Config Class Initialized
INFO - 2023-12-14 09:32:28 --> Loader Class Initialized
INFO - 2023-12-14 09:32:28 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:28 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:28 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:28 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:28 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:28 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:38 --> Config Class Initialized
INFO - 2023-12-14 09:32:38 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:32:38 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:32:38 --> Utf8 Class Initialized
INFO - 2023-12-14 09:32:38 --> URI Class Initialized
INFO - 2023-12-14 09:32:38 --> Router Class Initialized
INFO - 2023-12-14 09:32:38 --> Output Class Initialized
INFO - 2023-12-14 09:32:38 --> Security Class Initialized
DEBUG - 2023-12-14 09:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:32:38 --> Input Class Initialized
INFO - 2023-12-14 09:32:38 --> Language Class Initialized
INFO - 2023-12-14 09:32:39 --> Language Class Initialized
INFO - 2023-12-14 09:32:39 --> Config Class Initialized
INFO - 2023-12-14 09:32:39 --> Loader Class Initialized
INFO - 2023-12-14 09:32:39 --> Helper loaded: url_helper
INFO - 2023-12-14 09:32:39 --> Helper loaded: file_helper
INFO - 2023-12-14 09:32:39 --> Helper loaded: form_helper
INFO - 2023-12-14 09:32:39 --> Helper loaded: my_helper
INFO - 2023-12-14 09:32:39 --> Database Driver Class Initialized
INFO - 2023-12-14 09:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:32:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:32:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:33:42 --> Config Class Initialized
INFO - 2023-12-14 09:33:42 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:33:42 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:33:42 --> Utf8 Class Initialized
INFO - 2023-12-14 09:33:42 --> URI Class Initialized
INFO - 2023-12-14 09:33:42 --> Router Class Initialized
INFO - 2023-12-14 09:33:43 --> Output Class Initialized
INFO - 2023-12-14 09:33:43 --> Security Class Initialized
DEBUG - 2023-12-14 09:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:33:43 --> Input Class Initialized
INFO - 2023-12-14 09:33:43 --> Language Class Initialized
INFO - 2023-12-14 09:33:43 --> Language Class Initialized
INFO - 2023-12-14 09:33:43 --> Config Class Initialized
INFO - 2023-12-14 09:33:43 --> Loader Class Initialized
INFO - 2023-12-14 09:33:43 --> Helper loaded: url_helper
INFO - 2023-12-14 09:33:43 --> Helper loaded: file_helper
INFO - 2023-12-14 09:33:43 --> Helper loaded: form_helper
INFO - 2023-12-14 09:33:43 --> Helper loaded: my_helper
INFO - 2023-12-14 09:33:43 --> Database Driver Class Initialized
INFO - 2023-12-14 09:33:44 --> Final output sent to browser
DEBUG - 2023-12-14 09:33:44 --> Total execution time: 83.8846
INFO - 2023-12-14 09:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:33:44 --> Controller Class Initialized
DEBUG - 2023-12-14 09:33:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:33:48 --> Config Class Initialized
INFO - 2023-12-14 09:33:48 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:33:48 --> Utf8 Class Initialized
INFO - 2023-12-14 09:33:48 --> URI Class Initialized
INFO - 2023-12-14 09:33:48 --> Router Class Initialized
INFO - 2023-12-14 09:33:48 --> Output Class Initialized
INFO - 2023-12-14 09:33:48 --> Security Class Initialized
DEBUG - 2023-12-14 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:33:48 --> Input Class Initialized
INFO - 2023-12-14 09:33:48 --> Language Class Initialized
INFO - 2023-12-14 09:33:48 --> Language Class Initialized
INFO - 2023-12-14 09:33:48 --> Config Class Initialized
INFO - 2023-12-14 09:33:48 --> Loader Class Initialized
INFO - 2023-12-14 09:33:48 --> Helper loaded: url_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: file_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: form_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: my_helper
INFO - 2023-12-14 09:33:48 --> Config Class Initialized
INFO - 2023-12-14 09:33:48 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:33:48 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:33:48 --> Utf8 Class Initialized
INFO - 2023-12-14 09:33:48 --> URI Class Initialized
INFO - 2023-12-14 09:33:48 --> Database Driver Class Initialized
INFO - 2023-12-14 09:33:48 --> Router Class Initialized
INFO - 2023-12-14 09:33:48 --> Output Class Initialized
INFO - 2023-12-14 09:33:48 --> Security Class Initialized
DEBUG - 2023-12-14 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:33:48 --> Input Class Initialized
INFO - 2023-12-14 09:33:48 --> Language Class Initialized
INFO - 2023-12-14 09:33:48 --> Language Class Initialized
INFO - 2023-12-14 09:33:48 --> Config Class Initialized
INFO - 2023-12-14 09:33:48 --> Loader Class Initialized
INFO - 2023-12-14 09:33:48 --> Helper loaded: url_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: file_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: form_helper
INFO - 2023-12-14 09:33:48 --> Helper loaded: my_helper
INFO - 2023-12-14 09:33:48 --> Database Driver Class Initialized
INFO - 2023-12-14 09:33:50 --> Config Class Initialized
INFO - 2023-12-14 09:33:50 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:33:50 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:33:50 --> Utf8 Class Initialized
INFO - 2023-12-14 09:33:50 --> URI Class Initialized
INFO - 2023-12-14 09:33:51 --> Router Class Initialized
INFO - 2023-12-14 09:33:51 --> Output Class Initialized
INFO - 2023-12-14 09:33:51 --> Security Class Initialized
DEBUG - 2023-12-14 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:33:51 --> Input Class Initialized
INFO - 2023-12-14 09:33:51 --> Language Class Initialized
INFO - 2023-12-14 09:33:51 --> Language Class Initialized
INFO - 2023-12-14 09:33:51 --> Config Class Initialized
INFO - 2023-12-14 09:33:51 --> Loader Class Initialized
INFO - 2023-12-14 09:33:51 --> Helper loaded: url_helper
INFO - 2023-12-14 09:33:51 --> Helper loaded: file_helper
INFO - 2023-12-14 09:33:51 --> Helper loaded: form_helper
INFO - 2023-12-14 09:33:51 --> Helper loaded: my_helper
INFO - 2023-12-14 09:33:51 --> Database Driver Class Initialized
INFO - 2023-12-14 09:33:53 --> Config Class Initialized
INFO - 2023-12-14 09:33:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:33:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:33:53 --> Utf8 Class Initialized
INFO - 2023-12-14 09:33:53 --> URI Class Initialized
INFO - 2023-12-14 09:33:53 --> Router Class Initialized
INFO - 2023-12-14 09:33:53 --> Output Class Initialized
INFO - 2023-12-14 09:33:53 --> Security Class Initialized
DEBUG - 2023-12-14 09:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:33:53 --> Input Class Initialized
INFO - 2023-12-14 09:33:53 --> Language Class Initialized
INFO - 2023-12-14 09:33:54 --> Language Class Initialized
INFO - 2023-12-14 09:33:54 --> Config Class Initialized
INFO - 2023-12-14 09:33:54 --> Loader Class Initialized
INFO - 2023-12-14 09:33:54 --> Helper loaded: url_helper
INFO - 2023-12-14 09:33:54 --> Helper loaded: file_helper
INFO - 2023-12-14 09:33:54 --> Helper loaded: form_helper
INFO - 2023-12-14 09:33:54 --> Helper loaded: my_helper
INFO - 2023-12-14 09:33:54 --> Database Driver Class Initialized
INFO - 2023-12-14 09:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:34:07 --> Controller Class Initialized
DEBUG - 2023-12-14 09:34:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:34:17 --> Controller Class Initialized
DEBUG - 2023-12-14 09:34:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:34:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:34:27 --> Controller Class Initialized
DEBUG - 2023-12-14 09:34:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:34:54 --> Config Class Initialized
INFO - 2023-12-14 09:34:54 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:34:54 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:34:54 --> Utf8 Class Initialized
INFO - 2023-12-14 09:34:54 --> URI Class Initialized
INFO - 2023-12-14 09:34:54 --> Router Class Initialized
INFO - 2023-12-14 09:34:54 --> Output Class Initialized
INFO - 2023-12-14 09:34:54 --> Security Class Initialized
DEBUG - 2023-12-14 09:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:34:54 --> Input Class Initialized
INFO - 2023-12-14 09:34:54 --> Language Class Initialized
INFO - 2023-12-14 09:34:54 --> Language Class Initialized
INFO - 2023-12-14 09:34:54 --> Config Class Initialized
INFO - 2023-12-14 09:34:54 --> Loader Class Initialized
INFO - 2023-12-14 09:34:54 --> Helper loaded: url_helper
INFO - 2023-12-14 09:34:54 --> Helper loaded: file_helper
INFO - 2023-12-14 09:34:54 --> Helper loaded: form_helper
INFO - 2023-12-14 09:34:54 --> Helper loaded: my_helper
INFO - 2023-12-14 09:34:54 --> Database Driver Class Initialized
INFO - 2023-12-14 09:34:57 --> Config Class Initialized
INFO - 2023-12-14 09:34:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:34:57 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:34:57 --> Utf8 Class Initialized
INFO - 2023-12-14 09:34:57 --> URI Class Initialized
INFO - 2023-12-14 09:34:57 --> Router Class Initialized
INFO - 2023-12-14 09:34:57 --> Output Class Initialized
INFO - 2023-12-14 09:34:57 --> Security Class Initialized
DEBUG - 2023-12-14 09:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:34:57 --> Input Class Initialized
INFO - 2023-12-14 09:34:57 --> Language Class Initialized
INFO - 2023-12-14 09:34:57 --> Language Class Initialized
INFO - 2023-12-14 09:34:57 --> Config Class Initialized
INFO - 2023-12-14 09:34:57 --> Loader Class Initialized
INFO - 2023-12-14 09:34:57 --> Helper loaded: url_helper
INFO - 2023-12-14 09:34:57 --> Helper loaded: file_helper
INFO - 2023-12-14 09:34:57 --> Helper loaded: form_helper
INFO - 2023-12-14 09:34:57 --> Helper loaded: my_helper
INFO - 2023-12-14 09:34:57 --> Database Driver Class Initialized
INFO - 2023-12-14 09:34:59 --> Config Class Initialized
INFO - 2023-12-14 09:34:59 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:34:59 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:34:59 --> Utf8 Class Initialized
INFO - 2023-12-14 09:34:59 --> URI Class Initialized
INFO - 2023-12-14 09:34:59 --> Router Class Initialized
INFO - 2023-12-14 09:34:59 --> Output Class Initialized
INFO - 2023-12-14 09:34:59 --> Security Class Initialized
DEBUG - 2023-12-14 09:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:34:59 --> Input Class Initialized
INFO - 2023-12-14 09:34:59 --> Language Class Initialized
INFO - 2023-12-14 09:34:59 --> Language Class Initialized
INFO - 2023-12-14 09:34:59 --> Config Class Initialized
INFO - 2023-12-14 09:34:59 --> Loader Class Initialized
INFO - 2023-12-14 09:34:59 --> Helper loaded: url_helper
INFO - 2023-12-14 09:35:00 --> Helper loaded: file_helper
INFO - 2023-12-14 09:35:00 --> Helper loaded: form_helper
INFO - 2023-12-14 09:35:00 --> Helper loaded: my_helper
INFO - 2023-12-14 09:35:00 --> Database Driver Class Initialized
INFO - 2023-12-14 09:35:07 --> Final output sent to browser
DEBUG - 2023-12-14 09:35:07 --> Total execution time: 84.5906
INFO - 2023-12-14 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:35:07 --> Controller Class Initialized
DEBUG - 2023-12-14 09:35:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:35:09 --> Config Class Initialized
INFO - 2023-12-14 09:35:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:35:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:35:09 --> Utf8 Class Initialized
INFO - 2023-12-14 09:35:09 --> URI Class Initialized
INFO - 2023-12-14 09:35:09 --> Router Class Initialized
INFO - 2023-12-14 09:35:09 --> Output Class Initialized
INFO - 2023-12-14 09:35:09 --> Security Class Initialized
DEBUG - 2023-12-14 09:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:35:09 --> Input Class Initialized
INFO - 2023-12-14 09:35:09 --> Language Class Initialized
INFO - 2023-12-14 09:35:09 --> Language Class Initialized
INFO - 2023-12-14 09:35:09 --> Config Class Initialized
INFO - 2023-12-14 09:35:09 --> Loader Class Initialized
INFO - 2023-12-14 09:35:10 --> Helper loaded: url_helper
INFO - 2023-12-14 09:35:10 --> Helper loaded: file_helper
INFO - 2023-12-14 09:35:10 --> Helper loaded: form_helper
INFO - 2023-12-14 09:35:10 --> Helper loaded: my_helper
INFO - 2023-12-14 09:35:10 --> Database Driver Class Initialized
INFO - 2023-12-14 09:35:25 --> Config Class Initialized
INFO - 2023-12-14 09:35:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:35:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:35:25 --> Utf8 Class Initialized
INFO - 2023-12-14 09:35:25 --> URI Class Initialized
INFO - 2023-12-14 09:35:25 --> Router Class Initialized
INFO - 2023-12-14 09:35:25 --> Output Class Initialized
INFO - 2023-12-14 09:35:25 --> Security Class Initialized
DEBUG - 2023-12-14 09:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:35:25 --> Input Class Initialized
INFO - 2023-12-14 09:35:25 --> Language Class Initialized
INFO - 2023-12-14 09:35:25 --> Language Class Initialized
INFO - 2023-12-14 09:35:25 --> Config Class Initialized
INFO - 2023-12-14 09:35:25 --> Loader Class Initialized
INFO - 2023-12-14 09:35:25 --> Helper loaded: url_helper
INFO - 2023-12-14 09:35:25 --> Helper loaded: file_helper
INFO - 2023-12-14 09:35:25 --> Helper loaded: form_helper
INFO - 2023-12-14 09:35:25 --> Helper loaded: my_helper
INFO - 2023-12-14 09:35:25 --> Database Driver Class Initialized
INFO - 2023-12-14 09:35:27 --> Config Class Initialized
INFO - 2023-12-14 09:35:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:35:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:35:27 --> Utf8 Class Initialized
INFO - 2023-12-14 09:35:27 --> URI Class Initialized
INFO - 2023-12-14 09:35:27 --> Router Class Initialized
INFO - 2023-12-14 09:35:27 --> Output Class Initialized
INFO - 2023-12-14 09:35:27 --> Security Class Initialized
DEBUG - 2023-12-14 09:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:35:27 --> Input Class Initialized
INFO - 2023-12-14 09:35:27 --> Language Class Initialized
INFO - 2023-12-14 09:35:27 --> Language Class Initialized
INFO - 2023-12-14 09:35:27 --> Config Class Initialized
INFO - 2023-12-14 09:35:27 --> Loader Class Initialized
INFO - 2023-12-14 09:35:27 --> Helper loaded: url_helper
INFO - 2023-12-14 09:35:27 --> Helper loaded: file_helper
INFO - 2023-12-14 09:35:27 --> Helper loaded: form_helper
INFO - 2023-12-14 09:35:27 --> Helper loaded: my_helper
INFO - 2023-12-14 09:35:28 --> Database Driver Class Initialized
INFO - 2023-12-14 09:35:34 --> Config Class Initialized
INFO - 2023-12-14 09:35:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:35:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:35:34 --> Utf8 Class Initialized
INFO - 2023-12-14 09:35:34 --> URI Class Initialized
INFO - 2023-12-14 09:35:34 --> Router Class Initialized
INFO - 2023-12-14 09:35:34 --> Output Class Initialized
INFO - 2023-12-14 09:35:34 --> Security Class Initialized
DEBUG - 2023-12-14 09:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:35:34 --> Input Class Initialized
INFO - 2023-12-14 09:35:34 --> Language Class Initialized
INFO - 2023-12-14 09:35:34 --> Language Class Initialized
INFO - 2023-12-14 09:35:34 --> Config Class Initialized
INFO - 2023-12-14 09:35:34 --> Loader Class Initialized
INFO - 2023-12-14 09:35:34 --> Helper loaded: url_helper
INFO - 2023-12-14 09:35:34 --> Helper loaded: file_helper
INFO - 2023-12-14 09:35:34 --> Helper loaded: form_helper
INFO - 2023-12-14 09:35:34 --> Helper loaded: my_helper
INFO - 2023-12-14 09:35:34 --> Database Driver Class Initialized
INFO - 2023-12-14 09:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:35:37 --> Controller Class Initialized
DEBUG - 2023-12-14 09:35:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:36:31 --> Final output sent to browser
DEBUG - 2023-12-14 09:36:31 --> Total execution time: 81.4237
INFO - 2023-12-14 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:36:31 --> Controller Class Initialized
DEBUG - 2023-12-14 09:36:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:36:37 --> Controller Class Initialized
DEBUG - 2023-12-14 09:36:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:36:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:36:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:37:07 --> Controller Class Initialized
DEBUG - 2023-12-14 09:37:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:40:17 --> Config Class Initialized
INFO - 2023-12-14 09:40:17 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:17 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:17 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:17 --> URI Class Initialized
INFO - 2023-12-14 09:40:17 --> Router Class Initialized
INFO - 2023-12-14 09:40:17 --> Output Class Initialized
INFO - 2023-12-14 09:40:17 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:17 --> Input Class Initialized
INFO - 2023-12-14 09:40:17 --> Language Class Initialized
INFO - 2023-12-14 09:40:17 --> Language Class Initialized
INFO - 2023-12-14 09:40:17 --> Config Class Initialized
INFO - 2023-12-14 09:40:17 --> Loader Class Initialized
INFO - 2023-12-14 09:40:17 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:17 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:17 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:17 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:17 --> Database Driver Class Initialized
INFO - 2023-12-14 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:40:17 --> Controller Class Initialized
DEBUG - 2023-12-14 09:40:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:40:22 --> Config Class Initialized
INFO - 2023-12-14 09:40:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:22 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:22 --> URI Class Initialized
INFO - 2023-12-14 09:40:22 --> Router Class Initialized
INFO - 2023-12-14 09:40:22 --> Output Class Initialized
INFO - 2023-12-14 09:40:22 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:22 --> Input Class Initialized
INFO - 2023-12-14 09:40:22 --> Language Class Initialized
INFO - 2023-12-14 09:40:23 --> Language Class Initialized
INFO - 2023-12-14 09:40:23 --> Config Class Initialized
INFO - 2023-12-14 09:40:23 --> Loader Class Initialized
INFO - 2023-12-14 09:40:23 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:23 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:23 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:23 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:23 --> Database Driver Class Initialized
INFO - 2023-12-14 09:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:40:23 --> Controller Class Initialized
DEBUG - 2023-12-14 09:40:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:40:25 --> Config Class Initialized
INFO - 2023-12-14 09:40:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:25 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:25 --> URI Class Initialized
INFO - 2023-12-14 09:40:25 --> Router Class Initialized
INFO - 2023-12-14 09:40:25 --> Output Class Initialized
INFO - 2023-12-14 09:40:25 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:25 --> Input Class Initialized
INFO - 2023-12-14 09:40:25 --> Language Class Initialized
INFO - 2023-12-14 09:40:25 --> Language Class Initialized
INFO - 2023-12-14 09:40:25 --> Config Class Initialized
INFO - 2023-12-14 09:40:25 --> Loader Class Initialized
INFO - 2023-12-14 09:40:25 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:25 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:25 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:25 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:25 --> Database Driver Class Initialized
INFO - 2023-12-14 09:40:27 --> Config Class Initialized
INFO - 2023-12-14 09:40:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:27 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:27 --> URI Class Initialized
INFO - 2023-12-14 09:40:27 --> Router Class Initialized
INFO - 2023-12-14 09:40:27 --> Output Class Initialized
INFO - 2023-12-14 09:40:27 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:27 --> Input Class Initialized
INFO - 2023-12-14 09:40:27 --> Language Class Initialized
INFO - 2023-12-14 09:40:27 --> Language Class Initialized
INFO - 2023-12-14 09:40:27 --> Config Class Initialized
INFO - 2023-12-14 09:40:27 --> Loader Class Initialized
INFO - 2023-12-14 09:40:27 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:27 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:27 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:27 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:27 --> Database Driver Class Initialized
INFO - 2023-12-14 09:40:45 --> Config Class Initialized
INFO - 2023-12-14 09:40:45 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:45 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:45 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:45 --> URI Class Initialized
INFO - 2023-12-14 09:40:45 --> Router Class Initialized
INFO - 2023-12-14 09:40:45 --> Output Class Initialized
INFO - 2023-12-14 09:40:45 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:45 --> Input Class Initialized
INFO - 2023-12-14 09:40:45 --> Language Class Initialized
INFO - 2023-12-14 09:40:45 --> Language Class Initialized
INFO - 2023-12-14 09:40:45 --> Config Class Initialized
INFO - 2023-12-14 09:40:45 --> Loader Class Initialized
INFO - 2023-12-14 09:40:45 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:45 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:45 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:45 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:45 --> Database Driver Class Initialized
INFO - 2023-12-14 09:40:47 --> Config Class Initialized
INFO - 2023-12-14 09:40:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:40:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:40:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:40:47 --> URI Class Initialized
INFO - 2023-12-14 09:40:47 --> Router Class Initialized
INFO - 2023-12-14 09:40:47 --> Output Class Initialized
INFO - 2023-12-14 09:40:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:40:48 --> Input Class Initialized
INFO - 2023-12-14 09:40:48 --> Language Class Initialized
INFO - 2023-12-14 09:40:48 --> Language Class Initialized
INFO - 2023-12-14 09:40:48 --> Config Class Initialized
INFO - 2023-12-14 09:40:48 --> Loader Class Initialized
INFO - 2023-12-14 09:40:48 --> Helper loaded: url_helper
INFO - 2023-12-14 09:40:48 --> Helper loaded: file_helper
INFO - 2023-12-14 09:40:48 --> Helper loaded: form_helper
INFO - 2023-12-14 09:40:48 --> Helper loaded: my_helper
INFO - 2023-12-14 09:40:48 --> Database Driver Class Initialized
INFO - 2023-12-14 09:41:01 --> Final output sent to browser
DEBUG - 2023-12-14 09:41:01 --> Total execution time: 44.6801
INFO - 2023-12-14 09:41:01 --> Config Class Initialized
INFO - 2023-12-14 09:41:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:41:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:41:01 --> Utf8 Class Initialized
INFO - 2023-12-14 09:41:01 --> Config Class Initialized
INFO - 2023-12-14 09:41:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:41:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:41:01 --> Utf8 Class Initialized
INFO - 2023-12-14 09:41:01 --> Config Class Initialized
INFO - 2023-12-14 09:41:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:41:02 --> Utf8 Class Initialized
INFO - 2023-12-14 09:41:02 --> Config Class Initialized
INFO - 2023-12-14 09:41:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:41:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:41:02 --> Utf8 Class Initialized
INFO - 2023-12-14 09:41:02 --> URI Class Initialized
INFO - 2023-12-14 09:41:02 --> URI Class Initialized
INFO - 2023-12-14 09:41:02 --> Router Class Initialized
INFO - 2023-12-14 09:41:02 --> Output Class Initialized
INFO - 2023-12-14 09:41:02 --> Security Class Initialized
INFO - 2023-12-14 09:41:02 --> URI Class Initialized
INFO - 2023-12-14 09:41:02 --> Router Class Initialized
INFO - 2023-12-14 09:41:02 --> Output Class Initialized
INFO - 2023-12-14 09:41:02 --> Security Class Initialized
DEBUG - 2023-12-14 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:41:02 --> Input Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> URI Class Initialized
INFO - 2023-12-14 09:41:02 --> Router Class Initialized
INFO - 2023-12-14 09:41:02 --> Output Class Initialized
INFO - 2023-12-14 09:41:02 --> Security Class Initialized
INFO - 2023-12-14 09:41:02 --> Router Class Initialized
INFO - 2023-12-14 09:41:02 --> Output Class Initialized
INFO - 2023-12-14 09:41:02 --> Security Class Initialized
DEBUG - 2023-12-14 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:41:02 --> Input Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
DEBUG - 2023-12-14 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:41:02 --> Input Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
DEBUG - 2023-12-14 09:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:41:02 --> Input Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> Config Class Initialized
INFO - 2023-12-14 09:41:02 --> Loader Class Initialized
INFO - 2023-12-14 09:41:02 --> Helper loaded: url_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: file_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: form_helper
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> Config Class Initialized
INFO - 2023-12-14 09:41:02 --> Loader Class Initialized
INFO - 2023-12-14 09:41:02 --> Helper loaded: url_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: file_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: form_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: my_helper
INFO - 2023-12-14 09:41:02 --> Database Driver Class Initialized
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> Config Class Initialized
INFO - 2023-12-14 09:41:02 --> Loader Class Initialized
INFO - 2023-12-14 09:41:02 --> Helper loaded: url_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: file_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: form_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: my_helper
INFO - 2023-12-14 09:41:02 --> Language Class Initialized
INFO - 2023-12-14 09:41:02 --> Config Class Initialized
INFO - 2023-12-14 09:41:02 --> Loader Class Initialized
INFO - 2023-12-14 09:41:02 --> Helper loaded: url_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: file_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: form_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: my_helper
INFO - 2023-12-14 09:41:02 --> Helper loaded: my_helper
INFO - 2023-12-14 09:41:02 --> Database Driver Class Initialized
INFO - 2023-12-14 09:41:02 --> Database Driver Class Initialized
INFO - 2023-12-14 09:41:02 --> Database Driver Class Initialized
INFO - 2023-12-14 09:41:07 --> Final output sent to browser
DEBUG - 2023-12-14 09:41:07 --> Total execution time: 44.2355
INFO - 2023-12-14 09:41:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:41:07 --> Controller Class Initialized
DEBUG - 2023-12-14 09:41:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:41:34 --> Final output sent to browser
DEBUG - 2023-12-14 09:41:34 --> Total execution time: 48.8106
INFO - 2023-12-14 09:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:41:34 --> Controller Class Initialized
DEBUG - 2023-12-14 09:41:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:41:59 --> Final output sent to browser
DEBUG - 2023-12-14 09:41:59 --> Total execution time: 91.6586
INFO - 2023-12-14 09:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:41:59 --> Controller Class Initialized
DEBUG - 2023-12-14 09:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:42:07 --> Controller Class Initialized
DEBUG - 2023-12-14 09:42:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:42:37 --> Controller Class Initialized
DEBUG - 2023-12-14 09:42:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:42:58 --> Config Class Initialized
INFO - 2023-12-14 09:42:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:42:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:42:58 --> Utf8 Class Initialized
INFO - 2023-12-14 09:42:58 --> URI Class Initialized
INFO - 2023-12-14 09:42:58 --> Router Class Initialized
INFO - 2023-12-14 09:42:58 --> Output Class Initialized
INFO - 2023-12-14 09:42:58 --> Security Class Initialized
DEBUG - 2023-12-14 09:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:42:58 --> Input Class Initialized
INFO - 2023-12-14 09:42:58 --> Language Class Initialized
INFO - 2023-12-14 09:42:58 --> Language Class Initialized
INFO - 2023-12-14 09:42:58 --> Config Class Initialized
INFO - 2023-12-14 09:42:58 --> Loader Class Initialized
INFO - 2023-12-14 09:42:58 --> Helper loaded: url_helper
INFO - 2023-12-14 09:42:59 --> Helper loaded: file_helper
INFO - 2023-12-14 09:42:59 --> Helper loaded: form_helper
INFO - 2023-12-14 09:42:59 --> Helper loaded: my_helper
INFO - 2023-12-14 09:42:59 --> Database Driver Class Initialized
INFO - 2023-12-14 09:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:42:59 --> Controller Class Initialized
DEBUG - 2023-12-14 09:42:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:43:21 --> Final output sent to browser
DEBUG - 2023-12-14 09:43:21 --> Total execution time: 23.0903
INFO - 2023-12-14 09:43:22 --> Config Class Initialized
INFO - 2023-12-14 09:43:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:43:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:43:22 --> Utf8 Class Initialized
INFO - 2023-12-14 09:43:22 --> URI Class Initialized
INFO - 2023-12-14 09:43:22 --> Router Class Initialized
INFO - 2023-12-14 09:43:22 --> Output Class Initialized
INFO - 2023-12-14 09:43:22 --> Security Class Initialized
DEBUG - 2023-12-14 09:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:43:22 --> Input Class Initialized
INFO - 2023-12-14 09:43:22 --> Language Class Initialized
INFO - 2023-12-14 09:43:22 --> Language Class Initialized
INFO - 2023-12-14 09:43:22 --> Config Class Initialized
INFO - 2023-12-14 09:43:22 --> Loader Class Initialized
INFO - 2023-12-14 09:43:22 --> Helper loaded: url_helper
INFO - 2023-12-14 09:43:22 --> Helper loaded: file_helper
INFO - 2023-12-14 09:43:22 --> Helper loaded: form_helper
INFO - 2023-12-14 09:43:22 --> Helper loaded: my_helper
INFO - 2023-12-14 09:43:22 --> Database Driver Class Initialized
INFO - 2023-12-14 09:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:43:22 --> Controller Class Initialized
DEBUG - 2023-12-14 09:43:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:43:24 --> Config Class Initialized
INFO - 2023-12-14 09:43:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:43:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:43:24 --> Utf8 Class Initialized
INFO - 2023-12-14 09:43:24 --> URI Class Initialized
INFO - 2023-12-14 09:43:24 --> Router Class Initialized
INFO - 2023-12-14 09:43:24 --> Output Class Initialized
INFO - 2023-12-14 09:43:24 --> Security Class Initialized
DEBUG - 2023-12-14 09:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:43:24 --> Input Class Initialized
INFO - 2023-12-14 09:43:24 --> Language Class Initialized
INFO - 2023-12-14 09:43:24 --> Language Class Initialized
INFO - 2023-12-14 09:43:24 --> Config Class Initialized
INFO - 2023-12-14 09:43:24 --> Loader Class Initialized
INFO - 2023-12-14 09:43:24 --> Helper loaded: url_helper
INFO - 2023-12-14 09:43:24 --> Helper loaded: file_helper
INFO - 2023-12-14 09:43:24 --> Helper loaded: form_helper
INFO - 2023-12-14 09:43:24 --> Helper loaded: my_helper
INFO - 2023-12-14 09:43:24 --> Database Driver Class Initialized
INFO - 2023-12-14 09:43:43 --> Final output sent to browser
DEBUG - 2023-12-14 09:43:43 --> Total execution time: 21.3020
INFO - 2023-12-14 09:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:43:43 --> Controller Class Initialized
DEBUG - 2023-12-14 09:43:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:44:14 --> Final output sent to browser
DEBUG - 2023-12-14 09:44:14 --> Total execution time: 49.4647
INFO - 2023-12-14 09:45:08 --> Config Class Initialized
INFO - 2023-12-14 09:45:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:45:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:45:08 --> Utf8 Class Initialized
INFO - 2023-12-14 09:45:08 --> URI Class Initialized
INFO - 2023-12-14 09:45:08 --> Router Class Initialized
INFO - 2023-12-14 09:45:08 --> Output Class Initialized
INFO - 2023-12-14 09:45:08 --> Security Class Initialized
DEBUG - 2023-12-14 09:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:45:08 --> Input Class Initialized
INFO - 2023-12-14 09:45:08 --> Language Class Initialized
INFO - 2023-12-14 09:45:08 --> Language Class Initialized
INFO - 2023-12-14 09:45:08 --> Config Class Initialized
INFO - 2023-12-14 09:45:08 --> Loader Class Initialized
INFO - 2023-12-14 09:45:08 --> Helper loaded: url_helper
INFO - 2023-12-14 09:45:08 --> Helper loaded: file_helper
INFO - 2023-12-14 09:45:08 --> Helper loaded: form_helper
INFO - 2023-12-14 09:45:08 --> Helper loaded: my_helper
INFO - 2023-12-14 09:45:08 --> Database Driver Class Initialized
INFO - 2023-12-14 09:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:45:08 --> Controller Class Initialized
DEBUG - 2023-12-14 09:45:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:45:09 --> Config Class Initialized
INFO - 2023-12-14 09:45:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:45:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:45:09 --> Utf8 Class Initialized
INFO - 2023-12-14 09:45:09 --> URI Class Initialized
INFO - 2023-12-14 09:45:09 --> Router Class Initialized
INFO - 2023-12-14 09:45:09 --> Output Class Initialized
INFO - 2023-12-14 09:45:09 --> Security Class Initialized
DEBUG - 2023-12-14 09:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:45:09 --> Input Class Initialized
INFO - 2023-12-14 09:45:09 --> Language Class Initialized
INFO - 2023-12-14 09:45:09 --> Language Class Initialized
INFO - 2023-12-14 09:45:09 --> Config Class Initialized
INFO - 2023-12-14 09:45:09 --> Loader Class Initialized
INFO - 2023-12-14 09:45:09 --> Helper loaded: url_helper
INFO - 2023-12-14 09:45:09 --> Helper loaded: file_helper
INFO - 2023-12-14 09:45:09 --> Helper loaded: form_helper
INFO - 2023-12-14 09:45:09 --> Helper loaded: my_helper
INFO - 2023-12-14 09:45:09 --> Database Driver Class Initialized
INFO - 2023-12-14 09:45:12 --> Config Class Initialized
INFO - 2023-12-14 09:45:12 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:45:12 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:45:12 --> Utf8 Class Initialized
INFO - 2023-12-14 09:45:12 --> URI Class Initialized
INFO - 2023-12-14 09:45:12 --> Router Class Initialized
INFO - 2023-12-14 09:45:12 --> Output Class Initialized
INFO - 2023-12-14 09:45:12 --> Security Class Initialized
DEBUG - 2023-12-14 09:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:45:12 --> Input Class Initialized
INFO - 2023-12-14 09:45:12 --> Language Class Initialized
INFO - 2023-12-14 09:45:12 --> Language Class Initialized
INFO - 2023-12-14 09:45:12 --> Config Class Initialized
INFO - 2023-12-14 09:45:12 --> Loader Class Initialized
INFO - 2023-12-14 09:45:12 --> Helper loaded: url_helper
INFO - 2023-12-14 09:45:12 --> Helper loaded: file_helper
INFO - 2023-12-14 09:45:12 --> Helper loaded: form_helper
INFO - 2023-12-14 09:45:12 --> Helper loaded: my_helper
INFO - 2023-12-14 09:45:12 --> Database Driver Class Initialized
INFO - 2023-12-14 09:45:25 --> Final output sent to browser
DEBUG - 2023-12-14 09:45:25 --> Total execution time: 17.4095
INFO - 2023-12-14 09:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:45:25 --> Controller Class Initialized
INFO - 2023-12-14 09:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:45:25 --> Controller Class Initialized
DEBUG - 2023-12-14 09:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
DEBUG - 2023-12-14 09:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:45:49 --> Final output sent to browser
DEBUG - 2023-12-14 09:45:49 --> Total execution time: 37.4595
INFO - 2023-12-14 09:45:49 --> Final output sent to browser
DEBUG - 2023-12-14 09:45:49 --> Total execution time: 40.3294
INFO - 2023-12-14 09:54:36 --> Config Class Initialized
INFO - 2023-12-14 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:36 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:36 --> URI Class Initialized
DEBUG - 2023-12-14 09:54:36 --> No URI present. Default controller set.
INFO - 2023-12-14 09:54:36 --> Router Class Initialized
INFO - 2023-12-14 09:54:36 --> Output Class Initialized
INFO - 2023-12-14 09:54:36 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:36 --> Input Class Initialized
INFO - 2023-12-14 09:54:36 --> Language Class Initialized
INFO - 2023-12-14 09:54:36 --> Language Class Initialized
INFO - 2023-12-14 09:54:36 --> Config Class Initialized
INFO - 2023-12-14 09:54:36 --> Loader Class Initialized
INFO - 2023-12-14 09:54:36 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:36 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:36 --> Controller Class Initialized
INFO - 2023-12-14 09:54:36 --> Config Class Initialized
INFO - 2023-12-14 09:54:36 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:36 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:36 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:36 --> URI Class Initialized
INFO - 2023-12-14 09:54:36 --> Router Class Initialized
INFO - 2023-12-14 09:54:36 --> Output Class Initialized
INFO - 2023-12-14 09:54:36 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:36 --> Input Class Initialized
INFO - 2023-12-14 09:54:36 --> Language Class Initialized
INFO - 2023-12-14 09:54:36 --> Language Class Initialized
INFO - 2023-12-14 09:54:36 --> Config Class Initialized
INFO - 2023-12-14 09:54:36 --> Loader Class Initialized
INFO - 2023-12-14 09:54:36 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:36 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:36 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:36 --> Controller Class Initialized
DEBUG - 2023-12-14 09:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 09:54:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:54:37 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:37 --> Total execution time: 0.1681
INFO - 2023-12-14 09:54:40 --> Config Class Initialized
INFO - 2023-12-14 09:54:40 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:40 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:40 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:40 --> URI Class Initialized
INFO - 2023-12-14 09:54:40 --> Router Class Initialized
INFO - 2023-12-14 09:54:40 --> Output Class Initialized
INFO - 2023-12-14 09:54:40 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:40 --> Input Class Initialized
INFO - 2023-12-14 09:54:40 --> Language Class Initialized
INFO - 2023-12-14 09:54:40 --> Language Class Initialized
INFO - 2023-12-14 09:54:40 --> Config Class Initialized
INFO - 2023-12-14 09:54:40 --> Loader Class Initialized
INFO - 2023-12-14 09:54:40 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:40 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:40 --> Controller Class Initialized
INFO - 2023-12-14 09:54:40 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:54:40 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:40 --> Total execution time: 0.2576
INFO - 2023-12-14 09:54:40 --> Config Class Initialized
INFO - 2023-12-14 09:54:40 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:40 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:40 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:40 --> URI Class Initialized
INFO - 2023-12-14 09:54:40 --> Router Class Initialized
INFO - 2023-12-14 09:54:40 --> Output Class Initialized
INFO - 2023-12-14 09:54:40 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:40 --> Input Class Initialized
INFO - 2023-12-14 09:54:40 --> Language Class Initialized
INFO - 2023-12-14 09:54:40 --> Language Class Initialized
INFO - 2023-12-14 09:54:40 --> Config Class Initialized
INFO - 2023-12-14 09:54:40 --> Loader Class Initialized
INFO - 2023-12-14 09:54:40 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:40 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:40 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:40 --> Controller Class Initialized
DEBUG - 2023-12-14 09:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 09:54:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:54:40 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:40 --> Total execution time: 0.1910
INFO - 2023-12-14 09:54:42 --> Config Class Initialized
INFO - 2023-12-14 09:54:42 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:42 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:42 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:42 --> URI Class Initialized
INFO - 2023-12-14 09:54:42 --> Router Class Initialized
INFO - 2023-12-14 09:54:42 --> Output Class Initialized
INFO - 2023-12-14 09:54:42 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:42 --> Input Class Initialized
INFO - 2023-12-14 09:54:42 --> Language Class Initialized
INFO - 2023-12-14 09:54:42 --> Language Class Initialized
INFO - 2023-12-14 09:54:42 --> Config Class Initialized
INFO - 2023-12-14 09:54:42 --> Loader Class Initialized
INFO - 2023-12-14 09:54:42 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:42 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:42 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:42 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:42 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:42 --> Controller Class Initialized
DEBUG - 2023-12-14 09:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 09:54:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:54:42 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:42 --> Total execution time: 0.1820
INFO - 2023-12-14 09:54:44 --> Config Class Initialized
INFO - 2023-12-14 09:54:44 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:44 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:44 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:44 --> URI Class Initialized
INFO - 2023-12-14 09:54:44 --> Router Class Initialized
INFO - 2023-12-14 09:54:44 --> Output Class Initialized
INFO - 2023-12-14 09:54:44 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:44 --> Input Class Initialized
INFO - 2023-12-14 09:54:44 --> Language Class Initialized
INFO - 2023-12-14 09:54:44 --> Language Class Initialized
INFO - 2023-12-14 09:54:44 --> Config Class Initialized
INFO - 2023-12-14 09:54:44 --> Loader Class Initialized
INFO - 2023-12-14 09:54:44 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:44 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:44 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:45 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:45 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:45 --> Controller Class Initialized
DEBUG - 2023-12-14 09:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 09:54:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:54:45 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:45 --> Total execution time: 0.2293
INFO - 2023-12-14 09:54:46 --> Config Class Initialized
INFO - 2023-12-14 09:54:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:54:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:54:46 --> Utf8 Class Initialized
INFO - 2023-12-14 09:54:46 --> URI Class Initialized
INFO - 2023-12-14 09:54:46 --> Router Class Initialized
INFO - 2023-12-14 09:54:46 --> Output Class Initialized
INFO - 2023-12-14 09:54:46 --> Security Class Initialized
DEBUG - 2023-12-14 09:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:54:46 --> Input Class Initialized
INFO - 2023-12-14 09:54:46 --> Language Class Initialized
INFO - 2023-12-14 09:54:46 --> Language Class Initialized
INFO - 2023-12-14 09:54:46 --> Config Class Initialized
INFO - 2023-12-14 09:54:46 --> Loader Class Initialized
INFO - 2023-12-14 09:54:46 --> Helper loaded: url_helper
INFO - 2023-12-14 09:54:46 --> Helper loaded: file_helper
INFO - 2023-12-14 09:54:46 --> Helper loaded: form_helper
INFO - 2023-12-14 09:54:46 --> Helper loaded: my_helper
INFO - 2023-12-14 09:54:46 --> Database Driver Class Initialized
INFO - 2023-12-14 09:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:54:46 --> Controller Class Initialized
INFO - 2023-12-14 09:54:46 --> Final output sent to browser
DEBUG - 2023-12-14 09:54:46 --> Total execution time: 0.2101
INFO - 2023-12-14 09:56:43 --> Config Class Initialized
INFO - 2023-12-14 09:56:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:43 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:43 --> URI Class Initialized
INFO - 2023-12-14 09:56:43 --> Router Class Initialized
INFO - 2023-12-14 09:56:43 --> Output Class Initialized
INFO - 2023-12-14 09:56:43 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:43 --> Input Class Initialized
INFO - 2023-12-14 09:56:43 --> Language Class Initialized
INFO - 2023-12-14 09:56:43 --> Language Class Initialized
INFO - 2023-12-14 09:56:43 --> Config Class Initialized
INFO - 2023-12-14 09:56:43 --> Loader Class Initialized
INFO - 2023-12-14 09:56:43 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:43 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:43 --> Controller Class Initialized
INFO - 2023-12-14 09:56:43 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:56:43 --> Config Class Initialized
INFO - 2023-12-14 09:56:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:43 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:43 --> URI Class Initialized
INFO - 2023-12-14 09:56:43 --> Router Class Initialized
INFO - 2023-12-14 09:56:43 --> Output Class Initialized
INFO - 2023-12-14 09:56:43 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:43 --> Input Class Initialized
INFO - 2023-12-14 09:56:43 --> Language Class Initialized
INFO - 2023-12-14 09:56:43 --> Language Class Initialized
INFO - 2023-12-14 09:56:43 --> Config Class Initialized
INFO - 2023-12-14 09:56:43 --> Loader Class Initialized
INFO - 2023-12-14 09:56:43 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:43 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:43 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:43 --> Controller Class Initialized
INFO - 2023-12-14 09:56:43 --> Config Class Initialized
INFO - 2023-12-14 09:56:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:43 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:43 --> URI Class Initialized
INFO - 2023-12-14 09:56:43 --> Router Class Initialized
INFO - 2023-12-14 09:56:43 --> Output Class Initialized
INFO - 2023-12-14 09:56:43 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:43 --> Input Class Initialized
INFO - 2023-12-14 09:56:43 --> Language Class Initialized
INFO - 2023-12-14 09:56:44 --> Language Class Initialized
INFO - 2023-12-14 09:56:44 --> Config Class Initialized
INFO - 2023-12-14 09:56:44 --> Loader Class Initialized
INFO - 2023-12-14 09:56:44 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:44 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:44 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:44 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:44 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:44 --> Controller Class Initialized
DEBUG - 2023-12-14 09:56:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 09:56:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:56:44 --> Final output sent to browser
DEBUG - 2023-12-14 09:56:44 --> Total execution time: 0.5015
INFO - 2023-12-14 09:56:47 --> Config Class Initialized
INFO - 2023-12-14 09:56:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:47 --> URI Class Initialized
INFO - 2023-12-14 09:56:47 --> Router Class Initialized
INFO - 2023-12-14 09:56:47 --> Output Class Initialized
INFO - 2023-12-14 09:56:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:47 --> Input Class Initialized
INFO - 2023-12-14 09:56:47 --> Language Class Initialized
INFO - 2023-12-14 09:56:47 --> Language Class Initialized
INFO - 2023-12-14 09:56:47 --> Config Class Initialized
INFO - 2023-12-14 09:56:47 --> Loader Class Initialized
INFO - 2023-12-14 09:56:47 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:47 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:47 --> Controller Class Initialized
INFO - 2023-12-14 09:56:47 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:56:47 --> Final output sent to browser
DEBUG - 2023-12-14 09:56:47 --> Total execution time: 0.2887
INFO - 2023-12-14 09:56:47 --> Config Class Initialized
INFO - 2023-12-14 09:56:47 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:47 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:47 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:47 --> URI Class Initialized
INFO - 2023-12-14 09:56:47 --> Router Class Initialized
INFO - 2023-12-14 09:56:47 --> Output Class Initialized
INFO - 2023-12-14 09:56:47 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:47 --> Input Class Initialized
INFO - 2023-12-14 09:56:47 --> Language Class Initialized
INFO - 2023-12-14 09:56:47 --> Language Class Initialized
INFO - 2023-12-14 09:56:47 --> Config Class Initialized
INFO - 2023-12-14 09:56:47 --> Loader Class Initialized
INFO - 2023-12-14 09:56:47 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:47 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:47 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:47 --> Controller Class Initialized
DEBUG - 2023-12-14 09:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 09:56:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:56:47 --> Final output sent to browser
DEBUG - 2023-12-14 09:56:47 --> Total execution time: 0.3046
INFO - 2023-12-14 09:56:50 --> Config Class Initialized
INFO - 2023-12-14 09:56:50 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:50 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:50 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:50 --> URI Class Initialized
INFO - 2023-12-14 09:56:50 --> Router Class Initialized
INFO - 2023-12-14 09:56:50 --> Output Class Initialized
INFO - 2023-12-14 09:56:50 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:50 --> Input Class Initialized
INFO - 2023-12-14 09:56:50 --> Language Class Initialized
INFO - 2023-12-14 09:56:50 --> Language Class Initialized
INFO - 2023-12-14 09:56:50 --> Config Class Initialized
INFO - 2023-12-14 09:56:50 --> Loader Class Initialized
INFO - 2023-12-14 09:56:50 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:50 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:50 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:50 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:50 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:50 --> Controller Class Initialized
DEBUG - 2023-12-14 09:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:56:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:56:50 --> Final output sent to browser
DEBUG - 2023-12-14 09:56:50 --> Total execution time: 0.4573
INFO - 2023-12-14 09:56:56 --> Config Class Initialized
INFO - 2023-12-14 09:56:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:56 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:56 --> URI Class Initialized
INFO - 2023-12-14 09:56:56 --> Router Class Initialized
INFO - 2023-12-14 09:56:56 --> Output Class Initialized
INFO - 2023-12-14 09:56:56 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:56 --> Input Class Initialized
INFO - 2023-12-14 09:56:56 --> Language Class Initialized
INFO - 2023-12-14 09:56:56 --> Language Class Initialized
INFO - 2023-12-14 09:56:56 --> Config Class Initialized
INFO - 2023-12-14 09:56:56 --> Loader Class Initialized
INFO - 2023-12-14 09:56:56 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:56 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:56 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:57 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:57 --> Database Driver Class Initialized
INFO - 2023-12-14 09:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:56:57 --> Controller Class Initialized
DEBUG - 2023-12-14 09:56:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 09:56:58 --> Config Class Initialized
INFO - 2023-12-14 09:56:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:56:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:56:58 --> Utf8 Class Initialized
INFO - 2023-12-14 09:56:58 --> URI Class Initialized
INFO - 2023-12-14 09:56:58 --> Router Class Initialized
INFO - 2023-12-14 09:56:58 --> Output Class Initialized
INFO - 2023-12-14 09:56:58 --> Security Class Initialized
DEBUG - 2023-12-14 09:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:56:58 --> Input Class Initialized
INFO - 2023-12-14 09:56:58 --> Language Class Initialized
INFO - 2023-12-14 09:56:58 --> Language Class Initialized
INFO - 2023-12-14 09:56:58 --> Config Class Initialized
INFO - 2023-12-14 09:56:58 --> Loader Class Initialized
INFO - 2023-12-14 09:56:58 --> Helper loaded: url_helper
INFO - 2023-12-14 09:56:58 --> Helper loaded: file_helper
INFO - 2023-12-14 09:56:59 --> Helper loaded: form_helper
INFO - 2023-12-14 09:56:59 --> Helper loaded: my_helper
INFO - 2023-12-14 09:56:59 --> Database Driver Class Initialized
INFO - 2023-12-14 09:58:29 --> Config Class Initialized
INFO - 2023-12-14 09:58:29 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:58:29 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:58:29 --> Utf8 Class Initialized
INFO - 2023-12-14 09:58:29 --> URI Class Initialized
INFO - 2023-12-14 09:58:29 --> Router Class Initialized
INFO - 2023-12-14 09:58:29 --> Output Class Initialized
INFO - 2023-12-14 09:58:29 --> Security Class Initialized
DEBUG - 2023-12-14 09:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:58:29 --> Input Class Initialized
INFO - 2023-12-14 09:58:29 --> Language Class Initialized
INFO - 2023-12-14 09:58:30 --> Language Class Initialized
INFO - 2023-12-14 09:58:30 --> Config Class Initialized
INFO - 2023-12-14 09:58:30 --> Loader Class Initialized
INFO - 2023-12-14 09:58:30 --> Helper loaded: url_helper
INFO - 2023-12-14 09:58:30 --> Helper loaded: file_helper
INFO - 2023-12-14 09:58:30 --> Helper loaded: form_helper
INFO - 2023-12-14 09:58:30 --> Helper loaded: my_helper
INFO - 2023-12-14 09:58:30 --> Database Driver Class Initialized
INFO - 2023-12-14 09:58:31 --> Config Class Initialized
INFO - 2023-12-14 09:58:31 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:58:31 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:58:31 --> Utf8 Class Initialized
INFO - 2023-12-14 09:58:31 --> URI Class Initialized
INFO - 2023-12-14 09:58:31 --> Router Class Initialized
INFO - 2023-12-14 09:58:31 --> Output Class Initialized
INFO - 2023-12-14 09:58:31 --> Security Class Initialized
DEBUG - 2023-12-14 09:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:58:31 --> Input Class Initialized
INFO - 2023-12-14 09:58:31 --> Language Class Initialized
INFO - 2023-12-14 09:58:31 --> Language Class Initialized
INFO - 2023-12-14 09:58:31 --> Config Class Initialized
INFO - 2023-12-14 09:58:31 --> Loader Class Initialized
INFO - 2023-12-14 09:58:31 --> Helper loaded: url_helper
INFO - 2023-12-14 09:58:31 --> Helper loaded: file_helper
INFO - 2023-12-14 09:58:31 --> Helper loaded: form_helper
INFO - 2023-12-14 09:58:31 --> Helper loaded: my_helper
INFO - 2023-12-14 09:58:32 --> Database Driver Class Initialized
INFO - 2023-12-14 09:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:58:32 --> Controller Class Initialized
DEBUG - 2023-12-14 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 09:58:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 09:58:32 --> Final output sent to browser
DEBUG - 2023-12-14 09:58:32 --> Total execution time: 1.2859
INFO - 2023-12-14 09:58:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 09:58:38 --> Controller Class Initialized
INFO - 2023-12-14 09:58:38 --> Helper loaded: cookie_helper
INFO - 2023-12-14 09:59:23 --> Config Class Initialized
INFO - 2023-12-14 09:59:23 --> Hooks Class Initialized
DEBUG - 2023-12-14 09:59:23 --> UTF-8 Support Enabled
INFO - 2023-12-14 09:59:23 --> Utf8 Class Initialized
INFO - 2023-12-14 09:59:23 --> URI Class Initialized
INFO - 2023-12-14 09:59:23 --> Router Class Initialized
INFO - 2023-12-14 09:59:23 --> Output Class Initialized
INFO - 2023-12-14 09:59:23 --> Security Class Initialized
DEBUG - 2023-12-14 09:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 09:59:23 --> Input Class Initialized
INFO - 2023-12-14 09:59:23 --> Language Class Initialized
INFO - 2023-12-14 09:59:23 --> Language Class Initialized
INFO - 2023-12-14 09:59:23 --> Config Class Initialized
INFO - 2023-12-14 09:59:23 --> Loader Class Initialized
INFO - 2023-12-14 09:59:23 --> Helper loaded: url_helper
INFO - 2023-12-14 09:59:23 --> Helper loaded: file_helper
INFO - 2023-12-14 09:59:23 --> Helper loaded: form_helper
INFO - 2023-12-14 09:59:23 --> Helper loaded: my_helper
INFO - 2023-12-14 09:59:24 --> Database Driver Class Initialized
INFO - 2023-12-14 10:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:00:18 --> Controller Class Initialized
INFO - 2023-12-14 10:00:54 --> Config Class Initialized
INFO - 2023-12-14 10:00:54 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:00:54 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:00:54 --> Utf8 Class Initialized
INFO - 2023-12-14 10:00:54 --> URI Class Initialized
DEBUG - 2023-12-14 10:00:54 --> No URI present. Default controller set.
INFO - 2023-12-14 10:00:54 --> Router Class Initialized
INFO - 2023-12-14 10:00:54 --> Output Class Initialized
INFO - 2023-12-14 10:00:54 --> Security Class Initialized
DEBUG - 2023-12-14 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:00:54 --> Input Class Initialized
INFO - 2023-12-14 10:00:54 --> Language Class Initialized
INFO - 2023-12-14 10:00:54 --> Language Class Initialized
INFO - 2023-12-14 10:00:54 --> Config Class Initialized
INFO - 2023-12-14 10:00:54 --> Loader Class Initialized
INFO - 2023-12-14 10:00:54 --> Helper loaded: url_helper
INFO - 2023-12-14 10:00:54 --> Helper loaded: file_helper
INFO - 2023-12-14 10:00:54 --> Helper loaded: form_helper
INFO - 2023-12-14 10:00:54 --> Helper loaded: my_helper
INFO - 2023-12-14 10:00:55 --> Database Driver Class Initialized
INFO - 2023-12-14 10:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:00:55 --> Controller Class Initialized
INFO - 2023-12-14 10:00:55 --> Config Class Initialized
INFO - 2023-12-14 10:00:55 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:00:55 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:00:55 --> Utf8 Class Initialized
INFO - 2023-12-14 10:00:55 --> URI Class Initialized
INFO - 2023-12-14 10:00:55 --> Router Class Initialized
INFO - 2023-12-14 10:00:55 --> Output Class Initialized
INFO - 2023-12-14 10:00:55 --> Security Class Initialized
DEBUG - 2023-12-14 10:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:00:55 --> Input Class Initialized
INFO - 2023-12-14 10:00:55 --> Language Class Initialized
INFO - 2023-12-14 10:00:55 --> Language Class Initialized
INFO - 2023-12-14 10:00:55 --> Config Class Initialized
INFO - 2023-12-14 10:00:55 --> Loader Class Initialized
INFO - 2023-12-14 10:00:55 --> Helper loaded: url_helper
INFO - 2023-12-14 10:00:55 --> Helper loaded: file_helper
INFO - 2023-12-14 10:00:55 --> Helper loaded: form_helper
INFO - 2023-12-14 10:00:55 --> Helper loaded: my_helper
INFO - 2023-12-14 10:00:56 --> Database Driver Class Initialized
INFO - 2023-12-14 10:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:00:56 --> Controller Class Initialized
DEBUG - 2023-12-14 10:00:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 10:00:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:00:56 --> Final output sent to browser
DEBUG - 2023-12-14 10:00:56 --> Total execution time: 0.9195
INFO - 2023-12-14 10:01:03 --> Config Class Initialized
INFO - 2023-12-14 10:01:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:03 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:03 --> URI Class Initialized
INFO - 2023-12-14 10:01:03 --> Router Class Initialized
INFO - 2023-12-14 10:01:03 --> Output Class Initialized
INFO - 2023-12-14 10:01:03 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:03 --> Input Class Initialized
INFO - 2023-12-14 10:01:03 --> Language Class Initialized
INFO - 2023-12-14 10:01:03 --> Language Class Initialized
INFO - 2023-12-14 10:01:03 --> Config Class Initialized
INFO - 2023-12-14 10:01:03 --> Loader Class Initialized
INFO - 2023-12-14 10:01:03 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:03 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:03 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:03 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:03 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:04 --> Controller Class Initialized
INFO - 2023-12-14 10:01:04 --> Helper loaded: cookie_helper
INFO - 2023-12-14 10:01:04 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:04 --> Total execution time: 1.1975
INFO - 2023-12-14 10:01:04 --> Config Class Initialized
INFO - 2023-12-14 10:01:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:04 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:04 --> URI Class Initialized
INFO - 2023-12-14 10:01:04 --> Router Class Initialized
INFO - 2023-12-14 10:01:04 --> Output Class Initialized
INFO - 2023-12-14 10:01:04 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:04 --> Input Class Initialized
INFO - 2023-12-14 10:01:04 --> Language Class Initialized
INFO - 2023-12-14 10:01:04 --> Language Class Initialized
INFO - 2023-12-14 10:01:04 --> Config Class Initialized
INFO - 2023-12-14 10:01:04 --> Loader Class Initialized
INFO - 2023-12-14 10:01:04 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:04 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:05 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:05 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:05 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:05 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 10:01:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:05 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:05 --> Total execution time: 1.1830
INFO - 2023-12-14 10:01:08 --> Config Class Initialized
INFO - 2023-12-14 10:01:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:08 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:08 --> URI Class Initialized
INFO - 2023-12-14 10:01:08 --> Router Class Initialized
INFO - 2023-12-14 10:01:08 --> Output Class Initialized
INFO - 2023-12-14 10:01:08 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:08 --> Input Class Initialized
INFO - 2023-12-14 10:01:08 --> Language Class Initialized
INFO - 2023-12-14 10:01:09 --> Language Class Initialized
INFO - 2023-12-14 10:01:09 --> Config Class Initialized
INFO - 2023-12-14 10:01:09 --> Loader Class Initialized
INFO - 2023-12-14 10:01:09 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:09 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:09 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:09 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:09 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:09 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 10:01:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:09 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:09 --> Total execution time: 1.2781
INFO - 2023-12-14 10:01:22 --> Config Class Initialized
INFO - 2023-12-14 10:01:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:22 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:22 --> URI Class Initialized
INFO - 2023-12-14 10:01:23 --> Router Class Initialized
INFO - 2023-12-14 10:01:23 --> Output Class Initialized
INFO - 2023-12-14 10:01:23 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:23 --> Input Class Initialized
INFO - 2023-12-14 10:01:23 --> Language Class Initialized
INFO - 2023-12-14 10:01:23 --> Language Class Initialized
INFO - 2023-12-14 10:01:23 --> Config Class Initialized
INFO - 2023-12-14 10:01:23 --> Loader Class Initialized
INFO - 2023-12-14 10:01:23 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:23 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:23 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:23 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:23 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:23 --> Controller Class Initialized
INFO - 2023-12-14 10:01:23 --> Helper loaded: cookie_helper
INFO - 2023-12-14 10:01:23 --> Config Class Initialized
INFO - 2023-12-14 10:01:23 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:23 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:23 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:23 --> URI Class Initialized
INFO - 2023-12-14 10:01:23 --> Router Class Initialized
INFO - 2023-12-14 10:01:23 --> Output Class Initialized
INFO - 2023-12-14 10:01:23 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:23 --> Input Class Initialized
INFO - 2023-12-14 10:01:23 --> Language Class Initialized
INFO - 2023-12-14 10:01:24 --> Language Class Initialized
INFO - 2023-12-14 10:01:24 --> Config Class Initialized
INFO - 2023-12-14 10:01:24 --> Loader Class Initialized
INFO - 2023-12-14 10:01:24 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:24 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:24 --> Controller Class Initialized
INFO - 2023-12-14 10:01:24 --> Config Class Initialized
INFO - 2023-12-14 10:01:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:24 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:24 --> URI Class Initialized
INFO - 2023-12-14 10:01:24 --> Router Class Initialized
INFO - 2023-12-14 10:01:24 --> Output Class Initialized
INFO - 2023-12-14 10:01:24 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:24 --> Input Class Initialized
INFO - 2023-12-14 10:01:24 --> Language Class Initialized
INFO - 2023-12-14 10:01:24 --> Language Class Initialized
INFO - 2023-12-14 10:01:24 --> Config Class Initialized
INFO - 2023-12-14 10:01:24 --> Loader Class Initialized
INFO - 2023-12-14 10:01:24 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:24 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:24 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:25 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 10:01:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:25 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:25 --> Total execution time: 0.6821
INFO - 2023-12-14 10:01:29 --> Config Class Initialized
INFO - 2023-12-14 10:01:29 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:29 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:29 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:29 --> URI Class Initialized
INFO - 2023-12-14 10:01:29 --> Router Class Initialized
INFO - 2023-12-14 10:01:29 --> Output Class Initialized
INFO - 2023-12-14 10:01:29 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:29 --> Input Class Initialized
INFO - 2023-12-14 10:01:29 --> Language Class Initialized
INFO - 2023-12-14 10:01:29 --> Language Class Initialized
INFO - 2023-12-14 10:01:29 --> Config Class Initialized
INFO - 2023-12-14 10:01:29 --> Loader Class Initialized
INFO - 2023-12-14 10:01:29 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:29 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:29 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:29 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:29 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:29 --> Controller Class Initialized
INFO - 2023-12-14 10:01:30 --> Helper loaded: cookie_helper
INFO - 2023-12-14 10:01:30 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:30 --> Total execution time: 0.6090
INFO - 2023-12-14 10:01:30 --> Config Class Initialized
INFO - 2023-12-14 10:01:30 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:30 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:30 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:30 --> URI Class Initialized
INFO - 2023-12-14 10:01:30 --> Router Class Initialized
INFO - 2023-12-14 10:01:30 --> Output Class Initialized
INFO - 2023-12-14 10:01:30 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:30 --> Input Class Initialized
INFO - 2023-12-14 10:01:30 --> Language Class Initialized
INFO - 2023-12-14 10:01:30 --> Language Class Initialized
INFO - 2023-12-14 10:01:30 --> Config Class Initialized
INFO - 2023-12-14 10:01:30 --> Loader Class Initialized
INFO - 2023-12-14 10:01:30 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:30 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:30 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:30 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:30 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:30 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 10:01:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:30 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:30 --> Total execution time: 0.6462
INFO - 2023-12-14 10:01:32 --> Config Class Initialized
INFO - 2023-12-14 10:01:32 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:32 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:32 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:32 --> URI Class Initialized
INFO - 2023-12-14 10:01:32 --> Router Class Initialized
INFO - 2023-12-14 10:01:32 --> Output Class Initialized
INFO - 2023-12-14 10:01:32 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:32 --> Input Class Initialized
INFO - 2023-12-14 10:01:32 --> Language Class Initialized
INFO - 2023-12-14 10:01:32 --> Language Class Initialized
INFO - 2023-12-14 10:01:32 --> Config Class Initialized
INFO - 2023-12-14 10:01:32 --> Loader Class Initialized
INFO - 2023-12-14 10:01:32 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:32 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:32 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:32 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:33 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:33 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 10:01:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:33 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:33 --> Total execution time: 0.7689
INFO - 2023-12-14 10:01:34 --> Config Class Initialized
INFO - 2023-12-14 10:01:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:34 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:34 --> URI Class Initialized
INFO - 2023-12-14 10:01:34 --> Router Class Initialized
INFO - 2023-12-14 10:01:34 --> Output Class Initialized
INFO - 2023-12-14 10:01:34 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:34 --> Input Class Initialized
INFO - 2023-12-14 10:01:34 --> Language Class Initialized
INFO - 2023-12-14 10:01:34 --> Language Class Initialized
INFO - 2023-12-14 10:01:34 --> Config Class Initialized
INFO - 2023-12-14 10:01:34 --> Loader Class Initialized
INFO - 2023-12-14 10:01:34 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:34 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:34 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:34 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:34 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:35 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 10:01:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:01:35 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:35 --> Total execution time: 0.7907
INFO - 2023-12-14 10:01:36 --> Config Class Initialized
INFO - 2023-12-14 10:01:36 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:36 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:36 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:36 --> URI Class Initialized
INFO - 2023-12-14 10:01:36 --> Router Class Initialized
INFO - 2023-12-14 10:01:36 --> Output Class Initialized
INFO - 2023-12-14 10:01:36 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:36 --> Input Class Initialized
INFO - 2023-12-14 10:01:36 --> Language Class Initialized
INFO - 2023-12-14 10:01:36 --> Language Class Initialized
INFO - 2023-12-14 10:01:36 --> Config Class Initialized
INFO - 2023-12-14 10:01:36 --> Loader Class Initialized
INFO - 2023-12-14 10:01:36 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:36 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:36 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:36 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:36 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:37 --> Controller Class Initialized
INFO - 2023-12-14 10:01:37 --> Final output sent to browser
DEBUG - 2023-12-14 10:01:37 --> Total execution time: 0.7061
INFO - 2023-12-14 10:01:40 --> Config Class Initialized
INFO - 2023-12-14 10:01:40 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:01:40 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:01:40 --> Utf8 Class Initialized
INFO - 2023-12-14 10:01:40 --> URI Class Initialized
INFO - 2023-12-14 10:01:40 --> Router Class Initialized
INFO - 2023-12-14 10:01:40 --> Output Class Initialized
INFO - 2023-12-14 10:01:40 --> Security Class Initialized
DEBUG - 2023-12-14 10:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:01:40 --> Input Class Initialized
INFO - 2023-12-14 10:01:40 --> Language Class Initialized
INFO - 2023-12-14 10:01:40 --> Language Class Initialized
INFO - 2023-12-14 10:01:40 --> Config Class Initialized
INFO - 2023-12-14 10:01:40 --> Loader Class Initialized
INFO - 2023-12-14 10:01:40 --> Helper loaded: url_helper
INFO - 2023-12-14 10:01:40 --> Helper loaded: file_helper
INFO - 2023-12-14 10:01:40 --> Helper loaded: form_helper
INFO - 2023-12-14 10:01:40 --> Helper loaded: my_helper
INFO - 2023-12-14 10:01:41 --> Database Driver Class Initialized
INFO - 2023-12-14 10:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:01:41 --> Controller Class Initialized
DEBUG - 2023-12-14 10:01:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:06:19 --> Config Class Initialized
INFO - 2023-12-14 10:06:19 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:06:19 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:06:19 --> Utf8 Class Initialized
INFO - 2023-12-14 10:06:19 --> URI Class Initialized
INFO - 2023-12-14 10:06:19 --> Router Class Initialized
INFO - 2023-12-14 10:06:19 --> Output Class Initialized
INFO - 2023-12-14 10:06:19 --> Security Class Initialized
DEBUG - 2023-12-14 10:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:06:19 --> Input Class Initialized
INFO - 2023-12-14 10:06:19 --> Language Class Initialized
INFO - 2023-12-14 10:06:19 --> Language Class Initialized
INFO - 2023-12-14 10:06:19 --> Config Class Initialized
INFO - 2023-12-14 10:06:19 --> Loader Class Initialized
INFO - 2023-12-14 10:06:19 --> Helper loaded: url_helper
INFO - 2023-12-14 10:06:19 --> Helper loaded: file_helper
INFO - 2023-12-14 10:06:19 --> Helper loaded: form_helper
INFO - 2023-12-14 10:06:19 --> Helper loaded: my_helper
INFO - 2023-12-14 10:06:20 --> Database Driver Class Initialized
INFO - 2023-12-14 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:06:20 --> Controller Class Initialized
DEBUG - 2023-12-14 10:06:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:07:53 --> Final output sent to browser
DEBUG - 2023-12-14 10:07:53 --> Total execution time: 94.1513
INFO - 2023-12-14 10:14:04 --> Config Class Initialized
INFO - 2023-12-14 10:14:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:14:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:14:04 --> Utf8 Class Initialized
INFO - 2023-12-14 10:14:05 --> URI Class Initialized
INFO - 2023-12-14 10:14:05 --> Router Class Initialized
INFO - 2023-12-14 10:14:05 --> Output Class Initialized
INFO - 2023-12-14 10:14:05 --> Security Class Initialized
DEBUG - 2023-12-14 10:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:14:05 --> Input Class Initialized
INFO - 2023-12-14 10:14:05 --> Language Class Initialized
INFO - 2023-12-14 10:14:05 --> Language Class Initialized
INFO - 2023-12-14 10:14:05 --> Config Class Initialized
INFO - 2023-12-14 10:14:05 --> Loader Class Initialized
INFO - 2023-12-14 10:14:05 --> Helper loaded: url_helper
INFO - 2023-12-14 10:14:05 --> Helper loaded: file_helper
INFO - 2023-12-14 10:14:06 --> Helper loaded: form_helper
INFO - 2023-12-14 10:14:06 --> Helper loaded: my_helper
INFO - 2023-12-14 10:14:06 --> Database Driver Class Initialized
INFO - 2023-12-14 10:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:14:06 --> Controller Class Initialized
ERROR - 2023-12-14 10:14:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-14 10:14:08 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-14 10:14:24 --> Config Class Initialized
INFO - 2023-12-14 10:14:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:14:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:14:25 --> Utf8 Class Initialized
INFO - 2023-12-14 10:14:25 --> URI Class Initialized
INFO - 2023-12-14 10:14:25 --> Router Class Initialized
INFO - 2023-12-14 10:14:25 --> Output Class Initialized
INFO - 2023-12-14 10:14:25 --> Security Class Initialized
DEBUG - 2023-12-14 10:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:14:25 --> Input Class Initialized
INFO - 2023-12-14 10:14:25 --> Language Class Initialized
INFO - 2023-12-14 10:14:25 --> Language Class Initialized
INFO - 2023-12-14 10:14:25 --> Config Class Initialized
INFO - 2023-12-14 10:14:25 --> Loader Class Initialized
INFO - 2023-12-14 10:14:25 --> Helper loaded: url_helper
INFO - 2023-12-14 10:14:25 --> Helper loaded: file_helper
INFO - 2023-12-14 10:14:25 --> Helper loaded: form_helper
INFO - 2023-12-14 10:14:25 --> Helper loaded: my_helper
INFO - 2023-12-14 10:14:26 --> Database Driver Class Initialized
INFO - 2023-12-14 10:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:14:26 --> Controller Class Initialized
DEBUG - 2023-12-14 10:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 10:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:14:26 --> Final output sent to browser
DEBUG - 2023-12-14 10:14:26 --> Total execution time: 1.5730
INFO - 2023-12-14 10:14:29 --> Config Class Initialized
INFO - 2023-12-14 10:14:29 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:14:29 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:14:29 --> Utf8 Class Initialized
INFO - 2023-12-14 10:14:29 --> URI Class Initialized
INFO - 2023-12-14 10:14:29 --> Router Class Initialized
INFO - 2023-12-14 10:14:29 --> Output Class Initialized
INFO - 2023-12-14 10:14:29 --> Security Class Initialized
DEBUG - 2023-12-14 10:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:14:30 --> Input Class Initialized
INFO - 2023-12-14 10:14:30 --> Language Class Initialized
INFO - 2023-12-14 10:14:30 --> Language Class Initialized
INFO - 2023-12-14 10:14:30 --> Config Class Initialized
INFO - 2023-12-14 10:14:30 --> Loader Class Initialized
INFO - 2023-12-14 10:14:30 --> Helper loaded: url_helper
INFO - 2023-12-14 10:14:30 --> Helper loaded: file_helper
INFO - 2023-12-14 10:14:30 --> Helper loaded: form_helper
INFO - 2023-12-14 10:14:30 --> Helper loaded: my_helper
INFO - 2023-12-14 10:14:30 --> Database Driver Class Initialized
INFO - 2023-12-14 10:14:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:14:31 --> Controller Class Initialized
INFO - 2023-12-14 10:14:31 --> Final output sent to browser
DEBUG - 2023-12-14 10:14:31 --> Total execution time: 1.8235
INFO - 2023-12-14 10:14:39 --> Config Class Initialized
INFO - 2023-12-14 10:14:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:14:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:14:39 --> Utf8 Class Initialized
INFO - 2023-12-14 10:14:39 --> URI Class Initialized
INFO - 2023-12-14 10:14:40 --> Router Class Initialized
INFO - 2023-12-14 10:14:40 --> Output Class Initialized
INFO - 2023-12-14 10:14:40 --> Security Class Initialized
DEBUG - 2023-12-14 10:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:14:40 --> Input Class Initialized
INFO - 2023-12-14 10:14:40 --> Language Class Initialized
INFO - 2023-12-14 10:14:40 --> Language Class Initialized
INFO - 2023-12-14 10:14:40 --> Config Class Initialized
INFO - 2023-12-14 10:14:40 --> Loader Class Initialized
INFO - 2023-12-14 10:14:40 --> Helper loaded: url_helper
INFO - 2023-12-14 10:14:40 --> Helper loaded: file_helper
INFO - 2023-12-14 10:14:41 --> Helper loaded: form_helper
INFO - 2023-12-14 10:14:41 --> Helper loaded: my_helper
INFO - 2023-12-14 10:14:41 --> Database Driver Class Initialized
INFO - 2023-12-14 10:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:14:41 --> Controller Class Initialized
DEBUG - 2023-12-14 10:14:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:16:49 --> Config Class Initialized
INFO - 2023-12-14 10:16:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:16:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:16:49 --> Utf8 Class Initialized
INFO - 2023-12-14 10:16:49 --> URI Class Initialized
INFO - 2023-12-14 10:16:50 --> Router Class Initialized
INFO - 2023-12-14 10:16:50 --> Output Class Initialized
INFO - 2023-12-14 10:16:50 --> Security Class Initialized
DEBUG - 2023-12-14 10:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:16:50 --> Input Class Initialized
INFO - 2023-12-14 10:16:50 --> Language Class Initialized
INFO - 2023-12-14 10:16:50 --> Language Class Initialized
INFO - 2023-12-14 10:16:50 --> Config Class Initialized
INFO - 2023-12-14 10:16:50 --> Loader Class Initialized
INFO - 2023-12-14 10:16:50 --> Helper loaded: url_helper
INFO - 2023-12-14 10:16:50 --> Helper loaded: file_helper
INFO - 2023-12-14 10:16:50 --> Helper loaded: form_helper
INFO - 2023-12-14 10:16:50 --> Helper loaded: my_helper
INFO - 2023-12-14 10:16:51 --> Database Driver Class Initialized
INFO - 2023-12-14 10:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:16:51 --> Controller Class Initialized
DEBUG - 2023-12-14 10:16:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:18:36 --> Final output sent to browser
DEBUG - 2023-12-14 10:18:36 --> Total execution time: 107.1017
INFO - 2023-12-14 10:22:29 --> Config Class Initialized
INFO - 2023-12-14 10:22:29 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:22:29 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:22:29 --> Utf8 Class Initialized
INFO - 2023-12-14 10:22:29 --> URI Class Initialized
INFO - 2023-12-14 10:22:30 --> Router Class Initialized
INFO - 2023-12-14 10:22:30 --> Output Class Initialized
INFO - 2023-12-14 10:22:30 --> Security Class Initialized
DEBUG - 2023-12-14 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:22:30 --> Input Class Initialized
INFO - 2023-12-14 10:22:30 --> Language Class Initialized
INFO - 2023-12-14 10:22:31 --> Language Class Initialized
INFO - 2023-12-14 10:22:31 --> Config Class Initialized
INFO - 2023-12-14 10:22:31 --> Loader Class Initialized
INFO - 2023-12-14 10:22:31 --> Helper loaded: url_helper
INFO - 2023-12-14 10:22:31 --> Helper loaded: file_helper
INFO - 2023-12-14 10:22:31 --> Helper loaded: form_helper
INFO - 2023-12-14 10:22:31 --> Helper loaded: my_helper
INFO - 2023-12-14 10:22:31 --> Database Driver Class Initialized
INFO - 2023-12-14 10:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:22:31 --> Controller Class Initialized
ERROR - 2023-12-14 10:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-14 10:22:32 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-14 10:22:36 --> Config Class Initialized
INFO - 2023-12-14 10:22:36 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:22:36 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:22:36 --> Utf8 Class Initialized
INFO - 2023-12-14 10:22:36 --> URI Class Initialized
INFO - 2023-12-14 10:22:36 --> Router Class Initialized
INFO - 2023-12-14 10:22:36 --> Output Class Initialized
INFO - 2023-12-14 10:22:36 --> Security Class Initialized
DEBUG - 2023-12-14 10:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:22:36 --> Input Class Initialized
INFO - 2023-12-14 10:22:36 --> Language Class Initialized
INFO - 2023-12-14 10:22:37 --> Language Class Initialized
INFO - 2023-12-14 10:22:37 --> Config Class Initialized
INFO - 2023-12-14 10:22:37 --> Loader Class Initialized
INFO - 2023-12-14 10:22:37 --> Helper loaded: url_helper
INFO - 2023-12-14 10:22:37 --> Helper loaded: file_helper
INFO - 2023-12-14 10:22:37 --> Helper loaded: form_helper
INFO - 2023-12-14 10:22:37 --> Helper loaded: my_helper
INFO - 2023-12-14 10:22:37 --> Database Driver Class Initialized
INFO - 2023-12-14 10:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:22:37 --> Controller Class Initialized
DEBUG - 2023-12-14 10:22:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 10:22:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:22:37 --> Final output sent to browser
DEBUG - 2023-12-14 10:22:37 --> Total execution time: 1.3950
INFO - 2023-12-14 10:22:39 --> Config Class Initialized
INFO - 2023-12-14 10:22:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:22:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:22:39 --> Utf8 Class Initialized
INFO - 2023-12-14 10:22:39 --> URI Class Initialized
INFO - 2023-12-14 10:22:39 --> Router Class Initialized
INFO - 2023-12-14 10:22:39 --> Output Class Initialized
INFO - 2023-12-14 10:22:39 --> Security Class Initialized
DEBUG - 2023-12-14 10:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:22:39 --> Input Class Initialized
INFO - 2023-12-14 10:22:39 --> Language Class Initialized
INFO - 2023-12-14 10:22:40 --> Language Class Initialized
INFO - 2023-12-14 10:22:40 --> Config Class Initialized
INFO - 2023-12-14 10:22:40 --> Loader Class Initialized
INFO - 2023-12-14 10:22:40 --> Helper loaded: url_helper
INFO - 2023-12-14 10:22:40 --> Helper loaded: file_helper
INFO - 2023-12-14 10:22:40 --> Helper loaded: form_helper
INFO - 2023-12-14 10:22:40 --> Helper loaded: my_helper
INFO - 2023-12-14 10:22:40 --> Database Driver Class Initialized
INFO - 2023-12-14 10:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:22:40 --> Controller Class Initialized
INFO - 2023-12-14 10:22:40 --> Final output sent to browser
DEBUG - 2023-12-14 10:22:40 --> Total execution time: 1.0580
INFO - 2023-12-14 10:22:46 --> Config Class Initialized
INFO - 2023-12-14 10:22:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:22:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:22:46 --> Utf8 Class Initialized
INFO - 2023-12-14 10:22:46 --> URI Class Initialized
INFO - 2023-12-14 10:22:46 --> Router Class Initialized
INFO - 2023-12-14 10:22:46 --> Output Class Initialized
INFO - 2023-12-14 10:22:46 --> Security Class Initialized
DEBUG - 2023-12-14 10:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:22:46 --> Input Class Initialized
INFO - 2023-12-14 10:22:46 --> Language Class Initialized
INFO - 2023-12-14 10:22:46 --> Language Class Initialized
INFO - 2023-12-14 10:22:46 --> Config Class Initialized
INFO - 2023-12-14 10:22:46 --> Loader Class Initialized
INFO - 2023-12-14 10:22:46 --> Helper loaded: url_helper
INFO - 2023-12-14 10:22:46 --> Helper loaded: file_helper
INFO - 2023-12-14 10:22:46 --> Helper loaded: form_helper
INFO - 2023-12-14 10:22:46 --> Helper loaded: my_helper
INFO - 2023-12-14 10:22:47 --> Database Driver Class Initialized
INFO - 2023-12-14 10:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:22:47 --> Controller Class Initialized
DEBUG - 2023-12-14 10:22:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:23:51 --> Final output sent to browser
DEBUG - 2023-12-14 10:23:51 --> Total execution time: 65.1160
INFO - 2023-12-14 10:28:14 --> Config Class Initialized
INFO - 2023-12-14 10:28:14 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:28:14 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:28:14 --> Utf8 Class Initialized
INFO - 2023-12-14 10:28:14 --> URI Class Initialized
INFO - 2023-12-14 10:28:14 --> Router Class Initialized
INFO - 2023-12-14 10:28:14 --> Output Class Initialized
INFO - 2023-12-14 10:28:14 --> Security Class Initialized
DEBUG - 2023-12-14 10:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:28:14 --> Input Class Initialized
INFO - 2023-12-14 10:28:14 --> Language Class Initialized
INFO - 2023-12-14 10:28:14 --> Language Class Initialized
INFO - 2023-12-14 10:28:14 --> Config Class Initialized
INFO - 2023-12-14 10:28:14 --> Loader Class Initialized
INFO - 2023-12-14 10:28:14 --> Helper loaded: url_helper
INFO - 2023-12-14 10:28:14 --> Helper loaded: file_helper
INFO - 2023-12-14 10:28:14 --> Helper loaded: form_helper
INFO - 2023-12-14 10:28:14 --> Helper loaded: my_helper
INFO - 2023-12-14 10:28:14 --> Database Driver Class Initialized
INFO - 2023-12-14 10:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:28:15 --> Controller Class Initialized
ERROR - 2023-12-14 10:28:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'contribution. You also possess a good understanding of sub-topic oppression. How' at line 1 - Invalid query: UPDATE t_nilai_cat SET tasm = '20231', nilai = 'You have greatly improved on the topic of Global Conflict, and the United Nations' contribution. You also possess a good understanding of sub-topic oppression. However, you should improve your understanding of topics of Social Injustice and Gender Inequality. I believe you can achieve enormous results in the future, Saffa!', nilai_mid = 'You already possess the ability to identify and understand conflict, gender inequality, and social injustice. Howeever, you need to improve more in  application especially in writing the explanation. I believe you can achieve a way better result in the future.' WHERE id_guru_mapel = '2' AND id_mapel_kd = '9' AND id_siswa = '9' AND jenis = 'c'
INFO - 2023-12-14 10:28:15 --> Language file loaded: language/english/db_lang.php
INFO - 2023-12-14 10:28:18 --> Config Class Initialized
INFO - 2023-12-14 10:28:18 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:28:18 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:28:18 --> Utf8 Class Initialized
INFO - 2023-12-14 10:28:18 --> URI Class Initialized
INFO - 2023-12-14 10:28:18 --> Router Class Initialized
INFO - 2023-12-14 10:28:18 --> Output Class Initialized
INFO - 2023-12-14 10:28:18 --> Security Class Initialized
DEBUG - 2023-12-14 10:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:28:18 --> Input Class Initialized
INFO - 2023-12-14 10:28:18 --> Language Class Initialized
INFO - 2023-12-14 10:28:18 --> Language Class Initialized
INFO - 2023-12-14 10:28:18 --> Config Class Initialized
INFO - 2023-12-14 10:28:18 --> Loader Class Initialized
INFO - 2023-12-14 10:28:18 --> Helper loaded: url_helper
INFO - 2023-12-14 10:28:18 --> Helper loaded: file_helper
INFO - 2023-12-14 10:28:18 --> Helper loaded: form_helper
INFO - 2023-12-14 10:28:18 --> Helper loaded: my_helper
INFO - 2023-12-14 10:28:19 --> Database Driver Class Initialized
INFO - 2023-12-14 10:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:28:19 --> Controller Class Initialized
DEBUG - 2023-12-14 10:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 10:28:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:28:19 --> Final output sent to browser
DEBUG - 2023-12-14 10:28:19 --> Total execution time: 0.6218
INFO - 2023-12-14 10:28:21 --> Config Class Initialized
INFO - 2023-12-14 10:28:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:28:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:28:21 --> Utf8 Class Initialized
INFO - 2023-12-14 10:28:21 --> URI Class Initialized
INFO - 2023-12-14 10:28:21 --> Router Class Initialized
INFO - 2023-12-14 10:28:21 --> Output Class Initialized
INFO - 2023-12-14 10:28:21 --> Security Class Initialized
DEBUG - 2023-12-14 10:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:28:21 --> Input Class Initialized
INFO - 2023-12-14 10:28:21 --> Language Class Initialized
INFO - 2023-12-14 10:28:21 --> Language Class Initialized
INFO - 2023-12-14 10:28:21 --> Config Class Initialized
INFO - 2023-12-14 10:28:21 --> Loader Class Initialized
INFO - 2023-12-14 10:28:21 --> Helper loaded: url_helper
INFO - 2023-12-14 10:28:21 --> Helper loaded: file_helper
INFO - 2023-12-14 10:28:21 --> Helper loaded: form_helper
INFO - 2023-12-14 10:28:21 --> Helper loaded: my_helper
INFO - 2023-12-14 10:28:21 --> Database Driver Class Initialized
INFO - 2023-12-14 10:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:28:21 --> Controller Class Initialized
INFO - 2023-12-14 10:28:21 --> Final output sent to browser
DEBUG - 2023-12-14 10:28:21 --> Total execution time: 0.8884
INFO - 2023-12-14 10:28:27 --> Config Class Initialized
INFO - 2023-12-14 10:28:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:28:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:28:27 --> Utf8 Class Initialized
INFO - 2023-12-14 10:28:27 --> URI Class Initialized
INFO - 2023-12-14 10:28:27 --> Router Class Initialized
INFO - 2023-12-14 10:28:27 --> Output Class Initialized
INFO - 2023-12-14 10:28:27 --> Security Class Initialized
DEBUG - 2023-12-14 10:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:28:27 --> Input Class Initialized
INFO - 2023-12-14 10:28:27 --> Language Class Initialized
INFO - 2023-12-14 10:28:27 --> Language Class Initialized
INFO - 2023-12-14 10:28:27 --> Config Class Initialized
INFO - 2023-12-14 10:28:27 --> Loader Class Initialized
INFO - 2023-12-14 10:28:27 --> Helper loaded: url_helper
INFO - 2023-12-14 10:28:27 --> Helper loaded: file_helper
INFO - 2023-12-14 10:28:27 --> Helper loaded: form_helper
INFO - 2023-12-14 10:28:27 --> Helper loaded: my_helper
INFO - 2023-12-14 10:28:27 --> Database Driver Class Initialized
INFO - 2023-12-14 10:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:28:27 --> Controller Class Initialized
DEBUG - 2023-12-14 10:28:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:29:53 --> Final output sent to browser
DEBUG - 2023-12-14 10:29:53 --> Total execution time: 86.4737
INFO - 2023-12-14 10:30:15 --> Config Class Initialized
INFO - 2023-12-14 10:30:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:30:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:30:15 --> Utf8 Class Initialized
INFO - 2023-12-14 10:30:15 --> URI Class Initialized
INFO - 2023-12-14 10:30:15 --> Router Class Initialized
INFO - 2023-12-14 10:30:15 --> Output Class Initialized
INFO - 2023-12-14 10:30:15 --> Security Class Initialized
DEBUG - 2023-12-14 10:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:30:15 --> Input Class Initialized
INFO - 2023-12-14 10:30:15 --> Language Class Initialized
INFO - 2023-12-14 10:30:15 --> Language Class Initialized
INFO - 2023-12-14 10:30:15 --> Config Class Initialized
INFO - 2023-12-14 10:30:15 --> Loader Class Initialized
INFO - 2023-12-14 10:30:15 --> Helper loaded: url_helper
INFO - 2023-12-14 10:30:15 --> Helper loaded: file_helper
INFO - 2023-12-14 10:30:15 --> Helper loaded: form_helper
INFO - 2023-12-14 10:30:15 --> Helper loaded: my_helper
INFO - 2023-12-14 10:30:15 --> Database Driver Class Initialized
INFO - 2023-12-14 10:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:30:15 --> Controller Class Initialized
DEBUG - 2023-12-14 10:30:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:31:32 --> Final output sent to browser
DEBUG - 2023-12-14 10:31:32 --> Total execution time: 76.8055
INFO - 2023-12-14 10:31:53 --> Config Class Initialized
INFO - 2023-12-14 10:31:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:31:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:31:53 --> Utf8 Class Initialized
INFO - 2023-12-14 10:31:53 --> URI Class Initialized
INFO - 2023-12-14 10:31:53 --> Router Class Initialized
INFO - 2023-12-14 10:31:53 --> Output Class Initialized
INFO - 2023-12-14 10:31:53 --> Security Class Initialized
DEBUG - 2023-12-14 10:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:31:53 --> Input Class Initialized
INFO - 2023-12-14 10:31:53 --> Language Class Initialized
INFO - 2023-12-14 10:31:53 --> Language Class Initialized
INFO - 2023-12-14 10:31:53 --> Config Class Initialized
INFO - 2023-12-14 10:31:53 --> Loader Class Initialized
INFO - 2023-12-14 10:31:53 --> Helper loaded: url_helper
INFO - 2023-12-14 10:31:54 --> Helper loaded: file_helper
INFO - 2023-12-14 10:31:54 --> Helper loaded: form_helper
INFO - 2023-12-14 10:31:54 --> Helper loaded: my_helper
INFO - 2023-12-14 10:31:54 --> Database Driver Class Initialized
INFO - 2023-12-14 10:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:31:54 --> Controller Class Initialized
DEBUG - 2023-12-14 10:31:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:34:01 --> Config Class Initialized
INFO - 2023-12-14 10:34:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:34:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:34:02 --> Utf8 Class Initialized
INFO - 2023-12-14 10:34:02 --> URI Class Initialized
INFO - 2023-12-14 10:34:02 --> Router Class Initialized
INFO - 2023-12-14 10:34:02 --> Output Class Initialized
INFO - 2023-12-14 10:34:02 --> Security Class Initialized
DEBUG - 2023-12-14 10:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:34:02 --> Input Class Initialized
INFO - 2023-12-14 10:34:02 --> Language Class Initialized
INFO - 2023-12-14 10:34:03 --> Language Class Initialized
INFO - 2023-12-14 10:34:03 --> Config Class Initialized
INFO - 2023-12-14 10:34:03 --> Loader Class Initialized
INFO - 2023-12-14 10:34:03 --> Helper loaded: url_helper
INFO - 2023-12-14 10:34:03 --> Helper loaded: file_helper
INFO - 2023-12-14 10:34:03 --> Helper loaded: form_helper
INFO - 2023-12-14 10:34:03 --> Helper loaded: my_helper
INFO - 2023-12-14 10:34:03 --> Database Driver Class Initialized
INFO - 2023-12-14 10:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:34:03 --> Controller Class Initialized
DEBUG - 2023-12-14 10:34:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:36:39 --> Config Class Initialized
INFO - 2023-12-14 10:36:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:36:40 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:36:40 --> Utf8 Class Initialized
INFO - 2023-12-14 10:36:40 --> URI Class Initialized
INFO - 2023-12-14 10:36:40 --> Router Class Initialized
INFO - 2023-12-14 10:36:40 --> Output Class Initialized
INFO - 2023-12-14 10:36:40 --> Security Class Initialized
DEBUG - 2023-12-14 10:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:36:40 --> Input Class Initialized
INFO - 2023-12-14 10:36:40 --> Language Class Initialized
INFO - 2023-12-14 10:36:40 --> Language Class Initialized
INFO - 2023-12-14 10:36:40 --> Config Class Initialized
INFO - 2023-12-14 10:36:40 --> Loader Class Initialized
INFO - 2023-12-14 10:36:41 --> Helper loaded: url_helper
INFO - 2023-12-14 10:36:41 --> Helper loaded: file_helper
INFO - 2023-12-14 10:36:41 --> Helper loaded: form_helper
INFO - 2023-12-14 10:36:41 --> Helper loaded: my_helper
INFO - 2023-12-14 10:36:41 --> Database Driver Class Initialized
INFO - 2023-12-14 10:36:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:36:41 --> Controller Class Initialized
DEBUG - 2023-12-14 10:36:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:55:27 --> Config Class Initialized
INFO - 2023-12-14 10:55:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:55:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:55:27 --> Utf8 Class Initialized
INFO - 2023-12-14 10:55:27 --> URI Class Initialized
INFO - 2023-12-14 10:55:27 --> Router Class Initialized
INFO - 2023-12-14 10:55:27 --> Output Class Initialized
INFO - 2023-12-14 10:55:27 --> Security Class Initialized
DEBUG - 2023-12-14 10:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:55:27 --> Input Class Initialized
INFO - 2023-12-14 10:55:27 --> Language Class Initialized
INFO - 2023-12-14 10:55:27 --> Language Class Initialized
INFO - 2023-12-14 10:55:27 --> Config Class Initialized
INFO - 2023-12-14 10:55:27 --> Loader Class Initialized
INFO - 2023-12-14 10:55:27 --> Helper loaded: url_helper
INFO - 2023-12-14 10:55:27 --> Helper loaded: file_helper
INFO - 2023-12-14 10:55:27 --> Helper loaded: form_helper
INFO - 2023-12-14 10:55:27 --> Helper loaded: my_helper
INFO - 2023-12-14 10:55:27 --> Database Driver Class Initialized
INFO - 2023-12-14 10:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:55:27 --> Controller Class Initialized
DEBUG - 2023-12-14 10:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 10:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 10:55:27 --> Final output sent to browser
DEBUG - 2023-12-14 10:55:27 --> Total execution time: 0.0596
INFO - 2023-12-14 10:55:33 --> Config Class Initialized
INFO - 2023-12-14 10:55:33 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:55:33 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:55:33 --> Utf8 Class Initialized
INFO - 2023-12-14 10:55:33 --> URI Class Initialized
INFO - 2023-12-14 10:55:33 --> Router Class Initialized
INFO - 2023-12-14 10:55:33 --> Output Class Initialized
INFO - 2023-12-14 10:55:33 --> Security Class Initialized
DEBUG - 2023-12-14 10:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:55:33 --> Input Class Initialized
INFO - 2023-12-14 10:55:33 --> Language Class Initialized
INFO - 2023-12-14 10:55:33 --> Language Class Initialized
INFO - 2023-12-14 10:55:33 --> Config Class Initialized
INFO - 2023-12-14 10:55:33 --> Loader Class Initialized
INFO - 2023-12-14 10:55:33 --> Helper loaded: url_helper
INFO - 2023-12-14 10:55:33 --> Helper loaded: file_helper
INFO - 2023-12-14 10:55:33 --> Helper loaded: form_helper
INFO - 2023-12-14 10:55:33 --> Helper loaded: my_helper
INFO - 2023-12-14 10:55:33 --> Database Driver Class Initialized
INFO - 2023-12-14 10:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:55:33 --> Controller Class Initialized
DEBUG - 2023-12-14 10:55:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:55:39 --> Final output sent to browser
DEBUG - 2023-12-14 10:55:39 --> Total execution time: 6.0879
INFO - 2023-12-14 10:56:24 --> Config Class Initialized
INFO - 2023-12-14 10:56:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 10:56:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 10:56:24 --> Utf8 Class Initialized
INFO - 2023-12-14 10:56:24 --> URI Class Initialized
INFO - 2023-12-14 10:56:24 --> Router Class Initialized
INFO - 2023-12-14 10:56:24 --> Output Class Initialized
INFO - 2023-12-14 10:56:24 --> Security Class Initialized
DEBUG - 2023-12-14 10:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 10:56:24 --> Input Class Initialized
INFO - 2023-12-14 10:56:24 --> Language Class Initialized
INFO - 2023-12-14 10:56:24 --> Language Class Initialized
INFO - 2023-12-14 10:56:24 --> Config Class Initialized
INFO - 2023-12-14 10:56:24 --> Loader Class Initialized
INFO - 2023-12-14 10:56:24 --> Helper loaded: url_helper
INFO - 2023-12-14 10:56:24 --> Helper loaded: file_helper
INFO - 2023-12-14 10:56:24 --> Helper loaded: form_helper
INFO - 2023-12-14 10:56:24 --> Helper loaded: my_helper
INFO - 2023-12-14 10:56:24 --> Database Driver Class Initialized
INFO - 2023-12-14 10:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 10:56:24 --> Controller Class Initialized
DEBUG - 2023-12-14 10:56:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 10:56:40 --> Final output sent to browser
DEBUG - 2023-12-14 10:56:40 --> Total execution time: 16.1609
INFO - 2023-12-14 11:01:37 --> Config Class Initialized
INFO - 2023-12-14 11:01:37 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:01:37 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:01:37 --> Utf8 Class Initialized
INFO - 2023-12-14 11:01:37 --> URI Class Initialized
INFO - 2023-12-14 11:01:37 --> Router Class Initialized
INFO - 2023-12-14 11:01:37 --> Output Class Initialized
INFO - 2023-12-14 11:01:37 --> Security Class Initialized
DEBUG - 2023-12-14 11:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:01:37 --> Input Class Initialized
INFO - 2023-12-14 11:01:37 --> Language Class Initialized
INFO - 2023-12-14 11:01:37 --> Language Class Initialized
INFO - 2023-12-14 11:01:37 --> Config Class Initialized
INFO - 2023-12-14 11:01:37 --> Loader Class Initialized
INFO - 2023-12-14 11:01:37 --> Helper loaded: url_helper
INFO - 2023-12-14 11:01:37 --> Helper loaded: file_helper
INFO - 2023-12-14 11:01:37 --> Helper loaded: form_helper
INFO - 2023-12-14 11:01:37 --> Helper loaded: my_helper
INFO - 2023-12-14 11:01:37 --> Database Driver Class Initialized
INFO - 2023-12-14 11:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:01:37 --> Controller Class Initialized
DEBUG - 2023-12-14 11:01:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:02:35 --> Final output sent to browser
DEBUG - 2023-12-14 11:02:35 --> Total execution time: 58.6659
INFO - 2023-12-14 11:03:07 --> Config Class Initialized
INFO - 2023-12-14 11:03:07 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:03:07 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:03:07 --> Utf8 Class Initialized
INFO - 2023-12-14 11:03:07 --> URI Class Initialized
INFO - 2023-12-14 11:03:07 --> Router Class Initialized
INFO - 2023-12-14 11:03:07 --> Output Class Initialized
INFO - 2023-12-14 11:03:07 --> Security Class Initialized
DEBUG - 2023-12-14 11:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:03:07 --> Input Class Initialized
INFO - 2023-12-14 11:03:07 --> Language Class Initialized
INFO - 2023-12-14 11:03:07 --> Language Class Initialized
INFO - 2023-12-14 11:03:07 --> Config Class Initialized
INFO - 2023-12-14 11:03:07 --> Loader Class Initialized
INFO - 2023-12-14 11:03:07 --> Helper loaded: url_helper
INFO - 2023-12-14 11:03:07 --> Helper loaded: file_helper
INFO - 2023-12-14 11:03:07 --> Helper loaded: form_helper
INFO - 2023-12-14 11:03:07 --> Helper loaded: my_helper
INFO - 2023-12-14 11:03:07 --> Database Driver Class Initialized
INFO - 2023-12-14 11:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:03:07 --> Controller Class Initialized
DEBUG - 2023-12-14 11:03:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:04:22 --> Final output sent to browser
DEBUG - 2023-12-14 11:04:22 --> Total execution time: 75.3817
INFO - 2023-12-14 11:07:02 --> Config Class Initialized
INFO - 2023-12-14 11:07:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:07:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:07:02 --> Utf8 Class Initialized
INFO - 2023-12-14 11:07:02 --> URI Class Initialized
INFO - 2023-12-14 11:07:02 --> Router Class Initialized
INFO - 2023-12-14 11:07:02 --> Output Class Initialized
INFO - 2023-12-14 11:07:02 --> Security Class Initialized
DEBUG - 2023-12-14 11:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:07:02 --> Input Class Initialized
INFO - 2023-12-14 11:07:02 --> Language Class Initialized
INFO - 2023-12-14 11:07:02 --> Language Class Initialized
INFO - 2023-12-14 11:07:02 --> Config Class Initialized
INFO - 2023-12-14 11:07:02 --> Loader Class Initialized
INFO - 2023-12-14 11:07:02 --> Helper loaded: url_helper
INFO - 2023-12-14 11:07:02 --> Helper loaded: file_helper
INFO - 2023-12-14 11:07:03 --> Helper loaded: form_helper
INFO - 2023-12-14 11:07:03 --> Helper loaded: my_helper
INFO - 2023-12-14 11:07:03 --> Database Driver Class Initialized
INFO - 2023-12-14 11:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:07:03 --> Controller Class Initialized
INFO - 2023-12-14 11:07:03 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:07:03 --> Config Class Initialized
INFO - 2023-12-14 11:07:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:07:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:07:03 --> Utf8 Class Initialized
INFO - 2023-12-14 11:07:03 --> URI Class Initialized
INFO - 2023-12-14 11:07:03 --> Router Class Initialized
INFO - 2023-12-14 11:07:03 --> Output Class Initialized
INFO - 2023-12-14 11:07:03 --> Security Class Initialized
DEBUG - 2023-12-14 11:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:07:03 --> Input Class Initialized
INFO - 2023-12-14 11:07:03 --> Language Class Initialized
INFO - 2023-12-14 11:07:03 --> Language Class Initialized
INFO - 2023-12-14 11:07:03 --> Config Class Initialized
INFO - 2023-12-14 11:07:03 --> Loader Class Initialized
INFO - 2023-12-14 11:07:03 --> Helper loaded: url_helper
INFO - 2023-12-14 11:07:03 --> Helper loaded: file_helper
INFO - 2023-12-14 11:07:03 --> Helper loaded: form_helper
INFO - 2023-12-14 11:07:03 --> Helper loaded: my_helper
INFO - 2023-12-14 11:07:03 --> Database Driver Class Initialized
INFO - 2023-12-14 11:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:07:03 --> Controller Class Initialized
INFO - 2023-12-14 11:07:03 --> Config Class Initialized
INFO - 2023-12-14 11:07:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:07:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:07:03 --> Utf8 Class Initialized
INFO - 2023-12-14 11:07:03 --> URI Class Initialized
INFO - 2023-12-14 11:07:04 --> Router Class Initialized
INFO - 2023-12-14 11:07:04 --> Output Class Initialized
INFO - 2023-12-14 11:07:04 --> Security Class Initialized
DEBUG - 2023-12-14 11:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:07:04 --> Input Class Initialized
INFO - 2023-12-14 11:07:04 --> Language Class Initialized
INFO - 2023-12-14 11:07:04 --> Language Class Initialized
INFO - 2023-12-14 11:07:04 --> Config Class Initialized
INFO - 2023-12-14 11:07:04 --> Loader Class Initialized
INFO - 2023-12-14 11:07:04 --> Helper loaded: url_helper
INFO - 2023-12-14 11:07:04 --> Helper loaded: file_helper
INFO - 2023-12-14 11:07:04 --> Helper loaded: form_helper
INFO - 2023-12-14 11:07:04 --> Helper loaded: my_helper
INFO - 2023-12-14 11:07:04 --> Database Driver Class Initialized
INFO - 2023-12-14 11:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:07:04 --> Controller Class Initialized
DEBUG - 2023-12-14 11:07:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:07:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:07:04 --> Final output sent to browser
DEBUG - 2023-12-14 11:07:04 --> Total execution time: 0.4800
INFO - 2023-12-14 11:07:20 --> Config Class Initialized
INFO - 2023-12-14 11:07:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:07:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:07:20 --> Utf8 Class Initialized
INFO - 2023-12-14 11:07:20 --> URI Class Initialized
INFO - 2023-12-14 11:07:20 --> Router Class Initialized
INFO - 2023-12-14 11:07:20 --> Output Class Initialized
INFO - 2023-12-14 11:07:20 --> Security Class Initialized
DEBUG - 2023-12-14 11:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:07:20 --> Input Class Initialized
INFO - 2023-12-14 11:07:20 --> Language Class Initialized
INFO - 2023-12-14 11:07:20 --> Language Class Initialized
INFO - 2023-12-14 11:07:20 --> Config Class Initialized
INFO - 2023-12-14 11:07:20 --> Loader Class Initialized
INFO - 2023-12-14 11:07:20 --> Helper loaded: url_helper
INFO - 2023-12-14 11:07:20 --> Helper loaded: file_helper
INFO - 2023-12-14 11:07:20 --> Helper loaded: form_helper
INFO - 2023-12-14 11:07:20 --> Helper loaded: my_helper
INFO - 2023-12-14 11:07:20 --> Database Driver Class Initialized
INFO - 2023-12-14 11:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:07:20 --> Controller Class Initialized
ERROR - 2023-12-14 11:07:20 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2023-12-14 11:07:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:07:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:07:21 --> Final output sent to browser
DEBUG - 2023-12-14 11:07:21 --> Total execution time: 0.7952
INFO - 2023-12-14 11:07:32 --> Config Class Initialized
INFO - 2023-12-14 11:07:32 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:07:32 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:07:32 --> Utf8 Class Initialized
INFO - 2023-12-14 11:07:32 --> URI Class Initialized
INFO - 2023-12-14 11:07:32 --> Router Class Initialized
INFO - 2023-12-14 11:07:32 --> Output Class Initialized
INFO - 2023-12-14 11:07:32 --> Security Class Initialized
DEBUG - 2023-12-14 11:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:07:32 --> Input Class Initialized
INFO - 2023-12-14 11:07:32 --> Language Class Initialized
INFO - 2023-12-14 11:07:32 --> Language Class Initialized
INFO - 2023-12-14 11:07:32 --> Config Class Initialized
INFO - 2023-12-14 11:07:32 --> Loader Class Initialized
INFO - 2023-12-14 11:07:32 --> Helper loaded: url_helper
INFO - 2023-12-14 11:07:32 --> Helper loaded: file_helper
INFO - 2023-12-14 11:07:32 --> Helper loaded: form_helper
INFO - 2023-12-14 11:07:32 --> Helper loaded: my_helper
INFO - 2023-12-14 11:07:32 --> Database Driver Class Initialized
INFO - 2023-12-14 11:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:07:32 --> Controller Class Initialized
DEBUG - 2023-12-14 11:07:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:07:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:07:32 --> Final output sent to browser
DEBUG - 2023-12-14 11:07:32 --> Total execution time: 0.2009
INFO - 2023-12-14 11:08:52 --> Config Class Initialized
INFO - 2023-12-14 11:08:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:08:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:08:52 --> Utf8 Class Initialized
INFO - 2023-12-14 11:08:52 --> URI Class Initialized
INFO - 2023-12-14 11:08:52 --> Router Class Initialized
INFO - 2023-12-14 11:08:52 --> Output Class Initialized
INFO - 2023-12-14 11:08:52 --> Security Class Initialized
DEBUG - 2023-12-14 11:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:08:52 --> Input Class Initialized
INFO - 2023-12-14 11:08:52 --> Language Class Initialized
INFO - 2023-12-14 11:08:52 --> Language Class Initialized
INFO - 2023-12-14 11:08:52 --> Config Class Initialized
INFO - 2023-12-14 11:08:52 --> Loader Class Initialized
INFO - 2023-12-14 11:08:52 --> Helper loaded: url_helper
INFO - 2023-12-14 11:08:52 --> Helper loaded: file_helper
INFO - 2023-12-14 11:08:52 --> Helper loaded: form_helper
INFO - 2023-12-14 11:08:52 --> Helper loaded: my_helper
INFO - 2023-12-14 11:08:52 --> Database Driver Class Initialized
INFO - 2023-12-14 11:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:08:53 --> Controller Class Initialized
DEBUG - 2023-12-14 11:08:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:08:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:08:53 --> Final output sent to browser
DEBUG - 2023-12-14 11:08:53 --> Total execution time: 0.7978
INFO - 2023-12-14 11:08:58 --> Config Class Initialized
INFO - 2023-12-14 11:08:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:08:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:08:58 --> Utf8 Class Initialized
INFO - 2023-12-14 11:08:58 --> URI Class Initialized
INFO - 2023-12-14 11:08:58 --> Router Class Initialized
INFO - 2023-12-14 11:08:58 --> Output Class Initialized
INFO - 2023-12-14 11:08:58 --> Security Class Initialized
DEBUG - 2023-12-14 11:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:08:58 --> Input Class Initialized
INFO - 2023-12-14 11:08:58 --> Language Class Initialized
INFO - 2023-12-14 11:08:58 --> Language Class Initialized
INFO - 2023-12-14 11:08:58 --> Config Class Initialized
INFO - 2023-12-14 11:08:58 --> Loader Class Initialized
INFO - 2023-12-14 11:08:58 --> Helper loaded: url_helper
INFO - 2023-12-14 11:08:58 --> Helper loaded: file_helper
INFO - 2023-12-14 11:08:58 --> Helper loaded: form_helper
INFO - 2023-12-14 11:08:58 --> Helper loaded: my_helper
INFO - 2023-12-14 11:08:58 --> Database Driver Class Initialized
INFO - 2023-12-14 11:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:08:59 --> Controller Class Initialized
DEBUG - 2023-12-14 11:08:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:09:00 --> Config Class Initialized
INFO - 2023-12-14 11:09:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:09:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:09:00 --> Utf8 Class Initialized
INFO - 2023-12-14 11:09:00 --> URI Class Initialized
INFO - 2023-12-14 11:09:00 --> Router Class Initialized
INFO - 2023-12-14 11:09:00 --> Output Class Initialized
INFO - 2023-12-14 11:09:00 --> Security Class Initialized
DEBUG - 2023-12-14 11:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:09:00 --> Input Class Initialized
INFO - 2023-12-14 11:09:00 --> Language Class Initialized
INFO - 2023-12-14 11:09:00 --> Language Class Initialized
INFO - 2023-12-14 11:09:00 --> Config Class Initialized
INFO - 2023-12-14 11:09:00 --> Loader Class Initialized
INFO - 2023-12-14 11:09:00 --> Helper loaded: url_helper
INFO - 2023-12-14 11:09:00 --> Helper loaded: file_helper
INFO - 2023-12-14 11:09:00 --> Helper loaded: form_helper
INFO - 2023-12-14 11:09:00 --> Helper loaded: my_helper
INFO - 2023-12-14 11:09:01 --> Database Driver Class Initialized
INFO - 2023-12-14 11:09:05 --> Config Class Initialized
INFO - 2023-12-14 11:09:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:09:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:09:05 --> Utf8 Class Initialized
INFO - 2023-12-14 11:09:05 --> URI Class Initialized
INFO - 2023-12-14 11:09:05 --> Router Class Initialized
INFO - 2023-12-14 11:09:05 --> Output Class Initialized
INFO - 2023-12-14 11:09:05 --> Security Class Initialized
DEBUG - 2023-12-14 11:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:09:05 --> Input Class Initialized
INFO - 2023-12-14 11:09:05 --> Language Class Initialized
INFO - 2023-12-14 11:09:05 --> Language Class Initialized
INFO - 2023-12-14 11:09:05 --> Config Class Initialized
INFO - 2023-12-14 11:09:05 --> Loader Class Initialized
INFO - 2023-12-14 11:09:05 --> Helper loaded: url_helper
INFO - 2023-12-14 11:09:05 --> Helper loaded: file_helper
INFO - 2023-12-14 11:09:05 --> Helper loaded: form_helper
INFO - 2023-12-14 11:09:05 --> Helper loaded: my_helper
INFO - 2023-12-14 11:09:05 --> Database Driver Class Initialized
INFO - 2023-12-14 11:09:33 --> Config Class Initialized
INFO - 2023-12-14 11:09:33 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:09:33 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:09:33 --> Utf8 Class Initialized
INFO - 2023-12-14 11:09:33 --> URI Class Initialized
INFO - 2023-12-14 11:09:33 --> Router Class Initialized
INFO - 2023-12-14 11:09:33 --> Output Class Initialized
INFO - 2023-12-14 11:09:33 --> Security Class Initialized
DEBUG - 2023-12-14 11:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:09:33 --> Input Class Initialized
INFO - 2023-12-14 11:09:33 --> Language Class Initialized
INFO - 2023-12-14 11:09:33 --> Language Class Initialized
INFO - 2023-12-14 11:09:33 --> Config Class Initialized
INFO - 2023-12-14 11:09:33 --> Loader Class Initialized
INFO - 2023-12-14 11:09:33 --> Helper loaded: url_helper
INFO - 2023-12-14 11:09:33 --> Helper loaded: file_helper
INFO - 2023-12-14 11:09:33 --> Helper loaded: form_helper
INFO - 2023-12-14 11:09:33 --> Helper loaded: my_helper
INFO - 2023-12-14 11:09:34 --> Database Driver Class Initialized
INFO - 2023-12-14 11:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:09:34 --> Controller Class Initialized
DEBUG - 2023-12-14 11:09:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:09:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:09:34 --> Final output sent to browser
DEBUG - 2023-12-14 11:09:34 --> Total execution time: 1.3258
INFO - 2023-12-14 11:10:03 --> Config Class Initialized
INFO - 2023-12-14 11:10:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:03 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:03 --> URI Class Initialized
INFO - 2023-12-14 11:10:03 --> Router Class Initialized
INFO - 2023-12-14 11:10:03 --> Output Class Initialized
INFO - 2023-12-14 11:10:03 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:03 --> Input Class Initialized
INFO - 2023-12-14 11:10:03 --> Language Class Initialized
INFO - 2023-12-14 11:10:04 --> Language Class Initialized
INFO - 2023-12-14 11:10:04 --> Config Class Initialized
INFO - 2023-12-14 11:10:04 --> Loader Class Initialized
INFO - 2023-12-14 11:10:04 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:04 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:04 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:04 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:04 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:04 --> Controller Class Initialized
INFO - 2023-12-14 11:10:05 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:10:05 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:05 --> Total execution time: 1.8182
INFO - 2023-12-14 11:10:05 --> Config Class Initialized
INFO - 2023-12-14 11:10:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:05 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:05 --> URI Class Initialized
INFO - 2023-12-14 11:10:05 --> Router Class Initialized
INFO - 2023-12-14 11:10:06 --> Output Class Initialized
INFO - 2023-12-14 11:10:06 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:06 --> Input Class Initialized
INFO - 2023-12-14 11:10:06 --> Language Class Initialized
INFO - 2023-12-14 11:10:06 --> Language Class Initialized
INFO - 2023-12-14 11:10:06 --> Config Class Initialized
INFO - 2023-12-14 11:10:06 --> Loader Class Initialized
INFO - 2023-12-14 11:10:06 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:06 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:06 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:06 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:06 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:07 --> Controller Class Initialized
DEBUG - 2023-12-14 11:10:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 11:10:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:10:07 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:07 --> Total execution time: 2.0022
INFO - 2023-12-14 11:10:16 --> Config Class Initialized
INFO - 2023-12-14 11:10:16 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:16 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:16 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:16 --> URI Class Initialized
INFO - 2023-12-14 11:10:16 --> Router Class Initialized
INFO - 2023-12-14 11:10:16 --> Output Class Initialized
INFO - 2023-12-14 11:10:16 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:16 --> Input Class Initialized
INFO - 2023-12-14 11:10:16 --> Language Class Initialized
INFO - 2023-12-14 11:10:16 --> Language Class Initialized
INFO - 2023-12-14 11:10:16 --> Config Class Initialized
INFO - 2023-12-14 11:10:16 --> Loader Class Initialized
INFO - 2023-12-14 11:10:16 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:16 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:17 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:17 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:17 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:17 --> Controller Class Initialized
DEBUG - 2023-12-14 11:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-12-14 11:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:10:17 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:17 --> Total execution time: 0.8535
INFO - 2023-12-14 11:10:17 --> Config Class Initialized
INFO - 2023-12-14 11:10:17 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:17 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:17 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:17 --> URI Class Initialized
INFO - 2023-12-14 11:10:17 --> Router Class Initialized
INFO - 2023-12-14 11:10:17 --> Output Class Initialized
INFO - 2023-12-14 11:10:17 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:17 --> Input Class Initialized
INFO - 2023-12-14 11:10:17 --> Language Class Initialized
ERROR - 2023-12-14 11:10:17 --> 404 Page Not Found: /index
INFO - 2023-12-14 11:10:17 --> Config Class Initialized
INFO - 2023-12-14 11:10:17 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:17 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:17 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:17 --> URI Class Initialized
INFO - 2023-12-14 11:10:18 --> Router Class Initialized
INFO - 2023-12-14 11:10:18 --> Output Class Initialized
INFO - 2023-12-14 11:10:18 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:18 --> Input Class Initialized
INFO - 2023-12-14 11:10:18 --> Language Class Initialized
INFO - 2023-12-14 11:10:18 --> Language Class Initialized
INFO - 2023-12-14 11:10:18 --> Config Class Initialized
INFO - 2023-12-14 11:10:18 --> Loader Class Initialized
INFO - 2023-12-14 11:10:18 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:18 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:18 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:18 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:18 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:18 --> Controller Class Initialized
INFO - 2023-12-14 11:10:20 --> Config Class Initialized
INFO - 2023-12-14 11:10:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:20 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:20 --> URI Class Initialized
INFO - 2023-12-14 11:10:20 --> Router Class Initialized
INFO - 2023-12-14 11:10:20 --> Output Class Initialized
INFO - 2023-12-14 11:10:20 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:20 --> Input Class Initialized
INFO - 2023-12-14 11:10:20 --> Language Class Initialized
INFO - 2023-12-14 11:10:20 --> Language Class Initialized
INFO - 2023-12-14 11:10:20 --> Config Class Initialized
INFO - 2023-12-14 11:10:20 --> Loader Class Initialized
INFO - 2023-12-14 11:10:20 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:20 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:20 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:20 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:20 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:21 --> Controller Class Initialized
INFO - 2023-12-14 11:10:21 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:21 --> Total execution time: 0.7097
INFO - 2023-12-14 11:10:33 --> Config Class Initialized
INFO - 2023-12-14 11:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:33 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:33 --> URI Class Initialized
INFO - 2023-12-14 11:10:33 --> Router Class Initialized
INFO - 2023-12-14 11:10:33 --> Output Class Initialized
INFO - 2023-12-14 11:10:33 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:33 --> Input Class Initialized
INFO - 2023-12-14 11:10:33 --> Language Class Initialized
INFO - 2023-12-14 11:10:33 --> Language Class Initialized
INFO - 2023-12-14 11:10:33 --> Config Class Initialized
INFO - 2023-12-14 11:10:33 --> Loader Class Initialized
INFO - 2023-12-14 11:10:33 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:33 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:33 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:33 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:33 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:33 --> Controller Class Initialized
INFO - 2023-12-14 11:10:33 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:33 --> Total execution time: 0.6192
INFO - 2023-12-14 11:10:33 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:33 --> Total execution time: 95.7362
INFO - 2023-12-14 11:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:34 --> Controller Class Initialized
INFO - 2023-12-14 11:10:34 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:10:45 --> Config Class Initialized
INFO - 2023-12-14 11:10:45 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:45 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:45 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:45 --> URI Class Initialized
INFO - 2023-12-14 11:10:45 --> Router Class Initialized
INFO - 2023-12-14 11:10:45 --> Output Class Initialized
INFO - 2023-12-14 11:10:45 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:45 --> Input Class Initialized
INFO - 2023-12-14 11:10:45 --> Language Class Initialized
INFO - 2023-12-14 11:10:45 --> Language Class Initialized
INFO - 2023-12-14 11:10:45 --> Config Class Initialized
INFO - 2023-12-14 11:10:45 --> Loader Class Initialized
INFO - 2023-12-14 11:10:45 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:45 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:45 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:45 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:45 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:45 --> Controller Class Initialized
INFO - 2023-12-14 11:10:46 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:46 --> Total execution time: 0.8797
INFO - 2023-12-14 11:10:46 --> Config Class Initialized
INFO - 2023-12-14 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:46 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:46 --> URI Class Initialized
INFO - 2023-12-14 11:10:46 --> Router Class Initialized
INFO - 2023-12-14 11:10:46 --> Output Class Initialized
INFO - 2023-12-14 11:10:46 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:46 --> Input Class Initialized
INFO - 2023-12-14 11:10:46 --> Language Class Initialized
ERROR - 2023-12-14 11:10:46 --> 404 Page Not Found: /index
INFO - 2023-12-14 11:10:46 --> Config Class Initialized
INFO - 2023-12-14 11:10:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:46 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:46 --> URI Class Initialized
INFO - 2023-12-14 11:10:46 --> Router Class Initialized
INFO - 2023-12-14 11:10:46 --> Output Class Initialized
INFO - 2023-12-14 11:10:46 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:46 --> Input Class Initialized
INFO - 2023-12-14 11:10:46 --> Language Class Initialized
INFO - 2023-12-14 11:10:46 --> Language Class Initialized
INFO - 2023-12-14 11:10:46 --> Config Class Initialized
INFO - 2023-12-14 11:10:46 --> Loader Class Initialized
INFO - 2023-12-14 11:10:46 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:46 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:47 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:47 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:47 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:47 --> Controller Class Initialized
INFO - 2023-12-14 11:10:53 --> Config Class Initialized
INFO - 2023-12-14 11:10:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:53 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:54 --> URI Class Initialized
INFO - 2023-12-14 11:10:54 --> Router Class Initialized
INFO - 2023-12-14 11:10:54 --> Output Class Initialized
INFO - 2023-12-14 11:10:54 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:54 --> Input Class Initialized
INFO - 2023-12-14 11:10:54 --> Language Class Initialized
INFO - 2023-12-14 11:10:54 --> Language Class Initialized
INFO - 2023-12-14 11:10:54 --> Config Class Initialized
INFO - 2023-12-14 11:10:54 --> Loader Class Initialized
INFO - 2023-12-14 11:10:54 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:54 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:54 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:54 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:54 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:54 --> Controller Class Initialized
INFO - 2023-12-14 11:10:54 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:10:54 --> Config Class Initialized
INFO - 2023-12-14 11:10:54 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:54 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:54 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:54 --> URI Class Initialized
INFO - 2023-12-14 11:10:54 --> Router Class Initialized
INFO - 2023-12-14 11:10:54 --> Output Class Initialized
INFO - 2023-12-14 11:10:54 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:54 --> Input Class Initialized
INFO - 2023-12-14 11:10:54 --> Language Class Initialized
INFO - 2023-12-14 11:10:54 --> Language Class Initialized
INFO - 2023-12-14 11:10:54 --> Config Class Initialized
INFO - 2023-12-14 11:10:54 --> Loader Class Initialized
INFO - 2023-12-14 11:10:54 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:54 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:54 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:55 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:55 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:55 --> Controller Class Initialized
INFO - 2023-12-14 11:10:55 --> Config Class Initialized
INFO - 2023-12-14 11:10:55 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:10:55 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:10:55 --> Utf8 Class Initialized
INFO - 2023-12-14 11:10:55 --> URI Class Initialized
INFO - 2023-12-14 11:10:55 --> Router Class Initialized
INFO - 2023-12-14 11:10:55 --> Output Class Initialized
INFO - 2023-12-14 11:10:55 --> Security Class Initialized
DEBUG - 2023-12-14 11:10:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:10:55 --> Input Class Initialized
INFO - 2023-12-14 11:10:55 --> Language Class Initialized
INFO - 2023-12-14 11:10:55 --> Language Class Initialized
INFO - 2023-12-14 11:10:55 --> Config Class Initialized
INFO - 2023-12-14 11:10:55 --> Loader Class Initialized
INFO - 2023-12-14 11:10:55 --> Helper loaded: url_helper
INFO - 2023-12-14 11:10:55 --> Helper loaded: file_helper
INFO - 2023-12-14 11:10:55 --> Helper loaded: form_helper
INFO - 2023-12-14 11:10:55 --> Helper loaded: my_helper
INFO - 2023-12-14 11:10:55 --> Database Driver Class Initialized
INFO - 2023-12-14 11:10:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:10:55 --> Controller Class Initialized
DEBUG - 2023-12-14 11:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:10:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:10:56 --> Final output sent to browser
DEBUG - 2023-12-14 11:10:56 --> Total execution time: 0.6698
INFO - 2023-12-14 11:11:02 --> Config Class Initialized
INFO - 2023-12-14 11:11:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:11:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:11:02 --> Utf8 Class Initialized
INFO - 2023-12-14 11:11:02 --> URI Class Initialized
INFO - 2023-12-14 11:11:02 --> Router Class Initialized
INFO - 2023-12-14 11:11:02 --> Output Class Initialized
INFO - 2023-12-14 11:11:02 --> Security Class Initialized
DEBUG - 2023-12-14 11:11:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:11:02 --> Input Class Initialized
INFO - 2023-12-14 11:11:02 --> Language Class Initialized
INFO - 2023-12-14 11:11:03 --> Language Class Initialized
INFO - 2023-12-14 11:11:03 --> Config Class Initialized
INFO - 2023-12-14 11:11:03 --> Loader Class Initialized
INFO - 2023-12-14 11:11:03 --> Helper loaded: url_helper
INFO - 2023-12-14 11:11:03 --> Helper loaded: file_helper
INFO - 2023-12-14 11:11:03 --> Helper loaded: form_helper
INFO - 2023-12-14 11:11:03 --> Helper loaded: my_helper
INFO - 2023-12-14 11:11:03 --> Database Driver Class Initialized
INFO - 2023-12-14 11:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:11:03 --> Controller Class Initialized
ERROR - 2023-12-14 11:11:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 3888
DEBUG - 2023-12-14 11:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:11:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:11:03 --> Final output sent to browser
DEBUG - 2023-12-14 11:11:03 --> Total execution time: 1.0122
INFO - 2023-12-14 11:11:08 --> Config Class Initialized
INFO - 2023-12-14 11:11:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:11:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:11:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:11:08 --> URI Class Initialized
INFO - 2023-12-14 11:11:08 --> Router Class Initialized
INFO - 2023-12-14 11:11:08 --> Output Class Initialized
INFO - 2023-12-14 11:11:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:11:08 --> Input Class Initialized
INFO - 2023-12-14 11:11:08 --> Language Class Initialized
INFO - 2023-12-14 11:11:09 --> Language Class Initialized
INFO - 2023-12-14 11:11:09 --> Config Class Initialized
INFO - 2023-12-14 11:11:09 --> Loader Class Initialized
INFO - 2023-12-14 11:11:09 --> Helper loaded: url_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: file_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: form_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: my_helper
INFO - 2023-12-14 11:11:09 --> Database Driver Class Initialized
INFO - 2023-12-14 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:11:09 --> Controller Class Initialized
INFO - 2023-12-14 11:11:09 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:11:09 --> Final output sent to browser
DEBUG - 2023-12-14 11:11:09 --> Total execution time: 0.5930
INFO - 2023-12-14 11:11:09 --> Config Class Initialized
INFO - 2023-12-14 11:11:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:11:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:11:09 --> Utf8 Class Initialized
INFO - 2023-12-14 11:11:09 --> URI Class Initialized
INFO - 2023-12-14 11:11:09 --> Router Class Initialized
INFO - 2023-12-14 11:11:09 --> Output Class Initialized
INFO - 2023-12-14 11:11:09 --> Security Class Initialized
DEBUG - 2023-12-14 11:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:11:09 --> Input Class Initialized
INFO - 2023-12-14 11:11:09 --> Language Class Initialized
INFO - 2023-12-14 11:11:09 --> Language Class Initialized
INFO - 2023-12-14 11:11:09 --> Config Class Initialized
INFO - 2023-12-14 11:11:09 --> Loader Class Initialized
INFO - 2023-12-14 11:11:09 --> Helper loaded: url_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: file_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: form_helper
INFO - 2023-12-14 11:11:09 --> Helper loaded: my_helper
INFO - 2023-12-14 11:11:09 --> Database Driver Class Initialized
INFO - 2023-12-14 11:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:11:09 --> Controller Class Initialized
DEBUG - 2023-12-14 11:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 11:11:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:11:09 --> Final output sent to browser
DEBUG - 2023-12-14 11:11:09 --> Total execution time: 0.5894
INFO - 2023-12-14 11:11:24 --> Config Class Initialized
INFO - 2023-12-14 11:11:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:11:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:11:24 --> Utf8 Class Initialized
INFO - 2023-12-14 11:11:24 --> URI Class Initialized
INFO - 2023-12-14 11:11:24 --> Router Class Initialized
INFO - 2023-12-14 11:11:24 --> Output Class Initialized
INFO - 2023-12-14 11:11:24 --> Security Class Initialized
DEBUG - 2023-12-14 11:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:11:24 --> Input Class Initialized
INFO - 2023-12-14 11:11:24 --> Language Class Initialized
INFO - 2023-12-14 11:11:24 --> Language Class Initialized
INFO - 2023-12-14 11:11:24 --> Config Class Initialized
INFO - 2023-12-14 11:11:24 --> Loader Class Initialized
INFO - 2023-12-14 11:11:24 --> Helper loaded: url_helper
INFO - 2023-12-14 11:11:24 --> Helper loaded: file_helper
INFO - 2023-12-14 11:11:24 --> Helper loaded: form_helper
INFO - 2023-12-14 11:11:24 --> Helper loaded: my_helper
INFO - 2023-12-14 11:11:24 --> Database Driver Class Initialized
INFO - 2023-12-14 11:11:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:11:24 --> Controller Class Initialized
DEBUG - 2023-12-14 11:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:11:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:11:25 --> Final output sent to browser
DEBUG - 2023-12-14 11:11:25 --> Total execution time: 0.9824
INFO - 2023-12-14 11:11:28 --> Config Class Initialized
INFO - 2023-12-14 11:11:28 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:11:28 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:11:28 --> Utf8 Class Initialized
INFO - 2023-12-14 11:11:28 --> URI Class Initialized
INFO - 2023-12-14 11:11:28 --> Router Class Initialized
INFO - 2023-12-14 11:11:28 --> Output Class Initialized
INFO - 2023-12-14 11:11:28 --> Security Class Initialized
DEBUG - 2023-12-14 11:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:11:28 --> Input Class Initialized
INFO - 2023-12-14 11:11:28 --> Language Class Initialized
INFO - 2023-12-14 11:11:28 --> Language Class Initialized
INFO - 2023-12-14 11:11:28 --> Config Class Initialized
INFO - 2023-12-14 11:11:28 --> Loader Class Initialized
INFO - 2023-12-14 11:11:28 --> Helper loaded: url_helper
INFO - 2023-12-14 11:11:28 --> Helper loaded: file_helper
INFO - 2023-12-14 11:11:28 --> Helper loaded: form_helper
INFO - 2023-12-14 11:11:28 --> Helper loaded: my_helper
INFO - 2023-12-14 11:11:28 --> Database Driver Class Initialized
INFO - 2023-12-14 11:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:11:28 --> Controller Class Initialized
DEBUG - 2023-12-14 11:11:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:12:04 --> Config Class Initialized
INFO - 2023-12-14 11:12:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:12:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:12:04 --> Utf8 Class Initialized
INFO - 2023-12-14 11:12:04 --> URI Class Initialized
INFO - 2023-12-14 11:12:04 --> Router Class Initialized
INFO - 2023-12-14 11:12:04 --> Output Class Initialized
INFO - 2023-12-14 11:12:04 --> Security Class Initialized
DEBUG - 2023-12-14 11:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:12:04 --> Input Class Initialized
INFO - 2023-12-14 11:12:04 --> Language Class Initialized
INFO - 2023-12-14 11:12:05 --> Language Class Initialized
INFO - 2023-12-14 11:12:05 --> Config Class Initialized
INFO - 2023-12-14 11:12:05 --> Loader Class Initialized
INFO - 2023-12-14 11:12:05 --> Helper loaded: url_helper
INFO - 2023-12-14 11:12:05 --> Helper loaded: file_helper
INFO - 2023-12-14 11:12:05 --> Helper loaded: form_helper
INFO - 2023-12-14 11:12:05 --> Helper loaded: my_helper
INFO - 2023-12-14 11:12:05 --> Database Driver Class Initialized
INFO - 2023-12-14 11:12:37 --> Config Class Initialized
INFO - 2023-12-14 11:12:37 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:12:37 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:12:37 --> Utf8 Class Initialized
INFO - 2023-12-14 11:12:37 --> URI Class Initialized
INFO - 2023-12-14 11:12:37 --> Router Class Initialized
INFO - 2023-12-14 11:12:37 --> Output Class Initialized
INFO - 2023-12-14 11:12:37 --> Security Class Initialized
DEBUG - 2023-12-14 11:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:12:37 --> Input Class Initialized
INFO - 2023-12-14 11:12:37 --> Language Class Initialized
INFO - 2023-12-14 11:12:38 --> Language Class Initialized
INFO - 2023-12-14 11:12:38 --> Config Class Initialized
INFO - 2023-12-14 11:12:38 --> Loader Class Initialized
INFO - 2023-12-14 11:12:38 --> Helper loaded: url_helper
INFO - 2023-12-14 11:12:38 --> Helper loaded: file_helper
INFO - 2023-12-14 11:12:38 --> Helper loaded: form_helper
INFO - 2023-12-14 11:12:38 --> Helper loaded: my_helper
INFO - 2023-12-14 11:12:38 --> Database Driver Class Initialized
INFO - 2023-12-14 11:12:42 --> Final output sent to browser
DEBUG - 2023-12-14 11:12:42 --> Total execution time: 74.4242
INFO - 2023-12-14 11:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:12:42 --> Controller Class Initialized
INFO - 2023-12-14 11:12:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:12:42 --> Controller Class Initialized
INFO - 2023-12-14 11:12:42 --> Helper loaded: cookie_helper
DEBUG - 2023-12-14 11:12:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 11:12:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:12:42 --> Final output sent to browser
DEBUG - 2023-12-14 11:12:42 --> Total execution time: 4.8454
INFO - 2023-12-14 11:12:51 --> Config Class Initialized
INFO - 2023-12-14 11:12:51 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:12:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:12:51 --> Utf8 Class Initialized
INFO - 2023-12-14 11:12:51 --> URI Class Initialized
INFO - 2023-12-14 11:12:51 --> Router Class Initialized
INFO - 2023-12-14 11:12:51 --> Output Class Initialized
INFO - 2023-12-14 11:12:51 --> Security Class Initialized
DEBUG - 2023-12-14 11:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:12:51 --> Input Class Initialized
INFO - 2023-12-14 11:12:51 --> Language Class Initialized
INFO - 2023-12-14 11:12:51 --> Language Class Initialized
INFO - 2023-12-14 11:12:51 --> Config Class Initialized
INFO - 2023-12-14 11:12:51 --> Loader Class Initialized
INFO - 2023-12-14 11:12:51 --> Helper loaded: url_helper
INFO - 2023-12-14 11:12:51 --> Helper loaded: file_helper
INFO - 2023-12-14 11:12:51 --> Helper loaded: form_helper
INFO - 2023-12-14 11:12:51 --> Helper loaded: my_helper
INFO - 2023-12-14 11:12:51 --> Database Driver Class Initialized
INFO - 2023-12-14 11:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:12:51 --> Controller Class Initialized
DEBUG - 2023-12-14 11:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:12:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:12:51 --> Final output sent to browser
DEBUG - 2023-12-14 11:12:51 --> Total execution time: 0.2000
INFO - 2023-12-14 11:13:00 --> Config Class Initialized
INFO - 2023-12-14 11:13:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:00 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:00 --> URI Class Initialized
INFO - 2023-12-14 11:13:00 --> Router Class Initialized
INFO - 2023-12-14 11:13:00 --> Output Class Initialized
INFO - 2023-12-14 11:13:00 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:00 --> Input Class Initialized
INFO - 2023-12-14 11:13:00 --> Language Class Initialized
INFO - 2023-12-14 11:13:00 --> Language Class Initialized
INFO - 2023-12-14 11:13:00 --> Config Class Initialized
INFO - 2023-12-14 11:13:00 --> Loader Class Initialized
INFO - 2023-12-14 11:13:00 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:00 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:00 --> Controller Class Initialized
INFO - 2023-12-14 11:13:00 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:13:00 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:00 --> Total execution time: 0.1256
INFO - 2023-12-14 11:13:00 --> Config Class Initialized
INFO - 2023-12-14 11:13:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:00 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:00 --> URI Class Initialized
INFO - 2023-12-14 11:13:00 --> Router Class Initialized
INFO - 2023-12-14 11:13:00 --> Output Class Initialized
INFO - 2023-12-14 11:13:00 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:00 --> Input Class Initialized
INFO - 2023-12-14 11:13:00 --> Language Class Initialized
INFO - 2023-12-14 11:13:00 --> Language Class Initialized
INFO - 2023-12-14 11:13:00 --> Config Class Initialized
INFO - 2023-12-14 11:13:00 --> Loader Class Initialized
INFO - 2023-12-14 11:13:00 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:00 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:00 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:00 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 11:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:00 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:00 --> Total execution time: 0.1585
INFO - 2023-12-14 11:13:04 --> Config Class Initialized
INFO - 2023-12-14 11:13:04 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:04 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:04 --> URI Class Initialized
INFO - 2023-12-14 11:13:04 --> Router Class Initialized
INFO - 2023-12-14 11:13:04 --> Output Class Initialized
INFO - 2023-12-14 11:13:04 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:04 --> Input Class Initialized
INFO - 2023-12-14 11:13:04 --> Language Class Initialized
INFO - 2023-12-14 11:13:04 --> Language Class Initialized
INFO - 2023-12-14 11:13:04 --> Config Class Initialized
INFO - 2023-12-14 11:13:04 --> Loader Class Initialized
INFO - 2023-12-14 11:13:04 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:04 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:04 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:04 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:04 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:04 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 11:13:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:04 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:04 --> Total execution time: 0.0424
INFO - 2023-12-14 11:13:07 --> Config Class Initialized
INFO - 2023-12-14 11:13:07 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:07 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:07 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:07 --> URI Class Initialized
INFO - 2023-12-14 11:13:07 --> Router Class Initialized
INFO - 2023-12-14 11:13:07 --> Output Class Initialized
INFO - 2023-12-14 11:13:07 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:07 --> Input Class Initialized
INFO - 2023-12-14 11:13:07 --> Language Class Initialized
INFO - 2023-12-14 11:13:07 --> Language Class Initialized
INFO - 2023-12-14 11:13:07 --> Config Class Initialized
INFO - 2023-12-14 11:13:07 --> Loader Class Initialized
INFO - 2023-12-14 11:13:07 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:07 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:07 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:07 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:07 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:07 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 11:13:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:07 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:07 --> Total execution time: 0.0455
INFO - 2023-12-14 11:13:08 --> Config Class Initialized
INFO - 2023-12-14 11:13:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:08 --> URI Class Initialized
INFO - 2023-12-14 11:13:08 --> Router Class Initialized
INFO - 2023-12-14 11:13:08 --> Output Class Initialized
INFO - 2023-12-14 11:13:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:08 --> Input Class Initialized
INFO - 2023-12-14 11:13:08 --> Language Class Initialized
INFO - 2023-12-14 11:13:08 --> Language Class Initialized
INFO - 2023-12-14 11:13:08 --> Config Class Initialized
INFO - 2023-12-14 11:13:08 --> Loader Class Initialized
INFO - 2023-12-14 11:13:08 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:08 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:08 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:08 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:08 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:08 --> Controller Class Initialized
INFO - 2023-12-14 11:13:08 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:08 --> Total execution time: 0.0399
INFO - 2023-12-14 11:13:21 --> Config Class Initialized
INFO - 2023-12-14 11:13:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:21 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:21 --> URI Class Initialized
INFO - 2023-12-14 11:13:21 --> Router Class Initialized
INFO - 2023-12-14 11:13:21 --> Output Class Initialized
INFO - 2023-12-14 11:13:21 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:21 --> Input Class Initialized
INFO - 2023-12-14 11:13:21 --> Language Class Initialized
INFO - 2023-12-14 11:13:21 --> Language Class Initialized
INFO - 2023-12-14 11:13:21 --> Config Class Initialized
INFO - 2023-12-14 11:13:21 --> Loader Class Initialized
INFO - 2023-12-14 11:13:21 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:21 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:21 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:21 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:21 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:21 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 11:13:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:21 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:21 --> Total execution time: 0.0746
INFO - 2023-12-14 11:13:24 --> Config Class Initialized
INFO - 2023-12-14 11:13:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:24 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:24 --> URI Class Initialized
INFO - 2023-12-14 11:13:24 --> Router Class Initialized
INFO - 2023-12-14 11:13:24 --> Output Class Initialized
INFO - 2023-12-14 11:13:24 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:24 --> Input Class Initialized
INFO - 2023-12-14 11:13:24 --> Language Class Initialized
INFO - 2023-12-14 11:13:24 --> Language Class Initialized
INFO - 2023-12-14 11:13:24 --> Config Class Initialized
INFO - 2023-12-14 11:13:24 --> Loader Class Initialized
INFO - 2023-12-14 11:13:24 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:24 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:24 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-14 11:13:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:24 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:24 --> Total execution time: 0.3451
INFO - 2023-12-14 11:13:24 --> Config Class Initialized
INFO - 2023-12-14 11:13:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:24 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:24 --> URI Class Initialized
INFO - 2023-12-14 11:13:24 --> Router Class Initialized
INFO - 2023-12-14 11:13:24 --> Output Class Initialized
INFO - 2023-12-14 11:13:24 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:24 --> Input Class Initialized
INFO - 2023-12-14 11:13:24 --> Language Class Initialized
INFO - 2023-12-14 11:13:24 --> Language Class Initialized
INFO - 2023-12-14 11:13:24 --> Config Class Initialized
INFO - 2023-12-14 11:13:24 --> Loader Class Initialized
INFO - 2023-12-14 11:13:24 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:24 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:24 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:24 --> Controller Class Initialized
INFO - 2023-12-14 11:13:27 --> Config Class Initialized
INFO - 2023-12-14 11:13:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:27 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:27 --> URI Class Initialized
INFO - 2023-12-14 11:13:27 --> Router Class Initialized
INFO - 2023-12-14 11:13:27 --> Output Class Initialized
INFO - 2023-12-14 11:13:27 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:27 --> Input Class Initialized
INFO - 2023-12-14 11:13:27 --> Language Class Initialized
INFO - 2023-12-14 11:13:27 --> Language Class Initialized
INFO - 2023-12-14 11:13:27 --> Config Class Initialized
INFO - 2023-12-14 11:13:27 --> Loader Class Initialized
INFO - 2023-12-14 11:13:27 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:27 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:27 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:27 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:27 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:27 --> Controller Class Initialized
INFO - 2023-12-14 11:13:27 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:27 --> Total execution time: 0.2527
INFO - 2023-12-14 11:13:53 --> Config Class Initialized
INFO - 2023-12-14 11:13:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:13:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:13:53 --> Utf8 Class Initialized
INFO - 2023-12-14 11:13:53 --> URI Class Initialized
INFO - 2023-12-14 11:13:53 --> Router Class Initialized
INFO - 2023-12-14 11:13:53 --> Output Class Initialized
INFO - 2023-12-14 11:13:53 --> Security Class Initialized
DEBUG - 2023-12-14 11:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:13:53 --> Input Class Initialized
INFO - 2023-12-14 11:13:53 --> Language Class Initialized
INFO - 2023-12-14 11:13:53 --> Language Class Initialized
INFO - 2023-12-14 11:13:53 --> Config Class Initialized
INFO - 2023-12-14 11:13:53 --> Loader Class Initialized
INFO - 2023-12-14 11:13:53 --> Helper loaded: url_helper
INFO - 2023-12-14 11:13:53 --> Helper loaded: file_helper
INFO - 2023-12-14 11:13:53 --> Helper loaded: form_helper
INFO - 2023-12-14 11:13:53 --> Helper loaded: my_helper
INFO - 2023-12-14 11:13:53 --> Database Driver Class Initialized
INFO - 2023-12-14 11:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:13:53 --> Controller Class Initialized
DEBUG - 2023-12-14 11:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 11:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:13:53 --> Final output sent to browser
DEBUG - 2023-12-14 11:13:53 --> Total execution time: 0.0775
INFO - 2023-12-14 11:14:51 --> Config Class Initialized
INFO - 2023-12-14 11:14:51 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:14:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:14:51 --> Utf8 Class Initialized
INFO - 2023-12-14 11:14:51 --> URI Class Initialized
INFO - 2023-12-14 11:14:51 --> Router Class Initialized
INFO - 2023-12-14 11:14:51 --> Output Class Initialized
INFO - 2023-12-14 11:14:51 --> Security Class Initialized
DEBUG - 2023-12-14 11:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:14:51 --> Input Class Initialized
INFO - 2023-12-14 11:14:51 --> Language Class Initialized
INFO - 2023-12-14 11:14:51 --> Language Class Initialized
INFO - 2023-12-14 11:14:51 --> Config Class Initialized
INFO - 2023-12-14 11:14:51 --> Loader Class Initialized
INFO - 2023-12-14 11:14:51 --> Helper loaded: url_helper
INFO - 2023-12-14 11:14:51 --> Helper loaded: file_helper
INFO - 2023-12-14 11:14:51 --> Helper loaded: form_helper
INFO - 2023-12-14 11:14:51 --> Helper loaded: my_helper
INFO - 2023-12-14 11:14:51 --> Database Driver Class Initialized
INFO - 2023-12-14 11:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:14:51 --> Controller Class Initialized
DEBUG - 2023-12-14 11:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-14 11:14:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:14:51 --> Final output sent to browser
DEBUG - 2023-12-14 11:14:51 --> Total execution time: 0.0889
INFO - 2023-12-14 11:14:54 --> Config Class Initialized
INFO - 2023-12-14 11:14:54 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:14:54 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:14:54 --> Utf8 Class Initialized
INFO - 2023-12-14 11:14:54 --> URI Class Initialized
INFO - 2023-12-14 11:14:54 --> Router Class Initialized
INFO - 2023-12-14 11:14:54 --> Output Class Initialized
INFO - 2023-12-14 11:14:54 --> Security Class Initialized
DEBUG - 2023-12-14 11:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:14:54 --> Input Class Initialized
INFO - 2023-12-14 11:14:54 --> Language Class Initialized
INFO - 2023-12-14 11:14:54 --> Language Class Initialized
INFO - 2023-12-14 11:14:54 --> Config Class Initialized
INFO - 2023-12-14 11:14:54 --> Loader Class Initialized
INFO - 2023-12-14 11:14:54 --> Helper loaded: url_helper
INFO - 2023-12-14 11:14:54 --> Helper loaded: file_helper
INFO - 2023-12-14 11:14:54 --> Helper loaded: form_helper
INFO - 2023-12-14 11:14:54 --> Helper loaded: my_helper
INFO - 2023-12-14 11:14:54 --> Database Driver Class Initialized
INFO - 2023-12-14 11:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:14:54 --> Controller Class Initialized
INFO - 2023-12-14 11:14:54 --> Final output sent to browser
DEBUG - 2023-12-14 11:14:54 --> Total execution time: 0.0342
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:08 --> URI Class Initialized
INFO - 2023-12-14 11:15:08 --> Router Class Initialized
INFO - 2023-12-14 11:15:08 --> Output Class Initialized
INFO - 2023-12-14 11:15:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:08 --> Input Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Loader Class Initialized
INFO - 2023-12-14 11:15:08 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:08 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:08 --> Controller Class Initialized
INFO - 2023-12-14 11:15:08 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:08 --> URI Class Initialized
INFO - 2023-12-14 11:15:08 --> Router Class Initialized
INFO - 2023-12-14 11:15:08 --> Output Class Initialized
INFO - 2023-12-14 11:15:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:08 --> Input Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Loader Class Initialized
INFO - 2023-12-14 11:15:08 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:08 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:08 --> Controller Class Initialized
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:08 --> URI Class Initialized
INFO - 2023-12-14 11:15:08 --> Router Class Initialized
INFO - 2023-12-14 11:15:08 --> Output Class Initialized
INFO - 2023-12-14 11:15:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:08 --> Input Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Language Class Initialized
INFO - 2023-12-14 11:15:08 --> Config Class Initialized
INFO - 2023-12-14 11:15:08 --> Loader Class Initialized
INFO - 2023-12-14 11:15:08 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:08 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:08 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:08 --> Controller Class Initialized
DEBUG - 2023-12-14 11:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:15:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:15:08 --> Final output sent to browser
DEBUG - 2023-12-14 11:15:08 --> Total execution time: 0.0554
INFO - 2023-12-14 11:15:35 --> Config Class Initialized
INFO - 2023-12-14 11:15:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:35 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:35 --> URI Class Initialized
INFO - 2023-12-14 11:15:35 --> Router Class Initialized
INFO - 2023-12-14 11:15:35 --> Output Class Initialized
INFO - 2023-12-14 11:15:35 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:35 --> Input Class Initialized
INFO - 2023-12-14 11:15:35 --> Language Class Initialized
INFO - 2023-12-14 11:15:35 --> Language Class Initialized
INFO - 2023-12-14 11:15:35 --> Config Class Initialized
INFO - 2023-12-14 11:15:35 --> Loader Class Initialized
INFO - 2023-12-14 11:15:35 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:35 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:35 --> Controller Class Initialized
INFO - 2023-12-14 11:15:35 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:15:35 --> Final output sent to browser
DEBUG - 2023-12-14 11:15:35 --> Total execution time: 0.0363
INFO - 2023-12-14 11:15:35 --> Config Class Initialized
INFO - 2023-12-14 11:15:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:35 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:35 --> URI Class Initialized
INFO - 2023-12-14 11:15:35 --> Router Class Initialized
INFO - 2023-12-14 11:15:35 --> Output Class Initialized
INFO - 2023-12-14 11:15:35 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:35 --> Input Class Initialized
INFO - 2023-12-14 11:15:35 --> Language Class Initialized
INFO - 2023-12-14 11:15:35 --> Language Class Initialized
INFO - 2023-12-14 11:15:35 --> Config Class Initialized
INFO - 2023-12-14 11:15:35 --> Loader Class Initialized
INFO - 2023-12-14 11:15:35 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:35 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:35 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:35 --> Controller Class Initialized
DEBUG - 2023-12-14 11:15:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 11:15:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:15:35 --> Final output sent to browser
DEBUG - 2023-12-14 11:15:35 --> Total execution time: 0.0346
INFO - 2023-12-14 11:15:43 --> Config Class Initialized
INFO - 2023-12-14 11:15:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:43 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:43 --> URI Class Initialized
INFO - 2023-12-14 11:15:43 --> Router Class Initialized
INFO - 2023-12-14 11:15:43 --> Output Class Initialized
INFO - 2023-12-14 11:15:43 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:43 --> Input Class Initialized
INFO - 2023-12-14 11:15:43 --> Language Class Initialized
INFO - 2023-12-14 11:15:43 --> Language Class Initialized
INFO - 2023-12-14 11:15:43 --> Config Class Initialized
INFO - 2023-12-14 11:15:43 --> Loader Class Initialized
INFO - 2023-12-14 11:15:43 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:43 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:43 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:43 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:43 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:43 --> Controller Class Initialized
DEBUG - 2023-12-14 11:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 11:15:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:15:43 --> Final output sent to browser
DEBUG - 2023-12-14 11:15:43 --> Total execution time: 0.1052
INFO - 2023-12-14 11:15:49 --> Config Class Initialized
INFO - 2023-12-14 11:15:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:49 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:49 --> URI Class Initialized
INFO - 2023-12-14 11:15:49 --> Router Class Initialized
INFO - 2023-12-14 11:15:49 --> Output Class Initialized
INFO - 2023-12-14 11:15:49 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:49 --> Input Class Initialized
INFO - 2023-12-14 11:15:49 --> Language Class Initialized
INFO - 2023-12-14 11:15:49 --> Language Class Initialized
INFO - 2023-12-14 11:15:49 --> Config Class Initialized
INFO - 2023-12-14 11:15:49 --> Loader Class Initialized
INFO - 2023-12-14 11:15:49 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:49 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:49 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:49 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:49 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:49 --> Controller Class Initialized
DEBUG - 2023-12-14 11:15:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:15:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:15:49 --> Final output sent to browser
DEBUG - 2023-12-14 11:15:49 --> Total execution time: 0.1000
INFO - 2023-12-14 11:15:53 --> Config Class Initialized
INFO - 2023-12-14 11:15:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:15:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:15:53 --> Utf8 Class Initialized
INFO - 2023-12-14 11:15:53 --> URI Class Initialized
INFO - 2023-12-14 11:15:53 --> Router Class Initialized
INFO - 2023-12-14 11:15:53 --> Output Class Initialized
INFO - 2023-12-14 11:15:53 --> Security Class Initialized
DEBUG - 2023-12-14 11:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:15:53 --> Input Class Initialized
INFO - 2023-12-14 11:15:53 --> Language Class Initialized
INFO - 2023-12-14 11:15:53 --> Language Class Initialized
INFO - 2023-12-14 11:15:53 --> Config Class Initialized
INFO - 2023-12-14 11:15:53 --> Loader Class Initialized
INFO - 2023-12-14 11:15:53 --> Helper loaded: url_helper
INFO - 2023-12-14 11:15:53 --> Helper loaded: file_helper
INFO - 2023-12-14 11:15:53 --> Helper loaded: form_helper
INFO - 2023-12-14 11:15:53 --> Helper loaded: my_helper
INFO - 2023-12-14 11:15:53 --> Database Driver Class Initialized
INFO - 2023-12-14 11:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:15:53 --> Controller Class Initialized
DEBUG - 2023-12-14 11:15:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:16:06 --> Final output sent to browser
DEBUG - 2023-12-14 11:16:06 --> Total execution time: 13.2853
INFO - 2023-12-14 11:17:00 --> Config Class Initialized
INFO - 2023-12-14 11:17:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:17:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:17:00 --> Utf8 Class Initialized
INFO - 2023-12-14 11:17:00 --> URI Class Initialized
INFO - 2023-12-14 11:17:00 --> Router Class Initialized
INFO - 2023-12-14 11:17:00 --> Output Class Initialized
INFO - 2023-12-14 11:17:00 --> Security Class Initialized
DEBUG - 2023-12-14 11:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:17:00 --> Input Class Initialized
INFO - 2023-12-14 11:17:00 --> Language Class Initialized
INFO - 2023-12-14 11:17:00 --> Language Class Initialized
INFO - 2023-12-14 11:17:00 --> Config Class Initialized
INFO - 2023-12-14 11:17:00 --> Loader Class Initialized
INFO - 2023-12-14 11:17:00 --> Helper loaded: url_helper
INFO - 2023-12-14 11:17:00 --> Helper loaded: file_helper
INFO - 2023-12-14 11:17:00 --> Helper loaded: form_helper
INFO - 2023-12-14 11:17:00 --> Helper loaded: my_helper
INFO - 2023-12-14 11:17:00 --> Database Driver Class Initialized
INFO - 2023-12-14 11:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:17:00 --> Controller Class Initialized
DEBUG - 2023-12-14 11:17:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:17:07 --> Final output sent to browser
DEBUG - 2023-12-14 11:17:07 --> Total execution time: 6.5819
INFO - 2023-12-14 11:17:25 --> Config Class Initialized
INFO - 2023-12-14 11:17:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:17:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:17:25 --> Utf8 Class Initialized
INFO - 2023-12-14 11:17:25 --> URI Class Initialized
INFO - 2023-12-14 11:17:25 --> Router Class Initialized
INFO - 2023-12-14 11:17:25 --> Output Class Initialized
INFO - 2023-12-14 11:17:25 --> Security Class Initialized
DEBUG - 2023-12-14 11:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:17:25 --> Input Class Initialized
INFO - 2023-12-14 11:17:25 --> Language Class Initialized
INFO - 2023-12-14 11:17:25 --> Language Class Initialized
INFO - 2023-12-14 11:17:25 --> Config Class Initialized
INFO - 2023-12-14 11:17:25 --> Loader Class Initialized
INFO - 2023-12-14 11:17:25 --> Helper loaded: url_helper
INFO - 2023-12-14 11:17:25 --> Helper loaded: file_helper
INFO - 2023-12-14 11:17:25 --> Helper loaded: form_helper
INFO - 2023-12-14 11:17:25 --> Helper loaded: my_helper
INFO - 2023-12-14 11:17:25 --> Database Driver Class Initialized
INFO - 2023-12-14 11:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:17:25 --> Controller Class Initialized
DEBUG - 2023-12-14 11:17:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:17:37 --> Final output sent to browser
DEBUG - 2023-12-14 11:17:37 --> Total execution time: 11.6618
INFO - 2023-12-14 11:17:49 --> Config Class Initialized
INFO - 2023-12-14 11:17:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:17:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:17:49 --> Utf8 Class Initialized
INFO - 2023-12-14 11:17:49 --> URI Class Initialized
INFO - 2023-12-14 11:17:49 --> Router Class Initialized
INFO - 2023-12-14 11:17:49 --> Output Class Initialized
INFO - 2023-12-14 11:17:49 --> Security Class Initialized
DEBUG - 2023-12-14 11:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:17:49 --> Input Class Initialized
INFO - 2023-12-14 11:17:49 --> Language Class Initialized
INFO - 2023-12-14 11:17:49 --> Language Class Initialized
INFO - 2023-12-14 11:17:49 --> Config Class Initialized
INFO - 2023-12-14 11:17:49 --> Loader Class Initialized
INFO - 2023-12-14 11:17:49 --> Helper loaded: url_helper
INFO - 2023-12-14 11:17:49 --> Helper loaded: file_helper
INFO - 2023-12-14 11:17:49 --> Helper loaded: form_helper
INFO - 2023-12-14 11:17:49 --> Helper loaded: my_helper
INFO - 2023-12-14 11:17:49 --> Database Driver Class Initialized
INFO - 2023-12-14 11:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:17:49 --> Controller Class Initialized
DEBUG - 2023-12-14 11:17:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:18:11 --> Final output sent to browser
DEBUG - 2023-12-14 11:18:11 --> Total execution time: 21.5214
INFO - 2023-12-14 11:18:22 --> Config Class Initialized
INFO - 2023-12-14 11:18:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:18:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:18:22 --> Utf8 Class Initialized
INFO - 2023-12-14 11:18:22 --> URI Class Initialized
INFO - 2023-12-14 11:18:22 --> Router Class Initialized
INFO - 2023-12-14 11:18:22 --> Output Class Initialized
INFO - 2023-12-14 11:18:22 --> Security Class Initialized
DEBUG - 2023-12-14 11:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:18:22 --> Input Class Initialized
INFO - 2023-12-14 11:18:22 --> Language Class Initialized
INFO - 2023-12-14 11:18:22 --> Language Class Initialized
INFO - 2023-12-14 11:18:22 --> Config Class Initialized
INFO - 2023-12-14 11:18:22 --> Loader Class Initialized
INFO - 2023-12-14 11:18:22 --> Helper loaded: url_helper
INFO - 2023-12-14 11:18:22 --> Helper loaded: file_helper
INFO - 2023-12-14 11:18:22 --> Helper loaded: form_helper
INFO - 2023-12-14 11:18:22 --> Helper loaded: my_helper
INFO - 2023-12-14 11:18:22 --> Database Driver Class Initialized
INFO - 2023-12-14 11:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:18:22 --> Controller Class Initialized
DEBUG - 2023-12-14 11:18:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:18:33 --> Config Class Initialized
INFO - 2023-12-14 11:18:33 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:18:33 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:18:33 --> Utf8 Class Initialized
INFO - 2023-12-14 11:18:33 --> URI Class Initialized
INFO - 2023-12-14 11:18:33 --> Router Class Initialized
INFO - 2023-12-14 11:18:33 --> Output Class Initialized
INFO - 2023-12-14 11:18:33 --> Security Class Initialized
DEBUG - 2023-12-14 11:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:18:33 --> Input Class Initialized
INFO - 2023-12-14 11:18:33 --> Language Class Initialized
INFO - 2023-12-14 11:18:33 --> Language Class Initialized
INFO - 2023-12-14 11:18:33 --> Config Class Initialized
INFO - 2023-12-14 11:18:33 --> Loader Class Initialized
INFO - 2023-12-14 11:18:33 --> Helper loaded: url_helper
INFO - 2023-12-14 11:18:33 --> Helper loaded: file_helper
INFO - 2023-12-14 11:18:33 --> Helper loaded: form_helper
INFO - 2023-12-14 11:18:34 --> Helper loaded: my_helper
INFO - 2023-12-14 11:18:34 --> Database Driver Class Initialized
INFO - 2023-12-14 11:18:44 --> Final output sent to browser
DEBUG - 2023-12-14 11:18:44 --> Total execution time: 22.2877
INFO - 2023-12-14 11:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:18:44 --> Controller Class Initialized
DEBUG - 2023-12-14 11:18:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:19:03 --> Config Class Initialized
INFO - 2023-12-14 11:19:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:19:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:19:03 --> Utf8 Class Initialized
INFO - 2023-12-14 11:19:03 --> URI Class Initialized
INFO - 2023-12-14 11:19:03 --> Router Class Initialized
INFO - 2023-12-14 11:19:03 --> Output Class Initialized
INFO - 2023-12-14 11:19:03 --> Security Class Initialized
DEBUG - 2023-12-14 11:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:19:03 --> Input Class Initialized
INFO - 2023-12-14 11:19:03 --> Language Class Initialized
INFO - 2023-12-14 11:19:04 --> Language Class Initialized
INFO - 2023-12-14 11:19:04 --> Config Class Initialized
INFO - 2023-12-14 11:19:04 --> Loader Class Initialized
INFO - 2023-12-14 11:19:04 --> Helper loaded: url_helper
INFO - 2023-12-14 11:19:04 --> Helper loaded: file_helper
INFO - 2023-12-14 11:19:04 --> Helper loaded: form_helper
INFO - 2023-12-14 11:19:04 --> Helper loaded: my_helper
INFO - 2023-12-14 11:19:04 --> Database Driver Class Initialized
INFO - 2023-12-14 11:19:05 --> Final output sent to browser
DEBUG - 2023-12-14 11:19:05 --> Total execution time: 31.9068
INFO - 2023-12-14 11:19:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:19:05 --> Controller Class Initialized
DEBUG - 2023-12-14 11:19:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:19:18 --> Config Class Initialized
INFO - 2023-12-14 11:19:18 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:19:18 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:19:18 --> Utf8 Class Initialized
INFO - 2023-12-14 11:19:18 --> URI Class Initialized
INFO - 2023-12-14 11:19:18 --> Router Class Initialized
INFO - 2023-12-14 11:19:18 --> Output Class Initialized
INFO - 2023-12-14 11:19:18 --> Security Class Initialized
DEBUG - 2023-12-14 11:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:19:18 --> Input Class Initialized
INFO - 2023-12-14 11:19:18 --> Language Class Initialized
INFO - 2023-12-14 11:19:19 --> Language Class Initialized
INFO - 2023-12-14 11:19:19 --> Config Class Initialized
INFO - 2023-12-14 11:19:19 --> Loader Class Initialized
INFO - 2023-12-14 11:19:19 --> Helper loaded: url_helper
INFO - 2023-12-14 11:19:19 --> Helper loaded: file_helper
INFO - 2023-12-14 11:19:19 --> Helper loaded: form_helper
INFO - 2023-12-14 11:19:19 --> Helper loaded: my_helper
INFO - 2023-12-14 11:19:19 --> Database Driver Class Initialized
INFO - 2023-12-14 11:19:30 --> Config Class Initialized
INFO - 2023-12-14 11:19:30 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:19:30 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:19:30 --> Utf8 Class Initialized
INFO - 2023-12-14 11:19:30 --> URI Class Initialized
INFO - 2023-12-14 11:19:30 --> Router Class Initialized
INFO - 2023-12-14 11:19:30 --> Output Class Initialized
INFO - 2023-12-14 11:19:30 --> Security Class Initialized
DEBUG - 2023-12-14 11:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:19:30 --> Input Class Initialized
INFO - 2023-12-14 11:19:30 --> Language Class Initialized
INFO - 2023-12-14 11:19:30 --> Language Class Initialized
INFO - 2023-12-14 11:19:30 --> Config Class Initialized
INFO - 2023-12-14 11:19:30 --> Loader Class Initialized
INFO - 2023-12-14 11:19:30 --> Helper loaded: url_helper
INFO - 2023-12-14 11:19:30 --> Helper loaded: file_helper
INFO - 2023-12-14 11:19:30 --> Helper loaded: form_helper
INFO - 2023-12-14 11:19:30 --> Helper loaded: my_helper
INFO - 2023-12-14 11:19:30 --> Database Driver Class Initialized
INFO - 2023-12-14 11:19:32 --> Final output sent to browser
DEBUG - 2023-12-14 11:19:32 --> Total execution time: 28.2692
INFO - 2023-12-14 11:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:19:32 --> Controller Class Initialized
DEBUG - 2023-12-14 11:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:19:42 --> Final output sent to browser
DEBUG - 2023-12-14 11:19:42 --> Total execution time: 23.2746
INFO - 2023-12-14 11:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:19:42 --> Controller Class Initialized
DEBUG - 2023-12-14 11:19:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:19:47 --> Final output sent to browser
DEBUG - 2023-12-14 11:19:47 --> Total execution time: 17.1427
INFO - 2023-12-14 11:19:58 --> Config Class Initialized
INFO - 2023-12-14 11:19:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:19:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:19:58 --> Utf8 Class Initialized
INFO - 2023-12-14 11:19:58 --> URI Class Initialized
INFO - 2023-12-14 11:19:58 --> Router Class Initialized
INFO - 2023-12-14 11:19:58 --> Output Class Initialized
INFO - 2023-12-14 11:19:58 --> Security Class Initialized
DEBUG - 2023-12-14 11:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:19:58 --> Input Class Initialized
INFO - 2023-12-14 11:19:58 --> Language Class Initialized
INFO - 2023-12-14 11:19:58 --> Language Class Initialized
INFO - 2023-12-14 11:19:58 --> Config Class Initialized
INFO - 2023-12-14 11:19:58 --> Loader Class Initialized
INFO - 2023-12-14 11:19:58 --> Helper loaded: url_helper
INFO - 2023-12-14 11:19:58 --> Helper loaded: file_helper
INFO - 2023-12-14 11:19:58 --> Helper loaded: form_helper
INFO - 2023-12-14 11:19:58 --> Helper loaded: my_helper
INFO - 2023-12-14 11:19:58 --> Database Driver Class Initialized
INFO - 2023-12-14 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:19:58 --> Controller Class Initialized
DEBUG - 2023-12-14 11:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:20:02 --> Config Class Initialized
INFO - 2023-12-14 11:20:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:20:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:20:02 --> Utf8 Class Initialized
INFO - 2023-12-14 11:20:02 --> URI Class Initialized
INFO - 2023-12-14 11:20:02 --> Router Class Initialized
INFO - 2023-12-14 11:20:02 --> Output Class Initialized
INFO - 2023-12-14 11:20:02 --> Security Class Initialized
DEBUG - 2023-12-14 11:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:20:02 --> Input Class Initialized
INFO - 2023-12-14 11:20:02 --> Language Class Initialized
INFO - 2023-12-14 11:20:02 --> Language Class Initialized
INFO - 2023-12-14 11:20:02 --> Config Class Initialized
INFO - 2023-12-14 11:20:02 --> Loader Class Initialized
INFO - 2023-12-14 11:20:02 --> Helper loaded: url_helper
INFO - 2023-12-14 11:20:02 --> Helper loaded: file_helper
INFO - 2023-12-14 11:20:02 --> Helper loaded: form_helper
INFO - 2023-12-14 11:20:02 --> Helper loaded: my_helper
INFO - 2023-12-14 11:20:02 --> Database Driver Class Initialized
INFO - 2023-12-14 11:20:17 --> Final output sent to browser
DEBUG - 2023-12-14 11:20:17 --> Total execution time: 19.4177
INFO - 2023-12-14 11:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:20:17 --> Controller Class Initialized
DEBUG - 2023-12-14 11:20:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:20:26 --> Config Class Initialized
INFO - 2023-12-14 11:20:26 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:20:26 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:20:26 --> Utf8 Class Initialized
INFO - 2023-12-14 11:20:26 --> URI Class Initialized
INFO - 2023-12-14 11:20:26 --> Router Class Initialized
INFO - 2023-12-14 11:20:26 --> Output Class Initialized
INFO - 2023-12-14 11:20:26 --> Security Class Initialized
DEBUG - 2023-12-14 11:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:20:26 --> Input Class Initialized
INFO - 2023-12-14 11:20:26 --> Language Class Initialized
INFO - 2023-12-14 11:20:26 --> Language Class Initialized
INFO - 2023-12-14 11:20:26 --> Config Class Initialized
INFO - 2023-12-14 11:20:26 --> Loader Class Initialized
INFO - 2023-12-14 11:20:26 --> Helper loaded: url_helper
INFO - 2023-12-14 11:20:26 --> Helper loaded: file_helper
INFO - 2023-12-14 11:20:26 --> Helper loaded: form_helper
INFO - 2023-12-14 11:20:26 --> Helper loaded: my_helper
INFO - 2023-12-14 11:20:26 --> Database Driver Class Initialized
INFO - 2023-12-14 11:20:40 --> Final output sent to browser
DEBUG - 2023-12-14 11:20:40 --> Total execution time: 37.6820
INFO - 2023-12-14 11:20:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:20:40 --> Controller Class Initialized
DEBUG - 2023-12-14 11:20:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:20:41 --> Config Class Initialized
INFO - 2023-12-14 11:20:41 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:20:41 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:20:41 --> Utf8 Class Initialized
INFO - 2023-12-14 11:20:41 --> URI Class Initialized
INFO - 2023-12-14 11:20:41 --> Router Class Initialized
INFO - 2023-12-14 11:20:41 --> Output Class Initialized
INFO - 2023-12-14 11:20:41 --> Security Class Initialized
DEBUG - 2023-12-14 11:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:20:41 --> Input Class Initialized
INFO - 2023-12-14 11:20:41 --> Language Class Initialized
INFO - 2023-12-14 11:20:41 --> Language Class Initialized
INFO - 2023-12-14 11:20:41 --> Config Class Initialized
INFO - 2023-12-14 11:20:41 --> Loader Class Initialized
INFO - 2023-12-14 11:20:41 --> Helper loaded: url_helper
INFO - 2023-12-14 11:20:41 --> Helper loaded: file_helper
INFO - 2023-12-14 11:20:41 --> Helper loaded: form_helper
INFO - 2023-12-14 11:20:41 --> Helper loaded: my_helper
INFO - 2023-12-14 11:20:42 --> Database Driver Class Initialized
INFO - 2023-12-14 11:21:00 --> Final output sent to browser
DEBUG - 2023-12-14 11:21:00 --> Total execution time: 33.7789
INFO - 2023-12-14 11:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:21:00 --> Controller Class Initialized
DEBUG - 2023-12-14 11:21:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:21:15 --> Config Class Initialized
INFO - 2023-12-14 11:21:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:21:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:21:15 --> Utf8 Class Initialized
INFO - 2023-12-14 11:21:15 --> URI Class Initialized
INFO - 2023-12-14 11:21:15 --> Router Class Initialized
INFO - 2023-12-14 11:21:15 --> Output Class Initialized
INFO - 2023-12-14 11:21:15 --> Security Class Initialized
DEBUG - 2023-12-14 11:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:21:15 --> Input Class Initialized
INFO - 2023-12-14 11:21:15 --> Language Class Initialized
INFO - 2023-12-14 11:21:15 --> Language Class Initialized
INFO - 2023-12-14 11:21:15 --> Config Class Initialized
INFO - 2023-12-14 11:21:15 --> Loader Class Initialized
INFO - 2023-12-14 11:21:15 --> Helper loaded: url_helper
INFO - 2023-12-14 11:21:15 --> Helper loaded: file_helper
INFO - 2023-12-14 11:21:15 --> Helper loaded: form_helper
INFO - 2023-12-14 11:21:15 --> Helper loaded: my_helper
INFO - 2023-12-14 11:21:15 --> Database Driver Class Initialized
INFO - 2023-12-14 11:21:26 --> Final output sent to browser
DEBUG - 2023-12-14 11:21:26 --> Total execution time: 44.2409
INFO - 2023-12-14 11:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:21:26 --> Controller Class Initialized
DEBUG - 2023-12-14 11:21:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:21:39 --> Config Class Initialized
INFO - 2023-12-14 11:21:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:21:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:21:39 --> Utf8 Class Initialized
INFO - 2023-12-14 11:21:39 --> URI Class Initialized
INFO - 2023-12-14 11:21:39 --> Router Class Initialized
INFO - 2023-12-14 11:21:39 --> Output Class Initialized
INFO - 2023-12-14 11:21:39 --> Security Class Initialized
DEBUG - 2023-12-14 11:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:21:39 --> Input Class Initialized
INFO - 2023-12-14 11:21:39 --> Language Class Initialized
INFO - 2023-12-14 11:21:39 --> Language Class Initialized
INFO - 2023-12-14 11:21:39 --> Config Class Initialized
INFO - 2023-12-14 11:21:39 --> Loader Class Initialized
INFO - 2023-12-14 11:21:39 --> Helper loaded: url_helper
INFO - 2023-12-14 11:21:39 --> Helper loaded: file_helper
INFO - 2023-12-14 11:21:39 --> Helper loaded: form_helper
INFO - 2023-12-14 11:21:39 --> Helper loaded: my_helper
INFO - 2023-12-14 11:21:39 --> Database Driver Class Initialized
INFO - 2023-12-14 11:21:54 --> Final output sent to browser
DEBUG - 2023-12-14 11:21:54 --> Total execution time: 38.4627
INFO - 2023-12-14 11:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:21:54 --> Controller Class Initialized
DEBUG - 2023-12-14 11:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:22:08 --> Config Class Initialized
INFO - 2023-12-14 11:22:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:22:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:22:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:22:08 --> URI Class Initialized
INFO - 2023-12-14 11:22:08 --> Router Class Initialized
INFO - 2023-12-14 11:22:08 --> Output Class Initialized
INFO - 2023-12-14 11:22:08 --> Security Class Initialized
DEBUG - 2023-12-14 11:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:22:08 --> Input Class Initialized
INFO - 2023-12-14 11:22:08 --> Language Class Initialized
INFO - 2023-12-14 11:22:08 --> Language Class Initialized
INFO - 2023-12-14 11:22:08 --> Config Class Initialized
INFO - 2023-12-14 11:22:08 --> Loader Class Initialized
INFO - 2023-12-14 11:22:08 --> Helper loaded: url_helper
INFO - 2023-12-14 11:22:08 --> Helper loaded: file_helper
INFO - 2023-12-14 11:22:09 --> Helper loaded: form_helper
INFO - 2023-12-14 11:22:09 --> Helper loaded: my_helper
INFO - 2023-12-14 11:22:09 --> Database Driver Class Initialized
INFO - 2023-12-14 11:22:56 --> Final output sent to browser
DEBUG - 2023-12-14 11:22:56 --> Total execution time: 77.3388
INFO - 2023-12-14 11:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:22:56 --> Controller Class Initialized
DEBUG - 2023-12-14 11:22:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:23:08 --> Config Class Initialized
INFO - 2023-12-14 11:23:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:23:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:23:08 --> Utf8 Class Initialized
INFO - 2023-12-14 11:23:08 --> URI Class Initialized
INFO - 2023-12-14 11:23:08 --> Router Class Initialized
INFO - 2023-12-14 11:23:08 --> Output Class Initialized
INFO - 2023-12-14 11:23:09 --> Security Class Initialized
DEBUG - 2023-12-14 11:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:23:09 --> Input Class Initialized
INFO - 2023-12-14 11:23:09 --> Language Class Initialized
INFO - 2023-12-14 11:23:09 --> Language Class Initialized
INFO - 2023-12-14 11:23:09 --> Config Class Initialized
INFO - 2023-12-14 11:23:09 --> Loader Class Initialized
INFO - 2023-12-14 11:23:09 --> Helper loaded: url_helper
INFO - 2023-12-14 11:23:09 --> Helper loaded: file_helper
INFO - 2023-12-14 11:23:09 --> Helper loaded: form_helper
INFO - 2023-12-14 11:23:09 --> Helper loaded: my_helper
INFO - 2023-12-14 11:23:09 --> Database Driver Class Initialized
INFO - 2023-12-14 11:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:23:09 --> Controller Class Initialized
DEBUG - 2023-12-14 11:23:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:23:13 --> Config Class Initialized
INFO - 2023-12-14 11:23:13 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:23:13 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:23:13 --> Utf8 Class Initialized
INFO - 2023-12-14 11:23:13 --> URI Class Initialized
INFO - 2023-12-14 11:23:13 --> Router Class Initialized
INFO - 2023-12-14 11:23:13 --> Output Class Initialized
INFO - 2023-12-14 11:23:13 --> Security Class Initialized
DEBUG - 2023-12-14 11:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:23:13 --> Input Class Initialized
INFO - 2023-12-14 11:23:14 --> Language Class Initialized
INFO - 2023-12-14 11:23:14 --> Language Class Initialized
INFO - 2023-12-14 11:23:14 --> Config Class Initialized
INFO - 2023-12-14 11:23:14 --> Loader Class Initialized
INFO - 2023-12-14 11:23:14 --> Helper loaded: url_helper
INFO - 2023-12-14 11:23:14 --> Helper loaded: file_helper
INFO - 2023-12-14 11:23:14 --> Helper loaded: form_helper
INFO - 2023-12-14 11:23:14 --> Helper loaded: my_helper
INFO - 2023-12-14 11:23:14 --> Database Driver Class Initialized
INFO - 2023-12-14 11:23:57 --> Config Class Initialized
INFO - 2023-12-14 11:23:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:23:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:23:58 --> Utf8 Class Initialized
INFO - 2023-12-14 11:23:58 --> URI Class Initialized
INFO - 2023-12-14 11:23:58 --> Router Class Initialized
INFO - 2023-12-14 11:23:58 --> Output Class Initialized
INFO - 2023-12-14 11:23:58 --> Security Class Initialized
DEBUG - 2023-12-14 11:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:23:58 --> Input Class Initialized
INFO - 2023-12-14 11:23:58 --> Language Class Initialized
INFO - 2023-12-14 11:23:58 --> Language Class Initialized
INFO - 2023-12-14 11:23:58 --> Config Class Initialized
INFO - 2023-12-14 11:23:58 --> Loader Class Initialized
INFO - 2023-12-14 11:23:58 --> Helper loaded: url_helper
INFO - 2023-12-14 11:23:58 --> Helper loaded: file_helper
INFO - 2023-12-14 11:23:58 --> Helper loaded: form_helper
INFO - 2023-12-14 11:23:58 --> Helper loaded: my_helper
INFO - 2023-12-14 11:23:58 --> Database Driver Class Initialized
INFO - 2023-12-14 11:24:34 --> Config Class Initialized
INFO - 2023-12-14 11:24:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:24:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:24:34 --> Utf8 Class Initialized
INFO - 2023-12-14 11:24:34 --> URI Class Initialized
INFO - 2023-12-14 11:24:34 --> Router Class Initialized
INFO - 2023-12-14 11:24:34 --> Output Class Initialized
INFO - 2023-12-14 11:24:34 --> Security Class Initialized
DEBUG - 2023-12-14 11:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:24:35 --> Input Class Initialized
INFO - 2023-12-14 11:24:35 --> Language Class Initialized
INFO - 2023-12-14 11:24:35 --> Language Class Initialized
INFO - 2023-12-14 11:24:35 --> Config Class Initialized
INFO - 2023-12-14 11:24:35 --> Loader Class Initialized
INFO - 2023-12-14 11:24:35 --> Helper loaded: url_helper
INFO - 2023-12-14 11:24:35 --> Helper loaded: file_helper
INFO - 2023-12-14 11:24:35 --> Helper loaded: form_helper
INFO - 2023-12-14 11:24:35 --> Helper loaded: my_helper
INFO - 2023-12-14 11:24:35 --> Database Driver Class Initialized
INFO - 2023-12-14 11:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:24:51 --> Controller Class Initialized
DEBUG - 2023-12-14 11:24:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:25:01 --> Controller Class Initialized
DEBUG - 2023-12-14 11:25:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:25:41 --> Controller Class Initialized
DEBUG - 2023-12-14 11:25:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:26:36 --> Config Class Initialized
INFO - 2023-12-14 11:26:36 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:36 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:36 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:36 --> URI Class Initialized
INFO - 2023-12-14 11:26:36 --> Router Class Initialized
INFO - 2023-12-14 11:26:36 --> Output Class Initialized
INFO - 2023-12-14 11:26:36 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:36 --> Input Class Initialized
INFO - 2023-12-14 11:26:36 --> Language Class Initialized
INFO - 2023-12-14 11:26:36 --> Language Class Initialized
INFO - 2023-12-14 11:26:36 --> Config Class Initialized
INFO - 2023-12-14 11:26:36 --> Loader Class Initialized
INFO - 2023-12-14 11:26:36 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:36 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:36 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:36 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:37 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:37 --> Controller Class Initialized
DEBUG - 2023-12-14 11:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:26:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:26:37 --> Final output sent to browser
DEBUG - 2023-12-14 11:26:37 --> Total execution time: 1.0931
INFO - 2023-12-14 11:26:39 --> Config Class Initialized
INFO - 2023-12-14 11:26:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:39 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:39 --> URI Class Initialized
INFO - 2023-12-14 11:26:39 --> Router Class Initialized
INFO - 2023-12-14 11:26:39 --> Output Class Initialized
INFO - 2023-12-14 11:26:39 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:39 --> Input Class Initialized
INFO - 2023-12-14 11:26:39 --> Language Class Initialized
INFO - 2023-12-14 11:26:39 --> Language Class Initialized
INFO - 2023-12-14 11:26:39 --> Config Class Initialized
INFO - 2023-12-14 11:26:39 --> Loader Class Initialized
INFO - 2023-12-14 11:26:39 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:39 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:39 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:39 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:39 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:40 --> Controller Class Initialized
DEBUG - 2023-12-14 11:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-14 11:26:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:26:40 --> Final output sent to browser
DEBUG - 2023-12-14 11:26:40 --> Total execution time: 0.9317
INFO - 2023-12-14 11:26:48 --> Config Class Initialized
INFO - 2023-12-14 11:26:48 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:48 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:48 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:48 --> URI Class Initialized
INFO - 2023-12-14 11:26:48 --> Router Class Initialized
INFO - 2023-12-14 11:26:48 --> Output Class Initialized
INFO - 2023-12-14 11:26:48 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:48 --> Input Class Initialized
INFO - 2023-12-14 11:26:48 --> Language Class Initialized
INFO - 2023-12-14 11:26:49 --> Language Class Initialized
INFO - 2023-12-14 11:26:49 --> Config Class Initialized
INFO - 2023-12-14 11:26:49 --> Loader Class Initialized
INFO - 2023-12-14 11:26:49 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:49 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:49 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:49 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:49 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:49 --> Controller Class Initialized
DEBUG - 2023-12-14 11:26:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:26:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:26:49 --> Final output sent to browser
DEBUG - 2023-12-14 11:26:49 --> Total execution time: 0.7302
INFO - 2023-12-14 11:26:51 --> Config Class Initialized
INFO - 2023-12-14 11:26:51 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:51 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:51 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:51 --> URI Class Initialized
INFO - 2023-12-14 11:26:51 --> Router Class Initialized
INFO - 2023-12-14 11:26:51 --> Output Class Initialized
INFO - 2023-12-14 11:26:51 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:51 --> Input Class Initialized
INFO - 2023-12-14 11:26:51 --> Language Class Initialized
INFO - 2023-12-14 11:26:51 --> Language Class Initialized
INFO - 2023-12-14 11:26:51 --> Config Class Initialized
INFO - 2023-12-14 11:26:51 --> Loader Class Initialized
INFO - 2023-12-14 11:26:51 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:51 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:51 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:51 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:51 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:51 --> Controller Class Initialized
DEBUG - 2023-12-14 11:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:26:52 --> Config Class Initialized
INFO - 2023-12-14 11:26:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:52 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:52 --> URI Class Initialized
DEBUG - 2023-12-14 11:26:52 --> No URI present. Default controller set.
INFO - 2023-12-14 11:26:52 --> Router Class Initialized
INFO - 2023-12-14 11:26:52 --> Output Class Initialized
INFO - 2023-12-14 11:26:52 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:52 --> Input Class Initialized
INFO - 2023-12-14 11:26:52 --> Language Class Initialized
INFO - 2023-12-14 11:26:52 --> Language Class Initialized
INFO - 2023-12-14 11:26:52 --> Config Class Initialized
INFO - 2023-12-14 11:26:52 --> Loader Class Initialized
INFO - 2023-12-14 11:26:52 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:52 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:52 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:52 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:53 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:53 --> Controller Class Initialized
INFO - 2023-12-14 11:26:53 --> Config Class Initialized
INFO - 2023-12-14 11:26:53 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:26:53 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:26:53 --> Utf8 Class Initialized
INFO - 2023-12-14 11:26:53 --> URI Class Initialized
INFO - 2023-12-14 11:26:53 --> Router Class Initialized
INFO - 2023-12-14 11:26:53 --> Output Class Initialized
INFO - 2023-12-14 11:26:53 --> Security Class Initialized
DEBUG - 2023-12-14 11:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:26:53 --> Input Class Initialized
INFO - 2023-12-14 11:26:53 --> Language Class Initialized
INFO - 2023-12-14 11:26:53 --> Language Class Initialized
INFO - 2023-12-14 11:26:53 --> Config Class Initialized
INFO - 2023-12-14 11:26:53 --> Loader Class Initialized
INFO - 2023-12-14 11:26:53 --> Helper loaded: url_helper
INFO - 2023-12-14 11:26:53 --> Helper loaded: file_helper
INFO - 2023-12-14 11:26:53 --> Helper loaded: form_helper
INFO - 2023-12-14 11:26:53 --> Helper loaded: my_helper
INFO - 2023-12-14 11:26:53 --> Database Driver Class Initialized
INFO - 2023-12-14 11:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:26:53 --> Controller Class Initialized
DEBUG - 2023-12-14 11:26:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:26:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:26:53 --> Final output sent to browser
DEBUG - 2023-12-14 11:26:53 --> Total execution time: 0.5470
INFO - 2023-12-14 11:27:06 --> Config Class Initialized
INFO - 2023-12-14 11:27:06 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:27:06 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:27:06 --> Utf8 Class Initialized
INFO - 2023-12-14 11:27:06 --> URI Class Initialized
INFO - 2023-12-14 11:27:06 --> Router Class Initialized
INFO - 2023-12-14 11:27:06 --> Output Class Initialized
INFO - 2023-12-14 11:27:06 --> Security Class Initialized
DEBUG - 2023-12-14 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:27:06 --> Input Class Initialized
INFO - 2023-12-14 11:27:06 --> Language Class Initialized
INFO - 2023-12-14 11:27:06 --> Language Class Initialized
INFO - 2023-12-14 11:27:06 --> Config Class Initialized
INFO - 2023-12-14 11:27:06 --> Loader Class Initialized
INFO - 2023-12-14 11:27:06 --> Helper loaded: url_helper
INFO - 2023-12-14 11:27:06 --> Helper loaded: file_helper
INFO - 2023-12-14 11:27:06 --> Helper loaded: form_helper
INFO - 2023-12-14 11:27:06 --> Helper loaded: my_helper
INFO - 2023-12-14 11:27:06 --> Database Driver Class Initialized
INFO - 2023-12-14 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:27:06 --> Controller Class Initialized
INFO - 2023-12-14 11:27:06 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:27:06 --> Final output sent to browser
DEBUG - 2023-12-14 11:27:06 --> Total execution time: 0.6928
INFO - 2023-12-14 11:27:07 --> Config Class Initialized
INFO - 2023-12-14 11:27:07 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:27:07 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:27:07 --> Utf8 Class Initialized
INFO - 2023-12-14 11:27:07 --> URI Class Initialized
INFO - 2023-12-14 11:27:07 --> Router Class Initialized
INFO - 2023-12-14 11:27:07 --> Output Class Initialized
INFO - 2023-12-14 11:27:07 --> Security Class Initialized
DEBUG - 2023-12-14 11:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:27:07 --> Input Class Initialized
INFO - 2023-12-14 11:27:07 --> Language Class Initialized
INFO - 2023-12-14 11:27:07 --> Language Class Initialized
INFO - 2023-12-14 11:27:07 --> Config Class Initialized
INFO - 2023-12-14 11:27:07 --> Loader Class Initialized
INFO - 2023-12-14 11:27:07 --> Helper loaded: url_helper
INFO - 2023-12-14 11:27:07 --> Helper loaded: file_helper
INFO - 2023-12-14 11:27:07 --> Helper loaded: form_helper
INFO - 2023-12-14 11:27:07 --> Helper loaded: my_helper
INFO - 2023-12-14 11:27:07 --> Database Driver Class Initialized
INFO - 2023-12-14 11:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:27:07 --> Controller Class Initialized
DEBUG - 2023-12-14 11:27:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 11:27:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:27:07 --> Final output sent to browser
DEBUG - 2023-12-14 11:27:07 --> Total execution time: 0.6303
INFO - 2023-12-14 11:28:10 --> Final output sent to browser
DEBUG - 2023-12-14 11:28:10 --> Total execution time: 79.0290
INFO - 2023-12-14 11:28:32 --> Config Class Initialized
INFO - 2023-12-14 11:28:32 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:28:32 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:28:32 --> Utf8 Class Initialized
INFO - 2023-12-14 11:28:32 --> URI Class Initialized
INFO - 2023-12-14 11:28:32 --> Router Class Initialized
INFO - 2023-12-14 11:28:32 --> Output Class Initialized
INFO - 2023-12-14 11:28:32 --> Security Class Initialized
DEBUG - 2023-12-14 11:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:28:32 --> Input Class Initialized
INFO - 2023-12-14 11:28:32 --> Language Class Initialized
INFO - 2023-12-14 11:28:32 --> Language Class Initialized
INFO - 2023-12-14 11:28:32 --> Config Class Initialized
INFO - 2023-12-14 11:28:32 --> Loader Class Initialized
INFO - 2023-12-14 11:28:32 --> Helper loaded: url_helper
INFO - 2023-12-14 11:28:32 --> Helper loaded: file_helper
INFO - 2023-12-14 11:28:32 --> Helper loaded: form_helper
INFO - 2023-12-14 11:28:32 --> Helper loaded: my_helper
INFO - 2023-12-14 11:28:32 --> Database Driver Class Initialized
INFO - 2023-12-14 11:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:28:33 --> Controller Class Initialized
DEBUG - 2023-12-14 11:28:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:29:48 --> Final output sent to browser
DEBUG - 2023-12-14 11:29:48 --> Total execution time: 76.3843
INFO - 2023-12-14 11:30:10 --> Config Class Initialized
INFO - 2023-12-14 11:30:10 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:30:10 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:30:10 --> Utf8 Class Initialized
INFO - 2023-12-14 11:30:10 --> URI Class Initialized
INFO - 2023-12-14 11:30:10 --> Router Class Initialized
INFO - 2023-12-14 11:30:10 --> Output Class Initialized
INFO - 2023-12-14 11:30:10 --> Security Class Initialized
DEBUG - 2023-12-14 11:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:30:10 --> Input Class Initialized
INFO - 2023-12-14 11:30:10 --> Language Class Initialized
INFO - 2023-12-14 11:30:10 --> Language Class Initialized
INFO - 2023-12-14 11:30:10 --> Config Class Initialized
INFO - 2023-12-14 11:30:10 --> Loader Class Initialized
INFO - 2023-12-14 11:30:10 --> Helper loaded: url_helper
INFO - 2023-12-14 11:30:10 --> Helper loaded: file_helper
INFO - 2023-12-14 11:30:10 --> Helper loaded: form_helper
INFO - 2023-12-14 11:30:10 --> Helper loaded: my_helper
INFO - 2023-12-14 11:30:10 --> Database Driver Class Initialized
INFO - 2023-12-14 11:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:30:10 --> Controller Class Initialized
DEBUG - 2023-12-14 11:30:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:30:57 --> Final output sent to browser
DEBUG - 2023-12-14 11:30:57 --> Total execution time: 47.3118
INFO - 2023-12-14 11:31:15 --> Config Class Initialized
INFO - 2023-12-14 11:31:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:31:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:31:15 --> Utf8 Class Initialized
INFO - 2023-12-14 11:31:15 --> URI Class Initialized
INFO - 2023-12-14 11:31:15 --> Router Class Initialized
INFO - 2023-12-14 11:31:15 --> Output Class Initialized
INFO - 2023-12-14 11:31:15 --> Security Class Initialized
DEBUG - 2023-12-14 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:31:15 --> Input Class Initialized
INFO - 2023-12-14 11:31:15 --> Language Class Initialized
INFO - 2023-12-14 11:31:15 --> Language Class Initialized
INFO - 2023-12-14 11:31:15 --> Config Class Initialized
INFO - 2023-12-14 11:31:15 --> Loader Class Initialized
INFO - 2023-12-14 11:31:15 --> Helper loaded: url_helper
INFO - 2023-12-14 11:31:15 --> Helper loaded: file_helper
INFO - 2023-12-14 11:31:15 --> Helper loaded: form_helper
INFO - 2023-12-14 11:31:15 --> Helper loaded: my_helper
INFO - 2023-12-14 11:31:15 --> Database Driver Class Initialized
INFO - 2023-12-14 11:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:31:15 --> Controller Class Initialized
DEBUG - 2023-12-14 11:31:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:31:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:31:15 --> Final output sent to browser
DEBUG - 2023-12-14 11:31:15 --> Total execution time: 0.2413
INFO - 2023-12-14 11:31:27 --> Config Class Initialized
INFO - 2023-12-14 11:31:27 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:31:27 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:31:27 --> Utf8 Class Initialized
INFO - 2023-12-14 11:31:27 --> URI Class Initialized
INFO - 2023-12-14 11:31:27 --> Router Class Initialized
INFO - 2023-12-14 11:31:27 --> Output Class Initialized
INFO - 2023-12-14 11:31:27 --> Security Class Initialized
DEBUG - 2023-12-14 11:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:31:27 --> Input Class Initialized
INFO - 2023-12-14 11:31:27 --> Language Class Initialized
INFO - 2023-12-14 11:31:27 --> Language Class Initialized
INFO - 2023-12-14 11:31:27 --> Config Class Initialized
INFO - 2023-12-14 11:31:27 --> Loader Class Initialized
INFO - 2023-12-14 11:31:27 --> Helper loaded: url_helper
INFO - 2023-12-14 11:31:27 --> Helper loaded: file_helper
INFO - 2023-12-14 11:31:27 --> Helper loaded: form_helper
INFO - 2023-12-14 11:31:27 --> Helper loaded: my_helper
INFO - 2023-12-14 11:31:27 --> Database Driver Class Initialized
INFO - 2023-12-14 11:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:31:27 --> Controller Class Initialized
DEBUG - 2023-12-14 11:31:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 11:31:48 --> Final output sent to browser
DEBUG - 2023-12-14 11:31:48 --> Total execution time: 21.5122
INFO - 2023-12-14 11:32:05 --> Config Class Initialized
INFO - 2023-12-14 11:32:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:32:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:32:05 --> Utf8 Class Initialized
INFO - 2023-12-14 11:32:05 --> URI Class Initialized
INFO - 2023-12-14 11:32:05 --> Router Class Initialized
INFO - 2023-12-14 11:32:05 --> Output Class Initialized
INFO - 2023-12-14 11:32:05 --> Security Class Initialized
DEBUG - 2023-12-14 11:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:32:05 --> Input Class Initialized
INFO - 2023-12-14 11:32:05 --> Language Class Initialized
INFO - 2023-12-14 11:32:05 --> Language Class Initialized
INFO - 2023-12-14 11:32:05 --> Config Class Initialized
INFO - 2023-12-14 11:32:05 --> Loader Class Initialized
INFO - 2023-12-14 11:32:05 --> Helper loaded: url_helper
INFO - 2023-12-14 11:32:05 --> Helper loaded: file_helper
INFO - 2023-12-14 11:32:05 --> Helper loaded: form_helper
INFO - 2023-12-14 11:32:05 --> Helper loaded: my_helper
INFO - 2023-12-14 11:32:05 --> Database Driver Class Initialized
INFO - 2023-12-14 11:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:32:05 --> Controller Class Initialized
DEBUG - 2023-12-14 11:32:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 11:32:10 --> Final output sent to browser
DEBUG - 2023-12-14 11:32:10 --> Total execution time: 5.1960
INFO - 2023-12-14 11:32:24 --> Config Class Initialized
INFO - 2023-12-14 11:32:24 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:32:24 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:32:24 --> Utf8 Class Initialized
INFO - 2023-12-14 11:32:24 --> URI Class Initialized
INFO - 2023-12-14 11:32:24 --> Router Class Initialized
INFO - 2023-12-14 11:32:24 --> Output Class Initialized
INFO - 2023-12-14 11:32:24 --> Security Class Initialized
DEBUG - 2023-12-14 11:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:32:24 --> Input Class Initialized
INFO - 2023-12-14 11:32:24 --> Language Class Initialized
INFO - 2023-12-14 11:32:24 --> Language Class Initialized
INFO - 2023-12-14 11:32:24 --> Config Class Initialized
INFO - 2023-12-14 11:32:24 --> Loader Class Initialized
INFO - 2023-12-14 11:32:24 --> Helper loaded: url_helper
INFO - 2023-12-14 11:32:24 --> Helper loaded: file_helper
INFO - 2023-12-14 11:32:24 --> Helper loaded: form_helper
INFO - 2023-12-14 11:32:24 --> Helper loaded: my_helper
INFO - 2023-12-14 11:32:24 --> Database Driver Class Initialized
INFO - 2023-12-14 11:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:32:24 --> Controller Class Initialized
DEBUG - 2023-12-14 11:32:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl1/views/list.php
DEBUG - 2023-12-14 11:32:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:32:25 --> Final output sent to browser
DEBUG - 2023-12-14 11:32:25 --> Total execution time: 0.2848
INFO - 2023-12-14 11:32:57 --> Config Class Initialized
INFO - 2023-12-14 11:32:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:32:57 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:32:57 --> Utf8 Class Initialized
INFO - 2023-12-14 11:32:57 --> URI Class Initialized
INFO - 2023-12-14 11:32:57 --> Router Class Initialized
INFO - 2023-12-14 11:32:57 --> Output Class Initialized
INFO - 2023-12-14 11:32:57 --> Security Class Initialized
DEBUG - 2023-12-14 11:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:32:57 --> Input Class Initialized
INFO - 2023-12-14 11:32:57 --> Language Class Initialized
INFO - 2023-12-14 11:32:57 --> Language Class Initialized
INFO - 2023-12-14 11:32:57 --> Config Class Initialized
INFO - 2023-12-14 11:32:57 --> Loader Class Initialized
INFO - 2023-12-14 11:32:57 --> Helper loaded: url_helper
INFO - 2023-12-14 11:32:57 --> Helper loaded: file_helper
INFO - 2023-12-14 11:32:57 --> Helper loaded: form_helper
INFO - 2023-12-14 11:32:57 --> Helper loaded: my_helper
INFO - 2023-12-14 11:32:57 --> Database Driver Class Initialized
INFO - 2023-12-14 11:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:32:57 --> Controller Class Initialized
DEBUG - 2023-12-14 11:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_kl2/views/list.php
DEBUG - 2023-12-14 11:32:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:32:57 --> Final output sent to browser
DEBUG - 2023-12-14 11:32:57 --> Total execution time: 0.1830
INFO - 2023-12-14 11:33:09 --> Config Class Initialized
INFO - 2023-12-14 11:33:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:33:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:33:09 --> Utf8 Class Initialized
INFO - 2023-12-14 11:33:09 --> URI Class Initialized
INFO - 2023-12-14 11:33:10 --> Router Class Initialized
INFO - 2023-12-14 11:33:10 --> Output Class Initialized
INFO - 2023-12-14 11:33:10 --> Security Class Initialized
DEBUG - 2023-12-14 11:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:33:10 --> Input Class Initialized
INFO - 2023-12-14 11:33:10 --> Language Class Initialized
INFO - 2023-12-14 11:33:10 --> Language Class Initialized
INFO - 2023-12-14 11:33:10 --> Config Class Initialized
INFO - 2023-12-14 11:33:10 --> Loader Class Initialized
INFO - 2023-12-14 11:33:10 --> Helper loaded: url_helper
INFO - 2023-12-14 11:33:10 --> Helper loaded: file_helper
INFO - 2023-12-14 11:33:10 --> Helper loaded: form_helper
INFO - 2023-12-14 11:33:10 --> Helper loaded: my_helper
INFO - 2023-12-14 11:33:10 --> Database Driver Class Initialized
INFO - 2023-12-14 11:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:33:10 --> Controller Class Initialized
DEBUG - 2023-12-14 11:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 11:33:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:33:10 --> Final output sent to browser
DEBUG - 2023-12-14 11:33:10 --> Total execution time: 0.2728
INFO - 2023-12-14 11:33:14 --> Config Class Initialized
INFO - 2023-12-14 11:33:14 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:33:14 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:33:14 --> Utf8 Class Initialized
INFO - 2023-12-14 11:33:14 --> URI Class Initialized
INFO - 2023-12-14 11:33:14 --> Router Class Initialized
INFO - 2023-12-14 11:33:14 --> Output Class Initialized
INFO - 2023-12-14 11:33:14 --> Security Class Initialized
DEBUG - 2023-12-14 11:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:33:14 --> Input Class Initialized
INFO - 2023-12-14 11:33:14 --> Language Class Initialized
INFO - 2023-12-14 11:33:14 --> Language Class Initialized
INFO - 2023-12-14 11:33:14 --> Config Class Initialized
INFO - 2023-12-14 11:33:14 --> Loader Class Initialized
INFO - 2023-12-14 11:33:14 --> Helper loaded: url_helper
INFO - 2023-12-14 11:33:14 --> Helper loaded: file_helper
INFO - 2023-12-14 11:33:14 --> Helper loaded: form_helper
INFO - 2023-12-14 11:33:14 --> Helper loaded: my_helper
INFO - 2023-12-14 11:33:14 --> Database Driver Class Initialized
INFO - 2023-12-14 11:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:33:14 --> Controller Class Initialized
DEBUG - 2023-12-14 11:33:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 11:33:29 --> Final output sent to browser
DEBUG - 2023-12-14 11:33:29 --> Total execution time: 15.0894
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:34:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:34:34 --> Utf8 Class Initialized
INFO - 2023-12-14 11:34:34 --> URI Class Initialized
INFO - 2023-12-14 11:34:34 --> Router Class Initialized
INFO - 2023-12-14 11:34:34 --> Output Class Initialized
INFO - 2023-12-14 11:34:34 --> Security Class Initialized
DEBUG - 2023-12-14 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:34:34 --> Input Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Loader Class Initialized
INFO - 2023-12-14 11:34:34 --> Helper loaded: url_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: file_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: form_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: my_helper
INFO - 2023-12-14 11:34:34 --> Database Driver Class Initialized
INFO - 2023-12-14 11:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:34:34 --> Controller Class Initialized
INFO - 2023-12-14 11:34:34 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:34:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:34:34 --> Utf8 Class Initialized
INFO - 2023-12-14 11:34:34 --> URI Class Initialized
INFO - 2023-12-14 11:34:34 --> Router Class Initialized
INFO - 2023-12-14 11:34:34 --> Output Class Initialized
INFO - 2023-12-14 11:34:34 --> Security Class Initialized
DEBUG - 2023-12-14 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:34:34 --> Input Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Loader Class Initialized
INFO - 2023-12-14 11:34:34 --> Helper loaded: url_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: file_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: form_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: my_helper
INFO - 2023-12-14 11:34:34 --> Database Driver Class Initialized
INFO - 2023-12-14 11:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:34:34 --> Controller Class Initialized
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:34:34 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:34:34 --> Utf8 Class Initialized
INFO - 2023-12-14 11:34:34 --> URI Class Initialized
INFO - 2023-12-14 11:34:34 --> Router Class Initialized
INFO - 2023-12-14 11:34:34 --> Output Class Initialized
INFO - 2023-12-14 11:34:34 --> Security Class Initialized
DEBUG - 2023-12-14 11:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:34:34 --> Input Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Language Class Initialized
INFO - 2023-12-14 11:34:34 --> Config Class Initialized
INFO - 2023-12-14 11:34:34 --> Loader Class Initialized
INFO - 2023-12-14 11:34:34 --> Helper loaded: url_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: file_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: form_helper
INFO - 2023-12-14 11:34:34 --> Helper loaded: my_helper
INFO - 2023-12-14 11:34:34 --> Database Driver Class Initialized
INFO - 2023-12-14 11:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:34:34 --> Controller Class Initialized
DEBUG - 2023-12-14 11:34:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 11:34:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:34:34 --> Final output sent to browser
DEBUG - 2023-12-14 11:34:34 --> Total execution time: 0.1397
INFO - 2023-12-14 11:34:41 --> Config Class Initialized
INFO - 2023-12-14 11:34:41 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:34:41 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:34:41 --> Utf8 Class Initialized
INFO - 2023-12-14 11:34:41 --> URI Class Initialized
INFO - 2023-12-14 11:34:41 --> Router Class Initialized
INFO - 2023-12-14 11:34:41 --> Output Class Initialized
INFO - 2023-12-14 11:34:41 --> Security Class Initialized
DEBUG - 2023-12-14 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:34:41 --> Input Class Initialized
INFO - 2023-12-14 11:34:41 --> Language Class Initialized
INFO - 2023-12-14 11:34:41 --> Language Class Initialized
INFO - 2023-12-14 11:34:41 --> Config Class Initialized
INFO - 2023-12-14 11:34:41 --> Loader Class Initialized
INFO - 2023-12-14 11:34:41 --> Helper loaded: url_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: file_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: form_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: my_helper
INFO - 2023-12-14 11:34:41 --> Database Driver Class Initialized
INFO - 2023-12-14 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:34:41 --> Controller Class Initialized
INFO - 2023-12-14 11:34:41 --> Helper loaded: cookie_helper
INFO - 2023-12-14 11:34:41 --> Final output sent to browser
DEBUG - 2023-12-14 11:34:41 --> Total execution time: 0.1319
INFO - 2023-12-14 11:34:41 --> Config Class Initialized
INFO - 2023-12-14 11:34:41 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:34:41 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:34:41 --> Utf8 Class Initialized
INFO - 2023-12-14 11:34:41 --> URI Class Initialized
INFO - 2023-12-14 11:34:41 --> Router Class Initialized
INFO - 2023-12-14 11:34:41 --> Output Class Initialized
INFO - 2023-12-14 11:34:41 --> Security Class Initialized
DEBUG - 2023-12-14 11:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:34:41 --> Input Class Initialized
INFO - 2023-12-14 11:34:41 --> Language Class Initialized
INFO - 2023-12-14 11:34:41 --> Language Class Initialized
INFO - 2023-12-14 11:34:41 --> Config Class Initialized
INFO - 2023-12-14 11:34:41 --> Loader Class Initialized
INFO - 2023-12-14 11:34:41 --> Helper loaded: url_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: file_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: form_helper
INFO - 2023-12-14 11:34:41 --> Helper loaded: my_helper
INFO - 2023-12-14 11:34:41 --> Database Driver Class Initialized
INFO - 2023-12-14 11:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:34:41 --> Controller Class Initialized
DEBUG - 2023-12-14 11:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 11:34:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 11:34:41 --> Final output sent to browser
DEBUG - 2023-12-14 11:34:41 --> Total execution time: 0.1399
INFO - 2023-12-14 11:36:18 --> Config Class Initialized
INFO - 2023-12-14 11:36:18 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:36:18 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:36:18 --> Utf8 Class Initialized
INFO - 2023-12-14 11:36:18 --> URI Class Initialized
INFO - 2023-12-14 11:36:18 --> Router Class Initialized
INFO - 2023-12-14 11:36:18 --> Output Class Initialized
INFO - 2023-12-14 11:36:18 --> Security Class Initialized
DEBUG - 2023-12-14 11:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:36:18 --> Input Class Initialized
INFO - 2023-12-14 11:36:18 --> Language Class Initialized
INFO - 2023-12-14 11:36:18 --> Language Class Initialized
INFO - 2023-12-14 11:36:18 --> Config Class Initialized
INFO - 2023-12-14 11:36:18 --> Loader Class Initialized
INFO - 2023-12-14 11:36:19 --> Helper loaded: url_helper
INFO - 2023-12-14 11:36:19 --> Helper loaded: file_helper
INFO - 2023-12-14 11:36:19 --> Helper loaded: form_helper
INFO - 2023-12-14 11:36:19 --> Helper loaded: my_helper
INFO - 2023-12-14 11:36:19 --> Database Driver Class Initialized
INFO - 2023-12-14 11:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:36:19 --> Controller Class Initialized
DEBUG - 2023-12-14 11:36:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 11:36:25 --> Config Class Initialized
INFO - 2023-12-14 11:36:25 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:36:25 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:36:25 --> Utf8 Class Initialized
INFO - 2023-12-14 11:36:25 --> URI Class Initialized
INFO - 2023-12-14 11:36:25 --> Router Class Initialized
INFO - 2023-12-14 11:36:25 --> Output Class Initialized
INFO - 2023-12-14 11:36:25 --> Security Class Initialized
DEBUG - 2023-12-14 11:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:36:25 --> Input Class Initialized
INFO - 2023-12-14 11:36:25 --> Language Class Initialized
INFO - 2023-12-14 11:36:25 --> Language Class Initialized
INFO - 2023-12-14 11:36:25 --> Config Class Initialized
INFO - 2023-12-14 11:36:25 --> Loader Class Initialized
INFO - 2023-12-14 11:36:25 --> Helper loaded: url_helper
INFO - 2023-12-14 11:36:25 --> Helper loaded: file_helper
INFO - 2023-12-14 11:36:25 --> Helper loaded: form_helper
INFO - 2023-12-14 11:36:25 --> Helper loaded: my_helper
INFO - 2023-12-14 11:36:25 --> Database Driver Class Initialized
INFO - 2023-12-14 11:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:36:25 --> Controller Class Initialized
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:36:26 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 11:36:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 11:36:28 --> Config Class Initialized
INFO - 2023-12-14 11:36:28 --> Hooks Class Initialized
DEBUG - 2023-12-14 11:36:28 --> UTF-8 Support Enabled
INFO - 2023-12-14 11:36:28 --> Utf8 Class Initialized
INFO - 2023-12-14 11:36:28 --> URI Class Initialized
INFO - 2023-12-14 11:36:28 --> Router Class Initialized
INFO - 2023-12-14 11:36:28 --> Output Class Initialized
INFO - 2023-12-14 11:36:28 --> Security Class Initialized
DEBUG - 2023-12-14 11:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 11:36:28 --> Input Class Initialized
INFO - 2023-12-14 11:36:28 --> Language Class Initialized
INFO - 2023-12-14 11:36:28 --> Language Class Initialized
INFO - 2023-12-14 11:36:28 --> Config Class Initialized
INFO - 2023-12-14 11:36:28 --> Loader Class Initialized
INFO - 2023-12-14 11:36:28 --> Helper loaded: url_helper
INFO - 2023-12-14 11:36:28 --> Helper loaded: file_helper
INFO - 2023-12-14 11:36:28 --> Helper loaded: form_helper
INFO - 2023-12-14 11:36:28 --> Helper loaded: my_helper
INFO - 2023-12-14 11:36:29 --> Database Driver Class Initialized
INFO - 2023-12-14 11:36:38 --> Final output sent to browser
DEBUG - 2023-12-14 11:36:38 --> Total execution time: 19.2671
INFO - 2023-12-14 11:37:08 --> Final output sent to browser
DEBUG - 2023-12-14 11:37:08 --> Total execution time: 43.2780
INFO - 2023-12-14 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 11:37:08 --> Controller Class Initialized
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 11:37:08 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 11:37:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 11:37:32 --> Final output sent to browser
DEBUG - 2023-12-14 11:37:32 --> Total execution time: 63.8181
INFO - 2023-12-14 12:12:35 --> Config Class Initialized
INFO - 2023-12-14 12:12:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:12:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:12:35 --> Utf8 Class Initialized
INFO - 2023-12-14 12:12:35 --> URI Class Initialized
INFO - 2023-12-14 12:12:35 --> Router Class Initialized
INFO - 2023-12-14 12:12:35 --> Output Class Initialized
INFO - 2023-12-14 12:12:35 --> Security Class Initialized
DEBUG - 2023-12-14 12:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:12:35 --> Input Class Initialized
INFO - 2023-12-14 12:12:35 --> Language Class Initialized
INFO - 2023-12-14 12:12:35 --> Language Class Initialized
INFO - 2023-12-14 12:12:35 --> Config Class Initialized
INFO - 2023-12-14 12:12:35 --> Loader Class Initialized
INFO - 2023-12-14 12:12:35 --> Helper loaded: url_helper
INFO - 2023-12-14 12:12:35 --> Helper loaded: file_helper
INFO - 2023-12-14 12:12:35 --> Helper loaded: form_helper
INFO - 2023-12-14 12:12:35 --> Helper loaded: my_helper
INFO - 2023-12-14 12:12:35 --> Database Driver Class Initialized
INFO - 2023-12-14 12:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:12:36 --> Controller Class Initialized
DEBUG - 2023-12-14 12:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-14 12:12:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 12:12:36 --> Final output sent to browser
DEBUG - 2023-12-14 12:12:36 --> Total execution time: 0.0664
INFO - 2023-12-14 12:12:38 --> Config Class Initialized
INFO - 2023-12-14 12:12:38 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:12:38 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:12:38 --> Utf8 Class Initialized
INFO - 2023-12-14 12:12:38 --> URI Class Initialized
INFO - 2023-12-14 12:12:38 --> Router Class Initialized
INFO - 2023-12-14 12:12:38 --> Output Class Initialized
INFO - 2023-12-14 12:12:38 --> Security Class Initialized
DEBUG - 2023-12-14 12:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:12:38 --> Input Class Initialized
INFO - 2023-12-14 12:12:38 --> Language Class Initialized
INFO - 2023-12-14 12:12:38 --> Language Class Initialized
INFO - 2023-12-14 12:12:38 --> Config Class Initialized
INFO - 2023-12-14 12:12:38 --> Loader Class Initialized
INFO - 2023-12-14 12:12:38 --> Helper loaded: url_helper
INFO - 2023-12-14 12:12:38 --> Helper loaded: file_helper
INFO - 2023-12-14 12:12:38 --> Helper loaded: form_helper
INFO - 2023-12-14 12:12:38 --> Helper loaded: my_helper
INFO - 2023-12-14 12:12:38 --> Database Driver Class Initialized
INFO - 2023-12-14 12:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:12:38 --> Controller Class Initialized
INFO - 2023-12-14 12:12:38 --> Final output sent to browser
DEBUG - 2023-12-14 12:12:38 --> Total execution time: 0.0375
INFO - 2023-12-14 12:12:44 --> Config Class Initialized
INFO - 2023-12-14 12:12:44 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:12:44 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:12:44 --> Utf8 Class Initialized
INFO - 2023-12-14 12:12:44 --> URI Class Initialized
INFO - 2023-12-14 12:12:44 --> Router Class Initialized
INFO - 2023-12-14 12:12:44 --> Output Class Initialized
INFO - 2023-12-14 12:12:44 --> Security Class Initialized
DEBUG - 2023-12-14 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:12:44 --> Input Class Initialized
INFO - 2023-12-14 12:12:44 --> Language Class Initialized
INFO - 2023-12-14 12:12:44 --> Language Class Initialized
INFO - 2023-12-14 12:12:44 --> Config Class Initialized
INFO - 2023-12-14 12:12:44 --> Loader Class Initialized
INFO - 2023-12-14 12:12:44 --> Helper loaded: url_helper
INFO - 2023-12-14 12:12:44 --> Helper loaded: file_helper
INFO - 2023-12-14 12:12:44 --> Helper loaded: form_helper
INFO - 2023-12-14 12:12:44 --> Helper loaded: my_helper
INFO - 2023-12-14 12:12:44 --> Database Driver Class Initialized
INFO - 2023-12-14 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:12:44 --> Controller Class Initialized
INFO - 2023-12-14 12:12:44 --> Final output sent to browser
DEBUG - 2023-12-14 12:12:44 --> Total execution time: 0.0598
INFO - 2023-12-14 12:12:57 --> Config Class Initialized
INFO - 2023-12-14 12:12:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:12:57 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:12:57 --> Utf8 Class Initialized
INFO - 2023-12-14 12:12:57 --> URI Class Initialized
INFO - 2023-12-14 12:12:57 --> Router Class Initialized
INFO - 2023-12-14 12:12:58 --> Output Class Initialized
INFO - 2023-12-14 12:12:58 --> Security Class Initialized
DEBUG - 2023-12-14 12:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:12:58 --> Input Class Initialized
INFO - 2023-12-14 12:12:58 --> Language Class Initialized
INFO - 2023-12-14 12:12:58 --> Language Class Initialized
INFO - 2023-12-14 12:12:58 --> Config Class Initialized
INFO - 2023-12-14 12:12:58 --> Loader Class Initialized
INFO - 2023-12-14 12:12:58 --> Helper loaded: url_helper
INFO - 2023-12-14 12:12:58 --> Helper loaded: file_helper
INFO - 2023-12-14 12:12:58 --> Helper loaded: form_helper
INFO - 2023-12-14 12:12:58 --> Helper loaded: my_helper
INFO - 2023-12-14 12:12:58 --> Database Driver Class Initialized
INFO - 2023-12-14 12:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:12:58 --> Controller Class Initialized
DEBUG - 2023-12-14 12:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-14 12:12:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 12:12:58 --> Final output sent to browser
DEBUG - 2023-12-14 12:12:58 --> Total execution time: 0.0429
INFO - 2023-12-14 12:12:59 --> Config Class Initialized
INFO - 2023-12-14 12:12:59 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:12:59 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:12:59 --> Utf8 Class Initialized
INFO - 2023-12-14 12:12:59 --> URI Class Initialized
INFO - 2023-12-14 12:12:59 --> Router Class Initialized
INFO - 2023-12-14 12:12:59 --> Output Class Initialized
INFO - 2023-12-14 12:12:59 --> Security Class Initialized
DEBUG - 2023-12-14 12:12:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:12:59 --> Input Class Initialized
INFO - 2023-12-14 12:12:59 --> Language Class Initialized
INFO - 2023-12-14 12:12:59 --> Language Class Initialized
INFO - 2023-12-14 12:12:59 --> Config Class Initialized
INFO - 2023-12-14 12:12:59 --> Loader Class Initialized
INFO - 2023-12-14 12:12:59 --> Helper loaded: url_helper
INFO - 2023-12-14 12:12:59 --> Helper loaded: file_helper
INFO - 2023-12-14 12:12:59 --> Helper loaded: form_helper
INFO - 2023-12-14 12:12:59 --> Helper loaded: my_helper
INFO - 2023-12-14 12:12:59 --> Database Driver Class Initialized
INFO - 2023-12-14 12:12:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:12:59 --> Controller Class Initialized
DEBUG - 2023-12-14 12:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 12:12:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 12:12:59 --> Final output sent to browser
DEBUG - 2023-12-14 12:12:59 --> Total execution time: 0.0436
INFO - 2023-12-14 12:13:00 --> Config Class Initialized
INFO - 2023-12-14 12:13:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:13:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:13:00 --> Utf8 Class Initialized
INFO - 2023-12-14 12:13:00 --> URI Class Initialized
INFO - 2023-12-14 12:13:00 --> Router Class Initialized
INFO - 2023-12-14 12:13:00 --> Output Class Initialized
INFO - 2023-12-14 12:13:00 --> Security Class Initialized
DEBUG - 2023-12-14 12:13:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:13:00 --> Input Class Initialized
INFO - 2023-12-14 12:13:00 --> Language Class Initialized
INFO - 2023-12-14 12:13:00 --> Language Class Initialized
INFO - 2023-12-14 12:13:00 --> Config Class Initialized
INFO - 2023-12-14 12:13:00 --> Loader Class Initialized
INFO - 2023-12-14 12:13:00 --> Helper loaded: url_helper
INFO - 2023-12-14 12:13:00 --> Helper loaded: file_helper
INFO - 2023-12-14 12:13:00 --> Helper loaded: form_helper
INFO - 2023-12-14 12:13:00 --> Helper loaded: my_helper
INFO - 2023-12-14 12:13:00 --> Database Driver Class Initialized
INFO - 2023-12-14 12:13:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:13:00 --> Controller Class Initialized
DEBUG - 2023-12-14 12:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/riwayat_mengajar/views/list.php
DEBUG - 2023-12-14 12:13:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 12:13:00 --> Final output sent to browser
DEBUG - 2023-12-14 12:13:00 --> Total execution time: 0.0723
INFO - 2023-12-14 12:13:06 --> Config Class Initialized
INFO - 2023-12-14 12:13:06 --> Hooks Class Initialized
DEBUG - 2023-12-14 12:13:06 --> UTF-8 Support Enabled
INFO - 2023-12-14 12:13:06 --> Utf8 Class Initialized
INFO - 2023-12-14 12:13:06 --> URI Class Initialized
INFO - 2023-12-14 12:13:06 --> Router Class Initialized
INFO - 2023-12-14 12:13:06 --> Output Class Initialized
INFO - 2023-12-14 12:13:06 --> Security Class Initialized
DEBUG - 2023-12-14 12:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 12:13:06 --> Input Class Initialized
INFO - 2023-12-14 12:13:06 --> Language Class Initialized
INFO - 2023-12-14 12:13:06 --> Language Class Initialized
INFO - 2023-12-14 12:13:06 --> Config Class Initialized
INFO - 2023-12-14 12:13:06 --> Loader Class Initialized
INFO - 2023-12-14 12:13:06 --> Helper loaded: url_helper
INFO - 2023-12-14 12:13:06 --> Helper loaded: file_helper
INFO - 2023-12-14 12:13:06 --> Helper loaded: form_helper
INFO - 2023-12-14 12:13:06 --> Helper loaded: my_helper
INFO - 2023-12-14 12:13:06 --> Database Driver Class Initialized
INFO - 2023-12-14 12:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 12:13:06 --> Controller Class Initialized
DEBUG - 2023-12-14 12:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-14 12:13:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 12:13:06 --> Final output sent to browser
DEBUG - 2023-12-14 12:13:06 --> Total execution time: 0.0741
INFO - 2023-12-14 16:47:05 --> Config Class Initialized
INFO - 2023-12-14 16:47:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:05 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:05 --> URI Class Initialized
DEBUG - 2023-12-14 16:47:05 --> No URI present. Default controller set.
INFO - 2023-12-14 16:47:05 --> Router Class Initialized
INFO - 2023-12-14 16:47:05 --> Output Class Initialized
INFO - 2023-12-14 16:47:05 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:05 --> Input Class Initialized
INFO - 2023-12-14 16:47:05 --> Language Class Initialized
INFO - 2023-12-14 16:47:05 --> Language Class Initialized
INFO - 2023-12-14 16:47:05 --> Config Class Initialized
INFO - 2023-12-14 16:47:05 --> Loader Class Initialized
INFO - 2023-12-14 16:47:05 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:05 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:05 --> Controller Class Initialized
INFO - 2023-12-14 16:47:05 --> Config Class Initialized
INFO - 2023-12-14 16:47:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:05 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:05 --> URI Class Initialized
INFO - 2023-12-14 16:47:05 --> Router Class Initialized
INFO - 2023-12-14 16:47:05 --> Output Class Initialized
INFO - 2023-12-14 16:47:05 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:05 --> Input Class Initialized
INFO - 2023-12-14 16:47:05 --> Language Class Initialized
INFO - 2023-12-14 16:47:05 --> Language Class Initialized
INFO - 2023-12-14 16:47:05 --> Config Class Initialized
INFO - 2023-12-14 16:47:05 --> Loader Class Initialized
INFO - 2023-12-14 16:47:05 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:05 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:05 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:06 --> Controller Class Initialized
DEBUG - 2023-12-14 16:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 16:47:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:06 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:06 --> Total execution time: 0.0881
INFO - 2023-12-14 16:47:09 --> Config Class Initialized
INFO - 2023-12-14 16:47:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:09 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:09 --> URI Class Initialized
INFO - 2023-12-14 16:47:09 --> Router Class Initialized
INFO - 2023-12-14 16:47:09 --> Output Class Initialized
INFO - 2023-12-14 16:47:09 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:09 --> Input Class Initialized
INFO - 2023-12-14 16:47:09 --> Language Class Initialized
INFO - 2023-12-14 16:47:09 --> Language Class Initialized
INFO - 2023-12-14 16:47:09 --> Config Class Initialized
INFO - 2023-12-14 16:47:09 --> Loader Class Initialized
INFO - 2023-12-14 16:47:09 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:09 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:09 --> Controller Class Initialized
INFO - 2023-12-14 16:47:09 --> Helper loaded: cookie_helper
INFO - 2023-12-14 16:47:09 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:09 --> Total execution time: 0.1045
INFO - 2023-12-14 16:47:09 --> Config Class Initialized
INFO - 2023-12-14 16:47:09 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:09 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:09 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:09 --> URI Class Initialized
INFO - 2023-12-14 16:47:09 --> Router Class Initialized
INFO - 2023-12-14 16:47:09 --> Output Class Initialized
INFO - 2023-12-14 16:47:09 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:09 --> Input Class Initialized
INFO - 2023-12-14 16:47:09 --> Language Class Initialized
INFO - 2023-12-14 16:47:09 --> Language Class Initialized
INFO - 2023-12-14 16:47:09 --> Config Class Initialized
INFO - 2023-12-14 16:47:09 --> Loader Class Initialized
INFO - 2023-12-14 16:47:09 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:09 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:09 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:09 --> Controller Class Initialized
DEBUG - 2023-12-14 16:47:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 16:47:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:09 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:09 --> Total execution time: 0.1071
INFO - 2023-12-14 16:47:12 --> Config Class Initialized
INFO - 2023-12-14 16:47:12 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:12 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:12 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:12 --> URI Class Initialized
DEBUG - 2023-12-14 16:47:12 --> No URI present. Default controller set.
INFO - 2023-12-14 16:47:12 --> Router Class Initialized
INFO - 2023-12-14 16:47:12 --> Output Class Initialized
INFO - 2023-12-14 16:47:12 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:12 --> Input Class Initialized
INFO - 2023-12-14 16:47:12 --> Language Class Initialized
INFO - 2023-12-14 16:47:12 --> Language Class Initialized
INFO - 2023-12-14 16:47:12 --> Config Class Initialized
INFO - 2023-12-14 16:47:12 --> Loader Class Initialized
INFO - 2023-12-14 16:47:12 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:12 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:12 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:12 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:12 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:12 --> Controller Class Initialized
DEBUG - 2023-12-14 16:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 16:47:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:12 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:12 --> Total execution time: 0.0405
INFO - 2023-12-14 16:47:20 --> Config Class Initialized
INFO - 2023-12-14 16:47:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:20 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:20 --> URI Class Initialized
INFO - 2023-12-14 16:47:20 --> Router Class Initialized
INFO - 2023-12-14 16:47:20 --> Output Class Initialized
INFO - 2023-12-14 16:47:20 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:20 --> Input Class Initialized
INFO - 2023-12-14 16:47:20 --> Language Class Initialized
INFO - 2023-12-14 16:47:20 --> Language Class Initialized
INFO - 2023-12-14 16:47:20 --> Config Class Initialized
INFO - 2023-12-14 16:47:20 --> Loader Class Initialized
INFO - 2023-12-14 16:47:20 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:20 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:20 --> Controller Class Initialized
DEBUG - 2023-12-14 16:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-12-14 16:47:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:20 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:20 --> Total execution time: 0.0633
INFO - 2023-12-14 16:47:20 --> Config Class Initialized
INFO - 2023-12-14 16:47:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:20 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:20 --> URI Class Initialized
INFO - 2023-12-14 16:47:20 --> Router Class Initialized
INFO - 2023-12-14 16:47:20 --> Output Class Initialized
INFO - 2023-12-14 16:47:20 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:20 --> Input Class Initialized
INFO - 2023-12-14 16:47:20 --> Language Class Initialized
ERROR - 2023-12-14 16:47:20 --> 404 Page Not Found: /index
INFO - 2023-12-14 16:47:20 --> Config Class Initialized
INFO - 2023-12-14 16:47:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:20 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:20 --> URI Class Initialized
INFO - 2023-12-14 16:47:20 --> Router Class Initialized
INFO - 2023-12-14 16:47:20 --> Output Class Initialized
INFO - 2023-12-14 16:47:20 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:20 --> Input Class Initialized
INFO - 2023-12-14 16:47:20 --> Language Class Initialized
INFO - 2023-12-14 16:47:20 --> Language Class Initialized
INFO - 2023-12-14 16:47:20 --> Config Class Initialized
INFO - 2023-12-14 16:47:20 --> Loader Class Initialized
INFO - 2023-12-14 16:47:20 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:20 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:20 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:20 --> Controller Class Initialized
INFO - 2023-12-14 16:47:48 --> Config Class Initialized
INFO - 2023-12-14 16:47:48 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:48 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:48 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:48 --> URI Class Initialized
INFO - 2023-12-14 16:47:48 --> Router Class Initialized
INFO - 2023-12-14 16:47:48 --> Output Class Initialized
INFO - 2023-12-14 16:47:48 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:48 --> Input Class Initialized
INFO - 2023-12-14 16:47:48 --> Language Class Initialized
INFO - 2023-12-14 16:47:48 --> Language Class Initialized
INFO - 2023-12-14 16:47:48 --> Config Class Initialized
INFO - 2023-12-14 16:47:48 --> Loader Class Initialized
INFO - 2023-12-14 16:47:48 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:48 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:48 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:48 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:49 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:49 --> Controller Class Initialized
DEBUG - 2023-12-14 16:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-12-14 16:47:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:49 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:49 --> Total execution time: 0.0351
INFO - 2023-12-14 16:47:49 --> Config Class Initialized
INFO - 2023-12-14 16:47:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:49 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:49 --> URI Class Initialized
INFO - 2023-12-14 16:47:49 --> Router Class Initialized
INFO - 2023-12-14 16:47:49 --> Output Class Initialized
INFO - 2023-12-14 16:47:49 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:49 --> Input Class Initialized
INFO - 2023-12-14 16:47:49 --> Language Class Initialized
ERROR - 2023-12-14 16:47:49 --> 404 Page Not Found: /index
INFO - 2023-12-14 16:47:49 --> Config Class Initialized
INFO - 2023-12-14 16:47:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:49 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:49 --> URI Class Initialized
INFO - 2023-12-14 16:47:49 --> Router Class Initialized
INFO - 2023-12-14 16:47:49 --> Output Class Initialized
INFO - 2023-12-14 16:47:49 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:49 --> Input Class Initialized
INFO - 2023-12-14 16:47:49 --> Language Class Initialized
INFO - 2023-12-14 16:47:49 --> Language Class Initialized
INFO - 2023-12-14 16:47:49 --> Config Class Initialized
INFO - 2023-12-14 16:47:49 --> Loader Class Initialized
INFO - 2023-12-14 16:47:49 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:49 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:49 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:49 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:49 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:49 --> Controller Class Initialized
INFO - 2023-12-14 16:47:57 --> Config Class Initialized
INFO - 2023-12-14 16:47:57 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:47:57 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:47:57 --> Utf8 Class Initialized
INFO - 2023-12-14 16:47:57 --> URI Class Initialized
INFO - 2023-12-14 16:47:57 --> Router Class Initialized
INFO - 2023-12-14 16:47:57 --> Output Class Initialized
INFO - 2023-12-14 16:47:57 --> Security Class Initialized
DEBUG - 2023-12-14 16:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:47:57 --> Input Class Initialized
INFO - 2023-12-14 16:47:57 --> Language Class Initialized
INFO - 2023-12-14 16:47:57 --> Language Class Initialized
INFO - 2023-12-14 16:47:57 --> Config Class Initialized
INFO - 2023-12-14 16:47:57 --> Loader Class Initialized
INFO - 2023-12-14 16:47:57 --> Helper loaded: url_helper
INFO - 2023-12-14 16:47:57 --> Helper loaded: file_helper
INFO - 2023-12-14 16:47:57 --> Helper loaded: form_helper
INFO - 2023-12-14 16:47:57 --> Helper loaded: my_helper
INFO - 2023-12-14 16:47:57 --> Database Driver Class Initialized
INFO - 2023-12-14 16:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:47:57 --> Controller Class Initialized
ERROR - 2023-12-14 16:47:57 --> Severity: Notice --> Undefined variable: status_form /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php 231
DEBUG - 2023-12-14 16:47:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/form.php
DEBUG - 2023-12-14 16:47:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:47:57 --> Final output sent to browser
DEBUG - 2023-12-14 16:47:57 --> Total execution time: 0.0383
INFO - 2023-12-14 16:48:02 --> Config Class Initialized
INFO - 2023-12-14 16:48:02 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:02 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:02 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:02 --> URI Class Initialized
INFO - 2023-12-14 16:48:02 --> Router Class Initialized
INFO - 2023-12-14 16:48:02 --> Output Class Initialized
INFO - 2023-12-14 16:48:02 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:02 --> Input Class Initialized
INFO - 2023-12-14 16:48:02 --> Language Class Initialized
INFO - 2023-12-14 16:48:02 --> Language Class Initialized
INFO - 2023-12-14 16:48:02 --> Config Class Initialized
INFO - 2023-12-14 16:48:02 --> Loader Class Initialized
INFO - 2023-12-14 16:48:02 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:02 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:02 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:02 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:02 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:03 --> Controller Class Initialized
DEBUG - 2023-12-14 16:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-12-14 16:48:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:48:03 --> Final output sent to browser
DEBUG - 2023-12-14 16:48:03 --> Total execution time: 0.1671
INFO - 2023-12-14 16:48:03 --> Config Class Initialized
INFO - 2023-12-14 16:48:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:03 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:03 --> URI Class Initialized
INFO - 2023-12-14 16:48:03 --> Router Class Initialized
INFO - 2023-12-14 16:48:03 --> Output Class Initialized
INFO - 2023-12-14 16:48:03 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:03 --> Input Class Initialized
INFO - 2023-12-14 16:48:03 --> Language Class Initialized
ERROR - 2023-12-14 16:48:03 --> 404 Page Not Found: /index
INFO - 2023-12-14 16:48:03 --> Config Class Initialized
INFO - 2023-12-14 16:48:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:03 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:03 --> URI Class Initialized
INFO - 2023-12-14 16:48:03 --> Router Class Initialized
INFO - 2023-12-14 16:48:03 --> Output Class Initialized
INFO - 2023-12-14 16:48:03 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:03 --> Input Class Initialized
INFO - 2023-12-14 16:48:03 --> Language Class Initialized
INFO - 2023-12-14 16:48:03 --> Language Class Initialized
INFO - 2023-12-14 16:48:03 --> Config Class Initialized
INFO - 2023-12-14 16:48:03 --> Loader Class Initialized
INFO - 2023-12-14 16:48:03 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:03 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:03 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:03 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:03 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:03 --> Controller Class Initialized
INFO - 2023-12-14 16:48:08 --> Config Class Initialized
INFO - 2023-12-14 16:48:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:08 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:08 --> URI Class Initialized
INFO - 2023-12-14 16:48:08 --> Router Class Initialized
INFO - 2023-12-14 16:48:08 --> Output Class Initialized
INFO - 2023-12-14 16:48:08 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:08 --> Input Class Initialized
INFO - 2023-12-14 16:48:08 --> Language Class Initialized
INFO - 2023-12-14 16:48:08 --> Language Class Initialized
INFO - 2023-12-14 16:48:08 --> Config Class Initialized
INFO - 2023-12-14 16:48:08 --> Loader Class Initialized
INFO - 2023-12-14 16:48:08 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:08 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:08 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:08 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:08 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:08 --> Controller Class Initialized
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:56 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:56 --> URI Class Initialized
INFO - 2023-12-14 16:48:56 --> Router Class Initialized
INFO - 2023-12-14 16:48:56 --> Output Class Initialized
INFO - 2023-12-14 16:48:56 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:56 --> Input Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Loader Class Initialized
INFO - 2023-12-14 16:48:56 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:56 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:56 --> Controller Class Initialized
INFO - 2023-12-14 16:48:56 --> Helper loaded: cookie_helper
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:56 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:56 --> URI Class Initialized
INFO - 2023-12-14 16:48:56 --> Router Class Initialized
INFO - 2023-12-14 16:48:56 --> Output Class Initialized
INFO - 2023-12-14 16:48:56 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:56 --> Input Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Loader Class Initialized
INFO - 2023-12-14 16:48:56 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:56 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:56 --> Controller Class Initialized
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:56 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:56 --> URI Class Initialized
INFO - 2023-12-14 16:48:56 --> Router Class Initialized
INFO - 2023-12-14 16:48:56 --> Output Class Initialized
INFO - 2023-12-14 16:48:56 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:56 --> Input Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Language Class Initialized
INFO - 2023-12-14 16:48:56 --> Config Class Initialized
INFO - 2023-12-14 16:48:56 --> Loader Class Initialized
INFO - 2023-12-14 16:48:56 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:56 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:56 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:56 --> Controller Class Initialized
DEBUG - 2023-12-14 16:48:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 16:48:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:48:56 --> Final output sent to browser
DEBUG - 2023-12-14 16:48:56 --> Total execution time: 0.1036
INFO - 2023-12-14 16:48:58 --> Config Class Initialized
INFO - 2023-12-14 16:48:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:58 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:58 --> URI Class Initialized
INFO - 2023-12-14 16:48:58 --> Router Class Initialized
INFO - 2023-12-14 16:48:58 --> Output Class Initialized
INFO - 2023-12-14 16:48:58 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:58 --> Input Class Initialized
INFO - 2023-12-14 16:48:58 --> Language Class Initialized
INFO - 2023-12-14 16:48:58 --> Language Class Initialized
INFO - 2023-12-14 16:48:58 --> Config Class Initialized
INFO - 2023-12-14 16:48:58 --> Loader Class Initialized
INFO - 2023-12-14 16:48:58 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:58 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:58 --> Controller Class Initialized
INFO - 2023-12-14 16:48:58 --> Helper loaded: cookie_helper
INFO - 2023-12-14 16:48:58 --> Final output sent to browser
DEBUG - 2023-12-14 16:48:58 --> Total execution time: 0.1329
INFO - 2023-12-14 16:48:58 --> Config Class Initialized
INFO - 2023-12-14 16:48:58 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:48:58 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:48:58 --> Utf8 Class Initialized
INFO - 2023-12-14 16:48:58 --> URI Class Initialized
INFO - 2023-12-14 16:48:58 --> Router Class Initialized
INFO - 2023-12-14 16:48:58 --> Output Class Initialized
INFO - 2023-12-14 16:48:58 --> Security Class Initialized
DEBUG - 2023-12-14 16:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:48:58 --> Input Class Initialized
INFO - 2023-12-14 16:48:58 --> Language Class Initialized
INFO - 2023-12-14 16:48:58 --> Language Class Initialized
INFO - 2023-12-14 16:48:58 --> Config Class Initialized
INFO - 2023-12-14 16:48:58 --> Loader Class Initialized
INFO - 2023-12-14 16:48:58 --> Helper loaded: url_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: file_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: form_helper
INFO - 2023-12-14 16:48:58 --> Helper loaded: my_helper
INFO - 2023-12-14 16:48:58 --> Database Driver Class Initialized
INFO - 2023-12-14 16:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:48:58 --> Controller Class Initialized
DEBUG - 2023-12-14 16:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2023-12-14 16:48:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:48:58 --> Final output sent to browser
DEBUG - 2023-12-14 16:48:58 --> Total execution time: 0.1103
INFO - 2023-12-14 16:49:00 --> Config Class Initialized
INFO - 2023-12-14 16:49:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:49:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:49:00 --> Utf8 Class Initialized
INFO - 2023-12-14 16:49:00 --> URI Class Initialized
INFO - 2023-12-14 16:49:00 --> Router Class Initialized
INFO - 2023-12-14 16:49:00 --> Output Class Initialized
INFO - 2023-12-14 16:49:00 --> Security Class Initialized
DEBUG - 2023-12-14 16:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:49:00 --> Input Class Initialized
INFO - 2023-12-14 16:49:00 --> Language Class Initialized
INFO - 2023-12-14 16:49:00 --> Language Class Initialized
INFO - 2023-12-14 16:49:00 --> Config Class Initialized
INFO - 2023-12-14 16:49:00 --> Loader Class Initialized
INFO - 2023-12-14 16:49:00 --> Helper loaded: url_helper
INFO - 2023-12-14 16:49:00 --> Helper loaded: file_helper
INFO - 2023-12-14 16:49:00 --> Helper loaded: form_helper
INFO - 2023-12-14 16:49:00 --> Helper loaded: my_helper
INFO - 2023-12-14 16:49:01 --> Database Driver Class Initialized
INFO - 2023-12-14 16:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:49:01 --> Controller Class Initialized
DEBUG - 2023-12-14 16:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-14 16:49:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:49:01 --> Final output sent to browser
DEBUG - 2023-12-14 16:49:01 --> Total execution time: 0.3003
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:52:21 --> Utf8 Class Initialized
INFO - 2023-12-14 16:52:21 --> URI Class Initialized
INFO - 2023-12-14 16:52:21 --> Router Class Initialized
INFO - 2023-12-14 16:52:21 --> Output Class Initialized
INFO - 2023-12-14 16:52:21 --> Security Class Initialized
DEBUG - 2023-12-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:52:21 --> Input Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Loader Class Initialized
INFO - 2023-12-14 16:52:21 --> Helper loaded: url_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: file_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: form_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: my_helper
INFO - 2023-12-14 16:52:21 --> Database Driver Class Initialized
INFO - 2023-12-14 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:52:21 --> Controller Class Initialized
INFO - 2023-12-14 16:52:21 --> Helper loaded: cookie_helper
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:52:21 --> Utf8 Class Initialized
INFO - 2023-12-14 16:52:21 --> URI Class Initialized
INFO - 2023-12-14 16:52:21 --> Router Class Initialized
INFO - 2023-12-14 16:52:21 --> Output Class Initialized
INFO - 2023-12-14 16:52:21 --> Security Class Initialized
DEBUG - 2023-12-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:52:21 --> Input Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Loader Class Initialized
INFO - 2023-12-14 16:52:21 --> Helper loaded: url_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: file_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: form_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: my_helper
INFO - 2023-12-14 16:52:21 --> Database Driver Class Initialized
INFO - 2023-12-14 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:52:21 --> Controller Class Initialized
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 16:52:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 16:52:21 --> Utf8 Class Initialized
INFO - 2023-12-14 16:52:21 --> URI Class Initialized
INFO - 2023-12-14 16:52:21 --> Router Class Initialized
INFO - 2023-12-14 16:52:21 --> Output Class Initialized
INFO - 2023-12-14 16:52:21 --> Security Class Initialized
DEBUG - 2023-12-14 16:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 16:52:21 --> Input Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Language Class Initialized
INFO - 2023-12-14 16:52:21 --> Config Class Initialized
INFO - 2023-12-14 16:52:21 --> Loader Class Initialized
INFO - 2023-12-14 16:52:21 --> Helper loaded: url_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: file_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: form_helper
INFO - 2023-12-14 16:52:21 --> Helper loaded: my_helper
INFO - 2023-12-14 16:52:21 --> Database Driver Class Initialized
INFO - 2023-12-14 16:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 16:52:21 --> Controller Class Initialized
DEBUG - 2023-12-14 16:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 16:52:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 16:52:21 --> Final output sent to browser
DEBUG - 2023-12-14 16:52:21 --> Total execution time: 0.0381
INFO - 2023-12-14 17:20:03 --> Config Class Initialized
INFO - 2023-12-14 17:20:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:03 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:03 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:03 --> URI Class Initialized
DEBUG - 2023-12-14 17:20:03 --> No URI present. Default controller set.
INFO - 2023-12-14 17:20:03 --> Router Class Initialized
INFO - 2023-12-14 17:20:03 --> Output Class Initialized
INFO - 2023-12-14 17:20:03 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:03 --> Input Class Initialized
INFO - 2023-12-14 17:20:03 --> Language Class Initialized
INFO - 2023-12-14 17:20:03 --> Language Class Initialized
INFO - 2023-12-14 17:20:03 --> Config Class Initialized
INFO - 2023-12-14 17:20:03 --> Loader Class Initialized
INFO - 2023-12-14 17:20:03 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:03 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:03 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:03 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:03 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:03 --> Controller Class Initialized
INFO - 2023-12-14 17:20:03 --> Config Class Initialized
INFO - 2023-12-14 17:20:03 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:04 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:04 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:04 --> URI Class Initialized
INFO - 2023-12-14 17:20:04 --> Router Class Initialized
INFO - 2023-12-14 17:20:04 --> Output Class Initialized
INFO - 2023-12-14 17:20:04 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:04 --> Input Class Initialized
INFO - 2023-12-14 17:20:04 --> Language Class Initialized
INFO - 2023-12-14 17:20:04 --> Language Class Initialized
INFO - 2023-12-14 17:20:04 --> Config Class Initialized
INFO - 2023-12-14 17:20:04 --> Loader Class Initialized
INFO - 2023-12-14 17:20:04 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:04 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:04 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:04 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:04 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:04 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 17:20:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:20:04 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:04 --> Total execution time: 0.0706
INFO - 2023-12-14 17:20:07 --> Config Class Initialized
INFO - 2023-12-14 17:20:07 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:07 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:07 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:07 --> URI Class Initialized
INFO - 2023-12-14 17:20:07 --> Router Class Initialized
INFO - 2023-12-14 17:20:07 --> Output Class Initialized
INFO - 2023-12-14 17:20:07 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:07 --> Input Class Initialized
INFO - 2023-12-14 17:20:07 --> Language Class Initialized
INFO - 2023-12-14 17:20:07 --> Language Class Initialized
INFO - 2023-12-14 17:20:07 --> Config Class Initialized
INFO - 2023-12-14 17:20:07 --> Loader Class Initialized
INFO - 2023-12-14 17:20:07 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:07 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:07 --> Controller Class Initialized
INFO - 2023-12-14 17:20:07 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:20:07 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:07 --> Total execution time: 0.0411
INFO - 2023-12-14 17:20:07 --> Config Class Initialized
INFO - 2023-12-14 17:20:07 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:07 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:07 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:07 --> URI Class Initialized
INFO - 2023-12-14 17:20:07 --> Router Class Initialized
INFO - 2023-12-14 17:20:07 --> Output Class Initialized
INFO - 2023-12-14 17:20:07 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:07 --> Input Class Initialized
INFO - 2023-12-14 17:20:07 --> Language Class Initialized
INFO - 2023-12-14 17:20:07 --> Language Class Initialized
INFO - 2023-12-14 17:20:07 --> Config Class Initialized
INFO - 2023-12-14 17:20:07 --> Loader Class Initialized
INFO - 2023-12-14 17:20:07 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:07 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:07 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:07 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-14 17:20:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:20:07 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:07 --> Total execution time: 0.0848
INFO - 2023-12-14 17:20:11 --> Config Class Initialized
INFO - 2023-12-14 17:20:11 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:11 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:11 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:11 --> URI Class Initialized
INFO - 2023-12-14 17:20:11 --> Router Class Initialized
INFO - 2023-12-14 17:20:11 --> Output Class Initialized
INFO - 2023-12-14 17:20:11 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:11 --> Input Class Initialized
INFO - 2023-12-14 17:20:11 --> Language Class Initialized
INFO - 2023-12-14 17:20:11 --> Language Class Initialized
INFO - 2023-12-14 17:20:11 --> Config Class Initialized
INFO - 2023-12-14 17:20:11 --> Loader Class Initialized
INFO - 2023-12-14 17:20:11 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:11 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:11 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:11 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:11 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:11 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-14 17:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:20:11 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:11 --> Total execution time: 0.0542
INFO - 2023-12-14 17:20:15 --> Config Class Initialized
INFO - 2023-12-14 17:20:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:15 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:15 --> URI Class Initialized
INFO - 2023-12-14 17:20:15 --> Router Class Initialized
INFO - 2023-12-14 17:20:15 --> Output Class Initialized
INFO - 2023-12-14 17:20:15 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:15 --> Input Class Initialized
INFO - 2023-12-14 17:20:15 --> Language Class Initialized
INFO - 2023-12-14 17:20:15 --> Language Class Initialized
INFO - 2023-12-14 17:20:15 --> Config Class Initialized
INFO - 2023-12-14 17:20:15 --> Loader Class Initialized
INFO - 2023-12-14 17:20:15 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:15 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:15 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:15 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:15 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:15 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 17:20:18 --> Config Class Initialized
INFO - 2023-12-14 17:20:18 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:18 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:18 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:18 --> URI Class Initialized
INFO - 2023-12-14 17:20:18 --> Router Class Initialized
INFO - 2023-12-14 17:20:18 --> Output Class Initialized
INFO - 2023-12-14 17:20:18 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:18 --> Input Class Initialized
INFO - 2023-12-14 17:20:18 --> Language Class Initialized
INFO - 2023-12-14 17:20:18 --> Language Class Initialized
INFO - 2023-12-14 17:20:18 --> Config Class Initialized
INFO - 2023-12-14 17:20:18 --> Loader Class Initialized
INFO - 2023-12-14 17:20:18 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:18 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:18 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:18 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:18 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:20 --> Config Class Initialized
INFO - 2023-12-14 17:20:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:20 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:20 --> URI Class Initialized
INFO - 2023-12-14 17:20:20 --> Router Class Initialized
INFO - 2023-12-14 17:20:20 --> Output Class Initialized
INFO - 2023-12-14 17:20:20 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:20 --> Input Class Initialized
INFO - 2023-12-14 17:20:20 --> Language Class Initialized
INFO - 2023-12-14 17:20:20 --> Language Class Initialized
INFO - 2023-12-14 17:20:20 --> Config Class Initialized
INFO - 2023-12-14 17:20:20 --> Loader Class Initialized
INFO - 2023-12-14 17:20:20 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:20 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:20 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:20 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:20 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:22 --> Config Class Initialized
INFO - 2023-12-14 17:20:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:20:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:20:22 --> Utf8 Class Initialized
INFO - 2023-12-14 17:20:22 --> URI Class Initialized
INFO - 2023-12-14 17:20:22 --> Router Class Initialized
INFO - 2023-12-14 17:20:22 --> Output Class Initialized
INFO - 2023-12-14 17:20:22 --> Security Class Initialized
DEBUG - 2023-12-14 17:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:20:22 --> Input Class Initialized
INFO - 2023-12-14 17:20:22 --> Language Class Initialized
INFO - 2023-12-14 17:20:22 --> Language Class Initialized
INFO - 2023-12-14 17:20:22 --> Config Class Initialized
INFO - 2023-12-14 17:20:22 --> Loader Class Initialized
INFO - 2023-12-14 17:20:22 --> Helper loaded: url_helper
INFO - 2023-12-14 17:20:22 --> Helper loaded: file_helper
INFO - 2023-12-14 17:20:22 --> Helper loaded: form_helper
INFO - 2023-12-14 17:20:22 --> Helper loaded: my_helper
INFO - 2023-12-14 17:20:22 --> Database Driver Class Initialized
INFO - 2023-12-14 17:20:26 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:26 --> Total execution time: 10.5974
INFO - 2023-12-14 17:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:26 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 17:20:35 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:35 --> Total execution time: 17.9305
INFO - 2023-12-14 17:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:36 --> Controller Class Initialized
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:20:36 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 17:20:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 17:20:42 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:42 --> Total execution time: 21.7391
INFO - 2023-12-14 17:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:20:42 --> Controller Class Initialized
DEBUG - 2023-12-14 17:20:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 17:20:44 --> Final output sent to browser
DEBUG - 2023-12-14 17:20:44 --> Total execution time: 22.2476
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:01 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:01 --> URI Class Initialized
INFO - 2023-12-14 17:22:01 --> Router Class Initialized
INFO - 2023-12-14 17:22:01 --> Output Class Initialized
INFO - 2023-12-14 17:22:01 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:01 --> Input Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Loader Class Initialized
INFO - 2023-12-14 17:22:01 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:01 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:01 --> Controller Class Initialized
INFO - 2023-12-14 17:22:01 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:01 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:01 --> URI Class Initialized
INFO - 2023-12-14 17:22:01 --> Router Class Initialized
INFO - 2023-12-14 17:22:01 --> Output Class Initialized
INFO - 2023-12-14 17:22:01 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:01 --> Input Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Loader Class Initialized
INFO - 2023-12-14 17:22:01 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:01 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:01 --> Controller Class Initialized
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:01 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:01 --> URI Class Initialized
INFO - 2023-12-14 17:22:01 --> Router Class Initialized
INFO - 2023-12-14 17:22:01 --> Output Class Initialized
INFO - 2023-12-14 17:22:01 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:01 --> Input Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Language Class Initialized
INFO - 2023-12-14 17:22:01 --> Config Class Initialized
INFO - 2023-12-14 17:22:01 --> Loader Class Initialized
INFO - 2023-12-14 17:22:01 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:01 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:01 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:01 --> Controller Class Initialized
DEBUG - 2023-12-14 17:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-14 17:22:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:22:01 --> Final output sent to browser
DEBUG - 2023-12-14 17:22:01 --> Total execution time: 0.0411
INFO - 2023-12-14 17:22:05 --> Config Class Initialized
INFO - 2023-12-14 17:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:05 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:05 --> URI Class Initialized
INFO - 2023-12-14 17:22:05 --> Router Class Initialized
INFO - 2023-12-14 17:22:05 --> Output Class Initialized
INFO - 2023-12-14 17:22:05 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:05 --> Input Class Initialized
INFO - 2023-12-14 17:22:05 --> Language Class Initialized
INFO - 2023-12-14 17:22:05 --> Language Class Initialized
INFO - 2023-12-14 17:22:05 --> Config Class Initialized
INFO - 2023-12-14 17:22:05 --> Loader Class Initialized
INFO - 2023-12-14 17:22:05 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:05 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:05 --> Controller Class Initialized
INFO - 2023-12-14 17:22:05 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:22:05 --> Final output sent to browser
DEBUG - 2023-12-14 17:22:05 --> Total execution time: 0.0538
INFO - 2023-12-14 17:22:05 --> Config Class Initialized
INFO - 2023-12-14 17:22:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:05 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:05 --> URI Class Initialized
INFO - 2023-12-14 17:22:05 --> Router Class Initialized
INFO - 2023-12-14 17:22:05 --> Output Class Initialized
INFO - 2023-12-14 17:22:05 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:05 --> Input Class Initialized
INFO - 2023-12-14 17:22:05 --> Language Class Initialized
INFO - 2023-12-14 17:22:05 --> Language Class Initialized
INFO - 2023-12-14 17:22:05 --> Config Class Initialized
INFO - 2023-12-14 17:22:05 --> Loader Class Initialized
INFO - 2023-12-14 17:22:05 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:05 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:05 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:05 --> Controller Class Initialized
DEBUG - 2023-12-14 17:22:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 17:22:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:22:05 --> Final output sent to browser
DEBUG - 2023-12-14 17:22:05 --> Total execution time: 0.0429
INFO - 2023-12-14 17:22:08 --> Config Class Initialized
INFO - 2023-12-14 17:22:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:08 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:08 --> URI Class Initialized
INFO - 2023-12-14 17:22:08 --> Router Class Initialized
INFO - 2023-12-14 17:22:08 --> Output Class Initialized
INFO - 2023-12-14 17:22:08 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:08 --> Input Class Initialized
INFO - 2023-12-14 17:22:08 --> Language Class Initialized
INFO - 2023-12-14 17:22:08 --> Language Class Initialized
INFO - 2023-12-14 17:22:08 --> Config Class Initialized
INFO - 2023-12-14 17:22:08 --> Loader Class Initialized
INFO - 2023-12-14 17:22:08 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:08 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:08 --> Controller Class Initialized
DEBUG - 2023-12-14 17:22:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-12-14 17:22:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:22:08 --> Final output sent to browser
DEBUG - 2023-12-14 17:22:08 --> Total execution time: 0.0366
INFO - 2023-12-14 17:22:08 --> Config Class Initialized
INFO - 2023-12-14 17:22:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:08 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:08 --> URI Class Initialized
INFO - 2023-12-14 17:22:08 --> Router Class Initialized
INFO - 2023-12-14 17:22:08 --> Output Class Initialized
INFO - 2023-12-14 17:22:08 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:08 --> Input Class Initialized
INFO - 2023-12-14 17:22:08 --> Language Class Initialized
ERROR - 2023-12-14 17:22:08 --> 404 Page Not Found: /index
INFO - 2023-12-14 17:22:08 --> Config Class Initialized
INFO - 2023-12-14 17:22:08 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:08 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:08 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:08 --> URI Class Initialized
INFO - 2023-12-14 17:22:08 --> Router Class Initialized
INFO - 2023-12-14 17:22:08 --> Output Class Initialized
INFO - 2023-12-14 17:22:08 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:08 --> Input Class Initialized
INFO - 2023-12-14 17:22:08 --> Language Class Initialized
INFO - 2023-12-14 17:22:08 --> Language Class Initialized
INFO - 2023-12-14 17:22:08 --> Config Class Initialized
INFO - 2023-12-14 17:22:08 --> Loader Class Initialized
INFO - 2023-12-14 17:22:08 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:08 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:08 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:08 --> Controller Class Initialized
INFO - 2023-12-14 17:22:13 --> Config Class Initialized
INFO - 2023-12-14 17:22:13 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:22:13 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:22:13 --> Utf8 Class Initialized
INFO - 2023-12-14 17:22:13 --> URI Class Initialized
INFO - 2023-12-14 17:22:13 --> Router Class Initialized
INFO - 2023-12-14 17:22:13 --> Output Class Initialized
INFO - 2023-12-14 17:22:13 --> Security Class Initialized
DEBUG - 2023-12-14 17:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:22:13 --> Input Class Initialized
INFO - 2023-12-14 17:22:13 --> Language Class Initialized
INFO - 2023-12-14 17:22:13 --> Language Class Initialized
INFO - 2023-12-14 17:22:13 --> Config Class Initialized
INFO - 2023-12-14 17:22:13 --> Loader Class Initialized
INFO - 2023-12-14 17:22:13 --> Helper loaded: url_helper
INFO - 2023-12-14 17:22:13 --> Helper loaded: file_helper
INFO - 2023-12-14 17:22:13 --> Helper loaded: form_helper
INFO - 2023-12-14 17:22:13 --> Helper loaded: my_helper
INFO - 2023-12-14 17:22:13 --> Database Driver Class Initialized
INFO - 2023-12-14 17:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:22:13 --> Controller Class Initialized
INFO - 2023-12-14 17:24:30 --> Config Class Initialized
INFO - 2023-12-14 17:24:30 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:24:30 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:24:30 --> Utf8 Class Initialized
INFO - 2023-12-14 17:24:30 --> URI Class Initialized
INFO - 2023-12-14 17:24:30 --> Router Class Initialized
INFO - 2023-12-14 17:24:30 --> Output Class Initialized
INFO - 2023-12-14 17:24:30 --> Security Class Initialized
DEBUG - 2023-12-14 17:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:24:30 --> Input Class Initialized
INFO - 2023-12-14 17:24:30 --> Language Class Initialized
ERROR - 2023-12-14 17:24:30 --> 404 Page Not Found: ../modules/login/controllers/Login/do_loginapii
INFO - 2023-12-14 17:26:20 --> Config Class Initialized
INFO - 2023-12-14 17:26:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:20 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:20 --> URI Class Initialized
INFO - 2023-12-14 17:26:20 --> Router Class Initialized
INFO - 2023-12-14 17:26:20 --> Output Class Initialized
INFO - 2023-12-14 17:26:20 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:20 --> Input Class Initialized
INFO - 2023-12-14 17:26:20 --> Language Class Initialized
INFO - 2023-12-14 17:26:20 --> Language Class Initialized
INFO - 2023-12-14 17:26:20 --> Config Class Initialized
INFO - 2023-12-14 17:26:20 --> Loader Class Initialized
INFO - 2023-12-14 17:26:20 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:20 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:20 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:20 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:20 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:20 --> Controller Class Initialized
INFO - 2023-12-14 17:26:20 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:26:20 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:20 --> Total execution time: 0.0436
INFO - 2023-12-14 17:26:21 --> Config Class Initialized
INFO - 2023-12-14 17:26:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:21 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:21 --> URI Class Initialized
INFO - 2023-12-14 17:26:21 --> Router Class Initialized
INFO - 2023-12-14 17:26:21 --> Output Class Initialized
INFO - 2023-12-14 17:26:21 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:21 --> Input Class Initialized
INFO - 2023-12-14 17:26:21 --> Language Class Initialized
INFO - 2023-12-14 17:26:21 --> Language Class Initialized
INFO - 2023-12-14 17:26:21 --> Config Class Initialized
INFO - 2023-12-14 17:26:21 --> Loader Class Initialized
INFO - 2023-12-14 17:26:21 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:21 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:21 --> Controller Class Initialized
INFO - 2023-12-14 17:26:21 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:26:21 --> Config Class Initialized
INFO - 2023-12-14 17:26:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:21 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:21 --> URI Class Initialized
INFO - 2023-12-14 17:26:21 --> Router Class Initialized
INFO - 2023-12-14 17:26:21 --> Output Class Initialized
INFO - 2023-12-14 17:26:21 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:21 --> Input Class Initialized
INFO - 2023-12-14 17:26:21 --> Language Class Initialized
INFO - 2023-12-14 17:26:21 --> Language Class Initialized
INFO - 2023-12-14 17:26:21 --> Config Class Initialized
INFO - 2023-12-14 17:26:21 --> Loader Class Initialized
INFO - 2023-12-14 17:26:21 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:21 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:21 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:21 --> Controller Class Initialized
DEBUG - 2023-12-14 17:26:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-14 17:26:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:26:21 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:21 --> Total execution time: 0.0413
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:43 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:43 --> URI Class Initialized
INFO - 2023-12-14 17:26:43 --> Router Class Initialized
INFO - 2023-12-14 17:26:43 --> Output Class Initialized
INFO - 2023-12-14 17:26:43 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:43 --> Input Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Loader Class Initialized
INFO - 2023-12-14 17:26:43 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:43 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:43 --> Controller Class Initialized
INFO - 2023-12-14 17:26:43 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:26:43 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:43 --> Total execution time: 0.0345
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:43 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:43 --> URI Class Initialized
INFO - 2023-12-14 17:26:43 --> Router Class Initialized
INFO - 2023-12-14 17:26:43 --> Output Class Initialized
INFO - 2023-12-14 17:26:43 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:43 --> Input Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Loader Class Initialized
INFO - 2023-12-14 17:26:43 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:43 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:43 --> Controller Class Initialized
INFO - 2023-12-14 17:26:43 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:43 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:43 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:43 --> URI Class Initialized
INFO - 2023-12-14 17:26:43 --> Router Class Initialized
INFO - 2023-12-14 17:26:43 --> Output Class Initialized
INFO - 2023-12-14 17:26:43 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:43 --> Input Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Language Class Initialized
INFO - 2023-12-14 17:26:43 --> Config Class Initialized
INFO - 2023-12-14 17:26:43 --> Loader Class Initialized
INFO - 2023-12-14 17:26:43 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:43 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:43 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:43 --> Controller Class Initialized
DEBUG - 2023-12-14 17:26:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-14 17:26:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:26:43 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:43 --> Total execution time: 0.0431
INFO - 2023-12-14 17:26:46 --> Config Class Initialized
INFO - 2023-12-14 17:26:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:46 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:46 --> URI Class Initialized
INFO - 2023-12-14 17:26:46 --> Router Class Initialized
INFO - 2023-12-14 17:26:46 --> Output Class Initialized
INFO - 2023-12-14 17:26:46 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:46 --> Input Class Initialized
INFO - 2023-12-14 17:26:46 --> Language Class Initialized
INFO - 2023-12-14 17:26:46 --> Language Class Initialized
INFO - 2023-12-14 17:26:46 --> Config Class Initialized
INFO - 2023-12-14 17:26:46 --> Loader Class Initialized
INFO - 2023-12-14 17:26:46 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:46 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:46 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:46 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:46 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:46 --> Controller Class Initialized
DEBUG - 2023-12-14 17:26:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-14 17:26:50 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:50 --> Total execution time: 3.9554
INFO - 2023-12-14 17:26:52 --> Config Class Initialized
INFO - 2023-12-14 17:26:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:26:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:26:52 --> Utf8 Class Initialized
INFO - 2023-12-14 17:26:52 --> URI Class Initialized
INFO - 2023-12-14 17:26:52 --> Router Class Initialized
INFO - 2023-12-14 17:26:52 --> Output Class Initialized
INFO - 2023-12-14 17:26:52 --> Security Class Initialized
DEBUG - 2023-12-14 17:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:26:52 --> Input Class Initialized
INFO - 2023-12-14 17:26:52 --> Language Class Initialized
INFO - 2023-12-14 17:26:52 --> Language Class Initialized
INFO - 2023-12-14 17:26:52 --> Config Class Initialized
INFO - 2023-12-14 17:26:52 --> Loader Class Initialized
INFO - 2023-12-14 17:26:52 --> Helper loaded: url_helper
INFO - 2023-12-14 17:26:52 --> Helper loaded: file_helper
INFO - 2023-12-14 17:26:52 --> Helper loaded: form_helper
INFO - 2023-12-14 17:26:52 --> Helper loaded: my_helper
INFO - 2023-12-14 17:26:52 --> Database Driver Class Initialized
INFO - 2023-12-14 17:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:26:52 --> Controller Class Initialized
DEBUG - 2023-12-14 17:26:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-12-14 17:26:56 --> Final output sent to browser
DEBUG - 2023-12-14 17:26:56 --> Total execution time: 3.8606
INFO - 2023-12-14 17:31:14 --> Config Class Initialized
INFO - 2023-12-14 17:31:14 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:14 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:14 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:14 --> URI Class Initialized
INFO - 2023-12-14 17:31:14 --> Router Class Initialized
INFO - 2023-12-14 17:31:14 --> Output Class Initialized
INFO - 2023-12-14 17:31:14 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:14 --> Input Class Initialized
INFO - 2023-12-14 17:31:14 --> Language Class Initialized
INFO - 2023-12-14 17:31:14 --> Language Class Initialized
INFO - 2023-12-14 17:31:14 --> Config Class Initialized
INFO - 2023-12-14 17:31:14 --> Loader Class Initialized
INFO - 2023-12-14 17:31:14 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:14 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:14 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:14 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:14 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:14 --> Controller Class Initialized
DEBUG - 2023-12-14 17:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-12-14 17:31:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:31:14 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:14 --> Total execution time: 0.0734
INFO - 2023-12-14 17:31:15 --> Config Class Initialized
INFO - 2023-12-14 17:31:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:15 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:15 --> URI Class Initialized
INFO - 2023-12-14 17:31:15 --> Router Class Initialized
INFO - 2023-12-14 17:31:15 --> Output Class Initialized
INFO - 2023-12-14 17:31:15 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:15 --> Input Class Initialized
INFO - 2023-12-14 17:31:15 --> Language Class Initialized
ERROR - 2023-12-14 17:31:15 --> 404 Page Not Found: /index
INFO - 2023-12-14 17:31:15 --> Config Class Initialized
INFO - 2023-12-14 17:31:15 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:15 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:15 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:15 --> URI Class Initialized
INFO - 2023-12-14 17:31:15 --> Router Class Initialized
INFO - 2023-12-14 17:31:15 --> Output Class Initialized
INFO - 2023-12-14 17:31:15 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:15 --> Input Class Initialized
INFO - 2023-12-14 17:31:15 --> Language Class Initialized
INFO - 2023-12-14 17:31:15 --> Language Class Initialized
INFO - 2023-12-14 17:31:15 --> Config Class Initialized
INFO - 2023-12-14 17:31:15 --> Loader Class Initialized
INFO - 2023-12-14 17:31:15 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:15 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:15 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:15 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:15 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:15 --> Controller Class Initialized
INFO - 2023-12-14 17:31:16 --> Config Class Initialized
INFO - 2023-12-14 17:31:16 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:16 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:16 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:16 --> URI Class Initialized
INFO - 2023-12-14 17:31:16 --> Router Class Initialized
INFO - 2023-12-14 17:31:16 --> Output Class Initialized
INFO - 2023-12-14 17:31:16 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:16 --> Input Class Initialized
INFO - 2023-12-14 17:31:16 --> Language Class Initialized
INFO - 2023-12-14 17:31:16 --> Language Class Initialized
INFO - 2023-12-14 17:31:16 --> Config Class Initialized
INFO - 2023-12-14 17:31:16 --> Loader Class Initialized
INFO - 2023-12-14 17:31:16 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:16 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:16 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:16 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:16 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:16 --> Controller Class Initialized
INFO - 2023-12-14 17:31:16 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:16 --> Total execution time: 0.0445
INFO - 2023-12-14 17:31:19 --> Config Class Initialized
INFO - 2023-12-14 17:31:19 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:19 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:19 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:19 --> URI Class Initialized
INFO - 2023-12-14 17:31:19 --> Router Class Initialized
INFO - 2023-12-14 17:31:19 --> Output Class Initialized
INFO - 2023-12-14 17:31:19 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:19 --> Input Class Initialized
INFO - 2023-12-14 17:31:19 --> Language Class Initialized
INFO - 2023-12-14 17:31:19 --> Language Class Initialized
INFO - 2023-12-14 17:31:19 --> Config Class Initialized
INFO - 2023-12-14 17:31:19 --> Loader Class Initialized
INFO - 2023-12-14 17:31:19 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:19 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:19 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:19 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:19 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:20 --> Controller Class Initialized
INFO - 2023-12-14 17:31:20 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:20 --> Total execution time: 0.0790
INFO - 2023-12-14 17:31:20 --> Config Class Initialized
INFO - 2023-12-14 17:31:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:20 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:20 --> URI Class Initialized
INFO - 2023-12-14 17:31:20 --> Router Class Initialized
INFO - 2023-12-14 17:31:20 --> Output Class Initialized
INFO - 2023-12-14 17:31:20 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:20 --> Input Class Initialized
INFO - 2023-12-14 17:31:20 --> Language Class Initialized
ERROR - 2023-12-14 17:31:20 --> 404 Page Not Found: /index
INFO - 2023-12-14 17:31:20 --> Config Class Initialized
INFO - 2023-12-14 17:31:20 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:20 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:20 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:20 --> URI Class Initialized
INFO - 2023-12-14 17:31:20 --> Router Class Initialized
INFO - 2023-12-14 17:31:20 --> Output Class Initialized
INFO - 2023-12-14 17:31:20 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:20 --> Input Class Initialized
INFO - 2023-12-14 17:31:20 --> Language Class Initialized
INFO - 2023-12-14 17:31:20 --> Language Class Initialized
INFO - 2023-12-14 17:31:20 --> Config Class Initialized
INFO - 2023-12-14 17:31:20 --> Loader Class Initialized
INFO - 2023-12-14 17:31:20 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:20 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:20 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:20 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:20 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:20 --> Controller Class Initialized
INFO - 2023-12-14 17:31:39 --> Config Class Initialized
INFO - 2023-12-14 17:31:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:39 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:39 --> URI Class Initialized
INFO - 2023-12-14 17:31:39 --> Router Class Initialized
INFO - 2023-12-14 17:31:39 --> Output Class Initialized
INFO - 2023-12-14 17:31:39 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:39 --> Input Class Initialized
INFO - 2023-12-14 17:31:39 --> Language Class Initialized
INFO - 2023-12-14 17:31:39 --> Language Class Initialized
INFO - 2023-12-14 17:31:39 --> Config Class Initialized
INFO - 2023-12-14 17:31:39 --> Loader Class Initialized
INFO - 2023-12-14 17:31:39 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:39 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:39 --> Controller Class Initialized
INFO - 2023-12-14 17:31:39 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:31:39 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:39 --> Total execution time: 0.0395
INFO - 2023-12-14 17:31:39 --> Config Class Initialized
INFO - 2023-12-14 17:31:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:39 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:39 --> URI Class Initialized
INFO - 2023-12-14 17:31:39 --> Router Class Initialized
INFO - 2023-12-14 17:31:39 --> Output Class Initialized
INFO - 2023-12-14 17:31:39 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:39 --> Input Class Initialized
INFO - 2023-12-14 17:31:39 --> Language Class Initialized
INFO - 2023-12-14 17:31:39 --> Language Class Initialized
INFO - 2023-12-14 17:31:39 --> Config Class Initialized
INFO - 2023-12-14 17:31:39 --> Loader Class Initialized
INFO - 2023-12-14 17:31:39 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:39 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:39 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:39 --> Controller Class Initialized
INFO - 2023-12-14 17:31:39 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:31:40 --> Config Class Initialized
INFO - 2023-12-14 17:31:40 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:40 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:40 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:40 --> URI Class Initialized
INFO - 2023-12-14 17:31:40 --> Router Class Initialized
INFO - 2023-12-14 17:31:40 --> Output Class Initialized
INFO - 2023-12-14 17:31:40 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:40 --> Input Class Initialized
INFO - 2023-12-14 17:31:40 --> Language Class Initialized
INFO - 2023-12-14 17:31:40 --> Language Class Initialized
INFO - 2023-12-14 17:31:40 --> Config Class Initialized
INFO - 2023-12-14 17:31:40 --> Loader Class Initialized
INFO - 2023-12-14 17:31:40 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:40 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:40 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:40 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:40 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:40 --> Controller Class Initialized
DEBUG - 2023-12-14 17:31:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-14 17:31:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:31:40 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:40 --> Total execution time: 0.0571
INFO - 2023-12-14 17:31:45 --> Config Class Initialized
INFO - 2023-12-14 17:31:45 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:45 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:45 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:45 --> URI Class Initialized
INFO - 2023-12-14 17:31:45 --> Router Class Initialized
INFO - 2023-12-14 17:31:45 --> Output Class Initialized
INFO - 2023-12-14 17:31:45 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:45 --> Input Class Initialized
INFO - 2023-12-14 17:31:45 --> Language Class Initialized
INFO - 2023-12-14 17:31:45 --> Language Class Initialized
INFO - 2023-12-14 17:31:45 --> Config Class Initialized
INFO - 2023-12-14 17:31:45 --> Loader Class Initialized
INFO - 2023-12-14 17:31:45 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:45 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:45 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:45 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:45 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:45 --> Controller Class Initialized
DEBUG - 2023-12-14 17:31:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 17:31:48 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:48 --> Total execution time: 2.6186
INFO - 2023-12-14 17:31:50 --> Config Class Initialized
INFO - 2023-12-14 17:31:50 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:31:50 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:31:50 --> Utf8 Class Initialized
INFO - 2023-12-14 17:31:50 --> URI Class Initialized
INFO - 2023-12-14 17:31:50 --> Router Class Initialized
INFO - 2023-12-14 17:31:50 --> Output Class Initialized
INFO - 2023-12-14 17:31:50 --> Security Class Initialized
DEBUG - 2023-12-14 17:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:31:50 --> Input Class Initialized
INFO - 2023-12-14 17:31:50 --> Language Class Initialized
INFO - 2023-12-14 17:31:50 --> Language Class Initialized
INFO - 2023-12-14 17:31:50 --> Config Class Initialized
INFO - 2023-12-14 17:31:50 --> Loader Class Initialized
INFO - 2023-12-14 17:31:50 --> Helper loaded: url_helper
INFO - 2023-12-14 17:31:50 --> Helper loaded: file_helper
INFO - 2023-12-14 17:31:50 --> Helper loaded: form_helper
INFO - 2023-12-14 17:31:50 --> Helper loaded: my_helper
INFO - 2023-12-14 17:31:50 --> Database Driver Class Initialized
INFO - 2023-12-14 17:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:31:50 --> Controller Class Initialized
DEBUG - 2023-12-14 17:31:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-14 17:31:52 --> Final output sent to browser
DEBUG - 2023-12-14 17:31:52 --> Total execution time: 2.4614
INFO - 2023-12-14 17:32:05 --> Config Class Initialized
INFO - 2023-12-14 17:32:05 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:32:05 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:32:05 --> Utf8 Class Initialized
INFO - 2023-12-14 17:32:05 --> URI Class Initialized
INFO - 2023-12-14 17:32:05 --> Router Class Initialized
INFO - 2023-12-14 17:32:05 --> Output Class Initialized
INFO - 2023-12-14 17:32:05 --> Security Class Initialized
DEBUG - 2023-12-14 17:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:32:05 --> Input Class Initialized
INFO - 2023-12-14 17:32:05 --> Language Class Initialized
INFO - 2023-12-14 17:32:05 --> Language Class Initialized
INFO - 2023-12-14 17:32:05 --> Config Class Initialized
INFO - 2023-12-14 17:32:05 --> Loader Class Initialized
INFO - 2023-12-14 17:32:05 --> Helper loaded: url_helper
INFO - 2023-12-14 17:32:05 --> Helper loaded: file_helper
INFO - 2023-12-14 17:32:05 --> Helper loaded: form_helper
INFO - 2023-12-14 17:32:05 --> Helper loaded: my_helper
INFO - 2023-12-14 17:32:05 --> Database Driver Class Initialized
INFO - 2023-12-14 17:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:32:05 --> Controller Class Initialized
DEBUG - 2023-12-14 17:32:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 17:32:18 --> Final output sent to browser
DEBUG - 2023-12-14 17:32:18 --> Total execution time: 12.4962
INFO - 2023-12-14 17:32:22 --> Config Class Initialized
INFO - 2023-12-14 17:32:22 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:32:22 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:32:22 --> Utf8 Class Initialized
INFO - 2023-12-14 17:32:22 --> URI Class Initialized
INFO - 2023-12-14 17:32:22 --> Router Class Initialized
INFO - 2023-12-14 17:32:22 --> Output Class Initialized
INFO - 2023-12-14 17:32:22 --> Security Class Initialized
DEBUG - 2023-12-14 17:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:32:22 --> Input Class Initialized
INFO - 2023-12-14 17:32:22 --> Language Class Initialized
INFO - 2023-12-14 17:32:22 --> Language Class Initialized
INFO - 2023-12-14 17:32:22 --> Config Class Initialized
INFO - 2023-12-14 17:32:22 --> Loader Class Initialized
INFO - 2023-12-14 17:32:22 --> Helper loaded: url_helper
INFO - 2023-12-14 17:32:22 --> Helper loaded: file_helper
INFO - 2023-12-14 17:32:22 --> Helper loaded: form_helper
INFO - 2023-12-14 17:32:22 --> Helper loaded: my_helper
INFO - 2023-12-14 17:32:22 --> Database Driver Class Initialized
INFO - 2023-12-14 17:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:32:22 --> Controller Class Initialized
DEBUG - 2023-12-14 17:32:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2023-12-14 17:32:34 --> Final output sent to browser
DEBUG - 2023-12-14 17:32:34 --> Total execution time: 12.1882
INFO - 2023-12-14 17:32:52 --> Config Class Initialized
INFO - 2023-12-14 17:32:52 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:32:52 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:32:52 --> Utf8 Class Initialized
INFO - 2023-12-14 17:32:52 --> URI Class Initialized
INFO - 2023-12-14 17:32:52 --> Router Class Initialized
INFO - 2023-12-14 17:32:52 --> Output Class Initialized
INFO - 2023-12-14 17:32:52 --> Security Class Initialized
DEBUG - 2023-12-14 17:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:32:52 --> Input Class Initialized
INFO - 2023-12-14 17:32:52 --> Language Class Initialized
INFO - 2023-12-14 17:32:52 --> Language Class Initialized
INFO - 2023-12-14 17:32:52 --> Config Class Initialized
INFO - 2023-12-14 17:32:52 --> Loader Class Initialized
INFO - 2023-12-14 17:32:52 --> Helper loaded: url_helper
INFO - 2023-12-14 17:32:52 --> Helper loaded: file_helper
INFO - 2023-12-14 17:32:52 --> Helper loaded: form_helper
INFO - 2023-12-14 17:32:52 --> Helper loaded: my_helper
INFO - 2023-12-14 17:32:52 --> Database Driver Class Initialized
INFO - 2023-12-14 17:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:32:52 --> Controller Class Initialized
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:32:52 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 17:32:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 17:32:57 --> Final output sent to browser
DEBUG - 2023-12-14 17:32:57 --> Total execution time: 5.6923
INFO - 2023-12-14 17:33:00 --> Config Class Initialized
INFO - 2023-12-14 17:33:00 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:00 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:00 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:00 --> URI Class Initialized
INFO - 2023-12-14 17:33:00 --> Router Class Initialized
INFO - 2023-12-14 17:33:00 --> Output Class Initialized
INFO - 2023-12-14 17:33:00 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:00 --> Input Class Initialized
INFO - 2023-12-14 17:33:00 --> Language Class Initialized
INFO - 2023-12-14 17:33:00 --> Language Class Initialized
INFO - 2023-12-14 17:33:00 --> Config Class Initialized
INFO - 2023-12-14 17:33:00 --> Loader Class Initialized
INFO - 2023-12-14 17:33:00 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:00 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:00 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:00 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:00 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:00 --> Controller Class Initialized
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-14 17:33:00 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2023-12-14 17:33:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-14 17:33:07 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:07 --> Total execution time: 6.5971
INFO - 2023-12-14 17:33:14 --> Config Class Initialized
INFO - 2023-12-14 17:33:14 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:14 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:14 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:14 --> URI Class Initialized
INFO - 2023-12-14 17:33:14 --> Router Class Initialized
INFO - 2023-12-14 17:33:14 --> Output Class Initialized
INFO - 2023-12-14 17:33:14 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:14 --> Input Class Initialized
INFO - 2023-12-14 17:33:14 --> Language Class Initialized
INFO - 2023-12-14 17:33:14 --> Language Class Initialized
INFO - 2023-12-14 17:33:14 --> Config Class Initialized
INFO - 2023-12-14 17:33:14 --> Loader Class Initialized
INFO - 2023-12-14 17:33:14 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:14 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:14 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:14 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:14 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:14 --> Controller Class Initialized
DEBUG - 2023-12-14 17:33:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 17:33:19 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:19 --> Total execution time: 5.0697
INFO - 2023-12-14 17:33:21 --> Config Class Initialized
INFO - 2023-12-14 17:33:21 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:21 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:21 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:21 --> URI Class Initialized
INFO - 2023-12-14 17:33:21 --> Router Class Initialized
INFO - 2023-12-14 17:33:21 --> Output Class Initialized
INFO - 2023-12-14 17:33:21 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:21 --> Input Class Initialized
INFO - 2023-12-14 17:33:21 --> Language Class Initialized
INFO - 2023-12-14 17:33:21 --> Language Class Initialized
INFO - 2023-12-14 17:33:21 --> Config Class Initialized
INFO - 2023-12-14 17:33:21 --> Loader Class Initialized
INFO - 2023-12-14 17:33:21 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:21 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:21 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:21 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:21 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:21 --> Controller Class Initialized
DEBUG - 2023-12-14 17:33:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-14 17:33:26 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:26 --> Total execution time: 4.8406
INFO - 2023-12-14 17:33:39 --> Config Class Initialized
INFO - 2023-12-14 17:33:39 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:39 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:39 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:39 --> URI Class Initialized
INFO - 2023-12-14 17:33:39 --> Router Class Initialized
INFO - 2023-12-14 17:33:39 --> Output Class Initialized
INFO - 2023-12-14 17:33:39 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:39 --> Input Class Initialized
INFO - 2023-12-14 17:33:39 --> Language Class Initialized
INFO - 2023-12-14 17:33:39 --> Language Class Initialized
INFO - 2023-12-14 17:33:39 --> Config Class Initialized
INFO - 2023-12-14 17:33:39 --> Loader Class Initialized
INFO - 2023-12-14 17:33:39 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:39 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:39 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:39 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:39 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:39 --> Controller Class Initialized
INFO - 2023-12-14 17:33:39 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:39 --> Total execution time: 0.0378
INFO - 2023-12-14 17:33:46 --> Config Class Initialized
INFO - 2023-12-14 17:33:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:46 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:46 --> URI Class Initialized
INFO - 2023-12-14 17:33:46 --> Router Class Initialized
INFO - 2023-12-14 17:33:46 --> Output Class Initialized
INFO - 2023-12-14 17:33:46 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:46 --> Input Class Initialized
INFO - 2023-12-14 17:33:46 --> Language Class Initialized
INFO - 2023-12-14 17:33:46 --> Language Class Initialized
INFO - 2023-12-14 17:33:46 --> Config Class Initialized
INFO - 2023-12-14 17:33:46 --> Loader Class Initialized
INFO - 2023-12-14 17:33:46 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:46 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:46 --> Controller Class Initialized
DEBUG - 2023-12-14 17:33:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/tahun/views/list.php
DEBUG - 2023-12-14 17:33:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:33:46 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:46 --> Total execution time: 0.0431
INFO - 2023-12-14 17:33:46 --> Config Class Initialized
INFO - 2023-12-14 17:33:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:46 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:46 --> URI Class Initialized
INFO - 2023-12-14 17:33:46 --> Router Class Initialized
INFO - 2023-12-14 17:33:46 --> Output Class Initialized
INFO - 2023-12-14 17:33:46 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:46 --> Input Class Initialized
INFO - 2023-12-14 17:33:46 --> Language Class Initialized
ERROR - 2023-12-14 17:33:46 --> 404 Page Not Found: /index
INFO - 2023-12-14 17:33:46 --> Config Class Initialized
INFO - 2023-12-14 17:33:46 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:46 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:46 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:46 --> URI Class Initialized
INFO - 2023-12-14 17:33:46 --> Router Class Initialized
INFO - 2023-12-14 17:33:46 --> Output Class Initialized
INFO - 2023-12-14 17:33:46 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:46 --> Input Class Initialized
INFO - 2023-12-14 17:33:46 --> Language Class Initialized
INFO - 2023-12-14 17:33:46 --> Language Class Initialized
INFO - 2023-12-14 17:33:46 --> Config Class Initialized
INFO - 2023-12-14 17:33:46 --> Loader Class Initialized
INFO - 2023-12-14 17:33:46 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:46 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:46 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:46 --> Controller Class Initialized
INFO - 2023-12-14 17:33:49 --> Config Class Initialized
INFO - 2023-12-14 17:33:49 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:49 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:49 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:49 --> URI Class Initialized
INFO - 2023-12-14 17:33:49 --> Router Class Initialized
INFO - 2023-12-14 17:33:49 --> Output Class Initialized
INFO - 2023-12-14 17:33:49 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:49 --> Input Class Initialized
INFO - 2023-12-14 17:33:49 --> Language Class Initialized
INFO - 2023-12-14 17:33:49 --> Language Class Initialized
INFO - 2023-12-14 17:33:49 --> Config Class Initialized
INFO - 2023-12-14 17:33:49 --> Loader Class Initialized
INFO - 2023-12-14 17:33:49 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:49 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:49 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:49 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:49 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:49 --> Controller Class Initialized
INFO - 2023-12-14 17:33:49 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:49 --> Total execution time: 0.0419
INFO - 2023-12-14 17:33:56 --> Config Class Initialized
INFO - 2023-12-14 17:33:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:56 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:56 --> URI Class Initialized
INFO - 2023-12-14 17:33:56 --> Router Class Initialized
INFO - 2023-12-14 17:33:56 --> Output Class Initialized
INFO - 2023-12-14 17:33:56 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:56 --> Input Class Initialized
INFO - 2023-12-14 17:33:56 --> Language Class Initialized
INFO - 2023-12-14 17:33:56 --> Language Class Initialized
INFO - 2023-12-14 17:33:56 --> Config Class Initialized
INFO - 2023-12-14 17:33:56 --> Loader Class Initialized
INFO - 2023-12-14 17:33:56 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:56 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:56 --> Controller Class Initialized
INFO - 2023-12-14 17:33:56 --> Final output sent to browser
DEBUG - 2023-12-14 17:33:56 --> Total execution time: 0.0839
INFO - 2023-12-14 17:33:56 --> Config Class Initialized
INFO - 2023-12-14 17:33:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:56 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:56 --> URI Class Initialized
INFO - 2023-12-14 17:33:56 --> Router Class Initialized
INFO - 2023-12-14 17:33:56 --> Output Class Initialized
INFO - 2023-12-14 17:33:56 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:56 --> Input Class Initialized
INFO - 2023-12-14 17:33:56 --> Language Class Initialized
ERROR - 2023-12-14 17:33:56 --> 404 Page Not Found: /index
INFO - 2023-12-14 17:33:56 --> Config Class Initialized
INFO - 2023-12-14 17:33:56 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:33:56 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:33:56 --> Utf8 Class Initialized
INFO - 2023-12-14 17:33:56 --> URI Class Initialized
INFO - 2023-12-14 17:33:56 --> Router Class Initialized
INFO - 2023-12-14 17:33:56 --> Output Class Initialized
INFO - 2023-12-14 17:33:56 --> Security Class Initialized
DEBUG - 2023-12-14 17:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:33:56 --> Input Class Initialized
INFO - 2023-12-14 17:33:56 --> Language Class Initialized
INFO - 2023-12-14 17:33:56 --> Language Class Initialized
INFO - 2023-12-14 17:33:56 --> Config Class Initialized
INFO - 2023-12-14 17:33:56 --> Loader Class Initialized
INFO - 2023-12-14 17:33:56 --> Helper loaded: url_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: file_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: form_helper
INFO - 2023-12-14 17:33:56 --> Helper loaded: my_helper
INFO - 2023-12-14 17:33:56 --> Database Driver Class Initialized
INFO - 2023-12-14 17:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:33:56 --> Controller Class Initialized
INFO - 2023-12-14 17:34:01 --> Config Class Initialized
INFO - 2023-12-14 17:34:01 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:34:01 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:34:01 --> Utf8 Class Initialized
INFO - 2023-12-14 17:34:02 --> URI Class Initialized
DEBUG - 2023-12-14 17:34:02 --> No URI present. Default controller set.
INFO - 2023-12-14 17:34:02 --> Router Class Initialized
INFO - 2023-12-14 17:34:02 --> Output Class Initialized
INFO - 2023-12-14 17:34:02 --> Security Class Initialized
DEBUG - 2023-12-14 17:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:34:02 --> Input Class Initialized
INFO - 2023-12-14 17:34:02 --> Language Class Initialized
INFO - 2023-12-14 17:34:02 --> Language Class Initialized
INFO - 2023-12-14 17:34:02 --> Config Class Initialized
INFO - 2023-12-14 17:34:02 --> Loader Class Initialized
INFO - 2023-12-14 17:34:02 --> Helper loaded: url_helper
INFO - 2023-12-14 17:34:02 --> Helper loaded: file_helper
INFO - 2023-12-14 17:34:02 --> Helper loaded: form_helper
INFO - 2023-12-14 17:34:02 --> Helper loaded: my_helper
INFO - 2023-12-14 17:34:02 --> Database Driver Class Initialized
INFO - 2023-12-14 17:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:34:02 --> Controller Class Initialized
DEBUG - 2023-12-14 17:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-14 17:34:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:34:02 --> Final output sent to browser
DEBUG - 2023-12-14 17:34:02 --> Total execution time: 0.2237
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:43:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:43:35 --> Utf8 Class Initialized
INFO - 2023-12-14 17:43:35 --> URI Class Initialized
INFO - 2023-12-14 17:43:35 --> Router Class Initialized
INFO - 2023-12-14 17:43:35 --> Output Class Initialized
INFO - 2023-12-14 17:43:35 --> Security Class Initialized
DEBUG - 2023-12-14 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:43:35 --> Input Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Loader Class Initialized
INFO - 2023-12-14 17:43:35 --> Helper loaded: url_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: file_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: form_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: my_helper
INFO - 2023-12-14 17:43:35 --> Database Driver Class Initialized
INFO - 2023-12-14 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:43:35 --> Controller Class Initialized
INFO - 2023-12-14 17:43:35 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:43:35 --> Final output sent to browser
DEBUG - 2023-12-14 17:43:35 --> Total execution time: 0.0870
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:43:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:43:35 --> Utf8 Class Initialized
INFO - 2023-12-14 17:43:35 --> URI Class Initialized
INFO - 2023-12-14 17:43:35 --> Router Class Initialized
INFO - 2023-12-14 17:43:35 --> Output Class Initialized
INFO - 2023-12-14 17:43:35 --> Security Class Initialized
DEBUG - 2023-12-14 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:43:35 --> Input Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Loader Class Initialized
INFO - 2023-12-14 17:43:35 --> Helper loaded: url_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: file_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: form_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: my_helper
INFO - 2023-12-14 17:43:35 --> Database Driver Class Initialized
INFO - 2023-12-14 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:43:35 --> Controller Class Initialized
INFO - 2023-12-14 17:43:35 --> Helper loaded: cookie_helper
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Hooks Class Initialized
DEBUG - 2023-12-14 17:43:35 --> UTF-8 Support Enabled
INFO - 2023-12-14 17:43:35 --> Utf8 Class Initialized
INFO - 2023-12-14 17:43:35 --> URI Class Initialized
INFO - 2023-12-14 17:43:35 --> Router Class Initialized
INFO - 2023-12-14 17:43:35 --> Output Class Initialized
INFO - 2023-12-14 17:43:35 --> Security Class Initialized
DEBUG - 2023-12-14 17:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-14 17:43:35 --> Input Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Language Class Initialized
INFO - 2023-12-14 17:43:35 --> Config Class Initialized
INFO - 2023-12-14 17:43:35 --> Loader Class Initialized
INFO - 2023-12-14 17:43:35 --> Helper loaded: url_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: file_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: form_helper
INFO - 2023-12-14 17:43:35 --> Helper loaded: my_helper
INFO - 2023-12-14 17:43:35 --> Database Driver Class Initialized
INFO - 2023-12-14 17:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-14 17:43:35 --> Controller Class Initialized
DEBUG - 2023-12-14 17:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-14 17:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-14 17:43:35 --> Final output sent to browser
DEBUG - 2023-12-14 17:43:35 --> Total execution time: 0.0358
