<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-09-14 08:21:05 --> Config Class Initialized
INFO - 2023-09-14 08:21:05 --> Hooks Class Initialized
DEBUG - 2023-09-14 08:21:05 --> UTF-8 Support Enabled
INFO - 2023-09-14 08:21:05 --> Utf8 Class Initialized
INFO - 2023-09-14 08:21:05 --> URI Class Initialized
INFO - 2023-09-14 08:21:05 --> Router Class Initialized
INFO - 2023-09-14 08:21:05 --> Output Class Initialized
INFO - 2023-09-14 08:21:05 --> Security Class Initialized
DEBUG - 2023-09-14 08:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 08:21:05 --> Input Class Initialized
INFO - 2023-09-14 08:21:05 --> Language Class Initialized
INFO - 2023-09-14 08:21:05 --> Language Class Initialized
INFO - 2023-09-14 08:21:05 --> Config Class Initialized
INFO - 2023-09-14 08:21:05 --> Loader Class Initialized
INFO - 2023-09-14 08:21:05 --> Helper loaded: url_helper
INFO - 2023-09-14 08:21:05 --> Helper loaded: file_helper
INFO - 2023-09-14 08:21:05 --> Helper loaded: form_helper
INFO - 2023-09-14 08:21:05 --> Helper loaded: my_helper
INFO - 2023-09-14 08:21:05 --> Database Driver Class Initialized
INFO - 2023-09-14 08:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 08:21:05 --> Controller Class Initialized
DEBUG - 2023-09-14 08:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-09-14 08:21:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 08:21:05 --> Final output sent to browser
DEBUG - 2023-09-14 08:21:05 --> Total execution time: 0.0666
INFO - 2023-09-14 08:21:06 --> Config Class Initialized
INFO - 2023-09-14 08:21:06 --> Hooks Class Initialized
DEBUG - 2023-09-14 08:21:06 --> UTF-8 Support Enabled
INFO - 2023-09-14 08:21:06 --> Utf8 Class Initialized
INFO - 2023-09-14 08:21:06 --> URI Class Initialized
INFO - 2023-09-14 08:21:06 --> Router Class Initialized
INFO - 2023-09-14 08:21:06 --> Output Class Initialized
INFO - 2023-09-14 08:21:06 --> Security Class Initialized
DEBUG - 2023-09-14 08:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 08:21:06 --> Input Class Initialized
INFO - 2023-09-14 08:21:06 --> Language Class Initialized
INFO - 2023-09-14 08:21:06 --> Language Class Initialized
INFO - 2023-09-14 08:21:06 --> Config Class Initialized
INFO - 2023-09-14 08:21:06 --> Loader Class Initialized
INFO - 2023-09-14 08:21:06 --> Helper loaded: url_helper
INFO - 2023-09-14 08:21:06 --> Helper loaded: file_helper
INFO - 2023-09-14 08:21:06 --> Helper loaded: form_helper
INFO - 2023-09-14 08:21:06 --> Helper loaded: my_helper
INFO - 2023-09-14 08:21:06 --> Database Driver Class Initialized
INFO - 2023-09-14 08:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 08:21:06 --> Controller Class Initialized
INFO - 2023-09-14 10:04:30 --> Config Class Initialized
INFO - 2023-09-14 10:04:30 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:04:30 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:04:30 --> Utf8 Class Initialized
INFO - 2023-09-14 10:04:30 --> URI Class Initialized
INFO - 2023-09-14 10:04:30 --> Router Class Initialized
INFO - 2023-09-14 10:04:30 --> Output Class Initialized
INFO - 2023-09-14 10:04:30 --> Security Class Initialized
DEBUG - 2023-09-14 10:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:04:30 --> Input Class Initialized
INFO - 2023-09-14 10:04:30 --> Language Class Initialized
INFO - 2023-09-14 10:04:30 --> Language Class Initialized
INFO - 2023-09-14 10:04:30 --> Config Class Initialized
INFO - 2023-09-14 10:04:30 --> Loader Class Initialized
INFO - 2023-09-14 10:04:30 --> Helper loaded: url_helper
INFO - 2023-09-14 10:04:30 --> Helper loaded: file_helper
INFO - 2023-09-14 10:04:30 --> Helper loaded: form_helper
INFO - 2023-09-14 10:04:30 --> Helper loaded: my_helper
INFO - 2023-09-14 10:04:30 --> Database Driver Class Initialized
INFO - 2023-09-14 10:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:04:30 --> Controller Class Initialized
DEBUG - 2023-09-14 10:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-14 10:04:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:04:30 --> Final output sent to browser
DEBUG - 2023-09-14 10:04:30 --> Total execution time: 0.0655
INFO - 2023-09-14 10:45:29 --> Config Class Initialized
INFO - 2023-09-14 10:45:29 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:29 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:29 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:29 --> URI Class Initialized
INFO - 2023-09-14 10:45:29 --> Router Class Initialized
INFO - 2023-09-14 10:45:29 --> Output Class Initialized
INFO - 2023-09-14 10:45:29 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:29 --> Input Class Initialized
INFO - 2023-09-14 10:45:29 --> Language Class Initialized
INFO - 2023-09-14 10:45:29 --> Language Class Initialized
INFO - 2023-09-14 10:45:29 --> Config Class Initialized
INFO - 2023-09-14 10:45:29 --> Loader Class Initialized
INFO - 2023-09-14 10:45:29 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:29 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:29 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:29 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:29 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:29 --> Controller Class Initialized
DEBUG - 2023-09-14 10:45:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-09-14 10:45:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:45:29 --> Final output sent to browser
DEBUG - 2023-09-14 10:45:29 --> Total execution time: 0.3082
INFO - 2023-09-14 10:45:32 --> Config Class Initialized
INFO - 2023-09-14 10:45:32 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:32 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:32 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:32 --> URI Class Initialized
INFO - 2023-09-14 10:45:32 --> Router Class Initialized
INFO - 2023-09-14 10:45:32 --> Output Class Initialized
INFO - 2023-09-14 10:45:32 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:32 --> Input Class Initialized
INFO - 2023-09-14 10:45:32 --> Language Class Initialized
INFO - 2023-09-14 10:45:32 --> Language Class Initialized
INFO - 2023-09-14 10:45:32 --> Config Class Initialized
INFO - 2023-09-14 10:45:32 --> Loader Class Initialized
INFO - 2023-09-14 10:45:32 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:32 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:32 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:32 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:32 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:32 --> Controller Class Initialized
INFO - 2023-09-14 10:45:32 --> Helper loaded: cookie_helper
INFO - 2023-09-14 10:45:32 --> Final output sent to browser
DEBUG - 2023-09-14 10:45:32 --> Total execution time: 0.0321
INFO - 2023-09-14 10:45:33 --> Config Class Initialized
INFO - 2023-09-14 10:45:33 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:33 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:33 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:33 --> URI Class Initialized
INFO - 2023-09-14 10:45:33 --> Router Class Initialized
INFO - 2023-09-14 10:45:33 --> Output Class Initialized
INFO - 2023-09-14 10:45:33 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:33 --> Input Class Initialized
INFO - 2023-09-14 10:45:33 --> Language Class Initialized
INFO - 2023-09-14 10:45:33 --> Language Class Initialized
INFO - 2023-09-14 10:45:33 --> Config Class Initialized
INFO - 2023-09-14 10:45:33 --> Loader Class Initialized
INFO - 2023-09-14 10:45:33 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:33 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:33 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:33 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:33 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:33 --> Controller Class Initialized
DEBUG - 2023-09-14 10:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-09-14 10:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:45:33 --> Final output sent to browser
DEBUG - 2023-09-14 10:45:33 --> Total execution time: 0.0365
INFO - 2023-09-14 10:45:37 --> Config Class Initialized
INFO - 2023-09-14 10:45:37 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:37 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:37 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:37 --> URI Class Initialized
INFO - 2023-09-14 10:45:37 --> Router Class Initialized
INFO - 2023-09-14 10:45:37 --> Output Class Initialized
INFO - 2023-09-14 10:45:37 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:37 --> Input Class Initialized
INFO - 2023-09-14 10:45:37 --> Language Class Initialized
INFO - 2023-09-14 10:45:37 --> Language Class Initialized
INFO - 2023-09-14 10:45:37 --> Config Class Initialized
INFO - 2023-09-14 10:45:37 --> Loader Class Initialized
INFO - 2023-09-14 10:45:37 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:37 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:37 --> Controller Class Initialized
DEBUG - 2023-09-14 10:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-14 10:45:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:45:37 --> Final output sent to browser
DEBUG - 2023-09-14 10:45:37 --> Total execution time: 0.0442
INFO - 2023-09-14 10:45:37 --> Config Class Initialized
INFO - 2023-09-14 10:45:37 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:37 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:37 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:37 --> URI Class Initialized
INFO - 2023-09-14 10:45:37 --> Router Class Initialized
INFO - 2023-09-14 10:45:37 --> Output Class Initialized
INFO - 2023-09-14 10:45:37 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:37 --> Input Class Initialized
INFO - 2023-09-14 10:45:37 --> Language Class Initialized
ERROR - 2023-09-14 10:45:37 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:45:37 --> Config Class Initialized
INFO - 2023-09-14 10:45:37 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:37 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:37 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:37 --> URI Class Initialized
INFO - 2023-09-14 10:45:37 --> Router Class Initialized
INFO - 2023-09-14 10:45:37 --> Output Class Initialized
INFO - 2023-09-14 10:45:37 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:37 --> Input Class Initialized
INFO - 2023-09-14 10:45:37 --> Language Class Initialized
INFO - 2023-09-14 10:45:37 --> Language Class Initialized
INFO - 2023-09-14 10:45:37 --> Config Class Initialized
INFO - 2023-09-14 10:45:37 --> Loader Class Initialized
INFO - 2023-09-14 10:45:37 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:37 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:37 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:37 --> Controller Class Initialized
INFO - 2023-09-14 10:45:45 --> Config Class Initialized
INFO - 2023-09-14 10:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:45 --> URI Class Initialized
INFO - 2023-09-14 10:45:45 --> Router Class Initialized
INFO - 2023-09-14 10:45:45 --> Output Class Initialized
INFO - 2023-09-14 10:45:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:45 --> Input Class Initialized
INFO - 2023-09-14 10:45:45 --> Language Class Initialized
INFO - 2023-09-14 10:45:45 --> Language Class Initialized
INFO - 2023-09-14 10:45:45 --> Config Class Initialized
INFO - 2023-09-14 10:45:45 --> Loader Class Initialized
INFO - 2023-09-14 10:45:45 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:45 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:45 --> Controller Class Initialized
DEBUG - 2023-09-14 10:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-14 10:45:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:45:45 --> Final output sent to browser
DEBUG - 2023-09-14 10:45:45 --> Total execution time: 0.0725
INFO - 2023-09-14 10:45:45 --> Config Class Initialized
INFO - 2023-09-14 10:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:45 --> URI Class Initialized
INFO - 2023-09-14 10:45:45 --> Router Class Initialized
INFO - 2023-09-14 10:45:45 --> Output Class Initialized
INFO - 2023-09-14 10:45:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:45 --> Input Class Initialized
INFO - 2023-09-14 10:45:45 --> Language Class Initialized
ERROR - 2023-09-14 10:45:45 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:45:45 --> Config Class Initialized
INFO - 2023-09-14 10:45:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:45 --> URI Class Initialized
INFO - 2023-09-14 10:45:45 --> Router Class Initialized
INFO - 2023-09-14 10:45:45 --> Output Class Initialized
INFO - 2023-09-14 10:45:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:45 --> Input Class Initialized
INFO - 2023-09-14 10:45:45 --> Language Class Initialized
INFO - 2023-09-14 10:45:45 --> Language Class Initialized
INFO - 2023-09-14 10:45:45 --> Config Class Initialized
INFO - 2023-09-14 10:45:45 --> Loader Class Initialized
INFO - 2023-09-14 10:45:45 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:45 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:45 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:45 --> Controller Class Initialized
INFO - 2023-09-14 10:45:48 --> Config Class Initialized
INFO - 2023-09-14 10:45:48 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:48 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:48 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:48 --> URI Class Initialized
INFO - 2023-09-14 10:45:48 --> Router Class Initialized
INFO - 2023-09-14 10:45:48 --> Output Class Initialized
INFO - 2023-09-14 10:45:48 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:48 --> Input Class Initialized
INFO - 2023-09-14 10:45:48 --> Language Class Initialized
INFO - 2023-09-14 10:45:48 --> Language Class Initialized
INFO - 2023-09-14 10:45:48 --> Config Class Initialized
INFO - 2023-09-14 10:45:48 --> Loader Class Initialized
INFO - 2023-09-14 10:45:48 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:48 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:48 --> Controller Class Initialized
INFO - 2023-09-14 10:45:48 --> Config Class Initialized
INFO - 2023-09-14 10:45:48 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:48 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:48 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:48 --> URI Class Initialized
INFO - 2023-09-14 10:45:48 --> Router Class Initialized
INFO - 2023-09-14 10:45:48 --> Output Class Initialized
INFO - 2023-09-14 10:45:48 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:48 --> Input Class Initialized
INFO - 2023-09-14 10:45:48 --> Language Class Initialized
INFO - 2023-09-14 10:45:48 --> Language Class Initialized
INFO - 2023-09-14 10:45:48 --> Config Class Initialized
INFO - 2023-09-14 10:45:48 --> Loader Class Initialized
INFO - 2023-09-14 10:45:48 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:48 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:48 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:48 --> Controller Class Initialized
INFO - 2023-09-14 10:45:53 --> Config Class Initialized
INFO - 2023-09-14 10:45:53 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:53 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:53 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:53 --> URI Class Initialized
INFO - 2023-09-14 10:45:53 --> Router Class Initialized
INFO - 2023-09-14 10:45:53 --> Output Class Initialized
INFO - 2023-09-14 10:45:53 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:53 --> Input Class Initialized
INFO - 2023-09-14 10:45:53 --> Language Class Initialized
INFO - 2023-09-14 10:45:53 --> Language Class Initialized
INFO - 2023-09-14 10:45:53 --> Config Class Initialized
INFO - 2023-09-14 10:45:53 --> Loader Class Initialized
INFO - 2023-09-14 10:45:53 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:53 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:53 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:53 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:53 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:53 --> Controller Class Initialized
ERROR - 2023-09-14 10:45:53 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`ereport_secondary_bangka`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '13'
INFO - 2023-09-14 10:45:53 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-14 10:45:59 --> Config Class Initialized
INFO - 2023-09-14 10:45:59 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:45:59 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:45:59 --> Utf8 Class Initialized
INFO - 2023-09-14 10:45:59 --> URI Class Initialized
INFO - 2023-09-14 10:45:59 --> Router Class Initialized
INFO - 2023-09-14 10:45:59 --> Output Class Initialized
INFO - 2023-09-14 10:45:59 --> Security Class Initialized
DEBUG - 2023-09-14 10:45:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:45:59 --> Input Class Initialized
INFO - 2023-09-14 10:45:59 --> Language Class Initialized
INFO - 2023-09-14 10:45:59 --> Language Class Initialized
INFO - 2023-09-14 10:45:59 --> Config Class Initialized
INFO - 2023-09-14 10:45:59 --> Loader Class Initialized
INFO - 2023-09-14 10:45:59 --> Helper loaded: url_helper
INFO - 2023-09-14 10:45:59 --> Helper loaded: file_helper
INFO - 2023-09-14 10:45:59 --> Helper loaded: form_helper
INFO - 2023-09-14 10:45:59 --> Helper loaded: my_helper
INFO - 2023-09-14 10:45:59 --> Database Driver Class Initialized
INFO - 2023-09-14 10:45:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:45:59 --> Controller Class Initialized
ERROR - 2023-09-14 10:45:59 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`ereport_secondary_bangka`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '13'
INFO - 2023-09-14 10:45:59 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-14 10:46:02 --> Config Class Initialized
INFO - 2023-09-14 10:46:02 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:02 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:02 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:02 --> URI Class Initialized
INFO - 2023-09-14 10:46:02 --> Router Class Initialized
INFO - 2023-09-14 10:46:02 --> Output Class Initialized
INFO - 2023-09-14 10:46:02 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:02 --> Input Class Initialized
INFO - 2023-09-14 10:46:02 --> Language Class Initialized
INFO - 2023-09-14 10:46:02 --> Language Class Initialized
INFO - 2023-09-14 10:46:02 --> Config Class Initialized
INFO - 2023-09-14 10:46:02 --> Loader Class Initialized
INFO - 2023-09-14 10:46:02 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:02 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:02 --> Controller Class Initialized
DEBUG - 2023-09-14 10:46:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-14 10:46:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:46:02 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:02 --> Total execution time: 0.0367
INFO - 2023-09-14 10:46:02 --> Config Class Initialized
INFO - 2023-09-14 10:46:02 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:02 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:02 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:02 --> URI Class Initialized
INFO - 2023-09-14 10:46:02 --> Router Class Initialized
INFO - 2023-09-14 10:46:02 --> Output Class Initialized
INFO - 2023-09-14 10:46:02 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:02 --> Input Class Initialized
INFO - 2023-09-14 10:46:02 --> Language Class Initialized
ERROR - 2023-09-14 10:46:02 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:02 --> Config Class Initialized
INFO - 2023-09-14 10:46:02 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:02 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:02 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:02 --> URI Class Initialized
INFO - 2023-09-14 10:46:02 --> Router Class Initialized
INFO - 2023-09-14 10:46:02 --> Output Class Initialized
INFO - 2023-09-14 10:46:02 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:02 --> Input Class Initialized
INFO - 2023-09-14 10:46:02 --> Language Class Initialized
INFO - 2023-09-14 10:46:02 --> Language Class Initialized
INFO - 2023-09-14 10:46:02 --> Config Class Initialized
INFO - 2023-09-14 10:46:02 --> Loader Class Initialized
INFO - 2023-09-14 10:46:02 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:02 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:02 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:02 --> Controller Class Initialized
INFO - 2023-09-14 10:46:14 --> Config Class Initialized
INFO - 2023-09-14 10:46:14 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:14 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:14 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:14 --> URI Class Initialized
INFO - 2023-09-14 10:46:14 --> Router Class Initialized
INFO - 2023-09-14 10:46:14 --> Output Class Initialized
INFO - 2023-09-14 10:46:14 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:14 --> Input Class Initialized
INFO - 2023-09-14 10:46:14 --> Language Class Initialized
INFO - 2023-09-14 10:46:14 --> Language Class Initialized
INFO - 2023-09-14 10:46:14 --> Config Class Initialized
INFO - 2023-09-14 10:46:14 --> Loader Class Initialized
INFO - 2023-09-14 10:46:14 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:14 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:14 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:14 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:14 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:14 --> Controller Class Initialized
ERROR - 2023-09-14 10:46:14 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`ereport_secondary_bangka`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '13'
INFO - 2023-09-14 10:46:14 --> Language file loaded: language/english/db_lang.php
INFO - 2023-09-14 10:46:18 --> Config Class Initialized
INFO - 2023-09-14 10:46:18 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:18 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:18 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:18 --> URI Class Initialized
INFO - 2023-09-14 10:46:18 --> Router Class Initialized
INFO - 2023-09-14 10:46:18 --> Output Class Initialized
INFO - 2023-09-14 10:46:18 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:18 --> Input Class Initialized
INFO - 2023-09-14 10:46:18 --> Language Class Initialized
INFO - 2023-09-14 10:46:18 --> Language Class Initialized
INFO - 2023-09-14 10:46:18 --> Config Class Initialized
INFO - 2023-09-14 10:46:18 --> Loader Class Initialized
INFO - 2023-09-14 10:46:18 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:18 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:18 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:18 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:18 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:18 --> Controller Class Initialized
INFO - 2023-09-14 10:46:18 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:18 --> Total execution time: 0.0358
INFO - 2023-09-14 10:46:24 --> Config Class Initialized
INFO - 2023-09-14 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:24 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:24 --> URI Class Initialized
INFO - 2023-09-14 10:46:24 --> Router Class Initialized
INFO - 2023-09-14 10:46:24 --> Output Class Initialized
INFO - 2023-09-14 10:46:24 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:24 --> Input Class Initialized
INFO - 2023-09-14 10:46:24 --> Language Class Initialized
INFO - 2023-09-14 10:46:24 --> Language Class Initialized
INFO - 2023-09-14 10:46:24 --> Config Class Initialized
INFO - 2023-09-14 10:46:24 --> Loader Class Initialized
INFO - 2023-09-14 10:46:24 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:24 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:24 --> Controller Class Initialized
DEBUG - 2023-09-14 10:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-09-14 10:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:46:24 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:24 --> Total execution time: 0.0384
INFO - 2023-09-14 10:46:24 --> Config Class Initialized
INFO - 2023-09-14 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:24 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:24 --> URI Class Initialized
INFO - 2023-09-14 10:46:24 --> Router Class Initialized
INFO - 2023-09-14 10:46:24 --> Output Class Initialized
INFO - 2023-09-14 10:46:24 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:24 --> Input Class Initialized
INFO - 2023-09-14 10:46:24 --> Language Class Initialized
ERROR - 2023-09-14 10:46:24 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:24 --> Config Class Initialized
INFO - 2023-09-14 10:46:24 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:24 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:24 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:24 --> URI Class Initialized
INFO - 2023-09-14 10:46:24 --> Router Class Initialized
INFO - 2023-09-14 10:46:24 --> Output Class Initialized
INFO - 2023-09-14 10:46:24 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:24 --> Input Class Initialized
INFO - 2023-09-14 10:46:24 --> Language Class Initialized
INFO - 2023-09-14 10:46:24 --> Language Class Initialized
INFO - 2023-09-14 10:46:24 --> Config Class Initialized
INFO - 2023-09-14 10:46:24 --> Loader Class Initialized
INFO - 2023-09-14 10:46:24 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:24 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:24 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:24 --> Controller Class Initialized
INFO - 2023-09-14 10:46:31 --> Config Class Initialized
INFO - 2023-09-14 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:31 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:31 --> URI Class Initialized
INFO - 2023-09-14 10:46:31 --> Router Class Initialized
INFO - 2023-09-14 10:46:31 --> Output Class Initialized
INFO - 2023-09-14 10:46:31 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:31 --> Input Class Initialized
INFO - 2023-09-14 10:46:31 --> Language Class Initialized
INFO - 2023-09-14 10:46:31 --> Language Class Initialized
INFO - 2023-09-14 10:46:31 --> Config Class Initialized
INFO - 2023-09-14 10:46:31 --> Loader Class Initialized
INFO - 2023-09-14 10:46:31 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:31 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:31 --> Controller Class Initialized
DEBUG - 2023-09-14 10:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-14 10:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:46:31 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:31 --> Total execution time: 0.0332
INFO - 2023-09-14 10:46:31 --> Config Class Initialized
INFO - 2023-09-14 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:31 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:31 --> URI Class Initialized
INFO - 2023-09-14 10:46:31 --> Router Class Initialized
INFO - 2023-09-14 10:46:31 --> Output Class Initialized
INFO - 2023-09-14 10:46:31 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:31 --> Input Class Initialized
INFO - 2023-09-14 10:46:31 --> Language Class Initialized
ERROR - 2023-09-14 10:46:31 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:31 --> Config Class Initialized
INFO - 2023-09-14 10:46:31 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:31 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:31 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:31 --> URI Class Initialized
INFO - 2023-09-14 10:46:31 --> Router Class Initialized
INFO - 2023-09-14 10:46:31 --> Output Class Initialized
INFO - 2023-09-14 10:46:31 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:31 --> Input Class Initialized
INFO - 2023-09-14 10:46:31 --> Language Class Initialized
INFO - 2023-09-14 10:46:31 --> Language Class Initialized
INFO - 2023-09-14 10:46:31 --> Config Class Initialized
INFO - 2023-09-14 10:46:31 --> Loader Class Initialized
INFO - 2023-09-14 10:46:31 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:31 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:31 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:31 --> Controller Class Initialized
INFO - 2023-09-14 10:46:38 --> Config Class Initialized
INFO - 2023-09-14 10:46:38 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:38 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:38 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:38 --> URI Class Initialized
INFO - 2023-09-14 10:46:38 --> Router Class Initialized
INFO - 2023-09-14 10:46:38 --> Output Class Initialized
INFO - 2023-09-14 10:46:38 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:38 --> Input Class Initialized
INFO - 2023-09-14 10:46:38 --> Language Class Initialized
INFO - 2023-09-14 10:46:38 --> Language Class Initialized
INFO - 2023-09-14 10:46:38 --> Config Class Initialized
INFO - 2023-09-14 10:46:38 --> Loader Class Initialized
INFO - 2023-09-14 10:46:38 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:38 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:38 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:38 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:38 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:38 --> Controller Class Initialized
DEBUG - 2023-09-14 10:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_mapel/views/list.php
DEBUG - 2023-09-14 10:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:46:38 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:38 --> Total execution time: 0.0319
INFO - 2023-09-14 10:46:38 --> Config Class Initialized
INFO - 2023-09-14 10:46:38 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:38 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:38 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:38 --> URI Class Initialized
INFO - 2023-09-14 10:46:38 --> Router Class Initialized
INFO - 2023-09-14 10:46:39 --> Output Class Initialized
INFO - 2023-09-14 10:46:39 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:39 --> Input Class Initialized
INFO - 2023-09-14 10:46:39 --> Language Class Initialized
ERROR - 2023-09-14 10:46:39 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:39 --> Config Class Initialized
INFO - 2023-09-14 10:46:39 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:39 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:39 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:39 --> URI Class Initialized
INFO - 2023-09-14 10:46:39 --> Router Class Initialized
INFO - 2023-09-14 10:46:39 --> Output Class Initialized
INFO - 2023-09-14 10:46:39 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:39 --> Input Class Initialized
INFO - 2023-09-14 10:46:39 --> Language Class Initialized
INFO - 2023-09-14 10:46:39 --> Language Class Initialized
INFO - 2023-09-14 10:46:39 --> Config Class Initialized
INFO - 2023-09-14 10:46:39 --> Loader Class Initialized
INFO - 2023-09-14 10:46:39 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:39 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:39 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:39 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:39 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:39 --> Controller Class Initialized
INFO - 2023-09-14 10:46:41 --> Config Class Initialized
INFO - 2023-09-14 10:46:41 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:41 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:41 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:41 --> URI Class Initialized
INFO - 2023-09-14 10:46:41 --> Router Class Initialized
INFO - 2023-09-14 10:46:41 --> Output Class Initialized
INFO - 2023-09-14 10:46:41 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:41 --> Input Class Initialized
INFO - 2023-09-14 10:46:41 --> Language Class Initialized
INFO - 2023-09-14 10:46:41 --> Language Class Initialized
INFO - 2023-09-14 10:46:41 --> Config Class Initialized
INFO - 2023-09-14 10:46:41 --> Loader Class Initialized
INFO - 2023-09-14 10:46:41 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:41 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:41 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:41 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:41 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:41 --> Controller Class Initialized
INFO - 2023-09-14 10:46:42 --> Config Class Initialized
INFO - 2023-09-14 10:46:42 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:42 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:42 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:42 --> URI Class Initialized
INFO - 2023-09-14 10:46:42 --> Router Class Initialized
INFO - 2023-09-14 10:46:42 --> Output Class Initialized
INFO - 2023-09-14 10:46:42 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:42 --> Input Class Initialized
INFO - 2023-09-14 10:46:42 --> Language Class Initialized
INFO - 2023-09-14 10:46:42 --> Language Class Initialized
INFO - 2023-09-14 10:46:42 --> Config Class Initialized
INFO - 2023-09-14 10:46:42 --> Loader Class Initialized
INFO - 2023-09-14 10:46:42 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:42 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:42 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:42 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:42 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:42 --> Controller Class Initialized
INFO - 2023-09-14 10:46:45 --> Config Class Initialized
INFO - 2023-09-14 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:45 --> URI Class Initialized
INFO - 2023-09-14 10:46:45 --> Router Class Initialized
INFO - 2023-09-14 10:46:45 --> Output Class Initialized
INFO - 2023-09-14 10:46:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:45 --> Input Class Initialized
INFO - 2023-09-14 10:46:45 --> Language Class Initialized
INFO - 2023-09-14 10:46:45 --> Language Class Initialized
INFO - 2023-09-14 10:46:45 --> Config Class Initialized
INFO - 2023-09-14 10:46:45 --> Loader Class Initialized
INFO - 2023-09-14 10:46:45 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:45 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:45 --> Controller Class Initialized
INFO - 2023-09-14 10:46:45 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:45 --> Total execution time: 0.0411
INFO - 2023-09-14 10:46:45 --> Config Class Initialized
INFO - 2023-09-14 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:45 --> URI Class Initialized
INFO - 2023-09-14 10:46:45 --> Router Class Initialized
INFO - 2023-09-14 10:46:45 --> Output Class Initialized
INFO - 2023-09-14 10:46:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:45 --> Input Class Initialized
INFO - 2023-09-14 10:46:45 --> Language Class Initialized
ERROR - 2023-09-14 10:46:45 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:45 --> Config Class Initialized
INFO - 2023-09-14 10:46:45 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:45 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:45 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:45 --> URI Class Initialized
INFO - 2023-09-14 10:46:45 --> Router Class Initialized
INFO - 2023-09-14 10:46:45 --> Output Class Initialized
INFO - 2023-09-14 10:46:45 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:45 --> Input Class Initialized
INFO - 2023-09-14 10:46:45 --> Language Class Initialized
INFO - 2023-09-14 10:46:45 --> Language Class Initialized
INFO - 2023-09-14 10:46:45 --> Config Class Initialized
INFO - 2023-09-14 10:46:45 --> Loader Class Initialized
INFO - 2023-09-14 10:46:45 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:45 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:45 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:45 --> Controller Class Initialized
INFO - 2023-09-14 10:46:48 --> Config Class Initialized
INFO - 2023-09-14 10:46:48 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:48 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:48 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:48 --> URI Class Initialized
INFO - 2023-09-14 10:46:48 --> Router Class Initialized
INFO - 2023-09-14 10:46:48 --> Output Class Initialized
INFO - 2023-09-14 10:46:48 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:48 --> Input Class Initialized
INFO - 2023-09-14 10:46:48 --> Language Class Initialized
INFO - 2023-09-14 10:46:48 --> Language Class Initialized
INFO - 2023-09-14 10:46:48 --> Config Class Initialized
INFO - 2023-09-14 10:46:48 --> Loader Class Initialized
INFO - 2023-09-14 10:46:48 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:48 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:48 --> Controller Class Initialized
DEBUG - 2023-09-14 10:46:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-09-14 10:46:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-09-14 10:46:48 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:48 --> Total execution time: 0.0301
INFO - 2023-09-14 10:46:48 --> Config Class Initialized
INFO - 2023-09-14 10:46:48 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:48 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:48 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:48 --> URI Class Initialized
INFO - 2023-09-14 10:46:48 --> Router Class Initialized
INFO - 2023-09-14 10:46:48 --> Output Class Initialized
INFO - 2023-09-14 10:46:48 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:48 --> Input Class Initialized
INFO - 2023-09-14 10:46:48 --> Language Class Initialized
ERROR - 2023-09-14 10:46:48 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:48 --> Config Class Initialized
INFO - 2023-09-14 10:46:48 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:48 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:48 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:48 --> URI Class Initialized
INFO - 2023-09-14 10:46:48 --> Router Class Initialized
INFO - 2023-09-14 10:46:48 --> Output Class Initialized
INFO - 2023-09-14 10:46:48 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:48 --> Input Class Initialized
INFO - 2023-09-14 10:46:48 --> Language Class Initialized
INFO - 2023-09-14 10:46:48 --> Language Class Initialized
INFO - 2023-09-14 10:46:48 --> Config Class Initialized
INFO - 2023-09-14 10:46:48 --> Loader Class Initialized
INFO - 2023-09-14 10:46:48 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:48 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:48 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:48 --> Controller Class Initialized
INFO - 2023-09-14 10:46:51 --> Config Class Initialized
INFO - 2023-09-14 10:46:51 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:51 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:51 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:51 --> URI Class Initialized
INFO - 2023-09-14 10:46:51 --> Router Class Initialized
INFO - 2023-09-14 10:46:51 --> Output Class Initialized
INFO - 2023-09-14 10:46:51 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:51 --> Input Class Initialized
INFO - 2023-09-14 10:46:51 --> Language Class Initialized
INFO - 2023-09-14 10:46:51 --> Language Class Initialized
INFO - 2023-09-14 10:46:51 --> Config Class Initialized
INFO - 2023-09-14 10:46:51 --> Loader Class Initialized
INFO - 2023-09-14 10:46:51 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:51 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:51 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:51 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:51 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:51 --> Controller Class Initialized
INFO - 2023-09-14 10:46:52 --> Config Class Initialized
INFO - 2023-09-14 10:46:52 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:52 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:52 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:52 --> URI Class Initialized
INFO - 2023-09-14 10:46:52 --> Router Class Initialized
INFO - 2023-09-14 10:46:52 --> Output Class Initialized
INFO - 2023-09-14 10:46:52 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:52 --> Input Class Initialized
INFO - 2023-09-14 10:46:52 --> Language Class Initialized
INFO - 2023-09-14 10:46:52 --> Language Class Initialized
INFO - 2023-09-14 10:46:52 --> Config Class Initialized
INFO - 2023-09-14 10:46:52 --> Loader Class Initialized
INFO - 2023-09-14 10:46:52 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:52 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:52 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:52 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:52 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:52 --> Controller Class Initialized
INFO - 2023-09-14 10:46:55 --> Config Class Initialized
INFO - 2023-09-14 10:46:55 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:55 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:55 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:55 --> URI Class Initialized
INFO - 2023-09-14 10:46:55 --> Router Class Initialized
INFO - 2023-09-14 10:46:55 --> Output Class Initialized
INFO - 2023-09-14 10:46:55 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:55 --> Input Class Initialized
INFO - 2023-09-14 10:46:55 --> Language Class Initialized
INFO - 2023-09-14 10:46:55 --> Language Class Initialized
INFO - 2023-09-14 10:46:55 --> Config Class Initialized
INFO - 2023-09-14 10:46:55 --> Loader Class Initialized
INFO - 2023-09-14 10:46:55 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:55 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:55 --> Controller Class Initialized
INFO - 2023-09-14 10:46:55 --> Final output sent to browser
DEBUG - 2023-09-14 10:46:55 --> Total execution time: 0.0438
INFO - 2023-09-14 10:46:55 --> Config Class Initialized
INFO - 2023-09-14 10:46:55 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:55 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:55 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:55 --> URI Class Initialized
INFO - 2023-09-14 10:46:55 --> Router Class Initialized
INFO - 2023-09-14 10:46:55 --> Output Class Initialized
INFO - 2023-09-14 10:46:55 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:55 --> Input Class Initialized
INFO - 2023-09-14 10:46:55 --> Language Class Initialized
ERROR - 2023-09-14 10:46:55 --> 404 Page Not Found: /index
INFO - 2023-09-14 10:46:55 --> Config Class Initialized
INFO - 2023-09-14 10:46:55 --> Hooks Class Initialized
DEBUG - 2023-09-14 10:46:55 --> UTF-8 Support Enabled
INFO - 2023-09-14 10:46:55 --> Utf8 Class Initialized
INFO - 2023-09-14 10:46:55 --> URI Class Initialized
INFO - 2023-09-14 10:46:55 --> Router Class Initialized
INFO - 2023-09-14 10:46:55 --> Output Class Initialized
INFO - 2023-09-14 10:46:55 --> Security Class Initialized
DEBUG - 2023-09-14 10:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-09-14 10:46:55 --> Input Class Initialized
INFO - 2023-09-14 10:46:55 --> Language Class Initialized
INFO - 2023-09-14 10:46:55 --> Language Class Initialized
INFO - 2023-09-14 10:46:55 --> Config Class Initialized
INFO - 2023-09-14 10:46:55 --> Loader Class Initialized
INFO - 2023-09-14 10:46:55 --> Helper loaded: url_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: file_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: form_helper
INFO - 2023-09-14 10:46:55 --> Helper loaded: my_helper
INFO - 2023-09-14 10:46:55 --> Database Driver Class Initialized
INFO - 2023-09-14 10:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-09-14 10:46:55 --> Controller Class Initialized
