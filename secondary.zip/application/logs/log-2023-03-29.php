<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-03-29 03:40:49 --> Config Class Initialized
INFO - 2023-03-29 03:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:40:49 --> Utf8 Class Initialized
INFO - 2023-03-29 03:40:49 --> URI Class Initialized
DEBUG - 2023-03-29 03:40:49 --> No URI present. Default controller set.
INFO - 2023-03-29 03:40:49 --> Router Class Initialized
INFO - 2023-03-29 03:40:49 --> Output Class Initialized
INFO - 2023-03-29 03:40:49 --> Security Class Initialized
DEBUG - 2023-03-29 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:40:49 --> Input Class Initialized
INFO - 2023-03-29 03:40:49 --> Language Class Initialized
INFO - 2023-03-29 03:40:49 --> Language Class Initialized
INFO - 2023-03-29 03:40:49 --> Config Class Initialized
INFO - 2023-03-29 03:40:49 --> Loader Class Initialized
INFO - 2023-03-29 03:40:49 --> Helper loaded: url_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: file_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: form_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: my_helper
INFO - 2023-03-29 03:40:49 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:40:49 --> Controller Class Initialized
INFO - 2023-03-29 03:40:49 --> Config Class Initialized
INFO - 2023-03-29 03:40:49 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:40:49 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:40:49 --> Utf8 Class Initialized
INFO - 2023-03-29 03:40:49 --> URI Class Initialized
INFO - 2023-03-29 03:40:49 --> Router Class Initialized
INFO - 2023-03-29 03:40:49 --> Output Class Initialized
INFO - 2023-03-29 03:40:49 --> Security Class Initialized
DEBUG - 2023-03-29 03:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:40:49 --> Input Class Initialized
INFO - 2023-03-29 03:40:49 --> Language Class Initialized
INFO - 2023-03-29 03:40:49 --> Language Class Initialized
INFO - 2023-03-29 03:40:49 --> Config Class Initialized
INFO - 2023-03-29 03:40:49 --> Loader Class Initialized
INFO - 2023-03-29 03:40:49 --> Helper loaded: url_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: file_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: form_helper
INFO - 2023-03-29 03:40:49 --> Helper loaded: my_helper
INFO - 2023-03-29 03:40:49 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:40:49 --> Controller Class Initialized
DEBUG - 2023-03-29 03:40:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-29 03:40:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 03:40:49 --> Final output sent to browser
DEBUG - 2023-03-29 03:40:49 --> Total execution time: 0.0687
INFO - 2023-03-29 03:40:56 --> Config Class Initialized
INFO - 2023-03-29 03:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:40:56 --> Utf8 Class Initialized
INFO - 2023-03-29 03:40:56 --> URI Class Initialized
INFO - 2023-03-29 03:40:56 --> Router Class Initialized
INFO - 2023-03-29 03:40:56 --> Output Class Initialized
INFO - 2023-03-29 03:40:56 --> Security Class Initialized
DEBUG - 2023-03-29 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:40:56 --> Input Class Initialized
INFO - 2023-03-29 03:40:56 --> Language Class Initialized
INFO - 2023-03-29 03:40:56 --> Language Class Initialized
INFO - 2023-03-29 03:40:56 --> Config Class Initialized
INFO - 2023-03-29 03:40:56 --> Loader Class Initialized
INFO - 2023-03-29 03:40:56 --> Helper loaded: url_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: file_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: form_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: my_helper
INFO - 2023-03-29 03:40:56 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:40:56 --> Controller Class Initialized
INFO - 2023-03-29 03:40:56 --> Helper loaded: cookie_helper
INFO - 2023-03-29 03:40:56 --> Final output sent to browser
DEBUG - 2023-03-29 03:40:56 --> Total execution time: 0.0478
INFO - 2023-03-29 03:40:56 --> Config Class Initialized
INFO - 2023-03-29 03:40:56 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:40:56 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:40:56 --> Utf8 Class Initialized
INFO - 2023-03-29 03:40:56 --> URI Class Initialized
INFO - 2023-03-29 03:40:56 --> Router Class Initialized
INFO - 2023-03-29 03:40:56 --> Output Class Initialized
INFO - 2023-03-29 03:40:56 --> Security Class Initialized
DEBUG - 2023-03-29 03:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:40:56 --> Input Class Initialized
INFO - 2023-03-29 03:40:56 --> Language Class Initialized
INFO - 2023-03-29 03:40:56 --> Language Class Initialized
INFO - 2023-03-29 03:40:56 --> Config Class Initialized
INFO - 2023-03-29 03:40:56 --> Loader Class Initialized
INFO - 2023-03-29 03:40:56 --> Helper loaded: url_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: file_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: form_helper
INFO - 2023-03-29 03:40:56 --> Helper loaded: my_helper
INFO - 2023-03-29 03:40:56 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:40:56 --> Controller Class Initialized
DEBUG - 2023-03-29 03:40:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 03:40:56 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 03:40:56 --> Final output sent to browser
DEBUG - 2023-03-29 03:40:56 --> Total execution time: 0.0431
INFO - 2023-03-29 03:41:01 --> Config Class Initialized
INFO - 2023-03-29 03:41:01 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:41:01 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:41:01 --> Utf8 Class Initialized
INFO - 2023-03-29 03:41:01 --> URI Class Initialized
INFO - 2023-03-29 03:41:01 --> Router Class Initialized
INFO - 2023-03-29 03:41:01 --> Output Class Initialized
INFO - 2023-03-29 03:41:01 --> Security Class Initialized
DEBUG - 2023-03-29 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:41:01 --> Input Class Initialized
INFO - 2023-03-29 03:41:01 --> Language Class Initialized
INFO - 2023-03-29 03:41:01 --> Language Class Initialized
INFO - 2023-03-29 03:41:01 --> Config Class Initialized
INFO - 2023-03-29 03:41:01 --> Loader Class Initialized
INFO - 2023-03-29 03:41:01 --> Helper loaded: url_helper
INFO - 2023-03-29 03:41:01 --> Helper loaded: file_helper
INFO - 2023-03-29 03:41:01 --> Helper loaded: form_helper
INFO - 2023-03-29 03:41:01 --> Helper loaded: my_helper
INFO - 2023-03-29 03:41:01 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:41:01 --> Controller Class Initialized
DEBUG - 2023-03-29 03:41:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-29 03:41:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 03:41:01 --> Final output sent to browser
DEBUG - 2023-03-29 03:41:01 --> Total execution time: 0.0629
INFO - 2023-03-29 03:41:02 --> Config Class Initialized
INFO - 2023-03-29 03:41:02 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:41:02 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:41:02 --> Utf8 Class Initialized
INFO - 2023-03-29 03:41:02 --> URI Class Initialized
INFO - 2023-03-29 03:41:02 --> Router Class Initialized
INFO - 2023-03-29 03:41:02 --> Output Class Initialized
INFO - 2023-03-29 03:41:02 --> Security Class Initialized
DEBUG - 2023-03-29 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:41:02 --> Input Class Initialized
INFO - 2023-03-29 03:41:02 --> Language Class Initialized
INFO - 2023-03-29 03:41:02 --> Language Class Initialized
INFO - 2023-03-29 03:41:02 --> Config Class Initialized
INFO - 2023-03-29 03:41:02 --> Loader Class Initialized
INFO - 2023-03-29 03:41:02 --> Helper loaded: url_helper
INFO - 2023-03-29 03:41:02 --> Helper loaded: file_helper
INFO - 2023-03-29 03:41:02 --> Helper loaded: form_helper
INFO - 2023-03-29 03:41:02 --> Helper loaded: my_helper
INFO - 2023-03-29 03:41:02 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:41:02 --> Controller Class Initialized
DEBUG - 2023-03-29 03:41:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-29 03:41:04 --> Config Class Initialized
INFO - 2023-03-29 03:41:04 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:41:04 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:41:04 --> Utf8 Class Initialized
INFO - 2023-03-29 03:41:04 --> URI Class Initialized
INFO - 2023-03-29 03:41:04 --> Router Class Initialized
INFO - 2023-03-29 03:41:04 --> Output Class Initialized
INFO - 2023-03-29 03:41:04 --> Security Class Initialized
DEBUG - 2023-03-29 03:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:41:04 --> Input Class Initialized
INFO - 2023-03-29 03:41:04 --> Language Class Initialized
INFO - 2023-03-29 03:41:04 --> Language Class Initialized
INFO - 2023-03-29 03:41:04 --> Config Class Initialized
INFO - 2023-03-29 03:41:04 --> Loader Class Initialized
INFO - 2023-03-29 03:41:04 --> Helper loaded: url_helper
INFO - 2023-03-29 03:41:04 --> Helper loaded: file_helper
INFO - 2023-03-29 03:41:04 --> Helper loaded: form_helper
INFO - 2023-03-29 03:41:04 --> Helper loaded: my_helper
INFO - 2023-03-29 03:41:04 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:41:04 --> Final output sent to browser
DEBUG - 2023-03-29 03:41:04 --> Total execution time: 2.1323
INFO - 2023-03-29 03:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:41:04 --> Controller Class Initialized
DEBUG - 2023-03-29 03:41:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-29 03:41:06 --> Final output sent to browser
DEBUG - 2023-03-29 03:41:06 --> Total execution time: 1.5010
INFO - 2023-03-29 03:43:46 --> Config Class Initialized
INFO - 2023-03-29 03:43:46 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:43:46 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:43:46 --> Utf8 Class Initialized
INFO - 2023-03-29 03:43:46 --> URI Class Initialized
INFO - 2023-03-29 03:43:46 --> Router Class Initialized
INFO - 2023-03-29 03:43:46 --> Output Class Initialized
INFO - 2023-03-29 03:43:46 --> Security Class Initialized
DEBUG - 2023-03-29 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:43:46 --> Input Class Initialized
INFO - 2023-03-29 03:43:46 --> Language Class Initialized
INFO - 2023-03-29 03:43:46 --> Language Class Initialized
INFO - 2023-03-29 03:43:46 --> Config Class Initialized
INFO - 2023-03-29 03:43:46 --> Loader Class Initialized
INFO - 2023-03-29 03:43:46 --> Helper loaded: url_helper
INFO - 2023-03-29 03:43:46 --> Helper loaded: file_helper
INFO - 2023-03-29 03:43:46 --> Helper loaded: form_helper
INFO - 2023-03-29 03:43:46 --> Helper loaded: my_helper
INFO - 2023-03-29 03:43:46 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:43:46 --> Controller Class Initialized
DEBUG - 2023-03-29 03:43:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-29 03:43:47 --> Final output sent to browser
DEBUG - 2023-03-29 03:43:47 --> Total execution time: 1.0739
INFO - 2023-03-29 03:44:23 --> Config Class Initialized
INFO - 2023-03-29 03:44:23 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:44:23 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:44:23 --> Utf8 Class Initialized
INFO - 2023-03-29 03:44:23 --> URI Class Initialized
INFO - 2023-03-29 03:44:23 --> Router Class Initialized
INFO - 2023-03-29 03:44:23 --> Output Class Initialized
INFO - 2023-03-29 03:44:23 --> Security Class Initialized
DEBUG - 2023-03-29 03:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:44:23 --> Input Class Initialized
INFO - 2023-03-29 03:44:23 --> Language Class Initialized
INFO - 2023-03-29 03:44:23 --> Language Class Initialized
INFO - 2023-03-29 03:44:23 --> Config Class Initialized
INFO - 2023-03-29 03:44:23 --> Loader Class Initialized
INFO - 2023-03-29 03:44:23 --> Helper loaded: url_helper
INFO - 2023-03-29 03:44:23 --> Helper loaded: file_helper
INFO - 2023-03-29 03:44:23 --> Helper loaded: form_helper
INFO - 2023-03-29 03:44:23 --> Helper loaded: my_helper
INFO - 2023-03-29 03:44:23 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:44:23 --> Controller Class Initialized
DEBUG - 2023-03-29 03:44:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-29 03:44:24 --> Final output sent to browser
DEBUG - 2023-03-29 03:44:24 --> Total execution time: 1.0621
INFO - 2023-03-29 03:47:07 --> Config Class Initialized
INFO - 2023-03-29 03:47:07 --> Hooks Class Initialized
DEBUG - 2023-03-29 03:47:07 --> UTF-8 Support Enabled
INFO - 2023-03-29 03:47:07 --> Utf8 Class Initialized
INFO - 2023-03-29 03:47:07 --> URI Class Initialized
INFO - 2023-03-29 03:47:07 --> Router Class Initialized
INFO - 2023-03-29 03:47:07 --> Output Class Initialized
INFO - 2023-03-29 03:47:07 --> Security Class Initialized
DEBUG - 2023-03-29 03:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 03:47:07 --> Input Class Initialized
INFO - 2023-03-29 03:47:07 --> Language Class Initialized
INFO - 2023-03-29 03:47:07 --> Language Class Initialized
INFO - 2023-03-29 03:47:07 --> Config Class Initialized
INFO - 2023-03-29 03:47:07 --> Loader Class Initialized
INFO - 2023-03-29 03:47:07 --> Helper loaded: url_helper
INFO - 2023-03-29 03:47:07 --> Helper loaded: file_helper
INFO - 2023-03-29 03:47:07 --> Helper loaded: form_helper
INFO - 2023-03-29 03:47:07 --> Helper loaded: my_helper
INFO - 2023-03-29 03:47:07 --> Database Driver Class Initialized
DEBUG - 2023-03-29 03:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 03:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 03:47:07 --> Controller Class Initialized
DEBUG - 2023-03-29 03:47:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-29 03:47:08 --> Final output sent to browser
DEBUG - 2023-03-29 03:47:08 --> Total execution time: 1.0548
INFO - 2023-03-29 05:45:58 --> Config Class Initialized
INFO - 2023-03-29 05:45:58 --> Hooks Class Initialized
DEBUG - 2023-03-29 05:45:58 --> UTF-8 Support Enabled
INFO - 2023-03-29 05:45:58 --> Utf8 Class Initialized
INFO - 2023-03-29 05:45:58 --> URI Class Initialized
INFO - 2023-03-29 05:45:58 --> Router Class Initialized
INFO - 2023-03-29 05:45:58 --> Output Class Initialized
INFO - 2023-03-29 05:45:58 --> Security Class Initialized
DEBUG - 2023-03-29 05:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 05:45:58 --> Input Class Initialized
INFO - 2023-03-29 05:45:58 --> Language Class Initialized
INFO - 2023-03-29 05:45:58 --> Language Class Initialized
INFO - 2023-03-29 05:45:58 --> Config Class Initialized
INFO - 2023-03-29 05:45:58 --> Loader Class Initialized
INFO - 2023-03-29 05:45:58 --> Helper loaded: url_helper
INFO - 2023-03-29 05:45:58 --> Helper loaded: file_helper
INFO - 2023-03-29 05:45:58 --> Helper loaded: form_helper
INFO - 2023-03-29 05:45:58 --> Helper loaded: my_helper
INFO - 2023-03-29 05:45:58 --> Database Driver Class Initialized
DEBUG - 2023-03-29 05:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 05:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 05:45:58 --> Controller Class Initialized
DEBUG - 2023-03-29 05:45:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-29 05:45:58 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 05:45:58 --> Final output sent to browser
DEBUG - 2023-03-29 05:45:58 --> Total execution time: 0.0562
INFO - 2023-03-29 07:06:36 --> Config Class Initialized
INFO - 2023-03-29 07:06:36 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:06:36 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:06:36 --> Utf8 Class Initialized
INFO - 2023-03-29 07:06:36 --> URI Class Initialized
INFO - 2023-03-29 07:06:36 --> Router Class Initialized
INFO - 2023-03-29 07:06:36 --> Output Class Initialized
INFO - 2023-03-29 07:06:36 --> Security Class Initialized
DEBUG - 2023-03-29 07:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:06:36 --> Input Class Initialized
INFO - 2023-03-29 07:06:36 --> Language Class Initialized
INFO - 2023-03-29 07:06:36 --> Language Class Initialized
INFO - 2023-03-29 07:06:36 --> Config Class Initialized
INFO - 2023-03-29 07:06:36 --> Loader Class Initialized
INFO - 2023-03-29 07:06:36 --> Helper loaded: url_helper
INFO - 2023-03-29 07:06:36 --> Helper loaded: file_helper
INFO - 2023-03-29 07:06:36 --> Helper loaded: form_helper
INFO - 2023-03-29 07:06:36 --> Helper loaded: my_helper
INFO - 2023-03-29 07:06:36 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:06:36 --> Controller Class Initialized
DEBUG - 2023-03-29 07:06:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-29 07:06:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:06:36 --> Final output sent to browser
DEBUG - 2023-03-29 07:06:36 --> Total execution time: 0.0814
INFO - 2023-03-29 07:06:50 --> Config Class Initialized
INFO - 2023-03-29 07:06:50 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:06:50 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:06:50 --> Utf8 Class Initialized
INFO - 2023-03-29 07:06:50 --> URI Class Initialized
DEBUG - 2023-03-29 07:06:50 --> No URI present. Default controller set.
INFO - 2023-03-29 07:06:50 --> Router Class Initialized
INFO - 2023-03-29 07:06:50 --> Output Class Initialized
INFO - 2023-03-29 07:06:50 --> Security Class Initialized
DEBUG - 2023-03-29 07:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:06:50 --> Input Class Initialized
INFO - 2023-03-29 07:06:50 --> Language Class Initialized
INFO - 2023-03-29 07:06:50 --> Language Class Initialized
INFO - 2023-03-29 07:06:50 --> Config Class Initialized
INFO - 2023-03-29 07:06:50 --> Loader Class Initialized
INFO - 2023-03-29 07:06:50 --> Helper loaded: url_helper
INFO - 2023-03-29 07:06:50 --> Helper loaded: file_helper
INFO - 2023-03-29 07:06:50 --> Helper loaded: form_helper
INFO - 2023-03-29 07:06:50 --> Helper loaded: my_helper
INFO - 2023-03-29 07:06:50 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:06:50 --> Controller Class Initialized
DEBUG - 2023-03-29 07:06:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 07:06:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:06:50 --> Final output sent to browser
DEBUG - 2023-03-29 07:06:50 --> Total execution time: 0.0500
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:14 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:14 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:14 --> URI Class Initialized
INFO - 2023-03-29 07:07:14 --> Router Class Initialized
INFO - 2023-03-29 07:07:14 --> Output Class Initialized
INFO - 2023-03-29 07:07:14 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:14 --> Input Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Loader Class Initialized
INFO - 2023-03-29 07:07:14 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:14 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:14 --> Controller Class Initialized
INFO - 2023-03-29 07:07:14 --> Helper loaded: cookie_helper
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:14 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:14 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:14 --> URI Class Initialized
INFO - 2023-03-29 07:07:14 --> Router Class Initialized
INFO - 2023-03-29 07:07:14 --> Output Class Initialized
INFO - 2023-03-29 07:07:14 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:14 --> Input Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Loader Class Initialized
INFO - 2023-03-29 07:07:14 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:14 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:14 --> Controller Class Initialized
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:14 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:14 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:14 --> URI Class Initialized
INFO - 2023-03-29 07:07:14 --> Router Class Initialized
INFO - 2023-03-29 07:07:14 --> Output Class Initialized
INFO - 2023-03-29 07:07:14 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:14 --> Input Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Language Class Initialized
INFO - 2023-03-29 07:07:14 --> Config Class Initialized
INFO - 2023-03-29 07:07:14 --> Loader Class Initialized
INFO - 2023-03-29 07:07:14 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:14 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:14 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:14 --> Controller Class Initialized
DEBUG - 2023-03-29 07:07:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-29 07:07:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:07:14 --> Final output sent to browser
DEBUG - 2023-03-29 07:07:14 --> Total execution time: 0.0551
INFO - 2023-03-29 07:07:23 --> Config Class Initialized
INFO - 2023-03-29 07:07:23 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:23 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:23 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:23 --> URI Class Initialized
INFO - 2023-03-29 07:07:23 --> Router Class Initialized
INFO - 2023-03-29 07:07:23 --> Output Class Initialized
INFO - 2023-03-29 07:07:23 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:23 --> Input Class Initialized
INFO - 2023-03-29 07:07:23 --> Language Class Initialized
INFO - 2023-03-29 07:07:23 --> Language Class Initialized
INFO - 2023-03-29 07:07:23 --> Config Class Initialized
INFO - 2023-03-29 07:07:23 --> Loader Class Initialized
INFO - 2023-03-29 07:07:23 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:23 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:23 --> Controller Class Initialized
INFO - 2023-03-29 07:07:23 --> Helper loaded: cookie_helper
INFO - 2023-03-29 07:07:23 --> Final output sent to browser
DEBUG - 2023-03-29 07:07:23 --> Total execution time: 0.0717
INFO - 2023-03-29 07:07:23 --> Config Class Initialized
INFO - 2023-03-29 07:07:23 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:23 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:23 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:23 --> URI Class Initialized
INFO - 2023-03-29 07:07:23 --> Router Class Initialized
INFO - 2023-03-29 07:07:23 --> Output Class Initialized
INFO - 2023-03-29 07:07:23 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:23 --> Input Class Initialized
INFO - 2023-03-29 07:07:23 --> Language Class Initialized
INFO - 2023-03-29 07:07:23 --> Language Class Initialized
INFO - 2023-03-29 07:07:23 --> Config Class Initialized
INFO - 2023-03-29 07:07:23 --> Loader Class Initialized
INFO - 2023-03-29 07:07:23 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:23 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:23 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:23 --> Controller Class Initialized
DEBUG - 2023-03-29 07:07:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 07:07:23 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:07:23 --> Final output sent to browser
DEBUG - 2023-03-29 07:07:23 --> Total execution time: 0.0503
INFO - 2023-03-29 07:07:39 --> Config Class Initialized
INFO - 2023-03-29 07:07:39 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:07:39 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:07:39 --> Utf8 Class Initialized
INFO - 2023-03-29 07:07:39 --> URI Class Initialized
INFO - 2023-03-29 07:07:39 --> Router Class Initialized
INFO - 2023-03-29 07:07:39 --> Output Class Initialized
INFO - 2023-03-29 07:07:39 --> Security Class Initialized
DEBUG - 2023-03-29 07:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:07:39 --> Input Class Initialized
INFO - 2023-03-29 07:07:39 --> Language Class Initialized
INFO - 2023-03-29 07:07:39 --> Language Class Initialized
INFO - 2023-03-29 07:07:39 --> Config Class Initialized
INFO - 2023-03-29 07:07:39 --> Loader Class Initialized
INFO - 2023-03-29 07:07:39 --> Helper loaded: url_helper
INFO - 2023-03-29 07:07:39 --> Helper loaded: file_helper
INFO - 2023-03-29 07:07:39 --> Helper loaded: form_helper
INFO - 2023-03-29 07:07:39 --> Helper loaded: my_helper
INFO - 2023-03-29 07:07:39 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:07:39 --> Controller Class Initialized
DEBUG - 2023-03-29 07:07:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-29 07:07:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:07:39 --> Final output sent to browser
DEBUG - 2023-03-29 07:07:39 --> Total execution time: 0.1084
INFO - 2023-03-29 07:09:21 --> Config Class Initialized
INFO - 2023-03-29 07:09:21 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:09:21 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:09:21 --> Utf8 Class Initialized
INFO - 2023-03-29 07:09:21 --> URI Class Initialized
INFO - 2023-03-29 07:09:21 --> Router Class Initialized
INFO - 2023-03-29 07:09:21 --> Output Class Initialized
INFO - 2023-03-29 07:09:21 --> Security Class Initialized
DEBUG - 2023-03-29 07:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:09:21 --> Input Class Initialized
INFO - 2023-03-29 07:09:21 --> Language Class Initialized
INFO - 2023-03-29 07:09:21 --> Language Class Initialized
INFO - 2023-03-29 07:09:21 --> Config Class Initialized
INFO - 2023-03-29 07:09:21 --> Loader Class Initialized
INFO - 2023-03-29 07:09:21 --> Helper loaded: url_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: file_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: form_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: my_helper
INFO - 2023-03-29 07:09:21 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:09:21 --> Controller Class Initialized
DEBUG - 2023-03-29 07:09:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-03-29 07:09:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:09:21 --> Final output sent to browser
DEBUG - 2023-03-29 07:09:21 --> Total execution time: 0.1196
INFO - 2023-03-29 07:09:21 --> Config Class Initialized
INFO - 2023-03-29 07:09:21 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:09:21 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:09:21 --> Utf8 Class Initialized
INFO - 2023-03-29 07:09:21 --> URI Class Initialized
INFO - 2023-03-29 07:09:21 --> Router Class Initialized
INFO - 2023-03-29 07:09:21 --> Output Class Initialized
INFO - 2023-03-29 07:09:21 --> Security Class Initialized
DEBUG - 2023-03-29 07:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:09:21 --> Input Class Initialized
INFO - 2023-03-29 07:09:21 --> Language Class Initialized
INFO - 2023-03-29 07:09:21 --> Language Class Initialized
INFO - 2023-03-29 07:09:21 --> Config Class Initialized
INFO - 2023-03-29 07:09:21 --> Loader Class Initialized
INFO - 2023-03-29 07:09:21 --> Helper loaded: url_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: file_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: form_helper
INFO - 2023-03-29 07:09:21 --> Helper loaded: my_helper
INFO - 2023-03-29 07:09:21 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:09:21 --> Controller Class Initialized
INFO - 2023-03-29 07:09:36 --> Config Class Initialized
INFO - 2023-03-29 07:09:36 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:09:36 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:09:36 --> Utf8 Class Initialized
INFO - 2023-03-29 07:09:36 --> URI Class Initialized
INFO - 2023-03-29 07:09:36 --> Router Class Initialized
INFO - 2023-03-29 07:09:36 --> Output Class Initialized
INFO - 2023-03-29 07:09:36 --> Security Class Initialized
DEBUG - 2023-03-29 07:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:09:36 --> Input Class Initialized
INFO - 2023-03-29 07:09:36 --> Language Class Initialized
INFO - 2023-03-29 07:09:36 --> Language Class Initialized
INFO - 2023-03-29 07:09:36 --> Config Class Initialized
INFO - 2023-03-29 07:09:36 --> Loader Class Initialized
INFO - 2023-03-29 07:09:36 --> Helper loaded: url_helper
INFO - 2023-03-29 07:09:36 --> Helper loaded: file_helper
INFO - 2023-03-29 07:09:36 --> Helper loaded: form_helper
INFO - 2023-03-29 07:09:36 --> Helper loaded: my_helper
INFO - 2023-03-29 07:09:36 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:09:36 --> Controller Class Initialized
INFO - 2023-03-29 07:09:36 --> Final output sent to browser
DEBUG - 2023-03-29 07:09:36 --> Total execution time: 0.0613
INFO - 2023-03-29 07:09:55 --> Config Class Initialized
INFO - 2023-03-29 07:09:55 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:09:55 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:09:55 --> Utf8 Class Initialized
INFO - 2023-03-29 07:09:55 --> URI Class Initialized
INFO - 2023-03-29 07:09:55 --> Router Class Initialized
INFO - 2023-03-29 07:09:55 --> Output Class Initialized
INFO - 2023-03-29 07:09:55 --> Security Class Initialized
DEBUG - 2023-03-29 07:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:09:55 --> Input Class Initialized
INFO - 2023-03-29 07:09:55 --> Language Class Initialized
INFO - 2023-03-29 07:09:55 --> Language Class Initialized
INFO - 2023-03-29 07:09:55 --> Config Class Initialized
INFO - 2023-03-29 07:09:55 --> Loader Class Initialized
INFO - 2023-03-29 07:09:55 --> Helper loaded: url_helper
INFO - 2023-03-29 07:09:55 --> Helper loaded: file_helper
INFO - 2023-03-29 07:09:55 --> Helper loaded: form_helper
INFO - 2023-03-29 07:09:55 --> Helper loaded: my_helper
INFO - 2023-03-29 07:09:55 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:09:55 --> Controller Class Initialized
INFO - 2023-03-29 07:12:07 --> Config Class Initialized
INFO - 2023-03-29 07:12:07 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:07 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:07 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:07 --> URI Class Initialized
INFO - 2023-03-29 07:12:07 --> Router Class Initialized
INFO - 2023-03-29 07:12:07 --> Output Class Initialized
INFO - 2023-03-29 07:12:07 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:07 --> Input Class Initialized
INFO - 2023-03-29 07:12:07 --> Language Class Initialized
INFO - 2023-03-29 07:12:07 --> Language Class Initialized
INFO - 2023-03-29 07:12:07 --> Config Class Initialized
INFO - 2023-03-29 07:12:07 --> Loader Class Initialized
INFO - 2023-03-29 07:12:07 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:07 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:07 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:07 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:08 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:08 --> Controller Class Initialized
INFO - 2023-03-29 07:12:08 --> Helper loaded: cookie_helper
INFO - 2023-03-29 07:12:08 --> Config Class Initialized
INFO - 2023-03-29 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:08 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:08 --> URI Class Initialized
INFO - 2023-03-29 07:12:08 --> Router Class Initialized
INFO - 2023-03-29 07:12:08 --> Output Class Initialized
INFO - 2023-03-29 07:12:08 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:08 --> Input Class Initialized
INFO - 2023-03-29 07:12:08 --> Language Class Initialized
INFO - 2023-03-29 07:12:08 --> Language Class Initialized
INFO - 2023-03-29 07:12:08 --> Config Class Initialized
INFO - 2023-03-29 07:12:08 --> Loader Class Initialized
INFO - 2023-03-29 07:12:08 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:08 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:08 --> Controller Class Initialized
INFO - 2023-03-29 07:12:08 --> Config Class Initialized
INFO - 2023-03-29 07:12:08 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:08 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:08 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:08 --> URI Class Initialized
INFO - 2023-03-29 07:12:08 --> Router Class Initialized
INFO - 2023-03-29 07:12:08 --> Output Class Initialized
INFO - 2023-03-29 07:12:08 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:08 --> Input Class Initialized
INFO - 2023-03-29 07:12:08 --> Language Class Initialized
INFO - 2023-03-29 07:12:08 --> Language Class Initialized
INFO - 2023-03-29 07:12:08 --> Config Class Initialized
INFO - 2023-03-29 07:12:08 --> Loader Class Initialized
INFO - 2023-03-29 07:12:08 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:08 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:08 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:08 --> Controller Class Initialized
DEBUG - 2023-03-29 07:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-03-29 07:12:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:12:08 --> Final output sent to browser
DEBUG - 2023-03-29 07:12:08 --> Total execution time: 0.0543
INFO - 2023-03-29 07:12:15 --> Config Class Initialized
INFO - 2023-03-29 07:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:15 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:15 --> URI Class Initialized
INFO - 2023-03-29 07:12:15 --> Router Class Initialized
INFO - 2023-03-29 07:12:15 --> Output Class Initialized
INFO - 2023-03-29 07:12:15 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:15 --> Input Class Initialized
INFO - 2023-03-29 07:12:15 --> Language Class Initialized
INFO - 2023-03-29 07:12:15 --> Language Class Initialized
INFO - 2023-03-29 07:12:15 --> Config Class Initialized
INFO - 2023-03-29 07:12:15 --> Loader Class Initialized
INFO - 2023-03-29 07:12:15 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:15 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:15 --> Controller Class Initialized
INFO - 2023-03-29 07:12:15 --> Helper loaded: cookie_helper
INFO - 2023-03-29 07:12:15 --> Final output sent to browser
DEBUG - 2023-03-29 07:12:15 --> Total execution time: 0.0440
INFO - 2023-03-29 07:12:15 --> Config Class Initialized
INFO - 2023-03-29 07:12:15 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:15 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:15 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:15 --> URI Class Initialized
INFO - 2023-03-29 07:12:15 --> Router Class Initialized
INFO - 2023-03-29 07:12:15 --> Output Class Initialized
INFO - 2023-03-29 07:12:15 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:15 --> Input Class Initialized
INFO - 2023-03-29 07:12:15 --> Language Class Initialized
INFO - 2023-03-29 07:12:15 --> Language Class Initialized
INFO - 2023-03-29 07:12:15 --> Config Class Initialized
INFO - 2023-03-29 07:12:15 --> Loader Class Initialized
INFO - 2023-03-29 07:12:15 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:15 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:15 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:15 --> Controller Class Initialized
DEBUG - 2023-03-29 07:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 07:12:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:12:15 --> Final output sent to browser
DEBUG - 2023-03-29 07:12:15 --> Total execution time: 0.0663
INFO - 2023-03-29 07:12:50 --> Config Class Initialized
INFO - 2023-03-29 07:12:50 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:12:50 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:12:50 --> Utf8 Class Initialized
INFO - 2023-03-29 07:12:50 --> URI Class Initialized
INFO - 2023-03-29 07:12:50 --> Router Class Initialized
INFO - 2023-03-29 07:12:50 --> Output Class Initialized
INFO - 2023-03-29 07:12:50 --> Security Class Initialized
DEBUG - 2023-03-29 07:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:12:50 --> Input Class Initialized
INFO - 2023-03-29 07:12:50 --> Language Class Initialized
INFO - 2023-03-29 07:12:50 --> Language Class Initialized
INFO - 2023-03-29 07:12:50 --> Config Class Initialized
INFO - 2023-03-29 07:12:50 --> Loader Class Initialized
INFO - 2023-03-29 07:12:50 --> Helper loaded: url_helper
INFO - 2023-03-29 07:12:50 --> Helper loaded: file_helper
INFO - 2023-03-29 07:12:50 --> Helper loaded: form_helper
INFO - 2023-03-29 07:12:50 --> Helper loaded: my_helper
INFO - 2023-03-29 07:12:50 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:12:50 --> Controller Class Initialized
DEBUG - 2023-03-29 07:12:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/list.php
DEBUG - 2023-03-29 07:12:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:12:50 --> Final output sent to browser
DEBUG - 2023-03-29 07:12:50 --> Total execution time: 0.0751
INFO - 2023-03-29 07:13:03 --> Config Class Initialized
INFO - 2023-03-29 07:13:03 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:13:03 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:13:03 --> Utf8 Class Initialized
INFO - 2023-03-29 07:13:03 --> URI Class Initialized
INFO - 2023-03-29 07:13:03 --> Router Class Initialized
INFO - 2023-03-29 07:13:03 --> Output Class Initialized
INFO - 2023-03-29 07:13:03 --> Security Class Initialized
DEBUG - 2023-03-29 07:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:13:03 --> Input Class Initialized
INFO - 2023-03-29 07:13:03 --> Language Class Initialized
INFO - 2023-03-29 07:13:03 --> Language Class Initialized
INFO - 2023-03-29 07:13:03 --> Config Class Initialized
INFO - 2023-03-29 07:13:03 --> Loader Class Initialized
INFO - 2023-03-29 07:13:03 --> Helper loaded: url_helper
INFO - 2023-03-29 07:13:03 --> Helper loaded: file_helper
INFO - 2023-03-29 07:13:03 --> Helper loaded: form_helper
INFO - 2023-03-29 07:13:03 --> Helper loaded: my_helper
INFO - 2023-03-29 07:13:03 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:13:03 --> Controller Class Initialized
DEBUG - 2023-03-29 07:13:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-03-29 07:13:04 --> Final output sent to browser
DEBUG - 2023-03-29 07:13:04 --> Total execution time: 1.7492
INFO - 2023-03-29 07:14:25 --> Config Class Initialized
INFO - 2023-03-29 07:14:25 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:14:25 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:14:25 --> Utf8 Class Initialized
INFO - 2023-03-29 07:14:25 --> URI Class Initialized
INFO - 2023-03-29 07:14:25 --> Router Class Initialized
INFO - 2023-03-29 07:14:25 --> Output Class Initialized
INFO - 2023-03-29 07:14:25 --> Security Class Initialized
DEBUG - 2023-03-29 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:14:25 --> Input Class Initialized
INFO - 2023-03-29 07:14:25 --> Language Class Initialized
INFO - 2023-03-29 07:14:25 --> Language Class Initialized
INFO - 2023-03-29 07:14:25 --> Config Class Initialized
INFO - 2023-03-29 07:14:25 --> Loader Class Initialized
INFO - 2023-03-29 07:14:25 --> Helper loaded: url_helper
INFO - 2023-03-29 07:14:25 --> Helper loaded: file_helper
INFO - 2023-03-29 07:14:25 --> Helper loaded: form_helper
INFO - 2023-03-29 07:14:25 --> Helper loaded: my_helper
INFO - 2023-03-29 07:14:25 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:14:25 --> Controller Class Initialized
DEBUG - 2023-03-29 07:14:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-29 07:14:25 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:14:25 --> Final output sent to browser
DEBUG - 2023-03-29 07:14:25 --> Total execution time: 0.0569
INFO - 2023-03-29 07:14:27 --> Config Class Initialized
INFO - 2023-03-29 07:14:27 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:14:27 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:14:27 --> Utf8 Class Initialized
INFO - 2023-03-29 07:14:27 --> URI Class Initialized
INFO - 2023-03-29 07:14:27 --> Router Class Initialized
INFO - 2023-03-29 07:14:27 --> Output Class Initialized
INFO - 2023-03-29 07:14:27 --> Security Class Initialized
DEBUG - 2023-03-29 07:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:14:27 --> Input Class Initialized
INFO - 2023-03-29 07:14:27 --> Language Class Initialized
INFO - 2023-03-29 07:14:27 --> Language Class Initialized
INFO - 2023-03-29 07:14:27 --> Config Class Initialized
INFO - 2023-03-29 07:14:27 --> Loader Class Initialized
INFO - 2023-03-29 07:14:27 --> Helper loaded: url_helper
INFO - 2023-03-29 07:14:27 --> Helper loaded: file_helper
INFO - 2023-03-29 07:14:27 --> Helper loaded: form_helper
INFO - 2023-03-29 07:14:27 --> Helper loaded: my_helper
INFO - 2023-03-29 07:14:27 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:14:27 --> Controller Class Initialized
DEBUG - 2023-03-29 07:14:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2023-03-29 07:14:28 --> Final output sent to browser
DEBUG - 2023-03-29 07:14:28 --> Total execution time: 1.4013
INFO - 2023-03-29 07:15:28 --> Config Class Initialized
INFO - 2023-03-29 07:15:28 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:15:28 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:15:28 --> Utf8 Class Initialized
INFO - 2023-03-29 07:15:28 --> URI Class Initialized
INFO - 2023-03-29 07:15:28 --> Router Class Initialized
INFO - 2023-03-29 07:15:28 --> Output Class Initialized
INFO - 2023-03-29 07:15:28 --> Security Class Initialized
DEBUG - 2023-03-29 07:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:15:28 --> Input Class Initialized
INFO - 2023-03-29 07:15:28 --> Language Class Initialized
INFO - 2023-03-29 07:15:28 --> Language Class Initialized
INFO - 2023-03-29 07:15:28 --> Config Class Initialized
INFO - 2023-03-29 07:15:28 --> Loader Class Initialized
INFO - 2023-03-29 07:15:28 --> Helper loaded: url_helper
INFO - 2023-03-29 07:15:28 --> Helper loaded: file_helper
INFO - 2023-03-29 07:15:28 --> Helper loaded: form_helper
INFO - 2023-03-29 07:15:28 --> Helper loaded: my_helper
INFO - 2023-03-29 07:15:28 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:15:28 --> Controller Class Initialized
DEBUG - 2023-03-29 07:15:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-03-29 07:15:29 --> Final output sent to browser
DEBUG - 2023-03-29 07:15:29 --> Total execution time: 1.5299
INFO - 2023-03-29 07:15:55 --> Config Class Initialized
INFO - 2023-03-29 07:15:55 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:15:55 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:15:55 --> Utf8 Class Initialized
INFO - 2023-03-29 07:15:55 --> URI Class Initialized
DEBUG - 2023-03-29 07:15:55 --> No URI present. Default controller set.
INFO - 2023-03-29 07:15:55 --> Router Class Initialized
INFO - 2023-03-29 07:15:55 --> Output Class Initialized
INFO - 2023-03-29 07:15:55 --> Security Class Initialized
DEBUG - 2023-03-29 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:15:55 --> Input Class Initialized
INFO - 2023-03-29 07:15:55 --> Language Class Initialized
INFO - 2023-03-29 07:15:55 --> Language Class Initialized
INFO - 2023-03-29 07:15:55 --> Config Class Initialized
INFO - 2023-03-29 07:15:55 --> Loader Class Initialized
INFO - 2023-03-29 07:15:55 --> Helper loaded: url_helper
INFO - 2023-03-29 07:15:55 --> Helper loaded: file_helper
INFO - 2023-03-29 07:15:55 --> Helper loaded: form_helper
INFO - 2023-03-29 07:15:55 --> Helper loaded: my_helper
INFO - 2023-03-29 07:15:55 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:15:55 --> Controller Class Initialized
DEBUG - 2023-03-29 07:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 07:15:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:15:55 --> Final output sent to browser
DEBUG - 2023-03-29 07:15:55 --> Total execution time: 0.0469
INFO - 2023-03-29 07:15:59 --> Config Class Initialized
INFO - 2023-03-29 07:15:59 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:15:59 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:15:59 --> Utf8 Class Initialized
INFO - 2023-03-29 07:15:59 --> URI Class Initialized
INFO - 2023-03-29 07:15:59 --> Router Class Initialized
INFO - 2023-03-29 07:15:59 --> Output Class Initialized
INFO - 2023-03-29 07:15:59 --> Security Class Initialized
DEBUG - 2023-03-29 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:15:59 --> Input Class Initialized
INFO - 2023-03-29 07:15:59 --> Language Class Initialized
INFO - 2023-03-29 07:15:59 --> Language Class Initialized
INFO - 2023-03-29 07:15:59 --> Config Class Initialized
INFO - 2023-03-29 07:15:59 --> Loader Class Initialized
INFO - 2023-03-29 07:15:59 --> Helper loaded: url_helper
INFO - 2023-03-29 07:15:59 --> Helper loaded: file_helper
INFO - 2023-03-29 07:15:59 --> Helper loaded: form_helper
INFO - 2023-03-29 07:15:59 --> Helper loaded: my_helper
INFO - 2023-03-29 07:15:59 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:15:59 --> Controller Class Initialized
DEBUG - 2023-03-29 07:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-03-29 07:15:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:15:59 --> Final output sent to browser
DEBUG - 2023-03-29 07:15:59 --> Total execution time: 0.0584
INFO - 2023-03-29 07:16:07 --> Config Class Initialized
INFO - 2023-03-29 07:16:07 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:16:07 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:16:07 --> Utf8 Class Initialized
INFO - 2023-03-29 07:16:07 --> URI Class Initialized
INFO - 2023-03-29 07:16:07 --> Router Class Initialized
INFO - 2023-03-29 07:16:07 --> Output Class Initialized
INFO - 2023-03-29 07:16:07 --> Security Class Initialized
DEBUG - 2023-03-29 07:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:16:07 --> Input Class Initialized
INFO - 2023-03-29 07:16:07 --> Language Class Initialized
INFO - 2023-03-29 07:16:07 --> Language Class Initialized
INFO - 2023-03-29 07:16:07 --> Config Class Initialized
INFO - 2023-03-29 07:16:07 --> Loader Class Initialized
INFO - 2023-03-29 07:16:07 --> Helper loaded: url_helper
INFO - 2023-03-29 07:16:07 --> Helper loaded: file_helper
INFO - 2023-03-29 07:16:07 --> Helper loaded: form_helper
INFO - 2023-03-29 07:16:07 --> Helper loaded: my_helper
INFO - 2023-03-29 07:16:07 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:16:07 --> Controller Class Initialized
DEBUG - 2023-03-29 07:16:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-03-29 07:16:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:16:07 --> Final output sent to browser
DEBUG - 2023-03-29 07:16:07 --> Total execution time: 0.0559
INFO - 2023-03-29 07:54:42 --> Config Class Initialized
INFO - 2023-03-29 07:54:42 --> Hooks Class Initialized
DEBUG - 2023-03-29 07:54:42 --> UTF-8 Support Enabled
INFO - 2023-03-29 07:54:42 --> Utf8 Class Initialized
INFO - 2023-03-29 07:54:42 --> URI Class Initialized
DEBUG - 2023-03-29 07:54:42 --> No URI present. Default controller set.
INFO - 2023-03-29 07:54:42 --> Router Class Initialized
INFO - 2023-03-29 07:54:42 --> Output Class Initialized
INFO - 2023-03-29 07:54:42 --> Security Class Initialized
DEBUG - 2023-03-29 07:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-03-29 07:54:42 --> Input Class Initialized
INFO - 2023-03-29 07:54:42 --> Language Class Initialized
INFO - 2023-03-29 07:54:42 --> Language Class Initialized
INFO - 2023-03-29 07:54:42 --> Config Class Initialized
INFO - 2023-03-29 07:54:42 --> Loader Class Initialized
INFO - 2023-03-29 07:54:42 --> Helper loaded: url_helper
INFO - 2023-03-29 07:54:42 --> Helper loaded: file_helper
INFO - 2023-03-29 07:54:42 --> Helper loaded: form_helper
INFO - 2023-03-29 07:54:42 --> Helper loaded: my_helper
INFO - 2023-03-29 07:54:42 --> Database Driver Class Initialized
DEBUG - 2023-03-29 07:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-03-29 07:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-03-29 07:54:42 --> Controller Class Initialized
DEBUG - 2023-03-29 07:54:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-03-29 07:54:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-03-29 07:54:42 --> Final output sent to browser
DEBUG - 2023-03-29 07:54:42 --> Total execution time: 0.0553
