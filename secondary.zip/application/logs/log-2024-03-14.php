<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-14 07:58:39 --> Config Class Initialized
INFO - 2024-03-14 07:58:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 07:58:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 07:58:39 --> Utf8 Class Initialized
INFO - 2024-03-14 07:58:39 --> URI Class Initialized
INFO - 2024-03-14 07:58:39 --> Router Class Initialized
INFO - 2024-03-14 07:58:39 --> Output Class Initialized
INFO - 2024-03-14 07:58:39 --> Security Class Initialized
DEBUG - 2024-03-14 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 07:58:39 --> Input Class Initialized
INFO - 2024-03-14 07:58:39 --> Language Class Initialized
INFO - 2024-03-14 07:58:39 --> Language Class Initialized
INFO - 2024-03-14 07:58:39 --> Config Class Initialized
INFO - 2024-03-14 07:58:39 --> Loader Class Initialized
INFO - 2024-03-14 07:58:39 --> Helper loaded: url_helper
INFO - 2024-03-14 07:58:39 --> Helper loaded: file_helper
INFO - 2024-03-14 07:58:39 --> Helper loaded: form_helper
INFO - 2024-03-14 07:58:39 --> Helper loaded: my_helper
INFO - 2024-03-14 07:58:39 --> Database Driver Class Initialized
INFO - 2024-03-14 07:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 07:58:39 --> Controller Class Initialized
DEBUG - 2024-03-14 07:58:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 07:58:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 07:58:39 --> Final output sent to browser
DEBUG - 2024-03-14 07:58:39 --> Total execution time: 0.0475
INFO - 2024-03-14 07:58:45 --> Config Class Initialized
INFO - 2024-03-14 07:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 07:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 07:58:45 --> Utf8 Class Initialized
INFO - 2024-03-14 07:58:45 --> URI Class Initialized
INFO - 2024-03-14 07:58:45 --> Router Class Initialized
INFO - 2024-03-14 07:58:45 --> Output Class Initialized
INFO - 2024-03-14 07:58:45 --> Security Class Initialized
DEBUG - 2024-03-14 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 07:58:45 --> Input Class Initialized
INFO - 2024-03-14 07:58:45 --> Language Class Initialized
INFO - 2024-03-14 07:58:45 --> Language Class Initialized
INFO - 2024-03-14 07:58:45 --> Config Class Initialized
INFO - 2024-03-14 07:58:45 --> Loader Class Initialized
INFO - 2024-03-14 07:58:45 --> Helper loaded: url_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: file_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: form_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: my_helper
INFO - 2024-03-14 07:58:45 --> Database Driver Class Initialized
INFO - 2024-03-14 07:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 07:58:45 --> Controller Class Initialized
INFO - 2024-03-14 07:58:45 --> Helper loaded: cookie_helper
INFO - 2024-03-14 07:58:45 --> Final output sent to browser
DEBUG - 2024-03-14 07:58:45 --> Total execution time: 0.0333
INFO - 2024-03-14 07:58:45 --> Config Class Initialized
INFO - 2024-03-14 07:58:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 07:58:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 07:58:45 --> Utf8 Class Initialized
INFO - 2024-03-14 07:58:45 --> URI Class Initialized
INFO - 2024-03-14 07:58:45 --> Router Class Initialized
INFO - 2024-03-14 07:58:45 --> Output Class Initialized
INFO - 2024-03-14 07:58:45 --> Security Class Initialized
DEBUG - 2024-03-14 07:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 07:58:45 --> Input Class Initialized
INFO - 2024-03-14 07:58:45 --> Language Class Initialized
INFO - 2024-03-14 07:58:45 --> Language Class Initialized
INFO - 2024-03-14 07:58:45 --> Config Class Initialized
INFO - 2024-03-14 07:58:45 --> Loader Class Initialized
INFO - 2024-03-14 07:58:45 --> Helper loaded: url_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: file_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: form_helper
INFO - 2024-03-14 07:58:45 --> Helper loaded: my_helper
INFO - 2024-03-14 07:58:45 --> Database Driver Class Initialized
INFO - 2024-03-14 07:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 07:58:45 --> Controller Class Initialized
DEBUG - 2024-03-14 07:58:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 07:58:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 07:58:45 --> Final output sent to browser
DEBUG - 2024-03-14 07:58:45 --> Total execution time: 0.0361
INFO - 2024-03-14 07:59:02 --> Config Class Initialized
INFO - 2024-03-14 07:59:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 07:59:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 07:59:02 --> Utf8 Class Initialized
INFO - 2024-03-14 07:59:02 --> URI Class Initialized
INFO - 2024-03-14 07:59:02 --> Router Class Initialized
INFO - 2024-03-14 07:59:02 --> Output Class Initialized
INFO - 2024-03-14 07:59:02 --> Security Class Initialized
DEBUG - 2024-03-14 07:59:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 07:59:02 --> Input Class Initialized
INFO - 2024-03-14 07:59:02 --> Language Class Initialized
INFO - 2024-03-14 07:59:02 --> Language Class Initialized
INFO - 2024-03-14 07:59:02 --> Config Class Initialized
INFO - 2024-03-14 07:59:02 --> Loader Class Initialized
INFO - 2024-03-14 07:59:02 --> Helper loaded: url_helper
INFO - 2024-03-14 07:59:02 --> Helper loaded: file_helper
INFO - 2024-03-14 07:59:02 --> Helper loaded: form_helper
INFO - 2024-03-14 07:59:02 --> Helper loaded: my_helper
INFO - 2024-03-14 07:59:02 --> Database Driver Class Initialized
INFO - 2024-03-14 07:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 07:59:02 --> Controller Class Initialized
DEBUG - 2024-03-14 07:59:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2024-03-14 07:59:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 07:59:02 --> Final output sent to browser
DEBUG - 2024-03-14 07:59:02 --> Total execution time: 0.0456
INFO - 2024-03-14 07:59:05 --> Config Class Initialized
INFO - 2024-03-14 07:59:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 07:59:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 07:59:05 --> Utf8 Class Initialized
INFO - 2024-03-14 07:59:05 --> URI Class Initialized
INFO - 2024-03-14 07:59:05 --> Router Class Initialized
INFO - 2024-03-14 07:59:05 --> Output Class Initialized
INFO - 2024-03-14 07:59:05 --> Security Class Initialized
DEBUG - 2024-03-14 07:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 07:59:05 --> Input Class Initialized
INFO - 2024-03-14 07:59:05 --> Language Class Initialized
INFO - 2024-03-14 07:59:05 --> Language Class Initialized
INFO - 2024-03-14 07:59:05 --> Config Class Initialized
INFO - 2024-03-14 07:59:05 --> Loader Class Initialized
INFO - 2024-03-14 07:59:05 --> Helper loaded: url_helper
INFO - 2024-03-14 07:59:05 --> Helper loaded: file_helper
INFO - 2024-03-14 07:59:05 --> Helper loaded: form_helper
INFO - 2024-03-14 07:59:05 --> Helper loaded: my_helper
INFO - 2024-03-14 07:59:05 --> Database Driver Class Initialized
INFO - 2024-03-14 07:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 07:59:05 --> Controller Class Initialized
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1554
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1555
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Undefined offset: 15 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-14 07:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1694
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Undefined offset: 16 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-14 07:59:05 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1731
ERROR - 2024-03-14 07:59:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 110
DEBUG - 2024-03-14 07:59:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-03-14 07:59:08 --> Final output sent to browser
DEBUG - 2024-03-14 07:59:08 --> Total execution time: 3.0430
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:22:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:22:44 --> Utf8 Class Initialized
INFO - 2024-03-14 08:22:44 --> URI Class Initialized
INFO - 2024-03-14 08:22:44 --> Router Class Initialized
INFO - 2024-03-14 08:22:44 --> Output Class Initialized
INFO - 2024-03-14 08:22:44 --> Security Class Initialized
DEBUG - 2024-03-14 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:22:44 --> Input Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Loader Class Initialized
INFO - 2024-03-14 08:22:44 --> Helper loaded: url_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: file_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: form_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: my_helper
INFO - 2024-03-14 08:22:44 --> Database Driver Class Initialized
INFO - 2024-03-14 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:22:44 --> Controller Class Initialized
INFO - 2024-03-14 08:22:44 --> Helper loaded: cookie_helper
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:22:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:22:44 --> Utf8 Class Initialized
INFO - 2024-03-14 08:22:44 --> URI Class Initialized
INFO - 2024-03-14 08:22:44 --> Router Class Initialized
INFO - 2024-03-14 08:22:44 --> Output Class Initialized
INFO - 2024-03-14 08:22:44 --> Security Class Initialized
DEBUG - 2024-03-14 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:22:44 --> Input Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Loader Class Initialized
INFO - 2024-03-14 08:22:44 --> Helper loaded: url_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: file_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: form_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: my_helper
INFO - 2024-03-14 08:22:44 --> Database Driver Class Initialized
INFO - 2024-03-14 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:22:44 --> Controller Class Initialized
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:22:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:22:44 --> Utf8 Class Initialized
INFO - 2024-03-14 08:22:44 --> URI Class Initialized
INFO - 2024-03-14 08:22:44 --> Router Class Initialized
INFO - 2024-03-14 08:22:44 --> Output Class Initialized
INFO - 2024-03-14 08:22:44 --> Security Class Initialized
DEBUG - 2024-03-14 08:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:22:44 --> Input Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Language Class Initialized
INFO - 2024-03-14 08:22:44 --> Config Class Initialized
INFO - 2024-03-14 08:22:44 --> Loader Class Initialized
INFO - 2024-03-14 08:22:44 --> Helper loaded: url_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: file_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: form_helper
INFO - 2024-03-14 08:22:44 --> Helper loaded: my_helper
INFO - 2024-03-14 08:22:44 --> Database Driver Class Initialized
INFO - 2024-03-14 08:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:22:44 --> Controller Class Initialized
DEBUG - 2024-03-14 08:22:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 08:22:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:22:44 --> Final output sent to browser
DEBUG - 2024-03-14 08:22:44 --> Total execution time: 0.0293
INFO - 2024-03-14 08:22:51 --> Config Class Initialized
INFO - 2024-03-14 08:22:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:22:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:22:51 --> Utf8 Class Initialized
INFO - 2024-03-14 08:22:51 --> URI Class Initialized
INFO - 2024-03-14 08:22:51 --> Router Class Initialized
INFO - 2024-03-14 08:22:51 --> Output Class Initialized
INFO - 2024-03-14 08:22:51 --> Security Class Initialized
DEBUG - 2024-03-14 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:22:51 --> Input Class Initialized
INFO - 2024-03-14 08:22:51 --> Language Class Initialized
INFO - 2024-03-14 08:22:51 --> Language Class Initialized
INFO - 2024-03-14 08:22:51 --> Config Class Initialized
INFO - 2024-03-14 08:22:51 --> Loader Class Initialized
INFO - 2024-03-14 08:22:51 --> Helper loaded: url_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: file_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: form_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: my_helper
INFO - 2024-03-14 08:22:51 --> Database Driver Class Initialized
INFO - 2024-03-14 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:22:51 --> Controller Class Initialized
INFO - 2024-03-14 08:22:51 --> Helper loaded: cookie_helper
INFO - 2024-03-14 08:22:51 --> Final output sent to browser
DEBUG - 2024-03-14 08:22:51 --> Total execution time: 0.0294
INFO - 2024-03-14 08:22:51 --> Config Class Initialized
INFO - 2024-03-14 08:22:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:22:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:22:51 --> Utf8 Class Initialized
INFO - 2024-03-14 08:22:51 --> URI Class Initialized
INFO - 2024-03-14 08:22:51 --> Router Class Initialized
INFO - 2024-03-14 08:22:51 --> Output Class Initialized
INFO - 2024-03-14 08:22:51 --> Security Class Initialized
DEBUG - 2024-03-14 08:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:22:51 --> Input Class Initialized
INFO - 2024-03-14 08:22:51 --> Language Class Initialized
INFO - 2024-03-14 08:22:51 --> Language Class Initialized
INFO - 2024-03-14 08:22:51 --> Config Class Initialized
INFO - 2024-03-14 08:22:51 --> Loader Class Initialized
INFO - 2024-03-14 08:22:51 --> Helper loaded: url_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: file_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: form_helper
INFO - 2024-03-14 08:22:51 --> Helper loaded: my_helper
INFO - 2024-03-14 08:22:51 --> Database Driver Class Initialized
INFO - 2024-03-14 08:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:22:51 --> Controller Class Initialized
DEBUG - 2024-03-14 08:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-14 08:22:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:22:51 --> Final output sent to browser
DEBUG - 2024-03-14 08:22:51 --> Total execution time: 0.0363
INFO - 2024-03-14 08:23:07 --> Config Class Initialized
INFO - 2024-03-14 08:23:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:07 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:07 --> URI Class Initialized
INFO - 2024-03-14 08:23:07 --> Router Class Initialized
INFO - 2024-03-14 08:23:07 --> Output Class Initialized
INFO - 2024-03-14 08:23:07 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:07 --> Input Class Initialized
INFO - 2024-03-14 08:23:07 --> Language Class Initialized
INFO - 2024-03-14 08:23:07 --> Language Class Initialized
INFO - 2024-03-14 08:23:07 --> Config Class Initialized
INFO - 2024-03-14 08:23:07 --> Loader Class Initialized
INFO - 2024-03-14 08:23:07 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:07 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:07 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2024-03-14 08:23:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:07 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:07 --> Total execution time: 0.0306
INFO - 2024-03-14 08:23:07 --> Config Class Initialized
INFO - 2024-03-14 08:23:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:07 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:07 --> URI Class Initialized
INFO - 2024-03-14 08:23:07 --> Router Class Initialized
INFO - 2024-03-14 08:23:07 --> Output Class Initialized
INFO - 2024-03-14 08:23:07 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:07 --> Input Class Initialized
INFO - 2024-03-14 08:23:07 --> Language Class Initialized
ERROR - 2024-03-14 08:23:07 --> 404 Page Not Found: /index
INFO - 2024-03-14 08:23:07 --> Config Class Initialized
INFO - 2024-03-14 08:23:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:07 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:07 --> URI Class Initialized
INFO - 2024-03-14 08:23:07 --> Router Class Initialized
INFO - 2024-03-14 08:23:07 --> Output Class Initialized
INFO - 2024-03-14 08:23:07 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:07 --> Input Class Initialized
INFO - 2024-03-14 08:23:07 --> Language Class Initialized
INFO - 2024-03-14 08:23:07 --> Language Class Initialized
INFO - 2024-03-14 08:23:07 --> Config Class Initialized
INFO - 2024-03-14 08:23:07 --> Loader Class Initialized
INFO - 2024-03-14 08:23:07 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:07 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:07 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:07 --> Controller Class Initialized
INFO - 2024-03-14 08:23:15 --> Config Class Initialized
INFO - 2024-03-14 08:23:15 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:15 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:15 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:15 --> URI Class Initialized
INFO - 2024-03-14 08:23:15 --> Router Class Initialized
INFO - 2024-03-14 08:23:15 --> Output Class Initialized
INFO - 2024-03-14 08:23:15 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:15 --> Input Class Initialized
INFO - 2024-03-14 08:23:15 --> Language Class Initialized
INFO - 2024-03-14 08:23:15 --> Language Class Initialized
INFO - 2024-03-14 08:23:15 --> Config Class Initialized
INFO - 2024-03-14 08:23:15 --> Loader Class Initialized
INFO - 2024-03-14 08:23:15 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:15 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:15 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:15 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:15 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:15 --> Controller Class Initialized
INFO - 2024-03-14 08:23:15 --> Helper loaded: cookie_helper
INFO - 2024-03-14 08:23:16 --> Config Class Initialized
INFO - 2024-03-14 08:23:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:16 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:16 --> URI Class Initialized
INFO - 2024-03-14 08:23:16 --> Router Class Initialized
INFO - 2024-03-14 08:23:16 --> Output Class Initialized
INFO - 2024-03-14 08:23:16 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:16 --> Input Class Initialized
INFO - 2024-03-14 08:23:16 --> Language Class Initialized
INFO - 2024-03-14 08:23:16 --> Language Class Initialized
INFO - 2024-03-14 08:23:16 --> Config Class Initialized
INFO - 2024-03-14 08:23:16 --> Loader Class Initialized
INFO - 2024-03-14 08:23:16 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:16 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:16 --> Controller Class Initialized
INFO - 2024-03-14 08:23:16 --> Config Class Initialized
INFO - 2024-03-14 08:23:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:16 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:16 --> URI Class Initialized
INFO - 2024-03-14 08:23:16 --> Router Class Initialized
INFO - 2024-03-14 08:23:16 --> Output Class Initialized
INFO - 2024-03-14 08:23:16 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:16 --> Input Class Initialized
INFO - 2024-03-14 08:23:16 --> Language Class Initialized
INFO - 2024-03-14 08:23:16 --> Language Class Initialized
INFO - 2024-03-14 08:23:16 --> Config Class Initialized
INFO - 2024-03-14 08:23:16 --> Loader Class Initialized
INFO - 2024-03-14 08:23:16 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:16 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:16 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:16 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 08:23:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:16 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:16 --> Total execution time: 0.0435
INFO - 2024-03-14 08:23:21 --> Config Class Initialized
INFO - 2024-03-14 08:23:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:21 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:21 --> URI Class Initialized
INFO - 2024-03-14 08:23:21 --> Router Class Initialized
INFO - 2024-03-14 08:23:21 --> Output Class Initialized
INFO - 2024-03-14 08:23:21 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:21 --> Input Class Initialized
INFO - 2024-03-14 08:23:21 --> Language Class Initialized
INFO - 2024-03-14 08:23:21 --> Language Class Initialized
INFO - 2024-03-14 08:23:21 --> Config Class Initialized
INFO - 2024-03-14 08:23:21 --> Loader Class Initialized
INFO - 2024-03-14 08:23:21 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:21 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:21 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:21 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:21 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:21 --> Controller Class Initialized
INFO - 2024-03-14 08:23:21 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:21 --> Total execution time: 0.1011
INFO - 2024-03-14 08:23:29 --> Config Class Initialized
INFO - 2024-03-14 08:23:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:29 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:29 --> URI Class Initialized
INFO - 2024-03-14 08:23:29 --> Router Class Initialized
INFO - 2024-03-14 08:23:29 --> Output Class Initialized
INFO - 2024-03-14 08:23:29 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:29 --> Input Class Initialized
INFO - 2024-03-14 08:23:29 --> Language Class Initialized
INFO - 2024-03-14 08:23:29 --> Language Class Initialized
INFO - 2024-03-14 08:23:29 --> Config Class Initialized
INFO - 2024-03-14 08:23:29 --> Loader Class Initialized
INFO - 2024-03-14 08:23:29 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:29 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:29 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:29 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:29 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:29 --> Controller Class Initialized
INFO - 2024-03-14 08:23:29 --> Helper loaded: cookie_helper
INFO - 2024-03-14 08:23:29 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:29 --> Total execution time: 0.0447
INFO - 2024-03-14 08:23:29 --> Config Class Initialized
INFO - 2024-03-14 08:23:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:29 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:29 --> URI Class Initialized
INFO - 2024-03-14 08:23:29 --> Router Class Initialized
INFO - 2024-03-14 08:23:29 --> Output Class Initialized
INFO - 2024-03-14 08:23:29 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:29 --> Input Class Initialized
INFO - 2024-03-14 08:23:29 --> Language Class Initialized
INFO - 2024-03-14 08:23:30 --> Language Class Initialized
INFO - 2024-03-14 08:23:30 --> Config Class Initialized
INFO - 2024-03-14 08:23:30 --> Loader Class Initialized
INFO - 2024-03-14 08:23:30 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:30 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:30 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:30 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:30 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:30 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 08:23:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:30 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:30 --> Total execution time: 0.0476
INFO - 2024-03-14 08:23:33 --> Config Class Initialized
INFO - 2024-03-14 08:23:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:33 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:33 --> URI Class Initialized
INFO - 2024-03-14 08:23:33 --> Router Class Initialized
INFO - 2024-03-14 08:23:33 --> Output Class Initialized
INFO - 2024-03-14 08:23:33 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:33 --> Input Class Initialized
INFO - 2024-03-14 08:23:33 --> Language Class Initialized
INFO - 2024-03-14 08:23:33 --> Language Class Initialized
INFO - 2024-03-14 08:23:33 --> Config Class Initialized
INFO - 2024-03-14 08:23:33 --> Loader Class Initialized
INFO - 2024-03-14 08:23:33 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:33 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:33 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:33 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:33 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:33 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 08:23:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:33 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:33 --> Total execution time: 0.0380
INFO - 2024-03-14 08:23:35 --> Config Class Initialized
INFO - 2024-03-14 08:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:35 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:35 --> URI Class Initialized
INFO - 2024-03-14 08:23:35 --> Router Class Initialized
INFO - 2024-03-14 08:23:35 --> Output Class Initialized
INFO - 2024-03-14 08:23:35 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:35 --> Input Class Initialized
INFO - 2024-03-14 08:23:35 --> Language Class Initialized
INFO - 2024-03-14 08:23:35 --> Language Class Initialized
INFO - 2024-03-14 08:23:35 --> Config Class Initialized
INFO - 2024-03-14 08:23:35 --> Loader Class Initialized
INFO - 2024-03-14 08:23:35 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:35 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:35 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 08:23:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:35 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:35 --> Total execution time: 0.0467
INFO - 2024-03-14 08:23:35 --> Config Class Initialized
INFO - 2024-03-14 08:23:35 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:35 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:35 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:35 --> URI Class Initialized
INFO - 2024-03-14 08:23:35 --> Router Class Initialized
INFO - 2024-03-14 08:23:35 --> Output Class Initialized
INFO - 2024-03-14 08:23:35 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:35 --> Input Class Initialized
INFO - 2024-03-14 08:23:35 --> Language Class Initialized
INFO - 2024-03-14 08:23:35 --> Language Class Initialized
INFO - 2024-03-14 08:23:35 --> Config Class Initialized
INFO - 2024-03-14 08:23:35 --> Loader Class Initialized
INFO - 2024-03-14 08:23:35 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:35 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:35 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:35 --> Controller Class Initialized
INFO - 2024-03-14 08:23:41 --> Config Class Initialized
INFO - 2024-03-14 08:23:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:41 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:41 --> URI Class Initialized
INFO - 2024-03-14 08:23:41 --> Router Class Initialized
INFO - 2024-03-14 08:23:41 --> Output Class Initialized
INFO - 2024-03-14 08:23:41 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:41 --> Input Class Initialized
INFO - 2024-03-14 08:23:41 --> Language Class Initialized
INFO - 2024-03-14 08:23:41 --> Language Class Initialized
INFO - 2024-03-14 08:23:41 --> Config Class Initialized
INFO - 2024-03-14 08:23:41 --> Loader Class Initialized
INFO - 2024-03-14 08:23:41 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:41 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:41 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:41 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:41 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:41 --> Controller Class Initialized
INFO - 2024-03-14 08:23:45 --> Config Class Initialized
INFO - 2024-03-14 08:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:45 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:45 --> URI Class Initialized
INFO - 2024-03-14 08:23:45 --> Router Class Initialized
INFO - 2024-03-14 08:23:45 --> Output Class Initialized
INFO - 2024-03-14 08:23:45 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:45 --> Input Class Initialized
INFO - 2024-03-14 08:23:45 --> Language Class Initialized
INFO - 2024-03-14 08:23:45 --> Language Class Initialized
INFO - 2024-03-14 08:23:45 --> Config Class Initialized
INFO - 2024-03-14 08:23:45 --> Loader Class Initialized
INFO - 2024-03-14 08:23:45 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:45 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:45 --> Controller Class Initialized
DEBUG - 2024-03-14 08:23:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 08:23:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:23:45 --> Final output sent to browser
DEBUG - 2024-03-14 08:23:45 --> Total execution time: 0.0340
INFO - 2024-03-14 08:23:45 --> Config Class Initialized
INFO - 2024-03-14 08:23:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:23:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:23:45 --> Utf8 Class Initialized
INFO - 2024-03-14 08:23:45 --> URI Class Initialized
INFO - 2024-03-14 08:23:45 --> Router Class Initialized
INFO - 2024-03-14 08:23:45 --> Output Class Initialized
INFO - 2024-03-14 08:23:45 --> Security Class Initialized
DEBUG - 2024-03-14 08:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:23:45 --> Input Class Initialized
INFO - 2024-03-14 08:23:45 --> Language Class Initialized
INFO - 2024-03-14 08:23:45 --> Language Class Initialized
INFO - 2024-03-14 08:23:45 --> Config Class Initialized
INFO - 2024-03-14 08:23:45 --> Loader Class Initialized
INFO - 2024-03-14 08:23:45 --> Helper loaded: url_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: file_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: form_helper
INFO - 2024-03-14 08:23:45 --> Helper loaded: my_helper
INFO - 2024-03-14 08:23:45 --> Database Driver Class Initialized
INFO - 2024-03-14 08:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:23:45 --> Controller Class Initialized
INFO - 2024-03-14 08:57:53 --> Config Class Initialized
INFO - 2024-03-14 08:57:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:57:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:57:53 --> Utf8 Class Initialized
INFO - 2024-03-14 08:57:53 --> URI Class Initialized
INFO - 2024-03-14 08:57:53 --> Router Class Initialized
INFO - 2024-03-14 08:57:53 --> Output Class Initialized
INFO - 2024-03-14 08:57:53 --> Security Class Initialized
DEBUG - 2024-03-14 08:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:57:53 --> Input Class Initialized
INFO - 2024-03-14 08:57:53 --> Language Class Initialized
INFO - 2024-03-14 08:57:53 --> Language Class Initialized
INFO - 2024-03-14 08:57:53 --> Config Class Initialized
INFO - 2024-03-14 08:57:53 --> Loader Class Initialized
INFO - 2024-03-14 08:57:53 --> Helper loaded: url_helper
INFO - 2024-03-14 08:57:53 --> Helper loaded: file_helper
INFO - 2024-03-14 08:57:53 --> Helper loaded: form_helper
INFO - 2024-03-14 08:57:53 --> Helper loaded: my_helper
INFO - 2024-03-14 08:57:53 --> Database Driver Class Initialized
INFO - 2024-03-14 08:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:57:53 --> Controller Class Initialized
DEBUG - 2024-03-14 08:57:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 08:57:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:57:53 --> Final output sent to browser
DEBUG - 2024-03-14 08:57:53 --> Total execution time: 0.0312
INFO - 2024-03-14 08:57:56 --> Config Class Initialized
INFO - 2024-03-14 08:57:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:57:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:57:56 --> Utf8 Class Initialized
INFO - 2024-03-14 08:57:56 --> URI Class Initialized
INFO - 2024-03-14 08:57:56 --> Router Class Initialized
INFO - 2024-03-14 08:57:56 --> Output Class Initialized
INFO - 2024-03-14 08:57:56 --> Security Class Initialized
DEBUG - 2024-03-14 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:57:56 --> Input Class Initialized
INFO - 2024-03-14 08:57:56 --> Language Class Initialized
INFO - 2024-03-14 08:57:56 --> Language Class Initialized
INFO - 2024-03-14 08:57:56 --> Config Class Initialized
INFO - 2024-03-14 08:57:56 --> Loader Class Initialized
INFO - 2024-03-14 08:57:56 --> Helper loaded: url_helper
INFO - 2024-03-14 08:57:56 --> Helper loaded: file_helper
INFO - 2024-03-14 08:57:56 --> Helper loaded: form_helper
INFO - 2024-03-14 08:57:56 --> Helper loaded: my_helper
INFO - 2024-03-14 08:57:56 --> Database Driver Class Initialized
INFO - 2024-03-14 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:57:56 --> Controller Class Initialized
DEBUG - 2024-03-14 08:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 08:57:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 08:57:56 --> Final output sent to browser
DEBUG - 2024-03-14 08:57:56 --> Total execution time: 0.0423
INFO - 2024-03-14 08:58:02 --> Config Class Initialized
INFO - 2024-03-14 08:58:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 08:58:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 08:58:02 --> Utf8 Class Initialized
INFO - 2024-03-14 08:58:02 --> URI Class Initialized
INFO - 2024-03-14 08:58:02 --> Router Class Initialized
INFO - 2024-03-14 08:58:02 --> Output Class Initialized
INFO - 2024-03-14 08:58:02 --> Security Class Initialized
DEBUG - 2024-03-14 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 08:58:02 --> Input Class Initialized
INFO - 2024-03-14 08:58:02 --> Language Class Initialized
INFO - 2024-03-14 08:58:02 --> Language Class Initialized
INFO - 2024-03-14 08:58:02 --> Config Class Initialized
INFO - 2024-03-14 08:58:02 --> Loader Class Initialized
INFO - 2024-03-14 08:58:02 --> Helper loaded: url_helper
INFO - 2024-03-14 08:58:02 --> Helper loaded: file_helper
INFO - 2024-03-14 08:58:02 --> Helper loaded: form_helper
INFO - 2024-03-14 08:58:02 --> Helper loaded: my_helper
INFO - 2024-03-14 08:58:02 --> Database Driver Class Initialized
INFO - 2024-03-14 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 08:58:02 --> Controller Class Initialized
INFO - 2024-03-14 08:58:02 --> Final output sent to browser
DEBUG - 2024-03-14 08:58:02 --> Total execution time: 0.1939
INFO - 2024-03-14 09:01:01 --> Config Class Initialized
INFO - 2024-03-14 09:01:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:01:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:01:01 --> Utf8 Class Initialized
INFO - 2024-03-14 09:01:01 --> URI Class Initialized
INFO - 2024-03-14 09:01:01 --> Router Class Initialized
INFO - 2024-03-14 09:01:01 --> Output Class Initialized
INFO - 2024-03-14 09:01:01 --> Security Class Initialized
DEBUG - 2024-03-14 09:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:01:01 --> Input Class Initialized
INFO - 2024-03-14 09:01:01 --> Language Class Initialized
INFO - 2024-03-14 09:01:01 --> Language Class Initialized
INFO - 2024-03-14 09:01:01 --> Config Class Initialized
INFO - 2024-03-14 09:01:01 --> Loader Class Initialized
INFO - 2024-03-14 09:01:01 --> Helper loaded: url_helper
INFO - 2024-03-14 09:01:01 --> Helper loaded: file_helper
INFO - 2024-03-14 09:01:01 --> Helper loaded: form_helper
INFO - 2024-03-14 09:01:01 --> Helper loaded: my_helper
INFO - 2024-03-14 09:01:01 --> Database Driver Class Initialized
INFO - 2024-03-14 09:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:01:01 --> Controller Class Initialized
INFO - 2024-03-14 09:01:01 --> Final output sent to browser
DEBUG - 2024-03-14 09:01:01 --> Total execution time: 0.4959
INFO - 2024-03-14 09:01:12 --> Config Class Initialized
INFO - 2024-03-14 09:01:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:01:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:01:12 --> Utf8 Class Initialized
INFO - 2024-03-14 09:01:12 --> URI Class Initialized
INFO - 2024-03-14 09:01:12 --> Router Class Initialized
INFO - 2024-03-14 09:01:12 --> Output Class Initialized
INFO - 2024-03-14 09:01:12 --> Security Class Initialized
DEBUG - 2024-03-14 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:01:12 --> Input Class Initialized
INFO - 2024-03-14 09:01:12 --> Language Class Initialized
INFO - 2024-03-14 09:01:12 --> Language Class Initialized
INFO - 2024-03-14 09:01:12 --> Config Class Initialized
INFO - 2024-03-14 09:01:12 --> Loader Class Initialized
INFO - 2024-03-14 09:01:12 --> Helper loaded: url_helper
INFO - 2024-03-14 09:01:12 --> Helper loaded: file_helper
INFO - 2024-03-14 09:01:12 --> Helper loaded: form_helper
INFO - 2024-03-14 09:01:12 --> Helper loaded: my_helper
INFO - 2024-03-14 09:01:12 --> Database Driver Class Initialized
INFO - 2024-03-14 09:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:01:12 --> Controller Class Initialized
DEBUG - 2024-03-14 09:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 09:01:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:01:12 --> Final output sent to browser
DEBUG - 2024-03-14 09:01:12 --> Total execution time: 0.0407
INFO - 2024-03-14 09:01:14 --> Config Class Initialized
INFO - 2024-03-14 09:01:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:01:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:01:14 --> Utf8 Class Initialized
INFO - 2024-03-14 09:01:14 --> URI Class Initialized
INFO - 2024-03-14 09:01:14 --> Router Class Initialized
INFO - 2024-03-14 09:01:14 --> Output Class Initialized
INFO - 2024-03-14 09:01:14 --> Security Class Initialized
DEBUG - 2024-03-14 09:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:01:14 --> Input Class Initialized
INFO - 2024-03-14 09:01:14 --> Language Class Initialized
INFO - 2024-03-14 09:01:14 --> Language Class Initialized
INFO - 2024-03-14 09:01:14 --> Config Class Initialized
INFO - 2024-03-14 09:01:14 --> Loader Class Initialized
INFO - 2024-03-14 09:01:14 --> Helper loaded: url_helper
INFO - 2024-03-14 09:01:14 --> Helper loaded: file_helper
INFO - 2024-03-14 09:01:14 --> Helper loaded: form_helper
INFO - 2024-03-14 09:01:14 --> Helper loaded: my_helper
INFO - 2024-03-14 09:01:14 --> Database Driver Class Initialized
INFO - 2024-03-14 09:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:01:14 --> Controller Class Initialized
DEBUG - 2024-03-14 09:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 09:01:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:01:14 --> Final output sent to browser
DEBUG - 2024-03-14 09:01:14 --> Total execution time: 0.0412
INFO - 2024-03-14 09:01:16 --> Config Class Initialized
INFO - 2024-03-14 09:01:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:01:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:01:16 --> Utf8 Class Initialized
INFO - 2024-03-14 09:01:16 --> URI Class Initialized
INFO - 2024-03-14 09:01:16 --> Router Class Initialized
INFO - 2024-03-14 09:01:16 --> Output Class Initialized
INFO - 2024-03-14 09:01:16 --> Security Class Initialized
DEBUG - 2024-03-14 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:01:16 --> Input Class Initialized
INFO - 2024-03-14 09:01:16 --> Language Class Initialized
INFO - 2024-03-14 09:01:16 --> Language Class Initialized
INFO - 2024-03-14 09:01:16 --> Config Class Initialized
INFO - 2024-03-14 09:01:16 --> Loader Class Initialized
INFO - 2024-03-14 09:01:16 --> Helper loaded: url_helper
INFO - 2024-03-14 09:01:16 --> Helper loaded: file_helper
INFO - 2024-03-14 09:01:16 --> Helper loaded: form_helper
INFO - 2024-03-14 09:01:16 --> Helper loaded: my_helper
INFO - 2024-03-14 09:01:16 --> Database Driver Class Initialized
INFO - 2024-03-14 09:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:01:16 --> Controller Class Initialized
INFO - 2024-03-14 09:01:16 --> Final output sent to browser
DEBUG - 2024-03-14 09:01:16 --> Total execution time: 0.0402
INFO - 2024-03-14 09:42:21 --> Config Class Initialized
INFO - 2024-03-14 09:42:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:42:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:42:21 --> Utf8 Class Initialized
INFO - 2024-03-14 09:42:21 --> URI Class Initialized
DEBUG - 2024-03-14 09:42:21 --> No URI present. Default controller set.
INFO - 2024-03-14 09:42:21 --> Router Class Initialized
INFO - 2024-03-14 09:42:21 --> Output Class Initialized
INFO - 2024-03-14 09:42:21 --> Security Class Initialized
DEBUG - 2024-03-14 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:42:21 --> Input Class Initialized
INFO - 2024-03-14 09:42:21 --> Language Class Initialized
INFO - 2024-03-14 09:42:21 --> Language Class Initialized
INFO - 2024-03-14 09:42:21 --> Config Class Initialized
INFO - 2024-03-14 09:42:21 --> Loader Class Initialized
INFO - 2024-03-14 09:42:21 --> Helper loaded: url_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: file_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: form_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: my_helper
INFO - 2024-03-14 09:42:21 --> Database Driver Class Initialized
INFO - 2024-03-14 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:42:21 --> Controller Class Initialized
INFO - 2024-03-14 09:42:21 --> Config Class Initialized
INFO - 2024-03-14 09:42:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:42:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:42:21 --> Utf8 Class Initialized
INFO - 2024-03-14 09:42:21 --> URI Class Initialized
INFO - 2024-03-14 09:42:21 --> Router Class Initialized
INFO - 2024-03-14 09:42:21 --> Output Class Initialized
INFO - 2024-03-14 09:42:21 --> Security Class Initialized
DEBUG - 2024-03-14 09:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:42:21 --> Input Class Initialized
INFO - 2024-03-14 09:42:21 --> Language Class Initialized
INFO - 2024-03-14 09:42:21 --> Language Class Initialized
INFO - 2024-03-14 09:42:21 --> Config Class Initialized
INFO - 2024-03-14 09:42:21 --> Loader Class Initialized
INFO - 2024-03-14 09:42:21 --> Helper loaded: url_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: file_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: form_helper
INFO - 2024-03-14 09:42:21 --> Helper loaded: my_helper
INFO - 2024-03-14 09:42:21 --> Database Driver Class Initialized
INFO - 2024-03-14 09:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:42:21 --> Controller Class Initialized
DEBUG - 2024-03-14 09:42:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 09:42:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:42:21 --> Final output sent to browser
DEBUG - 2024-03-14 09:42:21 --> Total execution time: 0.0449
INFO - 2024-03-14 09:55:27 --> Config Class Initialized
INFO - 2024-03-14 09:55:27 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:27 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:27 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:27 --> URI Class Initialized
INFO - 2024-03-14 09:55:27 --> Router Class Initialized
INFO - 2024-03-14 09:55:27 --> Output Class Initialized
INFO - 2024-03-14 09:55:27 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:27 --> Input Class Initialized
INFO - 2024-03-14 09:55:27 --> Language Class Initialized
INFO - 2024-03-14 09:55:27 --> Language Class Initialized
INFO - 2024-03-14 09:55:27 --> Config Class Initialized
INFO - 2024-03-14 09:55:27 --> Loader Class Initialized
INFO - 2024-03-14 09:55:27 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:27 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:27 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:27 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:27 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:27 --> Controller Class Initialized
DEBUG - 2024-03-14 09:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 09:55:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:55:27 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:27 --> Total execution time: 0.2922
INFO - 2024-03-14 09:55:28 --> Config Class Initialized
INFO - 2024-03-14 09:55:28 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:28 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:28 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:28 --> URI Class Initialized
INFO - 2024-03-14 09:55:28 --> Router Class Initialized
INFO - 2024-03-14 09:55:28 --> Output Class Initialized
INFO - 2024-03-14 09:55:28 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:28 --> Input Class Initialized
INFO - 2024-03-14 09:55:28 --> Language Class Initialized
INFO - 2024-03-14 09:55:28 --> Language Class Initialized
INFO - 2024-03-14 09:55:28 --> Config Class Initialized
INFO - 2024-03-14 09:55:28 --> Loader Class Initialized
INFO - 2024-03-14 09:55:28 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:28 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:28 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:28 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:28 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:28 --> Controller Class Initialized
INFO - 2024-03-14 09:55:34 --> Config Class Initialized
INFO - 2024-03-14 09:55:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:34 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:34 --> URI Class Initialized
DEBUG - 2024-03-14 09:55:34 --> No URI present. Default controller set.
INFO - 2024-03-14 09:55:34 --> Router Class Initialized
INFO - 2024-03-14 09:55:34 --> Output Class Initialized
INFO - 2024-03-14 09:55:34 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:34 --> Input Class Initialized
INFO - 2024-03-14 09:55:34 --> Language Class Initialized
INFO - 2024-03-14 09:55:34 --> Language Class Initialized
INFO - 2024-03-14 09:55:34 --> Config Class Initialized
INFO - 2024-03-14 09:55:34 --> Loader Class Initialized
INFO - 2024-03-14 09:55:34 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:34 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:34 --> Controller Class Initialized
INFO - 2024-03-14 09:55:34 --> Config Class Initialized
INFO - 2024-03-14 09:55:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:34 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:34 --> URI Class Initialized
INFO - 2024-03-14 09:55:34 --> Router Class Initialized
INFO - 2024-03-14 09:55:34 --> Output Class Initialized
INFO - 2024-03-14 09:55:34 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:34 --> Input Class Initialized
INFO - 2024-03-14 09:55:34 --> Language Class Initialized
INFO - 2024-03-14 09:55:34 --> Language Class Initialized
INFO - 2024-03-14 09:55:34 --> Config Class Initialized
INFO - 2024-03-14 09:55:34 --> Loader Class Initialized
INFO - 2024-03-14 09:55:34 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:34 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:34 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:34 --> Controller Class Initialized
DEBUG - 2024-03-14 09:55:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 09:55:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:55:34 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:34 --> Total execution time: 0.0324
INFO - 2024-03-14 09:55:36 --> Config Class Initialized
INFO - 2024-03-14 09:55:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:36 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:36 --> URI Class Initialized
INFO - 2024-03-14 09:55:36 --> Router Class Initialized
INFO - 2024-03-14 09:55:36 --> Output Class Initialized
INFO - 2024-03-14 09:55:36 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:36 --> Input Class Initialized
INFO - 2024-03-14 09:55:36 --> Language Class Initialized
INFO - 2024-03-14 09:55:36 --> Language Class Initialized
INFO - 2024-03-14 09:55:36 --> Config Class Initialized
INFO - 2024-03-14 09:55:36 --> Loader Class Initialized
INFO - 2024-03-14 09:55:36 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:36 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:36 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:36 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:36 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:36 --> Controller Class Initialized
INFO - 2024-03-14 09:55:36 --> Helper loaded: cookie_helper
INFO - 2024-03-14 09:55:36 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:36 --> Total execution time: 0.1149
INFO - 2024-03-14 09:55:37 --> Config Class Initialized
INFO - 2024-03-14 09:55:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:37 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:37 --> URI Class Initialized
INFO - 2024-03-14 09:55:37 --> Router Class Initialized
INFO - 2024-03-14 09:55:37 --> Output Class Initialized
INFO - 2024-03-14 09:55:37 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:37 --> Input Class Initialized
INFO - 2024-03-14 09:55:37 --> Language Class Initialized
INFO - 2024-03-14 09:55:37 --> Language Class Initialized
INFO - 2024-03-14 09:55:37 --> Config Class Initialized
INFO - 2024-03-14 09:55:37 --> Loader Class Initialized
INFO - 2024-03-14 09:55:37 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:37 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:37 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:37 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:37 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:37 --> Controller Class Initialized
DEBUG - 2024-03-14 09:55:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 09:55:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:55:37 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:37 --> Total execution time: 0.0395
INFO - 2024-03-14 09:55:43 --> Config Class Initialized
INFO - 2024-03-14 09:55:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:43 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:43 --> URI Class Initialized
INFO - 2024-03-14 09:55:43 --> Router Class Initialized
INFO - 2024-03-14 09:55:43 --> Output Class Initialized
INFO - 2024-03-14 09:55:43 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:43 --> Input Class Initialized
INFO - 2024-03-14 09:55:43 --> Language Class Initialized
INFO - 2024-03-14 09:55:43 --> Language Class Initialized
INFO - 2024-03-14 09:55:43 --> Config Class Initialized
INFO - 2024-03-14 09:55:43 --> Loader Class Initialized
INFO - 2024-03-14 09:55:43 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:43 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:43 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:43 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:43 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:43 --> Controller Class Initialized
DEBUG - 2024-03-14 09:55:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 09:55:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:55:43 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:43 --> Total execution time: 0.0312
INFO - 2024-03-14 09:55:46 --> Config Class Initialized
INFO - 2024-03-14 09:55:46 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:55:46 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:55:46 --> Utf8 Class Initialized
INFO - 2024-03-14 09:55:46 --> URI Class Initialized
INFO - 2024-03-14 09:55:46 --> Router Class Initialized
INFO - 2024-03-14 09:55:46 --> Output Class Initialized
INFO - 2024-03-14 09:55:46 --> Security Class Initialized
DEBUG - 2024-03-14 09:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:55:46 --> Input Class Initialized
INFO - 2024-03-14 09:55:46 --> Language Class Initialized
INFO - 2024-03-14 09:55:46 --> Language Class Initialized
INFO - 2024-03-14 09:55:46 --> Config Class Initialized
INFO - 2024-03-14 09:55:46 --> Loader Class Initialized
INFO - 2024-03-14 09:55:46 --> Helper loaded: url_helper
INFO - 2024-03-14 09:55:46 --> Helper loaded: file_helper
INFO - 2024-03-14 09:55:46 --> Helper loaded: form_helper
INFO - 2024-03-14 09:55:46 --> Helper loaded: my_helper
INFO - 2024-03-14 09:55:46 --> Database Driver Class Initialized
INFO - 2024-03-14 09:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:55:46 --> Controller Class Initialized
DEBUG - 2024-03-14 09:55:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 09:55:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:55:46 --> Final output sent to browser
DEBUG - 2024-03-14 09:55:46 --> Total execution time: 0.0347
INFO - 2024-03-14 09:56:01 --> Config Class Initialized
INFO - 2024-03-14 09:56:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:56:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:56:01 --> Utf8 Class Initialized
INFO - 2024-03-14 09:56:01 --> URI Class Initialized
INFO - 2024-03-14 09:56:01 --> Router Class Initialized
INFO - 2024-03-14 09:56:01 --> Output Class Initialized
INFO - 2024-03-14 09:56:01 --> Security Class Initialized
DEBUG - 2024-03-14 09:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:56:01 --> Input Class Initialized
INFO - 2024-03-14 09:56:01 --> Language Class Initialized
INFO - 2024-03-14 09:56:01 --> Language Class Initialized
INFO - 2024-03-14 09:56:01 --> Config Class Initialized
INFO - 2024-03-14 09:56:01 --> Loader Class Initialized
INFO - 2024-03-14 09:56:01 --> Helper loaded: url_helper
INFO - 2024-03-14 09:56:01 --> Helper loaded: file_helper
INFO - 2024-03-14 09:56:01 --> Helper loaded: form_helper
INFO - 2024-03-14 09:56:01 --> Helper loaded: my_helper
INFO - 2024-03-14 09:56:01 --> Database Driver Class Initialized
INFO - 2024-03-14 09:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:56:01 --> Controller Class Initialized
INFO - 2024-03-14 09:56:01 --> Final output sent to browser
DEBUG - 2024-03-14 09:56:01 --> Total execution time: 0.1228
INFO - 2024-03-14 09:57:18 --> Config Class Initialized
INFO - 2024-03-14 09:57:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:18 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:18 --> URI Class Initialized
INFO - 2024-03-14 09:57:18 --> Router Class Initialized
INFO - 2024-03-14 09:57:18 --> Output Class Initialized
INFO - 2024-03-14 09:57:18 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:18 --> Input Class Initialized
INFO - 2024-03-14 09:57:18 --> Language Class Initialized
INFO - 2024-03-14 09:57:18 --> Language Class Initialized
INFO - 2024-03-14 09:57:18 --> Config Class Initialized
INFO - 2024-03-14 09:57:18 --> Loader Class Initialized
INFO - 2024-03-14 09:57:18 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:18 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:18 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:18 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:18 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:18 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 09:57:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:18 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:18 --> Total execution time: 0.0360
INFO - 2024-03-14 09:57:31 --> Config Class Initialized
INFO - 2024-03-14 09:57:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:31 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:31 --> URI Class Initialized
INFO - 2024-03-14 09:57:31 --> Router Class Initialized
INFO - 2024-03-14 09:57:31 --> Output Class Initialized
INFO - 2024-03-14 09:57:31 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:31 --> Input Class Initialized
INFO - 2024-03-14 09:57:31 --> Language Class Initialized
INFO - 2024-03-14 09:57:31 --> Language Class Initialized
INFO - 2024-03-14 09:57:31 --> Config Class Initialized
INFO - 2024-03-14 09:57:31 --> Loader Class Initialized
INFO - 2024-03-14 09:57:31 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:31 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:31 --> Controller Class Initialized
INFO - 2024-03-14 09:57:31 --> Helper loaded: cookie_helper
INFO - 2024-03-14 09:57:31 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:31 --> Total execution time: 0.0333
INFO - 2024-03-14 09:57:31 --> Config Class Initialized
INFO - 2024-03-14 09:57:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:31 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:31 --> URI Class Initialized
INFO - 2024-03-14 09:57:31 --> Router Class Initialized
INFO - 2024-03-14 09:57:31 --> Output Class Initialized
INFO - 2024-03-14 09:57:31 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:31 --> Input Class Initialized
INFO - 2024-03-14 09:57:31 --> Language Class Initialized
INFO - 2024-03-14 09:57:31 --> Language Class Initialized
INFO - 2024-03-14 09:57:31 --> Config Class Initialized
INFO - 2024-03-14 09:57:31 --> Loader Class Initialized
INFO - 2024-03-14 09:57:31 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:31 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:31 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:31 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 09:57:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:31 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:31 --> Total execution time: 0.0315
INFO - 2024-03-14 09:57:37 --> Config Class Initialized
INFO - 2024-03-14 09:57:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:37 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:37 --> URI Class Initialized
INFO - 2024-03-14 09:57:37 --> Router Class Initialized
INFO - 2024-03-14 09:57:37 --> Output Class Initialized
INFO - 2024-03-14 09:57:37 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:37 --> Input Class Initialized
INFO - 2024-03-14 09:57:37 --> Language Class Initialized
INFO - 2024-03-14 09:57:37 --> Language Class Initialized
INFO - 2024-03-14 09:57:37 --> Config Class Initialized
INFO - 2024-03-14 09:57:37 --> Loader Class Initialized
INFO - 2024-03-14 09:57:37 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:37 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:37 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:37 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:37 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:37 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 09:57:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:37 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:37 --> Total execution time: 0.0373
INFO - 2024-03-14 09:57:39 --> Config Class Initialized
INFO - 2024-03-14 09:57:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:39 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:39 --> URI Class Initialized
INFO - 2024-03-14 09:57:39 --> Router Class Initialized
INFO - 2024-03-14 09:57:39 --> Output Class Initialized
INFO - 2024-03-14 09:57:39 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:39 --> Input Class Initialized
INFO - 2024-03-14 09:57:39 --> Language Class Initialized
INFO - 2024-03-14 09:57:39 --> Language Class Initialized
INFO - 2024-03-14 09:57:39 --> Config Class Initialized
INFO - 2024-03-14 09:57:39 --> Loader Class Initialized
INFO - 2024-03-14 09:57:39 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:39 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:39 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:39 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:39 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:39 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 09:57:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:39 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:39 --> Total execution time: 0.0301
INFO - 2024-03-14 09:57:40 --> Config Class Initialized
INFO - 2024-03-14 09:57:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:40 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:40 --> URI Class Initialized
INFO - 2024-03-14 09:57:40 --> Router Class Initialized
INFO - 2024-03-14 09:57:40 --> Output Class Initialized
INFO - 2024-03-14 09:57:40 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:40 --> Input Class Initialized
INFO - 2024-03-14 09:57:40 --> Language Class Initialized
INFO - 2024-03-14 09:57:40 --> Language Class Initialized
INFO - 2024-03-14 09:57:40 --> Config Class Initialized
INFO - 2024-03-14 09:57:40 --> Loader Class Initialized
INFO - 2024-03-14 09:57:40 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:40 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:40 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:40 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:40 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:40 --> Controller Class Initialized
INFO - 2024-03-14 09:57:42 --> Config Class Initialized
INFO - 2024-03-14 09:57:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:42 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:42 --> URI Class Initialized
INFO - 2024-03-14 09:57:42 --> Router Class Initialized
INFO - 2024-03-14 09:57:42 --> Output Class Initialized
INFO - 2024-03-14 09:57:42 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:42 --> Input Class Initialized
INFO - 2024-03-14 09:57:42 --> Language Class Initialized
INFO - 2024-03-14 09:57:42 --> Language Class Initialized
INFO - 2024-03-14 09:57:42 --> Config Class Initialized
INFO - 2024-03-14 09:57:42 --> Loader Class Initialized
INFO - 2024-03-14 09:57:42 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:42 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:42 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:42 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:42 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:42 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 09:57:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:42 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:42 --> Total execution time: 0.0460
INFO - 2024-03-14 09:57:44 --> Config Class Initialized
INFO - 2024-03-14 09:57:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:44 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:44 --> URI Class Initialized
INFO - 2024-03-14 09:57:44 --> Router Class Initialized
INFO - 2024-03-14 09:57:44 --> Output Class Initialized
INFO - 2024-03-14 09:57:44 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:44 --> Input Class Initialized
INFO - 2024-03-14 09:57:44 --> Language Class Initialized
INFO - 2024-03-14 09:57:44 --> Language Class Initialized
INFO - 2024-03-14 09:57:44 --> Config Class Initialized
INFO - 2024-03-14 09:57:44 --> Loader Class Initialized
INFO - 2024-03-14 09:57:44 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:44 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:44 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:44 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:44 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:44 --> Controller Class Initialized
DEBUG - 2024-03-14 09:57:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 09:57:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 09:57:44 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:44 --> Total execution time: 0.0303
INFO - 2024-03-14 09:57:46 --> Config Class Initialized
INFO - 2024-03-14 09:57:46 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:57:46 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:57:46 --> Utf8 Class Initialized
INFO - 2024-03-14 09:57:46 --> URI Class Initialized
INFO - 2024-03-14 09:57:46 --> Router Class Initialized
INFO - 2024-03-14 09:57:46 --> Output Class Initialized
INFO - 2024-03-14 09:57:46 --> Security Class Initialized
DEBUG - 2024-03-14 09:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:57:46 --> Input Class Initialized
INFO - 2024-03-14 09:57:46 --> Language Class Initialized
INFO - 2024-03-14 09:57:46 --> Language Class Initialized
INFO - 2024-03-14 09:57:46 --> Config Class Initialized
INFO - 2024-03-14 09:57:46 --> Loader Class Initialized
INFO - 2024-03-14 09:57:46 --> Helper loaded: url_helper
INFO - 2024-03-14 09:57:46 --> Helper loaded: file_helper
INFO - 2024-03-14 09:57:46 --> Helper loaded: form_helper
INFO - 2024-03-14 09:57:46 --> Helper loaded: my_helper
INFO - 2024-03-14 09:57:46 --> Database Driver Class Initialized
INFO - 2024-03-14 09:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:57:46 --> Controller Class Initialized
INFO - 2024-03-14 09:57:46 --> Final output sent to browser
DEBUG - 2024-03-14 09:57:46 --> Total execution time: 0.0330
INFO - 2024-03-14 09:59:39 --> Config Class Initialized
INFO - 2024-03-14 09:59:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 09:59:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 09:59:39 --> Utf8 Class Initialized
INFO - 2024-03-14 09:59:39 --> URI Class Initialized
INFO - 2024-03-14 09:59:39 --> Router Class Initialized
INFO - 2024-03-14 09:59:39 --> Output Class Initialized
INFO - 2024-03-14 09:59:39 --> Security Class Initialized
DEBUG - 2024-03-14 09:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 09:59:39 --> Input Class Initialized
INFO - 2024-03-14 09:59:39 --> Language Class Initialized
INFO - 2024-03-14 09:59:39 --> Language Class Initialized
INFO - 2024-03-14 09:59:39 --> Config Class Initialized
INFO - 2024-03-14 09:59:39 --> Loader Class Initialized
INFO - 2024-03-14 09:59:39 --> Helper loaded: url_helper
INFO - 2024-03-14 09:59:39 --> Helper loaded: file_helper
INFO - 2024-03-14 09:59:39 --> Helper loaded: form_helper
INFO - 2024-03-14 09:59:39 --> Helper loaded: my_helper
INFO - 2024-03-14 09:59:39 --> Database Driver Class Initialized
INFO - 2024-03-14 09:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 09:59:39 --> Controller Class Initialized
ERROR - 2024-03-14 09:59:39 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 09:59:39 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:04 --> Config Class Initialized
INFO - 2024-03-14 10:00:04 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:04 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:04 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:04 --> URI Class Initialized
INFO - 2024-03-14 10:00:04 --> Router Class Initialized
INFO - 2024-03-14 10:00:04 --> Output Class Initialized
INFO - 2024-03-14 10:00:04 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:04 --> Input Class Initialized
INFO - 2024-03-14 10:00:04 --> Language Class Initialized
INFO - 2024-03-14 10:00:04 --> Language Class Initialized
INFO - 2024-03-14 10:00:04 --> Config Class Initialized
INFO - 2024-03-14 10:00:04 --> Loader Class Initialized
INFO - 2024-03-14 10:00:04 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:04 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:04 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:04 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:04 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:04 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:04 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:05 --> URI Class Initialized
INFO - 2024-03-14 10:00:05 --> Router Class Initialized
INFO - 2024-03-14 10:00:05 --> Output Class Initialized
INFO - 2024-03-14 10:00:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:05 --> Input Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Loader Class Initialized
INFO - 2024-03-14 10:00:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:05 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:05 --> URI Class Initialized
INFO - 2024-03-14 10:00:05 --> Router Class Initialized
INFO - 2024-03-14 10:00:05 --> Output Class Initialized
INFO - 2024-03-14 10:00:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:05 --> Input Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Loader Class Initialized
INFO - 2024-03-14 10:00:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:05 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:05 --> URI Class Initialized
INFO - 2024-03-14 10:00:05 --> Router Class Initialized
INFO - 2024-03-14 10:00:05 --> Output Class Initialized
INFO - 2024-03-14 10:00:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:05 --> Input Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Loader Class Initialized
INFO - 2024-03-14 10:00:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:05 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:05 --> URI Class Initialized
INFO - 2024-03-14 10:00:05 --> Router Class Initialized
INFO - 2024-03-14 10:00:05 --> Output Class Initialized
INFO - 2024-03-14 10:00:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:05 --> Input Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Language Class Initialized
INFO - 2024-03-14 10:00:05 --> Config Class Initialized
INFO - 2024-03-14 10:00:05 --> Loader Class Initialized
INFO - 2024-03-14 10:00:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:05 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:05 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:06 --> Config Class Initialized
INFO - 2024-03-14 10:00:06 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:06 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:06 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:06 --> URI Class Initialized
INFO - 2024-03-14 10:00:06 --> Router Class Initialized
INFO - 2024-03-14 10:00:06 --> Output Class Initialized
INFO - 2024-03-14 10:00:06 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:06 --> Input Class Initialized
INFO - 2024-03-14 10:00:06 --> Language Class Initialized
INFO - 2024-03-14 10:00:06 --> Language Class Initialized
INFO - 2024-03-14 10:00:06 --> Config Class Initialized
INFO - 2024-03-14 10:00:06 --> Loader Class Initialized
INFO - 2024-03-14 10:00:06 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:06 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:06 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:06 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:06 --> Config Class Initialized
INFO - 2024-03-14 10:00:06 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:06 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:06 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:06 --> URI Class Initialized
INFO - 2024-03-14 10:00:06 --> Router Class Initialized
INFO - 2024-03-14 10:00:06 --> Output Class Initialized
INFO - 2024-03-14 10:00:06 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:06 --> Input Class Initialized
INFO - 2024-03-14 10:00:06 --> Language Class Initialized
INFO - 2024-03-14 10:00:06 --> Language Class Initialized
INFO - 2024-03-14 10:00:06 --> Config Class Initialized
INFO - 2024-03-14 10:00:06 --> Loader Class Initialized
INFO - 2024-03-14 10:00:06 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:06 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:07 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:07 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 't hesitate to ask your teachers and peers for clarification. This way, you can a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '28', '6', '3', '-', 'You demonstrate a strong commitment to learning, evident from the improvement in your exam scores and daily efforts. You diligently tackle exercises and assignments, showcasing proficiency in understanding topics such as Perimeter of Polygon, Area of Rectilinear, Congruency and Enlargement, Area of a Shape, Volume and Surface Area of a Cuboid, Rotation, Enlargement, Transformation, Reflection, Translation, and Statistics. However, there are still areas where misunderstandings persist. If you encounter questions during your learning journey, don't hesitate to ask your teachers and peers for clarification. This way, you can approach problems with confidence and accuracy.')
INFO - 2024-03-14 10:00:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:00:08 --> Config Class Initialized
INFO - 2024-03-14 10:00:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:08 --> URI Class Initialized
INFO - 2024-03-14 10:00:08 --> Router Class Initialized
INFO - 2024-03-14 10:00:08 --> Output Class Initialized
INFO - 2024-03-14 10:00:08 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:08 --> Input Class Initialized
INFO - 2024-03-14 10:00:08 --> Language Class Initialized
INFO - 2024-03-14 10:00:08 --> Language Class Initialized
INFO - 2024-03-14 10:00:08 --> Config Class Initialized
INFO - 2024-03-14 10:00:08 --> Loader Class Initialized
INFO - 2024-03-14 10:00:08 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:08 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:08 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:08 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:08 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:08 --> Controller Class Initialized
DEBUG - 2024-03-14 10:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:00:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:00:08 --> Final output sent to browser
DEBUG - 2024-03-14 10:00:08 --> Total execution time: 0.0658
INFO - 2024-03-14 10:00:11 --> Config Class Initialized
INFO - 2024-03-14 10:00:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:11 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:11 --> URI Class Initialized
INFO - 2024-03-14 10:00:11 --> Router Class Initialized
INFO - 2024-03-14 10:00:11 --> Output Class Initialized
INFO - 2024-03-14 10:00:11 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:11 --> Input Class Initialized
INFO - 2024-03-14 10:00:11 --> Language Class Initialized
INFO - 2024-03-14 10:00:11 --> Language Class Initialized
INFO - 2024-03-14 10:00:11 --> Config Class Initialized
INFO - 2024-03-14 10:00:11 --> Loader Class Initialized
INFO - 2024-03-14 10:00:11 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:11 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:11 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:11 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:11 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:11 --> Controller Class Initialized
INFO - 2024-03-14 10:00:11 --> Final output sent to browser
DEBUG - 2024-03-14 10:00:11 --> Total execution time: 0.0735
INFO - 2024-03-14 10:00:16 --> Config Class Initialized
INFO - 2024-03-14 10:00:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:16 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:16 --> URI Class Initialized
INFO - 2024-03-14 10:00:16 --> Router Class Initialized
INFO - 2024-03-14 10:00:16 --> Output Class Initialized
INFO - 2024-03-14 10:00:16 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:16 --> Input Class Initialized
INFO - 2024-03-14 10:00:16 --> Language Class Initialized
INFO - 2024-03-14 10:00:16 --> Language Class Initialized
INFO - 2024-03-14 10:00:16 --> Config Class Initialized
INFO - 2024-03-14 10:00:16 --> Loader Class Initialized
INFO - 2024-03-14 10:00:16 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:16 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:16 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:16 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:16 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:16 --> Controller Class Initialized
INFO - 2024-03-14 10:00:54 --> Config Class Initialized
INFO - 2024-03-14 10:00:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:00:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:00:54 --> Utf8 Class Initialized
INFO - 2024-03-14 10:00:54 --> URI Class Initialized
INFO - 2024-03-14 10:00:54 --> Router Class Initialized
INFO - 2024-03-14 10:00:54 --> Output Class Initialized
INFO - 2024-03-14 10:00:54 --> Security Class Initialized
DEBUG - 2024-03-14 10:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:00:54 --> Input Class Initialized
INFO - 2024-03-14 10:00:54 --> Language Class Initialized
INFO - 2024-03-14 10:00:54 --> Language Class Initialized
INFO - 2024-03-14 10:00:54 --> Config Class Initialized
INFO - 2024-03-14 10:00:54 --> Loader Class Initialized
INFO - 2024-03-14 10:00:54 --> Helper loaded: url_helper
INFO - 2024-03-14 10:00:54 --> Helper loaded: file_helper
INFO - 2024-03-14 10:00:54 --> Helper loaded: form_helper
INFO - 2024-03-14 10:00:54 --> Helper loaded: my_helper
INFO - 2024-03-14 10:00:54 --> Database Driver Class Initialized
INFO - 2024-03-14 10:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:00:54 --> Controller Class Initialized
ERROR - 2024-03-14 10:00:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:00:54 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:01:13 --> Config Class Initialized
INFO - 2024-03-14 10:01:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:01:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:01:13 --> Utf8 Class Initialized
INFO - 2024-03-14 10:01:13 --> URI Class Initialized
INFO - 2024-03-14 10:01:13 --> Router Class Initialized
INFO - 2024-03-14 10:01:13 --> Output Class Initialized
INFO - 2024-03-14 10:01:13 --> Security Class Initialized
DEBUG - 2024-03-14 10:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:01:13 --> Input Class Initialized
INFO - 2024-03-14 10:01:13 --> Language Class Initialized
INFO - 2024-03-14 10:01:13 --> Language Class Initialized
INFO - 2024-03-14 10:01:13 --> Config Class Initialized
INFO - 2024-03-14 10:01:13 --> Loader Class Initialized
INFO - 2024-03-14 10:01:13 --> Helper loaded: url_helper
INFO - 2024-03-14 10:01:13 --> Helper loaded: file_helper
INFO - 2024-03-14 10:01:13 --> Helper loaded: form_helper
INFO - 2024-03-14 10:01:13 --> Helper loaded: my_helper
INFO - 2024-03-14 10:01:13 --> Database Driver Class Initialized
INFO - 2024-03-14 10:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:01:13 --> Controller Class Initialized
ERROR - 2024-03-14 10:01:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:01:13 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:01:21 --> Config Class Initialized
INFO - 2024-03-14 10:01:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:01:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:01:21 --> Utf8 Class Initialized
INFO - 2024-03-14 10:01:21 --> URI Class Initialized
INFO - 2024-03-14 10:01:21 --> Router Class Initialized
INFO - 2024-03-14 10:01:21 --> Output Class Initialized
INFO - 2024-03-14 10:01:21 --> Security Class Initialized
DEBUG - 2024-03-14 10:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:01:21 --> Input Class Initialized
INFO - 2024-03-14 10:01:21 --> Language Class Initialized
INFO - 2024-03-14 10:01:21 --> Language Class Initialized
INFO - 2024-03-14 10:01:21 --> Config Class Initialized
INFO - 2024-03-14 10:01:21 --> Loader Class Initialized
INFO - 2024-03-14 10:01:21 --> Helper loaded: url_helper
INFO - 2024-03-14 10:01:21 --> Helper loaded: file_helper
INFO - 2024-03-14 10:01:21 --> Helper loaded: form_helper
INFO - 2024-03-14 10:01:21 --> Helper loaded: my_helper
INFO - 2024-03-14 10:01:21 --> Database Driver Class Initialized
INFO - 2024-03-14 10:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:01:21 --> Controller Class Initialized
ERROR - 2024-03-14 10:01:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:01:21 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:02:52 --> Config Class Initialized
INFO - 2024-03-14 10:02:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:02:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:02:52 --> Utf8 Class Initialized
INFO - 2024-03-14 10:02:52 --> URI Class Initialized
INFO - 2024-03-14 10:02:52 --> Router Class Initialized
INFO - 2024-03-14 10:02:52 --> Output Class Initialized
INFO - 2024-03-14 10:02:52 --> Security Class Initialized
DEBUG - 2024-03-14 10:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:02:52 --> Input Class Initialized
INFO - 2024-03-14 10:02:52 --> Language Class Initialized
INFO - 2024-03-14 10:02:52 --> Language Class Initialized
INFO - 2024-03-14 10:02:52 --> Config Class Initialized
INFO - 2024-03-14 10:02:52 --> Loader Class Initialized
INFO - 2024-03-14 10:02:52 --> Helper loaded: url_helper
INFO - 2024-03-14 10:02:52 --> Helper loaded: file_helper
INFO - 2024-03-14 10:02:52 --> Helper loaded: form_helper
INFO - 2024-03-14 10:02:52 --> Helper loaded: my_helper
INFO - 2024-03-14 10:02:52 --> Database Driver Class Initialized
INFO - 2024-03-14 10:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:02:52 --> Controller Class Initialized
DEBUG - 2024-03-14 10:02:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-03-14 10:02:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:02:52 --> Final output sent to browser
DEBUG - 2024-03-14 10:02:52 --> Total execution time: 0.0743
INFO - 2024-03-14 10:03:01 --> Config Class Initialized
INFO - 2024-03-14 10:03:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:01 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:01 --> URI Class Initialized
INFO - 2024-03-14 10:03:01 --> Router Class Initialized
INFO - 2024-03-14 10:03:01 --> Output Class Initialized
INFO - 2024-03-14 10:03:01 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:01 --> Input Class Initialized
INFO - 2024-03-14 10:03:01 --> Language Class Initialized
INFO - 2024-03-14 10:03:01 --> Language Class Initialized
INFO - 2024-03-14 10:03:01 --> Config Class Initialized
INFO - 2024-03-14 10:03:01 --> Loader Class Initialized
INFO - 2024-03-14 10:03:01 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:01 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:01 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:01 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:01 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:01 --> Controller Class Initialized
INFO - 2024-03-14 10:03:02 --> Config Class Initialized
INFO - 2024-03-14 10:03:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:02 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:02 --> URI Class Initialized
INFO - 2024-03-14 10:03:02 --> Router Class Initialized
INFO - 2024-03-14 10:03:02 --> Output Class Initialized
INFO - 2024-03-14 10:03:02 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:02 --> Input Class Initialized
INFO - 2024-03-14 10:03:02 --> Language Class Initialized
INFO - 2024-03-14 10:03:02 --> Language Class Initialized
INFO - 2024-03-14 10:03:02 --> Config Class Initialized
INFO - 2024-03-14 10:03:02 --> Loader Class Initialized
INFO - 2024-03-14 10:03:02 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:02 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:02 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:02 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:02 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:02 --> Controller Class Initialized
DEBUG - 2024-03-14 10:03:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:03:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:03:02 --> Final output sent to browser
DEBUG - 2024-03-14 10:03:02 --> Total execution time: 0.0364
INFO - 2024-03-14 10:03:05 --> Config Class Initialized
INFO - 2024-03-14 10:03:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:05 --> URI Class Initialized
INFO - 2024-03-14 10:03:05 --> Router Class Initialized
INFO - 2024-03-14 10:03:05 --> Output Class Initialized
INFO - 2024-03-14 10:03:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:05 --> Input Class Initialized
INFO - 2024-03-14 10:03:05 --> Language Class Initialized
INFO - 2024-03-14 10:03:05 --> Language Class Initialized
INFO - 2024-03-14 10:03:05 --> Config Class Initialized
INFO - 2024-03-14 10:03:05 --> Loader Class Initialized
INFO - 2024-03-14 10:03:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:05 --> Controller Class Initialized
INFO - 2024-03-14 10:03:05 --> Final output sent to browser
DEBUG - 2024-03-14 10:03:05 --> Total execution time: 0.0291
INFO - 2024-03-14 10:03:30 --> Config Class Initialized
INFO - 2024-03-14 10:03:30 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:30 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:30 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:30 --> URI Class Initialized
INFO - 2024-03-14 10:03:30 --> Router Class Initialized
INFO - 2024-03-14 10:03:30 --> Output Class Initialized
INFO - 2024-03-14 10:03:30 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:30 --> Input Class Initialized
INFO - 2024-03-14 10:03:30 --> Language Class Initialized
INFO - 2024-03-14 10:03:30 --> Language Class Initialized
INFO - 2024-03-14 10:03:30 --> Config Class Initialized
INFO - 2024-03-14 10:03:30 --> Loader Class Initialized
INFO - 2024-03-14 10:03:30 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:30 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:30 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:30 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:30 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:30 --> Controller Class Initialized
DEBUG - 2024-03-14 10:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:03:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:03:30 --> Final output sent to browser
DEBUG - 2024-03-14 10:03:30 --> Total execution time: 0.0347
INFO - 2024-03-14 10:03:33 --> Config Class Initialized
INFO - 2024-03-14 10:03:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:33 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:33 --> URI Class Initialized
INFO - 2024-03-14 10:03:33 --> Router Class Initialized
INFO - 2024-03-14 10:03:33 --> Output Class Initialized
INFO - 2024-03-14 10:03:33 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:33 --> Input Class Initialized
INFO - 2024-03-14 10:03:33 --> Language Class Initialized
INFO - 2024-03-14 10:03:33 --> Language Class Initialized
INFO - 2024-03-14 10:03:33 --> Config Class Initialized
INFO - 2024-03-14 10:03:33 --> Loader Class Initialized
INFO - 2024-03-14 10:03:33 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:33 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:33 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:33 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:33 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:33 --> Controller Class Initialized
DEBUG - 2024-03-14 10:03:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:03:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:03:33 --> Final output sent to browser
DEBUG - 2024-03-14 10:03:33 --> Total execution time: 0.0322
INFO - 2024-03-14 10:03:37 --> Config Class Initialized
INFO - 2024-03-14 10:03:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:03:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:03:37 --> Utf8 Class Initialized
INFO - 2024-03-14 10:03:37 --> URI Class Initialized
INFO - 2024-03-14 10:03:37 --> Router Class Initialized
INFO - 2024-03-14 10:03:37 --> Output Class Initialized
INFO - 2024-03-14 10:03:37 --> Security Class Initialized
DEBUG - 2024-03-14 10:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:03:37 --> Input Class Initialized
INFO - 2024-03-14 10:03:37 --> Language Class Initialized
INFO - 2024-03-14 10:03:37 --> Language Class Initialized
INFO - 2024-03-14 10:03:37 --> Config Class Initialized
INFO - 2024-03-14 10:03:37 --> Loader Class Initialized
INFO - 2024-03-14 10:03:37 --> Helper loaded: url_helper
INFO - 2024-03-14 10:03:37 --> Helper loaded: file_helper
INFO - 2024-03-14 10:03:37 --> Helper loaded: form_helper
INFO - 2024-03-14 10:03:37 --> Helper loaded: my_helper
INFO - 2024-03-14 10:03:37 --> Database Driver Class Initialized
INFO - 2024-03-14 10:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:03:37 --> Controller Class Initialized
INFO - 2024-03-14 10:05:54 --> Config Class Initialized
INFO - 2024-03-14 10:05:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:05:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:05:54 --> Utf8 Class Initialized
INFO - 2024-03-14 10:05:54 --> URI Class Initialized
INFO - 2024-03-14 10:05:54 --> Router Class Initialized
INFO - 2024-03-14 10:05:54 --> Output Class Initialized
INFO - 2024-03-14 10:05:54 --> Security Class Initialized
DEBUG - 2024-03-14 10:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:05:54 --> Input Class Initialized
INFO - 2024-03-14 10:05:54 --> Language Class Initialized
INFO - 2024-03-14 10:05:54 --> Language Class Initialized
INFO - 2024-03-14 10:05:54 --> Config Class Initialized
INFO - 2024-03-14 10:05:54 --> Loader Class Initialized
INFO - 2024-03-14 10:05:54 --> Helper loaded: url_helper
INFO - 2024-03-14 10:05:54 --> Helper loaded: file_helper
INFO - 2024-03-14 10:05:54 --> Helper loaded: form_helper
INFO - 2024-03-14 10:05:54 --> Helper loaded: my_helper
INFO - 2024-03-14 10:05:54 --> Database Driver Class Initialized
INFO - 2024-03-14 10:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:05:54 --> Controller Class Initialized
DEBUG - 2024-03-14 10:05:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-03-14 10:05:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:05:54 --> Final output sent to browser
DEBUG - 2024-03-14 10:05:54 --> Total execution time: 0.0325
INFO - 2024-03-14 10:06:00 --> Config Class Initialized
INFO - 2024-03-14 10:06:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:06:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:06:00 --> Utf8 Class Initialized
INFO - 2024-03-14 10:06:00 --> URI Class Initialized
INFO - 2024-03-14 10:06:00 --> Router Class Initialized
INFO - 2024-03-14 10:06:00 --> Output Class Initialized
INFO - 2024-03-14 10:06:00 --> Security Class Initialized
DEBUG - 2024-03-14 10:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:06:00 --> Input Class Initialized
INFO - 2024-03-14 10:06:00 --> Language Class Initialized
INFO - 2024-03-14 10:06:00 --> Language Class Initialized
INFO - 2024-03-14 10:06:00 --> Config Class Initialized
INFO - 2024-03-14 10:06:00 --> Loader Class Initialized
INFO - 2024-03-14 10:06:00 --> Helper loaded: url_helper
INFO - 2024-03-14 10:06:00 --> Helper loaded: file_helper
INFO - 2024-03-14 10:06:00 --> Helper loaded: form_helper
INFO - 2024-03-14 10:06:00 --> Helper loaded: my_helper
INFO - 2024-03-14 10:06:00 --> Database Driver Class Initialized
INFO - 2024-03-14 10:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:06:00 --> Controller Class Initialized
INFO - 2024-03-14 10:06:00 --> Config Class Initialized
INFO - 2024-03-14 10:06:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:06:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:06:00 --> Utf8 Class Initialized
INFO - 2024-03-14 10:06:00 --> URI Class Initialized
INFO - 2024-03-14 10:06:00 --> Router Class Initialized
INFO - 2024-03-14 10:06:00 --> Output Class Initialized
INFO - 2024-03-14 10:06:00 --> Security Class Initialized
DEBUG - 2024-03-14 10:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:06:00 --> Input Class Initialized
INFO - 2024-03-14 10:06:00 --> Language Class Initialized
INFO - 2024-03-14 10:06:01 --> Language Class Initialized
INFO - 2024-03-14 10:06:01 --> Config Class Initialized
INFO - 2024-03-14 10:06:01 --> Loader Class Initialized
INFO - 2024-03-14 10:06:01 --> Helper loaded: url_helper
INFO - 2024-03-14 10:06:01 --> Helper loaded: file_helper
INFO - 2024-03-14 10:06:01 --> Helper loaded: form_helper
INFO - 2024-03-14 10:06:01 --> Helper loaded: my_helper
INFO - 2024-03-14 10:06:01 --> Database Driver Class Initialized
INFO - 2024-03-14 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:06:01 --> Controller Class Initialized
DEBUG - 2024-03-14 10:06:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:06:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:06:01 --> Final output sent to browser
DEBUG - 2024-03-14 10:06:01 --> Total execution time: 0.0389
INFO - 2024-03-14 10:06:03 --> Config Class Initialized
INFO - 2024-03-14 10:06:03 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:06:03 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:06:03 --> Utf8 Class Initialized
INFO - 2024-03-14 10:06:03 --> URI Class Initialized
INFO - 2024-03-14 10:06:03 --> Router Class Initialized
INFO - 2024-03-14 10:06:03 --> Output Class Initialized
INFO - 2024-03-14 10:06:03 --> Security Class Initialized
DEBUG - 2024-03-14 10:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:06:03 --> Input Class Initialized
INFO - 2024-03-14 10:06:03 --> Language Class Initialized
INFO - 2024-03-14 10:06:03 --> Language Class Initialized
INFO - 2024-03-14 10:06:03 --> Config Class Initialized
INFO - 2024-03-14 10:06:03 --> Loader Class Initialized
INFO - 2024-03-14 10:06:03 --> Helper loaded: url_helper
INFO - 2024-03-14 10:06:03 --> Helper loaded: file_helper
INFO - 2024-03-14 10:06:03 --> Helper loaded: form_helper
INFO - 2024-03-14 10:06:03 --> Helper loaded: my_helper
INFO - 2024-03-14 10:06:03 --> Database Driver Class Initialized
INFO - 2024-03-14 10:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:06:03 --> Controller Class Initialized
INFO - 2024-03-14 10:06:03 --> Final output sent to browser
DEBUG - 2024-03-14 10:06:03 --> Total execution time: 0.0514
INFO - 2024-03-14 10:06:50 --> Config Class Initialized
INFO - 2024-03-14 10:06:50 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:06:50 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:06:50 --> Utf8 Class Initialized
INFO - 2024-03-14 10:06:50 --> URI Class Initialized
INFO - 2024-03-14 10:06:50 --> Router Class Initialized
INFO - 2024-03-14 10:06:50 --> Output Class Initialized
INFO - 2024-03-14 10:06:50 --> Security Class Initialized
DEBUG - 2024-03-14 10:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:06:50 --> Input Class Initialized
INFO - 2024-03-14 10:06:50 --> Language Class Initialized
INFO - 2024-03-14 10:06:50 --> Language Class Initialized
INFO - 2024-03-14 10:06:50 --> Config Class Initialized
INFO - 2024-03-14 10:06:50 --> Loader Class Initialized
INFO - 2024-03-14 10:06:50 --> Helper loaded: url_helper
INFO - 2024-03-14 10:06:50 --> Helper loaded: file_helper
INFO - 2024-03-14 10:06:50 --> Helper loaded: form_helper
INFO - 2024-03-14 10:06:50 --> Helper loaded: my_helper
INFO - 2024-03-14 10:06:50 --> Database Driver Class Initialized
INFO - 2024-03-14 10:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:06:50 --> Controller Class Initialized
ERROR - 2024-03-14 10:06:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:06:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:07:14 --> Config Class Initialized
INFO - 2024-03-14 10:07:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:07:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:07:14 --> Utf8 Class Initialized
INFO - 2024-03-14 10:07:14 --> URI Class Initialized
INFO - 2024-03-14 10:07:14 --> Router Class Initialized
INFO - 2024-03-14 10:07:14 --> Output Class Initialized
INFO - 2024-03-14 10:07:14 --> Security Class Initialized
DEBUG - 2024-03-14 10:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:07:14 --> Input Class Initialized
INFO - 2024-03-14 10:07:14 --> Language Class Initialized
INFO - 2024-03-14 10:07:14 --> Language Class Initialized
INFO - 2024-03-14 10:07:14 --> Config Class Initialized
INFO - 2024-03-14 10:07:14 --> Loader Class Initialized
INFO - 2024-03-14 10:07:14 --> Helper loaded: url_helper
INFO - 2024-03-14 10:07:14 --> Helper loaded: file_helper
INFO - 2024-03-14 10:07:14 --> Helper loaded: form_helper
INFO - 2024-03-14 10:07:14 --> Helper loaded: my_helper
INFO - 2024-03-14 10:07:14 --> Database Driver Class Initialized
INFO - 2024-03-14 10:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:07:14 --> Controller Class Initialized
ERROR - 2024-03-14 10:07:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:07:14 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:07:17 --> Config Class Initialized
INFO - 2024-03-14 10:07:17 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:07:17 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:07:17 --> Utf8 Class Initialized
INFO - 2024-03-14 10:07:17 --> URI Class Initialized
INFO - 2024-03-14 10:07:17 --> Router Class Initialized
INFO - 2024-03-14 10:07:17 --> Output Class Initialized
INFO - 2024-03-14 10:07:17 --> Security Class Initialized
DEBUG - 2024-03-14 10:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:07:17 --> Input Class Initialized
INFO - 2024-03-14 10:07:17 --> Language Class Initialized
INFO - 2024-03-14 10:07:17 --> Language Class Initialized
INFO - 2024-03-14 10:07:17 --> Config Class Initialized
INFO - 2024-03-14 10:07:17 --> Loader Class Initialized
INFO - 2024-03-14 10:07:17 --> Helper loaded: url_helper
INFO - 2024-03-14 10:07:17 --> Helper loaded: file_helper
INFO - 2024-03-14 10:07:17 --> Helper loaded: form_helper
INFO - 2024-03-14 10:07:17 --> Helper loaded: my_helper
INFO - 2024-03-14 10:07:17 --> Database Driver Class Initialized
INFO - 2024-03-14 10:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:07:17 --> Controller Class Initialized
DEBUG - 2024-03-14 10:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:07:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:07:17 --> Final output sent to browser
DEBUG - 2024-03-14 10:07:17 --> Total execution time: 0.0327
INFO - 2024-03-14 10:07:21 --> Config Class Initialized
INFO - 2024-03-14 10:07:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:07:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:07:21 --> Utf8 Class Initialized
INFO - 2024-03-14 10:07:21 --> URI Class Initialized
INFO - 2024-03-14 10:07:21 --> Router Class Initialized
INFO - 2024-03-14 10:07:21 --> Output Class Initialized
INFO - 2024-03-14 10:07:21 --> Security Class Initialized
DEBUG - 2024-03-14 10:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:07:21 --> Input Class Initialized
INFO - 2024-03-14 10:07:21 --> Language Class Initialized
INFO - 2024-03-14 10:07:21 --> Language Class Initialized
INFO - 2024-03-14 10:07:21 --> Config Class Initialized
INFO - 2024-03-14 10:07:21 --> Loader Class Initialized
INFO - 2024-03-14 10:07:21 --> Helper loaded: url_helper
INFO - 2024-03-14 10:07:21 --> Helper loaded: file_helper
INFO - 2024-03-14 10:07:21 --> Helper loaded: form_helper
INFO - 2024-03-14 10:07:21 --> Helper loaded: my_helper
INFO - 2024-03-14 10:07:21 --> Database Driver Class Initialized
INFO - 2024-03-14 10:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:07:21 --> Controller Class Initialized
DEBUG - 2024-03-14 10:07:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:07:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:07:21 --> Final output sent to browser
DEBUG - 2024-03-14 10:07:21 --> Total execution time: 0.0329
INFO - 2024-03-14 10:07:22 --> Config Class Initialized
INFO - 2024-03-14 10:07:22 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:07:22 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:07:22 --> Utf8 Class Initialized
INFO - 2024-03-14 10:07:22 --> URI Class Initialized
INFO - 2024-03-14 10:07:22 --> Router Class Initialized
INFO - 2024-03-14 10:07:22 --> Output Class Initialized
INFO - 2024-03-14 10:07:22 --> Security Class Initialized
DEBUG - 2024-03-14 10:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:07:22 --> Input Class Initialized
INFO - 2024-03-14 10:07:22 --> Language Class Initialized
INFO - 2024-03-14 10:07:22 --> Language Class Initialized
INFO - 2024-03-14 10:07:22 --> Config Class Initialized
INFO - 2024-03-14 10:07:22 --> Loader Class Initialized
INFO - 2024-03-14 10:07:22 --> Helper loaded: url_helper
INFO - 2024-03-14 10:07:22 --> Helper loaded: file_helper
INFO - 2024-03-14 10:07:22 --> Helper loaded: form_helper
INFO - 2024-03-14 10:07:22 --> Helper loaded: my_helper
INFO - 2024-03-14 10:07:22 --> Database Driver Class Initialized
INFO - 2024-03-14 10:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:07:22 --> Controller Class Initialized
INFO - 2024-03-14 10:07:22 --> Final output sent to browser
DEBUG - 2024-03-14 10:07:22 --> Total execution time: 0.0297
INFO - 2024-03-14 10:08:50 --> Config Class Initialized
INFO - 2024-03-14 10:08:50 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:08:50 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:08:50 --> Utf8 Class Initialized
INFO - 2024-03-14 10:08:50 --> URI Class Initialized
INFO - 2024-03-14 10:08:50 --> Router Class Initialized
INFO - 2024-03-14 10:08:50 --> Output Class Initialized
INFO - 2024-03-14 10:08:50 --> Security Class Initialized
DEBUG - 2024-03-14 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:08:50 --> Input Class Initialized
INFO - 2024-03-14 10:08:50 --> Language Class Initialized
INFO - 2024-03-14 10:08:50 --> Language Class Initialized
INFO - 2024-03-14 10:08:50 --> Config Class Initialized
INFO - 2024-03-14 10:08:50 --> Loader Class Initialized
INFO - 2024-03-14 10:08:50 --> Helper loaded: url_helper
INFO - 2024-03-14 10:08:50 --> Helper loaded: file_helper
INFO - 2024-03-14 10:08:50 --> Helper loaded: form_helper
INFO - 2024-03-14 10:08:50 --> Helper loaded: my_helper
INFO - 2024-03-14 10:08:50 --> Database Driver Class Initialized
INFO - 2024-03-14 10:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:08:50 --> Controller Class Initialized
ERROR - 2024-03-14 10:08:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:08:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:08:54 --> Config Class Initialized
INFO - 2024-03-14 10:08:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:08:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:08:54 --> Utf8 Class Initialized
INFO - 2024-03-14 10:08:54 --> URI Class Initialized
INFO - 2024-03-14 10:08:54 --> Router Class Initialized
INFO - 2024-03-14 10:08:54 --> Output Class Initialized
INFO - 2024-03-14 10:08:54 --> Security Class Initialized
DEBUG - 2024-03-14 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:08:54 --> Input Class Initialized
INFO - 2024-03-14 10:08:54 --> Language Class Initialized
INFO - 2024-03-14 10:08:54 --> Language Class Initialized
INFO - 2024-03-14 10:08:54 --> Config Class Initialized
INFO - 2024-03-14 10:08:54 --> Loader Class Initialized
INFO - 2024-03-14 10:08:54 --> Helper loaded: url_helper
INFO - 2024-03-14 10:08:54 --> Helper loaded: file_helper
INFO - 2024-03-14 10:08:54 --> Helper loaded: form_helper
INFO - 2024-03-14 10:08:54 --> Helper loaded: my_helper
INFO - 2024-03-14 10:08:54 --> Database Driver Class Initialized
INFO - 2024-03-14 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:08:54 --> Controller Class Initialized
ERROR - 2024-03-14 10:08:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:08:54 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:08:57 --> Config Class Initialized
INFO - 2024-03-14 10:08:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:08:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:08:57 --> Utf8 Class Initialized
INFO - 2024-03-14 10:08:57 --> URI Class Initialized
INFO - 2024-03-14 10:08:57 --> Router Class Initialized
INFO - 2024-03-14 10:08:57 --> Output Class Initialized
INFO - 2024-03-14 10:08:57 --> Security Class Initialized
DEBUG - 2024-03-14 10:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:08:57 --> Input Class Initialized
INFO - 2024-03-14 10:08:57 --> Language Class Initialized
INFO - 2024-03-14 10:08:57 --> Language Class Initialized
INFO - 2024-03-14 10:08:57 --> Config Class Initialized
INFO - 2024-03-14 10:08:57 --> Loader Class Initialized
INFO - 2024-03-14 10:08:57 --> Helper loaded: url_helper
INFO - 2024-03-14 10:08:57 --> Helper loaded: file_helper
INFO - 2024-03-14 10:08:57 --> Helper loaded: form_helper
INFO - 2024-03-14 10:08:57 --> Helper loaded: my_helper
INFO - 2024-03-14 10:08:57 --> Database Driver Class Initialized
INFO - 2024-03-14 10:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:08:57 --> Controller Class Initialized
ERROR - 2024-03-14 10:08:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:08:57 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:08:58 --> Config Class Initialized
INFO - 2024-03-14 10:08:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:08:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:08:58 --> Utf8 Class Initialized
INFO - 2024-03-14 10:08:58 --> URI Class Initialized
INFO - 2024-03-14 10:08:58 --> Router Class Initialized
INFO - 2024-03-14 10:08:58 --> Output Class Initialized
INFO - 2024-03-14 10:08:58 --> Security Class Initialized
DEBUG - 2024-03-14 10:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:08:58 --> Input Class Initialized
INFO - 2024-03-14 10:08:58 --> Language Class Initialized
INFO - 2024-03-14 10:08:58 --> Language Class Initialized
INFO - 2024-03-14 10:08:58 --> Config Class Initialized
INFO - 2024-03-14 10:08:58 --> Loader Class Initialized
INFO - 2024-03-14 10:08:58 --> Helper loaded: url_helper
INFO - 2024-03-14 10:08:58 --> Helper loaded: file_helper
INFO - 2024-03-14 10:08:58 --> Helper loaded: form_helper
INFO - 2024-03-14 10:08:58 --> Helper loaded: my_helper
INFO - 2024-03-14 10:08:58 --> Database Driver Class Initialized
INFO - 2024-03-14 10:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:08:58 --> Controller Class Initialized
ERROR - 2024-03-14 10:08:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:08:58 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:09:00 --> Config Class Initialized
INFO - 2024-03-14 10:09:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:09:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:09:00 --> Utf8 Class Initialized
INFO - 2024-03-14 10:09:00 --> URI Class Initialized
INFO - 2024-03-14 10:09:00 --> Router Class Initialized
INFO - 2024-03-14 10:09:00 --> Output Class Initialized
INFO - 2024-03-14 10:09:00 --> Security Class Initialized
DEBUG - 2024-03-14 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:09:00 --> Input Class Initialized
INFO - 2024-03-14 10:09:00 --> Language Class Initialized
INFO - 2024-03-14 10:09:00 --> Language Class Initialized
INFO - 2024-03-14 10:09:00 --> Config Class Initialized
INFO - 2024-03-14 10:09:00 --> Loader Class Initialized
INFO - 2024-03-14 10:09:00 --> Helper loaded: url_helper
INFO - 2024-03-14 10:09:00 --> Helper loaded: file_helper
INFO - 2024-03-14 10:09:00 --> Helper loaded: form_helper
INFO - 2024-03-14 10:09:00 --> Helper loaded: my_helper
INFO - 2024-03-14 10:09:00 --> Database Driver Class Initialized
INFO - 2024-03-14 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:09:00 --> Controller Class Initialized
ERROR - 2024-03-14 10:09:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:09:00 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:09:07 --> Config Class Initialized
INFO - 2024-03-14 10:09:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:09:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:09:07 --> Utf8 Class Initialized
INFO - 2024-03-14 10:09:07 --> URI Class Initialized
INFO - 2024-03-14 10:09:07 --> Router Class Initialized
INFO - 2024-03-14 10:09:07 --> Output Class Initialized
INFO - 2024-03-14 10:09:07 --> Security Class Initialized
DEBUG - 2024-03-14 10:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:09:07 --> Input Class Initialized
INFO - 2024-03-14 10:09:07 --> Language Class Initialized
INFO - 2024-03-14 10:09:07 --> Language Class Initialized
INFO - 2024-03-14 10:09:07 --> Config Class Initialized
INFO - 2024-03-14 10:09:07 --> Loader Class Initialized
INFO - 2024-03-14 10:09:07 --> Helper loaded: url_helper
INFO - 2024-03-14 10:09:07 --> Helper loaded: file_helper
INFO - 2024-03-14 10:09:07 --> Helper loaded: form_helper
INFO - 2024-03-14 10:09:07 --> Helper loaded: my_helper
INFO - 2024-03-14 10:09:07 --> Database Driver Class Initialized
INFO - 2024-03-14 10:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:09:07 --> Controller Class Initialized
ERROR - 2024-03-14 10:09:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:09:07 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:09:12 --> Config Class Initialized
INFO - 2024-03-14 10:09:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:09:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:09:12 --> Utf8 Class Initialized
INFO - 2024-03-14 10:09:12 --> URI Class Initialized
INFO - 2024-03-14 10:09:12 --> Router Class Initialized
INFO - 2024-03-14 10:09:12 --> Output Class Initialized
INFO - 2024-03-14 10:09:12 --> Security Class Initialized
DEBUG - 2024-03-14 10:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:09:12 --> Input Class Initialized
INFO - 2024-03-14 10:09:12 --> Language Class Initialized
INFO - 2024-03-14 10:09:12 --> Language Class Initialized
INFO - 2024-03-14 10:09:12 --> Config Class Initialized
INFO - 2024-03-14 10:09:12 --> Loader Class Initialized
INFO - 2024-03-14 10:09:12 --> Helper loaded: url_helper
INFO - 2024-03-14 10:09:12 --> Helper loaded: file_helper
INFO - 2024-03-14 10:09:12 --> Helper loaded: form_helper
INFO - 2024-03-14 10:09:12 --> Helper loaded: my_helper
INFO - 2024-03-14 10:09:12 --> Database Driver Class Initialized
INFO - 2024-03-14 10:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:09:12 --> Controller Class Initialized
ERROR - 2024-03-14 10:09:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:09:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:09:19 --> Config Class Initialized
INFO - 2024-03-14 10:09:19 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:09:19 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:09:19 --> Utf8 Class Initialized
INFO - 2024-03-14 10:09:19 --> URI Class Initialized
INFO - 2024-03-14 10:09:19 --> Router Class Initialized
INFO - 2024-03-14 10:09:19 --> Output Class Initialized
INFO - 2024-03-14 10:09:19 --> Security Class Initialized
DEBUG - 2024-03-14 10:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:09:19 --> Input Class Initialized
INFO - 2024-03-14 10:09:19 --> Language Class Initialized
INFO - 2024-03-14 10:09:19 --> Language Class Initialized
INFO - 2024-03-14 10:09:19 --> Config Class Initialized
INFO - 2024-03-14 10:09:19 --> Loader Class Initialized
INFO - 2024-03-14 10:09:19 --> Helper loaded: url_helper
INFO - 2024-03-14 10:09:19 --> Helper loaded: file_helper
INFO - 2024-03-14 10:09:19 --> Helper loaded: form_helper
INFO - 2024-03-14 10:09:19 --> Helper loaded: my_helper
INFO - 2024-03-14 10:09:19 --> Database Driver Class Initialized
INFO - 2024-03-14 10:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:09:19 --> Controller Class Initialized
ERROR - 2024-03-14 10:09:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:09:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:12:08 --> Config Class Initialized
INFO - 2024-03-14 10:12:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:12:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:12:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:12:08 --> URI Class Initialized
INFO - 2024-03-14 10:12:08 --> Router Class Initialized
INFO - 2024-03-14 10:12:08 --> Output Class Initialized
INFO - 2024-03-14 10:12:08 --> Security Class Initialized
DEBUG - 2024-03-14 10:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:12:08 --> Input Class Initialized
INFO - 2024-03-14 10:12:08 --> Language Class Initialized
INFO - 2024-03-14 10:12:08 --> Language Class Initialized
INFO - 2024-03-14 10:12:08 --> Config Class Initialized
INFO - 2024-03-14 10:12:08 --> Loader Class Initialized
INFO - 2024-03-14 10:12:08 --> Helper loaded: url_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: file_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: form_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: my_helper
INFO - 2024-03-14 10:12:08 --> Database Driver Class Initialized
INFO - 2024-03-14 10:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:12:08 --> Controller Class Initialized
ERROR - 2024-03-14 10:12:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:12:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:12:08 --> Config Class Initialized
INFO - 2024-03-14 10:12:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:12:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:12:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:12:08 --> URI Class Initialized
INFO - 2024-03-14 10:12:08 --> Router Class Initialized
INFO - 2024-03-14 10:12:08 --> Output Class Initialized
INFO - 2024-03-14 10:12:08 --> Security Class Initialized
DEBUG - 2024-03-14 10:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:12:08 --> Input Class Initialized
INFO - 2024-03-14 10:12:08 --> Language Class Initialized
INFO - 2024-03-14 10:12:08 --> Language Class Initialized
INFO - 2024-03-14 10:12:08 --> Config Class Initialized
INFO - 2024-03-14 10:12:08 --> Loader Class Initialized
INFO - 2024-03-14 10:12:08 --> Helper loaded: url_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: file_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: form_helper
INFO - 2024-03-14 10:12:08 --> Helper loaded: my_helper
INFO - 2024-03-14 10:12:08 --> Database Driver Class Initialized
INFO - 2024-03-14 10:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:12:08 --> Controller Class Initialized
ERROR - 2024-03-14 10:12:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:12:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:12:12 --> Config Class Initialized
INFO - 2024-03-14 10:12:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:12:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:12:12 --> Utf8 Class Initialized
INFO - 2024-03-14 10:12:12 --> URI Class Initialized
INFO - 2024-03-14 10:12:12 --> Router Class Initialized
INFO - 2024-03-14 10:12:12 --> Output Class Initialized
INFO - 2024-03-14 10:12:12 --> Security Class Initialized
DEBUG - 2024-03-14 10:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:12:12 --> Input Class Initialized
INFO - 2024-03-14 10:12:12 --> Language Class Initialized
INFO - 2024-03-14 10:12:12 --> Language Class Initialized
INFO - 2024-03-14 10:12:12 --> Config Class Initialized
INFO - 2024-03-14 10:12:12 --> Loader Class Initialized
INFO - 2024-03-14 10:12:12 --> Helper loaded: url_helper
INFO - 2024-03-14 10:12:12 --> Helper loaded: file_helper
INFO - 2024-03-14 10:12:12 --> Helper loaded: form_helper
INFO - 2024-03-14 10:12:12 --> Helper loaded: my_helper
INFO - 2024-03-14 10:12:12 --> Database Driver Class Initialized
INFO - 2024-03-14 10:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:12:12 --> Controller Class Initialized
ERROR - 2024-03-14 10:12:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:12:12 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:12:16 --> Config Class Initialized
INFO - 2024-03-14 10:12:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:12:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:12:16 --> Utf8 Class Initialized
INFO - 2024-03-14 10:12:16 --> URI Class Initialized
INFO - 2024-03-14 10:12:16 --> Router Class Initialized
INFO - 2024-03-14 10:12:16 --> Output Class Initialized
INFO - 2024-03-14 10:12:16 --> Security Class Initialized
DEBUG - 2024-03-14 10:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:12:16 --> Input Class Initialized
INFO - 2024-03-14 10:12:16 --> Language Class Initialized
INFO - 2024-03-14 10:12:16 --> Language Class Initialized
INFO - 2024-03-14 10:12:16 --> Config Class Initialized
INFO - 2024-03-14 10:12:16 --> Loader Class Initialized
INFO - 2024-03-14 10:12:16 --> Helper loaded: url_helper
INFO - 2024-03-14 10:12:16 --> Helper loaded: file_helper
INFO - 2024-03-14 10:12:16 --> Helper loaded: form_helper
INFO - 2024-03-14 10:12:16 --> Helper loaded: my_helper
INFO - 2024-03-14 10:12:16 --> Database Driver Class Initialized
INFO - 2024-03-14 10:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:12:16 --> Controller Class Initialized
ERROR - 2024-03-14 10:12:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:12:16 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:37:57 --> Config Class Initialized
INFO - 2024-03-14 10:37:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:37:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:37:57 --> Utf8 Class Initialized
INFO - 2024-03-14 10:37:57 --> URI Class Initialized
INFO - 2024-03-14 10:37:57 --> Router Class Initialized
INFO - 2024-03-14 10:37:57 --> Output Class Initialized
INFO - 2024-03-14 10:37:57 --> Security Class Initialized
DEBUG - 2024-03-14 10:37:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:37:57 --> Input Class Initialized
INFO - 2024-03-14 10:37:57 --> Language Class Initialized
INFO - 2024-03-14 10:37:57 --> Language Class Initialized
INFO - 2024-03-14 10:37:57 --> Config Class Initialized
INFO - 2024-03-14 10:37:57 --> Loader Class Initialized
INFO - 2024-03-14 10:37:57 --> Helper loaded: url_helper
INFO - 2024-03-14 10:37:57 --> Helper loaded: file_helper
INFO - 2024-03-14 10:37:57 --> Helper loaded: form_helper
INFO - 2024-03-14 10:37:57 --> Helper loaded: my_helper
INFO - 2024-03-14 10:37:57 --> Database Driver Class Initialized
INFO - 2024-03-14 10:37:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:37:57 --> Controller Class Initialized
DEBUG - 2024-03-14 10:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 10:37:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:37:57 --> Final output sent to browser
DEBUG - 2024-03-14 10:37:57 --> Total execution time: 0.0439
INFO - 2024-03-14 10:40:49 --> Config Class Initialized
INFO - 2024-03-14 10:40:49 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:40:49 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:40:49 --> Utf8 Class Initialized
INFO - 2024-03-14 10:40:49 --> URI Class Initialized
INFO - 2024-03-14 10:40:49 --> Router Class Initialized
INFO - 2024-03-14 10:40:49 --> Output Class Initialized
INFO - 2024-03-14 10:40:49 --> Security Class Initialized
DEBUG - 2024-03-14 10:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:40:49 --> Input Class Initialized
INFO - 2024-03-14 10:40:49 --> Language Class Initialized
INFO - 2024-03-14 10:40:49 --> Language Class Initialized
INFO - 2024-03-14 10:40:49 --> Config Class Initialized
INFO - 2024-03-14 10:40:49 --> Loader Class Initialized
INFO - 2024-03-14 10:40:49 --> Helper loaded: url_helper
INFO - 2024-03-14 10:40:49 --> Helper loaded: file_helper
INFO - 2024-03-14 10:40:49 --> Helper loaded: form_helper
INFO - 2024-03-14 10:40:49 --> Helper loaded: my_helper
INFO - 2024-03-14 10:40:49 --> Database Driver Class Initialized
INFO - 2024-03-14 10:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:40:49 --> Controller Class Initialized
ERROR - 2024-03-14 10:40:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:40:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:40:53 --> Config Class Initialized
INFO - 2024-03-14 10:40:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:40:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:40:53 --> Utf8 Class Initialized
INFO - 2024-03-14 10:40:53 --> URI Class Initialized
INFO - 2024-03-14 10:40:53 --> Router Class Initialized
INFO - 2024-03-14 10:40:53 --> Output Class Initialized
INFO - 2024-03-14 10:40:53 --> Security Class Initialized
DEBUG - 2024-03-14 10:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:40:53 --> Input Class Initialized
INFO - 2024-03-14 10:40:53 --> Language Class Initialized
INFO - 2024-03-14 10:40:53 --> Language Class Initialized
INFO - 2024-03-14 10:40:53 --> Config Class Initialized
INFO - 2024-03-14 10:40:53 --> Loader Class Initialized
INFO - 2024-03-14 10:40:53 --> Helper loaded: url_helper
INFO - 2024-03-14 10:40:53 --> Helper loaded: file_helper
INFO - 2024-03-14 10:40:53 --> Helper loaded: form_helper
INFO - 2024-03-14 10:40:53 --> Helper loaded: my_helper
INFO - 2024-03-14 10:40:53 --> Database Driver Class Initialized
INFO - 2024-03-14 10:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:40:53 --> Controller Class Initialized
ERROR - 2024-03-14 10:40:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:40:53 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:40:55 --> Config Class Initialized
INFO - 2024-03-14 10:40:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:40:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:40:55 --> Utf8 Class Initialized
INFO - 2024-03-14 10:40:55 --> URI Class Initialized
INFO - 2024-03-14 10:40:55 --> Router Class Initialized
INFO - 2024-03-14 10:40:55 --> Output Class Initialized
INFO - 2024-03-14 10:40:55 --> Security Class Initialized
DEBUG - 2024-03-14 10:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:40:55 --> Input Class Initialized
INFO - 2024-03-14 10:40:55 --> Language Class Initialized
INFO - 2024-03-14 10:40:55 --> Language Class Initialized
INFO - 2024-03-14 10:40:55 --> Config Class Initialized
INFO - 2024-03-14 10:40:55 --> Loader Class Initialized
INFO - 2024-03-14 10:40:55 --> Helper loaded: url_helper
INFO - 2024-03-14 10:40:55 --> Helper loaded: file_helper
INFO - 2024-03-14 10:40:55 --> Helper loaded: form_helper
INFO - 2024-03-14 10:40:55 --> Helper loaded: my_helper
INFO - 2024-03-14 10:40:55 --> Database Driver Class Initialized
INFO - 2024-03-14 10:40:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:40:55 --> Controller Class Initialized
ERROR - 2024-03-14 10:40:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:40:55 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:40:59 --> Config Class Initialized
INFO - 2024-03-14 10:40:59 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:40:59 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:40:59 --> Utf8 Class Initialized
INFO - 2024-03-14 10:40:59 --> URI Class Initialized
INFO - 2024-03-14 10:40:59 --> Router Class Initialized
INFO - 2024-03-14 10:40:59 --> Output Class Initialized
INFO - 2024-03-14 10:40:59 --> Security Class Initialized
DEBUG - 2024-03-14 10:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:40:59 --> Input Class Initialized
INFO - 2024-03-14 10:40:59 --> Language Class Initialized
INFO - 2024-03-14 10:40:59 --> Language Class Initialized
INFO - 2024-03-14 10:40:59 --> Config Class Initialized
INFO - 2024-03-14 10:40:59 --> Loader Class Initialized
INFO - 2024-03-14 10:40:59 --> Helper loaded: url_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: file_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: form_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: my_helper
INFO - 2024-03-14 10:40:59 --> Database Driver Class Initialized
INFO - 2024-03-14 10:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:40:59 --> Controller Class Initialized
ERROR - 2024-03-14 10:40:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:40:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:40:59 --> Config Class Initialized
INFO - 2024-03-14 10:40:59 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:40:59 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:40:59 --> Utf8 Class Initialized
INFO - 2024-03-14 10:40:59 --> URI Class Initialized
INFO - 2024-03-14 10:40:59 --> Router Class Initialized
INFO - 2024-03-14 10:40:59 --> Output Class Initialized
INFO - 2024-03-14 10:40:59 --> Security Class Initialized
DEBUG - 2024-03-14 10:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:40:59 --> Input Class Initialized
INFO - 2024-03-14 10:40:59 --> Language Class Initialized
INFO - 2024-03-14 10:40:59 --> Language Class Initialized
INFO - 2024-03-14 10:40:59 --> Config Class Initialized
INFO - 2024-03-14 10:40:59 --> Loader Class Initialized
INFO - 2024-03-14 10:40:59 --> Helper loaded: url_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: file_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: form_helper
INFO - 2024-03-14 10:40:59 --> Helper loaded: my_helper
INFO - 2024-03-14 10:40:59 --> Database Driver Class Initialized
INFO - 2024-03-14 10:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:40:59 --> Controller Class Initialized
ERROR - 2024-03-14 10:40:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:40:59 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:00 --> Config Class Initialized
INFO - 2024-03-14 10:41:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:00 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:00 --> URI Class Initialized
INFO - 2024-03-14 10:41:00 --> Router Class Initialized
INFO - 2024-03-14 10:41:00 --> Output Class Initialized
INFO - 2024-03-14 10:41:00 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:00 --> Input Class Initialized
INFO - 2024-03-14 10:41:00 --> Language Class Initialized
INFO - 2024-03-14 10:41:00 --> Language Class Initialized
INFO - 2024-03-14 10:41:00 --> Config Class Initialized
INFO - 2024-03-14 10:41:00 --> Loader Class Initialized
INFO - 2024-03-14 10:41:00 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:00 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:00 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:00 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:00 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:00 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:00 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:01 --> Config Class Initialized
INFO - 2024-03-14 10:41:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:01 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:01 --> URI Class Initialized
INFO - 2024-03-14 10:41:01 --> Router Class Initialized
INFO - 2024-03-14 10:41:01 --> Output Class Initialized
INFO - 2024-03-14 10:41:01 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:01 --> Input Class Initialized
INFO - 2024-03-14 10:41:01 --> Language Class Initialized
INFO - 2024-03-14 10:41:01 --> Language Class Initialized
INFO - 2024-03-14 10:41:01 --> Config Class Initialized
INFO - 2024-03-14 10:41:01 --> Loader Class Initialized
INFO - 2024-03-14 10:41:01 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:01 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:01 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:01 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:01 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:01 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:01 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:08 --> Config Class Initialized
INFO - 2024-03-14 10:41:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:08 --> URI Class Initialized
INFO - 2024-03-14 10:41:08 --> Router Class Initialized
INFO - 2024-03-14 10:41:08 --> Output Class Initialized
INFO - 2024-03-14 10:41:08 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:08 --> Input Class Initialized
INFO - 2024-03-14 10:41:08 --> Language Class Initialized
INFO - 2024-03-14 10:41:08 --> Language Class Initialized
INFO - 2024-03-14 10:41:08 --> Config Class Initialized
INFO - 2024-03-14 10:41:08 --> Loader Class Initialized
INFO - 2024-03-14 10:41:08 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:08 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:08 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:08 --> Config Class Initialized
INFO - 2024-03-14 10:41:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:08 --> URI Class Initialized
INFO - 2024-03-14 10:41:08 --> Router Class Initialized
INFO - 2024-03-14 10:41:08 --> Output Class Initialized
INFO - 2024-03-14 10:41:08 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:08 --> Input Class Initialized
INFO - 2024-03-14 10:41:08 --> Language Class Initialized
INFO - 2024-03-14 10:41:08 --> Language Class Initialized
INFO - 2024-03-14 10:41:08 --> Config Class Initialized
INFO - 2024-03-14 10:41:08 --> Loader Class Initialized
INFO - 2024-03-14 10:41:08 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:08 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:08 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:08 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:08 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:09 --> Config Class Initialized
INFO - 2024-03-14 10:41:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:09 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:09 --> URI Class Initialized
INFO - 2024-03-14 10:41:09 --> Router Class Initialized
INFO - 2024-03-14 10:41:09 --> Output Class Initialized
INFO - 2024-03-14 10:41:09 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:09 --> Input Class Initialized
INFO - 2024-03-14 10:41:09 --> Language Class Initialized
INFO - 2024-03-14 10:41:09 --> Language Class Initialized
INFO - 2024-03-14 10:41:09 --> Config Class Initialized
INFO - 2024-03-14 10:41:09 --> Loader Class Initialized
INFO - 2024-03-14 10:41:09 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:09 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:09 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:09 --> Config Class Initialized
INFO - 2024-03-14 10:41:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:09 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:09 --> URI Class Initialized
INFO - 2024-03-14 10:41:09 --> Router Class Initialized
INFO - 2024-03-14 10:41:09 --> Output Class Initialized
INFO - 2024-03-14 10:41:09 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:09 --> Input Class Initialized
INFO - 2024-03-14 10:41:09 --> Language Class Initialized
INFO - 2024-03-14 10:41:09 --> Language Class Initialized
INFO - 2024-03-14 10:41:09 --> Config Class Initialized
INFO - 2024-03-14 10:41:09 --> Loader Class Initialized
INFO - 2024-03-14 10:41:09 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:09 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:09 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:09 --> Controller Class Initialized
ERROR - 2024-03-14 10:41:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:41:09 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:41:14 --> Config Class Initialized
INFO - 2024-03-14 10:41:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:14 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:14 --> URI Class Initialized
INFO - 2024-03-14 10:41:14 --> Router Class Initialized
INFO - 2024-03-14 10:41:14 --> Output Class Initialized
INFO - 2024-03-14 10:41:14 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:14 --> Input Class Initialized
INFO - 2024-03-14 10:41:14 --> Language Class Initialized
INFO - 2024-03-14 10:41:14 --> Language Class Initialized
INFO - 2024-03-14 10:41:14 --> Config Class Initialized
INFO - 2024-03-14 10:41:14 --> Loader Class Initialized
INFO - 2024-03-14 10:41:14 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:14 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:14 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:14 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:14 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:14 --> Controller Class Initialized
DEBUG - 2024-03-14 10:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:41:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:41:14 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:14 --> Total execution time: 0.0534
INFO - 2024-03-14 10:41:18 --> Config Class Initialized
INFO - 2024-03-14 10:41:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:18 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:18 --> URI Class Initialized
INFO - 2024-03-14 10:41:18 --> Router Class Initialized
INFO - 2024-03-14 10:41:18 --> Output Class Initialized
INFO - 2024-03-14 10:41:18 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:18 --> Input Class Initialized
INFO - 2024-03-14 10:41:18 --> Language Class Initialized
INFO - 2024-03-14 10:41:18 --> Language Class Initialized
INFO - 2024-03-14 10:41:18 --> Config Class Initialized
INFO - 2024-03-14 10:41:18 --> Loader Class Initialized
INFO - 2024-03-14 10:41:18 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:18 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:18 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:18 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:18 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:18 --> Controller Class Initialized
DEBUG - 2024-03-14 10:41:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:41:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:41:18 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:18 --> Total execution time: 0.0318
INFO - 2024-03-14 10:41:19 --> Config Class Initialized
INFO - 2024-03-14 10:41:19 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:19 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:19 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:19 --> URI Class Initialized
INFO - 2024-03-14 10:41:19 --> Router Class Initialized
INFO - 2024-03-14 10:41:19 --> Output Class Initialized
INFO - 2024-03-14 10:41:19 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:19 --> Input Class Initialized
INFO - 2024-03-14 10:41:19 --> Language Class Initialized
INFO - 2024-03-14 10:41:19 --> Language Class Initialized
INFO - 2024-03-14 10:41:19 --> Config Class Initialized
INFO - 2024-03-14 10:41:19 --> Loader Class Initialized
INFO - 2024-03-14 10:41:19 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:19 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:19 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:19 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:19 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:19 --> Controller Class Initialized
INFO - 2024-03-14 10:41:19 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:19 --> Total execution time: 0.0333
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:43 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:43 --> URI Class Initialized
INFO - 2024-03-14 10:41:43 --> Router Class Initialized
INFO - 2024-03-14 10:41:43 --> Output Class Initialized
INFO - 2024-03-14 10:41:43 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:43 --> Input Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Loader Class Initialized
INFO - 2024-03-14 10:41:43 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:43 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:43 --> Controller Class Initialized
INFO - 2024-03-14 10:41:43 --> Helper loaded: cookie_helper
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:43 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:43 --> URI Class Initialized
INFO - 2024-03-14 10:41:43 --> Router Class Initialized
INFO - 2024-03-14 10:41:43 --> Output Class Initialized
INFO - 2024-03-14 10:41:43 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:43 --> Input Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Loader Class Initialized
INFO - 2024-03-14 10:41:43 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:43 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:43 --> Controller Class Initialized
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:43 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:43 --> URI Class Initialized
INFO - 2024-03-14 10:41:43 --> Router Class Initialized
INFO - 2024-03-14 10:41:43 --> Output Class Initialized
INFO - 2024-03-14 10:41:43 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:43 --> Input Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Language Class Initialized
INFO - 2024-03-14 10:41:43 --> Config Class Initialized
INFO - 2024-03-14 10:41:43 --> Loader Class Initialized
INFO - 2024-03-14 10:41:43 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:43 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:43 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:43 --> Controller Class Initialized
DEBUG - 2024-03-14 10:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 10:41:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:41:43 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:43 --> Total execution time: 0.0395
INFO - 2024-03-14 10:41:48 --> Config Class Initialized
INFO - 2024-03-14 10:41:48 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:48 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:48 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:48 --> URI Class Initialized
INFO - 2024-03-14 10:41:48 --> Router Class Initialized
INFO - 2024-03-14 10:41:48 --> Output Class Initialized
INFO - 2024-03-14 10:41:48 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:48 --> Input Class Initialized
INFO - 2024-03-14 10:41:48 --> Language Class Initialized
INFO - 2024-03-14 10:41:48 --> Language Class Initialized
INFO - 2024-03-14 10:41:48 --> Config Class Initialized
INFO - 2024-03-14 10:41:48 --> Loader Class Initialized
INFO - 2024-03-14 10:41:48 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:48 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:48 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:48 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:48 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:48 --> Controller Class Initialized
INFO - 2024-03-14 10:41:48 --> Helper loaded: cookie_helper
INFO - 2024-03-14 10:41:48 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:48 --> Total execution time: 0.0869
INFO - 2024-03-14 10:41:49 --> Config Class Initialized
INFO - 2024-03-14 10:41:49 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:49 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:49 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:49 --> URI Class Initialized
INFO - 2024-03-14 10:41:49 --> Router Class Initialized
INFO - 2024-03-14 10:41:49 --> Output Class Initialized
INFO - 2024-03-14 10:41:49 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:49 --> Input Class Initialized
INFO - 2024-03-14 10:41:49 --> Language Class Initialized
INFO - 2024-03-14 10:41:49 --> Language Class Initialized
INFO - 2024-03-14 10:41:49 --> Config Class Initialized
INFO - 2024-03-14 10:41:49 --> Loader Class Initialized
INFO - 2024-03-14 10:41:49 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:49 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:49 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:49 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:49 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:49 --> Controller Class Initialized
DEBUG - 2024-03-14 10:41:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 10:41:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:41:49 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:49 --> Total execution time: 0.0326
INFO - 2024-03-14 10:41:59 --> Config Class Initialized
INFO - 2024-03-14 10:41:59 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:41:59 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:41:59 --> Utf8 Class Initialized
INFO - 2024-03-14 10:41:59 --> URI Class Initialized
INFO - 2024-03-14 10:41:59 --> Router Class Initialized
INFO - 2024-03-14 10:41:59 --> Output Class Initialized
INFO - 2024-03-14 10:41:59 --> Security Class Initialized
DEBUG - 2024-03-14 10:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:41:59 --> Input Class Initialized
INFO - 2024-03-14 10:41:59 --> Language Class Initialized
INFO - 2024-03-14 10:41:59 --> Language Class Initialized
INFO - 2024-03-14 10:41:59 --> Config Class Initialized
INFO - 2024-03-14 10:41:59 --> Loader Class Initialized
INFO - 2024-03-14 10:41:59 --> Helper loaded: url_helper
INFO - 2024-03-14 10:41:59 --> Helper loaded: file_helper
INFO - 2024-03-14 10:41:59 --> Helper loaded: form_helper
INFO - 2024-03-14 10:41:59 --> Helper loaded: my_helper
INFO - 2024-03-14 10:41:59 --> Database Driver Class Initialized
INFO - 2024-03-14 10:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:41:59 --> Controller Class Initialized
DEBUG - 2024-03-14 10:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:41:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:41:59 --> Final output sent to browser
DEBUG - 2024-03-14 10:41:59 --> Total execution time: 0.0489
INFO - 2024-03-14 10:42:40 --> Config Class Initialized
INFO - 2024-03-14 10:42:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:42:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:42:40 --> Utf8 Class Initialized
INFO - 2024-03-14 10:42:40 --> URI Class Initialized
INFO - 2024-03-14 10:42:40 --> Router Class Initialized
INFO - 2024-03-14 10:42:40 --> Output Class Initialized
INFO - 2024-03-14 10:42:40 --> Security Class Initialized
DEBUG - 2024-03-14 10:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:42:40 --> Input Class Initialized
INFO - 2024-03-14 10:42:40 --> Language Class Initialized
INFO - 2024-03-14 10:42:40 --> Language Class Initialized
INFO - 2024-03-14 10:42:40 --> Config Class Initialized
INFO - 2024-03-14 10:42:40 --> Loader Class Initialized
INFO - 2024-03-14 10:42:40 --> Helper loaded: url_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: file_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: form_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: my_helper
INFO - 2024-03-14 10:42:40 --> Database Driver Class Initialized
INFO - 2024-03-14 10:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:42:40 --> Controller Class Initialized
DEBUG - 2024-03-14 10:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 10:42:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:42:40 --> Final output sent to browser
DEBUG - 2024-03-14 10:42:40 --> Total execution time: 0.0369
INFO - 2024-03-14 10:42:40 --> Config Class Initialized
INFO - 2024-03-14 10:42:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:42:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:42:40 --> Utf8 Class Initialized
INFO - 2024-03-14 10:42:40 --> URI Class Initialized
INFO - 2024-03-14 10:42:40 --> Router Class Initialized
INFO - 2024-03-14 10:42:40 --> Output Class Initialized
INFO - 2024-03-14 10:42:40 --> Security Class Initialized
DEBUG - 2024-03-14 10:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:42:40 --> Input Class Initialized
INFO - 2024-03-14 10:42:40 --> Language Class Initialized
INFO - 2024-03-14 10:42:40 --> Language Class Initialized
INFO - 2024-03-14 10:42:40 --> Config Class Initialized
INFO - 2024-03-14 10:42:40 --> Loader Class Initialized
INFO - 2024-03-14 10:42:40 --> Helper loaded: url_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: file_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: form_helper
INFO - 2024-03-14 10:42:40 --> Helper loaded: my_helper
INFO - 2024-03-14 10:42:40 --> Database Driver Class Initialized
INFO - 2024-03-14 10:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:42:40 --> Controller Class Initialized
INFO - 2024-03-14 10:42:45 --> Config Class Initialized
INFO - 2024-03-14 10:42:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:42:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:42:45 --> Utf8 Class Initialized
INFO - 2024-03-14 10:42:45 --> URI Class Initialized
INFO - 2024-03-14 10:42:45 --> Router Class Initialized
INFO - 2024-03-14 10:42:45 --> Output Class Initialized
INFO - 2024-03-14 10:42:45 --> Security Class Initialized
DEBUG - 2024-03-14 10:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:42:45 --> Input Class Initialized
INFO - 2024-03-14 10:42:45 --> Language Class Initialized
INFO - 2024-03-14 10:42:45 --> Language Class Initialized
INFO - 2024-03-14 10:42:45 --> Config Class Initialized
INFO - 2024-03-14 10:42:45 --> Loader Class Initialized
INFO - 2024-03-14 10:42:45 --> Helper loaded: url_helper
INFO - 2024-03-14 10:42:45 --> Helper loaded: file_helper
INFO - 2024-03-14 10:42:45 --> Helper loaded: form_helper
INFO - 2024-03-14 10:42:45 --> Helper loaded: my_helper
INFO - 2024-03-14 10:42:45 --> Database Driver Class Initialized
INFO - 2024-03-14 10:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:42:45 --> Controller Class Initialized
INFO - 2024-03-14 10:42:45 --> Final output sent to browser
DEBUG - 2024-03-14 10:42:45 --> Total execution time: 0.1189
INFO - 2024-03-14 10:43:01 --> Config Class Initialized
INFO - 2024-03-14 10:43:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:43:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:43:01 --> Utf8 Class Initialized
INFO - 2024-03-14 10:43:01 --> URI Class Initialized
INFO - 2024-03-14 10:43:01 --> Router Class Initialized
INFO - 2024-03-14 10:43:01 --> Output Class Initialized
INFO - 2024-03-14 10:43:01 --> Security Class Initialized
DEBUG - 2024-03-14 10:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:43:01 --> Input Class Initialized
INFO - 2024-03-14 10:43:01 --> Language Class Initialized
INFO - 2024-03-14 10:43:01 --> Language Class Initialized
INFO - 2024-03-14 10:43:01 --> Config Class Initialized
INFO - 2024-03-14 10:43:01 --> Loader Class Initialized
INFO - 2024-03-14 10:43:01 --> Helper loaded: url_helper
INFO - 2024-03-14 10:43:01 --> Helper loaded: file_helper
INFO - 2024-03-14 10:43:01 --> Helper loaded: form_helper
INFO - 2024-03-14 10:43:01 --> Helper loaded: my_helper
INFO - 2024-03-14 10:43:01 --> Database Driver Class Initialized
INFO - 2024-03-14 10:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:43:01 --> Controller Class Initialized
DEBUG - 2024-03-14 10:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:43:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:43:01 --> Final output sent to browser
DEBUG - 2024-03-14 10:43:01 --> Total execution time: 0.0923
INFO - 2024-03-14 10:43:03 --> Config Class Initialized
INFO - 2024-03-14 10:43:03 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:43:03 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:43:03 --> Utf8 Class Initialized
INFO - 2024-03-14 10:43:03 --> URI Class Initialized
INFO - 2024-03-14 10:43:03 --> Router Class Initialized
INFO - 2024-03-14 10:43:03 --> Output Class Initialized
INFO - 2024-03-14 10:43:03 --> Security Class Initialized
DEBUG - 2024-03-14 10:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:43:03 --> Input Class Initialized
INFO - 2024-03-14 10:43:03 --> Language Class Initialized
INFO - 2024-03-14 10:43:03 --> Language Class Initialized
INFO - 2024-03-14 10:43:03 --> Config Class Initialized
INFO - 2024-03-14 10:43:03 --> Loader Class Initialized
INFO - 2024-03-14 10:43:03 --> Helper loaded: url_helper
INFO - 2024-03-14 10:43:03 --> Helper loaded: file_helper
INFO - 2024-03-14 10:43:03 --> Helper loaded: form_helper
INFO - 2024-03-14 10:43:03 --> Helper loaded: my_helper
INFO - 2024-03-14 10:43:03 --> Database Driver Class Initialized
INFO - 2024-03-14 10:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:43:03 --> Controller Class Initialized
DEBUG - 2024-03-14 10:43:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:43:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:43:03 --> Final output sent to browser
DEBUG - 2024-03-14 10:43:03 --> Total execution time: 0.0350
INFO - 2024-03-14 10:43:05 --> Config Class Initialized
INFO - 2024-03-14 10:43:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:43:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:43:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:43:05 --> URI Class Initialized
INFO - 2024-03-14 10:43:05 --> Router Class Initialized
INFO - 2024-03-14 10:43:05 --> Output Class Initialized
INFO - 2024-03-14 10:43:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:43:05 --> Input Class Initialized
INFO - 2024-03-14 10:43:05 --> Language Class Initialized
INFO - 2024-03-14 10:43:05 --> Language Class Initialized
INFO - 2024-03-14 10:43:05 --> Config Class Initialized
INFO - 2024-03-14 10:43:05 --> Loader Class Initialized
INFO - 2024-03-14 10:43:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:43:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:43:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:43:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:43:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:43:05 --> Controller Class Initialized
INFO - 2024-03-14 10:43:05 --> Final output sent to browser
DEBUG - 2024-03-14 10:43:05 --> Total execution time: 0.0443
INFO - 2024-03-14 10:45:19 --> Config Class Initialized
INFO - 2024-03-14 10:45:19 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:19 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:19 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:19 --> URI Class Initialized
INFO - 2024-03-14 10:45:19 --> Router Class Initialized
INFO - 2024-03-14 10:45:19 --> Output Class Initialized
INFO - 2024-03-14 10:45:19 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:19 --> Input Class Initialized
INFO - 2024-03-14 10:45:19 --> Language Class Initialized
INFO - 2024-03-14 10:45:19 --> Language Class Initialized
INFO - 2024-03-14 10:45:19 --> Config Class Initialized
INFO - 2024-03-14 10:45:19 --> Loader Class Initialized
INFO - 2024-03-14 10:45:19 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:19 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:19 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:19 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:19 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:19 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:19 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:21 --> Config Class Initialized
INFO - 2024-03-14 10:45:21 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:21 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:21 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:21 --> URI Class Initialized
INFO - 2024-03-14 10:45:21 --> Router Class Initialized
INFO - 2024-03-14 10:45:21 --> Output Class Initialized
INFO - 2024-03-14 10:45:21 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:21 --> Input Class Initialized
INFO - 2024-03-14 10:45:21 --> Language Class Initialized
INFO - 2024-03-14 10:45:21 --> Language Class Initialized
INFO - 2024-03-14 10:45:21 --> Config Class Initialized
INFO - 2024-03-14 10:45:21 --> Loader Class Initialized
INFO - 2024-03-14 10:45:21 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:21 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:21 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:21 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:21 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:21 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:21 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:22 --> Config Class Initialized
INFO - 2024-03-14 10:45:22 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:22 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:22 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:22 --> URI Class Initialized
INFO - 2024-03-14 10:45:22 --> Router Class Initialized
INFO - 2024-03-14 10:45:22 --> Output Class Initialized
INFO - 2024-03-14 10:45:22 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:22 --> Input Class Initialized
INFO - 2024-03-14 10:45:22 --> Language Class Initialized
INFO - 2024-03-14 10:45:22 --> Language Class Initialized
INFO - 2024-03-14 10:45:22 --> Config Class Initialized
INFO - 2024-03-14 10:45:22 --> Loader Class Initialized
INFO - 2024-03-14 10:45:22 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:22 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:22 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:22 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:22 --> Config Class Initialized
INFO - 2024-03-14 10:45:22 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:22 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:22 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:22 --> URI Class Initialized
INFO - 2024-03-14 10:45:22 --> Router Class Initialized
INFO - 2024-03-14 10:45:22 --> Output Class Initialized
INFO - 2024-03-14 10:45:22 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:22 --> Input Class Initialized
INFO - 2024-03-14 10:45:22 --> Language Class Initialized
INFO - 2024-03-14 10:45:22 --> Language Class Initialized
INFO - 2024-03-14 10:45:22 --> Config Class Initialized
INFO - 2024-03-14 10:45:22 --> Loader Class Initialized
INFO - 2024-03-14 10:45:22 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:22 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:22 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:22 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:22 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:23 --> Config Class Initialized
INFO - 2024-03-14 10:45:23 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:23 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:23 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:23 --> URI Class Initialized
INFO - 2024-03-14 10:45:23 --> Router Class Initialized
INFO - 2024-03-14 10:45:23 --> Output Class Initialized
INFO - 2024-03-14 10:45:23 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:23 --> Input Class Initialized
INFO - 2024-03-14 10:45:23 --> Language Class Initialized
INFO - 2024-03-14 10:45:23 --> Language Class Initialized
INFO - 2024-03-14 10:45:23 --> Config Class Initialized
INFO - 2024-03-14 10:45:23 --> Loader Class Initialized
INFO - 2024-03-14 10:45:23 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:23 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:23 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:23 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:23 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:23 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:23 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:44 --> Config Class Initialized
INFO - 2024-03-14 10:45:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:44 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:44 --> URI Class Initialized
INFO - 2024-03-14 10:45:44 --> Router Class Initialized
INFO - 2024-03-14 10:45:44 --> Output Class Initialized
INFO - 2024-03-14 10:45:44 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:44 --> Input Class Initialized
INFO - 2024-03-14 10:45:44 --> Language Class Initialized
INFO - 2024-03-14 10:45:44 --> Language Class Initialized
INFO - 2024-03-14 10:45:44 --> Config Class Initialized
INFO - 2024-03-14 10:45:44 --> Loader Class Initialized
INFO - 2024-03-14 10:45:44 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:44 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:44 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:44 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:44 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:44 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:44 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:45 --> Config Class Initialized
INFO - 2024-03-14 10:45:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:45 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:45 --> URI Class Initialized
INFO - 2024-03-14 10:45:45 --> Router Class Initialized
INFO - 2024-03-14 10:45:45 --> Output Class Initialized
INFO - 2024-03-14 10:45:45 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:45 --> Input Class Initialized
INFO - 2024-03-14 10:45:45 --> Language Class Initialized
INFO - 2024-03-14 10:45:45 --> Language Class Initialized
INFO - 2024-03-14 10:45:45 --> Config Class Initialized
INFO - 2024-03-14 10:45:45 --> Loader Class Initialized
INFO - 2024-03-14 10:45:45 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:45 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:45 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:45 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:45:45 --> Config Class Initialized
INFO - 2024-03-14 10:45:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:45:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:45:45 --> Utf8 Class Initialized
INFO - 2024-03-14 10:45:45 --> URI Class Initialized
INFO - 2024-03-14 10:45:45 --> Router Class Initialized
INFO - 2024-03-14 10:45:45 --> Output Class Initialized
INFO - 2024-03-14 10:45:45 --> Security Class Initialized
DEBUG - 2024-03-14 10:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:45:45 --> Input Class Initialized
INFO - 2024-03-14 10:45:45 --> Language Class Initialized
INFO - 2024-03-14 10:45:45 --> Language Class Initialized
INFO - 2024-03-14 10:45:45 --> Config Class Initialized
INFO - 2024-03-14 10:45:45 --> Loader Class Initialized
INFO - 2024-03-14 10:45:45 --> Helper loaded: url_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: file_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: form_helper
INFO - 2024-03-14 10:45:45 --> Helper loaded: my_helper
INFO - 2024-03-14 10:45:45 --> Database Driver Class Initialized
INFO - 2024-03-14 10:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:45:45 --> Controller Class Initialized
ERROR - 2024-03-14 10:45:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:45:45 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:46:05 --> Config Class Initialized
INFO - 2024-03-14 10:46:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:46:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:46:05 --> Utf8 Class Initialized
INFO - 2024-03-14 10:46:05 --> URI Class Initialized
INFO - 2024-03-14 10:46:05 --> Router Class Initialized
INFO - 2024-03-14 10:46:05 --> Output Class Initialized
INFO - 2024-03-14 10:46:05 --> Security Class Initialized
DEBUG - 2024-03-14 10:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:46:05 --> Input Class Initialized
INFO - 2024-03-14 10:46:05 --> Language Class Initialized
INFO - 2024-03-14 10:46:05 --> Language Class Initialized
INFO - 2024-03-14 10:46:05 --> Config Class Initialized
INFO - 2024-03-14 10:46:05 --> Loader Class Initialized
INFO - 2024-03-14 10:46:05 --> Helper loaded: url_helper
INFO - 2024-03-14 10:46:05 --> Helper loaded: file_helper
INFO - 2024-03-14 10:46:05 --> Helper loaded: form_helper
INFO - 2024-03-14 10:46:05 --> Helper loaded: my_helper
INFO - 2024-03-14 10:46:05 --> Database Driver Class Initialized
INFO - 2024-03-14 10:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:46:05 --> Controller Class Initialized
ERROR - 2024-03-14 10:46:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 's inconsistently applied in your writing. Surprisingly, in crafting persuasive a' at line 1 - Invalid query: INSERT INTO t_nilai_cat (tasm,jenis,id_guru_mapel, id_mapel_kd, id_siswa, nilai, nilai_mid) VALUES ('20232', 'c', '23', '10', '8', '-', 'You are showing progress in your reading comprehension skills, with efforts made to understand the main ideas and details in reading assignments. You have a good grasp of vocabulary and context within texts. In terms of passive voice, you are beginning to grasp its usage, although it's inconsistently applied in your writing. Surprisingly, in crafting persuasive articles, you construct well-organized arguments with clear analysis and compelling evidence, demonstrating a persuasive writing style. However, when it comes to persuasive techniques, you show a limited understanding and application.')
INFO - 2024-03-14 10:46:06 --> Language file loaded: language/english/db_lang.php
INFO - 2024-03-14 10:46:08 --> Config Class Initialized
INFO - 2024-03-14 10:46:08 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:46:08 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:46:08 --> Utf8 Class Initialized
INFO - 2024-03-14 10:46:08 --> URI Class Initialized
INFO - 2024-03-14 10:46:09 --> Router Class Initialized
INFO - 2024-03-14 10:46:09 --> Output Class Initialized
INFO - 2024-03-14 10:46:09 --> Security Class Initialized
DEBUG - 2024-03-14 10:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:46:09 --> Input Class Initialized
INFO - 2024-03-14 10:46:09 --> Language Class Initialized
INFO - 2024-03-14 10:46:09 --> Language Class Initialized
INFO - 2024-03-14 10:46:09 --> Config Class Initialized
INFO - 2024-03-14 10:46:09 --> Loader Class Initialized
INFO - 2024-03-14 10:46:09 --> Helper loaded: url_helper
INFO - 2024-03-14 10:46:09 --> Helper loaded: file_helper
INFO - 2024-03-14 10:46:09 --> Helper loaded: form_helper
INFO - 2024-03-14 10:46:09 --> Helper loaded: my_helper
INFO - 2024-03-14 10:46:09 --> Database Driver Class Initialized
INFO - 2024-03-14 10:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:46:09 --> Controller Class Initialized
DEBUG - 2024-03-14 10:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:46:09 --> Final output sent to browser
DEBUG - 2024-03-14 10:46:09 --> Total execution time: 0.0728
INFO - 2024-03-14 10:46:11 --> Config Class Initialized
INFO - 2024-03-14 10:46:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:46:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:46:11 --> Utf8 Class Initialized
INFO - 2024-03-14 10:46:11 --> URI Class Initialized
INFO - 2024-03-14 10:46:11 --> Router Class Initialized
INFO - 2024-03-14 10:46:11 --> Output Class Initialized
INFO - 2024-03-14 10:46:11 --> Security Class Initialized
DEBUG - 2024-03-14 10:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:46:11 --> Input Class Initialized
INFO - 2024-03-14 10:46:11 --> Language Class Initialized
INFO - 2024-03-14 10:46:11 --> Language Class Initialized
INFO - 2024-03-14 10:46:11 --> Config Class Initialized
INFO - 2024-03-14 10:46:11 --> Loader Class Initialized
INFO - 2024-03-14 10:46:11 --> Helper loaded: url_helper
INFO - 2024-03-14 10:46:11 --> Helper loaded: file_helper
INFO - 2024-03-14 10:46:11 --> Helper loaded: form_helper
INFO - 2024-03-14 10:46:11 --> Helper loaded: my_helper
INFO - 2024-03-14 10:46:11 --> Database Driver Class Initialized
INFO - 2024-03-14 10:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:46:11 --> Controller Class Initialized
DEBUG - 2024-03-14 10:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:46:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:46:11 --> Final output sent to browser
DEBUG - 2024-03-14 10:46:11 --> Total execution time: 0.1171
INFO - 2024-03-14 10:46:13 --> Config Class Initialized
INFO - 2024-03-14 10:46:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:46:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:46:13 --> Utf8 Class Initialized
INFO - 2024-03-14 10:46:13 --> URI Class Initialized
INFO - 2024-03-14 10:46:13 --> Router Class Initialized
INFO - 2024-03-14 10:46:13 --> Output Class Initialized
INFO - 2024-03-14 10:46:13 --> Security Class Initialized
DEBUG - 2024-03-14 10:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:46:13 --> Input Class Initialized
INFO - 2024-03-14 10:46:13 --> Language Class Initialized
INFO - 2024-03-14 10:46:13 --> Language Class Initialized
INFO - 2024-03-14 10:46:13 --> Config Class Initialized
INFO - 2024-03-14 10:46:13 --> Loader Class Initialized
INFO - 2024-03-14 10:46:13 --> Helper loaded: url_helper
INFO - 2024-03-14 10:46:13 --> Helper loaded: file_helper
INFO - 2024-03-14 10:46:13 --> Helper loaded: form_helper
INFO - 2024-03-14 10:46:13 --> Helper loaded: my_helper
INFO - 2024-03-14 10:46:13 --> Database Driver Class Initialized
INFO - 2024-03-14 10:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:46:13 --> Controller Class Initialized
INFO - 2024-03-14 10:46:13 --> Final output sent to browser
DEBUG - 2024-03-14 10:46:13 --> Total execution time: 0.0322
INFO - 2024-03-14 10:46:18 --> Config Class Initialized
INFO - 2024-03-14 10:46:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:46:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:46:18 --> Utf8 Class Initialized
INFO - 2024-03-14 10:46:18 --> URI Class Initialized
INFO - 2024-03-14 10:46:18 --> Router Class Initialized
INFO - 2024-03-14 10:46:18 --> Output Class Initialized
INFO - 2024-03-14 10:46:18 --> Security Class Initialized
DEBUG - 2024-03-14 10:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:46:18 --> Input Class Initialized
INFO - 2024-03-14 10:46:18 --> Language Class Initialized
INFO - 2024-03-14 10:46:18 --> Language Class Initialized
INFO - 2024-03-14 10:46:18 --> Config Class Initialized
INFO - 2024-03-14 10:46:18 --> Loader Class Initialized
INFO - 2024-03-14 10:46:18 --> Helper loaded: url_helper
INFO - 2024-03-14 10:46:18 --> Helper loaded: file_helper
INFO - 2024-03-14 10:46:18 --> Helper loaded: form_helper
INFO - 2024-03-14 10:46:18 --> Helper loaded: my_helper
INFO - 2024-03-14 10:46:18 --> Database Driver Class Initialized
INFO - 2024-03-14 10:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:46:18 --> Controller Class Initialized
INFO - 2024-03-14 10:49:47 --> Config Class Initialized
INFO - 2024-03-14 10:49:47 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:49:47 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:49:47 --> Utf8 Class Initialized
INFO - 2024-03-14 10:49:47 --> URI Class Initialized
INFO - 2024-03-14 10:49:47 --> Router Class Initialized
INFO - 2024-03-14 10:49:47 --> Output Class Initialized
INFO - 2024-03-14 10:49:47 --> Security Class Initialized
DEBUG - 2024-03-14 10:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:49:47 --> Input Class Initialized
INFO - 2024-03-14 10:49:47 --> Language Class Initialized
INFO - 2024-03-14 10:49:47 --> Language Class Initialized
INFO - 2024-03-14 10:49:47 --> Config Class Initialized
INFO - 2024-03-14 10:49:47 --> Loader Class Initialized
INFO - 2024-03-14 10:49:47 --> Helper loaded: url_helper
INFO - 2024-03-14 10:49:47 --> Helper loaded: file_helper
INFO - 2024-03-14 10:49:47 --> Helper loaded: form_helper
INFO - 2024-03-14 10:49:47 --> Helper loaded: my_helper
INFO - 2024-03-14 10:49:47 --> Database Driver Class Initialized
INFO - 2024-03-14 10:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:49:47 --> Controller Class Initialized
DEBUG - 2024-03-14 10:49:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/form.php
DEBUG - 2024-03-14 10:49:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:49:47 --> Final output sent to browser
DEBUG - 2024-03-14 10:49:47 --> Total execution time: 0.0317
INFO - 2024-03-14 10:49:54 --> Config Class Initialized
INFO - 2024-03-14 10:49:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:49:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:49:54 --> Utf8 Class Initialized
INFO - 2024-03-14 10:49:54 --> URI Class Initialized
INFO - 2024-03-14 10:49:54 --> Router Class Initialized
INFO - 2024-03-14 10:49:54 --> Output Class Initialized
INFO - 2024-03-14 10:49:54 --> Security Class Initialized
DEBUG - 2024-03-14 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:49:54 --> Input Class Initialized
INFO - 2024-03-14 10:49:54 --> Language Class Initialized
INFO - 2024-03-14 10:49:54 --> Language Class Initialized
INFO - 2024-03-14 10:49:54 --> Config Class Initialized
INFO - 2024-03-14 10:49:54 --> Loader Class Initialized
INFO - 2024-03-14 10:49:54 --> Helper loaded: url_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: file_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: form_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: my_helper
INFO - 2024-03-14 10:49:54 --> Database Driver Class Initialized
INFO - 2024-03-14 10:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:49:54 --> Controller Class Initialized
INFO - 2024-03-14 10:49:54 --> Config Class Initialized
INFO - 2024-03-14 10:49:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:49:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:49:54 --> Utf8 Class Initialized
INFO - 2024-03-14 10:49:54 --> URI Class Initialized
INFO - 2024-03-14 10:49:54 --> Router Class Initialized
INFO - 2024-03-14 10:49:54 --> Output Class Initialized
INFO - 2024-03-14 10:49:54 --> Security Class Initialized
DEBUG - 2024-03-14 10:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:49:54 --> Input Class Initialized
INFO - 2024-03-14 10:49:54 --> Language Class Initialized
INFO - 2024-03-14 10:49:54 --> Language Class Initialized
INFO - 2024-03-14 10:49:54 --> Config Class Initialized
INFO - 2024-03-14 10:49:54 --> Loader Class Initialized
INFO - 2024-03-14 10:49:54 --> Helper loaded: url_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: file_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: form_helper
INFO - 2024-03-14 10:49:54 --> Helper loaded: my_helper
INFO - 2024-03-14 10:49:54 --> Database Driver Class Initialized
INFO - 2024-03-14 10:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:49:54 --> Controller Class Initialized
DEBUG - 2024-03-14 10:49:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:49:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:49:54 --> Final output sent to browser
DEBUG - 2024-03-14 10:49:54 --> Total execution time: 0.0384
INFO - 2024-03-14 10:49:57 --> Config Class Initialized
INFO - 2024-03-14 10:49:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:49:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:49:57 --> Utf8 Class Initialized
INFO - 2024-03-14 10:49:57 --> URI Class Initialized
INFO - 2024-03-14 10:49:57 --> Router Class Initialized
INFO - 2024-03-14 10:49:57 --> Output Class Initialized
INFO - 2024-03-14 10:49:57 --> Security Class Initialized
DEBUG - 2024-03-14 10:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:49:57 --> Input Class Initialized
INFO - 2024-03-14 10:49:57 --> Language Class Initialized
INFO - 2024-03-14 10:49:57 --> Language Class Initialized
INFO - 2024-03-14 10:49:57 --> Config Class Initialized
INFO - 2024-03-14 10:49:57 --> Loader Class Initialized
INFO - 2024-03-14 10:49:57 --> Helper loaded: url_helper
INFO - 2024-03-14 10:49:57 --> Helper loaded: file_helper
INFO - 2024-03-14 10:49:57 --> Helper loaded: form_helper
INFO - 2024-03-14 10:49:57 --> Helper loaded: my_helper
INFO - 2024-03-14 10:49:57 --> Database Driver Class Initialized
INFO - 2024-03-14 10:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:49:57 --> Controller Class Initialized
INFO - 2024-03-14 10:49:57 --> Final output sent to browser
DEBUG - 2024-03-14 10:49:57 --> Total execution time: 0.0670
INFO - 2024-03-14 10:50:04 --> Config Class Initialized
INFO - 2024-03-14 10:50:04 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:50:04 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:50:04 --> Utf8 Class Initialized
INFO - 2024-03-14 10:50:04 --> URI Class Initialized
DEBUG - 2024-03-14 10:50:04 --> No URI present. Default controller set.
INFO - 2024-03-14 10:50:04 --> Router Class Initialized
INFO - 2024-03-14 10:50:04 --> Output Class Initialized
INFO - 2024-03-14 10:50:04 --> Security Class Initialized
DEBUG - 2024-03-14 10:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:50:04 --> Input Class Initialized
INFO - 2024-03-14 10:50:04 --> Language Class Initialized
INFO - 2024-03-14 10:50:04 --> Language Class Initialized
INFO - 2024-03-14 10:50:04 --> Config Class Initialized
INFO - 2024-03-14 10:50:04 --> Loader Class Initialized
INFO - 2024-03-14 10:50:04 --> Helper loaded: url_helper
INFO - 2024-03-14 10:50:04 --> Helper loaded: file_helper
INFO - 2024-03-14 10:50:04 --> Helper loaded: form_helper
INFO - 2024-03-14 10:50:04 --> Helper loaded: my_helper
INFO - 2024-03-14 10:50:04 --> Database Driver Class Initialized
INFO - 2024-03-14 10:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:50:04 --> Controller Class Initialized
DEBUG - 2024-03-14 10:50:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 10:50:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:50:04 --> Final output sent to browser
DEBUG - 2024-03-14 10:50:04 --> Total execution time: 0.0469
INFO - 2024-03-14 10:54:31 --> Config Class Initialized
INFO - 2024-03-14 10:54:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:54:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:54:31 --> Utf8 Class Initialized
INFO - 2024-03-14 10:54:31 --> URI Class Initialized
INFO - 2024-03-14 10:54:31 --> Router Class Initialized
INFO - 2024-03-14 10:54:31 --> Output Class Initialized
INFO - 2024-03-14 10:54:31 --> Security Class Initialized
DEBUG - 2024-03-14 10:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:54:31 --> Input Class Initialized
INFO - 2024-03-14 10:54:31 --> Language Class Initialized
INFO - 2024-03-14 10:54:31 --> Language Class Initialized
INFO - 2024-03-14 10:54:31 --> Config Class Initialized
INFO - 2024-03-14 10:54:31 --> Loader Class Initialized
INFO - 2024-03-14 10:54:31 --> Helper loaded: url_helper
INFO - 2024-03-14 10:54:31 --> Helper loaded: file_helper
INFO - 2024-03-14 10:54:31 --> Helper loaded: form_helper
INFO - 2024-03-14 10:54:31 --> Helper loaded: my_helper
INFO - 2024-03-14 10:54:31 --> Database Driver Class Initialized
INFO - 2024-03-14 10:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:54:31 --> Controller Class Initialized
DEBUG - 2024-03-14 10:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 10:54:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:54:31 --> Final output sent to browser
DEBUG - 2024-03-14 10:54:31 --> Total execution time: 0.0339
INFO - 2024-03-14 10:54:55 --> Config Class Initialized
INFO - 2024-03-14 10:54:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:54:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:54:55 --> Utf8 Class Initialized
INFO - 2024-03-14 10:54:55 --> URI Class Initialized
INFO - 2024-03-14 10:54:55 --> Router Class Initialized
INFO - 2024-03-14 10:54:55 --> Output Class Initialized
INFO - 2024-03-14 10:54:55 --> Security Class Initialized
DEBUG - 2024-03-14 10:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:54:55 --> Input Class Initialized
INFO - 2024-03-14 10:54:55 --> Language Class Initialized
INFO - 2024-03-14 10:54:55 --> Language Class Initialized
INFO - 2024-03-14 10:54:55 --> Config Class Initialized
INFO - 2024-03-14 10:54:55 --> Loader Class Initialized
INFO - 2024-03-14 10:54:55 --> Helper loaded: url_helper
INFO - 2024-03-14 10:54:55 --> Helper loaded: file_helper
INFO - 2024-03-14 10:54:55 --> Helper loaded: form_helper
INFO - 2024-03-14 10:54:55 --> Helper loaded: my_helper
INFO - 2024-03-14 10:54:55 --> Database Driver Class Initialized
INFO - 2024-03-14 10:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:54:55 --> Controller Class Initialized
DEBUG - 2024-03-14 10:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 10:54:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 10:54:55 --> Final output sent to browser
DEBUG - 2024-03-14 10:54:55 --> Total execution time: 0.0684
INFO - 2024-03-14 10:54:57 --> Config Class Initialized
INFO - 2024-03-14 10:54:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 10:54:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 10:54:57 --> Utf8 Class Initialized
INFO - 2024-03-14 10:54:57 --> URI Class Initialized
INFO - 2024-03-14 10:54:57 --> Router Class Initialized
INFO - 2024-03-14 10:54:57 --> Output Class Initialized
INFO - 2024-03-14 10:54:57 --> Security Class Initialized
DEBUG - 2024-03-14 10:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 10:54:57 --> Input Class Initialized
INFO - 2024-03-14 10:54:57 --> Language Class Initialized
INFO - 2024-03-14 10:54:57 --> Language Class Initialized
INFO - 2024-03-14 10:54:57 --> Config Class Initialized
INFO - 2024-03-14 10:54:57 --> Loader Class Initialized
INFO - 2024-03-14 10:54:57 --> Helper loaded: url_helper
INFO - 2024-03-14 10:54:57 --> Helper loaded: file_helper
INFO - 2024-03-14 10:54:57 --> Helper loaded: form_helper
INFO - 2024-03-14 10:54:57 --> Helper loaded: my_helper
INFO - 2024-03-14 10:54:57 --> Database Driver Class Initialized
INFO - 2024-03-14 10:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 10:54:57 --> Controller Class Initialized
INFO - 2024-03-14 10:54:57 --> Final output sent to browser
DEBUG - 2024-03-14 10:54:57 --> Total execution time: 0.0369
INFO - 2024-03-14 14:53:36 --> Config Class Initialized
INFO - 2024-03-14 14:53:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:36 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:36 --> URI Class Initialized
INFO - 2024-03-14 14:53:36 --> Router Class Initialized
INFO - 2024-03-14 14:53:36 --> Output Class Initialized
INFO - 2024-03-14 14:53:36 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:36 --> Input Class Initialized
INFO - 2024-03-14 14:53:36 --> Language Class Initialized
INFO - 2024-03-14 14:53:36 --> Language Class Initialized
INFO - 2024-03-14 14:53:36 --> Config Class Initialized
INFO - 2024-03-14 14:53:36 --> Loader Class Initialized
INFO - 2024-03-14 14:53:36 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:36 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:36 --> Controller Class Initialized
INFO - 2024-03-14 14:53:36 --> Config Class Initialized
INFO - 2024-03-14 14:53:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:36 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:36 --> URI Class Initialized
INFO - 2024-03-14 14:53:36 --> Router Class Initialized
INFO - 2024-03-14 14:53:36 --> Output Class Initialized
INFO - 2024-03-14 14:53:36 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:36 --> Input Class Initialized
INFO - 2024-03-14 14:53:36 --> Language Class Initialized
INFO - 2024-03-14 14:53:36 --> Language Class Initialized
INFO - 2024-03-14 14:53:36 --> Config Class Initialized
INFO - 2024-03-14 14:53:36 --> Loader Class Initialized
INFO - 2024-03-14 14:53:36 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:36 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:36 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:36 --> Controller Class Initialized
DEBUG - 2024-03-14 14:53:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 14:53:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 14:53:36 --> Final output sent to browser
DEBUG - 2024-03-14 14:53:36 --> Total execution time: 0.0792
INFO - 2024-03-14 14:53:38 --> Config Class Initialized
INFO - 2024-03-14 14:53:38 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:38 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:38 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:38 --> URI Class Initialized
INFO - 2024-03-14 14:53:38 --> Router Class Initialized
INFO - 2024-03-14 14:53:38 --> Output Class Initialized
INFO - 2024-03-14 14:53:38 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:38 --> Input Class Initialized
INFO - 2024-03-14 14:53:38 --> Language Class Initialized
INFO - 2024-03-14 14:53:38 --> Language Class Initialized
INFO - 2024-03-14 14:53:38 --> Config Class Initialized
INFO - 2024-03-14 14:53:38 --> Loader Class Initialized
INFO - 2024-03-14 14:53:38 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:38 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:38 --> Controller Class Initialized
INFO - 2024-03-14 14:53:38 --> Helper loaded: cookie_helper
INFO - 2024-03-14 14:53:38 --> Final output sent to browser
DEBUG - 2024-03-14 14:53:38 --> Total execution time: 0.0334
INFO - 2024-03-14 14:53:38 --> Config Class Initialized
INFO - 2024-03-14 14:53:38 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:38 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:38 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:38 --> URI Class Initialized
INFO - 2024-03-14 14:53:38 --> Router Class Initialized
INFO - 2024-03-14 14:53:38 --> Output Class Initialized
INFO - 2024-03-14 14:53:38 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:38 --> Input Class Initialized
INFO - 2024-03-14 14:53:38 --> Language Class Initialized
INFO - 2024-03-14 14:53:38 --> Language Class Initialized
INFO - 2024-03-14 14:53:38 --> Config Class Initialized
INFO - 2024-03-14 14:53:38 --> Loader Class Initialized
INFO - 2024-03-14 14:53:38 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:38 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:38 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:38 --> Controller Class Initialized
DEBUG - 2024-03-14 14:53:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 14:53:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 14:53:38 --> Final output sent to browser
DEBUG - 2024-03-14 14:53:38 --> Total execution time: 0.0765
INFO - 2024-03-14 14:53:40 --> Config Class Initialized
INFO - 2024-03-14 14:53:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:40 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:40 --> URI Class Initialized
INFO - 2024-03-14 14:53:40 --> Router Class Initialized
INFO - 2024-03-14 14:53:40 --> Output Class Initialized
INFO - 2024-03-14 14:53:40 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:40 --> Input Class Initialized
INFO - 2024-03-14 14:53:40 --> Language Class Initialized
INFO - 2024-03-14 14:53:40 --> Language Class Initialized
INFO - 2024-03-14 14:53:40 --> Config Class Initialized
INFO - 2024-03-14 14:53:40 --> Loader Class Initialized
INFO - 2024-03-14 14:53:40 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:40 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:40 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:40 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:40 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:40 --> Controller Class Initialized
DEBUG - 2024-03-14 14:53:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 14:53:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 14:53:40 --> Final output sent to browser
DEBUG - 2024-03-14 14:53:40 --> Total execution time: 0.0311
INFO - 2024-03-14 14:53:44 --> Config Class Initialized
INFO - 2024-03-14 14:53:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:53:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:53:44 --> Utf8 Class Initialized
INFO - 2024-03-14 14:53:44 --> URI Class Initialized
INFO - 2024-03-14 14:53:44 --> Router Class Initialized
INFO - 2024-03-14 14:53:44 --> Output Class Initialized
INFO - 2024-03-14 14:53:44 --> Security Class Initialized
DEBUG - 2024-03-14 14:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:53:44 --> Input Class Initialized
INFO - 2024-03-14 14:53:44 --> Language Class Initialized
INFO - 2024-03-14 14:53:44 --> Language Class Initialized
INFO - 2024-03-14 14:53:44 --> Config Class Initialized
INFO - 2024-03-14 14:53:44 --> Loader Class Initialized
INFO - 2024-03-14 14:53:44 --> Helper loaded: url_helper
INFO - 2024-03-14 14:53:44 --> Helper loaded: file_helper
INFO - 2024-03-14 14:53:44 --> Helper loaded: form_helper
INFO - 2024-03-14 14:53:44 --> Helper loaded: my_helper
INFO - 2024-03-14 14:53:44 --> Database Driver Class Initialized
INFO - 2024-03-14 14:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:53:44 --> Controller Class Initialized
DEBUG - 2024-03-14 14:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 14:53:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 14:53:44 --> Final output sent to browser
DEBUG - 2024-03-14 14:53:44 --> Total execution time: 0.0359
INFO - 2024-03-14 14:56:14 --> Config Class Initialized
INFO - 2024-03-14 14:56:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 14:56:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 14:56:14 --> Utf8 Class Initialized
INFO - 2024-03-14 14:56:14 --> URI Class Initialized
INFO - 2024-03-14 14:56:14 --> Router Class Initialized
INFO - 2024-03-14 14:56:14 --> Output Class Initialized
INFO - 2024-03-14 14:56:14 --> Security Class Initialized
DEBUG - 2024-03-14 14:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 14:56:14 --> Input Class Initialized
INFO - 2024-03-14 14:56:14 --> Language Class Initialized
INFO - 2024-03-14 14:56:14 --> Language Class Initialized
INFO - 2024-03-14 14:56:14 --> Config Class Initialized
INFO - 2024-03-14 14:56:14 --> Loader Class Initialized
INFO - 2024-03-14 14:56:14 --> Helper loaded: url_helper
INFO - 2024-03-14 14:56:14 --> Helper loaded: file_helper
INFO - 2024-03-14 14:56:14 --> Helper loaded: form_helper
INFO - 2024-03-14 14:56:14 --> Helper loaded: my_helper
INFO - 2024-03-14 14:56:14 --> Database Driver Class Initialized
INFO - 2024-03-14 14:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 14:56:15 --> Controller Class Initialized
INFO - 2024-03-14 14:56:15 --> Final output sent to browser
DEBUG - 2024-03-14 14:56:15 --> Total execution time: 0.1434
INFO - 2024-03-14 15:03:18 --> Config Class Initialized
INFO - 2024-03-14 15:03:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:03:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:03:18 --> Utf8 Class Initialized
INFO - 2024-03-14 15:03:18 --> URI Class Initialized
INFO - 2024-03-14 15:03:18 --> Router Class Initialized
INFO - 2024-03-14 15:03:18 --> Output Class Initialized
INFO - 2024-03-14 15:03:18 --> Security Class Initialized
DEBUG - 2024-03-14 15:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:03:18 --> Input Class Initialized
INFO - 2024-03-14 15:03:18 --> Language Class Initialized
INFO - 2024-03-14 15:03:18 --> Language Class Initialized
INFO - 2024-03-14 15:03:18 --> Config Class Initialized
INFO - 2024-03-14 15:03:18 --> Loader Class Initialized
INFO - 2024-03-14 15:03:18 --> Helper loaded: url_helper
INFO - 2024-03-14 15:03:18 --> Helper loaded: file_helper
INFO - 2024-03-14 15:03:18 --> Helper loaded: form_helper
INFO - 2024-03-14 15:03:18 --> Helper loaded: my_helper
INFO - 2024-03-14 15:03:18 --> Database Driver Class Initialized
INFO - 2024-03-14 15:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:03:18 --> Controller Class Initialized
INFO - 2024-03-14 15:03:18 --> Final output sent to browser
DEBUG - 2024-03-14 15:03:18 --> Total execution time: 0.0541
INFO - 2024-03-14 15:07:32 --> Config Class Initialized
INFO - 2024-03-14 15:07:32 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:32 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:32 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:32 --> URI Class Initialized
INFO - 2024-03-14 15:07:32 --> Router Class Initialized
INFO - 2024-03-14 15:07:32 --> Output Class Initialized
INFO - 2024-03-14 15:07:32 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:32 --> Input Class Initialized
INFO - 2024-03-14 15:07:32 --> Language Class Initialized
INFO - 2024-03-14 15:07:32 --> Language Class Initialized
INFO - 2024-03-14 15:07:32 --> Config Class Initialized
INFO - 2024-03-14 15:07:32 --> Loader Class Initialized
INFO - 2024-03-14 15:07:32 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:32 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:32 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:32 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:32 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:32 --> Controller Class Initialized
INFO - 2024-03-14 15:07:32 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:32 --> Total execution time: 0.0671
INFO - 2024-03-14 15:07:35 --> Config Class Initialized
INFO - 2024-03-14 15:07:35 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:35 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:35 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:35 --> URI Class Initialized
INFO - 2024-03-14 15:07:35 --> Router Class Initialized
INFO - 2024-03-14 15:07:35 --> Output Class Initialized
INFO - 2024-03-14 15:07:35 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:35 --> Input Class Initialized
INFO - 2024-03-14 15:07:35 --> Language Class Initialized
INFO - 2024-03-14 15:07:35 --> Language Class Initialized
INFO - 2024-03-14 15:07:35 --> Config Class Initialized
INFO - 2024-03-14 15:07:35 --> Loader Class Initialized
INFO - 2024-03-14 15:07:35 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:35 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:35 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:35 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:36 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:36 --> Controller Class Initialized
DEBUG - 2024-03-14 15:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:07:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:07:36 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:36 --> Total execution time: 0.0660
INFO - 2024-03-14 15:07:44 --> Config Class Initialized
INFO - 2024-03-14 15:07:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:44 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:44 --> URI Class Initialized
INFO - 2024-03-14 15:07:44 --> Router Class Initialized
INFO - 2024-03-14 15:07:44 --> Output Class Initialized
INFO - 2024-03-14 15:07:44 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:44 --> Input Class Initialized
INFO - 2024-03-14 15:07:44 --> Language Class Initialized
INFO - 2024-03-14 15:07:44 --> Language Class Initialized
INFO - 2024-03-14 15:07:44 --> Config Class Initialized
INFO - 2024-03-14 15:07:44 --> Loader Class Initialized
INFO - 2024-03-14 15:07:44 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:44 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:44 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:44 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:44 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:44 --> Controller Class Initialized
DEBUG - 2024-03-14 15:07:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 15:07:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:07:44 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:44 --> Total execution time: 0.0357
INFO - 2024-03-14 15:07:46 --> Config Class Initialized
INFO - 2024-03-14 15:07:46 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:46 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:46 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:46 --> URI Class Initialized
INFO - 2024-03-14 15:07:46 --> Router Class Initialized
INFO - 2024-03-14 15:07:46 --> Output Class Initialized
INFO - 2024-03-14 15:07:46 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:46 --> Input Class Initialized
INFO - 2024-03-14 15:07:46 --> Language Class Initialized
INFO - 2024-03-14 15:07:46 --> Language Class Initialized
INFO - 2024-03-14 15:07:46 --> Config Class Initialized
INFO - 2024-03-14 15:07:46 --> Loader Class Initialized
INFO - 2024-03-14 15:07:46 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:46 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:46 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:46 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:46 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:46 --> Controller Class Initialized
INFO - 2024-03-14 15:07:46 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:46 --> Total execution time: 0.0389
INFO - 2024-03-14 15:07:49 --> Config Class Initialized
INFO - 2024-03-14 15:07:49 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:49 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:49 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:49 --> URI Class Initialized
INFO - 2024-03-14 15:07:49 --> Router Class Initialized
INFO - 2024-03-14 15:07:49 --> Output Class Initialized
INFO - 2024-03-14 15:07:49 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:49 --> Input Class Initialized
INFO - 2024-03-14 15:07:49 --> Language Class Initialized
INFO - 2024-03-14 15:07:49 --> Language Class Initialized
INFO - 2024-03-14 15:07:49 --> Config Class Initialized
INFO - 2024-03-14 15:07:49 --> Loader Class Initialized
INFO - 2024-03-14 15:07:49 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:49 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:49 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:49 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:49 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:49 --> Controller Class Initialized
DEBUG - 2024-03-14 15:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:07:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:07:49 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:49 --> Total execution time: 0.0401
INFO - 2024-03-14 15:07:52 --> Config Class Initialized
INFO - 2024-03-14 15:07:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:52 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:52 --> URI Class Initialized
INFO - 2024-03-14 15:07:52 --> Router Class Initialized
INFO - 2024-03-14 15:07:52 --> Output Class Initialized
INFO - 2024-03-14 15:07:52 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:52 --> Input Class Initialized
INFO - 2024-03-14 15:07:52 --> Language Class Initialized
INFO - 2024-03-14 15:07:52 --> Language Class Initialized
INFO - 2024-03-14 15:07:52 --> Config Class Initialized
INFO - 2024-03-14 15:07:52 --> Loader Class Initialized
INFO - 2024-03-14 15:07:52 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:52 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:52 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:52 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:52 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:52 --> Controller Class Initialized
DEBUG - 2024-03-14 15:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 15:07:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:07:52 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:52 --> Total execution time: 0.0398
INFO - 2024-03-14 15:07:54 --> Config Class Initialized
INFO - 2024-03-14 15:07:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:07:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:07:54 --> Utf8 Class Initialized
INFO - 2024-03-14 15:07:54 --> URI Class Initialized
INFO - 2024-03-14 15:07:54 --> Router Class Initialized
INFO - 2024-03-14 15:07:54 --> Output Class Initialized
INFO - 2024-03-14 15:07:54 --> Security Class Initialized
DEBUG - 2024-03-14 15:07:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:07:54 --> Input Class Initialized
INFO - 2024-03-14 15:07:54 --> Language Class Initialized
INFO - 2024-03-14 15:07:54 --> Language Class Initialized
INFO - 2024-03-14 15:07:54 --> Config Class Initialized
INFO - 2024-03-14 15:07:54 --> Loader Class Initialized
INFO - 2024-03-14 15:07:54 --> Helper loaded: url_helper
INFO - 2024-03-14 15:07:54 --> Helper loaded: file_helper
INFO - 2024-03-14 15:07:54 --> Helper loaded: form_helper
INFO - 2024-03-14 15:07:54 --> Helper loaded: my_helper
INFO - 2024-03-14 15:07:54 --> Database Driver Class Initialized
INFO - 2024-03-14 15:07:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:07:54 --> Controller Class Initialized
INFO - 2024-03-14 15:07:54 --> Final output sent to browser
DEBUG - 2024-03-14 15:07:54 --> Total execution time: 0.0454
INFO - 2024-03-14 15:20:05 --> Config Class Initialized
INFO - 2024-03-14 15:20:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:05 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:05 --> URI Class Initialized
INFO - 2024-03-14 15:20:05 --> Router Class Initialized
INFO - 2024-03-14 15:20:05 --> Output Class Initialized
INFO - 2024-03-14 15:20:05 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:05 --> Input Class Initialized
INFO - 2024-03-14 15:20:05 --> Language Class Initialized
INFO - 2024-03-14 15:20:05 --> Language Class Initialized
INFO - 2024-03-14 15:20:05 --> Config Class Initialized
INFO - 2024-03-14 15:20:05 --> Loader Class Initialized
INFO - 2024-03-14 15:20:05 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:05 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:05 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:05 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:05 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:05 --> Controller Class Initialized
INFO - 2024-03-14 15:20:05 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:05 --> Total execution time: 0.1522
INFO - 2024-03-14 15:20:17 --> Config Class Initialized
INFO - 2024-03-14 15:20:17 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:17 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:17 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:17 --> URI Class Initialized
INFO - 2024-03-14 15:20:17 --> Router Class Initialized
INFO - 2024-03-14 15:20:17 --> Output Class Initialized
INFO - 2024-03-14 15:20:17 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:17 --> Input Class Initialized
INFO - 2024-03-14 15:20:17 --> Language Class Initialized
INFO - 2024-03-14 15:20:17 --> Language Class Initialized
INFO - 2024-03-14 15:20:17 --> Config Class Initialized
INFO - 2024-03-14 15:20:17 --> Loader Class Initialized
INFO - 2024-03-14 15:20:17 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:17 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:17 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:17 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:17 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:17 --> Controller Class Initialized
INFO - 2024-03-14 15:20:17 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:17 --> Total execution time: 0.0617
INFO - 2024-03-14 15:20:31 --> Config Class Initialized
INFO - 2024-03-14 15:20:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:31 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:31 --> URI Class Initialized
INFO - 2024-03-14 15:20:31 --> Router Class Initialized
INFO - 2024-03-14 15:20:31 --> Output Class Initialized
INFO - 2024-03-14 15:20:31 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:31 --> Input Class Initialized
INFO - 2024-03-14 15:20:31 --> Language Class Initialized
INFO - 2024-03-14 15:20:31 --> Language Class Initialized
INFO - 2024-03-14 15:20:31 --> Config Class Initialized
INFO - 2024-03-14 15:20:31 --> Loader Class Initialized
INFO - 2024-03-14 15:20:31 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:31 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:31 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:31 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:31 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:31 --> Controller Class Initialized
DEBUG - 2024-03-14 15:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:20:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:20:31 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:31 --> Total execution time: 0.0384
INFO - 2024-03-14 15:20:34 --> Config Class Initialized
INFO - 2024-03-14 15:20:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:34 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:34 --> URI Class Initialized
INFO - 2024-03-14 15:20:34 --> Router Class Initialized
INFO - 2024-03-14 15:20:34 --> Output Class Initialized
INFO - 2024-03-14 15:20:34 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:34 --> Input Class Initialized
INFO - 2024-03-14 15:20:34 --> Language Class Initialized
INFO - 2024-03-14 15:20:34 --> Language Class Initialized
INFO - 2024-03-14 15:20:34 --> Config Class Initialized
INFO - 2024-03-14 15:20:34 --> Loader Class Initialized
INFO - 2024-03-14 15:20:34 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:34 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:34 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:34 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:34 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:34 --> Controller Class Initialized
DEBUG - 2024-03-14 15:20:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 15:20:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:20:34 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:34 --> Total execution time: 0.0343
INFO - 2024-03-14 15:20:36 --> Config Class Initialized
INFO - 2024-03-14 15:20:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:36 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:36 --> URI Class Initialized
INFO - 2024-03-14 15:20:36 --> Router Class Initialized
INFO - 2024-03-14 15:20:36 --> Output Class Initialized
INFO - 2024-03-14 15:20:36 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:36 --> Input Class Initialized
INFO - 2024-03-14 15:20:36 --> Language Class Initialized
INFO - 2024-03-14 15:20:36 --> Language Class Initialized
INFO - 2024-03-14 15:20:36 --> Config Class Initialized
INFO - 2024-03-14 15:20:36 --> Loader Class Initialized
INFO - 2024-03-14 15:20:36 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:36 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:36 --> Controller Class Initialized
INFO - 2024-03-14 15:20:36 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:36 --> Total execution time: 0.0334
INFO - 2024-03-14 15:20:36 --> Config Class Initialized
INFO - 2024-03-14 15:20:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:36 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:36 --> URI Class Initialized
INFO - 2024-03-14 15:20:36 --> Router Class Initialized
INFO - 2024-03-14 15:20:36 --> Output Class Initialized
INFO - 2024-03-14 15:20:36 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:36 --> Input Class Initialized
INFO - 2024-03-14 15:20:36 --> Language Class Initialized
INFO - 2024-03-14 15:20:36 --> Language Class Initialized
INFO - 2024-03-14 15:20:36 --> Config Class Initialized
INFO - 2024-03-14 15:20:36 --> Loader Class Initialized
INFO - 2024-03-14 15:20:36 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:36 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:36 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:36 --> Controller Class Initialized
INFO - 2024-03-14 15:20:36 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:36 --> Total execution time: 0.0472
INFO - 2024-03-14 15:20:37 --> Config Class Initialized
INFO - 2024-03-14 15:20:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:20:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:20:37 --> Utf8 Class Initialized
INFO - 2024-03-14 15:20:37 --> URI Class Initialized
INFO - 2024-03-14 15:20:37 --> Router Class Initialized
INFO - 2024-03-14 15:20:37 --> Output Class Initialized
INFO - 2024-03-14 15:20:37 --> Security Class Initialized
DEBUG - 2024-03-14 15:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:20:37 --> Input Class Initialized
INFO - 2024-03-14 15:20:37 --> Language Class Initialized
INFO - 2024-03-14 15:20:37 --> Language Class Initialized
INFO - 2024-03-14 15:20:37 --> Config Class Initialized
INFO - 2024-03-14 15:20:37 --> Loader Class Initialized
INFO - 2024-03-14 15:20:37 --> Helper loaded: url_helper
INFO - 2024-03-14 15:20:37 --> Helper loaded: file_helper
INFO - 2024-03-14 15:20:37 --> Helper loaded: form_helper
INFO - 2024-03-14 15:20:37 --> Helper loaded: my_helper
INFO - 2024-03-14 15:20:37 --> Database Driver Class Initialized
INFO - 2024-03-14 15:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:20:37 --> Controller Class Initialized
INFO - 2024-03-14 15:20:37 --> Final output sent to browser
DEBUG - 2024-03-14 15:20:37 --> Total execution time: 0.0315
INFO - 2024-03-14 15:24:53 --> Config Class Initialized
INFO - 2024-03-14 15:24:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:24:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:24:53 --> Utf8 Class Initialized
INFO - 2024-03-14 15:24:53 --> URI Class Initialized
INFO - 2024-03-14 15:24:53 --> Router Class Initialized
INFO - 2024-03-14 15:24:53 --> Output Class Initialized
INFO - 2024-03-14 15:24:53 --> Security Class Initialized
DEBUG - 2024-03-14 15:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:24:53 --> Input Class Initialized
INFO - 2024-03-14 15:24:53 --> Language Class Initialized
INFO - 2024-03-14 15:24:53 --> Language Class Initialized
INFO - 2024-03-14 15:24:53 --> Config Class Initialized
INFO - 2024-03-14 15:24:53 --> Loader Class Initialized
INFO - 2024-03-14 15:24:53 --> Helper loaded: url_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: file_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: form_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: my_helper
INFO - 2024-03-14 15:24:53 --> Database Driver Class Initialized
INFO - 2024-03-14 15:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:24:53 --> Controller Class Initialized
DEBUG - 2024-03-14 15:24:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-14 15:24:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:24:53 --> Final output sent to browser
DEBUG - 2024-03-14 15:24:53 --> Total execution time: 0.0339
INFO - 2024-03-14 15:24:53 --> Config Class Initialized
INFO - 2024-03-14 15:24:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:24:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:24:53 --> Utf8 Class Initialized
INFO - 2024-03-14 15:24:53 --> URI Class Initialized
INFO - 2024-03-14 15:24:53 --> Router Class Initialized
INFO - 2024-03-14 15:24:53 --> Output Class Initialized
INFO - 2024-03-14 15:24:53 --> Security Class Initialized
DEBUG - 2024-03-14 15:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:24:53 --> Input Class Initialized
INFO - 2024-03-14 15:24:53 --> Language Class Initialized
INFO - 2024-03-14 15:24:53 --> Language Class Initialized
INFO - 2024-03-14 15:24:53 --> Config Class Initialized
INFO - 2024-03-14 15:24:53 --> Loader Class Initialized
INFO - 2024-03-14 15:24:53 --> Helper loaded: url_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: file_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: form_helper
INFO - 2024-03-14 15:24:53 --> Helper loaded: my_helper
INFO - 2024-03-14 15:24:53 --> Database Driver Class Initialized
INFO - 2024-03-14 15:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:24:53 --> Controller Class Initialized
INFO - 2024-03-14 15:24:56 --> Config Class Initialized
INFO - 2024-03-14 15:24:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:24:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:24:56 --> Utf8 Class Initialized
INFO - 2024-03-14 15:24:56 --> URI Class Initialized
DEBUG - 2024-03-14 15:24:56 --> No URI present. Default controller set.
INFO - 2024-03-14 15:24:56 --> Router Class Initialized
INFO - 2024-03-14 15:24:56 --> Output Class Initialized
INFO - 2024-03-14 15:24:56 --> Security Class Initialized
DEBUG - 2024-03-14 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:24:56 --> Input Class Initialized
INFO - 2024-03-14 15:24:56 --> Language Class Initialized
INFO - 2024-03-14 15:24:56 --> Language Class Initialized
INFO - 2024-03-14 15:24:56 --> Config Class Initialized
INFO - 2024-03-14 15:24:56 --> Loader Class Initialized
INFO - 2024-03-14 15:24:56 --> Helper loaded: url_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: file_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: form_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: my_helper
INFO - 2024-03-14 15:24:56 --> Database Driver Class Initialized
INFO - 2024-03-14 15:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:24:56 --> Controller Class Initialized
INFO - 2024-03-14 15:24:56 --> Config Class Initialized
INFO - 2024-03-14 15:24:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:24:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:24:56 --> Utf8 Class Initialized
INFO - 2024-03-14 15:24:56 --> URI Class Initialized
INFO - 2024-03-14 15:24:56 --> Router Class Initialized
INFO - 2024-03-14 15:24:56 --> Output Class Initialized
INFO - 2024-03-14 15:24:56 --> Security Class Initialized
DEBUG - 2024-03-14 15:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:24:56 --> Input Class Initialized
INFO - 2024-03-14 15:24:56 --> Language Class Initialized
INFO - 2024-03-14 15:24:56 --> Language Class Initialized
INFO - 2024-03-14 15:24:56 --> Config Class Initialized
INFO - 2024-03-14 15:24:56 --> Loader Class Initialized
INFO - 2024-03-14 15:24:56 --> Helper loaded: url_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: file_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: form_helper
INFO - 2024-03-14 15:24:56 --> Helper loaded: my_helper
INFO - 2024-03-14 15:24:56 --> Database Driver Class Initialized
INFO - 2024-03-14 15:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:24:56 --> Controller Class Initialized
DEBUG - 2024-03-14 15:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 15:24:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:24:56 --> Final output sent to browser
DEBUG - 2024-03-14 15:24:56 --> Total execution time: 0.0490
INFO - 2024-03-14 15:25:00 --> Config Class Initialized
INFO - 2024-03-14 15:25:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:25:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:25:00 --> Utf8 Class Initialized
INFO - 2024-03-14 15:25:00 --> URI Class Initialized
INFO - 2024-03-14 15:25:00 --> Router Class Initialized
INFO - 2024-03-14 15:25:00 --> Output Class Initialized
INFO - 2024-03-14 15:25:00 --> Security Class Initialized
DEBUG - 2024-03-14 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:25:00 --> Input Class Initialized
INFO - 2024-03-14 15:25:00 --> Language Class Initialized
INFO - 2024-03-14 15:25:00 --> Language Class Initialized
INFO - 2024-03-14 15:25:00 --> Config Class Initialized
INFO - 2024-03-14 15:25:00 --> Loader Class Initialized
INFO - 2024-03-14 15:25:00 --> Helper loaded: url_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: file_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: form_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: my_helper
INFO - 2024-03-14 15:25:00 --> Database Driver Class Initialized
INFO - 2024-03-14 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:25:00 --> Controller Class Initialized
INFO - 2024-03-14 15:25:00 --> Helper loaded: cookie_helper
INFO - 2024-03-14 15:25:00 --> Final output sent to browser
DEBUG - 2024-03-14 15:25:00 --> Total execution time: 0.0386
INFO - 2024-03-14 15:25:00 --> Config Class Initialized
INFO - 2024-03-14 15:25:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:25:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:25:00 --> Utf8 Class Initialized
INFO - 2024-03-14 15:25:00 --> URI Class Initialized
INFO - 2024-03-14 15:25:00 --> Router Class Initialized
INFO - 2024-03-14 15:25:00 --> Output Class Initialized
INFO - 2024-03-14 15:25:00 --> Security Class Initialized
DEBUG - 2024-03-14 15:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:25:00 --> Input Class Initialized
INFO - 2024-03-14 15:25:00 --> Language Class Initialized
INFO - 2024-03-14 15:25:00 --> Language Class Initialized
INFO - 2024-03-14 15:25:00 --> Config Class Initialized
INFO - 2024-03-14 15:25:00 --> Loader Class Initialized
INFO - 2024-03-14 15:25:00 --> Helper loaded: url_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: file_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: form_helper
INFO - 2024-03-14 15:25:00 --> Helper loaded: my_helper
INFO - 2024-03-14 15:25:00 --> Database Driver Class Initialized
INFO - 2024-03-14 15:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:25:00 --> Controller Class Initialized
DEBUG - 2024-03-14 15:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 15:25:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:25:00 --> Final output sent to browser
DEBUG - 2024-03-14 15:25:00 --> Total execution time: 0.0393
INFO - 2024-03-14 15:25:03 --> Config Class Initialized
INFO - 2024-03-14 15:25:03 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:25:03 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:25:03 --> Utf8 Class Initialized
INFO - 2024-03-14 15:25:03 --> URI Class Initialized
INFO - 2024-03-14 15:25:03 --> Router Class Initialized
INFO - 2024-03-14 15:25:03 --> Output Class Initialized
INFO - 2024-03-14 15:25:03 --> Security Class Initialized
DEBUG - 2024-03-14 15:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:25:03 --> Input Class Initialized
INFO - 2024-03-14 15:25:03 --> Language Class Initialized
INFO - 2024-03-14 15:25:03 --> Language Class Initialized
INFO - 2024-03-14 15:25:03 --> Config Class Initialized
INFO - 2024-03-14 15:25:03 --> Loader Class Initialized
INFO - 2024-03-14 15:25:03 --> Helper loaded: url_helper
INFO - 2024-03-14 15:25:03 --> Helper loaded: file_helper
INFO - 2024-03-14 15:25:03 --> Helper loaded: form_helper
INFO - 2024-03-14 15:25:03 --> Helper loaded: my_helper
INFO - 2024-03-14 15:25:03 --> Database Driver Class Initialized
INFO - 2024-03-14 15:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:25:03 --> Controller Class Initialized
DEBUG - 2024-03-14 15:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:25:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:25:03 --> Final output sent to browser
DEBUG - 2024-03-14 15:25:03 --> Total execution time: 0.0884
INFO - 2024-03-14 15:25:05 --> Config Class Initialized
INFO - 2024-03-14 15:25:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:25:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:25:05 --> Utf8 Class Initialized
INFO - 2024-03-14 15:25:05 --> URI Class Initialized
INFO - 2024-03-14 15:25:05 --> Router Class Initialized
INFO - 2024-03-14 15:25:05 --> Output Class Initialized
INFO - 2024-03-14 15:25:05 --> Security Class Initialized
DEBUG - 2024-03-14 15:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:25:05 --> Input Class Initialized
INFO - 2024-03-14 15:25:05 --> Language Class Initialized
INFO - 2024-03-14 15:25:05 --> Language Class Initialized
INFO - 2024-03-14 15:25:05 --> Config Class Initialized
INFO - 2024-03-14 15:25:05 --> Loader Class Initialized
INFO - 2024-03-14 15:25:05 --> Helper loaded: url_helper
INFO - 2024-03-14 15:25:05 --> Helper loaded: file_helper
INFO - 2024-03-14 15:25:05 --> Helper loaded: form_helper
INFO - 2024-03-14 15:25:05 --> Helper loaded: my_helper
INFO - 2024-03-14 15:25:05 --> Database Driver Class Initialized
INFO - 2024-03-14 15:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:25:05 --> Controller Class Initialized
DEBUG - 2024-03-14 15:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 15:25:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:25:05 --> Final output sent to browser
DEBUG - 2024-03-14 15:25:05 --> Total execution time: 0.0447
INFO - 2024-03-14 15:25:13 --> Config Class Initialized
INFO - 2024-03-14 15:25:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:25:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:25:13 --> Utf8 Class Initialized
INFO - 2024-03-14 15:25:13 --> URI Class Initialized
INFO - 2024-03-14 15:25:13 --> Router Class Initialized
INFO - 2024-03-14 15:25:13 --> Output Class Initialized
INFO - 2024-03-14 15:25:13 --> Security Class Initialized
DEBUG - 2024-03-14 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:25:13 --> Input Class Initialized
INFO - 2024-03-14 15:25:13 --> Language Class Initialized
INFO - 2024-03-14 15:25:13 --> Language Class Initialized
INFO - 2024-03-14 15:25:13 --> Config Class Initialized
INFO - 2024-03-14 15:25:13 --> Loader Class Initialized
INFO - 2024-03-14 15:25:13 --> Helper loaded: url_helper
INFO - 2024-03-14 15:25:13 --> Helper loaded: file_helper
INFO - 2024-03-14 15:25:13 --> Helper loaded: form_helper
INFO - 2024-03-14 15:25:13 --> Helper loaded: my_helper
INFO - 2024-03-14 15:25:13 --> Database Driver Class Initialized
INFO - 2024-03-14 15:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:25:13 --> Controller Class Initialized
INFO - 2024-03-14 15:25:13 --> Final output sent to browser
DEBUG - 2024-03-14 15:25:13 --> Total execution time: 0.0427
INFO - 2024-03-14 15:29:04 --> Config Class Initialized
INFO - 2024-03-14 15:29:04 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:29:04 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:29:04 --> Utf8 Class Initialized
INFO - 2024-03-14 15:29:04 --> URI Class Initialized
INFO - 2024-03-14 15:29:04 --> Router Class Initialized
INFO - 2024-03-14 15:29:04 --> Output Class Initialized
INFO - 2024-03-14 15:29:04 --> Security Class Initialized
DEBUG - 2024-03-14 15:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:29:04 --> Input Class Initialized
INFO - 2024-03-14 15:29:04 --> Language Class Initialized
INFO - 2024-03-14 15:29:04 --> Language Class Initialized
INFO - 2024-03-14 15:29:04 --> Config Class Initialized
INFO - 2024-03-14 15:29:04 --> Loader Class Initialized
INFO - 2024-03-14 15:29:04 --> Helper loaded: url_helper
INFO - 2024-03-14 15:29:04 --> Helper loaded: file_helper
INFO - 2024-03-14 15:29:04 --> Helper loaded: form_helper
INFO - 2024-03-14 15:29:04 --> Helper loaded: my_helper
INFO - 2024-03-14 15:29:04 --> Database Driver Class Initialized
INFO - 2024-03-14 15:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:29:04 --> Controller Class Initialized
INFO - 2024-03-14 15:29:05 --> Final output sent to browser
DEBUG - 2024-03-14 15:29:05 --> Total execution time: 0.2642
INFO - 2024-03-14 15:43:35 --> Config Class Initialized
INFO - 2024-03-14 15:43:35 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:43:35 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:43:35 --> Utf8 Class Initialized
INFO - 2024-03-14 15:43:35 --> URI Class Initialized
INFO - 2024-03-14 15:43:35 --> Router Class Initialized
INFO - 2024-03-14 15:43:35 --> Output Class Initialized
INFO - 2024-03-14 15:43:35 --> Security Class Initialized
DEBUG - 2024-03-14 15:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:43:35 --> Input Class Initialized
INFO - 2024-03-14 15:43:35 --> Language Class Initialized
INFO - 2024-03-14 15:43:35 --> Language Class Initialized
INFO - 2024-03-14 15:43:35 --> Config Class Initialized
INFO - 2024-03-14 15:43:35 --> Loader Class Initialized
INFO - 2024-03-14 15:43:35 --> Helper loaded: url_helper
INFO - 2024-03-14 15:43:35 --> Helper loaded: file_helper
INFO - 2024-03-14 15:43:35 --> Helper loaded: form_helper
INFO - 2024-03-14 15:43:35 --> Helper loaded: my_helper
INFO - 2024-03-14 15:43:35 --> Database Driver Class Initialized
INFO - 2024-03-14 15:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:43:35 --> Controller Class Initialized
DEBUG - 2024-03-14 15:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2024-03-14 15:43:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:43:35 --> Final output sent to browser
DEBUG - 2024-03-14 15:43:35 --> Total execution time: 0.0368
INFO - 2024-03-14 15:46:01 --> Config Class Initialized
INFO - 2024-03-14 15:46:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:01 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:01 --> URI Class Initialized
INFO - 2024-03-14 15:46:01 --> Router Class Initialized
INFO - 2024-03-14 15:46:01 --> Output Class Initialized
INFO - 2024-03-14 15:46:01 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:01 --> Input Class Initialized
INFO - 2024-03-14 15:46:01 --> Language Class Initialized
INFO - 2024-03-14 15:46:01 --> Language Class Initialized
INFO - 2024-03-14 15:46:01 --> Config Class Initialized
INFO - 2024-03-14 15:46:01 --> Loader Class Initialized
INFO - 2024-03-14 15:46:01 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:01 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:01 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:01 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:02 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:02 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 15:46:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:02 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:02 --> Total execution time: 0.2671
INFO - 2024-03-14 15:46:09 --> Config Class Initialized
INFO - 2024-03-14 15:46:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:09 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:09 --> URI Class Initialized
INFO - 2024-03-14 15:46:09 --> Router Class Initialized
INFO - 2024-03-14 15:46:09 --> Output Class Initialized
INFO - 2024-03-14 15:46:09 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:09 --> Input Class Initialized
INFO - 2024-03-14 15:46:09 --> Language Class Initialized
INFO - 2024-03-14 15:46:09 --> Language Class Initialized
INFO - 2024-03-14 15:46:09 --> Config Class Initialized
INFO - 2024-03-14 15:46:09 --> Loader Class Initialized
INFO - 2024-03-14 15:46:09 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:09 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:09 --> Controller Class Initialized
INFO - 2024-03-14 15:46:09 --> Helper loaded: cookie_helper
INFO - 2024-03-14 15:46:09 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:09 --> Total execution time: 0.0683
INFO - 2024-03-14 15:46:09 --> Config Class Initialized
INFO - 2024-03-14 15:46:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:09 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:09 --> URI Class Initialized
INFO - 2024-03-14 15:46:09 --> Router Class Initialized
INFO - 2024-03-14 15:46:09 --> Output Class Initialized
INFO - 2024-03-14 15:46:09 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:09 --> Input Class Initialized
INFO - 2024-03-14 15:46:09 --> Language Class Initialized
INFO - 2024-03-14 15:46:09 --> Language Class Initialized
INFO - 2024-03-14 15:46:09 --> Config Class Initialized
INFO - 2024-03-14 15:46:09 --> Loader Class Initialized
INFO - 2024-03-14 15:46:09 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:09 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:09 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:09 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 15:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:09 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:09 --> Total execution time: 0.0779
INFO - 2024-03-14 15:46:31 --> Config Class Initialized
INFO - 2024-03-14 15:46:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:31 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:31 --> URI Class Initialized
INFO - 2024-03-14 15:46:31 --> Router Class Initialized
INFO - 2024-03-14 15:46:31 --> Output Class Initialized
INFO - 2024-03-14 15:46:31 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:31 --> Input Class Initialized
INFO - 2024-03-14 15:46:31 --> Language Class Initialized
INFO - 2024-03-14 15:46:31 --> Language Class Initialized
INFO - 2024-03-14 15:46:31 --> Config Class Initialized
INFO - 2024-03-14 15:46:31 --> Loader Class Initialized
INFO - 2024-03-14 15:46:31 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:31 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:31 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:31 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:31 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:31 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:31 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:31 --> Total execution time: 0.0321
INFO - 2024-03-14 15:46:35 --> Config Class Initialized
INFO - 2024-03-14 15:46:35 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:35 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:35 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:35 --> URI Class Initialized
INFO - 2024-03-14 15:46:35 --> Router Class Initialized
INFO - 2024-03-14 15:46:35 --> Output Class Initialized
INFO - 2024-03-14 15:46:35 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:35 --> Input Class Initialized
INFO - 2024-03-14 15:46:35 --> Language Class Initialized
INFO - 2024-03-14 15:46:35 --> Language Class Initialized
INFO - 2024-03-14 15:46:35 --> Config Class Initialized
INFO - 2024-03-14 15:46:35 --> Loader Class Initialized
INFO - 2024-03-14 15:46:35 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:35 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:35 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:35 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:35 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:35 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 15:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:35 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:35 --> Total execution time: 0.0765
INFO - 2024-03-14 15:46:36 --> Config Class Initialized
INFO - 2024-03-14 15:46:36 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:36 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:36 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:36 --> URI Class Initialized
INFO - 2024-03-14 15:46:36 --> Router Class Initialized
INFO - 2024-03-14 15:46:36 --> Output Class Initialized
INFO - 2024-03-14 15:46:36 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:36 --> Input Class Initialized
INFO - 2024-03-14 15:46:36 --> Language Class Initialized
INFO - 2024-03-14 15:46:36 --> Language Class Initialized
INFO - 2024-03-14 15:46:36 --> Config Class Initialized
INFO - 2024-03-14 15:46:36 --> Loader Class Initialized
INFO - 2024-03-14 15:46:36 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:36 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:36 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:36 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:36 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:36 --> Controller Class Initialized
INFO - 2024-03-14 15:46:45 --> Config Class Initialized
INFO - 2024-03-14 15:46:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:45 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:45 --> URI Class Initialized
INFO - 2024-03-14 15:46:45 --> Router Class Initialized
INFO - 2024-03-14 15:46:45 --> Output Class Initialized
INFO - 2024-03-14 15:46:45 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:45 --> Input Class Initialized
INFO - 2024-03-14 15:46:45 --> Language Class Initialized
INFO - 2024-03-14 15:46:45 --> Language Class Initialized
INFO - 2024-03-14 15:46:45 --> Config Class Initialized
INFO - 2024-03-14 15:46:45 --> Loader Class Initialized
INFO - 2024-03-14 15:46:45 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:45 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:45 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:45 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:45 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:45 --> Controller Class Initialized
INFO - 2024-03-14 15:46:45 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:45 --> Total execution time: 0.0403
INFO - 2024-03-14 15:46:50 --> Config Class Initialized
INFO - 2024-03-14 15:46:50 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:50 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:50 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:50 --> URI Class Initialized
INFO - 2024-03-14 15:46:50 --> Router Class Initialized
INFO - 2024-03-14 15:46:50 --> Output Class Initialized
INFO - 2024-03-14 15:46:50 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:50 --> Input Class Initialized
INFO - 2024-03-14 15:46:50 --> Language Class Initialized
INFO - 2024-03-14 15:46:50 --> Language Class Initialized
INFO - 2024-03-14 15:46:50 --> Config Class Initialized
INFO - 2024-03-14 15:46:50 --> Loader Class Initialized
INFO - 2024-03-14 15:46:50 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:50 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:50 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:50 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:50 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:50 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:46:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:50 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:50 --> Total execution time: 0.0359
INFO - 2024-03-14 15:46:51 --> Config Class Initialized
INFO - 2024-03-14 15:46:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:51 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:51 --> URI Class Initialized
INFO - 2024-03-14 15:46:51 --> Router Class Initialized
INFO - 2024-03-14 15:46:51 --> Output Class Initialized
INFO - 2024-03-14 15:46:51 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:51 --> Input Class Initialized
INFO - 2024-03-14 15:46:51 --> Language Class Initialized
INFO - 2024-03-14 15:46:51 --> Language Class Initialized
INFO - 2024-03-14 15:46:51 --> Config Class Initialized
INFO - 2024-03-14 15:46:51 --> Loader Class Initialized
INFO - 2024-03-14 15:46:51 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:51 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:51 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 15:46:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:51 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:51 --> Total execution time: 0.0916
INFO - 2024-03-14 15:46:51 --> Config Class Initialized
INFO - 2024-03-14 15:46:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:51 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:51 --> URI Class Initialized
INFO - 2024-03-14 15:46:51 --> Router Class Initialized
INFO - 2024-03-14 15:46:51 --> Output Class Initialized
INFO - 2024-03-14 15:46:51 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:51 --> Input Class Initialized
INFO - 2024-03-14 15:46:51 --> Language Class Initialized
INFO - 2024-03-14 15:46:51 --> Language Class Initialized
INFO - 2024-03-14 15:46:51 --> Config Class Initialized
INFO - 2024-03-14 15:46:51 --> Loader Class Initialized
INFO - 2024-03-14 15:46:51 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:51 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:51 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:51 --> Controller Class Initialized
INFO - 2024-03-14 15:46:53 --> Config Class Initialized
INFO - 2024-03-14 15:46:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:53 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:53 --> URI Class Initialized
INFO - 2024-03-14 15:46:53 --> Router Class Initialized
INFO - 2024-03-14 15:46:53 --> Output Class Initialized
INFO - 2024-03-14 15:46:53 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:53 --> Input Class Initialized
INFO - 2024-03-14 15:46:53 --> Language Class Initialized
INFO - 2024-03-14 15:46:53 --> Language Class Initialized
INFO - 2024-03-14 15:46:53 --> Config Class Initialized
INFO - 2024-03-14 15:46:53 --> Loader Class Initialized
INFO - 2024-03-14 15:46:53 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:53 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:53 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:53 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:53 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:53 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:46:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:53 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:53 --> Total execution time: 0.0453
INFO - 2024-03-14 15:46:54 --> Config Class Initialized
INFO - 2024-03-14 15:46:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:54 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:54 --> URI Class Initialized
INFO - 2024-03-14 15:46:54 --> Router Class Initialized
INFO - 2024-03-14 15:46:54 --> Output Class Initialized
INFO - 2024-03-14 15:46:54 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:54 --> Input Class Initialized
INFO - 2024-03-14 15:46:54 --> Language Class Initialized
INFO - 2024-03-14 15:46:54 --> Language Class Initialized
INFO - 2024-03-14 15:46:54 --> Config Class Initialized
INFO - 2024-03-14 15:46:54 --> Loader Class Initialized
INFO - 2024-03-14 15:46:54 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:54 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:54 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:54 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:54 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:54 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 15:46:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:54 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:54 --> Total execution time: 0.0482
INFO - 2024-03-14 15:46:55 --> Config Class Initialized
INFO - 2024-03-14 15:46:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:55 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:55 --> URI Class Initialized
INFO - 2024-03-14 15:46:55 --> Router Class Initialized
INFO - 2024-03-14 15:46:55 --> Output Class Initialized
INFO - 2024-03-14 15:46:55 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:55 --> Input Class Initialized
INFO - 2024-03-14 15:46:55 --> Language Class Initialized
INFO - 2024-03-14 15:46:55 --> Language Class Initialized
INFO - 2024-03-14 15:46:55 --> Config Class Initialized
INFO - 2024-03-14 15:46:55 --> Loader Class Initialized
INFO - 2024-03-14 15:46:55 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:55 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:55 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:55 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:55 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:55 --> Controller Class Initialized
INFO - 2024-03-14 15:46:56 --> Config Class Initialized
INFO - 2024-03-14 15:46:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:46:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:46:56 --> Utf8 Class Initialized
INFO - 2024-03-14 15:46:56 --> URI Class Initialized
INFO - 2024-03-14 15:46:56 --> Router Class Initialized
INFO - 2024-03-14 15:46:56 --> Output Class Initialized
INFO - 2024-03-14 15:46:56 --> Security Class Initialized
DEBUG - 2024-03-14 15:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:46:56 --> Input Class Initialized
INFO - 2024-03-14 15:46:56 --> Language Class Initialized
INFO - 2024-03-14 15:46:56 --> Language Class Initialized
INFO - 2024-03-14 15:46:56 --> Config Class Initialized
INFO - 2024-03-14 15:46:56 --> Loader Class Initialized
INFO - 2024-03-14 15:46:56 --> Helper loaded: url_helper
INFO - 2024-03-14 15:46:56 --> Helper loaded: file_helper
INFO - 2024-03-14 15:46:56 --> Helper loaded: form_helper
INFO - 2024-03-14 15:46:56 --> Helper loaded: my_helper
INFO - 2024-03-14 15:46:56 --> Database Driver Class Initialized
INFO - 2024-03-14 15:46:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:46:56 --> Controller Class Initialized
DEBUG - 2024-03-14 15:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:46:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:46:56 --> Final output sent to browser
DEBUG - 2024-03-14 15:46:56 --> Total execution time: 0.0383
INFO - 2024-03-14 15:52:37 --> Config Class Initialized
INFO - 2024-03-14 15:52:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:52:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:52:37 --> Utf8 Class Initialized
INFO - 2024-03-14 15:52:37 --> URI Class Initialized
INFO - 2024-03-14 15:52:37 --> Router Class Initialized
INFO - 2024-03-14 15:52:37 --> Output Class Initialized
INFO - 2024-03-14 15:52:37 --> Security Class Initialized
DEBUG - 2024-03-14 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:52:37 --> Input Class Initialized
INFO - 2024-03-14 15:52:37 --> Language Class Initialized
INFO - 2024-03-14 15:52:37 --> Language Class Initialized
INFO - 2024-03-14 15:52:37 --> Config Class Initialized
INFO - 2024-03-14 15:52:37 --> Loader Class Initialized
INFO - 2024-03-14 15:52:37 --> Helper loaded: url_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: file_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: form_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: my_helper
INFO - 2024-03-14 15:52:37 --> Database Driver Class Initialized
INFO - 2024-03-14 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:52:37 --> Controller Class Initialized
DEBUG - 2024-03-14 15:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 15:52:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:52:37 --> Final output sent to browser
DEBUG - 2024-03-14 15:52:37 --> Total execution time: 0.0403
INFO - 2024-03-14 15:52:37 --> Config Class Initialized
INFO - 2024-03-14 15:52:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:52:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:52:37 --> Utf8 Class Initialized
INFO - 2024-03-14 15:52:37 --> URI Class Initialized
INFO - 2024-03-14 15:52:37 --> Router Class Initialized
INFO - 2024-03-14 15:52:37 --> Output Class Initialized
INFO - 2024-03-14 15:52:37 --> Security Class Initialized
DEBUG - 2024-03-14 15:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:52:37 --> Input Class Initialized
INFO - 2024-03-14 15:52:37 --> Language Class Initialized
INFO - 2024-03-14 15:52:37 --> Language Class Initialized
INFO - 2024-03-14 15:52:37 --> Config Class Initialized
INFO - 2024-03-14 15:52:37 --> Loader Class Initialized
INFO - 2024-03-14 15:52:37 --> Helper loaded: url_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: file_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: form_helper
INFO - 2024-03-14 15:52:37 --> Helper loaded: my_helper
INFO - 2024-03-14 15:52:37 --> Database Driver Class Initialized
INFO - 2024-03-14 15:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:52:37 --> Controller Class Initialized
INFO - 2024-03-14 15:56:39 --> Config Class Initialized
INFO - 2024-03-14 15:56:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:56:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:56:39 --> Utf8 Class Initialized
INFO - 2024-03-14 15:56:39 --> URI Class Initialized
INFO - 2024-03-14 15:56:39 --> Router Class Initialized
INFO - 2024-03-14 15:56:39 --> Output Class Initialized
INFO - 2024-03-14 15:56:39 --> Security Class Initialized
DEBUG - 2024-03-14 15:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:56:39 --> Input Class Initialized
INFO - 2024-03-14 15:56:39 --> Language Class Initialized
INFO - 2024-03-14 15:56:39 --> Language Class Initialized
INFO - 2024-03-14 15:56:39 --> Config Class Initialized
INFO - 2024-03-14 15:56:39 --> Loader Class Initialized
INFO - 2024-03-14 15:56:39 --> Helper loaded: url_helper
INFO - 2024-03-14 15:56:39 --> Helper loaded: file_helper
INFO - 2024-03-14 15:56:39 --> Helper loaded: form_helper
INFO - 2024-03-14 15:56:39 --> Helper loaded: my_helper
INFO - 2024-03-14 15:56:39 --> Database Driver Class Initialized
INFO - 2024-03-14 15:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:56:39 --> Controller Class Initialized
DEBUG - 2024-03-14 15:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 15:56:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:56:39 --> Final output sent to browser
DEBUG - 2024-03-14 15:56:39 --> Total execution time: 0.0348
INFO - 2024-03-14 15:56:51 --> Config Class Initialized
INFO - 2024-03-14 15:56:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:56:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:56:51 --> Utf8 Class Initialized
INFO - 2024-03-14 15:56:51 --> URI Class Initialized
INFO - 2024-03-14 15:56:51 --> Router Class Initialized
INFO - 2024-03-14 15:56:51 --> Output Class Initialized
INFO - 2024-03-14 15:56:51 --> Security Class Initialized
DEBUG - 2024-03-14 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:56:51 --> Input Class Initialized
INFO - 2024-03-14 15:56:51 --> Language Class Initialized
INFO - 2024-03-14 15:56:51 --> Language Class Initialized
INFO - 2024-03-14 15:56:51 --> Config Class Initialized
INFO - 2024-03-14 15:56:51 --> Loader Class Initialized
INFO - 2024-03-14 15:56:51 --> Helper loaded: url_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: file_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: form_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: my_helper
INFO - 2024-03-14 15:56:51 --> Database Driver Class Initialized
INFO - 2024-03-14 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:56:51 --> Controller Class Initialized
INFO - 2024-03-14 15:56:51 --> Helper loaded: cookie_helper
INFO - 2024-03-14 15:56:51 --> Final output sent to browser
DEBUG - 2024-03-14 15:56:51 --> Total execution time: 0.0372
INFO - 2024-03-14 15:56:51 --> Config Class Initialized
INFO - 2024-03-14 15:56:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:56:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:56:51 --> Utf8 Class Initialized
INFO - 2024-03-14 15:56:51 --> URI Class Initialized
INFO - 2024-03-14 15:56:51 --> Router Class Initialized
INFO - 2024-03-14 15:56:51 --> Output Class Initialized
INFO - 2024-03-14 15:56:51 --> Security Class Initialized
DEBUG - 2024-03-14 15:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:56:51 --> Input Class Initialized
INFO - 2024-03-14 15:56:51 --> Language Class Initialized
INFO - 2024-03-14 15:56:51 --> Language Class Initialized
INFO - 2024-03-14 15:56:51 --> Config Class Initialized
INFO - 2024-03-14 15:56:51 --> Loader Class Initialized
INFO - 2024-03-14 15:56:51 --> Helper loaded: url_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: file_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: form_helper
INFO - 2024-03-14 15:56:51 --> Helper loaded: my_helper
INFO - 2024-03-14 15:56:51 --> Database Driver Class Initialized
INFO - 2024-03-14 15:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:56:51 --> Controller Class Initialized
DEBUG - 2024-03-14 15:56:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2024-03-14 15:56:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:56:51 --> Final output sent to browser
DEBUG - 2024-03-14 15:56:51 --> Total execution time: 0.0385
INFO - 2024-03-14 15:57:01 --> Config Class Initialized
INFO - 2024-03-14 15:57:01 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:01 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:01 --> URI Class Initialized
INFO - 2024-03-14 15:57:01 --> Router Class Initialized
INFO - 2024-03-14 15:57:01 --> Output Class Initialized
INFO - 2024-03-14 15:57:01 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:01 --> Input Class Initialized
INFO - 2024-03-14 15:57:01 --> Language Class Initialized
INFO - 2024-03-14 15:57:02 --> Language Class Initialized
INFO - 2024-03-14 15:57:02 --> Config Class Initialized
INFO - 2024-03-14 15:57:02 --> Loader Class Initialized
INFO - 2024-03-14 15:57:02 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:02 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:02 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-14 15:57:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:02 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:02 --> Total execution time: 0.0450
INFO - 2024-03-14 15:57:02 --> Config Class Initialized
INFO - 2024-03-14 15:57:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:02 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:02 --> URI Class Initialized
INFO - 2024-03-14 15:57:02 --> Router Class Initialized
INFO - 2024-03-14 15:57:02 --> Output Class Initialized
INFO - 2024-03-14 15:57:02 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:02 --> Input Class Initialized
INFO - 2024-03-14 15:57:02 --> Language Class Initialized
ERROR - 2024-03-14 15:57:02 --> 404 Page Not Found: /index
INFO - 2024-03-14 15:57:02 --> Config Class Initialized
INFO - 2024-03-14 15:57:02 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:02 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:02 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:02 --> URI Class Initialized
INFO - 2024-03-14 15:57:02 --> Router Class Initialized
INFO - 2024-03-14 15:57:02 --> Output Class Initialized
INFO - 2024-03-14 15:57:02 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:02 --> Input Class Initialized
INFO - 2024-03-14 15:57:02 --> Language Class Initialized
INFO - 2024-03-14 15:57:02 --> Language Class Initialized
INFO - 2024-03-14 15:57:02 --> Config Class Initialized
INFO - 2024-03-14 15:57:02 --> Loader Class Initialized
INFO - 2024-03-14 15:57:02 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:02 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:02 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:02 --> Controller Class Initialized
INFO - 2024-03-14 15:57:09 --> Config Class Initialized
INFO - 2024-03-14 15:57:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:09 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:09 --> URI Class Initialized
INFO - 2024-03-14 15:57:09 --> Router Class Initialized
INFO - 2024-03-14 15:57:09 --> Output Class Initialized
INFO - 2024-03-14 15:57:09 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:09 --> Input Class Initialized
INFO - 2024-03-14 15:57:09 --> Language Class Initialized
INFO - 2024-03-14 15:57:09 --> Language Class Initialized
INFO - 2024-03-14 15:57:09 --> Config Class Initialized
INFO - 2024-03-14 15:57:09 --> Loader Class Initialized
INFO - 2024-03-14 15:57:09 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:09 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:09 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2024-03-14 15:57:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:09 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:09 --> Total execution time: 0.0331
INFO - 2024-03-14 15:57:09 --> Config Class Initialized
INFO - 2024-03-14 15:57:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:09 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:09 --> URI Class Initialized
INFO - 2024-03-14 15:57:09 --> Router Class Initialized
INFO - 2024-03-14 15:57:09 --> Output Class Initialized
INFO - 2024-03-14 15:57:09 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:09 --> Input Class Initialized
INFO - 2024-03-14 15:57:09 --> Language Class Initialized
ERROR - 2024-03-14 15:57:09 --> 404 Page Not Found: /index
INFO - 2024-03-14 15:57:09 --> Config Class Initialized
INFO - 2024-03-14 15:57:09 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:09 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:09 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:09 --> URI Class Initialized
INFO - 2024-03-14 15:57:09 --> Router Class Initialized
INFO - 2024-03-14 15:57:09 --> Output Class Initialized
INFO - 2024-03-14 15:57:09 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:09 --> Input Class Initialized
INFO - 2024-03-14 15:57:09 --> Language Class Initialized
INFO - 2024-03-14 15:57:09 --> Language Class Initialized
INFO - 2024-03-14 15:57:09 --> Config Class Initialized
INFO - 2024-03-14 15:57:09 --> Loader Class Initialized
INFO - 2024-03-14 15:57:09 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:09 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:09 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:09 --> Controller Class Initialized
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:33 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:33 --> URI Class Initialized
INFO - 2024-03-14 15:57:33 --> Router Class Initialized
INFO - 2024-03-14 15:57:33 --> Output Class Initialized
INFO - 2024-03-14 15:57:33 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:33 --> Input Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Loader Class Initialized
INFO - 2024-03-14 15:57:33 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:33 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:33 --> Controller Class Initialized
INFO - 2024-03-14 15:57:33 --> Helper loaded: cookie_helper
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:33 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:33 --> URI Class Initialized
INFO - 2024-03-14 15:57:33 --> Router Class Initialized
INFO - 2024-03-14 15:57:33 --> Output Class Initialized
INFO - 2024-03-14 15:57:33 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:33 --> Input Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Loader Class Initialized
INFO - 2024-03-14 15:57:33 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:33 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:33 --> Controller Class Initialized
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:33 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:33 --> URI Class Initialized
INFO - 2024-03-14 15:57:33 --> Router Class Initialized
INFO - 2024-03-14 15:57:33 --> Output Class Initialized
INFO - 2024-03-14 15:57:33 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:33 --> Input Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Language Class Initialized
INFO - 2024-03-14 15:57:33 --> Config Class Initialized
INFO - 2024-03-14 15:57:33 --> Loader Class Initialized
INFO - 2024-03-14 15:57:33 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:33 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:33 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:33 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 15:57:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:33 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:33 --> Total execution time: 0.0298
INFO - 2024-03-14 15:57:40 --> Config Class Initialized
INFO - 2024-03-14 15:57:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:40 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:40 --> URI Class Initialized
INFO - 2024-03-14 15:57:40 --> Router Class Initialized
INFO - 2024-03-14 15:57:40 --> Output Class Initialized
INFO - 2024-03-14 15:57:40 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:40 --> Input Class Initialized
INFO - 2024-03-14 15:57:40 --> Language Class Initialized
INFO - 2024-03-14 15:57:40 --> Language Class Initialized
INFO - 2024-03-14 15:57:40 --> Config Class Initialized
INFO - 2024-03-14 15:57:40 --> Loader Class Initialized
INFO - 2024-03-14 15:57:40 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:40 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:40 --> Controller Class Initialized
INFO - 2024-03-14 15:57:40 --> Helper loaded: cookie_helper
INFO - 2024-03-14 15:57:40 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:40 --> Total execution time: 0.0370
INFO - 2024-03-14 15:57:40 --> Config Class Initialized
INFO - 2024-03-14 15:57:40 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:40 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:40 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:40 --> URI Class Initialized
INFO - 2024-03-14 15:57:40 --> Router Class Initialized
INFO - 2024-03-14 15:57:40 --> Output Class Initialized
INFO - 2024-03-14 15:57:40 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:40 --> Input Class Initialized
INFO - 2024-03-14 15:57:40 --> Language Class Initialized
INFO - 2024-03-14 15:57:40 --> Language Class Initialized
INFO - 2024-03-14 15:57:40 --> Config Class Initialized
INFO - 2024-03-14 15:57:40 --> Loader Class Initialized
INFO - 2024-03-14 15:57:40 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:40 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:40 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:40 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-14 15:57:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:40 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:40 --> Total execution time: 0.0344
INFO - 2024-03-14 15:57:49 --> Config Class Initialized
INFO - 2024-03-14 15:57:49 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:49 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:49 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:49 --> URI Class Initialized
INFO - 2024-03-14 15:57:49 --> Router Class Initialized
INFO - 2024-03-14 15:57:49 --> Output Class Initialized
INFO - 2024-03-14 15:57:49 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:49 --> Input Class Initialized
INFO - 2024-03-14 15:57:49 --> Language Class Initialized
INFO - 2024-03-14 15:57:49 --> Language Class Initialized
INFO - 2024-03-14 15:57:49 --> Config Class Initialized
INFO - 2024-03-14 15:57:49 --> Loader Class Initialized
INFO - 2024-03-14 15:57:49 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:49 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:49 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:49 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:49 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:49 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 15:57:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:49 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:49 --> Total execution time: 0.0757
INFO - 2024-03-14 15:57:52 --> Config Class Initialized
INFO - 2024-03-14 15:57:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:52 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:52 --> URI Class Initialized
INFO - 2024-03-14 15:57:52 --> Router Class Initialized
INFO - 2024-03-14 15:57:52 --> Output Class Initialized
INFO - 2024-03-14 15:57:52 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:52 --> Input Class Initialized
INFO - 2024-03-14 15:57:52 --> Language Class Initialized
INFO - 2024-03-14 15:57:52 --> Language Class Initialized
INFO - 2024-03-14 15:57:52 --> Config Class Initialized
INFO - 2024-03-14 15:57:52 --> Loader Class Initialized
INFO - 2024-03-14 15:57:52 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:52 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:52 --> Controller Class Initialized
DEBUG - 2024-03-14 15:57:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 15:57:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 15:57:52 --> Final output sent to browser
DEBUG - 2024-03-14 15:57:52 --> Total execution time: 0.0312
INFO - 2024-03-14 15:57:52 --> Config Class Initialized
INFO - 2024-03-14 15:57:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:57:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:57:52 --> Utf8 Class Initialized
INFO - 2024-03-14 15:57:52 --> URI Class Initialized
INFO - 2024-03-14 15:57:52 --> Router Class Initialized
INFO - 2024-03-14 15:57:52 --> Output Class Initialized
INFO - 2024-03-14 15:57:52 --> Security Class Initialized
DEBUG - 2024-03-14 15:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:57:52 --> Input Class Initialized
INFO - 2024-03-14 15:57:52 --> Language Class Initialized
INFO - 2024-03-14 15:57:52 --> Language Class Initialized
INFO - 2024-03-14 15:57:52 --> Config Class Initialized
INFO - 2024-03-14 15:57:52 --> Loader Class Initialized
INFO - 2024-03-14 15:57:52 --> Helper loaded: url_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: file_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: form_helper
INFO - 2024-03-14 15:57:52 --> Helper loaded: my_helper
INFO - 2024-03-14 15:57:52 --> Database Driver Class Initialized
INFO - 2024-03-14 15:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:57:52 --> Controller Class Initialized
INFO - 2024-03-14 15:59:11 --> Config Class Initialized
INFO - 2024-03-14 15:59:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:59:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:59:11 --> Utf8 Class Initialized
INFO - 2024-03-14 15:59:11 --> URI Class Initialized
INFO - 2024-03-14 15:59:11 --> Router Class Initialized
INFO - 2024-03-14 15:59:11 --> Output Class Initialized
INFO - 2024-03-14 15:59:11 --> Security Class Initialized
DEBUG - 2024-03-14 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:59:11 --> Input Class Initialized
INFO - 2024-03-14 15:59:11 --> Language Class Initialized
INFO - 2024-03-14 15:59:11 --> Language Class Initialized
INFO - 2024-03-14 15:59:11 --> Config Class Initialized
INFO - 2024-03-14 15:59:11 --> Loader Class Initialized
INFO - 2024-03-14 15:59:11 --> Helper loaded: url_helper
INFO - 2024-03-14 15:59:11 --> Helper loaded: file_helper
INFO - 2024-03-14 15:59:11 --> Helper loaded: form_helper
INFO - 2024-03-14 15:59:11 --> Helper loaded: my_helper
INFO - 2024-03-14 15:59:11 --> Database Driver Class Initialized
INFO - 2024-03-14 15:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:59:11 --> Controller Class Initialized
INFO - 2024-03-14 15:59:11 --> Final output sent to browser
DEBUG - 2024-03-14 15:59:11 --> Total execution time: 0.0299
INFO - 2024-03-14 15:59:20 --> Config Class Initialized
INFO - 2024-03-14 15:59:20 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:59:20 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:59:20 --> Utf8 Class Initialized
INFO - 2024-03-14 15:59:20 --> URI Class Initialized
INFO - 2024-03-14 15:59:20 --> Router Class Initialized
INFO - 2024-03-14 15:59:20 --> Output Class Initialized
INFO - 2024-03-14 15:59:20 --> Security Class Initialized
DEBUG - 2024-03-14 15:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:59:20 --> Input Class Initialized
INFO - 2024-03-14 15:59:20 --> Language Class Initialized
INFO - 2024-03-14 15:59:20 --> Language Class Initialized
INFO - 2024-03-14 15:59:20 --> Config Class Initialized
INFO - 2024-03-14 15:59:20 --> Loader Class Initialized
INFO - 2024-03-14 15:59:20 --> Helper loaded: url_helper
INFO - 2024-03-14 15:59:20 --> Helper loaded: file_helper
INFO - 2024-03-14 15:59:20 --> Helper loaded: form_helper
INFO - 2024-03-14 15:59:20 --> Helper loaded: my_helper
INFO - 2024-03-14 15:59:20 --> Database Driver Class Initialized
INFO - 2024-03-14 15:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:59:20 --> Controller Class Initialized
ERROR - 2024-03-14 15:59:20 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 15:59:20 --> Final output sent to browser
DEBUG - 2024-03-14 15:59:20 --> Total execution time: 0.0426
INFO - 2024-03-14 15:59:29 --> Config Class Initialized
INFO - 2024-03-14 15:59:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:59:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:59:29 --> Utf8 Class Initialized
INFO - 2024-03-14 15:59:29 --> URI Class Initialized
INFO - 2024-03-14 15:59:29 --> Router Class Initialized
INFO - 2024-03-14 15:59:29 --> Output Class Initialized
INFO - 2024-03-14 15:59:29 --> Security Class Initialized
DEBUG - 2024-03-14 15:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:59:29 --> Input Class Initialized
INFO - 2024-03-14 15:59:29 --> Language Class Initialized
INFO - 2024-03-14 15:59:29 --> Language Class Initialized
INFO - 2024-03-14 15:59:29 --> Config Class Initialized
INFO - 2024-03-14 15:59:29 --> Loader Class Initialized
INFO - 2024-03-14 15:59:29 --> Helper loaded: url_helper
INFO - 2024-03-14 15:59:29 --> Helper loaded: file_helper
INFO - 2024-03-14 15:59:29 --> Helper loaded: form_helper
INFO - 2024-03-14 15:59:29 --> Helper loaded: my_helper
INFO - 2024-03-14 15:59:29 --> Database Driver Class Initialized
INFO - 2024-03-14 15:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:59:29 --> Controller Class Initialized
INFO - 2024-03-14 15:59:29 --> Final output sent to browser
DEBUG - 2024-03-14 15:59:29 --> Total execution time: 0.0381
INFO - 2024-03-14 15:59:57 --> Config Class Initialized
INFO - 2024-03-14 15:59:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 15:59:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 15:59:57 --> Utf8 Class Initialized
INFO - 2024-03-14 15:59:57 --> URI Class Initialized
INFO - 2024-03-14 15:59:57 --> Router Class Initialized
INFO - 2024-03-14 15:59:57 --> Output Class Initialized
INFO - 2024-03-14 15:59:57 --> Security Class Initialized
DEBUG - 2024-03-14 15:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 15:59:57 --> Input Class Initialized
INFO - 2024-03-14 15:59:57 --> Language Class Initialized
INFO - 2024-03-14 15:59:57 --> Language Class Initialized
INFO - 2024-03-14 15:59:57 --> Config Class Initialized
INFO - 2024-03-14 15:59:57 --> Loader Class Initialized
INFO - 2024-03-14 15:59:57 --> Helper loaded: url_helper
INFO - 2024-03-14 15:59:57 --> Helper loaded: file_helper
INFO - 2024-03-14 15:59:57 --> Helper loaded: form_helper
INFO - 2024-03-14 15:59:57 --> Helper loaded: my_helper
INFO - 2024-03-14 15:59:57 --> Database Driver Class Initialized
INFO - 2024-03-14 15:59:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 15:59:57 --> Controller Class Initialized
INFO - 2024-03-14 16:00:20 --> Config Class Initialized
INFO - 2024-03-14 16:00:20 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:00:20 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:00:20 --> Utf8 Class Initialized
INFO - 2024-03-14 16:00:20 --> URI Class Initialized
INFO - 2024-03-14 16:00:20 --> Router Class Initialized
INFO - 2024-03-14 16:00:20 --> Output Class Initialized
INFO - 2024-03-14 16:00:20 --> Security Class Initialized
DEBUG - 2024-03-14 16:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:00:20 --> Input Class Initialized
INFO - 2024-03-14 16:00:20 --> Language Class Initialized
INFO - 2024-03-14 16:00:20 --> Language Class Initialized
INFO - 2024-03-14 16:00:20 --> Config Class Initialized
INFO - 2024-03-14 16:00:20 --> Loader Class Initialized
INFO - 2024-03-14 16:00:20 --> Helper loaded: url_helper
INFO - 2024-03-14 16:00:20 --> Helper loaded: file_helper
INFO - 2024-03-14 16:00:20 --> Helper loaded: form_helper
INFO - 2024-03-14 16:00:20 --> Helper loaded: my_helper
INFO - 2024-03-14 16:00:20 --> Database Driver Class Initialized
INFO - 2024-03-14 16:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:00:20 --> Controller Class Initialized
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2024-03-14 16:00:20 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2024-03-14 16:00:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2024-03-14 16:00:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:00:20 --> Final output sent to browser
DEBUG - 2024-03-14 16:00:20 --> Total execution time: 0.0544
INFO - 2024-03-14 16:01:37 --> Config Class Initialized
INFO - 2024-03-14 16:01:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:01:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:01:37 --> Utf8 Class Initialized
INFO - 2024-03-14 16:01:37 --> URI Class Initialized
INFO - 2024-03-14 16:01:37 --> Router Class Initialized
INFO - 2024-03-14 16:01:37 --> Output Class Initialized
INFO - 2024-03-14 16:01:37 --> Security Class Initialized
DEBUG - 2024-03-14 16:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:01:37 --> Input Class Initialized
INFO - 2024-03-14 16:01:37 --> Language Class Initialized
INFO - 2024-03-14 16:01:37 --> Language Class Initialized
INFO - 2024-03-14 16:01:37 --> Config Class Initialized
INFO - 2024-03-14 16:01:37 --> Loader Class Initialized
INFO - 2024-03-14 16:01:37 --> Helper loaded: url_helper
INFO - 2024-03-14 16:01:37 --> Helper loaded: file_helper
INFO - 2024-03-14 16:01:37 --> Helper loaded: form_helper
INFO - 2024-03-14 16:01:37 --> Helper loaded: my_helper
INFO - 2024-03-14 16:01:37 --> Database Driver Class Initialized
INFO - 2024-03-14 16:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:01:37 --> Controller Class Initialized
DEBUG - 2024-03-14 16:01:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 16:01:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:01:37 --> Final output sent to browser
DEBUG - 2024-03-14 16:01:37 --> Total execution time: 0.0430
INFO - 2024-03-14 16:01:39 --> Config Class Initialized
INFO - 2024-03-14 16:01:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:01:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:01:39 --> Utf8 Class Initialized
INFO - 2024-03-14 16:01:39 --> URI Class Initialized
INFO - 2024-03-14 16:01:39 --> Router Class Initialized
INFO - 2024-03-14 16:01:39 --> Output Class Initialized
INFO - 2024-03-14 16:01:39 --> Security Class Initialized
DEBUG - 2024-03-14 16:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:01:39 --> Input Class Initialized
INFO - 2024-03-14 16:01:39 --> Language Class Initialized
INFO - 2024-03-14 16:01:39 --> Language Class Initialized
INFO - 2024-03-14 16:01:39 --> Config Class Initialized
INFO - 2024-03-14 16:01:39 --> Loader Class Initialized
INFO - 2024-03-14 16:01:39 --> Helper loaded: url_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: file_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: form_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: my_helper
INFO - 2024-03-14 16:01:39 --> Database Driver Class Initialized
INFO - 2024-03-14 16:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:01:39 --> Controller Class Initialized
DEBUG - 2024-03-14 16:01:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:01:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:01:39 --> Final output sent to browser
DEBUG - 2024-03-14 16:01:39 --> Total execution time: 0.1400
INFO - 2024-03-14 16:01:39 --> Config Class Initialized
INFO - 2024-03-14 16:01:39 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:01:39 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:01:39 --> Utf8 Class Initialized
INFO - 2024-03-14 16:01:39 --> URI Class Initialized
INFO - 2024-03-14 16:01:39 --> Router Class Initialized
INFO - 2024-03-14 16:01:39 --> Output Class Initialized
INFO - 2024-03-14 16:01:39 --> Security Class Initialized
DEBUG - 2024-03-14 16:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:01:39 --> Input Class Initialized
INFO - 2024-03-14 16:01:39 --> Language Class Initialized
INFO - 2024-03-14 16:01:39 --> Language Class Initialized
INFO - 2024-03-14 16:01:39 --> Config Class Initialized
INFO - 2024-03-14 16:01:39 --> Loader Class Initialized
INFO - 2024-03-14 16:01:39 --> Helper loaded: url_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: file_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: form_helper
INFO - 2024-03-14 16:01:39 --> Helper loaded: my_helper
INFO - 2024-03-14 16:01:39 --> Database Driver Class Initialized
INFO - 2024-03-14 16:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:01:39 --> Controller Class Initialized
INFO - 2024-03-14 16:01:43 --> Config Class Initialized
INFO - 2024-03-14 16:01:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:01:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:01:43 --> Utf8 Class Initialized
INFO - 2024-03-14 16:01:43 --> URI Class Initialized
INFO - 2024-03-14 16:01:43 --> Router Class Initialized
INFO - 2024-03-14 16:01:43 --> Output Class Initialized
INFO - 2024-03-14 16:01:43 --> Security Class Initialized
DEBUG - 2024-03-14 16:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:01:43 --> Input Class Initialized
INFO - 2024-03-14 16:01:43 --> Language Class Initialized
INFO - 2024-03-14 16:01:43 --> Language Class Initialized
INFO - 2024-03-14 16:01:43 --> Config Class Initialized
INFO - 2024-03-14 16:01:43 --> Loader Class Initialized
INFO - 2024-03-14 16:01:43 --> Helper loaded: url_helper
INFO - 2024-03-14 16:01:43 --> Helper loaded: file_helper
INFO - 2024-03-14 16:01:43 --> Helper loaded: form_helper
INFO - 2024-03-14 16:01:43 --> Helper loaded: my_helper
INFO - 2024-03-14 16:01:43 --> Database Driver Class Initialized
INFO - 2024-03-14 16:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:01:43 --> Controller Class Initialized
INFO - 2024-03-14 16:01:43 --> Final output sent to browser
DEBUG - 2024-03-14 16:01:43 --> Total execution time: 0.0306
INFO - 2024-03-14 16:01:57 --> Config Class Initialized
INFO - 2024-03-14 16:01:57 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:01:57 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:01:57 --> Utf8 Class Initialized
INFO - 2024-03-14 16:01:57 --> URI Class Initialized
INFO - 2024-03-14 16:01:57 --> Router Class Initialized
INFO - 2024-03-14 16:01:57 --> Output Class Initialized
INFO - 2024-03-14 16:01:57 --> Security Class Initialized
DEBUG - 2024-03-14 16:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:01:57 --> Input Class Initialized
INFO - 2024-03-14 16:01:57 --> Language Class Initialized
INFO - 2024-03-14 16:01:57 --> Language Class Initialized
INFO - 2024-03-14 16:01:57 --> Config Class Initialized
INFO - 2024-03-14 16:01:57 --> Loader Class Initialized
INFO - 2024-03-14 16:01:57 --> Helper loaded: url_helper
INFO - 2024-03-14 16:01:57 --> Helper loaded: file_helper
INFO - 2024-03-14 16:01:57 --> Helper loaded: form_helper
INFO - 2024-03-14 16:01:57 --> Helper loaded: my_helper
INFO - 2024-03-14 16:01:57 --> Database Driver Class Initialized
INFO - 2024-03-14 16:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:01:57 --> Controller Class Initialized
ERROR - 2024-03-14 16:01:57 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:01:57 --> Final output sent to browser
DEBUG - 2024-03-14 16:01:57 --> Total execution time: 0.0346
INFO - 2024-03-14 16:02:13 --> Config Class Initialized
INFO - 2024-03-14 16:02:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:13 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:13 --> URI Class Initialized
INFO - 2024-03-14 16:02:13 --> Router Class Initialized
INFO - 2024-03-14 16:02:13 --> Output Class Initialized
INFO - 2024-03-14 16:02:13 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:13 --> Input Class Initialized
INFO - 2024-03-14 16:02:13 --> Language Class Initialized
INFO - 2024-03-14 16:02:13 --> Language Class Initialized
INFO - 2024-03-14 16:02:13 --> Config Class Initialized
INFO - 2024-03-14 16:02:13 --> Loader Class Initialized
INFO - 2024-03-14 16:02:13 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:13 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:13 --> Controller Class Initialized
DEBUG - 2024-03-14 16:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:02:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:02:13 --> Final output sent to browser
DEBUG - 2024-03-14 16:02:13 --> Total execution time: 0.0393
INFO - 2024-03-14 16:02:13 --> Config Class Initialized
INFO - 2024-03-14 16:02:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:13 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:13 --> URI Class Initialized
INFO - 2024-03-14 16:02:13 --> Router Class Initialized
INFO - 2024-03-14 16:02:13 --> Output Class Initialized
INFO - 2024-03-14 16:02:13 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:13 --> Input Class Initialized
INFO - 2024-03-14 16:02:13 --> Language Class Initialized
INFO - 2024-03-14 16:02:13 --> Language Class Initialized
INFO - 2024-03-14 16:02:13 --> Config Class Initialized
INFO - 2024-03-14 16:02:13 --> Loader Class Initialized
INFO - 2024-03-14 16:02:13 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:13 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:13 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:13 --> Controller Class Initialized
INFO - 2024-03-14 16:02:18 --> Config Class Initialized
INFO - 2024-03-14 16:02:18 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:18 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:18 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:18 --> URI Class Initialized
INFO - 2024-03-14 16:02:18 --> Router Class Initialized
INFO - 2024-03-14 16:02:18 --> Output Class Initialized
INFO - 2024-03-14 16:02:18 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:18 --> Input Class Initialized
INFO - 2024-03-14 16:02:18 --> Language Class Initialized
INFO - 2024-03-14 16:02:18 --> Language Class Initialized
INFO - 2024-03-14 16:02:18 --> Config Class Initialized
INFO - 2024-03-14 16:02:18 --> Loader Class Initialized
INFO - 2024-03-14 16:02:18 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:18 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:18 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:18 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:18 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:18 --> Controller Class Initialized
INFO - 2024-03-14 16:02:18 --> Final output sent to browser
DEBUG - 2024-03-14 16:02:18 --> Total execution time: 0.0513
INFO - 2024-03-14 16:02:53 --> Config Class Initialized
INFO - 2024-03-14 16:02:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:53 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:53 --> URI Class Initialized
INFO - 2024-03-14 16:02:53 --> Router Class Initialized
INFO - 2024-03-14 16:02:53 --> Output Class Initialized
INFO - 2024-03-14 16:02:53 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:53 --> Input Class Initialized
INFO - 2024-03-14 16:02:53 --> Language Class Initialized
INFO - 2024-03-14 16:02:53 --> Language Class Initialized
INFO - 2024-03-14 16:02:53 --> Config Class Initialized
INFO - 2024-03-14 16:02:53 --> Loader Class Initialized
INFO - 2024-03-14 16:02:53 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:53 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:53 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:53 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:53 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:53 --> Controller Class Initialized
ERROR - 2024-03-14 16:02:53 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:02:53 --> Final output sent to browser
DEBUG - 2024-03-14 16:02:53 --> Total execution time: 0.0636
INFO - 2024-03-14 16:02:58 --> Config Class Initialized
INFO - 2024-03-14 16:02:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:58 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:58 --> URI Class Initialized
INFO - 2024-03-14 16:02:58 --> Router Class Initialized
INFO - 2024-03-14 16:02:58 --> Output Class Initialized
INFO - 2024-03-14 16:02:58 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:58 --> Input Class Initialized
INFO - 2024-03-14 16:02:58 --> Language Class Initialized
INFO - 2024-03-14 16:02:58 --> Language Class Initialized
INFO - 2024-03-14 16:02:58 --> Config Class Initialized
INFO - 2024-03-14 16:02:58 --> Loader Class Initialized
INFO - 2024-03-14 16:02:58 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:58 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:58 --> Controller Class Initialized
DEBUG - 2024-03-14 16:02:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:02:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:02:58 --> Final output sent to browser
DEBUG - 2024-03-14 16:02:58 --> Total execution time: 0.0370
INFO - 2024-03-14 16:02:58 --> Config Class Initialized
INFO - 2024-03-14 16:02:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:02:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:02:58 --> Utf8 Class Initialized
INFO - 2024-03-14 16:02:58 --> URI Class Initialized
INFO - 2024-03-14 16:02:58 --> Router Class Initialized
INFO - 2024-03-14 16:02:58 --> Output Class Initialized
INFO - 2024-03-14 16:02:58 --> Security Class Initialized
DEBUG - 2024-03-14 16:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:02:58 --> Input Class Initialized
INFO - 2024-03-14 16:02:58 --> Language Class Initialized
INFO - 2024-03-14 16:02:58 --> Language Class Initialized
INFO - 2024-03-14 16:02:58 --> Config Class Initialized
INFO - 2024-03-14 16:02:58 --> Loader Class Initialized
INFO - 2024-03-14 16:02:58 --> Helper loaded: url_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: file_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: form_helper
INFO - 2024-03-14 16:02:58 --> Helper loaded: my_helper
INFO - 2024-03-14 16:02:58 --> Database Driver Class Initialized
INFO - 2024-03-14 16:02:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:02:58 --> Controller Class Initialized
INFO - 2024-03-14 16:03:00 --> Config Class Initialized
INFO - 2024-03-14 16:03:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:01 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:01 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:01 --> URI Class Initialized
INFO - 2024-03-14 16:03:01 --> Router Class Initialized
INFO - 2024-03-14 16:03:01 --> Output Class Initialized
INFO - 2024-03-14 16:03:01 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:01 --> Input Class Initialized
INFO - 2024-03-14 16:03:01 --> Language Class Initialized
INFO - 2024-03-14 16:03:01 --> Language Class Initialized
INFO - 2024-03-14 16:03:01 --> Config Class Initialized
INFO - 2024-03-14 16:03:01 --> Loader Class Initialized
INFO - 2024-03-14 16:03:01 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:01 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:01 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:01 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:01 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:01 --> Controller Class Initialized
INFO - 2024-03-14 16:03:01 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:01 --> Total execution time: 0.0358
INFO - 2024-03-14 16:03:11 --> Config Class Initialized
INFO - 2024-03-14 16:03:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:11 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:11 --> URI Class Initialized
INFO - 2024-03-14 16:03:11 --> Router Class Initialized
INFO - 2024-03-14 16:03:11 --> Output Class Initialized
INFO - 2024-03-14 16:03:11 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:11 --> Input Class Initialized
INFO - 2024-03-14 16:03:11 --> Language Class Initialized
INFO - 2024-03-14 16:03:11 --> Language Class Initialized
INFO - 2024-03-14 16:03:11 --> Config Class Initialized
INFO - 2024-03-14 16:03:11 --> Loader Class Initialized
INFO - 2024-03-14 16:03:11 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:11 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:11 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:11 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:11 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:11 --> Controller Class Initialized
ERROR - 2024-03-14 16:03:11 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:03:11 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:11 --> Total execution time: 0.0399
INFO - 2024-03-14 16:03:14 --> Config Class Initialized
INFO - 2024-03-14 16:03:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:14 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:14 --> URI Class Initialized
INFO - 2024-03-14 16:03:14 --> Router Class Initialized
INFO - 2024-03-14 16:03:14 --> Output Class Initialized
INFO - 2024-03-14 16:03:14 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:14 --> Input Class Initialized
INFO - 2024-03-14 16:03:14 --> Language Class Initialized
INFO - 2024-03-14 16:03:14 --> Language Class Initialized
INFO - 2024-03-14 16:03:14 --> Config Class Initialized
INFO - 2024-03-14 16:03:14 --> Loader Class Initialized
INFO - 2024-03-14 16:03:14 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:14 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:14 --> Controller Class Initialized
DEBUG - 2024-03-14 16:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:03:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:03:14 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:14 --> Total execution time: 0.0824
INFO - 2024-03-14 16:03:14 --> Config Class Initialized
INFO - 2024-03-14 16:03:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:14 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:14 --> URI Class Initialized
INFO - 2024-03-14 16:03:14 --> Router Class Initialized
INFO - 2024-03-14 16:03:14 --> Output Class Initialized
INFO - 2024-03-14 16:03:14 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:14 --> Input Class Initialized
INFO - 2024-03-14 16:03:14 --> Language Class Initialized
INFO - 2024-03-14 16:03:14 --> Language Class Initialized
INFO - 2024-03-14 16:03:14 --> Config Class Initialized
INFO - 2024-03-14 16:03:14 --> Loader Class Initialized
INFO - 2024-03-14 16:03:14 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:14 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:14 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:14 --> Controller Class Initialized
INFO - 2024-03-14 16:03:17 --> Config Class Initialized
INFO - 2024-03-14 16:03:17 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:17 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:17 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:17 --> URI Class Initialized
INFO - 2024-03-14 16:03:17 --> Router Class Initialized
INFO - 2024-03-14 16:03:17 --> Output Class Initialized
INFO - 2024-03-14 16:03:17 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:17 --> Input Class Initialized
INFO - 2024-03-14 16:03:17 --> Language Class Initialized
INFO - 2024-03-14 16:03:17 --> Language Class Initialized
INFO - 2024-03-14 16:03:17 --> Config Class Initialized
INFO - 2024-03-14 16:03:17 --> Loader Class Initialized
INFO - 2024-03-14 16:03:17 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:17 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:17 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:17 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:17 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:17 --> Controller Class Initialized
INFO - 2024-03-14 16:03:17 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:17 --> Total execution time: 0.0339
INFO - 2024-03-14 16:03:29 --> Config Class Initialized
INFO - 2024-03-14 16:03:29 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:29 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:29 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:29 --> URI Class Initialized
INFO - 2024-03-14 16:03:29 --> Router Class Initialized
INFO - 2024-03-14 16:03:29 --> Output Class Initialized
INFO - 2024-03-14 16:03:29 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:29 --> Input Class Initialized
INFO - 2024-03-14 16:03:29 --> Language Class Initialized
INFO - 2024-03-14 16:03:29 --> Language Class Initialized
INFO - 2024-03-14 16:03:29 --> Config Class Initialized
INFO - 2024-03-14 16:03:29 --> Loader Class Initialized
INFO - 2024-03-14 16:03:29 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:29 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:29 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:29 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:29 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:29 --> Controller Class Initialized
ERROR - 2024-03-14 16:03:29 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:03:29 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:29 --> Total execution time: 0.0312
INFO - 2024-03-14 16:03:32 --> Config Class Initialized
INFO - 2024-03-14 16:03:32 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:32 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:32 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:32 --> URI Class Initialized
INFO - 2024-03-14 16:03:32 --> Router Class Initialized
INFO - 2024-03-14 16:03:32 --> Output Class Initialized
INFO - 2024-03-14 16:03:32 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:32 --> Input Class Initialized
INFO - 2024-03-14 16:03:32 --> Language Class Initialized
INFO - 2024-03-14 16:03:32 --> Language Class Initialized
INFO - 2024-03-14 16:03:32 --> Config Class Initialized
INFO - 2024-03-14 16:03:32 --> Loader Class Initialized
INFO - 2024-03-14 16:03:32 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:32 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:32 --> Controller Class Initialized
DEBUG - 2024-03-14 16:03:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:03:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:03:32 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:32 --> Total execution time: 0.0461
INFO - 2024-03-14 16:03:32 --> Config Class Initialized
INFO - 2024-03-14 16:03:32 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:32 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:32 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:32 --> URI Class Initialized
INFO - 2024-03-14 16:03:32 --> Router Class Initialized
INFO - 2024-03-14 16:03:32 --> Output Class Initialized
INFO - 2024-03-14 16:03:32 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:32 --> Input Class Initialized
INFO - 2024-03-14 16:03:32 --> Language Class Initialized
INFO - 2024-03-14 16:03:32 --> Language Class Initialized
INFO - 2024-03-14 16:03:32 --> Config Class Initialized
INFO - 2024-03-14 16:03:32 --> Loader Class Initialized
INFO - 2024-03-14 16:03:32 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:32 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:32 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:32 --> Controller Class Initialized
INFO - 2024-03-14 16:03:34 --> Config Class Initialized
INFO - 2024-03-14 16:03:34 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:03:34 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:03:34 --> Utf8 Class Initialized
INFO - 2024-03-14 16:03:34 --> URI Class Initialized
INFO - 2024-03-14 16:03:34 --> Router Class Initialized
INFO - 2024-03-14 16:03:34 --> Output Class Initialized
INFO - 2024-03-14 16:03:34 --> Security Class Initialized
DEBUG - 2024-03-14 16:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:03:34 --> Input Class Initialized
INFO - 2024-03-14 16:03:34 --> Language Class Initialized
INFO - 2024-03-14 16:03:34 --> Language Class Initialized
INFO - 2024-03-14 16:03:34 --> Config Class Initialized
INFO - 2024-03-14 16:03:34 --> Loader Class Initialized
INFO - 2024-03-14 16:03:34 --> Helper loaded: url_helper
INFO - 2024-03-14 16:03:34 --> Helper loaded: file_helper
INFO - 2024-03-14 16:03:34 --> Helper loaded: form_helper
INFO - 2024-03-14 16:03:34 --> Helper loaded: my_helper
INFO - 2024-03-14 16:03:34 --> Database Driver Class Initialized
INFO - 2024-03-14 16:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:03:34 --> Controller Class Initialized
INFO - 2024-03-14 16:03:34 --> Final output sent to browser
DEBUG - 2024-03-14 16:03:34 --> Total execution time: 0.0336
INFO - 2024-03-14 16:04:15 --> Config Class Initialized
INFO - 2024-03-14 16:04:15 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:15 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:15 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:15 --> URI Class Initialized
INFO - 2024-03-14 16:04:15 --> Router Class Initialized
INFO - 2024-03-14 16:04:15 --> Output Class Initialized
INFO - 2024-03-14 16:04:15 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:15 --> Input Class Initialized
INFO - 2024-03-14 16:04:15 --> Language Class Initialized
INFO - 2024-03-14 16:04:15 --> Language Class Initialized
INFO - 2024-03-14 16:04:15 --> Config Class Initialized
INFO - 2024-03-14 16:04:15 --> Loader Class Initialized
INFO - 2024-03-14 16:04:15 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:15 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:15 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:15 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:15 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:15 --> Controller Class Initialized
ERROR - 2024-03-14 16:04:15 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:04:15 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:15 --> Total execution time: 0.0335
INFO - 2024-03-14 16:04:16 --> Config Class Initialized
INFO - 2024-03-14 16:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:16 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:16 --> URI Class Initialized
INFO - 2024-03-14 16:04:16 --> Router Class Initialized
INFO - 2024-03-14 16:04:16 --> Output Class Initialized
INFO - 2024-03-14 16:04:16 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:16 --> Input Class Initialized
INFO - 2024-03-14 16:04:16 --> Language Class Initialized
INFO - 2024-03-14 16:04:16 --> Language Class Initialized
INFO - 2024-03-14 16:04:16 --> Config Class Initialized
INFO - 2024-03-14 16:04:16 --> Loader Class Initialized
INFO - 2024-03-14 16:04:16 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:16 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:16 --> Controller Class Initialized
DEBUG - 2024-03-14 16:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:04:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:04:16 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:16 --> Total execution time: 0.0330
INFO - 2024-03-14 16:04:16 --> Config Class Initialized
INFO - 2024-03-14 16:04:16 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:16 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:16 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:16 --> URI Class Initialized
INFO - 2024-03-14 16:04:16 --> Router Class Initialized
INFO - 2024-03-14 16:04:16 --> Output Class Initialized
INFO - 2024-03-14 16:04:16 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:16 --> Input Class Initialized
INFO - 2024-03-14 16:04:16 --> Language Class Initialized
INFO - 2024-03-14 16:04:16 --> Language Class Initialized
INFO - 2024-03-14 16:04:16 --> Config Class Initialized
INFO - 2024-03-14 16:04:16 --> Loader Class Initialized
INFO - 2024-03-14 16:04:16 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:16 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:16 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:16 --> Controller Class Initialized
INFO - 2024-03-14 16:04:20 --> Config Class Initialized
INFO - 2024-03-14 16:04:20 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:20 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:20 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:20 --> URI Class Initialized
INFO - 2024-03-14 16:04:20 --> Router Class Initialized
INFO - 2024-03-14 16:04:20 --> Output Class Initialized
INFO - 2024-03-14 16:04:20 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:20 --> Input Class Initialized
INFO - 2024-03-14 16:04:20 --> Language Class Initialized
INFO - 2024-03-14 16:04:20 --> Language Class Initialized
INFO - 2024-03-14 16:04:20 --> Config Class Initialized
INFO - 2024-03-14 16:04:20 --> Loader Class Initialized
INFO - 2024-03-14 16:04:20 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:20 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:20 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:20 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:20 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:20 --> Controller Class Initialized
INFO - 2024-03-14 16:04:20 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:20 --> Total execution time: 0.0308
INFO - 2024-03-14 16:04:31 --> Config Class Initialized
INFO - 2024-03-14 16:04:31 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:31 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:31 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:31 --> URI Class Initialized
INFO - 2024-03-14 16:04:31 --> Router Class Initialized
INFO - 2024-03-14 16:04:31 --> Output Class Initialized
INFO - 2024-03-14 16:04:31 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:31 --> Input Class Initialized
INFO - 2024-03-14 16:04:31 --> Language Class Initialized
INFO - 2024-03-14 16:04:31 --> Language Class Initialized
INFO - 2024-03-14 16:04:31 --> Config Class Initialized
INFO - 2024-03-14 16:04:31 --> Loader Class Initialized
INFO - 2024-03-14 16:04:31 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:31 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:31 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:31 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:31 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:31 --> Controller Class Initialized
ERROR - 2024-03-14 16:04:31 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:04:31 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:31 --> Total execution time: 0.1326
INFO - 2024-03-14 16:04:32 --> Config Class Initialized
INFO - 2024-03-14 16:04:32 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:32 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:32 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:32 --> URI Class Initialized
INFO - 2024-03-14 16:04:32 --> Router Class Initialized
INFO - 2024-03-14 16:04:32 --> Output Class Initialized
INFO - 2024-03-14 16:04:32 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:32 --> Input Class Initialized
INFO - 2024-03-14 16:04:32 --> Language Class Initialized
INFO - 2024-03-14 16:04:32 --> Language Class Initialized
INFO - 2024-03-14 16:04:32 --> Config Class Initialized
INFO - 2024-03-14 16:04:32 --> Loader Class Initialized
INFO - 2024-03-14 16:04:32 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:32 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:32 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:32 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:32 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:32 --> Controller Class Initialized
DEBUG - 2024-03-14 16:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:04:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:04:32 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:32 --> Total execution time: 0.0455
INFO - 2024-03-14 16:04:33 --> Config Class Initialized
INFO - 2024-03-14 16:04:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:33 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:33 --> URI Class Initialized
INFO - 2024-03-14 16:04:33 --> Router Class Initialized
INFO - 2024-03-14 16:04:33 --> Output Class Initialized
INFO - 2024-03-14 16:04:33 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:33 --> Input Class Initialized
INFO - 2024-03-14 16:04:33 --> Language Class Initialized
INFO - 2024-03-14 16:04:33 --> Language Class Initialized
INFO - 2024-03-14 16:04:33 --> Config Class Initialized
INFO - 2024-03-14 16:04:33 --> Loader Class Initialized
INFO - 2024-03-14 16:04:33 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:33 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:33 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:33 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:33 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:33 --> Controller Class Initialized
INFO - 2024-03-14 16:04:37 --> Config Class Initialized
INFO - 2024-03-14 16:04:37 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:37 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:37 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:37 --> URI Class Initialized
INFO - 2024-03-14 16:04:37 --> Router Class Initialized
INFO - 2024-03-14 16:04:37 --> Output Class Initialized
INFO - 2024-03-14 16:04:37 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:37 --> Input Class Initialized
INFO - 2024-03-14 16:04:37 --> Language Class Initialized
INFO - 2024-03-14 16:04:37 --> Language Class Initialized
INFO - 2024-03-14 16:04:37 --> Config Class Initialized
INFO - 2024-03-14 16:04:37 --> Loader Class Initialized
INFO - 2024-03-14 16:04:37 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:37 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:37 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:37 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:37 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:37 --> Controller Class Initialized
INFO - 2024-03-14 16:04:38 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:38 --> Total execution time: 0.0337
INFO - 2024-03-14 16:04:45 --> Config Class Initialized
INFO - 2024-03-14 16:04:45 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:45 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:45 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:45 --> URI Class Initialized
INFO - 2024-03-14 16:04:45 --> Router Class Initialized
INFO - 2024-03-14 16:04:45 --> Output Class Initialized
INFO - 2024-03-14 16:04:45 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:45 --> Input Class Initialized
INFO - 2024-03-14 16:04:45 --> Language Class Initialized
INFO - 2024-03-14 16:04:45 --> Language Class Initialized
INFO - 2024-03-14 16:04:45 --> Config Class Initialized
INFO - 2024-03-14 16:04:45 --> Loader Class Initialized
INFO - 2024-03-14 16:04:45 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:45 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:45 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:45 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:45 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:45 --> Controller Class Initialized
ERROR - 2024-03-14 16:04:45 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:04:45 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:45 --> Total execution time: 0.0356
INFO - 2024-03-14 16:04:47 --> Config Class Initialized
INFO - 2024-03-14 16:04:47 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:47 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:47 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:47 --> URI Class Initialized
INFO - 2024-03-14 16:04:47 --> Router Class Initialized
INFO - 2024-03-14 16:04:47 --> Output Class Initialized
INFO - 2024-03-14 16:04:47 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:47 --> Input Class Initialized
INFO - 2024-03-14 16:04:47 --> Language Class Initialized
INFO - 2024-03-14 16:04:47 --> Language Class Initialized
INFO - 2024-03-14 16:04:47 --> Config Class Initialized
INFO - 2024-03-14 16:04:47 --> Loader Class Initialized
INFO - 2024-03-14 16:04:47 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:47 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:47 --> Controller Class Initialized
DEBUG - 2024-03-14 16:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_icb/views/list.php
DEBUG - 2024-03-14 16:04:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:04:47 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:47 --> Total execution time: 0.0362
INFO - 2024-03-14 16:04:47 --> Config Class Initialized
INFO - 2024-03-14 16:04:47 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:47 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:47 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:47 --> URI Class Initialized
INFO - 2024-03-14 16:04:47 --> Router Class Initialized
INFO - 2024-03-14 16:04:47 --> Output Class Initialized
INFO - 2024-03-14 16:04:47 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:47 --> Input Class Initialized
INFO - 2024-03-14 16:04:47 --> Language Class Initialized
INFO - 2024-03-14 16:04:47 --> Language Class Initialized
INFO - 2024-03-14 16:04:47 --> Config Class Initialized
INFO - 2024-03-14 16:04:47 --> Loader Class Initialized
INFO - 2024-03-14 16:04:47 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:47 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:47 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:47 --> Controller Class Initialized
INFO - 2024-03-14 16:04:51 --> Config Class Initialized
INFO - 2024-03-14 16:04:51 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:51 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:51 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:51 --> URI Class Initialized
INFO - 2024-03-14 16:04:51 --> Router Class Initialized
INFO - 2024-03-14 16:04:51 --> Output Class Initialized
INFO - 2024-03-14 16:04:51 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:51 --> Input Class Initialized
INFO - 2024-03-14 16:04:51 --> Language Class Initialized
INFO - 2024-03-14 16:04:51 --> Language Class Initialized
INFO - 2024-03-14 16:04:51 --> Config Class Initialized
INFO - 2024-03-14 16:04:51 --> Loader Class Initialized
INFO - 2024-03-14 16:04:51 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:51 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:51 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:51 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:51 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:51 --> Controller Class Initialized
DEBUG - 2024-03-14 16:04:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 16:04:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:04:51 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:51 --> Total execution time: 0.0668
INFO - 2024-03-14 16:04:55 --> Config Class Initialized
INFO - 2024-03-14 16:04:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:55 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:55 --> URI Class Initialized
INFO - 2024-03-14 16:04:55 --> Router Class Initialized
INFO - 2024-03-14 16:04:55 --> Output Class Initialized
INFO - 2024-03-14 16:04:55 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:55 --> Input Class Initialized
INFO - 2024-03-14 16:04:55 --> Language Class Initialized
INFO - 2024-03-14 16:04:55 --> Language Class Initialized
INFO - 2024-03-14 16:04:55 --> Config Class Initialized
INFO - 2024-03-14 16:04:55 --> Loader Class Initialized
INFO - 2024-03-14 16:04:55 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:55 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:55 --> Controller Class Initialized
DEBUG - 2024-03-14 16:04:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:04:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:04:55 --> Final output sent to browser
DEBUG - 2024-03-14 16:04:55 --> Total execution time: 0.0445
INFO - 2024-03-14 16:04:55 --> Config Class Initialized
INFO - 2024-03-14 16:04:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:04:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:04:55 --> Utf8 Class Initialized
INFO - 2024-03-14 16:04:55 --> URI Class Initialized
INFO - 2024-03-14 16:04:55 --> Router Class Initialized
INFO - 2024-03-14 16:04:55 --> Output Class Initialized
INFO - 2024-03-14 16:04:55 --> Security Class Initialized
DEBUG - 2024-03-14 16:04:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:04:55 --> Input Class Initialized
INFO - 2024-03-14 16:04:55 --> Language Class Initialized
INFO - 2024-03-14 16:04:55 --> Language Class Initialized
INFO - 2024-03-14 16:04:55 --> Config Class Initialized
INFO - 2024-03-14 16:04:55 --> Loader Class Initialized
INFO - 2024-03-14 16:04:55 --> Helper loaded: url_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: file_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: form_helper
INFO - 2024-03-14 16:04:55 --> Helper loaded: my_helper
INFO - 2024-03-14 16:04:55 --> Database Driver Class Initialized
INFO - 2024-03-14 16:04:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:04:55 --> Controller Class Initialized
INFO - 2024-03-14 16:05:00 --> Config Class Initialized
INFO - 2024-03-14 16:05:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:00 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:00 --> URI Class Initialized
INFO - 2024-03-14 16:05:00 --> Router Class Initialized
INFO - 2024-03-14 16:05:00 --> Output Class Initialized
INFO - 2024-03-14 16:05:00 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:00 --> Input Class Initialized
INFO - 2024-03-14 16:05:00 --> Language Class Initialized
INFO - 2024-03-14 16:05:00 --> Language Class Initialized
INFO - 2024-03-14 16:05:00 --> Config Class Initialized
INFO - 2024-03-14 16:05:00 --> Loader Class Initialized
INFO - 2024-03-14 16:05:00 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:00 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:00 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:00 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:00 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:00 --> Controller Class Initialized
INFO - 2024-03-14 16:05:00 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:00 --> Total execution time: 0.0797
INFO - 2024-03-14 16:05:12 --> Config Class Initialized
INFO - 2024-03-14 16:05:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:12 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:12 --> URI Class Initialized
INFO - 2024-03-14 16:05:12 --> Router Class Initialized
INFO - 2024-03-14 16:05:12 --> Output Class Initialized
INFO - 2024-03-14 16:05:12 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:12 --> Input Class Initialized
INFO - 2024-03-14 16:05:12 --> Language Class Initialized
INFO - 2024-03-14 16:05:12 --> Language Class Initialized
INFO - 2024-03-14 16:05:12 --> Config Class Initialized
INFO - 2024-03-14 16:05:12 --> Loader Class Initialized
INFO - 2024-03-14 16:05:12 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:12 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:12 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:12 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:12 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:12 --> Controller Class Initialized
ERROR - 2024-03-14 16:05:12 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:05:12 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:12 --> Total execution time: 0.0358
INFO - 2024-03-14 16:05:13 --> Config Class Initialized
INFO - 2024-03-14 16:05:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:13 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:13 --> URI Class Initialized
INFO - 2024-03-14 16:05:13 --> Router Class Initialized
INFO - 2024-03-14 16:05:13 --> Output Class Initialized
INFO - 2024-03-14 16:05:13 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:13 --> Input Class Initialized
INFO - 2024-03-14 16:05:13 --> Language Class Initialized
INFO - 2024-03-14 16:05:13 --> Language Class Initialized
INFO - 2024-03-14 16:05:13 --> Config Class Initialized
INFO - 2024-03-14 16:05:13 --> Loader Class Initialized
INFO - 2024-03-14 16:05:13 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:13 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:13 --> Controller Class Initialized
DEBUG - 2024-03-14 16:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:05:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:05:13 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:13 --> Total execution time: 0.0358
INFO - 2024-03-14 16:05:13 --> Config Class Initialized
INFO - 2024-03-14 16:05:13 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:13 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:13 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:13 --> URI Class Initialized
INFO - 2024-03-14 16:05:13 --> Router Class Initialized
INFO - 2024-03-14 16:05:13 --> Output Class Initialized
INFO - 2024-03-14 16:05:13 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:13 --> Input Class Initialized
INFO - 2024-03-14 16:05:13 --> Language Class Initialized
INFO - 2024-03-14 16:05:13 --> Language Class Initialized
INFO - 2024-03-14 16:05:13 --> Config Class Initialized
INFO - 2024-03-14 16:05:13 --> Loader Class Initialized
INFO - 2024-03-14 16:05:13 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:13 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:13 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:13 --> Controller Class Initialized
INFO - 2024-03-14 16:05:15 --> Config Class Initialized
INFO - 2024-03-14 16:05:15 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:15 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:15 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:15 --> URI Class Initialized
INFO - 2024-03-14 16:05:15 --> Router Class Initialized
INFO - 2024-03-14 16:05:15 --> Output Class Initialized
INFO - 2024-03-14 16:05:15 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:15 --> Input Class Initialized
INFO - 2024-03-14 16:05:15 --> Language Class Initialized
INFO - 2024-03-14 16:05:15 --> Language Class Initialized
INFO - 2024-03-14 16:05:15 --> Config Class Initialized
INFO - 2024-03-14 16:05:15 --> Loader Class Initialized
INFO - 2024-03-14 16:05:15 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:15 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:15 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:15 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:15 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:15 --> Controller Class Initialized
INFO - 2024-03-14 16:05:15 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:15 --> Total execution time: 0.0437
INFO - 2024-03-14 16:05:23 --> Config Class Initialized
INFO - 2024-03-14 16:05:23 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:23 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:23 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:23 --> URI Class Initialized
INFO - 2024-03-14 16:05:23 --> Router Class Initialized
INFO - 2024-03-14 16:05:23 --> Output Class Initialized
INFO - 2024-03-14 16:05:23 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:23 --> Input Class Initialized
INFO - 2024-03-14 16:05:23 --> Language Class Initialized
INFO - 2024-03-14 16:05:23 --> Language Class Initialized
INFO - 2024-03-14 16:05:23 --> Config Class Initialized
INFO - 2024-03-14 16:05:23 --> Loader Class Initialized
INFO - 2024-03-14 16:05:23 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:23 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:23 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:23 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:23 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:23 --> Controller Class Initialized
ERROR - 2024-03-14 16:05:23 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:05:23 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:23 --> Total execution time: 0.0368
INFO - 2024-03-14 16:05:26 --> Config Class Initialized
INFO - 2024-03-14 16:05:26 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:26 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:26 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:26 --> URI Class Initialized
INFO - 2024-03-14 16:05:26 --> Router Class Initialized
INFO - 2024-03-14 16:05:26 --> Output Class Initialized
INFO - 2024-03-14 16:05:26 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:26 --> Input Class Initialized
INFO - 2024-03-14 16:05:26 --> Language Class Initialized
INFO - 2024-03-14 16:05:26 --> Language Class Initialized
INFO - 2024-03-14 16:05:26 --> Config Class Initialized
INFO - 2024-03-14 16:05:26 --> Loader Class Initialized
INFO - 2024-03-14 16:05:26 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:26 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:26 --> Controller Class Initialized
DEBUG - 2024-03-14 16:05:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:05:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:05:26 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:26 --> Total execution time: 0.0394
INFO - 2024-03-14 16:05:26 --> Config Class Initialized
INFO - 2024-03-14 16:05:26 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:26 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:26 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:26 --> URI Class Initialized
INFO - 2024-03-14 16:05:26 --> Router Class Initialized
INFO - 2024-03-14 16:05:26 --> Output Class Initialized
INFO - 2024-03-14 16:05:26 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:26 --> Input Class Initialized
INFO - 2024-03-14 16:05:26 --> Language Class Initialized
INFO - 2024-03-14 16:05:26 --> Language Class Initialized
INFO - 2024-03-14 16:05:26 --> Config Class Initialized
INFO - 2024-03-14 16:05:26 --> Loader Class Initialized
INFO - 2024-03-14 16:05:26 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:26 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:26 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:26 --> Controller Class Initialized
INFO - 2024-03-14 16:05:28 --> Config Class Initialized
INFO - 2024-03-14 16:05:28 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:28 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:28 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:28 --> URI Class Initialized
INFO - 2024-03-14 16:05:28 --> Router Class Initialized
INFO - 2024-03-14 16:05:28 --> Output Class Initialized
INFO - 2024-03-14 16:05:28 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:28 --> Input Class Initialized
INFO - 2024-03-14 16:05:28 --> Language Class Initialized
INFO - 2024-03-14 16:05:28 --> Language Class Initialized
INFO - 2024-03-14 16:05:28 --> Config Class Initialized
INFO - 2024-03-14 16:05:28 --> Loader Class Initialized
INFO - 2024-03-14 16:05:28 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:28 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:28 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:28 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:28 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:28 --> Controller Class Initialized
INFO - 2024-03-14 16:05:28 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:28 --> Total execution time: 0.0795
INFO - 2024-03-14 16:05:49 --> Config Class Initialized
INFO - 2024-03-14 16:05:49 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:05:49 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:05:49 --> Utf8 Class Initialized
INFO - 2024-03-14 16:05:49 --> URI Class Initialized
INFO - 2024-03-14 16:05:49 --> Router Class Initialized
INFO - 2024-03-14 16:05:49 --> Output Class Initialized
INFO - 2024-03-14 16:05:49 --> Security Class Initialized
DEBUG - 2024-03-14 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:05:49 --> Input Class Initialized
INFO - 2024-03-14 16:05:49 --> Language Class Initialized
INFO - 2024-03-14 16:05:49 --> Language Class Initialized
INFO - 2024-03-14 16:05:49 --> Config Class Initialized
INFO - 2024-03-14 16:05:49 --> Loader Class Initialized
INFO - 2024-03-14 16:05:49 --> Helper loaded: url_helper
INFO - 2024-03-14 16:05:49 --> Helper loaded: file_helper
INFO - 2024-03-14 16:05:49 --> Helper loaded: form_helper
INFO - 2024-03-14 16:05:49 --> Helper loaded: my_helper
INFO - 2024-03-14 16:05:49 --> Database Driver Class Initialized
INFO - 2024-03-14 16:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:05:49 --> Controller Class Initialized
INFO - 2024-03-14 16:05:49 --> Final output sent to browser
DEBUG - 2024-03-14 16:05:49 --> Total execution time: 0.0421
INFO - 2024-03-14 16:06:00 --> Config Class Initialized
INFO - 2024-03-14 16:06:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:00 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:00 --> URI Class Initialized
INFO - 2024-03-14 16:06:00 --> Router Class Initialized
INFO - 2024-03-14 16:06:00 --> Output Class Initialized
INFO - 2024-03-14 16:06:00 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:00 --> Input Class Initialized
INFO - 2024-03-14 16:06:00 --> Language Class Initialized
INFO - 2024-03-14 16:06:00 --> Language Class Initialized
INFO - 2024-03-14 16:06:00 --> Config Class Initialized
INFO - 2024-03-14 16:06:00 --> Loader Class Initialized
INFO - 2024-03-14 16:06:00 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:00 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:00 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:00 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:00 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:00 --> Controller Class Initialized
ERROR - 2024-03-14 16:06:00 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:06:00 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:00 --> Total execution time: 0.0883
INFO - 2024-03-14 16:06:06 --> Config Class Initialized
INFO - 2024-03-14 16:06:06 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:06 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:06 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:06 --> URI Class Initialized
INFO - 2024-03-14 16:06:06 --> Router Class Initialized
INFO - 2024-03-14 16:06:06 --> Output Class Initialized
INFO - 2024-03-14 16:06:06 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:06 --> Input Class Initialized
INFO - 2024-03-14 16:06:06 --> Language Class Initialized
INFO - 2024-03-14 16:06:06 --> Language Class Initialized
INFO - 2024-03-14 16:06:06 --> Config Class Initialized
INFO - 2024-03-14 16:06:06 --> Loader Class Initialized
INFO - 2024-03-14 16:06:06 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:06 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:06 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:06 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:06 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:07 --> Controller Class Initialized
DEBUG - 2024-03-14 16:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:06:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:06:07 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:07 --> Total execution time: 0.0335
INFO - 2024-03-14 16:06:07 --> Config Class Initialized
INFO - 2024-03-14 16:06:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:07 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:07 --> URI Class Initialized
INFO - 2024-03-14 16:06:07 --> Router Class Initialized
INFO - 2024-03-14 16:06:07 --> Output Class Initialized
INFO - 2024-03-14 16:06:07 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:07 --> Input Class Initialized
INFO - 2024-03-14 16:06:07 --> Language Class Initialized
INFO - 2024-03-14 16:06:07 --> Language Class Initialized
INFO - 2024-03-14 16:06:07 --> Config Class Initialized
INFO - 2024-03-14 16:06:07 --> Loader Class Initialized
INFO - 2024-03-14 16:06:07 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:07 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:07 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:07 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:07 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:07 --> Controller Class Initialized
INFO - 2024-03-14 16:06:11 --> Config Class Initialized
INFO - 2024-03-14 16:06:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:11 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:11 --> URI Class Initialized
INFO - 2024-03-14 16:06:11 --> Router Class Initialized
INFO - 2024-03-14 16:06:11 --> Output Class Initialized
INFO - 2024-03-14 16:06:11 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:11 --> Input Class Initialized
INFO - 2024-03-14 16:06:11 --> Language Class Initialized
INFO - 2024-03-14 16:06:11 --> Language Class Initialized
INFO - 2024-03-14 16:06:11 --> Config Class Initialized
INFO - 2024-03-14 16:06:11 --> Loader Class Initialized
INFO - 2024-03-14 16:06:11 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:11 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:11 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:11 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:11 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:11 --> Controller Class Initialized
INFO - 2024-03-14 16:06:11 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:11 --> Total execution time: 0.0352
INFO - 2024-03-14 16:06:22 --> Config Class Initialized
INFO - 2024-03-14 16:06:22 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:22 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:22 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:22 --> URI Class Initialized
INFO - 2024-03-14 16:06:22 --> Router Class Initialized
INFO - 2024-03-14 16:06:22 --> Output Class Initialized
INFO - 2024-03-14 16:06:22 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:22 --> Input Class Initialized
INFO - 2024-03-14 16:06:22 --> Language Class Initialized
INFO - 2024-03-14 16:06:22 --> Language Class Initialized
INFO - 2024-03-14 16:06:22 --> Config Class Initialized
INFO - 2024-03-14 16:06:22 --> Loader Class Initialized
INFO - 2024-03-14 16:06:22 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:22 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:22 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:22 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:22 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:22 --> Controller Class Initialized
ERROR - 2024-03-14 16:06:22 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:06:22 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:22 --> Total execution time: 0.0400
INFO - 2024-03-14 16:06:24 --> Config Class Initialized
INFO - 2024-03-14 16:06:24 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:24 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:24 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:24 --> URI Class Initialized
INFO - 2024-03-14 16:06:24 --> Router Class Initialized
INFO - 2024-03-14 16:06:24 --> Output Class Initialized
INFO - 2024-03-14 16:06:24 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:24 --> Input Class Initialized
INFO - 2024-03-14 16:06:24 --> Language Class Initialized
INFO - 2024-03-14 16:06:24 --> Language Class Initialized
INFO - 2024-03-14 16:06:24 --> Config Class Initialized
INFO - 2024-03-14 16:06:24 --> Loader Class Initialized
INFO - 2024-03-14 16:06:24 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:24 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:24 --> Controller Class Initialized
DEBUG - 2024-03-14 16:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:06:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:06:24 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:24 --> Total execution time: 0.0457
INFO - 2024-03-14 16:06:24 --> Config Class Initialized
INFO - 2024-03-14 16:06:24 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:24 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:24 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:24 --> URI Class Initialized
INFO - 2024-03-14 16:06:24 --> Router Class Initialized
INFO - 2024-03-14 16:06:24 --> Output Class Initialized
INFO - 2024-03-14 16:06:24 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:24 --> Input Class Initialized
INFO - 2024-03-14 16:06:24 --> Language Class Initialized
INFO - 2024-03-14 16:06:24 --> Language Class Initialized
INFO - 2024-03-14 16:06:24 --> Config Class Initialized
INFO - 2024-03-14 16:06:24 --> Loader Class Initialized
INFO - 2024-03-14 16:06:24 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:24 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:24 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:24 --> Controller Class Initialized
INFO - 2024-03-14 16:06:33 --> Config Class Initialized
INFO - 2024-03-14 16:06:33 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:33 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:33 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:33 --> URI Class Initialized
INFO - 2024-03-14 16:06:33 --> Router Class Initialized
INFO - 2024-03-14 16:06:33 --> Output Class Initialized
INFO - 2024-03-14 16:06:33 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:33 --> Input Class Initialized
INFO - 2024-03-14 16:06:33 --> Language Class Initialized
INFO - 2024-03-14 16:06:33 --> Language Class Initialized
INFO - 2024-03-14 16:06:33 --> Config Class Initialized
INFO - 2024-03-14 16:06:33 --> Loader Class Initialized
INFO - 2024-03-14 16:06:33 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:33 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:33 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:33 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:33 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:33 --> Controller Class Initialized
INFO - 2024-03-14 16:06:33 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:33 --> Total execution time: 0.0326
INFO - 2024-03-14 16:06:41 --> Config Class Initialized
INFO - 2024-03-14 16:06:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:41 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:41 --> URI Class Initialized
INFO - 2024-03-14 16:06:41 --> Router Class Initialized
INFO - 2024-03-14 16:06:41 --> Output Class Initialized
INFO - 2024-03-14 16:06:41 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:41 --> Input Class Initialized
INFO - 2024-03-14 16:06:41 --> Language Class Initialized
INFO - 2024-03-14 16:06:41 --> Language Class Initialized
INFO - 2024-03-14 16:06:41 --> Config Class Initialized
INFO - 2024-03-14 16:06:41 --> Loader Class Initialized
INFO - 2024-03-14 16:06:41 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:41 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:41 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:41 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:41 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:41 --> Controller Class Initialized
ERROR - 2024-03-14 16:06:41 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:06:41 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:41 --> Total execution time: 0.0785
INFO - 2024-03-14 16:06:42 --> Config Class Initialized
INFO - 2024-03-14 16:06:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:42 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:42 --> URI Class Initialized
INFO - 2024-03-14 16:06:42 --> Router Class Initialized
INFO - 2024-03-14 16:06:42 --> Output Class Initialized
INFO - 2024-03-14 16:06:42 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:42 --> Input Class Initialized
INFO - 2024-03-14 16:06:42 --> Language Class Initialized
INFO - 2024-03-14 16:06:42 --> Language Class Initialized
INFO - 2024-03-14 16:06:42 --> Config Class Initialized
INFO - 2024-03-14 16:06:42 --> Loader Class Initialized
INFO - 2024-03-14 16:06:42 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:42 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:42 --> Controller Class Initialized
DEBUG - 2024-03-14 16:06:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:06:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:06:42 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:42 --> Total execution time: 0.0325
INFO - 2024-03-14 16:06:42 --> Config Class Initialized
INFO - 2024-03-14 16:06:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:42 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:42 --> URI Class Initialized
INFO - 2024-03-14 16:06:42 --> Router Class Initialized
INFO - 2024-03-14 16:06:42 --> Output Class Initialized
INFO - 2024-03-14 16:06:42 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:42 --> Input Class Initialized
INFO - 2024-03-14 16:06:42 --> Language Class Initialized
INFO - 2024-03-14 16:06:42 --> Language Class Initialized
INFO - 2024-03-14 16:06:42 --> Config Class Initialized
INFO - 2024-03-14 16:06:42 --> Loader Class Initialized
INFO - 2024-03-14 16:06:42 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:42 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:42 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:42 --> Controller Class Initialized
INFO - 2024-03-14 16:06:44 --> Config Class Initialized
INFO - 2024-03-14 16:06:44 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:44 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:44 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:44 --> URI Class Initialized
INFO - 2024-03-14 16:06:44 --> Router Class Initialized
INFO - 2024-03-14 16:06:44 --> Output Class Initialized
INFO - 2024-03-14 16:06:44 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:44 --> Input Class Initialized
INFO - 2024-03-14 16:06:44 --> Language Class Initialized
INFO - 2024-03-14 16:06:44 --> Language Class Initialized
INFO - 2024-03-14 16:06:44 --> Config Class Initialized
INFO - 2024-03-14 16:06:44 --> Loader Class Initialized
INFO - 2024-03-14 16:06:44 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:44 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:44 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:44 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:44 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:44 --> Controller Class Initialized
INFO - 2024-03-14 16:06:44 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:44 --> Total execution time: 0.0680
INFO - 2024-03-14 16:06:52 --> Config Class Initialized
INFO - 2024-03-14 16:06:52 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:52 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:52 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:52 --> URI Class Initialized
INFO - 2024-03-14 16:06:52 --> Router Class Initialized
INFO - 2024-03-14 16:06:52 --> Output Class Initialized
INFO - 2024-03-14 16:06:52 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:52 --> Input Class Initialized
INFO - 2024-03-14 16:06:52 --> Language Class Initialized
INFO - 2024-03-14 16:06:52 --> Language Class Initialized
INFO - 2024-03-14 16:06:52 --> Config Class Initialized
INFO - 2024-03-14 16:06:52 --> Loader Class Initialized
INFO - 2024-03-14 16:06:52 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:52 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:52 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:52 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:52 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:52 --> Controller Class Initialized
ERROR - 2024-03-14 16:06:52 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:06:52 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:52 --> Total execution time: 0.0407
INFO - 2024-03-14 16:06:54 --> Config Class Initialized
INFO - 2024-03-14 16:06:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:54 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:54 --> URI Class Initialized
INFO - 2024-03-14 16:06:54 --> Router Class Initialized
INFO - 2024-03-14 16:06:54 --> Output Class Initialized
INFO - 2024-03-14 16:06:54 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:54 --> Input Class Initialized
INFO - 2024-03-14 16:06:54 --> Language Class Initialized
INFO - 2024-03-14 16:06:54 --> Language Class Initialized
INFO - 2024-03-14 16:06:54 --> Config Class Initialized
INFO - 2024-03-14 16:06:54 --> Loader Class Initialized
INFO - 2024-03-14 16:06:54 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:54 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:54 --> Controller Class Initialized
DEBUG - 2024-03-14 16:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pss/views/list.php
DEBUG - 2024-03-14 16:06:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:06:54 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:54 --> Total execution time: 0.0843
INFO - 2024-03-14 16:06:54 --> Config Class Initialized
INFO - 2024-03-14 16:06:54 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:54 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:54 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:54 --> URI Class Initialized
INFO - 2024-03-14 16:06:54 --> Router Class Initialized
INFO - 2024-03-14 16:06:54 --> Output Class Initialized
INFO - 2024-03-14 16:06:54 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:54 --> Input Class Initialized
INFO - 2024-03-14 16:06:54 --> Language Class Initialized
INFO - 2024-03-14 16:06:54 --> Language Class Initialized
INFO - 2024-03-14 16:06:54 --> Config Class Initialized
INFO - 2024-03-14 16:06:54 --> Loader Class Initialized
INFO - 2024-03-14 16:06:54 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:54 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:54 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:54 --> Controller Class Initialized
INFO - 2024-03-14 16:06:56 --> Config Class Initialized
INFO - 2024-03-14 16:06:56 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:06:56 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:06:56 --> Utf8 Class Initialized
INFO - 2024-03-14 16:06:56 --> URI Class Initialized
INFO - 2024-03-14 16:06:56 --> Router Class Initialized
INFO - 2024-03-14 16:06:56 --> Output Class Initialized
INFO - 2024-03-14 16:06:56 --> Security Class Initialized
DEBUG - 2024-03-14 16:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:06:56 --> Input Class Initialized
INFO - 2024-03-14 16:06:56 --> Language Class Initialized
INFO - 2024-03-14 16:06:56 --> Language Class Initialized
INFO - 2024-03-14 16:06:56 --> Config Class Initialized
INFO - 2024-03-14 16:06:56 --> Loader Class Initialized
INFO - 2024-03-14 16:06:56 --> Helper loaded: url_helper
INFO - 2024-03-14 16:06:56 --> Helper loaded: file_helper
INFO - 2024-03-14 16:06:56 --> Helper loaded: form_helper
INFO - 2024-03-14 16:06:56 --> Helper loaded: my_helper
INFO - 2024-03-14 16:06:56 --> Database Driver Class Initialized
INFO - 2024-03-14 16:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:06:56 --> Controller Class Initialized
DEBUG - 2024-03-14 16:06:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-14 16:06:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:06:56 --> Final output sent to browser
DEBUG - 2024-03-14 16:06:56 --> Total execution time: 0.0353
INFO - 2024-03-14 16:07:00 --> Config Class Initialized
INFO - 2024-03-14 16:07:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:00 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:00 --> URI Class Initialized
INFO - 2024-03-14 16:07:00 --> Router Class Initialized
INFO - 2024-03-14 16:07:00 --> Output Class Initialized
INFO - 2024-03-14 16:07:00 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:00 --> Input Class Initialized
INFO - 2024-03-14 16:07:00 --> Language Class Initialized
INFO - 2024-03-14 16:07:00 --> Language Class Initialized
INFO - 2024-03-14 16:07:00 --> Config Class Initialized
INFO - 2024-03-14 16:07:00 --> Loader Class Initialized
INFO - 2024-03-14 16:07:00 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:00 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:00 --> Controller Class Initialized
DEBUG - 2024-03-14 16:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:07:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:07:00 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:00 --> Total execution time: 0.0648
INFO - 2024-03-14 16:07:00 --> Config Class Initialized
INFO - 2024-03-14 16:07:00 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:00 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:00 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:00 --> URI Class Initialized
INFO - 2024-03-14 16:07:00 --> Router Class Initialized
INFO - 2024-03-14 16:07:00 --> Output Class Initialized
INFO - 2024-03-14 16:07:00 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:00 --> Input Class Initialized
INFO - 2024-03-14 16:07:00 --> Language Class Initialized
INFO - 2024-03-14 16:07:00 --> Language Class Initialized
INFO - 2024-03-14 16:07:00 --> Config Class Initialized
INFO - 2024-03-14 16:07:00 --> Loader Class Initialized
INFO - 2024-03-14 16:07:00 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:00 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:00 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:00 --> Controller Class Initialized
INFO - 2024-03-14 16:07:04 --> Config Class Initialized
INFO - 2024-03-14 16:07:04 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:04 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:04 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:04 --> URI Class Initialized
INFO - 2024-03-14 16:07:04 --> Router Class Initialized
INFO - 2024-03-14 16:07:04 --> Output Class Initialized
INFO - 2024-03-14 16:07:04 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:04 --> Input Class Initialized
INFO - 2024-03-14 16:07:04 --> Language Class Initialized
INFO - 2024-03-14 16:07:04 --> Language Class Initialized
INFO - 2024-03-14 16:07:04 --> Config Class Initialized
INFO - 2024-03-14 16:07:04 --> Loader Class Initialized
INFO - 2024-03-14 16:07:04 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:04 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:04 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:04 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:04 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:04 --> Controller Class Initialized
INFO - 2024-03-14 16:07:04 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:04 --> Total execution time: 0.0387
INFO - 2024-03-14 16:07:11 --> Config Class Initialized
INFO - 2024-03-14 16:07:11 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:11 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:11 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:11 --> URI Class Initialized
INFO - 2024-03-14 16:07:11 --> Router Class Initialized
INFO - 2024-03-14 16:07:11 --> Output Class Initialized
INFO - 2024-03-14 16:07:11 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:11 --> Input Class Initialized
INFO - 2024-03-14 16:07:11 --> Language Class Initialized
INFO - 2024-03-14 16:07:11 --> Language Class Initialized
INFO - 2024-03-14 16:07:11 --> Config Class Initialized
INFO - 2024-03-14 16:07:11 --> Loader Class Initialized
INFO - 2024-03-14 16:07:11 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:11 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:11 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:11 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:11 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:11 --> Controller Class Initialized
ERROR - 2024-03-14 16:07:11 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:07:11 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:11 --> Total execution time: 0.0484
INFO - 2024-03-14 16:07:12 --> Config Class Initialized
INFO - 2024-03-14 16:07:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:12 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:12 --> URI Class Initialized
INFO - 2024-03-14 16:07:12 --> Router Class Initialized
INFO - 2024-03-14 16:07:12 --> Output Class Initialized
INFO - 2024-03-14 16:07:12 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:12 --> Input Class Initialized
INFO - 2024-03-14 16:07:12 --> Language Class Initialized
INFO - 2024-03-14 16:07:12 --> Language Class Initialized
INFO - 2024-03-14 16:07:12 --> Config Class Initialized
INFO - 2024-03-14 16:07:12 --> Loader Class Initialized
INFO - 2024-03-14 16:07:12 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:12 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:12 --> Controller Class Initialized
DEBUG - 2024-03-14 16:07:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:07:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:07:12 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:12 --> Total execution time: 0.0420
INFO - 2024-03-14 16:07:12 --> Config Class Initialized
INFO - 2024-03-14 16:07:12 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:12 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:12 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:12 --> URI Class Initialized
INFO - 2024-03-14 16:07:12 --> Router Class Initialized
INFO - 2024-03-14 16:07:12 --> Output Class Initialized
INFO - 2024-03-14 16:07:12 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:12 --> Input Class Initialized
INFO - 2024-03-14 16:07:12 --> Language Class Initialized
INFO - 2024-03-14 16:07:12 --> Language Class Initialized
INFO - 2024-03-14 16:07:12 --> Config Class Initialized
INFO - 2024-03-14 16:07:12 --> Loader Class Initialized
INFO - 2024-03-14 16:07:12 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:12 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:12 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:12 --> Controller Class Initialized
INFO - 2024-03-14 16:07:14 --> Config Class Initialized
INFO - 2024-03-14 16:07:14 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:14 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:14 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:14 --> URI Class Initialized
INFO - 2024-03-14 16:07:14 --> Router Class Initialized
INFO - 2024-03-14 16:07:14 --> Output Class Initialized
INFO - 2024-03-14 16:07:14 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:14 --> Input Class Initialized
INFO - 2024-03-14 16:07:14 --> Language Class Initialized
INFO - 2024-03-14 16:07:14 --> Language Class Initialized
INFO - 2024-03-14 16:07:14 --> Config Class Initialized
INFO - 2024-03-14 16:07:14 --> Loader Class Initialized
INFO - 2024-03-14 16:07:14 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:14 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:14 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:14 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:14 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:14 --> Controller Class Initialized
INFO - 2024-03-14 16:07:14 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:14 --> Total execution time: 0.0332
INFO - 2024-03-14 16:07:24 --> Config Class Initialized
INFO - 2024-03-14 16:07:24 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:24 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:24 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:24 --> URI Class Initialized
INFO - 2024-03-14 16:07:24 --> Router Class Initialized
INFO - 2024-03-14 16:07:24 --> Output Class Initialized
INFO - 2024-03-14 16:07:24 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:24 --> Input Class Initialized
INFO - 2024-03-14 16:07:24 --> Language Class Initialized
INFO - 2024-03-14 16:07:24 --> Language Class Initialized
INFO - 2024-03-14 16:07:24 --> Config Class Initialized
INFO - 2024-03-14 16:07:24 --> Loader Class Initialized
INFO - 2024-03-14 16:07:24 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:24 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:24 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:24 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:24 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:24 --> Controller Class Initialized
ERROR - 2024-03-14 16:07:24 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:07:24 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:24 --> Total execution time: 0.0315
INFO - 2024-03-14 16:07:25 --> Config Class Initialized
INFO - 2024-03-14 16:07:25 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:25 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:25 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:25 --> URI Class Initialized
INFO - 2024-03-14 16:07:25 --> Router Class Initialized
INFO - 2024-03-14 16:07:25 --> Output Class Initialized
INFO - 2024-03-14 16:07:25 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:25 --> Input Class Initialized
INFO - 2024-03-14 16:07:25 --> Language Class Initialized
INFO - 2024-03-14 16:07:25 --> Language Class Initialized
INFO - 2024-03-14 16:07:25 --> Config Class Initialized
INFO - 2024-03-14 16:07:25 --> Loader Class Initialized
INFO - 2024-03-14 16:07:25 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:25 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:25 --> Controller Class Initialized
DEBUG - 2024-03-14 16:07:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:07:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:07:25 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:25 --> Total execution time: 0.0352
INFO - 2024-03-14 16:07:25 --> Config Class Initialized
INFO - 2024-03-14 16:07:25 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:25 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:25 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:25 --> URI Class Initialized
INFO - 2024-03-14 16:07:25 --> Router Class Initialized
INFO - 2024-03-14 16:07:25 --> Output Class Initialized
INFO - 2024-03-14 16:07:25 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:25 --> Input Class Initialized
INFO - 2024-03-14 16:07:25 --> Language Class Initialized
INFO - 2024-03-14 16:07:25 --> Language Class Initialized
INFO - 2024-03-14 16:07:25 --> Config Class Initialized
INFO - 2024-03-14 16:07:25 --> Loader Class Initialized
INFO - 2024-03-14 16:07:25 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:25 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:25 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:25 --> Controller Class Initialized
INFO - 2024-03-14 16:07:27 --> Config Class Initialized
INFO - 2024-03-14 16:07:27 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:27 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:27 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:27 --> URI Class Initialized
INFO - 2024-03-14 16:07:27 --> Router Class Initialized
INFO - 2024-03-14 16:07:27 --> Output Class Initialized
INFO - 2024-03-14 16:07:27 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:27 --> Input Class Initialized
INFO - 2024-03-14 16:07:27 --> Language Class Initialized
INFO - 2024-03-14 16:07:27 --> Language Class Initialized
INFO - 2024-03-14 16:07:27 --> Config Class Initialized
INFO - 2024-03-14 16:07:27 --> Loader Class Initialized
INFO - 2024-03-14 16:07:27 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:27 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:27 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:27 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:27 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:27 --> Controller Class Initialized
INFO - 2024-03-14 16:07:27 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:27 --> Total execution time: 0.0309
INFO - 2024-03-14 16:07:38 --> Config Class Initialized
INFO - 2024-03-14 16:07:38 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:38 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:38 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:38 --> URI Class Initialized
INFO - 2024-03-14 16:07:38 --> Router Class Initialized
INFO - 2024-03-14 16:07:38 --> Output Class Initialized
INFO - 2024-03-14 16:07:38 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:38 --> Input Class Initialized
INFO - 2024-03-14 16:07:38 --> Language Class Initialized
INFO - 2024-03-14 16:07:38 --> Language Class Initialized
INFO - 2024-03-14 16:07:38 --> Config Class Initialized
INFO - 2024-03-14 16:07:38 --> Loader Class Initialized
INFO - 2024-03-14 16:07:38 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:38 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:38 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:38 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:38 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:38 --> Controller Class Initialized
ERROR - 2024-03-14 16:07:38 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:07:38 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:38 --> Total execution time: 0.0436
INFO - 2024-03-14 16:07:41 --> Config Class Initialized
INFO - 2024-03-14 16:07:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:41 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:41 --> URI Class Initialized
INFO - 2024-03-14 16:07:41 --> Router Class Initialized
INFO - 2024-03-14 16:07:41 --> Output Class Initialized
INFO - 2024-03-14 16:07:41 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:41 --> Input Class Initialized
INFO - 2024-03-14 16:07:41 --> Language Class Initialized
INFO - 2024-03-14 16:07:41 --> Language Class Initialized
INFO - 2024-03-14 16:07:41 --> Config Class Initialized
INFO - 2024-03-14 16:07:41 --> Loader Class Initialized
INFO - 2024-03-14 16:07:41 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:41 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:41 --> Controller Class Initialized
DEBUG - 2024-03-14 16:07:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:07:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:07:41 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:41 --> Total execution time: 0.0450
INFO - 2024-03-14 16:07:41 --> Config Class Initialized
INFO - 2024-03-14 16:07:41 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:41 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:41 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:41 --> URI Class Initialized
INFO - 2024-03-14 16:07:41 --> Router Class Initialized
INFO - 2024-03-14 16:07:41 --> Output Class Initialized
INFO - 2024-03-14 16:07:41 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:41 --> Input Class Initialized
INFO - 2024-03-14 16:07:41 --> Language Class Initialized
INFO - 2024-03-14 16:07:41 --> Language Class Initialized
INFO - 2024-03-14 16:07:41 --> Config Class Initialized
INFO - 2024-03-14 16:07:41 --> Loader Class Initialized
INFO - 2024-03-14 16:07:41 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:41 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:41 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:41 --> Controller Class Initialized
INFO - 2024-03-14 16:07:43 --> Config Class Initialized
INFO - 2024-03-14 16:07:43 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:43 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:43 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:43 --> URI Class Initialized
INFO - 2024-03-14 16:07:43 --> Router Class Initialized
INFO - 2024-03-14 16:07:43 --> Output Class Initialized
INFO - 2024-03-14 16:07:43 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:43 --> Input Class Initialized
INFO - 2024-03-14 16:07:43 --> Language Class Initialized
INFO - 2024-03-14 16:07:43 --> Language Class Initialized
INFO - 2024-03-14 16:07:43 --> Config Class Initialized
INFO - 2024-03-14 16:07:43 --> Loader Class Initialized
INFO - 2024-03-14 16:07:43 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:43 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:43 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:43 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:43 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:43 --> Controller Class Initialized
INFO - 2024-03-14 16:07:43 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:43 --> Total execution time: 0.0377
INFO - 2024-03-14 16:07:53 --> Config Class Initialized
INFO - 2024-03-14 16:07:53 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:53 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:53 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:53 --> URI Class Initialized
INFO - 2024-03-14 16:07:53 --> Router Class Initialized
INFO - 2024-03-14 16:07:53 --> Output Class Initialized
INFO - 2024-03-14 16:07:53 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:53 --> Input Class Initialized
INFO - 2024-03-14 16:07:53 --> Language Class Initialized
INFO - 2024-03-14 16:07:53 --> Language Class Initialized
INFO - 2024-03-14 16:07:53 --> Config Class Initialized
INFO - 2024-03-14 16:07:53 --> Loader Class Initialized
INFO - 2024-03-14 16:07:53 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:53 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:53 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:53 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:53 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:53 --> Controller Class Initialized
ERROR - 2024-03-14 16:07:53 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:07:53 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:53 --> Total execution time: 0.0325
INFO - 2024-03-14 16:07:55 --> Config Class Initialized
INFO - 2024-03-14 16:07:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:55 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:55 --> URI Class Initialized
INFO - 2024-03-14 16:07:55 --> Router Class Initialized
INFO - 2024-03-14 16:07:55 --> Output Class Initialized
INFO - 2024-03-14 16:07:55 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:55 --> Input Class Initialized
INFO - 2024-03-14 16:07:55 --> Language Class Initialized
INFO - 2024-03-14 16:07:55 --> Language Class Initialized
INFO - 2024-03-14 16:07:55 --> Config Class Initialized
INFO - 2024-03-14 16:07:55 --> Loader Class Initialized
INFO - 2024-03-14 16:07:55 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:55 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:55 --> Controller Class Initialized
DEBUG - 2024-03-14 16:07:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:07:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:07:55 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:55 --> Total execution time: 0.0391
INFO - 2024-03-14 16:07:55 --> Config Class Initialized
INFO - 2024-03-14 16:07:55 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:55 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:55 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:55 --> URI Class Initialized
INFO - 2024-03-14 16:07:55 --> Router Class Initialized
INFO - 2024-03-14 16:07:55 --> Output Class Initialized
INFO - 2024-03-14 16:07:55 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:55 --> Input Class Initialized
INFO - 2024-03-14 16:07:55 --> Language Class Initialized
INFO - 2024-03-14 16:07:55 --> Language Class Initialized
INFO - 2024-03-14 16:07:55 --> Config Class Initialized
INFO - 2024-03-14 16:07:55 --> Loader Class Initialized
INFO - 2024-03-14 16:07:55 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:55 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:55 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:55 --> Controller Class Initialized
INFO - 2024-03-14 16:07:58 --> Config Class Initialized
INFO - 2024-03-14 16:07:58 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:07:58 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:07:58 --> Utf8 Class Initialized
INFO - 2024-03-14 16:07:58 --> URI Class Initialized
INFO - 2024-03-14 16:07:58 --> Router Class Initialized
INFO - 2024-03-14 16:07:58 --> Output Class Initialized
INFO - 2024-03-14 16:07:58 --> Security Class Initialized
DEBUG - 2024-03-14 16:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:07:58 --> Input Class Initialized
INFO - 2024-03-14 16:07:58 --> Language Class Initialized
INFO - 2024-03-14 16:07:58 --> Language Class Initialized
INFO - 2024-03-14 16:07:58 --> Config Class Initialized
INFO - 2024-03-14 16:07:58 --> Loader Class Initialized
INFO - 2024-03-14 16:07:58 --> Helper loaded: url_helper
INFO - 2024-03-14 16:07:58 --> Helper loaded: file_helper
INFO - 2024-03-14 16:07:58 --> Helper loaded: form_helper
INFO - 2024-03-14 16:07:58 --> Helper loaded: my_helper
INFO - 2024-03-14 16:07:58 --> Database Driver Class Initialized
INFO - 2024-03-14 16:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:07:58 --> Controller Class Initialized
INFO - 2024-03-14 16:07:58 --> Final output sent to browser
DEBUG - 2024-03-14 16:07:58 --> Total execution time: 0.0375
INFO - 2024-03-14 16:08:05 --> Config Class Initialized
INFO - 2024-03-14 16:08:05 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:05 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:05 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:05 --> URI Class Initialized
INFO - 2024-03-14 16:08:05 --> Router Class Initialized
INFO - 2024-03-14 16:08:05 --> Output Class Initialized
INFO - 2024-03-14 16:08:05 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:05 --> Input Class Initialized
INFO - 2024-03-14 16:08:05 --> Language Class Initialized
INFO - 2024-03-14 16:08:05 --> Language Class Initialized
INFO - 2024-03-14 16:08:05 --> Config Class Initialized
INFO - 2024-03-14 16:08:05 --> Loader Class Initialized
INFO - 2024-03-14 16:08:05 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:05 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:05 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:05 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:05 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:05 --> Controller Class Initialized
ERROR - 2024-03-14 16:08:05 --> Severity: Notice --> Undefined index: semester /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/set_kd/controllers/Set_kd.php 104
INFO - 2024-03-14 16:08:05 --> Final output sent to browser
DEBUG - 2024-03-14 16:08:05 --> Total execution time: 0.0438
INFO - 2024-03-14 16:08:07 --> Config Class Initialized
INFO - 2024-03-14 16:08:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:07 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:07 --> URI Class Initialized
INFO - 2024-03-14 16:08:07 --> Router Class Initialized
INFO - 2024-03-14 16:08:07 --> Output Class Initialized
INFO - 2024-03-14 16:08:07 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:07 --> Input Class Initialized
INFO - 2024-03-14 16:08:07 --> Language Class Initialized
INFO - 2024-03-14 16:08:07 --> Language Class Initialized
INFO - 2024-03-14 16:08:07 --> Config Class Initialized
INFO - 2024-03-14 16:08:07 --> Loader Class Initialized
INFO - 2024-03-14 16:08:07 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:07 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:07 --> Controller Class Initialized
DEBUG - 2024-03-14 16:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_la/views/list.php
DEBUG - 2024-03-14 16:08:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:08:07 --> Final output sent to browser
DEBUG - 2024-03-14 16:08:07 --> Total execution time: 0.0398
INFO - 2024-03-14 16:08:07 --> Config Class Initialized
INFO - 2024-03-14 16:08:07 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:07 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:07 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:07 --> URI Class Initialized
INFO - 2024-03-14 16:08:07 --> Router Class Initialized
INFO - 2024-03-14 16:08:07 --> Output Class Initialized
INFO - 2024-03-14 16:08:07 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:07 --> Input Class Initialized
INFO - 2024-03-14 16:08:07 --> Language Class Initialized
INFO - 2024-03-14 16:08:07 --> Language Class Initialized
INFO - 2024-03-14 16:08:07 --> Config Class Initialized
INFO - 2024-03-14 16:08:07 --> Loader Class Initialized
INFO - 2024-03-14 16:08:07 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:07 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:07 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:07 --> Controller Class Initialized
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:42 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:42 --> URI Class Initialized
INFO - 2024-03-14 16:08:42 --> Router Class Initialized
INFO - 2024-03-14 16:08:42 --> Output Class Initialized
INFO - 2024-03-14 16:08:42 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:42 --> Input Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Loader Class Initialized
INFO - 2024-03-14 16:08:42 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:42 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:42 --> Controller Class Initialized
INFO - 2024-03-14 16:08:42 --> Helper loaded: cookie_helper
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:42 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:42 --> URI Class Initialized
INFO - 2024-03-14 16:08:42 --> Router Class Initialized
INFO - 2024-03-14 16:08:42 --> Output Class Initialized
INFO - 2024-03-14 16:08:42 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:42 --> Input Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Loader Class Initialized
INFO - 2024-03-14 16:08:42 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:42 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:42 --> Controller Class Initialized
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Hooks Class Initialized
DEBUG - 2024-03-14 16:08:42 --> UTF-8 Support Enabled
INFO - 2024-03-14 16:08:42 --> Utf8 Class Initialized
INFO - 2024-03-14 16:08:42 --> URI Class Initialized
INFO - 2024-03-14 16:08:42 --> Router Class Initialized
INFO - 2024-03-14 16:08:42 --> Output Class Initialized
INFO - 2024-03-14 16:08:42 --> Security Class Initialized
DEBUG - 2024-03-14 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-14 16:08:42 --> Input Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Language Class Initialized
INFO - 2024-03-14 16:08:42 --> Config Class Initialized
INFO - 2024-03-14 16:08:42 --> Loader Class Initialized
INFO - 2024-03-14 16:08:42 --> Helper loaded: url_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: file_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: form_helper
INFO - 2024-03-14 16:08:42 --> Helper loaded: my_helper
INFO - 2024-03-14 16:08:42 --> Database Driver Class Initialized
INFO - 2024-03-14 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-14 16:08:42 --> Controller Class Initialized
DEBUG - 2024-03-14 16:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-14 16:08:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-14 16:08:42 --> Final output sent to browser
DEBUG - 2024-03-14 16:08:42 --> Total execution time: 0.0345
