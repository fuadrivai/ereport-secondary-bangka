<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-26 20:15:22 --> Config Class Initialized
INFO - 2023-12-26 20:15:22 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:22 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:22 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:22 --> URI Class Initialized
INFO - 2023-12-26 20:15:22 --> Router Class Initialized
INFO - 2023-12-26 20:15:22 --> Output Class Initialized
INFO - 2023-12-26 20:15:22 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:22 --> Input Class Initialized
INFO - 2023-12-26 20:15:22 --> Language Class Initialized
INFO - 2023-12-26 20:15:22 --> Language Class Initialized
INFO - 2023-12-26 20:15:22 --> Config Class Initialized
INFO - 2023-12-26 20:15:22 --> Loader Class Initialized
INFO - 2023-12-26 20:15:22 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:22 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:22 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:22 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:22 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:22 --> Controller Class Initialized
INFO - 2023-12-26 20:15:22 --> Helper loaded: cookie_helper
INFO - 2023-12-26 20:15:22 --> Final output sent to browser
DEBUG - 2023-12-26 20:15:22 --> Total execution time: 0.0653
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:23 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:23 --> URI Class Initialized
INFO - 2023-12-26 20:15:23 --> Router Class Initialized
INFO - 2023-12-26 20:15:23 --> Output Class Initialized
INFO - 2023-12-26 20:15:23 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:23 --> Input Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Loader Class Initialized
INFO - 2023-12-26 20:15:23 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:23 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:23 --> Controller Class Initialized
INFO - 2023-12-26 20:15:23 --> Helper loaded: cookie_helper
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:23 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:23 --> URI Class Initialized
INFO - 2023-12-26 20:15:23 --> Router Class Initialized
INFO - 2023-12-26 20:15:23 --> Output Class Initialized
INFO - 2023-12-26 20:15:23 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:23 --> Input Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Loader Class Initialized
INFO - 2023-12-26 20:15:23 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:23 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:23 --> Controller Class Initialized
INFO - 2023-12-26 20:15:23 --> Helper loaded: cookie_helper
INFO - 2023-12-26 20:15:23 --> Final output sent to browser
DEBUG - 2023-12-26 20:15:23 --> Total execution time: 0.0374
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:23 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:23 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:23 --> URI Class Initialized
INFO - 2023-12-26 20:15:23 --> Router Class Initialized
INFO - 2023-12-26 20:15:23 --> Output Class Initialized
INFO - 2023-12-26 20:15:23 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:23 --> Input Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Language Class Initialized
INFO - 2023-12-26 20:15:23 --> Config Class Initialized
INFO - 2023-12-26 20:15:23 --> Loader Class Initialized
INFO - 2023-12-26 20:15:23 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:23 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:23 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:23 --> Controller Class Initialized
DEBUG - 2023-12-26 20:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-26 20:15:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-26 20:15:23 --> Final output sent to browser
DEBUG - 2023-12-26 20:15:23 --> Total execution time: 0.0488
INFO - 2023-12-26 20:15:32 --> Config Class Initialized
INFO - 2023-12-26 20:15:32 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:32 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:32 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:32 --> URI Class Initialized
INFO - 2023-12-26 20:15:32 --> Router Class Initialized
INFO - 2023-12-26 20:15:32 --> Output Class Initialized
INFO - 2023-12-26 20:15:32 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:32 --> Input Class Initialized
INFO - 2023-12-26 20:15:32 --> Language Class Initialized
INFO - 2023-12-26 20:15:32 --> Language Class Initialized
INFO - 2023-12-26 20:15:32 --> Config Class Initialized
INFO - 2023-12-26 20:15:32 --> Loader Class Initialized
INFO - 2023-12-26 20:15:32 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:32 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:32 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:32 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:32 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:32 --> Controller Class Initialized
INFO - 2023-12-26 20:15:32 --> Helper loaded: cookie_helper
INFO - 2023-12-26 20:15:34 --> Config Class Initialized
INFO - 2023-12-26 20:15:34 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:34 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:34 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:34 --> URI Class Initialized
INFO - 2023-12-26 20:15:34 --> Router Class Initialized
INFO - 2023-12-26 20:15:34 --> Output Class Initialized
INFO - 2023-12-26 20:15:34 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:34 --> Input Class Initialized
INFO - 2023-12-26 20:15:34 --> Language Class Initialized
INFO - 2023-12-26 20:15:34 --> Language Class Initialized
INFO - 2023-12-26 20:15:34 --> Config Class Initialized
INFO - 2023-12-26 20:15:34 --> Loader Class Initialized
INFO - 2023-12-26 20:15:34 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:34 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:34 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:34 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:34 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:34 --> Controller Class Initialized
DEBUG - 2023-12-26 20:15:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-12-26 20:15:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-26 20:15:34 --> Final output sent to browser
DEBUG - 2023-12-26 20:15:34 --> Total execution time: 0.0435
INFO - 2023-12-26 20:15:51 --> Config Class Initialized
INFO - 2023-12-26 20:15:51 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:51 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:51 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:51 --> URI Class Initialized
INFO - 2023-12-26 20:15:51 --> Router Class Initialized
INFO - 2023-12-26 20:15:51 --> Output Class Initialized
INFO - 2023-12-26 20:15:51 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:51 --> Input Class Initialized
INFO - 2023-12-26 20:15:51 --> Language Class Initialized
INFO - 2023-12-26 20:15:51 --> Language Class Initialized
INFO - 2023-12-26 20:15:51 --> Config Class Initialized
INFO - 2023-12-26 20:15:51 --> Loader Class Initialized
INFO - 2023-12-26 20:15:51 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:51 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:51 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:51 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:51 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:51 --> Controller Class Initialized
DEBUG - 2023-12-26 20:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-26 20:15:57 --> Final output sent to browser
DEBUG - 2023-12-26 20:15:57 --> Total execution time: 6.3103
INFO - 2023-12-26 20:15:58 --> Config Class Initialized
INFO - 2023-12-26 20:15:58 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:15:58 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:15:58 --> Utf8 Class Initialized
INFO - 2023-12-26 20:15:58 --> URI Class Initialized
INFO - 2023-12-26 20:15:58 --> Router Class Initialized
INFO - 2023-12-26 20:15:58 --> Output Class Initialized
INFO - 2023-12-26 20:15:58 --> Security Class Initialized
DEBUG - 2023-12-26 20:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:15:58 --> Input Class Initialized
INFO - 2023-12-26 20:15:58 --> Language Class Initialized
INFO - 2023-12-26 20:15:58 --> Language Class Initialized
INFO - 2023-12-26 20:15:58 --> Config Class Initialized
INFO - 2023-12-26 20:15:58 --> Loader Class Initialized
INFO - 2023-12-26 20:15:58 --> Helper loaded: url_helper
INFO - 2023-12-26 20:15:58 --> Helper loaded: file_helper
INFO - 2023-12-26 20:15:58 --> Helper loaded: form_helper
INFO - 2023-12-26 20:15:58 --> Helper loaded: my_helper
INFO - 2023-12-26 20:15:58 --> Database Driver Class Initialized
INFO - 2023-12-26 20:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:15:58 --> Controller Class Initialized
DEBUG - 2023-12-26 20:15:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-26 20:16:00 --> Config Class Initialized
INFO - 2023-12-26 20:16:00 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:16:00 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:16:00 --> Utf8 Class Initialized
INFO - 2023-12-26 20:16:00 --> URI Class Initialized
INFO - 2023-12-26 20:16:00 --> Router Class Initialized
INFO - 2023-12-26 20:16:00 --> Output Class Initialized
INFO - 2023-12-26 20:16:00 --> Security Class Initialized
DEBUG - 2023-12-26 20:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:16:00 --> Input Class Initialized
INFO - 2023-12-26 20:16:00 --> Language Class Initialized
INFO - 2023-12-26 20:16:00 --> Language Class Initialized
INFO - 2023-12-26 20:16:00 --> Config Class Initialized
INFO - 2023-12-26 20:16:00 --> Loader Class Initialized
INFO - 2023-12-26 20:16:00 --> Helper loaded: url_helper
INFO - 2023-12-26 20:16:00 --> Helper loaded: file_helper
INFO - 2023-12-26 20:16:00 --> Helper loaded: form_helper
INFO - 2023-12-26 20:16:00 --> Helper loaded: my_helper
INFO - 2023-12-26 20:16:00 --> Database Driver Class Initialized
INFO - 2023-12-26 20:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:16:00 --> Controller Class Initialized
DEBUG - 2023-12-26 20:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-26 20:16:10 --> Config Class Initialized
INFO - 2023-12-26 20:16:10 --> Hooks Class Initialized
DEBUG - 2023-12-26 20:16:10 --> UTF-8 Support Enabled
INFO - 2023-12-26 20:16:10 --> Utf8 Class Initialized
INFO - 2023-12-26 20:16:10 --> URI Class Initialized
INFO - 2023-12-26 20:16:10 --> Router Class Initialized
INFO - 2023-12-26 20:16:10 --> Output Class Initialized
INFO - 2023-12-26 20:16:10 --> Security Class Initialized
DEBUG - 2023-12-26 20:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-26 20:16:10 --> Input Class Initialized
INFO - 2023-12-26 20:16:10 --> Language Class Initialized
INFO - 2023-12-26 20:16:10 --> Language Class Initialized
INFO - 2023-12-26 20:16:10 --> Config Class Initialized
INFO - 2023-12-26 20:16:10 --> Loader Class Initialized
INFO - 2023-12-26 20:16:10 --> Helper loaded: url_helper
INFO - 2023-12-26 20:16:10 --> Helper loaded: file_helper
INFO - 2023-12-26 20:16:10 --> Helper loaded: form_helper
INFO - 2023-12-26 20:16:10 --> Helper loaded: my_helper
INFO - 2023-12-26 20:16:10 --> Database Driver Class Initialized
INFO - 2023-12-26 20:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-26 20:16:10 --> Controller Class Initialized
DEBUG - 2023-12-26 20:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2023-12-26 20:16:16 --> Final output sent to browser
DEBUG - 2023-12-26 20:16:16 --> Total execution time: 5.4217
