<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-09 17:49:31 --> Config Class Initialized
INFO - 2023-12-09 17:49:31 --> Hooks Class Initialized
DEBUG - 2023-12-09 17:49:31 --> UTF-8 Support Enabled
INFO - 2023-12-09 17:49:31 --> Utf8 Class Initialized
INFO - 2023-12-09 17:49:31 --> URI Class Initialized
INFO - 2023-12-09 17:49:31 --> Router Class Initialized
INFO - 2023-12-09 17:49:31 --> Output Class Initialized
INFO - 2023-12-09 17:49:31 --> Security Class Initialized
DEBUG - 2023-12-09 17:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-09 17:49:31 --> Input Class Initialized
INFO - 2023-12-09 17:49:31 --> Language Class Initialized
INFO - 2023-12-09 17:49:31 --> Language Class Initialized
INFO - 2023-12-09 17:49:31 --> Config Class Initialized
INFO - 2023-12-09 17:49:31 --> Loader Class Initialized
INFO - 2023-12-09 17:49:31 --> Helper loaded: url_helper
INFO - 2023-12-09 17:49:31 --> Helper loaded: file_helper
INFO - 2023-12-09 17:49:31 --> Helper loaded: form_helper
INFO - 2023-12-09 17:49:31 --> Helper loaded: my_helper
INFO - 2023-12-09 17:49:31 --> Database Driver Class Initialized
INFO - 2023-12-09 17:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-09 17:49:31 --> Controller Class Initialized
INFO - 2023-12-09 17:49:31 --> Config Class Initialized
INFO - 2023-12-09 17:49:31 --> Hooks Class Initialized
DEBUG - 2023-12-09 17:49:31 --> UTF-8 Support Enabled
INFO - 2023-12-09 17:49:31 --> Utf8 Class Initialized
INFO - 2023-12-09 17:49:31 --> URI Class Initialized
INFO - 2023-12-09 17:49:32 --> Router Class Initialized
INFO - 2023-12-09 17:49:32 --> Output Class Initialized
INFO - 2023-12-09 17:49:32 --> Security Class Initialized
DEBUG - 2023-12-09 17:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-09 17:49:32 --> Input Class Initialized
INFO - 2023-12-09 17:49:32 --> Language Class Initialized
INFO - 2023-12-09 17:49:32 --> Language Class Initialized
INFO - 2023-12-09 17:49:32 --> Config Class Initialized
INFO - 2023-12-09 17:49:32 --> Loader Class Initialized
INFO - 2023-12-09 17:49:32 --> Helper loaded: url_helper
INFO - 2023-12-09 17:49:32 --> Helper loaded: file_helper
INFO - 2023-12-09 17:49:32 --> Helper loaded: form_helper
INFO - 2023-12-09 17:49:32 --> Helper loaded: my_helper
INFO - 2023-12-09 17:49:32 --> Database Driver Class Initialized
INFO - 2023-12-09 17:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-09 17:49:32 --> Controller Class Initialized
DEBUG - 2023-12-09 17:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-09 17:49:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-09 17:49:32 --> Final output sent to browser
DEBUG - 2023-12-09 17:49:32 --> Total execution time: 0.0356
