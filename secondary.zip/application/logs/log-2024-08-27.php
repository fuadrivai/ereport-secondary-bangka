<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:57:59 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:57:59 --> Utf8 Class Initialized
INFO - 2024-08-27 19:57:59 --> URI Class Initialized
INFO - 2024-08-27 19:57:59 --> Router Class Initialized
INFO - 2024-08-27 19:57:59 --> Output Class Initialized
INFO - 2024-08-27 19:57:59 --> Security Class Initialized
DEBUG - 2024-08-27 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:57:59 --> Input Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Loader Class Initialized
INFO - 2024-08-27 19:57:59 --> Helper loaded: url_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: file_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: form_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: my_helper
INFO - 2024-08-27 19:57:59 --> Database Driver Class Initialized
INFO - 2024-08-27 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:57:59 --> Controller Class Initialized
INFO - 2024-08-27 19:57:59 --> Helper loaded: cookie_helper
INFO - 2024-08-27 19:57:59 --> Final output sent to browser
DEBUG - 2024-08-27 19:57:59 --> Total execution time: 0.0887
INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:57:59 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:57:59 --> Utf8 Class Initialized
INFO - 2024-08-27 19:57:59 --> URI Class Initialized
INFO - 2024-08-27 19:57:59 --> Router Class Initialized
INFO - 2024-08-27 19:57:59 --> Output Class Initialized
INFO - 2024-08-27 19:57:59 --> Security Class Initialized
DEBUG - 2024-08-27 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:57:59 --> Input Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Loader Class Initialized
INFO - 2024-08-27 19:57:59 --> Helper loaded: url_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: file_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: form_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: my_helper
INFO - 2024-08-27 19:57:59 --> Database Driver Class Initialized
INFO - 2024-08-27 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:57:59 --> Controller Class Initialized
INFO - 2024-08-27 19:57:59 --> Helper loaded: cookie_helper
INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:57:59 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:57:59 --> Utf8 Class Initialized
INFO - 2024-08-27 19:57:59 --> URI Class Initialized
INFO - 2024-08-27 19:57:59 --> Router Class Initialized
INFO - 2024-08-27 19:57:59 --> Output Class Initialized
INFO - 2024-08-27 19:57:59 --> Security Class Initialized
DEBUG - 2024-08-27 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:57:59 --> Input Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Language Class Initialized
INFO - 2024-08-27 19:57:59 --> Config Class Initialized
INFO - 2024-08-27 19:57:59 --> Loader Class Initialized
INFO - 2024-08-27 19:57:59 --> Helper loaded: url_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: file_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: form_helper
INFO - 2024-08-27 19:57:59 --> Helper loaded: my_helper
INFO - 2024-08-27 19:57:59 --> Database Driver Class Initialized
INFO - 2024-08-27 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:57:59 --> Controller Class Initialized
DEBUG - 2024-08-27 19:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-08-27 19:57:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-08-27 19:57:59 --> Final output sent to browser
DEBUG - 2024-08-27 19:57:59 --> Total execution time: 0.0515
INFO - 2024-08-27 19:58:16 --> Config Class Initialized
INFO - 2024-08-27 19:58:16 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:16 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:16 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:16 --> URI Class Initialized
INFO - 2024-08-27 19:58:16 --> Router Class Initialized
INFO - 2024-08-27 19:58:16 --> Output Class Initialized
INFO - 2024-08-27 19:58:16 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:16 --> Input Class Initialized
INFO - 2024-08-27 19:58:16 --> Language Class Initialized
INFO - 2024-08-27 19:58:16 --> Language Class Initialized
INFO - 2024-08-27 19:58:16 --> Config Class Initialized
INFO - 2024-08-27 19:58:16 --> Loader Class Initialized
INFO - 2024-08-27 19:58:16 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:16 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:16 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:16 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:16 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:16 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-27 19:58:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-27 19:58:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-27 19:58:17 --> Config Class Initialized
INFO - 2024-08-27 19:58:17 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:17 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:17 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:17 --> URI Class Initialized
INFO - 2024-08-27 19:58:17 --> Router Class Initialized
INFO - 2024-08-27 19:58:17 --> Output Class Initialized
INFO - 2024-08-27 19:58:17 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:17 --> Input Class Initialized
INFO - 2024-08-27 19:58:17 --> Language Class Initialized
INFO - 2024-08-27 19:58:17 --> Language Class Initialized
INFO - 2024-08-27 19:58:17 --> Config Class Initialized
INFO - 2024-08-27 19:58:17 --> Loader Class Initialized
INFO - 2024-08-27 19:58:17 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:17 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:17 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:17 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:17 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:19 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:19 --> Total execution time: 2.6892
INFO - 2024-08-27 19:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:19 --> Controller Class Initialized
INFO - 2024-08-27 19:58:19 --> Config Class Initialized
INFO - 2024-08-27 19:58:19 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:19 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:19 --> Utf8 Class Initialized
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
INFO - 2024-08-27 19:58:19 --> URI Class Initialized
INFO - 2024-08-27 19:58:19 --> Router Class Initialized
INFO - 2024-08-27 19:58:19 --> Output Class Initialized
INFO - 2024-08-27 19:58:19 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:19 --> Input Class Initialized
INFO - 2024-08-27 19:58:19 --> Language Class Initialized
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-27 19:58:19 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-27 19:58:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-27 19:58:19 --> Language Class Initialized
INFO - 2024-08-27 19:58:19 --> Config Class Initialized
INFO - 2024-08-27 19:58:19 --> Loader Class Initialized
INFO - 2024-08-27 19:58:19 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:19 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:19 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:19 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:19 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:22 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:22 --> Total execution time: 4.5044
INFO - 2024-08-27 19:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:22 --> Controller Class Initialized
INFO - 2024-08-27 19:58:22 --> Config Class Initialized
INFO - 2024-08-27 19:58:22 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:22 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:22 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:22 --> URI Class Initialized
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-27 19:58:22 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-27 19:58:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-27 19:58:22 --> Router Class Initialized
INFO - 2024-08-27 19:58:22 --> Output Class Initialized
INFO - 2024-08-27 19:58:22 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:22 --> Input Class Initialized
INFO - 2024-08-27 19:58:22 --> Language Class Initialized
INFO - 2024-08-27 19:58:22 --> Language Class Initialized
INFO - 2024-08-27 19:58:22 --> Config Class Initialized
INFO - 2024-08-27 19:58:22 --> Loader Class Initialized
INFO - 2024-08-27 19:58:22 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:22 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:22 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:22 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:22 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:24 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:24 --> Total execution time: 5.0131
INFO - 2024-08-27 19:58:24 --> Config Class Initialized
INFO - 2024-08-27 19:58:24 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:24 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:24 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:24 --> URI Class Initialized
INFO - 2024-08-27 19:58:24 --> Router Class Initialized
INFO - 2024-08-27 19:58:24 --> Output Class Initialized
INFO - 2024-08-27 19:58:24 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:24 --> Input Class Initialized
INFO - 2024-08-27 19:58:24 --> Language Class Initialized
INFO - 2024-08-27 19:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:24 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
INFO - 2024-08-27 19:58:24 --> Language Class Initialized
INFO - 2024-08-27 19:58:24 --> Config Class Initialized
INFO - 2024-08-27 19:58:24 --> Loader Class Initialized
INFO - 2024-08-27 19:58:24 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:24 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:24 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:24 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:24 --> Database Driver Class Initialized
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-27 19:58:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-27 19:58:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-27 19:58:27 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:27 --> Total execution time: 5.7061
INFO - 2024-08-27 19:58:27 --> Config Class Initialized
INFO - 2024-08-27 19:58:27 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:27 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:27 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:27 --> URI Class Initialized
INFO - 2024-08-27 19:58:27 --> Router Class Initialized
INFO - 2024-08-27 19:58:27 --> Output Class Initialized
INFO - 2024-08-27 19:58:27 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:27 --> Input Class Initialized
INFO - 2024-08-27 19:58:27 --> Language Class Initialized
INFO - 2024-08-27 19:58:27 --> Language Class Initialized
INFO - 2024-08-27 19:58:27 --> Config Class Initialized
INFO - 2024-08-27 19:58:27 --> Loader Class Initialized
INFO - 2024-08-27 19:58:27 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:27 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:27 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:27 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:27 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-27 19:58:27 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-08-27 19:58:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-27 19:58:27 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:30 --> Config Class Initialized
INFO - 2024-08-27 19:58:30 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:30 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:30 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:30 --> URI Class Initialized
INFO - 2024-08-27 19:58:30 --> Router Class Initialized
INFO - 2024-08-27 19:58:30 --> Output Class Initialized
INFO - 2024-08-27 19:58:30 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:30 --> Input Class Initialized
INFO - 2024-08-27 19:58:30 --> Language Class Initialized
INFO - 2024-08-27 19:58:30 --> Language Class Initialized
INFO - 2024-08-27 19:58:30 --> Config Class Initialized
INFO - 2024-08-27 19:58:30 --> Loader Class Initialized
INFO - 2024-08-27 19:58:30 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:30 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:30 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:30 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:30 --> Database Driver Class Initialized
INFO - 2024-08-27 19:58:30 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:30 --> Total execution time: 5.9159
INFO - 2024-08-27 19:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:30 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-08-27 19:58:30 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-08-27 19:58:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-08-27 19:58:31 --> Config Class Initialized
INFO - 2024-08-27 19:58:31 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:31 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:31 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:31 --> URI Class Initialized
INFO - 2024-08-27 19:58:31 --> Router Class Initialized
INFO - 2024-08-27 19:58:31 --> Output Class Initialized
INFO - 2024-08-27 19:58:31 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:31 --> Input Class Initialized
INFO - 2024-08-27 19:58:31 --> Language Class Initialized
INFO - 2024-08-27 19:58:31 --> Language Class Initialized
INFO - 2024-08-27 19:58:31 --> Config Class Initialized
INFO - 2024-08-27 19:58:31 --> Loader Class Initialized
INFO - 2024-08-27 19:58:31 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:31 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:31 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:31 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:31 --> Database Driver Class Initialized
ERROR - 2024-08-27 19:58:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-08-27 19:58:34 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-08-27 19:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:34 --> Controller Class Initialized
DEBUG - 2024-08-27 19:58:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-08-27 19:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:37 --> Controller Class Initialized
INFO - 2024-08-27 19:58:37 --> Config Class Initialized
INFO - 2024-08-27 19:58:37 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:37 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:37 --> Utf8 Class Initialized
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
INFO - 2024-08-27 19:58:37 --> URI Class Initialized
INFO - 2024-08-27 19:58:37 --> Router Class Initialized
INFO - 2024-08-27 19:58:37 --> Output Class Initialized
INFO - 2024-08-27 19:58:37 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:37 --> Input Class Initialized
INFO - 2024-08-27 19:58:37 --> Language Class Initialized
INFO - 2024-08-27 19:58:37 --> Language Class Initialized
INFO - 2024-08-27 19:58:37 --> Config Class Initialized
INFO - 2024-08-27 19:58:37 --> Loader Class Initialized
INFO - 2024-08-27 19:58:37 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:37 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:37 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:37 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:37 --> Database Driver Class Initialized
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-27 19:58:37 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-27 19:58:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-27 19:58:40 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:40 --> Total execution time: 9.0720
INFO - 2024-08-27 19:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:40 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
INFO - 2024-08-27 19:58:40 --> Config Class Initialized
INFO - 2024-08-27 19:58:40 --> Hooks Class Initialized
DEBUG - 2024-08-27 19:58:40 --> UTF-8 Support Enabled
INFO - 2024-08-27 19:58:40 --> Utf8 Class Initialized
INFO - 2024-08-27 19:58:40 --> URI Class Initialized
INFO - 2024-08-27 19:58:40 --> Router Class Initialized
INFO - 2024-08-27 19:58:40 --> Output Class Initialized
INFO - 2024-08-27 19:58:40 --> Security Class Initialized
DEBUG - 2024-08-27 19:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-08-27 19:58:40 --> Input Class Initialized
INFO - 2024-08-27 19:58:40 --> Language Class Initialized
INFO - 2024-08-27 19:58:40 --> Language Class Initialized
INFO - 2024-08-27 19:58:40 --> Config Class Initialized
INFO - 2024-08-27 19:58:40 --> Loader Class Initialized
INFO - 2024-08-27 19:58:40 --> Helper loaded: url_helper
INFO - 2024-08-27 19:58:40 --> Helper loaded: file_helper
INFO - 2024-08-27 19:58:40 --> Helper loaded: form_helper
INFO - 2024-08-27 19:58:40 --> Helper loaded: my_helper
INFO - 2024-08-27 19:58:40 --> Database Driver Class Initialized
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 436
ERROR - 2024-08-27 19:58:40 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 437
DEBUG - 2024-08-27 19:58:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-08-27 19:58:43 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:43 --> Total execution time: 5.1556
INFO - 2024-08-27 19:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-08-27 19:58:43 --> Controller Class Initialized
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-08-27 19:58:43 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-08-27 19:58:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-08-27 19:58:45 --> Final output sent to browser
DEBUG - 2024-08-27 19:58:45 --> Total execution time: 5.3198
