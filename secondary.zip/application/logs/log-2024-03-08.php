<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-03-08 09:39:06 --> Config Class Initialized
INFO - 2024-03-08 09:39:06 --> Hooks Class Initialized
DEBUG - 2024-03-08 09:39:06 --> UTF-8 Support Enabled
INFO - 2024-03-08 09:39:06 --> Utf8 Class Initialized
INFO - 2024-03-08 09:39:06 --> URI Class Initialized
INFO - 2024-03-08 09:39:06 --> Router Class Initialized
INFO - 2024-03-08 09:39:06 --> Output Class Initialized
INFO - 2024-03-08 09:39:06 --> Security Class Initialized
DEBUG - 2024-03-08 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 09:39:06 --> Input Class Initialized
INFO - 2024-03-08 09:39:06 --> Language Class Initialized
INFO - 2024-03-08 09:39:06 --> Language Class Initialized
INFO - 2024-03-08 09:39:06 --> Config Class Initialized
INFO - 2024-03-08 09:39:06 --> Loader Class Initialized
INFO - 2024-03-08 09:39:06 --> Helper loaded: url_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: file_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: form_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: my_helper
INFO - 2024-03-08 09:39:06 --> Database Driver Class Initialized
INFO - 2024-03-08 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 09:39:06 --> Controller Class Initialized
INFO - 2024-03-08 09:39:06 --> Config Class Initialized
INFO - 2024-03-08 09:39:06 --> Hooks Class Initialized
DEBUG - 2024-03-08 09:39:06 --> UTF-8 Support Enabled
INFO - 2024-03-08 09:39:06 --> Utf8 Class Initialized
INFO - 2024-03-08 09:39:06 --> URI Class Initialized
INFO - 2024-03-08 09:39:06 --> Router Class Initialized
INFO - 2024-03-08 09:39:06 --> Output Class Initialized
INFO - 2024-03-08 09:39:06 --> Security Class Initialized
DEBUG - 2024-03-08 09:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 09:39:06 --> Input Class Initialized
INFO - 2024-03-08 09:39:06 --> Language Class Initialized
INFO - 2024-03-08 09:39:06 --> Language Class Initialized
INFO - 2024-03-08 09:39:06 --> Config Class Initialized
INFO - 2024-03-08 09:39:06 --> Loader Class Initialized
INFO - 2024-03-08 09:39:06 --> Helper loaded: url_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: file_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: form_helper
INFO - 2024-03-08 09:39:06 --> Helper loaded: my_helper
INFO - 2024-03-08 09:39:06 --> Database Driver Class Initialized
INFO - 2024-03-08 09:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 09:39:06 --> Controller Class Initialized
DEBUG - 2024-03-08 09:39:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-08 09:39:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 09:39:06 --> Final output sent to browser
DEBUG - 2024-03-08 09:39:06 --> Total execution time: 0.0659
INFO - 2024-03-08 11:33:06 --> Config Class Initialized
INFO - 2024-03-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:06 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:06 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:06 --> URI Class Initialized
DEBUG - 2024-03-08 11:33:06 --> No URI present. Default controller set.
INFO - 2024-03-08 11:33:06 --> Router Class Initialized
INFO - 2024-03-08 11:33:06 --> Output Class Initialized
INFO - 2024-03-08 11:33:06 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:06 --> Input Class Initialized
INFO - 2024-03-08 11:33:06 --> Language Class Initialized
INFO - 2024-03-08 11:33:06 --> Language Class Initialized
INFO - 2024-03-08 11:33:06 --> Config Class Initialized
INFO - 2024-03-08 11:33:06 --> Loader Class Initialized
INFO - 2024-03-08 11:33:06 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:06 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:06 --> Controller Class Initialized
INFO - 2024-03-08 11:33:06 --> Config Class Initialized
INFO - 2024-03-08 11:33:06 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:06 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:06 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:06 --> URI Class Initialized
INFO - 2024-03-08 11:33:06 --> Router Class Initialized
INFO - 2024-03-08 11:33:06 --> Output Class Initialized
INFO - 2024-03-08 11:33:06 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:06 --> Input Class Initialized
INFO - 2024-03-08 11:33:06 --> Language Class Initialized
INFO - 2024-03-08 11:33:06 --> Language Class Initialized
INFO - 2024-03-08 11:33:06 --> Config Class Initialized
INFO - 2024-03-08 11:33:06 --> Loader Class Initialized
INFO - 2024-03-08 11:33:06 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:06 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:06 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:06 --> Controller Class Initialized
DEBUG - 2024-03-08 11:33:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-08 11:33:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:33:06 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:06 --> Total execution time: 0.0438
INFO - 2024-03-08 11:33:09 --> Config Class Initialized
INFO - 2024-03-08 11:33:09 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:09 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:09 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:09 --> URI Class Initialized
INFO - 2024-03-08 11:33:09 --> Router Class Initialized
INFO - 2024-03-08 11:33:09 --> Output Class Initialized
INFO - 2024-03-08 11:33:09 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:09 --> Input Class Initialized
INFO - 2024-03-08 11:33:09 --> Language Class Initialized
INFO - 2024-03-08 11:33:09 --> Language Class Initialized
INFO - 2024-03-08 11:33:09 --> Config Class Initialized
INFO - 2024-03-08 11:33:09 --> Loader Class Initialized
INFO - 2024-03-08 11:33:09 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:09 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:09 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:09 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:09 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:09 --> Controller Class Initialized
INFO - 2024-03-08 11:33:09 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:09 --> Total execution time: 0.0419
INFO - 2024-03-08 11:33:18 --> Config Class Initialized
INFO - 2024-03-08 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:18 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:18 --> URI Class Initialized
INFO - 2024-03-08 11:33:18 --> Router Class Initialized
INFO - 2024-03-08 11:33:18 --> Output Class Initialized
INFO - 2024-03-08 11:33:18 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:18 --> Input Class Initialized
INFO - 2024-03-08 11:33:18 --> Language Class Initialized
INFO - 2024-03-08 11:33:18 --> Language Class Initialized
INFO - 2024-03-08 11:33:18 --> Config Class Initialized
INFO - 2024-03-08 11:33:18 --> Loader Class Initialized
INFO - 2024-03-08 11:33:18 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:18 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:18 --> Controller Class Initialized
INFO - 2024-03-08 11:33:18 --> Helper loaded: cookie_helper
INFO - 2024-03-08 11:33:18 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:18 --> Total execution time: 0.0777
INFO - 2024-03-08 11:33:18 --> Config Class Initialized
INFO - 2024-03-08 11:33:18 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:18 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:18 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:18 --> URI Class Initialized
INFO - 2024-03-08 11:33:18 --> Router Class Initialized
INFO - 2024-03-08 11:33:18 --> Output Class Initialized
INFO - 2024-03-08 11:33:18 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:18 --> Input Class Initialized
INFO - 2024-03-08 11:33:18 --> Language Class Initialized
INFO - 2024-03-08 11:33:18 --> Language Class Initialized
INFO - 2024-03-08 11:33:18 --> Config Class Initialized
INFO - 2024-03-08 11:33:18 --> Loader Class Initialized
INFO - 2024-03-08 11:33:18 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:18 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:18 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:18 --> Controller Class Initialized
DEBUG - 2024-03-08 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-08 11:33:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:33:18 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:18 --> Total execution time: 0.0358
INFO - 2024-03-08 11:33:23 --> Config Class Initialized
INFO - 2024-03-08 11:33:23 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:23 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:23 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:23 --> URI Class Initialized
INFO - 2024-03-08 11:33:23 --> Router Class Initialized
INFO - 2024-03-08 11:33:23 --> Output Class Initialized
INFO - 2024-03-08 11:33:23 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:23 --> Input Class Initialized
INFO - 2024-03-08 11:33:23 --> Language Class Initialized
INFO - 2024-03-08 11:33:23 --> Language Class Initialized
INFO - 2024-03-08 11:33:23 --> Config Class Initialized
INFO - 2024-03-08 11:33:23 --> Loader Class Initialized
INFO - 2024-03-08 11:33:23 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:23 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:23 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:23 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:23 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:23 --> Controller Class Initialized
DEBUG - 2024-03-08 11:33:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-08 11:33:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:33:23 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:23 --> Total execution time: 0.0441
INFO - 2024-03-08 11:33:24 --> Config Class Initialized
INFO - 2024-03-08 11:33:24 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:24 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:24 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:24 --> URI Class Initialized
INFO - 2024-03-08 11:33:24 --> Router Class Initialized
INFO - 2024-03-08 11:33:24 --> Output Class Initialized
INFO - 2024-03-08 11:33:24 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:24 --> Input Class Initialized
INFO - 2024-03-08 11:33:24 --> Language Class Initialized
INFO - 2024-03-08 11:33:24 --> Language Class Initialized
INFO - 2024-03-08 11:33:24 --> Config Class Initialized
INFO - 2024-03-08 11:33:24 --> Loader Class Initialized
INFO - 2024-03-08 11:33:24 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:24 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:24 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:24 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:24 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:24 --> Controller Class Initialized
DEBUG - 2024-03-08 11:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2024-03-08 11:33:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:33:25 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:25 --> Total execution time: 0.3678
INFO - 2024-03-08 11:33:25 --> Config Class Initialized
INFO - 2024-03-08 11:33:25 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:25 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:25 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:25 --> URI Class Initialized
INFO - 2024-03-08 11:33:25 --> Router Class Initialized
INFO - 2024-03-08 11:33:25 --> Output Class Initialized
INFO - 2024-03-08 11:33:25 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:25 --> Input Class Initialized
INFO - 2024-03-08 11:33:25 --> Language Class Initialized
INFO - 2024-03-08 11:33:25 --> Language Class Initialized
INFO - 2024-03-08 11:33:25 --> Config Class Initialized
INFO - 2024-03-08 11:33:25 --> Loader Class Initialized
INFO - 2024-03-08 11:33:25 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:25 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:25 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:25 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:25 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:25 --> Controller Class Initialized
INFO - 2024-03-08 11:33:32 --> Config Class Initialized
INFO - 2024-03-08 11:33:32 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:32 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:32 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:32 --> URI Class Initialized
INFO - 2024-03-08 11:33:32 --> Router Class Initialized
INFO - 2024-03-08 11:33:32 --> Output Class Initialized
INFO - 2024-03-08 11:33:32 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:32 --> Input Class Initialized
INFO - 2024-03-08 11:33:32 --> Language Class Initialized
INFO - 2024-03-08 11:33:32 --> Language Class Initialized
INFO - 2024-03-08 11:33:32 --> Config Class Initialized
INFO - 2024-03-08 11:33:32 --> Loader Class Initialized
INFO - 2024-03-08 11:33:32 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:32 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:32 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:32 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:32 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:32 --> Controller Class Initialized
INFO - 2024-03-08 11:33:32 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:32 --> Total execution time: 0.1731
INFO - 2024-03-08 11:33:38 --> Config Class Initialized
INFO - 2024-03-08 11:33:38 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:38 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:38 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:38 --> URI Class Initialized
INFO - 2024-03-08 11:33:38 --> Router Class Initialized
INFO - 2024-03-08 11:33:38 --> Output Class Initialized
INFO - 2024-03-08 11:33:38 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:38 --> Input Class Initialized
INFO - 2024-03-08 11:33:38 --> Language Class Initialized
INFO - 2024-03-08 11:33:38 --> Language Class Initialized
INFO - 2024-03-08 11:33:38 --> Config Class Initialized
INFO - 2024-03-08 11:33:38 --> Loader Class Initialized
INFO - 2024-03-08 11:33:38 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:38 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:38 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:38 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:38 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:38 --> Controller Class Initialized
INFO - 2024-03-08 11:33:39 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:39 --> Total execution time: 0.4043
INFO - 2024-03-08 11:33:43 --> Config Class Initialized
INFO - 2024-03-08 11:33:43 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:43 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:43 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:43 --> URI Class Initialized
INFO - 2024-03-08 11:33:43 --> Router Class Initialized
INFO - 2024-03-08 11:33:43 --> Output Class Initialized
INFO - 2024-03-08 11:33:43 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:43 --> Input Class Initialized
INFO - 2024-03-08 11:33:43 --> Language Class Initialized
INFO - 2024-03-08 11:33:43 --> Language Class Initialized
INFO - 2024-03-08 11:33:43 --> Config Class Initialized
INFO - 2024-03-08 11:33:43 --> Loader Class Initialized
INFO - 2024-03-08 11:33:43 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:43 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:43 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:43 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:43 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:43 --> Controller Class Initialized
INFO - 2024-03-08 11:33:43 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:43 --> Total execution time: 0.1147
INFO - 2024-03-08 11:33:50 --> Config Class Initialized
INFO - 2024-03-08 11:33:50 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:50 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:50 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:50 --> URI Class Initialized
INFO - 2024-03-08 11:33:50 --> Router Class Initialized
INFO - 2024-03-08 11:33:50 --> Output Class Initialized
INFO - 2024-03-08 11:33:50 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:50 --> Input Class Initialized
INFO - 2024-03-08 11:33:50 --> Language Class Initialized
INFO - 2024-03-08 11:33:50 --> Language Class Initialized
INFO - 2024-03-08 11:33:50 --> Config Class Initialized
INFO - 2024-03-08 11:33:50 --> Loader Class Initialized
INFO - 2024-03-08 11:33:50 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:50 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:50 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:50 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:50 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:50 --> Controller Class Initialized
INFO - 2024-03-08 11:33:50 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:50 --> Total execution time: 0.1688
INFO - 2024-03-08 11:33:55 --> Config Class Initialized
INFO - 2024-03-08 11:33:55 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:55 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:55 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:55 --> URI Class Initialized
INFO - 2024-03-08 11:33:55 --> Router Class Initialized
INFO - 2024-03-08 11:33:55 --> Output Class Initialized
INFO - 2024-03-08 11:33:55 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:55 --> Input Class Initialized
INFO - 2024-03-08 11:33:55 --> Language Class Initialized
INFO - 2024-03-08 11:33:55 --> Language Class Initialized
INFO - 2024-03-08 11:33:55 --> Config Class Initialized
INFO - 2024-03-08 11:33:55 --> Loader Class Initialized
INFO - 2024-03-08 11:33:55 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:55 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:55 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:55 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:55 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:55 --> Controller Class Initialized
INFO - 2024-03-08 11:33:55 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:55 --> Total execution time: 0.0483
INFO - 2024-03-08 11:33:59 --> Config Class Initialized
INFO - 2024-03-08 11:33:59 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:33:59 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:33:59 --> Utf8 Class Initialized
INFO - 2024-03-08 11:33:59 --> URI Class Initialized
INFO - 2024-03-08 11:33:59 --> Router Class Initialized
INFO - 2024-03-08 11:33:59 --> Output Class Initialized
INFO - 2024-03-08 11:33:59 --> Security Class Initialized
DEBUG - 2024-03-08 11:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:33:59 --> Input Class Initialized
INFO - 2024-03-08 11:33:59 --> Language Class Initialized
INFO - 2024-03-08 11:33:59 --> Language Class Initialized
INFO - 2024-03-08 11:33:59 --> Config Class Initialized
INFO - 2024-03-08 11:33:59 --> Loader Class Initialized
INFO - 2024-03-08 11:33:59 --> Helper loaded: url_helper
INFO - 2024-03-08 11:33:59 --> Helper loaded: file_helper
INFO - 2024-03-08 11:33:59 --> Helper loaded: form_helper
INFO - 2024-03-08 11:33:59 --> Helper loaded: my_helper
INFO - 2024-03-08 11:33:59 --> Database Driver Class Initialized
INFO - 2024-03-08 11:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:33:59 --> Controller Class Initialized
INFO - 2024-03-08 11:33:59 --> Final output sent to browser
DEBUG - 2024-03-08 11:33:59 --> Total execution time: 0.0424
INFO - 2024-03-08 11:36:37 --> Config Class Initialized
INFO - 2024-03-08 11:36:37 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:36:37 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:36:37 --> Utf8 Class Initialized
INFO - 2024-03-08 11:36:37 --> URI Class Initialized
INFO - 2024-03-08 11:36:37 --> Router Class Initialized
INFO - 2024-03-08 11:36:37 --> Output Class Initialized
INFO - 2024-03-08 11:36:37 --> Security Class Initialized
DEBUG - 2024-03-08 11:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:36:37 --> Input Class Initialized
INFO - 2024-03-08 11:36:37 --> Language Class Initialized
INFO - 2024-03-08 11:36:37 --> Language Class Initialized
INFO - 2024-03-08 11:36:37 --> Config Class Initialized
INFO - 2024-03-08 11:36:37 --> Loader Class Initialized
INFO - 2024-03-08 11:36:37 --> Helper loaded: url_helper
INFO - 2024-03-08 11:36:37 --> Helper loaded: file_helper
INFO - 2024-03-08 11:36:37 --> Helper loaded: form_helper
INFO - 2024-03-08 11:36:37 --> Helper loaded: my_helper
INFO - 2024-03-08 11:36:37 --> Database Driver Class Initialized
INFO - 2024-03-08 11:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:36:37 --> Controller Class Initialized
INFO - 2024-03-08 11:36:37 --> Final output sent to browser
DEBUG - 2024-03-08 11:36:37 --> Total execution time: 0.1112
INFO - 2024-03-08 11:36:40 --> Config Class Initialized
INFO - 2024-03-08 11:36:40 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:36:40 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:36:40 --> Utf8 Class Initialized
INFO - 2024-03-08 11:36:40 --> URI Class Initialized
INFO - 2024-03-08 11:36:40 --> Router Class Initialized
INFO - 2024-03-08 11:36:40 --> Output Class Initialized
INFO - 2024-03-08 11:36:40 --> Security Class Initialized
DEBUG - 2024-03-08 11:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:36:40 --> Input Class Initialized
INFO - 2024-03-08 11:36:40 --> Language Class Initialized
INFO - 2024-03-08 11:36:40 --> Language Class Initialized
INFO - 2024-03-08 11:36:40 --> Config Class Initialized
INFO - 2024-03-08 11:36:40 --> Loader Class Initialized
INFO - 2024-03-08 11:36:40 --> Helper loaded: url_helper
INFO - 2024-03-08 11:36:40 --> Helper loaded: file_helper
INFO - 2024-03-08 11:36:40 --> Helper loaded: form_helper
INFO - 2024-03-08 11:36:40 --> Helper loaded: my_helper
INFO - 2024-03-08 11:36:40 --> Database Driver Class Initialized
INFO - 2024-03-08 11:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:36:40 --> Controller Class Initialized
INFO - 2024-03-08 11:36:40 --> Final output sent to browser
DEBUG - 2024-03-08 11:36:40 --> Total execution time: 0.0347
INFO - 2024-03-08 11:39:57 --> Config Class Initialized
INFO - 2024-03-08 11:39:57 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:39:57 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:39:57 --> Utf8 Class Initialized
INFO - 2024-03-08 11:39:57 --> URI Class Initialized
INFO - 2024-03-08 11:39:57 --> Router Class Initialized
INFO - 2024-03-08 11:39:57 --> Output Class Initialized
INFO - 2024-03-08 11:39:57 --> Security Class Initialized
DEBUG - 2024-03-08 11:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:39:57 --> Input Class Initialized
INFO - 2024-03-08 11:39:57 --> Language Class Initialized
INFO - 2024-03-08 11:39:57 --> Language Class Initialized
INFO - 2024-03-08 11:39:57 --> Config Class Initialized
INFO - 2024-03-08 11:39:57 --> Loader Class Initialized
INFO - 2024-03-08 11:39:57 --> Helper loaded: url_helper
INFO - 2024-03-08 11:39:57 --> Helper loaded: file_helper
INFO - 2024-03-08 11:39:57 --> Helper loaded: form_helper
INFO - 2024-03-08 11:39:57 --> Helper loaded: my_helper
INFO - 2024-03-08 11:39:57 --> Database Driver Class Initialized
INFO - 2024-03-08 11:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:39:57 --> Controller Class Initialized
INFO - 2024-03-08 11:39:57 --> Final output sent to browser
DEBUG - 2024-03-08 11:39:57 --> Total execution time: 0.0707
INFO - 2024-03-08 11:40:03 --> Config Class Initialized
INFO - 2024-03-08 11:40:03 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:40:03 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:40:03 --> Utf8 Class Initialized
INFO - 2024-03-08 11:40:03 --> URI Class Initialized
INFO - 2024-03-08 11:40:03 --> Router Class Initialized
INFO - 2024-03-08 11:40:03 --> Output Class Initialized
INFO - 2024-03-08 11:40:03 --> Security Class Initialized
DEBUG - 2024-03-08 11:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:40:03 --> Input Class Initialized
INFO - 2024-03-08 11:40:03 --> Language Class Initialized
INFO - 2024-03-08 11:40:03 --> Language Class Initialized
INFO - 2024-03-08 11:40:03 --> Config Class Initialized
INFO - 2024-03-08 11:40:03 --> Loader Class Initialized
INFO - 2024-03-08 11:40:03 --> Helper loaded: url_helper
INFO - 2024-03-08 11:40:03 --> Helper loaded: file_helper
INFO - 2024-03-08 11:40:03 --> Helper loaded: form_helper
INFO - 2024-03-08 11:40:03 --> Helper loaded: my_helper
INFO - 2024-03-08 11:40:03 --> Database Driver Class Initialized
INFO - 2024-03-08 11:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:40:03 --> Controller Class Initialized
DEBUG - 2024-03-08 11:40:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2024-03-08 11:40:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:40:03 --> Final output sent to browser
DEBUG - 2024-03-08 11:40:03 --> Total execution time: 0.0502
INFO - 2024-03-08 11:40:04 --> Config Class Initialized
INFO - 2024-03-08 11:40:04 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:40:04 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:40:04 --> Utf8 Class Initialized
INFO - 2024-03-08 11:40:04 --> URI Class Initialized
INFO - 2024-03-08 11:40:04 --> Router Class Initialized
INFO - 2024-03-08 11:40:04 --> Output Class Initialized
INFO - 2024-03-08 11:40:04 --> Security Class Initialized
DEBUG - 2024-03-08 11:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:40:04 --> Input Class Initialized
INFO - 2024-03-08 11:40:04 --> Language Class Initialized
INFO - 2024-03-08 11:40:04 --> Language Class Initialized
INFO - 2024-03-08 11:40:04 --> Config Class Initialized
INFO - 2024-03-08 11:40:04 --> Loader Class Initialized
INFO - 2024-03-08 11:40:04 --> Helper loaded: url_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: file_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: form_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: my_helper
INFO - 2024-03-08 11:40:04 --> Database Driver Class Initialized
INFO - 2024-03-08 11:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:40:04 --> Controller Class Initialized
DEBUG - 2024-03-08 11:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2024-03-08 11:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:40:04 --> Final output sent to browser
DEBUG - 2024-03-08 11:40:04 --> Total execution time: 0.0485
INFO - 2024-03-08 11:40:04 --> Config Class Initialized
INFO - 2024-03-08 11:40:04 --> Hooks Class Initialized
DEBUG - 2024-03-08 11:40:04 --> UTF-8 Support Enabled
INFO - 2024-03-08 11:40:04 --> Utf8 Class Initialized
INFO - 2024-03-08 11:40:04 --> URI Class Initialized
INFO - 2024-03-08 11:40:04 --> Router Class Initialized
INFO - 2024-03-08 11:40:04 --> Output Class Initialized
INFO - 2024-03-08 11:40:04 --> Security Class Initialized
DEBUG - 2024-03-08 11:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-03-08 11:40:04 --> Input Class Initialized
INFO - 2024-03-08 11:40:04 --> Language Class Initialized
INFO - 2024-03-08 11:40:04 --> Language Class Initialized
INFO - 2024-03-08 11:40:04 --> Config Class Initialized
INFO - 2024-03-08 11:40:04 --> Loader Class Initialized
INFO - 2024-03-08 11:40:04 --> Helper loaded: url_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: file_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: form_helper
INFO - 2024-03-08 11:40:04 --> Helper loaded: my_helper
INFO - 2024-03-08 11:40:04 --> Database Driver Class Initialized
INFO - 2024-03-08 11:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-03-08 11:40:04 --> Controller Class Initialized
DEBUG - 2024-03-08 11:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-03-08 11:40:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-03-08 11:40:04 --> Final output sent to browser
DEBUG - 2024-03-08 11:40:04 --> Total execution time: 0.0375
