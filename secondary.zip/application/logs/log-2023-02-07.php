<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-02-07 09:47:30 --> Config Class Initialized
INFO - 2023-02-07 09:47:30 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:30 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:30 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:30 --> URI Class Initialized
DEBUG - 2023-02-07 09:47:30 --> No URI present. Default controller set.
INFO - 2023-02-07 09:47:30 --> Router Class Initialized
INFO - 2023-02-07 09:47:30 --> Output Class Initialized
INFO - 2023-02-07 09:47:30 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:30 --> Input Class Initialized
INFO - 2023-02-07 09:47:30 --> Language Class Initialized
INFO - 2023-02-07 09:47:31 --> Language Class Initialized
INFO - 2023-02-07 09:47:31 --> Config Class Initialized
INFO - 2023-02-07 09:47:31 --> Loader Class Initialized
INFO - 2023-02-07 09:47:31 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:31 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:31 --> Controller Class Initialized
INFO - 2023-02-07 09:47:31 --> Config Class Initialized
INFO - 2023-02-07 09:47:31 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:31 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:31 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:31 --> URI Class Initialized
INFO - 2023-02-07 09:47:31 --> Router Class Initialized
INFO - 2023-02-07 09:47:31 --> Output Class Initialized
INFO - 2023-02-07 09:47:31 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:31 --> Input Class Initialized
INFO - 2023-02-07 09:47:31 --> Language Class Initialized
INFO - 2023-02-07 09:47:31 --> Language Class Initialized
INFO - 2023-02-07 09:47:31 --> Config Class Initialized
INFO - 2023-02-07 09:47:31 --> Loader Class Initialized
INFO - 2023-02-07 09:47:31 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:31 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:31 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:31 --> Controller Class Initialized
DEBUG - 2023-02-07 09:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 09:47:31 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:47:31 --> Final output sent to browser
DEBUG - 2023-02-07 09:47:31 --> Total execution time: 0.0593
INFO - 2023-02-07 09:47:37 --> Config Class Initialized
INFO - 2023-02-07 09:47:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:37 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:37 --> URI Class Initialized
INFO - 2023-02-07 09:47:37 --> Router Class Initialized
INFO - 2023-02-07 09:47:37 --> Output Class Initialized
INFO - 2023-02-07 09:47:37 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:37 --> Input Class Initialized
INFO - 2023-02-07 09:47:37 --> Language Class Initialized
INFO - 2023-02-07 09:47:37 --> Language Class Initialized
INFO - 2023-02-07 09:47:37 --> Config Class Initialized
INFO - 2023-02-07 09:47:37 --> Loader Class Initialized
INFO - 2023-02-07 09:47:37 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:37 --> Controller Class Initialized
INFO - 2023-02-07 09:47:37 --> Helper loaded: cookie_helper
INFO - 2023-02-07 09:47:37 --> Final output sent to browser
DEBUG - 2023-02-07 09:47:37 --> Total execution time: 0.0674
INFO - 2023-02-07 09:47:37 --> Config Class Initialized
INFO - 2023-02-07 09:47:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:37 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:37 --> URI Class Initialized
INFO - 2023-02-07 09:47:37 --> Router Class Initialized
INFO - 2023-02-07 09:47:37 --> Output Class Initialized
INFO - 2023-02-07 09:47:37 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:37 --> Input Class Initialized
INFO - 2023-02-07 09:47:37 --> Language Class Initialized
INFO - 2023-02-07 09:47:37 --> Language Class Initialized
INFO - 2023-02-07 09:47:37 --> Config Class Initialized
INFO - 2023-02-07 09:47:37 --> Loader Class Initialized
INFO - 2023-02-07 09:47:37 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:37 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:37 --> Controller Class Initialized
DEBUG - 2023-02-07 09:47:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 09:47:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:47:37 --> Final output sent to browser
DEBUG - 2023-02-07 09:47:37 --> Total execution time: 0.0727
INFO - 2023-02-07 09:47:43 --> Config Class Initialized
INFO - 2023-02-07 09:47:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:43 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:43 --> URI Class Initialized
INFO - 2023-02-07 09:47:43 --> Router Class Initialized
INFO - 2023-02-07 09:47:43 --> Output Class Initialized
INFO - 2023-02-07 09:47:43 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:43 --> Input Class Initialized
INFO - 2023-02-07 09:47:43 --> Language Class Initialized
INFO - 2023-02-07 09:47:43 --> Language Class Initialized
INFO - 2023-02-07 09:47:43 --> Config Class Initialized
INFO - 2023-02-07 09:47:43 --> Loader Class Initialized
INFO - 2023-02-07 09:47:43 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:43 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:43 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:43 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:43 --> Controller Class Initialized
DEBUG - 2023-02-07 09:47:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/list.php
DEBUG - 2023-02-07 09:47:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:47:43 --> Final output sent to browser
DEBUG - 2023-02-07 09:47:43 --> Total execution time: 0.0572
INFO - 2023-02-07 09:47:46 --> Config Class Initialized
INFO - 2023-02-07 09:47:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:47:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:47:46 --> Utf8 Class Initialized
INFO - 2023-02-07 09:47:46 --> URI Class Initialized
INFO - 2023-02-07 09:47:46 --> Router Class Initialized
INFO - 2023-02-07 09:47:46 --> Output Class Initialized
INFO - 2023-02-07 09:47:46 --> Security Class Initialized
DEBUG - 2023-02-07 09:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:47:46 --> Input Class Initialized
INFO - 2023-02-07 09:47:46 --> Language Class Initialized
INFO - 2023-02-07 09:47:46 --> Language Class Initialized
INFO - 2023-02-07 09:47:46 --> Config Class Initialized
INFO - 2023-02-07 09:47:46 --> Loader Class Initialized
INFO - 2023-02-07 09:47:46 --> Helper loaded: url_helper
INFO - 2023-02-07 09:47:46 --> Helper loaded: file_helper
INFO - 2023-02-07 09:47:46 --> Helper loaded: form_helper
INFO - 2023-02-07 09:47:46 --> Helper loaded: my_helper
INFO - 2023-02-07 09:47:46 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:47:46 --> Controller Class Initialized
DEBUG - 2023-02-07 09:47:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/cetak_raport/views/cetak_mh.php
INFO - 2023-02-07 09:47:48 --> Final output sent to browser
DEBUG - 2023-02-07 09:47:48 --> Total execution time: 1.9263
INFO - 2023-02-07 09:48:33 --> Config Class Initialized
INFO - 2023-02-07 09:48:33 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:48:33 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:48:33 --> Utf8 Class Initialized
INFO - 2023-02-07 09:48:33 --> URI Class Initialized
INFO - 2023-02-07 09:48:33 --> Router Class Initialized
INFO - 2023-02-07 09:48:33 --> Output Class Initialized
INFO - 2023-02-07 09:48:33 --> Security Class Initialized
DEBUG - 2023-02-07 09:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:48:33 --> Input Class Initialized
INFO - 2023-02-07 09:48:33 --> Language Class Initialized
INFO - 2023-02-07 09:48:33 --> Language Class Initialized
INFO - 2023-02-07 09:48:33 --> Config Class Initialized
INFO - 2023-02-07 09:48:33 --> Loader Class Initialized
INFO - 2023-02-07 09:48:33 --> Helper loaded: url_helper
INFO - 2023-02-07 09:48:33 --> Helper loaded: file_helper
INFO - 2023-02-07 09:48:33 --> Helper loaded: form_helper
INFO - 2023-02-07 09:48:33 --> Helper loaded: my_helper
INFO - 2023-02-07 09:48:33 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:48:33 --> Controller Class Initialized
DEBUG - 2023-02-07 09:48:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 09:48:33 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:48:33 --> Final output sent to browser
DEBUG - 2023-02-07 09:48:33 --> Total execution time: 0.0819
INFO - 2023-02-07 09:48:34 --> Config Class Initialized
INFO - 2023-02-07 09:48:34 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:48:34 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:48:34 --> Utf8 Class Initialized
INFO - 2023-02-07 09:48:34 --> URI Class Initialized
INFO - 2023-02-07 09:48:34 --> Router Class Initialized
INFO - 2023-02-07 09:48:34 --> Output Class Initialized
INFO - 2023-02-07 09:48:34 --> Security Class Initialized
DEBUG - 2023-02-07 09:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:48:34 --> Input Class Initialized
INFO - 2023-02-07 09:48:34 --> Language Class Initialized
INFO - 2023-02-07 09:48:34 --> Language Class Initialized
INFO - 2023-02-07 09:48:34 --> Config Class Initialized
INFO - 2023-02-07 09:48:34 --> Loader Class Initialized
INFO - 2023-02-07 09:48:34 --> Helper loaded: url_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: file_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: form_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: my_helper
INFO - 2023-02-07 09:48:34 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:48:34 --> Controller Class Initialized
DEBUG - 2023-02-07 09:48:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 09:48:34 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:48:34 --> Final output sent to browser
DEBUG - 2023-02-07 09:48:34 --> Total execution time: 0.0762
INFO - 2023-02-07 09:48:34 --> Config Class Initialized
INFO - 2023-02-07 09:48:34 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:48:34 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:48:34 --> Utf8 Class Initialized
INFO - 2023-02-07 09:48:34 --> URI Class Initialized
INFO - 2023-02-07 09:48:34 --> Router Class Initialized
INFO - 2023-02-07 09:48:34 --> Output Class Initialized
INFO - 2023-02-07 09:48:34 --> Security Class Initialized
DEBUG - 2023-02-07 09:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:48:34 --> Input Class Initialized
INFO - 2023-02-07 09:48:34 --> Language Class Initialized
INFO - 2023-02-07 09:48:34 --> Language Class Initialized
INFO - 2023-02-07 09:48:34 --> Config Class Initialized
INFO - 2023-02-07 09:48:34 --> Loader Class Initialized
INFO - 2023-02-07 09:48:34 --> Helper loaded: url_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: file_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: form_helper
INFO - 2023-02-07 09:48:34 --> Helper loaded: my_helper
INFO - 2023-02-07 09:48:34 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:48:34 --> Controller Class Initialized
INFO - 2023-02-07 09:50:08 --> Config Class Initialized
INFO - 2023-02-07 09:50:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:50:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:50:08 --> Utf8 Class Initialized
INFO - 2023-02-07 09:50:08 --> URI Class Initialized
INFO - 2023-02-07 09:50:08 --> Router Class Initialized
INFO - 2023-02-07 09:50:08 --> Output Class Initialized
INFO - 2023-02-07 09:50:08 --> Security Class Initialized
DEBUG - 2023-02-07 09:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:50:08 --> Input Class Initialized
INFO - 2023-02-07 09:50:08 --> Language Class Initialized
INFO - 2023-02-07 09:50:08 --> Language Class Initialized
INFO - 2023-02-07 09:50:08 --> Config Class Initialized
INFO - 2023-02-07 09:50:08 --> Loader Class Initialized
INFO - 2023-02-07 09:50:08 --> Helper loaded: url_helper
INFO - 2023-02-07 09:50:08 --> Helper loaded: file_helper
INFO - 2023-02-07 09:50:08 --> Helper loaded: form_helper
INFO - 2023-02-07 09:50:08 --> Helper loaded: my_helper
INFO - 2023-02-07 09:50:08 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:50:08 --> Controller Class Initialized
INFO - 2023-02-07 09:50:08 --> Final output sent to browser
DEBUG - 2023-02-07 09:50:08 --> Total execution time: 0.0489
INFO - 2023-02-07 09:50:12 --> Config Class Initialized
INFO - 2023-02-07 09:50:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:50:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:50:12 --> Utf8 Class Initialized
INFO - 2023-02-07 09:50:12 --> URI Class Initialized
INFO - 2023-02-07 09:50:12 --> Router Class Initialized
INFO - 2023-02-07 09:50:12 --> Output Class Initialized
INFO - 2023-02-07 09:50:12 --> Security Class Initialized
DEBUG - 2023-02-07 09:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:50:12 --> Input Class Initialized
INFO - 2023-02-07 09:50:12 --> Language Class Initialized
ERROR - 2023-02-07 09:50:12 --> 404 Page Not Found: /index
INFO - 2023-02-07 09:50:17 --> Config Class Initialized
INFO - 2023-02-07 09:50:17 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:50:17 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:50:17 --> Utf8 Class Initialized
INFO - 2023-02-07 09:50:17 --> URI Class Initialized
INFO - 2023-02-07 09:50:17 --> Router Class Initialized
INFO - 2023-02-07 09:50:17 --> Output Class Initialized
INFO - 2023-02-07 09:50:17 --> Security Class Initialized
DEBUG - 2023-02-07 09:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:50:17 --> Input Class Initialized
INFO - 2023-02-07 09:50:17 --> Language Class Initialized
INFO - 2023-02-07 09:50:17 --> Language Class Initialized
INFO - 2023-02-07 09:50:17 --> Config Class Initialized
INFO - 2023-02-07 09:50:17 --> Loader Class Initialized
INFO - 2023-02-07 09:50:17 --> Helper loaded: url_helper
INFO - 2023-02-07 09:50:17 --> Helper loaded: file_helper
INFO - 2023-02-07 09:50:17 --> Helper loaded: form_helper
INFO - 2023-02-07 09:50:17 --> Helper loaded: my_helper
INFO - 2023-02-07 09:50:17 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:50:17 --> Controller Class Initialized
INFO - 2023-02-07 09:50:17 --> Final output sent to browser
DEBUG - 2023-02-07 09:50:17 --> Total execution time: 0.0255
INFO - 2023-02-07 09:51:39 --> Config Class Initialized
INFO - 2023-02-07 09:51:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:51:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:51:39 --> Utf8 Class Initialized
INFO - 2023-02-07 09:51:39 --> URI Class Initialized
INFO - 2023-02-07 09:51:39 --> Router Class Initialized
INFO - 2023-02-07 09:51:39 --> Output Class Initialized
INFO - 2023-02-07 09:51:39 --> Security Class Initialized
DEBUG - 2023-02-07 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:51:39 --> Input Class Initialized
INFO - 2023-02-07 09:51:39 --> Language Class Initialized
INFO - 2023-02-07 09:51:39 --> Language Class Initialized
INFO - 2023-02-07 09:51:39 --> Config Class Initialized
INFO - 2023-02-07 09:51:39 --> Loader Class Initialized
INFO - 2023-02-07 09:51:39 --> Helper loaded: url_helper
INFO - 2023-02-07 09:51:39 --> Helper loaded: file_helper
INFO - 2023-02-07 09:51:39 --> Helper loaded: form_helper
INFO - 2023-02-07 09:51:39 --> Helper loaded: my_helper
INFO - 2023-02-07 09:51:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:51:39 --> Controller Class Initialized
INFO - 2023-02-07 09:51:39 --> Final output sent to browser
DEBUG - 2023-02-07 09:51:39 --> Total execution time: 0.0545
INFO - 2023-02-07 09:51:40 --> Config Class Initialized
INFO - 2023-02-07 09:51:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:51:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:51:40 --> Utf8 Class Initialized
INFO - 2023-02-07 09:51:40 --> URI Class Initialized
INFO - 2023-02-07 09:51:40 --> Router Class Initialized
INFO - 2023-02-07 09:51:40 --> Output Class Initialized
INFO - 2023-02-07 09:51:40 --> Security Class Initialized
DEBUG - 2023-02-07 09:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:51:40 --> Input Class Initialized
INFO - 2023-02-07 09:51:40 --> Language Class Initialized
INFO - 2023-02-07 09:51:40 --> Language Class Initialized
INFO - 2023-02-07 09:51:40 --> Config Class Initialized
INFO - 2023-02-07 09:51:40 --> Loader Class Initialized
INFO - 2023-02-07 09:51:40 --> Helper loaded: url_helper
INFO - 2023-02-07 09:51:40 --> Helper loaded: file_helper
INFO - 2023-02-07 09:51:40 --> Helper loaded: form_helper
INFO - 2023-02-07 09:51:40 --> Helper loaded: my_helper
INFO - 2023-02-07 09:51:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:51:40 --> Controller Class Initialized
INFO - 2023-02-07 09:51:40 --> Final output sent to browser
DEBUG - 2023-02-07 09:51:40 --> Total execution time: 0.0247
INFO - 2023-02-07 09:55:08 --> Config Class Initialized
INFO - 2023-02-07 09:55:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:08 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:08 --> URI Class Initialized
INFO - 2023-02-07 09:55:08 --> Router Class Initialized
INFO - 2023-02-07 09:55:08 --> Output Class Initialized
INFO - 2023-02-07 09:55:08 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:08 --> Input Class Initialized
INFO - 2023-02-07 09:55:08 --> Language Class Initialized
INFO - 2023-02-07 09:55:08 --> Language Class Initialized
INFO - 2023-02-07 09:55:08 --> Config Class Initialized
INFO - 2023-02-07 09:55:08 --> Loader Class Initialized
INFO - 2023-02-07 09:55:08 --> Helper loaded: url_helper
INFO - 2023-02-07 09:55:08 --> Helper loaded: file_helper
INFO - 2023-02-07 09:55:08 --> Helper loaded: form_helper
INFO - 2023-02-07 09:55:08 --> Helper loaded: my_helper
INFO - 2023-02-07 09:55:08 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:55:08 --> Controller Class Initialized
DEBUG - 2023-02-07 09:55:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 09:55:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:55:08 --> Final output sent to browser
DEBUG - 2023-02-07 09:55:08 --> Total execution time: 0.0312
INFO - 2023-02-07 09:55:08 --> Config Class Initialized
INFO - 2023-02-07 09:55:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:08 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:08 --> URI Class Initialized
INFO - 2023-02-07 09:55:08 --> Router Class Initialized
INFO - 2023-02-07 09:55:08 --> Output Class Initialized
INFO - 2023-02-07 09:55:08 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:08 --> Input Class Initialized
INFO - 2023-02-07 09:55:08 --> Language Class Initialized
ERROR - 2023-02-07 09:55:08 --> 404 Page Not Found: /index
INFO - 2023-02-07 09:55:12 --> Config Class Initialized
INFO - 2023-02-07 09:55:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:12 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:12 --> URI Class Initialized
INFO - 2023-02-07 09:55:12 --> Router Class Initialized
INFO - 2023-02-07 09:55:12 --> Output Class Initialized
INFO - 2023-02-07 09:55:12 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:12 --> Input Class Initialized
INFO - 2023-02-07 09:55:12 --> Language Class Initialized
INFO - 2023-02-07 09:55:12 --> Language Class Initialized
INFO - 2023-02-07 09:55:12 --> Config Class Initialized
INFO - 2023-02-07 09:55:12 --> Loader Class Initialized
INFO - 2023-02-07 09:55:12 --> Helper loaded: url_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: file_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: form_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: my_helper
INFO - 2023-02-07 09:55:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:55:12 --> Controller Class Initialized
DEBUG - 2023-02-07 09:55:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 09:55:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:55:12 --> Final output sent to browser
DEBUG - 2023-02-07 09:55:12 --> Total execution time: 0.0297
INFO - 2023-02-07 09:55:12 --> Config Class Initialized
INFO - 2023-02-07 09:55:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:12 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:12 --> URI Class Initialized
INFO - 2023-02-07 09:55:12 --> Router Class Initialized
INFO - 2023-02-07 09:55:12 --> Output Class Initialized
INFO - 2023-02-07 09:55:12 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:12 --> Input Class Initialized
INFO - 2023-02-07 09:55:12 --> Language Class Initialized
ERROR - 2023-02-07 09:55:12 --> 404 Page Not Found: /index
INFO - 2023-02-07 09:55:12 --> Config Class Initialized
INFO - 2023-02-07 09:55:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:12 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:12 --> URI Class Initialized
INFO - 2023-02-07 09:55:12 --> Router Class Initialized
INFO - 2023-02-07 09:55:12 --> Output Class Initialized
INFO - 2023-02-07 09:55:12 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:12 --> Input Class Initialized
INFO - 2023-02-07 09:55:12 --> Language Class Initialized
INFO - 2023-02-07 09:55:12 --> Language Class Initialized
INFO - 2023-02-07 09:55:12 --> Config Class Initialized
INFO - 2023-02-07 09:55:12 --> Loader Class Initialized
INFO - 2023-02-07 09:55:12 --> Helper loaded: url_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: file_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: form_helper
INFO - 2023-02-07 09:55:12 --> Helper loaded: my_helper
INFO - 2023-02-07 09:55:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:55:12 --> Controller Class Initialized
INFO - 2023-02-07 09:55:40 --> Config Class Initialized
INFO - 2023-02-07 09:55:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:40 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:40 --> URI Class Initialized
INFO - 2023-02-07 09:55:40 --> Router Class Initialized
INFO - 2023-02-07 09:55:40 --> Output Class Initialized
INFO - 2023-02-07 09:55:40 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:40 --> Input Class Initialized
INFO - 2023-02-07 09:55:40 --> Language Class Initialized
INFO - 2023-02-07 09:55:40 --> Language Class Initialized
INFO - 2023-02-07 09:55:40 --> Config Class Initialized
INFO - 2023-02-07 09:55:40 --> Loader Class Initialized
INFO - 2023-02-07 09:55:40 --> Helper loaded: url_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: file_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: form_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: my_helper
INFO - 2023-02-07 09:55:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:55:40 --> Controller Class Initialized
INFO - 2023-02-07 09:55:40 --> Final output sent to browser
DEBUG - 2023-02-07 09:55:40 --> Total execution time: 0.0352
INFO - 2023-02-07 09:55:40 --> Config Class Initialized
INFO - 2023-02-07 09:55:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:55:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:55:40 --> Utf8 Class Initialized
INFO - 2023-02-07 09:55:40 --> URI Class Initialized
INFO - 2023-02-07 09:55:40 --> Router Class Initialized
INFO - 2023-02-07 09:55:40 --> Output Class Initialized
INFO - 2023-02-07 09:55:40 --> Security Class Initialized
DEBUG - 2023-02-07 09:55:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:55:40 --> Input Class Initialized
INFO - 2023-02-07 09:55:40 --> Language Class Initialized
INFO - 2023-02-07 09:55:40 --> Language Class Initialized
INFO - 2023-02-07 09:55:40 --> Config Class Initialized
INFO - 2023-02-07 09:55:40 --> Loader Class Initialized
INFO - 2023-02-07 09:55:40 --> Helper loaded: url_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: file_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: form_helper
INFO - 2023-02-07 09:55:40 --> Helper loaded: my_helper
INFO - 2023-02-07 09:55:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:55:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:55:40 --> Controller Class Initialized
INFO - 2023-02-07 09:55:40 --> Final output sent to browser
DEBUG - 2023-02-07 09:55:40 --> Total execution time: 0.0383
INFO - 2023-02-07 09:58:57 --> Config Class Initialized
INFO - 2023-02-07 09:58:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:58:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:58:57 --> Utf8 Class Initialized
INFO - 2023-02-07 09:58:57 --> URI Class Initialized
INFO - 2023-02-07 09:58:57 --> Router Class Initialized
INFO - 2023-02-07 09:58:57 --> Output Class Initialized
INFO - 2023-02-07 09:58:57 --> Security Class Initialized
DEBUG - 2023-02-07 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:58:57 --> Input Class Initialized
INFO - 2023-02-07 09:58:57 --> Language Class Initialized
INFO - 2023-02-07 09:58:57 --> Language Class Initialized
INFO - 2023-02-07 09:58:57 --> Config Class Initialized
INFO - 2023-02-07 09:58:57 --> Loader Class Initialized
INFO - 2023-02-07 09:58:57 --> Helper loaded: url_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: file_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: form_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: my_helper
INFO - 2023-02-07 09:58:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:58:57 --> Controller Class Initialized
DEBUG - 2023-02-07 09:58:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 09:58:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 09:58:57 --> Final output sent to browser
DEBUG - 2023-02-07 09:58:57 --> Total execution time: 0.0524
INFO - 2023-02-07 09:58:57 --> Config Class Initialized
INFO - 2023-02-07 09:58:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 09:58:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:58:57 --> Utf8 Class Initialized
INFO - 2023-02-07 09:58:57 --> Config Class Initialized
INFO - 2023-02-07 09:58:57 --> Hooks Class Initialized
INFO - 2023-02-07 09:58:57 --> URI Class Initialized
DEBUG - 2023-02-07 09:58:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 09:58:57 --> Utf8 Class Initialized
INFO - 2023-02-07 09:58:57 --> URI Class Initialized
INFO - 2023-02-07 09:58:57 --> Router Class Initialized
INFO - 2023-02-07 09:58:57 --> Output Class Initialized
INFO - 2023-02-07 09:58:57 --> Router Class Initialized
INFO - 2023-02-07 09:58:57 --> Security Class Initialized
INFO - 2023-02-07 09:58:57 --> Output Class Initialized
DEBUG - 2023-02-07 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:58:57 --> Input Class Initialized
INFO - 2023-02-07 09:58:57 --> Security Class Initialized
INFO - 2023-02-07 09:58:57 --> Language Class Initialized
DEBUG - 2023-02-07 09:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 09:58:57 --> Input Class Initialized
ERROR - 2023-02-07 09:58:57 --> 404 Page Not Found: /index
INFO - 2023-02-07 09:58:57 --> Language Class Initialized
INFO - 2023-02-07 09:58:57 --> Language Class Initialized
INFO - 2023-02-07 09:58:57 --> Config Class Initialized
INFO - 2023-02-07 09:58:57 --> Loader Class Initialized
INFO - 2023-02-07 09:58:57 --> Helper loaded: url_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: file_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: form_helper
INFO - 2023-02-07 09:58:57 --> Helper loaded: my_helper
INFO - 2023-02-07 09:58:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 09:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 09:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 09:58:57 --> Controller Class Initialized
INFO - 2023-02-07 10:01:51 --> Config Class Initialized
INFO - 2023-02-07 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:01:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:01:51 --> URI Class Initialized
INFO - 2023-02-07 10:01:51 --> Router Class Initialized
INFO - 2023-02-07 10:01:51 --> Output Class Initialized
INFO - 2023-02-07 10:01:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:01:51 --> Input Class Initialized
INFO - 2023-02-07 10:01:51 --> Language Class Initialized
INFO - 2023-02-07 10:01:51 --> Language Class Initialized
INFO - 2023-02-07 10:01:51 --> Config Class Initialized
INFO - 2023-02-07 10:01:51 --> Loader Class Initialized
INFO - 2023-02-07 10:01:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:01:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:01:51 --> Controller Class Initialized
DEBUG - 2023-02-07 10:01:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 10:01:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:01:51 --> Final output sent to browser
DEBUG - 2023-02-07 10:01:51 --> Total execution time: 0.0522
INFO - 2023-02-07 10:01:51 --> Config Class Initialized
INFO - 2023-02-07 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:01:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:01:51 --> URI Class Initialized
INFO - 2023-02-07 10:01:51 --> Router Class Initialized
INFO - 2023-02-07 10:01:51 --> Output Class Initialized
INFO - 2023-02-07 10:01:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:01:51 --> Input Class Initialized
INFO - 2023-02-07 10:01:51 --> Language Class Initialized
ERROR - 2023-02-07 10:01:51 --> 404 Page Not Found: /index
INFO - 2023-02-07 10:01:51 --> Config Class Initialized
INFO - 2023-02-07 10:01:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:01:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:01:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:01:51 --> URI Class Initialized
INFO - 2023-02-07 10:01:51 --> Router Class Initialized
INFO - 2023-02-07 10:01:51 --> Output Class Initialized
INFO - 2023-02-07 10:01:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:01:51 --> Input Class Initialized
INFO - 2023-02-07 10:01:51 --> Language Class Initialized
INFO - 2023-02-07 10:01:51 --> Language Class Initialized
INFO - 2023-02-07 10:01:51 --> Config Class Initialized
INFO - 2023-02-07 10:01:51 --> Loader Class Initialized
INFO - 2023-02-07 10:01:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:01:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:01:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:01:51 --> Controller Class Initialized
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:03 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:03 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:03 --> URI Class Initialized
INFO - 2023-02-07 10:02:03 --> Router Class Initialized
INFO - 2023-02-07 10:02:03 --> Output Class Initialized
INFO - 2023-02-07 10:02:03 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:03 --> Input Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Loader Class Initialized
INFO - 2023-02-07 10:02:03 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:03 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:03 --> Controller Class Initialized
INFO - 2023-02-07 10:02:03 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:03 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:03 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:03 --> URI Class Initialized
INFO - 2023-02-07 10:02:03 --> Router Class Initialized
INFO - 2023-02-07 10:02:03 --> Output Class Initialized
INFO - 2023-02-07 10:02:03 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:03 --> Input Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Loader Class Initialized
INFO - 2023-02-07 10:02:03 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:03 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:03 --> Controller Class Initialized
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:03 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:03 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:03 --> URI Class Initialized
INFO - 2023-02-07 10:02:03 --> Router Class Initialized
INFO - 2023-02-07 10:02:03 --> Output Class Initialized
INFO - 2023-02-07 10:02:03 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:03 --> Input Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Language Class Initialized
INFO - 2023-02-07 10:02:03 --> Config Class Initialized
INFO - 2023-02-07 10:02:03 --> Loader Class Initialized
INFO - 2023-02-07 10:02:03 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:03 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:03 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:03 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:02:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:03 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:03 --> Total execution time: 0.0363
INFO - 2023-02-07 10:02:09 --> Config Class Initialized
INFO - 2023-02-07 10:02:09 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:09 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:09 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:09 --> URI Class Initialized
INFO - 2023-02-07 10:02:09 --> Router Class Initialized
INFO - 2023-02-07 10:02:09 --> Output Class Initialized
INFO - 2023-02-07 10:02:09 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:09 --> Input Class Initialized
INFO - 2023-02-07 10:02:09 --> Language Class Initialized
INFO - 2023-02-07 10:02:09 --> Language Class Initialized
INFO - 2023-02-07 10:02:09 --> Config Class Initialized
INFO - 2023-02-07 10:02:09 --> Loader Class Initialized
INFO - 2023-02-07 10:02:09 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:09 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:09 --> Controller Class Initialized
INFO - 2023-02-07 10:02:09 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:02:09 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:09 --> Total execution time: 0.0353
INFO - 2023-02-07 10:02:09 --> Config Class Initialized
INFO - 2023-02-07 10:02:09 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:09 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:09 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:09 --> URI Class Initialized
INFO - 2023-02-07 10:02:09 --> Router Class Initialized
INFO - 2023-02-07 10:02:09 --> Output Class Initialized
INFO - 2023-02-07 10:02:09 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:09 --> Input Class Initialized
INFO - 2023-02-07 10:02:09 --> Language Class Initialized
INFO - 2023-02-07 10:02:09 --> Language Class Initialized
INFO - 2023-02-07 10:02:09 --> Config Class Initialized
INFO - 2023-02-07 10:02:09 --> Loader Class Initialized
INFO - 2023-02-07 10:02:09 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:09 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:09 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:09 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home.php
DEBUG - 2023-02-07 10:02:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:09 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:09 --> Total execution time: 0.0454
INFO - 2023-02-07 10:02:14 --> Config Class Initialized
INFO - 2023-02-07 10:02:14 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:14 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:14 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:14 --> URI Class Initialized
INFO - 2023-02-07 10:02:14 --> Router Class Initialized
INFO - 2023-02-07 10:02:14 --> Output Class Initialized
INFO - 2023-02-07 10:02:14 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:14 --> Input Class Initialized
INFO - 2023-02-07 10:02:14 --> Language Class Initialized
INFO - 2023-02-07 10:02:14 --> Language Class Initialized
INFO - 2023-02-07 10:02:14 --> Config Class Initialized
INFO - 2023-02-07 10:02:14 --> Loader Class Initialized
INFO - 2023-02-07 10:02:14 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:14 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:14 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:14 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:14 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:14 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-02-07 10:02:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:14 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:14 --> Total execution time: 0.0769
INFO - 2023-02-07 10:02:15 --> Config Class Initialized
INFO - 2023-02-07 10:02:15 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:15 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:15 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:15 --> URI Class Initialized
INFO - 2023-02-07 10:02:15 --> Router Class Initialized
INFO - 2023-02-07 10:02:15 --> Output Class Initialized
INFO - 2023-02-07 10:02:15 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:15 --> Input Class Initialized
INFO - 2023-02-07 10:02:15 --> Language Class Initialized
INFO - 2023-02-07 10:02:15 --> Language Class Initialized
INFO - 2023-02-07 10:02:15 --> Config Class Initialized
INFO - 2023-02-07 10:02:15 --> Loader Class Initialized
INFO - 2023-02-07 10:02:15 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:15 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:15 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:15 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:15 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:15 --> Controller Class Initialized
INFO - 2023-02-07 10:02:42 --> Config Class Initialized
INFO - 2023-02-07 10:02:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:42 --> URI Class Initialized
INFO - 2023-02-07 10:02:42 --> Router Class Initialized
INFO - 2023-02-07 10:02:42 --> Output Class Initialized
INFO - 2023-02-07 10:02:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:42 --> Input Class Initialized
INFO - 2023-02-07 10:02:42 --> Language Class Initialized
INFO - 2023-02-07 10:02:42 --> Language Class Initialized
INFO - 2023-02-07 10:02:42 --> Config Class Initialized
INFO - 2023-02-07 10:02:42 --> Loader Class Initialized
INFO - 2023-02-07 10:02:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:42 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/data_mapel/views/list.php
DEBUG - 2023-02-07 10:02:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:42 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:42 --> Total execution time: 0.0595
INFO - 2023-02-07 10:02:42 --> Config Class Initialized
INFO - 2023-02-07 10:02:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:42 --> URI Class Initialized
INFO - 2023-02-07 10:02:42 --> Router Class Initialized
INFO - 2023-02-07 10:02:42 --> Output Class Initialized
INFO - 2023-02-07 10:02:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:42 --> Input Class Initialized
INFO - 2023-02-07 10:02:42 --> Language Class Initialized
INFO - 2023-02-07 10:02:42 --> Language Class Initialized
INFO - 2023-02-07 10:02:42 --> Config Class Initialized
INFO - 2023-02-07 10:02:42 --> Loader Class Initialized
INFO - 2023-02-07 10:02:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:42 --> Controller Class Initialized
INFO - 2023-02-07 10:02:50 --> Config Class Initialized
INFO - 2023-02-07 10:02:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:50 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:50 --> URI Class Initialized
INFO - 2023-02-07 10:02:50 --> Router Class Initialized
INFO - 2023-02-07 10:02:50 --> Output Class Initialized
INFO - 2023-02-07 10:02:50 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:50 --> Input Class Initialized
INFO - 2023-02-07 10:02:50 --> Language Class Initialized
INFO - 2023-02-07 10:02:50 --> Language Class Initialized
INFO - 2023-02-07 10:02:50 --> Config Class Initialized
INFO - 2023-02-07 10:02:50 --> Loader Class Initialized
INFO - 2023-02-07 10:02:50 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:50 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/set_mapel/views/list.php
DEBUG - 2023-02-07 10:02:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:50 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:50 --> Total execution time: 0.0351
INFO - 2023-02-07 10:02:50 --> Config Class Initialized
INFO - 2023-02-07 10:02:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:50 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:50 --> URI Class Initialized
INFO - 2023-02-07 10:02:50 --> Router Class Initialized
INFO - 2023-02-07 10:02:50 --> Output Class Initialized
INFO - 2023-02-07 10:02:50 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:50 --> Input Class Initialized
INFO - 2023-02-07 10:02:50 --> Language Class Initialized
INFO - 2023-02-07 10:02:50 --> Language Class Initialized
INFO - 2023-02-07 10:02:50 --> Config Class Initialized
INFO - 2023-02-07 10:02:50 --> Loader Class Initialized
INFO - 2023-02-07 10:02:50 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:50 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:50 --> Controller Class Initialized
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:57 --> URI Class Initialized
INFO - 2023-02-07 10:02:57 --> Router Class Initialized
INFO - 2023-02-07 10:02:57 --> Output Class Initialized
INFO - 2023-02-07 10:02:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:57 --> Input Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Loader Class Initialized
INFO - 2023-02-07 10:02:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:57 --> Controller Class Initialized
INFO - 2023-02-07 10:02:57 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:57 --> URI Class Initialized
INFO - 2023-02-07 10:02:57 --> Router Class Initialized
INFO - 2023-02-07 10:02:57 --> Output Class Initialized
INFO - 2023-02-07 10:02:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:57 --> Input Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Loader Class Initialized
INFO - 2023-02-07 10:02:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:57 --> Controller Class Initialized
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:02:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:02:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:02:57 --> URI Class Initialized
INFO - 2023-02-07 10:02:57 --> Router Class Initialized
INFO - 2023-02-07 10:02:57 --> Output Class Initialized
INFO - 2023-02-07 10:02:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:02:57 --> Input Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Language Class Initialized
INFO - 2023-02-07 10:02:57 --> Config Class Initialized
INFO - 2023-02-07 10:02:57 --> Loader Class Initialized
INFO - 2023-02-07 10:02:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:02:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:02:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:02:57 --> Controller Class Initialized
DEBUG - 2023-02-07 10:02:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:02:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:02:57 --> Final output sent to browser
DEBUG - 2023-02-07 10:02:57 --> Total execution time: 0.0434
INFO - 2023-02-07 10:03:01 --> Config Class Initialized
INFO - 2023-02-07 10:03:01 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:01 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:01 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:01 --> URI Class Initialized
INFO - 2023-02-07 10:03:01 --> Router Class Initialized
INFO - 2023-02-07 10:03:01 --> Output Class Initialized
INFO - 2023-02-07 10:03:01 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:01 --> Input Class Initialized
INFO - 2023-02-07 10:03:01 --> Language Class Initialized
INFO - 2023-02-07 10:03:01 --> Language Class Initialized
INFO - 2023-02-07 10:03:01 --> Config Class Initialized
INFO - 2023-02-07 10:03:01 --> Loader Class Initialized
INFO - 2023-02-07 10:03:01 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:01 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:01 --> Controller Class Initialized
INFO - 2023-02-07 10:03:01 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:03:01 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:01 --> Total execution time: 0.0389
INFO - 2023-02-07 10:03:01 --> Config Class Initialized
INFO - 2023-02-07 10:03:01 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:01 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:01 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:01 --> URI Class Initialized
INFO - 2023-02-07 10:03:01 --> Router Class Initialized
INFO - 2023-02-07 10:03:01 --> Output Class Initialized
INFO - 2023-02-07 10:03:01 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:01 --> Input Class Initialized
INFO - 2023-02-07 10:03:01 --> Language Class Initialized
INFO - 2023-02-07 10:03:01 --> Language Class Initialized
INFO - 2023-02-07 10:03:01 --> Config Class Initialized
INFO - 2023-02-07 10:03:01 --> Loader Class Initialized
INFO - 2023-02-07 10:03:01 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:01 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:01 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:01 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 10:03:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:01 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:01 --> Total execution time: 0.0469
INFO - 2023-02-07 10:03:02 --> Config Class Initialized
INFO - 2023-02-07 10:03:02 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:02 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:02 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:02 --> URI Class Initialized
INFO - 2023-02-07 10:03:02 --> Router Class Initialized
INFO - 2023-02-07 10:03:02 --> Output Class Initialized
INFO - 2023-02-07 10:03:02 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:02 --> Input Class Initialized
INFO - 2023-02-07 10:03:02 --> Language Class Initialized
INFO - 2023-02-07 10:03:02 --> Language Class Initialized
INFO - 2023-02-07 10:03:02 --> Config Class Initialized
INFO - 2023-02-07 10:03:02 --> Loader Class Initialized
INFO - 2023-02-07 10:03:02 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:02 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:02 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:02 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:02 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:02 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:03:02 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:02 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:02 --> Total execution time: 0.0278
INFO - 2023-02-07 10:03:08 --> Config Class Initialized
INFO - 2023-02-07 10:03:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:08 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:08 --> URI Class Initialized
INFO - 2023-02-07 10:03:08 --> Router Class Initialized
INFO - 2023-02-07 10:03:08 --> Output Class Initialized
INFO - 2023-02-07 10:03:08 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:08 --> Input Class Initialized
INFO - 2023-02-07 10:03:08 --> Language Class Initialized
INFO - 2023-02-07 10:03:08 --> Language Class Initialized
INFO - 2023-02-07 10:03:08 --> Config Class Initialized
INFO - 2023-02-07 10:03:08 --> Loader Class Initialized
INFO - 2023-02-07 10:03:08 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:08 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:08 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:03:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:08 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:08 --> Total execution time: 0.0732
INFO - 2023-02-07 10:03:08 --> Config Class Initialized
INFO - 2023-02-07 10:03:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:08 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:08 --> URI Class Initialized
INFO - 2023-02-07 10:03:08 --> Router Class Initialized
INFO - 2023-02-07 10:03:08 --> Output Class Initialized
INFO - 2023-02-07 10:03:08 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:08 --> Input Class Initialized
INFO - 2023-02-07 10:03:08 --> Language Class Initialized
INFO - 2023-02-07 10:03:08 --> Language Class Initialized
INFO - 2023-02-07 10:03:08 --> Config Class Initialized
INFO - 2023-02-07 10:03:08 --> Loader Class Initialized
INFO - 2023-02-07 10:03:08 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:08 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:08 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:08 --> Controller Class Initialized
INFO - 2023-02-07 10:03:12 --> Config Class Initialized
INFO - 2023-02-07 10:03:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:12 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:12 --> URI Class Initialized
INFO - 2023-02-07 10:03:12 --> Router Class Initialized
INFO - 2023-02-07 10:03:12 --> Output Class Initialized
INFO - 2023-02-07 10:03:12 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:12 --> Input Class Initialized
INFO - 2023-02-07 10:03:12 --> Language Class Initialized
INFO - 2023-02-07 10:03:12 --> Language Class Initialized
INFO - 2023-02-07 10:03:12 --> Config Class Initialized
INFO - 2023-02-07 10:03:12 --> Loader Class Initialized
INFO - 2023-02-07 10:03:12 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:12 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:12 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:12 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:12 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:03:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:12 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:12 --> Total execution time: 0.0506
INFO - 2023-02-07 10:03:14 --> Config Class Initialized
INFO - 2023-02-07 10:03:14 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:14 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:14 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:14 --> URI Class Initialized
INFO - 2023-02-07 10:03:14 --> Router Class Initialized
INFO - 2023-02-07 10:03:14 --> Output Class Initialized
INFO - 2023-02-07 10:03:14 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:14 --> Input Class Initialized
INFO - 2023-02-07 10:03:14 --> Language Class Initialized
INFO - 2023-02-07 10:03:14 --> Language Class Initialized
INFO - 2023-02-07 10:03:14 --> Config Class Initialized
INFO - 2023-02-07 10:03:14 --> Loader Class Initialized
INFO - 2023-02-07 10:03:14 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:14 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:14 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:14 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:14 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:14 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-02-07 10:03:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:14 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:14 --> Total execution time: 0.0868
INFO - 2023-02-07 10:03:15 --> Config Class Initialized
INFO - 2023-02-07 10:03:15 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:15 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:15 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:15 --> URI Class Initialized
INFO - 2023-02-07 10:03:15 --> Router Class Initialized
INFO - 2023-02-07 10:03:15 --> Output Class Initialized
INFO - 2023-02-07 10:03:15 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:15 --> Input Class Initialized
INFO - 2023-02-07 10:03:15 --> Language Class Initialized
INFO - 2023-02-07 10:03:15 --> Language Class Initialized
INFO - 2023-02-07 10:03:15 --> Config Class Initialized
INFO - 2023-02-07 10:03:15 --> Loader Class Initialized
INFO - 2023-02-07 10:03:15 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:15 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:15 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:15 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:15 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:15 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:03:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:15 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:15 --> Total execution time: 0.0385
INFO - 2023-02-07 10:03:16 --> Config Class Initialized
INFO - 2023-02-07 10:03:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:16 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:16 --> URI Class Initialized
INFO - 2023-02-07 10:03:16 --> Router Class Initialized
INFO - 2023-02-07 10:03:16 --> Output Class Initialized
INFO - 2023-02-07 10:03:16 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:16 --> Input Class Initialized
INFO - 2023-02-07 10:03:16 --> Language Class Initialized
INFO - 2023-02-07 10:03:16 --> Language Class Initialized
INFO - 2023-02-07 10:03:16 --> Config Class Initialized
INFO - 2023-02-07 10:03:16 --> Loader Class Initialized
INFO - 2023-02-07 10:03:16 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:16 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:16 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:16 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:16 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:16 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-02-07 10:03:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:16 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:16 --> Total execution time: 0.0826
INFO - 2023-02-07 10:03:17 --> Config Class Initialized
INFO - 2023-02-07 10:03:17 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:17 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:17 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:17 --> URI Class Initialized
INFO - 2023-02-07 10:03:17 --> Router Class Initialized
INFO - 2023-02-07 10:03:17 --> Output Class Initialized
INFO - 2023-02-07 10:03:17 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:17 --> Input Class Initialized
INFO - 2023-02-07 10:03:17 --> Language Class Initialized
INFO - 2023-02-07 10:03:17 --> Language Class Initialized
INFO - 2023-02-07 10:03:17 --> Config Class Initialized
INFO - 2023-02-07 10:03:17 --> Loader Class Initialized
INFO - 2023-02-07 10:03:17 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:17 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:17 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:17 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:17 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:17 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:03:17 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:17 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:17 --> Total execution time: 0.0249
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:21 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:21 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:21 --> URI Class Initialized
INFO - 2023-02-07 10:03:21 --> Router Class Initialized
INFO - 2023-02-07 10:03:21 --> Output Class Initialized
INFO - 2023-02-07 10:03:21 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:21 --> Input Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Loader Class Initialized
INFO - 2023-02-07 10:03:21 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:21 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:21 --> Controller Class Initialized
INFO - 2023-02-07 10:03:21 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:21 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:21 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:21 --> URI Class Initialized
INFO - 2023-02-07 10:03:21 --> Router Class Initialized
INFO - 2023-02-07 10:03:21 --> Output Class Initialized
INFO - 2023-02-07 10:03:21 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:21 --> Input Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Loader Class Initialized
INFO - 2023-02-07 10:03:21 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:21 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:21 --> Controller Class Initialized
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:21 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:21 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:21 --> URI Class Initialized
INFO - 2023-02-07 10:03:21 --> Router Class Initialized
INFO - 2023-02-07 10:03:21 --> Output Class Initialized
INFO - 2023-02-07 10:03:21 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:21 --> Input Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Language Class Initialized
INFO - 2023-02-07 10:03:21 --> Config Class Initialized
INFO - 2023-02-07 10:03:21 --> Loader Class Initialized
INFO - 2023-02-07 10:03:21 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:21 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:21 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:21 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:03:21 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:21 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:21 --> Total execution time: 0.0222
INFO - 2023-02-07 10:03:51 --> Config Class Initialized
INFO - 2023-02-07 10:03:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:51 --> URI Class Initialized
INFO - 2023-02-07 10:03:51 --> Router Class Initialized
INFO - 2023-02-07 10:03:51 --> Output Class Initialized
INFO - 2023-02-07 10:03:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:51 --> Input Class Initialized
INFO - 2023-02-07 10:03:51 --> Language Class Initialized
INFO - 2023-02-07 10:03:51 --> Language Class Initialized
INFO - 2023-02-07 10:03:51 --> Config Class Initialized
INFO - 2023-02-07 10:03:51 --> Loader Class Initialized
INFO - 2023-02-07 10:03:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:51 --> Controller Class Initialized
INFO - 2023-02-07 10:03:51 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:03:51 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:51 --> Total execution time: 0.0346
INFO - 2023-02-07 10:03:51 --> Config Class Initialized
INFO - 2023-02-07 10:03:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:51 --> URI Class Initialized
INFO - 2023-02-07 10:03:51 --> Router Class Initialized
INFO - 2023-02-07 10:03:51 --> Output Class Initialized
INFO - 2023-02-07 10:03:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:51 --> Input Class Initialized
INFO - 2023-02-07 10:03:51 --> Language Class Initialized
INFO - 2023-02-07 10:03:51 --> Language Class Initialized
INFO - 2023-02-07 10:03:51 --> Config Class Initialized
INFO - 2023-02-07 10:03:51 --> Loader Class Initialized
INFO - 2023-02-07 10:03:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:51 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 10:03:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:51 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:51 --> Total execution time: 0.0424
INFO - 2023-02-07 10:03:53 --> Config Class Initialized
INFO - 2023-02-07 10:03:53 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:03:53 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:03:53 --> Utf8 Class Initialized
INFO - 2023-02-07 10:03:53 --> URI Class Initialized
INFO - 2023-02-07 10:03:53 --> Router Class Initialized
INFO - 2023-02-07 10:03:53 --> Output Class Initialized
INFO - 2023-02-07 10:03:53 --> Security Class Initialized
DEBUG - 2023-02-07 10:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:03:53 --> Input Class Initialized
INFO - 2023-02-07 10:03:53 --> Language Class Initialized
INFO - 2023-02-07 10:03:53 --> Language Class Initialized
INFO - 2023-02-07 10:03:53 --> Config Class Initialized
INFO - 2023-02-07 10:03:53 --> Loader Class Initialized
INFO - 2023-02-07 10:03:53 --> Helper loaded: url_helper
INFO - 2023-02-07 10:03:53 --> Helper loaded: file_helper
INFO - 2023-02-07 10:03:53 --> Helper loaded: form_helper
INFO - 2023-02-07 10:03:53 --> Helper loaded: my_helper
INFO - 2023-02-07 10:03:53 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:03:53 --> Controller Class Initialized
DEBUG - 2023-02-07 10:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:03:53 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:03:53 --> Final output sent to browser
DEBUG - 2023-02-07 10:03:53 --> Total execution time: 0.0269
INFO - 2023-02-07 10:05:03 --> Config Class Initialized
INFO - 2023-02-07 10:05:03 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:03 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:03 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:03 --> URI Class Initialized
INFO - 2023-02-07 10:05:03 --> Router Class Initialized
INFO - 2023-02-07 10:05:03 --> Output Class Initialized
INFO - 2023-02-07 10:05:03 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:03 --> Input Class Initialized
INFO - 2023-02-07 10:05:03 --> Language Class Initialized
INFO - 2023-02-07 10:05:03 --> Language Class Initialized
INFO - 2023-02-07 10:05:03 --> Config Class Initialized
INFO - 2023-02-07 10:05:03 --> Loader Class Initialized
INFO - 2023-02-07 10:05:03 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:03 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:03 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:05:03 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:03 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:03 --> Total execution time: 0.0262
INFO - 2023-02-07 10:05:03 --> Config Class Initialized
INFO - 2023-02-07 10:05:03 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:03 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:03 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:03 --> URI Class Initialized
INFO - 2023-02-07 10:05:03 --> Router Class Initialized
INFO - 2023-02-07 10:05:03 --> Output Class Initialized
INFO - 2023-02-07 10:05:03 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:03 --> Input Class Initialized
INFO - 2023-02-07 10:05:03 --> Language Class Initialized
INFO - 2023-02-07 10:05:03 --> Language Class Initialized
INFO - 2023-02-07 10:05:03 --> Config Class Initialized
INFO - 2023-02-07 10:05:03 --> Loader Class Initialized
INFO - 2023-02-07 10:05:03 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:03 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:03 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:03 --> Controller Class Initialized
INFO - 2023-02-07 10:05:07 --> Config Class Initialized
INFO - 2023-02-07 10:05:07 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:07 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:07 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:07 --> URI Class Initialized
INFO - 2023-02-07 10:05:07 --> Router Class Initialized
INFO - 2023-02-07 10:05:07 --> Output Class Initialized
INFO - 2023-02-07 10:05:07 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:07 --> Input Class Initialized
INFO - 2023-02-07 10:05:07 --> Language Class Initialized
INFO - 2023-02-07 10:05:07 --> Language Class Initialized
INFO - 2023-02-07 10:05:07 --> Config Class Initialized
INFO - 2023-02-07 10:05:07 --> Loader Class Initialized
INFO - 2023-02-07 10:05:07 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:07 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:07 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:07 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:07 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:07 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:07 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:07 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:07 --> Total execution time: 0.0282
INFO - 2023-02-07 10:05:08 --> Config Class Initialized
INFO - 2023-02-07 10:05:08 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:08 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:08 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:08 --> URI Class Initialized
INFO - 2023-02-07 10:05:08 --> Router Class Initialized
INFO - 2023-02-07 10:05:08 --> Output Class Initialized
INFO - 2023-02-07 10:05:08 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:08 --> Input Class Initialized
INFO - 2023-02-07 10:05:08 --> Language Class Initialized
INFO - 2023-02-07 10:05:08 --> Language Class Initialized
INFO - 2023-02-07 10:05:08 --> Config Class Initialized
INFO - 2023-02-07 10:05:08 --> Loader Class Initialized
INFO - 2023-02-07 10:05:08 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:08 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:08 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:08 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:08 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:08 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-02-07 10:05:08 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:08 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:08 --> Total execution time: 0.0369
INFO - 2023-02-07 10:05:09 --> Config Class Initialized
INFO - 2023-02-07 10:05:09 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:09 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:09 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:09 --> URI Class Initialized
INFO - 2023-02-07 10:05:09 --> Router Class Initialized
INFO - 2023-02-07 10:05:09 --> Output Class Initialized
INFO - 2023-02-07 10:05:09 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:09 --> Input Class Initialized
INFO - 2023-02-07 10:05:09 --> Language Class Initialized
INFO - 2023-02-07 10:05:09 --> Language Class Initialized
INFO - 2023-02-07 10:05:09 --> Config Class Initialized
INFO - 2023-02-07 10:05:09 --> Loader Class Initialized
INFO - 2023-02-07 10:05:09 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:09 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:09 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:09 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:09 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:09 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:09 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:09 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:09 --> Total execution time: 0.0253
INFO - 2023-02-07 10:05:10 --> Config Class Initialized
INFO - 2023-02-07 10:05:10 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:10 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:10 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:10 --> URI Class Initialized
INFO - 2023-02-07 10:05:10 --> Router Class Initialized
INFO - 2023-02-07 10:05:10 --> Output Class Initialized
INFO - 2023-02-07 10:05:10 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:10 --> Input Class Initialized
INFO - 2023-02-07 10:05:10 --> Language Class Initialized
INFO - 2023-02-07 10:05:10 --> Language Class Initialized
INFO - 2023-02-07 10:05:10 --> Config Class Initialized
INFO - 2023-02-07 10:05:10 --> Loader Class Initialized
INFO - 2023-02-07 10:05:10 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:10 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:10 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:10 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:10 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:10 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-02-07 10:05:10 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:10 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:10 --> Total execution time: 0.0423
INFO - 2023-02-07 10:05:11 --> Config Class Initialized
INFO - 2023-02-07 10:05:11 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:11 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:11 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:11 --> URI Class Initialized
INFO - 2023-02-07 10:05:11 --> Router Class Initialized
INFO - 2023-02-07 10:05:11 --> Output Class Initialized
INFO - 2023-02-07 10:05:11 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:11 --> Input Class Initialized
INFO - 2023-02-07 10:05:11 --> Language Class Initialized
INFO - 2023-02-07 10:05:11 --> Language Class Initialized
INFO - 2023-02-07 10:05:11 --> Config Class Initialized
INFO - 2023-02-07 10:05:11 --> Loader Class Initialized
INFO - 2023-02-07 10:05:11 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:11 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:11 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:11 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:11 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:11 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:11 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:11 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:11 --> Total execution time: 0.0436
INFO - 2023-02-07 10:05:12 --> Config Class Initialized
INFO - 2023-02-07 10:05:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:12 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:12 --> URI Class Initialized
INFO - 2023-02-07 10:05:12 --> Router Class Initialized
INFO - 2023-02-07 10:05:12 --> Output Class Initialized
INFO - 2023-02-07 10:05:12 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:12 --> Input Class Initialized
INFO - 2023-02-07 10:05:12 --> Language Class Initialized
INFO - 2023-02-07 10:05:12 --> Language Class Initialized
INFO - 2023-02-07 10:05:12 --> Config Class Initialized
INFO - 2023-02-07 10:05:12 --> Loader Class Initialized
INFO - 2023-02-07 10:05:12 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:12 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:05:12 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:12 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:12 --> Total execution time: 0.0390
INFO - 2023-02-07 10:05:12 --> Config Class Initialized
INFO - 2023-02-07 10:05:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:12 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:12 --> URI Class Initialized
INFO - 2023-02-07 10:05:12 --> Router Class Initialized
INFO - 2023-02-07 10:05:12 --> Output Class Initialized
INFO - 2023-02-07 10:05:12 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:12 --> Input Class Initialized
INFO - 2023-02-07 10:05:12 --> Language Class Initialized
INFO - 2023-02-07 10:05:12 --> Language Class Initialized
INFO - 2023-02-07 10:05:12 --> Config Class Initialized
INFO - 2023-02-07 10:05:12 --> Loader Class Initialized
INFO - 2023-02-07 10:05:12 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:12 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:12 --> Controller Class Initialized
INFO - 2023-02-07 10:05:15 --> Config Class Initialized
INFO - 2023-02-07 10:05:15 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:15 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:15 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:15 --> URI Class Initialized
INFO - 2023-02-07 10:05:15 --> Router Class Initialized
INFO - 2023-02-07 10:05:15 --> Output Class Initialized
INFO - 2023-02-07 10:05:15 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:15 --> Input Class Initialized
INFO - 2023-02-07 10:05:15 --> Language Class Initialized
INFO - 2023-02-07 10:05:15 --> Language Class Initialized
INFO - 2023-02-07 10:05:15 --> Config Class Initialized
INFO - 2023-02-07 10:05:15 --> Loader Class Initialized
INFO - 2023-02-07 10:05:15 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:15 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:15 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:15 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:15 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:15 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:15 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:15 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:15 --> Total execution time: 0.0424
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:19 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:19 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:19 --> URI Class Initialized
INFO - 2023-02-07 10:05:19 --> Router Class Initialized
INFO - 2023-02-07 10:05:19 --> Output Class Initialized
INFO - 2023-02-07 10:05:19 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:19 --> Input Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Loader Class Initialized
INFO - 2023-02-07 10:05:19 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:19 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:19 --> Controller Class Initialized
INFO - 2023-02-07 10:05:19 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:19 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:19 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:19 --> URI Class Initialized
INFO - 2023-02-07 10:05:19 --> Router Class Initialized
INFO - 2023-02-07 10:05:19 --> Output Class Initialized
INFO - 2023-02-07 10:05:19 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:19 --> Input Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Loader Class Initialized
INFO - 2023-02-07 10:05:19 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:19 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:19 --> Controller Class Initialized
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:19 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:19 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:19 --> URI Class Initialized
INFO - 2023-02-07 10:05:19 --> Router Class Initialized
INFO - 2023-02-07 10:05:19 --> Output Class Initialized
INFO - 2023-02-07 10:05:19 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:19 --> Input Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Language Class Initialized
INFO - 2023-02-07 10:05:19 --> Config Class Initialized
INFO - 2023-02-07 10:05:19 --> Loader Class Initialized
INFO - 2023-02-07 10:05:19 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:19 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:19 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:19 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:05:19 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:19 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:19 --> Total execution time: 0.0436
INFO - 2023-02-07 10:05:24 --> Config Class Initialized
INFO - 2023-02-07 10:05:24 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:24 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:24 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:24 --> URI Class Initialized
INFO - 2023-02-07 10:05:24 --> Router Class Initialized
INFO - 2023-02-07 10:05:24 --> Output Class Initialized
INFO - 2023-02-07 10:05:24 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:24 --> Input Class Initialized
INFO - 2023-02-07 10:05:24 --> Language Class Initialized
INFO - 2023-02-07 10:05:24 --> Language Class Initialized
INFO - 2023-02-07 10:05:24 --> Config Class Initialized
INFO - 2023-02-07 10:05:24 --> Loader Class Initialized
INFO - 2023-02-07 10:05:24 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:24 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:24 --> Controller Class Initialized
INFO - 2023-02-07 10:05:24 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:05:24 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:24 --> Total execution time: 0.0447
INFO - 2023-02-07 10:05:24 --> Config Class Initialized
INFO - 2023-02-07 10:05:24 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:24 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:24 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:24 --> URI Class Initialized
INFO - 2023-02-07 10:05:24 --> Router Class Initialized
INFO - 2023-02-07 10:05:24 --> Output Class Initialized
INFO - 2023-02-07 10:05:24 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:24 --> Input Class Initialized
INFO - 2023-02-07 10:05:24 --> Language Class Initialized
INFO - 2023-02-07 10:05:24 --> Language Class Initialized
INFO - 2023-02-07 10:05:24 --> Config Class Initialized
INFO - 2023-02-07 10:05:24 --> Loader Class Initialized
INFO - 2023-02-07 10:05:24 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:24 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:24 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:24 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 10:05:24 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:24 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:24 --> Total execution time: 0.0436
INFO - 2023-02-07 10:05:26 --> Config Class Initialized
INFO - 2023-02-07 10:05:26 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:26 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:26 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:26 --> URI Class Initialized
INFO - 2023-02-07 10:05:26 --> Router Class Initialized
INFO - 2023-02-07 10:05:26 --> Output Class Initialized
INFO - 2023-02-07 10:05:26 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:26 --> Input Class Initialized
INFO - 2023-02-07 10:05:26 --> Language Class Initialized
INFO - 2023-02-07 10:05:26 --> Language Class Initialized
INFO - 2023-02-07 10:05:26 --> Config Class Initialized
INFO - 2023-02-07 10:05:26 --> Loader Class Initialized
INFO - 2023-02-07 10:05:26 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:26 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:26 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:26 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:26 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:26 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:26 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:26 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:26 --> Total execution time: 0.0266
INFO - 2023-02-07 10:05:27 --> Config Class Initialized
INFO - 2023-02-07 10:05:27 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:27 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:27 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:27 --> URI Class Initialized
INFO - 2023-02-07 10:05:27 --> Router Class Initialized
INFO - 2023-02-07 10:05:27 --> Output Class Initialized
INFO - 2023-02-07 10:05:27 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:27 --> Input Class Initialized
INFO - 2023-02-07 10:05:27 --> Language Class Initialized
INFO - 2023-02-07 10:05:27 --> Language Class Initialized
INFO - 2023-02-07 10:05:27 --> Config Class Initialized
INFO - 2023-02-07 10:05:27 --> Loader Class Initialized
INFO - 2023-02-07 10:05:27 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:27 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:27 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 10:05:27 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:27 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:27 --> Total execution time: 0.0257
INFO - 2023-02-07 10:05:27 --> Config Class Initialized
INFO - 2023-02-07 10:05:27 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:27 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:27 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:27 --> URI Class Initialized
INFO - 2023-02-07 10:05:27 --> Router Class Initialized
INFO - 2023-02-07 10:05:27 --> Output Class Initialized
INFO - 2023-02-07 10:05:27 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:27 --> Input Class Initialized
INFO - 2023-02-07 10:05:27 --> Language Class Initialized
INFO - 2023-02-07 10:05:27 --> Language Class Initialized
INFO - 2023-02-07 10:05:27 --> Config Class Initialized
INFO - 2023-02-07 10:05:27 --> Loader Class Initialized
INFO - 2023-02-07 10:05:27 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:27 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:27 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:27 --> Controller Class Initialized
INFO - 2023-02-07 10:05:32 --> Config Class Initialized
INFO - 2023-02-07 10:05:32 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:32 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:32 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:32 --> URI Class Initialized
INFO - 2023-02-07 10:05:32 --> Router Class Initialized
INFO - 2023-02-07 10:05:32 --> Output Class Initialized
INFO - 2023-02-07 10:05:32 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:32 --> Input Class Initialized
INFO - 2023-02-07 10:05:32 --> Language Class Initialized
INFO - 2023-02-07 10:05:32 --> Language Class Initialized
INFO - 2023-02-07 10:05:32 --> Config Class Initialized
INFO - 2023-02-07 10:05:32 --> Loader Class Initialized
INFO - 2023-02-07 10:05:32 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:32 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:32 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:32 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:32 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:32 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:32 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:32 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:32 --> Total execution time: 0.0274
INFO - 2023-02-07 10:05:39 --> Config Class Initialized
INFO - 2023-02-07 10:05:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:39 --> URI Class Initialized
INFO - 2023-02-07 10:05:39 --> Router Class Initialized
INFO - 2023-02-07 10:05:39 --> Output Class Initialized
INFO - 2023-02-07 10:05:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:39 --> Input Class Initialized
INFO - 2023-02-07 10:05:39 --> Language Class Initialized
INFO - 2023-02-07 10:05:39 --> Language Class Initialized
INFO - 2023-02-07 10:05:39 --> Config Class Initialized
INFO - 2023-02-07 10:05:39 --> Loader Class Initialized
INFO - 2023-02-07 10:05:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:39 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 10:05:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:39 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:39 --> Total execution time: 0.0492
INFO - 2023-02-07 10:05:39 --> Config Class Initialized
INFO - 2023-02-07 10:05:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:39 --> URI Class Initialized
INFO - 2023-02-07 10:05:39 --> Router Class Initialized
INFO - 2023-02-07 10:05:39 --> Output Class Initialized
INFO - 2023-02-07 10:05:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:39 --> Input Class Initialized
INFO - 2023-02-07 10:05:39 --> Language Class Initialized
INFO - 2023-02-07 10:05:39 --> Language Class Initialized
INFO - 2023-02-07 10:05:39 --> Config Class Initialized
INFO - 2023-02-07 10:05:39 --> Loader Class Initialized
INFO - 2023-02-07 10:05:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:39 --> Controller Class Initialized
INFO - 2023-02-07 10:05:43 --> Config Class Initialized
INFO - 2023-02-07 10:05:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:43 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:43 --> URI Class Initialized
INFO - 2023-02-07 10:05:43 --> Router Class Initialized
INFO - 2023-02-07 10:05:43 --> Output Class Initialized
INFO - 2023-02-07 10:05:43 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:43 --> Input Class Initialized
INFO - 2023-02-07 10:05:43 --> Language Class Initialized
INFO - 2023-02-07 10:05:43 --> Language Class Initialized
INFO - 2023-02-07 10:05:43 --> Config Class Initialized
INFO - 2023-02-07 10:05:43 --> Loader Class Initialized
INFO - 2023-02-07 10:05:43 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:43 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:43 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:43 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:43 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:43 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:43 --> Total execution time: 0.0496
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:45 --> URI Class Initialized
INFO - 2023-02-07 10:05:45 --> Router Class Initialized
INFO - 2023-02-07 10:05:45 --> Output Class Initialized
INFO - 2023-02-07 10:05:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:45 --> Input Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Loader Class Initialized
INFO - 2023-02-07 10:05:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:45 --> Controller Class Initialized
INFO - 2023-02-07 10:05:45 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:45 --> URI Class Initialized
INFO - 2023-02-07 10:05:45 --> Router Class Initialized
INFO - 2023-02-07 10:05:45 --> Output Class Initialized
INFO - 2023-02-07 10:05:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:45 --> Input Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Loader Class Initialized
INFO - 2023-02-07 10:05:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:45 --> Controller Class Initialized
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:45 --> URI Class Initialized
INFO - 2023-02-07 10:05:45 --> Router Class Initialized
INFO - 2023-02-07 10:05:45 --> Output Class Initialized
INFO - 2023-02-07 10:05:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:45 --> Input Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Language Class Initialized
INFO - 2023-02-07 10:05:45 --> Config Class Initialized
INFO - 2023-02-07 10:05:45 --> Loader Class Initialized
INFO - 2023-02-07 10:05:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:45 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:05:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:46 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:46 --> Total execution time: 0.0223
INFO - 2023-02-07 10:05:54 --> Config Class Initialized
INFO - 2023-02-07 10:05:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:54 --> URI Class Initialized
INFO - 2023-02-07 10:05:54 --> Router Class Initialized
INFO - 2023-02-07 10:05:54 --> Output Class Initialized
INFO - 2023-02-07 10:05:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:54 --> Input Class Initialized
INFO - 2023-02-07 10:05:54 --> Language Class Initialized
INFO - 2023-02-07 10:05:54 --> Language Class Initialized
INFO - 2023-02-07 10:05:54 --> Config Class Initialized
INFO - 2023-02-07 10:05:54 --> Loader Class Initialized
INFO - 2023-02-07 10:05:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:54 --> Controller Class Initialized
INFO - 2023-02-07 10:05:54 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:05:54 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:54 --> Total execution time: 0.0260
INFO - 2023-02-07 10:05:54 --> Config Class Initialized
INFO - 2023-02-07 10:05:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:54 --> URI Class Initialized
INFO - 2023-02-07 10:05:54 --> Router Class Initialized
INFO - 2023-02-07 10:05:54 --> Output Class Initialized
INFO - 2023-02-07 10:05:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:54 --> Input Class Initialized
INFO - 2023-02-07 10:05:54 --> Language Class Initialized
INFO - 2023-02-07 10:05:54 --> Language Class Initialized
INFO - 2023-02-07 10:05:54 --> Config Class Initialized
INFO - 2023-02-07 10:05:54 --> Loader Class Initialized
INFO - 2023-02-07 10:05:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:54 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 10:05:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:54 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:54 --> Total execution time: 0.0499
INFO - 2023-02-07 10:05:55 --> Config Class Initialized
INFO - 2023-02-07 10:05:55 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:55 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:55 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:55 --> URI Class Initialized
INFO - 2023-02-07 10:05:55 --> Router Class Initialized
INFO - 2023-02-07 10:05:55 --> Output Class Initialized
INFO - 2023-02-07 10:05:55 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:55 --> Input Class Initialized
INFO - 2023-02-07 10:05:55 --> Language Class Initialized
INFO - 2023-02-07 10:05:55 --> Language Class Initialized
INFO - 2023-02-07 10:05:55 --> Config Class Initialized
INFO - 2023-02-07 10:05:55 --> Loader Class Initialized
INFO - 2023-02-07 10:05:55 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:55 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:55 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:55 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:55 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:55 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:55 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:55 --> Total execution time: 0.0273
INFO - 2023-02-07 10:05:57 --> Config Class Initialized
INFO - 2023-02-07 10:05:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:57 --> URI Class Initialized
INFO - 2023-02-07 10:05:57 --> Router Class Initialized
INFO - 2023-02-07 10:05:57 --> Output Class Initialized
INFO - 2023-02-07 10:05:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:57 --> Input Class Initialized
INFO - 2023-02-07 10:05:57 --> Language Class Initialized
INFO - 2023-02-07 10:05:57 --> Language Class Initialized
INFO - 2023-02-07 10:05:57 --> Config Class Initialized
INFO - 2023-02-07 10:05:57 --> Loader Class Initialized
INFO - 2023-02-07 10:05:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:57 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:05:57 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:57 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:57 --> Total execution time: 0.0473
INFO - 2023-02-07 10:05:57 --> Config Class Initialized
INFO - 2023-02-07 10:05:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:57 --> URI Class Initialized
INFO - 2023-02-07 10:05:57 --> Router Class Initialized
INFO - 2023-02-07 10:05:57 --> Output Class Initialized
INFO - 2023-02-07 10:05:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:57 --> Input Class Initialized
INFO - 2023-02-07 10:05:57 --> Language Class Initialized
INFO - 2023-02-07 10:05:57 --> Language Class Initialized
INFO - 2023-02-07 10:05:57 --> Config Class Initialized
INFO - 2023-02-07 10:05:57 --> Loader Class Initialized
INFO - 2023-02-07 10:05:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:57 --> Controller Class Initialized
INFO - 2023-02-07 10:05:59 --> Config Class Initialized
INFO - 2023-02-07 10:05:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:05:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:05:59 --> Utf8 Class Initialized
INFO - 2023-02-07 10:05:59 --> URI Class Initialized
INFO - 2023-02-07 10:05:59 --> Router Class Initialized
INFO - 2023-02-07 10:05:59 --> Output Class Initialized
INFO - 2023-02-07 10:05:59 --> Security Class Initialized
DEBUG - 2023-02-07 10:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:05:59 --> Input Class Initialized
INFO - 2023-02-07 10:05:59 --> Language Class Initialized
INFO - 2023-02-07 10:05:59 --> Language Class Initialized
INFO - 2023-02-07 10:05:59 --> Config Class Initialized
INFO - 2023-02-07 10:05:59 --> Loader Class Initialized
INFO - 2023-02-07 10:05:59 --> Helper loaded: url_helper
INFO - 2023-02-07 10:05:59 --> Helper loaded: file_helper
INFO - 2023-02-07 10:05:59 --> Helper loaded: form_helper
INFO - 2023-02-07 10:05:59 --> Helper loaded: my_helper
INFO - 2023-02-07 10:05:59 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:05:59 --> Controller Class Initialized
DEBUG - 2023-02-07 10:05:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:05:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:05:59 --> Final output sent to browser
DEBUG - 2023-02-07 10:05:59 --> Total execution time: 0.0414
INFO - 2023-02-07 10:06:01 --> Config Class Initialized
INFO - 2023-02-07 10:06:01 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:01 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:01 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:01 --> URI Class Initialized
INFO - 2023-02-07 10:06:01 --> Router Class Initialized
INFO - 2023-02-07 10:06:01 --> Output Class Initialized
INFO - 2023-02-07 10:06:01 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:01 --> Input Class Initialized
INFO - 2023-02-07 10:06:01 --> Language Class Initialized
INFO - 2023-02-07 10:06:01 --> Language Class Initialized
INFO - 2023-02-07 10:06:01 --> Config Class Initialized
INFO - 2023-02-07 10:06:01 --> Loader Class Initialized
INFO - 2023-02-07 10:06:01 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:01 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:01 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:01 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:01 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:01 --> Total execution time: 0.0390
INFO - 2023-02-07 10:06:01 --> Config Class Initialized
INFO - 2023-02-07 10:06:01 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:01 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:01 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:01 --> URI Class Initialized
INFO - 2023-02-07 10:06:01 --> Router Class Initialized
INFO - 2023-02-07 10:06:01 --> Output Class Initialized
INFO - 2023-02-07 10:06:01 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:01 --> Input Class Initialized
INFO - 2023-02-07 10:06:01 --> Language Class Initialized
INFO - 2023-02-07 10:06:01 --> Language Class Initialized
INFO - 2023-02-07 10:06:01 --> Config Class Initialized
INFO - 2023-02-07 10:06:01 --> Loader Class Initialized
INFO - 2023-02-07 10:06:01 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:01 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:01 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:01 --> Controller Class Initialized
INFO - 2023-02-07 10:06:39 --> Config Class Initialized
INFO - 2023-02-07 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:39 --> URI Class Initialized
INFO - 2023-02-07 10:06:39 --> Router Class Initialized
INFO - 2023-02-07 10:06:39 --> Output Class Initialized
INFO - 2023-02-07 10:06:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:39 --> Input Class Initialized
INFO - 2023-02-07 10:06:39 --> Language Class Initialized
INFO - 2023-02-07 10:06:39 --> Language Class Initialized
INFO - 2023-02-07 10:06:39 --> Config Class Initialized
INFO - 2023-02-07 10:06:39 --> Loader Class Initialized
INFO - 2023-02-07 10:06:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:39 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:39 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:39 --> Total execution time: 0.0376
INFO - 2023-02-07 10:06:39 --> Config Class Initialized
INFO - 2023-02-07 10:06:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:39 --> URI Class Initialized
INFO - 2023-02-07 10:06:39 --> Router Class Initialized
INFO - 2023-02-07 10:06:39 --> Output Class Initialized
INFO - 2023-02-07 10:06:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:39 --> Input Class Initialized
INFO - 2023-02-07 10:06:39 --> Language Class Initialized
INFO - 2023-02-07 10:06:39 --> Language Class Initialized
INFO - 2023-02-07 10:06:39 --> Config Class Initialized
INFO - 2023-02-07 10:06:39 --> Loader Class Initialized
INFO - 2023-02-07 10:06:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:39 --> Controller Class Initialized
INFO - 2023-02-07 10:06:40 --> Config Class Initialized
INFO - 2023-02-07 10:06:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:40 --> URI Class Initialized
INFO - 2023-02-07 10:06:40 --> Router Class Initialized
INFO - 2023-02-07 10:06:40 --> Output Class Initialized
INFO - 2023-02-07 10:06:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:40 --> Input Class Initialized
INFO - 2023-02-07 10:06:40 --> Language Class Initialized
INFO - 2023-02-07 10:06:40 --> Language Class Initialized
INFO - 2023-02-07 10:06:40 --> Config Class Initialized
INFO - 2023-02-07 10:06:40 --> Loader Class Initialized
INFO - 2023-02-07 10:06:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:40 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:06:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:40 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:40 --> Total execution time: 0.0325
INFO - 2023-02-07 10:06:42 --> Config Class Initialized
INFO - 2023-02-07 10:06:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:42 --> URI Class Initialized
INFO - 2023-02-07 10:06:42 --> Router Class Initialized
INFO - 2023-02-07 10:06:42 --> Output Class Initialized
INFO - 2023-02-07 10:06:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:42 --> Input Class Initialized
INFO - 2023-02-07 10:06:42 --> Language Class Initialized
INFO - 2023-02-07 10:06:42 --> Language Class Initialized
INFO - 2023-02-07 10:06:42 --> Config Class Initialized
INFO - 2023-02-07 10:06:42 --> Loader Class Initialized
INFO - 2023-02-07 10:06:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:42 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:42 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:42 --> Total execution time: 0.0483
INFO - 2023-02-07 10:06:42 --> Config Class Initialized
INFO - 2023-02-07 10:06:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:42 --> URI Class Initialized
INFO - 2023-02-07 10:06:42 --> Router Class Initialized
INFO - 2023-02-07 10:06:42 --> Output Class Initialized
INFO - 2023-02-07 10:06:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:42 --> Input Class Initialized
INFO - 2023-02-07 10:06:42 --> Language Class Initialized
INFO - 2023-02-07 10:06:42 --> Language Class Initialized
INFO - 2023-02-07 10:06:42 --> Config Class Initialized
INFO - 2023-02-07 10:06:42 --> Loader Class Initialized
INFO - 2023-02-07 10:06:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:42 --> Controller Class Initialized
INFO - 2023-02-07 10:06:43 --> Config Class Initialized
INFO - 2023-02-07 10:06:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:43 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:43 --> URI Class Initialized
INFO - 2023-02-07 10:06:43 --> Router Class Initialized
INFO - 2023-02-07 10:06:43 --> Output Class Initialized
INFO - 2023-02-07 10:06:43 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:43 --> Input Class Initialized
INFO - 2023-02-07 10:06:43 --> Language Class Initialized
INFO - 2023-02-07 10:06:43 --> Language Class Initialized
INFO - 2023-02-07 10:06:43 --> Config Class Initialized
INFO - 2023-02-07 10:06:43 --> Loader Class Initialized
INFO - 2023-02-07 10:06:43 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:43 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:43 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:43 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:43 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:06:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:43 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:43 --> Total execution time: 0.0511
INFO - 2023-02-07 10:06:44 --> Config Class Initialized
INFO - 2023-02-07 10:06:44 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:44 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:44 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:44 --> URI Class Initialized
INFO - 2023-02-07 10:06:44 --> Router Class Initialized
INFO - 2023-02-07 10:06:44 --> Output Class Initialized
INFO - 2023-02-07 10:06:44 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:44 --> Input Class Initialized
INFO - 2023-02-07 10:06:44 --> Language Class Initialized
INFO - 2023-02-07 10:06:44 --> Language Class Initialized
INFO - 2023-02-07 10:06:44 --> Config Class Initialized
INFO - 2023-02-07 10:06:44 --> Loader Class Initialized
INFO - 2023-02-07 10:06:44 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:44 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:44 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:44 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:44 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:44 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-02-07 10:06:44 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:44 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:44 --> Total execution time: 0.0247
INFO - 2023-02-07 10:06:45 --> Config Class Initialized
INFO - 2023-02-07 10:06:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:45 --> URI Class Initialized
INFO - 2023-02-07 10:06:45 --> Router Class Initialized
INFO - 2023-02-07 10:06:45 --> Output Class Initialized
INFO - 2023-02-07 10:06:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:45 --> Input Class Initialized
INFO - 2023-02-07 10:06:45 --> Language Class Initialized
INFO - 2023-02-07 10:06:45 --> Language Class Initialized
INFO - 2023-02-07 10:06:45 --> Config Class Initialized
INFO - 2023-02-07 10:06:45 --> Loader Class Initialized
INFO - 2023-02-07 10:06:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:45 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:06:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:45 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:45 --> Total execution time: 0.0382
INFO - 2023-02-07 10:06:47 --> Config Class Initialized
INFO - 2023-02-07 10:06:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:47 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:47 --> URI Class Initialized
INFO - 2023-02-07 10:06:47 --> Router Class Initialized
INFO - 2023-02-07 10:06:47 --> Output Class Initialized
INFO - 2023-02-07 10:06:47 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:47 --> Input Class Initialized
INFO - 2023-02-07 10:06:47 --> Language Class Initialized
INFO - 2023-02-07 10:06:47 --> Language Class Initialized
INFO - 2023-02-07 10:06:47 --> Config Class Initialized
INFO - 2023-02-07 10:06:47 --> Loader Class Initialized
INFO - 2023-02-07 10:06:47 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:47 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:47 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:47 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:47 --> Total execution time: 0.0259
INFO - 2023-02-07 10:06:47 --> Config Class Initialized
INFO - 2023-02-07 10:06:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:47 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:47 --> URI Class Initialized
INFO - 2023-02-07 10:06:47 --> Router Class Initialized
INFO - 2023-02-07 10:06:47 --> Output Class Initialized
INFO - 2023-02-07 10:06:47 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:47 --> Input Class Initialized
INFO - 2023-02-07 10:06:47 --> Language Class Initialized
INFO - 2023-02-07 10:06:47 --> Language Class Initialized
INFO - 2023-02-07 10:06:47 --> Config Class Initialized
INFO - 2023-02-07 10:06:47 --> Loader Class Initialized
INFO - 2023-02-07 10:06:47 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:47 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:47 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:47 --> Controller Class Initialized
INFO - 2023-02-07 10:06:49 --> Config Class Initialized
INFO - 2023-02-07 10:06:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:49 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:49 --> URI Class Initialized
INFO - 2023-02-07 10:06:49 --> Router Class Initialized
INFO - 2023-02-07 10:06:49 --> Output Class Initialized
INFO - 2023-02-07 10:06:49 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:49 --> Input Class Initialized
INFO - 2023-02-07 10:06:49 --> Language Class Initialized
INFO - 2023-02-07 10:06:49 --> Language Class Initialized
INFO - 2023-02-07 10:06:49 --> Config Class Initialized
INFO - 2023-02-07 10:06:49 --> Loader Class Initialized
INFO - 2023-02-07 10:06:49 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:49 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:49 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:49 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:49 --> Total execution time: 0.0244
INFO - 2023-02-07 10:06:49 --> Config Class Initialized
INFO - 2023-02-07 10:06:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:49 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:49 --> URI Class Initialized
INFO - 2023-02-07 10:06:49 --> Router Class Initialized
INFO - 2023-02-07 10:06:49 --> Output Class Initialized
INFO - 2023-02-07 10:06:49 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:49 --> Input Class Initialized
INFO - 2023-02-07 10:06:49 --> Language Class Initialized
INFO - 2023-02-07 10:06:49 --> Language Class Initialized
INFO - 2023-02-07 10:06:49 --> Config Class Initialized
INFO - 2023-02-07 10:06:49 --> Loader Class Initialized
INFO - 2023-02-07 10:06:49 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:49 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:49 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:49 --> Controller Class Initialized
INFO - 2023-02-07 10:06:52 --> Config Class Initialized
INFO - 2023-02-07 10:06:52 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:52 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:52 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:52 --> URI Class Initialized
INFO - 2023-02-07 10:06:52 --> Router Class Initialized
INFO - 2023-02-07 10:06:52 --> Output Class Initialized
INFO - 2023-02-07 10:06:52 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:52 --> Input Class Initialized
INFO - 2023-02-07 10:06:52 --> Language Class Initialized
ERROR - 2023-02-07 10:06:52 --> 404 Page Not Found: /index
INFO - 2023-02-07 10:06:54 --> Config Class Initialized
INFO - 2023-02-07 10:06:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:54 --> URI Class Initialized
INFO - 2023-02-07 10:06:54 --> Router Class Initialized
INFO - 2023-02-07 10:06:54 --> Output Class Initialized
INFO - 2023-02-07 10:06:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:54 --> Input Class Initialized
INFO - 2023-02-07 10:06:54 --> Language Class Initialized
INFO - 2023-02-07 10:06:54 --> Language Class Initialized
INFO - 2023-02-07 10:06:54 --> Config Class Initialized
INFO - 2023-02-07 10:06:54 --> Loader Class Initialized
INFO - 2023-02-07 10:06:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:54 --> Controller Class Initialized
DEBUG - 2023-02-07 10:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:06:54 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:06:54 --> Final output sent to browser
DEBUG - 2023-02-07 10:06:54 --> Total execution time: 0.0468
INFO - 2023-02-07 10:06:54 --> Config Class Initialized
INFO - 2023-02-07 10:06:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:54 --> URI Class Initialized
INFO - 2023-02-07 10:06:54 --> Router Class Initialized
INFO - 2023-02-07 10:06:54 --> Output Class Initialized
INFO - 2023-02-07 10:06:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:54 --> Input Class Initialized
INFO - 2023-02-07 10:06:54 --> Language Class Initialized
ERROR - 2023-02-07 10:06:54 --> 404 Page Not Found: /index
INFO - 2023-02-07 10:06:54 --> Config Class Initialized
INFO - 2023-02-07 10:06:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:06:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:06:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:06:54 --> URI Class Initialized
INFO - 2023-02-07 10:06:54 --> Router Class Initialized
INFO - 2023-02-07 10:06:54 --> Output Class Initialized
INFO - 2023-02-07 10:06:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:06:54 --> Input Class Initialized
INFO - 2023-02-07 10:06:54 --> Language Class Initialized
INFO - 2023-02-07 10:06:54 --> Language Class Initialized
INFO - 2023-02-07 10:06:54 --> Config Class Initialized
INFO - 2023-02-07 10:06:54 --> Loader Class Initialized
INFO - 2023-02-07 10:06:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:06:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:06:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:06:54 --> Controller Class Initialized
INFO - 2023-02-07 10:09:45 --> Config Class Initialized
INFO - 2023-02-07 10:09:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:45 --> URI Class Initialized
INFO - 2023-02-07 10:09:45 --> Router Class Initialized
INFO - 2023-02-07 10:09:45 --> Output Class Initialized
INFO - 2023-02-07 10:09:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:45 --> Input Class Initialized
INFO - 2023-02-07 10:09:45 --> Language Class Initialized
INFO - 2023-02-07 10:09:45 --> Language Class Initialized
INFO - 2023-02-07 10:09:45 --> Config Class Initialized
INFO - 2023-02-07 10:09:45 --> Loader Class Initialized
INFO - 2023-02-07 10:09:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:09:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:09:45 --> Controller Class Initialized
DEBUG - 2023-02-07 10:09:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:09:45 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:09:45 --> Final output sent to browser
DEBUG - 2023-02-07 10:09:45 --> Total execution time: 0.0426
INFO - 2023-02-07 10:09:45 --> Config Class Initialized
INFO - 2023-02-07 10:09:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:45 --> URI Class Initialized
INFO - 2023-02-07 10:09:45 --> Router Class Initialized
INFO - 2023-02-07 10:09:45 --> Output Class Initialized
INFO - 2023-02-07 10:09:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:45 --> Input Class Initialized
INFO - 2023-02-07 10:09:45 --> Language Class Initialized
ERROR - 2023-02-07 10:09:45 --> 404 Page Not Found: /index
INFO - 2023-02-07 10:09:45 --> Config Class Initialized
INFO - 2023-02-07 10:09:45 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:45 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:45 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:45 --> URI Class Initialized
INFO - 2023-02-07 10:09:45 --> Router Class Initialized
INFO - 2023-02-07 10:09:45 --> Output Class Initialized
INFO - 2023-02-07 10:09:45 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:45 --> Input Class Initialized
INFO - 2023-02-07 10:09:45 --> Language Class Initialized
INFO - 2023-02-07 10:09:45 --> Language Class Initialized
INFO - 2023-02-07 10:09:45 --> Config Class Initialized
INFO - 2023-02-07 10:09:45 --> Loader Class Initialized
INFO - 2023-02-07 10:09:45 --> Helper loaded: url_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: file_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: form_helper
INFO - 2023-02-07 10:09:45 --> Helper loaded: my_helper
INFO - 2023-02-07 10:09:45 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:09:45 --> Controller Class Initialized
INFO - 2023-02-07 10:09:50 --> Config Class Initialized
INFO - 2023-02-07 10:09:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:50 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:50 --> URI Class Initialized
INFO - 2023-02-07 10:09:50 --> Router Class Initialized
INFO - 2023-02-07 10:09:50 --> Output Class Initialized
INFO - 2023-02-07 10:09:50 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:50 --> Input Class Initialized
INFO - 2023-02-07 10:09:50 --> Language Class Initialized
INFO - 2023-02-07 10:09:50 --> Language Class Initialized
INFO - 2023-02-07 10:09:50 --> Config Class Initialized
INFO - 2023-02-07 10:09:50 --> Loader Class Initialized
INFO - 2023-02-07 10:09:50 --> Helper loaded: url_helper
INFO - 2023-02-07 10:09:50 --> Helper loaded: file_helper
INFO - 2023-02-07 10:09:50 --> Helper loaded: form_helper
INFO - 2023-02-07 10:09:50 --> Helper loaded: my_helper
INFO - 2023-02-07 10:09:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:09:50 --> Controller Class Initialized
INFO - 2023-02-07 10:09:50 --> Final output sent to browser
DEBUG - 2023-02-07 10:09:50 --> Total execution time: 0.0593
INFO - 2023-02-07 10:09:54 --> Config Class Initialized
INFO - 2023-02-07 10:09:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:54 --> URI Class Initialized
INFO - 2023-02-07 10:09:54 --> Router Class Initialized
INFO - 2023-02-07 10:09:54 --> Output Class Initialized
INFO - 2023-02-07 10:09:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:54 --> Input Class Initialized
INFO - 2023-02-07 10:09:54 --> Language Class Initialized
INFO - 2023-02-07 10:09:54 --> Language Class Initialized
INFO - 2023-02-07 10:09:54 --> Config Class Initialized
INFO - 2023-02-07 10:09:54 --> Loader Class Initialized
INFO - 2023-02-07 10:09:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:09:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:09:54 --> Controller Class Initialized
INFO - 2023-02-07 10:09:54 --> Final output sent to browser
DEBUG - 2023-02-07 10:09:54 --> Total execution time: 0.0323
INFO - 2023-02-07 10:09:54 --> Config Class Initialized
INFO - 2023-02-07 10:09:54 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:09:54 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:09:54 --> Utf8 Class Initialized
INFO - 2023-02-07 10:09:54 --> URI Class Initialized
INFO - 2023-02-07 10:09:54 --> Router Class Initialized
INFO - 2023-02-07 10:09:54 --> Output Class Initialized
INFO - 2023-02-07 10:09:54 --> Security Class Initialized
DEBUG - 2023-02-07 10:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:09:54 --> Input Class Initialized
INFO - 2023-02-07 10:09:54 --> Language Class Initialized
INFO - 2023-02-07 10:09:54 --> Language Class Initialized
INFO - 2023-02-07 10:09:54 --> Config Class Initialized
INFO - 2023-02-07 10:09:54 --> Loader Class Initialized
INFO - 2023-02-07 10:09:54 --> Helper loaded: url_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: file_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: form_helper
INFO - 2023-02-07 10:09:54 --> Helper loaded: my_helper
INFO - 2023-02-07 10:09:54 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:09:54 --> Controller Class Initialized
INFO - 2023-02-07 10:11:57 --> Config Class Initialized
INFO - 2023-02-07 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:11:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:11:57 --> URI Class Initialized
INFO - 2023-02-07 10:11:57 --> Router Class Initialized
INFO - 2023-02-07 10:11:57 --> Output Class Initialized
INFO - 2023-02-07 10:11:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:11:57 --> Input Class Initialized
INFO - 2023-02-07 10:11:57 --> Language Class Initialized
INFO - 2023-02-07 10:11:57 --> Language Class Initialized
INFO - 2023-02-07 10:11:57 --> Config Class Initialized
INFO - 2023-02-07 10:11:57 --> Loader Class Initialized
INFO - 2023-02-07 10:11:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:11:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:11:57 --> Controller Class Initialized
INFO - 2023-02-07 10:11:57 --> Final output sent to browser
DEBUG - 2023-02-07 10:11:57 --> Total execution time: 0.0385
INFO - 2023-02-07 10:11:57 --> Config Class Initialized
INFO - 2023-02-07 10:11:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:11:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:11:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:11:57 --> URI Class Initialized
INFO - 2023-02-07 10:11:57 --> Router Class Initialized
INFO - 2023-02-07 10:11:57 --> Output Class Initialized
INFO - 2023-02-07 10:11:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:11:57 --> Input Class Initialized
INFO - 2023-02-07 10:11:57 --> Language Class Initialized
INFO - 2023-02-07 10:11:57 --> Language Class Initialized
INFO - 2023-02-07 10:11:57 --> Config Class Initialized
INFO - 2023-02-07 10:11:57 --> Loader Class Initialized
INFO - 2023-02-07 10:11:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:11:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:11:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:11:57 --> Controller Class Initialized
INFO - 2023-02-07 10:11:59 --> Config Class Initialized
INFO - 2023-02-07 10:11:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:11:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:11:59 --> Utf8 Class Initialized
INFO - 2023-02-07 10:11:59 --> URI Class Initialized
INFO - 2023-02-07 10:11:59 --> Router Class Initialized
INFO - 2023-02-07 10:11:59 --> Output Class Initialized
INFO - 2023-02-07 10:11:59 --> Security Class Initialized
DEBUG - 2023-02-07 10:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:11:59 --> Input Class Initialized
INFO - 2023-02-07 10:11:59 --> Language Class Initialized
INFO - 2023-02-07 10:11:59 --> Language Class Initialized
INFO - 2023-02-07 10:11:59 --> Config Class Initialized
INFO - 2023-02-07 10:11:59 --> Loader Class Initialized
INFO - 2023-02-07 10:11:59 --> Helper loaded: url_helper
INFO - 2023-02-07 10:11:59 --> Helper loaded: file_helper
INFO - 2023-02-07 10:11:59 --> Helper loaded: form_helper
INFO - 2023-02-07 10:11:59 --> Helper loaded: my_helper
INFO - 2023-02-07 10:11:59 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:11:59 --> Controller Class Initialized
DEBUG - 2023-02-07 10:11:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:11:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:11:59 --> Final output sent to browser
DEBUG - 2023-02-07 10:11:59 --> Total execution time: 0.0337
INFO - 2023-02-07 10:11:59 --> Config Class Initialized
INFO - 2023-02-07 10:11:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:11:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:11:59 --> Utf8 Class Initialized
INFO - 2023-02-07 10:11:59 --> URI Class Initialized
INFO - 2023-02-07 10:11:59 --> Router Class Initialized
INFO - 2023-02-07 10:11:59 --> Output Class Initialized
INFO - 2023-02-07 10:11:59 --> Security Class Initialized
DEBUG - 2023-02-07 10:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:11:59 --> Input Class Initialized
INFO - 2023-02-07 10:11:59 --> Language Class Initialized
ERROR - 2023-02-07 10:11:59 --> 404 Page Not Found: /index
INFO - 2023-02-07 10:12:04 --> Config Class Initialized
INFO - 2023-02-07 10:12:04 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:04 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:04 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:04 --> URI Class Initialized
INFO - 2023-02-07 10:12:04 --> Router Class Initialized
INFO - 2023-02-07 10:12:04 --> Output Class Initialized
INFO - 2023-02-07 10:12:04 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:04 --> Input Class Initialized
INFO - 2023-02-07 10:12:04 --> Language Class Initialized
INFO - 2023-02-07 10:12:04 --> Language Class Initialized
INFO - 2023-02-07 10:12:04 --> Config Class Initialized
INFO - 2023-02-07 10:12:04 --> Loader Class Initialized
INFO - 2023-02-07 10:12:04 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:04 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:04 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:04 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:04 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:04 --> Total execution time: 0.0403
INFO - 2023-02-07 10:12:04 --> Config Class Initialized
INFO - 2023-02-07 10:12:04 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:04 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:04 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:04 --> URI Class Initialized
INFO - 2023-02-07 10:12:04 --> Router Class Initialized
INFO - 2023-02-07 10:12:04 --> Output Class Initialized
INFO - 2023-02-07 10:12:04 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:04 --> Input Class Initialized
INFO - 2023-02-07 10:12:04 --> Language Class Initialized
INFO - 2023-02-07 10:12:04 --> Language Class Initialized
INFO - 2023-02-07 10:12:04 --> Config Class Initialized
INFO - 2023-02-07 10:12:04 --> Loader Class Initialized
INFO - 2023-02-07 10:12:04 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:04 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:04 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:04 --> Controller Class Initialized
INFO - 2023-02-07 10:12:36 --> Config Class Initialized
INFO - 2023-02-07 10:12:36 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:36 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:36 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:36 --> URI Class Initialized
INFO - 2023-02-07 10:12:36 --> Router Class Initialized
INFO - 2023-02-07 10:12:36 --> Output Class Initialized
INFO - 2023-02-07 10:12:36 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:36 --> Input Class Initialized
INFO - 2023-02-07 10:12:36 --> Language Class Initialized
INFO - 2023-02-07 10:12:36 --> Language Class Initialized
INFO - 2023-02-07 10:12:36 --> Config Class Initialized
INFO - 2023-02-07 10:12:36 --> Loader Class Initialized
INFO - 2023-02-07 10:12:36 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:36 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:36 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:36 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:36 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:36 --> Total execution time: 0.0283
INFO - 2023-02-07 10:12:36 --> Config Class Initialized
INFO - 2023-02-07 10:12:36 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:36 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:36 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:36 --> URI Class Initialized
INFO - 2023-02-07 10:12:36 --> Router Class Initialized
INFO - 2023-02-07 10:12:36 --> Output Class Initialized
INFO - 2023-02-07 10:12:36 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:36 --> Input Class Initialized
INFO - 2023-02-07 10:12:36 --> Language Class Initialized
INFO - 2023-02-07 10:12:36 --> Language Class Initialized
INFO - 2023-02-07 10:12:36 --> Config Class Initialized
INFO - 2023-02-07 10:12:36 --> Loader Class Initialized
INFO - 2023-02-07 10:12:36 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:36 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:36 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:36 --> Controller Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:37 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:37 --> Total execution time: 0.0409
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:37 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:37 --> Total execution time: 0.0330
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:37 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:37 --> Total execution time: 0.0384
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:37 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:37 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:37 --> Total execution time: 0.0363
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:37 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:37 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:37 --> URI Class Initialized
INFO - 2023-02-07 10:12:37 --> Router Class Initialized
INFO - 2023-02-07 10:12:37 --> Output Class Initialized
INFO - 2023-02-07 10:12:37 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:37 --> Input Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Language Class Initialized
INFO - 2023-02-07 10:12:37 --> Config Class Initialized
INFO - 2023-02-07 10:12:37 --> Loader Class Initialized
INFO - 2023-02-07 10:12:37 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:37 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:37 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:37 --> Controller Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:38 --> URI Class Initialized
INFO - 2023-02-07 10:12:38 --> Router Class Initialized
INFO - 2023-02-07 10:12:38 --> Output Class Initialized
INFO - 2023-02-07 10:12:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:38 --> Input Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Loader Class Initialized
INFO - 2023-02-07 10:12:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:38 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:38 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:38 --> Total execution time: 0.0382
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:38 --> URI Class Initialized
INFO - 2023-02-07 10:12:38 --> Router Class Initialized
INFO - 2023-02-07 10:12:38 --> Output Class Initialized
INFO - 2023-02-07 10:12:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:38 --> Input Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Loader Class Initialized
INFO - 2023-02-07 10:12:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:38 --> Controller Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:38 --> URI Class Initialized
INFO - 2023-02-07 10:12:38 --> Router Class Initialized
INFO - 2023-02-07 10:12:38 --> Output Class Initialized
INFO - 2023-02-07 10:12:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:38 --> Input Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Loader Class Initialized
INFO - 2023-02-07 10:12:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:38 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:38 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:38 --> Total execution time: 0.0269
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:38 --> URI Class Initialized
INFO - 2023-02-07 10:12:38 --> Router Class Initialized
INFO - 2023-02-07 10:12:38 --> Output Class Initialized
INFO - 2023-02-07 10:12:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:38 --> Input Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Language Class Initialized
INFO - 2023-02-07 10:12:38 --> Config Class Initialized
INFO - 2023-02-07 10:12:38 --> Loader Class Initialized
INFO - 2023-02-07 10:12:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:38 --> Controller Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:39 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:39 --> Total execution time: 0.0328
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:39 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:39 --> Total execution time: 0.0241
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:39 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:39 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:39 --> Total execution time: 0.0322
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:39 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:39 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:39 --> URI Class Initialized
INFO - 2023-02-07 10:12:39 --> Router Class Initialized
INFO - 2023-02-07 10:12:39 --> Output Class Initialized
INFO - 2023-02-07 10:12:39 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:39 --> Input Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Language Class Initialized
INFO - 2023-02-07 10:12:39 --> Config Class Initialized
INFO - 2023-02-07 10:12:39 --> Loader Class Initialized
INFO - 2023-02-07 10:12:39 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:39 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:39 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:39 --> Controller Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:40 --> URI Class Initialized
INFO - 2023-02-07 10:12:40 --> Router Class Initialized
INFO - 2023-02-07 10:12:40 --> Output Class Initialized
INFO - 2023-02-07 10:12:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:40 --> Input Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Loader Class Initialized
INFO - 2023-02-07 10:12:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:40 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:40 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:40 --> Total execution time: 0.0244
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:40 --> URI Class Initialized
INFO - 2023-02-07 10:12:40 --> Router Class Initialized
INFO - 2023-02-07 10:12:40 --> Output Class Initialized
INFO - 2023-02-07 10:12:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:40 --> Input Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Loader Class Initialized
INFO - 2023-02-07 10:12:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:40 --> Controller Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:40 --> URI Class Initialized
INFO - 2023-02-07 10:12:40 --> Router Class Initialized
INFO - 2023-02-07 10:12:40 --> Output Class Initialized
INFO - 2023-02-07 10:12:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:40 --> Input Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Loader Class Initialized
INFO - 2023-02-07 10:12:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:40 --> Controller Class Initialized
DEBUG - 2023-02-07 10:12:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:12:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:12:40 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:40 --> Total execution time: 0.0436
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:40 --> URI Class Initialized
INFO - 2023-02-07 10:12:40 --> Router Class Initialized
INFO - 2023-02-07 10:12:40 --> Output Class Initialized
INFO - 2023-02-07 10:12:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:40 --> Input Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Language Class Initialized
INFO - 2023-02-07 10:12:40 --> Config Class Initialized
INFO - 2023-02-07 10:12:40 --> Loader Class Initialized
INFO - 2023-02-07 10:12:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:40 --> Controller Class Initialized
INFO - 2023-02-07 10:12:43 --> Config Class Initialized
INFO - 2023-02-07 10:12:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:43 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:43 --> URI Class Initialized
INFO - 2023-02-07 10:12:43 --> Router Class Initialized
INFO - 2023-02-07 10:12:43 --> Output Class Initialized
INFO - 2023-02-07 10:12:43 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:43 --> Input Class Initialized
INFO - 2023-02-07 10:12:43 --> Language Class Initialized
INFO - 2023-02-07 10:12:43 --> Language Class Initialized
INFO - 2023-02-07 10:12:43 --> Config Class Initialized
INFO - 2023-02-07 10:12:43 --> Loader Class Initialized
INFO - 2023-02-07 10:12:43 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:43 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:43 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:43 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:43 --> Controller Class Initialized
INFO - 2023-02-07 10:12:43 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:43 --> Total execution time: 0.0253
INFO - 2023-02-07 10:12:46 --> Config Class Initialized
INFO - 2023-02-07 10:12:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:46 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:46 --> URI Class Initialized
INFO - 2023-02-07 10:12:46 --> Router Class Initialized
INFO - 2023-02-07 10:12:46 --> Output Class Initialized
INFO - 2023-02-07 10:12:46 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:46 --> Input Class Initialized
INFO - 2023-02-07 10:12:46 --> Language Class Initialized
INFO - 2023-02-07 10:12:46 --> Language Class Initialized
INFO - 2023-02-07 10:12:46 --> Config Class Initialized
INFO - 2023-02-07 10:12:46 --> Loader Class Initialized
INFO - 2023-02-07 10:12:46 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:46 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:46 --> Controller Class Initialized
INFO - 2023-02-07 10:12:46 --> Final output sent to browser
DEBUG - 2023-02-07 10:12:46 --> Total execution time: 0.0341
INFO - 2023-02-07 10:12:46 --> Config Class Initialized
INFO - 2023-02-07 10:12:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:12:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:12:46 --> Utf8 Class Initialized
INFO - 2023-02-07 10:12:46 --> URI Class Initialized
INFO - 2023-02-07 10:12:46 --> Router Class Initialized
INFO - 2023-02-07 10:12:46 --> Output Class Initialized
INFO - 2023-02-07 10:12:46 --> Security Class Initialized
DEBUG - 2023-02-07 10:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:12:46 --> Input Class Initialized
INFO - 2023-02-07 10:12:46 --> Language Class Initialized
INFO - 2023-02-07 10:12:46 --> Language Class Initialized
INFO - 2023-02-07 10:12:46 --> Config Class Initialized
INFO - 2023-02-07 10:12:46 --> Loader Class Initialized
INFO - 2023-02-07 10:12:46 --> Helper loaded: url_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: file_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: form_helper
INFO - 2023-02-07 10:12:46 --> Helper loaded: my_helper
INFO - 2023-02-07 10:12:46 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:12:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:12:46 --> Controller Class Initialized
INFO - 2023-02-07 10:14:49 --> Config Class Initialized
INFO - 2023-02-07 10:14:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:49 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:49 --> URI Class Initialized
INFO - 2023-02-07 10:14:49 --> Router Class Initialized
INFO - 2023-02-07 10:14:49 --> Output Class Initialized
INFO - 2023-02-07 10:14:49 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:49 --> Input Class Initialized
INFO - 2023-02-07 10:14:49 --> Language Class Initialized
INFO - 2023-02-07 10:14:49 --> Language Class Initialized
INFO - 2023-02-07 10:14:49 --> Config Class Initialized
INFO - 2023-02-07 10:14:49 --> Loader Class Initialized
INFO - 2023-02-07 10:14:49 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:49 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:49 --> Controller Class Initialized
DEBUG - 2023-02-07 10:14:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pengetahuan/views/list.php
DEBUG - 2023-02-07 10:14:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:14:49 --> Final output sent to browser
DEBUG - 2023-02-07 10:14:49 --> Total execution time: 0.0284
INFO - 2023-02-07 10:14:49 --> Config Class Initialized
INFO - 2023-02-07 10:14:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:49 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:49 --> URI Class Initialized
INFO - 2023-02-07 10:14:49 --> Router Class Initialized
INFO - 2023-02-07 10:14:49 --> Output Class Initialized
INFO - 2023-02-07 10:14:49 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:49 --> Input Class Initialized
INFO - 2023-02-07 10:14:49 --> Language Class Initialized
INFO - 2023-02-07 10:14:49 --> Language Class Initialized
INFO - 2023-02-07 10:14:49 --> Config Class Initialized
INFO - 2023-02-07 10:14:49 --> Loader Class Initialized
INFO - 2023-02-07 10:14:49 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:49 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:49 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:49 --> Controller Class Initialized
INFO - 2023-02-07 10:14:55 --> Config Class Initialized
INFO - 2023-02-07 10:14:55 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:55 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:55 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:55 --> URI Class Initialized
INFO - 2023-02-07 10:14:55 --> Router Class Initialized
INFO - 2023-02-07 10:14:55 --> Output Class Initialized
INFO - 2023-02-07 10:14:55 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:55 --> Input Class Initialized
INFO - 2023-02-07 10:14:55 --> Language Class Initialized
INFO - 2023-02-07 10:14:55 --> Language Class Initialized
INFO - 2023-02-07 10:14:55 --> Config Class Initialized
INFO - 2023-02-07 10:14:55 --> Loader Class Initialized
INFO - 2023-02-07 10:14:55 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:55 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:55 --> Controller Class Initialized
INFO - 2023-02-07 10:14:55 --> Final output sent to browser
DEBUG - 2023-02-07 10:14:55 --> Total execution time: 0.0390
INFO - 2023-02-07 10:14:55 --> Config Class Initialized
INFO - 2023-02-07 10:14:55 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:55 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:55 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:55 --> URI Class Initialized
INFO - 2023-02-07 10:14:55 --> Router Class Initialized
INFO - 2023-02-07 10:14:55 --> Output Class Initialized
INFO - 2023-02-07 10:14:55 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:55 --> Input Class Initialized
INFO - 2023-02-07 10:14:55 --> Language Class Initialized
INFO - 2023-02-07 10:14:55 --> Language Class Initialized
INFO - 2023-02-07 10:14:55 --> Config Class Initialized
INFO - 2023-02-07 10:14:55 --> Loader Class Initialized
INFO - 2023-02-07 10:14:55 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:55 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:55 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:55 --> Controller Class Initialized
INFO - 2023-02-07 10:14:57 --> Config Class Initialized
INFO - 2023-02-07 10:14:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:57 --> URI Class Initialized
INFO - 2023-02-07 10:14:57 --> Router Class Initialized
INFO - 2023-02-07 10:14:57 --> Output Class Initialized
INFO - 2023-02-07 10:14:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:57 --> Input Class Initialized
INFO - 2023-02-07 10:14:57 --> Language Class Initialized
INFO - 2023-02-07 10:14:57 --> Language Class Initialized
INFO - 2023-02-07 10:14:57 --> Config Class Initialized
INFO - 2023-02-07 10:14:57 --> Loader Class Initialized
INFO - 2023-02-07 10:14:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:57 --> Controller Class Initialized
INFO - 2023-02-07 10:14:57 --> Final output sent to browser
DEBUG - 2023-02-07 10:14:57 --> Total execution time: 0.0505
INFO - 2023-02-07 10:14:57 --> Config Class Initialized
INFO - 2023-02-07 10:14:57 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:14:57 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:14:57 --> Utf8 Class Initialized
INFO - 2023-02-07 10:14:57 --> URI Class Initialized
INFO - 2023-02-07 10:14:57 --> Router Class Initialized
INFO - 2023-02-07 10:14:57 --> Output Class Initialized
INFO - 2023-02-07 10:14:57 --> Security Class Initialized
DEBUG - 2023-02-07 10:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:14:57 --> Input Class Initialized
INFO - 2023-02-07 10:14:57 --> Language Class Initialized
INFO - 2023-02-07 10:14:57 --> Language Class Initialized
INFO - 2023-02-07 10:14:57 --> Config Class Initialized
INFO - 2023-02-07 10:14:57 --> Loader Class Initialized
INFO - 2023-02-07 10:14:57 --> Helper loaded: url_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: file_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: form_helper
INFO - 2023-02-07 10:14:57 --> Helper loaded: my_helper
INFO - 2023-02-07 10:14:57 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:14:57 --> Controller Class Initialized
INFO - 2023-02-07 10:15:04 --> Config Class Initialized
INFO - 2023-02-07 10:15:04 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:15:04 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:15:04 --> Utf8 Class Initialized
INFO - 2023-02-07 10:15:04 --> URI Class Initialized
INFO - 2023-02-07 10:15:04 --> Router Class Initialized
INFO - 2023-02-07 10:15:04 --> Output Class Initialized
INFO - 2023-02-07 10:15:04 --> Security Class Initialized
DEBUG - 2023-02-07 10:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:15:04 --> Input Class Initialized
INFO - 2023-02-07 10:15:04 --> Language Class Initialized
INFO - 2023-02-07 10:15:04 --> Language Class Initialized
INFO - 2023-02-07 10:15:04 --> Config Class Initialized
INFO - 2023-02-07 10:15:04 --> Loader Class Initialized
INFO - 2023-02-07 10:15:04 --> Helper loaded: url_helper
INFO - 2023-02-07 10:15:04 --> Helper loaded: file_helper
INFO - 2023-02-07 10:15:04 --> Helper loaded: form_helper
INFO - 2023-02-07 10:15:04 --> Helper loaded: my_helper
INFO - 2023-02-07 10:15:04 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:15:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:15:04 --> Controller Class Initialized
INFO - 2023-02-07 10:15:04 --> Final output sent to browser
DEBUG - 2023-02-07 10:15:04 --> Total execution time: 0.0277
INFO - 2023-02-07 10:15:12 --> Config Class Initialized
INFO - 2023-02-07 10:15:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:15:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:15:12 --> Utf8 Class Initialized
INFO - 2023-02-07 10:15:12 --> URI Class Initialized
INFO - 2023-02-07 10:15:12 --> Router Class Initialized
INFO - 2023-02-07 10:15:12 --> Output Class Initialized
INFO - 2023-02-07 10:15:12 --> Security Class Initialized
DEBUG - 2023-02-07 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:15:12 --> Input Class Initialized
INFO - 2023-02-07 10:15:12 --> Language Class Initialized
INFO - 2023-02-07 10:15:12 --> Language Class Initialized
INFO - 2023-02-07 10:15:12 --> Config Class Initialized
INFO - 2023-02-07 10:15:12 --> Loader Class Initialized
INFO - 2023-02-07 10:15:12 --> Helper loaded: url_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: file_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: form_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: my_helper
INFO - 2023-02-07 10:15:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:15:12 --> Controller Class Initialized
INFO - 2023-02-07 10:15:12 --> Final output sent to browser
DEBUG - 2023-02-07 10:15:12 --> Total execution time: 0.0400
INFO - 2023-02-07 10:15:12 --> Config Class Initialized
INFO - 2023-02-07 10:15:12 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:15:12 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:15:12 --> Utf8 Class Initialized
INFO - 2023-02-07 10:15:12 --> URI Class Initialized
INFO - 2023-02-07 10:15:12 --> Router Class Initialized
INFO - 2023-02-07 10:15:12 --> Output Class Initialized
INFO - 2023-02-07 10:15:12 --> Security Class Initialized
DEBUG - 2023-02-07 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:15:12 --> Input Class Initialized
INFO - 2023-02-07 10:15:12 --> Language Class Initialized
INFO - 2023-02-07 10:15:12 --> Language Class Initialized
INFO - 2023-02-07 10:15:12 --> Config Class Initialized
INFO - 2023-02-07 10:15:12 --> Loader Class Initialized
INFO - 2023-02-07 10:15:12 --> Helper loaded: url_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: file_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: form_helper
INFO - 2023-02-07 10:15:12 --> Helper loaded: my_helper
INFO - 2023-02-07 10:15:12 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:15:12 --> Controller Class Initialized
INFO - 2023-02-07 10:24:14 --> Config Class Initialized
INFO - 2023-02-07 10:24:14 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:24:14 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:24:14 --> Utf8 Class Initialized
INFO - 2023-02-07 10:24:14 --> URI Class Initialized
INFO - 2023-02-07 10:24:14 --> Router Class Initialized
INFO - 2023-02-07 10:24:14 --> Output Class Initialized
INFO - 2023-02-07 10:24:14 --> Security Class Initialized
DEBUG - 2023-02-07 10:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:24:14 --> Input Class Initialized
INFO - 2023-02-07 10:24:14 --> Language Class Initialized
INFO - 2023-02-07 10:24:14 --> Language Class Initialized
INFO - 2023-02-07 10:24:14 --> Config Class Initialized
INFO - 2023-02-07 10:24:14 --> Loader Class Initialized
INFO - 2023-02-07 10:24:14 --> Helper loaded: url_helper
INFO - 2023-02-07 10:24:14 --> Helper loaded: file_helper
INFO - 2023-02-07 10:24:14 --> Helper loaded: form_helper
INFO - 2023-02-07 10:24:14 --> Helper loaded: my_helper
INFO - 2023-02-07 10:24:14 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:24:14 --> Controller Class Initialized
DEBUG - 2023-02-07 10:24:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:24:14 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:24:14 --> Final output sent to browser
DEBUG - 2023-02-07 10:24:14 --> Total execution time: 0.0368
INFO - 2023-02-07 10:24:16 --> Config Class Initialized
INFO - 2023-02-07 10:24:16 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:24:16 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:24:16 --> Utf8 Class Initialized
INFO - 2023-02-07 10:24:16 --> URI Class Initialized
INFO - 2023-02-07 10:24:16 --> Router Class Initialized
INFO - 2023-02-07 10:24:16 --> Output Class Initialized
INFO - 2023-02-07 10:24:16 --> Security Class Initialized
DEBUG - 2023-02-07 10:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:24:16 --> Input Class Initialized
INFO - 2023-02-07 10:24:16 --> Language Class Initialized
INFO - 2023-02-07 10:24:16 --> Language Class Initialized
INFO - 2023-02-07 10:24:16 --> Config Class Initialized
INFO - 2023-02-07 10:24:16 --> Loader Class Initialized
INFO - 2023-02-07 10:24:16 --> Helper loaded: url_helper
INFO - 2023-02-07 10:24:16 --> Helper loaded: file_helper
INFO - 2023-02-07 10:24:16 --> Helper loaded: form_helper
INFO - 2023-02-07 10:24:16 --> Helper loaded: my_helper
INFO - 2023-02-07 10:24:16 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:24:16 --> Controller Class Initialized
DEBUG - 2023-02-07 10:24:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-02-07 10:24:16 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:24:16 --> Final output sent to browser
DEBUG - 2023-02-07 10:24:16 --> Total execution time: 0.0255
INFO - 2023-02-07 10:25:40 --> Config Class Initialized
INFO - 2023-02-07 10:25:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:25:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:25:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:25:40 --> URI Class Initialized
INFO - 2023-02-07 10:25:40 --> Router Class Initialized
INFO - 2023-02-07 10:25:40 --> Output Class Initialized
INFO - 2023-02-07 10:25:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:25:40 --> Input Class Initialized
INFO - 2023-02-07 10:25:40 --> Language Class Initialized
INFO - 2023-02-07 10:25:40 --> Language Class Initialized
INFO - 2023-02-07 10:25:40 --> Config Class Initialized
INFO - 2023-02-07 10:25:40 --> Loader Class Initialized
INFO - 2023-02-07 10:25:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:25:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:25:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:25:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:25:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:25:40 --> Controller Class Initialized
DEBUG - 2023-02-07 10:25:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_keterampilan/views/list.php
DEBUG - 2023-02-07 10:25:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:25:40 --> Final output sent to browser
DEBUG - 2023-02-07 10:25:40 --> Total execution time: 0.0358
INFO - 2023-02-07 10:25:42 --> Config Class Initialized
INFO - 2023-02-07 10:25:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:25:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:25:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:25:42 --> URI Class Initialized
INFO - 2023-02-07 10:25:42 --> Router Class Initialized
INFO - 2023-02-07 10:25:42 --> Output Class Initialized
INFO - 2023-02-07 10:25:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:25:42 --> Input Class Initialized
INFO - 2023-02-07 10:25:42 --> Language Class Initialized
INFO - 2023-02-07 10:25:42 --> Language Class Initialized
INFO - 2023-02-07 10:25:42 --> Config Class Initialized
INFO - 2023-02-07 10:25:42 --> Loader Class Initialized
INFO - 2023-02-07 10:25:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:25:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:25:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:25:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:25:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:25:42 --> Controller Class Initialized
DEBUG - 2023-02-07 10:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:25:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:25:42 --> Final output sent to browser
DEBUG - 2023-02-07 10:25:42 --> Total execution time: 0.0270
INFO - 2023-02-07 10:25:48 --> Config Class Initialized
INFO - 2023-02-07 10:25:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:25:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:25:48 --> Utf8 Class Initialized
INFO - 2023-02-07 10:25:48 --> URI Class Initialized
INFO - 2023-02-07 10:25:48 --> Router Class Initialized
INFO - 2023-02-07 10:25:48 --> Output Class Initialized
INFO - 2023-02-07 10:25:48 --> Security Class Initialized
DEBUG - 2023-02-07 10:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:25:48 --> Input Class Initialized
INFO - 2023-02-07 10:25:48 --> Language Class Initialized
INFO - 2023-02-07 10:25:48 --> Language Class Initialized
INFO - 2023-02-07 10:25:48 --> Config Class Initialized
INFO - 2023-02-07 10:25:48 --> Loader Class Initialized
INFO - 2023-02-07 10:25:48 --> Helper loaded: url_helper
INFO - 2023-02-07 10:25:48 --> Helper loaded: file_helper
INFO - 2023-02-07 10:25:48 --> Helper loaded: form_helper
INFO - 2023-02-07 10:25:48 --> Helper loaded: my_helper
INFO - 2023-02-07 10:25:48 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:25:48 --> Controller Class Initialized
DEBUG - 2023-02-07 10:25:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan_guru/views/list.php
DEBUG - 2023-02-07 10:25:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:25:48 --> Final output sent to browser
DEBUG - 2023-02-07 10:25:48 --> Total execution time: 0.0427
INFO - 2023-02-07 10:25:52 --> Config Class Initialized
INFO - 2023-02-07 10:25:52 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:25:52 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:25:52 --> Utf8 Class Initialized
INFO - 2023-02-07 10:25:52 --> URI Class Initialized
INFO - 2023-02-07 10:25:52 --> Router Class Initialized
INFO - 2023-02-07 10:25:52 --> Output Class Initialized
INFO - 2023-02-07 10:25:52 --> Security Class Initialized
DEBUG - 2023-02-07 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:25:52 --> Input Class Initialized
INFO - 2023-02-07 10:25:52 --> Language Class Initialized
INFO - 2023-02-07 10:25:52 --> Language Class Initialized
INFO - 2023-02-07 10:25:52 --> Config Class Initialized
INFO - 2023-02-07 10:25:52 --> Loader Class Initialized
INFO - 2023-02-07 10:25:52 --> Helper loaded: url_helper
INFO - 2023-02-07 10:25:52 --> Helper loaded: file_helper
INFO - 2023-02-07 10:25:52 --> Helper loaded: form_helper
INFO - 2023-02-07 10:25:52 --> Helper loaded: my_helper
INFO - 2023-02-07 10:25:52 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:25:52 --> Controller Class Initialized
DEBUG - 2023-02-07 10:25:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:25:52 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:25:52 --> Final output sent to browser
DEBUG - 2023-02-07 10:25:52 --> Total execution time: 0.0287
INFO - 2023-02-07 10:26:46 --> Config Class Initialized
INFO - 2023-02-07 10:26:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:26:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:26:46 --> Utf8 Class Initialized
INFO - 2023-02-07 10:26:46 --> URI Class Initialized
INFO - 2023-02-07 10:26:46 --> Router Class Initialized
INFO - 2023-02-07 10:26:46 --> Output Class Initialized
INFO - 2023-02-07 10:26:46 --> Security Class Initialized
DEBUG - 2023-02-07 10:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:26:46 --> Input Class Initialized
INFO - 2023-02-07 10:26:46 --> Language Class Initialized
INFO - 2023-02-07 10:26:46 --> Language Class Initialized
INFO - 2023-02-07 10:26:46 --> Config Class Initialized
INFO - 2023-02-07 10:26:46 --> Loader Class Initialized
INFO - 2023-02-07 10:26:46 --> Helper loaded: url_helper
INFO - 2023-02-07 10:26:46 --> Helper loaded: file_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: form_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: my_helper
INFO - 2023-02-07 10:26:47 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:26:47 --> Controller Class Initialized
INFO - 2023-02-07 10:26:47 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:26:47 --> Config Class Initialized
INFO - 2023-02-07 10:26:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:26:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:26:47 --> Utf8 Class Initialized
INFO - 2023-02-07 10:26:47 --> URI Class Initialized
INFO - 2023-02-07 10:26:47 --> Router Class Initialized
INFO - 2023-02-07 10:26:47 --> Output Class Initialized
INFO - 2023-02-07 10:26:47 --> Security Class Initialized
DEBUG - 2023-02-07 10:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:26:47 --> Input Class Initialized
INFO - 2023-02-07 10:26:47 --> Language Class Initialized
INFO - 2023-02-07 10:26:47 --> Language Class Initialized
INFO - 2023-02-07 10:26:47 --> Config Class Initialized
INFO - 2023-02-07 10:26:47 --> Loader Class Initialized
INFO - 2023-02-07 10:26:47 --> Helper loaded: url_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: file_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: form_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: my_helper
INFO - 2023-02-07 10:26:47 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:26:47 --> Controller Class Initialized
INFO - 2023-02-07 10:26:47 --> Config Class Initialized
INFO - 2023-02-07 10:26:47 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:26:47 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:26:47 --> Utf8 Class Initialized
INFO - 2023-02-07 10:26:47 --> URI Class Initialized
INFO - 2023-02-07 10:26:47 --> Router Class Initialized
INFO - 2023-02-07 10:26:47 --> Output Class Initialized
INFO - 2023-02-07 10:26:47 --> Security Class Initialized
DEBUG - 2023-02-07 10:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:26:47 --> Input Class Initialized
INFO - 2023-02-07 10:26:47 --> Language Class Initialized
INFO - 2023-02-07 10:26:47 --> Language Class Initialized
INFO - 2023-02-07 10:26:47 --> Config Class Initialized
INFO - 2023-02-07 10:26:47 --> Loader Class Initialized
INFO - 2023-02-07 10:26:47 --> Helper loaded: url_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: file_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: form_helper
INFO - 2023-02-07 10:26:47 --> Helper loaded: my_helper
INFO - 2023-02-07 10:26:47 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:26:47 --> Controller Class Initialized
DEBUG - 2023-02-07 10:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/login/views/login.php
DEBUG - 2023-02-07 10:26:47 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:26:47 --> Final output sent to browser
DEBUG - 2023-02-07 10:26:47 --> Total execution time: 0.0289
INFO - 2023-02-07 10:28:28 --> Config Class Initialized
INFO - 2023-02-07 10:28:28 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:28 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:28 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:28 --> URI Class Initialized
INFO - 2023-02-07 10:28:28 --> Router Class Initialized
INFO - 2023-02-07 10:28:28 --> Output Class Initialized
INFO - 2023-02-07 10:28:28 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:28 --> Input Class Initialized
INFO - 2023-02-07 10:28:28 --> Language Class Initialized
INFO - 2023-02-07 10:28:28 --> Language Class Initialized
INFO - 2023-02-07 10:28:28 --> Config Class Initialized
INFO - 2023-02-07 10:28:28 --> Loader Class Initialized
INFO - 2023-02-07 10:28:28 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:28 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:28 --> Controller Class Initialized
INFO - 2023-02-07 10:28:28 --> Helper loaded: cookie_helper
INFO - 2023-02-07 10:28:28 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:28 --> Total execution time: 0.0335
INFO - 2023-02-07 10:28:28 --> Config Class Initialized
INFO - 2023-02-07 10:28:28 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:28 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:28 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:28 --> URI Class Initialized
INFO - 2023-02-07 10:28:28 --> Router Class Initialized
INFO - 2023-02-07 10:28:28 --> Output Class Initialized
INFO - 2023-02-07 10:28:28 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:28 --> Input Class Initialized
INFO - 2023-02-07 10:28:28 --> Language Class Initialized
INFO - 2023-02-07 10:28:28 --> Language Class Initialized
INFO - 2023-02-07 10:28:28 --> Config Class Initialized
INFO - 2023-02-07 10:28:28 --> Loader Class Initialized
INFO - 2023-02-07 10:28:28 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:28 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:28 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:28 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/home/views/v_home_guru.php
DEBUG - 2023-02-07 10:28:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:28 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:28 --> Total execution time: 0.0454
INFO - 2023-02-07 10:28:30 --> Config Class Initialized
INFO - 2023-02-07 10:28:30 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:30 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:30 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:30 --> URI Class Initialized
INFO - 2023-02-07 10:28:30 --> Router Class Initialized
INFO - 2023-02-07 10:28:30 --> Output Class Initialized
INFO - 2023-02-07 10:28:30 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:30 --> Input Class Initialized
INFO - 2023-02-07 10:28:30 --> Language Class Initialized
INFO - 2023-02-07 10:28:30 --> Language Class Initialized
INFO - 2023-02-07 10:28:30 --> Config Class Initialized
INFO - 2023-02-07 10:28:30 --> Loader Class Initialized
INFO - 2023-02-07 10:28:30 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:30 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:30 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:30 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:30 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:30 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:30 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:30 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:30 --> Total execution time: 0.0365
INFO - 2023-02-07 10:28:38 --> Config Class Initialized
INFO - 2023-02-07 10:28:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:38 --> URI Class Initialized
INFO - 2023-02-07 10:28:38 --> Router Class Initialized
INFO - 2023-02-07 10:28:38 --> Output Class Initialized
INFO - 2023-02-07 10:28:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:38 --> Input Class Initialized
INFO - 2023-02-07 10:28:38 --> Language Class Initialized
INFO - 2023-02-07 10:28:38 --> Language Class Initialized
INFO - 2023-02-07 10:28:38 --> Config Class Initialized
INFO - 2023-02-07 10:28:38 --> Loader Class Initialized
INFO - 2023-02-07 10:28:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:38 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 10:28:38 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:38 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:38 --> Total execution time: 0.0457
INFO - 2023-02-07 10:28:38 --> Config Class Initialized
INFO - 2023-02-07 10:28:38 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:38 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:38 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:38 --> URI Class Initialized
INFO - 2023-02-07 10:28:38 --> Router Class Initialized
INFO - 2023-02-07 10:28:38 --> Output Class Initialized
INFO - 2023-02-07 10:28:38 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:38 --> Input Class Initialized
INFO - 2023-02-07 10:28:38 --> Language Class Initialized
INFO - 2023-02-07 10:28:38 --> Language Class Initialized
INFO - 2023-02-07 10:28:38 --> Config Class Initialized
INFO - 2023-02-07 10:28:38 --> Loader Class Initialized
INFO - 2023-02-07 10:28:38 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:38 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:38 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:38 --> Controller Class Initialized
INFO - 2023-02-07 10:28:40 --> Config Class Initialized
INFO - 2023-02-07 10:28:40 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:40 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:40 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:40 --> URI Class Initialized
INFO - 2023-02-07 10:28:40 --> Router Class Initialized
INFO - 2023-02-07 10:28:40 --> Output Class Initialized
INFO - 2023-02-07 10:28:40 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:40 --> Input Class Initialized
INFO - 2023-02-07 10:28:40 --> Language Class Initialized
INFO - 2023-02-07 10:28:40 --> Language Class Initialized
INFO - 2023-02-07 10:28:40 --> Config Class Initialized
INFO - 2023-02-07 10:28:40 --> Loader Class Initialized
INFO - 2023-02-07 10:28:40 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:40 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:40 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:40 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:40 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:40 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:40 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:40 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:40 --> Total execution time: 0.0260
INFO - 2023-02-07 10:28:41 --> Config Class Initialized
INFO - 2023-02-07 10:28:41 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:41 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:41 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:41 --> URI Class Initialized
INFO - 2023-02-07 10:28:41 --> Router Class Initialized
INFO - 2023-02-07 10:28:41 --> Output Class Initialized
INFO - 2023-02-07 10:28:41 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:41 --> Input Class Initialized
INFO - 2023-02-07 10:28:41 --> Language Class Initialized
INFO - 2023-02-07 10:28:41 --> Language Class Initialized
INFO - 2023-02-07 10:28:41 --> Config Class Initialized
INFO - 2023-02-07 10:28:41 --> Loader Class Initialized
INFO - 2023-02-07 10:28:41 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:41 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:41 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_icb/views/list.php
DEBUG - 2023-02-07 10:28:41 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:41 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:41 --> Total execution time: 0.0379
INFO - 2023-02-07 10:28:41 --> Config Class Initialized
INFO - 2023-02-07 10:28:41 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:41 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:41 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:41 --> URI Class Initialized
INFO - 2023-02-07 10:28:41 --> Router Class Initialized
INFO - 2023-02-07 10:28:41 --> Output Class Initialized
INFO - 2023-02-07 10:28:41 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:41 --> Input Class Initialized
INFO - 2023-02-07 10:28:41 --> Language Class Initialized
INFO - 2023-02-07 10:28:41 --> Language Class Initialized
INFO - 2023-02-07 10:28:41 --> Config Class Initialized
INFO - 2023-02-07 10:28:41 --> Loader Class Initialized
INFO - 2023-02-07 10:28:41 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:41 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:41 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:41 --> Controller Class Initialized
INFO - 2023-02-07 10:28:42 --> Config Class Initialized
INFO - 2023-02-07 10:28:42 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:42 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:42 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:42 --> URI Class Initialized
INFO - 2023-02-07 10:28:42 --> Router Class Initialized
INFO - 2023-02-07 10:28:42 --> Output Class Initialized
INFO - 2023-02-07 10:28:42 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:42 --> Input Class Initialized
INFO - 2023-02-07 10:28:42 --> Language Class Initialized
INFO - 2023-02-07 10:28:42 --> Language Class Initialized
INFO - 2023-02-07 10:28:42 --> Config Class Initialized
INFO - 2023-02-07 10:28:42 --> Loader Class Initialized
INFO - 2023-02-07 10:28:42 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:42 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:42 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:42 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:42 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:42 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:42 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:42 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:42 --> Total execution time: 0.0464
INFO - 2023-02-07 10:28:43 --> Config Class Initialized
INFO - 2023-02-07 10:28:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:43 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:43 --> URI Class Initialized
INFO - 2023-02-07 10:28:43 --> Router Class Initialized
INFO - 2023-02-07 10:28:43 --> Output Class Initialized
INFO - 2023-02-07 10:28:43 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:43 --> Input Class Initialized
INFO - 2023-02-07 10:28:43 --> Language Class Initialized
INFO - 2023-02-07 10:28:43 --> Language Class Initialized
INFO - 2023-02-07 10:28:43 --> Config Class Initialized
INFO - 2023-02-07 10:28:43 --> Loader Class Initialized
INFO - 2023-02-07 10:28:43 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:43 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_pss/views/list.php
DEBUG - 2023-02-07 10:28:43 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:43 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:43 --> Total execution time: 0.0732
INFO - 2023-02-07 10:28:43 --> Config Class Initialized
INFO - 2023-02-07 10:28:43 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:43 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:43 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:43 --> URI Class Initialized
INFO - 2023-02-07 10:28:43 --> Router Class Initialized
INFO - 2023-02-07 10:28:43 --> Output Class Initialized
INFO - 2023-02-07 10:28:43 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:43 --> Input Class Initialized
INFO - 2023-02-07 10:28:43 --> Language Class Initialized
INFO - 2023-02-07 10:28:43 --> Language Class Initialized
INFO - 2023-02-07 10:28:43 --> Config Class Initialized
INFO - 2023-02-07 10:28:43 --> Loader Class Initialized
INFO - 2023-02-07 10:28:43 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:43 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:43 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:43 --> Controller Class Initialized
INFO - 2023-02-07 10:28:46 --> Config Class Initialized
INFO - 2023-02-07 10:28:46 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:46 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:46 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:46 --> URI Class Initialized
INFO - 2023-02-07 10:28:46 --> Router Class Initialized
INFO - 2023-02-07 10:28:46 --> Output Class Initialized
INFO - 2023-02-07 10:28:46 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:46 --> Input Class Initialized
INFO - 2023-02-07 10:28:46 --> Language Class Initialized
INFO - 2023-02-07 10:28:46 --> Language Class Initialized
INFO - 2023-02-07 10:28:46 --> Config Class Initialized
INFO - 2023-02-07 10:28:46 --> Loader Class Initialized
INFO - 2023-02-07 10:28:46 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:46 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:46 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:46 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:46 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:46 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:46 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:46 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:46 --> Total execution time: 0.0484
INFO - 2023-02-07 10:28:48 --> Config Class Initialized
INFO - 2023-02-07 10:28:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:48 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:48 --> URI Class Initialized
INFO - 2023-02-07 10:28:48 --> Router Class Initialized
INFO - 2023-02-07 10:28:48 --> Output Class Initialized
INFO - 2023-02-07 10:28:48 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:48 --> Input Class Initialized
INFO - 2023-02-07 10:28:48 --> Language Class Initialized
INFO - 2023-02-07 10:28:48 --> Language Class Initialized
INFO - 2023-02-07 10:28:48 --> Config Class Initialized
INFO - 2023-02-07 10:28:48 --> Loader Class Initialized
INFO - 2023-02-07 10:28:48 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:48 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:48 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-02-07 10:28:48 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:48 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:48 --> Total execution time: 0.0796
INFO - 2023-02-07 10:28:48 --> Config Class Initialized
INFO - 2023-02-07 10:28:48 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:48 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:48 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:48 --> URI Class Initialized
INFO - 2023-02-07 10:28:48 --> Router Class Initialized
INFO - 2023-02-07 10:28:48 --> Output Class Initialized
INFO - 2023-02-07 10:28:48 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:48 --> Input Class Initialized
INFO - 2023-02-07 10:28:48 --> Language Class Initialized
INFO - 2023-02-07 10:28:48 --> Language Class Initialized
INFO - 2023-02-07 10:28:48 --> Config Class Initialized
INFO - 2023-02-07 10:28:48 --> Loader Class Initialized
INFO - 2023-02-07 10:28:48 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:48 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:48 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:48 --> Controller Class Initialized
INFO - 2023-02-07 10:28:49 --> Config Class Initialized
INFO - 2023-02-07 10:28:49 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:49 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:49 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:49 --> URI Class Initialized
INFO - 2023-02-07 10:28:49 --> Router Class Initialized
INFO - 2023-02-07 10:28:49 --> Output Class Initialized
INFO - 2023-02-07 10:28:49 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:49 --> Input Class Initialized
INFO - 2023-02-07 10:28:49 --> Language Class Initialized
INFO - 2023-02-07 10:28:49 --> Language Class Initialized
INFO - 2023-02-07 10:28:49 --> Config Class Initialized
INFO - 2023-02-07 10:28:49 --> Loader Class Initialized
INFO - 2023-02-07 10:28:49 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:49 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:49 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:49 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:49 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:49 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:49 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:49 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:49 --> Total execution time: 0.0381
INFO - 2023-02-07 10:28:50 --> Config Class Initialized
INFO - 2023-02-07 10:28:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:50 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:50 --> URI Class Initialized
INFO - 2023-02-07 10:28:50 --> Router Class Initialized
INFO - 2023-02-07 10:28:50 --> Output Class Initialized
INFO - 2023-02-07 10:28:50 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:50 --> Input Class Initialized
INFO - 2023-02-07 10:28:50 --> Language Class Initialized
INFO - 2023-02-07 10:28:50 --> Language Class Initialized
INFO - 2023-02-07 10:28:50 --> Config Class Initialized
INFO - 2023-02-07 10:28:50 --> Loader Class Initialized
INFO - 2023-02-07 10:28:50 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:50 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_la/views/list.php
DEBUG - 2023-02-07 10:28:50 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:50 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:50 --> Total execution time: 0.0420
INFO - 2023-02-07 10:28:50 --> Config Class Initialized
INFO - 2023-02-07 10:28:50 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:50 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:50 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:50 --> URI Class Initialized
INFO - 2023-02-07 10:28:50 --> Router Class Initialized
INFO - 2023-02-07 10:28:50 --> Output Class Initialized
INFO - 2023-02-07 10:28:50 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:50 --> Input Class Initialized
INFO - 2023-02-07 10:28:50 --> Language Class Initialized
INFO - 2023-02-07 10:28:50 --> Language Class Initialized
INFO - 2023-02-07 10:28:50 --> Config Class Initialized
INFO - 2023-02-07 10:28:50 --> Loader Class Initialized
INFO - 2023-02-07 10:28:50 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:50 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:50 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:50 --> Controller Class Initialized
INFO - 2023-02-07 10:28:51 --> Config Class Initialized
INFO - 2023-02-07 10:28:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:51 --> URI Class Initialized
INFO - 2023-02-07 10:28:51 --> Router Class Initialized
INFO - 2023-02-07 10:28:51 --> Output Class Initialized
INFO - 2023-02-07 10:28:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:51 --> Input Class Initialized
INFO - 2023-02-07 10:28:51 --> Language Class Initialized
INFO - 2023-02-07 10:28:51 --> Language Class Initialized
INFO - 2023-02-07 10:28:51 --> Config Class Initialized
INFO - 2023-02-07 10:28:51 --> Loader Class Initialized
INFO - 2023-02-07 10:28:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:51 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-02-07 10:28:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:51 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:51 --> Total execution time: 0.0260
INFO - 2023-02-07 10:28:55 --> Config Class Initialized
INFO - 2023-02-07 10:28:55 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:28:55 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:28:55 --> Utf8 Class Initialized
INFO - 2023-02-07 10:28:55 --> URI Class Initialized
INFO - 2023-02-07 10:28:55 --> Router Class Initialized
INFO - 2023-02-07 10:28:55 --> Output Class Initialized
INFO - 2023-02-07 10:28:55 --> Security Class Initialized
DEBUG - 2023-02-07 10:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:28:55 --> Input Class Initialized
INFO - 2023-02-07 10:28:55 --> Language Class Initialized
INFO - 2023-02-07 10:28:55 --> Language Class Initialized
INFO - 2023-02-07 10:28:55 --> Config Class Initialized
INFO - 2023-02-07 10:28:55 --> Loader Class Initialized
INFO - 2023-02-07 10:28:55 --> Helper loaded: url_helper
INFO - 2023-02-07 10:28:55 --> Helper loaded: file_helper
INFO - 2023-02-07 10:28:55 --> Helper loaded: form_helper
INFO - 2023-02-07 10:28:55 --> Helper loaded: my_helper
INFO - 2023-02-07 10:28:55 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:28:55 --> Controller Class Initialized
DEBUG - 2023-02-07 10:28:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-02-07 10:28:55 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:28:55 --> Final output sent to browser
DEBUG - 2023-02-07 10:28:55 --> Total execution time: 0.0766
INFO - 2023-02-07 10:31:28 --> Config Class Initialized
INFO - 2023-02-07 10:31:28 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:31:28 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:31:28 --> Utf8 Class Initialized
INFO - 2023-02-07 10:31:28 --> URI Class Initialized
INFO - 2023-02-07 10:31:28 --> Router Class Initialized
INFO - 2023-02-07 10:31:28 --> Output Class Initialized
INFO - 2023-02-07 10:31:28 --> Security Class Initialized
DEBUG - 2023-02-07 10:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:31:28 --> Input Class Initialized
INFO - 2023-02-07 10:31:28 --> Language Class Initialized
INFO - 2023-02-07 10:31:28 --> Language Class Initialized
INFO - 2023-02-07 10:31:28 --> Config Class Initialized
INFO - 2023-02-07 10:31:28 --> Loader Class Initialized
INFO - 2023-02-07 10:31:28 --> Helper loaded: url_helper
INFO - 2023-02-07 10:31:28 --> Helper loaded: file_helper
INFO - 2023-02-07 10:31:28 --> Helper loaded: form_helper
INFO - 2023-02-07 10:31:28 --> Helper loaded: my_helper
INFO - 2023-02-07 10:31:28 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:31:28 --> Controller Class Initialized
DEBUG - 2023-02-07 10:31:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-02-07 10:31:28 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:31:28 --> Final output sent to browser
DEBUG - 2023-02-07 10:31:28 --> Total execution time: 0.1551
INFO - 2023-02-07 10:31:51 --> Config Class Initialized
INFO - 2023-02-07 10:31:51 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:31:51 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:31:51 --> Utf8 Class Initialized
INFO - 2023-02-07 10:31:51 --> URI Class Initialized
INFO - 2023-02-07 10:31:51 --> Router Class Initialized
INFO - 2023-02-07 10:31:51 --> Output Class Initialized
INFO - 2023-02-07 10:31:51 --> Security Class Initialized
DEBUG - 2023-02-07 10:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:31:51 --> Input Class Initialized
INFO - 2023-02-07 10:31:51 --> Language Class Initialized
INFO - 2023-02-07 10:31:51 --> Language Class Initialized
INFO - 2023-02-07 10:31:51 --> Config Class Initialized
INFO - 2023-02-07 10:31:51 --> Loader Class Initialized
INFO - 2023-02-07 10:31:51 --> Helper loaded: url_helper
INFO - 2023-02-07 10:31:51 --> Helper loaded: file_helper
INFO - 2023-02-07 10:31:51 --> Helper loaded: form_helper
INFO - 2023-02-07 10:31:51 --> Helper loaded: my_helper
INFO - 2023-02-07 10:31:51 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:31:51 --> Controller Class Initialized
DEBUG - 2023-02-07 10:31:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-02-07 10:31:51 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:31:51 --> Final output sent to browser
DEBUG - 2023-02-07 10:31:51 --> Total execution time: 0.0366
INFO - 2023-02-07 10:31:59 --> Config Class Initialized
INFO - 2023-02-07 10:31:59 --> Hooks Class Initialized
DEBUG - 2023-02-07 10:31:59 --> UTF-8 Support Enabled
INFO - 2023-02-07 10:31:59 --> Utf8 Class Initialized
INFO - 2023-02-07 10:31:59 --> URI Class Initialized
INFO - 2023-02-07 10:31:59 --> Router Class Initialized
INFO - 2023-02-07 10:31:59 --> Output Class Initialized
INFO - 2023-02-07 10:31:59 --> Security Class Initialized
DEBUG - 2023-02-07 10:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-02-07 10:31:59 --> Input Class Initialized
INFO - 2023-02-07 10:31:59 --> Language Class Initialized
INFO - 2023-02-07 10:31:59 --> Language Class Initialized
INFO - 2023-02-07 10:31:59 --> Config Class Initialized
INFO - 2023-02-07 10:31:59 --> Loader Class Initialized
INFO - 2023-02-07 10:31:59 --> Helper loaded: url_helper
INFO - 2023-02-07 10:31:59 --> Helper loaded: file_helper
INFO - 2023-02-07 10:31:59 --> Helper loaded: form_helper
INFO - 2023-02-07 10:31:59 --> Helper loaded: my_helper
INFO - 2023-02-07 10:31:59 --> Database Driver Class Initialized
DEBUG - 2023-02-07 10:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2023-02-07 10:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-02-07 10:31:59 --> Controller Class Initialized
DEBUG - 2023-02-07 10:31:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\modules/n_catatan/views/list.php
DEBUG - 2023-02-07 10:31:59 --> File loaded: C:\xampp\htdocs\myraportk13\application\views\template_utama.php
INFO - 2023-02-07 10:31:59 --> Final output sent to browser
DEBUG - 2023-02-07 10:31:59 --> Total execution time: 0.0413
