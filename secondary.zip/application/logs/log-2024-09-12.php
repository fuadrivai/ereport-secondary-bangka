<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-12 05:46:17 --> Config Class Initialized
INFO - 2024-09-12 05:46:17 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:17 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:17 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:17 --> URI Class Initialized
INFO - 2024-09-12 05:46:18 --> Router Class Initialized
INFO - 2024-09-12 05:46:18 --> Output Class Initialized
INFO - 2024-09-12 05:46:18 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:18 --> Input Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Config Class Initialized
INFO - 2024-09-12 05:46:18 --> Loader Class Initialized
INFO - 2024-09-12 05:46:18 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:18 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:18 --> Controller Class Initialized
INFO - 2024-09-12 05:46:18 --> Helper loaded: cookie_helper
INFO - 2024-09-12 05:46:18 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:18 --> Total execution time: 0.0737
INFO - 2024-09-12 05:46:18 --> Config Class Initialized
INFO - 2024-09-12 05:46:18 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:18 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:18 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:18 --> URI Class Initialized
INFO - 2024-09-12 05:46:18 --> Router Class Initialized
INFO - 2024-09-12 05:46:18 --> Output Class Initialized
INFO - 2024-09-12 05:46:18 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:18 --> Input Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Config Class Initialized
INFO - 2024-09-12 05:46:18 --> Loader Class Initialized
INFO - 2024-09-12 05:46:18 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:18 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:18 --> Controller Class Initialized
INFO - 2024-09-12 05:46:18 --> Helper loaded: cookie_helper
INFO - 2024-09-12 05:46:18 --> Config Class Initialized
INFO - 2024-09-12 05:46:18 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:18 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:18 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:18 --> URI Class Initialized
INFO - 2024-09-12 05:46:18 --> Router Class Initialized
INFO - 2024-09-12 05:46:18 --> Output Class Initialized
INFO - 2024-09-12 05:46:18 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:18 --> Input Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Language Class Initialized
INFO - 2024-09-12 05:46:18 --> Config Class Initialized
INFO - 2024-09-12 05:46:18 --> Loader Class Initialized
INFO - 2024-09-12 05:46:18 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:18 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:19 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:19 --> Controller Class Initialized
DEBUG - 2024-09-12 05:46:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 05:46:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 05:46:19 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:19 --> Total execution time: 0.0468
INFO - 2024-09-12 05:46:23 --> Config Class Initialized
INFO - 2024-09-12 05:46:23 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:23 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:23 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:23 --> URI Class Initialized
INFO - 2024-09-12 05:46:23 --> Router Class Initialized
INFO - 2024-09-12 05:46:23 --> Output Class Initialized
INFO - 2024-09-12 05:46:23 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:23 --> Input Class Initialized
INFO - 2024-09-12 05:46:23 --> Language Class Initialized
INFO - 2024-09-12 05:46:23 --> Language Class Initialized
INFO - 2024-09-12 05:46:23 --> Config Class Initialized
INFO - 2024-09-12 05:46:23 --> Loader Class Initialized
INFO - 2024-09-12 05:46:23 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:23 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:23 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:23 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:23 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:23 --> Controller Class Initialized
ERROR - 2024-09-12 05:46:23 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 05:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 05:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 05:46:27 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:27 --> Total execution time: 4.3199
INFO - 2024-09-12 05:46:28 --> Config Class Initialized
INFO - 2024-09-12 05:46:28 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:28 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:28 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:28 --> URI Class Initialized
INFO - 2024-09-12 05:46:28 --> Router Class Initialized
INFO - 2024-09-12 05:46:28 --> Output Class Initialized
INFO - 2024-09-12 05:46:28 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:28 --> Input Class Initialized
INFO - 2024-09-12 05:46:28 --> Language Class Initialized
INFO - 2024-09-12 05:46:28 --> Language Class Initialized
INFO - 2024-09-12 05:46:28 --> Config Class Initialized
INFO - 2024-09-12 05:46:28 --> Loader Class Initialized
INFO - 2024-09-12 05:46:28 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:28 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:28 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:28 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:28 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:28 --> Controller Class Initialized
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 05:46:28 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 05:46:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 05:46:31 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:31 --> Total execution time: 3.0104
INFO - 2024-09-12 05:46:31 --> Config Class Initialized
INFO - 2024-09-12 05:46:31 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:31 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:31 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:31 --> URI Class Initialized
INFO - 2024-09-12 05:46:31 --> Router Class Initialized
INFO - 2024-09-12 05:46:31 --> Output Class Initialized
INFO - 2024-09-12 05:46:31 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:31 --> Input Class Initialized
INFO - 2024-09-12 05:46:31 --> Language Class Initialized
INFO - 2024-09-12 05:46:31 --> Language Class Initialized
INFO - 2024-09-12 05:46:31 --> Config Class Initialized
INFO - 2024-09-12 05:46:31 --> Loader Class Initialized
INFO - 2024-09-12 05:46:31 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:31 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:31 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:31 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:31 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:31 --> Controller Class Initialized
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 05:46:31 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 05:46:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 05:46:33 --> Config Class Initialized
INFO - 2024-09-12 05:46:33 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:33 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:33 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:33 --> URI Class Initialized
INFO - 2024-09-12 05:46:33 --> Router Class Initialized
INFO - 2024-09-12 05:46:33 --> Output Class Initialized
INFO - 2024-09-12 05:46:33 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:33 --> Input Class Initialized
INFO - 2024-09-12 05:46:33 --> Language Class Initialized
INFO - 2024-09-12 05:46:33 --> Language Class Initialized
INFO - 2024-09-12 05:46:33 --> Config Class Initialized
INFO - 2024-09-12 05:46:33 --> Loader Class Initialized
INFO - 2024-09-12 05:46:33 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:33 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:33 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:33 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:33 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:34 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:34 --> Total execution time: 3.4048
INFO - 2024-09-12 05:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:34 --> Controller Class Initialized
DEBUG - 2024-09-12 05:46:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 05:46:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 05:46:34 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:34 --> Total execution time: 1.0908
INFO - 2024-09-12 05:46:35 --> Config Class Initialized
INFO - 2024-09-12 05:46:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:35 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:35 --> URI Class Initialized
INFO - 2024-09-12 05:46:35 --> Router Class Initialized
INFO - 2024-09-12 05:46:35 --> Output Class Initialized
INFO - 2024-09-12 05:46:35 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:35 --> Input Class Initialized
INFO - 2024-09-12 05:46:35 --> Language Class Initialized
INFO - 2024-09-12 05:46:35 --> Language Class Initialized
INFO - 2024-09-12 05:46:35 --> Config Class Initialized
INFO - 2024-09-12 05:46:35 --> Loader Class Initialized
INFO - 2024-09-12 05:46:35 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:35 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:35 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:35 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:35 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:35 --> Controller Class Initialized
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 05:46:35 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 05:46:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 05:46:38 --> Config Class Initialized
INFO - 2024-09-12 05:46:38 --> Hooks Class Initialized
DEBUG - 2024-09-12 05:46:38 --> UTF-8 Support Enabled
INFO - 2024-09-12 05:46:38 --> Utf8 Class Initialized
INFO - 2024-09-12 05:46:38 --> URI Class Initialized
INFO - 2024-09-12 05:46:38 --> Router Class Initialized
INFO - 2024-09-12 05:46:38 --> Output Class Initialized
INFO - 2024-09-12 05:46:38 --> Security Class Initialized
DEBUG - 2024-09-12 05:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 05:46:38 --> Input Class Initialized
INFO - 2024-09-12 05:46:38 --> Language Class Initialized
INFO - 2024-09-12 05:46:38 --> Language Class Initialized
INFO - 2024-09-12 05:46:38 --> Config Class Initialized
INFO - 2024-09-12 05:46:38 --> Loader Class Initialized
INFO - 2024-09-12 05:46:38 --> Helper loaded: url_helper
INFO - 2024-09-12 05:46:38 --> Helper loaded: file_helper
INFO - 2024-09-12 05:46:38 --> Helper loaded: form_helper
INFO - 2024-09-12 05:46:38 --> Helper loaded: my_helper
INFO - 2024-09-12 05:46:38 --> Database Driver Class Initialized
INFO - 2024-09-12 05:46:38 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:38 --> Total execution time: 3.3489
INFO - 2024-09-12 05:46:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 05:46:38 --> Controller Class Initialized
DEBUG - 2024-09-12 05:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 05:46:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 05:46:38 --> Final output sent to browser
DEBUG - 2024-09-12 05:46:38 --> Total execution time: 0.1217
INFO - 2024-09-12 09:17:25 --> Config Class Initialized
INFO - 2024-09-12 09:17:25 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:17:25 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:17:25 --> Utf8 Class Initialized
INFO - 2024-09-12 09:17:25 --> URI Class Initialized
INFO - 2024-09-12 09:17:25 --> Router Class Initialized
INFO - 2024-09-12 09:17:25 --> Output Class Initialized
INFO - 2024-09-12 09:17:25 --> Security Class Initialized
DEBUG - 2024-09-12 09:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:17:25 --> Input Class Initialized
INFO - 2024-09-12 09:17:25 --> Language Class Initialized
INFO - 2024-09-12 09:17:25 --> Language Class Initialized
INFO - 2024-09-12 09:17:25 --> Config Class Initialized
INFO - 2024-09-12 09:17:25 --> Loader Class Initialized
INFO - 2024-09-12 09:17:25 --> Helper loaded: url_helper
INFO - 2024-09-12 09:17:25 --> Helper loaded: file_helper
INFO - 2024-09-12 09:17:25 --> Helper loaded: form_helper
INFO - 2024-09-12 09:17:25 --> Helper loaded: my_helper
INFO - 2024-09-12 09:17:25 --> Database Driver Class Initialized
INFO - 2024-09-12 09:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:17:25 --> Controller Class Initialized
INFO - 2024-09-12 09:17:25 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:17:25 --> Final output sent to browser
DEBUG - 2024-09-12 09:17:25 --> Total execution time: 0.1004
INFO - 2024-09-12 09:17:26 --> Config Class Initialized
INFO - 2024-09-12 09:17:26 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:17:26 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:17:26 --> Utf8 Class Initialized
INFO - 2024-09-12 09:17:26 --> URI Class Initialized
INFO - 2024-09-12 09:17:26 --> Router Class Initialized
INFO - 2024-09-12 09:17:26 --> Output Class Initialized
INFO - 2024-09-12 09:17:26 --> Security Class Initialized
DEBUG - 2024-09-12 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:17:26 --> Input Class Initialized
INFO - 2024-09-12 09:17:26 --> Language Class Initialized
INFO - 2024-09-12 09:17:26 --> Language Class Initialized
INFO - 2024-09-12 09:17:26 --> Config Class Initialized
INFO - 2024-09-12 09:17:26 --> Loader Class Initialized
INFO - 2024-09-12 09:17:26 --> Helper loaded: url_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: file_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: form_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: my_helper
INFO - 2024-09-12 09:17:26 --> Database Driver Class Initialized
INFO - 2024-09-12 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:17:26 --> Controller Class Initialized
INFO - 2024-09-12 09:17:26 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:17:26 --> Config Class Initialized
INFO - 2024-09-12 09:17:26 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:17:26 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:17:26 --> Utf8 Class Initialized
INFO - 2024-09-12 09:17:26 --> URI Class Initialized
INFO - 2024-09-12 09:17:26 --> Router Class Initialized
INFO - 2024-09-12 09:17:26 --> Output Class Initialized
INFO - 2024-09-12 09:17:26 --> Security Class Initialized
DEBUG - 2024-09-12 09:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:17:26 --> Input Class Initialized
INFO - 2024-09-12 09:17:26 --> Language Class Initialized
INFO - 2024-09-12 09:17:26 --> Language Class Initialized
INFO - 2024-09-12 09:17:26 --> Config Class Initialized
INFO - 2024-09-12 09:17:26 --> Loader Class Initialized
INFO - 2024-09-12 09:17:26 --> Helper loaded: url_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: file_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: form_helper
INFO - 2024-09-12 09:17:26 --> Helper loaded: my_helper
INFO - 2024-09-12 09:17:26 --> Database Driver Class Initialized
INFO - 2024-09-12 09:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:17:26 --> Controller Class Initialized
DEBUG - 2024-09-12 09:17:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:17:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:17:26 --> Final output sent to browser
DEBUG - 2024-09-12 09:17:26 --> Total execution time: 0.0529
INFO - 2024-09-12 09:21:10 --> Config Class Initialized
INFO - 2024-09-12 09:21:10 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:10 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:10 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:10 --> URI Class Initialized
INFO - 2024-09-12 09:21:10 --> Router Class Initialized
INFO - 2024-09-12 09:21:10 --> Output Class Initialized
INFO - 2024-09-12 09:21:10 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:10 --> Input Class Initialized
INFO - 2024-09-12 09:21:10 --> Language Class Initialized
INFO - 2024-09-12 09:21:10 --> Language Class Initialized
INFO - 2024-09-12 09:21:10 --> Config Class Initialized
INFO - 2024-09-12 09:21:10 --> Loader Class Initialized
INFO - 2024-09-12 09:21:10 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:10 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:10 --> Controller Class Initialized
INFO - 2024-09-12 09:21:10 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:21:10 --> Final output sent to browser
DEBUG - 2024-09-12 09:21:10 --> Total execution time: 0.0696
INFO - 2024-09-12 09:21:10 --> Config Class Initialized
INFO - 2024-09-12 09:21:10 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:10 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:10 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:10 --> URI Class Initialized
INFO - 2024-09-12 09:21:10 --> Router Class Initialized
INFO - 2024-09-12 09:21:10 --> Output Class Initialized
INFO - 2024-09-12 09:21:10 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:10 --> Input Class Initialized
INFO - 2024-09-12 09:21:10 --> Language Class Initialized
INFO - 2024-09-12 09:21:10 --> Language Class Initialized
INFO - 2024-09-12 09:21:10 --> Config Class Initialized
INFO - 2024-09-12 09:21:10 --> Loader Class Initialized
INFO - 2024-09-12 09:21:10 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:10 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:10 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:10 --> Controller Class Initialized
INFO - 2024-09-12 09:21:10 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:21:10 --> Config Class Initialized
INFO - 2024-09-12 09:21:10 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:10 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:10 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:10 --> URI Class Initialized
INFO - 2024-09-12 09:21:10 --> Router Class Initialized
INFO - 2024-09-12 09:21:10 --> Output Class Initialized
INFO - 2024-09-12 09:21:10 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:10 --> Input Class Initialized
INFO - 2024-09-12 09:21:10 --> Language Class Initialized
INFO - 2024-09-12 09:21:11 --> Language Class Initialized
INFO - 2024-09-12 09:21:11 --> Config Class Initialized
INFO - 2024-09-12 09:21:11 --> Loader Class Initialized
INFO - 2024-09-12 09:21:11 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:11 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:11 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:11 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:11 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:11 --> Controller Class Initialized
DEBUG - 2024-09-12 09:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:21:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:21:11 --> Final output sent to browser
DEBUG - 2024-09-12 09:21:11 --> Total execution time: 0.0327
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:23 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:23 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:23 --> URI Class Initialized
INFO - 2024-09-12 09:21:23 --> Router Class Initialized
INFO - 2024-09-12 09:21:23 --> Output Class Initialized
INFO - 2024-09-12 09:21:23 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:23 --> Input Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Loader Class Initialized
INFO - 2024-09-12 09:21:23 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:23 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:23 --> Controller Class Initialized
INFO - 2024-09-12 09:21:23 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:21:23 --> Final output sent to browser
DEBUG - 2024-09-12 09:21:23 --> Total execution time: 0.1994
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:23 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:23 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:23 --> URI Class Initialized
INFO - 2024-09-12 09:21:23 --> Router Class Initialized
INFO - 2024-09-12 09:21:23 --> Output Class Initialized
INFO - 2024-09-12 09:21:23 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:23 --> Input Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Loader Class Initialized
INFO - 2024-09-12 09:21:23 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:23 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:23 --> Controller Class Initialized
INFO - 2024-09-12 09:21:23 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:21:23 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:21:23 --> Utf8 Class Initialized
INFO - 2024-09-12 09:21:23 --> URI Class Initialized
INFO - 2024-09-12 09:21:23 --> Router Class Initialized
INFO - 2024-09-12 09:21:23 --> Output Class Initialized
INFO - 2024-09-12 09:21:23 --> Security Class Initialized
DEBUG - 2024-09-12 09:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:21:23 --> Input Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Language Class Initialized
INFO - 2024-09-12 09:21:23 --> Config Class Initialized
INFO - 2024-09-12 09:21:23 --> Loader Class Initialized
INFO - 2024-09-12 09:21:23 --> Helper loaded: url_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: file_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: form_helper
INFO - 2024-09-12 09:21:23 --> Helper loaded: my_helper
INFO - 2024-09-12 09:21:23 --> Database Driver Class Initialized
INFO - 2024-09-12 09:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:21:23 --> Controller Class Initialized
DEBUG - 2024-09-12 09:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:21:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:21:23 --> Final output sent to browser
DEBUG - 2024-09-12 09:21:23 --> Total execution time: 0.0655
INFO - 2024-09-12 09:30:51 --> Config Class Initialized
INFO - 2024-09-12 09:30:51 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:30:51 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:30:51 --> Utf8 Class Initialized
INFO - 2024-09-12 09:30:51 --> URI Class Initialized
INFO - 2024-09-12 09:30:51 --> Router Class Initialized
INFO - 2024-09-12 09:30:51 --> Output Class Initialized
INFO - 2024-09-12 09:30:51 --> Security Class Initialized
DEBUG - 2024-09-12 09:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:30:51 --> Input Class Initialized
INFO - 2024-09-12 09:30:51 --> Language Class Initialized
INFO - 2024-09-12 09:30:51 --> Language Class Initialized
INFO - 2024-09-12 09:30:51 --> Config Class Initialized
INFO - 2024-09-12 09:30:51 --> Loader Class Initialized
INFO - 2024-09-12 09:30:51 --> Helper loaded: url_helper
INFO - 2024-09-12 09:30:51 --> Helper loaded: file_helper
INFO - 2024-09-12 09:30:51 --> Helper loaded: form_helper
INFO - 2024-09-12 09:30:51 --> Helper loaded: my_helper
INFO - 2024-09-12 09:30:51 --> Database Driver Class Initialized
INFO - 2024-09-12 09:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:30:51 --> Controller Class Initialized
INFO - 2024-09-12 09:30:51 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:30:51 --> Final output sent to browser
DEBUG - 2024-09-12 09:30:51 --> Total execution time: 0.1644
INFO - 2024-09-12 09:30:52 --> Config Class Initialized
INFO - 2024-09-12 09:30:52 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:30:52 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:30:52 --> Utf8 Class Initialized
INFO - 2024-09-12 09:30:52 --> URI Class Initialized
INFO - 2024-09-12 09:30:52 --> Router Class Initialized
INFO - 2024-09-12 09:30:52 --> Output Class Initialized
INFO - 2024-09-12 09:30:52 --> Security Class Initialized
DEBUG - 2024-09-12 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:30:52 --> Input Class Initialized
INFO - 2024-09-12 09:30:52 --> Language Class Initialized
INFO - 2024-09-12 09:30:52 --> Language Class Initialized
INFO - 2024-09-12 09:30:52 --> Config Class Initialized
INFO - 2024-09-12 09:30:52 --> Loader Class Initialized
INFO - 2024-09-12 09:30:52 --> Helper loaded: url_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: file_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: form_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: my_helper
INFO - 2024-09-12 09:30:52 --> Database Driver Class Initialized
INFO - 2024-09-12 09:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:30:52 --> Controller Class Initialized
INFO - 2024-09-12 09:30:52 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:30:52 --> Config Class Initialized
INFO - 2024-09-12 09:30:52 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:30:52 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:30:52 --> Utf8 Class Initialized
INFO - 2024-09-12 09:30:52 --> URI Class Initialized
INFO - 2024-09-12 09:30:52 --> Router Class Initialized
INFO - 2024-09-12 09:30:52 --> Output Class Initialized
INFO - 2024-09-12 09:30:52 --> Security Class Initialized
DEBUG - 2024-09-12 09:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:30:52 --> Input Class Initialized
INFO - 2024-09-12 09:30:52 --> Language Class Initialized
INFO - 2024-09-12 09:30:52 --> Language Class Initialized
INFO - 2024-09-12 09:30:52 --> Config Class Initialized
INFO - 2024-09-12 09:30:52 --> Loader Class Initialized
INFO - 2024-09-12 09:30:52 --> Helper loaded: url_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: file_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: form_helper
INFO - 2024-09-12 09:30:52 --> Helper loaded: my_helper
INFO - 2024-09-12 09:30:52 --> Database Driver Class Initialized
INFO - 2024-09-12 09:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:30:52 --> Controller Class Initialized
DEBUG - 2024-09-12 09:30:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:30:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:30:52 --> Final output sent to browser
DEBUG - 2024-09-12 09:30:52 --> Total execution time: 0.0937
INFO - 2024-09-12 09:31:33 --> Config Class Initialized
INFO - 2024-09-12 09:31:33 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:31:33 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:31:33 --> Utf8 Class Initialized
INFO - 2024-09-12 09:31:33 --> URI Class Initialized
INFO - 2024-09-12 09:31:33 --> Router Class Initialized
INFO - 2024-09-12 09:31:33 --> Output Class Initialized
INFO - 2024-09-12 09:31:33 --> Security Class Initialized
DEBUG - 2024-09-12 09:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:31:33 --> Input Class Initialized
INFO - 2024-09-12 09:31:33 --> Language Class Initialized
INFO - 2024-09-12 09:31:33 --> Language Class Initialized
INFO - 2024-09-12 09:31:33 --> Config Class Initialized
INFO - 2024-09-12 09:31:33 --> Loader Class Initialized
INFO - 2024-09-12 09:31:33 --> Helper loaded: url_helper
INFO - 2024-09-12 09:31:33 --> Helper loaded: file_helper
INFO - 2024-09-12 09:31:33 --> Helper loaded: form_helper
INFO - 2024-09-12 09:31:33 --> Helper loaded: my_helper
INFO - 2024-09-12 09:31:33 --> Database Driver Class Initialized
INFO - 2024-09-12 09:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:31:33 --> Controller Class Initialized
INFO - 2024-09-12 09:31:33 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:31:33 --> Final output sent to browser
DEBUG - 2024-09-12 09:31:33 --> Total execution time: 0.0664
INFO - 2024-09-12 09:31:34 --> Config Class Initialized
INFO - 2024-09-12 09:31:34 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:31:34 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:31:34 --> Utf8 Class Initialized
INFO - 2024-09-12 09:31:34 --> URI Class Initialized
INFO - 2024-09-12 09:31:34 --> Router Class Initialized
INFO - 2024-09-12 09:31:34 --> Output Class Initialized
INFO - 2024-09-12 09:31:34 --> Security Class Initialized
DEBUG - 2024-09-12 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:31:34 --> Input Class Initialized
INFO - 2024-09-12 09:31:34 --> Language Class Initialized
INFO - 2024-09-12 09:31:34 --> Language Class Initialized
INFO - 2024-09-12 09:31:34 --> Config Class Initialized
INFO - 2024-09-12 09:31:34 --> Loader Class Initialized
INFO - 2024-09-12 09:31:34 --> Helper loaded: url_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: file_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: form_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: my_helper
INFO - 2024-09-12 09:31:34 --> Database Driver Class Initialized
INFO - 2024-09-12 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:31:34 --> Controller Class Initialized
INFO - 2024-09-12 09:31:34 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:31:34 --> Config Class Initialized
INFO - 2024-09-12 09:31:34 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:31:34 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:31:34 --> Utf8 Class Initialized
INFO - 2024-09-12 09:31:34 --> URI Class Initialized
INFO - 2024-09-12 09:31:34 --> Router Class Initialized
INFO - 2024-09-12 09:31:34 --> Output Class Initialized
INFO - 2024-09-12 09:31:34 --> Security Class Initialized
DEBUG - 2024-09-12 09:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:31:34 --> Input Class Initialized
INFO - 2024-09-12 09:31:34 --> Language Class Initialized
INFO - 2024-09-12 09:31:34 --> Language Class Initialized
INFO - 2024-09-12 09:31:34 --> Config Class Initialized
INFO - 2024-09-12 09:31:34 --> Loader Class Initialized
INFO - 2024-09-12 09:31:34 --> Helper loaded: url_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: file_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: form_helper
INFO - 2024-09-12 09:31:34 --> Helper loaded: my_helper
INFO - 2024-09-12 09:31:34 --> Database Driver Class Initialized
INFO - 2024-09-12 09:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:31:34 --> Controller Class Initialized
DEBUG - 2024-09-12 09:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:31:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:31:34 --> Final output sent to browser
DEBUG - 2024-09-12 09:31:34 --> Total execution time: 0.0764
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:35 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:35 --> URI Class Initialized
INFO - 2024-09-12 09:45:35 --> Router Class Initialized
INFO - 2024-09-12 09:45:35 --> Output Class Initialized
INFO - 2024-09-12 09:45:35 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:35 --> Input Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Loader Class Initialized
INFO - 2024-09-12 09:45:35 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:35 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:35 --> Controller Class Initialized
INFO - 2024-09-12 09:45:35 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:45:35 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:35 --> Total execution time: 0.3045
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:35 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:35 --> URI Class Initialized
INFO - 2024-09-12 09:45:35 --> Router Class Initialized
INFO - 2024-09-12 09:45:35 --> Output Class Initialized
INFO - 2024-09-12 09:45:35 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:35 --> Input Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Loader Class Initialized
INFO - 2024-09-12 09:45:35 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:35 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:35 --> Controller Class Initialized
INFO - 2024-09-12 09:45:35 --> Helper loaded: cookie_helper
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:35 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:35 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:35 --> URI Class Initialized
INFO - 2024-09-12 09:45:35 --> Router Class Initialized
INFO - 2024-09-12 09:45:35 --> Output Class Initialized
INFO - 2024-09-12 09:45:35 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:35 --> Input Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Language Class Initialized
INFO - 2024-09-12 09:45:35 --> Config Class Initialized
INFO - 2024-09-12 09:45:35 --> Loader Class Initialized
INFO - 2024-09-12 09:45:35 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:35 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:35 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:35 --> Controller Class Initialized
DEBUG - 2024-09-12 09:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 09:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 09:45:35 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:35 --> Total execution time: 0.1140
INFO - 2024-09-12 09:45:38 --> Config Class Initialized
INFO - 2024-09-12 09:45:38 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:38 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:38 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:38 --> URI Class Initialized
INFO - 2024-09-12 09:45:38 --> Router Class Initialized
INFO - 2024-09-12 09:45:38 --> Output Class Initialized
INFO - 2024-09-12 09:45:38 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:38 --> Input Class Initialized
INFO - 2024-09-12 09:45:38 --> Language Class Initialized
INFO - 2024-09-12 09:45:38 --> Language Class Initialized
INFO - 2024-09-12 09:45:38 --> Config Class Initialized
INFO - 2024-09-12 09:45:38 --> Loader Class Initialized
INFO - 2024-09-12 09:45:38 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:38 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:38 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:38 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:38 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:38 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:38 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:41 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:41 --> Total execution time: 2.9284
INFO - 2024-09-12 09:45:41 --> Config Class Initialized
INFO - 2024-09-12 09:45:41 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:41 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:41 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:41 --> URI Class Initialized
INFO - 2024-09-12 09:45:41 --> Router Class Initialized
INFO - 2024-09-12 09:45:41 --> Output Class Initialized
INFO - 2024-09-12 09:45:41 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:41 --> Input Class Initialized
INFO - 2024-09-12 09:45:41 --> Language Class Initialized
INFO - 2024-09-12 09:45:41 --> Language Class Initialized
INFO - 2024-09-12 09:45:41 --> Config Class Initialized
INFO - 2024-09-12 09:45:41 --> Loader Class Initialized
INFO - 2024-09-12 09:45:41 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:41 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:41 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:41 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:41 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:41 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:41 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:44 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:44 --> Total execution time: 2.7429
INFO - 2024-09-12 09:45:44 --> Config Class Initialized
INFO - 2024-09-12 09:45:44 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:44 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:44 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:44 --> URI Class Initialized
INFO - 2024-09-12 09:45:44 --> Router Class Initialized
INFO - 2024-09-12 09:45:44 --> Output Class Initialized
INFO - 2024-09-12 09:45:44 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:44 --> Input Class Initialized
INFO - 2024-09-12 09:45:44 --> Language Class Initialized
INFO - 2024-09-12 09:45:44 --> Language Class Initialized
INFO - 2024-09-12 09:45:44 --> Config Class Initialized
INFO - 2024-09-12 09:45:44 --> Loader Class Initialized
INFO - 2024-09-12 09:45:44 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:44 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:44 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:44 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:44 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:44 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:44 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:47 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:47 --> Total execution time: 3.1076
INFO - 2024-09-12 09:45:47 --> Config Class Initialized
INFO - 2024-09-12 09:45:47 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:47 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:47 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:47 --> URI Class Initialized
INFO - 2024-09-12 09:45:47 --> Router Class Initialized
INFO - 2024-09-12 09:45:47 --> Output Class Initialized
INFO - 2024-09-12 09:45:47 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:47 --> Input Class Initialized
INFO - 2024-09-12 09:45:47 --> Language Class Initialized
INFO - 2024-09-12 09:45:47 --> Language Class Initialized
INFO - 2024-09-12 09:45:47 --> Config Class Initialized
INFO - 2024-09-12 09:45:47 --> Loader Class Initialized
INFO - 2024-09-12 09:45:47 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:47 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:47 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:47 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:47 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:47 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:47 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:48 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:50 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:50 --> Total execution time: 3.1644
INFO - 2024-09-12 09:45:51 --> Config Class Initialized
INFO - 2024-09-12 09:45:51 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:51 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:51 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:51 --> URI Class Initialized
INFO - 2024-09-12 09:45:51 --> Router Class Initialized
INFO - 2024-09-12 09:45:51 --> Output Class Initialized
INFO - 2024-09-12 09:45:51 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:51 --> Input Class Initialized
INFO - 2024-09-12 09:45:51 --> Language Class Initialized
INFO - 2024-09-12 09:45:51 --> Language Class Initialized
INFO - 2024-09-12 09:45:51 --> Config Class Initialized
INFO - 2024-09-12 09:45:51 --> Loader Class Initialized
INFO - 2024-09-12 09:45:51 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:51 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:51 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:51 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:51 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:51 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:51 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:54 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:54 --> Total execution time: 3.1786
INFO - 2024-09-12 09:45:54 --> Config Class Initialized
INFO - 2024-09-12 09:45:54 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:54 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:54 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:54 --> URI Class Initialized
INFO - 2024-09-12 09:45:54 --> Router Class Initialized
INFO - 2024-09-12 09:45:54 --> Output Class Initialized
INFO - 2024-09-12 09:45:54 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:54 --> Input Class Initialized
INFO - 2024-09-12 09:45:54 --> Language Class Initialized
INFO - 2024-09-12 09:45:54 --> Language Class Initialized
INFO - 2024-09-12 09:45:54 --> Config Class Initialized
INFO - 2024-09-12 09:45:54 --> Loader Class Initialized
INFO - 2024-09-12 09:45:54 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:54 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:54 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:54 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:54 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:54 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:45:57 --> Final output sent to browser
DEBUG - 2024-09-12 09:45:57 --> Total execution time: 3.0839
INFO - 2024-09-12 09:45:57 --> Config Class Initialized
INFO - 2024-09-12 09:45:57 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:45:57 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:45:57 --> Utf8 Class Initialized
INFO - 2024-09-12 09:45:57 --> URI Class Initialized
INFO - 2024-09-12 09:45:57 --> Router Class Initialized
INFO - 2024-09-12 09:45:57 --> Output Class Initialized
INFO - 2024-09-12 09:45:57 --> Security Class Initialized
DEBUG - 2024-09-12 09:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:45:57 --> Input Class Initialized
INFO - 2024-09-12 09:45:57 --> Language Class Initialized
INFO - 2024-09-12 09:45:57 --> Language Class Initialized
INFO - 2024-09-12 09:45:57 --> Config Class Initialized
INFO - 2024-09-12 09:45:57 --> Loader Class Initialized
INFO - 2024-09-12 09:45:57 --> Helper loaded: url_helper
INFO - 2024-09-12 09:45:57 --> Helper loaded: file_helper
INFO - 2024-09-12 09:45:57 --> Helper loaded: form_helper
INFO - 2024-09-12 09:45:57 --> Helper loaded: my_helper
INFO - 2024-09-12 09:45:57 --> Database Driver Class Initialized
INFO - 2024-09-12 09:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:45:57 --> Controller Class Initialized
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:45:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:45:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:01 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:01 --> Total execution time: 3.2964
INFO - 2024-09-12 09:46:01 --> Config Class Initialized
INFO - 2024-09-12 09:46:01 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:01 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:01 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:01 --> URI Class Initialized
INFO - 2024-09-12 09:46:01 --> Router Class Initialized
INFO - 2024-09-12 09:46:01 --> Output Class Initialized
INFO - 2024-09-12 09:46:01 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:01 --> Input Class Initialized
INFO - 2024-09-12 09:46:01 --> Language Class Initialized
INFO - 2024-09-12 09:46:01 --> Language Class Initialized
INFO - 2024-09-12 09:46:01 --> Config Class Initialized
INFO - 2024-09-12 09:46:01 --> Loader Class Initialized
INFO - 2024-09-12 09:46:01 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:01 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:01 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:01 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:01 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:01 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:01 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:01 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:05 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:05 --> Total execution time: 4.2260
INFO - 2024-09-12 09:46:05 --> Config Class Initialized
INFO - 2024-09-12 09:46:05 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:05 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:05 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:05 --> URI Class Initialized
INFO - 2024-09-12 09:46:05 --> Router Class Initialized
INFO - 2024-09-12 09:46:05 --> Output Class Initialized
INFO - 2024-09-12 09:46:05 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:05 --> Input Class Initialized
INFO - 2024-09-12 09:46:05 --> Language Class Initialized
INFO - 2024-09-12 09:46:05 --> Language Class Initialized
INFO - 2024-09-12 09:46:05 --> Config Class Initialized
INFO - 2024-09-12 09:46:05 --> Loader Class Initialized
INFO - 2024-09-12 09:46:05 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:05 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:05 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:05 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:05 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:05 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:05 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:08 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:08 --> Total execution time: 3.0590
INFO - 2024-09-12 09:46:08 --> Config Class Initialized
INFO - 2024-09-12 09:46:08 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:08 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:08 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:08 --> URI Class Initialized
INFO - 2024-09-12 09:46:08 --> Router Class Initialized
INFO - 2024-09-12 09:46:08 --> Output Class Initialized
INFO - 2024-09-12 09:46:08 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:08 --> Input Class Initialized
INFO - 2024-09-12 09:46:08 --> Language Class Initialized
INFO - 2024-09-12 09:46:08 --> Language Class Initialized
INFO - 2024-09-12 09:46:08 --> Config Class Initialized
INFO - 2024-09-12 09:46:08 --> Loader Class Initialized
INFO - 2024-09-12 09:46:09 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:09 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:09 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:09 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:09 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:09 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:09 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:12 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:12 --> Total execution time: 3.4327
INFO - 2024-09-12 09:46:12 --> Config Class Initialized
INFO - 2024-09-12 09:46:12 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:12 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:12 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:12 --> URI Class Initialized
INFO - 2024-09-12 09:46:12 --> Router Class Initialized
INFO - 2024-09-12 09:46:12 --> Output Class Initialized
INFO - 2024-09-12 09:46:12 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:12 --> Input Class Initialized
INFO - 2024-09-12 09:46:12 --> Language Class Initialized
INFO - 2024-09-12 09:46:12 --> Language Class Initialized
INFO - 2024-09-12 09:46:12 --> Config Class Initialized
INFO - 2024-09-12 09:46:12 --> Loader Class Initialized
INFO - 2024-09-12 09:46:12 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:12 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:12 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:12 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:12 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:12 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:12 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:17 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:17 --> Total execution time: 4.9812
INFO - 2024-09-12 09:46:17 --> Config Class Initialized
INFO - 2024-09-12 09:46:17 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:17 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:17 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:17 --> URI Class Initialized
INFO - 2024-09-12 09:46:17 --> Router Class Initialized
INFO - 2024-09-12 09:46:17 --> Output Class Initialized
INFO - 2024-09-12 09:46:17 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:17 --> Input Class Initialized
INFO - 2024-09-12 09:46:17 --> Language Class Initialized
INFO - 2024-09-12 09:46:17 --> Language Class Initialized
INFO - 2024-09-12 09:46:17 --> Config Class Initialized
INFO - 2024-09-12 09:46:17 --> Loader Class Initialized
INFO - 2024-09-12 09:46:17 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:17 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:17 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:17 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:17 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:17 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:21 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:21 --> Total execution time: 3.3797
INFO - 2024-09-12 09:46:21 --> Config Class Initialized
INFO - 2024-09-12 09:46:21 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:21 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:21 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:21 --> URI Class Initialized
INFO - 2024-09-12 09:46:21 --> Router Class Initialized
INFO - 2024-09-12 09:46:21 --> Output Class Initialized
INFO - 2024-09-12 09:46:21 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:21 --> Input Class Initialized
INFO - 2024-09-12 09:46:21 --> Language Class Initialized
INFO - 2024-09-12 09:46:21 --> Language Class Initialized
INFO - 2024-09-12 09:46:21 --> Config Class Initialized
INFO - 2024-09-12 09:46:21 --> Loader Class Initialized
INFO - 2024-09-12 09:46:21 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:21 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:21 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:21 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:21 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:21 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:21 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:24 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:24 --> Total execution time: 3.4366
INFO - 2024-09-12 09:46:24 --> Config Class Initialized
INFO - 2024-09-12 09:46:24 --> Hooks Class Initialized
DEBUG - 2024-09-12 09:46:24 --> UTF-8 Support Enabled
INFO - 2024-09-12 09:46:24 --> Utf8 Class Initialized
INFO - 2024-09-12 09:46:24 --> URI Class Initialized
INFO - 2024-09-12 09:46:24 --> Router Class Initialized
INFO - 2024-09-12 09:46:24 --> Output Class Initialized
INFO - 2024-09-12 09:46:24 --> Security Class Initialized
DEBUG - 2024-09-12 09:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 09:46:24 --> Input Class Initialized
INFO - 2024-09-12 09:46:24 --> Language Class Initialized
INFO - 2024-09-12 09:46:24 --> Language Class Initialized
INFO - 2024-09-12 09:46:24 --> Config Class Initialized
INFO - 2024-09-12 09:46:24 --> Loader Class Initialized
INFO - 2024-09-12 09:46:24 --> Helper loaded: url_helper
INFO - 2024-09-12 09:46:24 --> Helper loaded: file_helper
INFO - 2024-09-12 09:46:24 --> Helper loaded: form_helper
INFO - 2024-09-12 09:46:24 --> Helper loaded: my_helper
INFO - 2024-09-12 09:46:24 --> Database Driver Class Initialized
INFO - 2024-09-12 09:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 09:46:24 --> Controller Class Initialized
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 09:46:24 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 09:46:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 09:46:27 --> Final output sent to browser
DEBUG - 2024-09-12 09:46:27 --> Total execution time: 3.0462
INFO - 2024-09-12 11:13:43 --> Config Class Initialized
INFO - 2024-09-12 11:13:43 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:13:43 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:13:43 --> Utf8 Class Initialized
INFO - 2024-09-12 11:13:43 --> URI Class Initialized
INFO - 2024-09-12 11:13:43 --> Router Class Initialized
INFO - 2024-09-12 11:13:43 --> Output Class Initialized
INFO - 2024-09-12 11:13:43 --> Security Class Initialized
DEBUG - 2024-09-12 11:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:13:43 --> Input Class Initialized
INFO - 2024-09-12 11:13:43 --> Language Class Initialized
INFO - 2024-09-12 11:13:43 --> Language Class Initialized
INFO - 2024-09-12 11:13:43 --> Config Class Initialized
INFO - 2024-09-12 11:13:43 --> Loader Class Initialized
INFO - 2024-09-12 11:13:43 --> Helper loaded: url_helper
INFO - 2024-09-12 11:13:43 --> Helper loaded: file_helper
INFO - 2024-09-12 11:13:43 --> Helper loaded: form_helper
INFO - 2024-09-12 11:13:43 --> Helper loaded: my_helper
INFO - 2024-09-12 11:13:43 --> Database Driver Class Initialized
INFO - 2024-09-12 11:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:13:43 --> Controller Class Initialized
INFO - 2024-09-12 11:13:43 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:13:43 --> Final output sent to browser
DEBUG - 2024-09-12 11:13:43 --> Total execution time: 0.0641
INFO - 2024-09-12 11:13:44 --> Config Class Initialized
INFO - 2024-09-12 11:13:44 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:13:44 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:13:44 --> Utf8 Class Initialized
INFO - 2024-09-12 11:13:44 --> URI Class Initialized
INFO - 2024-09-12 11:13:44 --> Router Class Initialized
INFO - 2024-09-12 11:13:44 --> Output Class Initialized
INFO - 2024-09-12 11:13:44 --> Security Class Initialized
DEBUG - 2024-09-12 11:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:13:44 --> Input Class Initialized
INFO - 2024-09-12 11:13:44 --> Language Class Initialized
INFO - 2024-09-12 11:13:44 --> Language Class Initialized
INFO - 2024-09-12 11:13:44 --> Config Class Initialized
INFO - 2024-09-12 11:13:44 --> Loader Class Initialized
INFO - 2024-09-12 11:13:44 --> Helper loaded: url_helper
INFO - 2024-09-12 11:13:44 --> Helper loaded: file_helper
INFO - 2024-09-12 11:13:44 --> Helper loaded: form_helper
INFO - 2024-09-12 11:13:44 --> Helper loaded: my_helper
INFO - 2024-09-12 11:13:44 --> Database Driver Class Initialized
INFO - 2024-09-12 11:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:13:44 --> Controller Class Initialized
INFO - 2024-09-12 11:13:44 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:13:45 --> Config Class Initialized
INFO - 2024-09-12 11:13:45 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:13:45 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:13:45 --> Utf8 Class Initialized
INFO - 2024-09-12 11:13:45 --> URI Class Initialized
INFO - 2024-09-12 11:13:45 --> Router Class Initialized
INFO - 2024-09-12 11:13:45 --> Output Class Initialized
INFO - 2024-09-12 11:13:45 --> Security Class Initialized
DEBUG - 2024-09-12 11:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:13:45 --> Input Class Initialized
INFO - 2024-09-12 11:13:45 --> Language Class Initialized
INFO - 2024-09-12 11:13:45 --> Language Class Initialized
INFO - 2024-09-12 11:13:45 --> Config Class Initialized
INFO - 2024-09-12 11:13:45 --> Loader Class Initialized
INFO - 2024-09-12 11:13:45 --> Helper loaded: url_helper
INFO - 2024-09-12 11:13:45 --> Helper loaded: file_helper
INFO - 2024-09-12 11:13:45 --> Helper loaded: form_helper
INFO - 2024-09-12 11:13:45 --> Helper loaded: my_helper
INFO - 2024-09-12 11:13:45 --> Database Driver Class Initialized
INFO - 2024-09-12 11:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:13:45 --> Controller Class Initialized
DEBUG - 2024-09-12 11:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 11:13:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 11:13:45 --> Final output sent to browser
DEBUG - 2024-09-12 11:13:45 --> Total execution time: 0.0348
INFO - 2024-09-12 11:15:48 --> Config Class Initialized
INFO - 2024-09-12 11:15:48 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:48 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:48 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:48 --> URI Class Initialized
INFO - 2024-09-12 11:15:48 --> Router Class Initialized
INFO - 2024-09-12 11:15:48 --> Output Class Initialized
INFO - 2024-09-12 11:15:48 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:48 --> Input Class Initialized
INFO - 2024-09-12 11:15:48 --> Language Class Initialized
INFO - 2024-09-12 11:15:48 --> Language Class Initialized
INFO - 2024-09-12 11:15:48 --> Config Class Initialized
INFO - 2024-09-12 11:15:48 --> Loader Class Initialized
INFO - 2024-09-12 11:15:48 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:48 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:48 --> Controller Class Initialized
INFO - 2024-09-12 11:15:48 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:15:48 --> Final output sent to browser
DEBUG - 2024-09-12 11:15:48 --> Total execution time: 0.0381
INFO - 2024-09-12 11:15:48 --> Config Class Initialized
INFO - 2024-09-12 11:15:48 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:48 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:48 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:48 --> URI Class Initialized
INFO - 2024-09-12 11:15:48 --> Router Class Initialized
INFO - 2024-09-12 11:15:48 --> Output Class Initialized
INFO - 2024-09-12 11:15:48 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:48 --> Input Class Initialized
INFO - 2024-09-12 11:15:48 --> Language Class Initialized
INFO - 2024-09-12 11:15:48 --> Language Class Initialized
INFO - 2024-09-12 11:15:48 --> Config Class Initialized
INFO - 2024-09-12 11:15:48 --> Loader Class Initialized
INFO - 2024-09-12 11:15:48 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:48 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:48 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:48 --> Controller Class Initialized
INFO - 2024-09-12 11:15:48 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:15:48 --> Config Class Initialized
INFO - 2024-09-12 11:15:48 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:48 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:48 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:48 --> URI Class Initialized
INFO - 2024-09-12 11:15:49 --> Router Class Initialized
INFO - 2024-09-12 11:15:49 --> Output Class Initialized
INFO - 2024-09-12 11:15:49 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:49 --> Input Class Initialized
INFO - 2024-09-12 11:15:49 --> Language Class Initialized
INFO - 2024-09-12 11:15:49 --> Language Class Initialized
INFO - 2024-09-12 11:15:49 --> Config Class Initialized
INFO - 2024-09-12 11:15:49 --> Loader Class Initialized
INFO - 2024-09-12 11:15:49 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:49 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:49 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:49 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:49 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:49 --> Controller Class Initialized
DEBUG - 2024-09-12 11:15:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 11:15:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 11:15:49 --> Final output sent to browser
DEBUG - 2024-09-12 11:15:49 --> Total execution time: 0.0438
INFO - 2024-09-12 11:15:52 --> Config Class Initialized
INFO - 2024-09-12 11:15:52 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:52 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:52 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:52 --> URI Class Initialized
INFO - 2024-09-12 11:15:52 --> Router Class Initialized
INFO - 2024-09-12 11:15:52 --> Output Class Initialized
INFO - 2024-09-12 11:15:52 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:52 --> Input Class Initialized
INFO - 2024-09-12 11:15:52 --> Language Class Initialized
INFO - 2024-09-12 11:15:52 --> Language Class Initialized
INFO - 2024-09-12 11:15:52 --> Config Class Initialized
INFO - 2024-09-12 11:15:52 --> Loader Class Initialized
INFO - 2024-09-12 11:15:52 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:52 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:52 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:52 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:52 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:52 --> Controller Class Initialized
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:15:52 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:15:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:15:54 --> Config Class Initialized
INFO - 2024-09-12 11:15:54 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:54 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:54 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:54 --> URI Class Initialized
INFO - 2024-09-12 11:15:54 --> Router Class Initialized
INFO - 2024-09-12 11:15:54 --> Output Class Initialized
INFO - 2024-09-12 11:15:54 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:54 --> Input Class Initialized
INFO - 2024-09-12 11:15:54 --> Language Class Initialized
INFO - 2024-09-12 11:15:54 --> Language Class Initialized
INFO - 2024-09-12 11:15:54 --> Config Class Initialized
INFO - 2024-09-12 11:15:54 --> Loader Class Initialized
INFO - 2024-09-12 11:15:54 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:54 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:54 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:54 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:54 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:54 --> Final output sent to browser
DEBUG - 2024-09-12 11:15:54 --> Total execution time: 2.7076
INFO - 2024-09-12 11:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:54 --> Controller Class Initialized
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:15:54 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:15:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:15:57 --> Final output sent to browser
DEBUG - 2024-09-12 11:15:57 --> Total execution time: 2.9250
INFO - 2024-09-12 11:15:57 --> Config Class Initialized
INFO - 2024-09-12 11:15:57 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:15:57 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:15:57 --> Utf8 Class Initialized
INFO - 2024-09-12 11:15:57 --> URI Class Initialized
INFO - 2024-09-12 11:15:57 --> Router Class Initialized
INFO - 2024-09-12 11:15:57 --> Output Class Initialized
INFO - 2024-09-12 11:15:57 --> Security Class Initialized
DEBUG - 2024-09-12 11:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:15:57 --> Input Class Initialized
INFO - 2024-09-12 11:15:57 --> Language Class Initialized
INFO - 2024-09-12 11:15:57 --> Language Class Initialized
INFO - 2024-09-12 11:15:57 --> Config Class Initialized
INFO - 2024-09-12 11:15:57 --> Loader Class Initialized
INFO - 2024-09-12 11:15:57 --> Helper loaded: url_helper
INFO - 2024-09-12 11:15:57 --> Helper loaded: file_helper
INFO - 2024-09-12 11:15:57 --> Helper loaded: form_helper
INFO - 2024-09-12 11:15:57 --> Helper loaded: my_helper
INFO - 2024-09-12 11:15:57 --> Database Driver Class Initialized
INFO - 2024-09-12 11:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:15:57 --> Controller Class Initialized
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:15:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:15:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:00 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:00 --> Total execution time: 2.8839
INFO - 2024-09-12 11:16:00 --> Config Class Initialized
INFO - 2024-09-12 11:16:00 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:00 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:00 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:00 --> URI Class Initialized
INFO - 2024-09-12 11:16:00 --> Router Class Initialized
INFO - 2024-09-12 11:16:00 --> Output Class Initialized
INFO - 2024-09-12 11:16:00 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:00 --> Input Class Initialized
INFO - 2024-09-12 11:16:00 --> Language Class Initialized
INFO - 2024-09-12 11:16:00 --> Language Class Initialized
INFO - 2024-09-12 11:16:00 --> Config Class Initialized
INFO - 2024-09-12 11:16:00 --> Loader Class Initialized
INFO - 2024-09-12 11:16:00 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:00 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:00 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:00 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:00 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:00 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:00 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:00 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:04 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:04 --> Total execution time: 3.3142
INFO - 2024-09-12 11:16:04 --> Config Class Initialized
INFO - 2024-09-12 11:16:04 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:04 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:04 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:04 --> URI Class Initialized
INFO - 2024-09-12 11:16:04 --> Router Class Initialized
INFO - 2024-09-12 11:16:04 --> Output Class Initialized
INFO - 2024-09-12 11:16:04 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:04 --> Input Class Initialized
INFO - 2024-09-12 11:16:04 --> Language Class Initialized
INFO - 2024-09-12 11:16:04 --> Language Class Initialized
INFO - 2024-09-12 11:16:04 --> Config Class Initialized
INFO - 2024-09-12 11:16:04 --> Loader Class Initialized
INFO - 2024-09-12 11:16:04 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:04 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:04 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:04 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:04 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:04 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:04 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:07 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:07 --> Total execution time: 2.8679
INFO - 2024-09-12 11:16:07 --> Config Class Initialized
INFO - 2024-09-12 11:16:07 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:07 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:07 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:07 --> URI Class Initialized
INFO - 2024-09-12 11:16:07 --> Router Class Initialized
INFO - 2024-09-12 11:16:07 --> Output Class Initialized
INFO - 2024-09-12 11:16:07 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:07 --> Input Class Initialized
INFO - 2024-09-12 11:16:07 --> Language Class Initialized
INFO - 2024-09-12 11:16:07 --> Language Class Initialized
INFO - 2024-09-12 11:16:07 --> Config Class Initialized
INFO - 2024-09-12 11:16:07 --> Loader Class Initialized
INFO - 2024-09-12 11:16:07 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:07 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:07 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:07 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:07 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:07 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:07 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:10 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:10 --> Total execution time: 3.0269
INFO - 2024-09-12 11:16:10 --> Config Class Initialized
INFO - 2024-09-12 11:16:10 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:10 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:10 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:10 --> URI Class Initialized
INFO - 2024-09-12 11:16:10 --> Router Class Initialized
INFO - 2024-09-12 11:16:10 --> Output Class Initialized
INFO - 2024-09-12 11:16:10 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:10 --> Input Class Initialized
INFO - 2024-09-12 11:16:10 --> Language Class Initialized
INFO - 2024-09-12 11:16:10 --> Language Class Initialized
INFO - 2024-09-12 11:16:10 --> Config Class Initialized
INFO - 2024-09-12 11:16:10 --> Loader Class Initialized
INFO - 2024-09-12 11:16:10 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:10 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:10 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:10 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:10 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:10 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:10 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:10 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:13 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:13 --> Total execution time: 2.8661
INFO - 2024-09-12 11:16:13 --> Config Class Initialized
INFO - 2024-09-12 11:16:13 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:13 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:13 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:13 --> URI Class Initialized
INFO - 2024-09-12 11:16:13 --> Router Class Initialized
INFO - 2024-09-12 11:16:13 --> Output Class Initialized
INFO - 2024-09-12 11:16:13 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:13 --> Input Class Initialized
INFO - 2024-09-12 11:16:13 --> Language Class Initialized
INFO - 2024-09-12 11:16:13 --> Language Class Initialized
INFO - 2024-09-12 11:16:13 --> Config Class Initialized
INFO - 2024-09-12 11:16:13 --> Loader Class Initialized
INFO - 2024-09-12 11:16:13 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:13 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:13 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:13 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:13 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:13 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:16 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:16 --> Total execution time: 2.8114
INFO - 2024-09-12 11:16:16 --> Config Class Initialized
INFO - 2024-09-12 11:16:16 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:16:16 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:16:16 --> Utf8 Class Initialized
INFO - 2024-09-12 11:16:16 --> URI Class Initialized
INFO - 2024-09-12 11:16:16 --> Router Class Initialized
INFO - 2024-09-12 11:16:16 --> Output Class Initialized
INFO - 2024-09-12 11:16:16 --> Security Class Initialized
DEBUG - 2024-09-12 11:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:16:16 --> Input Class Initialized
INFO - 2024-09-12 11:16:16 --> Language Class Initialized
INFO - 2024-09-12 11:16:16 --> Language Class Initialized
INFO - 2024-09-12 11:16:16 --> Config Class Initialized
INFO - 2024-09-12 11:16:16 --> Loader Class Initialized
INFO - 2024-09-12 11:16:16 --> Helper loaded: url_helper
INFO - 2024-09-12 11:16:16 --> Helper loaded: file_helper
INFO - 2024-09-12 11:16:16 --> Helper loaded: form_helper
INFO - 2024-09-12 11:16:16 --> Helper loaded: my_helper
INFO - 2024-09-12 11:16:16 --> Database Driver Class Initialized
INFO - 2024-09-12 11:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:16:16 --> Controller Class Initialized
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-12 11:16:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-12 11:16:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-12 11:16:19 --> Final output sent to browser
DEBUG - 2024-09-12 11:16:19 --> Total execution time: 2.7249
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:17:03 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:17:03 --> Utf8 Class Initialized
INFO - 2024-09-12 11:17:03 --> URI Class Initialized
INFO - 2024-09-12 11:17:03 --> Router Class Initialized
INFO - 2024-09-12 11:17:03 --> Output Class Initialized
INFO - 2024-09-12 11:17:03 --> Security Class Initialized
DEBUG - 2024-09-12 11:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:17:03 --> Input Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Loader Class Initialized
INFO - 2024-09-12 11:17:03 --> Helper loaded: url_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: file_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: form_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: my_helper
INFO - 2024-09-12 11:17:03 --> Database Driver Class Initialized
INFO - 2024-09-12 11:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:17:03 --> Controller Class Initialized
INFO - 2024-09-12 11:17:03 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:17:03 --> Final output sent to browser
DEBUG - 2024-09-12 11:17:03 --> Total execution time: 0.0367
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:17:03 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:17:03 --> Utf8 Class Initialized
INFO - 2024-09-12 11:17:03 --> URI Class Initialized
INFO - 2024-09-12 11:17:03 --> Router Class Initialized
INFO - 2024-09-12 11:17:03 --> Output Class Initialized
INFO - 2024-09-12 11:17:03 --> Security Class Initialized
DEBUG - 2024-09-12 11:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:17:03 --> Input Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Loader Class Initialized
INFO - 2024-09-12 11:17:03 --> Helper loaded: url_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: file_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: form_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: my_helper
INFO - 2024-09-12 11:17:03 --> Database Driver Class Initialized
INFO - 2024-09-12 11:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:17:03 --> Controller Class Initialized
INFO - 2024-09-12 11:17:03 --> Helper loaded: cookie_helper
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Hooks Class Initialized
DEBUG - 2024-09-12 11:17:03 --> UTF-8 Support Enabled
INFO - 2024-09-12 11:17:03 --> Utf8 Class Initialized
INFO - 2024-09-12 11:17:03 --> URI Class Initialized
INFO - 2024-09-12 11:17:03 --> Router Class Initialized
INFO - 2024-09-12 11:17:03 --> Output Class Initialized
INFO - 2024-09-12 11:17:03 --> Security Class Initialized
DEBUG - 2024-09-12 11:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-12 11:17:03 --> Input Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Language Class Initialized
INFO - 2024-09-12 11:17:03 --> Config Class Initialized
INFO - 2024-09-12 11:17:03 --> Loader Class Initialized
INFO - 2024-09-12 11:17:03 --> Helper loaded: url_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: file_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: form_helper
INFO - 2024-09-12 11:17:03 --> Helper loaded: my_helper
INFO - 2024-09-12 11:17:03 --> Database Driver Class Initialized
INFO - 2024-09-12 11:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-12 11:17:03 --> Controller Class Initialized
DEBUG - 2024-09-12 11:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-12 11:17:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-12 11:17:03 --> Final output sent to browser
DEBUG - 2024-09-12 11:17:03 --> Total execution time: 0.0331
