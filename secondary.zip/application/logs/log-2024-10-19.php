<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-19 12:09:07 --> Config Class Initialized
INFO - 2024-10-19 12:09:07 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:09:07 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:09:07 --> Utf8 Class Initialized
INFO - 2024-10-19 12:09:07 --> URI Class Initialized
INFO - 2024-10-19 12:09:07 --> Router Class Initialized
INFO - 2024-10-19 12:09:07 --> Output Class Initialized
INFO - 2024-10-19 12:09:07 --> Security Class Initialized
DEBUG - 2024-10-19 12:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:09:07 --> Input Class Initialized
INFO - 2024-10-19 12:09:07 --> Language Class Initialized
INFO - 2024-10-19 12:09:07 --> Language Class Initialized
INFO - 2024-10-19 12:09:07 --> Config Class Initialized
INFO - 2024-10-19 12:09:07 --> Loader Class Initialized
INFO - 2024-10-19 12:09:07 --> Helper loaded: url_helper
INFO - 2024-10-19 12:09:07 --> Helper loaded: file_helper
INFO - 2024-10-19 12:09:07 --> Helper loaded: form_helper
INFO - 2024-10-19 12:09:07 --> Helper loaded: my_helper
INFO - 2024-10-19 12:09:07 --> Database Driver Class Initialized
INFO - 2024-10-19 12:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:09:07 --> Controller Class Initialized
INFO - 2024-10-19 12:09:07 --> Helper loaded: cookie_helper
INFO - 2024-10-19 12:09:07 --> Final output sent to browser
DEBUG - 2024-10-19 12:09:07 --> Total execution time: 0.0667
INFO - 2024-10-19 12:09:08 --> Config Class Initialized
INFO - 2024-10-19 12:09:08 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:09:08 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:09:08 --> Utf8 Class Initialized
INFO - 2024-10-19 12:09:08 --> URI Class Initialized
INFO - 2024-10-19 12:09:08 --> Router Class Initialized
INFO - 2024-10-19 12:09:08 --> Output Class Initialized
INFO - 2024-10-19 12:09:08 --> Security Class Initialized
DEBUG - 2024-10-19 12:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:09:08 --> Input Class Initialized
INFO - 2024-10-19 12:09:08 --> Language Class Initialized
INFO - 2024-10-19 12:09:08 --> Language Class Initialized
INFO - 2024-10-19 12:09:08 --> Config Class Initialized
INFO - 2024-10-19 12:09:08 --> Loader Class Initialized
INFO - 2024-10-19 12:09:08 --> Helper loaded: url_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: file_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: form_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: my_helper
INFO - 2024-10-19 12:09:08 --> Database Driver Class Initialized
INFO - 2024-10-19 12:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:09:08 --> Controller Class Initialized
INFO - 2024-10-19 12:09:08 --> Helper loaded: cookie_helper
INFO - 2024-10-19 12:09:08 --> Config Class Initialized
INFO - 2024-10-19 12:09:08 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:09:08 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:09:08 --> Utf8 Class Initialized
INFO - 2024-10-19 12:09:08 --> URI Class Initialized
INFO - 2024-10-19 12:09:08 --> Router Class Initialized
INFO - 2024-10-19 12:09:08 --> Output Class Initialized
INFO - 2024-10-19 12:09:08 --> Security Class Initialized
DEBUG - 2024-10-19 12:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:09:08 --> Input Class Initialized
INFO - 2024-10-19 12:09:08 --> Language Class Initialized
INFO - 2024-10-19 12:09:08 --> Language Class Initialized
INFO - 2024-10-19 12:09:08 --> Config Class Initialized
INFO - 2024-10-19 12:09:08 --> Loader Class Initialized
INFO - 2024-10-19 12:09:08 --> Helper loaded: url_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: file_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: form_helper
INFO - 2024-10-19 12:09:08 --> Helper loaded: my_helper
INFO - 2024-10-19 12:09:08 --> Database Driver Class Initialized
INFO - 2024-10-19 12:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:09:08 --> Controller Class Initialized
DEBUG - 2024-10-19 12:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-10-19 12:09:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-10-19 12:09:08 --> Final output sent to browser
DEBUG - 2024-10-19 12:09:08 --> Total execution time: 0.0643
INFO - 2024-10-19 12:09:12 --> Config Class Initialized
INFO - 2024-10-19 12:09:12 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:09:12 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:09:12 --> Utf8 Class Initialized
INFO - 2024-10-19 12:09:12 --> URI Class Initialized
INFO - 2024-10-19 12:09:12 --> Router Class Initialized
INFO - 2024-10-19 12:09:12 --> Output Class Initialized
INFO - 2024-10-19 12:09:12 --> Security Class Initialized
DEBUG - 2024-10-19 12:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:09:12 --> Input Class Initialized
INFO - 2024-10-19 12:09:12 --> Language Class Initialized
INFO - 2024-10-19 12:09:12 --> Language Class Initialized
INFO - 2024-10-19 12:09:12 --> Config Class Initialized
INFO - 2024-10-19 12:09:12 --> Loader Class Initialized
INFO - 2024-10-19 12:09:12 --> Helper loaded: url_helper
INFO - 2024-10-19 12:09:12 --> Helper loaded: file_helper
INFO - 2024-10-19 12:09:12 --> Helper loaded: form_helper
INFO - 2024-10-19 12:09:12 --> Helper loaded: my_helper
INFO - 2024-10-19 12:09:12 --> Database Driver Class Initialized
INFO - 2024-10-19 12:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:09:12 --> Controller Class Initialized
DEBUG - 2024-10-19 12:09:12 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-19 12:09:15 --> Final output sent to browser
DEBUG - 2024-10-19 12:09:15 --> Total execution time: 3.0310
INFO - 2024-10-19 12:10:42 --> Config Class Initialized
INFO - 2024-10-19 12:10:42 --> Hooks Class Initialized
DEBUG - 2024-10-19 12:10:42 --> UTF-8 Support Enabled
INFO - 2024-10-19 12:10:42 --> Utf8 Class Initialized
INFO - 2024-10-19 12:10:42 --> URI Class Initialized
INFO - 2024-10-19 12:10:42 --> Router Class Initialized
INFO - 2024-10-19 12:10:42 --> Output Class Initialized
INFO - 2024-10-19 12:10:42 --> Security Class Initialized
DEBUG - 2024-10-19 12:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-19 12:10:42 --> Input Class Initialized
INFO - 2024-10-19 12:10:42 --> Language Class Initialized
INFO - 2024-10-19 12:10:42 --> Language Class Initialized
INFO - 2024-10-19 12:10:42 --> Config Class Initialized
INFO - 2024-10-19 12:10:42 --> Loader Class Initialized
INFO - 2024-10-19 12:10:42 --> Helper loaded: url_helper
INFO - 2024-10-19 12:10:42 --> Helper loaded: file_helper
INFO - 2024-10-19 12:10:42 --> Helper loaded: form_helper
INFO - 2024-10-19 12:10:42 --> Helper loaded: my_helper
INFO - 2024-10-19 12:10:42 --> Database Driver Class Initialized
INFO - 2024-10-19 12:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-19 12:10:42 --> Controller Class Initialized
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1691
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1728
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1766
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1805
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1882
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1961
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2041
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2121
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2201
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2276
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-10-19 12:10:42 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-10-19 12:10:42 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-10-19 12:10:44 --> Final output sent to browser
DEBUG - 2024-10-19 12:10:44 --> Total execution time: 2.4400
