<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-12 09:43:32 --> Config Class Initialized
INFO - 2023-10-12 09:43:32 --> Hooks Class Initialized
DEBUG - 2023-10-12 09:43:32 --> UTF-8 Support Enabled
INFO - 2023-10-12 09:43:32 --> Utf8 Class Initialized
INFO - 2023-10-12 09:43:32 --> URI Class Initialized
INFO - 2023-10-12 09:43:32 --> Router Class Initialized
INFO - 2023-10-12 09:43:32 --> Output Class Initialized
INFO - 2023-10-12 09:43:32 --> Security Class Initialized
DEBUG - 2023-10-12 09:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 09:43:32 --> Input Class Initialized
INFO - 2023-10-12 09:43:32 --> Language Class Initialized
INFO - 2023-10-12 09:43:32 --> Language Class Initialized
INFO - 2023-10-12 09:43:32 --> Config Class Initialized
INFO - 2023-10-12 09:43:32 --> Loader Class Initialized
INFO - 2023-10-12 09:43:32 --> Helper loaded: url_helper
INFO - 2023-10-12 09:43:32 --> Helper loaded: file_helper
INFO - 2023-10-12 09:43:32 --> Helper loaded: form_helper
INFO - 2023-10-12 09:43:32 --> Helper loaded: my_helper
INFO - 2023-10-12 09:43:32 --> Database Driver Class Initialized
INFO - 2023-10-12 09:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 09:43:32 --> Controller Class Initialized
DEBUG - 2023-10-12 09:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-12 09:43:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-12 09:43:32 --> Final output sent to browser
DEBUG - 2023-10-12 09:43:32 --> Total execution time: 0.0534
INFO - 2023-10-12 11:06:16 --> Config Class Initialized
INFO - 2023-10-12 11:06:16 --> Hooks Class Initialized
DEBUG - 2023-10-12 11:06:16 --> UTF-8 Support Enabled
INFO - 2023-10-12 11:06:16 --> Utf8 Class Initialized
INFO - 2023-10-12 11:06:16 --> URI Class Initialized
INFO - 2023-10-12 11:06:16 --> Router Class Initialized
INFO - 2023-10-12 11:06:16 --> Output Class Initialized
INFO - 2023-10-12 11:06:16 --> Security Class Initialized
DEBUG - 2023-10-12 11:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 11:06:16 --> Input Class Initialized
INFO - 2023-10-12 11:06:16 --> Language Class Initialized
INFO - 2023-10-12 11:06:16 --> Language Class Initialized
INFO - 2023-10-12 11:06:16 --> Config Class Initialized
INFO - 2023-10-12 11:06:16 --> Loader Class Initialized
INFO - 2023-10-12 11:06:16 --> Helper loaded: url_helper
INFO - 2023-10-12 11:06:16 --> Helper loaded: file_helper
INFO - 2023-10-12 11:06:16 --> Helper loaded: form_helper
INFO - 2023-10-12 11:06:16 --> Helper loaded: my_helper
INFO - 2023-10-12 11:06:16 --> Database Driver Class Initialized
INFO - 2023-10-12 11:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 11:06:16 --> Controller Class Initialized
DEBUG - 2023-10-12 11:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-12 11:06:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-12 11:06:16 --> Final output sent to browser
DEBUG - 2023-10-12 11:06:16 --> Total execution time: 0.1805
INFO - 2023-10-12 11:46:30 --> Config Class Initialized
INFO - 2023-10-12 11:46:30 --> Hooks Class Initialized
DEBUG - 2023-10-12 11:46:30 --> UTF-8 Support Enabled
INFO - 2023-10-12 11:46:30 --> Utf8 Class Initialized
INFO - 2023-10-12 11:46:30 --> URI Class Initialized
INFO - 2023-10-12 11:46:30 --> Router Class Initialized
INFO - 2023-10-12 11:46:30 --> Output Class Initialized
INFO - 2023-10-12 11:46:30 --> Security Class Initialized
DEBUG - 2023-10-12 11:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 11:46:30 --> Input Class Initialized
INFO - 2023-10-12 11:46:30 --> Language Class Initialized
INFO - 2023-10-12 11:46:30 --> Language Class Initialized
INFO - 2023-10-12 11:46:30 --> Config Class Initialized
INFO - 2023-10-12 11:46:30 --> Loader Class Initialized
INFO - 2023-10-12 11:46:30 --> Helper loaded: url_helper
INFO - 2023-10-12 11:46:30 --> Helper loaded: file_helper
INFO - 2023-10-12 11:46:30 --> Helper loaded: form_helper
INFO - 2023-10-12 11:46:30 --> Helper loaded: my_helper
INFO - 2023-10-12 11:46:30 --> Database Driver Class Initialized
INFO - 2023-10-12 11:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 11:46:30 --> Controller Class Initialized
DEBUG - 2023-10-12 11:46:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-12 11:46:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-12 11:46:30 --> Final output sent to browser
DEBUG - 2023-10-12 11:46:30 --> Total execution time: 0.0488
INFO - 2023-10-12 13:24:25 --> Config Class Initialized
INFO - 2023-10-12 13:24:25 --> Hooks Class Initialized
DEBUG - 2023-10-12 13:24:25 --> UTF-8 Support Enabled
INFO - 2023-10-12 13:24:25 --> Utf8 Class Initialized
INFO - 2023-10-12 13:24:25 --> URI Class Initialized
INFO - 2023-10-12 13:24:25 --> Router Class Initialized
INFO - 2023-10-12 13:24:25 --> Output Class Initialized
INFO - 2023-10-12 13:24:25 --> Security Class Initialized
DEBUG - 2023-10-12 13:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 13:24:25 --> Input Class Initialized
INFO - 2023-10-12 13:24:25 --> Language Class Initialized
INFO - 2023-10-12 13:24:25 --> Language Class Initialized
INFO - 2023-10-12 13:24:25 --> Config Class Initialized
INFO - 2023-10-12 13:24:25 --> Loader Class Initialized
INFO - 2023-10-12 13:24:25 --> Helper loaded: url_helper
INFO - 2023-10-12 13:24:25 --> Helper loaded: file_helper
INFO - 2023-10-12 13:24:25 --> Helper loaded: form_helper
INFO - 2023-10-12 13:24:25 --> Helper loaded: my_helper
INFO - 2023-10-12 13:24:25 --> Database Driver Class Initialized
INFO - 2023-10-12 13:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 13:24:25 --> Controller Class Initialized
DEBUG - 2023-10-12 13:24:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-12 13:24:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-12 13:24:25 --> Final output sent to browser
DEBUG - 2023-10-12 13:24:25 --> Total execution time: 0.2252
INFO - 2023-10-12 17:56:02 --> Config Class Initialized
INFO - 2023-10-12 17:56:02 --> Hooks Class Initialized
DEBUG - 2023-10-12 17:56:02 --> UTF-8 Support Enabled
INFO - 2023-10-12 17:56:02 --> Utf8 Class Initialized
INFO - 2023-10-12 17:56:02 --> URI Class Initialized
INFO - 2023-10-12 17:56:02 --> Router Class Initialized
INFO - 2023-10-12 17:56:02 --> Output Class Initialized
INFO - 2023-10-12 17:56:02 --> Security Class Initialized
DEBUG - 2023-10-12 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-12 17:56:02 --> Input Class Initialized
INFO - 2023-10-12 17:56:02 --> Language Class Initialized
INFO - 2023-10-12 17:56:02 --> Language Class Initialized
INFO - 2023-10-12 17:56:02 --> Config Class Initialized
INFO - 2023-10-12 17:56:02 --> Loader Class Initialized
INFO - 2023-10-12 17:56:02 --> Helper loaded: url_helper
INFO - 2023-10-12 17:56:02 --> Helper loaded: file_helper
INFO - 2023-10-12 17:56:02 --> Helper loaded: form_helper
INFO - 2023-10-12 17:56:02 --> Helper loaded: my_helper
INFO - 2023-10-12 17:56:02 --> Database Driver Class Initialized
INFO - 2023-10-12 17:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-12 17:56:02 --> Controller Class Initialized
DEBUG - 2023-10-12 17:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-12 17:56:02 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-12 17:56:02 --> Final output sent to browser
DEBUG - 2023-10-12 17:56:02 --> Total execution time: 0.1050
