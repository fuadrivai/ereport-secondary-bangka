<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-11-27 13:10:13 --> Config Class Initialized
INFO - 2023-11-27 13:10:13 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:13 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:13 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:13 --> URI Class Initialized
DEBUG - 2023-11-27 13:10:13 --> No URI present. Default controller set.
INFO - 2023-11-27 13:10:13 --> Router Class Initialized
INFO - 2023-11-27 13:10:13 --> Output Class Initialized
INFO - 2023-11-27 13:10:13 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:13 --> Input Class Initialized
INFO - 2023-11-27 13:10:13 --> Language Class Initialized
INFO - 2023-11-27 13:10:13 --> Language Class Initialized
INFO - 2023-11-27 13:10:13 --> Config Class Initialized
INFO - 2023-11-27 13:10:13 --> Loader Class Initialized
INFO - 2023-11-27 13:10:13 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:13 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:13 --> Controller Class Initialized
INFO - 2023-11-27 13:10:13 --> Config Class Initialized
INFO - 2023-11-27 13:10:13 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:13 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:13 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:13 --> URI Class Initialized
INFO - 2023-11-27 13:10:13 --> Router Class Initialized
INFO - 2023-11-27 13:10:13 --> Output Class Initialized
INFO - 2023-11-27 13:10:13 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:13 --> Input Class Initialized
INFO - 2023-11-27 13:10:13 --> Language Class Initialized
INFO - 2023-11-27 13:10:13 --> Language Class Initialized
INFO - 2023-11-27 13:10:13 --> Config Class Initialized
INFO - 2023-11-27 13:10:13 --> Loader Class Initialized
INFO - 2023-11-27 13:10:13 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:13 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:13 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:13 --> Controller Class Initialized
DEBUG - 2023-11-27 13:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-27 13:10:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:10:13 --> Final output sent to browser
DEBUG - 2023-11-27 13:10:13 --> Total execution time: 0.0396
INFO - 2023-11-27 13:10:17 --> Config Class Initialized
INFO - 2023-11-27 13:10:17 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:17 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:17 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:17 --> URI Class Initialized
INFO - 2023-11-27 13:10:17 --> Router Class Initialized
INFO - 2023-11-27 13:10:17 --> Output Class Initialized
INFO - 2023-11-27 13:10:17 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:17 --> Input Class Initialized
INFO - 2023-11-27 13:10:17 --> Language Class Initialized
INFO - 2023-11-27 13:10:17 --> Language Class Initialized
INFO - 2023-11-27 13:10:17 --> Config Class Initialized
INFO - 2023-11-27 13:10:17 --> Loader Class Initialized
INFO - 2023-11-27 13:10:17 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:17 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:17 --> Controller Class Initialized
INFO - 2023-11-27 13:10:17 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:10:17 --> Final output sent to browser
DEBUG - 2023-11-27 13:10:17 --> Total execution time: 0.0391
INFO - 2023-11-27 13:10:17 --> Config Class Initialized
INFO - 2023-11-27 13:10:17 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:17 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:17 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:17 --> URI Class Initialized
INFO - 2023-11-27 13:10:17 --> Router Class Initialized
INFO - 2023-11-27 13:10:17 --> Output Class Initialized
INFO - 2023-11-27 13:10:17 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:17 --> Input Class Initialized
INFO - 2023-11-27 13:10:17 --> Language Class Initialized
INFO - 2023-11-27 13:10:17 --> Language Class Initialized
INFO - 2023-11-27 13:10:17 --> Config Class Initialized
INFO - 2023-11-27 13:10:17 --> Loader Class Initialized
INFO - 2023-11-27 13:10:17 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:17 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:17 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:17 --> Controller Class Initialized
DEBUG - 2023-11-27 13:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-11-27 13:10:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:10:17 --> Final output sent to browser
DEBUG - 2023-11-27 13:10:17 --> Total execution time: 0.0329
INFO - 2023-11-27 13:10:21 --> Config Class Initialized
INFO - 2023-11-27 13:10:21 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:21 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:21 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:21 --> URI Class Initialized
INFO - 2023-11-27 13:10:21 --> Router Class Initialized
INFO - 2023-11-27 13:10:21 --> Output Class Initialized
INFO - 2023-11-27 13:10:21 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:21 --> Input Class Initialized
INFO - 2023-11-27 13:10:21 --> Language Class Initialized
INFO - 2023-11-27 13:10:21 --> Language Class Initialized
INFO - 2023-11-27 13:10:21 --> Config Class Initialized
INFO - 2023-11-27 13:10:21 --> Loader Class Initialized
INFO - 2023-11-27 13:10:21 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:21 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:21 --> Controller Class Initialized
DEBUG - 2023-11-27 13:10:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-11-27 13:10:21 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:10:21 --> Final output sent to browser
DEBUG - 2023-11-27 13:10:21 --> Total execution time: 0.0325
INFO - 2023-11-27 13:10:21 --> Config Class Initialized
INFO - 2023-11-27 13:10:21 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:21 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:21 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:21 --> URI Class Initialized
INFO - 2023-11-27 13:10:21 --> Router Class Initialized
INFO - 2023-11-27 13:10:21 --> Output Class Initialized
INFO - 2023-11-27 13:10:21 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:21 --> Input Class Initialized
INFO - 2023-11-27 13:10:21 --> Language Class Initialized
ERROR - 2023-11-27 13:10:21 --> 404 Page Not Found: /index
INFO - 2023-11-27 13:10:21 --> Config Class Initialized
INFO - 2023-11-27 13:10:21 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:21 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:21 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:21 --> URI Class Initialized
INFO - 2023-11-27 13:10:21 --> Router Class Initialized
INFO - 2023-11-27 13:10:21 --> Output Class Initialized
INFO - 2023-11-27 13:10:21 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:21 --> Input Class Initialized
INFO - 2023-11-27 13:10:21 --> Language Class Initialized
INFO - 2023-11-27 13:10:21 --> Language Class Initialized
INFO - 2023-11-27 13:10:21 --> Config Class Initialized
INFO - 2023-11-27 13:10:21 --> Loader Class Initialized
INFO - 2023-11-27 13:10:21 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:21 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:21 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:21 --> Controller Class Initialized
INFO - 2023-11-27 13:10:24 --> Config Class Initialized
INFO - 2023-11-27 13:10:24 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:24 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:24 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:24 --> URI Class Initialized
INFO - 2023-11-27 13:10:24 --> Router Class Initialized
INFO - 2023-11-27 13:10:24 --> Output Class Initialized
INFO - 2023-11-27 13:10:24 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:24 --> Input Class Initialized
INFO - 2023-11-27 13:10:24 --> Language Class Initialized
INFO - 2023-11-27 13:10:24 --> Language Class Initialized
INFO - 2023-11-27 13:10:24 --> Config Class Initialized
INFO - 2023-11-27 13:10:24 --> Loader Class Initialized
INFO - 2023-11-27 13:10:24 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:24 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:24 --> Controller Class Initialized
DEBUG - 2023-11-27 13:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-11-27 13:10:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:10:24 --> Final output sent to browser
DEBUG - 2023-11-27 13:10:24 --> Total execution time: 0.0511
INFO - 2023-11-27 13:10:24 --> Config Class Initialized
INFO - 2023-11-27 13:10:24 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:24 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:24 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:24 --> URI Class Initialized
INFO - 2023-11-27 13:10:24 --> Router Class Initialized
INFO - 2023-11-27 13:10:24 --> Output Class Initialized
INFO - 2023-11-27 13:10:24 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:24 --> Input Class Initialized
INFO - 2023-11-27 13:10:24 --> Language Class Initialized
ERROR - 2023-11-27 13:10:24 --> 404 Page Not Found: /index
INFO - 2023-11-27 13:10:24 --> Config Class Initialized
INFO - 2023-11-27 13:10:24 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:24 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:24 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:24 --> URI Class Initialized
INFO - 2023-11-27 13:10:24 --> Router Class Initialized
INFO - 2023-11-27 13:10:24 --> Output Class Initialized
INFO - 2023-11-27 13:10:24 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:24 --> Input Class Initialized
INFO - 2023-11-27 13:10:24 --> Language Class Initialized
INFO - 2023-11-27 13:10:24 --> Language Class Initialized
INFO - 2023-11-27 13:10:24 --> Config Class Initialized
INFO - 2023-11-27 13:10:24 --> Loader Class Initialized
INFO - 2023-11-27 13:10:24 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:24 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:24 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:24 --> Controller Class Initialized
INFO - 2023-11-27 13:10:29 --> Config Class Initialized
INFO - 2023-11-27 13:10:29 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:10:29 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:10:29 --> Utf8 Class Initialized
INFO - 2023-11-27 13:10:29 --> URI Class Initialized
INFO - 2023-11-27 13:10:29 --> Router Class Initialized
INFO - 2023-11-27 13:10:29 --> Output Class Initialized
INFO - 2023-11-27 13:10:29 --> Security Class Initialized
DEBUG - 2023-11-27 13:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:10:29 --> Input Class Initialized
INFO - 2023-11-27 13:10:29 --> Language Class Initialized
INFO - 2023-11-27 13:10:29 --> Language Class Initialized
INFO - 2023-11-27 13:10:29 --> Config Class Initialized
INFO - 2023-11-27 13:10:29 --> Loader Class Initialized
INFO - 2023-11-27 13:10:29 --> Helper loaded: url_helper
INFO - 2023-11-27 13:10:29 --> Helper loaded: file_helper
INFO - 2023-11-27 13:10:29 --> Helper loaded: form_helper
INFO - 2023-11-27 13:10:29 --> Helper loaded: my_helper
INFO - 2023-11-27 13:10:29 --> Database Driver Class Initialized
INFO - 2023-11-27 13:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:10:29 --> Controller Class Initialized
INFO - 2023-11-27 13:12:36 --> Config Class Initialized
INFO - 2023-11-27 13:12:36 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:36 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:36 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:36 --> URI Class Initialized
INFO - 2023-11-27 13:12:36 --> Router Class Initialized
INFO - 2023-11-27 13:12:36 --> Output Class Initialized
INFO - 2023-11-27 13:12:36 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:36 --> Input Class Initialized
INFO - 2023-11-27 13:12:36 --> Language Class Initialized
INFO - 2023-11-27 13:12:36 --> Language Class Initialized
INFO - 2023-11-27 13:12:36 --> Config Class Initialized
INFO - 2023-11-27 13:12:36 --> Loader Class Initialized
INFO - 2023-11-27 13:12:36 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:36 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:36 --> Controller Class Initialized
INFO - 2023-11-27 13:12:36 --> Final output sent to browser
DEBUG - 2023-11-27 13:12:36 --> Total execution time: 0.0787
INFO - 2023-11-27 13:12:36 --> Config Class Initialized
INFO - 2023-11-27 13:12:36 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:36 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:36 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:36 --> URI Class Initialized
INFO - 2023-11-27 13:12:36 --> Router Class Initialized
INFO - 2023-11-27 13:12:36 --> Output Class Initialized
INFO - 2023-11-27 13:12:36 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:36 --> Input Class Initialized
INFO - 2023-11-27 13:12:36 --> Language Class Initialized
ERROR - 2023-11-27 13:12:36 --> 404 Page Not Found: /index
INFO - 2023-11-27 13:12:36 --> Config Class Initialized
INFO - 2023-11-27 13:12:36 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:36 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:36 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:36 --> URI Class Initialized
INFO - 2023-11-27 13:12:36 --> Router Class Initialized
INFO - 2023-11-27 13:12:36 --> Output Class Initialized
INFO - 2023-11-27 13:12:36 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:36 --> Input Class Initialized
INFO - 2023-11-27 13:12:36 --> Language Class Initialized
INFO - 2023-11-27 13:12:36 --> Language Class Initialized
INFO - 2023-11-27 13:12:36 --> Config Class Initialized
INFO - 2023-11-27 13:12:36 --> Loader Class Initialized
INFO - 2023-11-27 13:12:36 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:36 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:36 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:36 --> Controller Class Initialized
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:41 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:41 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:41 --> URI Class Initialized
INFO - 2023-11-27 13:12:41 --> Router Class Initialized
INFO - 2023-11-27 13:12:41 --> Output Class Initialized
INFO - 2023-11-27 13:12:41 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:41 --> Input Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Loader Class Initialized
INFO - 2023-11-27 13:12:41 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:41 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:41 --> Controller Class Initialized
INFO - 2023-11-27 13:12:41 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:41 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:41 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:41 --> URI Class Initialized
INFO - 2023-11-27 13:12:41 --> Router Class Initialized
INFO - 2023-11-27 13:12:41 --> Output Class Initialized
INFO - 2023-11-27 13:12:41 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:41 --> Input Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Loader Class Initialized
INFO - 2023-11-27 13:12:41 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:41 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:41 --> Controller Class Initialized
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:41 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:41 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:41 --> URI Class Initialized
INFO - 2023-11-27 13:12:41 --> Router Class Initialized
INFO - 2023-11-27 13:12:41 --> Output Class Initialized
INFO - 2023-11-27 13:12:41 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:41 --> Input Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Language Class Initialized
INFO - 2023-11-27 13:12:41 --> Config Class Initialized
INFO - 2023-11-27 13:12:41 --> Loader Class Initialized
INFO - 2023-11-27 13:12:41 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:41 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:41 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:41 --> Controller Class Initialized
DEBUG - 2023-11-27 13:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-27 13:12:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:12:41 --> Final output sent to browser
DEBUG - 2023-11-27 13:12:41 --> Total execution time: 0.0440
INFO - 2023-11-27 13:12:43 --> Config Class Initialized
INFO - 2023-11-27 13:12:43 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:43 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:43 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:43 --> URI Class Initialized
INFO - 2023-11-27 13:12:43 --> Router Class Initialized
INFO - 2023-11-27 13:12:43 --> Output Class Initialized
INFO - 2023-11-27 13:12:43 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:43 --> Input Class Initialized
INFO - 2023-11-27 13:12:43 --> Language Class Initialized
INFO - 2023-11-27 13:12:43 --> Language Class Initialized
INFO - 2023-11-27 13:12:43 --> Config Class Initialized
INFO - 2023-11-27 13:12:43 --> Loader Class Initialized
INFO - 2023-11-27 13:12:43 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:43 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:43 --> Controller Class Initialized
INFO - 2023-11-27 13:12:43 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:12:43 --> Final output sent to browser
DEBUG - 2023-11-27 13:12:43 --> Total execution time: 0.1429
INFO - 2023-11-27 13:12:43 --> Config Class Initialized
INFO - 2023-11-27 13:12:43 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:43 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:43 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:43 --> URI Class Initialized
INFO - 2023-11-27 13:12:43 --> Router Class Initialized
INFO - 2023-11-27 13:12:43 --> Output Class Initialized
INFO - 2023-11-27 13:12:43 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:43 --> Input Class Initialized
INFO - 2023-11-27 13:12:43 --> Language Class Initialized
INFO - 2023-11-27 13:12:43 --> Language Class Initialized
INFO - 2023-11-27 13:12:43 --> Config Class Initialized
INFO - 2023-11-27 13:12:43 --> Loader Class Initialized
INFO - 2023-11-27 13:12:43 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:43 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:43 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:43 --> Controller Class Initialized
DEBUG - 2023-11-27 13:12:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_siswa.php
DEBUG - 2023-11-27 13:12:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:12:43 --> Final output sent to browser
DEBUG - 2023-11-27 13:12:43 --> Total execution time: 0.0345
INFO - 2023-11-27 13:12:45 --> Config Class Initialized
INFO - 2023-11-27 13:12:45 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:12:45 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:12:45 --> Utf8 Class Initialized
INFO - 2023-11-27 13:12:45 --> URI Class Initialized
INFO - 2023-11-27 13:12:45 --> Router Class Initialized
INFO - 2023-11-27 13:12:45 --> Output Class Initialized
INFO - 2023-11-27 13:12:45 --> Security Class Initialized
DEBUG - 2023-11-27 13:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:12:45 --> Input Class Initialized
INFO - 2023-11-27 13:12:45 --> Language Class Initialized
INFO - 2023-11-27 13:12:45 --> Language Class Initialized
INFO - 2023-11-27 13:12:45 --> Config Class Initialized
INFO - 2023-11-27 13:12:45 --> Loader Class Initialized
INFO - 2023-11-27 13:12:45 --> Helper loaded: url_helper
INFO - 2023-11-27 13:12:45 --> Helper loaded: file_helper
INFO - 2023-11-27 13:12:45 --> Helper loaded: form_helper
INFO - 2023-11-27 13:12:45 --> Helper loaded: my_helper
INFO - 2023-11-27 13:12:45 --> Database Driver Class Initialized
INFO - 2023-11-27 13:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:12:45 --> Controller Class Initialized
DEBUG - 2023-11-27 13:12:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-11-27 13:12:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:12:45 --> Final output sent to browser
DEBUG - 2023-11-27 13:12:45 --> Total execution time: 0.0419
INFO - 2023-11-27 13:13:27 --> Config Class Initialized
INFO - 2023-11-27 13:13:27 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:13:27 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:13:27 --> Utf8 Class Initialized
INFO - 2023-11-27 13:13:27 --> URI Class Initialized
INFO - 2023-11-27 13:13:27 --> Router Class Initialized
INFO - 2023-11-27 13:13:27 --> Output Class Initialized
INFO - 2023-11-27 13:13:27 --> Security Class Initialized
DEBUG - 2023-11-27 13:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:13:27 --> Input Class Initialized
INFO - 2023-11-27 13:13:27 --> Language Class Initialized
INFO - 2023-11-27 13:13:27 --> Language Class Initialized
INFO - 2023-11-27 13:13:27 --> Config Class Initialized
INFO - 2023-11-27 13:13:27 --> Loader Class Initialized
INFO - 2023-11-27 13:13:27 --> Helper loaded: url_helper
INFO - 2023-11-27 13:13:27 --> Helper loaded: file_helper
INFO - 2023-11-27 13:13:27 --> Helper loaded: form_helper
INFO - 2023-11-27 13:13:27 --> Helper loaded: my_helper
INFO - 2023-11-27 13:13:27 --> Database Driver Class Initialized
INFO - 2023-11-27 13:13:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:13:27 --> Controller Class Initialized
DEBUG - 2023-11-27 13:13:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-11-27 13:13:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:13:27 --> Final output sent to browser
DEBUG - 2023-11-27 13:13:27 --> Total execution time: 0.0730
INFO - 2023-11-27 13:13:53 --> Config Class Initialized
INFO - 2023-11-27 13:13:53 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:13:53 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:13:53 --> Utf8 Class Initialized
INFO - 2023-11-27 13:13:53 --> URI Class Initialized
INFO - 2023-11-27 13:13:53 --> Router Class Initialized
INFO - 2023-11-27 13:13:53 --> Output Class Initialized
INFO - 2023-11-27 13:13:53 --> Security Class Initialized
DEBUG - 2023-11-27 13:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:13:53 --> Input Class Initialized
INFO - 2023-11-27 13:13:53 --> Language Class Initialized
INFO - 2023-11-27 13:13:53 --> Language Class Initialized
INFO - 2023-11-27 13:13:53 --> Config Class Initialized
INFO - 2023-11-27 13:13:53 --> Loader Class Initialized
INFO - 2023-11-27 13:13:53 --> Helper loaded: url_helper
INFO - 2023-11-27 13:13:53 --> Helper loaded: file_helper
INFO - 2023-11-27 13:13:53 --> Helper loaded: form_helper
INFO - 2023-11-27 13:13:53 --> Helper loaded: my_helper
INFO - 2023-11-27 13:13:53 --> Database Driver Class Initialized
INFO - 2023-11-27 13:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:13:53 --> Controller Class Initialized
DEBUG - 2023-11-27 13:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2023-11-27 13:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:13:53 --> Final output sent to browser
DEBUG - 2023-11-27 13:13:53 --> Total execution time: 0.0801
INFO - 2023-11-27 13:13:54 --> Config Class Initialized
INFO - 2023-11-27 13:13:54 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:13:54 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:13:54 --> Utf8 Class Initialized
INFO - 2023-11-27 13:13:54 --> URI Class Initialized
INFO - 2023-11-27 13:13:54 --> Router Class Initialized
INFO - 2023-11-27 13:13:54 --> Output Class Initialized
INFO - 2023-11-27 13:13:54 --> Security Class Initialized
DEBUG - 2023-11-27 13:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:13:54 --> Input Class Initialized
INFO - 2023-11-27 13:13:54 --> Language Class Initialized
INFO - 2023-11-27 13:13:54 --> Language Class Initialized
INFO - 2023-11-27 13:13:54 --> Config Class Initialized
INFO - 2023-11-27 13:13:54 --> Loader Class Initialized
INFO - 2023-11-27 13:13:54 --> Helper loaded: url_helper
INFO - 2023-11-27 13:13:54 --> Helper loaded: file_helper
INFO - 2023-11-27 13:13:54 --> Helper loaded: form_helper
INFO - 2023-11-27 13:13:54 --> Helper loaded: my_helper
INFO - 2023-11-27 13:13:54 --> Database Driver Class Initialized
INFO - 2023-11-27 13:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:13:54 --> Controller Class Initialized
DEBUG - 2023-11-27 13:13:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-11-27 13:13:58 --> Final output sent to browser
DEBUG - 2023-11-27 13:13:58 --> Total execution time: 3.3542
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:14:26 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:14:26 --> Utf8 Class Initialized
INFO - 2023-11-27 13:14:26 --> URI Class Initialized
INFO - 2023-11-27 13:14:26 --> Router Class Initialized
INFO - 2023-11-27 13:14:26 --> Output Class Initialized
INFO - 2023-11-27 13:14:26 --> Security Class Initialized
DEBUG - 2023-11-27 13:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:14:26 --> Input Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Loader Class Initialized
INFO - 2023-11-27 13:14:26 --> Helper loaded: url_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: file_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: form_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: my_helper
INFO - 2023-11-27 13:14:26 --> Database Driver Class Initialized
INFO - 2023-11-27 13:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:14:26 --> Controller Class Initialized
INFO - 2023-11-27 13:14:26 --> Helper loaded: cookie_helper
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:14:26 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:14:26 --> Utf8 Class Initialized
INFO - 2023-11-27 13:14:26 --> URI Class Initialized
INFO - 2023-11-27 13:14:26 --> Router Class Initialized
INFO - 2023-11-27 13:14:26 --> Output Class Initialized
INFO - 2023-11-27 13:14:26 --> Security Class Initialized
DEBUG - 2023-11-27 13:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:14:26 --> Input Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Loader Class Initialized
INFO - 2023-11-27 13:14:26 --> Helper loaded: url_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: file_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: form_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: my_helper
INFO - 2023-11-27 13:14:26 --> Database Driver Class Initialized
INFO - 2023-11-27 13:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:14:26 --> Controller Class Initialized
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Hooks Class Initialized
DEBUG - 2023-11-27 13:14:26 --> UTF-8 Support Enabled
INFO - 2023-11-27 13:14:26 --> Utf8 Class Initialized
INFO - 2023-11-27 13:14:26 --> URI Class Initialized
INFO - 2023-11-27 13:14:26 --> Router Class Initialized
INFO - 2023-11-27 13:14:26 --> Output Class Initialized
INFO - 2023-11-27 13:14:26 --> Security Class Initialized
DEBUG - 2023-11-27 13:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-11-27 13:14:26 --> Input Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Language Class Initialized
INFO - 2023-11-27 13:14:26 --> Config Class Initialized
INFO - 2023-11-27 13:14:26 --> Loader Class Initialized
INFO - 2023-11-27 13:14:26 --> Helper loaded: url_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: file_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: form_helper
INFO - 2023-11-27 13:14:26 --> Helper loaded: my_helper
INFO - 2023-11-27 13:14:26 --> Database Driver Class Initialized
INFO - 2023-11-27 13:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-11-27 13:14:26 --> Controller Class Initialized
DEBUG - 2023-11-27 13:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-11-27 13:14:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-11-27 13:14:26 --> Final output sent to browser
DEBUG - 2023-11-27 13:14:26 --> Total execution time: 0.0331
