<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-12-07 09:03:25 --> Config Class Initialized
INFO - 2023-12-07 09:03:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:03:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:03:25 --> Utf8 Class Initialized
INFO - 2023-12-07 09:03:25 --> URI Class Initialized
INFO - 2023-12-07 09:03:25 --> Router Class Initialized
INFO - 2023-12-07 09:03:25 --> Output Class Initialized
INFO - 2023-12-07 09:03:25 --> Security Class Initialized
DEBUG - 2023-12-07 09:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:03:25 --> Input Class Initialized
INFO - 2023-12-07 09:03:25 --> Language Class Initialized
INFO - 2023-12-07 09:03:25 --> Language Class Initialized
INFO - 2023-12-07 09:03:25 --> Config Class Initialized
INFO - 2023-12-07 09:03:25 --> Loader Class Initialized
INFO - 2023-12-07 09:03:25 --> Helper loaded: url_helper
INFO - 2023-12-07 09:03:25 --> Helper loaded: file_helper
INFO - 2023-12-07 09:03:25 --> Helper loaded: form_helper
INFO - 2023-12-07 09:03:25 --> Helper loaded: my_helper
INFO - 2023-12-07 09:03:25 --> Database Driver Class Initialized
INFO - 2023-12-07 09:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:03:25 --> Controller Class Initialized
DEBUG - 2023-12-07 09:03:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 09:03:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:03:25 --> Final output sent to browser
DEBUG - 2023-12-07 09:03:25 --> Total execution time: 0.0518
INFO - 2023-12-07 09:05:08 --> Config Class Initialized
INFO - 2023-12-07 09:05:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:08 --> URI Class Initialized
INFO - 2023-12-07 09:05:08 --> Router Class Initialized
INFO - 2023-12-07 09:05:08 --> Output Class Initialized
INFO - 2023-12-07 09:05:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:08 --> Input Class Initialized
INFO - 2023-12-07 09:05:08 --> Language Class Initialized
INFO - 2023-12-07 09:05:08 --> Language Class Initialized
INFO - 2023-12-07 09:05:08 --> Config Class Initialized
INFO - 2023-12-07 09:05:08 --> Loader Class Initialized
INFO - 2023-12-07 09:05:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:08 --> Controller Class Initialized
DEBUG - 2023-12-07 09:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 09:05:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:08 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:08 --> Total execution time: 0.0448
INFO - 2023-12-07 09:05:11 --> Config Class Initialized
INFO - 2023-12-07 09:05:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:11 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:11 --> URI Class Initialized
INFO - 2023-12-07 09:05:11 --> Router Class Initialized
INFO - 2023-12-07 09:05:11 --> Output Class Initialized
INFO - 2023-12-07 09:05:11 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:11 --> Input Class Initialized
INFO - 2023-12-07 09:05:11 --> Language Class Initialized
INFO - 2023-12-07 09:05:11 --> Language Class Initialized
INFO - 2023-12-07 09:05:11 --> Config Class Initialized
INFO - 2023-12-07 09:05:11 --> Loader Class Initialized
INFO - 2023-12-07 09:05:11 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:11 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:11 --> Controller Class Initialized
INFO - 2023-12-07 09:05:11 --> Helper loaded: cookie_helper
INFO - 2023-12-07 09:05:11 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:11 --> Total execution time: 0.0364
INFO - 2023-12-07 09:05:11 --> Config Class Initialized
INFO - 2023-12-07 09:05:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:11 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:11 --> URI Class Initialized
INFO - 2023-12-07 09:05:11 --> Router Class Initialized
INFO - 2023-12-07 09:05:11 --> Output Class Initialized
INFO - 2023-12-07 09:05:11 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:11 --> Input Class Initialized
INFO - 2023-12-07 09:05:11 --> Language Class Initialized
INFO - 2023-12-07 09:05:11 --> Language Class Initialized
INFO - 2023-12-07 09:05:11 --> Config Class Initialized
INFO - 2023-12-07 09:05:11 --> Loader Class Initialized
INFO - 2023-12-07 09:05:11 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:11 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:11 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:11 --> Controller Class Initialized
DEBUG - 2023-12-07 09:05:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 09:05:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:11 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:11 --> Total execution time: 0.0450
INFO - 2023-12-07 09:05:32 --> Config Class Initialized
INFO - 2023-12-07 09:05:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:32 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:32 --> URI Class Initialized
INFO - 2023-12-07 09:05:32 --> Router Class Initialized
INFO - 2023-12-07 09:05:32 --> Output Class Initialized
INFO - 2023-12-07 09:05:32 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:32 --> Input Class Initialized
INFO - 2023-12-07 09:05:32 --> Language Class Initialized
INFO - 2023-12-07 09:05:32 --> Language Class Initialized
INFO - 2023-12-07 09:05:32 --> Config Class Initialized
INFO - 2023-12-07 09:05:32 --> Loader Class Initialized
INFO - 2023-12-07 09:05:32 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:32 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:32 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:32 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:32 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:32 --> Controller Class Initialized
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:32 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:05:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:32 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:32 --> Total execution time: 0.1179
INFO - 2023-12-07 09:05:35 --> Config Class Initialized
INFO - 2023-12-07 09:05:35 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:35 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:35 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:35 --> URI Class Initialized
INFO - 2023-12-07 09:05:35 --> Router Class Initialized
INFO - 2023-12-07 09:05:35 --> Output Class Initialized
INFO - 2023-12-07 09:05:35 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:35 --> Input Class Initialized
INFO - 2023-12-07 09:05:35 --> Language Class Initialized
INFO - 2023-12-07 09:05:35 --> Language Class Initialized
INFO - 2023-12-07 09:05:35 --> Config Class Initialized
INFO - 2023-12-07 09:05:35 --> Loader Class Initialized
INFO - 2023-12-07 09:05:35 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:35 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:35 --> Controller Class Initialized
DEBUG - 2023-12-07 09:05:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:05:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:35 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:35 --> Total execution time: 0.0524
INFO - 2023-12-07 09:05:35 --> Config Class Initialized
INFO - 2023-12-07 09:05:35 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:35 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:35 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:35 --> URI Class Initialized
INFO - 2023-12-07 09:05:35 --> Router Class Initialized
INFO - 2023-12-07 09:05:35 --> Output Class Initialized
INFO - 2023-12-07 09:05:35 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:35 --> Input Class Initialized
INFO - 2023-12-07 09:05:35 --> Language Class Initialized
INFO - 2023-12-07 09:05:35 --> Language Class Initialized
INFO - 2023-12-07 09:05:35 --> Config Class Initialized
INFO - 2023-12-07 09:05:35 --> Loader Class Initialized
INFO - 2023-12-07 09:05:35 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:35 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:35 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:35 --> Controller Class Initialized
INFO - 2023-12-07 09:05:45 --> Config Class Initialized
INFO - 2023-12-07 09:05:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:46 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:46 --> URI Class Initialized
INFO - 2023-12-07 09:05:46 --> Router Class Initialized
INFO - 2023-12-07 09:05:46 --> Output Class Initialized
INFO - 2023-12-07 09:05:46 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:46 --> Input Class Initialized
INFO - 2023-12-07 09:05:46 --> Language Class Initialized
INFO - 2023-12-07 09:05:46 --> Language Class Initialized
INFO - 2023-12-07 09:05:46 --> Config Class Initialized
INFO - 2023-12-07 09:05:46 --> Loader Class Initialized
INFO - 2023-12-07 09:05:46 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:46 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:46 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:46 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:46 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:46 --> Controller Class Initialized
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:05:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:05:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:46 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:46 --> Total execution time: 0.0476
INFO - 2023-12-07 09:05:48 --> Config Class Initialized
INFO - 2023-12-07 09:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:48 --> URI Class Initialized
INFO - 2023-12-07 09:05:48 --> Router Class Initialized
INFO - 2023-12-07 09:05:48 --> Output Class Initialized
INFO - 2023-12-07 09:05:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:48 --> Input Class Initialized
INFO - 2023-12-07 09:05:48 --> Language Class Initialized
INFO - 2023-12-07 09:05:48 --> Language Class Initialized
INFO - 2023-12-07 09:05:48 --> Config Class Initialized
INFO - 2023-12-07 09:05:48 --> Loader Class Initialized
INFO - 2023-12-07 09:05:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:48 --> Controller Class Initialized
DEBUG - 2023-12-07 09:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:05:48 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:48 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:48 --> Total execution time: 0.0380
INFO - 2023-12-07 09:05:48 --> Config Class Initialized
INFO - 2023-12-07 09:05:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:48 --> URI Class Initialized
INFO - 2023-12-07 09:05:48 --> Router Class Initialized
INFO - 2023-12-07 09:05:48 --> Output Class Initialized
INFO - 2023-12-07 09:05:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:48 --> Input Class Initialized
INFO - 2023-12-07 09:05:48 --> Language Class Initialized
INFO - 2023-12-07 09:05:48 --> Language Class Initialized
INFO - 2023-12-07 09:05:48 --> Config Class Initialized
INFO - 2023-12-07 09:05:48 --> Loader Class Initialized
INFO - 2023-12-07 09:05:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:48 --> Controller Class Initialized
INFO - 2023-12-07 09:05:53 --> Config Class Initialized
INFO - 2023-12-07 09:05:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:53 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:53 --> URI Class Initialized
INFO - 2023-12-07 09:05:53 --> Router Class Initialized
INFO - 2023-12-07 09:05:53 --> Output Class Initialized
INFO - 2023-12-07 09:05:53 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:53 --> Input Class Initialized
INFO - 2023-12-07 09:05:53 --> Language Class Initialized
INFO - 2023-12-07 09:05:53 --> Language Class Initialized
INFO - 2023-12-07 09:05:53 --> Config Class Initialized
INFO - 2023-12-07 09:05:53 --> Loader Class Initialized
INFO - 2023-12-07 09:05:53 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:53 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:53 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:53 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:53 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:53 --> Controller Class Initialized
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:05:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:05:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:53 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:53 --> Total execution time: 0.0383
INFO - 2023-12-07 09:05:55 --> Config Class Initialized
INFO - 2023-12-07 09:05:55 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:55 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:55 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:55 --> URI Class Initialized
INFO - 2023-12-07 09:05:56 --> Router Class Initialized
INFO - 2023-12-07 09:05:56 --> Output Class Initialized
INFO - 2023-12-07 09:05:56 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:56 --> Input Class Initialized
INFO - 2023-12-07 09:05:56 --> Language Class Initialized
INFO - 2023-12-07 09:05:56 --> Language Class Initialized
INFO - 2023-12-07 09:05:56 --> Config Class Initialized
INFO - 2023-12-07 09:05:56 --> Loader Class Initialized
INFO - 2023-12-07 09:05:56 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:56 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:56 --> Controller Class Initialized
DEBUG - 2023-12-07 09:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:05:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:05:56 --> Final output sent to browser
DEBUG - 2023-12-07 09:05:56 --> Total execution time: 0.0338
INFO - 2023-12-07 09:05:56 --> Config Class Initialized
INFO - 2023-12-07 09:05:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:05:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:05:56 --> Utf8 Class Initialized
INFO - 2023-12-07 09:05:56 --> URI Class Initialized
INFO - 2023-12-07 09:05:56 --> Router Class Initialized
INFO - 2023-12-07 09:05:56 --> Output Class Initialized
INFO - 2023-12-07 09:05:56 --> Security Class Initialized
DEBUG - 2023-12-07 09:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:05:56 --> Input Class Initialized
INFO - 2023-12-07 09:05:56 --> Language Class Initialized
INFO - 2023-12-07 09:05:56 --> Language Class Initialized
INFO - 2023-12-07 09:05:56 --> Config Class Initialized
INFO - 2023-12-07 09:05:56 --> Loader Class Initialized
INFO - 2023-12-07 09:05:56 --> Helper loaded: url_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: file_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: form_helper
INFO - 2023-12-07 09:05:56 --> Helper loaded: my_helper
INFO - 2023-12-07 09:05:56 --> Database Driver Class Initialized
INFO - 2023-12-07 09:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:05:56 --> Controller Class Initialized
INFO - 2023-12-07 09:07:07 --> Config Class Initialized
INFO - 2023-12-07 09:07:07 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:07 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:07 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:07 --> URI Class Initialized
INFO - 2023-12-07 09:07:07 --> Router Class Initialized
INFO - 2023-12-07 09:07:07 --> Output Class Initialized
INFO - 2023-12-07 09:07:07 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:07 --> Input Class Initialized
INFO - 2023-12-07 09:07:07 --> Language Class Initialized
INFO - 2023-12-07 09:07:07 --> Language Class Initialized
INFO - 2023-12-07 09:07:07 --> Config Class Initialized
INFO - 2023-12-07 09:07:07 --> Loader Class Initialized
INFO - 2023-12-07 09:07:07 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:07 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:07 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:07 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:07 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:07 --> Controller Class Initialized
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:07:07 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:07:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:07:07 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:07:07 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:07 --> Total execution time: 0.0395
INFO - 2023-12-07 09:07:09 --> Config Class Initialized
INFO - 2023-12-07 09:07:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:09 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:09 --> URI Class Initialized
INFO - 2023-12-07 09:07:09 --> Router Class Initialized
INFO - 2023-12-07 09:07:09 --> Output Class Initialized
INFO - 2023-12-07 09:07:09 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:09 --> Input Class Initialized
INFO - 2023-12-07 09:07:09 --> Language Class Initialized
INFO - 2023-12-07 09:07:09 --> Language Class Initialized
INFO - 2023-12-07 09:07:09 --> Config Class Initialized
INFO - 2023-12-07 09:07:09 --> Loader Class Initialized
INFO - 2023-12-07 09:07:09 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:09 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:09 --> Controller Class Initialized
DEBUG - 2023-12-07 09:07:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:07:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:07:09 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:09 --> Total execution time: 0.0373
INFO - 2023-12-07 09:07:09 --> Config Class Initialized
INFO - 2023-12-07 09:07:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:09 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:09 --> URI Class Initialized
INFO - 2023-12-07 09:07:09 --> Router Class Initialized
INFO - 2023-12-07 09:07:09 --> Output Class Initialized
INFO - 2023-12-07 09:07:09 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:09 --> Input Class Initialized
INFO - 2023-12-07 09:07:09 --> Language Class Initialized
INFO - 2023-12-07 09:07:09 --> Language Class Initialized
INFO - 2023-12-07 09:07:09 --> Config Class Initialized
INFO - 2023-12-07 09:07:09 --> Loader Class Initialized
INFO - 2023-12-07 09:07:09 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:09 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:09 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:09 --> Controller Class Initialized
INFO - 2023-12-07 09:07:15 --> Config Class Initialized
INFO - 2023-12-07 09:07:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:15 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:15 --> URI Class Initialized
INFO - 2023-12-07 09:07:15 --> Router Class Initialized
INFO - 2023-12-07 09:07:15 --> Output Class Initialized
INFO - 2023-12-07 09:07:15 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:15 --> Input Class Initialized
INFO - 2023-12-07 09:07:15 --> Language Class Initialized
INFO - 2023-12-07 09:07:15 --> Language Class Initialized
INFO - 2023-12-07 09:07:15 --> Config Class Initialized
INFO - 2023-12-07 09:07:15 --> Loader Class Initialized
INFO - 2023-12-07 09:07:15 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:15 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:15 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:15 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:15 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:15 --> Controller Class Initialized
INFO - 2023-12-07 09:07:15 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:15 --> Total execution time: 0.0401
INFO - 2023-12-07 09:07:23 --> Config Class Initialized
INFO - 2023-12-07 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:23 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:23 --> URI Class Initialized
INFO - 2023-12-07 09:07:23 --> Router Class Initialized
INFO - 2023-12-07 09:07:23 --> Output Class Initialized
INFO - 2023-12-07 09:07:23 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:23 --> Input Class Initialized
INFO - 2023-12-07 09:07:23 --> Language Class Initialized
INFO - 2023-12-07 09:07:23 --> Language Class Initialized
INFO - 2023-12-07 09:07:23 --> Config Class Initialized
INFO - 2023-12-07 09:07:23 --> Loader Class Initialized
INFO - 2023-12-07 09:07:23 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:23 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:23 --> Controller Class Initialized
INFO - 2023-12-07 09:07:23 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:23 --> Total execution time: 0.0842
INFO - 2023-12-07 09:07:23 --> Config Class Initialized
INFO - 2023-12-07 09:07:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:23 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:23 --> URI Class Initialized
INFO - 2023-12-07 09:07:23 --> Router Class Initialized
INFO - 2023-12-07 09:07:23 --> Output Class Initialized
INFO - 2023-12-07 09:07:23 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:23 --> Input Class Initialized
INFO - 2023-12-07 09:07:23 --> Language Class Initialized
INFO - 2023-12-07 09:07:23 --> Language Class Initialized
INFO - 2023-12-07 09:07:23 --> Config Class Initialized
INFO - 2023-12-07 09:07:23 --> Loader Class Initialized
INFO - 2023-12-07 09:07:23 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:23 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:23 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:23 --> Controller Class Initialized
INFO - 2023-12-07 09:07:28 --> Config Class Initialized
INFO - 2023-12-07 09:07:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:28 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:28 --> URI Class Initialized
INFO - 2023-12-07 09:07:28 --> Router Class Initialized
INFO - 2023-12-07 09:07:28 --> Output Class Initialized
INFO - 2023-12-07 09:07:28 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:28 --> Input Class Initialized
INFO - 2023-12-07 09:07:28 --> Language Class Initialized
INFO - 2023-12-07 09:07:28 --> Language Class Initialized
INFO - 2023-12-07 09:07:28 --> Config Class Initialized
INFO - 2023-12-07 09:07:28 --> Loader Class Initialized
INFO - 2023-12-07 09:07:28 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:28 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:28 --> Controller Class Initialized
INFO - 2023-12-07 09:07:28 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:28 --> Total execution time: 0.0387
INFO - 2023-12-07 09:07:28 --> Config Class Initialized
INFO - 2023-12-07 09:07:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:28 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:28 --> URI Class Initialized
INFO - 2023-12-07 09:07:28 --> Router Class Initialized
INFO - 2023-12-07 09:07:28 --> Output Class Initialized
INFO - 2023-12-07 09:07:28 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:28 --> Input Class Initialized
INFO - 2023-12-07 09:07:28 --> Language Class Initialized
INFO - 2023-12-07 09:07:28 --> Language Class Initialized
INFO - 2023-12-07 09:07:28 --> Config Class Initialized
INFO - 2023-12-07 09:07:28 --> Loader Class Initialized
INFO - 2023-12-07 09:07:28 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:28 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:28 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:28 --> Controller Class Initialized
INFO - 2023-12-07 09:07:39 --> Config Class Initialized
INFO - 2023-12-07 09:07:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:39 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:39 --> URI Class Initialized
INFO - 2023-12-07 09:07:39 --> Router Class Initialized
INFO - 2023-12-07 09:07:39 --> Output Class Initialized
INFO - 2023-12-07 09:07:39 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:39 --> Input Class Initialized
INFO - 2023-12-07 09:07:39 --> Language Class Initialized
INFO - 2023-12-07 09:07:39 --> Language Class Initialized
INFO - 2023-12-07 09:07:39 --> Config Class Initialized
INFO - 2023-12-07 09:07:39 --> Loader Class Initialized
INFO - 2023-12-07 09:07:39 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:39 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:39 --> Controller Class Initialized
INFO - 2023-12-07 09:07:39 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:39 --> Total execution time: 0.1692
INFO - 2023-12-07 09:07:39 --> Config Class Initialized
INFO - 2023-12-07 09:07:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:39 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:39 --> URI Class Initialized
INFO - 2023-12-07 09:07:39 --> Router Class Initialized
INFO - 2023-12-07 09:07:39 --> Output Class Initialized
INFO - 2023-12-07 09:07:39 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:39 --> Input Class Initialized
INFO - 2023-12-07 09:07:39 --> Language Class Initialized
INFO - 2023-12-07 09:07:39 --> Language Class Initialized
INFO - 2023-12-07 09:07:39 --> Config Class Initialized
INFO - 2023-12-07 09:07:39 --> Loader Class Initialized
INFO - 2023-12-07 09:07:39 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:39 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:39 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:39 --> Controller Class Initialized
INFO - 2023-12-07 09:07:42 --> Config Class Initialized
INFO - 2023-12-07 09:07:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:42 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:42 --> URI Class Initialized
INFO - 2023-12-07 09:07:42 --> Router Class Initialized
INFO - 2023-12-07 09:07:42 --> Output Class Initialized
INFO - 2023-12-07 09:07:42 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:42 --> Input Class Initialized
INFO - 2023-12-07 09:07:42 --> Language Class Initialized
INFO - 2023-12-07 09:07:42 --> Language Class Initialized
INFO - 2023-12-07 09:07:42 --> Config Class Initialized
INFO - 2023-12-07 09:07:42 --> Loader Class Initialized
INFO - 2023-12-07 09:07:42 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:42 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:42 --> Controller Class Initialized
INFO - 2023-12-07 09:07:42 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:42 --> Total execution time: 0.0462
INFO - 2023-12-07 09:07:42 --> Config Class Initialized
INFO - 2023-12-07 09:07:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:42 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:42 --> URI Class Initialized
INFO - 2023-12-07 09:07:42 --> Router Class Initialized
INFO - 2023-12-07 09:07:42 --> Output Class Initialized
INFO - 2023-12-07 09:07:42 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:42 --> Input Class Initialized
INFO - 2023-12-07 09:07:42 --> Language Class Initialized
INFO - 2023-12-07 09:07:42 --> Language Class Initialized
INFO - 2023-12-07 09:07:42 --> Config Class Initialized
INFO - 2023-12-07 09:07:42 --> Loader Class Initialized
INFO - 2023-12-07 09:07:42 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:42 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:42 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:42 --> Controller Class Initialized
INFO - 2023-12-07 09:07:48 --> Config Class Initialized
INFO - 2023-12-07 09:07:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:48 --> URI Class Initialized
INFO - 2023-12-07 09:07:48 --> Router Class Initialized
INFO - 2023-12-07 09:07:48 --> Output Class Initialized
INFO - 2023-12-07 09:07:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:48 --> Input Class Initialized
INFO - 2023-12-07 09:07:48 --> Language Class Initialized
INFO - 2023-12-07 09:07:48 --> Language Class Initialized
INFO - 2023-12-07 09:07:48 --> Config Class Initialized
INFO - 2023-12-07 09:07:48 --> Loader Class Initialized
INFO - 2023-12-07 09:07:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:48 --> Controller Class Initialized
INFO - 2023-12-07 09:07:48 --> Final output sent to browser
DEBUG - 2023-12-07 09:07:48 --> Total execution time: 0.0853
INFO - 2023-12-07 09:07:48 --> Config Class Initialized
INFO - 2023-12-07 09:07:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:07:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:07:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:07:48 --> URI Class Initialized
INFO - 2023-12-07 09:07:48 --> Router Class Initialized
INFO - 2023-12-07 09:07:48 --> Output Class Initialized
INFO - 2023-12-07 09:07:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:07:48 --> Input Class Initialized
INFO - 2023-12-07 09:07:48 --> Language Class Initialized
INFO - 2023-12-07 09:07:48 --> Language Class Initialized
INFO - 2023-12-07 09:07:48 --> Config Class Initialized
INFO - 2023-12-07 09:07:48 --> Loader Class Initialized
INFO - 2023-12-07 09:07:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:07:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:07:49 --> Database Driver Class Initialized
INFO - 2023-12-07 09:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:07:49 --> Controller Class Initialized
INFO - 2023-12-07 09:08:03 --> Config Class Initialized
INFO - 2023-12-07 09:08:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:03 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:03 --> URI Class Initialized
INFO - 2023-12-07 09:08:03 --> Router Class Initialized
INFO - 2023-12-07 09:08:03 --> Output Class Initialized
INFO - 2023-12-07 09:08:03 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:03 --> Input Class Initialized
INFO - 2023-12-07 09:08:03 --> Language Class Initialized
INFO - 2023-12-07 09:08:03 --> Language Class Initialized
INFO - 2023-12-07 09:08:03 --> Config Class Initialized
INFO - 2023-12-07 09:08:03 --> Loader Class Initialized
INFO - 2023-12-07 09:08:03 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:03 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:03 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:03 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:03 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:03 --> Controller Class Initialized
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:08:03 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:08:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:08:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:08:03 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:03 --> Total execution time: 0.0449
INFO - 2023-12-07 09:08:06 --> Config Class Initialized
INFO - 2023-12-07 09:08:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:06 --> URI Class Initialized
INFO - 2023-12-07 09:08:06 --> Router Class Initialized
INFO - 2023-12-07 09:08:06 --> Output Class Initialized
INFO - 2023-12-07 09:08:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:06 --> Input Class Initialized
INFO - 2023-12-07 09:08:06 --> Language Class Initialized
INFO - 2023-12-07 09:08:06 --> Language Class Initialized
INFO - 2023-12-07 09:08:06 --> Config Class Initialized
INFO - 2023-12-07 09:08:06 --> Loader Class Initialized
INFO - 2023-12-07 09:08:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:06 --> Controller Class Initialized
DEBUG - 2023-12-07 09:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:08:06 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:08:06 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:06 --> Total execution time: 0.0442
INFO - 2023-12-07 09:08:06 --> Config Class Initialized
INFO - 2023-12-07 09:08:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:06 --> URI Class Initialized
INFO - 2023-12-07 09:08:06 --> Router Class Initialized
INFO - 2023-12-07 09:08:06 --> Output Class Initialized
INFO - 2023-12-07 09:08:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:06 --> Input Class Initialized
INFO - 2023-12-07 09:08:06 --> Language Class Initialized
INFO - 2023-12-07 09:08:06 --> Language Class Initialized
INFO - 2023-12-07 09:08:06 --> Config Class Initialized
INFO - 2023-12-07 09:08:06 --> Loader Class Initialized
INFO - 2023-12-07 09:08:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:06 --> Controller Class Initialized
INFO - 2023-12-07 09:08:09 --> Config Class Initialized
INFO - 2023-12-07 09:08:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:09 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:09 --> URI Class Initialized
INFO - 2023-12-07 09:08:09 --> Router Class Initialized
INFO - 2023-12-07 09:08:09 --> Output Class Initialized
INFO - 2023-12-07 09:08:09 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:09 --> Input Class Initialized
INFO - 2023-12-07 09:08:09 --> Language Class Initialized
INFO - 2023-12-07 09:08:09 --> Language Class Initialized
INFO - 2023-12-07 09:08:09 --> Config Class Initialized
INFO - 2023-12-07 09:08:09 --> Loader Class Initialized
INFO - 2023-12-07 09:08:09 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:09 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:09 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:09 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:09 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:09 --> Controller Class Initialized
INFO - 2023-12-07 09:08:09 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:09 --> Total execution time: 0.0720
INFO - 2023-12-07 09:08:19 --> Config Class Initialized
INFO - 2023-12-07 09:08:19 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:19 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:19 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:19 --> URI Class Initialized
INFO - 2023-12-07 09:08:19 --> Router Class Initialized
INFO - 2023-12-07 09:08:19 --> Output Class Initialized
INFO - 2023-12-07 09:08:19 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:19 --> Input Class Initialized
INFO - 2023-12-07 09:08:19 --> Language Class Initialized
INFO - 2023-12-07 09:08:19 --> Language Class Initialized
INFO - 2023-12-07 09:08:19 --> Config Class Initialized
INFO - 2023-12-07 09:08:19 --> Loader Class Initialized
INFO - 2023-12-07 09:08:19 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:19 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:19 --> Controller Class Initialized
INFO - 2023-12-07 09:08:19 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:19 --> Total execution time: 0.1030
INFO - 2023-12-07 09:08:19 --> Config Class Initialized
INFO - 2023-12-07 09:08:19 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:19 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:19 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:19 --> URI Class Initialized
INFO - 2023-12-07 09:08:19 --> Router Class Initialized
INFO - 2023-12-07 09:08:19 --> Output Class Initialized
INFO - 2023-12-07 09:08:19 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:19 --> Input Class Initialized
INFO - 2023-12-07 09:08:19 --> Language Class Initialized
INFO - 2023-12-07 09:08:19 --> Language Class Initialized
INFO - 2023-12-07 09:08:19 --> Config Class Initialized
INFO - 2023-12-07 09:08:19 --> Loader Class Initialized
INFO - 2023-12-07 09:08:19 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:19 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:19 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:19 --> Controller Class Initialized
INFO - 2023-12-07 09:08:29 --> Config Class Initialized
INFO - 2023-12-07 09:08:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:29 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:29 --> URI Class Initialized
INFO - 2023-12-07 09:08:29 --> Router Class Initialized
INFO - 2023-12-07 09:08:29 --> Output Class Initialized
INFO - 2023-12-07 09:08:29 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:29 --> Input Class Initialized
INFO - 2023-12-07 09:08:29 --> Language Class Initialized
INFO - 2023-12-07 09:08:29 --> Language Class Initialized
INFO - 2023-12-07 09:08:29 --> Config Class Initialized
INFO - 2023-12-07 09:08:29 --> Loader Class Initialized
INFO - 2023-12-07 09:08:29 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:29 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:29 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:29 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:29 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:29 --> Controller Class Initialized
INFO - 2023-12-07 09:08:29 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:29 --> Total execution time: 0.0322
INFO - 2023-12-07 09:08:48 --> Config Class Initialized
INFO - 2023-12-07 09:08:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:48 --> URI Class Initialized
INFO - 2023-12-07 09:08:48 --> Router Class Initialized
INFO - 2023-12-07 09:08:48 --> Output Class Initialized
INFO - 2023-12-07 09:08:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:48 --> Input Class Initialized
INFO - 2023-12-07 09:08:48 --> Language Class Initialized
INFO - 2023-12-07 09:08:48 --> Language Class Initialized
INFO - 2023-12-07 09:08:48 --> Config Class Initialized
INFO - 2023-12-07 09:08:48 --> Loader Class Initialized
INFO - 2023-12-07 09:08:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:48 --> Controller Class Initialized
INFO - 2023-12-07 09:08:48 --> Final output sent to browser
DEBUG - 2023-12-07 09:08:48 --> Total execution time: 0.0391
INFO - 2023-12-07 09:08:48 --> Config Class Initialized
INFO - 2023-12-07 09:08:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:08:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:08:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:08:48 --> URI Class Initialized
INFO - 2023-12-07 09:08:48 --> Router Class Initialized
INFO - 2023-12-07 09:08:48 --> Output Class Initialized
INFO - 2023-12-07 09:08:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:08:48 --> Input Class Initialized
INFO - 2023-12-07 09:08:48 --> Language Class Initialized
INFO - 2023-12-07 09:08:48 --> Language Class Initialized
INFO - 2023-12-07 09:08:48 --> Config Class Initialized
INFO - 2023-12-07 09:08:48 --> Loader Class Initialized
INFO - 2023-12-07 09:08:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:08:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:08:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:08:48 --> Controller Class Initialized
INFO - 2023-12-07 09:09:00 --> Config Class Initialized
INFO - 2023-12-07 09:09:00 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:00 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:00 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:00 --> URI Class Initialized
INFO - 2023-12-07 09:09:00 --> Router Class Initialized
INFO - 2023-12-07 09:09:00 --> Output Class Initialized
INFO - 2023-12-07 09:09:00 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:00 --> Input Class Initialized
INFO - 2023-12-07 09:09:00 --> Language Class Initialized
INFO - 2023-12-07 09:09:00 --> Language Class Initialized
INFO - 2023-12-07 09:09:00 --> Config Class Initialized
INFO - 2023-12-07 09:09:00 --> Loader Class Initialized
INFO - 2023-12-07 09:09:00 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:00 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:00 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:00 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:00 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:00 --> Controller Class Initialized
INFO - 2023-12-07 09:09:00 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:00 --> Total execution time: 0.0337
INFO - 2023-12-07 09:09:08 --> Config Class Initialized
INFO - 2023-12-07 09:09:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:08 --> URI Class Initialized
INFO - 2023-12-07 09:09:08 --> Router Class Initialized
INFO - 2023-12-07 09:09:08 --> Output Class Initialized
INFO - 2023-12-07 09:09:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:08 --> Input Class Initialized
INFO - 2023-12-07 09:09:08 --> Language Class Initialized
INFO - 2023-12-07 09:09:08 --> Language Class Initialized
INFO - 2023-12-07 09:09:08 --> Config Class Initialized
INFO - 2023-12-07 09:09:08 --> Loader Class Initialized
INFO - 2023-12-07 09:09:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:08 --> Controller Class Initialized
INFO - 2023-12-07 09:09:08 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:08 --> Total execution time: 0.0422
INFO - 2023-12-07 09:09:08 --> Config Class Initialized
INFO - 2023-12-07 09:09:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:08 --> URI Class Initialized
INFO - 2023-12-07 09:09:08 --> Router Class Initialized
INFO - 2023-12-07 09:09:08 --> Output Class Initialized
INFO - 2023-12-07 09:09:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:08 --> Input Class Initialized
INFO - 2023-12-07 09:09:08 --> Language Class Initialized
INFO - 2023-12-07 09:09:08 --> Language Class Initialized
INFO - 2023-12-07 09:09:08 --> Config Class Initialized
INFO - 2023-12-07 09:09:08 --> Loader Class Initialized
INFO - 2023-12-07 09:09:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:09 --> Controller Class Initialized
INFO - 2023-12-07 09:09:24 --> Config Class Initialized
INFO - 2023-12-07 09:09:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:24 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:24 --> URI Class Initialized
INFO - 2023-12-07 09:09:24 --> Router Class Initialized
INFO - 2023-12-07 09:09:24 --> Output Class Initialized
INFO - 2023-12-07 09:09:24 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:24 --> Input Class Initialized
INFO - 2023-12-07 09:09:24 --> Language Class Initialized
INFO - 2023-12-07 09:09:24 --> Language Class Initialized
INFO - 2023-12-07 09:09:24 --> Config Class Initialized
INFO - 2023-12-07 09:09:24 --> Loader Class Initialized
INFO - 2023-12-07 09:09:24 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:24 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:24 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:24 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:24 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:24 --> Controller Class Initialized
INFO - 2023-12-07 09:09:24 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:24 --> Total execution time: 0.0328
INFO - 2023-12-07 09:09:37 --> Config Class Initialized
INFO - 2023-12-07 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:37 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:37 --> URI Class Initialized
INFO - 2023-12-07 09:09:37 --> Router Class Initialized
INFO - 2023-12-07 09:09:37 --> Output Class Initialized
INFO - 2023-12-07 09:09:37 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:37 --> Input Class Initialized
INFO - 2023-12-07 09:09:37 --> Language Class Initialized
INFO - 2023-12-07 09:09:37 --> Language Class Initialized
INFO - 2023-12-07 09:09:37 --> Config Class Initialized
INFO - 2023-12-07 09:09:37 --> Loader Class Initialized
INFO - 2023-12-07 09:09:37 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:37 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:37 --> Controller Class Initialized
INFO - 2023-12-07 09:09:37 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:37 --> Total execution time: 0.0363
INFO - 2023-12-07 09:09:37 --> Config Class Initialized
INFO - 2023-12-07 09:09:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:37 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:37 --> URI Class Initialized
INFO - 2023-12-07 09:09:37 --> Router Class Initialized
INFO - 2023-12-07 09:09:37 --> Output Class Initialized
INFO - 2023-12-07 09:09:37 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:37 --> Input Class Initialized
INFO - 2023-12-07 09:09:37 --> Language Class Initialized
INFO - 2023-12-07 09:09:37 --> Language Class Initialized
INFO - 2023-12-07 09:09:37 --> Config Class Initialized
INFO - 2023-12-07 09:09:37 --> Loader Class Initialized
INFO - 2023-12-07 09:09:37 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:37 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:37 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:37 --> Controller Class Initialized
INFO - 2023-12-07 09:09:53 --> Config Class Initialized
INFO - 2023-12-07 09:09:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:53 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:53 --> URI Class Initialized
INFO - 2023-12-07 09:09:53 --> Router Class Initialized
INFO - 2023-12-07 09:09:53 --> Output Class Initialized
INFO - 2023-12-07 09:09:53 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:53 --> Input Class Initialized
INFO - 2023-12-07 09:09:53 --> Language Class Initialized
INFO - 2023-12-07 09:09:53 --> Language Class Initialized
INFO - 2023-12-07 09:09:53 --> Config Class Initialized
INFO - 2023-12-07 09:09:53 --> Loader Class Initialized
INFO - 2023-12-07 09:09:53 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:53 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:53 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:53 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:53 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:53 --> Controller Class Initialized
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:09:53 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:09:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:09:53 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:53 --> Total execution time: 0.0437
INFO - 2023-12-07 09:09:56 --> Config Class Initialized
INFO - 2023-12-07 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:56 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:56 --> URI Class Initialized
INFO - 2023-12-07 09:09:56 --> Router Class Initialized
INFO - 2023-12-07 09:09:56 --> Output Class Initialized
INFO - 2023-12-07 09:09:56 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:56 --> Input Class Initialized
INFO - 2023-12-07 09:09:56 --> Language Class Initialized
INFO - 2023-12-07 09:09:56 --> Language Class Initialized
INFO - 2023-12-07 09:09:56 --> Config Class Initialized
INFO - 2023-12-07 09:09:56 --> Loader Class Initialized
INFO - 2023-12-07 09:09:56 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:56 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:56 --> Controller Class Initialized
DEBUG - 2023-12-07 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:09:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:09:56 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:56 --> Total execution time: 0.0364
INFO - 2023-12-07 09:09:56 --> Config Class Initialized
INFO - 2023-12-07 09:09:56 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:56 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:56 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:56 --> URI Class Initialized
INFO - 2023-12-07 09:09:56 --> Router Class Initialized
INFO - 2023-12-07 09:09:56 --> Output Class Initialized
INFO - 2023-12-07 09:09:56 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:56 --> Input Class Initialized
INFO - 2023-12-07 09:09:56 --> Language Class Initialized
INFO - 2023-12-07 09:09:56 --> Language Class Initialized
INFO - 2023-12-07 09:09:56 --> Config Class Initialized
INFO - 2023-12-07 09:09:56 --> Loader Class Initialized
INFO - 2023-12-07 09:09:56 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:56 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:56 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:56 --> Controller Class Initialized
INFO - 2023-12-07 09:09:58 --> Config Class Initialized
INFO - 2023-12-07 09:09:58 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:09:58 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:09:58 --> Utf8 Class Initialized
INFO - 2023-12-07 09:09:58 --> URI Class Initialized
INFO - 2023-12-07 09:09:58 --> Router Class Initialized
INFO - 2023-12-07 09:09:58 --> Output Class Initialized
INFO - 2023-12-07 09:09:58 --> Security Class Initialized
DEBUG - 2023-12-07 09:09:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:09:58 --> Input Class Initialized
INFO - 2023-12-07 09:09:58 --> Language Class Initialized
INFO - 2023-12-07 09:09:58 --> Language Class Initialized
INFO - 2023-12-07 09:09:58 --> Config Class Initialized
INFO - 2023-12-07 09:09:58 --> Loader Class Initialized
INFO - 2023-12-07 09:09:58 --> Helper loaded: url_helper
INFO - 2023-12-07 09:09:58 --> Helper loaded: file_helper
INFO - 2023-12-07 09:09:58 --> Helper loaded: form_helper
INFO - 2023-12-07 09:09:58 --> Helper loaded: my_helper
INFO - 2023-12-07 09:09:58 --> Database Driver Class Initialized
INFO - 2023-12-07 09:09:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:09:58 --> Controller Class Initialized
INFO - 2023-12-07 09:09:58 --> Final output sent to browser
DEBUG - 2023-12-07 09:09:58 --> Total execution time: 0.0502
INFO - 2023-12-07 09:10:13 --> Config Class Initialized
INFO - 2023-12-07 09:10:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:13 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:13 --> URI Class Initialized
INFO - 2023-12-07 09:10:13 --> Router Class Initialized
INFO - 2023-12-07 09:10:13 --> Output Class Initialized
INFO - 2023-12-07 09:10:13 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:13 --> Input Class Initialized
INFO - 2023-12-07 09:10:13 --> Language Class Initialized
INFO - 2023-12-07 09:10:13 --> Language Class Initialized
INFO - 2023-12-07 09:10:13 --> Config Class Initialized
INFO - 2023-12-07 09:10:13 --> Loader Class Initialized
INFO - 2023-12-07 09:10:13 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:13 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:13 --> Controller Class Initialized
INFO - 2023-12-07 09:10:13 --> Final output sent to browser
DEBUG - 2023-12-07 09:10:13 --> Total execution time: 0.0404
INFO - 2023-12-07 09:10:13 --> Config Class Initialized
INFO - 2023-12-07 09:10:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:13 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:13 --> URI Class Initialized
INFO - 2023-12-07 09:10:13 --> Router Class Initialized
INFO - 2023-12-07 09:10:13 --> Output Class Initialized
INFO - 2023-12-07 09:10:13 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:13 --> Input Class Initialized
INFO - 2023-12-07 09:10:13 --> Language Class Initialized
INFO - 2023-12-07 09:10:13 --> Language Class Initialized
INFO - 2023-12-07 09:10:13 --> Config Class Initialized
INFO - 2023-12-07 09:10:13 --> Loader Class Initialized
INFO - 2023-12-07 09:10:13 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:13 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:13 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:13 --> Controller Class Initialized
INFO - 2023-12-07 09:10:22 --> Config Class Initialized
INFO - 2023-12-07 09:10:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:22 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:22 --> URI Class Initialized
INFO - 2023-12-07 09:10:22 --> Router Class Initialized
INFO - 2023-12-07 09:10:22 --> Output Class Initialized
INFO - 2023-12-07 09:10:22 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:22 --> Input Class Initialized
INFO - 2023-12-07 09:10:22 --> Language Class Initialized
INFO - 2023-12-07 09:10:22 --> Language Class Initialized
INFO - 2023-12-07 09:10:22 --> Config Class Initialized
INFO - 2023-12-07 09:10:22 --> Loader Class Initialized
INFO - 2023-12-07 09:10:22 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:22 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:22 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:22 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:22 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:22 --> Controller Class Initialized
INFO - 2023-12-07 09:10:22 --> Final output sent to browser
DEBUG - 2023-12-07 09:10:22 --> Total execution time: 0.0346
INFO - 2023-12-07 09:10:33 --> Config Class Initialized
INFO - 2023-12-07 09:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:33 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:33 --> URI Class Initialized
INFO - 2023-12-07 09:10:33 --> Router Class Initialized
INFO - 2023-12-07 09:10:33 --> Output Class Initialized
INFO - 2023-12-07 09:10:33 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:33 --> Input Class Initialized
INFO - 2023-12-07 09:10:33 --> Language Class Initialized
INFO - 2023-12-07 09:10:33 --> Language Class Initialized
INFO - 2023-12-07 09:10:33 --> Config Class Initialized
INFO - 2023-12-07 09:10:33 --> Loader Class Initialized
INFO - 2023-12-07 09:10:33 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:33 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:33 --> Controller Class Initialized
INFO - 2023-12-07 09:10:33 --> Final output sent to browser
DEBUG - 2023-12-07 09:10:33 --> Total execution time: 0.0365
INFO - 2023-12-07 09:10:33 --> Config Class Initialized
INFO - 2023-12-07 09:10:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:33 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:33 --> URI Class Initialized
INFO - 2023-12-07 09:10:33 --> Router Class Initialized
INFO - 2023-12-07 09:10:33 --> Output Class Initialized
INFO - 2023-12-07 09:10:33 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:33 --> Input Class Initialized
INFO - 2023-12-07 09:10:33 --> Language Class Initialized
INFO - 2023-12-07 09:10:33 --> Language Class Initialized
INFO - 2023-12-07 09:10:33 --> Config Class Initialized
INFO - 2023-12-07 09:10:33 --> Loader Class Initialized
INFO - 2023-12-07 09:10:33 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:33 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:33 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:33 --> Controller Class Initialized
INFO - 2023-12-07 09:10:42 --> Config Class Initialized
INFO - 2023-12-07 09:10:42 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:10:42 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:10:42 --> Utf8 Class Initialized
INFO - 2023-12-07 09:10:42 --> URI Class Initialized
INFO - 2023-12-07 09:10:42 --> Router Class Initialized
INFO - 2023-12-07 09:10:42 --> Output Class Initialized
INFO - 2023-12-07 09:10:42 --> Security Class Initialized
DEBUG - 2023-12-07 09:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:10:42 --> Input Class Initialized
INFO - 2023-12-07 09:10:42 --> Language Class Initialized
INFO - 2023-12-07 09:10:42 --> Language Class Initialized
INFO - 2023-12-07 09:10:42 --> Config Class Initialized
INFO - 2023-12-07 09:10:42 --> Loader Class Initialized
INFO - 2023-12-07 09:10:42 --> Helper loaded: url_helper
INFO - 2023-12-07 09:10:42 --> Helper loaded: file_helper
INFO - 2023-12-07 09:10:42 --> Helper loaded: form_helper
INFO - 2023-12-07 09:10:42 --> Helper loaded: my_helper
INFO - 2023-12-07 09:10:42 --> Database Driver Class Initialized
INFO - 2023-12-07 09:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:10:42 --> Controller Class Initialized
INFO - 2023-12-07 09:10:42 --> Final output sent to browser
DEBUG - 2023-12-07 09:10:42 --> Total execution time: 0.0339
INFO - 2023-12-07 09:11:04 --> Config Class Initialized
INFO - 2023-12-07 09:11:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:11:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:11:04 --> Utf8 Class Initialized
INFO - 2023-12-07 09:11:04 --> URI Class Initialized
INFO - 2023-12-07 09:11:04 --> Router Class Initialized
INFO - 2023-12-07 09:11:04 --> Output Class Initialized
INFO - 2023-12-07 09:11:04 --> Security Class Initialized
DEBUG - 2023-12-07 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:11:04 --> Input Class Initialized
INFO - 2023-12-07 09:11:04 --> Language Class Initialized
INFO - 2023-12-07 09:11:04 --> Language Class Initialized
INFO - 2023-12-07 09:11:04 --> Config Class Initialized
INFO - 2023-12-07 09:11:04 --> Loader Class Initialized
INFO - 2023-12-07 09:11:04 --> Helper loaded: url_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: file_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: form_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: my_helper
INFO - 2023-12-07 09:11:04 --> Database Driver Class Initialized
INFO - 2023-12-07 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:11:04 --> Controller Class Initialized
INFO - 2023-12-07 09:11:04 --> Final output sent to browser
DEBUG - 2023-12-07 09:11:04 --> Total execution time: 0.0911
INFO - 2023-12-07 09:11:04 --> Config Class Initialized
INFO - 2023-12-07 09:11:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:11:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:11:04 --> Utf8 Class Initialized
INFO - 2023-12-07 09:11:04 --> URI Class Initialized
INFO - 2023-12-07 09:11:04 --> Router Class Initialized
INFO - 2023-12-07 09:11:04 --> Output Class Initialized
INFO - 2023-12-07 09:11:04 --> Security Class Initialized
DEBUG - 2023-12-07 09:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:11:04 --> Input Class Initialized
INFO - 2023-12-07 09:11:04 --> Language Class Initialized
INFO - 2023-12-07 09:11:04 --> Language Class Initialized
INFO - 2023-12-07 09:11:04 --> Config Class Initialized
INFO - 2023-12-07 09:11:04 --> Loader Class Initialized
INFO - 2023-12-07 09:11:04 --> Helper loaded: url_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: file_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: form_helper
INFO - 2023-12-07 09:11:04 --> Helper loaded: my_helper
INFO - 2023-12-07 09:11:04 --> Database Driver Class Initialized
INFO - 2023-12-07 09:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:11:04 --> Controller Class Initialized
INFO - 2023-12-07 09:11:51 --> Config Class Initialized
INFO - 2023-12-07 09:11:51 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:11:51 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:11:51 --> Utf8 Class Initialized
INFO - 2023-12-07 09:11:51 --> URI Class Initialized
INFO - 2023-12-07 09:11:51 --> Router Class Initialized
INFO - 2023-12-07 09:11:51 --> Output Class Initialized
INFO - 2023-12-07 09:11:51 --> Security Class Initialized
DEBUG - 2023-12-07 09:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:11:51 --> Input Class Initialized
INFO - 2023-12-07 09:11:51 --> Language Class Initialized
INFO - 2023-12-07 09:11:51 --> Language Class Initialized
INFO - 2023-12-07 09:11:51 --> Config Class Initialized
INFO - 2023-12-07 09:11:51 --> Loader Class Initialized
INFO - 2023-12-07 09:11:51 --> Helper loaded: url_helper
INFO - 2023-12-07 09:11:51 --> Helper loaded: file_helper
INFO - 2023-12-07 09:11:51 --> Helper loaded: form_helper
INFO - 2023-12-07 09:11:51 --> Helper loaded: my_helper
INFO - 2023-12-07 09:11:51 --> Database Driver Class Initialized
INFO - 2023-12-07 09:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:11:51 --> Controller Class Initialized
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:11:51 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:11:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:11:51 --> Final output sent to browser
DEBUG - 2023-12-07 09:11:51 --> Total execution time: 0.0468
INFO - 2023-12-07 09:11:54 --> Config Class Initialized
INFO - 2023-12-07 09:11:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:11:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:11:54 --> Utf8 Class Initialized
INFO - 2023-12-07 09:11:54 --> URI Class Initialized
INFO - 2023-12-07 09:11:54 --> Router Class Initialized
INFO - 2023-12-07 09:11:54 --> Output Class Initialized
INFO - 2023-12-07 09:11:54 --> Security Class Initialized
DEBUG - 2023-12-07 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:11:54 --> Input Class Initialized
INFO - 2023-12-07 09:11:54 --> Language Class Initialized
INFO - 2023-12-07 09:11:54 --> Language Class Initialized
INFO - 2023-12-07 09:11:54 --> Config Class Initialized
INFO - 2023-12-07 09:11:54 --> Loader Class Initialized
INFO - 2023-12-07 09:11:54 --> Helper loaded: url_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: file_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: form_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: my_helper
INFO - 2023-12-07 09:11:54 --> Database Driver Class Initialized
INFO - 2023-12-07 09:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:11:54 --> Controller Class Initialized
DEBUG - 2023-12-07 09:11:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:11:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:11:54 --> Final output sent to browser
DEBUG - 2023-12-07 09:11:54 --> Total execution time: 0.0429
INFO - 2023-12-07 09:11:54 --> Config Class Initialized
INFO - 2023-12-07 09:11:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:11:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:11:54 --> Utf8 Class Initialized
INFO - 2023-12-07 09:11:54 --> URI Class Initialized
INFO - 2023-12-07 09:11:54 --> Router Class Initialized
INFO - 2023-12-07 09:11:54 --> Output Class Initialized
INFO - 2023-12-07 09:11:54 --> Security Class Initialized
DEBUG - 2023-12-07 09:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:11:54 --> Input Class Initialized
INFO - 2023-12-07 09:11:54 --> Language Class Initialized
INFO - 2023-12-07 09:11:54 --> Language Class Initialized
INFO - 2023-12-07 09:11:54 --> Config Class Initialized
INFO - 2023-12-07 09:11:54 --> Loader Class Initialized
INFO - 2023-12-07 09:11:54 --> Helper loaded: url_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: file_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: form_helper
INFO - 2023-12-07 09:11:54 --> Helper loaded: my_helper
INFO - 2023-12-07 09:11:54 --> Database Driver Class Initialized
INFO - 2023-12-07 09:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:11:54 --> Controller Class Initialized
INFO - 2023-12-07 09:12:05 --> Config Class Initialized
INFO - 2023-12-07 09:12:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:05 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:05 --> URI Class Initialized
INFO - 2023-12-07 09:12:05 --> Router Class Initialized
INFO - 2023-12-07 09:12:05 --> Output Class Initialized
INFO - 2023-12-07 09:12:05 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:05 --> Input Class Initialized
INFO - 2023-12-07 09:12:05 --> Language Class Initialized
INFO - 2023-12-07 09:12:05 --> Language Class Initialized
INFO - 2023-12-07 09:12:05 --> Config Class Initialized
INFO - 2023-12-07 09:12:05 --> Loader Class Initialized
INFO - 2023-12-07 09:12:05 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:05 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:05 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:05 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:05 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:05 --> Controller Class Initialized
INFO - 2023-12-07 09:12:05 --> Final output sent to browser
DEBUG - 2023-12-07 09:12:05 --> Total execution time: 0.0411
INFO - 2023-12-07 09:12:13 --> Config Class Initialized
INFO - 2023-12-07 09:12:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:13 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:13 --> URI Class Initialized
INFO - 2023-12-07 09:12:13 --> Router Class Initialized
INFO - 2023-12-07 09:12:13 --> Output Class Initialized
INFO - 2023-12-07 09:12:13 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:13 --> Input Class Initialized
INFO - 2023-12-07 09:12:13 --> Language Class Initialized
INFO - 2023-12-07 09:12:13 --> Language Class Initialized
INFO - 2023-12-07 09:12:13 --> Config Class Initialized
INFO - 2023-12-07 09:12:13 --> Loader Class Initialized
INFO - 2023-12-07 09:12:13 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:13 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:13 --> Controller Class Initialized
INFO - 2023-12-07 09:12:13 --> Final output sent to browser
DEBUG - 2023-12-07 09:12:13 --> Total execution time: 0.0377
INFO - 2023-12-07 09:12:13 --> Config Class Initialized
INFO - 2023-12-07 09:12:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:13 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:13 --> URI Class Initialized
INFO - 2023-12-07 09:12:13 --> Router Class Initialized
INFO - 2023-12-07 09:12:13 --> Output Class Initialized
INFO - 2023-12-07 09:12:13 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:13 --> Input Class Initialized
INFO - 2023-12-07 09:12:13 --> Language Class Initialized
INFO - 2023-12-07 09:12:13 --> Language Class Initialized
INFO - 2023-12-07 09:12:13 --> Config Class Initialized
INFO - 2023-12-07 09:12:13 --> Loader Class Initialized
INFO - 2023-12-07 09:12:13 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:13 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:13 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:13 --> Controller Class Initialized
INFO - 2023-12-07 09:12:24 --> Config Class Initialized
INFO - 2023-12-07 09:12:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:24 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:24 --> URI Class Initialized
INFO - 2023-12-07 09:12:24 --> Router Class Initialized
INFO - 2023-12-07 09:12:24 --> Output Class Initialized
INFO - 2023-12-07 09:12:24 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:24 --> Input Class Initialized
INFO - 2023-12-07 09:12:24 --> Language Class Initialized
INFO - 2023-12-07 09:12:24 --> Language Class Initialized
INFO - 2023-12-07 09:12:24 --> Config Class Initialized
INFO - 2023-12-07 09:12:24 --> Loader Class Initialized
INFO - 2023-12-07 09:12:24 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:24 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:24 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:24 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:24 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:24 --> Controller Class Initialized
INFO - 2023-12-07 09:12:24 --> Final output sent to browser
DEBUG - 2023-12-07 09:12:24 --> Total execution time: 0.0404
INFO - 2023-12-07 09:12:54 --> Config Class Initialized
INFO - 2023-12-07 09:12:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:54 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:54 --> URI Class Initialized
INFO - 2023-12-07 09:12:54 --> Router Class Initialized
INFO - 2023-12-07 09:12:54 --> Output Class Initialized
INFO - 2023-12-07 09:12:54 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:54 --> Input Class Initialized
INFO - 2023-12-07 09:12:54 --> Language Class Initialized
INFO - 2023-12-07 09:12:54 --> Language Class Initialized
INFO - 2023-12-07 09:12:54 --> Config Class Initialized
INFO - 2023-12-07 09:12:54 --> Loader Class Initialized
INFO - 2023-12-07 09:12:54 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:54 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:54 --> Controller Class Initialized
INFO - 2023-12-07 09:12:54 --> Final output sent to browser
DEBUG - 2023-12-07 09:12:54 --> Total execution time: 0.0360
INFO - 2023-12-07 09:12:54 --> Config Class Initialized
INFO - 2023-12-07 09:12:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:12:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:12:54 --> Utf8 Class Initialized
INFO - 2023-12-07 09:12:54 --> URI Class Initialized
INFO - 2023-12-07 09:12:54 --> Router Class Initialized
INFO - 2023-12-07 09:12:54 --> Output Class Initialized
INFO - 2023-12-07 09:12:54 --> Security Class Initialized
DEBUG - 2023-12-07 09:12:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:12:54 --> Input Class Initialized
INFO - 2023-12-07 09:12:54 --> Language Class Initialized
INFO - 2023-12-07 09:12:54 --> Language Class Initialized
INFO - 2023-12-07 09:12:54 --> Config Class Initialized
INFO - 2023-12-07 09:12:54 --> Loader Class Initialized
INFO - 2023-12-07 09:12:54 --> Helper loaded: url_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: file_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: form_helper
INFO - 2023-12-07 09:12:54 --> Helper loaded: my_helper
INFO - 2023-12-07 09:12:54 --> Database Driver Class Initialized
INFO - 2023-12-07 09:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:12:54 --> Controller Class Initialized
INFO - 2023-12-07 09:13:18 --> Config Class Initialized
INFO - 2023-12-07 09:13:18 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:13:18 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:13:18 --> Utf8 Class Initialized
INFO - 2023-12-07 09:13:18 --> URI Class Initialized
INFO - 2023-12-07 09:13:18 --> Router Class Initialized
INFO - 2023-12-07 09:13:18 --> Output Class Initialized
INFO - 2023-12-07 09:13:18 --> Security Class Initialized
DEBUG - 2023-12-07 09:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:13:18 --> Input Class Initialized
INFO - 2023-12-07 09:13:18 --> Language Class Initialized
INFO - 2023-12-07 09:13:18 --> Language Class Initialized
INFO - 2023-12-07 09:13:18 --> Config Class Initialized
INFO - 2023-12-07 09:13:18 --> Loader Class Initialized
INFO - 2023-12-07 09:13:18 --> Helper loaded: url_helper
INFO - 2023-12-07 09:13:18 --> Helper loaded: file_helper
INFO - 2023-12-07 09:13:18 --> Helper loaded: form_helper
INFO - 2023-12-07 09:13:18 --> Helper loaded: my_helper
INFO - 2023-12-07 09:13:18 --> Database Driver Class Initialized
INFO - 2023-12-07 09:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:13:18 --> Controller Class Initialized
INFO - 2023-12-07 09:13:18 --> Final output sent to browser
DEBUG - 2023-12-07 09:13:18 --> Total execution time: 0.0318
INFO - 2023-12-07 09:13:45 --> Config Class Initialized
INFO - 2023-12-07 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:13:45 --> Utf8 Class Initialized
INFO - 2023-12-07 09:13:45 --> URI Class Initialized
INFO - 2023-12-07 09:13:45 --> Router Class Initialized
INFO - 2023-12-07 09:13:45 --> Output Class Initialized
INFO - 2023-12-07 09:13:45 --> Security Class Initialized
DEBUG - 2023-12-07 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:13:45 --> Input Class Initialized
INFO - 2023-12-07 09:13:45 --> Language Class Initialized
INFO - 2023-12-07 09:13:45 --> Language Class Initialized
INFO - 2023-12-07 09:13:45 --> Config Class Initialized
INFO - 2023-12-07 09:13:45 --> Loader Class Initialized
INFO - 2023-12-07 09:13:45 --> Helper loaded: url_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: file_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: form_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: my_helper
INFO - 2023-12-07 09:13:45 --> Database Driver Class Initialized
INFO - 2023-12-07 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:13:45 --> Controller Class Initialized
INFO - 2023-12-07 09:13:45 --> Final output sent to browser
DEBUG - 2023-12-07 09:13:45 --> Total execution time: 0.0501
INFO - 2023-12-07 09:13:45 --> Config Class Initialized
INFO - 2023-12-07 09:13:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:13:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:13:45 --> Utf8 Class Initialized
INFO - 2023-12-07 09:13:45 --> URI Class Initialized
INFO - 2023-12-07 09:13:45 --> Router Class Initialized
INFO - 2023-12-07 09:13:45 --> Output Class Initialized
INFO - 2023-12-07 09:13:45 --> Security Class Initialized
DEBUG - 2023-12-07 09:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:13:45 --> Input Class Initialized
INFO - 2023-12-07 09:13:45 --> Language Class Initialized
INFO - 2023-12-07 09:13:45 --> Language Class Initialized
INFO - 2023-12-07 09:13:45 --> Config Class Initialized
INFO - 2023-12-07 09:13:45 --> Loader Class Initialized
INFO - 2023-12-07 09:13:45 --> Helper loaded: url_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: file_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: form_helper
INFO - 2023-12-07 09:13:45 --> Helper loaded: my_helper
INFO - 2023-12-07 09:13:45 --> Database Driver Class Initialized
INFO - 2023-12-07 09:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:13:45 --> Controller Class Initialized
INFO - 2023-12-07 09:14:46 --> Config Class Initialized
INFO - 2023-12-07 09:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:14:46 --> Utf8 Class Initialized
INFO - 2023-12-07 09:14:46 --> URI Class Initialized
INFO - 2023-12-07 09:14:46 --> Router Class Initialized
INFO - 2023-12-07 09:14:46 --> Output Class Initialized
INFO - 2023-12-07 09:14:46 --> Security Class Initialized
DEBUG - 2023-12-07 09:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:14:46 --> Input Class Initialized
INFO - 2023-12-07 09:14:46 --> Language Class Initialized
INFO - 2023-12-07 09:14:46 --> Language Class Initialized
INFO - 2023-12-07 09:14:46 --> Config Class Initialized
INFO - 2023-12-07 09:14:46 --> Loader Class Initialized
INFO - 2023-12-07 09:14:46 --> Helper loaded: url_helper
INFO - 2023-12-07 09:14:46 --> Helper loaded: file_helper
INFO - 2023-12-07 09:14:46 --> Helper loaded: form_helper
INFO - 2023-12-07 09:14:46 --> Helper loaded: my_helper
INFO - 2023-12-07 09:14:46 --> Database Driver Class Initialized
INFO - 2023-12-07 09:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:14:46 --> Controller Class Initialized
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:14:46 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:14:46 --> Final output sent to browser
DEBUG - 2023-12-07 09:14:46 --> Total execution time: 0.0373
INFO - 2023-12-07 09:14:49 --> Config Class Initialized
INFO - 2023-12-07 09:14:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:14:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:14:49 --> Utf8 Class Initialized
INFO - 2023-12-07 09:14:49 --> URI Class Initialized
INFO - 2023-12-07 09:14:49 --> Router Class Initialized
INFO - 2023-12-07 09:14:49 --> Output Class Initialized
INFO - 2023-12-07 09:14:49 --> Security Class Initialized
DEBUG - 2023-12-07 09:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:14:49 --> Input Class Initialized
INFO - 2023-12-07 09:14:49 --> Language Class Initialized
INFO - 2023-12-07 09:14:49 --> Language Class Initialized
INFO - 2023-12-07 09:14:49 --> Config Class Initialized
INFO - 2023-12-07 09:14:49 --> Loader Class Initialized
INFO - 2023-12-07 09:14:49 --> Helper loaded: url_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: file_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: form_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: my_helper
INFO - 2023-12-07 09:14:49 --> Database Driver Class Initialized
INFO - 2023-12-07 09:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:14:49 --> Controller Class Initialized
DEBUG - 2023-12-07 09:14:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:14:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:14:49 --> Final output sent to browser
DEBUG - 2023-12-07 09:14:49 --> Total execution time: 0.0420
INFO - 2023-12-07 09:14:49 --> Config Class Initialized
INFO - 2023-12-07 09:14:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:14:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:14:49 --> Utf8 Class Initialized
INFO - 2023-12-07 09:14:49 --> URI Class Initialized
INFO - 2023-12-07 09:14:49 --> Router Class Initialized
INFO - 2023-12-07 09:14:49 --> Output Class Initialized
INFO - 2023-12-07 09:14:49 --> Security Class Initialized
DEBUG - 2023-12-07 09:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:14:49 --> Input Class Initialized
INFO - 2023-12-07 09:14:49 --> Language Class Initialized
INFO - 2023-12-07 09:14:49 --> Language Class Initialized
INFO - 2023-12-07 09:14:49 --> Config Class Initialized
INFO - 2023-12-07 09:14:49 --> Loader Class Initialized
INFO - 2023-12-07 09:14:49 --> Helper loaded: url_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: file_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: form_helper
INFO - 2023-12-07 09:14:49 --> Helper loaded: my_helper
INFO - 2023-12-07 09:14:49 --> Database Driver Class Initialized
INFO - 2023-12-07 09:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:14:49 --> Controller Class Initialized
INFO - 2023-12-07 09:14:55 --> Config Class Initialized
INFO - 2023-12-07 09:14:55 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:14:55 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:14:55 --> Utf8 Class Initialized
INFO - 2023-12-07 09:14:55 --> URI Class Initialized
INFO - 2023-12-07 09:14:55 --> Router Class Initialized
INFO - 2023-12-07 09:14:56 --> Output Class Initialized
INFO - 2023-12-07 09:14:56 --> Security Class Initialized
DEBUG - 2023-12-07 09:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:14:56 --> Input Class Initialized
INFO - 2023-12-07 09:14:56 --> Language Class Initialized
INFO - 2023-12-07 09:14:56 --> Language Class Initialized
INFO - 2023-12-07 09:14:56 --> Config Class Initialized
INFO - 2023-12-07 09:14:56 --> Loader Class Initialized
INFO - 2023-12-07 09:14:56 --> Helper loaded: url_helper
INFO - 2023-12-07 09:14:56 --> Helper loaded: file_helper
INFO - 2023-12-07 09:14:56 --> Helper loaded: form_helper
INFO - 2023-12-07 09:14:56 --> Helper loaded: my_helper
INFO - 2023-12-07 09:14:56 --> Database Driver Class Initialized
INFO - 2023-12-07 09:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:14:56 --> Controller Class Initialized
INFO - 2023-12-07 09:14:56 --> Final output sent to browser
DEBUG - 2023-12-07 09:14:56 --> Total execution time: 0.0326
INFO - 2023-12-07 09:15:11 --> Config Class Initialized
INFO - 2023-12-07 09:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:11 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:11 --> URI Class Initialized
INFO - 2023-12-07 09:15:11 --> Router Class Initialized
INFO - 2023-12-07 09:15:11 --> Output Class Initialized
INFO - 2023-12-07 09:15:11 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:11 --> Input Class Initialized
INFO - 2023-12-07 09:15:11 --> Language Class Initialized
INFO - 2023-12-07 09:15:11 --> Language Class Initialized
INFO - 2023-12-07 09:15:11 --> Config Class Initialized
INFO - 2023-12-07 09:15:11 --> Loader Class Initialized
INFO - 2023-12-07 09:15:11 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:11 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:11 --> Controller Class Initialized
INFO - 2023-12-07 09:15:11 --> Final output sent to browser
DEBUG - 2023-12-07 09:15:11 --> Total execution time: 0.0389
INFO - 2023-12-07 09:15:11 --> Config Class Initialized
INFO - 2023-12-07 09:15:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:11 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:11 --> URI Class Initialized
INFO - 2023-12-07 09:15:11 --> Router Class Initialized
INFO - 2023-12-07 09:15:11 --> Output Class Initialized
INFO - 2023-12-07 09:15:11 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:11 --> Input Class Initialized
INFO - 2023-12-07 09:15:11 --> Language Class Initialized
INFO - 2023-12-07 09:15:11 --> Language Class Initialized
INFO - 2023-12-07 09:15:11 --> Config Class Initialized
INFO - 2023-12-07 09:15:11 --> Loader Class Initialized
INFO - 2023-12-07 09:15:11 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:11 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:11 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:11 --> Controller Class Initialized
INFO - 2023-12-07 09:15:13 --> Config Class Initialized
INFO - 2023-12-07 09:15:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:13 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:13 --> URI Class Initialized
INFO - 2023-12-07 09:15:13 --> Router Class Initialized
INFO - 2023-12-07 09:15:13 --> Output Class Initialized
INFO - 2023-12-07 09:15:13 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:13 --> Input Class Initialized
INFO - 2023-12-07 09:15:13 --> Language Class Initialized
INFO - 2023-12-07 09:15:13 --> Language Class Initialized
INFO - 2023-12-07 09:15:13 --> Config Class Initialized
INFO - 2023-12-07 09:15:13 --> Loader Class Initialized
INFO - 2023-12-07 09:15:13 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:13 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:13 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:13 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:13 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:13 --> Controller Class Initialized
INFO - 2023-12-07 09:15:13 --> Final output sent to browser
DEBUG - 2023-12-07 09:15:13 --> Total execution time: 0.0325
INFO - 2023-12-07 09:15:33 --> Config Class Initialized
INFO - 2023-12-07 09:15:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:33 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:33 --> URI Class Initialized
INFO - 2023-12-07 09:15:33 --> Router Class Initialized
INFO - 2023-12-07 09:15:33 --> Output Class Initialized
INFO - 2023-12-07 09:15:33 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:33 --> Input Class Initialized
INFO - 2023-12-07 09:15:33 --> Language Class Initialized
INFO - 2023-12-07 09:15:33 --> Language Class Initialized
INFO - 2023-12-07 09:15:33 --> Config Class Initialized
INFO - 2023-12-07 09:15:33 --> Loader Class Initialized
INFO - 2023-12-07 09:15:33 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:33 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:33 --> Controller Class Initialized
INFO - 2023-12-07 09:15:33 --> Final output sent to browser
DEBUG - 2023-12-07 09:15:33 --> Total execution time: 0.0354
INFO - 2023-12-07 09:15:33 --> Config Class Initialized
INFO - 2023-12-07 09:15:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:33 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:33 --> URI Class Initialized
INFO - 2023-12-07 09:15:33 --> Router Class Initialized
INFO - 2023-12-07 09:15:33 --> Output Class Initialized
INFO - 2023-12-07 09:15:33 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:33 --> Input Class Initialized
INFO - 2023-12-07 09:15:33 --> Language Class Initialized
INFO - 2023-12-07 09:15:33 --> Language Class Initialized
INFO - 2023-12-07 09:15:33 --> Config Class Initialized
INFO - 2023-12-07 09:15:33 --> Loader Class Initialized
INFO - 2023-12-07 09:15:33 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:33 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:33 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:33 --> Controller Class Initialized
INFO - 2023-12-07 09:15:53 --> Config Class Initialized
INFO - 2023-12-07 09:15:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:15:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:15:53 --> Utf8 Class Initialized
INFO - 2023-12-07 09:15:53 --> URI Class Initialized
INFO - 2023-12-07 09:15:53 --> Router Class Initialized
INFO - 2023-12-07 09:15:53 --> Output Class Initialized
INFO - 2023-12-07 09:15:53 --> Security Class Initialized
DEBUG - 2023-12-07 09:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:15:53 --> Input Class Initialized
INFO - 2023-12-07 09:15:53 --> Language Class Initialized
INFO - 2023-12-07 09:15:53 --> Language Class Initialized
INFO - 2023-12-07 09:15:53 --> Config Class Initialized
INFO - 2023-12-07 09:15:53 --> Loader Class Initialized
INFO - 2023-12-07 09:15:53 --> Helper loaded: url_helper
INFO - 2023-12-07 09:15:53 --> Helper loaded: file_helper
INFO - 2023-12-07 09:15:53 --> Helper loaded: form_helper
INFO - 2023-12-07 09:15:53 --> Helper loaded: my_helper
INFO - 2023-12-07 09:15:53 --> Database Driver Class Initialized
INFO - 2023-12-07 09:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:15:53 --> Controller Class Initialized
INFO - 2023-12-07 09:15:53 --> Final output sent to browser
DEBUG - 2023-12-07 09:15:53 --> Total execution time: 0.0328
INFO - 2023-12-07 09:16:02 --> Config Class Initialized
INFO - 2023-12-07 09:16:02 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:02 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:02 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:02 --> URI Class Initialized
INFO - 2023-12-07 09:16:02 --> Router Class Initialized
INFO - 2023-12-07 09:16:02 --> Output Class Initialized
INFO - 2023-12-07 09:16:02 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:02 --> Input Class Initialized
INFO - 2023-12-07 09:16:02 --> Language Class Initialized
INFO - 2023-12-07 09:16:02 --> Language Class Initialized
INFO - 2023-12-07 09:16:02 --> Config Class Initialized
INFO - 2023-12-07 09:16:02 --> Loader Class Initialized
INFO - 2023-12-07 09:16:02 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:02 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:02 --> Controller Class Initialized
INFO - 2023-12-07 09:16:02 --> Final output sent to browser
DEBUG - 2023-12-07 09:16:02 --> Total execution time: 0.2554
INFO - 2023-12-07 09:16:02 --> Config Class Initialized
INFO - 2023-12-07 09:16:02 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:02 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:02 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:02 --> URI Class Initialized
INFO - 2023-12-07 09:16:02 --> Router Class Initialized
INFO - 2023-12-07 09:16:02 --> Output Class Initialized
INFO - 2023-12-07 09:16:02 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:02 --> Input Class Initialized
INFO - 2023-12-07 09:16:02 --> Language Class Initialized
INFO - 2023-12-07 09:16:02 --> Language Class Initialized
INFO - 2023-12-07 09:16:02 --> Config Class Initialized
INFO - 2023-12-07 09:16:02 --> Loader Class Initialized
INFO - 2023-12-07 09:16:02 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:02 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:02 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:02 --> Controller Class Initialized
INFO - 2023-12-07 09:16:22 --> Config Class Initialized
INFO - 2023-12-07 09:16:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:22 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:22 --> URI Class Initialized
INFO - 2023-12-07 09:16:22 --> Router Class Initialized
INFO - 2023-12-07 09:16:22 --> Output Class Initialized
INFO - 2023-12-07 09:16:22 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:22 --> Input Class Initialized
INFO - 2023-12-07 09:16:22 --> Language Class Initialized
INFO - 2023-12-07 09:16:22 --> Language Class Initialized
INFO - 2023-12-07 09:16:22 --> Config Class Initialized
INFO - 2023-12-07 09:16:22 --> Loader Class Initialized
INFO - 2023-12-07 09:16:22 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:22 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:22 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:22 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:22 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:22 --> Controller Class Initialized
INFO - 2023-12-07 09:16:22 --> Final output sent to browser
DEBUG - 2023-12-07 09:16:22 --> Total execution time: 0.0404
INFO - 2023-12-07 09:16:28 --> Config Class Initialized
INFO - 2023-12-07 09:16:28 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:28 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:28 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:28 --> URI Class Initialized
INFO - 2023-12-07 09:16:28 --> Router Class Initialized
INFO - 2023-12-07 09:16:28 --> Output Class Initialized
INFO - 2023-12-07 09:16:28 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:28 --> Input Class Initialized
INFO - 2023-12-07 09:16:28 --> Language Class Initialized
INFO - 2023-12-07 09:16:28 --> Language Class Initialized
INFO - 2023-12-07 09:16:28 --> Config Class Initialized
INFO - 2023-12-07 09:16:28 --> Loader Class Initialized
INFO - 2023-12-07 09:16:28 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:28 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:29 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:29 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:29 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:29 --> Controller Class Initialized
INFO - 2023-12-07 09:16:29 --> Final output sent to browser
DEBUG - 2023-12-07 09:16:29 --> Total execution time: 0.0398
INFO - 2023-12-07 09:16:29 --> Config Class Initialized
INFO - 2023-12-07 09:16:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:29 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:29 --> URI Class Initialized
INFO - 2023-12-07 09:16:29 --> Router Class Initialized
INFO - 2023-12-07 09:16:29 --> Output Class Initialized
INFO - 2023-12-07 09:16:29 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:29 --> Input Class Initialized
INFO - 2023-12-07 09:16:29 --> Language Class Initialized
INFO - 2023-12-07 09:16:29 --> Language Class Initialized
INFO - 2023-12-07 09:16:29 --> Config Class Initialized
INFO - 2023-12-07 09:16:29 --> Loader Class Initialized
INFO - 2023-12-07 09:16:29 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:29 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:29 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:29 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:29 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:29 --> Controller Class Initialized
INFO - 2023-12-07 09:16:57 --> Config Class Initialized
INFO - 2023-12-07 09:16:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:16:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:16:57 --> Utf8 Class Initialized
INFO - 2023-12-07 09:16:57 --> URI Class Initialized
INFO - 2023-12-07 09:16:57 --> Router Class Initialized
INFO - 2023-12-07 09:16:57 --> Output Class Initialized
INFO - 2023-12-07 09:16:57 --> Security Class Initialized
DEBUG - 2023-12-07 09:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:16:57 --> Input Class Initialized
INFO - 2023-12-07 09:16:57 --> Language Class Initialized
INFO - 2023-12-07 09:16:57 --> Language Class Initialized
INFO - 2023-12-07 09:16:57 --> Config Class Initialized
INFO - 2023-12-07 09:16:57 --> Loader Class Initialized
INFO - 2023-12-07 09:16:57 --> Helper loaded: url_helper
INFO - 2023-12-07 09:16:57 --> Helper loaded: file_helper
INFO - 2023-12-07 09:16:57 --> Helper loaded: form_helper
INFO - 2023-12-07 09:16:57 --> Helper loaded: my_helper
INFO - 2023-12-07 09:16:57 --> Database Driver Class Initialized
INFO - 2023-12-07 09:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:16:57 --> Controller Class Initialized
INFO - 2023-12-07 09:16:57 --> Final output sent to browser
DEBUG - 2023-12-07 09:16:57 --> Total execution time: 0.0296
INFO - 2023-12-07 09:17:06 --> Config Class Initialized
INFO - 2023-12-07 09:17:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:06 --> URI Class Initialized
INFO - 2023-12-07 09:17:06 --> Router Class Initialized
INFO - 2023-12-07 09:17:06 --> Output Class Initialized
INFO - 2023-12-07 09:17:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:06 --> Input Class Initialized
INFO - 2023-12-07 09:17:06 --> Language Class Initialized
INFO - 2023-12-07 09:17:06 --> Language Class Initialized
INFO - 2023-12-07 09:17:06 --> Config Class Initialized
INFO - 2023-12-07 09:17:06 --> Loader Class Initialized
INFO - 2023-12-07 09:17:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:06 --> Controller Class Initialized
INFO - 2023-12-07 09:17:06 --> Final output sent to browser
DEBUG - 2023-12-07 09:17:06 --> Total execution time: 0.0334
INFO - 2023-12-07 09:17:06 --> Config Class Initialized
INFO - 2023-12-07 09:17:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:06 --> URI Class Initialized
INFO - 2023-12-07 09:17:06 --> Router Class Initialized
INFO - 2023-12-07 09:17:06 --> Output Class Initialized
INFO - 2023-12-07 09:17:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:06 --> Input Class Initialized
INFO - 2023-12-07 09:17:06 --> Language Class Initialized
INFO - 2023-12-07 09:17:06 --> Language Class Initialized
INFO - 2023-12-07 09:17:06 --> Config Class Initialized
INFO - 2023-12-07 09:17:06 --> Loader Class Initialized
INFO - 2023-12-07 09:17:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:06 --> Controller Class Initialized
INFO - 2023-12-07 09:17:08 --> Config Class Initialized
INFO - 2023-12-07 09:17:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:08 --> URI Class Initialized
INFO - 2023-12-07 09:17:08 --> Router Class Initialized
INFO - 2023-12-07 09:17:08 --> Output Class Initialized
INFO - 2023-12-07 09:17:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:08 --> Input Class Initialized
INFO - 2023-12-07 09:17:08 --> Language Class Initialized
INFO - 2023-12-07 09:17:08 --> Language Class Initialized
INFO - 2023-12-07 09:17:08 --> Config Class Initialized
INFO - 2023-12-07 09:17:08 --> Loader Class Initialized
INFO - 2023-12-07 09:17:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:08 --> Controller Class Initialized
INFO - 2023-12-07 09:17:08 --> Final output sent to browser
DEBUG - 2023-12-07 09:17:08 --> Total execution time: 0.0400
INFO - 2023-12-07 09:17:31 --> Config Class Initialized
INFO - 2023-12-07 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:31 --> URI Class Initialized
INFO - 2023-12-07 09:17:31 --> Router Class Initialized
INFO - 2023-12-07 09:17:31 --> Output Class Initialized
INFO - 2023-12-07 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:31 --> Input Class Initialized
INFO - 2023-12-07 09:17:31 --> Language Class Initialized
INFO - 2023-12-07 09:17:31 --> Language Class Initialized
INFO - 2023-12-07 09:17:31 --> Config Class Initialized
INFO - 2023-12-07 09:17:31 --> Loader Class Initialized
INFO - 2023-12-07 09:17:31 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:31 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:31 --> Controller Class Initialized
INFO - 2023-12-07 09:17:31 --> Final output sent to browser
DEBUG - 2023-12-07 09:17:31 --> Total execution time: 0.0333
INFO - 2023-12-07 09:17:31 --> Config Class Initialized
INFO - 2023-12-07 09:17:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:31 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:31 --> URI Class Initialized
INFO - 2023-12-07 09:17:31 --> Router Class Initialized
INFO - 2023-12-07 09:17:31 --> Output Class Initialized
INFO - 2023-12-07 09:17:31 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:31 --> Input Class Initialized
INFO - 2023-12-07 09:17:31 --> Language Class Initialized
INFO - 2023-12-07 09:17:31 --> Language Class Initialized
INFO - 2023-12-07 09:17:31 --> Config Class Initialized
INFO - 2023-12-07 09:17:31 --> Loader Class Initialized
INFO - 2023-12-07 09:17:31 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:31 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:31 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:31 --> Controller Class Initialized
INFO - 2023-12-07 09:17:40 --> Config Class Initialized
INFO - 2023-12-07 09:17:40 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:40 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:40 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:40 --> URI Class Initialized
INFO - 2023-12-07 09:17:40 --> Router Class Initialized
INFO - 2023-12-07 09:17:40 --> Output Class Initialized
INFO - 2023-12-07 09:17:40 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:40 --> Input Class Initialized
INFO - 2023-12-07 09:17:40 --> Language Class Initialized
INFO - 2023-12-07 09:17:40 --> Language Class Initialized
INFO - 2023-12-07 09:17:40 --> Config Class Initialized
INFO - 2023-12-07 09:17:40 --> Loader Class Initialized
INFO - 2023-12-07 09:17:40 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:40 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:40 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:40 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:40 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:40 --> Controller Class Initialized
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:17:40 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:17:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:17:40 --> Final output sent to browser
DEBUG - 2023-12-07 09:17:40 --> Total execution time: 0.0840
INFO - 2023-12-07 09:17:52 --> Config Class Initialized
INFO - 2023-12-07 09:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:52 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:52 --> URI Class Initialized
INFO - 2023-12-07 09:17:52 --> Router Class Initialized
INFO - 2023-12-07 09:17:52 --> Output Class Initialized
INFO - 2023-12-07 09:17:52 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:52 --> Input Class Initialized
INFO - 2023-12-07 09:17:52 --> Language Class Initialized
INFO - 2023-12-07 09:17:52 --> Language Class Initialized
INFO - 2023-12-07 09:17:52 --> Config Class Initialized
INFO - 2023-12-07 09:17:52 --> Loader Class Initialized
INFO - 2023-12-07 09:17:52 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:52 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:52 --> Controller Class Initialized
DEBUG - 2023-12-07 09:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:17:52 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:17:52 --> Final output sent to browser
DEBUG - 2023-12-07 09:17:52 --> Total execution time: 0.0436
INFO - 2023-12-07 09:17:52 --> Config Class Initialized
INFO - 2023-12-07 09:17:52 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:17:52 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:17:52 --> Utf8 Class Initialized
INFO - 2023-12-07 09:17:52 --> URI Class Initialized
INFO - 2023-12-07 09:17:52 --> Router Class Initialized
INFO - 2023-12-07 09:17:52 --> Output Class Initialized
INFO - 2023-12-07 09:17:52 --> Security Class Initialized
DEBUG - 2023-12-07 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:17:52 --> Input Class Initialized
INFO - 2023-12-07 09:17:52 --> Language Class Initialized
INFO - 2023-12-07 09:17:52 --> Language Class Initialized
INFO - 2023-12-07 09:17:52 --> Config Class Initialized
INFO - 2023-12-07 09:17:52 --> Loader Class Initialized
INFO - 2023-12-07 09:17:52 --> Helper loaded: url_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: file_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: form_helper
INFO - 2023-12-07 09:17:52 --> Helper loaded: my_helper
INFO - 2023-12-07 09:17:52 --> Database Driver Class Initialized
INFO - 2023-12-07 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:17:52 --> Controller Class Initialized
INFO - 2023-12-07 09:18:05 --> Config Class Initialized
INFO - 2023-12-07 09:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:05 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:05 --> URI Class Initialized
INFO - 2023-12-07 09:18:05 --> Router Class Initialized
INFO - 2023-12-07 09:18:05 --> Output Class Initialized
INFO - 2023-12-07 09:18:05 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:05 --> Input Class Initialized
INFO - 2023-12-07 09:18:05 --> Language Class Initialized
INFO - 2023-12-07 09:18:05 --> Language Class Initialized
INFO - 2023-12-07 09:18:05 --> Config Class Initialized
INFO - 2023-12-07 09:18:05 --> Loader Class Initialized
INFO - 2023-12-07 09:18:05 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:05 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:05 --> Controller Class Initialized
INFO - 2023-12-07 09:18:05 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:05 --> Total execution time: 0.0596
INFO - 2023-12-07 09:18:05 --> Config Class Initialized
INFO - 2023-12-07 09:18:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:05 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:05 --> URI Class Initialized
INFO - 2023-12-07 09:18:05 --> Router Class Initialized
INFO - 2023-12-07 09:18:05 --> Output Class Initialized
INFO - 2023-12-07 09:18:05 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:05 --> Input Class Initialized
INFO - 2023-12-07 09:18:05 --> Language Class Initialized
INFO - 2023-12-07 09:18:05 --> Language Class Initialized
INFO - 2023-12-07 09:18:05 --> Config Class Initialized
INFO - 2023-12-07 09:18:05 --> Loader Class Initialized
INFO - 2023-12-07 09:18:05 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:05 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:05 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:05 --> Controller Class Initialized
INFO - 2023-12-07 09:18:08 --> Config Class Initialized
INFO - 2023-12-07 09:18:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:08 --> URI Class Initialized
INFO - 2023-12-07 09:18:08 --> Router Class Initialized
INFO - 2023-12-07 09:18:08 --> Output Class Initialized
INFO - 2023-12-07 09:18:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:08 --> Input Class Initialized
INFO - 2023-12-07 09:18:08 --> Language Class Initialized
INFO - 2023-12-07 09:18:08 --> Language Class Initialized
INFO - 2023-12-07 09:18:08 --> Config Class Initialized
INFO - 2023-12-07 09:18:08 --> Loader Class Initialized
INFO - 2023-12-07 09:18:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:08 --> Controller Class Initialized
INFO - 2023-12-07 09:18:08 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:08 --> Total execution time: 0.0366
INFO - 2023-12-07 09:18:09 --> Config Class Initialized
INFO - 2023-12-07 09:18:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:09 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:09 --> URI Class Initialized
INFO - 2023-12-07 09:18:09 --> Router Class Initialized
INFO - 2023-12-07 09:18:09 --> Output Class Initialized
INFO - 2023-12-07 09:18:09 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:09 --> Input Class Initialized
INFO - 2023-12-07 09:18:09 --> Language Class Initialized
INFO - 2023-12-07 09:18:09 --> Language Class Initialized
INFO - 2023-12-07 09:18:09 --> Config Class Initialized
INFO - 2023-12-07 09:18:09 --> Loader Class Initialized
INFO - 2023-12-07 09:18:09 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:09 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:09 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:09 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:09 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:09 --> Controller Class Initialized
INFO - 2023-12-07 09:18:15 --> Config Class Initialized
INFO - 2023-12-07 09:18:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:15 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:15 --> URI Class Initialized
INFO - 2023-12-07 09:18:15 --> Router Class Initialized
INFO - 2023-12-07 09:18:15 --> Output Class Initialized
INFO - 2023-12-07 09:18:15 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:15 --> Input Class Initialized
INFO - 2023-12-07 09:18:15 --> Language Class Initialized
INFO - 2023-12-07 09:18:15 --> Language Class Initialized
INFO - 2023-12-07 09:18:15 --> Config Class Initialized
INFO - 2023-12-07 09:18:15 --> Loader Class Initialized
INFO - 2023-12-07 09:18:15 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:15 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:15 --> Controller Class Initialized
INFO - 2023-12-07 09:18:15 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:15 --> Total execution time: 0.0865
INFO - 2023-12-07 09:18:15 --> Config Class Initialized
INFO - 2023-12-07 09:18:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:15 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:15 --> URI Class Initialized
INFO - 2023-12-07 09:18:15 --> Router Class Initialized
INFO - 2023-12-07 09:18:15 --> Output Class Initialized
INFO - 2023-12-07 09:18:15 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:15 --> Input Class Initialized
INFO - 2023-12-07 09:18:15 --> Language Class Initialized
INFO - 2023-12-07 09:18:15 --> Language Class Initialized
INFO - 2023-12-07 09:18:15 --> Config Class Initialized
INFO - 2023-12-07 09:18:15 --> Loader Class Initialized
INFO - 2023-12-07 09:18:15 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:15 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:15 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:15 --> Controller Class Initialized
INFO - 2023-12-07 09:18:29 --> Config Class Initialized
INFO - 2023-12-07 09:18:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:29 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:29 --> URI Class Initialized
INFO - 2023-12-07 09:18:29 --> Router Class Initialized
INFO - 2023-12-07 09:18:29 --> Output Class Initialized
INFO - 2023-12-07 09:18:29 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:29 --> Input Class Initialized
INFO - 2023-12-07 09:18:29 --> Language Class Initialized
INFO - 2023-12-07 09:18:29 --> Language Class Initialized
INFO - 2023-12-07 09:18:29 --> Config Class Initialized
INFO - 2023-12-07 09:18:29 --> Loader Class Initialized
INFO - 2023-12-07 09:18:29 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:29 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:29 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:29 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:29 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:29 --> Controller Class Initialized
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:18:29 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:18:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:18:29 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:29 --> Total execution time: 0.0565
INFO - 2023-12-07 09:18:32 --> Config Class Initialized
INFO - 2023-12-07 09:18:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:32 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:32 --> URI Class Initialized
INFO - 2023-12-07 09:18:32 --> Router Class Initialized
INFO - 2023-12-07 09:18:32 --> Output Class Initialized
INFO - 2023-12-07 09:18:32 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:32 --> Input Class Initialized
INFO - 2023-12-07 09:18:32 --> Language Class Initialized
INFO - 2023-12-07 09:18:32 --> Language Class Initialized
INFO - 2023-12-07 09:18:32 --> Config Class Initialized
INFO - 2023-12-07 09:18:32 --> Loader Class Initialized
INFO - 2023-12-07 09:18:32 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:32 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:32 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:32 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:32 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:32 --> Controller Class Initialized
DEBUG - 2023-12-07 09:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:18:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:18:32 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:32 --> Total execution time: 0.0405
INFO - 2023-12-07 09:18:33 --> Config Class Initialized
INFO - 2023-12-07 09:18:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:33 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:33 --> URI Class Initialized
INFO - 2023-12-07 09:18:33 --> Router Class Initialized
INFO - 2023-12-07 09:18:33 --> Output Class Initialized
INFO - 2023-12-07 09:18:33 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:33 --> Input Class Initialized
INFO - 2023-12-07 09:18:33 --> Language Class Initialized
INFO - 2023-12-07 09:18:33 --> Language Class Initialized
INFO - 2023-12-07 09:18:33 --> Config Class Initialized
INFO - 2023-12-07 09:18:33 --> Loader Class Initialized
INFO - 2023-12-07 09:18:33 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:33 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:33 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:33 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:33 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:33 --> Controller Class Initialized
INFO - 2023-12-07 09:18:35 --> Config Class Initialized
INFO - 2023-12-07 09:18:35 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:35 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:35 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:35 --> URI Class Initialized
INFO - 2023-12-07 09:18:35 --> Router Class Initialized
INFO - 2023-12-07 09:18:35 --> Output Class Initialized
INFO - 2023-12-07 09:18:35 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:35 --> Input Class Initialized
INFO - 2023-12-07 09:18:35 --> Language Class Initialized
INFO - 2023-12-07 09:18:35 --> Language Class Initialized
INFO - 2023-12-07 09:18:35 --> Config Class Initialized
INFO - 2023-12-07 09:18:35 --> Loader Class Initialized
INFO - 2023-12-07 09:18:35 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:35 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:35 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:35 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:35 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:35 --> Controller Class Initialized
INFO - 2023-12-07 09:18:35 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:35 --> Total execution time: 0.0356
INFO - 2023-12-07 09:18:46 --> Config Class Initialized
INFO - 2023-12-07 09:18:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:46 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:46 --> URI Class Initialized
INFO - 2023-12-07 09:18:46 --> Router Class Initialized
INFO - 2023-12-07 09:18:46 --> Output Class Initialized
INFO - 2023-12-07 09:18:46 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:46 --> Input Class Initialized
INFO - 2023-12-07 09:18:46 --> Language Class Initialized
INFO - 2023-12-07 09:18:46 --> Language Class Initialized
INFO - 2023-12-07 09:18:46 --> Config Class Initialized
INFO - 2023-12-07 09:18:46 --> Loader Class Initialized
INFO - 2023-12-07 09:18:46 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:46 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:46 --> Controller Class Initialized
INFO - 2023-12-07 09:18:46 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:46 --> Total execution time: 0.0408
INFO - 2023-12-07 09:18:46 --> Config Class Initialized
INFO - 2023-12-07 09:18:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:46 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:46 --> URI Class Initialized
INFO - 2023-12-07 09:18:46 --> Router Class Initialized
INFO - 2023-12-07 09:18:46 --> Output Class Initialized
INFO - 2023-12-07 09:18:46 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:46 --> Input Class Initialized
INFO - 2023-12-07 09:18:46 --> Language Class Initialized
INFO - 2023-12-07 09:18:46 --> Language Class Initialized
INFO - 2023-12-07 09:18:46 --> Config Class Initialized
INFO - 2023-12-07 09:18:46 --> Loader Class Initialized
INFO - 2023-12-07 09:18:46 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:46 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:46 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:46 --> Controller Class Initialized
INFO - 2023-12-07 09:18:48 --> Config Class Initialized
INFO - 2023-12-07 09:18:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:18:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:18:48 --> Utf8 Class Initialized
INFO - 2023-12-07 09:18:48 --> URI Class Initialized
INFO - 2023-12-07 09:18:48 --> Router Class Initialized
INFO - 2023-12-07 09:18:48 --> Output Class Initialized
INFO - 2023-12-07 09:18:48 --> Security Class Initialized
DEBUG - 2023-12-07 09:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:18:48 --> Input Class Initialized
INFO - 2023-12-07 09:18:48 --> Language Class Initialized
INFO - 2023-12-07 09:18:48 --> Language Class Initialized
INFO - 2023-12-07 09:18:48 --> Config Class Initialized
INFO - 2023-12-07 09:18:48 --> Loader Class Initialized
INFO - 2023-12-07 09:18:48 --> Helper loaded: url_helper
INFO - 2023-12-07 09:18:48 --> Helper loaded: file_helper
INFO - 2023-12-07 09:18:48 --> Helper loaded: form_helper
INFO - 2023-12-07 09:18:48 --> Helper loaded: my_helper
INFO - 2023-12-07 09:18:48 --> Database Driver Class Initialized
INFO - 2023-12-07 09:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:18:48 --> Controller Class Initialized
INFO - 2023-12-07 09:18:48 --> Final output sent to browser
DEBUG - 2023-12-07 09:18:48 --> Total execution time: 0.0324
INFO - 2023-12-07 09:19:06 --> Config Class Initialized
INFO - 2023-12-07 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:06 --> URI Class Initialized
INFO - 2023-12-07 09:19:06 --> Router Class Initialized
INFO - 2023-12-07 09:19:06 --> Output Class Initialized
INFO - 2023-12-07 09:19:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:06 --> Input Class Initialized
INFO - 2023-12-07 09:19:06 --> Language Class Initialized
INFO - 2023-12-07 09:19:06 --> Language Class Initialized
INFO - 2023-12-07 09:19:06 --> Config Class Initialized
INFO - 2023-12-07 09:19:06 --> Loader Class Initialized
INFO - 2023-12-07 09:19:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:06 --> Controller Class Initialized
INFO - 2023-12-07 09:19:06 --> Final output sent to browser
DEBUG - 2023-12-07 09:19:06 --> Total execution time: 0.0383
INFO - 2023-12-07 09:19:06 --> Config Class Initialized
INFO - 2023-12-07 09:19:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:06 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:06 --> URI Class Initialized
INFO - 2023-12-07 09:19:06 --> Router Class Initialized
INFO - 2023-12-07 09:19:06 --> Output Class Initialized
INFO - 2023-12-07 09:19:06 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:06 --> Input Class Initialized
INFO - 2023-12-07 09:19:06 --> Language Class Initialized
INFO - 2023-12-07 09:19:06 --> Language Class Initialized
INFO - 2023-12-07 09:19:06 --> Config Class Initialized
INFO - 2023-12-07 09:19:06 --> Loader Class Initialized
INFO - 2023-12-07 09:19:06 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:06 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:06 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:06 --> Controller Class Initialized
INFO - 2023-12-07 09:19:08 --> Config Class Initialized
INFO - 2023-12-07 09:19:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:08 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:08 --> URI Class Initialized
INFO - 2023-12-07 09:19:08 --> Router Class Initialized
INFO - 2023-12-07 09:19:08 --> Output Class Initialized
INFO - 2023-12-07 09:19:08 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:08 --> Input Class Initialized
INFO - 2023-12-07 09:19:08 --> Language Class Initialized
INFO - 2023-12-07 09:19:08 --> Language Class Initialized
INFO - 2023-12-07 09:19:08 --> Config Class Initialized
INFO - 2023-12-07 09:19:08 --> Loader Class Initialized
INFO - 2023-12-07 09:19:08 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:08 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:08 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:08 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:08 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:08 --> Controller Class Initialized
INFO - 2023-12-07 09:19:08 --> Final output sent to browser
DEBUG - 2023-12-07 09:19:08 --> Total execution time: 0.0930
INFO - 2023-12-07 09:19:22 --> Config Class Initialized
INFO - 2023-12-07 09:19:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:22 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:22 --> URI Class Initialized
INFO - 2023-12-07 09:19:22 --> Router Class Initialized
INFO - 2023-12-07 09:19:22 --> Output Class Initialized
INFO - 2023-12-07 09:19:22 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:22 --> Input Class Initialized
INFO - 2023-12-07 09:19:22 --> Language Class Initialized
INFO - 2023-12-07 09:19:22 --> Language Class Initialized
INFO - 2023-12-07 09:19:22 --> Config Class Initialized
INFO - 2023-12-07 09:19:22 --> Loader Class Initialized
INFO - 2023-12-07 09:19:22 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:22 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:22 --> Controller Class Initialized
INFO - 2023-12-07 09:19:22 --> Final output sent to browser
DEBUG - 2023-12-07 09:19:22 --> Total execution time: 0.1031
INFO - 2023-12-07 09:19:22 --> Config Class Initialized
INFO - 2023-12-07 09:19:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:22 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:22 --> URI Class Initialized
INFO - 2023-12-07 09:19:22 --> Router Class Initialized
INFO - 2023-12-07 09:19:22 --> Output Class Initialized
INFO - 2023-12-07 09:19:22 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:22 --> Input Class Initialized
INFO - 2023-12-07 09:19:22 --> Language Class Initialized
INFO - 2023-12-07 09:19:22 --> Language Class Initialized
INFO - 2023-12-07 09:19:22 --> Config Class Initialized
INFO - 2023-12-07 09:19:22 --> Loader Class Initialized
INFO - 2023-12-07 09:19:22 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:22 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:22 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:22 --> Controller Class Initialized
INFO - 2023-12-07 09:19:32 --> Config Class Initialized
INFO - 2023-12-07 09:19:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:32 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:32 --> URI Class Initialized
INFO - 2023-12-07 09:19:32 --> Router Class Initialized
INFO - 2023-12-07 09:19:32 --> Output Class Initialized
INFO - 2023-12-07 09:19:32 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:32 --> Input Class Initialized
INFO - 2023-12-07 09:19:32 --> Language Class Initialized
INFO - 2023-12-07 09:19:32 --> Language Class Initialized
INFO - 2023-12-07 09:19:32 --> Config Class Initialized
INFO - 2023-12-07 09:19:32 --> Loader Class Initialized
INFO - 2023-12-07 09:19:32 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:32 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:32 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:32 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:32 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:32 --> Controller Class Initialized
DEBUG - 2023-12-07 09:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 09:19:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:19:32 --> Final output sent to browser
DEBUG - 2023-12-07 09:19:32 --> Total execution time: 0.0501
INFO - 2023-12-07 09:19:34 --> Config Class Initialized
INFO - 2023-12-07 09:19:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:19:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:19:34 --> Utf8 Class Initialized
INFO - 2023-12-07 09:19:34 --> URI Class Initialized
INFO - 2023-12-07 09:19:34 --> Router Class Initialized
INFO - 2023-12-07 09:19:34 --> Output Class Initialized
INFO - 2023-12-07 09:19:34 --> Security Class Initialized
DEBUG - 2023-12-07 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:19:34 --> Input Class Initialized
INFO - 2023-12-07 09:19:34 --> Language Class Initialized
INFO - 2023-12-07 09:19:34 --> Language Class Initialized
INFO - 2023-12-07 09:19:34 --> Config Class Initialized
INFO - 2023-12-07 09:19:34 --> Loader Class Initialized
INFO - 2023-12-07 09:19:34 --> Helper loaded: url_helper
INFO - 2023-12-07 09:19:34 --> Helper loaded: file_helper
INFO - 2023-12-07 09:19:34 --> Helper loaded: form_helper
INFO - 2023-12-07 09:19:34 --> Helper loaded: my_helper
INFO - 2023-12-07 09:19:34 --> Database Driver Class Initialized
INFO - 2023-12-07 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:19:34 --> Controller Class Initialized
ERROR - 2023-12-07 09:19:34 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
DEBUG - 2023-12-07 09:19:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-07 09:19:38 --> Final output sent to browser
DEBUG - 2023-12-07 09:19:38 --> Total execution time: 3.7189
INFO - 2023-12-07 09:20:11 --> Config Class Initialized
INFO - 2023-12-07 09:20:11 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:11 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:11 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:11 --> URI Class Initialized
INFO - 2023-12-07 09:20:11 --> Router Class Initialized
INFO - 2023-12-07 09:20:11 --> Output Class Initialized
INFO - 2023-12-07 09:20:11 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:11 --> Input Class Initialized
INFO - 2023-12-07 09:20:11 --> Language Class Initialized
INFO - 2023-12-07 09:20:11 --> Language Class Initialized
INFO - 2023-12-07 09:20:11 --> Config Class Initialized
INFO - 2023-12-07 09:20:11 --> Loader Class Initialized
INFO - 2023-12-07 09:20:11 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:11 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:11 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:11 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:11 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:11 --> Controller Class Initialized
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:20:11 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:20:11 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:20:11 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:11 --> Total execution time: 0.0401
INFO - 2023-12-07 09:20:16 --> Config Class Initialized
INFO - 2023-12-07 09:20:16 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:16 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:16 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:16 --> URI Class Initialized
INFO - 2023-12-07 09:20:16 --> Router Class Initialized
INFO - 2023-12-07 09:20:16 --> Output Class Initialized
INFO - 2023-12-07 09:20:16 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:16 --> Input Class Initialized
INFO - 2023-12-07 09:20:16 --> Language Class Initialized
INFO - 2023-12-07 09:20:16 --> Language Class Initialized
INFO - 2023-12-07 09:20:16 --> Config Class Initialized
INFO - 2023-12-07 09:20:16 --> Loader Class Initialized
INFO - 2023-12-07 09:20:16 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:16 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:16 --> Controller Class Initialized
DEBUG - 2023-12-07 09:20:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_kelompok/views/list.php
DEBUG - 2023-12-07 09:20:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:20:16 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:16 --> Total execution time: 0.0577
INFO - 2023-12-07 09:20:16 --> Config Class Initialized
INFO - 2023-12-07 09:20:16 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:16 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:16 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:16 --> URI Class Initialized
INFO - 2023-12-07 09:20:16 --> Router Class Initialized
INFO - 2023-12-07 09:20:16 --> Output Class Initialized
INFO - 2023-12-07 09:20:16 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:16 --> Input Class Initialized
INFO - 2023-12-07 09:20:16 --> Language Class Initialized
INFO - 2023-12-07 09:20:16 --> Language Class Initialized
INFO - 2023-12-07 09:20:16 --> Config Class Initialized
INFO - 2023-12-07 09:20:16 --> Loader Class Initialized
INFO - 2023-12-07 09:20:16 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:16 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:16 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:16 --> Controller Class Initialized
INFO - 2023-12-07 09:20:21 --> Config Class Initialized
INFO - 2023-12-07 09:20:21 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:21 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:21 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:21 --> URI Class Initialized
INFO - 2023-12-07 09:20:21 --> Router Class Initialized
INFO - 2023-12-07 09:20:21 --> Output Class Initialized
INFO - 2023-12-07 09:20:21 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:21 --> Input Class Initialized
INFO - 2023-12-07 09:20:21 --> Language Class Initialized
INFO - 2023-12-07 09:20:21 --> Language Class Initialized
INFO - 2023-12-07 09:20:21 --> Config Class Initialized
INFO - 2023-12-07 09:20:21 --> Loader Class Initialized
INFO - 2023-12-07 09:20:21 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:21 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:21 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:21 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:21 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:21 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:21 --> Controller Class Initialized
INFO - 2023-12-07 09:20:21 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:21 --> Total execution time: 0.0549
INFO - 2023-12-07 09:20:30 --> Config Class Initialized
INFO - 2023-12-07 09:20:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:30 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:30 --> URI Class Initialized
INFO - 2023-12-07 09:20:30 --> Router Class Initialized
INFO - 2023-12-07 09:20:30 --> Output Class Initialized
INFO - 2023-12-07 09:20:30 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:30 --> Input Class Initialized
INFO - 2023-12-07 09:20:30 --> Language Class Initialized
INFO - 2023-12-07 09:20:30 --> Language Class Initialized
INFO - 2023-12-07 09:20:30 --> Config Class Initialized
INFO - 2023-12-07 09:20:30 --> Loader Class Initialized
INFO - 2023-12-07 09:20:30 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:30 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:30 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:30 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:30 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:30 --> Controller Class Initialized
INFO - 2023-12-07 09:20:30 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:30 --> Total execution time: 0.2943
INFO - 2023-12-07 09:20:36 --> Config Class Initialized
INFO - 2023-12-07 09:20:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:36 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:36 --> URI Class Initialized
INFO - 2023-12-07 09:20:36 --> Router Class Initialized
INFO - 2023-12-07 09:20:36 --> Output Class Initialized
INFO - 2023-12-07 09:20:36 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:36 --> Input Class Initialized
INFO - 2023-12-07 09:20:36 --> Language Class Initialized
INFO - 2023-12-07 09:20:36 --> Language Class Initialized
INFO - 2023-12-07 09:20:36 --> Config Class Initialized
INFO - 2023-12-07 09:20:36 --> Loader Class Initialized
INFO - 2023-12-07 09:20:36 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:36 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:36 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:36 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:36 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:36 --> Controller Class Initialized
INFO - 2023-12-07 09:20:36 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:36 --> Total execution time: 0.0421
INFO - 2023-12-07 09:20:37 --> Config Class Initialized
INFO - 2023-12-07 09:20:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:37 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:37 --> URI Class Initialized
INFO - 2023-12-07 09:20:37 --> Router Class Initialized
INFO - 2023-12-07 09:20:37 --> Output Class Initialized
INFO - 2023-12-07 09:20:37 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:37 --> Input Class Initialized
INFO - 2023-12-07 09:20:37 --> Language Class Initialized
INFO - 2023-12-07 09:20:37 --> Language Class Initialized
INFO - 2023-12-07 09:20:37 --> Config Class Initialized
INFO - 2023-12-07 09:20:37 --> Loader Class Initialized
INFO - 2023-12-07 09:20:37 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:37 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:37 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:37 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:37 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:37 --> Controller Class Initialized
INFO - 2023-12-07 09:20:37 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:37 --> Total execution time: 0.0315
INFO - 2023-12-07 09:20:44 --> Config Class Initialized
INFO - 2023-12-07 09:20:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:44 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:44 --> URI Class Initialized
INFO - 2023-12-07 09:20:44 --> Router Class Initialized
INFO - 2023-12-07 09:20:44 --> Output Class Initialized
INFO - 2023-12-07 09:20:44 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:44 --> Input Class Initialized
INFO - 2023-12-07 09:20:44 --> Language Class Initialized
INFO - 2023-12-07 09:20:44 --> Language Class Initialized
INFO - 2023-12-07 09:20:44 --> Config Class Initialized
INFO - 2023-12-07 09:20:44 --> Loader Class Initialized
INFO - 2023-12-07 09:20:44 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:44 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:44 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:44 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:44 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:44 --> Controller Class Initialized
INFO - 2023-12-07 09:20:44 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:44 --> Total execution time: 0.3513
INFO - 2023-12-07 09:20:49 --> Config Class Initialized
INFO - 2023-12-07 09:20:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:49 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:49 --> URI Class Initialized
INFO - 2023-12-07 09:20:49 --> Router Class Initialized
INFO - 2023-12-07 09:20:49 --> Output Class Initialized
INFO - 2023-12-07 09:20:49 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:49 --> Input Class Initialized
INFO - 2023-12-07 09:20:49 --> Language Class Initialized
INFO - 2023-12-07 09:20:49 --> Language Class Initialized
INFO - 2023-12-07 09:20:49 --> Config Class Initialized
INFO - 2023-12-07 09:20:49 --> Loader Class Initialized
INFO - 2023-12-07 09:20:49 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:49 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:49 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:49 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:49 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:49 --> Controller Class Initialized
DEBUG - 2023-12-07 09:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-12-07 09:20:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:20:49 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:49 --> Total execution time: 0.0441
INFO - 2023-12-07 09:20:55 --> Config Class Initialized
INFO - 2023-12-07 09:20:55 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:55 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:55 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:55 --> URI Class Initialized
INFO - 2023-12-07 09:20:55 --> Router Class Initialized
INFO - 2023-12-07 09:20:55 --> Output Class Initialized
INFO - 2023-12-07 09:20:55 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:55 --> Input Class Initialized
INFO - 2023-12-07 09:20:55 --> Language Class Initialized
INFO - 2023-12-07 09:20:55 --> Language Class Initialized
INFO - 2023-12-07 09:20:55 --> Config Class Initialized
INFO - 2023-12-07 09:20:55 --> Loader Class Initialized
INFO - 2023-12-07 09:20:55 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:55 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:55 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:55 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:55 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:56 --> Controller Class Initialized
DEBUG - 2023-12-07 09:20:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 09:20:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:20:56 --> Final output sent to browser
DEBUG - 2023-12-07 09:20:56 --> Total execution time: 0.0946
INFO - 2023-12-07 09:20:57 --> Config Class Initialized
INFO - 2023-12-07 09:20:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:20:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:20:57 --> Utf8 Class Initialized
INFO - 2023-12-07 09:20:57 --> URI Class Initialized
INFO - 2023-12-07 09:20:57 --> Router Class Initialized
INFO - 2023-12-07 09:20:57 --> Output Class Initialized
INFO - 2023-12-07 09:20:57 --> Security Class Initialized
DEBUG - 2023-12-07 09:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:20:57 --> Input Class Initialized
INFO - 2023-12-07 09:20:57 --> Language Class Initialized
INFO - 2023-12-07 09:20:57 --> Language Class Initialized
INFO - 2023-12-07 09:20:57 --> Config Class Initialized
INFO - 2023-12-07 09:20:57 --> Loader Class Initialized
INFO - 2023-12-07 09:20:57 --> Helper loaded: url_helper
INFO - 2023-12-07 09:20:57 --> Helper loaded: file_helper
INFO - 2023-12-07 09:20:57 --> Helper loaded: form_helper
INFO - 2023-12-07 09:20:57 --> Helper loaded: my_helper
INFO - 2023-12-07 09:20:57 --> Database Driver Class Initialized
INFO - 2023-12-07 09:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:20:57 --> Controller Class Initialized
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Undefined offset: 3 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
ERROR - 2023-12-07 09:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Undefined offset: 4 /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
ERROR - 2023-12-07 09:20:57 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
ERROR - 2023-12-07 09:20:57 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 144
DEBUG - 2023-12-07 09:20:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2023-12-07 09:21:02 --> Final output sent to browser
DEBUG - 2023-12-07 09:21:02 --> Total execution time: 4.9402
INFO - 2023-12-07 09:31:20 --> Config Class Initialized
INFO - 2023-12-07 09:31:20 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:20 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:20 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:20 --> URI Class Initialized
INFO - 2023-12-07 09:31:20 --> Router Class Initialized
INFO - 2023-12-07 09:31:20 --> Output Class Initialized
INFO - 2023-12-07 09:31:20 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:20 --> Input Class Initialized
INFO - 2023-12-07 09:31:20 --> Language Class Initialized
INFO - 2023-12-07 09:31:20 --> Language Class Initialized
INFO - 2023-12-07 09:31:20 --> Config Class Initialized
INFO - 2023-12-07 09:31:20 --> Loader Class Initialized
INFO - 2023-12-07 09:31:20 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:20 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:20 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:20 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:20 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:20 --> Controller Class Initialized
DEBUG - 2023-12-07 09:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_ekstra/views/list.php
DEBUG - 2023-12-07 09:31:20 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:31:20 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:20 --> Total execution time: 0.0586
INFO - 2023-12-07 09:31:22 --> Config Class Initialized
INFO - 2023-12-07 09:31:22 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:22 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:22 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:22 --> URI Class Initialized
INFO - 2023-12-07 09:31:22 --> Router Class Initialized
INFO - 2023-12-07 09:31:22 --> Output Class Initialized
INFO - 2023-12-07 09:31:22 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:22 --> Input Class Initialized
INFO - 2023-12-07 09:31:22 --> Language Class Initialized
INFO - 2023-12-07 09:31:22 --> Language Class Initialized
INFO - 2023-12-07 09:31:22 --> Config Class Initialized
INFO - 2023-12-07 09:31:22 --> Loader Class Initialized
INFO - 2023-12-07 09:31:22 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:22 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:22 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:22 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:22 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:22 --> Controller Class Initialized
INFO - 2023-12-07 09:31:22 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:22 --> Total execution time: 0.0370
INFO - 2023-12-07 09:31:23 --> Config Class Initialized
INFO - 2023-12-07 09:31:23 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:23 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:23 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:23 --> URI Class Initialized
INFO - 2023-12-07 09:31:23 --> Router Class Initialized
INFO - 2023-12-07 09:31:23 --> Output Class Initialized
INFO - 2023-12-07 09:31:23 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:23 --> Input Class Initialized
INFO - 2023-12-07 09:31:23 --> Language Class Initialized
INFO - 2023-12-07 09:31:23 --> Language Class Initialized
INFO - 2023-12-07 09:31:23 --> Config Class Initialized
INFO - 2023-12-07 09:31:23 --> Loader Class Initialized
INFO - 2023-12-07 09:31:23 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:23 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:23 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:23 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:23 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:23 --> Controller Class Initialized
INFO - 2023-12-07 09:31:23 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:23 --> Total execution time: 0.0425
INFO - 2023-12-07 09:31:24 --> Config Class Initialized
INFO - 2023-12-07 09:31:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:24 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:24 --> URI Class Initialized
INFO - 2023-12-07 09:31:24 --> Router Class Initialized
INFO - 2023-12-07 09:31:24 --> Output Class Initialized
INFO - 2023-12-07 09:31:24 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:24 --> Input Class Initialized
INFO - 2023-12-07 09:31:24 --> Language Class Initialized
INFO - 2023-12-07 09:31:24 --> Language Class Initialized
INFO - 2023-12-07 09:31:24 --> Config Class Initialized
INFO - 2023-12-07 09:31:24 --> Loader Class Initialized
INFO - 2023-12-07 09:31:24 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:24 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:24 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:24 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:24 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:24 --> Controller Class Initialized
INFO - 2023-12-07 09:31:24 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:24 --> Total execution time: 0.0718
INFO - 2023-12-07 09:31:25 --> Config Class Initialized
INFO - 2023-12-07 09:31:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:25 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:25 --> URI Class Initialized
INFO - 2023-12-07 09:31:25 --> Router Class Initialized
INFO - 2023-12-07 09:31:25 --> Output Class Initialized
INFO - 2023-12-07 09:31:25 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:25 --> Input Class Initialized
INFO - 2023-12-07 09:31:25 --> Language Class Initialized
INFO - 2023-12-07 09:31:25 --> Language Class Initialized
INFO - 2023-12-07 09:31:25 --> Config Class Initialized
INFO - 2023-12-07 09:31:25 --> Loader Class Initialized
INFO - 2023-12-07 09:31:25 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:25 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:25 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:25 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:25 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:25 --> Controller Class Initialized
INFO - 2023-12-07 09:31:25 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:25 --> Total execution time: 0.0331
INFO - 2023-12-07 09:31:26 --> Config Class Initialized
INFO - 2023-12-07 09:31:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:26 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:26 --> URI Class Initialized
INFO - 2023-12-07 09:31:26 --> Router Class Initialized
INFO - 2023-12-07 09:31:26 --> Output Class Initialized
INFO - 2023-12-07 09:31:26 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:26 --> Input Class Initialized
INFO - 2023-12-07 09:31:26 --> Language Class Initialized
INFO - 2023-12-07 09:31:26 --> Language Class Initialized
INFO - 2023-12-07 09:31:26 --> Config Class Initialized
INFO - 2023-12-07 09:31:26 --> Loader Class Initialized
INFO - 2023-12-07 09:31:26 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:26 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:26 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:26 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:26 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:26 --> Controller Class Initialized
INFO - 2023-12-07 09:31:26 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:26 --> Total execution time: 0.0678
INFO - 2023-12-07 09:31:27 --> Config Class Initialized
INFO - 2023-12-07 09:31:27 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:31:27 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:31:27 --> Utf8 Class Initialized
INFO - 2023-12-07 09:31:27 --> URI Class Initialized
INFO - 2023-12-07 09:31:27 --> Router Class Initialized
INFO - 2023-12-07 09:31:27 --> Output Class Initialized
INFO - 2023-12-07 09:31:27 --> Security Class Initialized
DEBUG - 2023-12-07 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:31:27 --> Input Class Initialized
INFO - 2023-12-07 09:31:27 --> Language Class Initialized
INFO - 2023-12-07 09:31:27 --> Language Class Initialized
INFO - 2023-12-07 09:31:27 --> Config Class Initialized
INFO - 2023-12-07 09:31:27 --> Loader Class Initialized
INFO - 2023-12-07 09:31:27 --> Helper loaded: url_helper
INFO - 2023-12-07 09:31:27 --> Helper loaded: file_helper
INFO - 2023-12-07 09:31:27 --> Helper loaded: form_helper
INFO - 2023-12-07 09:31:27 --> Helper loaded: my_helper
INFO - 2023-12-07 09:31:27 --> Database Driver Class Initialized
INFO - 2023-12-07 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:31:27 --> Controller Class Initialized
INFO - 2023-12-07 09:31:27 --> Final output sent to browser
DEBUG - 2023-12-07 09:31:27 --> Total execution time: 0.0368
INFO - 2023-12-07 09:33:29 --> Config Class Initialized
INFO - 2023-12-07 09:33:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:33:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:33:29 --> Utf8 Class Initialized
INFO - 2023-12-07 09:33:29 --> URI Class Initialized
INFO - 2023-12-07 09:33:29 --> Router Class Initialized
INFO - 2023-12-07 09:33:29 --> Output Class Initialized
INFO - 2023-12-07 09:33:29 --> Security Class Initialized
DEBUG - 2023-12-07 09:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:33:29 --> Input Class Initialized
INFO - 2023-12-07 09:33:29 --> Language Class Initialized
INFO - 2023-12-07 09:33:29 --> Language Class Initialized
INFO - 2023-12-07 09:33:29 --> Config Class Initialized
INFO - 2023-12-07 09:33:29 --> Loader Class Initialized
INFO - 2023-12-07 09:33:29 --> Helper loaded: url_helper
INFO - 2023-12-07 09:33:29 --> Helper loaded: file_helper
INFO - 2023-12-07 09:33:29 --> Helper loaded: form_helper
INFO - 2023-12-07 09:33:29 --> Helper loaded: my_helper
INFO - 2023-12-07 09:33:29 --> Database Driver Class Initialized
INFO - 2023-12-07 09:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:33:29 --> Controller Class Initialized
INFO - 2023-12-07 09:33:29 --> Final output sent to browser
DEBUG - 2023-12-07 09:33:29 --> Total execution time: 0.0410
INFO - 2023-12-07 09:33:31 --> Config Class Initialized
INFO - 2023-12-07 09:33:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:33:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:33:31 --> Utf8 Class Initialized
INFO - 2023-12-07 09:33:31 --> URI Class Initialized
INFO - 2023-12-07 09:33:31 --> Router Class Initialized
INFO - 2023-12-07 09:33:31 --> Output Class Initialized
INFO - 2023-12-07 09:33:31 --> Security Class Initialized
DEBUG - 2023-12-07 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:33:31 --> Input Class Initialized
INFO - 2023-12-07 09:33:31 --> Language Class Initialized
INFO - 2023-12-07 09:33:31 --> Language Class Initialized
INFO - 2023-12-07 09:33:31 --> Config Class Initialized
INFO - 2023-12-07 09:33:31 --> Loader Class Initialized
INFO - 2023-12-07 09:33:31 --> Helper loaded: url_helper
INFO - 2023-12-07 09:33:31 --> Helper loaded: file_helper
INFO - 2023-12-07 09:33:31 --> Helper loaded: form_helper
INFO - 2023-12-07 09:33:31 --> Helper loaded: my_helper
INFO - 2023-12-07 09:33:31 --> Database Driver Class Initialized
INFO - 2023-12-07 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:33:31 --> Controller Class Initialized
INFO - 2023-12-07 09:33:31 --> Final output sent to browser
DEBUG - 2023-12-07 09:33:31 --> Total execution time: 0.0363
INFO - 2023-12-07 09:33:32 --> Config Class Initialized
INFO - 2023-12-07 09:33:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:33:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:33:32 --> Utf8 Class Initialized
INFO - 2023-12-07 09:33:32 --> URI Class Initialized
INFO - 2023-12-07 09:33:32 --> Router Class Initialized
INFO - 2023-12-07 09:33:32 --> Output Class Initialized
INFO - 2023-12-07 09:33:32 --> Security Class Initialized
DEBUG - 2023-12-07 09:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:33:32 --> Input Class Initialized
INFO - 2023-12-07 09:33:32 --> Language Class Initialized
INFO - 2023-12-07 09:33:32 --> Language Class Initialized
INFO - 2023-12-07 09:33:32 --> Config Class Initialized
INFO - 2023-12-07 09:33:32 --> Loader Class Initialized
INFO - 2023-12-07 09:33:32 --> Helper loaded: url_helper
INFO - 2023-12-07 09:33:32 --> Helper loaded: file_helper
INFO - 2023-12-07 09:33:32 --> Helper loaded: form_helper
INFO - 2023-12-07 09:33:32 --> Helper loaded: my_helper
INFO - 2023-12-07 09:33:32 --> Database Driver Class Initialized
INFO - 2023-12-07 09:33:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:33:32 --> Controller Class Initialized
INFO - 2023-12-07 09:33:32 --> Final output sent to browser
DEBUG - 2023-12-07 09:33:32 --> Total execution time: 0.0657
INFO - 2023-12-07 09:33:34 --> Config Class Initialized
INFO - 2023-12-07 09:33:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:33:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:33:34 --> Utf8 Class Initialized
INFO - 2023-12-07 09:33:34 --> URI Class Initialized
INFO - 2023-12-07 09:33:34 --> Router Class Initialized
INFO - 2023-12-07 09:33:34 --> Output Class Initialized
INFO - 2023-12-07 09:33:34 --> Security Class Initialized
DEBUG - 2023-12-07 09:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:33:34 --> Input Class Initialized
INFO - 2023-12-07 09:33:34 --> Language Class Initialized
INFO - 2023-12-07 09:33:34 --> Language Class Initialized
INFO - 2023-12-07 09:33:34 --> Config Class Initialized
INFO - 2023-12-07 09:33:34 --> Loader Class Initialized
INFO - 2023-12-07 09:33:34 --> Helper loaded: url_helper
INFO - 2023-12-07 09:33:34 --> Helper loaded: file_helper
INFO - 2023-12-07 09:33:34 --> Helper loaded: form_helper
INFO - 2023-12-07 09:33:34 --> Helper loaded: my_helper
INFO - 2023-12-07 09:33:34 --> Database Driver Class Initialized
INFO - 2023-12-07 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:33:34 --> Controller Class Initialized
INFO - 2023-12-07 09:33:34 --> Final output sent to browser
DEBUG - 2023-12-07 09:33:34 --> Total execution time: 0.0312
INFO - 2023-12-07 09:36:04 --> Config Class Initialized
INFO - 2023-12-07 09:36:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:36:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:36:04 --> Utf8 Class Initialized
INFO - 2023-12-07 09:36:04 --> URI Class Initialized
INFO - 2023-12-07 09:36:04 --> Router Class Initialized
INFO - 2023-12-07 09:36:04 --> Output Class Initialized
INFO - 2023-12-07 09:36:04 --> Security Class Initialized
DEBUG - 2023-12-07 09:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:36:04 --> Input Class Initialized
INFO - 2023-12-07 09:36:04 --> Language Class Initialized
INFO - 2023-12-07 09:36:04 --> Language Class Initialized
INFO - 2023-12-07 09:36:04 --> Config Class Initialized
INFO - 2023-12-07 09:36:04 --> Loader Class Initialized
INFO - 2023-12-07 09:36:04 --> Helper loaded: url_helper
INFO - 2023-12-07 09:36:04 --> Helper loaded: file_helper
INFO - 2023-12-07 09:36:04 --> Helper loaded: form_helper
INFO - 2023-12-07 09:36:04 --> Helper loaded: my_helper
INFO - 2023-12-07 09:36:04 --> Database Driver Class Initialized
INFO - 2023-12-07 09:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:36:04 --> Controller Class Initialized
INFO - 2023-12-07 09:36:04 --> Final output sent to browser
DEBUG - 2023-12-07 09:36:04 --> Total execution time: 0.0381
INFO - 2023-12-07 09:37:02 --> Config Class Initialized
INFO - 2023-12-07 09:37:02 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:37:02 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:37:02 --> Utf8 Class Initialized
INFO - 2023-12-07 09:37:02 --> URI Class Initialized
INFO - 2023-12-07 09:37:02 --> Router Class Initialized
INFO - 2023-12-07 09:37:02 --> Output Class Initialized
INFO - 2023-12-07 09:37:02 --> Security Class Initialized
DEBUG - 2023-12-07 09:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:37:02 --> Input Class Initialized
INFO - 2023-12-07 09:37:02 --> Language Class Initialized
INFO - 2023-12-07 09:37:02 --> Language Class Initialized
INFO - 2023-12-07 09:37:02 --> Config Class Initialized
INFO - 2023-12-07 09:37:02 --> Loader Class Initialized
INFO - 2023-12-07 09:37:02 --> Helper loaded: url_helper
INFO - 2023-12-07 09:37:02 --> Helper loaded: file_helper
INFO - 2023-12-07 09:37:02 --> Helper loaded: form_helper
INFO - 2023-12-07 09:37:02 --> Helper loaded: my_helper
INFO - 2023-12-07 09:37:02 --> Database Driver Class Initialized
INFO - 2023-12-07 09:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:37:02 --> Controller Class Initialized
INFO - 2023-12-07 09:37:02 --> Final output sent to browser
DEBUG - 2023-12-07 09:37:02 --> Total execution time: 0.0526
INFO - 2023-12-07 09:38:35 --> Config Class Initialized
INFO - 2023-12-07 09:38:35 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:38:35 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:38:35 --> Utf8 Class Initialized
INFO - 2023-12-07 09:38:35 --> URI Class Initialized
INFO - 2023-12-07 09:38:35 --> Router Class Initialized
INFO - 2023-12-07 09:38:35 --> Output Class Initialized
INFO - 2023-12-07 09:38:35 --> Security Class Initialized
DEBUG - 2023-12-07 09:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:38:35 --> Input Class Initialized
INFO - 2023-12-07 09:38:35 --> Language Class Initialized
INFO - 2023-12-07 09:38:35 --> Language Class Initialized
INFO - 2023-12-07 09:38:35 --> Config Class Initialized
INFO - 2023-12-07 09:38:35 --> Loader Class Initialized
INFO - 2023-12-07 09:38:35 --> Helper loaded: url_helper
INFO - 2023-12-07 09:38:35 --> Helper loaded: file_helper
INFO - 2023-12-07 09:38:35 --> Helper loaded: form_helper
INFO - 2023-12-07 09:38:35 --> Helper loaded: my_helper
INFO - 2023-12-07 09:38:35 --> Database Driver Class Initialized
INFO - 2023-12-07 09:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:38:35 --> Controller Class Initialized
INFO - 2023-12-07 09:38:35 --> Final output sent to browser
DEBUG - 2023-12-07 09:38:35 --> Total execution time: 0.0334
INFO - 2023-12-07 09:39:25 --> Config Class Initialized
INFO - 2023-12-07 09:39:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:39:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:39:25 --> Utf8 Class Initialized
INFO - 2023-12-07 09:39:25 --> URI Class Initialized
INFO - 2023-12-07 09:39:25 --> Router Class Initialized
INFO - 2023-12-07 09:39:25 --> Output Class Initialized
INFO - 2023-12-07 09:39:25 --> Security Class Initialized
DEBUG - 2023-12-07 09:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:39:25 --> Input Class Initialized
INFO - 2023-12-07 09:39:25 --> Language Class Initialized
INFO - 2023-12-07 09:39:25 --> Language Class Initialized
INFO - 2023-12-07 09:39:25 --> Config Class Initialized
INFO - 2023-12-07 09:39:25 --> Loader Class Initialized
INFO - 2023-12-07 09:39:25 --> Helper loaded: url_helper
INFO - 2023-12-07 09:39:25 --> Helper loaded: file_helper
INFO - 2023-12-07 09:39:25 --> Helper loaded: form_helper
INFO - 2023-12-07 09:39:25 --> Helper loaded: my_helper
INFO - 2023-12-07 09:39:26 --> Database Driver Class Initialized
INFO - 2023-12-07 09:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:39:26 --> Controller Class Initialized
INFO - 2023-12-07 09:39:26 --> Final output sent to browser
DEBUG - 2023-12-07 09:39:26 --> Total execution time: 0.0323
INFO - 2023-12-07 09:39:30 --> Config Class Initialized
INFO - 2023-12-07 09:39:30 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:39:30 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:39:30 --> Utf8 Class Initialized
INFO - 2023-12-07 09:39:30 --> URI Class Initialized
INFO - 2023-12-07 09:39:30 --> Router Class Initialized
INFO - 2023-12-07 09:39:30 --> Output Class Initialized
INFO - 2023-12-07 09:39:30 --> Security Class Initialized
DEBUG - 2023-12-07 09:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:39:30 --> Input Class Initialized
INFO - 2023-12-07 09:39:30 --> Language Class Initialized
INFO - 2023-12-07 09:39:30 --> Language Class Initialized
INFO - 2023-12-07 09:39:30 --> Config Class Initialized
INFO - 2023-12-07 09:39:30 --> Loader Class Initialized
INFO - 2023-12-07 09:39:30 --> Helper loaded: url_helper
INFO - 2023-12-07 09:39:30 --> Helper loaded: file_helper
INFO - 2023-12-07 09:39:30 --> Helper loaded: form_helper
INFO - 2023-12-07 09:39:30 --> Helper loaded: my_helper
INFO - 2023-12-07 09:39:30 --> Database Driver Class Initialized
INFO - 2023-12-07 09:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:39:30 --> Controller Class Initialized
INFO - 2023-12-07 09:39:30 --> Final output sent to browser
DEBUG - 2023-12-07 09:39:30 --> Total execution time: 0.0399
INFO - 2023-12-07 09:41:18 --> Config Class Initialized
INFO - 2023-12-07 09:41:18 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:41:18 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:41:18 --> Utf8 Class Initialized
INFO - 2023-12-07 09:41:18 --> URI Class Initialized
INFO - 2023-12-07 09:41:18 --> Router Class Initialized
INFO - 2023-12-07 09:41:18 --> Output Class Initialized
INFO - 2023-12-07 09:41:18 --> Security Class Initialized
DEBUG - 2023-12-07 09:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:41:18 --> Input Class Initialized
INFO - 2023-12-07 09:41:18 --> Language Class Initialized
INFO - 2023-12-07 09:41:18 --> Language Class Initialized
INFO - 2023-12-07 09:41:18 --> Config Class Initialized
INFO - 2023-12-07 09:41:18 --> Loader Class Initialized
INFO - 2023-12-07 09:41:18 --> Helper loaded: url_helper
INFO - 2023-12-07 09:41:18 --> Helper loaded: file_helper
INFO - 2023-12-07 09:41:18 --> Helper loaded: form_helper
INFO - 2023-12-07 09:41:18 --> Helper loaded: my_helper
INFO - 2023-12-07 09:41:18 --> Database Driver Class Initialized
INFO - 2023-12-07 09:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:41:18 --> Controller Class Initialized
INFO - 2023-12-07 09:41:18 --> Final output sent to browser
DEBUG - 2023-12-07 09:41:18 --> Total execution time: 0.0394
INFO - 2023-12-07 09:44:50 --> Config Class Initialized
INFO - 2023-12-07 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:44:50 --> Utf8 Class Initialized
INFO - 2023-12-07 09:44:50 --> URI Class Initialized
INFO - 2023-12-07 09:44:50 --> Router Class Initialized
INFO - 2023-12-07 09:44:50 --> Output Class Initialized
INFO - 2023-12-07 09:44:50 --> Security Class Initialized
DEBUG - 2023-12-07 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:44:50 --> Input Class Initialized
INFO - 2023-12-07 09:44:50 --> Language Class Initialized
INFO - 2023-12-07 09:44:50 --> Language Class Initialized
INFO - 2023-12-07 09:44:50 --> Config Class Initialized
INFO - 2023-12-07 09:44:50 --> Loader Class Initialized
INFO - 2023-12-07 09:44:50 --> Helper loaded: url_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: file_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: form_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: my_helper
INFO - 2023-12-07 09:44:50 --> Database Driver Class Initialized
INFO - 2023-12-07 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:44:50 --> Controller Class Initialized
DEBUG - 2023-12-07 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_prestasi/views/list.php
DEBUG - 2023-12-07 09:44:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:44:50 --> Final output sent to browser
DEBUG - 2023-12-07 09:44:50 --> Total execution time: 0.0468
INFO - 2023-12-07 09:44:50 --> Config Class Initialized
INFO - 2023-12-07 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:44:50 --> Utf8 Class Initialized
INFO - 2023-12-07 09:44:50 --> URI Class Initialized
INFO - 2023-12-07 09:44:50 --> Router Class Initialized
INFO - 2023-12-07 09:44:50 --> Output Class Initialized
INFO - 2023-12-07 09:44:50 --> Security Class Initialized
DEBUG - 2023-12-07 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:44:50 --> Input Class Initialized
INFO - 2023-12-07 09:44:50 --> Language Class Initialized
ERROR - 2023-12-07 09:44:50 --> 404 Page Not Found: /index
INFO - 2023-12-07 09:44:50 --> Config Class Initialized
INFO - 2023-12-07 09:44:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:44:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:44:50 --> Utf8 Class Initialized
INFO - 2023-12-07 09:44:50 --> URI Class Initialized
INFO - 2023-12-07 09:44:50 --> Router Class Initialized
INFO - 2023-12-07 09:44:50 --> Output Class Initialized
INFO - 2023-12-07 09:44:50 --> Security Class Initialized
DEBUG - 2023-12-07 09:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:44:50 --> Input Class Initialized
INFO - 2023-12-07 09:44:50 --> Language Class Initialized
INFO - 2023-12-07 09:44:50 --> Language Class Initialized
INFO - 2023-12-07 09:44:50 --> Config Class Initialized
INFO - 2023-12-07 09:44:50 --> Loader Class Initialized
INFO - 2023-12-07 09:44:50 --> Helper loaded: url_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: file_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: form_helper
INFO - 2023-12-07 09:44:50 --> Helper loaded: my_helper
INFO - 2023-12-07 09:44:50 --> Database Driver Class Initialized
INFO - 2023-12-07 09:44:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:44:50 --> Controller Class Initialized
INFO - 2023-12-07 09:45:35 --> Config Class Initialized
INFO - 2023-12-07 09:45:35 --> Hooks Class Initialized
DEBUG - 2023-12-07 09:45:35 --> UTF-8 Support Enabled
INFO - 2023-12-07 09:45:35 --> Utf8 Class Initialized
INFO - 2023-12-07 09:45:35 --> URI Class Initialized
INFO - 2023-12-07 09:45:35 --> Router Class Initialized
INFO - 2023-12-07 09:45:35 --> Output Class Initialized
INFO - 2023-12-07 09:45:35 --> Security Class Initialized
DEBUG - 2023-12-07 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 09:45:35 --> Input Class Initialized
INFO - 2023-12-07 09:45:35 --> Language Class Initialized
INFO - 2023-12-07 09:45:35 --> Language Class Initialized
INFO - 2023-12-07 09:45:35 --> Config Class Initialized
INFO - 2023-12-07 09:45:35 --> Loader Class Initialized
INFO - 2023-12-07 09:45:35 --> Helper loaded: url_helper
INFO - 2023-12-07 09:45:35 --> Helper loaded: file_helper
INFO - 2023-12-07 09:45:35 --> Helper loaded: form_helper
INFO - 2023-12-07 09:45:35 --> Helper loaded: my_helper
INFO - 2023-12-07 09:45:35 --> Database Driver Class Initialized
INFO - 2023-12-07 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 09:45:35 --> Controller Class Initialized
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
ERROR - 2023-12-07 09:45:35 --> Severity: Notice --> Undefined index: is_sikap /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php 56
DEBUG - 2023-12-07 09:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_kelompok/views/v_view_kelompok.php
DEBUG - 2023-12-07 09:45:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 09:45:35 --> Final output sent to browser
DEBUG - 2023-12-07 09:45:35 --> Total execution time: 0.0862
INFO - 2023-12-07 11:21:27 --> Config Class Initialized
INFO - 2023-12-07 11:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:27 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:27 --> URI Class Initialized
INFO - 2023-12-07 11:21:27 --> Router Class Initialized
INFO - 2023-12-07 11:21:27 --> Output Class Initialized
INFO - 2023-12-07 11:21:27 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:27 --> Input Class Initialized
INFO - 2023-12-07 11:21:27 --> Language Class Initialized
INFO - 2023-12-07 11:21:27 --> Language Class Initialized
INFO - 2023-12-07 11:21:27 --> Config Class Initialized
INFO - 2023-12-07 11:21:27 --> Loader Class Initialized
INFO - 2023-12-07 11:21:27 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:27 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:27 --> Controller Class Initialized
INFO - 2023-12-07 11:21:27 --> Config Class Initialized
INFO - 2023-12-07 11:21:27 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:27 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:27 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:27 --> URI Class Initialized
INFO - 2023-12-07 11:21:27 --> Router Class Initialized
INFO - 2023-12-07 11:21:27 --> Output Class Initialized
INFO - 2023-12-07 11:21:27 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:27 --> Input Class Initialized
INFO - 2023-12-07 11:21:27 --> Language Class Initialized
INFO - 2023-12-07 11:21:27 --> Language Class Initialized
INFO - 2023-12-07 11:21:27 --> Config Class Initialized
INFO - 2023-12-07 11:21:27 --> Loader Class Initialized
INFO - 2023-12-07 11:21:27 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:27 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:27 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:27 --> Controller Class Initialized
DEBUG - 2023-12-07 11:21:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 11:21:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 11:21:27 --> Final output sent to browser
DEBUG - 2023-12-07 11:21:27 --> Total execution time: 0.0427
INFO - 2023-12-07 11:21:33 --> Config Class Initialized
INFO - 2023-12-07 11:21:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:33 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:33 --> URI Class Initialized
INFO - 2023-12-07 11:21:33 --> Router Class Initialized
INFO - 2023-12-07 11:21:33 --> Output Class Initialized
INFO - 2023-12-07 11:21:33 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:33 --> Input Class Initialized
INFO - 2023-12-07 11:21:33 --> Language Class Initialized
INFO - 2023-12-07 11:21:33 --> Language Class Initialized
INFO - 2023-12-07 11:21:33 --> Config Class Initialized
INFO - 2023-12-07 11:21:33 --> Loader Class Initialized
INFO - 2023-12-07 11:21:33 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:33 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:33 --> Controller Class Initialized
INFO - 2023-12-07 11:21:33 --> Helper loaded: cookie_helper
INFO - 2023-12-07 11:21:33 --> Final output sent to browser
DEBUG - 2023-12-07 11:21:33 --> Total execution time: 0.0403
INFO - 2023-12-07 11:21:33 --> Config Class Initialized
INFO - 2023-12-07 11:21:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:33 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:33 --> URI Class Initialized
INFO - 2023-12-07 11:21:33 --> Router Class Initialized
INFO - 2023-12-07 11:21:33 --> Output Class Initialized
INFO - 2023-12-07 11:21:33 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:33 --> Input Class Initialized
INFO - 2023-12-07 11:21:33 --> Language Class Initialized
INFO - 2023-12-07 11:21:33 --> Language Class Initialized
INFO - 2023-12-07 11:21:33 --> Config Class Initialized
INFO - 2023-12-07 11:21:33 --> Loader Class Initialized
INFO - 2023-12-07 11:21:33 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:33 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:33 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:33 --> Controller Class Initialized
DEBUG - 2023-12-07 11:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 11:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 11:21:33 --> Final output sent to browser
DEBUG - 2023-12-07 11:21:33 --> Total execution time: 0.1965
INFO - 2023-12-07 11:21:36 --> Config Class Initialized
INFO - 2023-12-07 11:21:36 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:36 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:36 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:36 --> URI Class Initialized
INFO - 2023-12-07 11:21:36 --> Router Class Initialized
INFO - 2023-12-07 11:21:36 --> Output Class Initialized
INFO - 2023-12-07 11:21:36 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:36 --> Input Class Initialized
INFO - 2023-12-07 11:21:36 --> Language Class Initialized
INFO - 2023-12-07 11:21:36 --> Language Class Initialized
INFO - 2023-12-07 11:21:36 --> Config Class Initialized
INFO - 2023-12-07 11:21:36 --> Loader Class Initialized
INFO - 2023-12-07 11:21:36 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:36 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:36 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:36 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:36 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:36 --> Controller Class Initialized
DEBUG - 2023-12-07 11:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-07 11:21:36 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 11:21:36 --> Final output sent to browser
DEBUG - 2023-12-07 11:21:36 --> Total execution time: 0.0410
INFO - 2023-12-07 11:21:39 --> Config Class Initialized
INFO - 2023-12-07 11:21:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:39 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:39 --> URI Class Initialized
INFO - 2023-12-07 11:21:39 --> Router Class Initialized
INFO - 2023-12-07 11:21:39 --> Output Class Initialized
INFO - 2023-12-07 11:21:39 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:39 --> Input Class Initialized
INFO - 2023-12-07 11:21:39 --> Language Class Initialized
INFO - 2023-12-07 11:21:39 --> Language Class Initialized
INFO - 2023-12-07 11:21:39 --> Config Class Initialized
INFO - 2023-12-07 11:21:39 --> Loader Class Initialized
INFO - 2023-12-07 11:21:39 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:39 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:39 --> Controller Class Initialized
DEBUG - 2023-12-07 11:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-07 11:21:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 11:21:39 --> Final output sent to browser
DEBUG - 2023-12-07 11:21:39 --> Total execution time: 0.0425
INFO - 2023-12-07 11:21:39 --> Config Class Initialized
INFO - 2023-12-07 11:21:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:39 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:39 --> URI Class Initialized
INFO - 2023-12-07 11:21:39 --> Router Class Initialized
INFO - 2023-12-07 11:21:39 --> Output Class Initialized
INFO - 2023-12-07 11:21:39 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:39 --> Input Class Initialized
INFO - 2023-12-07 11:21:39 --> Language Class Initialized
INFO - 2023-12-07 11:21:39 --> Language Class Initialized
INFO - 2023-12-07 11:21:39 --> Config Class Initialized
INFO - 2023-12-07 11:21:39 --> Loader Class Initialized
INFO - 2023-12-07 11:21:39 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:39 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:39 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:39 --> Controller Class Initialized
INFO - 2023-12-07 11:21:41 --> Config Class Initialized
INFO - 2023-12-07 11:21:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 11:21:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 11:21:41 --> Utf8 Class Initialized
INFO - 2023-12-07 11:21:41 --> URI Class Initialized
INFO - 2023-12-07 11:21:41 --> Router Class Initialized
INFO - 2023-12-07 11:21:41 --> Output Class Initialized
INFO - 2023-12-07 11:21:41 --> Security Class Initialized
DEBUG - 2023-12-07 11:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 11:21:41 --> Input Class Initialized
INFO - 2023-12-07 11:21:41 --> Language Class Initialized
INFO - 2023-12-07 11:21:41 --> Language Class Initialized
INFO - 2023-12-07 11:21:41 --> Config Class Initialized
INFO - 2023-12-07 11:21:41 --> Loader Class Initialized
INFO - 2023-12-07 11:21:41 --> Helper loaded: url_helper
INFO - 2023-12-07 11:21:41 --> Helper loaded: file_helper
INFO - 2023-12-07 11:21:41 --> Helper loaded: form_helper
INFO - 2023-12-07 11:21:41 --> Helper loaded: my_helper
INFO - 2023-12-07 11:21:41 --> Database Driver Class Initialized
INFO - 2023-12-07 11:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 11:21:41 --> Controller Class Initialized
INFO - 2023-12-07 15:03:40 --> Config Class Initialized
INFO - 2023-12-07 15:03:40 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:40 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:40 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:40 --> URI Class Initialized
INFO - 2023-12-07 15:03:40 --> Router Class Initialized
INFO - 2023-12-07 15:03:40 --> Output Class Initialized
INFO - 2023-12-07 15:03:40 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:40 --> Input Class Initialized
INFO - 2023-12-07 15:03:40 --> Language Class Initialized
INFO - 2023-12-07 15:03:40 --> Language Class Initialized
INFO - 2023-12-07 15:03:40 --> Config Class Initialized
INFO - 2023-12-07 15:03:40 --> Loader Class Initialized
INFO - 2023-12-07 15:03:40 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: my_helper
INFO - 2023-12-07 15:03:41 --> Database Driver Class Initialized
INFO - 2023-12-07 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:41 --> Controller Class Initialized
INFO - 2023-12-07 15:03:41 --> Config Class Initialized
INFO - 2023-12-07 15:03:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:03:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:03:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:03:41 --> URI Class Initialized
INFO - 2023-12-07 15:03:41 --> Router Class Initialized
INFO - 2023-12-07 15:03:41 --> Output Class Initialized
INFO - 2023-12-07 15:03:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:03:41 --> Input Class Initialized
INFO - 2023-12-07 15:03:41 --> Language Class Initialized
INFO - 2023-12-07 15:03:41 --> Language Class Initialized
INFO - 2023-12-07 15:03:41 --> Config Class Initialized
INFO - 2023-12-07 15:03:41 --> Loader Class Initialized
INFO - 2023-12-07 15:03:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:03:41 --> Helper loaded: my_helper
INFO - 2023-12-07 15:03:41 --> Database Driver Class Initialized
INFO - 2023-12-07 15:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:03:41 --> Controller Class Initialized
DEBUG - 2023-12-07 15:03:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:03:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:03:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:03:41 --> Total execution time: 0.0420
INFO - 2023-12-07 15:06:08 --> Config Class Initialized
INFO - 2023-12-07 15:06:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:06:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:06:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:06:08 --> URI Class Initialized
INFO - 2023-12-07 15:06:08 --> Router Class Initialized
INFO - 2023-12-07 15:06:08 --> Output Class Initialized
INFO - 2023-12-07 15:06:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:06:08 --> Input Class Initialized
INFO - 2023-12-07 15:06:08 --> Language Class Initialized
INFO - 2023-12-07 15:06:08 --> Language Class Initialized
INFO - 2023-12-07 15:06:08 --> Config Class Initialized
INFO - 2023-12-07 15:06:08 --> Loader Class Initialized
INFO - 2023-12-07 15:06:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: my_helper
INFO - 2023-12-07 15:06:08 --> Database Driver Class Initialized
INFO - 2023-12-07 15:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:06:08 --> Controller Class Initialized
INFO - 2023-12-07 15:06:08 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:06:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:06:08 --> Total execution time: 0.0373
INFO - 2023-12-07 15:06:08 --> Config Class Initialized
INFO - 2023-12-07 15:06:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:06:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:06:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:06:08 --> URI Class Initialized
INFO - 2023-12-07 15:06:08 --> Router Class Initialized
INFO - 2023-12-07 15:06:08 --> Output Class Initialized
INFO - 2023-12-07 15:06:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:06:08 --> Input Class Initialized
INFO - 2023-12-07 15:06:08 --> Language Class Initialized
INFO - 2023-12-07 15:06:08 --> Language Class Initialized
INFO - 2023-12-07 15:06:08 --> Config Class Initialized
INFO - 2023-12-07 15:06:08 --> Loader Class Initialized
INFO - 2023-12-07 15:06:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:06:08 --> Helper loaded: my_helper
INFO - 2023-12-07 15:06:08 --> Database Driver Class Initialized
INFO - 2023-12-07 15:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:06:08 --> Controller Class Initialized
DEBUG - 2023-12-07 15:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:06:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:06:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:06:08 --> Total execution time: 0.0431
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:39 --> URI Class Initialized
INFO - 2023-12-07 15:09:39 --> Router Class Initialized
INFO - 2023-12-07 15:09:39 --> Output Class Initialized
INFO - 2023-12-07 15:09:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:39 --> Input Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Loader Class Initialized
INFO - 2023-12-07 15:09:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:39 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:39 --> Controller Class Initialized
INFO - 2023-12-07 15:09:39 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:39 --> URI Class Initialized
INFO - 2023-12-07 15:09:39 --> Router Class Initialized
INFO - 2023-12-07 15:09:39 --> Output Class Initialized
INFO - 2023-12-07 15:09:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:39 --> Input Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Loader Class Initialized
INFO - 2023-12-07 15:09:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:39 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:39 --> Controller Class Initialized
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:39 --> URI Class Initialized
INFO - 2023-12-07 15:09:39 --> Router Class Initialized
INFO - 2023-12-07 15:09:39 --> Output Class Initialized
INFO - 2023-12-07 15:09:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:39 --> Input Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Language Class Initialized
INFO - 2023-12-07 15:09:39 --> Config Class Initialized
INFO - 2023-12-07 15:09:39 --> Loader Class Initialized
INFO - 2023-12-07 15:09:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:39 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:39 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:39 --> Controller Class Initialized
DEBUG - 2023-12-07 15:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:09:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:09:39 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:39 --> Total execution time: 0.0349
INFO - 2023-12-07 15:09:43 --> Config Class Initialized
INFO - 2023-12-07 15:09:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:43 --> URI Class Initialized
INFO - 2023-12-07 15:09:43 --> Router Class Initialized
INFO - 2023-12-07 15:09:43 --> Output Class Initialized
INFO - 2023-12-07 15:09:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:43 --> Input Class Initialized
INFO - 2023-12-07 15:09:43 --> Language Class Initialized
INFO - 2023-12-07 15:09:43 --> Language Class Initialized
INFO - 2023-12-07 15:09:43 --> Config Class Initialized
INFO - 2023-12-07 15:09:43 --> Loader Class Initialized
INFO - 2023-12-07 15:09:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:43 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:43 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:43 --> Controller Class Initialized
INFO - 2023-12-07 15:09:43 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:09:43 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:43 --> Total execution time: 0.0446
INFO - 2023-12-07 15:09:44 --> Config Class Initialized
INFO - 2023-12-07 15:09:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:44 --> URI Class Initialized
INFO - 2023-12-07 15:09:44 --> Router Class Initialized
INFO - 2023-12-07 15:09:44 --> Output Class Initialized
INFO - 2023-12-07 15:09:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:44 --> Input Class Initialized
INFO - 2023-12-07 15:09:44 --> Language Class Initialized
INFO - 2023-12-07 15:09:44 --> Language Class Initialized
INFO - 2023-12-07 15:09:44 --> Config Class Initialized
INFO - 2023-12-07 15:09:44 --> Loader Class Initialized
INFO - 2023-12-07 15:09:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:44 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:44 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:44 --> Controller Class Initialized
DEBUG - 2023-12-07 15:09:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:09:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:09:44 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:44 --> Total execution time: 0.0350
INFO - 2023-12-07 15:09:50 --> Config Class Initialized
INFO - 2023-12-07 15:09:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:50 --> URI Class Initialized
INFO - 2023-12-07 15:09:50 --> Router Class Initialized
INFO - 2023-12-07 15:09:50 --> Output Class Initialized
INFO - 2023-12-07 15:09:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:50 --> Input Class Initialized
INFO - 2023-12-07 15:09:50 --> Language Class Initialized
INFO - 2023-12-07 15:09:50 --> Language Class Initialized
INFO - 2023-12-07 15:09:50 --> Config Class Initialized
INFO - 2023-12-07 15:09:50 --> Loader Class Initialized
INFO - 2023-12-07 15:09:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:50 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:50 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:50 --> Controller Class Initialized
DEBUG - 2023-12-07 15:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 15:09:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:09:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:50 --> Total execution time: 0.1726
INFO - 2023-12-07 15:09:54 --> Config Class Initialized
INFO - 2023-12-07 15:09:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:09:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:09:54 --> Utf8 Class Initialized
INFO - 2023-12-07 15:09:54 --> URI Class Initialized
INFO - 2023-12-07 15:09:54 --> Router Class Initialized
INFO - 2023-12-07 15:09:54 --> Output Class Initialized
INFO - 2023-12-07 15:09:54 --> Security Class Initialized
DEBUG - 2023-12-07 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:09:54 --> Input Class Initialized
INFO - 2023-12-07 15:09:54 --> Language Class Initialized
INFO - 2023-12-07 15:09:54 --> Language Class Initialized
INFO - 2023-12-07 15:09:54 --> Config Class Initialized
INFO - 2023-12-07 15:09:54 --> Loader Class Initialized
INFO - 2023-12-07 15:09:54 --> Helper loaded: url_helper
INFO - 2023-12-07 15:09:54 --> Helper loaded: file_helper
INFO - 2023-12-07 15:09:54 --> Helper loaded: form_helper
INFO - 2023-12-07 15:09:54 --> Helper loaded: my_helper
INFO - 2023-12-07 15:09:54 --> Database Driver Class Initialized
INFO - 2023-12-07 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:09:54 --> Controller Class Initialized
DEBUG - 2023-12-07 15:09:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-07 15:09:58 --> Final output sent to browser
DEBUG - 2023-12-07 15:09:58 --> Total execution time: 3.8461
INFO - 2023-12-07 15:11:32 --> Config Class Initialized
INFO - 2023-12-07 15:11:32 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:32 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:32 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:32 --> URI Class Initialized
INFO - 2023-12-07 15:11:32 --> Router Class Initialized
INFO - 2023-12-07 15:11:32 --> Output Class Initialized
INFO - 2023-12-07 15:11:32 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:32 --> Input Class Initialized
INFO - 2023-12-07 15:11:32 --> Language Class Initialized
INFO - 2023-12-07 15:11:32 --> Language Class Initialized
INFO - 2023-12-07 15:11:32 --> Config Class Initialized
INFO - 2023-12-07 15:11:32 --> Loader Class Initialized
INFO - 2023-12-07 15:11:32 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:32 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:32 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:32 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:32 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:32 --> Controller Class Initialized
INFO - 2023-12-07 15:11:32 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:11:33 --> Config Class Initialized
INFO - 2023-12-07 15:11:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:33 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:33 --> URI Class Initialized
INFO - 2023-12-07 15:11:33 --> Router Class Initialized
INFO - 2023-12-07 15:11:33 --> Output Class Initialized
INFO - 2023-12-07 15:11:33 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:33 --> Input Class Initialized
INFO - 2023-12-07 15:11:33 --> Language Class Initialized
INFO - 2023-12-07 15:11:33 --> Language Class Initialized
INFO - 2023-12-07 15:11:33 --> Config Class Initialized
INFO - 2023-12-07 15:11:33 --> Loader Class Initialized
INFO - 2023-12-07 15:11:33 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:33 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:33 --> Controller Class Initialized
INFO - 2023-12-07 15:11:33 --> Config Class Initialized
INFO - 2023-12-07 15:11:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:33 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:33 --> URI Class Initialized
INFO - 2023-12-07 15:11:33 --> Router Class Initialized
INFO - 2023-12-07 15:11:33 --> Output Class Initialized
INFO - 2023-12-07 15:11:33 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:33 --> Input Class Initialized
INFO - 2023-12-07 15:11:33 --> Language Class Initialized
INFO - 2023-12-07 15:11:33 --> Language Class Initialized
INFO - 2023-12-07 15:11:33 --> Config Class Initialized
INFO - 2023-12-07 15:11:33 --> Loader Class Initialized
INFO - 2023-12-07 15:11:33 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:33 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:33 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:33 --> Controller Class Initialized
DEBUG - 2023-12-07 15:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:11:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:11:33 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:33 --> Total execution time: 0.0703
INFO - 2023-12-07 15:11:39 --> Config Class Initialized
INFO - 2023-12-07 15:11:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:39 --> URI Class Initialized
INFO - 2023-12-07 15:11:39 --> Router Class Initialized
INFO - 2023-12-07 15:11:39 --> Output Class Initialized
INFO - 2023-12-07 15:11:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:39 --> Input Class Initialized
INFO - 2023-12-07 15:11:39 --> Language Class Initialized
INFO - 2023-12-07 15:11:39 --> Language Class Initialized
INFO - 2023-12-07 15:11:39 --> Config Class Initialized
INFO - 2023-12-07 15:11:39 --> Loader Class Initialized
INFO - 2023-12-07 15:11:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:39 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:39 --> Controller Class Initialized
INFO - 2023-12-07 15:11:39 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:11:39 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:39 --> Total execution time: 0.0365
INFO - 2023-12-07 15:11:39 --> Config Class Initialized
INFO - 2023-12-07 15:11:39 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:39 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:39 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:39 --> URI Class Initialized
INFO - 2023-12-07 15:11:39 --> Router Class Initialized
INFO - 2023-12-07 15:11:39 --> Output Class Initialized
INFO - 2023-12-07 15:11:39 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:39 --> Input Class Initialized
INFO - 2023-12-07 15:11:39 --> Language Class Initialized
INFO - 2023-12-07 15:11:39 --> Language Class Initialized
INFO - 2023-12-07 15:11:39 --> Config Class Initialized
INFO - 2023-12-07 15:11:39 --> Loader Class Initialized
INFO - 2023-12-07 15:11:39 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:39 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:39 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:39 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:39 --> Controller Class Initialized
DEBUG - 2023-12-07 15:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:11:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:11:39 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:39 --> Total execution time: 0.0359
INFO - 2023-12-07 15:11:44 --> Config Class Initialized
INFO - 2023-12-07 15:11:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:44 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:44 --> URI Class Initialized
INFO - 2023-12-07 15:11:44 --> Router Class Initialized
INFO - 2023-12-07 15:11:44 --> Output Class Initialized
INFO - 2023-12-07 15:11:44 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:44 --> Input Class Initialized
INFO - 2023-12-07 15:11:44 --> Language Class Initialized
INFO - 2023-12-07 15:11:44 --> Language Class Initialized
INFO - 2023-12-07 15:11:44 --> Config Class Initialized
INFO - 2023-12-07 15:11:44 --> Loader Class Initialized
INFO - 2023-12-07 15:11:44 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:44 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:44 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:44 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:44 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:44 --> Controller Class Initialized
DEBUG - 2023-12-07 15:11:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-07 15:11:44 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:11:44 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:44 --> Total execution time: 0.0334
INFO - 2023-12-07 15:11:47 --> Config Class Initialized
INFO - 2023-12-07 15:11:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:47 --> URI Class Initialized
INFO - 2023-12-07 15:11:47 --> Router Class Initialized
INFO - 2023-12-07 15:11:47 --> Output Class Initialized
INFO - 2023-12-07 15:11:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:47 --> Input Class Initialized
INFO - 2023-12-07 15:11:47 --> Language Class Initialized
INFO - 2023-12-07 15:11:47 --> Language Class Initialized
INFO - 2023-12-07 15:11:47 --> Config Class Initialized
INFO - 2023-12-07 15:11:47 --> Loader Class Initialized
INFO - 2023-12-07 15:11:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:47 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:47 --> Controller Class Initialized
DEBUG - 2023-12-07 15:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_pengetahuan/views/list.php
DEBUG - 2023-12-07 15:11:47 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:11:47 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:47 --> Total execution time: 0.0397
INFO - 2023-12-07 15:11:47 --> Config Class Initialized
INFO - 2023-12-07 15:11:47 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:47 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:47 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:47 --> URI Class Initialized
INFO - 2023-12-07 15:11:47 --> Router Class Initialized
INFO - 2023-12-07 15:11:47 --> Output Class Initialized
INFO - 2023-12-07 15:11:47 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:47 --> Input Class Initialized
INFO - 2023-12-07 15:11:47 --> Language Class Initialized
INFO - 2023-12-07 15:11:47 --> Language Class Initialized
INFO - 2023-12-07 15:11:47 --> Config Class Initialized
INFO - 2023-12-07 15:11:47 --> Loader Class Initialized
INFO - 2023-12-07 15:11:47 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:47 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:47 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:47 --> Controller Class Initialized
INFO - 2023-12-07 15:11:49 --> Config Class Initialized
INFO - 2023-12-07 15:11:49 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:11:49 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:11:49 --> Utf8 Class Initialized
INFO - 2023-12-07 15:11:49 --> URI Class Initialized
INFO - 2023-12-07 15:11:49 --> Router Class Initialized
INFO - 2023-12-07 15:11:49 --> Output Class Initialized
INFO - 2023-12-07 15:11:49 --> Security Class Initialized
DEBUG - 2023-12-07 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:11:49 --> Input Class Initialized
INFO - 2023-12-07 15:11:49 --> Language Class Initialized
INFO - 2023-12-07 15:11:49 --> Language Class Initialized
INFO - 2023-12-07 15:11:49 --> Config Class Initialized
INFO - 2023-12-07 15:11:49 --> Loader Class Initialized
INFO - 2023-12-07 15:11:49 --> Helper loaded: url_helper
INFO - 2023-12-07 15:11:49 --> Helper loaded: file_helper
INFO - 2023-12-07 15:11:49 --> Helper loaded: form_helper
INFO - 2023-12-07 15:11:49 --> Helper loaded: my_helper
INFO - 2023-12-07 15:11:49 --> Database Driver Class Initialized
INFO - 2023-12-07 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:11:49 --> Controller Class Initialized
INFO - 2023-12-07 15:11:49 --> Final output sent to browser
DEBUG - 2023-12-07 15:11:49 --> Total execution time: 0.0507
INFO - 2023-12-07 15:12:03 --> Config Class Initialized
INFO - 2023-12-07 15:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:03 --> URI Class Initialized
INFO - 2023-12-07 15:12:03 --> Router Class Initialized
INFO - 2023-12-07 15:12:03 --> Output Class Initialized
INFO - 2023-12-07 15:12:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:03 --> Input Class Initialized
INFO - 2023-12-07 15:12:03 --> Language Class Initialized
INFO - 2023-12-07 15:12:03 --> Language Class Initialized
INFO - 2023-12-07 15:12:03 --> Config Class Initialized
INFO - 2023-12-07 15:12:03 --> Loader Class Initialized
INFO - 2023-12-07 15:12:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:03 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:03 --> Controller Class Initialized
INFO - 2023-12-07 15:12:03 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:03 --> Total execution time: 0.0444
INFO - 2023-12-07 15:12:03 --> Config Class Initialized
INFO - 2023-12-07 15:12:03 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:03 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:03 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:03 --> URI Class Initialized
INFO - 2023-12-07 15:12:03 --> Router Class Initialized
INFO - 2023-12-07 15:12:03 --> Output Class Initialized
INFO - 2023-12-07 15:12:03 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:03 --> Input Class Initialized
INFO - 2023-12-07 15:12:03 --> Language Class Initialized
INFO - 2023-12-07 15:12:03 --> Language Class Initialized
INFO - 2023-12-07 15:12:03 --> Config Class Initialized
INFO - 2023-12-07 15:12:03 --> Loader Class Initialized
INFO - 2023-12-07 15:12:03 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:03 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:03 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:03 --> Controller Class Initialized
INFO - 2023-12-07 15:12:06 --> Config Class Initialized
INFO - 2023-12-07 15:12:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:06 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:06 --> URI Class Initialized
INFO - 2023-12-07 15:12:06 --> Router Class Initialized
INFO - 2023-12-07 15:12:06 --> Output Class Initialized
INFO - 2023-12-07 15:12:06 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:06 --> Input Class Initialized
INFO - 2023-12-07 15:12:06 --> Language Class Initialized
INFO - 2023-12-07 15:12:06 --> Language Class Initialized
INFO - 2023-12-07 15:12:06 --> Config Class Initialized
INFO - 2023-12-07 15:12:06 --> Loader Class Initialized
INFO - 2023-12-07 15:12:06 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:06 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:06 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:06 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:06 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:06 --> Controller Class Initialized
INFO - 2023-12-07 15:12:06 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:06 --> Total execution time: 0.0884
INFO - 2023-12-07 15:12:15 --> Config Class Initialized
INFO - 2023-12-07 15:12:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:15 --> URI Class Initialized
INFO - 2023-12-07 15:12:15 --> Router Class Initialized
INFO - 2023-12-07 15:12:15 --> Output Class Initialized
INFO - 2023-12-07 15:12:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:15 --> Input Class Initialized
INFO - 2023-12-07 15:12:15 --> Language Class Initialized
INFO - 2023-12-07 15:12:15 --> Language Class Initialized
INFO - 2023-12-07 15:12:15 --> Config Class Initialized
INFO - 2023-12-07 15:12:15 --> Loader Class Initialized
INFO - 2023-12-07 15:12:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:15 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:15 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:15 --> Controller Class Initialized
INFO - 2023-12-07 15:12:15 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:15 --> Total execution time: 0.0828
INFO - 2023-12-07 15:12:29 --> Config Class Initialized
INFO - 2023-12-07 15:12:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:29 --> URI Class Initialized
INFO - 2023-12-07 15:12:29 --> Router Class Initialized
INFO - 2023-12-07 15:12:29 --> Output Class Initialized
INFO - 2023-12-07 15:12:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:29 --> Input Class Initialized
INFO - 2023-12-07 15:12:29 --> Language Class Initialized
INFO - 2023-12-07 15:12:29 --> Language Class Initialized
INFO - 2023-12-07 15:12:29 --> Config Class Initialized
INFO - 2023-12-07 15:12:29 --> Loader Class Initialized
INFO - 2023-12-07 15:12:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:29 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:29 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:29 --> Controller Class Initialized
DEBUG - 2023-12-07 15:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-07 15:12:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:12:29 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:29 --> Total execution time: 0.0599
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:34 --> URI Class Initialized
INFO - 2023-12-07 15:12:34 --> Router Class Initialized
INFO - 2023-12-07 15:12:34 --> Output Class Initialized
INFO - 2023-12-07 15:12:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:34 --> Input Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Loader Class Initialized
INFO - 2023-12-07 15:12:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:34 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:34 --> Controller Class Initialized
INFO - 2023-12-07 15:12:34 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:34 --> URI Class Initialized
INFO - 2023-12-07 15:12:34 --> Router Class Initialized
INFO - 2023-12-07 15:12:34 --> Output Class Initialized
INFO - 2023-12-07 15:12:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:34 --> Input Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Loader Class Initialized
INFO - 2023-12-07 15:12:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:34 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:34 --> Controller Class Initialized
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:12:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:12:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:12:34 --> URI Class Initialized
INFO - 2023-12-07 15:12:34 --> Router Class Initialized
INFO - 2023-12-07 15:12:34 --> Output Class Initialized
INFO - 2023-12-07 15:12:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:12:34 --> Input Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Language Class Initialized
INFO - 2023-12-07 15:12:34 --> Config Class Initialized
INFO - 2023-12-07 15:12:34 --> Loader Class Initialized
INFO - 2023-12-07 15:12:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:12:34 --> Helper loaded: my_helper
INFO - 2023-12-07 15:12:34 --> Database Driver Class Initialized
INFO - 2023-12-07 15:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:12:34 --> Controller Class Initialized
DEBUG - 2023-12-07 15:12:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:12:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:12:34 --> Final output sent to browser
DEBUG - 2023-12-07 15:12:34 --> Total execution time: 0.0350
INFO - 2023-12-07 15:14:13 --> Config Class Initialized
INFO - 2023-12-07 15:14:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:13 --> URI Class Initialized
INFO - 2023-12-07 15:14:13 --> Router Class Initialized
INFO - 2023-12-07 15:14:13 --> Output Class Initialized
INFO - 2023-12-07 15:14:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:13 --> Input Class Initialized
INFO - 2023-12-07 15:14:13 --> Language Class Initialized
INFO - 2023-12-07 15:14:13 --> Language Class Initialized
INFO - 2023-12-07 15:14:13 --> Config Class Initialized
INFO - 2023-12-07 15:14:13 --> Loader Class Initialized
INFO - 2023-12-07 15:14:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:14:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:13 --> Controller Class Initialized
INFO - 2023-12-07 15:14:13 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:14:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:13 --> Total execution time: 0.0407
INFO - 2023-12-07 15:14:13 --> Config Class Initialized
INFO - 2023-12-07 15:14:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:13 --> URI Class Initialized
INFO - 2023-12-07 15:14:13 --> Router Class Initialized
INFO - 2023-12-07 15:14:13 --> Output Class Initialized
INFO - 2023-12-07 15:14:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:13 --> Input Class Initialized
INFO - 2023-12-07 15:14:13 --> Language Class Initialized
INFO - 2023-12-07 15:14:13 --> Language Class Initialized
INFO - 2023-12-07 15:14:13 --> Config Class Initialized
INFO - 2023-12-07 15:14:13 --> Loader Class Initialized
INFO - 2023-12-07 15:14:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:14:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:13 --> Controller Class Initialized
DEBUG - 2023-12-07 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:14:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:14:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:13 --> Total execution time: 0.0747
INFO - 2023-12-07 15:14:17 --> Config Class Initialized
INFO - 2023-12-07 15:14:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:17 --> URI Class Initialized
INFO - 2023-12-07 15:14:17 --> Router Class Initialized
INFO - 2023-12-07 15:14:17 --> Output Class Initialized
INFO - 2023-12-07 15:14:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:17 --> Input Class Initialized
INFO - 2023-12-07 15:14:17 --> Language Class Initialized
INFO - 2023-12-07 15:14:17 --> Language Class Initialized
INFO - 2023-12-07 15:14:17 --> Config Class Initialized
INFO - 2023-12-07 15:14:17 --> Loader Class Initialized
INFO - 2023-12-07 15:14:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:17 --> Helper loaded: my_helper
INFO - 2023-12-07 15:14:17 --> Database Driver Class Initialized
INFO - 2023-12-07 15:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:17 --> Controller Class Initialized
DEBUG - 2023-12-07 15:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 15:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:14:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:17 --> Total execution time: 0.0429
INFO - 2023-12-07 15:14:46 --> Config Class Initialized
INFO - 2023-12-07 15:14:46 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:14:46 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:14:46 --> Utf8 Class Initialized
INFO - 2023-12-07 15:14:46 --> URI Class Initialized
INFO - 2023-12-07 15:14:46 --> Router Class Initialized
INFO - 2023-12-07 15:14:46 --> Output Class Initialized
INFO - 2023-12-07 15:14:46 --> Security Class Initialized
DEBUG - 2023-12-07 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:14:46 --> Input Class Initialized
INFO - 2023-12-07 15:14:46 --> Language Class Initialized
INFO - 2023-12-07 15:14:46 --> Language Class Initialized
INFO - 2023-12-07 15:14:46 --> Config Class Initialized
INFO - 2023-12-07 15:14:46 --> Loader Class Initialized
INFO - 2023-12-07 15:14:46 --> Helper loaded: url_helper
INFO - 2023-12-07 15:14:46 --> Helper loaded: file_helper
INFO - 2023-12-07 15:14:46 --> Helper loaded: form_helper
INFO - 2023-12-07 15:14:46 --> Helper loaded: my_helper
INFO - 2023-12-07 15:14:46 --> Database Driver Class Initialized
INFO - 2023-12-07 15:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:14:46 --> Controller Class Initialized
DEBUG - 2023-12-07 15:14:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-07 15:14:49 --> Final output sent to browser
DEBUG - 2023-12-07 15:14:49 --> Total execution time: 3.5806
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:13 --> URI Class Initialized
INFO - 2023-12-07 15:15:13 --> Router Class Initialized
INFO - 2023-12-07 15:15:13 --> Output Class Initialized
INFO - 2023-12-07 15:15:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:13 --> Input Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Loader Class Initialized
INFO - 2023-12-07 15:15:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:13 --> Controller Class Initialized
INFO - 2023-12-07 15:15:13 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:13 --> URI Class Initialized
INFO - 2023-12-07 15:15:13 --> Router Class Initialized
INFO - 2023-12-07 15:15:13 --> Output Class Initialized
INFO - 2023-12-07 15:15:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:13 --> Input Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Loader Class Initialized
INFO - 2023-12-07 15:15:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:13 --> Controller Class Initialized
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:13 --> URI Class Initialized
INFO - 2023-12-07 15:15:13 --> Router Class Initialized
INFO - 2023-12-07 15:15:13 --> Output Class Initialized
INFO - 2023-12-07 15:15:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:13 --> Input Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Language Class Initialized
INFO - 2023-12-07 15:15:13 --> Config Class Initialized
INFO - 2023-12-07 15:15:13 --> Loader Class Initialized
INFO - 2023-12-07 15:15:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:13 --> Controller Class Initialized
DEBUG - 2023-12-07 15:15:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:15:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:15:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:13 --> Total execution time: 0.0363
INFO - 2023-12-07 15:15:15 --> Config Class Initialized
INFO - 2023-12-07 15:15:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:15 --> URI Class Initialized
INFO - 2023-12-07 15:15:15 --> Router Class Initialized
INFO - 2023-12-07 15:15:15 --> Output Class Initialized
INFO - 2023-12-07 15:15:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:15 --> Input Class Initialized
INFO - 2023-12-07 15:15:15 --> Language Class Initialized
INFO - 2023-12-07 15:15:15 --> Language Class Initialized
INFO - 2023-12-07 15:15:15 --> Config Class Initialized
INFO - 2023-12-07 15:15:15 --> Loader Class Initialized
INFO - 2023-12-07 15:15:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:15 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:15 --> Controller Class Initialized
INFO - 2023-12-07 15:15:15 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:15:15 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:15 --> Total execution time: 0.0697
INFO - 2023-12-07 15:15:15 --> Config Class Initialized
INFO - 2023-12-07 15:15:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:15 --> URI Class Initialized
INFO - 2023-12-07 15:15:15 --> Router Class Initialized
INFO - 2023-12-07 15:15:15 --> Output Class Initialized
INFO - 2023-12-07 15:15:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:15 --> Input Class Initialized
INFO - 2023-12-07 15:15:15 --> Language Class Initialized
INFO - 2023-12-07 15:15:15 --> Language Class Initialized
INFO - 2023-12-07 15:15:15 --> Config Class Initialized
INFO - 2023-12-07 15:15:15 --> Loader Class Initialized
INFO - 2023-12-07 15:15:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:15 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:15 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:15 --> Controller Class Initialized
DEBUG - 2023-12-07 15:15:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:15:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:15:15 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:15 --> Total execution time: 0.0569
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:17 --> URI Class Initialized
INFO - 2023-12-07 15:15:17 --> Router Class Initialized
INFO - 2023-12-07 15:15:17 --> Output Class Initialized
INFO - 2023-12-07 15:15:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:17 --> Input Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Loader Class Initialized
INFO - 2023-12-07 15:15:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:17 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:17 --> Controller Class Initialized
INFO - 2023-12-07 15:15:17 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:17 --> URI Class Initialized
INFO - 2023-12-07 15:15:17 --> Router Class Initialized
INFO - 2023-12-07 15:15:17 --> Output Class Initialized
INFO - 2023-12-07 15:15:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:17 --> Input Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Loader Class Initialized
INFO - 2023-12-07 15:15:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:17 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:17 --> Controller Class Initialized
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:17 --> URI Class Initialized
INFO - 2023-12-07 15:15:17 --> Router Class Initialized
INFO - 2023-12-07 15:15:17 --> Output Class Initialized
INFO - 2023-12-07 15:15:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:17 --> Input Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Language Class Initialized
INFO - 2023-12-07 15:15:17 --> Config Class Initialized
INFO - 2023-12-07 15:15:17 --> Loader Class Initialized
INFO - 2023-12-07 15:15:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:17 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:17 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:17 --> Controller Class Initialized
DEBUG - 2023-12-07 15:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:15:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:15:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:17 --> Total execution time: 0.0344
INFO - 2023-12-07 15:15:41 --> Config Class Initialized
INFO - 2023-12-07 15:15:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:41 --> URI Class Initialized
INFO - 2023-12-07 15:15:41 --> Router Class Initialized
INFO - 2023-12-07 15:15:41 --> Output Class Initialized
INFO - 2023-12-07 15:15:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:41 --> Input Class Initialized
INFO - 2023-12-07 15:15:41 --> Language Class Initialized
INFO - 2023-12-07 15:15:41 --> Language Class Initialized
INFO - 2023-12-07 15:15:41 --> Config Class Initialized
INFO - 2023-12-07 15:15:41 --> Loader Class Initialized
INFO - 2023-12-07 15:15:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:41 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:41 --> Controller Class Initialized
INFO - 2023-12-07 15:15:41 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:15:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:41 --> Total execution time: 0.0403
INFO - 2023-12-07 15:15:41 --> Config Class Initialized
INFO - 2023-12-07 15:15:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:41 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:41 --> URI Class Initialized
INFO - 2023-12-07 15:15:41 --> Router Class Initialized
INFO - 2023-12-07 15:15:41 --> Output Class Initialized
INFO - 2023-12-07 15:15:41 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:41 --> Input Class Initialized
INFO - 2023-12-07 15:15:41 --> Language Class Initialized
INFO - 2023-12-07 15:15:41 --> Language Class Initialized
INFO - 2023-12-07 15:15:41 --> Config Class Initialized
INFO - 2023-12-07 15:15:41 --> Loader Class Initialized
INFO - 2023-12-07 15:15:41 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:41 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:41 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:41 --> Controller Class Initialized
DEBUG - 2023-12-07 15:15:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-07 15:15:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:15:41 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:41 --> Total execution time: 0.0381
INFO - 2023-12-07 15:15:57 --> Config Class Initialized
INFO - 2023-12-07 15:15:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:57 --> URI Class Initialized
INFO - 2023-12-07 15:15:57 --> Router Class Initialized
INFO - 2023-12-07 15:15:57 --> Output Class Initialized
INFO - 2023-12-07 15:15:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:57 --> Input Class Initialized
INFO - 2023-12-07 15:15:57 --> Language Class Initialized
INFO - 2023-12-07 15:15:57 --> Language Class Initialized
INFO - 2023-12-07 15:15:57 --> Config Class Initialized
INFO - 2023-12-07 15:15:57 --> Loader Class Initialized
INFO - 2023-12-07 15:15:57 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:57 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:57 --> Controller Class Initialized
DEBUG - 2023-12-07 15:15:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-07 15:15:57 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:15:57 --> Final output sent to browser
DEBUG - 2023-12-07 15:15:57 --> Total execution time: 0.0408
INFO - 2023-12-07 15:15:57 --> Config Class Initialized
INFO - 2023-12-07 15:15:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:57 --> URI Class Initialized
INFO - 2023-12-07 15:15:57 --> Router Class Initialized
INFO - 2023-12-07 15:15:57 --> Output Class Initialized
INFO - 2023-12-07 15:15:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:57 --> Input Class Initialized
INFO - 2023-12-07 15:15:57 --> Language Class Initialized
ERROR - 2023-12-07 15:15:57 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:15:57 --> Config Class Initialized
INFO - 2023-12-07 15:15:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:15:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:15:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:15:57 --> URI Class Initialized
INFO - 2023-12-07 15:15:57 --> Router Class Initialized
INFO - 2023-12-07 15:15:57 --> Output Class Initialized
INFO - 2023-12-07 15:15:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:15:57 --> Input Class Initialized
INFO - 2023-12-07 15:15:57 --> Language Class Initialized
INFO - 2023-12-07 15:15:57 --> Language Class Initialized
INFO - 2023-12-07 15:15:57 --> Config Class Initialized
INFO - 2023-12-07 15:15:57 --> Loader Class Initialized
INFO - 2023-12-07 15:15:57 --> Helper loaded: url_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: file_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: form_helper
INFO - 2023-12-07 15:15:57 --> Helper loaded: my_helper
INFO - 2023-12-07 15:15:57 --> Database Driver Class Initialized
INFO - 2023-12-07 15:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:15:57 --> Controller Class Initialized
INFO - 2023-12-07 15:16:06 --> Config Class Initialized
INFO - 2023-12-07 15:16:06 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:16:06 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:16:06 --> Utf8 Class Initialized
INFO - 2023-12-07 15:16:06 --> URI Class Initialized
INFO - 2023-12-07 15:16:06 --> Router Class Initialized
INFO - 2023-12-07 15:16:06 --> Output Class Initialized
INFO - 2023-12-07 15:16:06 --> Security Class Initialized
DEBUG - 2023-12-07 15:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:16:06 --> Input Class Initialized
INFO - 2023-12-07 15:16:06 --> Language Class Initialized
INFO - 2023-12-07 15:16:06 --> Language Class Initialized
INFO - 2023-12-07 15:16:06 --> Config Class Initialized
INFO - 2023-12-07 15:16:06 --> Loader Class Initialized
INFO - 2023-12-07 15:16:06 --> Helper loaded: url_helper
INFO - 2023-12-07 15:16:06 --> Helper loaded: file_helper
INFO - 2023-12-07 15:16:06 --> Helper loaded: form_helper
INFO - 2023-12-07 15:16:06 --> Helper loaded: my_helper
INFO - 2023-12-07 15:16:06 --> Database Driver Class Initialized
INFO - 2023-12-07 15:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:16:06 --> Controller Class Initialized
INFO - 2023-12-07 15:16:06 --> Final output sent to browser
DEBUG - 2023-12-07 15:16:06 --> Total execution time: 0.0593
INFO - 2023-12-07 15:18:59 --> Config Class Initialized
INFO - 2023-12-07 15:18:59 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:59 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:59 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:59 --> URI Class Initialized
INFO - 2023-12-07 15:18:59 --> Router Class Initialized
INFO - 2023-12-07 15:18:59 --> Output Class Initialized
INFO - 2023-12-07 15:18:59 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:59 --> Input Class Initialized
INFO - 2023-12-07 15:18:59 --> Language Class Initialized
INFO - 2023-12-07 15:18:59 --> Language Class Initialized
INFO - 2023-12-07 15:18:59 --> Config Class Initialized
INFO - 2023-12-07 15:18:59 --> Loader Class Initialized
INFO - 2023-12-07 15:18:59 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: my_helper
INFO - 2023-12-07 15:18:59 --> Database Driver Class Initialized
INFO - 2023-12-07 15:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:59 --> Controller Class Initialized
INFO - 2023-12-07 15:18:59 --> Final output sent to browser
DEBUG - 2023-12-07 15:18:59 --> Total execution time: 0.0491
INFO - 2023-12-07 15:18:59 --> Config Class Initialized
INFO - 2023-12-07 15:18:59 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:59 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:59 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:59 --> URI Class Initialized
INFO - 2023-12-07 15:18:59 --> Router Class Initialized
INFO - 2023-12-07 15:18:59 --> Output Class Initialized
INFO - 2023-12-07 15:18:59 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:59 --> Input Class Initialized
INFO - 2023-12-07 15:18:59 --> Language Class Initialized
ERROR - 2023-12-07 15:18:59 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:18:59 --> Config Class Initialized
INFO - 2023-12-07 15:18:59 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:18:59 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:18:59 --> Utf8 Class Initialized
INFO - 2023-12-07 15:18:59 --> URI Class Initialized
INFO - 2023-12-07 15:18:59 --> Router Class Initialized
INFO - 2023-12-07 15:18:59 --> Output Class Initialized
INFO - 2023-12-07 15:18:59 --> Security Class Initialized
DEBUG - 2023-12-07 15:18:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:18:59 --> Input Class Initialized
INFO - 2023-12-07 15:18:59 --> Language Class Initialized
INFO - 2023-12-07 15:18:59 --> Language Class Initialized
INFO - 2023-12-07 15:18:59 --> Config Class Initialized
INFO - 2023-12-07 15:18:59 --> Loader Class Initialized
INFO - 2023-12-07 15:18:59 --> Helper loaded: url_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: file_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: form_helper
INFO - 2023-12-07 15:18:59 --> Helper loaded: my_helper
INFO - 2023-12-07 15:18:59 --> Database Driver Class Initialized
INFO - 2023-12-07 15:18:59 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:18:59 --> Controller Class Initialized
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:04 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:04 --> URI Class Initialized
INFO - 2023-12-07 15:19:04 --> Router Class Initialized
INFO - 2023-12-07 15:19:04 --> Output Class Initialized
INFO - 2023-12-07 15:19:04 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:04 --> Input Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Loader Class Initialized
INFO - 2023-12-07 15:19:04 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:04 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:04 --> Controller Class Initialized
INFO - 2023-12-07 15:19:04 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:04 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:04 --> URI Class Initialized
INFO - 2023-12-07 15:19:04 --> Router Class Initialized
INFO - 2023-12-07 15:19:04 --> Output Class Initialized
INFO - 2023-12-07 15:19:04 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:04 --> Input Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Loader Class Initialized
INFO - 2023-12-07 15:19:04 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:04 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:04 --> Controller Class Initialized
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:04 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:04 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:04 --> URI Class Initialized
INFO - 2023-12-07 15:19:04 --> Router Class Initialized
INFO - 2023-12-07 15:19:04 --> Output Class Initialized
INFO - 2023-12-07 15:19:04 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:04 --> Input Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Language Class Initialized
INFO - 2023-12-07 15:19:04 --> Config Class Initialized
INFO - 2023-12-07 15:19:04 --> Loader Class Initialized
INFO - 2023-12-07 15:19:04 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:04 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:04 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:04 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:04 --> Controller Class Initialized
DEBUG - 2023-12-07 15:19:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:19:04 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:19:04 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:04 --> Total execution time: 0.0389
INFO - 2023-12-07 15:19:08 --> Config Class Initialized
INFO - 2023-12-07 15:19:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:08 --> URI Class Initialized
INFO - 2023-12-07 15:19:08 --> Router Class Initialized
INFO - 2023-12-07 15:19:08 --> Output Class Initialized
INFO - 2023-12-07 15:19:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:08 --> Input Class Initialized
INFO - 2023-12-07 15:19:08 --> Language Class Initialized
INFO - 2023-12-07 15:19:08 --> Language Class Initialized
INFO - 2023-12-07 15:19:08 --> Config Class Initialized
INFO - 2023-12-07 15:19:08 --> Loader Class Initialized
INFO - 2023-12-07 15:19:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:08 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:08 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:08 --> Controller Class Initialized
INFO - 2023-12-07 15:19:08 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:19:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:08 --> Total execution time: 0.0366
INFO - 2023-12-07 15:19:09 --> Config Class Initialized
INFO - 2023-12-07 15:19:09 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:09 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:09 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:09 --> URI Class Initialized
INFO - 2023-12-07 15:19:09 --> Router Class Initialized
INFO - 2023-12-07 15:19:09 --> Output Class Initialized
INFO - 2023-12-07 15:19:09 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:09 --> Input Class Initialized
INFO - 2023-12-07 15:19:09 --> Language Class Initialized
INFO - 2023-12-07 15:19:09 --> Language Class Initialized
INFO - 2023-12-07 15:19:09 --> Config Class Initialized
INFO - 2023-12-07 15:19:09 --> Loader Class Initialized
INFO - 2023-12-07 15:19:09 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:09 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:09 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:09 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:09 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:09 --> Controller Class Initialized
DEBUG - 2023-12-07 15:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:19:09 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:19:09 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:09 --> Total execution time: 0.0356
INFO - 2023-12-07 15:19:13 --> Config Class Initialized
INFO - 2023-12-07 15:19:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:13 --> URI Class Initialized
INFO - 2023-12-07 15:19:13 --> Router Class Initialized
INFO - 2023-12-07 15:19:13 --> Output Class Initialized
INFO - 2023-12-07 15:19:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:13 --> Input Class Initialized
INFO - 2023-12-07 15:19:13 --> Language Class Initialized
INFO - 2023-12-07 15:19:13 --> Language Class Initialized
INFO - 2023-12-07 15:19:13 --> Config Class Initialized
INFO - 2023-12-07 15:19:13 --> Loader Class Initialized
INFO - 2023-12-07 15:19:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:13 --> Controller Class Initialized
DEBUG - 2023-12-07 15:19:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 15:19:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:19:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:13 --> Total execution time: 0.0463
INFO - 2023-12-07 15:19:15 --> Config Class Initialized
INFO - 2023-12-07 15:19:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:19:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:19:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:19:15 --> URI Class Initialized
INFO - 2023-12-07 15:19:15 --> Router Class Initialized
INFO - 2023-12-07 15:19:15 --> Output Class Initialized
INFO - 2023-12-07 15:19:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:19:15 --> Input Class Initialized
INFO - 2023-12-07 15:19:15 --> Language Class Initialized
INFO - 2023-12-07 15:19:15 --> Language Class Initialized
INFO - 2023-12-07 15:19:15 --> Config Class Initialized
INFO - 2023-12-07 15:19:15 --> Loader Class Initialized
INFO - 2023-12-07 15:19:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:19:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:19:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:19:15 --> Helper loaded: my_helper
INFO - 2023-12-07 15:19:15 --> Database Driver Class Initialized
INFO - 2023-12-07 15:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:19:15 --> Controller Class Initialized
DEBUG - 2023-12-07 15:19:15 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-07 15:19:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:19:17 --> Total execution time: 2.0694
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:45 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:45 --> URI Class Initialized
INFO - 2023-12-07 15:20:45 --> Router Class Initialized
INFO - 2023-12-07 15:20:45 --> Output Class Initialized
INFO - 2023-12-07 15:20:45 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:45 --> Input Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Loader Class Initialized
INFO - 2023-12-07 15:20:45 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: my_helper
INFO - 2023-12-07 15:20:45 --> Database Driver Class Initialized
INFO - 2023-12-07 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:45 --> Controller Class Initialized
INFO - 2023-12-07 15:20:45 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:45 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:45 --> URI Class Initialized
INFO - 2023-12-07 15:20:45 --> Router Class Initialized
INFO - 2023-12-07 15:20:45 --> Output Class Initialized
INFO - 2023-12-07 15:20:45 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:45 --> Input Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Loader Class Initialized
INFO - 2023-12-07 15:20:45 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: my_helper
INFO - 2023-12-07 15:20:45 --> Database Driver Class Initialized
INFO - 2023-12-07 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:45 --> Controller Class Initialized
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:20:45 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:20:45 --> Utf8 Class Initialized
INFO - 2023-12-07 15:20:45 --> URI Class Initialized
INFO - 2023-12-07 15:20:45 --> Router Class Initialized
INFO - 2023-12-07 15:20:45 --> Output Class Initialized
INFO - 2023-12-07 15:20:45 --> Security Class Initialized
DEBUG - 2023-12-07 15:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:20:45 --> Input Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Language Class Initialized
INFO - 2023-12-07 15:20:45 --> Config Class Initialized
INFO - 2023-12-07 15:20:45 --> Loader Class Initialized
INFO - 2023-12-07 15:20:45 --> Helper loaded: url_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: file_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: form_helper
INFO - 2023-12-07 15:20:45 --> Helper loaded: my_helper
INFO - 2023-12-07 15:20:45 --> Database Driver Class Initialized
INFO - 2023-12-07 15:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:20:45 --> Controller Class Initialized
DEBUG - 2023-12-07 15:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:20:45 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:20:45 --> Final output sent to browser
DEBUG - 2023-12-07 15:20:45 --> Total execution time: 0.0385
INFO - 2023-12-07 15:21:31 --> Config Class Initialized
INFO - 2023-12-07 15:21:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:31 --> URI Class Initialized
INFO - 2023-12-07 15:21:31 --> Router Class Initialized
INFO - 2023-12-07 15:21:31 --> Output Class Initialized
INFO - 2023-12-07 15:21:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:31 --> Input Class Initialized
INFO - 2023-12-07 15:21:31 --> Language Class Initialized
INFO - 2023-12-07 15:21:31 --> Language Class Initialized
INFO - 2023-12-07 15:21:31 --> Config Class Initialized
INFO - 2023-12-07 15:21:31 --> Loader Class Initialized
INFO - 2023-12-07 15:21:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:31 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:31 --> Controller Class Initialized
INFO - 2023-12-07 15:21:31 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:21:31 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:31 --> Total execution time: 0.0423
INFO - 2023-12-07 15:21:31 --> Config Class Initialized
INFO - 2023-12-07 15:21:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:31 --> URI Class Initialized
INFO - 2023-12-07 15:21:31 --> Router Class Initialized
INFO - 2023-12-07 15:21:31 --> Output Class Initialized
INFO - 2023-12-07 15:21:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:31 --> Input Class Initialized
INFO - 2023-12-07 15:21:31 --> Language Class Initialized
INFO - 2023-12-07 15:21:31 --> Language Class Initialized
INFO - 2023-12-07 15:21:31 --> Config Class Initialized
INFO - 2023-12-07 15:21:31 --> Loader Class Initialized
INFO - 2023-12-07 15:21:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:31 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:31 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:31 --> Controller Class Initialized
DEBUG - 2023-12-07 15:21:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-07 15:21:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:21:31 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:31 --> Total execution time: 0.0418
INFO - 2023-12-07 15:21:33 --> Config Class Initialized
INFO - 2023-12-07 15:21:33 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:33 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:33 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:33 --> URI Class Initialized
INFO - 2023-12-07 15:21:33 --> Router Class Initialized
INFO - 2023-12-07 15:21:33 --> Output Class Initialized
INFO - 2023-12-07 15:21:33 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:33 --> Input Class Initialized
INFO - 2023-12-07 15:21:33 --> Language Class Initialized
INFO - 2023-12-07 15:21:33 --> Language Class Initialized
INFO - 2023-12-07 15:21:33 --> Config Class Initialized
INFO - 2023-12-07 15:21:33 --> Loader Class Initialized
INFO - 2023-12-07 15:21:33 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:33 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:33 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:33 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:33 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:33 --> Controller Class Initialized
DEBUG - 2023-12-07 15:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-07 15:21:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:21:33 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:33 --> Total execution time: 0.0362
INFO - 2023-12-07 15:21:34 --> Config Class Initialized
INFO - 2023-12-07 15:21:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:34 --> URI Class Initialized
INFO - 2023-12-07 15:21:34 --> Router Class Initialized
INFO - 2023-12-07 15:21:34 --> Output Class Initialized
INFO - 2023-12-07 15:21:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:34 --> Input Class Initialized
INFO - 2023-12-07 15:21:34 --> Language Class Initialized
ERROR - 2023-12-07 15:21:34 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:21:34 --> Config Class Initialized
INFO - 2023-12-07 15:21:34 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:34 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:34 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:34 --> URI Class Initialized
INFO - 2023-12-07 15:21:34 --> Router Class Initialized
INFO - 2023-12-07 15:21:34 --> Output Class Initialized
INFO - 2023-12-07 15:21:34 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:34 --> Input Class Initialized
INFO - 2023-12-07 15:21:34 --> Language Class Initialized
INFO - 2023-12-07 15:21:34 --> Language Class Initialized
INFO - 2023-12-07 15:21:34 --> Config Class Initialized
INFO - 2023-12-07 15:21:34 --> Loader Class Initialized
INFO - 2023-12-07 15:21:34 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:34 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:34 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:34 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:34 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:34 --> Controller Class Initialized
INFO - 2023-12-07 15:21:37 --> Config Class Initialized
INFO - 2023-12-07 15:21:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:37 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:37 --> URI Class Initialized
INFO - 2023-12-07 15:21:37 --> Router Class Initialized
INFO - 2023-12-07 15:21:37 --> Output Class Initialized
INFO - 2023-12-07 15:21:37 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:37 --> Input Class Initialized
INFO - 2023-12-07 15:21:37 --> Language Class Initialized
INFO - 2023-12-07 15:21:37 --> Language Class Initialized
INFO - 2023-12-07 15:21:37 --> Config Class Initialized
INFO - 2023-12-07 15:21:37 --> Loader Class Initialized
INFO - 2023-12-07 15:21:37 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:37 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:37 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:37 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:37 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:37 --> Controller Class Initialized
INFO - 2023-12-07 15:21:37 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:37 --> Total execution time: 0.0426
INFO - 2023-12-07 15:21:43 --> Config Class Initialized
INFO - 2023-12-07 15:21:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:43 --> URI Class Initialized
INFO - 2023-12-07 15:21:43 --> Router Class Initialized
INFO - 2023-12-07 15:21:43 --> Output Class Initialized
INFO - 2023-12-07 15:21:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:43 --> Input Class Initialized
INFO - 2023-12-07 15:21:43 --> Language Class Initialized
INFO - 2023-12-07 15:21:43 --> Language Class Initialized
INFO - 2023-12-07 15:21:43 --> Config Class Initialized
INFO - 2023-12-07 15:21:43 --> Loader Class Initialized
INFO - 2023-12-07 15:21:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:43 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:43 --> Controller Class Initialized
INFO - 2023-12-07 15:21:43 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:43 --> Total execution time: 0.0366
INFO - 2023-12-07 15:21:43 --> Config Class Initialized
INFO - 2023-12-07 15:21:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:43 --> URI Class Initialized
INFO - 2023-12-07 15:21:43 --> Router Class Initialized
INFO - 2023-12-07 15:21:43 --> Output Class Initialized
INFO - 2023-12-07 15:21:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:43 --> Input Class Initialized
INFO - 2023-12-07 15:21:43 --> Language Class Initialized
ERROR - 2023-12-07 15:21:43 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:21:43 --> Config Class Initialized
INFO - 2023-12-07 15:21:43 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:43 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:43 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:43 --> URI Class Initialized
INFO - 2023-12-07 15:21:43 --> Router Class Initialized
INFO - 2023-12-07 15:21:43 --> Output Class Initialized
INFO - 2023-12-07 15:21:43 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:43 --> Input Class Initialized
INFO - 2023-12-07 15:21:43 --> Language Class Initialized
INFO - 2023-12-07 15:21:43 --> Language Class Initialized
INFO - 2023-12-07 15:21:43 --> Config Class Initialized
INFO - 2023-12-07 15:21:43 --> Loader Class Initialized
INFO - 2023-12-07 15:21:43 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:43 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:43 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:43 --> Controller Class Initialized
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:48 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:48 --> URI Class Initialized
INFO - 2023-12-07 15:21:48 --> Router Class Initialized
INFO - 2023-12-07 15:21:48 --> Output Class Initialized
INFO - 2023-12-07 15:21:48 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:48 --> Input Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Loader Class Initialized
INFO - 2023-12-07 15:21:48 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:48 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:48 --> Controller Class Initialized
INFO - 2023-12-07 15:21:48 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:48 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:48 --> URI Class Initialized
INFO - 2023-12-07 15:21:48 --> Router Class Initialized
INFO - 2023-12-07 15:21:48 --> Output Class Initialized
INFO - 2023-12-07 15:21:48 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:48 --> Input Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Loader Class Initialized
INFO - 2023-12-07 15:21:48 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:48 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:48 --> Controller Class Initialized
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:48 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:48 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:48 --> URI Class Initialized
INFO - 2023-12-07 15:21:48 --> Router Class Initialized
INFO - 2023-12-07 15:21:48 --> Output Class Initialized
INFO - 2023-12-07 15:21:48 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:48 --> Input Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Language Class Initialized
INFO - 2023-12-07 15:21:48 --> Config Class Initialized
INFO - 2023-12-07 15:21:48 --> Loader Class Initialized
INFO - 2023-12-07 15:21:48 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:48 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:48 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:48 --> Controller Class Initialized
DEBUG - 2023-12-07 15:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:21:49 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:21:49 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:49 --> Total execution time: 0.0945
INFO - 2023-12-07 15:21:53 --> Config Class Initialized
INFO - 2023-12-07 15:21:53 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:53 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:53 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:53 --> URI Class Initialized
INFO - 2023-12-07 15:21:53 --> Router Class Initialized
INFO - 2023-12-07 15:21:53 --> Output Class Initialized
INFO - 2023-12-07 15:21:53 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:53 --> Input Class Initialized
INFO - 2023-12-07 15:21:53 --> Language Class Initialized
INFO - 2023-12-07 15:21:53 --> Language Class Initialized
INFO - 2023-12-07 15:21:53 --> Config Class Initialized
INFO - 2023-12-07 15:21:53 --> Loader Class Initialized
INFO - 2023-12-07 15:21:53 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:53 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:53 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:53 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:54 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:54 --> Controller Class Initialized
INFO - 2023-12-07 15:21:54 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:21:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:54 --> Total execution time: 0.0727
INFO - 2023-12-07 15:21:54 --> Config Class Initialized
INFO - 2023-12-07 15:21:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:21:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:21:54 --> Utf8 Class Initialized
INFO - 2023-12-07 15:21:54 --> URI Class Initialized
INFO - 2023-12-07 15:21:54 --> Router Class Initialized
INFO - 2023-12-07 15:21:54 --> Output Class Initialized
INFO - 2023-12-07 15:21:54 --> Security Class Initialized
DEBUG - 2023-12-07 15:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:21:54 --> Input Class Initialized
INFO - 2023-12-07 15:21:54 --> Language Class Initialized
INFO - 2023-12-07 15:21:54 --> Language Class Initialized
INFO - 2023-12-07 15:21:54 --> Config Class Initialized
INFO - 2023-12-07 15:21:54 --> Loader Class Initialized
INFO - 2023-12-07 15:21:54 --> Helper loaded: url_helper
INFO - 2023-12-07 15:21:54 --> Helper loaded: file_helper
INFO - 2023-12-07 15:21:54 --> Helper loaded: form_helper
INFO - 2023-12-07 15:21:54 --> Helper loaded: my_helper
INFO - 2023-12-07 15:21:54 --> Database Driver Class Initialized
INFO - 2023-12-07 15:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:21:54 --> Controller Class Initialized
DEBUG - 2023-12-07 15:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 15:21:54 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:21:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:21:54 --> Total execution time: 0.1150
INFO - 2023-12-07 15:22:17 --> Config Class Initialized
INFO - 2023-12-07 15:22:17 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:17 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:17 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:17 --> URI Class Initialized
INFO - 2023-12-07 15:22:17 --> Router Class Initialized
INFO - 2023-12-07 15:22:17 --> Output Class Initialized
INFO - 2023-12-07 15:22:17 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:17 --> Input Class Initialized
INFO - 2023-12-07 15:22:17 --> Language Class Initialized
INFO - 2023-12-07 15:22:17 --> Language Class Initialized
INFO - 2023-12-07 15:22:17 --> Config Class Initialized
INFO - 2023-12-07 15:22:17 --> Loader Class Initialized
INFO - 2023-12-07 15:22:17 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:17 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:17 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:17 --> Helper loaded: my_helper
INFO - 2023-12-07 15:22:17 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:17 --> Controller Class Initialized
DEBUG - 2023-12-07 15:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/list.php
DEBUG - 2023-12-07 15:22:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:22:17 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:17 --> Total execution time: 0.0506
INFO - 2023-12-07 15:22:19 --> Config Class Initialized
INFO - 2023-12-07 15:22:19 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:19 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:19 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:19 --> URI Class Initialized
INFO - 2023-12-07 15:22:19 --> Router Class Initialized
INFO - 2023-12-07 15:22:19 --> Output Class Initialized
INFO - 2023-12-07 15:22:19 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:19 --> Input Class Initialized
INFO - 2023-12-07 15:22:19 --> Language Class Initialized
INFO - 2023-12-07 15:22:19 --> Language Class Initialized
INFO - 2023-12-07 15:22:19 --> Config Class Initialized
INFO - 2023-12-07 15:22:19 --> Loader Class Initialized
INFO - 2023-12-07 15:22:19 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:19 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:19 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:19 --> Helper loaded: my_helper
INFO - 2023-12-07 15:22:19 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:19 --> Controller Class Initialized
DEBUG - 2023-12-07 15:22:19 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2023-12-07 15:22:22 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:22 --> Total execution time: 2.4003
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:50 --> URI Class Initialized
INFO - 2023-12-07 15:22:50 --> Router Class Initialized
INFO - 2023-12-07 15:22:50 --> Output Class Initialized
INFO - 2023-12-07 15:22:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:50 --> Input Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Loader Class Initialized
INFO - 2023-12-07 15:22:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: my_helper
INFO - 2023-12-07 15:22:50 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:50 --> Controller Class Initialized
INFO - 2023-12-07 15:22:50 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:50 --> URI Class Initialized
INFO - 2023-12-07 15:22:50 --> Router Class Initialized
INFO - 2023-12-07 15:22:50 --> Output Class Initialized
INFO - 2023-12-07 15:22:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:50 --> Input Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Loader Class Initialized
INFO - 2023-12-07 15:22:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: my_helper
INFO - 2023-12-07 15:22:50 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:50 --> Controller Class Initialized
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:22:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:22:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:22:50 --> URI Class Initialized
INFO - 2023-12-07 15:22:50 --> Router Class Initialized
INFO - 2023-12-07 15:22:50 --> Output Class Initialized
INFO - 2023-12-07 15:22:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:22:50 --> Input Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Language Class Initialized
INFO - 2023-12-07 15:22:50 --> Config Class Initialized
INFO - 2023-12-07 15:22:50 --> Loader Class Initialized
INFO - 2023-12-07 15:22:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:22:50 --> Helper loaded: my_helper
INFO - 2023-12-07 15:22:50 --> Database Driver Class Initialized
INFO - 2023-12-07 15:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:22:50 --> Controller Class Initialized
DEBUG - 2023-12-07 15:22:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 15:22:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:22:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:22:50 --> Total execution time: 0.0424
INFO - 2023-12-07 15:23:05 --> Config Class Initialized
INFO - 2023-12-07 15:23:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:23:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:23:05 --> Utf8 Class Initialized
INFO - 2023-12-07 15:23:05 --> URI Class Initialized
INFO - 2023-12-07 15:23:05 --> Router Class Initialized
INFO - 2023-12-07 15:23:05 --> Output Class Initialized
INFO - 2023-12-07 15:23:05 --> Security Class Initialized
DEBUG - 2023-12-07 15:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:23:05 --> Input Class Initialized
INFO - 2023-12-07 15:23:05 --> Language Class Initialized
INFO - 2023-12-07 15:23:05 --> Language Class Initialized
INFO - 2023-12-07 15:23:05 --> Config Class Initialized
INFO - 2023-12-07 15:23:05 --> Loader Class Initialized
INFO - 2023-12-07 15:23:05 --> Helper loaded: url_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: file_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: form_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: my_helper
INFO - 2023-12-07 15:23:05 --> Database Driver Class Initialized
INFO - 2023-12-07 15:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:23:05 --> Controller Class Initialized
INFO - 2023-12-07 15:23:05 --> Helper loaded: cookie_helper
INFO - 2023-12-07 15:23:05 --> Final output sent to browser
DEBUG - 2023-12-07 15:23:05 --> Total execution time: 0.0339
INFO - 2023-12-07 15:23:05 --> Config Class Initialized
INFO - 2023-12-07 15:23:05 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:23:05 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:23:05 --> Utf8 Class Initialized
INFO - 2023-12-07 15:23:05 --> URI Class Initialized
INFO - 2023-12-07 15:23:05 --> Router Class Initialized
INFO - 2023-12-07 15:23:05 --> Output Class Initialized
INFO - 2023-12-07 15:23:05 --> Security Class Initialized
DEBUG - 2023-12-07 15:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:23:05 --> Input Class Initialized
INFO - 2023-12-07 15:23:05 --> Language Class Initialized
INFO - 2023-12-07 15:23:05 --> Language Class Initialized
INFO - 2023-12-07 15:23:05 --> Config Class Initialized
INFO - 2023-12-07 15:23:05 --> Loader Class Initialized
INFO - 2023-12-07 15:23:05 --> Helper loaded: url_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: file_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: form_helper
INFO - 2023-12-07 15:23:05 --> Helper loaded: my_helper
INFO - 2023-12-07 15:23:05 --> Database Driver Class Initialized
INFO - 2023-12-07 15:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:23:05 --> Controller Class Initialized
DEBUG - 2023-12-07 15:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-12-07 15:23:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:23:05 --> Final output sent to browser
DEBUG - 2023-12-07 15:23:05 --> Total execution time: 0.0382
INFO - 2023-12-07 15:31:08 --> Config Class Initialized
INFO - 2023-12-07 15:31:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:08 --> URI Class Initialized
INFO - 2023-12-07 15:31:08 --> Router Class Initialized
INFO - 2023-12-07 15:31:08 --> Output Class Initialized
INFO - 2023-12-07 15:31:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:08 --> Input Class Initialized
INFO - 2023-12-07 15:31:08 --> Language Class Initialized
INFO - 2023-12-07 15:31:08 --> Language Class Initialized
INFO - 2023-12-07 15:31:08 --> Config Class Initialized
INFO - 2023-12-07 15:31:08 --> Loader Class Initialized
INFO - 2023-12-07 15:31:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: my_helper
INFO - 2023-12-07 15:31:08 --> Database Driver Class Initialized
INFO - 2023-12-07 15:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:08 --> Controller Class Initialized
DEBUG - 2023-12-07 15:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-07 15:31:08 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:31:08 --> Final output sent to browser
DEBUG - 2023-12-07 15:31:08 --> Total execution time: 0.0421
INFO - 2023-12-07 15:31:08 --> Config Class Initialized
INFO - 2023-12-07 15:31:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:08 --> URI Class Initialized
INFO - 2023-12-07 15:31:08 --> Router Class Initialized
INFO - 2023-12-07 15:31:08 --> Output Class Initialized
INFO - 2023-12-07 15:31:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:08 --> Input Class Initialized
INFO - 2023-12-07 15:31:08 --> Language Class Initialized
ERROR - 2023-12-07 15:31:08 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:31:08 --> Config Class Initialized
INFO - 2023-12-07 15:31:08 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:08 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:08 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:08 --> URI Class Initialized
INFO - 2023-12-07 15:31:08 --> Router Class Initialized
INFO - 2023-12-07 15:31:08 --> Output Class Initialized
INFO - 2023-12-07 15:31:08 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:08 --> Input Class Initialized
INFO - 2023-12-07 15:31:08 --> Language Class Initialized
INFO - 2023-12-07 15:31:08 --> Language Class Initialized
INFO - 2023-12-07 15:31:08 --> Config Class Initialized
INFO - 2023-12-07 15:31:08 --> Loader Class Initialized
INFO - 2023-12-07 15:31:08 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:08 --> Helper loaded: my_helper
INFO - 2023-12-07 15:31:09 --> Database Driver Class Initialized
INFO - 2023-12-07 15:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:09 --> Controller Class Initialized
INFO - 2023-12-07 15:31:15 --> Config Class Initialized
INFO - 2023-12-07 15:31:15 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:15 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:15 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:15 --> URI Class Initialized
INFO - 2023-12-07 15:31:15 --> Router Class Initialized
INFO - 2023-12-07 15:31:15 --> Output Class Initialized
INFO - 2023-12-07 15:31:15 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:15 --> Input Class Initialized
INFO - 2023-12-07 15:31:15 --> Language Class Initialized
INFO - 2023-12-07 15:31:15 --> Language Class Initialized
INFO - 2023-12-07 15:31:15 --> Config Class Initialized
INFO - 2023-12-07 15:31:15 --> Loader Class Initialized
INFO - 2023-12-07 15:31:15 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:15 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:15 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:15 --> Helper loaded: my_helper
INFO - 2023-12-07 15:31:15 --> Database Driver Class Initialized
INFO - 2023-12-07 15:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:15 --> Controller Class Initialized
INFO - 2023-12-07 15:31:15 --> Final output sent to browser
DEBUG - 2023-12-07 15:31:15 --> Total execution time: 0.0351
INFO - 2023-12-07 15:31:57 --> Config Class Initialized
INFO - 2023-12-07 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:57 --> URI Class Initialized
INFO - 2023-12-07 15:31:57 --> Router Class Initialized
INFO - 2023-12-07 15:31:57 --> Output Class Initialized
INFO - 2023-12-07 15:31:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:57 --> Input Class Initialized
INFO - 2023-12-07 15:31:57 --> Language Class Initialized
INFO - 2023-12-07 15:31:57 --> Language Class Initialized
INFO - 2023-12-07 15:31:57 --> Config Class Initialized
INFO - 2023-12-07 15:31:57 --> Loader Class Initialized
INFO - 2023-12-07 15:31:57 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: my_helper
INFO - 2023-12-07 15:31:57 --> Database Driver Class Initialized
INFO - 2023-12-07 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:57 --> Controller Class Initialized
INFO - 2023-12-07 15:31:57 --> Final output sent to browser
DEBUG - 2023-12-07 15:31:57 --> Total execution time: 0.0425
INFO - 2023-12-07 15:31:57 --> Config Class Initialized
INFO - 2023-12-07 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:57 --> URI Class Initialized
INFO - 2023-12-07 15:31:57 --> Router Class Initialized
INFO - 2023-12-07 15:31:57 --> Output Class Initialized
INFO - 2023-12-07 15:31:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:57 --> Input Class Initialized
INFO - 2023-12-07 15:31:57 --> Language Class Initialized
ERROR - 2023-12-07 15:31:57 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:31:57 --> Config Class Initialized
INFO - 2023-12-07 15:31:57 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:31:57 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:31:57 --> Utf8 Class Initialized
INFO - 2023-12-07 15:31:57 --> URI Class Initialized
INFO - 2023-12-07 15:31:57 --> Router Class Initialized
INFO - 2023-12-07 15:31:57 --> Output Class Initialized
INFO - 2023-12-07 15:31:57 --> Security Class Initialized
DEBUG - 2023-12-07 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:31:57 --> Input Class Initialized
INFO - 2023-12-07 15:31:57 --> Language Class Initialized
INFO - 2023-12-07 15:31:57 --> Language Class Initialized
INFO - 2023-12-07 15:31:57 --> Config Class Initialized
INFO - 2023-12-07 15:31:57 --> Loader Class Initialized
INFO - 2023-12-07 15:31:57 --> Helper loaded: url_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: file_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: form_helper
INFO - 2023-12-07 15:31:57 --> Helper loaded: my_helper
INFO - 2023-12-07 15:31:57 --> Database Driver Class Initialized
INFO - 2023-12-07 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:31:57 --> Controller Class Initialized
INFO - 2023-12-07 15:35:24 --> Config Class Initialized
INFO - 2023-12-07 15:35:24 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:24 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:24 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:24 --> URI Class Initialized
INFO - 2023-12-07 15:35:24 --> Router Class Initialized
INFO - 2023-12-07 15:35:24 --> Output Class Initialized
INFO - 2023-12-07 15:35:24 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:24 --> Input Class Initialized
INFO - 2023-12-07 15:35:24 --> Language Class Initialized
INFO - 2023-12-07 15:35:24 --> Language Class Initialized
INFO - 2023-12-07 15:35:24 --> Config Class Initialized
INFO - 2023-12-07 15:35:24 --> Loader Class Initialized
INFO - 2023-12-07 15:35:24 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:24 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:24 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:24 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:24 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:24 --> Controller Class Initialized
DEBUG - 2023-12-07 15:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-12-07 15:35:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:35:24 --> Final output sent to browser
DEBUG - 2023-12-07 15:35:24 --> Total execution time: 0.0352
INFO - 2023-12-07 15:35:25 --> Config Class Initialized
INFO - 2023-12-07 15:35:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:25 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:25 --> URI Class Initialized
INFO - 2023-12-07 15:35:25 --> Router Class Initialized
INFO - 2023-12-07 15:35:25 --> Output Class Initialized
INFO - 2023-12-07 15:35:25 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:25 --> Input Class Initialized
INFO - 2023-12-07 15:35:25 --> Language Class Initialized
ERROR - 2023-12-07 15:35:25 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:35:25 --> Config Class Initialized
INFO - 2023-12-07 15:35:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:25 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:25 --> URI Class Initialized
INFO - 2023-12-07 15:35:25 --> Router Class Initialized
INFO - 2023-12-07 15:35:25 --> Output Class Initialized
INFO - 2023-12-07 15:35:25 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:25 --> Input Class Initialized
INFO - 2023-12-07 15:35:25 --> Language Class Initialized
INFO - 2023-12-07 15:35:25 --> Language Class Initialized
INFO - 2023-12-07 15:35:25 --> Config Class Initialized
INFO - 2023-12-07 15:35:25 --> Loader Class Initialized
INFO - 2023-12-07 15:35:25 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:25 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:25 --> Controller Class Initialized
INFO - 2023-12-07 15:35:25 --> Config Class Initialized
INFO - 2023-12-07 15:35:25 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:25 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:25 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:25 --> URI Class Initialized
INFO - 2023-12-07 15:35:25 --> Router Class Initialized
INFO - 2023-12-07 15:35:25 --> Output Class Initialized
INFO - 2023-12-07 15:35:25 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:25 --> Input Class Initialized
INFO - 2023-12-07 15:35:25 --> Language Class Initialized
INFO - 2023-12-07 15:35:25 --> Language Class Initialized
INFO - 2023-12-07 15:35:25 --> Config Class Initialized
INFO - 2023-12-07 15:35:25 --> Loader Class Initialized
INFO - 2023-12-07 15:35:25 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:25 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:25 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:25 --> Controller Class Initialized
DEBUG - 2023-12-07 15:35:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_guru/views/list.php
DEBUG - 2023-12-07 15:35:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:35:25 --> Final output sent to browser
DEBUG - 2023-12-07 15:35:25 --> Total execution time: 0.0329
INFO - 2023-12-07 15:35:26 --> Config Class Initialized
INFO - 2023-12-07 15:35:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:26 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:26 --> URI Class Initialized
INFO - 2023-12-07 15:35:26 --> Router Class Initialized
INFO - 2023-12-07 15:35:26 --> Output Class Initialized
INFO - 2023-12-07 15:35:26 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:26 --> Input Class Initialized
INFO - 2023-12-07 15:35:26 --> Language Class Initialized
ERROR - 2023-12-07 15:35:26 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:35:26 --> Config Class Initialized
INFO - 2023-12-07 15:35:26 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:26 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:26 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:26 --> URI Class Initialized
INFO - 2023-12-07 15:35:26 --> Router Class Initialized
INFO - 2023-12-07 15:35:26 --> Output Class Initialized
INFO - 2023-12-07 15:35:26 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:26 --> Input Class Initialized
INFO - 2023-12-07 15:35:26 --> Language Class Initialized
INFO - 2023-12-07 15:35:26 --> Language Class Initialized
INFO - 2023-12-07 15:35:26 --> Config Class Initialized
INFO - 2023-12-07 15:35:26 --> Loader Class Initialized
INFO - 2023-12-07 15:35:26 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:26 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:26 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:26 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:26 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:26 --> Controller Class Initialized
INFO - 2023-12-07 15:35:29 --> Config Class Initialized
INFO - 2023-12-07 15:35:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:29 --> URI Class Initialized
INFO - 2023-12-07 15:35:29 --> Router Class Initialized
INFO - 2023-12-07 15:35:29 --> Output Class Initialized
INFO - 2023-12-07 15:35:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:29 --> Input Class Initialized
INFO - 2023-12-07 15:35:29 --> Language Class Initialized
INFO - 2023-12-07 15:35:29 --> Language Class Initialized
INFO - 2023-12-07 15:35:29 --> Config Class Initialized
INFO - 2023-12-07 15:35:29 --> Loader Class Initialized
INFO - 2023-12-07 15:35:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:29 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:29 --> Controller Class Initialized
DEBUG - 2023-12-07 15:35:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-12-07 15:35:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:35:29 --> Final output sent to browser
DEBUG - 2023-12-07 15:35:29 --> Total execution time: 0.0325
INFO - 2023-12-07 15:35:29 --> Config Class Initialized
INFO - 2023-12-07 15:35:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:29 --> URI Class Initialized
INFO - 2023-12-07 15:35:29 --> Router Class Initialized
INFO - 2023-12-07 15:35:29 --> Output Class Initialized
INFO - 2023-12-07 15:35:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:29 --> Input Class Initialized
INFO - 2023-12-07 15:35:29 --> Language Class Initialized
ERROR - 2023-12-07 15:35:29 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:35:29 --> Config Class Initialized
INFO - 2023-12-07 15:35:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:29 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:29 --> URI Class Initialized
INFO - 2023-12-07 15:35:29 --> Router Class Initialized
INFO - 2023-12-07 15:35:29 --> Output Class Initialized
INFO - 2023-12-07 15:35:29 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:29 --> Input Class Initialized
INFO - 2023-12-07 15:35:29 --> Language Class Initialized
INFO - 2023-12-07 15:35:29 --> Language Class Initialized
INFO - 2023-12-07 15:35:29 --> Config Class Initialized
INFO - 2023-12-07 15:35:29 --> Loader Class Initialized
INFO - 2023-12-07 15:35:29 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:29 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:29 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:29 --> Controller Class Initialized
INFO - 2023-12-07 15:35:31 --> Config Class Initialized
INFO - 2023-12-07 15:35:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:31 --> URI Class Initialized
INFO - 2023-12-07 15:35:31 --> Router Class Initialized
INFO - 2023-12-07 15:35:31 --> Output Class Initialized
INFO - 2023-12-07 15:35:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:31 --> Input Class Initialized
INFO - 2023-12-07 15:35:31 --> Language Class Initialized
INFO - 2023-12-07 15:35:31 --> Language Class Initialized
INFO - 2023-12-07 15:35:31 --> Config Class Initialized
INFO - 2023-12-07 15:35:31 --> Loader Class Initialized
INFO - 2023-12-07 15:35:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:31 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:31 --> Controller Class Initialized
DEBUG - 2023-12-07 15:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_kelas/views/list.php
DEBUG - 2023-12-07 15:35:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:35:31 --> Final output sent to browser
DEBUG - 2023-12-07 15:35:31 --> Total execution time: 0.0499
INFO - 2023-12-07 15:35:31 --> Config Class Initialized
INFO - 2023-12-07 15:35:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:31 --> URI Class Initialized
INFO - 2023-12-07 15:35:31 --> Router Class Initialized
INFO - 2023-12-07 15:35:31 --> Output Class Initialized
INFO - 2023-12-07 15:35:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:31 --> Input Class Initialized
INFO - 2023-12-07 15:35:31 --> Language Class Initialized
ERROR - 2023-12-07 15:35:31 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:35:31 --> Config Class Initialized
INFO - 2023-12-07 15:35:31 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:35:31 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:35:31 --> Utf8 Class Initialized
INFO - 2023-12-07 15:35:31 --> URI Class Initialized
INFO - 2023-12-07 15:35:31 --> Router Class Initialized
INFO - 2023-12-07 15:35:31 --> Output Class Initialized
INFO - 2023-12-07 15:35:31 --> Security Class Initialized
DEBUG - 2023-12-07 15:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:35:31 --> Input Class Initialized
INFO - 2023-12-07 15:35:31 --> Language Class Initialized
INFO - 2023-12-07 15:35:31 --> Language Class Initialized
INFO - 2023-12-07 15:35:31 --> Config Class Initialized
INFO - 2023-12-07 15:35:31 --> Loader Class Initialized
INFO - 2023-12-07 15:35:31 --> Helper loaded: url_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: file_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: form_helper
INFO - 2023-12-07 15:35:31 --> Helper loaded: my_helper
INFO - 2023-12-07 15:35:31 --> Database Driver Class Initialized
INFO - 2023-12-07 15:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:35:31 --> Controller Class Initialized
INFO - 2023-12-07 15:36:50 --> Config Class Initialized
INFO - 2023-12-07 15:36:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:36:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:36:50 --> Utf8 Class Initialized
INFO - 2023-12-07 15:36:50 --> URI Class Initialized
INFO - 2023-12-07 15:36:50 --> Router Class Initialized
INFO - 2023-12-07 15:36:50 --> Output Class Initialized
INFO - 2023-12-07 15:36:50 --> Security Class Initialized
DEBUG - 2023-12-07 15:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:36:50 --> Input Class Initialized
INFO - 2023-12-07 15:36:50 --> Language Class Initialized
INFO - 2023-12-07 15:36:50 --> Language Class Initialized
INFO - 2023-12-07 15:36:50 --> Config Class Initialized
INFO - 2023-12-07 15:36:50 --> Loader Class Initialized
INFO - 2023-12-07 15:36:50 --> Helper loaded: url_helper
INFO - 2023-12-07 15:36:50 --> Helper loaded: file_helper
INFO - 2023-12-07 15:36:50 --> Helper loaded: form_helper
INFO - 2023-12-07 15:36:50 --> Helper loaded: my_helper
INFO - 2023-12-07 15:36:50 --> Database Driver Class Initialized
INFO - 2023-12-07 15:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:36:50 --> Controller Class Initialized
DEBUG - 2023-12-07 15:36:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_mapel/views/list.php
DEBUG - 2023-12-07 15:36:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 15:36:50 --> Final output sent to browser
DEBUG - 2023-12-07 15:36:50 --> Total execution time: 0.0337
INFO - 2023-12-07 15:36:51 --> Config Class Initialized
INFO - 2023-12-07 15:36:51 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:36:51 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:36:51 --> Utf8 Class Initialized
INFO - 2023-12-07 15:36:51 --> URI Class Initialized
INFO - 2023-12-07 15:36:51 --> Router Class Initialized
INFO - 2023-12-07 15:36:51 --> Output Class Initialized
INFO - 2023-12-07 15:36:51 --> Security Class Initialized
DEBUG - 2023-12-07 15:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:36:51 --> Input Class Initialized
INFO - 2023-12-07 15:36:51 --> Language Class Initialized
ERROR - 2023-12-07 15:36:51 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:36:51 --> Config Class Initialized
INFO - 2023-12-07 15:36:51 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:36:51 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:36:51 --> Utf8 Class Initialized
INFO - 2023-12-07 15:36:51 --> URI Class Initialized
INFO - 2023-12-07 15:36:51 --> Router Class Initialized
INFO - 2023-12-07 15:36:51 --> Output Class Initialized
INFO - 2023-12-07 15:36:51 --> Security Class Initialized
DEBUG - 2023-12-07 15:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:36:51 --> Input Class Initialized
INFO - 2023-12-07 15:36:51 --> Language Class Initialized
INFO - 2023-12-07 15:36:51 --> Language Class Initialized
INFO - 2023-12-07 15:36:51 --> Config Class Initialized
INFO - 2023-12-07 15:36:51 --> Loader Class Initialized
INFO - 2023-12-07 15:36:51 --> Helper loaded: url_helper
INFO - 2023-12-07 15:36:51 --> Helper loaded: file_helper
INFO - 2023-12-07 15:36:51 --> Helper loaded: form_helper
INFO - 2023-12-07 15:36:51 --> Helper loaded: my_helper
INFO - 2023-12-07 15:36:51 --> Database Driver Class Initialized
INFO - 2023-12-07 15:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:36:51 --> Controller Class Initialized
INFO - 2023-12-07 15:36:54 --> Config Class Initialized
INFO - 2023-12-07 15:36:54 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:36:54 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:36:54 --> Utf8 Class Initialized
INFO - 2023-12-07 15:36:54 --> URI Class Initialized
INFO - 2023-12-07 15:36:54 --> Router Class Initialized
INFO - 2023-12-07 15:36:54 --> Output Class Initialized
INFO - 2023-12-07 15:36:54 --> Security Class Initialized
DEBUG - 2023-12-07 15:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:36:54 --> Input Class Initialized
INFO - 2023-12-07 15:36:54 --> Language Class Initialized
INFO - 2023-12-07 15:36:54 --> Language Class Initialized
INFO - 2023-12-07 15:36:54 --> Config Class Initialized
INFO - 2023-12-07 15:36:54 --> Loader Class Initialized
INFO - 2023-12-07 15:36:54 --> Helper loaded: url_helper
INFO - 2023-12-07 15:36:54 --> Helper loaded: file_helper
INFO - 2023-12-07 15:36:54 --> Helper loaded: form_helper
INFO - 2023-12-07 15:36:54 --> Helper loaded: my_helper
INFO - 2023-12-07 15:36:54 --> Database Driver Class Initialized
INFO - 2023-12-07 15:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:36:54 --> Controller Class Initialized
INFO - 2023-12-07 15:36:54 --> Final output sent to browser
DEBUG - 2023-12-07 15:36:54 --> Total execution time: 0.0372
INFO - 2023-12-07 15:37:13 --> Config Class Initialized
INFO - 2023-12-07 15:37:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:37:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:37:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:37:13 --> URI Class Initialized
INFO - 2023-12-07 15:37:13 --> Router Class Initialized
INFO - 2023-12-07 15:37:13 --> Output Class Initialized
INFO - 2023-12-07 15:37:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:37:13 --> Input Class Initialized
INFO - 2023-12-07 15:37:13 --> Language Class Initialized
INFO - 2023-12-07 15:37:13 --> Language Class Initialized
INFO - 2023-12-07 15:37:13 --> Config Class Initialized
INFO - 2023-12-07 15:37:13 --> Loader Class Initialized
INFO - 2023-12-07 15:37:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:37:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:37:13 --> Controller Class Initialized
INFO - 2023-12-07 15:37:13 --> Final output sent to browser
DEBUG - 2023-12-07 15:37:13 --> Total execution time: 0.1174
INFO - 2023-12-07 15:37:13 --> Config Class Initialized
INFO - 2023-12-07 15:37:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:37:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:37:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:37:13 --> URI Class Initialized
INFO - 2023-12-07 15:37:13 --> Router Class Initialized
INFO - 2023-12-07 15:37:13 --> Output Class Initialized
INFO - 2023-12-07 15:37:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:37:13 --> Input Class Initialized
INFO - 2023-12-07 15:37:13 --> Language Class Initialized
ERROR - 2023-12-07 15:37:13 --> 404 Page Not Found: /index
INFO - 2023-12-07 15:37:13 --> Config Class Initialized
INFO - 2023-12-07 15:37:13 --> Hooks Class Initialized
DEBUG - 2023-12-07 15:37:13 --> UTF-8 Support Enabled
INFO - 2023-12-07 15:37:13 --> Utf8 Class Initialized
INFO - 2023-12-07 15:37:13 --> URI Class Initialized
INFO - 2023-12-07 15:37:13 --> Router Class Initialized
INFO - 2023-12-07 15:37:13 --> Output Class Initialized
INFO - 2023-12-07 15:37:13 --> Security Class Initialized
DEBUG - 2023-12-07 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 15:37:13 --> Input Class Initialized
INFO - 2023-12-07 15:37:13 --> Language Class Initialized
INFO - 2023-12-07 15:37:13 --> Language Class Initialized
INFO - 2023-12-07 15:37:13 --> Config Class Initialized
INFO - 2023-12-07 15:37:13 --> Loader Class Initialized
INFO - 2023-12-07 15:37:13 --> Helper loaded: url_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: file_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: form_helper
INFO - 2023-12-07 15:37:13 --> Helper loaded: my_helper
INFO - 2023-12-07 15:37:13 --> Database Driver Class Initialized
INFO - 2023-12-07 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 15:37:13 --> Controller Class Initialized
INFO - 2023-12-07 22:20:50 --> Config Class Initialized
INFO - 2023-12-07 22:20:50 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:20:50 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:20:50 --> Utf8 Class Initialized
INFO - 2023-12-07 22:20:50 --> URI Class Initialized
INFO - 2023-12-07 22:20:50 --> Router Class Initialized
INFO - 2023-12-07 22:20:50 --> Output Class Initialized
INFO - 2023-12-07 22:20:50 --> Security Class Initialized
DEBUG - 2023-12-07 22:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:20:50 --> Input Class Initialized
INFO - 2023-12-07 22:20:50 --> Language Class Initialized
INFO - 2023-12-07 22:20:50 --> Language Class Initialized
INFO - 2023-12-07 22:20:50 --> Config Class Initialized
INFO - 2023-12-07 22:20:50 --> Loader Class Initialized
INFO - 2023-12-07 22:20:50 --> Helper loaded: url_helper
INFO - 2023-12-07 22:20:50 --> Helper loaded: file_helper
INFO - 2023-12-07 22:20:50 --> Helper loaded: form_helper
INFO - 2023-12-07 22:20:50 --> Helper loaded: my_helper
INFO - 2023-12-07 22:20:50 --> Database Driver Class Initialized
INFO - 2023-12-07 22:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:20:50 --> Controller Class Initialized
DEBUG - 2023-12-07 22:20:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-12-07 22:20:50 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 22:20:50 --> Final output sent to browser
DEBUG - 2023-12-07 22:20:50 --> Total execution time: 0.1252
INFO - 2023-12-07 22:21:29 --> Config Class Initialized
INFO - 2023-12-07 22:21:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:21:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:21:29 --> Utf8 Class Initialized
INFO - 2023-12-07 22:21:29 --> URI Class Initialized
INFO - 2023-12-07 22:21:29 --> Router Class Initialized
INFO - 2023-12-07 22:21:29 --> Output Class Initialized
INFO - 2023-12-07 22:21:29 --> Security Class Initialized
DEBUG - 2023-12-07 22:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:21:29 --> Input Class Initialized
INFO - 2023-12-07 22:21:29 --> Language Class Initialized
INFO - 2023-12-07 22:21:29 --> Language Class Initialized
INFO - 2023-12-07 22:21:29 --> Config Class Initialized
INFO - 2023-12-07 22:21:29 --> Loader Class Initialized
INFO - 2023-12-07 22:21:29 --> Helper loaded: url_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: file_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: form_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: my_helper
INFO - 2023-12-07 22:21:29 --> Database Driver Class Initialized
INFO - 2023-12-07 22:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:21:29 --> Controller Class Initialized
INFO - 2023-12-07 22:21:29 --> Helper loaded: cookie_helper
INFO - 2023-12-07 22:21:29 --> Final output sent to browser
DEBUG - 2023-12-07 22:21:29 --> Total execution time: 0.0380
INFO - 2023-12-07 22:21:29 --> Config Class Initialized
INFO - 2023-12-07 22:21:29 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:21:29 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:21:29 --> Utf8 Class Initialized
INFO - 2023-12-07 22:21:29 --> URI Class Initialized
INFO - 2023-12-07 22:21:29 --> Router Class Initialized
INFO - 2023-12-07 22:21:29 --> Output Class Initialized
INFO - 2023-12-07 22:21:29 --> Security Class Initialized
DEBUG - 2023-12-07 22:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:21:29 --> Input Class Initialized
INFO - 2023-12-07 22:21:29 --> Language Class Initialized
INFO - 2023-12-07 22:21:29 --> Language Class Initialized
INFO - 2023-12-07 22:21:29 --> Config Class Initialized
INFO - 2023-12-07 22:21:29 --> Loader Class Initialized
INFO - 2023-12-07 22:21:29 --> Helper loaded: url_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: file_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: form_helper
INFO - 2023-12-07 22:21:29 --> Helper loaded: my_helper
INFO - 2023-12-07 22:21:29 --> Database Driver Class Initialized
INFO - 2023-12-07 22:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:21:29 --> Controller Class Initialized
DEBUG - 2023-12-07 22:21:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-12-07 22:21:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 22:21:29 --> Final output sent to browser
DEBUG - 2023-12-07 22:21:29 --> Total execution time: 0.0382
INFO - 2023-12-07 22:21:37 --> Config Class Initialized
INFO - 2023-12-07 22:21:37 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:21:37 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:21:37 --> Utf8 Class Initialized
INFO - 2023-12-07 22:21:37 --> URI Class Initialized
INFO - 2023-12-07 22:21:37 --> Router Class Initialized
INFO - 2023-12-07 22:21:37 --> Output Class Initialized
INFO - 2023-12-07 22:21:37 --> Security Class Initialized
DEBUG - 2023-12-07 22:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:21:37 --> Input Class Initialized
INFO - 2023-12-07 22:21:37 --> Language Class Initialized
INFO - 2023-12-07 22:21:37 --> Language Class Initialized
INFO - 2023-12-07 22:21:37 --> Config Class Initialized
INFO - 2023-12-07 22:21:37 --> Loader Class Initialized
INFO - 2023-12-07 22:21:37 --> Helper loaded: url_helper
INFO - 2023-12-07 22:21:37 --> Helper loaded: file_helper
INFO - 2023-12-07 22:21:37 --> Helper loaded: form_helper
INFO - 2023-12-07 22:21:37 --> Helper loaded: my_helper
INFO - 2023-12-07 22:21:37 --> Database Driver Class Initialized
INFO - 2023-12-07 22:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:21:37 --> Controller Class Initialized
DEBUG - 2023-12-07 22:21:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/view_mapel/views/v_view_mapel.php
DEBUG - 2023-12-07 22:21:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 22:21:37 --> Final output sent to browser
DEBUG - 2023-12-07 22:21:37 --> Total execution time: 0.0364
INFO - 2023-12-07 22:21:41 --> Config Class Initialized
INFO - 2023-12-07 22:21:41 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:21:41 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:21:41 --> Utf8 Class Initialized
INFO - 2023-12-07 22:21:41 --> URI Class Initialized
INFO - 2023-12-07 22:21:41 --> Router Class Initialized
INFO - 2023-12-07 22:21:41 --> Output Class Initialized
INFO - 2023-12-07 22:21:41 --> Security Class Initialized
DEBUG - 2023-12-07 22:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:21:41 --> Input Class Initialized
INFO - 2023-12-07 22:21:41 --> Language Class Initialized
INFO - 2023-12-07 22:21:41 --> Language Class Initialized
INFO - 2023-12-07 22:21:41 --> Config Class Initialized
INFO - 2023-12-07 22:21:41 --> Loader Class Initialized
INFO - 2023-12-07 22:21:41 --> Helper loaded: url_helper
INFO - 2023-12-07 22:21:41 --> Helper loaded: file_helper
INFO - 2023-12-07 22:21:41 --> Helper loaded: form_helper
INFO - 2023-12-07 22:21:41 --> Helper loaded: my_helper
INFO - 2023-12-07 22:21:41 --> Database Driver Class Initialized
INFO - 2023-12-07 22:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:21:41 --> Controller Class Initialized
DEBUG - 2023-12-07 22:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_catatan_guru/views/list.php
DEBUG - 2023-12-07 22:21:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-12-07 22:21:41 --> Final output sent to browser
DEBUG - 2023-12-07 22:21:41 --> Total execution time: 0.0793
INFO - 2023-12-07 22:21:44 --> Config Class Initialized
INFO - 2023-12-07 22:21:44 --> Hooks Class Initialized
DEBUG - 2023-12-07 22:21:44 --> UTF-8 Support Enabled
INFO - 2023-12-07 22:21:44 --> Utf8 Class Initialized
INFO - 2023-12-07 22:21:44 --> URI Class Initialized
INFO - 2023-12-07 22:21:44 --> Router Class Initialized
INFO - 2023-12-07 22:21:44 --> Output Class Initialized
INFO - 2023-12-07 22:21:44 --> Security Class Initialized
DEBUG - 2023-12-07 22:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-12-07 22:21:44 --> Input Class Initialized
INFO - 2023-12-07 22:21:44 --> Language Class Initialized
INFO - 2023-12-07 22:21:44 --> Language Class Initialized
INFO - 2023-12-07 22:21:44 --> Config Class Initialized
INFO - 2023-12-07 22:21:44 --> Loader Class Initialized
INFO - 2023-12-07 22:21:44 --> Helper loaded: url_helper
INFO - 2023-12-07 22:21:44 --> Helper loaded: file_helper
INFO - 2023-12-07 22:21:44 --> Helper loaded: form_helper
INFO - 2023-12-07 22:21:44 --> Helper loaded: my_helper
INFO - 2023-12-07 22:21:44 --> Database Driver Class Initialized
INFO - 2023-12-07 22:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2023-12-07 22:21:44 --> Controller Class Initialized
INFO - 2023-12-07 22:21:44 --> Final output sent to browser
DEBUG - 2023-12-07 22:21:44 --> Total execution time: 0.0653
