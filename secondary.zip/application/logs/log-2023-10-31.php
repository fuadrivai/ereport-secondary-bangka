<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2023-10-31 08:38:23 --> Config Class Initialized
INFO - 2023-10-31 08:38:23 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:38:23 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:38:23 --> Utf8 Class Initialized
INFO - 2023-10-31 08:38:23 --> URI Class Initialized
INFO - 2023-10-31 08:38:23 --> Router Class Initialized
INFO - 2023-10-31 08:38:23 --> Output Class Initialized
INFO - 2023-10-31 08:38:23 --> Security Class Initialized
DEBUG - 2023-10-31 08:38:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:38:23 --> Input Class Initialized
INFO - 2023-10-31 08:38:23 --> Language Class Initialized
INFO - 2023-10-31 08:38:23 --> Language Class Initialized
INFO - 2023-10-31 08:38:23 --> Config Class Initialized
INFO - 2023-10-31 08:38:23 --> Loader Class Initialized
INFO - 2023-10-31 08:38:23 --> Helper loaded: url_helper
INFO - 2023-10-31 08:38:23 --> Helper loaded: file_helper
INFO - 2023-10-31 08:38:23 --> Helper loaded: form_helper
INFO - 2023-10-31 08:38:23 --> Helper loaded: my_helper
INFO - 2023-10-31 08:38:23 --> Database Driver Class Initialized
INFO - 2023-10-31 08:38:23 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:38:23 --> Controller Class Initialized
DEBUG - 2023-10-31 08:38:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_ekstra/views/list.php
DEBUG - 2023-10-31 08:38:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 08:38:23 --> Final output sent to browser
DEBUG - 2023-10-31 08:38:23 --> Total execution time: 0.1533
INFO - 2023-10-31 08:38:24 --> Config Class Initialized
INFO - 2023-10-31 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:38:24 --> Utf8 Class Initialized
INFO - 2023-10-31 08:38:24 --> URI Class Initialized
INFO - 2023-10-31 08:38:24 --> Router Class Initialized
INFO - 2023-10-31 08:38:24 --> Output Class Initialized
INFO - 2023-10-31 08:38:24 --> Security Class Initialized
DEBUG - 2023-10-31 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:38:24 --> Input Class Initialized
INFO - 2023-10-31 08:38:24 --> Language Class Initialized
ERROR - 2023-10-31 08:38:24 --> 404 Page Not Found: /index
INFO - 2023-10-31 08:38:24 --> Config Class Initialized
INFO - 2023-10-31 08:38:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:38:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:38:24 --> Utf8 Class Initialized
INFO - 2023-10-31 08:38:24 --> URI Class Initialized
INFO - 2023-10-31 08:38:24 --> Router Class Initialized
INFO - 2023-10-31 08:38:24 --> Output Class Initialized
INFO - 2023-10-31 08:38:24 --> Security Class Initialized
DEBUG - 2023-10-31 08:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:38:24 --> Input Class Initialized
INFO - 2023-10-31 08:38:24 --> Language Class Initialized
INFO - 2023-10-31 08:38:24 --> Language Class Initialized
INFO - 2023-10-31 08:38:24 --> Config Class Initialized
INFO - 2023-10-31 08:38:24 --> Loader Class Initialized
INFO - 2023-10-31 08:38:24 --> Helper loaded: url_helper
INFO - 2023-10-31 08:38:24 --> Helper loaded: file_helper
INFO - 2023-10-31 08:38:24 --> Helper loaded: form_helper
INFO - 2023-10-31 08:38:24 --> Helper loaded: my_helper
INFO - 2023-10-31 08:38:24 --> Database Driver Class Initialized
INFO - 2023-10-31 08:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:38:24 --> Controller Class Initialized
INFO - 2023-10-31 08:38:25 --> Config Class Initialized
INFO - 2023-10-31 08:38:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:38:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:38:25 --> Utf8 Class Initialized
INFO - 2023-10-31 08:38:25 --> URI Class Initialized
INFO - 2023-10-31 08:38:25 --> Router Class Initialized
INFO - 2023-10-31 08:38:25 --> Output Class Initialized
INFO - 2023-10-31 08:38:25 --> Security Class Initialized
DEBUG - 2023-10-31 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:38:25 --> Input Class Initialized
INFO - 2023-10-31 08:38:25 --> Language Class Initialized
INFO - 2023-10-31 08:38:25 --> Language Class Initialized
INFO - 2023-10-31 08:38:25 --> Config Class Initialized
INFO - 2023-10-31 08:38:25 --> Loader Class Initialized
INFO - 2023-10-31 08:38:25 --> Helper loaded: url_helper
INFO - 2023-10-31 08:38:25 --> Helper loaded: file_helper
INFO - 2023-10-31 08:38:25 --> Helper loaded: form_helper
INFO - 2023-10-31 08:38:25 --> Helper loaded: my_helper
INFO - 2023-10-31 08:38:25 --> Database Driver Class Initialized
INFO - 2023-10-31 08:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:38:25 --> Controller Class Initialized
DEBUG - 2023-10-31 08:38:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-31 08:38:31 --> Final output sent to browser
DEBUG - 2023-10-31 08:38:31 --> Total execution time: 5.9705
INFO - 2023-10-31 08:51:32 --> Config Class Initialized
INFO - 2023-10-31 08:51:32 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:51:32 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:51:32 --> Utf8 Class Initialized
INFO - 2023-10-31 08:51:32 --> URI Class Initialized
INFO - 2023-10-31 08:51:32 --> Router Class Initialized
INFO - 2023-10-31 08:51:32 --> Output Class Initialized
INFO - 2023-10-31 08:51:32 --> Security Class Initialized
DEBUG - 2023-10-31 08:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:51:32 --> Input Class Initialized
INFO - 2023-10-31 08:51:32 --> Language Class Initialized
INFO - 2023-10-31 08:51:32 --> Language Class Initialized
INFO - 2023-10-31 08:51:32 --> Config Class Initialized
INFO - 2023-10-31 08:51:32 --> Loader Class Initialized
INFO - 2023-10-31 08:51:32 --> Helper loaded: url_helper
INFO - 2023-10-31 08:51:32 --> Helper loaded: file_helper
INFO - 2023-10-31 08:51:32 --> Helper loaded: form_helper
INFO - 2023-10-31 08:51:32 --> Helper loaded: my_helper
INFO - 2023-10-31 08:51:32 --> Database Driver Class Initialized
INFO - 2023-10-31 08:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:51:32 --> Controller Class Initialized
DEBUG - 2023-10-31 08:51:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-31 08:51:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 08:51:32 --> Final output sent to browser
DEBUG - 2023-10-31 08:51:32 --> Total execution time: 0.1279
INFO - 2023-10-31 08:51:34 --> Config Class Initialized
INFO - 2023-10-31 08:51:34 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:51:34 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:51:34 --> Utf8 Class Initialized
INFO - 2023-10-31 08:51:34 --> URI Class Initialized
INFO - 2023-10-31 08:51:34 --> Router Class Initialized
INFO - 2023-10-31 08:51:34 --> Output Class Initialized
INFO - 2023-10-31 08:51:34 --> Security Class Initialized
DEBUG - 2023-10-31 08:51:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:51:34 --> Input Class Initialized
INFO - 2023-10-31 08:51:34 --> Language Class Initialized
INFO - 2023-10-31 08:51:34 --> Language Class Initialized
INFO - 2023-10-31 08:51:34 --> Config Class Initialized
INFO - 2023-10-31 08:51:34 --> Loader Class Initialized
INFO - 2023-10-31 08:51:34 --> Helper loaded: url_helper
INFO - 2023-10-31 08:51:34 --> Helper loaded: file_helper
INFO - 2023-10-31 08:51:34 --> Helper loaded: form_helper
INFO - 2023-10-31 08:51:34 --> Helper loaded: my_helper
INFO - 2023-10-31 08:51:34 --> Database Driver Class Initialized
INFO - 2023-10-31 08:51:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:51:34 --> Controller Class Initialized
INFO - 2023-10-31 08:51:34 --> Helper loaded: cookie_helper
INFO - 2023-10-31 08:51:34 --> Final output sent to browser
DEBUG - 2023-10-31 08:51:34 --> Total execution time: 0.1325
INFO - 2023-10-31 08:51:35 --> Config Class Initialized
INFO - 2023-10-31 08:51:35 --> Hooks Class Initialized
DEBUG - 2023-10-31 08:51:35 --> UTF-8 Support Enabled
INFO - 2023-10-31 08:51:35 --> Utf8 Class Initialized
INFO - 2023-10-31 08:51:35 --> URI Class Initialized
INFO - 2023-10-31 08:51:35 --> Router Class Initialized
INFO - 2023-10-31 08:51:35 --> Output Class Initialized
INFO - 2023-10-31 08:51:35 --> Security Class Initialized
DEBUG - 2023-10-31 08:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 08:51:35 --> Input Class Initialized
INFO - 2023-10-31 08:51:35 --> Language Class Initialized
INFO - 2023-10-31 08:51:35 --> Language Class Initialized
INFO - 2023-10-31 08:51:35 --> Config Class Initialized
INFO - 2023-10-31 08:51:35 --> Loader Class Initialized
INFO - 2023-10-31 08:51:35 --> Helper loaded: url_helper
INFO - 2023-10-31 08:51:35 --> Helper loaded: file_helper
INFO - 2023-10-31 08:51:35 --> Helper loaded: form_helper
INFO - 2023-10-31 08:51:35 --> Helper loaded: my_helper
INFO - 2023-10-31 08:51:35 --> Database Driver Class Initialized
INFO - 2023-10-31 08:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 08:51:35 --> Controller Class Initialized
DEBUG - 2023-10-31 08:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-10-31 08:51:35 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 08:51:35 --> Final output sent to browser
DEBUG - 2023-10-31 08:51:35 --> Total execution time: 0.0908
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:16:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:16:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:16:40 --> URI Class Initialized
INFO - 2023-10-31 09:16:40 --> Router Class Initialized
INFO - 2023-10-31 09:16:40 --> Output Class Initialized
INFO - 2023-10-31 09:16:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:16:40 --> Input Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Loader Class Initialized
INFO - 2023-10-31 09:16:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: my_helper
INFO - 2023-10-31 09:16:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:16:40 --> Controller Class Initialized
INFO - 2023-10-31 09:16:40 --> Helper loaded: cookie_helper
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:16:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:16:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:16:40 --> URI Class Initialized
INFO - 2023-10-31 09:16:40 --> Router Class Initialized
INFO - 2023-10-31 09:16:40 --> Output Class Initialized
INFO - 2023-10-31 09:16:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:16:40 --> Input Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Loader Class Initialized
INFO - 2023-10-31 09:16:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: my_helper
INFO - 2023-10-31 09:16:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:16:40 --> Controller Class Initialized
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Hooks Class Initialized
DEBUG - 2023-10-31 09:16:40 --> UTF-8 Support Enabled
INFO - 2023-10-31 09:16:40 --> Utf8 Class Initialized
INFO - 2023-10-31 09:16:40 --> URI Class Initialized
INFO - 2023-10-31 09:16:40 --> Router Class Initialized
INFO - 2023-10-31 09:16:40 --> Output Class Initialized
INFO - 2023-10-31 09:16:40 --> Security Class Initialized
DEBUG - 2023-10-31 09:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 09:16:40 --> Input Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Language Class Initialized
INFO - 2023-10-31 09:16:40 --> Config Class Initialized
INFO - 2023-10-31 09:16:40 --> Loader Class Initialized
INFO - 2023-10-31 09:16:40 --> Helper loaded: url_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: file_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: form_helper
INFO - 2023-10-31 09:16:40 --> Helper loaded: my_helper
INFO - 2023-10-31 09:16:40 --> Database Driver Class Initialized
INFO - 2023-10-31 09:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 09:16:40 --> Controller Class Initialized
DEBUG - 2023-10-31 09:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-31 09:16:40 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 09:16:40 --> Final output sent to browser
DEBUG - 2023-10-31 09:16:40 --> Total execution time: 0.0360
INFO - 2023-10-31 15:08:41 --> Config Class Initialized
INFO - 2023-10-31 15:08:41 --> Hooks Class Initialized
DEBUG - 2023-10-31 15:08:41 --> UTF-8 Support Enabled
INFO - 2023-10-31 15:08:41 --> Utf8 Class Initialized
INFO - 2023-10-31 15:08:41 --> URI Class Initialized
INFO - 2023-10-31 15:08:41 --> Router Class Initialized
INFO - 2023-10-31 15:08:41 --> Output Class Initialized
INFO - 2023-10-31 15:08:41 --> Security Class Initialized
DEBUG - 2023-10-31 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 15:08:41 --> Input Class Initialized
INFO - 2023-10-31 15:08:41 --> Language Class Initialized
INFO - 2023-10-31 15:08:41 --> Language Class Initialized
INFO - 2023-10-31 15:08:41 --> Config Class Initialized
INFO - 2023-10-31 15:08:41 --> Loader Class Initialized
INFO - 2023-10-31 15:08:41 --> Helper loaded: url_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: file_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: form_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: my_helper
INFO - 2023-10-31 15:08:41 --> Database Driver Class Initialized
INFO - 2023-10-31 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 15:08:41 --> Controller Class Initialized
INFO - 2023-10-31 15:08:41 --> Helper loaded: cookie_helper
INFO - 2023-10-31 15:08:41 --> Final output sent to browser
DEBUG - 2023-10-31 15:08:41 --> Total execution time: 0.1662
INFO - 2023-10-31 15:08:41 --> Config Class Initialized
INFO - 2023-10-31 15:08:41 --> Hooks Class Initialized
DEBUG - 2023-10-31 15:08:41 --> UTF-8 Support Enabled
INFO - 2023-10-31 15:08:41 --> Utf8 Class Initialized
INFO - 2023-10-31 15:08:41 --> URI Class Initialized
INFO - 2023-10-31 15:08:41 --> Router Class Initialized
INFO - 2023-10-31 15:08:41 --> Output Class Initialized
INFO - 2023-10-31 15:08:41 --> Security Class Initialized
DEBUG - 2023-10-31 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 15:08:41 --> Input Class Initialized
INFO - 2023-10-31 15:08:41 --> Language Class Initialized
INFO - 2023-10-31 15:08:41 --> Language Class Initialized
INFO - 2023-10-31 15:08:41 --> Config Class Initialized
INFO - 2023-10-31 15:08:41 --> Loader Class Initialized
INFO - 2023-10-31 15:08:41 --> Helper loaded: url_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: file_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: form_helper
INFO - 2023-10-31 15:08:41 --> Helper loaded: my_helper
INFO - 2023-10-31 15:08:41 --> Database Driver Class Initialized
INFO - 2023-10-31 15:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 15:08:41 --> Controller Class Initialized
DEBUG - 2023-10-31 15:08:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home_guru.php
DEBUG - 2023-10-31 15:08:41 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 15:08:41 --> Final output sent to browser
DEBUG - 2023-10-31 15:08:41 --> Total execution time: 0.0488
INFO - 2023-10-31 15:09:24 --> Config Class Initialized
INFO - 2023-10-31 15:09:24 --> Hooks Class Initialized
DEBUG - 2023-10-31 15:09:24 --> UTF-8 Support Enabled
INFO - 2023-10-31 15:09:24 --> Utf8 Class Initialized
INFO - 2023-10-31 15:09:24 --> URI Class Initialized
INFO - 2023-10-31 15:09:24 --> Router Class Initialized
INFO - 2023-10-31 15:09:24 --> Output Class Initialized
INFO - 2023-10-31 15:09:24 --> Security Class Initialized
DEBUG - 2023-10-31 15:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 15:09:24 --> Input Class Initialized
INFO - 2023-10-31 15:09:24 --> Language Class Initialized
INFO - 2023-10-31 15:09:24 --> Language Class Initialized
INFO - 2023-10-31 15:09:24 --> Config Class Initialized
INFO - 2023-10-31 15:09:24 --> Loader Class Initialized
INFO - 2023-10-31 15:09:24 --> Helper loaded: url_helper
INFO - 2023-10-31 15:09:24 --> Helper loaded: file_helper
INFO - 2023-10-31 15:09:24 --> Helper loaded: form_helper
INFO - 2023-10-31 15:09:24 --> Helper loaded: my_helper
INFO - 2023-10-31 15:09:24 --> Database Driver Class Initialized
INFO - 2023-10-31 15:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 15:09:24 --> Controller Class Initialized
DEBUG - 2023-10-31 15:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-31 15:09:24 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 15:09:24 --> Final output sent to browser
DEBUG - 2023-10-31 15:09:24 --> Total execution time: 0.0627
INFO - 2023-10-31 15:09:26 --> Config Class Initialized
INFO - 2023-10-31 15:09:26 --> Hooks Class Initialized
DEBUG - 2023-10-31 15:09:26 --> UTF-8 Support Enabled
INFO - 2023-10-31 15:09:26 --> Utf8 Class Initialized
INFO - 2023-10-31 15:09:26 --> URI Class Initialized
INFO - 2023-10-31 15:09:26 --> Router Class Initialized
INFO - 2023-10-31 15:09:26 --> Output Class Initialized
INFO - 2023-10-31 15:09:26 --> Security Class Initialized
DEBUG - 2023-10-31 15:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 15:09:26 --> Input Class Initialized
INFO - 2023-10-31 15:09:26 --> Language Class Initialized
INFO - 2023-10-31 15:09:26 --> Language Class Initialized
INFO - 2023-10-31 15:09:26 --> Config Class Initialized
INFO - 2023-10-31 15:09:26 --> Loader Class Initialized
INFO - 2023-10-31 15:09:26 --> Helper loaded: url_helper
INFO - 2023-10-31 15:09:26 --> Helper loaded: file_helper
INFO - 2023-10-31 15:09:26 --> Helper loaded: form_helper
INFO - 2023-10-31 15:09:26 --> Helper loaded: my_helper
INFO - 2023-10-31 15:09:27 --> Database Driver Class Initialized
INFO - 2023-10-31 15:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 15:09:27 --> Controller Class Initialized
DEBUG - 2023-10-31 15:09:27 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-31 15:09:31 --> Final output sent to browser
DEBUG - 2023-10-31 15:09:31 --> Total execution time: 4.7571
INFO - 2023-10-31 15:21:58 --> Config Class Initialized
INFO - 2023-10-31 15:21:58 --> Hooks Class Initialized
DEBUG - 2023-10-31 15:21:58 --> UTF-8 Support Enabled
INFO - 2023-10-31 15:21:58 --> Utf8 Class Initialized
INFO - 2023-10-31 15:21:58 --> URI Class Initialized
INFO - 2023-10-31 15:21:58 --> Router Class Initialized
INFO - 2023-10-31 15:21:58 --> Output Class Initialized
INFO - 2023-10-31 15:21:58 --> Security Class Initialized
DEBUG - 2023-10-31 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 15:21:58 --> Input Class Initialized
INFO - 2023-10-31 15:21:58 --> Language Class Initialized
INFO - 2023-10-31 15:21:58 --> Language Class Initialized
INFO - 2023-10-31 15:21:58 --> Config Class Initialized
INFO - 2023-10-31 15:21:58 --> Loader Class Initialized
INFO - 2023-10-31 15:21:58 --> Helper loaded: url_helper
INFO - 2023-10-31 15:21:58 --> Helper loaded: file_helper
INFO - 2023-10-31 15:21:58 --> Helper loaded: form_helper
INFO - 2023-10-31 15:21:58 --> Helper loaded: my_helper
INFO - 2023-10-31 15:21:58 --> Database Driver Class Initialized
INFO - 2023-10-31 15:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 15:21:58 --> Controller Class Initialized
DEBUG - 2023-10-31 15:21:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-31 15:22:04 --> Final output sent to browser
DEBUG - 2023-10-31 15:22:04 --> Total execution time: 6.2097
INFO - 2023-10-31 16:45:25 --> Config Class Initialized
INFO - 2023-10-31 16:45:25 --> Hooks Class Initialized
DEBUG - 2023-10-31 16:45:25 --> UTF-8 Support Enabled
INFO - 2023-10-31 16:45:25 --> Utf8 Class Initialized
INFO - 2023-10-31 16:45:25 --> URI Class Initialized
INFO - 2023-10-31 16:45:25 --> Router Class Initialized
INFO - 2023-10-31 16:45:25 --> Output Class Initialized
INFO - 2023-10-31 16:45:25 --> Security Class Initialized
DEBUG - 2023-10-31 16:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 16:45:25 --> Input Class Initialized
INFO - 2023-10-31 16:45:25 --> Language Class Initialized
INFO - 2023-10-31 16:45:25 --> Language Class Initialized
INFO - 2023-10-31 16:45:25 --> Config Class Initialized
INFO - 2023-10-31 16:45:25 --> Loader Class Initialized
INFO - 2023-10-31 16:45:25 --> Helper loaded: url_helper
INFO - 2023-10-31 16:45:25 --> Helper loaded: file_helper
INFO - 2023-10-31 16:45:25 --> Helper loaded: form_helper
INFO - 2023-10-31 16:45:25 --> Helper loaded: my_helper
INFO - 2023-10-31 16:45:25 --> Database Driver Class Initialized
INFO - 2023-10-31 16:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 16:45:25 --> Controller Class Initialized
DEBUG - 2023-10-31 16:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-31 16:45:25 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 16:45:25 --> Final output sent to browser
DEBUG - 2023-10-31 16:45:25 --> Total execution time: 0.0887
INFO - 2023-10-31 16:45:28 --> Config Class Initialized
INFO - 2023-10-31 16:45:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 16:45:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 16:45:28 --> Utf8 Class Initialized
INFO - 2023-10-31 16:45:28 --> URI Class Initialized
INFO - 2023-10-31 16:45:28 --> Router Class Initialized
INFO - 2023-10-31 16:45:28 --> Output Class Initialized
INFO - 2023-10-31 16:45:28 --> Security Class Initialized
DEBUG - 2023-10-31 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 16:45:28 --> Input Class Initialized
INFO - 2023-10-31 16:45:28 --> Language Class Initialized
INFO - 2023-10-31 16:45:28 --> Language Class Initialized
INFO - 2023-10-31 16:45:28 --> Config Class Initialized
INFO - 2023-10-31 16:45:28 --> Loader Class Initialized
INFO - 2023-10-31 16:45:28 --> Helper loaded: url_helper
INFO - 2023-10-31 16:45:28 --> Helper loaded: file_helper
INFO - 2023-10-31 16:45:28 --> Helper loaded: form_helper
INFO - 2023-10-31 16:45:28 --> Helper loaded: my_helper
INFO - 2023-10-31 16:45:28 --> Database Driver Class Initialized
INFO - 2023-10-31 16:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 16:45:28 --> Controller Class Initialized
DEBUG - 2023-10-31 16:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/n_absensi/views/list.php
DEBUG - 2023-10-31 16:45:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 16:45:28 --> Final output sent to browser
DEBUG - 2023-10-31 16:45:28 --> Total execution time: 0.0459
INFO - 2023-10-31 16:45:31 --> Config Class Initialized
INFO - 2023-10-31 16:45:31 --> Hooks Class Initialized
DEBUG - 2023-10-31 16:45:31 --> UTF-8 Support Enabled
INFO - 2023-10-31 16:45:31 --> Utf8 Class Initialized
INFO - 2023-10-31 16:45:31 --> URI Class Initialized
INFO - 2023-10-31 16:45:31 --> Router Class Initialized
INFO - 2023-10-31 16:45:31 --> Output Class Initialized
INFO - 2023-10-31 16:45:31 --> Security Class Initialized
DEBUG - 2023-10-31 16:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 16:45:31 --> Input Class Initialized
INFO - 2023-10-31 16:45:31 --> Language Class Initialized
INFO - 2023-10-31 16:45:31 --> Language Class Initialized
INFO - 2023-10-31 16:45:31 --> Config Class Initialized
INFO - 2023-10-31 16:45:31 --> Loader Class Initialized
INFO - 2023-10-31 16:45:31 --> Helper loaded: url_helper
INFO - 2023-10-31 16:45:31 --> Helper loaded: file_helper
INFO - 2023-10-31 16:45:31 --> Helper loaded: form_helper
INFO - 2023-10-31 16:45:31 --> Helper loaded: my_helper
INFO - 2023-10-31 16:45:31 --> Database Driver Class Initialized
INFO - 2023-10-31 16:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 16:45:31 --> Controller Class Initialized
DEBUG - 2023-10-31 16:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/list.php
DEBUG - 2023-10-31 16:45:31 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 16:45:31 --> Final output sent to browser
DEBUG - 2023-10-31 16:45:31 --> Total execution time: 0.0770
INFO - 2023-10-31 16:45:33 --> Config Class Initialized
INFO - 2023-10-31 16:45:33 --> Hooks Class Initialized
DEBUG - 2023-10-31 16:45:33 --> UTF-8 Support Enabled
INFO - 2023-10-31 16:45:33 --> Utf8 Class Initialized
INFO - 2023-10-31 16:45:33 --> URI Class Initialized
INFO - 2023-10-31 16:45:33 --> Router Class Initialized
INFO - 2023-10-31 16:45:33 --> Output Class Initialized
INFO - 2023-10-31 16:45:33 --> Security Class Initialized
DEBUG - 2023-10-31 16:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 16:45:33 --> Input Class Initialized
INFO - 2023-10-31 16:45:33 --> Language Class Initialized
INFO - 2023-10-31 16:45:33 --> Language Class Initialized
INFO - 2023-10-31 16:45:33 --> Config Class Initialized
INFO - 2023-10-31 16:45:33 --> Loader Class Initialized
INFO - 2023-10-31 16:45:33 --> Helper loaded: url_helper
INFO - 2023-10-31 16:45:33 --> Helper loaded: file_helper
INFO - 2023-10-31 16:45:33 --> Helper loaded: form_helper
INFO - 2023-10-31 16:45:33 --> Helper loaded: my_helper
INFO - 2023-10-31 16:45:33 --> Database Driver Class Initialized
INFO - 2023-10-31 16:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 16:45:33 --> Controller Class Initialized
DEBUG - 2023-10-31 16:45:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2023-10-31 16:45:38 --> Final output sent to browser
DEBUG - 2023-10-31 16:45:38 --> Total execution time: 4.8773
INFO - 2023-10-31 17:51:43 --> Config Class Initialized
INFO - 2023-10-31 17:51:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:51:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:51:43 --> Utf8 Class Initialized
INFO - 2023-10-31 17:51:43 --> URI Class Initialized
DEBUG - 2023-10-31 17:51:43 --> No URI present. Default controller set.
INFO - 2023-10-31 17:51:43 --> Router Class Initialized
INFO - 2023-10-31 17:51:43 --> Output Class Initialized
INFO - 2023-10-31 17:51:43 --> Security Class Initialized
DEBUG - 2023-10-31 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:51:43 --> Input Class Initialized
INFO - 2023-10-31 17:51:43 --> Language Class Initialized
INFO - 2023-10-31 17:51:43 --> Language Class Initialized
INFO - 2023-10-31 17:51:43 --> Config Class Initialized
INFO - 2023-10-31 17:51:43 --> Loader Class Initialized
INFO - 2023-10-31 17:51:43 --> Helper loaded: url_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: file_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: form_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: my_helper
INFO - 2023-10-31 17:51:43 --> Database Driver Class Initialized
INFO - 2023-10-31 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:51:43 --> Controller Class Initialized
INFO - 2023-10-31 17:51:43 --> Config Class Initialized
INFO - 2023-10-31 17:51:43 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:51:43 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:51:43 --> Utf8 Class Initialized
INFO - 2023-10-31 17:51:43 --> URI Class Initialized
INFO - 2023-10-31 17:51:43 --> Router Class Initialized
INFO - 2023-10-31 17:51:43 --> Output Class Initialized
INFO - 2023-10-31 17:51:43 --> Security Class Initialized
DEBUG - 2023-10-31 17:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:51:43 --> Input Class Initialized
INFO - 2023-10-31 17:51:43 --> Language Class Initialized
INFO - 2023-10-31 17:51:43 --> Language Class Initialized
INFO - 2023-10-31 17:51:43 --> Config Class Initialized
INFO - 2023-10-31 17:51:43 --> Loader Class Initialized
INFO - 2023-10-31 17:51:43 --> Helper loaded: url_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: file_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: form_helper
INFO - 2023-10-31 17:51:43 --> Helper loaded: my_helper
INFO - 2023-10-31 17:51:43 --> Database Driver Class Initialized
INFO - 2023-10-31 17:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:51:43 --> Controller Class Initialized
DEBUG - 2023-10-31 17:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2023-10-31 17:51:43 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 17:51:43 --> Final output sent to browser
DEBUG - 2023-10-31 17:51:43 --> Total execution time: 0.0434
INFO - 2023-10-31 17:55:28 --> Config Class Initialized
INFO - 2023-10-31 17:55:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:55:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:55:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:55:28 --> URI Class Initialized
INFO - 2023-10-31 17:55:28 --> Router Class Initialized
INFO - 2023-10-31 17:55:28 --> Output Class Initialized
INFO - 2023-10-31 17:55:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:55:28 --> Input Class Initialized
INFO - 2023-10-31 17:55:28 --> Language Class Initialized
INFO - 2023-10-31 17:55:28 --> Language Class Initialized
INFO - 2023-10-31 17:55:28 --> Config Class Initialized
INFO - 2023-10-31 17:55:28 --> Loader Class Initialized
INFO - 2023-10-31 17:55:28 --> Helper loaded: url_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: file_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: form_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: my_helper
INFO - 2023-10-31 17:55:28 --> Database Driver Class Initialized
INFO - 2023-10-31 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:55:28 --> Controller Class Initialized
INFO - 2023-10-31 17:55:28 --> Helper loaded: cookie_helper
INFO - 2023-10-31 17:55:28 --> Final output sent to browser
DEBUG - 2023-10-31 17:55:28 --> Total execution time: 0.0529
INFO - 2023-10-31 17:55:28 --> Config Class Initialized
INFO - 2023-10-31 17:55:28 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:55:28 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:55:28 --> Utf8 Class Initialized
INFO - 2023-10-31 17:55:28 --> URI Class Initialized
INFO - 2023-10-31 17:55:28 --> Router Class Initialized
INFO - 2023-10-31 17:55:28 --> Output Class Initialized
INFO - 2023-10-31 17:55:28 --> Security Class Initialized
DEBUG - 2023-10-31 17:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:55:28 --> Input Class Initialized
INFO - 2023-10-31 17:55:28 --> Language Class Initialized
INFO - 2023-10-31 17:55:28 --> Language Class Initialized
INFO - 2023-10-31 17:55:28 --> Config Class Initialized
INFO - 2023-10-31 17:55:28 --> Loader Class Initialized
INFO - 2023-10-31 17:55:28 --> Helper loaded: url_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: file_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: form_helper
INFO - 2023-10-31 17:55:28 --> Helper loaded: my_helper
INFO - 2023-10-31 17:55:28 --> Database Driver Class Initialized
INFO - 2023-10-31 17:55:28 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:55:28 --> Controller Class Initialized
DEBUG - 2023-10-31 17:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/home/views/v_home.php
DEBUG - 2023-10-31 17:55:28 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 17:55:28 --> Final output sent to browser
DEBUG - 2023-10-31 17:55:28 --> Total execution time: 0.0487
INFO - 2023-10-31 17:55:34 --> Config Class Initialized
INFO - 2023-10-31 17:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:55:34 --> Utf8 Class Initialized
INFO - 2023-10-31 17:55:34 --> URI Class Initialized
INFO - 2023-10-31 17:55:34 --> Router Class Initialized
INFO - 2023-10-31 17:55:34 --> Output Class Initialized
INFO - 2023-10-31 17:55:34 --> Security Class Initialized
DEBUG - 2023-10-31 17:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:55:34 --> Input Class Initialized
INFO - 2023-10-31 17:55:34 --> Language Class Initialized
INFO - 2023-10-31 17:55:34 --> Language Class Initialized
INFO - 2023-10-31 17:55:34 --> Config Class Initialized
INFO - 2023-10-31 17:55:34 --> Loader Class Initialized
INFO - 2023-10-31 17:55:34 --> Helper loaded: url_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: file_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: form_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: my_helper
INFO - 2023-10-31 17:55:34 --> Database Driver Class Initialized
INFO - 2023-10-31 17:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:55:34 --> Controller Class Initialized
DEBUG - 2023-10-31 17:55:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/data_siswa/views/list.php
DEBUG - 2023-10-31 17:55:34 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2023-10-31 17:55:34 --> Final output sent to browser
DEBUG - 2023-10-31 17:55:34 --> Total execution time: 0.0463
INFO - 2023-10-31 17:55:34 --> Config Class Initialized
INFO - 2023-10-31 17:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:55:34 --> Utf8 Class Initialized
INFO - 2023-10-31 17:55:34 --> URI Class Initialized
INFO - 2023-10-31 17:55:34 --> Router Class Initialized
INFO - 2023-10-31 17:55:34 --> Output Class Initialized
INFO - 2023-10-31 17:55:34 --> Security Class Initialized
DEBUG - 2023-10-31 17:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:55:34 --> Input Class Initialized
INFO - 2023-10-31 17:55:34 --> Language Class Initialized
ERROR - 2023-10-31 17:55:34 --> 404 Page Not Found: /index
INFO - 2023-10-31 17:55:34 --> Config Class Initialized
INFO - 2023-10-31 17:55:34 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:55:34 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:55:34 --> Utf8 Class Initialized
INFO - 2023-10-31 17:55:34 --> URI Class Initialized
INFO - 2023-10-31 17:55:34 --> Router Class Initialized
INFO - 2023-10-31 17:55:34 --> Output Class Initialized
INFO - 2023-10-31 17:55:34 --> Security Class Initialized
DEBUG - 2023-10-31 17:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:55:34 --> Input Class Initialized
INFO - 2023-10-31 17:55:34 --> Language Class Initialized
INFO - 2023-10-31 17:55:34 --> Language Class Initialized
INFO - 2023-10-31 17:55:34 --> Config Class Initialized
INFO - 2023-10-31 17:55:34 --> Loader Class Initialized
INFO - 2023-10-31 17:55:34 --> Helper loaded: url_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: file_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: form_helper
INFO - 2023-10-31 17:55:34 --> Helper loaded: my_helper
INFO - 2023-10-31 17:55:34 --> Database Driver Class Initialized
INFO - 2023-10-31 17:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:55:34 --> Controller Class Initialized
INFO - 2023-10-31 17:57:10 --> Config Class Initialized
INFO - 2023-10-31 17:57:10 --> Hooks Class Initialized
DEBUG - 2023-10-31 17:57:10 --> UTF-8 Support Enabled
INFO - 2023-10-31 17:57:10 --> Utf8 Class Initialized
INFO - 2023-10-31 17:57:10 --> URI Class Initialized
INFO - 2023-10-31 17:57:10 --> Router Class Initialized
INFO - 2023-10-31 17:57:10 --> Output Class Initialized
INFO - 2023-10-31 17:57:10 --> Security Class Initialized
DEBUG - 2023-10-31 17:57:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2023-10-31 17:57:10 --> Input Class Initialized
INFO - 2023-10-31 17:57:10 --> Language Class Initialized
INFO - 2023-10-31 17:57:10 --> Language Class Initialized
INFO - 2023-10-31 17:57:10 --> Config Class Initialized
INFO - 2023-10-31 17:57:10 --> Loader Class Initialized
INFO - 2023-10-31 17:57:10 --> Helper loaded: url_helper
INFO - 2023-10-31 17:57:10 --> Helper loaded: file_helper
INFO - 2023-10-31 17:57:10 --> Helper loaded: form_helper
INFO - 2023-10-31 17:57:10 --> Helper loaded: my_helper
INFO - 2023-10-31 17:57:10 --> Database Driver Class Initialized
INFO - 2023-10-31 17:57:10 --> Session: Class initialized using 'files' driver.
INFO - 2023-10-31 17:57:10 --> Controller Class Initialized
