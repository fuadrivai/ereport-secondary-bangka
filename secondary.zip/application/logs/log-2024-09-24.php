<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-24 08:03:36 --> Config Class Initialized
INFO - 2024-09-24 08:03:36 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:03:36 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:03:36 --> Utf8 Class Initialized
INFO - 2024-09-24 08:03:36 --> URI Class Initialized
INFO - 2024-09-24 08:03:36 --> Router Class Initialized
INFO - 2024-09-24 08:03:36 --> Output Class Initialized
INFO - 2024-09-24 08:03:36 --> Security Class Initialized
DEBUG - 2024-09-24 08:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:03:36 --> Input Class Initialized
INFO - 2024-09-24 08:03:36 --> Language Class Initialized
INFO - 2024-09-24 08:03:36 --> Language Class Initialized
INFO - 2024-09-24 08:03:36 --> Config Class Initialized
INFO - 2024-09-24 08:03:36 --> Loader Class Initialized
INFO - 2024-09-24 08:03:36 --> Helper loaded: url_helper
INFO - 2024-09-24 08:03:36 --> Helper loaded: file_helper
INFO - 2024-09-24 08:03:36 --> Helper loaded: form_helper
INFO - 2024-09-24 08:03:36 --> Helper loaded: my_helper
INFO - 2024-09-24 08:03:36 --> Database Driver Class Initialized
INFO - 2024-09-24 08:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:03:36 --> Controller Class Initialized
INFO - 2024-09-24 08:03:36 --> Final output sent to browser
DEBUG - 2024-09-24 08:03:36 --> Total execution time: 0.0859
INFO - 2024-09-24 08:04:36 --> Config Class Initialized
INFO - 2024-09-24 08:04:36 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:04:36 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:04:36 --> Utf8 Class Initialized
INFO - 2024-09-24 08:04:36 --> URI Class Initialized
INFO - 2024-09-24 08:04:36 --> Router Class Initialized
INFO - 2024-09-24 08:04:36 --> Output Class Initialized
INFO - 2024-09-24 08:04:36 --> Security Class Initialized
DEBUG - 2024-09-24 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:04:36 --> Input Class Initialized
INFO - 2024-09-24 08:04:36 --> Language Class Initialized
INFO - 2024-09-24 08:04:36 --> Language Class Initialized
INFO - 2024-09-24 08:04:36 --> Config Class Initialized
INFO - 2024-09-24 08:04:36 --> Loader Class Initialized
INFO - 2024-09-24 08:04:36 --> Helper loaded: url_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: file_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: form_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: my_helper
INFO - 2024-09-24 08:04:36 --> Database Driver Class Initialized
INFO - 2024-09-24 08:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:04:36 --> Controller Class Initialized
INFO - 2024-09-24 08:04:36 --> Helper loaded: cookie_helper
INFO - 2024-09-24 08:04:36 --> Final output sent to browser
DEBUG - 2024-09-24 08:04:36 --> Total execution time: 0.0669
INFO - 2024-09-24 08:04:36 --> Config Class Initialized
INFO - 2024-09-24 08:04:36 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:04:36 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:04:36 --> Utf8 Class Initialized
INFO - 2024-09-24 08:04:36 --> URI Class Initialized
INFO - 2024-09-24 08:04:36 --> Router Class Initialized
INFO - 2024-09-24 08:04:36 --> Output Class Initialized
INFO - 2024-09-24 08:04:36 --> Security Class Initialized
DEBUG - 2024-09-24 08:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:04:36 --> Input Class Initialized
INFO - 2024-09-24 08:04:36 --> Language Class Initialized
INFO - 2024-09-24 08:04:36 --> Language Class Initialized
INFO - 2024-09-24 08:04:36 --> Config Class Initialized
INFO - 2024-09-24 08:04:36 --> Loader Class Initialized
INFO - 2024-09-24 08:04:36 --> Helper loaded: url_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: file_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: form_helper
INFO - 2024-09-24 08:04:36 --> Helper loaded: my_helper
INFO - 2024-09-24 08:04:36 --> Database Driver Class Initialized
INFO - 2024-09-24 08:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:04:36 --> Controller Class Initialized
INFO - 2024-09-24 08:04:36 --> Helper loaded: cookie_helper
INFO - 2024-09-24 08:04:37 --> Config Class Initialized
INFO - 2024-09-24 08:04:37 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:04:37 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:04:37 --> Utf8 Class Initialized
INFO - 2024-09-24 08:04:37 --> URI Class Initialized
INFO - 2024-09-24 08:04:37 --> Router Class Initialized
INFO - 2024-09-24 08:04:37 --> Output Class Initialized
INFO - 2024-09-24 08:04:37 --> Security Class Initialized
DEBUG - 2024-09-24 08:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:04:37 --> Input Class Initialized
INFO - 2024-09-24 08:04:37 --> Language Class Initialized
INFO - 2024-09-24 08:04:37 --> Language Class Initialized
INFO - 2024-09-24 08:04:37 --> Config Class Initialized
INFO - 2024-09-24 08:04:37 --> Loader Class Initialized
INFO - 2024-09-24 08:04:37 --> Helper loaded: url_helper
INFO - 2024-09-24 08:04:37 --> Helper loaded: file_helper
INFO - 2024-09-24 08:04:37 --> Helper loaded: form_helper
INFO - 2024-09-24 08:04:37 --> Helper loaded: my_helper
INFO - 2024-09-24 08:04:37 --> Database Driver Class Initialized
INFO - 2024-09-24 08:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:04:37 --> Controller Class Initialized
DEBUG - 2024-09-24 08:04:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-24 08:04:37 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-24 08:04:37 --> Final output sent to browser
DEBUG - 2024-09-24 08:04:37 --> Total execution time: 0.0417
INFO - 2024-09-24 08:04:46 --> Config Class Initialized
INFO - 2024-09-24 08:04:46 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:04:46 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:04:46 --> Utf8 Class Initialized
INFO - 2024-09-24 08:04:46 --> URI Class Initialized
INFO - 2024-09-24 08:04:46 --> Router Class Initialized
INFO - 2024-09-24 08:04:46 --> Output Class Initialized
INFO - 2024-09-24 08:04:46 --> Security Class Initialized
DEBUG - 2024-09-24 08:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:04:46 --> Input Class Initialized
INFO - 2024-09-24 08:04:46 --> Language Class Initialized
INFO - 2024-09-24 08:04:46 --> Language Class Initialized
INFO - 2024-09-24 08:04:46 --> Config Class Initialized
INFO - 2024-09-24 08:04:46 --> Loader Class Initialized
INFO - 2024-09-24 08:04:46 --> Helper loaded: url_helper
INFO - 2024-09-24 08:04:46 --> Helper loaded: file_helper
INFO - 2024-09-24 08:04:46 --> Helper loaded: form_helper
INFO - 2024-09-24 08:04:46 --> Helper loaded: my_helper
INFO - 2024-09-24 08:04:46 --> Database Driver Class Initialized
INFO - 2024-09-24 08:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:04:46 --> Controller Class Initialized
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-24 08:04:46 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-24 08:04:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-24 08:04:48 --> Final output sent to browser
DEBUG - 2024-09-24 08:04:48 --> Total execution time: 2.6046
INFO - 2024-09-24 08:05:03 --> Config Class Initialized
INFO - 2024-09-24 08:05:03 --> Hooks Class Initialized
DEBUG - 2024-09-24 08:05:03 --> UTF-8 Support Enabled
INFO - 2024-09-24 08:05:03 --> Utf8 Class Initialized
INFO - 2024-09-24 08:05:03 --> URI Class Initialized
INFO - 2024-09-24 08:05:03 --> Router Class Initialized
INFO - 2024-09-24 08:05:03 --> Output Class Initialized
INFO - 2024-09-24 08:05:03 --> Security Class Initialized
DEBUG - 2024-09-24 08:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 08:05:03 --> Input Class Initialized
INFO - 2024-09-24 08:05:03 --> Language Class Initialized
INFO - 2024-09-24 08:05:03 --> Language Class Initialized
INFO - 2024-09-24 08:05:03 --> Config Class Initialized
INFO - 2024-09-24 08:05:03 --> Loader Class Initialized
INFO - 2024-09-24 08:05:03 --> Helper loaded: url_helper
INFO - 2024-09-24 08:05:03 --> Helper loaded: file_helper
INFO - 2024-09-24 08:05:03 --> Helper loaded: form_helper
INFO - 2024-09-24 08:05:03 --> Helper loaded: my_helper
INFO - 2024-09-24 08:05:03 --> Database Driver Class Initialized
INFO - 2024-09-24 08:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 08:05:03 --> Controller Class Initialized
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-24 08:05:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-24 08:05:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-24 08:05:05 --> Final output sent to browser
DEBUG - 2024-09-24 08:05:05 --> Total execution time: 2.7331
INFO - 2024-09-24 09:46:08 --> Config Class Initialized
INFO - 2024-09-24 09:46:08 --> Hooks Class Initialized
DEBUG - 2024-09-24 09:46:08 --> UTF-8 Support Enabled
INFO - 2024-09-24 09:46:08 --> Utf8 Class Initialized
INFO - 2024-09-24 09:46:08 --> URI Class Initialized
INFO - 2024-09-24 09:46:08 --> Router Class Initialized
INFO - 2024-09-24 09:46:08 --> Output Class Initialized
INFO - 2024-09-24 09:46:08 --> Security Class Initialized
DEBUG - 2024-09-24 09:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-24 09:46:08 --> Input Class Initialized
INFO - 2024-09-24 09:46:08 --> Language Class Initialized
INFO - 2024-09-24 09:46:08 --> Language Class Initialized
INFO - 2024-09-24 09:46:08 --> Config Class Initialized
INFO - 2024-09-24 09:46:08 --> Loader Class Initialized
INFO - 2024-09-24 09:46:08 --> Helper loaded: url_helper
INFO - 2024-09-24 09:46:08 --> Helper loaded: file_helper
INFO - 2024-09-24 09:46:08 --> Helper loaded: form_helper
INFO - 2024-09-24 09:46:08 --> Helper loaded: my_helper
INFO - 2024-09-24 09:46:08 --> Database Driver Class Initialized
INFO - 2024-09-24 09:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-24 09:46:08 --> Controller Class Initialized
INFO - 2024-09-24 09:46:08 --> Final output sent to browser
DEBUG - 2024-09-24 09:46:08 --> Total execution time: 0.0674
