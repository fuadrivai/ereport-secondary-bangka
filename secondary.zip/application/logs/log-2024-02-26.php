<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-02-26 09:46:32 --> Config Class Initialized
INFO - 2024-02-26 09:46:32 --> Hooks Class Initialized
DEBUG - 2024-02-26 09:46:32 --> UTF-8 Support Enabled
INFO - 2024-02-26 09:46:32 --> Utf8 Class Initialized
INFO - 2024-02-26 09:46:32 --> URI Class Initialized
INFO - 2024-02-26 09:46:32 --> Router Class Initialized
INFO - 2024-02-26 09:46:32 --> Output Class Initialized
INFO - 2024-02-26 09:46:32 --> Security Class Initialized
DEBUG - 2024-02-26 09:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 09:46:32 --> Input Class Initialized
INFO - 2024-02-26 09:46:32 --> Language Class Initialized
INFO - 2024-02-26 09:46:32 --> Language Class Initialized
INFO - 2024-02-26 09:46:32 --> Config Class Initialized
INFO - 2024-02-26 09:46:32 --> Loader Class Initialized
INFO - 2024-02-26 09:46:32 --> Helper loaded: url_helper
INFO - 2024-02-26 09:46:32 --> Helper loaded: file_helper
INFO - 2024-02-26 09:46:32 --> Helper loaded: form_helper
INFO - 2024-02-26 09:46:32 --> Helper loaded: my_helper
INFO - 2024-02-26 09:46:32 --> Database Driver Class Initialized
INFO - 2024-02-26 09:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 09:46:32 --> Controller Class Initialized
DEBUG - 2024-02-26 09:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/login/views/login.php
DEBUG - 2024-02-26 09:46:32 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 09:46:32 --> Final output sent to browser
DEBUG - 2024-02-26 09:46:32 --> Total execution time: 0.0852
INFO - 2024-02-26 11:19:55 --> Config Class Initialized
INFO - 2024-02-26 11:19:55 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:55 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:55 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:55 --> URI Class Initialized
INFO - 2024-02-26 11:19:55 --> Router Class Initialized
INFO - 2024-02-26 11:19:55 --> Output Class Initialized
INFO - 2024-02-26 11:19:55 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:55 --> Input Class Initialized
INFO - 2024-02-26 11:19:55 --> Language Class Initialized
INFO - 2024-02-26 11:19:55 --> Language Class Initialized
INFO - 2024-02-26 11:19:55 --> Config Class Initialized
INFO - 2024-02-26 11:19:55 --> Loader Class Initialized
INFO - 2024-02-26 11:19:55 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:55 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:55 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:55 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:55 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:55 --> Controller Class Initialized
INFO - 2024-02-26 11:19:55 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:55 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:55 --> Total execution time: 0.1303
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:56 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:56 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:56 --> URI Class Initialized
INFO - 2024-02-26 11:19:56 --> Router Class Initialized
INFO - 2024-02-26 11:19:56 --> Output Class Initialized
INFO - 2024-02-26 11:19:56 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:56 --> Input Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Loader Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:56 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:56 --> Controller Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:56 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:56 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:56 --> URI Class Initialized
INFO - 2024-02-26 11:19:56 --> Router Class Initialized
INFO - 2024-02-26 11:19:56 --> Output Class Initialized
INFO - 2024-02-26 11:19:56 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:56 --> Input Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Loader Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:56 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:56 --> Controller Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:56 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:56 --> Total execution time: 0.0355
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:56 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:56 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:56 --> URI Class Initialized
INFO - 2024-02-26 11:19:56 --> Router Class Initialized
INFO - 2024-02-26 11:19:56 --> Output Class Initialized
INFO - 2024-02-26 11:19:56 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:56 --> Input Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Loader Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:56 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:56 --> Controller Class Initialized
DEBUG - 2024-02-26 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:19:56 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:56 --> Total execution time: 0.0414
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:56 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:56 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:56 --> URI Class Initialized
INFO - 2024-02-26 11:19:56 --> Router Class Initialized
INFO - 2024-02-26 11:19:56 --> Output Class Initialized
INFO - 2024-02-26 11:19:56 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:56 --> Input Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Loader Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:56 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:56 --> Controller Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:56 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:56 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:56 --> URI Class Initialized
INFO - 2024-02-26 11:19:56 --> Router Class Initialized
INFO - 2024-02-26 11:19:56 --> Output Class Initialized
INFO - 2024-02-26 11:19:56 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:56 --> Input Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Language Class Initialized
INFO - 2024-02-26 11:19:56 --> Config Class Initialized
INFO - 2024-02-26 11:19:56 --> Loader Class Initialized
INFO - 2024-02-26 11:19:56 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:56 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:56 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:56 --> Controller Class Initialized
DEBUG - 2024-02-26 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:19:56 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:19:56 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:56 --> Total execution time: 0.0349
INFO - 2024-02-26 11:19:57 --> Config Class Initialized
INFO - 2024-02-26 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:57 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:57 --> URI Class Initialized
INFO - 2024-02-26 11:19:57 --> Router Class Initialized
INFO - 2024-02-26 11:19:57 --> Output Class Initialized
INFO - 2024-02-26 11:19:57 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:57 --> Input Class Initialized
INFO - 2024-02-26 11:19:57 --> Language Class Initialized
INFO - 2024-02-26 11:19:57 --> Language Class Initialized
INFO - 2024-02-26 11:19:57 --> Config Class Initialized
INFO - 2024-02-26 11:19:57 --> Loader Class Initialized
INFO - 2024-02-26 11:19:57 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:57 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:57 --> Controller Class Initialized
INFO - 2024-02-26 11:19:57 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:57 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:57 --> Total execution time: 0.0414
INFO - 2024-02-26 11:19:57 --> Config Class Initialized
INFO - 2024-02-26 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:57 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:57 --> URI Class Initialized
INFO - 2024-02-26 11:19:57 --> Router Class Initialized
INFO - 2024-02-26 11:19:57 --> Output Class Initialized
INFO - 2024-02-26 11:19:57 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:57 --> Input Class Initialized
INFO - 2024-02-26 11:19:57 --> Language Class Initialized
INFO - 2024-02-26 11:19:57 --> Language Class Initialized
INFO - 2024-02-26 11:19:57 --> Config Class Initialized
INFO - 2024-02-26 11:19:57 --> Loader Class Initialized
INFO - 2024-02-26 11:19:57 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:57 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:57 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:57 --> Controller Class Initialized
INFO - 2024-02-26 11:19:57 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:19:57 --> Config Class Initialized
INFO - 2024-02-26 11:19:57 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:19:57 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:19:57 --> Utf8 Class Initialized
INFO - 2024-02-26 11:19:57 --> URI Class Initialized
INFO - 2024-02-26 11:19:57 --> Router Class Initialized
INFO - 2024-02-26 11:19:57 --> Output Class Initialized
INFO - 2024-02-26 11:19:57 --> Security Class Initialized
DEBUG - 2024-02-26 11:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:19:57 --> Input Class Initialized
INFO - 2024-02-26 11:19:57 --> Language Class Initialized
INFO - 2024-02-26 11:19:58 --> Language Class Initialized
INFO - 2024-02-26 11:19:58 --> Config Class Initialized
INFO - 2024-02-26 11:19:58 --> Loader Class Initialized
INFO - 2024-02-26 11:19:58 --> Helper loaded: url_helper
INFO - 2024-02-26 11:19:58 --> Helper loaded: file_helper
INFO - 2024-02-26 11:19:58 --> Helper loaded: form_helper
INFO - 2024-02-26 11:19:58 --> Helper loaded: my_helper
INFO - 2024-02-26 11:19:58 --> Database Driver Class Initialized
INFO - 2024-02-26 11:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:19:58 --> Controller Class Initialized
DEBUG - 2024-02-26 11:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:19:58 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:19:58 --> Final output sent to browser
DEBUG - 2024-02-26 11:19:58 --> Total execution time: 0.0353
INFO - 2024-02-26 11:20:05 --> Config Class Initialized
INFO - 2024-02-26 11:20:05 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:20:05 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:20:05 --> Utf8 Class Initialized
INFO - 2024-02-26 11:20:05 --> URI Class Initialized
INFO - 2024-02-26 11:20:05 --> Router Class Initialized
INFO - 2024-02-26 11:20:05 --> Output Class Initialized
INFO - 2024-02-26 11:20:05 --> Security Class Initialized
DEBUG - 2024-02-26 11:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:20:05 --> Input Class Initialized
INFO - 2024-02-26 11:20:05 --> Language Class Initialized
INFO - 2024-02-26 11:20:05 --> Language Class Initialized
INFO - 2024-02-26 11:20:05 --> Config Class Initialized
INFO - 2024-02-26 11:20:05 --> Loader Class Initialized
INFO - 2024-02-26 11:20:05 --> Helper loaded: url_helper
INFO - 2024-02-26 11:20:05 --> Helper loaded: file_helper
INFO - 2024-02-26 11:20:05 --> Helper loaded: form_helper
INFO - 2024-02-26 11:20:05 --> Helper loaded: my_helper
INFO - 2024-02-26 11:20:05 --> Database Driver Class Initialized
INFO - 2024-02-26 11:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:20:05 --> Controller Class Initialized
DEBUG - 2024-02-26 11:20:05 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-02-26 11:20:10 --> Final output sent to browser
DEBUG - 2024-02-26 11:20:10 --> Total execution time: 5.0556
INFO - 2024-02-26 11:20:14 --> Config Class Initialized
INFO - 2024-02-26 11:20:14 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:20:14 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:20:14 --> Utf8 Class Initialized
INFO - 2024-02-26 11:20:14 --> URI Class Initialized
INFO - 2024-02-26 11:20:14 --> Router Class Initialized
INFO - 2024-02-26 11:20:14 --> Output Class Initialized
INFO - 2024-02-26 11:20:14 --> Security Class Initialized
DEBUG - 2024-02-26 11:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:20:14 --> Input Class Initialized
INFO - 2024-02-26 11:20:14 --> Language Class Initialized
INFO - 2024-02-26 11:20:14 --> Language Class Initialized
INFO - 2024-02-26 11:20:14 --> Config Class Initialized
INFO - 2024-02-26 11:20:14 --> Loader Class Initialized
INFO - 2024-02-26 11:20:14 --> Helper loaded: url_helper
INFO - 2024-02-26 11:20:14 --> Helper loaded: file_helper
INFO - 2024-02-26 11:20:14 --> Helper loaded: form_helper
INFO - 2024-02-26 11:20:14 --> Helper loaded: my_helper
INFO - 2024-02-26 11:20:14 --> Database Driver Class Initialized
INFO - 2024-02-26 11:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:20:14 --> Controller Class Initialized
DEBUG - 2024-02-26 11:20:14 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-02-26 11:20:19 --> Final output sent to browser
DEBUG - 2024-02-26 11:20:19 --> Total execution time: 5.0303
INFO - 2024-02-26 11:20:38 --> Config Class Initialized
INFO - 2024-02-26 11:20:38 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:20:38 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:20:38 --> Utf8 Class Initialized
INFO - 2024-02-26 11:20:38 --> URI Class Initialized
INFO - 2024-02-26 11:20:38 --> Router Class Initialized
INFO - 2024-02-26 11:20:38 --> Output Class Initialized
INFO - 2024-02-26 11:20:38 --> Security Class Initialized
DEBUG - 2024-02-26 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:20:38 --> Input Class Initialized
INFO - 2024-02-26 11:20:38 --> Language Class Initialized
INFO - 2024-02-26 11:20:38 --> Language Class Initialized
INFO - 2024-02-26 11:20:38 --> Config Class Initialized
INFO - 2024-02-26 11:20:38 --> Loader Class Initialized
INFO - 2024-02-26 11:20:38 --> Helper loaded: url_helper
INFO - 2024-02-26 11:20:38 --> Helper loaded: file_helper
INFO - 2024-02-26 11:20:38 --> Helper loaded: form_helper
INFO - 2024-02-26 11:20:38 --> Helper loaded: my_helper
INFO - 2024-02-26 11:20:38 --> Database Driver Class Initialized
INFO - 2024-02-26 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:20:38 --> Controller Class Initialized
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:38 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-02-26 11:20:38 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-02-26 11:20:43 --> Final output sent to browser
DEBUG - 2024-02-26 11:20:43 --> Total execution time: 5.3002
INFO - 2024-02-26 11:20:46 --> Config Class Initialized
INFO - 2024-02-26 11:20:46 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:20:46 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:20:46 --> Utf8 Class Initialized
INFO - 2024-02-26 11:20:46 --> URI Class Initialized
INFO - 2024-02-26 11:20:46 --> Router Class Initialized
INFO - 2024-02-26 11:20:46 --> Output Class Initialized
INFO - 2024-02-26 11:20:46 --> Security Class Initialized
DEBUG - 2024-02-26 11:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:20:46 --> Input Class Initialized
INFO - 2024-02-26 11:20:46 --> Language Class Initialized
INFO - 2024-02-26 11:20:46 --> Language Class Initialized
INFO - 2024-02-26 11:20:46 --> Config Class Initialized
INFO - 2024-02-26 11:20:46 --> Loader Class Initialized
INFO - 2024-02-26 11:20:46 --> Helper loaded: url_helper
INFO - 2024-02-26 11:20:46 --> Helper loaded: file_helper
INFO - 2024-02-26 11:20:46 --> Helper loaded: form_helper
INFO - 2024-02-26 11:20:46 --> Helper loaded: my_helper
INFO - 2024-02-26 11:20:46 --> Database Driver Class Initialized
INFO - 2024-02-26 11:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:20:46 --> Controller Class Initialized
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:20:46 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-02-26 11:20:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-02-26 11:20:52 --> Final output sent to browser
DEBUG - 2024-02-26 11:20:52 --> Total execution time: 6.2472
INFO - 2024-02-26 11:25:22 --> Config Class Initialized
INFO - 2024-02-26 11:25:22 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:25:22 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:25:22 --> Utf8 Class Initialized
INFO - 2024-02-26 11:25:22 --> URI Class Initialized
INFO - 2024-02-26 11:25:22 --> Router Class Initialized
INFO - 2024-02-26 11:25:22 --> Output Class Initialized
INFO - 2024-02-26 11:25:22 --> Security Class Initialized
DEBUG - 2024-02-26 11:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:25:22 --> Input Class Initialized
INFO - 2024-02-26 11:25:22 --> Language Class Initialized
INFO - 2024-02-26 11:25:23 --> Language Class Initialized
INFO - 2024-02-26 11:25:23 --> Config Class Initialized
INFO - 2024-02-26 11:25:23 --> Loader Class Initialized
INFO - 2024-02-26 11:25:23 --> Helper loaded: url_helper
INFO - 2024-02-26 11:25:23 --> Helper loaded: file_helper
INFO - 2024-02-26 11:25:23 --> Helper loaded: form_helper
INFO - 2024-02-26 11:25:23 --> Helper loaded: my_helper
INFO - 2024-02-26 11:25:23 --> Database Driver Class Initialized
INFO - 2024-02-26 11:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:25:23 --> Controller Class Initialized
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:23 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-02-26 11:25:23 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-02-26 11:25:28 --> Final output sent to browser
DEBUG - 2024-02-26 11:25:28 --> Total execution time: 5.1999
INFO - 2024-02-26 11:25:30 --> Config Class Initialized
INFO - 2024-02-26 11:25:30 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:25:30 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:25:30 --> Utf8 Class Initialized
INFO - 2024-02-26 11:25:30 --> URI Class Initialized
INFO - 2024-02-26 11:25:30 --> Router Class Initialized
INFO - 2024-02-26 11:25:30 --> Output Class Initialized
INFO - 2024-02-26 11:25:30 --> Security Class Initialized
DEBUG - 2024-02-26 11:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:25:30 --> Input Class Initialized
INFO - 2024-02-26 11:25:30 --> Language Class Initialized
INFO - 2024-02-26 11:25:30 --> Language Class Initialized
INFO - 2024-02-26 11:25:30 --> Config Class Initialized
INFO - 2024-02-26 11:25:30 --> Loader Class Initialized
INFO - 2024-02-26 11:25:30 --> Helper loaded: url_helper
INFO - 2024-02-26 11:25:30 --> Helper loaded: file_helper
INFO - 2024-02-26 11:25:30 --> Helper loaded: form_helper
INFO - 2024-02-26 11:25:30 --> Helper loaded: my_helper
INFO - 2024-02-26 11:25:30 --> Database Driver Class Initialized
INFO - 2024-02-26 11:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:25:30 --> Controller Class Initialized
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1837
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
ERROR - 2024-02-26 11:25:30 --> Severity: Notice --> Undefined index: lang /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1855
DEBUG - 2024-02-26 11:25:30 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
INFO - 2024-02-26 11:25:36 --> Final output sent to browser
DEBUG - 2024-02-26 11:25:36 --> Total execution time: 5.9091
INFO - 2024-02-26 11:31:15 --> Config Class Initialized
INFO - 2024-02-26 11:31:15 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:15 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:15 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:15 --> URI Class Initialized
INFO - 2024-02-26 11:31:15 --> Router Class Initialized
INFO - 2024-02-26 11:31:15 --> Output Class Initialized
INFO - 2024-02-26 11:31:15 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:15 --> Input Class Initialized
INFO - 2024-02-26 11:31:15 --> Language Class Initialized
INFO - 2024-02-26 11:31:15 --> Language Class Initialized
INFO - 2024-02-26 11:31:15 --> Config Class Initialized
INFO - 2024-02-26 11:31:15 --> Loader Class Initialized
INFO - 2024-02-26 11:31:15 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:15 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:15 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:15 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:15 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:15 --> Controller Class Initialized
INFO - 2024-02-26 11:31:15 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:15 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:15 --> Total execution time: 0.0640
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:16 --> URI Class Initialized
INFO - 2024-02-26 11:31:16 --> Router Class Initialized
INFO - 2024-02-26 11:31:16 --> Output Class Initialized
INFO - 2024-02-26 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:16 --> Input Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Loader Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:16 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:16 --> Controller Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:16 --> URI Class Initialized
INFO - 2024-02-26 11:31:16 --> Router Class Initialized
INFO - 2024-02-26 11:31:16 --> Output Class Initialized
INFO - 2024-02-26 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:16 --> Input Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Loader Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:16 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:16 --> Controller Class Initialized
DEBUG - 2024-02-26 11:31:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:31:16 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:31:16 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:16 --> Total execution time: 0.0392
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:16 --> URI Class Initialized
INFO - 2024-02-26 11:31:16 --> Router Class Initialized
INFO - 2024-02-26 11:31:16 --> Output Class Initialized
INFO - 2024-02-26 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:16 --> Input Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Loader Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:16 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:16 --> Controller Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:16 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:16 --> Total execution time: 0.0849
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:16 --> URI Class Initialized
INFO - 2024-02-26 11:31:16 --> Router Class Initialized
INFO - 2024-02-26 11:31:16 --> Output Class Initialized
INFO - 2024-02-26 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:16 --> Input Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Loader Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:16 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:16 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:16 --> URI Class Initialized
INFO - 2024-02-26 11:31:16 --> Router Class Initialized
INFO - 2024-02-26 11:31:16 --> Output Class Initialized
INFO - 2024-02-26 11:31:16 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:16 --> Input Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Language Class Initialized
INFO - 2024-02-26 11:31:16 --> Config Class Initialized
INFO - 2024-02-26 11:31:16 --> Loader Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:16 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:16 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:16 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:16 --> Controller Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:16 --> Controller Class Initialized
INFO - 2024-02-26 11:31:16 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:17 --> Config Class Initialized
INFO - 2024-02-26 11:31:17 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:17 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:17 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:17 --> URI Class Initialized
INFO - 2024-02-26 11:31:17 --> Router Class Initialized
INFO - 2024-02-26 11:31:17 --> Output Class Initialized
INFO - 2024-02-26 11:31:17 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:17 --> Input Class Initialized
INFO - 2024-02-26 11:31:17 --> Language Class Initialized
INFO - 2024-02-26 11:31:17 --> Language Class Initialized
INFO - 2024-02-26 11:31:17 --> Config Class Initialized
INFO - 2024-02-26 11:31:17 --> Loader Class Initialized
INFO - 2024-02-26 11:31:17 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:17 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:17 --> Controller Class Initialized
DEBUG - 2024-02-26 11:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:31:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:31:17 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:17 --> Total execution time: 0.0996
INFO - 2024-02-26 11:31:17 --> Config Class Initialized
INFO - 2024-02-26 11:31:17 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:17 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:17 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:17 --> URI Class Initialized
INFO - 2024-02-26 11:31:17 --> Router Class Initialized
INFO - 2024-02-26 11:31:17 --> Output Class Initialized
INFO - 2024-02-26 11:31:17 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:17 --> Input Class Initialized
INFO - 2024-02-26 11:31:17 --> Language Class Initialized
INFO - 2024-02-26 11:31:17 --> Language Class Initialized
INFO - 2024-02-26 11:31:17 --> Config Class Initialized
INFO - 2024-02-26 11:31:17 --> Loader Class Initialized
INFO - 2024-02-26 11:31:17 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:17 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:17 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:17 --> Controller Class Initialized
INFO - 2024-02-26 11:31:17 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:17 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:17 --> Total execution time: 0.0378
INFO - 2024-02-26 11:31:18 --> Config Class Initialized
INFO - 2024-02-26 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:18 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:18 --> URI Class Initialized
INFO - 2024-02-26 11:31:18 --> Router Class Initialized
INFO - 2024-02-26 11:31:18 --> Output Class Initialized
INFO - 2024-02-26 11:31:18 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:18 --> Input Class Initialized
INFO - 2024-02-26 11:31:18 --> Language Class Initialized
INFO - 2024-02-26 11:31:18 --> Language Class Initialized
INFO - 2024-02-26 11:31:18 --> Config Class Initialized
INFO - 2024-02-26 11:31:18 --> Loader Class Initialized
INFO - 2024-02-26 11:31:18 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:18 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:18 --> Controller Class Initialized
INFO - 2024-02-26 11:31:18 --> Helper loaded: cookie_helper
INFO - 2024-02-26 11:31:18 --> Config Class Initialized
INFO - 2024-02-26 11:31:18 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:18 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:18 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:18 --> URI Class Initialized
INFO - 2024-02-26 11:31:18 --> Router Class Initialized
INFO - 2024-02-26 11:31:18 --> Output Class Initialized
INFO - 2024-02-26 11:31:18 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:18 --> Input Class Initialized
INFO - 2024-02-26 11:31:18 --> Language Class Initialized
INFO - 2024-02-26 11:31:18 --> Language Class Initialized
INFO - 2024-02-26 11:31:18 --> Config Class Initialized
INFO - 2024-02-26 11:31:18 --> Loader Class Initialized
INFO - 2024-02-26 11:31:18 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:18 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:18 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:18 --> Controller Class Initialized
DEBUG - 2024-02-26 11:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-02-26 11:31:18 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-02-26 11:31:18 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:18 --> Total execution time: 0.0478
INFO - 2024-02-26 11:31:22 --> Config Class Initialized
INFO - 2024-02-26 11:31:22 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:22 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:22 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:22 --> URI Class Initialized
INFO - 2024-02-26 11:31:22 --> Router Class Initialized
INFO - 2024-02-26 11:31:22 --> Output Class Initialized
INFO - 2024-02-26 11:31:22 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:22 --> Input Class Initialized
INFO - 2024-02-26 11:31:22 --> Language Class Initialized
INFO - 2024-02-26 11:31:22 --> Language Class Initialized
INFO - 2024-02-26 11:31:22 --> Config Class Initialized
INFO - 2024-02-26 11:31:22 --> Loader Class Initialized
INFO - 2024-02-26 11:31:22 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:22 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:22 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:22 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:22 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:22 --> Controller Class Initialized
DEBUG - 2024-02-26 11:31:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-02-26 11:31:26 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:26 --> Total execution time: 3.7073
INFO - 2024-02-26 11:31:29 --> Config Class Initialized
INFO - 2024-02-26 11:31:29 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:31:29 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:31:29 --> Utf8 Class Initialized
INFO - 2024-02-26 11:31:29 --> URI Class Initialized
INFO - 2024-02-26 11:31:29 --> Router Class Initialized
INFO - 2024-02-26 11:31:29 --> Output Class Initialized
INFO - 2024-02-26 11:31:29 --> Security Class Initialized
DEBUG - 2024-02-26 11:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:31:29 --> Input Class Initialized
INFO - 2024-02-26 11:31:29 --> Language Class Initialized
INFO - 2024-02-26 11:31:29 --> Language Class Initialized
INFO - 2024-02-26 11:31:29 --> Config Class Initialized
INFO - 2024-02-26 11:31:29 --> Loader Class Initialized
INFO - 2024-02-26 11:31:29 --> Helper loaded: url_helper
INFO - 2024-02-26 11:31:29 --> Helper loaded: file_helper
INFO - 2024-02-26 11:31:29 --> Helper loaded: form_helper
INFO - 2024-02-26 11:31:29 --> Helper loaded: my_helper
INFO - 2024-02-26 11:31:29 --> Database Driver Class Initialized
INFO - 2024-02-26 11:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:31:29 --> Controller Class Initialized
DEBUG - 2024-02-26 11:31:29 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-02-26 11:31:33 --> Final output sent to browser
DEBUG - 2024-02-26 11:31:33 --> Total execution time: 3.7724
INFO - 2024-02-26 11:32:22 --> Config Class Initialized
INFO - 2024-02-26 11:32:22 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:32:22 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:32:22 --> Utf8 Class Initialized
INFO - 2024-02-26 11:32:22 --> URI Class Initialized
INFO - 2024-02-26 11:32:22 --> Router Class Initialized
INFO - 2024-02-26 11:32:22 --> Output Class Initialized
INFO - 2024-02-26 11:32:22 --> Security Class Initialized
DEBUG - 2024-02-26 11:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:32:22 --> Input Class Initialized
INFO - 2024-02-26 11:32:22 --> Language Class Initialized
INFO - 2024-02-26 11:32:22 --> Language Class Initialized
INFO - 2024-02-26 11:32:22 --> Config Class Initialized
INFO - 2024-02-26 11:32:22 --> Loader Class Initialized
INFO - 2024-02-26 11:32:22 --> Helper loaded: url_helper
INFO - 2024-02-26 11:32:22 --> Helper loaded: file_helper
INFO - 2024-02-26 11:32:22 --> Helper loaded: form_helper
INFO - 2024-02-26 11:32:22 --> Helper loaded: my_helper
INFO - 2024-02-26 11:32:22 --> Database Driver Class Initialized
INFO - 2024-02-26 11:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:32:22 --> Controller Class Initialized
DEBUG - 2024-02-26 11:32:22 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-02-26 11:32:24 --> Final output sent to browser
DEBUG - 2024-02-26 11:32:24 --> Total execution time: 2.3784
INFO - 2024-02-26 11:32:26 --> Config Class Initialized
INFO - 2024-02-26 11:32:26 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:32:26 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:32:26 --> Utf8 Class Initialized
INFO - 2024-02-26 11:32:26 --> URI Class Initialized
INFO - 2024-02-26 11:32:26 --> Router Class Initialized
INFO - 2024-02-26 11:32:26 --> Output Class Initialized
INFO - 2024-02-26 11:32:26 --> Security Class Initialized
DEBUG - 2024-02-26 11:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:32:26 --> Input Class Initialized
INFO - 2024-02-26 11:32:26 --> Language Class Initialized
INFO - 2024-02-26 11:32:26 --> Language Class Initialized
INFO - 2024-02-26 11:32:26 --> Config Class Initialized
INFO - 2024-02-26 11:32:26 --> Loader Class Initialized
INFO - 2024-02-26 11:32:26 --> Helper loaded: url_helper
INFO - 2024-02-26 11:32:26 --> Helper loaded: file_helper
INFO - 2024-02-26 11:32:26 --> Helper loaded: form_helper
INFO - 2024-02-26 11:32:26 --> Helper loaded: my_helper
INFO - 2024-02-26 11:32:26 --> Database Driver Class Initialized
INFO - 2024-02-26 11:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:32:26 --> Controller Class Initialized
DEBUG - 2024-02-26 11:32:26 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_ikm.php
INFO - 2024-02-26 11:32:28 --> Final output sent to browser
DEBUG - 2024-02-26 11:32:28 --> Total execution time: 2.3590
INFO - 2024-02-26 11:32:46 --> Config Class Initialized
INFO - 2024-02-26 11:32:46 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:32:46 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:32:46 --> Utf8 Class Initialized
INFO - 2024-02-26 11:32:46 --> URI Class Initialized
INFO - 2024-02-26 11:32:46 --> Router Class Initialized
INFO - 2024-02-26 11:32:46 --> Output Class Initialized
INFO - 2024-02-26 11:32:46 --> Security Class Initialized
DEBUG - 2024-02-26 11:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:32:46 --> Input Class Initialized
INFO - 2024-02-26 11:32:46 --> Language Class Initialized
INFO - 2024-02-26 11:32:46 --> Language Class Initialized
INFO - 2024-02-26 11:32:46 --> Config Class Initialized
INFO - 2024-02-26 11:32:46 --> Loader Class Initialized
INFO - 2024-02-26 11:32:46 --> Helper loaded: url_helper
INFO - 2024-02-26 11:32:46 --> Helper loaded: file_helper
INFO - 2024-02-26 11:32:46 --> Helper loaded: form_helper
INFO - 2024-02-26 11:32:46 --> Helper loaded: my_helper
INFO - 2024-02-26 11:32:46 --> Database Driver Class Initialized
INFO - 2024-02-26 11:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:32:46 --> Controller Class Initialized
DEBUG - 2024-02-26 11:32:46 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-02-26 11:32:53 --> Final output sent to browser
DEBUG - 2024-02-26 11:32:53 --> Total execution time: 7.0518
INFO - 2024-02-26 11:32:55 --> Config Class Initialized
INFO - 2024-02-26 11:32:55 --> Hooks Class Initialized
DEBUG - 2024-02-26 11:32:55 --> UTF-8 Support Enabled
INFO - 2024-02-26 11:32:55 --> Utf8 Class Initialized
INFO - 2024-02-26 11:32:55 --> URI Class Initialized
INFO - 2024-02-26 11:32:55 --> Router Class Initialized
INFO - 2024-02-26 11:32:55 --> Output Class Initialized
INFO - 2024-02-26 11:32:55 --> Security Class Initialized
DEBUG - 2024-02-26 11:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-02-26 11:32:55 --> Input Class Initialized
INFO - 2024-02-26 11:32:55 --> Language Class Initialized
INFO - 2024-02-26 11:32:55 --> Language Class Initialized
INFO - 2024-02-26 11:32:55 --> Config Class Initialized
INFO - 2024-02-26 11:32:55 --> Loader Class Initialized
INFO - 2024-02-26 11:32:55 --> Helper loaded: url_helper
INFO - 2024-02-26 11:32:55 --> Helper loaded: file_helper
INFO - 2024-02-26 11:32:55 --> Helper loaded: form_helper
INFO - 2024-02-26 11:32:55 --> Helper loaded: my_helper
INFO - 2024-02-26 11:32:55 --> Database Driver Class Initialized
INFO - 2024-02-26 11:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-02-26 11:32:55 --> Controller Class Initialized
DEBUG - 2024-02-26 11:32:55 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_mh.php
INFO - 2024-02-26 11:33:01 --> Final output sent to browser
DEBUG - 2024-02-26 11:33:01 --> Total execution time: 5.2595
