<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Hooks Class Initialized
DEBUG - 2024-09-25 08:13:53 --> UTF-8 Support Enabled
INFO - 2024-09-25 08:13:53 --> Utf8 Class Initialized
INFO - 2024-09-25 08:13:53 --> URI Class Initialized
INFO - 2024-09-25 08:13:53 --> Router Class Initialized
INFO - 2024-09-25 08:13:53 --> Output Class Initialized
INFO - 2024-09-25 08:13:53 --> Security Class Initialized
DEBUG - 2024-09-25 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 08:13:53 --> Input Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Loader Class Initialized
INFO - 2024-09-25 08:13:53 --> Helper loaded: url_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: file_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: form_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: my_helper
INFO - 2024-09-25 08:13:53 --> Database Driver Class Initialized
INFO - 2024-09-25 08:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 08:13:53 --> Controller Class Initialized
INFO - 2024-09-25 08:13:53 --> Helper loaded: cookie_helper
INFO - 2024-09-25 08:13:53 --> Final output sent to browser
DEBUG - 2024-09-25 08:13:53 --> Total execution time: 0.0699
INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Hooks Class Initialized
DEBUG - 2024-09-25 08:13:53 --> UTF-8 Support Enabled
INFO - 2024-09-25 08:13:53 --> Utf8 Class Initialized
INFO - 2024-09-25 08:13:53 --> URI Class Initialized
INFO - 2024-09-25 08:13:53 --> Router Class Initialized
INFO - 2024-09-25 08:13:53 --> Output Class Initialized
INFO - 2024-09-25 08:13:53 --> Security Class Initialized
DEBUG - 2024-09-25 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 08:13:53 --> Input Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Loader Class Initialized
INFO - 2024-09-25 08:13:53 --> Helper loaded: url_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: file_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: form_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: my_helper
INFO - 2024-09-25 08:13:53 --> Database Driver Class Initialized
INFO - 2024-09-25 08:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 08:13:53 --> Controller Class Initialized
INFO - 2024-09-25 08:13:53 --> Helper loaded: cookie_helper
INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Hooks Class Initialized
DEBUG - 2024-09-25 08:13:53 --> UTF-8 Support Enabled
INFO - 2024-09-25 08:13:53 --> Utf8 Class Initialized
INFO - 2024-09-25 08:13:53 --> URI Class Initialized
INFO - 2024-09-25 08:13:53 --> Router Class Initialized
INFO - 2024-09-25 08:13:53 --> Output Class Initialized
INFO - 2024-09-25 08:13:53 --> Security Class Initialized
DEBUG - 2024-09-25 08:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 08:13:53 --> Input Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Language Class Initialized
INFO - 2024-09-25 08:13:53 --> Config Class Initialized
INFO - 2024-09-25 08:13:53 --> Loader Class Initialized
INFO - 2024-09-25 08:13:53 --> Helper loaded: url_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: file_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: form_helper
INFO - 2024-09-25 08:13:53 --> Helper loaded: my_helper
INFO - 2024-09-25 08:13:53 --> Database Driver Class Initialized
INFO - 2024-09-25 08:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 08:13:53 --> Controller Class Initialized
DEBUG - 2024-09-25 08:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-25 08:13:53 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-25 08:13:53 --> Final output sent to browser
DEBUG - 2024-09-25 08:13:53 --> Total execution time: 0.0325
INFO - 2024-09-25 08:13:59 --> Config Class Initialized
INFO - 2024-09-25 08:13:59 --> Hooks Class Initialized
DEBUG - 2024-09-25 08:13:59 --> UTF-8 Support Enabled
INFO - 2024-09-25 08:13:59 --> Utf8 Class Initialized
INFO - 2024-09-25 08:13:59 --> URI Class Initialized
INFO - 2024-09-25 08:13:59 --> Router Class Initialized
INFO - 2024-09-25 08:13:59 --> Output Class Initialized
INFO - 2024-09-25 08:13:59 --> Security Class Initialized
DEBUG - 2024-09-25 08:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 08:13:59 --> Input Class Initialized
INFO - 2024-09-25 08:13:59 --> Language Class Initialized
INFO - 2024-09-25 08:13:59 --> Language Class Initialized
INFO - 2024-09-25 08:13:59 --> Config Class Initialized
INFO - 2024-09-25 08:13:59 --> Loader Class Initialized
INFO - 2024-09-25 08:13:59 --> Helper loaded: url_helper
INFO - 2024-09-25 08:13:59 --> Helper loaded: file_helper
INFO - 2024-09-25 08:13:59 --> Helper loaded: form_helper
INFO - 2024-09-25 08:13:59 --> Helper loaded: my_helper
INFO - 2024-09-25 08:13:59 --> Database Driver Class Initialized
INFO - 2024-09-25 08:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 08:13:59 --> Controller Class Initialized
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-25 08:13:59 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-25 08:13:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-25 08:14:02 --> Final output sent to browser
DEBUG - 2024-09-25 08:14:02 --> Total execution time: 2.9917
INFO - 2024-09-25 08:14:17 --> Config Class Initialized
INFO - 2024-09-25 08:14:17 --> Hooks Class Initialized
DEBUG - 2024-09-25 08:14:17 --> UTF-8 Support Enabled
INFO - 2024-09-25 08:14:17 --> Utf8 Class Initialized
INFO - 2024-09-25 08:14:17 --> URI Class Initialized
INFO - 2024-09-25 08:14:17 --> Router Class Initialized
INFO - 2024-09-25 08:14:17 --> Output Class Initialized
INFO - 2024-09-25 08:14:17 --> Security Class Initialized
DEBUG - 2024-09-25 08:14:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 08:14:17 --> Input Class Initialized
INFO - 2024-09-25 08:14:17 --> Language Class Initialized
INFO - 2024-09-25 08:14:17 --> Language Class Initialized
INFO - 2024-09-25 08:14:17 --> Config Class Initialized
INFO - 2024-09-25 08:14:17 --> Loader Class Initialized
INFO - 2024-09-25 08:14:17 --> Helper loaded: url_helper
INFO - 2024-09-25 08:14:17 --> Helper loaded: file_helper
INFO - 2024-09-25 08:14:17 --> Helper loaded: form_helper
INFO - 2024-09-25 08:14:17 --> Helper loaded: my_helper
INFO - 2024-09-25 08:14:17 --> Database Driver Class Initialized
INFO - 2024-09-25 08:14:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 08:14:17 --> Controller Class Initialized
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 107
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 554
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 616
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 679
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 686
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 757
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 760
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 832
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 906
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 913
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 987
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 83
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
ERROR - 2024-09-25 08:14:17 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php 95
DEBUG - 2024-09-25 08:14:17 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_rapot.php
INFO - 2024-09-25 08:14:20 --> Final output sent to browser
DEBUG - 2024-09-25 08:14:20 --> Total execution time: 2.6463
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:23:59 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:23:59 --> Utf8 Class Initialized
INFO - 2024-09-25 17:23:59 --> URI Class Initialized
INFO - 2024-09-25 17:23:59 --> Router Class Initialized
INFO - 2024-09-25 17:23:59 --> Output Class Initialized
INFO - 2024-09-25 17:23:59 --> Security Class Initialized
DEBUG - 2024-09-25 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:23:59 --> Input Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Loader Class Initialized
INFO - 2024-09-25 17:23:59 --> Helper loaded: url_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: file_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: form_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: my_helper
INFO - 2024-09-25 17:23:59 --> Database Driver Class Initialized
INFO - 2024-09-25 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:23:59 --> Controller Class Initialized
INFO - 2024-09-25 17:23:59 --> Helper loaded: cookie_helper
INFO - 2024-09-25 17:23:59 --> Final output sent to browser
DEBUG - 2024-09-25 17:23:59 --> Total execution time: 0.0545
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:23:59 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:23:59 --> Utf8 Class Initialized
INFO - 2024-09-25 17:23:59 --> URI Class Initialized
INFO - 2024-09-25 17:23:59 --> Router Class Initialized
INFO - 2024-09-25 17:23:59 --> Output Class Initialized
INFO - 2024-09-25 17:23:59 --> Security Class Initialized
DEBUG - 2024-09-25 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:23:59 --> Input Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Loader Class Initialized
INFO - 2024-09-25 17:23:59 --> Helper loaded: url_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: file_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: form_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: my_helper
INFO - 2024-09-25 17:23:59 --> Database Driver Class Initialized
INFO - 2024-09-25 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:23:59 --> Controller Class Initialized
INFO - 2024-09-25 17:23:59 --> Helper loaded: cookie_helper
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:23:59 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:23:59 --> Utf8 Class Initialized
INFO - 2024-09-25 17:23:59 --> URI Class Initialized
INFO - 2024-09-25 17:23:59 --> Router Class Initialized
INFO - 2024-09-25 17:23:59 --> Output Class Initialized
INFO - 2024-09-25 17:23:59 --> Security Class Initialized
DEBUG - 2024-09-25 17:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:23:59 --> Input Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Language Class Initialized
INFO - 2024-09-25 17:23:59 --> Config Class Initialized
INFO - 2024-09-25 17:23:59 --> Loader Class Initialized
INFO - 2024-09-25 17:23:59 --> Helper loaded: url_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: file_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: form_helper
INFO - 2024-09-25 17:23:59 --> Helper loaded: my_helper
INFO - 2024-09-25 17:23:59 --> Database Driver Class Initialized
INFO - 2024-09-25 17:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:23:59 --> Controller Class Initialized
DEBUG - 2024-09-25 17:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-09-25 17:23:59 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-09-25 17:23:59 --> Final output sent to browser
DEBUG - 2024-09-25 17:23:59 --> Total execution time: 0.0610
INFO - 2024-09-25 17:24:03 --> Config Class Initialized
INFO - 2024-09-25 17:24:03 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:24:03 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:24:03 --> Utf8 Class Initialized
INFO - 2024-09-25 17:24:03 --> URI Class Initialized
INFO - 2024-09-25 17:24:03 --> Router Class Initialized
INFO - 2024-09-25 17:24:03 --> Output Class Initialized
INFO - 2024-09-25 17:24:03 --> Security Class Initialized
DEBUG - 2024-09-25 17:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:24:03 --> Input Class Initialized
INFO - 2024-09-25 17:24:03 --> Language Class Initialized
INFO - 2024-09-25 17:24:03 --> Language Class Initialized
INFO - 2024-09-25 17:24:03 --> Config Class Initialized
INFO - 2024-09-25 17:24:03 --> Loader Class Initialized
INFO - 2024-09-25 17:24:03 --> Helper loaded: url_helper
INFO - 2024-09-25 17:24:03 --> Helper loaded: file_helper
INFO - 2024-09-25 17:24:03 --> Helper loaded: form_helper
INFO - 2024-09-25 17:24:03 --> Helper loaded: my_helper
INFO - 2024-09-25 17:24:03 --> Database Driver Class Initialized
INFO - 2024-09-25 17:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:24:03 --> Controller Class Initialized
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1160
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Undefined variable: kkmx /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1493
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1692
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1729
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1767
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1806
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1883
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 1962
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2042
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2122
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2202
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/controllers/Cetak_raport_pts.php 2277
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
ERROR - 2024-09-25 17:24:03 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php 32
DEBUG - 2024-09-25 17:24:03 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-09-25 17:24:06 --> Final output sent to browser
DEBUG - 2024-09-25 17:24:06 --> Total execution time: 2.7547
INFO - 2024-09-25 17:24:13 --> Config Class Initialized
INFO - 2024-09-25 17:24:13 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:24:13 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:24:13 --> Utf8 Class Initialized
INFO - 2024-09-25 17:24:13 --> URI Class Initialized
INFO - 2024-09-25 17:24:13 --> Router Class Initialized
INFO - 2024-09-25 17:24:13 --> Output Class Initialized
INFO - 2024-09-25 17:24:13 --> Security Class Initialized
DEBUG - 2024-09-25 17:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:24:13 --> Input Class Initialized
INFO - 2024-09-25 17:24:13 --> Language Class Initialized
INFO - 2024-09-25 17:24:13 --> Language Class Initialized
INFO - 2024-09-25 17:24:13 --> Config Class Initialized
INFO - 2024-09-25 17:24:13 --> Loader Class Initialized
INFO - 2024-09-25 17:24:13 --> Helper loaded: url_helper
INFO - 2024-09-25 17:24:13 --> Helper loaded: file_helper
INFO - 2024-09-25 17:24:13 --> Helper loaded: form_helper
INFO - 2024-09-25 17:24:13 --> Helper loaded: my_helper
INFO - 2024-09-25 17:24:13 --> Database Driver Class Initialized
INFO - 2024-09-25 17:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:24:13 --> Controller Class Initialized
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1797
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 1804
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2022
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 67
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 86
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 98
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Undefined variable: projek /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 107
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 297
ERROR - 2024-09-25 17:24:13 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php 307
DEBUG - 2024-09-25 17:24:13 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_projek.php
ERROR - 2024-09-25 17:24:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
ERROR - 2024-09-25 17:24:16 --> Severity: Notice --> Trying to access array offset on value of type null /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/controllers/Cetak_raport.php 2037
INFO - 2024-09-25 17:24:17 --> Final output sent to browser
DEBUG - 2024-09-25 17:24:17 --> Total execution time: 3.6781
INFO - 2024-09-25 17:24:51 --> Config Class Initialized
INFO - 2024-09-25 17:24:51 --> Hooks Class Initialized
DEBUG - 2024-09-25 17:24:51 --> UTF-8 Support Enabled
INFO - 2024-09-25 17:24:51 --> Utf8 Class Initialized
INFO - 2024-09-25 17:24:51 --> URI Class Initialized
INFO - 2024-09-25 17:24:51 --> Router Class Initialized
INFO - 2024-09-25 17:24:51 --> Output Class Initialized
INFO - 2024-09-25 17:24:51 --> Security Class Initialized
DEBUG - 2024-09-25 17:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-09-25 17:24:51 --> Input Class Initialized
INFO - 2024-09-25 17:24:51 --> Language Class Initialized
INFO - 2024-09-25 17:24:51 --> Language Class Initialized
INFO - 2024-09-25 17:24:51 --> Config Class Initialized
INFO - 2024-09-25 17:24:51 --> Loader Class Initialized
INFO - 2024-09-25 17:24:51 --> Helper loaded: url_helper
INFO - 2024-09-25 17:24:51 --> Helper loaded: file_helper
INFO - 2024-09-25 17:24:51 --> Helper loaded: form_helper
INFO - 2024-09-25 17:24:51 --> Helper loaded: my_helper
INFO - 2024-09-25 17:24:51 --> Database Driver Class Initialized
INFO - 2024-09-25 17:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-09-25 17:24:51 --> Controller Class Initialized
DEBUG - 2024-09-25 17:24:51 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport/views/cetak_tahfiz.php
INFO - 2024-09-25 17:24:55 --> Final output sent to browser
DEBUG - 2024-09-25 17:24:55 --> Total execution time: 3.8826
