<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-12-01 09:27:32 --> Config Class Initialized
INFO - 2024-12-01 09:27:32 --> Hooks Class Initialized
DEBUG - 2024-12-01 09:27:32 --> UTF-8 Support Enabled
INFO - 2024-12-01 09:27:32 --> Utf8 Class Initialized
INFO - 2024-12-01 09:27:32 --> URI Class Initialized
INFO - 2024-12-01 09:27:32 --> Router Class Initialized
INFO - 2024-12-01 09:27:32 --> Output Class Initialized
INFO - 2024-12-01 09:27:32 --> Security Class Initialized
DEBUG - 2024-12-01 09:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 09:27:32 --> Input Class Initialized
INFO - 2024-12-01 09:27:32 --> Language Class Initialized
INFO - 2024-12-01 09:27:32 --> Language Class Initialized
INFO - 2024-12-01 09:27:32 --> Config Class Initialized
INFO - 2024-12-01 09:27:32 --> Loader Class Initialized
INFO - 2024-12-01 09:27:32 --> Helper loaded: url_helper
INFO - 2024-12-01 09:27:32 --> Helper loaded: file_helper
INFO - 2024-12-01 09:27:32 --> Helper loaded: form_helper
INFO - 2024-12-01 09:27:32 --> Helper loaded: my_helper
INFO - 2024-12-01 09:27:32 --> Database Driver Class Initialized
INFO - 2024-12-01 09:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 09:27:32 --> Controller Class Initialized
INFO - 2024-12-01 09:27:32 --> Helper loaded: cookie_helper
INFO - 2024-12-01 09:27:32 --> Final output sent to browser
DEBUG - 2024-12-01 09:27:32 --> Total execution time: 0.0604
INFO - 2024-12-01 09:27:33 --> Config Class Initialized
INFO - 2024-12-01 09:27:33 --> Hooks Class Initialized
DEBUG - 2024-12-01 09:27:33 --> UTF-8 Support Enabled
INFO - 2024-12-01 09:27:33 --> Utf8 Class Initialized
INFO - 2024-12-01 09:27:33 --> URI Class Initialized
INFO - 2024-12-01 09:27:33 --> Router Class Initialized
INFO - 2024-12-01 09:27:33 --> Output Class Initialized
INFO - 2024-12-01 09:27:33 --> Security Class Initialized
DEBUG - 2024-12-01 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 09:27:33 --> Input Class Initialized
INFO - 2024-12-01 09:27:33 --> Language Class Initialized
INFO - 2024-12-01 09:27:33 --> Language Class Initialized
INFO - 2024-12-01 09:27:33 --> Config Class Initialized
INFO - 2024-12-01 09:27:33 --> Loader Class Initialized
INFO - 2024-12-01 09:27:33 --> Helper loaded: url_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: file_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: form_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: my_helper
INFO - 2024-12-01 09:27:33 --> Database Driver Class Initialized
INFO - 2024-12-01 09:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 09:27:33 --> Controller Class Initialized
INFO - 2024-12-01 09:27:33 --> Helper loaded: cookie_helper
INFO - 2024-12-01 09:27:33 --> Config Class Initialized
INFO - 2024-12-01 09:27:33 --> Hooks Class Initialized
DEBUG - 2024-12-01 09:27:33 --> UTF-8 Support Enabled
INFO - 2024-12-01 09:27:33 --> Utf8 Class Initialized
INFO - 2024-12-01 09:27:33 --> URI Class Initialized
INFO - 2024-12-01 09:27:33 --> Router Class Initialized
INFO - 2024-12-01 09:27:33 --> Output Class Initialized
INFO - 2024-12-01 09:27:33 --> Security Class Initialized
DEBUG - 2024-12-01 09:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 09:27:33 --> Input Class Initialized
INFO - 2024-12-01 09:27:33 --> Language Class Initialized
INFO - 2024-12-01 09:27:33 --> Language Class Initialized
INFO - 2024-12-01 09:27:33 --> Config Class Initialized
INFO - 2024-12-01 09:27:33 --> Loader Class Initialized
INFO - 2024-12-01 09:27:33 --> Helper loaded: url_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: file_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: form_helper
INFO - 2024-12-01 09:27:33 --> Helper loaded: my_helper
INFO - 2024-12-01 09:27:33 --> Database Driver Class Initialized
INFO - 2024-12-01 09:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 09:27:33 --> Controller Class Initialized
DEBUG - 2024-12-01 09:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/lihat_raport/views/list.php
DEBUG - 2024-12-01 09:27:33 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/views/template_utama.php
INFO - 2024-12-01 09:27:33 --> Final output sent to browser
DEBUG - 2024-12-01 09:27:33 --> Total execution time: 0.0339
INFO - 2024-12-01 09:27:39 --> Config Class Initialized
INFO - 2024-12-01 09:27:39 --> Hooks Class Initialized
DEBUG - 2024-12-01 09:27:39 --> UTF-8 Support Enabled
INFO - 2024-12-01 09:27:39 --> Utf8 Class Initialized
INFO - 2024-12-01 09:27:39 --> URI Class Initialized
INFO - 2024-12-01 09:27:39 --> Router Class Initialized
INFO - 2024-12-01 09:27:39 --> Output Class Initialized
INFO - 2024-12-01 09:27:39 --> Security Class Initialized
DEBUG - 2024-12-01 09:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-12-01 09:27:39 --> Input Class Initialized
INFO - 2024-12-01 09:27:39 --> Language Class Initialized
INFO - 2024-12-01 09:27:39 --> Language Class Initialized
INFO - 2024-12-01 09:27:39 --> Config Class Initialized
INFO - 2024-12-01 09:27:39 --> Loader Class Initialized
INFO - 2024-12-01 09:27:39 --> Helper loaded: url_helper
INFO - 2024-12-01 09:27:39 --> Helper loaded: file_helper
INFO - 2024-12-01 09:27:39 --> Helper loaded: form_helper
INFO - 2024-12-01 09:27:39 --> Helper loaded: my_helper
INFO - 2024-12-01 09:27:39 --> Database Driver Class Initialized
INFO - 2024-12-01 09:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-12-01 09:27:39 --> Controller Class Initialized
DEBUG - 2024-12-01 09:27:39 --> File loaded: /www/wwwroot/report.mhis.link/bangka/secondary/application/modules/cetak_raport_pts/views/cetak_pts_mh.php
INFO - 2024-12-01 09:27:42 --> Final output sent to browser
DEBUG - 2024-12-01 09:27:42 --> Total execution time: 3.0269
